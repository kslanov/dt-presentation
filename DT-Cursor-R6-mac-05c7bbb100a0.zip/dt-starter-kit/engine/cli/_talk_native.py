"""Ввод ключа Толка и выбор записи на Mac."""

import json
import re
import subprocess

from core.ingress.talk_account import space_secret
from core.secrets import KEYCHAIN_ACCOUNT, KEYCHAIN_PREFIX, get_secret


def dialog(label, choices=None, *, secret=False):
    # Only the calling process receives the result. Neither key nor meeting data goes in argv.
    config = json.dumps({"label": label, "choices": choices, "secret": secret}, ensure_ascii=True)
    script = """const app = Application.currentApplication(); app.includeStandardAdditions = true;
    app.activate();
    const c = CONFIG;
    function ask() {
      if (c.choices) {
        const answer = app.chooseFromList(c.choices, {withTitle:'Digital Twin · Толк',
          withPrompt:c.label, multipleSelectionsAllowed:false});
        return answer === false ? '' : String(c.choices.indexOf(answer[0]) + 1);
      }
      return app.displayDialog(c.label, {withTitle:'Digital Twin · Толк',
        defaultAnswer:'', hiddenAnswer:c.secret}).textReturned;
    }
    ask();""".replace("CONFIG", config, 1)
    proc = subprocess.run(
        ["/usr/bin/osascript", "-l", "JavaScript", "-"],
        input=script,
        capture_output=True,
        text=True,
        check=False,
    )
    if proc.returncode or not proc.stdout.strip():
        raise ValueError("Ввод отменен.")
    return proc.stdout.strip()


def connect(space):
    """Save a PAT in the DT keychain, scoped to the space receiving it."""
    name = space_secret(space)
    token = dialog(
        f"Вставьте персональный ключ Толка для {space}.ktalk.ru. "
        "DT сохранит его в системной связке ключей этого Mac.",
        secret=True,
    )
    if not re.fullmatch(r"talkusr\.[!-~]+", token):
        raise ValueError("Ожидается персональный ключ Толка с префиксом talkusr.")
    # security reads twice from its terminal. Only expect's stdin carries the secret.
    script = r"""
        log_user 0
        set timeout 120
        if {[gets stdin secret] < 0} {exit 1}
        spawn -noecho /usr/bin/security add-generic-password -U -a ACCOUNT -s SERVICE -w
        expect {
            -nocase -re {password[^:\r\n]*:[ ]*$} {send -- "$secret\r"; exp_continue}
            eof {catch wait result; exit [lindex $result 3]}
            timeout {exit 1}
        }
    """.replace("ACCOUNT", KEYCHAIN_ACCOUNT).replace("SERVICE", KEYCHAIN_PREFIX + name)
    proc = subprocess.run(  # noqa: S603 - fixed executable, validated service, PAT via stdin
        ["/usr/bin/expect", "-c", script],
        input=token + "\n",
        text=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    if proc.returncode or get_secret(name) != token:
        raise ValueError("DT не подтвердил сохранение ключа в системной связке.")
    return token


