@echo off
setlocal
set "PYTHONUTF8=1"
set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Links;%ProgramFiles%\Git\cmd;%LOCALAPPDATA%\Programs\Git\cmd;%PATH%"
cd /d "%~dp0engine" || exit /b 1
set "PYTHONPATH=%CD%"
if not exist ".venv\Scripts\python.exe" (echo Run START.cmd prepare first. & exit /b 1)
".venv\Scripts\python.exe" -X utf8 "..\installer\command.py" %*
exit /b %errorlevel%
