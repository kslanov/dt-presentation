@echo off
setlocal
if /i "%~1"=="guide" (
  if exist "%~dp0engine\.venv\Scripts\python.exe" if exist "%~dp0engine\.venv\Lib\site-packages\yaml\__init__.py" goto liveguide
  start "" "%~dp0Guide.html"
  exit /b
)
set "DT_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "DT_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%DT_PS%" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0installer\bootstrap.ps1" %*
exit /b %errorlevel%
:liveguide
call "%~dp0DT.cmd" guide open
exit /b %errorlevel%
