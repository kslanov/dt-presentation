# Digital Twin Engine 0.3.17 для Windows

Начните с INSTALL.md в корне комплекта. Команда DT.cmd использует окружение Python этой установки.
