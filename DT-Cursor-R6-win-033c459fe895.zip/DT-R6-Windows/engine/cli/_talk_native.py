"""Interactive setup on the Windows test machine."""
import getpass
import re
import sys

from core.ingress.talk_account import space_secret
from core.windows_credential import read, store


def dialog(label, choices=None, *, secret=False):
    if not sys.stdin.isatty():
        raise ValueError("Откройте PowerShell в папке комплекта и запустите DT.cmd talk.")
    if choices:
        for choice in choices:
            print(choice)
        label += " (номер)"
    value = (getpass.getpass if secret else input)(label + ": ").strip()
    if not value:
        raise ValueError("Ввод отменен.")
    if choices and (not value.isdecimal() or not 1 <= int(value) <= len(choices)):
        raise ValueError("Введите номер из списка.")
    return value


def connect(space):
    value = dialog(f"Персональный ключ для {space}.ktalk.ru", secret=True)
    if not re.fullmatch(r"talkusr\.[!-~]+", value):
        raise ValueError("Ожидается персональный ключ Толка.")
    name = space_secret(space)
    store(name, value)
    if read(name) != value:
        raise ValueError("Не удалось проверить сохраненный ключ.")
