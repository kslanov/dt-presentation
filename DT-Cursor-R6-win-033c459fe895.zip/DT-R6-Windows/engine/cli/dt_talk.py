"""Import one user-selected Kontur Talk recording from the owner's space."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from cli._env import load_env
from cli._talk_native import connect, dialog
from core import connectors
from core.config import default_vault_path, engine_env_path
from core.config.env_file import set_key
from core.ingress import talk_service as talk
from core.ingress.talk_account import space_secret
from core.instance import instance_role
from core.secrets import get_secret


def select(label, options):
    if not options:
        raise ValueError("Вариантов для выбора нет.")
    # Include ordinal so equally named meetings and utterances stay distinguishable.
    rows = [f"{i}. {value}" for i, value in enumerate(options, 1)]
    return int(dialog(label, rows)) - 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--import-package", type=Path, help="папка проверенного предпросмотра Толка"
    )
    parser.add_argument("--apply", action="store_true", help="сохранить проверенный пакет в vault")
    for key in ("space", "query", "hub"):
        parser.add_argument("--" + key)
    parser.add_argument("--replace-key", action="store_true", help="заменить сохраненный ключ")
    parser.add_argument("--connect", action="store_true", help="сохранить ключ пространства для DT")
    args = parser.parse_args(argv)
    try:
        load_env()
        if instance_role() != "work":
            raise ValueError("Импорт предназначен для рабочего DT.")
        if args.import_package:
            from core.ingress.talk_package import import_package

            if not args.hub:
                parser.error("для импорта пакета укажите --hub")
            print(
                import_package(
                    args.import_package, default_vault_path(), args.hub, apply=args.apply
                )
            )
            return 0
        if args.apply:
            parser.error("--apply применяется только с --import-package")
        space = talk.normalize_space(
            args.space or os.getenv("DT_TALK_SPACE") or dialog("Адрес пространства Толка")
        )
        if args.connect:
            if not get_secret(space_secret(space)) or args.replace_key:
                connect(space)
            set_key(engine_env_path(), "DT_TALK_SPACE", space)
            if connectors.mode() != connectors.AUTO:
                active = [k for k in connectors.CONNECTORS if connectors.enabled(k) or k == "talk"]
                set_key(engine_env_path(), "DT_CONNECTORS", ",".join(active))
            print("Толк подключен. Перезапустите службу DT для загрузки настроек.")
            return 0
        os.environ["DT_TALK_SPACE"] = space
        query = args.query or dialog("Название записи для поиска")
        hub = args.hub or dialog("ID проекта или клиента в DT")
        offset = 0
        while True:
            page = talk.search(query, offset)
            records = page["recordings"]
            labels = [f"{r['createdDate']} · {r['title']}" for r in records]
            if page["next_offset"] is not None:
                labels.append("Следующая страница")
            index = select("Выберите запись", labels)
            if index < len(records):
                break
            offset = page["next_offset"]
        key = records[index]["id"]
        preview = talk.preview(query, key, hub, offset)
        print(preview["summary"])
        rows = preview["utterances"]
        row = rows[
            select(
                "Реплика для ссылки из хаба",
                [f"{r['clock']} · {r['who']} · {r['text'][:140]}" for r in rows],
            )
        ]
        select(f"Сохранить {preview['path']} и добавить ссылки в хаб?", ["Сохранить"])
        result = talk.apply_review(query, key, hub, row["anchor"], preview["review"], offset)
        print(result["path"])
        return 0
    except (KeyError, TypeError):
        print("Ответ Толка отличается от схемы API.", file=sys.stderr)
    except (ValueError, OSError, RuntimeError) as exc:
        print(str(exc), file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
