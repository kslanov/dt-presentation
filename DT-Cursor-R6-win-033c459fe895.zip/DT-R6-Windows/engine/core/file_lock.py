"""Reentrant per-path lock for file read/modify/publish transactions.

RLock serializes threads, flock serializes processes. The sidecar inode is stable:
never unlink it on release. All cooperating writers must use the same target path.
External editors do not take this lock; callers must still check expected hashes.
"""

from __future__ import annotations

import hashlib
import os
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from core import os_runtime as fcntl

_guard = threading.Lock()
_locks: dict[str, threading.RLock] = {}
_held = threading.local()


@contextmanager
def file_lock(path: Path) -> Iterator[None]:
    target = Path(path).resolve()
    key = os.path.normcase(str(target))
    with _guard:
        lock = _locks.setdefault(key, threading.RLock())
    with lock:
        held = getattr(_held, "paths", None)
        if held is None:
            held = _held.paths = set()
        if key in held:
            yield
            return
        directory = fcntl.lock_directory()
        sidecar = directory / (hashlib.sha256(key.encode()).hexdigest() + ".lock")
        fd = os.open(sidecar, os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0), 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            held.add(key)
            try:
                yield
            finally:
                held.remove(key)
                fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)
