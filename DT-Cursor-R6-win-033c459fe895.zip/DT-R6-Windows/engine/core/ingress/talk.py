"""Manual one-recording import. Obsidian block links point at source utterances."""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import quote, urlsplit

import frontmatter

from core.eventlog import emit
from core.file_lock import file_lock
from core.ingress.provenance import stamp_fields
from core.note_writer import sha256_bytes, write_note_atomic
from core.operational.hub_notes import append_reference
from core.output import slugify
from core.privacy import is_nda
from core.vault import read_note, resolve_note_path

FOLDER = "02-knowledge/meetings/"
START = "<!-- dt-talk:begin -->"
END = "<!-- dt-talk:end -->"


def digest(*parts):
    return hashlib.sha256(json.dumps(parts, ensure_ascii=False).encode()).hexdigest()


def plain(value):
    return " ".join("".join(c if c.isprintable() else " " for c in str(value)).split())


def literal(value):
    return re.sub(r"([\\`*_\[\]<>|^#~])", r"\\\1", plain(value))


def speaker(ref):
    if isinstance(ref, str):
        return ref
    if isinstance(ref, dict):
        user = ref.get("userInfo") or ref
        full_name = " ".join(user.get(k) or "" for k in ("firstname", "surname")).strip()
        return (
            full_name
            or ref.get("anonymousName")
            or ref.get("displayName")
            or ref.get("name")
            or ref.get("userName")
        )
    return None


@dataclass(frozen=True)
class Utterance:
    anchor: str
    offset: int
    who: str
    text: str

    @property
    def clock(self):
        seconds = self.offset // 1000
        return f"{seconds // 3600:02}:{seconds // 60 % 60:02}:{seconds % 60:02}"


def utterances(data):
    if data.get("status") != "complete" or data.get("errors"):
        raise ValueError("Транскрипция еще обрабатывается или содержит ошибки.")
    rows = []
    anchors = set()
    for track in data["tracks"]:
        for c in track["chunks"]:
            if not isinstance(c.get("text"), str):
                raise ValueError("В реплике отсутствует текст.")
            body = plain(c["text"])
            if not body:
                continue
            offset = c.get("startTimeOffsetInMillis", c.get("timeOffsetInMillis"))
            if type(offset) is not int or offset < 0:
                raise ValueError("У реплики нет корректного времени начала.")
            who = (
                speaker(c.get("diarizedSpeaker"))
                or speaker(track.get("diarizedSpeaker"))
                or speaker(track.get("speaker"))
                or "Спикер не указан"
            )
            chunk_id = c.get("chunkId")
            anchor = (
                "talk-"
                + digest(track.get("trackId"), offset if chunk_id is None else chunk_id)[:20]
            )
            if anchor in anchors:
                raise ValueError("API вернул неоднозначные идентификаторы реплик.")
            anchors.add(anchor)
            rows.append(Utterance(anchor, offset, plain(who), body))
    if not rows:
        raise ValueError("Готовых текстовых реплик нет.")
    return sorted(rows, key=lambda r: (r.offset, r.anchor))


@dataclass
class ImportResult:
    new: int
    changed: int
    unchanged: int
    dry_run: bool
    path: str
    anchor: str


def resolve_hub(vault, hub):
    if is_nda(hub):
        raise ValueError("Выберите рабочий хаб.")
    path = resolve_note_path(hub, vault_path=vault)
    if path is None:
        raise ValueError("Хаб не найден.")
    rel = path.resolve().relative_to(vault.resolve())
    if is_nda(rel) or rel.parts[0] not in ("03-projects", "04-clients"):
        raise ValueError("Выбери рабочий хаб проекта или клиента.")
    note = read_note(path)
    if note.type != "hub" and path.name != "hub.md":
        raise ValueError("Выберите хаб проекта или клиента.")
    return path, note.id, "project" if rel.parts[0] == "03-projects" else "client"


def _existing(vault, ident):
    base = vault / FOLDER
    matches = [p for p in base.glob(f"*/*/*-{ident}.md") if not is_nda(p.relative_to(vault))]
    if len(matches) > 1:
        raise ValueError("Для одной записи найдены две заметки.")
    return matches[0] if matches else None


def _replace_transcript(post, block, old):
    before, start, tail = post.content.partition(START)
    prior, end, after = tail.partition(END)
    if not start or not end or START in tail or END in after:
        raise ValueError("Разметка расшифровки изменена вручную.")
    if digest(prior.strip()) != post.get("source_content_hash"):
        raise ValueError("Есть ручные правки внутри расшифровки. Требуется сверка.")
    if prior.strip() == block:
        return old
    old_anchors = set(re.findall(r" \^(talk-[a-f0-9]+)$", prior, re.M))
    if any(f" ^{anchor}\n" not in block + "\n" for anchor in old_anchors):
        raise ValueError("Изменились идентификаторы реплик. Сначала сверь ссылки.")
    post["summary_review"] = True
    post["source_content_hash"] = digest(block)
    post.content = before + START + "\n\n" + block + "\n\n" + END + after
    return frontmatter.dumps(post) + "\n"


def import_one(
    *, vault: Path, space, recording, data, hub, anchor, finding="", source_url="", dry_run=True
):
    vault = vault.resolve()
    title, key = recording["title"], recording["id"]
    if not title or not key or any(is_nda(v) for v in (title, key, space, hub)):
        raise ValueError("Запись исключена из импорта.")
    created = datetime.fromisoformat(recording["createdDate"].replace("Z", "+00:00"))
    hub_path, hub_id, field = resolve_hub(vault, hub)
    rows = utterances(data)
    selected = next((row for row in rows if row.anchor == anchor), None)
    if selected is None:
        raise ValueError("Выбранной реплики в записи больше нет.")
    identity = digest(space, key)[:20]
    block = "\n\n".join(
        f"**{r.clock} · {literal(r.who)}** — {literal(r.text)} ^{r.anchor}" for r in rows
    )
    link = f"[[#^{anchor}|{selected.clock}]]"
    source_id = f"{space}:{key}"
    api_source = f"https://{space}.ktalk.ru/api/recordings/{quote(key, safe='')}/transcript"
    if source_url:
        parts = urlsplit(source_url)
        if (
            parts.scheme != "https"
            or parts.netloc != f"{space}.ktalk.ru"
            or parts.query
            or parts.fragment
            or not parts.path.strip("/")
            or not re.fullmatch(r"/[A-Za-z0-9._/%~-]+", parts.path)
        ):
            raise ValueError("Укажите постоянную ссылку из этого пространства без параметров.")
    source = source_url or api_source
    with file_lock(vault / FOLDER / identity):
        path = _existing(vault, identity)
        if path and (path.is_symlink() or not path.resolve().is_relative_to(vault)):
            raise ValueError("Путь заметки перенаправлен.")
        if path is None:
            rel = f"{FOLDER}{created:%Y/%m/%Y-%m-%d} — {slugify(title)}-{identity}.md"
            path = vault / rel
        rel = path.relative_to(vault).as_posix()
        previous = path.read_bytes() if path.is_file() else None
        if previous is None:
            post = frontmatter.Post("")
            post.metadata.update(
                stamp_fields("talk", source_id),
                id="talk-" + identity,
                type="meeting",
                title=plain(title),
                created=created.date().isoformat(),
                source_path=source,
                participants=[
                    plain(speaker(p)) for p in recording.get("participants") or [] if speaker(p)
                ],
                source_content_hash=digest(block),
            )
            post[field] = "[[" + hub_id + "]]"
            summary = (
                literal(finding) if finding else "Выбранная реплика — " + literal(selected.text)
            )
            post.content = (
                f"# {literal(title)}\n\n[Источник в Толке]({source})\n\n"
                f"## Итоги\n\n{summary} {link}\n\n"
                f"## Расшифровка\n\n{START}\n\n{block}\n\n{END}"
            )
            text = frontmatter.dumps(post) + "\n"
        else:
            old = previous.decode()
            post = frontmatter.loads(old)
            if post.get("source_id") != source_id or post.get("source") != "talk":
                raise ValueError("Путь занят другой заметкой.")
            text = _replace_transcript(post, block, old)
        changed = previous is not None and text.encode() != previous
        result = ImportResult(
            int(previous is None),
            int(changed),
            int(previous == text.encode()),
            dry_run,
            rel,
            anchor,
        )
        if dry_run:
            return result
        if previous is None or changed:
            write_note_atomic(
                vault,
                rel,
                text,
                allowed_prefix=FOLDER,
                expect_sha=sha256_bytes(previous) if previous is not None else None,
            )
        target = rel.removesuffix(".md")
        reference = (
            f"[[{target}|{slugify(title)}]] · [[{target}#^{anchor}|реплика {selected.clock}]]"
        )
        with file_lock(hub_path):
            append_reference(hub_path, reference, vault_path=vault, now=created)
            if reference not in hub_path.read_text() or not any(
                line.endswith(f" — {literal(selected.text)} ^{anchor}")
                for line in path.read_text().splitlines()
            ):
                raise ValueError("Не удалось подтвердить ссылку из хаба на выбранную реплику.")
        emit("ingest", "ok", note_id="talk-" + identity, path=rel, detail={"source": "talk"})
        return result
