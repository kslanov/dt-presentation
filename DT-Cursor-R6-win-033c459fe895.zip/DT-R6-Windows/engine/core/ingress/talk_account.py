"""Имя пространства и привязка ключа к единственному получателю."""

import re


def normalize_space(value):
    space = value.strip().lower().removeprefix("https://").rstrip("/").removesuffix(".ktalk.ru")
    if not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", space):
        raise ValueError("Укажите адрес пространства вида имя.ktalk.ru.")
    return space


def space_secret(space):
    return "DT_TALK_PAT_" + normalize_space(space).upper().replace("-", "_")
