"""Optional macOS Obsidian setup for the vault configured by DT."""

from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path
from urllib.parse import quote

from core.file_lock import file_lock
from core.install.base import ABSENT, DONE, PARTIAL, InstallError, Step, StepCheck, StepResult
from core.install.context import InstallContext
from core.mcp_json_edit import write_text_atomic

_VAULT_MARKERS = ("_system/ingest-roots.yaml", "_system/retrieval-policies")


def _target(ctx: InstallContext) -> Path:
    value = ctx.env_values().get("DT_VAULT_PATH")
    configured = (Path(value).expanduser() if value else ctx.workspace / "vault").resolve()
    if ctx.vault.resolve() != configured:
        raise InstallError("obsidian_vault", "выбранный vault отличается от настроенного в DT",
                           f"повтори шаг для vault, подключенного к DT: {configured}")
    if not ctx.env_path.is_file() or not all((configured / p).exists() for p in _VAULT_MARKERS):
        raise InstallError("obsidian_vault", "сначала подготовь vault установщиком DT",
                           "выполни dt install с выбранным путем --vault")
    return configured


def _app(ctx: InstallContext) -> Path | None:
    for root in (Path(os.environ["LOCALAPPDATA"]), Path(os.environ["ProgramFiles"])):
        for name in ("Programs/Obsidian/Obsidian.exe", "Obsidian/Obsidian.exe"):
            candidate = root / name
            if candidate.is_file():
                return candidate
    return None


def _registry_path(ctx: InstallContext) -> Path:
    return Path(os.environ["APPDATA"]) / "obsidian/obsidian.json"


def _registry(path: Path) -> dict:
    if path.is_symlink():
        raise InstallError("obsidian_config", "список vault Obsidian является ссылкой")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (ValueError, OSError) as exc:
        raise InstallError("obsidian_config", "список vault Obsidian не читается",
                           "открой выбранный vault в Obsidian и повтори шаг") from exc
    if not isinstance(data, dict) or not isinstance(data.get("vaults", {}), dict):
        raise InstallError("obsidian_config", "формат списка vault Obsidian не поддерживается")
    return data


def _entry(data: dict, target: Path) -> tuple[str, dict] | None:
    for key, value in data.get("vaults", {}).items():
        if isinstance(value, dict) and isinstance(value.get("path"), str):
            if Path(value["path"]).expanduser().resolve() == target:
                return key, value
    return None


def _capture(ctx: InstallContext, argv: list[str], code: str, reason: str) -> str:
    status, output = ctx.tools.capture(argv, ctx.engine_dir, None)
    if status:
        raise InstallError(code, reason, output.strip().splitlines()[-1] if output.strip() else "")
    return output


def _install(ctx: InstallContext) -> Path:
    code, _ = ctx.tools.run_cmd(["winget", "install", "--exact", "--id", "Obsidian.Obsidian",
                                 "--source", "winget"], ctx.engine_dir, None)
    app = _app(ctx)
    if code or app is None:
        raise InstallError("obsidian_app", "не удалось установить Obsidian через WinGet")
    return app


def _running(ctx: InstallContext) -> bool:
    output = _capture(ctx, ["tasklist", "/FI", "IMAGENAME eq Obsidian.exe", "/NH"],
                      "obsidian_process", "не удалось проверить состояние Obsidian")
    return "obsidian.exe" in output.lower()


def _register(ctx: InstallContext, path: Path, target: Path, data: dict) -> str:
    if _running(ctx):
        raise InstallError("obsidian_running", "Obsidian уже открыт с другим vault",
                           "закрой Obsidian и повтори шаг или открой указанную папку в приложении")
    ctx.guard(path.resolve())
    if _registry(path) != data:
        raise InstallError("obsidian_config", "список vault изменился, повтори шаг")
    key = uuid.uuid4().hex[:16]
    data.setdefault("vaults", {})[key] = {"path": str(target), "ts": int(time.time() * 1000)}
    path.parent.mkdir(parents=True, exist_ok=True)
    write_text_atomic(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    return key


def check(ctx: InstallContext) -> StepCheck:
    target = _target(ctx)
    if _app(ctx) is None:
        return StepCheck(ABSENT, "Obsidian не установлен")
    match = _entry(_registry(_registry_path(ctx)), target)
    if match and (match[1].get("open") is True or (target / ".obsidian/workspace.json").is_file()):
        return StepCheck(DONE, f"vault подключен к Obsidian: {target}")
    return StepCheck(PARTIAL, f"Obsidian установлен, vault еще не открыт: {target}")


def run(ctx: InstallContext) -> StepResult:
    target = _target(ctx)
    if ctx.tools.probe.system() != "Windows" or ctx.home != Path.home().resolve():
        raise InstallError("obsidian_platform", "шаг открывает Obsidian в текущем сеансе Windows",
                           "запусти его в Cursor под своим пользователем")
    path = _registry_path(ctx)
    ctx.guard(path.resolve())
    with file_lock(path):
        data = _registry(path)
        match = _entry(data, target)
        app = _app(ctx) or _install(ctx)
        key = match[0] if match else _register(ctx, path, target, data)
        uri = "obsidian://open?vault=" + quote(key, safe="")
        import subprocess
        subprocess.Popen([str(app), uri], cwd=app.parent)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            current = _entry(_registry(path), target)
            if current and current[1].get("open") is True:
                return StepResult(note=f"Obsidian открыл vault DT: {target}")
            time.sleep(0.25)
    raise InstallError("obsidian_open", f"Obsidian не подтвердил открытие: {target}",
                       "проверь окно Obsidian и повтори dt install --step obsidian")


STEP = Step("obsidian", "Obsidian", "Установить при необходимости и открыть vault DT",
            check, run, "Obsidian для Windows")
