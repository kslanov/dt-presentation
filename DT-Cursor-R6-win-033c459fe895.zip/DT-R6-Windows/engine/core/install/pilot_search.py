"""Evidence for the Windows starter kit's single control source."""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

from core.mcp_json_edit import write_text_atomic

QUERY = "На какой день недели назначена передача записей дежурному?"


def folder(ctx):
    vault = Path(ctx.env_values().get("DT_VAULT_PATH") or ctx.vault).resolve()
    key = hashlib.sha256(str(vault).encode()).hexdigest()[:24]
    return ctx.derived / "install" / "semantic" / key


def read(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (FileNotFoundError, ValueError):
        return {}


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    write_text_atomic(path, json.dumps({**data, "at": datetime.now(UTC).isoformat()}))


def evidence(ctx):
    root = folder(ctx)
    return {"probe": read(root / "probe.json"), "cursor": read(root / "cursor.json")}


def source_note(ctx):
    from core.config import current_ingest_manifest_path, legacy_ingest_manifest_path
    from core.vault import read_note

    for path in (current_ingest_manifest_path(), legacy_ingest_manifest_path()):
        rec = read(path).get("control-note.md", {})
        if rec.get("root") == "windows-pilot" and rec.get("note_path"):
            note = (ctx.vault / rec["note_path"]).resolve()
            if note.is_relative_to(ctx.vault.resolve()) and note.is_file():
                return read_note(note, ctx.vault)
    return None


def record_cursor(ctx, hits, warnings):
    from core.host import current_host

    host = current_host()
    if (
        "cursor" not in host["name"].casefold()
        or not (ctx.engine_dir.parent / "KIT-MANIFEST.json").is_file()
    ):
        return
    note = source_note(ctx)
    if note is None:
        return
    match = next((h for h in hits if h["note_id"] == note.id), {})
    degraded = any(w.get("component") == "semantic" for w in warnings)
    save(
        folder(ctx) / "cursor.json",
        {"found": bool(match), "matched_by": match.get("matched_by"), "semantic_warning": degraded},
    )
