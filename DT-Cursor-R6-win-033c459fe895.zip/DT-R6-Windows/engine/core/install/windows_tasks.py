"""User-scoped background jobs for the Windows starter kit."""
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

from core.install.base import ABSENT, DONE, PARTIAL, InstallError, StepCheck, StepResult

JOBS = {"server": (0, 0), "sync.fast": (0, 30), "sync.index": (3, 0), "backup": (11, 0)}


def task(engine, key, mode):
    hour, minutes = JOBS[key]
    engine = Path(engine).resolve()
    identity = hashlib.sha256(os.path.normcase(str(engine)).encode()).hexdigest()[:12]
    spec = {"engine": str(engine), "key": key, "mode": mode, "hour": hour, "minutes": minutes,
            "owner": f"Digital Twin R6 | {engine}", "name": f"DT-{identity}-{key}",
            "program": str(engine / ".venv/Scripts/pythonw.exe"),
            "arguments": subprocess.list2cmdline(["-X", "utf8", "ops/windows_job.py", key])}
    shell = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    result = subprocess.run([str(shell), "-NoProfile", "-NonInteractive", "-ExecutionPolicy",
                             "Bypass", "-File", str(engine / "ops/windows-task.ps1")],
                            env={**os.environ, "DT_TASK_SPEC": json.dumps(spec, ensure_ascii=False)},
                            capture_output=True, encoding="utf-8", errors="replace", timeout=45)
    if result.returncode:
        raise InstallError("windows_task", f"{key}: {result.stderr.strip()[:700]}")
    return json.loads(result.stdout) if mode == "status" else None


def healthy(ctx):
    from core.daemon import fetch_health

    health = fetch_health(port=8787) or {}
    receipt = ctx.derived / "install/server.pid"
    try:
        pid = int(receipt.read_text(encoding="ascii"))
    except (ValueError, OSError):
        return False
    return bool(health.get("ok") and health.get("pid") == pid and "lean" in health.get("profiles", []))


def check(ctx):
    if os.name != "nt":
        return StepCheck(ABSENT, "требуется Планировщик заданий Windows")
    states = {key: task(ctx.engine_dir, key, "status") for key in JOBS}
    missing = [key for key, row in states.items() if not row["valid"]]
    if missing:
        return StepCheck(PARTIAL, "требуют регистрации: " + ", ".join(missing))
    if not states["server"]["running"] or not healthy(ctx):
        return StepCheck(PARTIAL, "служба этого экземпляра еще не отвечает на 127.0.0.1:8787")
    return StepCheck(DONE, "4 задания зарегистрированы, служба отвечает")


def run(ctx):
    from core.daemon import fetch_health

    if os.name != "nt":
        raise InstallError("windows_task", "нужна Windows 11")
    if fetch_health(port=8787) and not healthy(ctx):
        raise InstallError("port_in_use", "на порту 8787 уже работает другой экземпляр DT")
    for key in JOBS:
        if not task(ctx.engine_dir, key, "status")["valid"]:
            task(ctx.engine_dir, key, "register")
    if not task(ctx.engine_dir, "server", "status")["running"]:
        task(ctx.engine_dir, "server", "start")
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        if healthy(ctx):
            status, _ = ctx.tools.capture(ctx.python_cmd(
                "mcp-server/server.py", "--transport", "http", "--port", "8787", "--selftest"),
                ctx.engine_dir, ctx.child_env())
            if status:
                raise InstallError("server_mcp", "служба запущена, проверка инструментов MCP не прошла")
            return StepResult(note="Планировщик Windows запустил службу DT")
        time.sleep(1)
    raise InstallError("server_start", "служба DT не подтвердила запуск",
                       "проверь .derived/install/server.log и состояние задания server")


def installed_labels(ctx):
    if os.name != "nt":
        return []
    return [key for key in JOBS if task(ctx.engine_dir, key, "status")["present"]]


def remove_labels(ctx, labels):
    for key in labels:
        task(ctx.engine_dir, key, "remove")
        yield key
