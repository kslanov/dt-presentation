"""Confirmed work context in the profile read by owner_profile and generation."""

from core.file_lock import file_lock
from core.note_writer import sha256_bytes, write_note_atomic
from core.owner.store import ABOUT_FILE, profile_dir

FIELDS = {"activity": "Моя работа", "knowledge": "Предметные области"}
BEGIN = "<!-- dt:work-context -->"
END = "<!-- /dt:work-context -->"


def sections(text):
    before, start, rest = text.partition(BEGIN)
    block, end, after = rest.partition(END)
    if (
        bool(start) != bool(end)
        or BEGIN in block
        or END in before
        or END in after
        or BEGIN in after
    ):
        raise ValueError("Проверьте раздел рабочего контекста в about.md.")
    return before, block, after


def values(vault):
    path = profile_dir(vault) / ABOUT_FILE
    if not path.is_file():
        return {}
    _, block, _ = sections(path.read_text(encoding="utf-8"))
    lines = dict(line.split(": ", 1) for line in block.splitlines() if ": " in line)
    return {key: lines.get(label, "") for key, label in FIELDS.items()}


def apply(vault, answers):
    path = profile_dir(vault) / ABOUT_FILE
    with file_lock(path):
        old = path.read_bytes() if path.exists() else None
        text = old.decode("utf-8") if old is not None else ""
        before, _, after = sections(text)
        block = []
        for key, label in FIELDS.items():
            value = " ".join(answers.get(key, "").split())
            if BEGIN in value or END in value:
                raise ValueError("Уберите технический маркер из ответа.")
            if value:
                block.append(f"{label}: {value}")
        if not block and BEGIN not in text:
            return
        new = (
            before.rstrip()
            + "\n\n"
            + BEGIN
            + "\n"
            + "\n\n".join(block)
            + "\n"
            + END
            + (after or "\n")
        )
        if new != text:
            write_note_atomic(
                vault,
                path.relative_to(vault).as_posix(),
                new,
                allowed_prefix="_system/profile/",
                expect_sha=sha256_bytes(old) if old is not None else None,
            )
