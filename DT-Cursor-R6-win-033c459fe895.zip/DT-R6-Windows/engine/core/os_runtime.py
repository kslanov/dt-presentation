"""OS primitives shared by the installer, server and background writers."""
import errno
import os
import time
from pathlib import Path

if os.name == "nt":
    import ctypes
    import msvcrt
    from ctypes import wintypes

    LOCK_EX, LOCK_NB, LOCK_UN = 2, 4, 8

    def flock(file, operation):
        """Lock a byte beyond the data. Other processes can still read job metadata."""
        fd = file if isinstance(file, int) else file.fileno()
        offset = os.lseek(fd, 0, os.SEEK_CUR)
        try:
            os.lseek(fd, 1 << 30, os.SEEK_SET)
            if operation == LOCK_UN:
                msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
                return
            if operation not in (LOCK_EX, LOCK_EX | LOCK_NB):
                raise ValueError("unsupported file lock operation")
            while True:
                try:
                    msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                    return
                except OSError as exc:
                    if exc.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                        raise
                    if operation & LOCK_NB:
                        raise BlockingIOError(errno.EAGAIN, "busy") from exc
                    time.sleep(0.05)
        finally:
            os.lseek(fd, offset, os.SEEK_SET)

    def process_alive(pid):
        if pid <= 0:
            return False
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
        kernel.WaitForSingleObject.restype = wintypes.DWORD
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x00100000, False, pid)  # SYNCHRONIZE
        if not handle:
            err = ctypes.get_last_error()
            if err == 87:  # ERROR_INVALID_PARAMETER, PID is gone
                return False
            if err == 5:  # access denied; never reclaim a lock on this evidence
                return True
            raise ctypes.WinError(err)
        try:
            result = kernel.WaitForSingleObject(handle, 0)
            if result not in (0, 258):
                raise ctypes.WinError(ctypes.get_last_error())
            return result == 258
        finally:
            kernel.CloseHandle(handle)

    def lock_directory():
        root = Path(os.environ["LOCALAPPDATA"]).resolve()
        folder = root / "DigitalTwin" / "locks"
        folder.mkdir(parents=True, exist_ok=True)
        if folder.resolve() != folder:
            raise OSError("redirected lock directory")
        return folder
else:
    from fcntl import LOCK_EX, LOCK_NB, LOCK_UN, flock  # noqa: F401

    def process_alive(pid):
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        return True

    def lock_directory():
        directory = Path("/tmp") / f"dt-file-locks-{os.getuid()}"
        directory.mkdir(mode=0o700, exist_ok=True)
        if (directory.is_symlink() or directory.stat().st_uid != os.getuid()
                or directory.stat().st_mode & 0o077):
            raise OSError("unsafe file-lock directory")
        return directory
