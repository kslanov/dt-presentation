"""SLEEP-STORE-1 п.4 - короткая блокировка целевого набора применения (lease с TTL).

Параллельно работают человек, импорт, линт и синтез (sleep-1.md §6.2): применение берет блокировку
всех целей ОДНИМ атомарным шагом (``BEGIN IMMEDIATE``: либо все, либо ни одной). Занятая цель -
:class:`LockBusy` (конфликт, не ожидание и не слепая перезапись).

**Кто может забрать чужую блокировку** (:func:`_stale`): срок (``expires_at``) вышел; процесс-
хозяин не существует; либо хозяин - этот же процесс, но носитель (``holder``) уже не выполняется
(прерванное применение в том же процессе). Живой чужой процесс с неистекшим сроком -
блокировка уважается. Освобождение - по носителю (``holder``), чужую блокировку снять нельзя.
"""

from __future__ import annotations

import os
import uuid
from datetime import datetime, timedelta

from core.sleep_store.store import SleepStore

__all__ = ["LockBusy", "acquire", "active", "holders_of", "new_holder", "release"]

_ACTIVE: set[str] = set()   # носители, выполняющиеся в ЭТОМ процессе сейчас
_FMT = "%Y-%m-%dT%H:%M:%SZ"


class LockBusy(RuntimeError):
    def __init__(self, refs: dict[str, str]) -> None:
        super().__init__("цель занята другим применением: " + ", ".join(sorted(refs)))
        self.refs = refs  # {ref: holder}


def new_holder() -> str:
    token = f"{os.getpid()}-{uuid.uuid4().hex[:12]}"
    _ACTIVE.add(token)
    return token


def active(holder: str) -> bool:
    return holder in _ACTIVE


def forget(holder: str) -> None:
    """Носитель закончил (штатно или сбоем) в этом процессе; БД-блокировка остается до release."""
    _ACTIVE.discard(holder)


def _pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    from core.os_runtime import process_alive

    return process_alive(pid)


def _stale(row: dict[str, object], now: datetime) -> bool:
    expires = datetime.strptime(str(row["expires_at"]), _FMT)
    pid = int(row["pid"] or 0)  # type: ignore[call-overload]
    holder = str(row["holder"])
    if expires <= now:
        return True
    if not _pid_alive(pid):
        return True
    return pid == os.getpid() and holder not in _ACTIVE


def acquire(store: SleepStore, refs: list[str], holder: str, *, ttl_s: float, now: str,
            proposal_id: str = "") -> None:
    """Взять все ``refs`` или ни одной. ``LockBusy`` - хотя бы одна занята живым носителем."""
    moment = datetime.strptime(now, _FMT)
    until = (moment + timedelta(seconds=ttl_s)).strftime(_FMT)
    wanted = sorted(set(refs))
    with store.tx(immediate=True):
        busy: dict[str, str] = {}
        for ref in wanted:
            row = store.conn.execute("SELECT * FROM sleep_locks WHERE ref=?", (ref,)).fetchone()
            if row is None or str(row["holder"]) == holder:
                continue
            if _stale(dict(row), moment):
                store.conn.execute("DELETE FROM sleep_locks WHERE ref=?", (ref,))
            else:
                busy[ref] = str(row["holder"])
        if busy:
            raise LockBusy(busy)
        for ref in wanted:
            store.conn.execute(
                "INSERT OR REPLACE INTO sleep_locks(ref, holder, pid, proposal_id, acquired_at, "
                "expires_at) VALUES (?,?,?,?,?,?)",
                (ref, holder, os.getpid(), proposal_id, now, until))


def release(store: SleepStore, holder: str) -> int:
    """Снять все блокировки носителя; вернуть сколько снято."""
    with store.tx(immediate=True):
        n = store.conn.execute("DELETE FROM sleep_locks WHERE holder=?", (holder,)).rowcount
    forget(holder)
    return int(n)


def holders_of(store: SleepStore) -> list[dict[str, object]]:
    return [dict(r) for r in store.conn.execute("SELECT * FROM sleep_locks ORDER BY ref")]
