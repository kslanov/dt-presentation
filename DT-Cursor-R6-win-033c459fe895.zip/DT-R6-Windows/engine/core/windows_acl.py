"""Check Windows DACLs using untranslated SIDs. Never read or print file contents."""
import os
import subprocess
from pathlib import Path


def private_access(path):
    shell = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    script = """
$ErrorActionPreference='Stop'
$a=Get-Acl -LiteralPath $env:DT_ACL_TARGET
$me=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$trusted=@($me,'S-1-5-18','S-1-5-32-544','S-1-3-0')
if ($a.GetOwner([Security.Principal.SecurityIdentifier]).Value -notin $trusted) {exit 1}
if (!$a.AreAccessRulesCanonical -or !$a.Access.Count) {exit 1}
foreach ($r in $a.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])) {
    if ($r.AccessControlType -eq 'Allow' -and $r.IdentityReference.Value -notin $trusted) {exit 1}
}
exit 0
"""
    result = subprocess.run([str(shell), "-NoProfile", "-NonInteractive", "-Command", script],
                            env={**os.environ, "DT_ACL_TARGET": str(path)},
                            capture_output=True, timeout=30)
    return result.returncode == 0
