"""User-scoped generic credentials in Windows Credential Manager."""
import ctypes
from ctypes import wintypes


class Credential(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD), ("Type", wintypes.DWORD), ("TargetName", wintypes.LPWSTR),
        ("Comment", wintypes.LPWSTR), ("LastWritten", wintypes.FILETIME),
        ("CredentialBlobSize", wintypes.DWORD), ("CredentialBlob", ctypes.c_void_p),
        ("Persist", wintypes.DWORD), ("AttributeCount", wintypes.DWORD),
        ("Attributes", ctypes.c_void_p), ("TargetAlias", wintypes.LPWSTR),
        ("UserName", wintypes.LPWSTR),
    ]


def read(name):
    api = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    pointer = ctypes.POINTER(Credential)()
    api.CredReadW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(type(pointer))]
    if not api.CredReadW("dt:" + name, 1, 0, ctypes.byref(pointer)):
        return None
    try:
        item = pointer.contents
        return ctypes.string_at(item.CredentialBlob, item.CredentialBlobSize).decode("utf-16-le")
    finally:
        api.CredFree.argtypes = [ctypes.c_void_p]
        api.CredFree(pointer)


def store(name, value):
    api = ctypes.WinDLL("Advapi32.dll", use_last_error=True)
    raw = value.encode("utf-16-le")
    blob = ctypes.create_string_buffer(raw)
    item = Credential(Type=1, TargetName="dt:" + name, UserName="dt",
                      CredentialBlobSize=len(raw), CredentialBlob=ctypes.addressof(blob), Persist=2)
    api.CredWriteW.argtypes = [ctypes.POINTER(Credential), wintypes.DWORD]
    if not api.CredWriteW(ctypes.byref(item), 0):
        raise OSError(ctypes.get_last_error(), "Не удалось сохранить ключ в Диспетчере учетных данных.")
