"""Register only the supplied single-note pilot folder, preserving existing root entries."""

import yaml

from core.file_lock import file_lock
from core.install.context import InstallContext
from core.mcp_json_edit import write_text_atomic


def register(ctx):
    folder = ctx.engine_dir.parent / "control"
    document = folder / "control-note.md"
    if not document.is_file() or document.resolve() != document or folder.resolve() != folder:
        raise ValueError("Контрольный источник отсутствует или перенаправлен")
    target = ctx.vault / "_system/ingest-roots.yaml"
    entry = {"name": "windows-pilot", "path": str(folder), "route": "knowledge", "corpus": "current",
             "include": ["control-note.md"], "exclude": []}
    with file_lock(target):
        original = target.read_text(encoding="utf-8")
        data = yaml.safe_load(original)
        rows = data["roots"]
        for row in rows:
            if row["name"] == entry["name"]:
                if row != entry:
                    raise ValueError("Имя windows-pilot уже используется другим источником")
                return
        rows.append(entry)
        comments = "\n".join(line for line in original.splitlines() if line.startswith("#"))
        write_text_atomic(target, comments + "\n" + yaml.safe_dump(
            data, allow_unicode=True, sort_keys=False))


if __name__ == "__main__":
    register(InstallContext.build())
