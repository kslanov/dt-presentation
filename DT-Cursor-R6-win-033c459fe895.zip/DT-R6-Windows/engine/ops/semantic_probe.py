"""Read-only model and vector-index check after indexing the starter note."""

import json
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from cli._env import load_env
from core.file_lock import file_lock
from core.install.context import InstallContext
from core.install.pilot_search import QUERY, folder, read, save, source_note


def measure(ctx, emit):
    result = {"model": "pending", "index": "pending", "state": "running"}
    stage = "model"
    try:
        import numpy as np

        from core.embeddings import EMBEDDING_DIM, embed_query

        vector = np.asarray(embed_query(QUERY))
        if vector.shape != (EMBEDDING_DIM,) or not np.isfinite(vector).all() or not np.any(vector):
            raise ValueError("invalid_vector")
        result.update(model="ok", dimensions=vector.size)
        emit(result)
        stage = "index"
        import lancedb

        from core.config import lancedb_path
        from core.retrieval.index import TABLE_NAME

        path = lancedb_path()
        if not path.is_dir():
            raise FileNotFoundError("index")
        table = lancedb.connect(str(path)).open_table(TABLE_NAME)
        rows = (
            table.search(vector.tolist(), query_type="vector")
            .select(["note_id", "_distance"])
            .limit(10)
            .to_list()
        )
        result.update(index="ok" if rows else "empty", hits=len(rows))
        stage = "source"
        note = source_note(ctx)
        rank = next(
            (i for i, row in enumerate(rows, 1) if note and row["note_id"] == note.id), None
        )
        result.update(
            state="passed" if rank else "partial", rank=rank, source_registered=bool(note)
        )
    except Exception as exc:  # noqa: BLE001 - model and index backends expose different errors
        result.update(state="failed", stage=stage, error=type(exc).__name__)
        if stage in ("index", "model"):
            result[stage] = "failed"
        cause = exc.__cause__ or exc.__context__
        if cause:
            result["cause"] = type(cause).__name__
        message = str(exc).casefold()
        if "invalid_vector" in message:
            result["hint"] = "Некорректная размерность или значения вектора."
        elif "cache" in message and (
            "missing" in message or "not found" in message or "not cached" in message
        ):
            result["hint"] = "Модель не найдена в локальном кеше."
        elif isinstance(exc, FileNotFoundError):
            result["hint"] = "Проверьте наличие локальных файлов модели или индекса."
        elif isinstance(exc, (ImportError, ModuleNotFoundError)):
            result["hint"] = "Не загрузилась библиотека установленного ядра."
    emit(result)


def run(ctx):
    path = folder(ctx) / "probe.json"
    requested = time.time()
    with file_lock(path.with_suffix(".run")):
        last = read(path)
        if (
            last.get("state") in {"partial", "passed", "failed"}
            and datetime.fromisoformat(last["at"]).timestamp() >= requested
        ):
            return last
        save(path, {"state": "running", "model": "pending", "index": "pending"})
        try:
            subprocess.run(  # noqa: S603 - fixed local diagnostic with a bounded lifetime
                [sys.executable, "-X", "utf8", str(Path(__file__).resolve()), "--measure"],
                cwd=ctx.engine_dir,
                timeout=180,
                check=True,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            status = read(path)
            stage = "index" if status.get("model") == "ok" else "model"
            save(
                path,
                {
                    **status,
                    "state": "failed",
                    "stage": stage,
                    stage: "failed",
                    "error": type(exc).__name__,
                },
            )
        return read(path)


if __name__ == "__main__":
    load_env()
    ctx = InstallContext.build()
    if sys.argv[1:] == ["--measure"]:
        measure(ctx, lambda r: save(folder(ctx) / "probe.json", r))
    else:
        print(json.dumps(run(ctx)))
