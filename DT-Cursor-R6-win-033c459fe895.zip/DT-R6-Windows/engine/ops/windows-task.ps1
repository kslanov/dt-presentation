$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$spec = $env:DT_TASK_SPEC | ConvertFrom-Json
$scheduler = New-Object -ComObject 'Schedule.Service'
$scheduler.Connect()
$folder = $scheduler.GetFolder('\')
$user = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
$task = $folder.GetTasks(1) | Where-Object { $_.Name -eq $spec.name } | Select-Object -First 1
if ($task -and ($task.Definition.RegistrationInfo.Description -ne $spec.owner -or
                $task.Definition.Actions.Item(1).WorkingDirectory -ne $spec.engine)) {
    throw 'Task name belongs to another installation'
}
switch ($spec.mode) {
    'register' {
        $d = $scheduler.NewTask(0)
        $d.RegistrationInfo.Description = $spec.owner
        $d.Principal.UserId = $user
        $d.Principal.LogonType = 3
        $d.Principal.RunLevel = 0
        $d.Settings.Enabled = $true
        $d.Settings.StartWhenAvailable = $true
        $d.Settings.DisallowStartIfOnBatteries = $false
        $d.Settings.StopIfGoingOnBatteries = $false
        $d.Settings.MultipleInstances = 2
        $d.Settings.ExecutionTimeLimit = 'PT0S'
        $action = $d.Actions.Create(0)
        $action.Path = $spec.program
        $action.Arguments = $spec.arguments
        $action.WorkingDirectory = $spec.engine
        if ($spec.key -eq 'server') {
            $trigger = $d.Triggers.Create(9)
            $trigger.UserId = $user
            $d.Settings.RestartCount = 3
            $d.Settings.RestartInterval = 'PT1M'
        } else {
            $trigger = $d.Triggers.Create(2)
            $trigger.DaysInterval = 1
            $trigger.StartBoundary = [DateTime]::Today.AddHours($spec.hour).ToString('s')
            if ($spec.minutes) {
                $trigger.StartBoundary = [DateTime]::Now.AddMinutes($spec.minutes).ToString('s')
                $trigger.Repetition.Interval = "PT$($spec.minutes)M"
                $trigger.Repetition.Duration = 'P1D'
            }
            if ($spec.key -eq 'backup') {
                $d.Triggers.Clear()
                $trigger = $d.Triggers.Create(3)
                $trigger.WeeksInterval = 1
                $trigger.DaysOfWeek = 1
                $trigger.StartBoundary = [DateTime]::Today.AddHours(11).ToString('s')
            }
        }
        $flags = if ($task) { 4 } else { 2 }
        $null = $folder.RegisterTaskDefinition($spec.name, $d, $flags, $user, $null, 3)
    }
    'status' {
        $running = $false
        $valid = $false
        if ($task) {
            $running = $task.State -eq 4
            $a = $task.Definition.Actions.Item(1)
            $valid = $task.Enabled -and $a.Path -eq $spec.program -and $a.Arguments -eq $spec.arguments
        }
        @{present=[bool]$task; valid=$valid; running=$running} | ConvertTo-Json -Compress
    }
    'start' { $null = $task.Run($null) }
    'stop' { if ($task.State -eq 4) { $task.Stop(0) } }
    'remove' { if ($task) { if ($task.State -eq 4) { $task.Stop(0) }; $folder.DeleteTask($spec.name, 0) } }
    default { throw 'Unknown task action' }
}
