"""Task Scheduler entry point. Run the CLI in this very process so Stop controls the actual job."""
import os
import runpy
import sys
from pathlib import Path

ENGINE = Path(__file__).resolve().parents[1]
JOBS = {"server": ["mcp-server/server.py", "--transport", "http", "--host", "127.0.0.1",
                   "--port", "8787"],
        "sync.fast": ["cli/dt_sync.py", "fast", "--sleep-tick"],
        "sync.index": ["cli/dt_sync.py", "index"], "backup": ["cli/dt_backup.py"]}


def main(key):
    os.chdir(ENGINE)
    path, *args = JOBS[key]
    logdir = ENGINE.parent / ".derived/install"
    logdir.mkdir(parents=True, exist_ok=True)
    log = (logdir / (key + ".log")).open("a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = log
    if key == "server":
        (logdir / "server.pid").write_text(str(os.getpid()), encoding="ascii")
    script = ENGINE / path
    sys.path[:0] = [str(script.parent), str(ENGINE)]
    sys.argv = [str(script), *args]
    try:
        runpy.run_path(str(script), run_name="__main__")
    except Exception:
        import traceback
        traceback.print_exc(file=log)
        raise


if __name__ == "__main__":
    main(sys.argv[1])
