"""Browser access: trusted local navigation and revocable paired devices, no DB schema."""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import os
import secrets
import tempfile
import time
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import urlsplit

from core.file_lock import file_lock
from core.instance import secrets_path

COOKIE = "dtweb_device"
YEAR = 365 * 86400
PAIR_SECONDS = 600


class AccessError(ValueError):
    def __init__(self, code, message, status=400):
        self.code, self.status = code, status
        super().__init__(message)


def fingerprint(value):
    return hashlib.sha256(value.encode()).hexdigest()


def cookie_value(headers, name=COOKIE):
    try:
        cookies = SimpleCookie(headers.get("cookie", ""))
        return cookies[name].value if name in cookies else ""
    except Exception:  # noqa: BLE001 - invalid cookie is anonymous
        return ""


def same_origin(scope, headers):
    host = headers.get("host", "")
    origin = headers.get("origin", "")
    if origin:
        if origin == scope.get("scheme", "http") + "://" + host:
            return True
        # TLS may terminate at Tailscale while ASGI deliberately keeps the true TCP
        # peer/scheme. Fetch metadata confirms the external browser origin here.
        return origin == "https://" + host and headers.get("sec-fetch-site", "") == "same-origin"
    return headers.get("sec-fetch-site", "") == "same-origin"


def local_browser(scope, headers):
    try:
        peer = ipaddress.ip_address((scope.get("client") or ("", 0))[0])
        host = urlsplit("//" + headers.get("host", ""))
        port = host.port or (443 if scope.get("scheme") == "https" else 80)
        if not peer.is_loopback or host.hostname not in ("localhost", "127.0.0.1", "::1"):
            return False
        if host.username or host.password or host.path or port != scope["server"][1]:
            return False
    except (ValueError, KeyError, TypeError):
        return False
    # A local proxy does not make its remote client the Mac owner.
    keys = [k.decode("latin-1").lower() for k, _ in scope.get("headers", [])]
    if any(k == "forwarded" or k.startswith(("x-forwarded-", "tailscale-")) for k in keys):
        return False
    if scope["method"] in ("GET", "HEAD"):
        return (
            headers.get("sec-fetch-mode", "") == "navigate"
            and headers.get("sec-fetch-site", "") in ("none", "same-origin")
        ) or same_origin(scope, headers)
    return same_origin(scope, headers)


def secure_browser(scope, headers):
    return (
        scope.get("scheme") == "https"
        or headers.get("x-forwarded-proto", "") == "https"
        or headers.get("origin", "").startswith("https://")
    )


def session_cookie(value, secure=False, *, clear=False, name=COOKIE):
    return f"{name}={value}; Path=/; Max-Age={0 if clear else YEAR}; HttpOnly; SameSite=Strict" + (
        "; Secure" if secure else ""
    )


class WebAccess:
    def __init__(self, tokens, directory=None, clock=time.time):
        self.tokens = tokens
        self.path = Path(directory or secrets_path()) / "web_access.json"
        self.clock = clock

    def _read(self):
        if not self.path.exists():
            return {"version": 1, "devices": [], "attempts": {}, "pair": None}
        if self.path.stat().st_size > 1_000_000:
            raise AccessError("access_unavailable", "Хранилище доступа недоступно", 503)
        try:
            d = json.loads(self.path.read_text())
            if d["version"] != 1 or not isinstance(d["devices"], list):
                raise ValueError("version")
            return d
        except (ValueError, KeyError, TypeError) as exc:
            raise AccessError("access_unavailable", "Хранилище доступа недоступно", 503) from exc

    def _save(self, data):
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".web-access-", dir=self.path.parent)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w") as f:
                json.dump(data, f, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, self.path)
        finally:
            Path(tmp).unlink(missing_ok=True)

    def _issuer(self):
        return fingerprint(self.tokens.rw() or "")

    def identify(self, token):
        if not token or len(token) > 200:
            return None
        now = self.clock()
        with file_lock(self.path):
            d = self._read()
            for row in d["devices"]:
                if (
                    not row.get("revoked")
                    and row["expires"] > now
                    and hmac.compare_digest(row["hash"], fingerprint(token))
                    and row["issuer"] == self._issuer()
                ):
                    if now - row["seen"] > 86400:
                        row.update(seen=now, expires=now + YEAR)
                        self._save(d)
                    return {
                        **{k: row[k] for k in ("id", "name", "created", "seen", "expires")},
                        "secure": bool(row.get("secure")),
                    }
        return None

    def devices(self):
        with file_lock(self.path):
            d = self._read()
            return [
                {
                    **{k: r[k] for k in ("id", "name", "created", "seen", "expires")},
                    "revoked": bool(r.get("revoked")),
                    "active": not r.get("revoked")
                    and r["expires"] > self.clock()
                    and r["issuer"] == self._issuer(),
                }
                for r in d["devices"]
            ]

    def create_code(self):
        code = f"{secrets.randbelow(100_000_000):08d}"
        with file_lock(self.path):
            d = self._read()
            d["pair"] = {
                "hash": fingerprint(code),
                "until": self.clock() + PAIR_SECONDS,
                "issuer": self._issuer(),
            }
            self._save(d)
        return code

    def login(self, code, name, peer, *, secure=False):
        if (
            not isinstance(code, str)
            or not isinstance(name, str)
            or not 1 <= len(name.strip()) <= 80
        ):
            raise AccessError("login_invalid", "Укажите код и название устройства")
        code = code.replace(" ", "").replace("-", "")
        now = self.clock()
        with file_lock(self.path):
            d = self._read()
            attempts = {k: v for k, v in d["attempts"].items() if now - v["at"] < 60}
            key = fingerprint(peer)
            if len(attempts) >= 100 or attempts.get(key, {}).get("count", 0) >= 5:
                raise AccessError(
                    "login_rate_limited", "Слишком много попыток. Повторите через минуту", 429
                )
            attempts[key] = {"at": now, "count": attempts.get(key, {}).get("count", 0) + 1}
            d["attempts"] = attempts
            pair = d.get("pair")
            if not (
                len(code) == 8
                and code.isdigit()
                and pair
                and pair["until"] > now
                and pair["issuer"] == self._issuer()
                and hmac.compare_digest(pair["hash"], fingerprint(code))
            ):
                self._save(d)
                raise AccessError(
                    "login_invalid", "Код неверен или истек. Получите новый код на Mac", 403
                )
            d["devices"] = [r for r in d["devices"] if not r.get("revoked") and r["expires"] > now]
            if len(d["devices"]) >= 100:
                raise AccessError("device_limit", "Удалите лишние устройства на Mac", 409)
            token = secrets.token_urlsafe(32)
            row = {
                "id": secrets.token_hex(12),
                "hash": fingerprint(token),
                "name": name.strip(),
                "created": now,
                "secure": bool(secure),
                "seen": now,
                "expires": now + YEAR,
                "issuer": self._issuer(),
            }
            d["devices"].append(row)
            d["pair"] = None
            self._save(d)
            return token

    def revoke(self, device_id):
        with file_lock(self.path):
            d = self._read()
            for row in d["devices"]:
                if row["id"] == device_id:
                    row["revoked"] = True
                    self._save(d)
                    return
            raise AccessError("device_missing", "Устройство уже удалено", 404)
