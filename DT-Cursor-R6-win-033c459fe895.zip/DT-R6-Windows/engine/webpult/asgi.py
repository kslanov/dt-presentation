"""DAEMON-1 — веб-пульт: ЕДИНСТВЕННАЯ реализация ``GET /`` и ``POST /api/<tool>`` (ASGI).

Пульт и ``/mcp/<профиль>`` живут в одном процессе на одном порту (демон ``com.dt.server``);
автономный ``python webpult/server.py`` поднимает тот же ASGI без ``/mcp``. Контракт
WEBPULT-ACCESS-1: профиль ``pult``, два токена (read/write), cookie, ``inject_mode``, write-гейт
(403 ``write_token_required``), 404 вне профиля, аудит с ``auth``/хвостом токена/``peer``. Разбор
токенов, ``inject_mode`` и константы - в ``webpult.server`` (общие хелперы). Инструмент идет в
поток (``anyio``), хост запроса - ``webpult`` через ContextVar ``core.host`` (хост процесса не
трогаем).
"""

from __future__ import annotations

import inspect
import json
from collections.abc import Awaitable, Callable
from datetime import date
from pathlib import Path
from typing import Any

from core import eval_journal as _eval_journal
from core.contract import unknown_param_refusal
from core.daemon import heavy_slot, track_tool
from core.host import (
    SURFACE_WEBPULT,
    bind_session_host,
    clear_request,
    set_request,
    unbind_session_host,
)
from core.operational.pult import record_action
from core.web_tokens import FixedTokens, WebTokens, tail
from webpult import server as _wp
from webpult.access import (
    COOKIE,
    AccessError,
    WebAccess,
    cookie_value,
    local_browser,
    same_origin,
    secure_browser,
    session_cookie,
)

Scope = dict[str, Any]
Receive = Callable[[], Awaitable[dict[str, Any]]]
Send = Callable[[dict[str, Any]], Awaitable[None]]


class _Headers:
    """``.get`` как у ``http.server`` (регистр не важен) - для ``webpult.server._presented``."""

    def __init__(self, scope: Scope) -> None:
        self._h = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope["headers"]}

    def get(self, name: str, default: str = "") -> str:
        return self._h.get(name.lower(), default)


async def _body(receive: Receive, max_bytes: int | None = None) -> bytes:
    chunks: list[bytes] = []
    size = 0
    while True:
        msg = await receive()
        chunk = msg.get("body", b"")
        size += len(chunk)
        if max_bytes is not None and size > max_bytes:
            raise ValueError("body too large")
        chunks.append(chunk)
        if not msg.get("more_body"):
            return b"".join(chunks)


async def _send(
    send: Send, status: int, body: bytes, ctype: str, extra: list[tuple[str, str]] | None = None
) -> None:
    headers = [
        (b"content-type", ctype.encode()),
        (b"content-length", str(len(body)).encode()),
        (b"cache-control", b"no-store"),
        (b"referrer-policy", b"no-referrer"),
    ]
    headers += [(k.lower().encode(), v.encode()) for k, v in extra or []]
    await send({"type": "http.response.start", "status": status, "headers": headers})
    await send({"type": "http.response.body", "body": body})


def _json_default(value: Any) -> str:
    # YAML frontmatter may contain date/datetime objects. Preserve their ISO value;
    # never stringify arbitrary objects (that can hide bugs or expose their repr).
    if isinstance(value, date):
        return value.isoformat()
    raise TypeError(f"Unsupported response type: {type(value).__name__}")


def _json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, default=_json_default).encode("utf-8")


async def _json(send: Send, status: int, obj: Any) -> None:
    await _send(send, status, _json_bytes(obj), "application/json; charset=utf-8")


async def _fail(send: Send, http: int, code: str, text: str) -> None:
    await _json(send, http, {"isError": True, "code": code, "content": [{"text": text}]})


def unknown_args(fn: Any, args: dict[str, Any]) -> tuple[list[str], list[str]]:
    """``(неизвестные, допустимые)`` ключи тела по сигнатуре инструмента (ARGS-STRICT-1).

    Та же семантика, что у границы MCP (``StrictFastMCP.call_tool``): имя, которого нет среди
    параметров, - отказ ДО вызова. Инструмент с ``**kwargs`` или без читаемой сигнатуры - не
    проверяется (``([], [])``): сомнение не повод отказывать здоровому вызову.
    """
    try:
        params = inspect.signature(fn).parameters.values()
    except (TypeError, ValueError):
        return [], []
    if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params):
        return [], []
    accepted = [
        p.name
        for p in params
        if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
    ]
    return [key for key in args if key not in accepted], accepted


async def _auth_route(scope, headers, receive, send, access, auth, local, device, cookie_name):
    path = scope["path"]
    try:
        if path == "/auth/status" and scope["method"] == "GET":
            await _json(
                send,
                200,
                {
                    "ok": True,
                    "mode": auth,
                    "local": local,
                    "device": device,
                    "devices": access.devices() if local else [],
                },
            )
            return
        if scope["method"] != "POST" or not same_origin(scope, headers):
            await _fail(send, 403, "origin_forbidden", "Откройте действие из самого пульта")
            return
        raw = await _body(receive, 4096)
        if len(raw) > 4096:
            raise AccessError("login_invalid", "Слишком большой запрос")
        args = json.loads(raw or b"{}")
        if not isinstance(args, dict):
            raise AccessError("login_invalid", "Некорректный запрос")
        secure = secure_browser(scope, headers)
        if path == "/auth/login" and set(args) == {"code", "name"}:
            token = access.login(
                args["code"], args["name"], (scope.get("client") or ("", 0))[0], secure=secure
            )
            await _send(
                send,
                200,
                b'{"ok":true}',
                "application/json",
                [
                    ("Set-Cookie", session_cookie(token, secure, name=cookie_name)),
                    ("Cache-Control", "no-store"),
                ],
            )
            return
        if path == "/auth/logout":
            if device:
                access.revoke(device["id"])
            cookies = [("Set-Cookie", session_cookie("", secure, clear=True, name=cookie_name))]
            for name in (_wp.COOKIE_READ, _wp.COOKIE_RW):
                cookies.append(
                    ("Set-Cookie", f"{name}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax")
                )
            await _send(send, 200, b'{"ok":true}', "application/json", cookies)
            return
        if not local:
            await _fail(
                send, 403, "owner_mac_required", "Управлять устройствами можно на вашем Mac"
            )
            return
        if path == "/auth/pair" and not args:
            await _send(
                send,
                200,
                _json_bytes({"ok": True, "code": access.create_code(), "expires_in": 600}),
                "application/json",
                [("Cache-Control", "no-store")],
            )
            return
        if path == "/auth/revoke" and set(args) == {"id"}:
            access.revoke(args["id"])
            await _json(send, 200, {"ok": True})
            return
        await _fail(send, 400, "auth_action_invalid", "Неизвестное действие доступа")
    except AccessError as e:
        await _fail(send, e.status, e.code, str(e))
    except (ValueError, TypeError):
        await _fail(send, 400, "login_invalid", "Некорректный запрос")
    except OSError:
        await _fail(send, 503, "access_unavailable", "Не удалось сохранить доступ")
    return


def make_pult_asgi(
    tools: Any,
    tokens: Any | None = None,
    html_path: Path | None = None,
    access: WebAccess | None = None,
):
    """ASGI-приложение пульта поверх ``tools`` (модуль ``mcp-server/server.py``)."""
    import anyio

    tokens = tokens if tokens is not None else WebTokens()
    if isinstance(tokens, str):  # прежняя сигнатура: строка = только read-токен
        tokens = FixedTokens(tokens)
    access = access if access is not None else WebAccess(tokens)
    names, write_names = _wp.tool_sets(tools)
    guard = getattr(tools, "guarded_tool", None)
    facades = frozenset(getattr(tools, "WRITE_OPS", None) or {}) & write_names  # права по операции
    read_ops_fn = getattr(tools, "facade_read_ops", None)
    read_ops = {
        k: v for k, v in (read_ops_fn() if callable(read_ops_fn) else {}).items() if k in names
    }

    def call_tool(
        name: str, args: dict[str, Any], ctx_args: tuple[str, str, str], quiet: bool = False
    ) -> Any:
        """Выполняется в потоке: контекст запроса и хост ``webpult`` ставятся здесь.

        ``quiet`` (PERSONAL-1, заголовок ``X-DT-No-Journal: 1``) - вызов не пишется в журнал
        запросов поиска (:func:`core.eval_journal.suppressed`)."""
        host_token = bind_session_host("webpult", surface=SURFACE_WEBPULT)
        req_token = set_request(*ctx_args)
        try:
            fn = getattr(tools, name)
            with track_tool(), _eval_journal.suppressed(quiet):  # SANDBOX-DAEMON: поток виден
                return (guard(fn) if callable(guard) else fn)(**args)
        finally:
            clear_request(req_token)
            unbind_session_host(host_token)

    async def app(scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            return
        path = scope["path"]
        query = scope.get("query_string", b"").decode("latin-1")
        headers = _Headers(scope)
        presented, from_query = _wp._presented(headers, query)
        auth = tokens.classify(presented)
        local = bool(tokens.rw()) and local_browser(scope, headers)
        cookie_name = COOKIE + "_" + str((scope.get("server") or ("", 0))[1])
        device_token = cookie_value(headers, cookie_name)
        try:
            device = None if local else access.identify(device_token)
        except (AccessError, OSError):
            await _fail(send, 503, "access_unavailable", "Хранилище доступа недоступно")
            return
        if local or device:
            auth = "write"
        # Cookie privileges never authorize a cross-origin form or fetch. Bearer API
        # clients without browser metadata retain their existing token contract.
        if scope["method"] == "POST" and (
            (headers.get("origin") and not same_origin(scope, headers))
            or headers.get("sec-fetch-site") == "cross-site"
            or (device and not same_origin(scope, headers))
        ):
            await _fail(send, 403, "origin_forbidden", "Запрос должен идти из самого пульта")
            return
        if path.startswith("/auth/"):
            await _auth_route(
                scope, headers, receive, send, access, auth, local, device, cookie_name
            )
            return

        if scope["method"] in ("GET", "HEAD") and path in (
            "/",
            "/index.html",
            "/pult.html",
            "/login",
        ):
            if auth is None or (path == "/login" and not local and not device):
                await _send(
                    send,
                    401,
                    Path(__file__).with_name("login.html").read_bytes(),
                    "text/html; charset=utf-8",
                    [("Cache-Control", "no-store")],
                )
                return
            try:
                html = (html_path or _wp.resolve_html_path()).read_bytes()
            except OSError:
                await _send(send, 500, b"pult.html not found", "text/plain; charset=utf-8")
                return
            cookies: list[tuple[str, str]] = []
            read_tok = tokens.read()
            if read_tok and not (local or device):
                cookies.append(
                    (
                        "Set-Cookie",
                        f"{_wp.COOKIE_READ}={read_tok}; Path=/; "
                        f"Max-Age={_wp.READ_COOKIE_MAX_AGE}; HttpOnly; SameSite=Lax",
                    )
                )
            if tokens.classify(from_query) == "write" and tokens.rw():
                cookies.append(
                    (
                        "Set-Cookie",
                        f"{_wp.COOKIE_RW}={tokens.rw()}; Path=/; "
                        f"Max-Age={_wp.RW_COOKIE_MAX_AGE}; HttpOnly; SameSite=Lax",
                    )
                )
            if device:
                cookies.append(
                    (
                        "Set-Cookie",
                        session_cookie(
                            device_token,
                            device.get("secure") or secure_browser(scope, headers),
                            name=cookie_name,
                        ),
                    )
                )
            await _send(
                send,
                200,
                _wp.inject_mode(html, auth, write_names, read_ops),
                "text/html; charset=utf-8",
                cookies,
            )
            return

        if scope["method"] != "POST" or not path.startswith("/api/"):
            await _send(send, 404, b"not found", "text/plain; charset=utf-8")
            return
        name = path[len("/api/") :]
        if name not in names:
            await _fail(send, 404, _wp.CODE_UNKNOWN_TOOL, f"unknown tool: {name}")
            return
        is_write = name in write_names
        args: dict[str, Any] | None = None
        if name in facades and auth is not None:
            # SLEEP-PULT-1: фасад с правами по операции (sleep, sleep_eval): чтение работает с
            # read-токеном, запись операции - только с write-токеном (то же решение, что у MCP-http)
            try:
                args = json.loads((await _body(receive)) or b"{}")
                if not isinstance(args, dict):
                    raise ValueError("body must be a JSON object")
            except (ValueError, json.JSONDecodeError) as e:
                await _fail(send, 400, _wp.CODE_BAD_REQUEST, f"bad request: {e}")
                return
            is_write = bool(tools.tool_needs_write(name, args))
        peer = (scope.get("client") or ("", 0))[0]
        matched = (
            device["id"]
            if device
            else "owner-mac"
            if local
            else tokens.rw()
            if auth == "write"
            else tokens.read()
        )
        ctx = (auth or "none", tail(matched) if auth else "", peer)

        # запись аудита идет в поток: ``record_action`` читает контекст запроса и хост
        def audit(outcome: str) -> None:
            host_token = bind_session_host("webpult", surface=SURFACE_WEBPULT)
            req_token = set_request(*ctx)
            try:
                record_action("web_api", {"tool": name}, outcome)
            finally:
                clear_request(req_token)
                unbind_session_host(host_token)

        if auth is None:
            if is_write:
                await anyio.to_thread.run_sync(audit, "denied:auth_required")
            await _fail(send, 401, _wp.CODE_AUTH_REQUIRED, "нужен токен (?t=… или Bearer)")
            return
        if is_write and auth != "write":
            await anyio.to_thread.run_sync(audit, "denied:write_token_required")
            await _fail(
                send,
                403,
                _wp.CODE_WRITE_TOKEN_REQUIRED,
                "нужен токен записи: открой ссылку с rw-токеном",
            )
            return
        if args is None:
            try:
                args = json.loads((await _body(receive)) or b"{}")
                if not isinstance(args, dict):
                    raise ValueError("body must be a JSON object")
            except (ValueError, json.JSONDecodeError) as e:
                await _fail(send, 400, _wp.CODE_BAD_REQUEST, f"bad request: {e}")
                return
        unknown, accepted = unknown_args(getattr(tools, name, None), args)
        if unknown:
            # ARGS-STRICT-1: лишний ключ - 400 с конвертом CONTRACT-2 (не ``tool_error``),
            # инструмент не вызван; ``TypeError`` ВНУТРИ инструмента остается ``tool_error``.
            refusal = unknown_param_refusal(name, unknown, accepted)

            def record_refusal() -> None:
                host_token = bind_session_host("webpult", surface=SURFACE_WEBPULT)
                req_token = set_request(*ctx)
                try:
                    for hook, extra in (
                        ("_record_degradation", (refusal,)),
                        ("_record_tool_call", (False, 0)),
                    ):
                        fn = getattr(tools, hook, None)
                        if callable(fn):
                            fn(name, *extra)
                finally:
                    clear_request(req_token)
                    unbind_session_host(host_token)

            await anyio.to_thread.run_sync(record_refusal)
            if is_write:
                await anyio.to_thread.run_sync(audit, f"denied:{_wp.CODE_UNKNOWN_PARAM}")
            await _json(
                send,
                400,
                {
                    "isError": True,
                    "code": _wp.CODE_UNKNOWN_PARAM,
                    "content": [{"text": refusal["error"]}],
                    **refusal,
                },
            )
            return
        try:
            async with heavy_slot(name):  # generate/retrieve: слот семафора демона
                quiet = headers.get(_eval_journal.HEADER_NO_JOURNAL) == "1"
                val = await anyio.to_thread.run_sync(call_tool, name, args, ctx, quiet)
            outcome = "ok"
            reply = {"structuredContent": _wp._wrap(val), "isError": False}
            body = _json_bytes(reply)  # serialize inside the guard, before response headers
        except Exception as e:  # noqa: BLE001 - сбой инструмента -> в ответ, не в 500
            outcome = "error"
            reply = {
                "isError": True,
                "code": _wp.CODE_TOOL_ERROR,
                "content": [{"text": str(e)[:500]}],
            }
            body = _json_bytes(reply)
        if is_write:
            await anyio.to_thread.run_sync(audit, outcome)
        await _send(send, 200, body, "application/json; charset=utf-8")

    return app


__all__ = ["make_pult_asgi"]
