param([ValidateSet('check','prepare')][string]$Mode='check')
$ErrorActionPreference = 'Stop'
$kit = Split-Path -Parent $PSScriptRoot
$engine = Join-Path $kit 'engine'
$step = 'computer'
try {
    $system = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    if ($system.ProductType -ne 1 -or [int]$system.BuildNumber -lt 22000 -or $cpu.Architecture -ne 9 -or ![Environment]::Is64BitOperatingSystem) { throw 'Windows 11 x64 is required' }
    if ($system.TotalVisibleMemorySize -lt 7.5MB) { throw 'At least 8 GB RAM required' }
    $disk = Get-PSDrive -Name ([IO.Path]::GetPathRoot($kit).Substring(0,1))
    if ($disk.Free -lt 12GB) { throw 'At least 12 GB free space required' }
    $step = 'package-integrity'
    $manifest = Get-Content -LiteralPath (Join-Path $kit 'KIT-MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($file in $manifest.files) {
        $path = Join-Path $kit $file.path
        $stream = [IO.File]::OpenRead($path)
        try {
            $sha = [Security.Cryptography.SHA256]::Create()
            try { $hash = [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '') }
            finally { $sha.Dispose() }
        } finally { $stream.Dispose() }
        if ($hash -ne $file.sha256) { throw "Package file changed: $($file.path)" }
    }
    Write-Output "Windows $($system.BuildNumber) x64; kit $($manifest.candidate); package verified"
    if ($Mode -eq 'check') { exit 0 }
    $step = 'tools'
    foreach ($item in @(@('uv','astral-sh.uv'),@('git','Git.Git'))) {
        if (!(Get-Command $item[0] -ErrorAction SilentlyContinue)) {
            & winget install --exact --id $item[1] --source winget --accept-package-agreements --accept-source-agreements
            if ($LASTEXITCODE -ne 0) { throw "WinGet failed for $($item[1]) with code $LASTEXITCODE" }
            $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [Environment]::GetEnvironmentVariable('Path','User') + ';' + $env:Path
            if (!(Get-Command $item[0] -ErrorAction SilentlyContinue)) { throw "Reopen Cursor and resume: $($item[0]) is not on PATH yet" }
        }
    }
    $step = 'python'
    Set-Location -LiteralPath $engine
    $env:PYTHONUTF8 = '1'
    & uv python install 3.12
    if ($LASTEXITCODE) { throw "uv python install failed ($LASTEXITCODE)" }
    $step = 'preview-tools'
    $python = Join-Path $engine '.venv/Scripts/python.exe'
    if (!(Test-Path -LiteralPath $python)) {
        & uv venv --python 3.12 .venv
        if ($LASTEXITCODE) { throw "uv venv failed ($LASTEXITCODE)" }
    }
    & uv pip install --python $python --require-hashes --only-binary :all: -r (Join-Path $PSScriptRoot 'preview-requirements.txt')
    if ($LASTEXITCODE) { throw "Preparing deployment preview failed ($LASTEXITCODE)" }
    Write-Output 'Ready for deployment preview'
} catch {
    $why = $_.Exception.Message
    $receipt = Join-Path $kit 'first-failure.json'
    if (!(Test-Path -LiteralPath $receipt)) {
        @{step=$step; windowsBuild=$system.BuildNumber; reason=$why; candidate=$manifest.candidate} |
            ConvertTo-Json | Set-Content -LiteralPath $receipt -Encoding UTF8
    }
    [Console]::Error.WriteLine("$step - $why")
    exit 1
}
