"""Local evidence for selectively imported Talk recordings (no API or transcript reads)."""

import json
import re
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path

import yaml

from core.config import default_vault_path
from core.fsguard import is_dataless
from core.ingress.talk import FOLDER
from core.ingress.talk_sync import read_state, state_path
from core.privacy import is_nda


def _utc(value):
    if not value:
        return None
    stamp = datetime.fromisoformat(str(value))
    return stamp.replace(tzinfo=UTC) if stamp.tzinfo is None else stamp.astimezone(UTC)


@lru_cache(maxsize=512)
def _dates(path, mtime_ns, size):
    if path.suffix == ".json":
        meta = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(meta.get("space"), str) or not meta["space"].endswith(".ktalk.ru"):
            return None
        return (
            _utc(meta["recording"]["createdDate"]),
            _utc(meta.get("fetched_at")),
            meta["recording"].get("title"),
        )
    # Early imports were single Markdown notes. Read only their YAML header.
    with path.open(encoding="utf-8") as f:
        if f.readline().strip() != "---":
            return None
        lines = []
        for line in f:
            if line.strip() == "---":
                break
            lines.append(line)
        else:
            raise ValueError("Incomplete meeting header")
    fm = yaml.safe_load("".join(lines))
    if not isinstance(fm, dict) or fm.get("source") != "talk":
        return None
    return _utc(fm.get("created")), _utc(fm.get("ingested")), fm.get("title")


def _inventory(vault: Path | None):
    root = (vault or default_vault_path()).resolve()
    base = root / FOLDER
    local_items = {}
    latest = received = None
    unreadable = 0
    if base.resolve() == base and base.is_dir():
        for month in base.glob("[0-9][0-9][0-9][0-9]/[0-9][0-9]"):
            if month.resolve() != month:
                continue
            if month.resolve() != month or not month.is_dir():
                continue
            try:
                items = list(month.iterdir())
            except OSError:
                unreadable += 1
                continue
            for item in items:
                match = re.search(r"-([0-9a-f]{20})(?:\.md)?$", item.name)
                if not match or item.is_symlink() or is_nda(item.name):
                    continue
                path = item
                if item.is_dir():
                    path = item / "metadata.json"
                    if any(
                        f.is_symlink() or not f.is_file()
                        for f in (path, item / "source.md", item / "summary.md")
                    ):
                        unreadable += 1
                        continue
                try:
                    if is_dataless(path):
                        unreadable += 1
                        continue
                    stat = path.stat()
                    dates = _dates(path, stat.st_mtime_ns, stat.st_size)
                    if dates is None:
                        continue
                    created, fetched, title = dates
                    note = item / "summary.md" if item.is_dir() else item
                    rel = note.relative_to(root).as_posix()
                    if title and is_nda(title):
                        continue
                    key = match[1]
                    # Old single notes and meeting folders share the same recording identity.
                    if key not in local_items or item.is_dir():
                        local_items[key] = {
                            "title": title or item.stem.removesuffix("-" + key),
                            "path": rel,
                            "at": fetched.isoformat() if fetched else None,
                            "created": created.isoformat() if created else None,
                            "change": "existing",
                            "absolute_path": str(note),
                        }
                    if created and (not latest or latest < created):
                        latest = created
                    if fetched and (not received or received < fetched):
                        received = fetched
                except (OSError, ValueError, KeyError, AttributeError, TypeError, yaml.YAMLError):
                    unreadable += 1
    try:
        state = read_state(state_path(root))
        successful = _utc(state.get("last_success"))
    except (OSError, ValueError):
        state, successful = {}, None
        unreadable += 1
    by_path = {row["path"]: row for row in local_items.values()}
    for item in reversed(state.get("recent", [])):
        if item.get("path") in by_path:
            row = by_path[item["path"]]
            row["at"] = item.get("at") or row["at"]
            row["change"] = item.get("change", "existing")
    rows = sorted(
        local_items.values(),
        key=lambda r: (r["at"] or "", r["created"] or "", r["path"]),
        reverse=True,
    )
    return rows, latest, received, unreadable, state, successful


def saved_meetings(query="", offset=0, limit=5, *, vault=None):
    rows, _, _, unreadable, _, _ = _inventory(vault)
    count = len(rows)
    needle = (query or "").strip().casefold()
    matches = [row for row in rows if needle in row["title"].casefold()] if needle else rows
    total = len(matches)
    limit = max(1, min(100, int(limit)))
    offset = min(max(0, int(offset)), max(0, (total - 1) // limit * limit))
    return {
        "meeting_count": count, "total": total, "offset": offset, "limit": limit,
        "rows": matches[offset:offset + limit], "unreadable": unreadable,
    }


def evidence(vault: Path | None = None, *, now=None):
    from core.ingress.registry import get

    adapter = get("talk")
    rows, latest, received, unreadable, state, successful = _inventory(vault)
    check = state.get("check", {})
    age = (
        max(0, ((now or datetime.now(UTC)) - successful).total_seconds() / 3600)
        if successful
        else None
    )
    return {
        "source": "talk",
        "mode": adapter.mode,
        "meeting_count": len(rows),
        "unreadable": unreadable,
        "last_meeting": latest.isoformat() if latest else None,
        "last_received": received.isoformat() if received else None,
        "check": check,
        "recent": rows[:20],
        "data_as_of": state.get("last_success"),
        "last_run": {
            "ts": check["finished"],
            "ok": not check.get("errors") and not check.get("interrupted"),
        }
        if check.get("finished")
        else None,
        "sync": {"mode": adapter.mode, "steps": [adapter.step]},
        "stale": age > adapter.stale_after_h if age is not None else None,
        "lag_h": round(age, 1) if age is not None else None,
        "stale_after_h": adapter.stale_after_h,
    }
