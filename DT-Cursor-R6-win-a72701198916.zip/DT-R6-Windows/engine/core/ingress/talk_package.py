"""Publish a reviewed Talk preview as a meeting folder using the DT vault writer."""

import json
import re
from datetime import datetime
from pathlib import Path

import frontmatter

from core.eventlog import emit
from core.file_lock import file_lock
from core.ingress.talk import FOLDER, digest, resolve_hub
from core.note_writer import read_sha, sha256_bytes, write_note_atomic
from core.output import slugify
from core.privacy import is_nda


def package_path(meta, vault=None):
    rec = meta["recording"]
    created = datetime.fromisoformat(rec["createdDate"])
    identity = digest(meta["space"].removesuffix(".ktalk.ru"), rec["id"])[:20]
    if vault is not None:
        base = vault / FOLDER / f"{created:%Y/%m}"
        matches = [p for p in base.glob(f"*-{identity}") if not is_nda(p.name)]
        if len(matches) > 1:
            raise ValueError("Для одной записи найдены несколько папок.")
        if matches:
            return matches[0].relative_to(vault).as_posix()
    return f"{FOLDER}{created:%Y/%m/%Y-%m-%d} {slugify(rec['title'])}-{identity}"


def import_package(
    folder: Path, vault: Path, hub: str, *, apply: bool = False, refresh: bool = False
) -> str:
    folder = folder.resolve()
    vault = vault.resolve()
    if is_nda(folder):
        raise ValueError("Пакет исключен из импорта.")
    attribution = {}
    hub_id = None
    if hub is not None:
        _, hub_id, field = resolve_hub(vault, hub)
        attribution[field] = hub_id
    files = {}
    names = ["metadata.json", "source.md", "summary.md"]
    if (folder / "protocol.md").exists():
        names.append("protocol.md")
    for filename in names:
        path = folder / filename
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"В пакете ожидается файл {filename}.")
        files[filename] = path.read_text(encoding="utf-8")
    meta = json.loads(files["metadata.json"])
    rec = meta["recording"]
    space, key, title = meta["space"], rec["id"], rec["title"]
    if not re.fullmatch(r"[a-z0-9-]+\.ktalk\.ru", space) or any(
        is_nda(v) for v in (key, title, meta["topic"]["title"])
    ):
        raise ValueError("Неверный источник встречи.")
    created = datetime.fromisoformat(rec["createdDate"])
    identity = digest(space.removesuffix(".ktalk.ru"), key)[:20]
    rel = package_path(meta, vault)
    source = files["source.md"]
    anchors = re.findall(r" \^(talk-[a-f0-9]+)$", source, re.M)
    if not anchors or len(set(anchors)) != len(anchors) or len(anchors) != meta["utterances"]:
        raise ValueError("Количество реплик или их идентификаторы расходятся с метаданными.")
    old_prefix = f"[[{folder.name}/source#^"
    for filename in ("summary.md", "protocol.md"):
        if filename not in files:
            continue
        body = files[filename]
        refs = re.findall(re.escape(old_prefix) + r"(talk-[a-f0-9]+)\|", body)
        if not refs or len(refs) != body.count("/source#^") or not set(refs).issubset(anchors):
            raise ValueError(f"{filename}: ссылки на транскрипт не подтверждены.")
        files[filename] = body.replace(old_prefix, f"[[{rel}/source#^")
    for filename, label in (
        ("source.md", "Транскрипт"),
        ("summary.md", "Итоги"),
        ("protocol.md", "Протокол"),
    ):
        if filename not in files:
            continue
        post = frontmatter.Post(
            files[filename].rstrip(),
            id=f"talk-{identity}-{Path(filename).stem}",
            title=f"{title} · {created:%d.%m.%Y} · {label}",
            type="meeting",
            source="talk",
            source_id=f"{space}:{key}",
            created=created.date().isoformat(),
            **({"ingested": meta["fetched_at"]} if meta.get("review") else {}),
            fetched_at=meta["fetched_at"],
            participants=[p["name"] for p in meta["participants_resolved"]],
            **(
                {"tags": [t["title"] for t in meta["linked_artifacts"]["topic"] if t.get("title")]}
                if meta.get("automatic")
                else {}
            ),
            **attribution,
        )
        files[filename] = frontmatter.dumps(post) + "\n"
    target = vault / rel
    with file_lock(target):
        meta_path = target / "metadata.json"
        if meta_path.resolve() != meta_path:
            raise ValueError("Путь метаданных перенаправлен.")
        prior = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}
        managed = prior.get("managed_hashes", {}) if refresh else {}
        if managed and (
            (prior.get("space"), prior.get("recording", {}).get("id")) != (space, key)
            or prior.get("hub_id") != hub_id
        ):
            raise ValueError("Проверьте пространство и хаб ранее сохраненной встречи.")
        if managed and any(name not in files for name in managed):
            raise ValueError("Ранее сохраненный материал исчез в Толке. Требуется сверка.")
        if refresh:
            meta["managed_hashes"] = {
                name: sha256_bytes(content.encode())
                for name, content in files.items()
                if name != "metadata.json"
            }
            meta["hub_id"] = hub_id
            files.pop("metadata.json")
            files["metadata.json"] = json.dumps(meta, ensure_ascii=False, indent=2) + "\n"
        pending = {}
        for filename, content in files.items():
            path = target / filename
            if path.resolve() != path or not path.is_relative_to(vault):
                raise ValueError("Путь встречи перенаправлен.")
            current = read_sha(path)
            incoming = sha256_bytes(content.encode())
            # Keep links added by the regular linker to otherwise unchanged source content.
            if current == incoming or (
                meta.get("automatic") and current is not None and managed.get(filename) == incoming
            ):
                continue
            if current is not None:
                matches_base = managed.get(filename) == current
                if meta.get("automatic") and filename.endswith(".md") and not matches_base:
                    from core.linking.apply import RELATED_HEADING

                    existing = path.read_text(encoding="utf-8")
                    original, marker, links = existing.rpartition("\n\n" + RELATED_HEADING + "\n")
                    if marker:
                        original_sha = sha256_bytes((original + "\n").encode())
                        if original_sha == incoming:
                            continue
                        if original_sha == managed.get(filename):
                            files[filename] = content.rstrip() + marker + links
                            matches_base = True
                if not managed or (
                    filename != "metadata.json" and not matches_base
                ):
                    raise ValueError(f"В {rel}/{filename} уже есть другая версия.")
                if filename == "source.md":
                    old_anchors = re.findall(
                        r" \^(talk-[a-f0-9]+)$", path.read_text(encoding="utf-8"), re.M
                    )
                    if not set(old_anchors).issubset(anchors):
                        raise ValueError("В Толке изменились ссылки на сохраненные реплики.")
            pending[filename] = current
        if apply:
            for filename, expected in pending.items():
                write_note_atomic(
                    vault,
                    f"{rel}/{filename}",
                    files[filename],
                    allowed_prefix=FOLDER,
                    expect_sha=expected,
                )
            if pending:
                emit(
                    "ingest",
                    "ok",
                    note_id=f"talk-{identity}-summary",
                    path=f"{rel}/summary.md",
                    detail={"source": "talk", "files": len(pending)},
                )
    return rel
