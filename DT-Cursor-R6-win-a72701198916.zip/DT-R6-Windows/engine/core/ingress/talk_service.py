"""Контур.Толк: поиск в личных записях, предпросмотр и импорт выбранной записи."""

from __future__ import annotations

import json
import os
import re
from bisect import bisect_left, bisect_right
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from tempfile import TemporaryDirectory

import httpx

from core import connectors
from core.config import default_vault_path
from core.file_lock import file_lock
from core.ingress.talk import ImportResult, digest, literal, resolve_hub, speaker, utterances
from core.ingress.talk_account import normalize_space, space_secret
from core.ingress.talk_package import import_package, package_path
from core.instance import instance_role
from core.operational.hub_notes import append_reference
from core.privacy import is_nda
from core.secrets import get_secret
from core.text.stem import key_tokens
from core.vault import read_note


@contextmanager
def client():
    if instance_role() != "work" or not connectors.enabled("talk"):
        raise ValueError("Толк выключен для этого экземпляра.")
    space = normalize_space(os.environ.get("DT_TALK_SPACE", ""))
    token = get_secret(space_secret(space))
    if not token or not re.fullmatch(r"talkusr\.[!-~]+", token):
        raise ValueError("Сохраните ключ этого пространства через dt talk --connect.")
    with httpx.Client(
        base_url=f"https://{space}.ktalk.ru",
        trust_env=False,
        follow_redirects=False,
        timeout=25,
        headers={"X-Auth-Token": token},
    ) as api:
        yield api


def get(api, path, params=None, *, optional=False):
    try:
        response = api.get(path, params=params)
    except httpx.RequestError:
        raise ValueError("Не удалось связаться с пространством Толка.") from None
    if optional and response.status_code in (204, 404):
        return {}
    if response.status_code != 200:
        raise ValueError(f"Толк вернул HTTP {response.status_code}.")
    return response.json()


def recordings(api, query, offset):
    if not query.strip() or is_nda(query) or offset < 0:
        raise ValueError("Укажите название рабочей записи.")
    page = get(api, "/api/Recordings", {"query": query, "skip": offset, "top": 20})["recordings"]
    return [
        r
        for r in page
        if r.get("title")
        and not is_nda(r["title"])
        and re.fullmatch(r"[a-zA-Z0-9_-]+", r.get("id", ""))
    ], len(page) == 20


def search(query, offset=0):
    with client() as api:
        rows, more = recordings(api, query, offset)
    return {
        "recordings": [
            {k: r.get(k) for k in ("id", "createdDate", "title", "duration")} for r in rows
        ],
        "next_offset": offset + 20 if more else None,
    }


def linked(api, base, kind, *, skip_private=False):
    items, seen = [], set()
    params = {"targetType": kind, "take": 100}
    while True:
        page = get(api, base + "/links", params)
        if skip_private and any(is_nda(r.get("title")) for r in page["entities"]):
            raise PrivateRecording
        items.extend(
            {k: r.get(k) for k in ("type", "key", "title", "linkedDate", "modifiedDate")}
            for r in page["entities"]
            if not is_nda(r.get("title"))
        )
        cursor = page.get("nextPageToken")
        if not cursor:
            return items
        if cursor in seen:
            raise ValueError("Толк повторил страницу связанных материалов.")
        seen.add(cursor)
        params["pageTokenString"] = cursor


def clean_metadata(value):
    if isinstance(value, list):
        return [clean_metadata(v) for v in value]
    if isinstance(value, dict):
        return {
            k: clean_metadata(v)
            for k, v in value.items()
            if not k.lower().endswith("url")
            and k
            not in {
                "mobilePhone",
                "innerPhone",
                "email",
                "login",
                "roles",
                "roleInfos",
                "groupsCount",
                "features",
            }
        }
    return value


def participants(recording, tracks):
    people = {}

    def add(ref, origin):
        name = speaker(ref)
        if not name:
            return
        user = (ref.get("userInfo") or ref) if isinstance(ref, dict) else {}
        key = user.get("key") or user.get("anonymousId") or name
        person = people.setdefault(key, {"id": key, "name": name, "sources": []})
        if origin not in person["sources"]:
            person["sources"].append(origin)

    for ref in recording.get("participants") or []:
        add(ref, "карточка записи")
    for track in tracks:
        for field in ("speaker", "diarizedSpeaker"):
            add(track.get(field), "дорожка транскрипта")
        for chunk in track["chunks"]:
            add(chunk.get("diarizedSpeaker"), "реплика")
    return list(people.values())


def chunk_text(text):
    try:
        obj = json.loads(text)
    except ValueError:
        return literal(text)
    if not isinstance(obj, dict):
        return literal(text)
    if isinstance(obj.get("summary"), str):
        return f"**{literal(obj.get('headline', ''))}**\n\n{literal(obj['summary'])}"
    return literal(text)


def render_summary(part, label, rows, folder):
    offsets = [row.offset for row in rows]
    blocks = []
    if part.get("status") == "success" and not part.get("hidden"):
        chunks = part.get("chunks") or []
        boundaries = sorted(c["timestamp"] * 1000 for c in chunks if c.get("timestamp") is not None)
        for chunk in chunks:
            if (chunk.get("hiddenStatus") or {}).get("isHidden") or not chunk.get("text"):
                continue
            stamp = chunk["timestamp"] * 1000
            start = bisect_left(offsets, stamp)
            # Talk's whole-second chapter clock truncates the milliseconds of the first utterance.
            # For a timestamp inside ongoing speech, keep the utterance spanning that point.
            latest_start = stamp + 999 if stamp % 1000 == 0 else stamp
            if start == len(rows) or offsets[start] > latest_start:
                start = max(0, start - 1)
            row = rows[start]
            body = chunk_text(chunk["text"])
            link = f"[[{folder}/source#^{row.anchor}|{row.clock}]]"
            # A chapter can open with a handover. Keep the provider's boundary visible and
            # also link the following turn if it introduces the subject within this chapter.
            next_boundary = bisect_right(boundaries, stamp)
            end = boundaries[next_boundary] if next_boundary < len(boundaries) else float("inf")
            if start + 1 < len(rows) and offsets[start + 1] < end:
                following = rows[start + 1]
                terms = {word for word in key_tokens(body) if len(word) >= 4}
                if len(terms.intersection(key_tokens(row.text))) < 2 <= len(
                    terms.intersection(key_tokens(following.text))
                ):
                    link = (
                        f"По теме: [[{folder}/source#^{following.anchor}|{following.clock}]]"
                        f" · Начало раздела: {link}"
                    )
            blocks.append(f"{body}\n\n{link}")
    return f"# {label}\n\n" + "\n\n".join(blocks) + "\n" if blocks else ""


def prepare(api, query, recording_id, offset=0):
    candidates, _ = recordings(api, query, offset)
    rec = next((r for r in candidates if r["id"] == recording_id), None)
    if not rec:
        raise ValueError("Запись отсутствует на выбранной странице. Повторите поиск.")
    return prepare_recording(api, rec)


class TranscriptPending(ValueError):
    """The recording exists but currently has no readable utterances."""


class PrivateRecording(ValueError):
    """Recording belongs to an excluded topic."""


def prepare_recording(api, rec, *, automatic=False):
    host = api.base_url.host
    recording_id = rec["id"]
    base = f"/api/recordings/{recording_id}"
    topics = linked(api, base, "topic", skip_private=automatic)
    tr = get(api, base + "/transcript", optional=True)
    if not tr or (tr.get("status") not in ("complete", "failed", "error") and not tr.get("errors")):
        raise TranscriptPending("Транскрипт пока недоступен.")
    if (
        tr.get("status") == "complete"
        and not tr.get("errors")
        and not any(
            str(c.get("text") or "").strip()
            for t in tr.get("tracks", [])
            for c in t.get("chunks", [])
        )
    ):
        raise TranscriptPending("В записи пока нет текстовых реплик.")
    rows = utterances(tr)
    composite = get(api, f"/api/recordings/v2/{recording_id}/summary", optional=True)
    summary, protocol = composite.get("shortSummaryV2") or {}, composite.get("protocolV2") or {}
    links = {
        k: topics if k == "topic" else linked(api, base, k)
        for k in ("topic", "note", "whiteboard", "conference", "messengerRoom", "liveTranscript")
    }
    people = participants(rec, tr["tracks"])
    folder = "meeting"
    heading = f"{literal(rec['title'])} · {rec['createdDate'][:10]}"
    sections = [
        f"# {heading}",
        "## Участники",
        "\n".join("- " + literal(p["name"]) for p in people),
        "## Транскрипт",
    ]
    sections.extend(
        f"**{r.clock} · {literal(r.who)}** — {literal(r.text)} ^{r.anchor}" for r in rows
    )
    body = render_summary(summary, "Итоги · " + heading, rows, folder)
    files = {
        "source.md": "\n\n".join(sections) + "\n",
        "summary.md": body
        or (
            f"# Итоги · {heading}\n\nПересказ Толка недоступен. "
            f"[[{folder}/source#^{rows[0].anchor}|Транскрипт]]\n"
        ),
    }
    minutes = render_summary(protocol, "Протокол · " + heading, rows, folder)
    if minutes:
        files["protocol.md"] = minutes
    meta = {
        "space": host,
        "topic": next(iter(links["topic"]), {"title": ""}),
        "linked_artifacts": links,
        "recording": clean_metadata(rec),
        "participants_reported": rec.get("participantsCount"),
        "participants_resolved": people,
        "tracks": len(tr["tracks"]),
        "utterances": len(rows),
        "transcript": {k: tr.get(k) for k in ("transcriptId", "status", "errors", "statusMessage")},
        "summary": {k: summary.get(k) for k in ("summaryId", "status", "startedAt", "hidden")},
        "protocol": {k: protocol.get(k) for k in ("summaryId", "status", "startedAt", "hidden")},
        "source_endpoints": {
            "recording": "/api/Recordings",
            "transcript": base + "/transcript",
            "summary": f"/api/recordings/v2/{recording_id}/summary",
            "protocol": f"/api/recordings/v2/{recording_id}/summary",
        },
    }
    revision = digest(files, meta)
    return files, meta, rows, revision


def preview(query, recording_id, hub, offset=0):
    vault = default_vault_path()
    resolve_hub(vault, hub)
    with client() as api:
        files, meta, rows, revision = prepare(api, query, recording_id, offset)
    return {
        "review": digest(revision, hub),
        "path": package_path(meta, vault),
        "summary": files["summary.md"],
        "protocol": "hidden" if meta["protocol"]["hidden"] else meta["protocol"]["status"],
        "participants": meta["participants_resolved"],
        "topics": [t["title"] for t in meta["linked_artifacts"]["topic"]],
        "utterances": [
            {"anchor": r.anchor, "clock": r.clock, "who": r.who, "text": r.text} for r in rows
        ],
    }


def publish(*, files, meta, rows, revision, hub, anchor, dry_run, automatic=False):
    vault = default_vault_path().resolve()
    hub_path = None if automatic else resolve_hub(vault, hub)[0]
    row = next((r for r in rows if r.anchor == anchor), None)
    if not automatic and row is None:
        raise ValueError("Выберите реплику из предпросмотра.")
    rel = package_path(meta, vault)
    dest = vault / rel
    if dest.resolve() != dest:
        raise ValueError("Путь встречи перенаправлен.")
    with file_lock(dest):
        stored = dest / "metadata.json"
        if stored.is_symlink():
            raise ValueError("Путь метаданных перенаправлен.")
        old = json.loads(stored.read_text(encoding="utf-8")) if stored.exists() else {}
        if old and (old.get("space"), old.get("recording", {}).get("id")) != (
            meta["space"],
            meta["recording"]["id"],
        ):
            raise ValueError("Каталог занят другой встречей.")
        fetched_at = old.get("fetched_at")
        source = dest / "source.md"
        if not old and source.is_file() and not source.is_symlink():
            # Metadata is committed last. Reuse the timestamp of a verified partial first write.
            note = read_note(source)
            if note.frontmatter.get("source_id") == f"{meta['space']}:{meta['recording']['id']}":
                fetched_at = note.frontmatter.get("fetched_at")
        meta = {
            **meta,
            "review": revision,
            "fetched_at": fetched_at or datetime.now(UTC).isoformat(),
        }
        # Reviewed pilot folders predate the review hash. Preserve their authored summaries.
        if automatic:
            meta["automatic"] = True
            if old and not old.get("automatic"):
                return ImportResult(0, 0, 1, dry_run, rel + "/summary.md", "")
        legacy = bool(old and ("review" not in old or (old.get("automatic") and not automatic)))
        if legacy:
            if old["recording"].get("modifiedDate") != meta["recording"].get("modifiedDate") or any(
                old.get(k, {}).get("status") != meta[k]["status"]
                for k in ("transcript", "summary", "protocol")
            ):
                raise ValueError("Источники изменились. Требуется сверка с сохраненной встречей.")
            for filename in files:
                p = dest / filename
                if p.is_symlink() or not p.is_file():
                    raise ValueError("Сохраненная встреча неполна.")
            if f" ^{anchor}\n" not in (dest / "source.md").read_text(encoding="utf-8"):
                raise ValueError("Реплика отсутствует в сохраненном транскрипте.")
        else:
            with TemporaryDirectory() as tmp:
                folder = Path(tmp) / "meeting"
                folder.mkdir()
                for name, text in files.items():
                    (folder / name).write_text(text, encoding="utf-8")
                (folder / "metadata.json").write_text(
                    json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
                )
                import_package(folder, vault, hub, apply=not dry_run, refresh=True)
        if not dry_run and hub_path is not None:
            with file_lock(hub_path):
                target = f"[[{rel}/source#^{anchor}|"
                if target not in hub_path.read_text(encoding="utf-8"):
                    append_reference(
                        hub_path,
                        f"[[{rel}/summary|Итоги · {literal(meta['recording']['title'])}]] · "
                        f"{target}{row.clock} · {literal(row.who)}]]",
                        vault_path=vault,
                        now=datetime.fromisoformat(meta["recording"]["createdDate"]),
                    )
        changed = bool(old and not legacy and old.get("review") != revision)
        return ImportResult(
            int(not old),
            int(changed),
            int(bool(old) and not changed),
            dry_run,
            rel + "/summary.md",
            anchor,
        )


def apply_review(query, recording_id, hub, anchor, review, offset=0):
    from core.ingress.registry import get as adapter

    with client() as api:
        files, meta, rows, revision = prepare(api, query, recording_id, offset)
    if digest(revision, hub) != review:
        raise ValueError("Данные встречи изменились. Откройте предпросмотр еще раз.")
    result = adapter("talk").run(
        dry_run=False, files=files, meta=meta, rows=rows, revision=revision, hub=hub, anchor=anchor
    )
    return {
        "path": result.examples[0],
        "anchor": anchor,
        "new": result.new,
        "changed": result.changed,
        "unchanged": result.unchanged,
    }
