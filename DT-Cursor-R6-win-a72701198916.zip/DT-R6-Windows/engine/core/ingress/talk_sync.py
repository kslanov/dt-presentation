"""Poll the owner's recording list; durable per-space checkpoints live outside the vault."""

import json
import os
import re
from datetime import UTC, datetime, timedelta

from core.config import default_vault_path, ingress_dir
from core.file_lock import file_lock
from core.ingress import talk_service as talk
from core.ingress.run import ingress_run, record_last_run
from core.ingress.stats import IngressStats
from core.ingress.talk import digest
from core.mcp_json_edit import write_text_atomic
from core.privacy import is_nda


def state_path(vault=None):
    space = os.getenv("DT_TALK_SPACE", "").strip().lower()
    identity = digest(space, str((vault or default_vault_path()).resolve()))[:20]
    return ingress_dir() / f"talk-sync-{identity}.json"


def read_state(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}


def _catalog(api, since):
    """The personal API supports offset pagination but promises no ordering."""
    skip = 0
    seen = set()
    result = {}
    while True:
        page = talk.get(api, "/api/Recordings", {"skip": skip, "top": 50, "source": "talk"})[
            "recordings"
        ]
        ids = {record["id"] for record in page}
        if page and not ids - seen:
            raise ValueError("Толк повторил страницу списка записей.")
        seen.update(ids)
        for rec in page:
            key = rec["id"]
            if (
                not re.fullmatch(r"[a-zA-Z0-9_-]+", key)
                or not rec.get("title")
                or is_nda(rec["title"])
            ):
                continue
            if datetime.fromisoformat(rec["createdDate"]) >= since:
                result[key] = rec
        if len(page) < 50:
            return result
        skip += len(page)


def poll(*, dry_run=True, limit=None, should_stop=None, on_progress=None):
    path = state_path()
    with file_lock(path), ingress_run("talk", dry_run=dry_run) as handle:
        now = datetime.now(UTC).isoformat()
        state = read_state(path)
        state.setdefault("since", now)
        entries = state.setdefault("records", {})
        stats = IngressStats(adapter="talk", run_id=handle.run_id, dry_run=dry_run)
        run = {"started": now, "items": [], "errors": [], "pending": 0}

        def save():
            if not dry_run:
                path.parent.mkdir(parents=True, exist_ok=True)
                write_text_atomic(path, json.dumps(state, ensure_ascii=False))

        state["check"] = run
        save()
        try:
            with talk.client() as api:
                records = _catalog(api, datetime.fromisoformat(state["since"]))
                run["seen"] = len(records)
                # Least recently attempted first, including new arrivals and late transcripts.
                keys = sorted(records, key=lambda key: entries.get(key, {}).get("attempt", ""))
                attempted = 0
                for key in keys:
                    rec = records[key]
                    signature = digest(
                        rec.get("modifiedDate"),
                        rec.get("title"),
                        (rec.get("transcription") or {}).get("status"),
                    )
                    old = entries.get(key, {})
                    if old.get("done") == signature and (
                        "next_probe" not in old or old["next_probe"] > now
                    ):
                        stats.unchanged += 1
                        continue
                    if should_stop and should_stop():
                        stats.interrupted = 1
                        break
                    if attempted >= (12 if limit is None else limit):
                        stats.pending += 1
                        continue
                    attempted += 1
                    if on_progress:
                        on_progress("Проверка записи Толка")
                    entry = entries.setdefault(key, {})
                    entry["attempt"] = now
                    try:
                        files, meta, rows, rev = talk.prepare_recording(api, rec, automatic=True)
                        saved = talk.publish(
                            files=files,
                            meta=meta,
                            rows=rows,
                            revision=rev,
                            hub=None,
                            anchor="",
                            dry_run=dry_run,
                            automatic=True,
                        )
                        stats.new += saved.new
                        stats.changed += saved.changed
                        stats.unchanged += saved.unchanged
                        if saved.new or saved.changed:
                            item = {
                                "title": rec["title"],
                                "path": saved.path,
                                "at": now,
                                "change": "new" if saved.new else "changed",
                            }
                            run["items"].append(item)
                            state["recent"] = [item, *state.get("recent", [])][:20]
                        # A queued summary/protocol can arrive after the transcript.
                        waiting = any(
                            meta[part].get("status")
                            in {
                                "pending",
                                "queued",
                                "processing",
                                "inProgress",
                                "recreateInProgress",
                                "started",
                            }
                            for part in ("summary", "protocol")
                        )
                        if not waiting:
                            entry["done"] = signature
                            if any(
                                meta[part].get("status") != "success"
                                for part in ("summary", "protocol")
                            ):
                                entry["next_probe"] = (
                                    datetime.now(UTC) + timedelta(days=1)
                                ).isoformat()
                            else:
                                entry.pop("next_probe", None)
                        else:
                            stats.pending += 1
                    except talk.PrivateRecording:
                        stats.skipped_privacy += 1
                    except talk.TranscriptPending:
                        stats.pending += 1
                    except (ValueError, KeyError, OSError, TypeError) as exc:
                        stats.errors += 1
                        run["errors"].append({"title": rec["title"], "reason": _reason(exc)})
                    save()
            if not stats.errors and not stats.interrupted:
                state["last_success"] = datetime.now(UTC).isoformat()
        except (ValueError, KeyError, OSError, TypeError) as exc:
            stats.errors += 1
            run["errors"].append({"reason": _reason(exc)})
        run["finished"] = datetime.now(UTC).isoformat()
        run["pending"] = stats.pending
        run["interrupted"] = bool(stats.interrupted)
        stats.written = 0 if dry_run else stats.new + stats.changed
        save()
        if not dry_run:
            record_last_run(stats)
        return stats


def _reason(exc):
    if isinstance(exc, ValueError) and type(exc) is ValueError:
        return str(exc)[:250]
    return "Не удалось прочитать или сохранить данные встречи."
