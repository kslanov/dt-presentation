"""Plan confirmation for the starter kit and a local HTML snapshot of progress."""

from __future__ import annotations

import hashlib
import json
from html import escape

from core.file_lock import file_lock
from core.install.base import InstallError
from core.mcp_json_edit import write_text_atomic


def _path(ctx):
    return ctx.derived / "install" / "deployment.json"


def required(ctx) -> bool:
    return (ctx.engine_dir.parent / "KIT-MANIFEST.json").is_file()


def plan(ctx, answers, *, obsidian: bool, options: dict, source_dir: str = "") -> dict:
    from core.install import capabilities
    from core.install.wizard import validate_connectors

    env = ctx.env_values()
    choices = capabilities.choices_from_answers(ctx.answers)
    managed = capabilities.is_managed(choices)
    resolved = capabilities.resolve(choices, capabilities.facts_from_ctx(ctx)) if managed else None
    connectors = validate_connectors(ctx.answers.connectors or env.get("DT_CONNECTORS") or "none")
    plan = {
        "vault": str(ctx.vault),
        "assistant": ctx.host,
        "obsidian": obsidian,
        "connectors": capabilities.effective_connectors(resolved) if resolved else connectors,
        "preset": ctx.answers.preset or "base",
        "sleep": resolved.sleep.effective if resolved else "off",
        "enable": ctx.answers.enable,
        "disable": ctx.answers.disable,
        "profile_supplied": bool(ctx.answers.name and ctx.answers.emails),
    }
    if source_dir:
        from core.install.source_setup import source_path
        plan["source_dir"] = str(source_path(ctx, source_dir))
        plan["cursor_mcp"] = True
    payload = {**plan, "env": str(ctx.env_path), "home": str(ctx.home),
               "answers": answers.as_dict(), "options": options}
    return {**plan, "code": hashlib.sha256(json.dumps(
        payload, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]}


def confirmed(ctx) -> dict:
    try:
        data = json.loads(_path(ctx).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        raise InstallError("deployment_state", "Не удалось прочитать подтвержденный план",
                           "проверь .derived/install/deployment.json") from exc
    if not isinstance(data, dict):
        raise InstallError("deployment_state", "Неверный формат плана",
                           "проверь .derived/install/deployment.json")
    return data if data.get("vault") == str(ctx.vault) else {}


def confirm(ctx, proposed: dict, code: str) -> None:
    if proposed["code"] != code:
        raise InstallError("deployment_changed", "План изменился или код не совпадает",
                           "покажи новый --preview-deployment владельцу и получи подтверждение")
    path = _path(ctx)
    ctx.guard(path, ctx.env_path, ctx.vault)
    with file_lock(path):
        if confirmed(ctx) != proposed:
            path.parent.mkdir(parents=True, exist_ok=True)
            write_text_atomic(path, json.dumps(proposed, ensure_ascii=False, indent=2) + "\n")


def plan_lines(proposed: dict) -> list[str]:
    return [
        "Хранилище: " + proposed["vault"],
        *(["Исходные файлы и вложенные папки: " + proposed["source_dir"],
           "После установки: импорт в заметки, индекс и подключение digital-twin к Cursor."]
          if proposed.get("source_dir") else []),
        "Ассистент: " + proposed["assistant"],
        "Obsidian: " + ("открыть это хранилище" if proposed["obsidian"] else "отложен"),
        "После первой справки на рабочем столе появится ярлык «Пульт Digital Twin».",
        "Ядро: службы, модели поиска, индекс и диагностика.",
        "Профиль: " + ("имя и адрес заданы" if proposed["profile_supplied"]
                      else "нужно заполнить"),
        "Коннекторы: " + proposed["connectors"],
        "Сон: " + proposed["sleep"],
        "Пресет: " + proposed["preset"],
        "Запрошенные опции: " + (", ".join(proposed["enable"]) or "нет"),
        "Исключенные опции: " + (", ".join(proposed["disable"]) or "нет"),
        "Далее: подтвердить профиль, добавить один документ, найти его и сохранить ответ.",
    ]


_STATUS = {
    "done": ("✓", "Готово"),
    "next": ("→", "Следующий шаг"),
    "partial": ("◐", "Частично"),
    "deferred": ("–", "Отложено"),
    "pending": ("○", "Ожидает"),
}

_CORE_TITLES = {
    "platform": "Проверка компьютера",
    "vault": "Хранилище",
    "owner": "Создание профиля",
    "launchd": "Фоновые службы",
    "tasks": "Задания Windows",
    "index": "Индекс документов",
}


def _stage(title: str, state: str) -> str:
    icon, label = _STATUS[state]
    current = ' aria-current="step"' if state == "next" else ""
    return (
        f'<li class="stage {state}"{current}>'
        f'<span class="mark" aria-hidden="true">{icon}</span>'
        f'<span class="stage-title">{escape(title)}</span>'
        f'<span class="stage-state">{label}</span></li>'
    )


def _checklist(title: str, rows: str, done: int, total: int, *, note: str = "") -> str:
    heading_id = "setup-heading" if note else "core-heading"
    note_html = f'<p class="count-note">{escape(note)}</p>' if note else ""
    return f"""
    <section class="panel" aria-labelledby="{heading_id}">
      <div class="panel-head">
        <h2 id="{heading_id}">{title}</h2><strong class="count">{done} из {total}</strong>
      </div>
      <progress value="{done}" max="{total}" aria-labelledby="{heading_id}"></progress>
      {note_html}
      <ol class="stages">{rows}</ol>
    </section>"""


def _plan_details(proposed: dict, *, saved: bool, ready: bool) -> str:
    heading = (
        "Подтвержденный план" if saved else
        "Ядро установлено без подтвержденного плана" if ready else "План к подтверждению"
    )
    assistant = {"none": "Не подключать", "claude": "Claude Desktop", "cursor": "Cursor",
                 "kimi": "Kimi", "cherry": "Cherry Studio"}
    connectors = proposed["connectors"].replace(",", ", ")
    connectors = {"none": "Не подключать", "auto": "По доступности"}.get(connectors, connectors)
    fields = {
        "Хранилище": proposed["vault"],
        "Ассистент": assistant.get(proposed["assistant"], proposed["assistant"]),
        "Obsidian": "Открыть это хранилище" if proposed["obsidian"] else "Отложен",
        "Интеграции": connectors,
        "Сон": {"off": "Выключен", "manual": "Ручной", "scheduled": "По расписанию"}[
            proposed["sleep"]],
        "Пресет": proposed["preset"] if proposed["preset"] != "base" else "Базовый",
    }
    if proposed.get("source_dir"):
        fields["Папка исходников (с подпапками)"] = proposed["source_dir"]
        fields["Cursor MCP"] = "digital-twin"
    for key, label in (("enable", "Запрошенные опции"), ("disable", "Исключенные опции")):
        if proposed[key]:
            fields[label] = ", ".join(proposed[key])
    values = "".join(f"<div><dt>{label}</dt><dd>{escape(value)}</dd></div>"
                     for label, value in fields.items())
    opened = "" if ready else " open"
    return (f'<details class="panel plan"{opened}><summary>{heading}</summary>'
            f"<dl>{values}</dl></details>")


def report(ctx, progress: dict, rows, proposed: dict) -> str:
    from core.install.onboarding import OPTIONAL

    path = ctx.derived / "install" / "deployment.html"
    ctx.guard(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    saved = confirmed(ctx)
    ready = progress["core"] == "ready"
    complete = progress["onboarding"] == "done"
    phase = progress["next_phase"]
    core_next = next((row for row in rows if not row.check.done), None)
    if complete:
        icon, label, headline = "✓", "Развертывание завершено", "Первый результат сохранен"
    elif phase:
        icon, label, headline = "→", "Следующий шаг", phase["title"]
    elif saved:
        icon, label, headline = "→", "Следующий шаг", (
            _CORE_TITLES.get(core_next.step.name, core_next.step.title)
            if core_next else "Завершить установку ядра")
    else:
        icon, label, headline = "→", "Следующий шаг", "Подтвердить план установки"

    result = progress["phases"][-1].get("result")
    from core.host_config import daemon_port
    result_line = ""
    if result:
        uri = (ctx.vault / result / "output.md").as_uri()
        result_line = f'<p class="result"><a href="{escape(uri)}">Открыть справку</a></p>'
    if ready:
        result_line += f'<p><a href="http://127.0.0.1:{daemon_port()}/">Открыть Пульт</a></p>'
    imported = progress.get("source_import") or {}
    if imported.get("state"):
        states = {"ready": "Импорт завершен", "empty": "Папка подключена и ожидает файлов",
                  "running": "Идет импорт", "failed": "Импорт требует внимания"}
        result_line += (f'<p>{states.get(imported["state"], "Импорт")}. '
                        f'Файлов: {int(imported.get("seen", 0))}. '
                        f'Читаемых заметок: {int(imported.get("notes", 0))}.</p>')
    core_items = "".join(
        _stage(_CORE_TITLES.get(row.step.name, row.step.title),
               "next" if saved and row is core_next else
               "pending" if row.check.state == "absent" else row.check.state)
        for row in rows
    )
    setup_items = "".join(
        _stage(item["title"], "next" if item == phase else item["state"])
        for item in progress["phases"]
    )
    must_do = [item for item in progress["phases"] if item["id"] not in OPTIONAL]
    deferred = sum(item["state"] == "deferred" for item in progress["phases"])
    setup_title = "Настройка под владельца"
    setup_note = "Обязательные шаги"
    if deferred:
        setup_note += f" · отложено опций: {deferred}"
    core_section = _checklist(
        "Готовность ядра", core_items, sum(row.check.done for row in rows), len(rows))
    setup_section = _checklist(setup_title, setup_items,
                               sum(item["state"] == "done" for item in must_do),
                               len(must_do), note=setup_note)
    details = _plan_details(saved or proposed, saved=bool(saved), ready=ready)
    hero_state = "done" if complete else "next"
    columns_state = "ready" if ready else "waiting"
    write_text_atomic(path, f"""<!doctype html>
<html lang="ru">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Развертывание Digital Twin</title>
<style>
:root {{
  color-scheme:dark; background:#1c1c1e; color:#f5f5f7;
  font:16px/1.45 -apple-system,BlinkMacSystemFont,system-ui,sans-serif;
  --muted:#babac1; --rule:#414145; --green:#82d7a8; --blue:#a4cbff;
}}
* {{ box-sizing:border-box }}
body {{ max-width:1056px; margin:auto; padding:clamp(16px,4vw,48px) }}
h1 {{ margin:0 0 18px; font-size:clamp(1.6rem,4vw,2.1rem); letter-spacing:-.025em }}
h2,p,ol,dl,dd {{ margin:0 }}
.hero,.panel {{ border:1px solid var(--rule); border-radius:16px; background:#262628 }}
.hero {{ display:flex; gap:14px; align-items:flex-start; padding:16px 20px; margin-bottom:16px }}
.hero.next {{ border-color:#527db3; background:#232c38 }}
.hero.done {{ border-color:#4f8767; background:#23332b }}
.hero small {{ color:var(--muted); font-weight:600; font-size:.85rem }}
.hero h2 {{ font-size:clamp(1.1rem,3vw,1.45rem); line-height:1.3 }}
.result {{ color:var(--muted); margin-top:6px; font-size:.88rem; overflow-wrap:anywhere }}
.columns {{ display:grid; grid-template-columns:1fr 1fr; align-items:start; gap:16px }}
.panel {{ padding:17px 19px; min-width:0 }}
.panel-head {{ display:flex; align-items:baseline; justify-content:space-between; gap:12px }}
.panel-head h2 {{ font-size:1.08rem; line-height:1.3 }}
.count {{ white-space:nowrap; font-size:1.18rem; font-variant-numeric:tabular-nums }}
.count-note {{ margin:5px 0 0; font-size:.83rem; color:var(--muted) }}
progress {{ display:block; width:100%; height:7px; margin:11px 0;
            appearance:none; border:0; border-radius:6px; overflow:hidden }}
progress::-webkit-progress-bar {{ background:#414145 }}
progress::-webkit-progress-value {{ background:#75c99a }}
progress::-moz-progress-bar {{ background:#75c99a }}
.stages {{ list-style:none; padding:0 }}
.stage {{ display:flex; align-items:center; gap:9px; padding:7px 0;
          border-bottom:1px solid var(--rule); min-height:40px }}
.stage:last-child {{ border:0 }}
.stage.next {{ background:#29384e; margin:3px -7px; padding:7px;
               border:1px solid #527db3; border-radius:9px }}
.mark {{ display:grid; place-items:center; width:24px; height:24px; flex:none; border-radius:6px;
         color:var(--muted); background:#39393d; font-size:.97rem; font-weight:700 }}
.hero .mark {{ width:34px; height:34px; font-size:1.2rem }}
.stage-title {{ flex:1; min-width:0; font-size:.95rem; font-weight:550 }}
.stage-state {{ color:var(--muted); font-size:.76rem; text-align:right; font-weight:600 }}
.done .mark {{ color:var(--green); background:#263e31 }}
.done .stage-state {{ color:var(--green) }}
.next .mark {{ color:var(--blue); background:#354e6c }}
.next .stage-state {{ color:var(--blue) }}
.deferred .mark,.partial .mark {{ color:#ffda91; background:#443925 }}
.deferred .stage-state,.partial .stage-state {{ color:#ffda91 }}
.plan {{ margin-top:16px }}
.hero + .plan {{ margin:0 0 16px }}
summary {{ cursor:pointer; font-weight:650 }}
summary:focus-visible {{ outline:2px solid var(--blue); outline-offset:4px }}
dl {{ display:grid; grid-template-columns:repeat(auto-fit,minmax(min(100%,210px),1fr)); gap:12px;
      margin:13px 0 0; padding-top:12px; border-top:1px solid var(--rule) }}
dt {{ color:var(--muted); font-size:.8rem }}
dd {{ overflow-wrap:anywhere; font-size:.93rem }}
@media (max-width:680px) {{
  .columns {{ grid-template-columns:1fr }}
  .columns.ready .panel:last-child {{ order:-1 }}
}}
</style>
</head>
<body>
<h1>Развертывание Digital Twin</h1>
<main>
  <section class="hero {hero_state}" aria-labelledby="headline">
    <span class="mark" aria-hidden="true">{icon}</span>
    <div><small>{label}</small><h2 id="headline">{escape(headline)}</h2>{result_line}</div>
  </section>
  {details if not ready else ""}
  <div class="columns {columns_state}">{core_section}{setup_section}</div>
  {details if ready else ""}
</main>
</body></html>
""")
    return str(path)
