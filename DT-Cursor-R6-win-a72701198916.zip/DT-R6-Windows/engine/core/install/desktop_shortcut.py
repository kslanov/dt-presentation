"""User's Windows Desktop entry for the installed Pult launcher."""
import os
import subprocess
from pathlib import Path

TITLE = "Пульт Digital Twin"


def shortcut(ctx, mode):
    if mode not in {"ensure", "inspect", "remove"}:
        raise ValueError("Unknown shortcut action")
    if os.name != "nt":
        return "unavailable"
    shell = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
    try:
        proc = subprocess.run(  # noqa: S603 - fixed kit script, validated action
            [str(shell), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File",
             str(ctx.engine_dir / "ops/windows-shortcut.ps1"), "-Mode", mode],
            env={**os.environ, "DT_SHORTCUT_TITLE": TITLE}, capture_output=True,
            timeout=15, encoding="utf-8", errors="replace", check=True,
        )
    except (OSError, subprocess.SubprocessError):
        return "unavailable"
    state = proc.stdout.strip()
    return state if state in {"ready", "missing", "conflict"} else "unavailable"
