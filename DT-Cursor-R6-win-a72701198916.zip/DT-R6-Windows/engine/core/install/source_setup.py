"""Import the folder approved in the deployment plan and keep the first-run evidence."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import yaml

from core.file_lock import file_lock
from core.install import deployment
from core.install.base import InstallError
from core.mcp_json_edit import write_text_atomic
from core.privacy import is_nda

ROOT_NAME = "dt-documents"


def source_path(ctx, value: str) -> Path:
    path = Path(value).expanduser()
    if not value or not path.is_absolute():
        raise InstallError("source_dir", "Укажите полный путь к папке исходников")
    path = path.resolve()
    if (
        path == Path(path.anchor)
        or path.is_relative_to(ctx.vault)
        or ctx.vault.is_relative_to(path)
        or ctx.workspace.is_relative_to(path)
        or any(
            path.is_relative_to(p)
            for p in (ctx.engine_dir, ctx.derived, ctx.workspace / ".secrets")
        )
        or is_nda(str(path))
        or (path.exists() and not path.is_dir())
    ):
        raise InstallError(
            "source_dir", "Выберите отдельную папку исходников вне хранилища и служебных папок"
        )
    return path


def _receipt(ctx):
    return ctx.derived / "install" / "source-import.json"


def evidence(ctx):
    try:
        row = json.loads(_receipt(ctx).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    plan = deployment.confirmed(ctx)
    return row if plan.get("source_dir") and row.get("plan") == plan["code"] else {}


def _register(ctx, path):
    from core.file_ingest.config import load_ingest_roots

    config = ctx.vault / "_system/ingest-roots.yaml"
    entry = {
        "name": ROOT_NAME,
        "path": str(path),
        "route": "knowledge",
        "corpus": "current",
        "include": ["**/*"],
        "exclude": ["**/~$*"],
    }
    with file_lock(config):
        original = config.read_text(encoding="utf-8")
        data = yaml.safe_load(original)
        roots = data["roots"]
        for registered in load_ingest_roots(ctx.vault):
            if registered.path.resolve() == path:
                if registered.route == "knowledge" and registered.corpus == "current":
                    return registered.name
                raise InstallError(
                    "source_conflict", "Эта папка уже подключена с другим назначением"
                )
        existing = next((r for r in roots if r["name"] == ROOT_NAME), None)
        if existing is None:
            roots.append(entry)
            comments = "\n".join(line for line in original.splitlines() if line.startswith("#"))
            write_text_atomic(
                config, comments + "\n" + yaml.safe_dump(data, allow_unicode=True, sort_keys=False)
            )
        elif existing != entry:
            raise InstallError(
                "source_conflict", "Настройки источника изменились. Сверьте их в Пульте"
            )
        actual = next((r for r in load_ingest_roots(ctx.vault) if r.name == ROOT_NAME), None)
        if not actual or actual.path.resolve() != path:
            raise InstallError("source_conflict", "Настроенный путь отличается от подтвержденного")
    return ROOT_NAME


def note_paths(ctx, root):
    from core.config import current_ingest_manifest_path
    from core.legacy.ingest import _load_manifest

    manifest = _load_manifest(current_ingest_manifest_path())
    return {
        row["note_path"]: row
        for row in manifest.values()
        if row.get("root") == root
        and row.get("note_path")
        and (ctx.vault / row["note_path"]).resolve().is_relative_to(ctx.vault)
        and (ctx.vault / row["note_path"]).is_file()
    }


def linked_source(ctx, folder):
    """Return the imported Obsidian note referenced by the finalized first document."""
    proof = evidence(ctx)
    if proof.get("state") not in {"ready", "empty"}:
        return ""
    allowed = {proof["root"]}
    if proof["state"] == "empty":
        allowed.add("windows-pilot")
    links = {
        ref.removesuffix(".md")
        for ref in re.findall(
            r"\[\[([^\]|#\n]+)(?:[#|][^\]\n]*)?\]\]",
            (ctx.vault / folder / "output.md").read_text(encoding="utf-8"),
        )
    }
    for root in allowed:
        for rel, row in note_paths(ctx, root).items():
            if rel.removesuffix(".md") in links and row.get("ocr") in (None, "done", "low"):
                return rel
    return ""


def run(ctx):
    from core.file_ingest import scan
    from core.retrieval.index import reindex

    plan = deployment.confirmed(ctx)
    path = source_path(ctx, plan.get("source_dir", ""))
    ctx.guard(path, ctx.vault, ctx.derived)
    receipt = _receipt(ctx)
    with file_lock(receipt):
        result = {"plan": plan["code"], "state": "running", "folder": str(path)}

        def save(**fields):
            result.update(fields)
            write_text_atomic(receipt, json.dumps(result, ensure_ascii=False, indent=2))

        save()
        try:
            path.mkdir(parents=True, exist_ok=True)
            next(path.iterdir(), None)  # distinguish an unreadable folder from an empty one
            root = _register(ctx, path)
            stats = scan(vault_path=ctx.vault, root_name=root, dry_run=False, reindex=False)
            notes = note_paths(ctx, root)
            readable = sorted(
                rel for rel, row in notes.items() if row.get("ocr") in (None, "done", "low")
            )
            save(
                root=root,
                seen=stats.total_seen,
                notes=len(readable),
                examples=readable[:5],
                scans=len(notes) - len(readable),
                excluded=stats.excluded,
                errors=stats.errors,
                pending_download=stats.pending_download,
                without_note=max(0, stats.total_seen - len(notes)),
            )
            if stats.interrupted or stats.errors or stats.prune_guard:
                raise InstallError(
                    "source_import",
                    "Обход папки прерван или содержит ошибки. Проверьте журнал импорта",
                )
            if readable:
                reindex(ctx.vault)
            if stats.total_seen and not readable:
                raise InstallError(
                    "source_import",
                    "В папке пока нет читаемых заметок. Проверьте форматы и распознавание",
                )
            save(state="ready" if readable else "empty")
        except Exception as exc:
            save(state="failed", error=str(exc)[:500])
            raise
        print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    from core.install.context import InstallContext

    try:
        run(InstallContext.build(root=Path(sys.argv[1]), vault=Path(sys.argv[2])))
    except (ValueError, OSError, InstallError, yaml.YAMLError) as exc:
        sys.exit(str(exc))
