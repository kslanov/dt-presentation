param([ValidateSet('ensure','inspect','remove')][string]$Mode)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
if (-not $desktop -or -not [IO.Directory]::Exists($desktop)) { throw 'Desktop unavailable' }
$path = Join-Path $desktop ($env:DT_SHORTCUT_TITLE + '.lnk')
$engine = Split-Path -Parent $PSScriptRoot
$target = Join-Path (Split-Path -Parent $engine) 'DT.cmd'
$arguments = 'pult open --rw'
function Get-LinkState {
    if (-not (Test-Path -LiteralPath $path)) { return 'missing' }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.PSIsContainer -or ($item.LinkType -in @('Junction','SymbolicLink'))) { return 'conflict' }
    $link = $shell.CreateShortcut($path)
    if ($link.TargetPath -eq $target -and $link.Arguments -ceq $arguments) { return 'ready' }
    return 'conflict'
}
$state = Get-LinkState
if ($Mode -eq 'ensure' -and $state -eq 'missing') {
    if (-not [IO.File]::Exists($target)) { throw 'Launcher unavailable' }
    $temp = Join-Path $desktop ([guid]::NewGuid().ToString() + '.lnk')
    try {
        $link = $shell.CreateShortcut($temp)
        $link.TargetPath = $target
        $link.Arguments = $arguments
        $link.WorkingDirectory = Split-Path -Parent $target
        $link.Description = $env:DT_SHORTCUT_TITLE
        $link.IconLocation = "$env:SystemRoot\System32\shell32.dll,21"
        $link.Save()
        try { [IO.File]::Move($temp, $path) }
        catch [IO.IOException] { if (-not [IO.File]::Exists($path)) { throw } }
    } finally {
        if ([IO.File]::Exists($temp)) { [IO.File]::Delete($temp) }
    }
    $state = Get-LinkState
} elseif ($Mode -eq 'remove' -and $state -eq 'ready') {
    [IO.File]::Delete($path)
    $state = Get-LinkState
}
[Console]::Write($state)
