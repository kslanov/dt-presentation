@echo off
setlocal
powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0installer\bootstrap.ps1" %*
exit /b %errorlevel%
