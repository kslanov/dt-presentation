"""Read-only evidence for a manual run. No note bodies, usernames, tokens or full paths."""
import json
import os
import platform
from pathlib import Path

from core.install import onboarding
from core.install.context import InstallContext


def collect(ctx):
    from core.output import read_meta

    root = ctx.engine_dir.parent
    manifest = json.loads((root / "KIT-MANIFEST.json").read_text(encoding="utf-8"))
    receipt = {"candidate": manifest["candidate"], "system": platform.system(),
               "build": platform.version(), "architecture": platform.machine(),
               "assistant": ctx.host}
    records = ctx.state.steps
    if os.name == "nt":
        import subprocess
        shell = Path(os.environ["SystemRoot"]) / "System32/WindowsPowerShell/v1.0/powershell.exe"
        found = subprocess.run([str(shell), "-NoProfile", "-Command",
            "(Get-Process -Name Cursor -ErrorAction SilentlyContinue | Select-Object -First 1).Path | "
            "ForEach-Object { if ($_) { (Get-Item -LiteralPath $_).VersionInfo.ProductVersion } }"],
            capture_output=True, text=True, timeout=15)
        receipt["cursor_version"] = found.stdout.strip() or None
    receipt["core_steps"] = {name: row.status for name, row in records.items()}
    fail = next((key for key, row in records.items() if row.status == "failed"), "")
    if fail:
        receipt["failed_step"] = fail
    early = root / "first-failure.json"
    if early.is_file():
        receipt["first_failure_step"] = json.loads(early.read_text(encoding="utf-8-sig"))["step"]
    result = onboarding.status(ctx, missing=[] if all(records.get(s) and records[s].status == "done"
        for s in ("platform","deps","config","vault","owner","models","tasks","host","index","doctor"))
        else ["core"])
    saved = next((p.get("result") for p in result["phases"] if p["id"] == onboarding.FINAL), "")
    receipt["onboarding"] = result["onboarding"]
    if saved:
        folder = ctx.vault / saved
        content = (folder / "output.md").read_text(encoding="utf-8").casefold()
        receipt["document_finalized"] = read_meta(folder / "meta.yaml").get("status") == "final"
        receipt["control_answer_present"] = "янтарь-47" in content and "сред" in content
        receipt["sources_recorded"] = (folder / "sources.md").is_file()
        receipt["document"] = saved + "/output.md"
    return receipt


if __name__ == "__main__":
    ctx = InstallContext.build()
    print(json.dumps(collect(ctx), ensure_ascii=False, indent=2))
