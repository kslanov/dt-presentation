"""Dispatch the supported Windows commands and preserve the first failing stage for the pilot."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engine"


def execute(*args):
    return subprocess.call([sys.executable, "-X", "utf8", *map(str, args)], cwd=ENGINE)


def main(args):
    if not args:
        print("install | source | receipt | owner | doctor | uninstall")
        return 2
    name, *options = args
    if name == "receipt":
        from core.install.context import InstallContext
        from ops.acceptance import collect
        receipt = ROOT / "test-result.json"
        receipt.write_text(json.dumps(collect(InstallContext.build()), ensure_ascii=False,
                                      indent=2), encoding="utf-8")
        print(receipt)
        return 0
    if name == "source":
        if options:
            return 2
        steps = [("source-register", ["ops/control_source.py"]),
                 ("source-ingest", ["cli/dt_ingest.py", "--apply", "--root", "windows-pilot"]),
                 ("source-index", ["cli/dt_index.py"])]
    elif name in ("install", "owner", "doctor", "uninstall"):
        steps = [(name, ["cli/dt.py", name, *options])]
    else:
        return 2
    for step, command in steps:
        code = execute(*command)
        if code:
            from core.install.context import InstallContext
            ctx = InstallContext.build()
            failed = next((k for k,v in ctx.state.steps.items() if v.status == "failed"), step)
            path = ROOT / "first-failure.json"
            try:
                with path.open("x", encoding="utf-8") as out:
                    json.dump({"step": failed, "command": step, "returncode": code}, out)
            except FileExistsError:
                pass
            return code
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
