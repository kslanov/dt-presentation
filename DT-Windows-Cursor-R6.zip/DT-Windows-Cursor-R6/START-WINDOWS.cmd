@echo off
setlocal
set "DT_PROBE_RUN=%TEMP%\dt-win-%RANDOM%-%RANDOM%-%RANDOM%"
mkdir "%DT_PROBE_RUN%" || exit /b 1
echo Report: "%DT_PROBE_RUN%\report.json"
powershell.exe -NoProfile -NonInteractive -Command ^
  "$ErrorActionPreference='Stop'; $r=[ordered]@{kit_revision='R6';engine_version='0.3.17';stage='machine';status='blocked';cursor_scenario='not_run'};" ^
  "try { $os=Get-CimInstance Win32_OperatingSystem; $cpu=Get-CimInstance Win32_Processor | Select-Object -First 1; $r.windows_build=[int]$os.BuildNumber; $r.windows_caption=$os.Caption; $r.cpu_architecture=[int]$cpu.Architecture; $r.uv_available=[bool](Get-Command uv.exe -ErrorAction SilentlyContinue);" ^
  "if ($os.ProductType -ne 1 -or $r.windows_build -lt 22000 -or $r.cpu_architecture -ne 9) { $r.reason='This test targets Windows 11 x64 (Intel or AMD). See windows_build and cpu_architecture.' }" ^
  "elseif (-not $r.uv_available) { $r.stage='uv'; $r.reason='uv is missing from PATH. Install uv and reopen the terminal.' }" ^
  "else { $r.stage='python-bootstrap'; $r.reason='Check the uv console output if Python 3.12 does not start.' } } catch { $r.reason=$_.Exception.Message };" ^
  "$r | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $env:DT_PROBE_RUN 'report.json') -Encoding UTF8; if ($r.stage -ne 'python-bootstrap') { Write-Host $r.reason; exit 1 }"
if errorlevel 1 exit /b 1
uv.exe run --no-project --python 3.12 python "%~dp0run.py" --report-dir "%DT_PROBE_RUN%" %*
exit /b %ERRORLEVEL%
