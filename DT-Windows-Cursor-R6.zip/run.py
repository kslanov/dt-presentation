"""Prepare an isolated corpus and run the pinned DT installer platform check."""

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path


BASE = Path(__file__).resolve().parent
KIT_REVISION = "R6"
KIT_SHA = "1b57bf7374429409191c7819da5bd26bba1dafecfef3d5df5b4233b0362b39c8"
NOTE = "02-knowledge/win-cursor-beacon.md"
NOTE_SHA = "7bff5e4e6691dbc3bd477a8a2de5fa2741bda9405f96345322457b4294153647"


class RunBlocked(Exception):
    """A failed precondition or observed DT failure, saved in the report."""


def cursor_version(override):
    candidates = [override] if override else [
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs/Cursor/Cursor.exe",
        Path(os.environ.get("ProgramFiles", "")) / "Cursor/Cursor.exe",
    ]
    for binary in candidates:
        if binary and binary.is_file() and binary.name.lower() == "cursor.exe":
            # The app's own VS Code-compatible package can have two version fields.
            # Read the Windows product version from the executable itself.
            command = "(Get-Item -LiteralPath $env:DT_PROBE_CURSOR).VersionInfo.ProductVersion"
            result = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", command],
                env={**os.environ, "DT_PROBE_CURSOR": str(binary)}, capture_output=True,
                text=True, timeout=30, check=False,
            )
            version = result.stdout.strip()
            if result.returncode == 0 and re.match(r"^\d+\.\d+", version):
                return version
    raise RunBlocked("Cursor.exe or its version was not found. See --cursor-exe.")


def prepare_corpus(engine, work):
    vault = work / "vault"
    shutil.copytree(engine / "vault-template", vault)
    target = vault / NOTE
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(BASE / "control-note.md", target)
    return hashlib.sha256(target.read_bytes()).hexdigest()


def call(args, *, cwd, env, log, timeout):
    with log.open("w", encoding="utf-8") as out:
        result = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE,
                                stderr=out, text=True, encoding="utf-8",
                                errors="replace", timeout=timeout, check=False)
        out.write(result.stdout)
    return result


def probe(run, report, cursor_exe):
    report["stage"] = "machine"
    if sys.platform != "win32":
        raise RunBlocked("Use a clean Windows 11 x64 test account.")
    windows = sys.getwindowsversion()
    build = windows.build
    arch = os.environ.get("PROCESSOR_ARCHITEW6432") or os.environ.get("PROCESSOR_ARCHITECTURE")
    report.update(windows_build=build, native_arch=arch, python=platform.python_version())
    if (windows.product_type != 1 or build < 22000 or (arch or "").upper() != "AMD64"
            or sys.maxsize <= 2**32 or sys.version_info[:2] != (3, 12)):
        raise RunBlocked("The selected baseline requires Windows 11 x64 and 64-bit Python 3.12.")
    report["stage"] = "cursor-version"
    report["cursor_version"] = cursor_version(cursor_exe)
    report["stage"] = "kit-integrity"
    kit = BASE / "baseline.zip"
    digest = hashlib.sha256(kit.read_bytes()).hexdigest()
    if digest != KIT_SHA:
        raise RunBlocked("Baseline ZIP checksum mismatch.")
    with zipfile.ZipFile(kit) as archive:
        archive.extractall(run)
    engine = run / "dt-starter-kit" / "engine"
    work = run / "work"
    report["control_sha256"] = prepare_corpus(engine, work)
    if report["control_sha256"] != NOTE_SHA:
        raise RunBlocked("Control note checksum mismatch.")
    report["stage"] = "dependencies"
    uv = shutil.which("uv")
    if not uv:
        raise RunBlocked("Install uv for the test account and start a new run.")
    env = {k: v for k, v in os.environ.items()
           if not k.upper().startswith(("DT_", "UV_", "PYTHON"))
           and k.upper() != "VIRTUAL_ENV"}
    env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8", PYTHONPATH=str(engine),
               DT_CONNECTORS="none", DT_VAULT_PATH=str(work / "vault"))
    report["uv_version"] = subprocess.check_output([uv, "--version"], text=True, timeout=30).strip()
    result = call([uv, "sync", "--locked", "--all-extras", "--python", sys.executable],
                  cwd=engine, env=env, log=run / "dependencies.log", timeout=1800)
    if result.returncode:
        report["exit_code"] = result.returncode
        raise RunBlocked("uv sync failed. See dependencies.log.")
    report["stage"] = "install-platform"
    result = call([str(engine / ".venv/Scripts/python.exe"), "cli/dt.py", "install",
                   "--step", "platform", "--check", "--json", "--host", "cursor",
                   "--root", str(work), "--vault", str(work / "vault"),
                   "--home", str(run / "test-home"), "--env-file", str(work / ".env"),
                   "--engine-dir", str(engine)], cwd=engine, env=env,
                  log=run / "install-platform.log", timeout=180)
    report["exit_code"] = result.returncode
    try:
        rows = json.loads(result.stdout)
        row = next(item for item in rows if item["step"] == "platform")
    except (ValueError, KeyError, TypeError, StopIteration):
        log_text = (run / "install-platform.log").read_text(encoding="utf-8")
        missing = re.search(r"ModuleNotFoundError: No module named '([\w.]+)'", log_text)
        if missing:
            report["missing_module"] = missing.group(1)
        raise RunBlocked("Installer returned no platform row. See install-platform.log.") from None
    report["platform_result"] = row
    if result.returncode or row["state"] != "done":
        raise RunBlocked("Installer rejected the platform. See platform_result.")
    report["status"] = "platform_passed"
    report["note"] = "Platform check passed. Verify Cursor separately using README.md."


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cursor-exe", type=Path, help="Path for a custom Cursor installation")
    args = parser.parse_args()
    run = Path(tempfile.mkdtemp(prefix="dt-win-"))
    report = {"kit_revision": KIT_REVISION, "engine_version": "0.3.17", "expected_kit_sha256": KIT_SHA,
              "started_utc": datetime.now(timezone.utc).isoformat(),
              "status": "blocked", "cursor_scenario": "not_run"}
    try:
        probe(run, report, args.cursor_exe)
    except (RunBlocked, OSError, subprocess.SubprocessError, zipfile.BadZipFile) as exc:
        report["reason"] = str(exc)
    finally:
        report["finished_utc"] = datetime.now(timezone.utc).isoformat()
        target = run / "report.json"
        target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"{report['status']} / {report.get('stage')}: {target}")
    return 0 if report["status"] == "platform_passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
