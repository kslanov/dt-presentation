"""Bounded text-only Cursor transport for the scheduled Sleep executor."""

from __future__ import annotations

import json
import os
import re
import subprocess
from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory

from core.config import dt_db_path
from core.instance import secrets_path
from core.sleep.validate import contains_secret
from core.sleep_synth.store import SynthError

MODEL = "composer-2.5"
MAX_CHARS = 80_000
_GRANT = re.compile(r"[0-9a-f]{64}")


def account() -> str:
    path = secrets_path() / "sleep-cursor-account.json"
    if path.is_symlink() or not path.is_file() or path.stat().st_mode & 0o077:
        return ""
    with path.open("rb") as stream:
        data = stream.read(8193)
    return sha256(data).hexdigest() if 0 < len(data) <= 8192 else ""


def validate_grant(grant: dict) -> None:
    if (not isinstance(grant, dict) or grant.keys() != {"account", "billing"}
            or grant["billing"] != "included_only"
            or not isinstance(grant["account"], str) or not _GRANT.fullmatch(grant["account"])):
        raise SynthError("sleep_cursor_consent", "Нужно разрешение для аккаунта Cursor без доплат")


def request(ctx, cfg, system: str, user: str) -> dict:
    from core.sleep_synth.schedule import load

    actual, _ = load(ctx.vault)
    if actual != cfg or cfg.paused:
        raise SynthError("sleep_schedule_paused", "Настройка Сна изменилась")
    if not cfg.cursor or cfg.cursor["account"] != account():
        raise SynthError("sleep_cursor_consent", "Авторизация Cursor изменилась")
    if contains_secret(user):
        raise SynthError("sleep_cloud_private", "В досье найден возможный секрет")
    packet = json.dumps({"system": system, "user": user}, ensure_ascii=False).encode()
    if len(user) > MAX_CHARS or len(packet) > 150_000:
        raise SynthError("sleep_provider_budget", "Досье больше лимита профиля Cursor")
    install = Path(ctx.db_path or dt_db_path()).resolve().parent / "cursor-sleep"
    argv = [str(install / "node"), str(install / "sleep-cursor.mjs"),
            str(secrets_path() / "sleep-cursor-account.json")]
    env = {key: os.environ[key] for key in ("HOME", "PATH", "TMPDIR", "LANG") if key in os.environ}
    try:
        with TemporaryDirectory(prefix="dt-cursor-sleep-") as workspace:
            # The command is fixed. The request and documents enter on stdin only.
            result = subprocess.run(  # noqa: S603
                [*argv, workspace], input=packet, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, timeout=120, cwd=install, env=env,
            )
        if result.returncode or len(result.stdout) > 150_000:
            raise SynthError("sleep_provider_error", "Cursor не вернул результат")
        output = json.loads(result.stdout)
        if not isinstance(output, dict):
            raise ValueError
        return output
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise SynthError("sleep_provider_error", "Cursor недоступен") from exc
    except ValueError as exc:
        raise SynthError("sleep_provider_format", "Cursor не вернул объект JSON") from exc


def format_finding(output: dict, template: dict, scope: str) -> dict:
    """Translate the small model-facing shape into the DT-owned draft format."""
    from dataclasses import replace

    from core.sleep.contract import ClaimType, Evidence, EvidenceRole, Snapshot, proposal_from_dict

    reason = output.get("reason")
    finding = output.get("finding")
    if not isinstance(reason, str) or not reason.strip() or len(reason) > 4000:
        raise SynthError("sleep_provider_format", "Cursor не указал причину результата")
    if finding is None and "finding" in output:
        return {"candidates": [], "reason": reason}
    fields = {"type", "subject", "predicate", "object", "statement", "why_now", "use", "evidence"}
    if not isinstance(finding, dict) or finding.keys() != fields:
        raise SynthError("sleep_provider_format", "Cursor не заполнил карточку по форме")
    strings = fields - {"evidence"}
    if any(not isinstance(finding[k], str) or not finding[k].strip() or len(finding[k]) > 1200
           for k in strings):
        raise SynthError("sleep_provider_format", "Поля карточки Cursor не заполнены")
    raw_evidence = finding["evidence"]
    if (finding["type"] not in ("source_assertion", "hypothesis")
            or not isinstance(raw_evidence, list) or not 1 <= len(raw_evidence) <= 4
            or any(not isinstance(e, dict) or e.keys() != {"source_id", "locator"}
                   or any(not isinstance(v, str) or not v for v in e.values())
                   for e in raw_evidence)):
        raise SynthError("sleep_provider_format", "Cursor не указал тип или локаторы оснований")
    evidence = tuple(Evidence(e["source_id"], EvidenceRole.SUPPORT, locator=e["locator"])
                     for e in raw_evidence)
    proposal = proposal_from_dict(template)
    claim = replace(
        proposal.after.claims[0], type=ClaimType(finding["type"]), area=scope.removeprefix("hub:"),
        subject=finding["subject"], predicate=finding["predicate"], object=finding["object"],
        statement=finding["statement"], evidence=evidence,
    )
    candidate = replace(proposal, after=Snapshot(claims=(claim,)),
                        why_now=finding["why_now"], intended_use=finding["use"])
    return {"candidates": [candidate.to_dict()], "reason": reason}
