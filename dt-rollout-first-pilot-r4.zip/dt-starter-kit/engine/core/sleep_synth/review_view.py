"""Read-only view of a rejected draft and the material used to review it."""

from __future__ import annotations

import re

from core.sleep.contract import Evidence, EvidenceRole, proposal_from_dict
from core.sleep.validate import contains_secret
from core.sleep_input.store import InputStore
from core.sleep_store.evidence_view import preview
from core.sleep_synth.store import SynthError
from core.sleep_synth.verify import validate_pins

_LOCATOR = re.compile(r"\bsrc-[0-9a-f]+@[0-9]+#(?:m[0-9]+|c[0-9]+-[0-9]+)\b")


def _public_text(value: str) -> str:
    return value if not contains_secret(value) else ""


def rejected_review(ctx, store, batch: dict) -> dict:
    try:
        dossiers = validate_pins(ctx, batch["pins"])
    except SynthError:
        return {"unavailable": True}
    inputs = InputStore(store.conn)
    verified = {
        segment["locator"]: (d, segment)
        for d in dossiers
        for segment in d["segments"]
        if not segment["suspect_instruction"] and d["source"]["kind"] != "experience"
    }
    draft = []
    refs = {}
    for raw in batch["drafts"]:
        proposal = proposal_from_dict(raw)
        for claim in proposal.after.claims:
            draft.append(_public_text(claim.statement))
            refs.update((e.locator, None) for e in claim.evidence)
        for link in proposal.after.links:
            draft.append(_public_text(f"{link.source} → {link.target} ({link.type.value})"))
            refs.update((e.locator, None) for e in link.evidence)

    summary = _public_text(batch.get("review_reason") or "")
    comments = [
        {"decision": r["decision"], "text": _public_text(r["reason"])}
        for r in (*batch.get("reviews", []), *batch.get("link_reviews", []))
    ]
    for text in [summary, *(r["text"] for r in comments)]:
        refs.update((locator, None) for locator in _LOCATOR.findall(text))

    sources = []
    for locator in list(refs)[:12]:
        if locator not in verified:
            continue
        d, segment = verified[locator]
        source = d["source"]
        evidence = Evidence(
            source["source_id"], EvidenceRole.SUPPORT, revision=source["revision"],
            locator=locator, content_hash=d["versions"]["actual_hash"],
            fragment_fingerprint=segment["fingerprint"], source_path=source["locator"],
        )
        view = preview(ctx.vault, inputs, evidence)
        if view["preview_status"] != "ready":
            sources.append({"locator": locator, "status": view["preview_status"]})
            continue
        sources.append({
            "locator": locator, "title": _public_text(view["title"]),
            "date": _public_text(view["date"]), "sender": _public_text(view["sender"]),
            "path": str(ctx.vault / view["path"]), "excerpt": view["excerpt"][:1600],
            "truncated": view["excerpt_truncated"] or len(view["excerpt"]) > 1600,
        })
    return {
        "draft": [text for text in draft if text],
        "summary": summary,
        "comments": [r for r in comments if r["text"]],
        "sources": sources,
    }
