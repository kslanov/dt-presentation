"""Durable continuation after the technical installer, scoped to the installation target."""

from __future__ import annotations

import json
from pathlib import Path

from core.file_lock import file_lock
from core.install.base import InstallError
from core.mcp_json_edit import write_text_atomic

PHASES = (
    ("04-method", "Задачи и первые источники"),
    ("05-style", "Образцы стиля"),
    ("06-integrations", "Интеграции по выбору"),
    ("07-first-run", "Первый рабочий результат"),
)
OPTIONAL = {"05-style", "06-integrations"}
FINAL = PHASES[-1][0]


def _path(ctx):
    return ctx.derived / "install" / "onboarding.json"


def _read(ctx):
    path = _path(ctx)
    try:
        if path.is_symlink():
            raise ValueError
        data = json.loads(path.read_text(encoding="utf-8"))
        phases = data["phases"]
        if data["version"] != 1 or not isinstance(phases, dict):
            raise ValueError
        return phases if data["vault"] == str(ctx.vault) else {}
    except FileNotFoundError:
        return {}
    except (KeyError, OSError, TypeError, ValueError) as exc:
        raise InstallError(
            "onboarding_state", "Не удалось прочитать этапы настройки",
            "сохрани текущее состояние и проверь .derived/install/onboarding.json",
        ) from exc


def _result(ctx, value: str) -> str | None:
    if not isinstance(value, str) or not value:
        return None
    relative = Path(value)
    try:
        if relative.is_absolute():
            relative = relative.relative_to(ctx.vault)
        if (len(relative.parts) != 3 or relative.parts[0] != "07-outputs"
                or ".." in relative.parts):
            return None
        folder = ctx.vault / relative
        note = folder / "output.md"
        meta = folder / "meta.yaml"
        if any(p.resolve() != p or not p.is_file() for p in (note, meta)):
            return None
        from core.output import read_meta

        if note.stat().st_size > 0 and read_meta(meta).get("status") == "final":
            return relative.as_posix()
    except (OSError, RuntimeError, ValueError):
        pass
    return None


def status(ctx, *, missing: list[str]) -> dict:
    saved = _read(ctx)
    phases = []
    for phase, title in PHASES:
        entry = saved.get(phase) or {}
        checkpoint = entry.get("state") if isinstance(entry, dict) else None
        if checkpoint not in ("done", "deferred") or (checkpoint == "deferred"
                                                       and phase not in OPTIONAL):
            checkpoint = "pending"
        elif phase == FINAL and not _result(ctx, entry.get("result", "")):
            checkpoint = "pending"
        row = {"id": phase, "title": title, "state": checkpoint}
        if phase == FINAL and checkpoint == "done":
            row["result"] = entry["result"]
        phases.append(row)
    next_phase = next((p for p in phases if p["state"] == "pending"), None)
    return {
        "core": "incomplete" if missing else "ready",
        "pending_core_steps": missing,
        "onboarding": "waiting_for_core" if missing else "pending" if next_phase else "done",
        "next_phase": None if missing else next_phase,
        "phases": phases,
    }


def record(ctx, phase: str, *, missing: list[str], defer: bool, result: str) -> dict:
    path = _path(ctx)
    ctx.guard(path)
    with file_lock(path):
        progress = status(ctx, missing=missing)
        if missing:
            raise InstallError("onboarding_core", "Ядро пока не готово",
                               "сначала проверь dt install --check")
        current = next(p["state"] for p in progress["phases"] if p["id"] == phase)
        choice = "deferred" if defer else "done"
        if current == choice:
            return progress
        next_phase = progress["next_phase"]
        if (not next_phase or next_phase["id"] != phase) and not (
            phase in OPTIONAL and current == "deferred" and not defer
        ):
            raise InstallError("onboarding_order", "Этот этап пока нельзя отметить",
                               "продолжи с фазы из dt install --onboarding")
        if phase == FINAL:
            finalized = _result(ctx, result)
            if not finalized:
                raise InstallError("onboarding_result", "Нет сохраненного первого результата",
                                   "заверши выход через save_output и передай его папку в --result")
            result = finalized
        phases = _read(ctx)
        phases[phase] = {"state": choice, **({"result": result} if result else {})}
        payload = {"version": 1, "vault": str(ctx.vault), "phases": phases}
        path.parent.mkdir(parents=True, exist_ok=True)
        write_text_atomic(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
        return status(ctx, missing=missing)


def render(progress: dict) -> list[str]:
    if progress["core"] != "ready":
        return ["Ядро: не готово. Первый незавершенный шаг: " + progress["pending_core_steps"][0],
                "Настройка под владельца: ждет установки ядра."]
    phase = progress["next_phase"]
    if not phase:
        return ["Ядро: готово.", "Настройка под владельца: первый результат сохранен."]
    return ["Ядро: готово.", "Настройка под владельца: еще не завершена.",
            f"Следующая фаза: {phase['title']}. Открой installer/brain/{phase['id']}.md.",
            "В новом чате открой папку кита и попроси «продолжи установку». "
            "Проверка маршрута: dt install --onboarding."]
