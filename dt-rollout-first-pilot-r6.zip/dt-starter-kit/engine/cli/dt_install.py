"""dt install - фаза 1 инсталлера одной командой (DEV-3-KIT): шаги, состояние, возобновление.

Порядок: ``platform → deps → config → vault → owner → [models → launchd →] host → index → doctor``.
Каждый шаг - существующая команда движка + ``check()``; повтор продолжает с первого незавершенного.
Состояние - ``<корень>/.derived/install/state.json`` (чем кончился шаг, проценты скачивания, ответы
мастера; секретов нет). ``--check`` и ``--dry-run`` ничего не пишут. ``sudo`` нигде не нужен.

Usage:
    uv run python cli/dt.py install                    # продолжить с первого незавершенного
    uv run python cli/dt.py install --check            # таблица «шаг - сделано/нет - почему»
    uv run python cli/dt.py install --dry-run          # что было бы сделано
    uv run python cli/dt.py install --yes --name "Имя Фамилия" --email a@example.com
    uv run python cli/dt.py install --step models --models-from ~/Downloads/dt-models.tar
    uv run python cli/dt.py install --step host --host claude --relaunch
    uv run python cli/dt.py install --plan --preset consulting-sales --enable crm   # DT-OPTIONS-1
    uv run python cli/dt.py install --step config --capabilities    # диалог плана возможностей
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def add_target_args(parser: argparse.ArgumentParser) -> None:
    """Куда ставим (общие флаги ``dt install`` и ``dt uninstall``)."""
    parser.add_argument("--root", default=None, metavar="PATH",
                        help="корень рабочей папки (vault и .derived внутри); по умолчанию - "
                             "родитель engine/")
    parser.add_argument("--home", default=None, metavar="PATH",
                        help="домашний каталог (LaunchAgents, конфиги хостов); по умолчанию HOME")
    parser.add_argument("--engine-dir", default=None, metavar="PATH",
                        help="каталог движка (по умолчанию - где лежит этот код)")
    parser.add_argument("--env-file", default=None, metavar="PATH",
                        help=".env цели (по умолчанию <engine>/.env)")
    parser.add_argument("--vault", default=None, metavar="PATH", help="папка vault")
    parser.add_argument("--json", action="store_true", help="машиночитаемый вывод")


def _show_plan(ctx, *, as_json: bool) -> int:
    """``--plan``: план возможностей по флагам и ``state.json``; только чтение, код 0/1 (отказ)."""
    import json

    from core.install import capabilities
    from core.install.base import InstallError

    try:
        plan = capabilities.resolve(capabilities.choices_from_answers(ctx.answers),
                                    capabilities.facts_from_ctx(ctx))
    except InstallError as exc:
        ctx.say(f"отказ: {exc.reason}; {exc.hint}")
        return 1
    if as_json:
        ctx.say(json.dumps(plan.as_dict(), ensure_ascii=False, indent=2))
    else:
        for line in capabilities.render_plan(plan):
            ctx.say(line)
        ctx.say("это только показ: ничего не записано и не включено "
                "(применить: dt install --step config)")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt install", description=__doc__.split("\n")[0])
    add_target_args(parser)
    from core.install import onboarding

    parser.add_argument("--check", action="store_true",
                        help="только таблица «что сделано» (ничего не пишет; код 1, если не все)")
    parser.add_argument("--dry-run", action="store_true", help="показать план, ничего не менять")
    parser.add_argument("--yes", action="store_true",
                        help="без вопросов: значения из флагов/состояния/умолчаний")
    parser.add_argument("--step", default=None, metavar="ИМЯ", help="выполнить один шаг")
    parser.add_argument("--from", dest="start", default=None, metavar="ИМЯ",
                        help="начать с этого шага (готовые пропускаются)")
    parser.add_argument("--name", default=None, help="имя владельца")
    parser.add_argument("--email", action="append", default=[], metavar="АДРЕС",
                        help="ваш адрес (повторяемый)")
    parser.add_argument("--company", default=None, help="компания")
    parser.add_argument("--domain", action="append", default=[], metavar="ДОМЕН",
                        help="почтовый домен компании (повторяемый)")
    parser.add_argument("--internal-domain", action="append", default=[], metavar="ДОМЕН",
                        help="служебный домен группы (повторяемый)")
    parser.add_argument("--people", nargs="*", default=[], metavar="ФАМИЛИЯ",
                        help="чьи личные документы не индексировать (privacy.people)")
    parser.add_argument("--onboarding", action="store_true",
                        help="показать состояние ядра и следующую фазу настройки")
    parser.add_argument("--record-phase", choices=[phase for phase, _ in onboarding.PHASES],
                        help="отметить пройденную фазу после подтверждения владельца")
    parser.add_argument("--confirmed-vault", default="", metavar="PATH",
                        help="путь, подтвержденный владельцем на фазе 01")
    deployment_mode = parser.add_mutually_exclusive_group()
    deployment_mode.add_argument("--preview-deployment", action="store_true",
                                 help="показать план развертывания и код для подтверждения")
    deployment_mode.add_argument("--confirm-deployment", metavar="КОД",
                                 help="начать установку по показанному и согласованному плану")
    deployment_mode.add_argument("--core-only", action="store_true",
                                 help="явно выполнить только техническую установку")
    deployment_mode.add_argument("--deployment-report", action="store_true",
                                 help="сохранить локальный HTML с планом и прогрессом")
    parser.add_argument("--defer", action="store_true",
                        help="отложить образцы стиля или интеграции")
    parser.add_argument("--result", default="", metavar="ПАПКА",
                        help="папка первого сохраненного выхода относительно vault")
    hosts = ("claude", "cursor", "kimi", "cherry", "none")
    parser.add_argument("--host", default=None, choices=hosts,
                        help="какой ассистент подключаем (none - пропустить)")
    parser.add_argument("--connectors", default=None, metavar="none|auto|СПИСОК",
                        help="DT_CONNECTORS (по умолчанию none: база без CRM/почты)")
    caps = parser.add_argument_group(
        "возможности (DT-OPTIONS-1)",
        "ядро + независимые опции outlook, crm, capture и Сон; пресет рекомендует, явный выбор и "
        "предпосылки решают; без этих флагов установка прежняя (``--connectors``)")
    caps.add_argument("--plan", action="store_true",
                      help="показать план возможностей по флагам/состоянию, ничего не писать")
    caps.add_argument("--capabilities", action="store_true",
                      help="диалог плана: кто смотрит находки, внимание в неделю, опции, Сон")
    caps.add_argument("--preset", default=None, metavar="РОЛЬ",
                      help="встроенный пресет роли: РЕКОМЕНДУЕТ опции (ничего не включает)")
    caps.add_argument("--enable", action="append", default=[], metavar="ОПЦИЯ",
                      help="включить опцию: outlook | crm | capture | sleep (повторяемый)")
    caps.add_argument("--disable", action="append", default=[], metavar="ОПЦИЯ",
                      help="выключить опцию явно (сильнее пресета)")
    caps.add_argument("--reviewer", default=None, metavar="none|owner|delegate",
                      help="кто просматривает находки Сна")
    caps.add_argument("--attention", default=None, metavar="none|30|60|120+",
                      help="минут в неделю на разбор находок")
    caps.add_argument("--sleep", default=None, metavar="off|manual|scheduled",
                      help="режим Сна (по умолчанию off; scheduled - только за воротами)")
    caps.add_argument("--sleep-executor", default=None, metavar="ИМЯ",
                      help="ворота scheduled: исполнитель")
    caps.add_argument("--sleep-source", action="append", default=[], metavar="ИСТОЧНИК",
                      help="ворота scheduled: источник (повторяемый)")
    caps.add_argument("--sleep-budget", default=None, metavar="ЧИСЛО",
                      help="ворота scheduled: бюджет > 0")
    caps.add_argument("--sleep-manual-tested", default=None, metavar="МЕТКА",
                      help="ворота scheduled: метка проверенного ручного прогона")
    caps.add_argument("--confirm-sleep-schedule", action="store_true",
                      help="ворота scheduled: явное подтверждение расписания (--yes не заменяет)")
    parser.add_argument("--relaunch", action="store_true",
                        help="шаг host: Claude Desktop запущен - выйти, записать, запустить")
    parser.add_argument("--ops-full", action="store_true",
                        help="шаг launchd: полный состав (смоук и сторож прогонов - для владельца)")
    parser.add_argument("--models-from", default=None, metavar="ПАПКА|АРХИВ",
                        help="шаг models: офлайн-копия кэша моделей (dt-models.tar или папка)")
    parser.add_argument("--obsidian", action="store_true",
                        help="открыть vault DT в Obsidian, при необходимости установить его")
    args = parser.parse_args(argv)
    if args.confirmed_vault and args.record_phase != onboarding.VAULT:
        parser.error("--confirmed-vault передается с --record-phase 01-prereqs")
    if args.record_phase == onboarding.VAULT and not args.confirmed_vault:
        parser.error("нужен согласованный путь хранилища в --confirmed-vault")
    deployment_action = args.preview_deployment or args.confirm_deployment or args.core_only
    if (deployment_action or args.deployment_report) and any(
            (args.check, args.dry_run, args.plan, args.onboarding, args.record_phase)):
        parser.error("выбери одну команду установки, проверки или отчета")
    if args.confirm_deployment and not args.yes:
        parser.error("для установки по согласованному плану передай --yes и явные параметры")
    if args.core_only and (args.obsidian or args.connectors not in (None, "none") or any((
            args.capabilities, args.preset, args.enable, args.disable, args.reviewer,
            args.attention, args.sleep, args.confirm_sleep_schedule))):
        parser.error("--core-only: только ядро, без Obsidian и дополнительных опций")
    if args.capabilities and (args.preview_deployment or args.confirm_deployment):
        parser.error("для подтверждения используй явные опции и флаги, без --capabilities")
    if args.onboarding or args.record_phase:
        if any((args.check, args.dry_run, args.step, args.start, args.plan, args.obsidian,
                args.onboarding and args.record_phase)):
            parser.error("состояние настройки и запись фазы выполняются отдельной командой")
    if args.defer and args.record_phase not in ("05-style", "06-integrations"):
        parser.error("--defer доступен для образцов стиля и интеграций")
    if args.result and args.record_phase != "07-first-run":
        parser.error("--result передается с --record-phase 07-first-run")
    if args.record_phase == "07-first-run" and not args.result:
        parser.error("для первого результата нужна папка выхода в --result")
    chose_plan = bool(args.preset or args.enable or args.disable or args.reviewer or args.attention
                      or args.sleep or args.capabilities)
    if chose_plan and args.connectors:
        parser.error("--connectors и флаги плана возможностей (--enable/--preset/…) не "
                     "сочетаются: план сам задает DT_CONNECTORS")

    from dt_install_steps import STEPS

    from core.install.context import Answers, InstallContext
    from core.install.runner import check_rows, run_install

    answers = Answers(
        name=args.name or "", emails=list(args.email), company=args.company or "",
        domains=list(args.domain), internal_domains=list(args.internal_domain),
        people=list(args.people), host=args.host or "", connectors=args.connectors or "",
        vault=args.vault or "", preset=args.preset or "",
        enable=[t for v in args.enable for t in v.replace(";", ",").split(",") if t.strip()],
        disable=[t for v in args.disable for t in v.replace(";", ",").split(",") if t.strip()],
        reviewer=args.reviewer or "", attention=args.attention or "", sleep=args.sleep or "",
        sleep_executor=args.sleep_executor or "", sleep_sources=list(args.sleep_source),
        sleep_budget=args.sleep_budget or "", sleep_manual_tested=args.sleep_manual_tested or "",
        sleep_confirmed="yes" if args.confirm_sleep_schedule else "")
    ctx = InstallContext.build(
        engine_dir=Path(args.engine_dir) if args.engine_dir else None,
        root=Path(args.root) if args.root else None,
        home=Path(args.home) if args.home else None,
        env_path=Path(args.env_file) if args.env_file else None,
        vault=Path(args.vault) if args.vault else None, answers=answers,
        yes=args.yes, dry_run=args.dry_run, relaunch=args.relaunch, ops_full=args.ops_full,
        capability_dialogue=args.capabilities, plan_only=args.plan,
        models_from=Path(args.models_from).expanduser() if args.models_from else None)
    import json

    from core.install import deployment
    from core.install.base import InstallError

    try:
        if args.onboarding or args.record_phase:
            missing = [row.step.name for row in check_rows(ctx, STEPS) if not row.check.done]
            if args.record_phase:
                progress = onboarding.record(ctx, args.record_phase, missing=missing,
                                             defer=args.defer, result=args.result,
                                             vault_confirmation=args.confirmed_vault)
            else:
                progress = onboarding.status(ctx, missing=missing)
            if args.json:
                ctx.say(json.dumps(progress, ensure_ascii=False, indent=2))
            else:
                for line in onboarding.render(progress):
                    ctx.say(line)
            return 0
        if args.plan:
            return _show_plan(ctx, as_json=args.json)
        if args.preview_deployment or args.confirm_deployment or args.deployment_report:
            proposed = deployment.plan(ctx, answers, obsidian=args.obsidian, options={
                "yes": args.yes, "step": args.step, "from": args.start, "relaunch": args.relaunch,
                "ops_full": args.ops_full, "models_from": args.models_from,
            })
            if args.preview_deployment:
                if args.json:
                    ctx.say(json.dumps(proposed, ensure_ascii=False, indent=2))
                else:
                    for line in deployment.plan_lines(proposed):
                        ctx.say(line)
                    ctx.say("После подтверждения повтори те же параметры с "
                            f"--confirm-deployment {proposed['code']}.")
                return 0
            if args.deployment_report:
                rows = check_rows(ctx, STEPS)
                progress = onboarding.status(ctx, missing=[
                    row.step.name for row in rows if not row.check.done])
                ctx.say(deployment.report(ctx, progress, rows, proposed))
                return 0
            deployment.confirm(ctx, proposed, args.confirm_deployment)
        has_core_config = ctx.env_path.is_file() and (
            ctx.vault / "_system" / "profile" / "owner.yaml").is_file()
        if (deployment.required(ctx) and not has_core_config
                and not any((args.check, args.dry_run, args.core_only, args.confirm_deployment))):
            raise InstallError("deployment_confirmation", "План установки еще не подтвержден",
                               "начни с --preview-deployment или явно выбери --core-only")
    except InstallError as exc:
        if args.json:
            ctx.say(json.dumps({"ok": False, "code": exc.code, "reason": exc.reason},
                               ensure_ascii=False))
        else:
            ctx.say(f"отказ: {exc.reason}; {exc.hint}")
        return 1
    steps = STEPS
    if args.obsidian or "obsidian" in (args.step, args.start):
        from core.install.obsidian import STEP

        steps = [*STEPS, STEP]
    return run_install(ctx, steps, only=args.step, start=args.start, check_only=args.check,
                       as_json=args.json, show_onboarding=True)


if __name__ == "__main__":
    raise SystemExit(main())
