"""dt notes - операции над заметками vault (KIT-FIT-1 п.9, interface layer).

``dt notes backfill-aliases [--dry-run] [--limit N] [--vault ПУТЬ] [--json]`` - дописать
``aliases: [<id>]`` во frontmatter файловых заметок ``_legacy/`` (id вида ``legacy-<hash>``), чтобы
ссылки ``[[legacy-…]]``, которые пишут линковка, MOC и хабы, находились в Obsidian (файл называется
``<slug>-<hash8>.md``). Правка только frontmatter, атомарная, с аудитом; повтор идемпотентен;
``--dry-run`` ничего не пишет, ``--limit`` - сколько заметок изменить за прогон. Логика -
:mod:`core.notes_backfill`. Новые заметки получают алиас при рендере и без этой команды.

Usage:
    uv run python cli/dt.py notes backfill-aliases --dry-run
    uv run python cli/dt.py notes backfill-aliases --limit 200
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt notes", description="Операции над заметками vault.")
    sub = parser.add_subparsers(dest="cmd", required=True)
    bf = sub.add_parser("backfill-aliases",
                        help="Дописать aliases: [<id>] файловым заметкам _legacy/ (Obsidian).")
    bf.add_argument("--dry-run", action="store_true",
                    help="Показать, сколько заметок изменится, ничего не записывая.")
    bf.add_argument("--limit", type=int, default=None, metavar="N",
                    help="Изменить не больше N заметок за прогон (повтор продолжит).")
    bf.add_argument("--vault", type=Path, default=None)
    bf.add_argument("--json", action="store_true", help="Отчет JSON.")
    args = parser.parse_args(argv)
    if args.limit is not None and args.limit < 1:
        print("отказ: --limit - целое число не меньше 1", file=sys.stderr)
        return 2
    load_env()

    from core.config import default_vault_path
    from core.notes_backfill import backfill_aliases, format_report

    vault = args.vault or default_vault_path()
    report = backfill_aliases(vault, dry_run=args.dry_run, limit=args.limit)
    if args.json:
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=1))
    else:
        print(format_report(report))
    return 1 if report.raced else 0


if __name__ == "__main__":
    raise SystemExit(main())
