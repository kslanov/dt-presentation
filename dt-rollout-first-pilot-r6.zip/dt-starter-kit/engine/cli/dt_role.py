"""dt role - профиль роли в vault (ROLE-DATA-1): ``show [--effective] | check | init --preset``.

Профиль - один файл ``vault/_system/role.yaml``: правки поверх пресета (``consulting-sales``,
``personal``, ``product-analytics`` или пресет из ``vault/_system/role-presets/``). Он задает
словарь подписей, состав поверхности пульта, правила сканера хабов, сценарии генерации и состав
скиллов; ключи сущностей и папки vault не меняются. Правит человек (Obsidian); движок файл только
читает, разовая запись - ``init``.

* ``show`` - что движок видит: файл, пресет (запрошенный и действующий), версия профиля, замечания;
  ``--effective`` - плюс действующий профиль целиком (пресет с правками) YAML-ом;
* ``check`` - те же замечания с кодом, серьезностью и путем; код выхода 1 при ошибках (ошибка блока
  отбрасывает блок, действует пресет); предупреждения не валят. Самодостаточна: тесты в кит не идут;
* ``init --preset ИМЯ [--force]`` - создать ``role.yaml`` с пресетом и закомментированными
  примерами правок; существующий файл без ``--force`` не трогается (с ``--force`` - бэкап).
* ``model show|validate|form|context|compare`` - опциональный общий реестр предметной модели
  ROLE-DATA-2A; проверка и предпросмотр, без изменения схемы или объектов.

Usage:
    uv run python cli/dt.py role show --effective
    uv run python cli/dt.py role check
    uv run python cli/dt.py role init --preset product-analytics
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env


def _vault(args: argparse.Namespace) -> Path | None:
    return Path(args.vault).expanduser() if args.vault else None


def _role_name(args: argparse.Namespace) -> str | None:
    return getattr(args, "instance_role", None)


def _show(args: argparse.Namespace) -> int:
    import yaml

    from core.role import get_role
    from core.role.load import ROLE_FILE, builtin_presets
    from core.role.schema import role_to_dict

    got = get_role(_vault(args), _role_name(args))
    print(f"# {got.path}")
    print(f"файл:        {'есть' if got.present else 'нет (действует пресет роли экземпляра)'}")
    print(f"пресет:      {got.role.preset}"
          + (f" (в {ROLE_FILE}: {got.requested})" if got.requested
             and got.requested != got.role.preset else ""))
    print(f"версия:      {got.version or '-'}")
    print(f"правки:      {'есть' if got.customized else 'нет (профиль равен пресету)'}")
    print(f"заголовок:   {got.role.label or '-'}")
    print(f"встроенные пресеты: {', '.join(builtin_presets())}")
    print(f"замечаний:   ошибок {len(got.errors)}, предупреждений {len(got.warnings)}")
    for issue in got.issues:
        print(f"  {issue}")
    if args.effective:
        print("\n# действующий профиль (пресет + правки)")
        print(yaml.safe_dump(role_to_dict(got.role), allow_unicode=True, sort_keys=False,
                             width=100).rstrip())
    return 0


def _check(args: argparse.Namespace) -> int:
    from core.role import get_role

    got = get_role(_vault(args), _role_name(args))
    status = "error" if got.errors else ("warn" if got.warnings else "ok")
    where = f"профиль {got.version}" if got.present else "role.yaml нет"
    print(f"Роль: {status} - пресет {got.role.preset}, {where}, ошибок {len(got.errors)}, "
          f"предупреждений {len(got.warnings)}")
    for issue in got.issues:
        print(f"  {issue}")
    if got.errors:
        print("  что делать: ошибка блока отбросила блок (действует пресет); поправь файл "
              "(правка видна без рестарта) и повтори `dt role check`")
    from core.domain.load import load_model

    model = load_model(_vault(args))
    if model.present:
        print(f"Предметная модель: {'ok' if model.registry.ok else 'error'} · {model.version}")
        for issue in model.registry.issues:
            print(f"  [{issue.severity}] {issue.code} {issue.path}: {issue.message}")
    from core.activity.read import read_current
    from core.activity.store import ActivityStore
    from core.config import default_vault_path

    activity_ok = True
    try:
        current = read_current(_vault(args))
        if current["present"]:
            print(f"Деятельность: {current['version'][:12]}")
        ActivityStore(_vault(args) or default_vault_path()).settings()
    except (ValueError, OSError, RuntimeError):
        activity_ok = False
        print("Деятельность или настройки развития не читаются: _system/activity/")
    return 1 if got.errors or not model.registry.ok or not activity_ok else 0


def _model(args: argparse.Namespace) -> int:
    import json

    from core.domain.api import domain_model
    from core.domain.schema import MAX_BYTES
    from core.privacy import any_nda

    try:
        if args.input:
            path = Path(args.input).expanduser()
            if any_nda(path, path.resolve()):
                raise ValueError("input path refused")
            with path.open("rb") as stream:
                raw = stream.read(MAX_BYTES + 1)
            if len(raw) > MAX_BYTES:
                raise ValueError("input too large")
            payload = json.loads(raw)
        else:
            payload = {}
        if getattr(args, "activity", False):
            from core.activity.api import activity

            result = activity(args.operation, payload, vault_path=_vault(args))
        elif getattr(args, "objects", False):
            from core.domain.records import domain_objects

            result = domain_objects(args.operation, payload, vault_path=_vault(args))
        else:
            result = domain_model(args.operation, payload, vault_path=_vault(args))
    except (OSError, ValueError, RecursionError):
        result = {"ok": False, "code": "model_input", "error": "Входной JSON не прочитан"}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("ok") else 1


def _init(args: argparse.Namespace) -> int:
    from core.role.init import init_role

    try:
        res = init_role(_vault(args), args.preset, force=args.force)
    except ValueError as exc:
        print(f"отказ: {exc}", file=sys.stderr)
        return 2
    if res.skipped:
        print(f"{res.path}: уже есть (без --force не трогаю)")
        return 0
    if res.backup:
        print(f"бэкап прежнего: {res.backup}")
    print(f"создан {res.path} (пресет {res.preset})")
    print("дальше: при необходимости править в Obsidian; `dt role check`; "
          "`dt role show --effective`")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt role", description=__doc__.split("\n")[0])
    parser.add_argument("--vault", default=None, help="другой vault (по умолчанию DT_VAULT_PATH)")
    parser.add_argument("--instance-role", choices=("work", "personal"), default=None,
                        help="роль экземпляра, чей пресет по умолчанию взять "
                             "(по умолчанию DT_INSTANCE_ROLE)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sh = sub.add_parser("show", help="что движок видит в профиле роли")
    sh.add_argument("--effective", action="store_true",
                    help="плюс действующий профиль целиком (пресет с правками)")
    sh.set_defaults(func=_show)

    ck = sub.add_parser("check", help="замечания профиля (код 1 при ошибках)")
    ck.set_defaults(func=_check)

    it = sub.add_parser("init", help="создать role.yaml с пресетом")
    it.add_argument("--preset", required=True, metavar="ИМЯ",
                    help="consulting-sales | personal | product-analytics | имя из role-presets/")
    it.add_argument("--force", action="store_true", help="перезаписать существующий (с бэкапом)")
    it.set_defaults(func=_init)

    model = sub.add_parser("model", help="предметная модель: чтение, проверки и diff (без записи)")
    model.add_argument("operation", choices=("show", "validate", "form", "context", "compare"))
    model.add_argument("--input", help="JSON с аргументами операции; без него - пустой объект")
    model.set_defaults(func=_model)
    objects = sub.add_parser("objects", help="предметные объекты: поиск и предложения в очередь")
    objects.add_argument("operation", choices=("search", "get", "history", "context", "propose"))
    objects.add_argument("--input", help="JSON с аргументами операции")
    objects.set_defaults(func=_model, objects=True)

    activity = sub.add_parser("activity", help="интервью, версии деятельности и предложения")
    activity.add_argument("operation", choices=("state", "interview", "propose", "history",
                                               "rollback", "settings"))
    activity.add_argument("--input", help="JSON с аргументами операции")
    activity.set_defaults(func=_model, activity=True)

    args = parser.parse_args(argv)
    load_env()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
