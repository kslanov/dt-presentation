"""dt sleep - Сон: ledger, кандидаты, реестр входов, план, досье, опыт (SLEEP-STORE-1, -INPUT-1).

Тонкая обертка над :mod:`core.sleep_store.ops` и :mod:`core.sleep_input.ops` (те же функции зовет
MCP-фасад ``sleep``: одинаковые проверки и effects, сценарий 20). Решений здесь нет: принять/
отклонить/отложить может только владелец карточкой вида ``memory`` в общей очереди (``pult_cards``
/ ``pult_card_decide``). Модель не вызывается.

Usage:
    uv run python cli/dt.py sleep status [--run RUN]             # счетчики, очередь, внимание
    uv run python cli/dt.py sleep plan [--scope S] [--apply]     # план; без --apply не пишет
    uv run python cli/dt.py sleep context RUN ITEM [--cursor C]  # досье порции позиции прогона
    uv run python cli/dt.py sleep experience add FILE            # принять явный пакет опыта сессии
    uv run python cli/dt.py sleep inputs [--stale|--blocked]     # реестр входов
    uv run python cli/dt.py sleep propose FILE --dry-run         # проверить, ничего не писать
    uv run python cli/dt.py sleep propose FILE                   # записать кандидатов в ledger
    uv run python cli/dt.py sleep apply-recover [--proposal ID]  # довести прерванное применение

``FILE`` - JSON ``{run_id, idempotency_key, candidates: [предложения §5.3]}`` либо список
кандидатов (тогда ``--run-id`` и ``--key``). Код выхода 1 - есть отказы/конфликты/недоступно.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.sleep_input import ops as input_ops
from core.sleep_store import ops


def render_status(res: dict[str, Any]) -> str:
    if not res.get("ok"):
        return f"СОН: ledger недоступен - {res.get('error')}"
    if not res.get("present"):
        return "СОН: ledger не заводили (кандидатов нет)"
    s, q, a = res["summary"], res["queue"], res["attention"]
    lines = [
        f"СОН: кандидатов {s['candidates']} (ждут решения {q['pending']}), принятых утверждений "
        f"{s['accepted_claims']}, решений {s['decisions']}, последнее применение "
        f"{s['last_applied'] or 'нет'}",
        f"  очередь «Память»: бюджет {q['budget']} в неделю, в запасе {q['in_reserve']}",
    ]
    for key, label in (("conflict", "конфликт применения"),
                       ("unfinished", "применение не доведено")):
        if a[key]:
            lines.append(f"  {label}: {', '.join(a[key])}  -> dt sleep apply-recover")
    if a["index_pending"]:
        lines.append(f"  индексация ждет: {a['index_pending']} (reindex или apply-recover)")
    if a["needs_check"]:
        lines.append(f"  принятых утверждений на проверку (источник исчез): {a['needs_check']}")
    inp = res.get("inputs") or {}
    if inp.get("registry", {}).get("inputs"):
        reg, wl = inp["registry"], inp["worklist"]
        lines.append(f"  входы: {reg['inputs']} (доступно {reg['available']}, недоступно "
                     f"{reg['unavailable']}, заблокировано {reg['blocked']}); хвост worklist "
                     f"{wl['open']}; прогоны {inp['runs']}")
    if res.get("run"):
        r = res["run"]
        lines.append(f"  прогон {r['run_id']}: {r['state']}, предложения: {r['proposals']}, "
                     f"worklist: {r.get('worklist') or {}}")
    return "\n".join(lines)


def render_propose(res: dict[str, Any]) -> str:
    if "results" not in res:
        return f"propose: отказ - {res.get('error')}"
    mode = "DRY-RUN (ничего не записано)" if res.get("dry_run") else (
        "повтор того же запроса" if res.get("replayed") else "записано")
    lines = [f"propose {res['run_id']} / {res['idempotency_key']}: {mode}; итого {res['summary']}"]
    for r in res["results"]:
        head = f"  [{r['index']}] {r.get('proposal_id') or '-'}: {r['status']}"
        if r["status"] == "refused":
            lines.append(head + " - " + ", ".join(v["code"] for v in r["violations"]))
            lines += [f"        {v['path']}: {v.get('reason', '')}" for v in r["violations"][:5]]
        else:
            tail = f", ключ проблемы {r['issue_key']}" if r.get("issue_key") else ""
            lines.append(head + tail)
    if res.get("blockers") and res["ok"]:
        lines.append("  блокеры: " + ", ".join(b["code"] for b in res["blockers"]))
    return "\n".join(lines)


def _refusal(name: str, res: dict[str, Any]) -> str:
    return f"{name}: отказ - {res.get('error')}"


def render_plan(res: dict[str, Any]) -> str:
    if not res.get("ok"):
        return _refusal("plan", res)
    est, sk = res["estimate"], res["skipped"]
    if res.get("applied") and res.get("run_id"):
        state = f"прогон {res['run_id']}" + (" (повтор того же плана)" if res.get("replayed")
                                              else " записан")
    else:
        state = "DRY-RUN (ничего не записано)"
    unstored = (f" (+{est['tail_unstored']} не хранится, вычисляется заново)"
                if est["tail_unstored"] else "")
    lines = [
        f"plan {res['mode']} / {res['scope']}: {state}",
        f"  в манифесте {est['items']} (порций ~{est['portions']}, {est['bytes']} байт), в хвосте "
        f"{est['tail_items']}{unstored}; взято из хвоста прежних прогонов: "
        f"{res['carried']['items']}"]
    for it in res["manifest"][:20]:
        where = str(it.get("locator") or "").replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
        lines.append(f"  {it['seq']:>2}. {it['item_id']} [{it['kind']}] «{where[:60]}» "
                     f"{it['priority']}: {', '.join(it['reasons'])} - {it['intended_use']}; "
                     f"{it['difference']}")
    skipped = {k: v for k, v in sk["refused"].items()}
    lines.append(f"  пропущено: отказано {skipped or 0}, заблокировано {sk['blocked_count']}, "
                 f"недоступно {sk['unavailable_count']}, копий {sk['copies']}, уже обработано "
                 f"{sk['handled']}, обрезка по хабу {sk['per_hub_limit']}")
    lines.append(f"  сигналы: сделки {res['signals'].get('deals')}, встречи "
                 f"{res['signals'].get('meetings')}; обход: {res['scan']}")
    for w in res.get("warning", []):
        lines.append(f"  ! {w['code']}: {w['reason']}")
    if res.get("note"):
        lines.append("  " + res["note"])
    return "\n".join(lines)


def render_context(res: dict[str, Any]) -> str:
    if not res.get("ok"):
        return _refusal("context", res)
    cov, src = res["coverage"], res["source"]
    lines = [f"context {res['run_id']} / {res['item_id']}: {src['kind']} {src['locator']} "
             f"ревизия {src['revision']}",
             f"  покрытие: {cov['state']} ({cov.get('scope') or cov.get('note', '')})"]
    if res.get("blockers"):
        lines.append("  блокеры: " + ", ".join(b["code"] for b in res["blockers"]))
    for seg in res.get("segments", [])[:50]:
        lines.append(f"  [{seg['locator']}] " + " ".join(seg["text"].split())[:200])
    nxt = (res.get("portion") or {}).get("next_cursor")
    if nxt:
        lines.append(f"  дальше: --cursor {nxt}")
    for w in res.get("warning", []):
        lines.append(f"  ! {w['code']}: {w['reason']}")
    return "\n".join(lines)


def render_experience(res: dict[str, Any]) -> str:
    if not res.get("ok"):
        return _refusal("experience", res)
    lines = [f"experience {res['locator']}: {res['action']} (ревизия {res['revision']}), покрытие "
             f"{res['coverage']}" + (" [DRY-RUN]" if res.get("dry_run") else "")
             + f"; утверждения {res['statements']}; понижено до заявления агента "
             f"{res['downgraded']}; секретов отсечено {res['redacted']}"]
    for w in res.get("warning", []):
        lines.append(f"  ! {w['code']}: {w['reason']}")
    return "\n".join(lines)


def render_inputs(res: dict[str, Any]) -> str:
    if not res.get("ok"):
        return _refusal("inputs", res)
    if not res.get("present"):
        return "inputs: " + res["hint"]
    c = res["counts"]
    lines = [f"inputs ({res['filter']}): показано {len(res['rows'])} из {res['total']}; всего "
             f"{c['inputs']} (доступно {c['available']}, недоступно {c['unavailable']}, "
             f"заблокировано {c['blocked']}, копий {c['copies']}, опыт {c['experience']})"]
    for r in res["rows"]:
        tail = f" - {r['unavailable_reason']}" if r["unavailable_reason"] else ""
        lines.append(f"  {r['source_id']}@{r['revision']} [{r['kind']}] {r['availability']}/"
                     f"{r['privacy']} {r['locator']}{tail}")
    return "\n".join(lines)


def render_recover(res: dict[str, Any]) -> str:
    if "items" not in res:
        return f"apply-recover: отказ - {res.get('error')}"
    if not res["items"]:
        return "apply-recover: доводить нечего"
    lines = [f"apply-recover: {res['summary']}"]
    for it in res["items"]:
        lines.append(f"  {it['proposal_id']}: {it['result']}"
                     + (f" - {it['detail']}" if it.get("detail") else ""))
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt sleep", description="Сон: ledger и кандидаты.")
    parser.add_argument("--vault", type=Path, default=None)
    parser.add_argument("--json", action="store_true", help="Ответ JSON (как у MCP-фасада).")
    sub = parser.add_subparsers(dest="cmd", required=True)
    st = sub.add_parser("status", help="Сводка ledger.")
    st.add_argument("--run", default=None)
    pr = sub.add_parser("propose", help="Записать кандидатов через валидатор.")
    pr.add_argument("file", type=Path)
    pr.add_argument("--dry-run", action="store_true", help="Проверить, ничего не записывая.")
    pr.add_argument("--run-id", default=None)
    pr.add_argument("--key", default=None, help="idempotency_key батча.")
    ar = sub.add_parser("apply-recover", help="Довести прерванное применение.")
    ar.add_argument("--proposal", default=None)
    pl = sub.add_parser("plan", help="План прогона (без --apply ничего не пишет).")
    pl.add_argument("--scope", default=None, help="all | hub:<id хаба> | kind:<тип входа>.")
    pl.add_argument("--mode", default="incremental", help="incremental | recheck.")
    pl.add_argument("--items", type=int, default=None, help="Бюджет: позиций в манифесте.")
    pl.add_argument("--per-hub", type=int, default=None, help="Бюджет: позиций на хаб.")
    pl.add_argument("--seconds", type=int, default=None, help="Бюджет: время обхода, с.")
    pl.add_argument("--tail", type=int, default=None, help="Сколько позиций хвоста хранить.")
    pl.add_argument("--apply", action="store_true", help="Записать реестр, прогон и worklist.")
    cx = sub.add_parser("context", help="Досье порции позиции прогона.")
    cx.add_argument("run")
    cx.add_argument("item")
    cx.add_argument("--cursor", default=None)
    cx.add_argument("--no-record", action="store_true", help="Не писать квитанцию чтения.")
    ex = sub.add_parser("experience", help="Явный опыт сессий.")
    exs = ex.add_subparsers(dest="exp_cmd", required=True)
    ea = exs.add_parser("add", help="Принять пакет опыта из JSON-файла.")
    ea.add_argument("file", type=Path)
    ea.add_argument("--dry-run", action="store_true", help="Проверить, ничего не записывая.")
    ip = sub.add_parser("inputs", help="Реестр входов.")
    ip.add_argument("--stale", action="store_true", help="Недоступные и с изменившимся источником.")
    ip.add_argument("--blocked", action="store_true", help="Заблокированные приватностью.")
    ip.add_argument("--limit", type=int, default=50)
    sy = sub.add_parser("synth", help="Ручной сквозной синтез сохраненного плана.")
    sy.add_argument(
        "action",
        choices=(
            "start",
            "read",
            "submit",
            "review",
            "publish",
            "cancel",
            "resume",
            "report",
            "gate",
        ),
    )
    sy.add_argument("run", nargs="?", default="")
    sy.add_argument("--input", type=Path, help="JSON package фазы; session не передается в argv")
    sy.add_argument("--item")
    sy.add_argument("--cursor")
    sc = sub.add_parser("schedule", help="Персональный режим Сна и ограниченный запуск по окну.")
    sc.add_argument("action", choices=("status", "configure", "tick"))
    sc.add_argument("--input", type=Path, help="JSON настроек, только для configure")
    sc.add_argument("--expected-version", default=None, help="Версия из schedule status")
    args = parser.parse_args(argv)
    load_env()
    ctx = ops.make_ctx(vault=args.vault)

    if args.cmd == "schedule":
        from core.sleep_eval.gate import synthesis_readiness
        from core.sleep_synth import loop

        try:
            if args.action == "configure":
                from core.privacy import any_nda

                if args.input is None or args.input.is_symlink() or any_nda(
                    args.input, args.input.resolve()
                ):
                    raise ValueError("refused input")
                with args.input.open("rb") as stream:
                    raw = stream.read(8193)
                if len(raw) > 8192:
                    raise ValueError("input budget")
                res = loop.configure(ctx, json.loads(raw), args.expected_version,
                                     readiness=synthesis_readiness)
            else:
                res = (loop.tick(ctx, readiness=synthesis_readiness) if args.action == "tick"
                       else loop.status(ctx, readiness=synthesis_readiness))
        except (ValueError, OSError):
            res = {"ok": False, "code": "bad_file", "error": "JSON расписания не прочитан"}
        text = json.dumps(res, ensure_ascii=False, indent=2)
    elif args.cmd == "synth":
        from core.domain.schema import MAX_BYTES
        from core.privacy import any_nda
        from core.sleep_synth.ops import dispatch

        try:
            payload = {}
            if args.input:
                if args.input.is_symlink() or any_nda(args.input, args.input.resolve()):
                    raise ValueError("refused input")
                with args.input.open("rb") as stream:
                    raw = stream.read(MAX_BYTES + 1)
                if len(raw) > MAX_BYTES:
                    raise ValueError("input budget")
                payload = json.loads(raw)
            if args.action not in ("report", "cancel", "gate"):
                from core.sleep_eval.gate import synthesis_readiness

                ctx.extra["synthesis_gate"] = synthesis_readiness(ctx.vault)
            if args.action == "gate":
                from core.sleep_eval.gate import synthesis_readiness

                res = synthesis_readiness(ctx.vault)
            else:
                res = dispatch(
                    ctx, args.action, args.run, payload, item=args.item, cursor=args.cursor
                )
        except (ValueError, OSError):
            res = {"ok": False, "code": "bad_file", "error": "JSON фазы не прочитан"}
        text = json.dumps(res, ensure_ascii=False, indent=2)
    elif args.cmd == "status":
        res = ops.status(ctx, args.run)
        text = render_status(res)
    elif args.cmd == "plan":
        budgets = {
            k: v
            for k, v in (
                ("items", args.items),
                ("per_hub", args.per_hub),
                ("seconds", args.seconds),
                ("tail", args.tail),
            )
            if v is not None
        }
        res = input_ops.plan(
            ctx, scope=args.scope, mode=args.mode, budgets=budgets or None, apply=args.apply
        )
        text = render_plan(res)
    elif args.cmd == "context":
        res = input_ops.context(ctx, args.run, args.item, args.cursor, record=not args.no_record)
        text = render_context(res)
    elif args.cmd == "experience":
        res = input_ops.experience_from_file(ctx, args.file, dry_run=args.dry_run)
        text = render_experience(res)
    elif args.cmd == "inputs":
        res = input_ops.inputs(ctx, stale=args.stale, blocked=args.blocked, limit=args.limit)
        text = render_inputs(res)
    elif args.cmd == "propose":
        try:
            payload = json.loads(args.file.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            print(f"propose: файл не прочитан ({type(exc).__name__}): {args.file}")
            return 2
        res = ops.propose(
            ctx, payload, dry_run=args.dry_run, run_id=args.run_id, idempotency_key=args.key
        )
        text = render_propose(res)
    else:
        res = ops.apply_recover(ctx, args.proposal)
        text = render_recover(res)
    print(json.dumps(res, ensure_ascii=False, indent=1) if args.json else text)
    return 0 if res.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
