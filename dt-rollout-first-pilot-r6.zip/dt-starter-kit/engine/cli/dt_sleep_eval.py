"""dt sleep-eval - контрольный набор сна и методика оценки A/B/C/D (SLEEP-EVAL-1, sleep-1.md §11).

Подкоманды:

* ``check``  - прочитать и проверить ``vault/_system/eval/sleep-control.yaml`` (данные К.; движок
  файл только читает), показать покрытие пилота (30 размеченных, из них 10 многоисточниковых и 10
  рискованных), коды отказа;
* ``freeze`` - заморозить разрешенный корпус и исходную выдачу варианта A (``.derived/sleep/eval/
  <метка>/``);
* ``run``    - прогнать вариант A|B|C|D (B/C/D пока честно «недоступно: слой не реализован»);
* ``report`` - отчет по воротам §11 по сохраненным прогонам;
* ``review`` - решение человека по смысловому условию прогона;
* ``draft``  - кандидаты случаев для разметки К. (``candidates.json``), в набор не пишутся.

Модель не вызывается: ``run`` получает ответчика параметром (``--answerer модуль:функция``) либо
готовые ответы (``--answers файл.json``). Новый LLM-as-judge не вводится.

Usage:
    uv run python cli/dt.py sleep-eval check [--control PATH] [--json] [--strict]
"""

from __future__ import annotations

import argparse
import contextlib
import importlib.util
import json
import os
import sys
import tempfile
from collections.abc import Iterator
from pathlib import Path
from typing import Any
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

EXIT_OK, EXIT_FAIL, EXIT_USAGE, EXIT_UNAVAILABLE = 0, 1, 2, 3
_ENGINE_DIR = Path(__file__).resolve().parents[1]


def _load_tools() -> Any:
    """Боевые инструменты чтения - тот же ``mcp-server/server.py``, что видит агент."""
    spec = importlib.util.spec_from_file_location(
        "dt_sleep_eval_server", _ENGINE_DIR / "mcp-server" / "server.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load mcp-server/server.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@contextlib.contextmanager
def _read_tools(override: Any = None) -> Iterator[Any]:
    """Инструменты чтения в песочнице: побочные записи (БД фактов, аудит, метрики, журнал
    запросов) уходят в tmp - как у ``dt_eval``; ``.derived/sleep/eval`` песочница не трогает."""
    if override is not None:
        yield override
        return
    with tempfile.TemporaryDirectory(prefix="dt-sleep-eval-") as box, mock.patch.dict(
        os.environ, {
            "DT_DB_PATH": str(Path(box) / "dt.db"), "DT_LOGS_PATH": str(Path(box) / "logs"),
            "DT_EVENTS_PATH": str(Path(box) / "events.jsonl"), "DT_EVAL_QUERY_LOG": "0"},
    ):
        yield _load_tools()


def _vault(args: argparse.Namespace) -> Path:
    if getattr(args, "vault", None):
        return Path(args.vault)
    from core.config import default_vault_path

    return default_vault_path()


def _root(args: argparse.Namespace) -> Path:
    if getattr(args, "root", None):
        return Path(args.root)
    from core.config import sleep_eval_dir

    return sleep_eval_dir()


def _load_or_report(args: argparse.Namespace) -> Any:
    """Набор или ``None`` с напечатанным отказом (код выхода вызывающий ставит сам)."""
    from core.sleep_eval.control import SleepControlError, load_control

    path = _control_file(args)
    try:
        return load_control(path)
    except SleepControlError as exc:
        print(f"sleep-control: ОТКАЗ [{exc.code}] {path}", file=sys.stderr)
        for p in exc.problems:
            print(f"  - {p}", file=sys.stderr)
        return None


def _control_file(args: argparse.Namespace) -> Path:
    from core.sleep_eval.control import control_path

    if getattr(args, "control", None):
        return Path(args.control)
    return control_path(Path(args.vault) if getattr(args, "vault", None) else None)


def _cmd_check(args: argparse.Namespace) -> int:
    from core.sleep_eval.control import SleepControlError, coverage, load_control

    path = _control_file(args)
    try:
        control = load_control(path)
    except SleepControlError as exc:
        if args.json:
            print(json.dumps({
                "ok": False, "code": exc.code, "message": str(exc),
                "problems": [{"code": p.code, "where": p.where, "message": p.message}
                             for p in exc.problems]}, ensure_ascii=False, indent=1))
        else:
            print(f"sleep-control: ОТКАЗ [{exc.code}] {path}")
            for p in exc.problems:
                print(f"  - {p}")
            if not exc.problems:
                print(f"  {exc}")
        return EXIT_FAIL
    cov = coverage(control)
    if args.json:
        print(json.dumps({
            "ok": True, "label": control.label, "schema_version": control.schema_version,
            "file_sha256": control.file_sha256, "coverage": cov.to_dict(),
            "warnings": [{"code": w.code, "where": w.where, "message": w.message}
                         for w in control.warnings],
            "cases": [{"id": c.id, "part": c.part, "flags": sorted(c.flags),
                       "sources": list(c.sources), "critical": len(c.critical)}
                      for c in control.cases]}, ensure_ascii=False, indent=1))
    else:
        print(_render_check(control, cov, path))
    return EXIT_FAIL if (args.strict and not cov.ready) else EXIT_OK


def _render_check(control: Any, cov: Any, path: Path) -> str:
    lines = [
        f"sleep-control: схема {control.schema_version}, метка {control.label or '-'}, "
        f"случаев {cov.total} ({path})",
        f"  части: разработка {cov.development}, контроль {cov.control}",
        f"  по нескольким источникам {cov.multi}/10, рискованных {cov.risky}/10, "
        f"по одному документу {cov.single_doc}, всего {cov.total}/30",
    ]
    lines.append("  пилот: " + ("готов к заморозке" if cov.ready
                                else "НЕ готов - " + "; ".join(cov.shortfall)))
    for w in control.warnings[:10]:
        lines.append(f"  предупреждение: {w}")
    if len(control.warnings) > 10:
        lines.append(f"  … и еще {len(control.warnings) - 10} предупреждений")
    return "\n".join(lines)


def _cmd_freeze(args: argparse.Namespace) -> int:
    from core.sleep_eval.freeze import FreezeError, FreezeParams, freeze_corpus
    from core.version import engine_version

    control = _load_or_report(args)
    if control is None:
        return EXIT_FAIL
    params = FreezeParams(
        find_limit=args.find_limit, read_top=args.read_top, read_chars=args.read_chars,
        corpus=args.corpus, retrieve_use_case=args.retrieve_use_case)
    root = _root(args)  # до песочницы: корень заморозок - боевой .derived
    try:
        with _read_tools(args._tools) as tools:
            res = freeze_corpus(
                control, _vault(args), tools, label=args.label, root=root, params=params,
                force=args.force, engine_version=engine_version(),
                allow_missing=args.allow_missing)
    except FreezeError as exc:
        print(f"freeze: ОТКАЗ [{exc.code}] {exc}", file=sys.stderr)
        return EXIT_FAIL
    if args.json:
        print(json.dumps({
            "status": res.status, "directory": str(res.directory),
            "manifest_hash": res.manifest_hash, "baseline_hash": res.baseline_hash,
            "files": res.files, "excluded": res.excluded, "questions": res.questions,
            "missing_expected": [list(m) for m in res.missing_expected],
            "superseded": str(res.superseded) if res.superseded else None},
            ensure_ascii=False, indent=1))
        return EXIT_OK
    word = {"created": "заморожено", "unchanged": "без изменений (повтор на том же корпусе)",
            "replaced": "заморожено заново (прежнее отложено)"}[res.status]
    print(f"freeze: {word}: {res.directory}")
    print(f"  корпус: файлов {res.files}, исключено {res.excluded}; вопросов {res.questions}")
    print(f"  манифест {res.manifest_hash[:12]}, выдача A {res.baseline_hash[:12]}")
    if res.superseded:
        print(f"  прежняя заморозка: {res.superseded}")
    for cid, path in res.missing_expected:
        print(f"  ВНИМАНИЕ: ожидаемый источник вне корпуса: {cid}: {path}")
    return EXIT_OK


def _add_freeze(sub: Any, common: Any) -> None:
    p = sub.add_parser("freeze", help="Заморозить корпус и исходную выдачу варианта A.")
    common(p)
    p.add_argument("--label", help="Метка заморозки (по умолчанию - метка набора).")
    p.add_argument("--root", help="Корень заморозок (по умолчанию .derived/sleep/eval).")
    p.add_argument("--find-limit", type=int, default=8, help="Хитов find_notes на вопрос.")
    p.add_argument("--read-top", type=int, default=5, help="Сколько верхних хитов читать.")
    p.add_argument("--read-chars", type=int, default=2000, help="Знаков текста на хит.")
    p.add_argument("--corpus", help="Слой find_notes/retrieve (vault|current|legacy|raw|both).")
    p.add_argument("--retrieve-use-case", help="Добавить retrieve по этому сценарию.")
    p.add_argument("--force", action="store_true",
                   help="Заменить отличающуюся заморозку (прежняя уйдет в .superseded-N).")
    p.add_argument("--allow-missing", action="store_true",
                   help="Заморозить, даже если ожидаемые источники вне корпуса.")
    p.set_defaults(func=_cmd_freeze)


def _frozen_for(args: argparse.Namespace, control: Any) -> Any:
    from core.sleep_eval.freeze import load_frozen, safe_label

    name = safe_label(args.label or control.label or "")
    return load_frozen(_root(args) / name)


def _fmt_summary(s: dict[str, Any]) -> list[str]:
    def f(v: Any, unit: str = "") -> str:
        return "неизвестно" if v is None else f"{v:g}{unit}"

    cost = ("неизвестна" if s["cost_total"] is None
            else f"{s['cost_total']:g} {s['currency']}".strip())
    return [
        f"  случаев {s['cases']}, повторов {s['repeats']}"
        f"{' (предварительно: вариативность не оценена)' if s['preliminary'] else ''}, "
        f"ошибок ответчика {s['errors']}",
        f"  критических случаев {s['critical_cases']}: провалено {s['critical_fail']}, ждут "
        f"решения человека {s['critical_pending']}; потеряно условий {s['lost_conditions']}",
        f"  полный успех {s['quality_pass']}/{s['cases']}; источники {f(s['source_recall'])}, "
        f"локаторы {f(s['locator_recall'])}; нестабильных {s['flaky_cases']}",
        f"  токены всего {f(s['tokens_total'])}, медиана {f(s['tokens_median'])}; время "
        f"{f(s['seconds_total'], ' с')}; стоимость {cost}",
    ]


def _answerer(args: argparse.Namespace) -> tuple[Any, str]:
    from core.sleep_eval.runner import RecordedAnswerer, import_answerer

    if args.answers:
        rec = RecordedAnswerer(Path(args.answers))
        return rec, args.model or rec.model
    if args.answerer:
        return import_answerer(args.answerer), args.model
    return None, args.model


def _cmd_run(args: argparse.Namespace) -> int:
    from core.sleep_eval.freeze import FreezeError
    from core.sleep_eval.runner import Budget, RunError, run_variant, summarize

    control = _load_or_report(args)
    if control is None:
        return EXIT_FAIL
    try:
        frozen = _frozen_for(args, control)
        answerer, model = _answerer(args)
        run = run_variant(
            args.variant, control, frozen, answerer, repeats=args.repeats, part=args.part,
            final=args.final, vault=None if args.allow_drift else _vault(args),
            allow_drift=args.allow_drift, model=model,
            budget=Budget(args.max_context_chars, args.max_answer_tokens))
    except (FreezeError, RunError) as exc:
        print(f"run: ОТКАЗ [{exc.code}] {exc}", file=sys.stderr)
        return EXIT_FAIL
    except (OSError, ValueError) as exc:
        print(f"run: ОТКАЗ [answers_unreadable] {exc}", file=sys.stderr)
        return EXIT_FAIL
    if args.json:
        print(json.dumps({"run_id": run.run_id, "status": run.status, "reason": run.reason,
                          "directory": str(run.directory),
                          "summary": {k: v for k, v in summarize(run).items() if k != "per_case"}},
                         ensure_ascii=False, indent=1))
    else:
        print(f"run {run.run_id}: вариант {run.variant}, часть {run.part}, статус {run.status}")
        if run.status != "done":
            print(f"  {run.reason}")
        else:
            print("\n".join(_fmt_summary(summarize(run))))
            print(f"  решения по смысловым условиям: {run.directory}/human.json "
                  "(dt sleep-eval review)")
        for note in run.notes:
            print(f"  ВНИМАНИЕ: {note}")
    return EXIT_UNAVAILABLE if run.status != "done" else EXIT_OK


def _add_run(sub: Any, common: Any) -> None:
    p = sub.add_parser("run", help="Прогнать вариант A|B|C|D на замороженной выдаче.")
    common(p)
    p.add_argument("--variant", required=True, choices=("A", "B", "C", "D"))
    p.add_argument("--repeats", type=int, choices=(1, 3), default=1,
                   help="Повторов на случай: 1 (предварительно) или 3 (правило трех повторов).")
    p.add_argument("--part", choices=("development", "control", "all"), default="development",
                   help="Часть набора; control/all - только с --final.")
    p.add_argument("--final", action="store_true",
                   help="Осознанно открыть контрольную часть (каждое вскрытие учитывается).")
    p.add_argument("--label", help="Метка заморозки (по умолчанию - метка набора).")
    p.add_argument("--root", help="Корень заморозок (по умолчанию .derived/sleep/eval).")
    p.add_argument("--answerer", help="Ответчик модуль:функция (боевой хост подключается так).")
    p.add_argument("--answers", help="Готовые ответы JSON вместо вызова модели.")
    p.add_argument("--model", default="",
                   help="Имя модели (объявленное; одинаково у всех вариантов).")
    p.add_argument("--max-context-chars", type=int, default=12000)
    p.add_argument("--max-answer-tokens", type=int, default=1024)
    p.add_argument("--allow-drift", action="store_true",
                   help="Не сверять корпус с заморозкой (сравнение потеряет сопоставимость).")
    p.set_defaults(func=_cmd_run)


def _latest_runs(frozen: Any, part: str, wanted: list[str] | None) -> dict[str, Any]:
    from core.sleep_eval.runner import list_runs, load_run

    ids = wanted if wanted else list_runs(frozen)
    runs: dict[str, Any] = {}
    for run_id in sorted(ids):
        run = load_run(frozen, run_id)
        if wanted or run.part == part:
            runs[run.variant] = run  # поздний прогон варианта заменяет ранний
    return runs


def _cmd_report(args: argparse.Namespace) -> int:
    from core.sleep_eval.freeze import FreezeError
    from core.sleep_eval.report import build_report, format_report, report_json
    from core.sleep_eval.runner import RunError

    control = _load_or_report(args)
    if control is None:
        return EXIT_FAIL
    try:
        frozen = _frozen_for(args, control)
        runs = _latest_runs(frozen, args.part, args.runs.split(",") if args.runs else None)
    except (FreezeError, RunError) as exc:
        print(f"report: ОТКАЗ [{exc.code}] {exc}", file=sys.stderr)
        return EXIT_FAIL
    if not runs:
        print(f"report: нет прогонов части {args.part} в {frozen.directory}", file=sys.stderr)
        return EXIT_FAIL
    report = build_report(runs, questions_per_month=args.questions_per_month)
    text = format_report(report)
    if args.write:
        (frozen.directory / "report.md").write_text(text, encoding="utf-8")
        (frozen.directory / "report.json").write_text(
            json.dumps(report_json(report), ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(json.dumps(report_json(report), ensure_ascii=False, indent=1) if args.json else text)
    return EXIT_OK


def _add_report(sub: Any, common: Any) -> None:
    p = sub.add_parser("report", help="Отчет по воротам §11 по сохраненным прогонам.")
    common(p)
    p.add_argument("--label", help="Метка заморозки.")
    p.add_argument("--root", help="Корень заморозок.")
    p.add_argument("--part", choices=("development", "control", "all"), default="all",
                   help="Какие прогоны брать (последний по каждому варианту).")
    p.add_argument("--runs", help="Явный список прогонов через запятую (A-all-001,B-all-001).")
    p.add_argument("--questions-per-month", type=float, default=None,
                   help="Фактическая частота вопросов в месяц (для срока окупаемости).")
    p.add_argument("--write", action="store_true", help="Сохранить report.md/report.json.")
    p.set_defaults(func=_cmd_report)


def _cmd_review(args: argparse.Namespace) -> int:
    from core.sleep_eval.freeze import FreezeError
    from core.sleep_eval.runner import RunError, load_run, set_verdict

    control = _load_or_report(args)
    if control is None:
        return EXIT_FAIL
    try:
        run = load_run(_frozen_for(args, control), args.run)
        if args.verdict:
            if args.case is None or args.repeat is None or args.index is None:
                print("review: для решения нужны --case, --repeat, --index", file=sys.stderr)
                return EXIT_USAGE
            set_verdict(run, args.case, args.repeat, args.index, args.verdict, args.note or "")
            print(f"review: {args.case} повтор {args.repeat} условие {args.index} - {args.verdict}")
            return EXIT_OK
        data = json.loads((run.directory / "human.json").read_text(encoding="utf-8"))  # type: ignore[union-attr]
    except (FreezeError, RunError) as exc:
        print(f"review: ОТКАЗ [{exc.code}] {exc}", file=sys.stderr)
        return EXIT_FAIL
    items = data["items"]
    pending = [i for i in items if i["verdict"] is None]
    print(f"review {run.run_id}: смысловых условий {len(items)}, без решения {len(pending)}")
    for i in items:
        mark = i["verdict"] or "ждет"
        print(f"  [{mark}] {i['case_id']} повтор {i['repeat']} условие {i['index']} "
              f"({i['kind']}): {i['text']} - {i['hint']}")
    return EXIT_OK


def _add_review(sub: Any, common: Any) -> None:
    p = sub.add_parser("review", help="Решение человека по смысловому условию прогона.")
    common(p)
    p.add_argument("--run", required=True, help="Номер прогона (A-development-001).")
    p.add_argument("--label", help="Метка заморозки.")
    p.add_argument("--root", help="Корень заморозок.")
    p.add_argument("--verdict", choices=("ok", "lost"),
                   help="ok - условие сохранено; lost - потеряно.")
    p.add_argument("--case")
    p.add_argument("--repeat", type=int)
    p.add_argument("--index", type=int)
    p.add_argument("--note")
    p.set_defaults(func=_cmd_review)


def _cmd_draft(args: argparse.Namespace) -> int:
    from core.sleep_eval.control import SleepControlError, load_control
    from core.sleep_eval.draft import draft_candidates, write_candidates

    control = None
    note = ""
    try:
        control = load_control(_control_file(args))
    except SleepControlError as exc:
        note = f"набор не учтен при разметке пересечений ({exc.code})"
    provider = (lambda: ([], "противоречия фактов отключены")) if args.no_facts else None
    from core.sleep_eval.label import reviewed_ids

    root = Path(args.root) if args.root else None
    data = draft_candidates(_vault(args), control=control, budget_s=args.budget,
                            contradictions=provider, skip_ids=reviewed_ids(root))
    if note:
        data["warnings"].append(note)
    path = write_candidates(data, root)
    if args.json:
        print(json.dumps({"path": str(path), "counts": data["counts"], "partial": data["partial"],
                          "warnings": data["warnings"], "scanned": data["scanned"]},
                         ensure_ascii=False, indent=1))
        return EXIT_OK
    c, t = data["counts"], data["pilot_target"]
    print(f"draft: кандидатов {c['total']} (многоисточниковых "
          f"{c['multi_source']}/{t['multi_source']}, рискованных {c['risky']}/{t['risky']}, "
          f"по одному документу {c['single_doc']})"
          f"{' - ЧАСТИЧНО: бюджет времени вышел' if data['partial'] else ''}")
    ex = data["scanned"]["excluded"]
    print(f"  просмотрено документов {data['scanned']['documents']}, исключено: "
          f"{', '.join(f'{k} {v}' for k, v in sorted(ex.items())) or 'нет'}")
    for cand in data["candidates"][:8]:
        flags = "+".join(cand["flags"])
        print(f"  {cand['cand_id']} [{flags}] {cand['question_draft'][:90]} "
              f"(источников {len(cand['sources'])}, оценка {cand['score']})")
    for w in data["warnings"]:
        print(f"  предупреждение: {w}")
    print(f"  файл: {path} - материалы для подготовки кейсов; в набор не пишется")
    return EXIT_OK


def _add_draft(sub: Any, common: Any) -> None:
    p = sub.add_parser("draft", help="Кандидаты случаев для разметки К. (candidates.json).")
    common(p)
    p.add_argument("--root", help="Корень .derived/sleep/eval (по умолчанию боевой).")
    p.add_argument("--budget", type=float, default=120.0, help="Бюджет обхода, с.")
    p.add_argument("--no-facts", action="store_true",
                   help="Не читать стор фактов (без кандидатов-противоречий).")
    p.set_defaults(func=_cmd_draft)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="dt sleep-eval",
        description="Контрольный набор сна и методика оценки A/B/C/D (SLEEP-EVAL-1).")
    sub = parser.add_subparsers(dest="cmd", required=True)

    def common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--vault", help="Корень vault (по умолчанию боевой).")
        p.add_argument("--control", help="Путь к sleep-control.yaml (по умолчанию из vault).")
        p.add_argument("--json", action="store_true", help="Машинный итог вместо таблицы.")

    check = sub.add_parser("check", help="Проверить набор и покрытие пилота.")
    common(check)
    check.add_argument("--strict", action="store_true",
                       help="Код 1, если пилот не готов (меньше 30/10/10 и т.п.).")
    check.set_defaults(func=_cmd_check)
    _add_freeze(sub, common)
    _add_run(sub, common)
    _add_report(sub, common)
    _add_review(sub, common)
    _add_draft(sub, common)
    prep = sub.add_parser("prepare",
                          help="Пакет до пяти готовых кейсов с цитатами; без принятия и пилота.")
    common(prep)
    prep.add_argument("--root", help="Корень .derived/sleep/eval.")
    prep.add_argument("--file", required=True, help="JSON-пакет batch_id, model, cases.")
    prep.set_defaults(func=_cmd_prepare)
    refresh = sub.add_parser("refresh", help="Уточнить кейсы, сохранив решения владельца.")
    common(refresh)
    refresh.add_argument("--root")
    refresh.add_argument("--file", required=True)
    refresh.set_defaults(func=_cmd_prepare)
    return parser


def _cmd_prepare(args: argparse.Namespace) -> int:
    from core.sleep_eval.prepared import prepare
    if getattr(args, "cmd", "prepare") == "refresh":
        from core.sleep_eval.revision import refresh as prepare

    try:
        package = json.loads(Path(args.file).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        print("Пакет не прочитан: нужен JSON-файл")
        return 1
    result = prepare(package, vault=_vault(args), root=Path(args.root) if args.root else None,
                     host="cli")
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result.get("ok") else 1


def main(argv: list[str] | None = None, *, tools: Any = None) -> int:
    """``tools`` - подмена инструментов чтения (тесты); по умолчанию боевой server.py."""
    parser = build_parser()
    args = parser.parse_args(argv)
    args._tools = tools
    load_env()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
