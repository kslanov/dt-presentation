"""Activity facade: explicit drafts, owner queue, history and observation controls."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.activity.schema import ActivityError
from core.activity.store import ActivityStore
from core.config import default_vault_path
from core.domain.schema import bounded_json
from core.domain.store import DomainError
from core.note_writer import NoteWriteError

OPS = {
    "state": {"at", "version"},
    "interview": {"answers", "proposal_id"},
    "history": {"offset", "limit"},
    "propose": {
        "profile",
        "model",
        "expected_version",
        "legacy_version",
        "reason",
        "origin",
        "evidence",
        "replace",
    },
    "rollback": {"version", "expected_version"},
    "settings": {"values", "expected_version"},
}


def activity(
    op: str = "state", args: dict | None = None, *, vault_path: Path | None = None
) -> dict[str, Any]:
    from core.operational.pult import record_action

    writes = op in ("propose", "rollback") or (
        op == "settings" and isinstance(args, dict) and "values" in args
    )
    result: dict[str, Any] = {}
    try:
        if not isinstance(op, str) or op not in OPS:
            raise ActivityError("activity_op", "Неизвестная операция")
        args = {} if args is None else args
        if not isinstance(args, dict) or not bounded_json(args) or set(args) - OPS[op]:
            raise ActivityError("activity_args", "Некорректные аргументы")
        store = ActivityStore(vault_path or default_vault_path())
        if op == "state":
            result = store.state(args.get("at"), args.get("version"))
        elif op == "interview":
            result = {"ok": True, **store.draft(args.get("answers"), args.get("proposal_id"))}
        elif op == "history":
            result = store.history(args.get("offset", 0), args.get("limit", 10))
        elif op == "settings":
            result = {
                "ok": True,
                **(
                    store.save_settings(args["values"], args.get("expected_version"))
                    if "values" in args
                    else store.settings()
                ),
            }
        elif op == "rollback":
            result = store.compensation(args.get("version"), args.get("expected_version"))
        else:
            result = store.propose(
                args.get("profile"),
                args.get("model"),
                args.get("expected_version"),
                args.get("legacy_version"),
                args.get("reason"),
                args.get("origin", "owner"),
                args.get("evidence"),
                args.get("replace"),
            )
        return result
    except (ActivityError, DomainError, NoteWriteError) as exc:
        result = {"ok": False, "code": exc.code, "error": str(exc)}
        return result
    except (ValueError, TypeError, KeyError, OSError, OverflowError, RecursionError) as exc:
        result = {"ok": False, "code": "activity_unavailable", "error": type(exc).__name__}
        return result
    finally:
        if writes:
            record_action(
                "activity",
                {"op": str(op)},
                result.get("status", "saved") if result.get("ok") else "refused",
            )
