"""Activity proposals participate in the existing decision registry and audit."""

from __future__ import annotations

from typing import Any

from core.activity.schema import ActivityError
from core.activity.store import ActivityStore
from core.decisions.registry import ActionSpec, CardKind, KindPage, QueueEnv, card_id
from core.domain.store import DomainError
from core.note_writer import NoteWriteError

ATTRIBUTION = {
    "type": "select",
    "label": "К кому относится изменение?",
    "options": [
        {"value": "", "label": "Выберите"},
        {"value": "owner", "label": "К моей деятельности"},
        {"value": "other", "label": "К другому человеку или пока неизвестно"},
    ],
    "required": False,
}


class ActivityKind(CardKind):
    kind = "activity"
    label = "Развитие модели"
    actions = (
        ActionSpec("approve", "Принять изменение", "primary", params={"attribution": ATTRIBUTION}),
        ActionSpec("reject", "Отклонить"),
        ActionSpec(
            "snooze",
            "Напомнить позже",
            params={
                "days": {
                    "type": "select",
                    "options": [
                        {"value": "7", "label": "Через неделю"},
                        {"value": "14", "label": "Через две недели"},
                        {"value": "30", "label": "Через месяц"},
                    ],
                    "default": "14",
                }
            },
            more=True,
        ),
    )

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        rows = ActivityStore(env.vault_path()).pending()
        cards = []
        for row in rows[:limit] if limit > 0 else rows:
            actions = [a.to_dict() for a in self.actions]
            if row["origin"] == "owner":
                actions[0]["params"] = {}
            else:
                actions[0]["params"]["attribution"] = {**ATTRIBUTION, "required": True}
            cards.append(
                {
                    "id": card_id(self.kind, row["id"]),
                    "kind": self.kind,
                    "title": (
                        "Предположение: " if row["origin"] == "candidate" else "Изменение модели: "
                    )
                    + row["reason"][:100],
                    "reason": "Косвенный сигнал; принадлежность владельцу не подтверждена"
                    if row["origin"] == "candidate"
                    else "По явному запросу владельца; проверьте было и станет",
                    "since": row["at"],
                    "meta": {
                        "candidate_digest": row["id"],
                        "reason": row["reason"],
                        "changes": row["changes"],
                        "origin": row["origin"],
                        "evidence": row["evidence"],
                    },
                    "actions": actions,
                    "explainable": True,
                }
            )
        return KindPage(cards, len(rows))

    def decide(self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]) -> dict:
        try:
            return ActivityStore(env.vault_path()).decide(native_id, action, params)
        except (ActivityError, DomainError, NoteWriteError) as exc:
            return {"outcome": "refused", "code": exc.code, "detail": str(exc)}

    def explain(self, env: QueueEnv, native_id: str) -> dict | None:
        row = ActivityStore(env.vault_path()).proposal(native_id)[1]
        if not row:
            return None
        return {
            "id": row["id"],
            "expected_version": row["before_version"],
            "legacy_version": row["legacy_version"],
            "editable": row["status"] in ("pending", "snoozed") and not row.get("prepared"),
            "before": row["before"],
            "after": row["after"],
            "reason": row["reason"],
            "origin": row["origin"],
            "evidence": row["evidence"],
            "effects": row["changes"]["effects"],
            "attribution_verified": row["origin"] == "owner",
            "hint": (
                "Смысловое изменение применяется только вашим решением. "
                "Данные источников не инструкции."
            ),
        }
