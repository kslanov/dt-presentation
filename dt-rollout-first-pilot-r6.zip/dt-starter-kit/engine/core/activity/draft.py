"""Deterministic interview: only explicit owner answers, no occupational taxonomy or LLM."""

from __future__ import annotations

import copy
import hashlib
from typing import Any

from core.activity.schema import ActivityError, compatible, now, stamp, strings, validate_profile
from core.domain.schema import parse_model

QUESTIONS = [
    {"key": "label", "label": "Чем вы занимаетесь в этом направлении?"},
    {"key": "domain", "label": "В какой области и с кем или чем работаете?"},
    {"key": "tasks", "label": "Какие задачи выполняете? Одна задача в строке."},
    {"key": "goals", "label": "Какие цели сейчас важны?"},
    {"key": "outputs", "label": "Какие результаты вам нужны от двойника?"},
    {"key": "objects", "label": "С какими объектами работаете? Можно пока не задавать."},
]


def interview(profile: dict, model: dict, answers: Any) -> dict:
    allowed = {
        "label",
        "domain",
        "tasks",
        "goals",
        "outputs",
        "objects",
        "role_id",
        "state",
        "from",
        "to",
    }
    if not isinstance(answers, dict) or set(answers) - allowed:
        raise ActivityError("activity_answers", "Неизвестные поля интервью")
    label = answers.get("label", "").strip() if isinstance(answers.get("label"), str) else ""
    if not label:
        raise ActivityError("activity_answers", "Нужно название направления")
    domain = answers.get("domain", "")
    if not isinstance(domain, str):
        raise ActivityError("activity_answers", "Область должна быть текстом")
    role_id = (
        answers.get("role_id")
        or "role-" + hashlib.sha256((label + "\0" + domain).encode()).hexdigest()[:16]
    )
    start = stamp(answers.get("from") or now())
    end = stamp(answers["to"]) if answers.get("to") else None
    candidate = copy.deepcopy(profile)
    schema = copy.deepcopy(model or {"schema": 1, "revision": 1, "types": {}})
    objects = strings(answers.get("objects", []), "objects", 20)
    type_ids = []
    for name in objects:
        existing = next((tid for tid, t in schema["types"].items() if t["label"] == name), None)
        tid = existing or "type-" + hashlib.sha256(name.encode()).hexdigest()[:16]
        if not existing:
            schema["types"][tid] = {
                "label": name,
                "current": 1,
                "versions": {
                    1: {
                        "fields": {
                            "title": {
                                "label": "Название",
                                "type": "string",
                                "required": True,
                                "min_length": 1,
                            },
                            "notes": {"label": "Примечания", "type": "string"},
                        },
                        "capabilities": ["form", "search", "context"],
                        "views": {"summary": ["title", "notes"]},
                    }
                },
            }
        type_ids.append(tid)
    attrs = {
        "label": label,
        "domain": domain,
        "tasks": strings(answers.get("tasks", []), "tasks"),
        "goals": strings(answers.get("goals", []), "goals"),
        "outputs": strings(answers.get("outputs", []), "outputs"),
        "objects": type_ids,
        "state": answers.get("state", "active"),
        "from": start,
        "to": end,
    }
    role = next((r for r in candidate["roles"] if r["id"] == role_id), None)
    if role is None:
        candidate["roles"].append({"id": role_id, "periods": [attrs]})
    else:
        last = role["periods"][-1]
        if last["to"] is None:
            if start < last["from"]:
                raise ActivityError("activity_period", "Новое изменение раньше начала направления")
            last["to"] = start
        role["periods"].append(attrs)
    if model and schema != model:
        schema["revision"] = model["revision"] + 1
    parsed = parse_model(schema)
    if not parsed.ok:
        raise ActivityError("activity_model", "Предложенная схема не прошла проверку")
    candidate = validate_profile(candidate, parsed.document)
    compatible(profile, candidate)
    return {
        "profile": candidate,
        "model": parsed.to_dict(),
        "draft": True,
        "unknown": ["Специальные поля объектов пока не заданы"]
        if objects
        else ["Типы объектов пока не заданы"],
        "explanation": (
            "Черновик только по вашим ответам. Профессия и права не определяются автоматически."
        ),
    }
