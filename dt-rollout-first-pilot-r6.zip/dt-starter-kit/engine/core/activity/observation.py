"""Detect explicit changes of responsibility in pinned owner mail during scheduled Sleep."""

from __future__ import annotations

import hashlib
import re
from datetime import date, timedelta

from core.activity.draft import interview
from core.activity.schema import ActivityError
from core.activity.store import ActivityStore
from core.domain.store import DomainError, fold
from core.note_writer import NoteWriteError
from core.retrieval.mail_read import cut_quote_tail, parse_thread
from core.sleep.validate import contains_secret
from core.sleep_input.store import InputStore

_WHEN_RU = r"(?:теперь|отныне|с сегодняшнего дня|с этой недели|с этого месяца)"
_CHANGE = re.compile(
    rf"(?:{_WHEN_RU}\s+я|я\s+{_WHEN_RU})\s+"
    r"(?:отвечаю за|занимаюсь|веду|беру на себя)\s+(?P<task>[^.!?;:\r\n]{4,116})[.!]"
    r"|(?:from now on|starting today|starting this week|starting this month)[, ]+I\s+"
    r"(?:am responsible for|will lead|am taking over)\s+(?P<task_en>[^.!?;:\r\n]{4,116})[.!]",
    re.IGNORECASE,
)
_UNCERTAIN = re.compile(
    r"\b(?:если|возможно|вероятно|разово|временно|пока|наверное|не|предположим|"
    r"if|maybe|possibly|temporarily|not|once)\b",
    re.IGNORECASE,
)
_MAX_AGE = timedelta(days=30)


def _declaration(segment, today: date):
    if segment.get("suspect_instruction"):
        return None
    parsed = parse_thread(segment["text"])
    if parsed is None or len(parsed.messages) != 1 or not parsed.messages[0].is_me:
        return None
    msg = parsed.messages[0]
    try:
        day = date.fromisoformat(msg.date[:10])
    except ValueError:
        return None
    if not today - _MAX_AGE <= day <= today:
        return None
    body, _ = cut_quote_tail(msg.text, keep_quote_only=False)
    for line in body.splitlines():
        if line.lstrip().startswith(">"):
            break
        quote = line.strip()
        match = _CHANGE.fullmatch(quote)
        if match and not _UNCERTAIN.search(quote) and not contains_secret(quote):
            task = (match["task"] or match["task_en"]).strip()
            return task, quote, msg.date
    return None


def _latest(inputs, dossiers, today):
    best = None
    for doc in dossiers:
        if doc["source"]["kind"] != "mail_thread" or doc["source"].get("is_copy"):
            continue
        row = inputs.input_row(doc["source"]["source_id"])
        if not row or not row["note_rel"]:
            continue
        for segment in doc["segments"]:
            signal = _declaration(segment, today)
            if signal and (best is None or signal[2] > best[2]):
                best = (*signal, row["note_rel"])
    return best


def observe(ctx, inputs: InputStore, dossiers: list[dict]) -> dict | None:
    """At most one candidate per window. Shared store owns CAS, evidence and deduplication."""
    if not ctx.extra.get("schedule_scope") or not any(
        doc["source"]["kind"] == "mail_thread" for doc in dossiers
    ):
        return None
    store = ActivityStore(ctx.vault)
    try:
        settings = store.settings()["settings"]
        if not settings["observe"] or not settings["profile"]:
            return None
        signal = _latest(inputs, dossiers, date.fromisoformat(ctx.stamp()[:10]))
        if signal is None:
            return None
        task, quote, when, path = signal
        before = store.base()
        identity = " ".join(fold(task).split())
        role_id = "role-" + hashlib.sha256(identity.encode()).hexdigest()[:16]
        for role in before["profile"]["roles"]:
            period = role["periods"][-1]
            if role["id"] == role_id or any(
                " ".join(fold(label).split()) == identity
                for label in (period["label"], *period["tasks"])
            ):
                return None
        draft = interview(before["profile"], before["model"], {
            "role_id": role_id,
            "label": task[0].upper() + task[1:],
            "tasks": [task],
            "from": ctx.stamp(),
        })
        result = store.propose(
            draft["profile"], draft["model"], before["version"], before["legacy_version"],
            f"Сон нашел явное сообщение владельца о новой задаче от {when[:10]}. "
            "Проверьте, стоит ли добавить это направление.",
            origin="candidate", evidence=[{"path": path, "quote": quote}],
        )
        return {
            "state": "duplicate" if result.get("duplicate") else result["status"],
            "card_id": result.get("card_id"),
        }
    except (ActivityError, DomainError, NoteWriteError) as exc:
        return {"state": "refused", "code": exc.code}
    except (OSError, ValueError, TypeError, KeyError):
        return {"state": "refused", "code": "activity_unavailable"}
