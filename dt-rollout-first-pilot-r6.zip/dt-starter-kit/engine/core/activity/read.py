"""Single atomic activity/model bundle reader; legacy YAML is an import, not a second master."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from core.activity.schema import ActivityError, validate_bundle
from core.config import default_vault_path

CURRENT = "_system/activity/current.json"
HISTORY = "_system/activity/versions/"
PROPOSALS = "_system/activity/proposals/"
SETTINGS = "_system/activity/settings.json"
DEFAULT_SETTINGS = {"observe": False, "profile": True, "schema": True, "max_pending": 5}


def model_hash(model: dict) -> str:
    return hashlib.sha256(
        json.dumps(model, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()[:12]


def read_current(vault: Path | None = None) -> dict[str, Any]:
    # Local import: DomainStore's primitive file reader does not invoke load_model.
    from core.domain.store import DomainStore

    store = DomainStore(vault or default_vault_path())
    raw = store.raw(CURRENT)
    if raw is None:
        return {"present": False, "version": "", "bundle": None}
    try:
        bundle = validate_bundle(json.loads(raw))
    except (ValueError, TypeError, KeyError, RecursionError) as exc:
        raise ActivityError("activity_unavailable", "Снимок деятельности не читается") from exc
    return {"present": True, "version": hashlib.sha256(raw).hexdigest(), "bundle": bundle}
