"""Versioned activity is data, independent of identity, credentials and retrieval scope."""

from __future__ import annotations

import copy
from datetime import UTC, datetime
from typing import Any

from core.domain.schema import ID, bounded_json, parse_model

ATTRS = {"label", "domain", "tasks", "goals", "outputs", "objects", "state", "from", "to"}
STATES = {"active", "paused", "historical"}
EMPTY = {"schema": 1, "roles": []}


class ActivityError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def stamp(value: Any) -> str:
    if not isinstance(value, str):
        raise ActivityError("activity_date", "Нужен момент времени с часовым поясом")
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ActivityError("activity_date", "Некорректная дата") from exc
    if dt.tzinfo is None:
        raise ActivityError("activity_date", "Часовой пояс обязателен")
    return dt.astimezone(UTC).isoformat()


def now() -> str:
    return datetime.now(UTC).isoformat()


def strings(value: Any, name: str, maximum: int = 40) -> list[str]:
    if (
        not isinstance(value, list)
        or len(value) > maximum
        or any(not isinstance(v, str) or not v.strip() or len(v) > 1000 for v in value)
        or len(set(value)) != len(value)
    ):
        raise ActivityError("activity_schema", "Нужен список неповторяющихся строк: " + name)
    return value


def validate_profile(raw: Any, model: dict) -> dict:
    if not bounded_json(raw) or not isinstance(raw, dict) or set(raw) != {"schema", "roles"}:
        raise ActivityError("activity_schema", "Некорректная структура профиля деятельности")
    if type(raw["schema"]) is not int or raw["schema"] != 1 or not isinstance(raw["roles"], list):
        raise ActivityError("activity_schema", "Поддерживается профиль деятельности версии 1")
    if len(raw["roles"]) > 40:
        raise ActivityError("activity_budget", "До 40 направлений в одном профиле")
    profile = copy.deepcopy(raw)
    seen = set()
    for role in profile["roles"]:
        if (
            not isinstance(role, dict)
            or set(role) != {"id", "periods"}
            or not isinstance(role["id"], str)
            or not ID.fullmatch(role["id"])
            or role["id"] in seen
            or not isinstance(role["periods"], list)
            or not 1 <= len(role["periods"]) <= 200
        ):
            raise ActivityError("activity_schema", "Некорректное направление или повтор ID")
        seen.add(role["id"])
        previous = None
        for period in role["periods"]:
            if not isinstance(period, dict) or set(period) != ATTRS:
                raise ActivityError("activity_schema", "Неизвестные или пропущенные поля периода")
            if (
                not isinstance(period["label"], str)
                or not period["label"].strip()
                or len(period["label"]) > 300
                or not isinstance(period["domain"], str)
                or len(period["domain"]) > 3000
                or not isinstance(period["state"], str)
                or period["state"] not in STATES
            ):
                raise ActivityError(
                    "activity_schema", "Нужны название, область и состояние направления"
                )
            for key in ("tasks", "goals", "outputs", "objects"):
                strings(period[key], key)
            if any(t not in model.get("types", {}) for t in period["objects"]):
                raise ActivityError("activity_type", "Направление ссылается на необъявленный тип")
            period["from"] = stamp(period["from"])
            period["to"] = stamp(period["to"]) if period["to"] is not None else None
            if period["to"] is not None and period["to"] < period["from"]:
                raise ActivityError("activity_period", "Конец периода раньше начала")
            if previous is not None and (previous["to"] is None or previous["to"] > period["from"]):
                raise ActivityError("activity_period", "Периоды одного направления пересекаются")
            previous = period
    return profile


def compatible(before: dict, after: dict) -> None:
    roles = {r["id"]: r for r in after["roles"]}
    for old in before["roles"]:
        new = roles.get(old["id"])
        if new is None or len(new["periods"]) < len(old["periods"]):
            raise ActivityError("activity_history", "Нельзя удалить направление или его историю")
        for index, previous in enumerate(old["periods"]):
            current = new["periods"][index]
            if previous == current:
                continue
            closing = (
                index == len(old["periods"]) - 1
                and previous["to"] is None
                and current["to"] is not None
                and {k: v for k, v in current.items() if k != "to"}
                == {k: v for k, v in previous.items() if k != "to"}
            )
            if not closing:
                raise ActivityError("activity_history", "Прежний период нельзя переписать")


def effective(profile: dict, at: str | None = None) -> list[dict]:
    at = stamp(at or now())
    out = []
    for role in profile["roles"]:
        period = next(
            (p for p in role["periods"] if p["from"] <= at and (p["to"] is None or at < p["to"])),
            None,
        )
        if period:
            out.append({"id": role["id"], **copy.deepcopy(period)})
    return out


def validate_bundle(raw: Any) -> dict:
    keys = {
        "schema",
        "revision",
        "profile",
        "model",
        "baseline_legacy",
        "parent_version",
        "recorded_at",
        "proposal_id",
        "reason",
        "evidence",
    }
    if not bounded_json(raw) or not isinstance(raw, dict) or set(raw) != keys:
        raise ActivityError("activity_bundle", "Некорректный снимок модели деятельности")
    if (
        raw["schema"] != 1
        or type(raw["schema"]) is not int
        or type(raw["revision"]) is not int
        or raw["revision"] < 1
    ):
        raise ActivityError("activity_bundle", "Неизвестная версия снимка")
    model = parse_model(raw["model"])
    if not model.ok:
        raise ActivityError("activity_model", "Предметная схема не прошла проверку")
    profile = validate_profile(raw["profile"], model.document)
    for key in ("baseline_legacy", "parent_version", "proposal_id", "reason"):
        if not isinstance(raw[key], str):
            raise ActivityError("activity_bundle", "Некорректный реквизит снимка")
    for key, lengths in (
        ("baseline_legacy", (0, 12)),
        ("parent_version", (0, 64)),
        ("proposal_id", (64,)),
    ):
        if len(raw[key]) not in lengths or any(c not in "0123456789abcdef" for c in raw[key]):
            raise ActivityError("activity_bundle", "Некорректная ссылка версии")
    if not isinstance(raw["evidence"], list):
        raise ActivityError("activity_bundle", "Некорректные основания снимка")
    return {
        **raw,
        "model": model.to_dict(),
        "profile": profile,
        "recorded_at": stamp(raw["recorded_at"]),
    }
