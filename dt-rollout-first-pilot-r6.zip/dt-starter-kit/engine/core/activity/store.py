"""Atomic owner-reviewed profile/model publication, immutable versions and compensation."""

from __future__ import annotations

import copy
import hashlib
import json
from datetime import UTC, datetime, timedelta
from typing import Any

from core.activity.draft import QUESTIONS, interview
from core.activity.read import CURRENT, DEFAULT_SETTINGS, HISTORY, PROPOSALS, SETTINGS, read_current
from core.activity.schema import (
    EMPTY,
    ActivityError,
    compatible,
    effective,
    now,
    stamp,
    validate_bundle,
    validate_profile,
)
from core.domain.compare import compare_models
from core.domain.load import load_legacy_model
from core.domain.schema import Registry, parse_model
from core.domain.store import DomainStore, fold
from core.file_lock import file_lock
from core.note_writer import sha256_bytes
from core.sleep.validate import contains_secret


def encoded(value: dict) -> str:
    # Normalize integer version keys before sorting: JSON wire keys are always strings.
    value = json.loads(json.dumps(value, ensure_ascii=False))
    return json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2)


def digest(value: Any) -> str:
    return hashlib.sha256(encoded(value).encode()).hexdigest()


def latest(profile: dict) -> dict:
    return {r["id"]: r["periods"][-1] for r in profile["roles"]}


def changes(before: dict, after: dict) -> dict:
    old, new = latest(before["profile"]), latest(after["profile"])
    roles = [k for k, v in new.items() if old.get(k) != v]
    types = [
        k
        for k, v in after["model"].get("types", {}).items()
        if before["model"].get("types", {}).get(k) != v
    ]
    return {
        "roles": roles,
        "types": types,
        "effects": [
            "Поиск и права источников не сужаются и не расширяются",
            "Существующие заметки и объекты не преобразуются",
            "Текущие задачи получают контекст принятых активных направлений",
        ],
    }


class ActivityStore(DomainStore):
    def base(self) -> dict:
        current = read_current(self.vault)
        legacy = load_legacy_model(self.vault)
        if not legacy.registry.ok:
            raise ActivityError("activity_legacy", "Исходная предметная схема не читается")
        if current["present"]:
            bundle = current["bundle"]
            return {
                **current,
                "profile": bundle["profile"],
                "model": bundle["model"],
                "legacy_version": legacy.version,
                "external_conflict": legacy.version != bundle["baseline_legacy"],
            }
        return {
            **current,
            "profile": copy.deepcopy(EMPTY),
            "model": legacy.registry.to_dict() or {"schema": 1, "revision": 1, "types": {}},
            "legacy_version": legacy.version,
            "external_conflict": False,
        }

    def settings(self) -> dict:
        raw = self.raw(SETTINGS)
        value = json.loads(raw) if raw else dict(DEFAULT_SETTINGS)
        if (
            not isinstance(value, dict)
            or set(value) != set(DEFAULT_SETTINGS)
            or any(type(value[k]) is not bool for k in ("observe", "profile", "schema"))
            or type(value["max_pending"]) is not int
            or not 1 <= value["max_pending"] <= 30
        ):
            raise ActivityError("activity_settings", "Некорректные настройки развития")
        return {
            "settings": value,
            "version": sha256_bytes(raw) if raw else "",
            "autonomous_detection": True,
            "hint": "Сон предлагает проверить новые обязанности из исходящих писем",
        }

    def save_settings(self, value: dict, expected: str) -> dict:
        with file_lock(self.lock):
            current = self.settings()
            if current["version"] != expected:
                raise ActivityError("activity_stale", "Настройки изменились")
            if (
                not isinstance(value, dict)
                or set(value) != set(DEFAULT_SETTINGS)
                or any(type(value[k]) is not bool for k in ("observe", "profile", "schema"))
                or type(value["max_pending"]) is not int
                or not 1 <= value["max_pending"] <= 30
            ):
                raise ActivityError("activity_settings", "Некорректные настройки развития")
            self.put_json(SETTINGS, value)
            return self.settings()

    def state(self, at: str | None = None, version: str | None = None) -> dict:
        if at is not None:
            stamp(at)
        if version is not None and (
            not isinstance(version, str)
            or len(version) not in (0, 64)
            or any(c not in "0123456789abcdef" for c in version)
        ):
            raise ActivityError("activity_args", "Некорректная версия деятельности")
        current = self.base()
        selected = current
        if version and version != current["version"]:
            bundle = self.version(version)
            selected = {"profile": bundle["profile"], "model": bundle["model"], "version": version}
        pending = self.pending()
        return {
            "ok": True,
            "present": current["present"],
            "version": current["version"],
            "legacy_version": current["legacy_version"],
            "selected_version": selected["version"],
            "profile": selected["profile"],
            "model": selected["model"],
            "roles": effective(selected["profile"], at),
            "at": stamp(at or now()),
            "external_conflict": current["external_conflict"],
            "external_model": load_legacy_model(self.vault).registry.to_dict()
            if current["external_conflict"]
            else None,
            "questions": QUESTIONS,
            "pending": [
                {
                    "id": p["id"],
                    "card_id": "activity:" + p["id"],
                    "reason": p["reason"],
                    "origin": p["origin"],
                    "changes": p["changes"],
                    "after": p["after"],
                }
                for p in pending
            ],
            "settings": self.settings(),
            "autonomous_detection": True,
        }

    def draft(self, answers: dict, proposal_id: str | None = None) -> dict:
        before = self.base()
        profile, model = before["profile"], before["model"]
        extra = {}
        if proposal_id is not None:
            row = self.proposal(proposal_id)[1]
            if (
                not row
                or row["status"] not in ("pending", "snoozed")
                or row.get("prepared")
                or row["before_version"] != before["version"]
                or row["legacy_version"] != before["legacy_version"]
            ):
                raise ActivityError("activity_stale", "Предложение или принятая модель изменились")
            if not isinstance(answers, dict):
                raise ActivityError("activity_answers", "Нужны ответы интервью")
            profile = copy.deepcopy(row["after"]["profile"])
            model = parse_model(row["after"]["model"]).to_dict()
            rid = answers.get("role_id")
            if rid:
                # Discard the unaccepted period, then edit from the accepted baseline.
                profile["roles"] = [r for r in profile["roles"] if r["id"] != rid]
                original = next((r for r in before["profile"]["roles"] if r["id"] == rid), None)
                if original:
                    profile["roles"].append(copy.deepcopy(original))
            extra = {
                "replace": proposal_id,
                "origin": row["origin"],
                "evidence": [{"path": e["path"], "quote": e["quote"]} for e in row["evidence"]],
            }
        return {
            **interview(profile, model, answers),
            "before": {"profile": before["profile"], "model": before["model"]},
            "expected_version": before["version"],
            "legacy_version": before["legacy_version"],
            **extra,
        }

    def evidence(self, rows: Any, candidate: bool) -> list:
        if not isinstance(rows, list) or len(rows) > 10:
            raise ActivityError("activity_evidence", "До 10 оснований на предложение")
        if candidate and not rows:
            raise ActivityError("activity_attribution", "Косвенному сигналу нужны источники")
        result = []
        for row in rows:
            if (
                not isinstance(row, dict)
                or set(row) != {"path", "quote"}
                or not isinstance(row["quote"], str)
                or not 1 <= len(row["quote"]) <= 1200
            ):
                raise ActivityError(
                    "activity_evidence", "Нужны заметка и короткая цитата основания"
                )
            pin = self.source(row["path"])
            raw = self.raw(row["path"])
            normalized = " ".join(fold(row["quote"]).split())
            if normalized not in " ".join(fold(raw.decode()).split()):
                raise ActivityError("activity_evidence", "Цитата не найдена в источнике")
            result.append(
                {
                    **pin,
                    "quote": row["quote"],
                    "fragment_hash": hashlib.sha256(normalized.encode()).hexdigest(),
                }
            )
        return result

    def pending(self, *, include_snoozed: bool = False) -> list:
        folder = self.path(PROPOSALS)
        paths = list(folder.glob("*.json")) if folder.exists() else []
        if len(paths) > 5000:
            raise ActivityError("activity_budget", "Нужно обслуживание журнала предложений")
        result = []
        for path in sorted(paths):
            row = self.json(path.relative_to(self.vault).as_posix())
            if row and (
                row["status"] == "pending"
                or (row["status"] == "snoozed" and (include_snoozed or row["until"] <= now()))
            ):
                result.append(row)
        return result

    def proposal(self, pid: str) -> tuple[str, dict | None]:
        if (
            not isinstance(pid, str)
            or len(pid) != 64
            or any(c not in "abcdef0123456789" for c in pid)
        ):
            raise ActivityError("activity_id", "Неизвестный ID предложения")
        rel = PROPOSALS + pid + ".json"
        return rel, self.json(rel)

    def propose(
        self,
        profile: Any,
        model: Any,
        expected: str,
        legacy_version: str,
        reason: str,
        origin: str = "owner",
        evidence: list | None = None,
        replace: str | None = None,
    ) -> dict:
        with file_lock(self.lock):
            before = self.base()
            if before["version"] != expected or before["legacy_version"] != legacy_version:
                raise ActivityError("activity_stale", "Деятельность или внешняя схема изменились")
            if (
                origin not in ("owner", "candidate")
                or not isinstance(reason, str)
                or not reason.strip()
                or len(reason) > 3000
            ):
                raise ActivityError(
                    "activity_reason", "Нужно объяснение изменения и его происхождение"
                )
            parsed = parse_model(model)
            if not parsed.ok:
                raise ActivityError("activity_model", "Предметная схема не прошла проверку")
            model = parsed.to_dict()
            profile = validate_profile(profile, model)
            compatible(before["profile"], profile)
            if model != before["model"]:
                compared = compare_models(Registry(before["model"]), model)
                if not compared["ok"]:
                    raise ActivityError("activity_history", "Новая схема переписывает историю")
            after = {"profile": profile, "model": model}
            if (
                after == {"profile": before["profile"], "model": before["model"]}
                and not before["external_conflict"]
            ):
                return {"ok": True, "status": "unchanged"}
            if (
                len(encoded(after).encode()) > 60000
                or contains_secret(encoded(after))
                or contains_secret(reason)
            ):
                raise ActivityError(
                    "activity_budget", "Слишком большой черновик или возможный секрет"
                )
            impact = changes(before, after)
            settings = self.settings()["settings"]
            if origin == "candidate" and (
                not settings["observe"]
                or (impact["roles"] and not settings["profile"])
                or (impact["types"] and not settings["schema"])
            ):
                raise ActivityError("activity_paused", "Этот вид наблюдаемых предложений отключен")
            unresolved = self.pending(include_snoozed=True)
            pins = self.evidence(evidence or [], origin == "candidate")
            # Repeats ignore formatting, proposal time and unrelated accepted changes.
            meaning = {
                "roles": {
                    k: {a: b for a, b in latest(profile)[k].items() if a not in ("from", "to")}
                    for k in impact["roles"]
                },
                "types": {k: model["types"][k] for k in impact["types"]},
                "basis": sorted({(p["note_id"], p["fragment_hash"]) for p in pins}),
                "origin": origin,
            }
            if origin == "owner":
                meaning["explicit_request"] = {
                    "version": expected,
                    "profile": profile,
                    "model": model,
                }
            fingerprint = digest(meaning)
            previous = self.proposal(replace)[1] if replace else None
            if replace and (
                not previous
                or previous["status"] not in ("pending", "snoozed")
                or previous.get("prepared")
            ):
                raise ActivityError("activity_stale", "Редактируемое предложение уже решено")
            folder = self.path(PROPOSALS)
            for path in folder.glob("*.json") if folder.exists() else []:
                row = self.json(path.relative_to(self.vault).as_posix())
                if (
                    row
                    and row["id"] != replace
                    and row.get("fingerprint") == fingerprint
                    and row["status"] != "superseded"
                ):
                    return {
                        "ok": True,
                        "id": row["id"],
                        "card_id": "activity:" + row["id"],
                        "status": row["status"],
                        "duplicate": True,
                    }
            if len(unresolved) - bool(previous) >= settings["max_pending"]:
                raise ActivityError("activity_budget", "Достигнут бюджет ожидающих предложений")
            request = {
                "before_version": expected,
                "legacy_version": legacy_version,
                "after": after,
                "reason": reason,
                "origin": origin,
                "evidence": pins,
                "replace": replace,
                "before": {"profile": before["profile"], "model": before["model"]},
            }
            pid = digest(request)
            row = {
                **request,
                "id": pid,
                "fingerprint": fingerprint,
                "status": "pending",
                "before": {"profile": before["profile"], "model": before["model"]},
                "changes": impact,
                "at": now(),
            }
            # Budget entire persisted row, not just its model.
            if len(encoded(row).encode()) > 250000:
                raise ActivityError("activity_budget", "Слишком большой пакет изменения")
            self.put_json(PROPOSALS + pid + ".json", row)
            if previous:
                previous["status"] = "superseded"
                self.put_json(PROPOSALS + replace + ".json", previous)
            return {
                "ok": True,
                "id": pid,
                "card_id": "activity:" + pid,
                "status": "pending",
                "changes": impact,
            }

    def chain(self) -> list[tuple[str, dict]]:
        current = read_current(self.vault)
        if not current["present"]:
            return []
        result = [(current["version"], current["bundle"])]
        seen = {current["version"]}
        parent = current["bundle"]["parent_version"]
        while parent:
            if parent in seen or len(result) >= 1000:
                raise ActivityError("activity_history", "История повреждена или слишком велика")
            raw = self.raw(HISTORY + parent + ".json")
            if raw is None or sha256_bytes(raw) != parent:
                raise ActivityError("activity_history", "Нарушена целостность истории")
            bundle = validate_bundle(json.loads(raw))
            result.append((parent, bundle))
            seen.add(parent)
            parent = bundle["parent_version"]
        return result

    def version(self, version: str) -> dict:
        for key, bundle in self.chain():
            if key == version:
                return bundle
        raise ActivityError("activity_history", "Версия не входит в принятую историю")

    def history(self, offset: int = 0, limit: int = 10) -> dict:
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 50:
            raise ActivityError("activity_args", "Некорректная страница истории")
        chain = self.chain()
        return {
            "ok": True,
            "versions": [{"version": v, **b} for v, b in chain[offset : offset + limit]],
            "total": len(chain),
            "more": offset + limit < len(chain),
        }

    def decide(self, pid: str, action: str, params: dict) -> dict:
        with file_lock(self.lock):
            rel, row = self.proposal(pid)
            if not row or row["status"] not in ("pending", "snoozed"):
                return {"outcome": "stale", "detail": "Предложение уже решено"}
            request = {
                k: row[k]
                for k in (
                    "before_version",
                    "legacy_version",
                    "after",
                    "reason",
                    "origin",
                    "evidence",
                    "replace",
                    "before",
                )
            }
            if digest(request) != pid:
                raise ActivityError("activity_corrupt", "Предложение изменено вне протокола")
            row["after"]["model"] = parse_model(row["after"]["model"]).to_dict()
            prepared = row.get("prepared")
            if prepared:
                prepared = validate_bundle(prepared)
                if (
                    {"profile": prepared["profile"], "model": prepared["model"]} != row["after"]
                    or prepared["proposal_id"] != pid
                    or prepared["parent_version"] != row["before_version"]
                    or prepared["baseline_legacy"] != row["legacy_version"]
                    or prepared["reason"] != row["reason"]
                    or prepared["evidence"] != row["evidence"]
                ):
                    raise ActivityError(
                        "activity_corrupt", "План публикации не соответствует предложению"
                    )
                version = sha256_bytes(encoded(prepared).encode())
                if any(v == version for v, _ in self.chain()):
                    if action != "approve":
                        raise ActivityError(
                            "activity_prepared",
                            "Изменение уже записано; сначала доведите квитанцию",
                        )
                    row["status"] = "applied"
                    row["applied_version"] = version
                    self.put_json(rel, row)
                    return {
                        "outcome": "applied",
                        "effects": ["Квитанция применения восстановлена"],
                        "version": version,
                    }
            if action == "reject":
                row["status"] = "rejected"
                self.put_json(rel, row)
                return {
                    "outcome": "rejected",
                    "effects": ["Предложение отклонено; профиль не изменен"],
                }
            if action == "snooze":
                days = int(params.get("days", 14))
                if not 1 <= days <= 90:
                    raise ActivityError("activity_args", "Отложить на 1-90 дней")
                row["status"] = "snoozed"
                row["until"] = (datetime.now(UTC) + timedelta(days=days)).isoformat()
                self.put_json(rel, row)
                return {"outcome": "snoozed", "effects": ["Отложено до " + row["until"]]}
            if action != "approve":
                raise ActivityError("activity_action", "Неизвестное действие")
            if row["origin"] == "candidate" and params.get("attribution") != "owner":
                raise ActivityError(
                    "activity_attribution",
                    "Подтвердите, что изменение относится к вашей деятельности",
                )
            before = self.base()
            if (
                before["version"] != row["before_version"]
                or before["legacy_version"] != row["legacy_version"]
            ):
                raise ActivityError("activity_stale", "Деятельность или внешняя схема изменились")
            pins = self.evidence(
                [{"path": p["path"], "quote": p["quote"]} for p in row["evidence"]],
                row["origin"] == "candidate",
            )
            if pins != row["evidence"]:
                raise ActivityError("activity_source_stale", "Основания изменились")
            if not prepared:
                prepared = validate_bundle(
                    {
                        "schema": 1,
                        "revision": before["bundle"]["revision"] + 1 if before["bundle"] else 1,
                        **row["after"],
                        "baseline_legacy": row["legacy_version"],
                        "parent_version": before["version"],
                        "recorded_at": now(),
                        "proposal_id": pid,
                        "reason": row["reason"],
                        "evidence": pins,
                    }
                )
                row["prepared"] = prepared
                self.put_json(rel, row)
            text = encoded(prepared)
            version = sha256_bytes(text.encode())
            raw = self.raw(HISTORY + version + ".json")
            if raw is None:
                self.publish(HISTORY + version + ".json", text, None)
            elif raw != text.encode():
                raise ActivityError("activity_history", "Снимок истории поврежден")
            self.publish(CURRENT, text, before["version"] or None)
            row["status"] = "applied"
            row["applied_version"] = version
            self.put_json(rel, row)
            return {
                "outcome": "applied",
                "effects": ["Принята новая версия деятельности и предметной модели"],
                "version": version,
                "objects_migrated": 0,
            }

    def compensation(self, version: str, expected: str) -> dict:
        with file_lock(self.lock):
            current = self.base()
            if current["version"] != expected:
                raise ActivityError("activity_stale", "Версия изменилась")
            target = self.version(version)
            parent = self.version(target["parent_version"]) if target["parent_version"] else None
            profile = copy.deepcopy(current["profile"])
            model = copy.deepcopy(current["model"])
            initial = self.proposal(target["proposal_id"])[1] if not parent else None
            if not parent and not initial:
                raise ActivityError("activity_history", "Нет исходного снимка первой версии")
            old_profile = parent["profile"] if parent else initial["before"]["profile"]
            old_model = parent["model"] if parent else initial["before"]["model"]
            old_model = parse_model(old_model).to_dict()
            old_roles = latest(old_profile)
            target_roles = latest(target["profile"])
            cur_roles = latest(profile)
            for rid, period in target_roles.items():
                if old_roles.get(rid) == period:
                    continue
                if cur_roles.get(rid) != period:
                    raise ActivityError(
                        "activity_conflict",
                        "Направление менялось позже; автоматическая компенсация невозможна",
                    )
                if period["to"] is not None:
                    raise ActivityError(
                        "activity_conflict", "Закрытый период требует ручной сверки"
                    )
                role = next(r for r in profile["roles"] if r["id"] == rid)
                start = max(now(), period["from"])
                restored = copy.deepcopy(old_roles.get(rid) or period)
                role["periods"][-1]["to"] = start
                restored.update({"from": start, "to": None})
                if rid not in old_roles:
                    restored["state"] = "historical"
                role["periods"].append(restored)
            for tid, typ in target["model"].get("types", {}).items():
                old = old_model.get("types", {}).get(tid)
                if not old or old == typ:
                    continue  # new types retained for object/history compatibility
                cur = model["types"][tid]
                if cur != typ:
                    raise ActivityError(
                        "activity_conflict", "Тип менялся позже; нужна ручная сверка"
                    )
                n = max(cur["versions"]) + 1
                cur["versions"][n] = copy.deepcopy(old["versions"][old["current"]])
                cur["current"] = n
                cur["label"] = old["label"]
            if model != current["model"]:
                model["revision"] += 1
            return self.propose(
                profile,
                model,
                expected,
                current["legacy_version"],
                "Компенсировать версию "
                + version[:12]
                + ". Добавленные типы остаются для сохранения истории.",
            )
