"""PROV-CITED-1 - сверка цитат и чисел текста выхода с источниками сессии (без модели).

Текст выхода пишет модель хоста; движок не может судить о смысле, но может механически проверить,
что (а) дословные цитаты в кавычках встречаются в источниках, которые сессия реально подняла, а
(б) числа с единицами/валютой и даты там тоже есть. Результат - находки с кодами, не блок:

* ``quote_not_found`` - дословной цитаты нет ни в одном из поднятых источников;
* ``number_not_found`` - числа (``kind: number``) или даты (``kind: date``) нет в источниках;
* ``number_unit_mismatch`` - число найдено, но в другой единице/валюте или с другим масштабом
  (``480`` против ``0,48 млн``: цифры те же, степень десяти другая).

Что значит «найдено»: значение совпало в базовых единицах (``value × scale``) при совместимой
единице (неизвестная единица совместима с любой) - ТОЛЬКО это, без вывода о смысле: совпадение
числа в другом контексте остаётся «найдено». Что значит «не найдено»: нет в проверенных источниках;
источники, которые проверить нельзя (чтение мимо DT, файл не поднялся, чтение усечено, лимит
объёма), перечислены отдельно (``unsearched``/``partial``) - «не нашли» не равно «нет».

Нормализация чисел, масштаба, единиц и дат - ОБЩАЯ с фактами (:mod:`core.facts.textnorm`,
:mod:`core.facts.units`), своей нет. Источники сверки: тексты прочитанных заметок и поднятых
файлов, факты поднятых файлов с локаторами, ``prompt.md`` папки ``generate``.

Строгий режим (:func:`validate_strict`, тот же :func:`check_text`) - для сна: возвращает отказ,
а не предупреждение. Модуль чистый: ни сети, ни модели; ``core`` не импортирует ``cli``/
``mcp-server``.
"""

from __future__ import annotations

import logging
import re
import unicodedata
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

from core.facts.textnorm import (
    DateMention,
    NumberMention,
    digit_signature,
    scale_word,
    scan_dates,
    scan_numbers,
)

logger = logging.getLogger(__name__)

__all__ = [
    "CODE_CITED_FAILED",
    "CODE_NUMBER_NOT_FOUND",
    "CODE_QUOTE_NOT_FOUND",
    "CODE_UNIT_MISMATCH",
    "CODE_UNVERIFIABLE",
    "CitedReport",
    "Corpus",
    "Finding",
    "Material",
    "StrictVerdict",
    "check_text",
    "count_claims",
    "materials_from_rows",
    "render_section",
    "today_iso",
    "validate_strict",
]

CODE_QUOTE_NOT_FOUND = "quote_not_found"
CODE_NUMBER_NOT_FOUND = "number_not_found"
CODE_UNIT_MISMATCH = "number_unit_mismatch"
# Строгий режим (``validate_strict``): коды ОТКАЗА, не предупреждения.
CODE_CITED_FAILED = "cited_check_failed"  # есть находки сверки - кандидат не публикуется
CODE_UNVERIFIABLE = "cited_unverifiable"  # утверждения есть, а проверить их не с чем

KIND_QUOTE, KIND_NUMBER, KIND_DATE = "quote", "number", "date"

_QUOTE_MIN_CHARS = 25  # короче и короче 4 слов - это название/термин, а не цитата
_QUOTE_MIN_WORDS = 4
_QUOTE_FRAGMENT_MIN = 12
_NUMBER_MIN_DIGITS = 4  # число без единицы проверяем, только если в нём ≥ 4 цифр (не год)
_YEAR_RANGE = (1900, 2100)
_CORPUS_MAX_CHARS = 3_000_000  # потолок суммарного объёма сверки (дальше - «лимит»)
_SNIPPET = 80
_ITEMS_MAX = 8

_QMIN = _QUOTE_FRAGMENT_MIN
_QUOTE_RES = (
    re.compile(r"«([^«»\n]{" + f"{_QMIN}" + r",400})»"),
    re.compile(r"“([^“”\n]{" + f"{_QMIN}" + r",400})”"),
    re.compile(r"„([^„“”\n]{" + f"{_QMIN}" + r",400})[“”]"),
    re.compile(r'"([^"\n]{' + f"{_QMIN}" + r',400})"'),
)
_ELLIPSIS_RE = re.compile(r"\s*(?:\.{3}|…)\s*")
_DASHES = str.maketrans({c: "-" for c in "‐‑‒–—―−"})
_DROP = str.maketrans({c: " " for c in "«»“”„\"'`‘’"})
_FM_RE = re.compile(r"\A---\n.*?\n---\n", re.DOTALL)


# --------------------------------------------------------------------------- #
# Данные                                                                        #
# --------------------------------------------------------------------------- #
@dataclass
class Material:
    """Один проверяемый источник: текст и/или факты (с локаторами).

    ``partial`` - хосту отдана только часть (усечённое чтение): «не найдено» тогда слабее.
    ``facts`` - объекты ``Fact`` (``value_num``/``scale``/``unit``/``currency``/``locator``).
    """

    label: str
    text: str = ""
    facts: list[Any] = field(default_factory=list)
    partial: bool = False


@dataclass(frozen=True)
class Finding:
    """Находка сверки: код, вид (``quote``/``number``/``date``), текст и пояснение."""

    code: str
    kind: str
    text: str
    detail: str = ""
    found_as: str = ""  # как то же число записано в источнике (для ``number_unit_mismatch``)
    source: str = ""

    def to_dict(self) -> dict[str, str]:
        out = {"code": self.code, "kind": self.kind, "text": self.text}
        for key in ("detail", "found_as", "source"):
            if getattr(self, key):
                out[key] = getattr(self, key)
        return out


@dataclass
class CitedReport:
    """Итог сверки: находки, что проверяли и чем, что проверить было нельзя, что нашлось и где."""

    findings: list[Finding] = field(default_factory=list)
    checked: dict[str, int] = field(default_factory=lambda: {"quotes": 0, "numbers": 0, "dates": 0})
    searched: list[str] = field(default_factory=list)
    unsearched: list[dict[str, str]] = field(default_factory=list)
    partial: list[str] = field(default_factory=list)
    evidence: list[dict[str, str]] = field(default_factory=list)

    @property
    def claims(self) -> int:
        return sum(self.checked.values())

    def codes(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for f in self.findings:
            out[f.code] = out.get(f.code, 0) + 1
        return out

    def to_dict(self) -> dict[str, Any]:
        return {
            "checked": dict(self.checked), "searched": len(self.searched),
            "unsearched": list(self.unsearched), "partial": list(self.partial),
            "findings": [f.to_dict() for f in self.findings],
        }


# --------------------------------------------------------------------------- #
# Нормализация цитат                                                            #
# --------------------------------------------------------------------------- #
def norm_quote_text(text: str) -> str:
    """Текст для дословного поиска: NFC, регистр, ё→е, тире, кавычки, пробелы схлопнуты."""
    low = unicodedata.normalize("NFC", str(text or "")).lower().replace("ё", "е")
    return " ".join(low.translate(_DASHES).translate(_DROP).split())


def _snippet(text: str) -> str:
    one = " ".join(text.split())
    return one if len(one) <= _SNIPPET else one[: _SNIPPET - 1] + "…"


def _strip_frontmatter(text: str) -> str:
    return _FM_RE.sub("", text, count=1)


# --------------------------------------------------------------------------- #
# Корпус                                                                        #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class _Num:
    base: float
    unit: str | None
    value: float
    scale: float | None
    raw: str
    source: str
    locator: str


def _unit_of_fact(fact: Any) -> str | None:
    return getattr(fact, "currency", None) or getattr(fact, "unit", None) or None


def _compatible(a: str | None, b: str | None) -> bool:
    return a is None or b is None or a == b


def _describe(n: _Num) -> str:
    return " ".join(x for x in (n.raw, scale_word(n.scale), n.unit or "") if x)


def _fmt_base(value: float) -> str:
    """Число в базовых единицах для текста находки: без экспоненты, тысячи через пробел."""
    return f"{value:,.6f}".rstrip("0").rstrip(".").replace(",", " ")


def _key(base: float) -> str:
    return f"{abs(base):.9g}"


class Corpus:
    """Проиндексированные источники сверки: тексты (для цитат), числа и даты."""

    def __init__(self, materials: list[Material], unsearched: list[dict[str, str]] | None = None):
        self.texts: list[tuple[str, str]] = []  # (метка, нормализованный текст)
        self._by_base: dict[str, list[_Num]] = {}
        self._by_sig: dict[str, list[_Num]] = {}
        self._days: dict[str, tuple[str, str]] = {}  # ISO-день -> (источник, локатор)
        self._months: dict[str, tuple[str, str]] = {}
        self.searched: list[str] = []
        self.partial: list[str] = []
        self.unsearched: list[dict[str, str]] = list(unsearched or [])
        total = 0
        for m in materials:
            size = len(m.text) + 64 * len(m.facts)
            if total + size > _CORPUS_MAX_CHARS:
                self.unsearched.append({"path": m.label, "reason": "лимит объема сверки"})
                continue
            total += size
            self._add(m)
            self.searched.append(m.label)
            if m.partial:
                self.partial.append(m.label)

    def _add(self, m: Material) -> None:
        if m.text:
            self.texts.append((m.label, norm_quote_text(m.text)))
            dates = scan_dates(m.text)
            for d in dates:
                self._put_date(d.iso, m.label, f"text@{d.start}")
            blank = _blank_spans(m.text, [(d.start, d.end) for d in dates])
            for n in scan_numbers(blank):
                self._put_num(_Num(n.base, n.unit, n.value, n.scale, n.raw, m.label,
                                   f"text@{n.start}"))
        for f in m.facts:
            self._add_fact(f, m.label)

    def _add_fact(self, fact: Any, label: str) -> None:
        locator = str(getattr(fact, "locator", "") or "")
        if getattr(fact, "kind", "") == "date":
            from core.facts.temporal import norm_day

            iso = norm_day(str(getattr(fact, "value_raw", "") or ""))
            if iso:
                self._put_date(iso, label, locator)
            return
        value = getattr(fact, "value_num", None)
        if value is None:
            return
        scale = getattr(fact, "scale", None)
        raw = str(getattr(fact, "value_raw", "") or value)
        self._put_num(_Num(float(value) * (scale or 1.0), _unit_of_fact(fact), float(value),
                           scale, raw, label, locator))

    def _put_num(self, n: _Num) -> None:
        self._by_base.setdefault(_key(n.base), []).append(n)
        self._by_sig.setdefault(digit_signature(n.base), []).append(n)

    def _put_date(self, iso: str, source: str, locator: str) -> None:
        if len(iso) == 10:
            self._days.setdefault(iso, (source, locator))
            self._months.setdefault(iso[:7], (source, locator))
        else:
            self._months.setdefault(iso, (source, locator))

    # --- проверки ---
    @property
    def empty(self) -> bool:
        return not self.searched

    def has_quote(self, quote: str) -> str | None:
        """Метка источника, где дословно есть ``quote`` (фрагменты по «…» - каждый), иначе None."""
        fragments = [norm_quote_text(p).strip(" .,;:!?-") for p in _ELLIPSIS_RE.split(quote)]
        fragments = [p for p in fragments if len(p) >= _QUOTE_FRAGMENT_MIN]
        if not fragments:
            return None
        for label, text in self.texts:
            if all(p in text for p in fragments):
                return label
        return None

    def number_status(self, claim: NumberMention) -> tuple[str, _Num | None]:
        """``found`` | ``mismatch`` | ``missing`` и подтверждающее/расходящееся упоминание."""
        for n in self._by_base.get(_key(claim.base), []):
            if _compatible(claim.unit, n.unit):
                return "found", n
        for n in self._by_base.get(_key(claim.base), []):
            return "mismatch", n  # то же значение, но другая единица/валюта
        sig = digit_signature(claim.base)
        for n in self._by_sig.get(sig, []):
            # голое число источника (ни масштаба, ни единицы) ни о чем не свидетельствует:
            # расхождение степени десяти засчитываем только против размеченного упоминания
            if (n.scale or n.unit) and _compatible(claim.unit, n.unit):
                return "mismatch", n  # те же цифры, другая степень десяти (масштаб)
        return "missing", None

    def date_status(self, claim: DateMention) -> tuple[bool, tuple[str, str] | None]:
        hit = self._days.get(claim.iso) if claim.is_day else self._months.get(claim.iso)
        return hit is not None, hit


def _blank_spans(text: str, spans: list[tuple[int, int]]) -> str:
    """Текст с пробелами на месте ``spans`` (позиции остаются теми же)."""
    if not spans:
        return text
    chars = list(text)
    for a, b in spans:
        chars[a:b] = " " * (b - a)
    return "".join(chars)


# --------------------------------------------------------------------------- #
# Утверждения текста выхода                                                     #
# --------------------------------------------------------------------------- #
def _quotes(text: str) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for rx in _QUOTE_RES:
        for m in rx.finditer(text):
            q = m.group(1).strip()
            words = len(q.split())
            if (len(q) < _QUOTE_MIN_CHARS and words < _QUOTE_MIN_WORDS) or q in seen:
                continue
            seen.add(q)
            out.append(q)
    return out


def _is_year(n: NumberMention) -> bool:
    return (n.unit is None and n.scale is None and n.value.is_integer()
            and _YEAR_RANGE[0] <= n.value <= _YEAR_RANGE[1] and "," not in n.raw
            and "." not in n.raw and " " not in n.raw)


def _digits(raw: str) -> int:
    return len(re.sub(r"\D", "", raw.split(",")[0].split(".")[0]))


def _checkable(n: NumberMention) -> bool:
    """Число проверяем, если у него есть единица/масштаб/% либо оно «крупное» (не год)."""
    if _is_year(n):
        return False
    return n.unit is not None or n.scale is not None or _digits(n.raw) >= _NUMBER_MIN_DIGITS


def check_text(
    text: str, materials: list[Material], *, unsearched: list[dict[str, str]] | None = None,
    ignore_dates: set[str] | None = None,
) -> CitedReport:
    """Сверить цитаты, числа и даты ``text`` с ``materials`` -> :class:`CitedReport` (без модели).

    ``unsearched`` - источники, которые проверить нельзя (``{path, reason}``); ``ignore_dates`` -
    ISO-дни, которые не сверяются (дата самого документа: «сегодня»). Пустой корпус - находок нет
    (проверять не с чем: «неизвестно», а не «не найдено»).
    """
    corpus = Corpus(materials, unsearched)
    report = CitedReport(searched=list(corpus.searched), unsearched=list(corpus.unsearched),
                         partial=list(corpus.partial))
    if corpus.empty:
        return report
    skip = ignore_dates or set()

    for quote in _quotes(text):
        report.checked["quotes"] += 1
        source = corpus.has_quote(quote)
        if source is None:
            report.findings.append(Finding(
                CODE_QUOTE_NOT_FOUND, KIND_QUOTE, _snippet(quote),
                "дословной цитаты нет в проверенных источниках"))
        else:
            report.evidence.append({"kind": KIND_QUOTE, "text": _snippet(quote), "source": source})

    dates = scan_dates(text)
    for d in dates:
        if d.iso in skip:
            continue
        report.checked["dates"] += 1
        found, where = corpus.date_status(d)
        if found and where:
            report.evidence.append({"kind": KIND_DATE, "text": d.raw, "source": where[0],
                                    "locator": where[1]})
        else:
            report.findings.append(Finding(
                CODE_NUMBER_NOT_FOUND, KIND_DATE, d.raw,
                f"даты {d.iso} нет в проверенных источниках (формат записи не важен)"))

    blank = _blank_spans(text, [(d.start, d.end) for d in dates])
    for n in scan_numbers(blank):
        if not _checkable(n):
            continue
        report.checked["numbers"] += 1
        label = " ".join(x for x in (n.raw, scale_word(n.scale), n.unit or "") if x)
        status, hit = corpus.number_status(n)
        if status == "found" and hit is not None:
            report.evidence.append({"kind": KIND_NUMBER, "text": label, "source": hit.source,
                                    "locator": hit.locator})
        elif status == "mismatch" and hit is not None:
            same_base = _key(hit.base) == _key(n.base)
            why = ("другая единица/валюта: в источнике " f"{hit.unit}, в тексте {n.unit}"
                   if same_base else
                   f"другой масштаб: в источнике {_describe(hit)} = {_fmt_base(hit.base)}, "
                   f"в тексте {label} = {_fmt_base(n.base)}")
            report.findings.append(Finding(
                CODE_UNIT_MISMATCH, KIND_NUMBER, label, why, found_as=_describe(hit),
                source=hit.source))
        else:
            report.findings.append(Finding(
                CODE_NUMBER_NOT_FOUND, KIND_NUMBER, label,
                "числа нет в проверенных источниках (с учетом масштаба и формата записи)"))
    return report


def count_claims(text: str, *, ignore_dates: set[str] | None = None) -> dict[str, int]:
    """Сколько проверяемых утверждений в ``text`` (цитаты, числа, даты) - без корпуса."""
    skip = ignore_dates or set()
    dates = [d for d in scan_dates(text) if d.iso not in skip]
    blank = _blank_spans(text, [(d.start, d.end) for d in scan_dates(text)])
    return {"quotes": len(_quotes(text)), "dates": len(dates),
            "numbers": sum(1 for n in scan_numbers(blank) if _checkable(n))}


# --------------------------------------------------------------------------- #
# Строгий режим: то же ядро, но отказ                                           #
# --------------------------------------------------------------------------- #
@dataclass
class StrictVerdict:
    """Вердикт строгого валидатора: ``ok`` либо отказ с кодом и причинами.

    ``code``: ``cited_check_failed`` (есть находки: цитата/число/дата не найдены или в другой
    единице) либо ``cited_unverifiable`` (утверждения в тексте есть, проверенных источников нет:
    предупреждение ``save_output`` здесь молчало бы, строгий режим - нет). ``evidence`` - что
    подтверждено и ГДЕ (источник + локатор): сну это нужно для «точная версия и locator».
    """

    ok: bool
    code: str = ""
    error: str = ""
    report: CitedReport = field(default_factory=CitedReport)
    claims: dict[str, int] = field(default_factory=dict)

    @property
    def refused(self) -> bool:
        return not self.ok

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"ok": self.ok, "refused": self.refused}
        if self.code:
            out["code"] = self.code
            out["error"] = self.error
        out["claims"] = dict(self.claims)
        out["findings"] = [f.to_dict() for f in self.report.findings]
        out["evidence"] = list(self.report.evidence)
        out["unsearched"] = list(self.report.unsearched)
        out["partial"] = list(self.report.partial)
        return out


def validate_strict(
    text: str,
    materials: list[Material] | None = None,
    *,
    rows: list[Any] | None = None,
    out_dir: Path | None = None,
    vault_path: Path | None = None,
    unsearched: list[dict[str, str]] | None = None,
    ignore_dates: set[str] | None = None,
) -> StrictVerdict:
    """Строгая сверка для сна (SLEEP-STORE/SYNTH): ТО ЖЕ ядро, что у ``save_output``, но отказ.

    Источники - готовые ``materials`` либо строки провенанса ``rows`` (тогда материалы собирает
    :func:`materials_from_rows`). Отказ (:attr:`StrictVerdict.refused`) там, где ``save_output``
    дал бы лишь предупреждение или промолчал:

    * любая находка (:data:`CODE_QUOTE_NOT_FOUND`/:data:`CODE_NUMBER_NOT_FOUND`/
      :data:`CODE_UNIT_MISMATCH`) -> ``cited_check_failed``;
    * утверждения в тексте есть, а проверенных источников нет (пустой корпус, всё мимо DT/не
      поднялось) -> ``cited_unverifiable``: «проверить нечем» не равно «проверено».

    Текст без проверяемых утверждений проходит. Совпадение числа не доказывает смысл: строгий
    режим закрывает только механическую часть §5.4 (числа, даты, единицы, цитаты), смысловая
    рецензия и сравнение версий - вне него.
    """
    if materials is None:
        materials, found_unsearched = materials_from_rows(
            rows or [], out_dir=out_dir, vault_path=vault_path)
        unsearched = [*found_unsearched, *(unsearched or [])]
    claims = count_claims(text, ignore_dates=ignore_dates)
    report = check_text(text, materials, unsearched=unsearched, ignore_dates=ignore_dates)
    total = sum(claims.values())
    if report.findings:
        codes = ", ".join(f"{c} - {n}" for c, n in report.codes().items())
        return StrictVerdict(False, CODE_CITED_FAILED,
                             f"сверка цитат и чисел не пройдена: {codes}", report, claims)
    if total and not report.searched:
        return StrictVerdict(
            False, CODE_UNVERIFIABLE,
            f"в тексте {total} проверяемых утверждений, а источников для сверки нет "
            "(мимо DT, не поднялись или не читались)", report, claims)
    return StrictVerdict(True, report=report, claims=claims)


# --------------------------------------------------------------------------- #
# Материалы из строк провенанса                                                 #
# --------------------------------------------------------------------------- #
def _read_material(row: Any, vault_path: Path | None) -> tuple[Material | None, str]:
    """Текст прочитанной заметки (то, что видел хост: усечённое чтение режется по ``chars``)."""
    from core.vault import read_note, resolve_note_path

    ref = row.note_id or row.path
    try:
        path = resolve_note_path(ref, vault_path=vault_path)
        if path is None:
            return None, "заметка не нашлась"
        note = read_note(path, vault_path)
    except Exception as exc:  # noqa: BLE001 - нечитаемая заметка не роняет сверку
        return None, f"заметка не прочиталась: {exc}"
    body = str(note.body or "")
    partial = False
    for part in getattr(row, "reads", ()):
        if part.tool in ("read_note", "work_note_preview") and part.truncated and part.chars:
            body, partial = body[: part.chars], True
    title = str(note.frontmatter.get("title") or "")
    return Material(label=str(row.path or row.note_id), text=f"{title}\n{body}".strip(),
                    partial=partial), ""


def _lift_material(row: Any, parts: set[str]) -> tuple[Material | None, str]:
    """Текст (если файл поднимали) и факты поднятого файла с локаторами."""
    from core.facts.extract import extract_facts
    from core.sources import lift_from

    try:
        lifted = lift_from(path=row.path)
    except Exception as exc:  # noqa: BLE001
        return None, f"источник не поднялся: {exc}"
    if getattr(lifted, "status", "ok") != "ok" or getattr(lifted, "nda", False):
        return None, f"источник не поднялся: {getattr(lifted, 'reason', '') or 'нет'}"
    text = ""
    partial = False
    if "lift" in parts:
        text = str(lifted.text or "")
        for part in getattr(row, "reads", ()):
            if part.tool == "lift_source" and part.truncated and part.chars:
                text, partial = text[: part.chars], True
    try:
        facts = extract_facts(lifted)
    except Exception:  # noqa: BLE001 - факты - улучшение сверки, не её условие
        facts = []
    return Material(label=str(row.path), text=text, facts=list(facts), partial=partial), ""


def materials_from_rows(
    rows: list[Any], *, out_dir: Path | None = None, vault_path: Path | None = None,
) -> tuple[list[Material], list[dict[str, str]]]:
    """Строки ``sources.md`` -> материалы сверки + то, что проверить нельзя.

    ``read`` - текст заметки, ``lift`` - текст файла, ``lift``/``facts`` - факты файла с
    локаторами; ``manual`` (мимо DT) - содержимого движок не видит: ``unsearched``. У папки
    ``generate`` в материалы входит ``prompt.md`` (то, что реально ушло модели).
    """
    from core.privacy import any_nda

    materials: list[Material] = []
    unsearched: list[dict[str, str]] = []
    for row in rows:
        parts = set(str(row.origin).split("+"))
        label = str(row.path or row.note_id)
        if any_nda(label, row.note_id):
            continue
        if not parts & {"read", "lift", "facts"}:
            unsearched.append({"path": label, "reason": "мимо DT: содержимое движку не видно"})
            continue
        if "read" in parts:
            mat, why = _read_material(row, vault_path)
            if mat is not None:
                materials.append(mat)
            else:
                unsearched.append({"path": label, "reason": why})
        if parts & {"lift", "facts"}:
            mat, why = _lift_material(row, parts)
            if mat is not None:
                materials.append(mat)
            else:
                unsearched.append({"path": label, "reason": why})
    if out_dir is not None:
        prompt = Path(out_dir) / "prompt.md"
        try:
            materials.append(Material(
                label="prompt.md", text=_strip_frontmatter(prompt.read_text(encoding="utf-8"))))
        except OSError:
            pass
    return materials, unsearched


def render_section(report: CitedReport, heading: str = "## Сверка цитат и чисел") -> str:
    """Автосекция ``sources.md`` по находкам; ``""``, если находок нет (сверка молчит).

    Находка - повод проверить, а не вывод о смысле; источники, которые проверить нельзя, и
    усечённые чтения названы, чтобы «не нашли» не читалось как «нет».
    """
    if not report.findings:
        return ""
    c = report.checked
    lines = [
        heading, "",
        f"Сверка без модели: проверено цитат {c['quotes']}, чисел {c['numbers']}, дат "
        f"{c['dates']} в {len(report.searched)} источниках; находок {len(report.findings)}. "
        "Находка - повод проверить, а не вывод о смысле: совпадение числа не доказывает смысл.",
        "",
    ]
    for f in report.findings:
        extra = f" (в источнике: {f.found_as})" if f.found_as else ""
        lines.append(f"- `{f.code}` · {f.kind}: {_cell(f.text)} - {_cell(f.detail)}{extra}")
    for u in report.unsearched:
        lines.append(f"- не проверялось: {_cell(u['path'])} - {_cell(u['reason'])}")
    for label in report.partial:
        lines.append(f"- прочитано не полностью: {_cell(label)} - «не найдено» слабее")
    return "\n".join(lines) + "\n"


def _cell(value: str) -> str:
    return " ".join(str(value or "").split())


def today_iso(today: date | None = None) -> str:
    """Сегодняшняя дата ISO: дата самого документа не сверяется с источниками."""
    return (today or date.today()).isoformat()
