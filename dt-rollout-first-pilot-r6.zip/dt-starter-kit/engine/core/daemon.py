"""DAEMON-1 — чистые (без MCP SDK) части демона движка ``com.dt.server``.

Демон = один процесс на машину (``mcp-server/server.py --transport http``): пульт (``/``, ``/api``)
+ MCP по http (``/mcp/<профиль>``) + ``/health``. Здесь - то, что не зависит от SDK и ASGI и нужно
больше чем одному потребителю (граница MCP, ASGI-пульт, доктор): семафор тяжелых инструментов,
реестр сессий, версия кода, сводка ``/health``, чтение ``/health`` и ``footprint`` процесса.
``core`` не зависит от MCP: SDK импортируется только там, где его зовет ``mcp-server``.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import re
import threading
from collections.abc import AsyncIterator, Iterator
from typing import Any

__all__ = [
    "DEFAULT_HEAVY_PARALLEL",
    "DEFAULT_SESSION_IDLE_H",
    "HEALTH_NOTE",
    "HEAVY_PARALLEL_ENV",
    "HEAVY_TOOLS",
    "MODES",
    "MODE_ENV",
    "SESSION_IDLE_ENV",
    "SessionRegistry",
    "CODE_PATHS",
    "code_drift",
    "code_version",
    "fetch_health",
    "FOOTPRINT_EVENT",
    "FootprintRecorder",
    "footprint_mb",
    "footprint_trend",
    "health_payload",
    "memory_verdict",
    "rss_peak_mb",
    "start_footprint_recorder",
    "health_peer_ok",
    "heavy_parallel",
    "heavy_slot",
    "inflight",
    "is_loopback",
    "is_tailscale",
    "mcp_peer_ok",
    "resolve_mode",
    "server_mode",
    "session_idle_hours",
    "sessions_by_host",
    "stdio_calls_by_host",
    "stdio_server_processes",
    "tailscale_clients",
    "track_tool",
    "transport_hosts",
    "wait_idle",
]

# Тяжелые инструменты: сборка контекста генерации/поиска грузит эмбеддер, реранкер и кэши LanceDB.
# Семафор - предохранитель по ПАМЯТИ (не по задержке): лишний вызов ждет слот, а не получает отказ.
# Остальные инструменты идут параллельно (замер спайка: lock эмбеддера/реранкера уже сериализует
# настоящую конкуренцию, а семафор на ``find_notes`` только заставил бы второй хост ждать целый
# ``generate``).
HEAVY_TOOLS = frozenset({"generate", "retrieve"})
HEAVY_PARALLEL_ENV = "DT_DAEMON_HEAVY_PARALLEL"
DEFAULT_HEAVY_PARALLEL = 2


def heavy_parallel() -> int:
    """Сколько тяжелых вызовов идут одновременно: ``DT_DAEMON_HEAVY_PARALLEL`` (дефолт 2, минимум 1;
    мусор в env - дефолт)."""
    raw = (os.environ.get(HEAVY_PARALLEL_ENV) or "").strip()
    try:
        value = int(raw) if raw else DEFAULT_HEAVY_PARALLEL
    except ValueError:
        return DEFAULT_HEAVY_PARALLEL
    return max(1, value)


_sems: dict[tuple[int, int], asyncio.Semaphore] = {}
_sems_lock = threading.Lock()


def _semaphore() -> asyncio.Semaphore:
    """Семафор текущего event loop и текущего лимита (ключ - ``(loop, лимит)``: смена env в тесте
    или другой loop дают свой семафор, а не залипший старый)."""
    key = (id(asyncio.get_running_loop()), heavy_parallel())
    with _sems_lock:
        sem = _sems.get(key)
        if sem is None:
            sem = _sems[key] = asyncio.Semaphore(key[1])
        return sem


@contextlib.asynccontextmanager
async def heavy_slot(tool: str) -> AsyncIterator[None]:
    """Слот тяжелого инструмента: ждет, пока их идет меньше :func:`heavy_parallel`; остальные
    инструменты проходят сразу. Ожидание не ограничено и отказа не бывает."""
    if tool not in HEAVY_TOOLS:
        yield
        return
    async with _semaphore():
        yield


# --------------------------------------------------------------------------- #
# сессии, версия кода, /health                                                #
# --------------------------------------------------------------------------- #
SESSION_IDLE_ENV = "DT_DAEMON_SESSION_IDLE_H"
DEFAULT_SESSION_IDLE_H = 24.0
HEALTH_NOTE = (
    "рестарт демона рвет сессии MCP-хостов (stateless_http=false: сессия хранит clientInfo "
    "хоста); прямой клиент переподключается сам, Claude Desktop - мост с --reconnect"
)


def session_idle_hours() -> float | None:
    """Простой сессии до закрытия, часы: ``DT_DAEMON_SESSION_IDLE_H`` (дефолт 24; ``0`` - без
    таймаута; мусор в env - дефолт)."""
    raw = (os.environ.get(SESSION_IDLE_ENV) or "").strip()
    if not raw:
        return DEFAULT_SESSION_IDLE_H
    try:
        value = float(raw)
    except ValueError:
        return DEFAULT_SESSION_IDLE_H
    return value if value > 0 else None


class SessionRegistry:
    """Какой хост работает в какой MCP-сессии (по вызовам инструментов).

    ``clientInfo`` известен границе MCP только на вызове инструмента, поэтому сессия, в которой
    еще не было вызовов, в ``by_host`` попадает как :data:`NO_CALLS_HOST`. Хранится короткий id
    (8 символов) и имя хоста - ни токенов, ни аргументов. Потокобезопасен."""

    NO_CALLS_HOST = "(без вызовов)"

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._rows: dict[str, tuple[str, str]] = {}  # sid -> (host, profile)

    def touch(self, sid: str, host: str, profile: str = "") -> None:
        if sid:
            with self._lock:
                self._rows[sid] = (host or "unknown", profile)

    def snapshot(self, live: dict[str, set[str]] | None = None) -> dict[str, Any]:
        """``{total, by_host, by_profile}``. ``live`` - ``{профиль: {id живых сессий}}`` из
        менеджеров SDK: реестр сверяется с ним (закрытые/протухшие сессии уходят); ``None`` - берем
        реестр."""
        with self._lock:
            rows = dict(self._rows)
        by_host: dict[str, int] = {}
        by_profile: dict[str, int] = {}
        if live is None:
            for host, profile in rows.values():
                by_host[host] = by_host.get(host, 0) + 1
                by_profile[profile] = by_profile.get(profile, 0) + 1
            return {"total": len(rows), "by_host": by_host, "by_profile": by_profile}
        total = 0
        for profile, sids in live.items():
            by_profile[profile] = len(sids)
            for sid in sids:
                total += 1
                host = (rows.get(sid) or (self.NO_CALLS_HOST, ""))[0]
                by_host[host] = by_host.get(host, 0) + 1
        with self._lock:  # забыть закрытые сессии
            alive = {sid for sids in live.values() for sid in sids}
            for sid in [s for s in self._rows if s not in alive]:
                del self._rows[sid]
        return {"total": total, "by_host": by_host, "by_profile": by_profile}


def code_version(root: Any = None) -> str:
    """Короткий sha ``HEAD`` репо движка (``git rev-parse --short HEAD``); нет git - ``unknown``."""
    import subprocess
    from pathlib import Path

    from core.config import ENGINE_ROOT

    cwd = Path(root) if root is not None else ENGINE_ROOT
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],  # noqa: S607
            cwd=str(cwd), capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return "unknown"
    sha = (out.stdout or "").strip()
    return sha if out.returncode == 0 and sha else "unknown"


# Пути, чья правка меняет поведение демона: коммит мимо них (доки, ТЗ, roadmap, тесты, скиллы)
# демон «отставшим» не делает. Доктор «Демон DT» сверяет по ним, а не по хэшу ``HEAD``.
CODE_PATHS = ("core", "mcp-server", "cli", "webpult", "pyproject.toml", "uv.lock")


def code_drift(code: str, root: Any = None) -> tuple[bool, int] | None:
    """Разошелся ли КОД демона с ``HEAD``: ``(изменился, коммитов с ``code`` до ``HEAD``)``.

    ``git diff --quiet <code> HEAD -- CODE_PATHS``: нет разницы по путям кода - демон на
    актуальном коде, даже если ``HEAD`` ушел вперед (доки). ``None`` - git недоступен или хэш
    ему неизвестен (демон стартовал на коммите другой ветки/клона): вызывающий остается на
    прежнем сравнении хэшей.
    """
    import subprocess
    from pathlib import Path

    from core.config import ENGINE_ROOT

    if not re.fullmatch(r"[0-9a-fA-F]{4,64}", code):  # из /health: не опция и не ref-выражение
        return None
    cwd = str(Path(root) if root is not None else ENGINE_ROOT)

    def git(*args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(  # noqa: S603
            ["git", *args],  # noqa: S607
            cwd=cwd, capture_output=True, text=True, timeout=5, check=False,
        )

    try:
        diff = git("diff", "--quiet", code, "HEAD", "--", *CODE_PATHS)
        if diff.returncode not in (0, 1):
            return None
        count = git("rev-list", "--count", f"{code}..HEAD")
    except (OSError, subprocess.SubprocessError):
        return None
    commits = int(count.stdout.strip()) if count.returncode == 0 and count.stdout.strip() else 0
    return diff.returncode == 1, commits


def is_loopback(peer: str) -> bool:
    import ipaddress

    try:
        return ipaddress.ip_address(peer.split("%")[0]).is_loopback
    except ValueError:
        return False


def is_tailscale(peer: str) -> bool:
    """Адрес из сети Tailscale: ``100.64.0.0/10`` (CGNAT) или ULA ``fd7a:115c:a1e0::/48``."""
    import ipaddress

    try:
        ip = ipaddress.ip_address(peer.split("%")[0])
    except ValueError:
        return False
    if isinstance(ip, ipaddress.IPv4Address):
        return ip in ipaddress.ip_network("100.64.0.0/10")
    return ip in ipaddress.ip_network("fd7a:115c:a1e0::/48")


# --------------------------------------------------------------------------- #
# CONFIG-1 п.5: режим демона local | server                                    #
# --------------------------------------------------------------------------- #
MODE_ENV = "DT_MODE"
MODES = ("local", "server", "client")
_LOCAL_HOSTS = ["127.0.0.1:*", "localhost:*", "[::1]:*"]
_LOCAL_ORIGINS = ["http://127.0.0.1:*", "http://localhost:*", "http://[::1]:*"]


def server_mode() -> str:
    """Режим из ``DT_MODE``: ``local`` (дефолт, мусор тоже), ``server`` или ``client`` (клиентская
    машина без своего демона). Что демон ВЫБРАЛ на самом деле - :func:`resolve_mode`."""
    raw = (os.environ.get(MODE_ENV) or "").strip().lower()
    return raw if raw in MODES else "local"


def resolve_mode(tailscale: Any, requested: str | None = None) -> str:
    """Режим демона: ``server`` только при заданном ``DT_MODE=server`` И найденном адресе Tailscale
    (``tailscale`` - ``core.tailscale.TailscaleInfo`` или ``None``); иначе ``local`` - демон не
    открывается наружу без того, чтобы было куда (``dt config check`` называет причину)."""
    mode = requested if requested is not None else server_mode()
    return "server" if mode == "server" and tailscale is not None else "local"


def mcp_peer_ok(peer: str, mode: str = "local") -> bool:
    """Кому ``/mcp`` вообще отвечает (до токена): в ``local`` - только loopback (как в DAEMON-1);
    в ``server`` - loopback и Tailscale-peer. Прокси-заголовки (Funnel/Serve) режут отдельно,
    в обоих режимах: ``/mcp`` через прокси не отвечает никогда."""
    return is_loopback(peer) or (mode == "server" and is_tailscale(peer))


def transport_hosts(mode: str, tailscale: Any = None) -> tuple[list[str], list[str]]:
    """``(allowed_hosts, allowed_origins)`` DNS-rebinding защиты ``/mcp``: localhost всегда; в
    ``server`` добавляются DNS-имя и IP этой машины в tailnet (``Host`` клиента по Tailscale)."""
    hosts, origins = list(_LOCAL_HOSTS), list(_LOCAL_ORIGINS)
    if mode == "server" and tailscale is not None:
        extra = [h for h in [getattr(tailscale, "dns", ""), *getattr(tailscale, "ips", ())] if h]
        for h in extra:
            host = f"[{h}]" if ":" in h else h  # IPv6 в Host - в квадратных скобках
            hosts.append(f"{host}:*")
            origins.append(f"http://{host}:*")
    return hosts, origins


def health_peer_ok(peer: str) -> bool:
    """``/health`` отвечает только loopback и Tailscale-peer (Wi-Fi/чужим - 403)."""
    return is_loopback(peer) or is_tailscale(peer)


def health_payload(
    *,
    code: str,
    started: float,
    now: float,
    sessions: dict[str, Any],
    profiles: list[str],
    pult: bool,
    pid: int,
    idle_h: float | None,
    mode: str = "local",
    tailscale: Any = None,
    models: dict[str, Any] | None = None,
    footprint: int | None = None,
    rss_peak: int | None = None,
) -> dict[str, Any]:
    """Тело ``/health`` БЕЗ секретов: ни токенов, ни путей, ни аргументов - только состояние демона.

    ``started``/``now`` - unix-секунды. ``version.code`` - sha репо на старте демона (доктор
    сравнивает с ``HEAD``: «отстает» = код обновили, демон не перезапускали). CONFIG-1: ``mode``
    (``local`` | ``server``) и в ``server`` - ``tailscale: {dns, ips}`` (адрес для клиентов)."""
    from datetime import UTC, datetime

    from core.version import engine_version

    body: dict[str, Any] = {
        "ok": True,
        "version": {
            "engine": engine_version(),
            "code": code,
            "started": datetime.fromtimestamp(started, UTC).isoformat(timespec="seconds"),
            "uptime_s": max(0, int(now - started)),
        },
        "pid": pid,
        "sessions": sessions,
        "profiles": profiles,
        "pult": pult,
        "limits": {"heavy_parallel": heavy_parallel(), "session_idle_h": idle_h},
        "note": HEALTH_NOTE,
        "mode": mode,
    }
    if models is not None:  # RESOURCE-1 п.4: состояние моделей (без их загрузки)
        body["models"] = models
    if footprint is not None:  # RESOURCE-1 п.5: память демона (как в докторе) и пик RSS
        body["footprint_mb"] = footprint
    if rss_peak is not None:
        body["rss_peak_mb"] = rss_peak
    if mode == "server" and tailscale is not None:
        body["tailscale"] = tailscale.as_health()
    from core.instance import describe, instance_name

    if instance_name() is not None:  # PERSONAL-1: ответ обычного демона без экземпляра не меняется
        body["instance"] = describe()
    return body


def fetch_health(port: int | None = None, *, host: str = "127.0.0.1",
                 timeout: float = 2.0) -> dict[str, Any] | None:
    """``GET /health`` демона на ``host:port`` (дефолт - ``DT_WEB_PORT`` или 8787); ``None`` - не
    ответил (демон не жив / порт занят чем-то другим)."""
    import json
    import urllib.error
    import urllib.request

    p = port if port is not None else int(os.environ.get("DT_WEB_PORT") or 8787)
    try:
        with urllib.request.urlopen(
            f"http://{host}:{p}/health", timeout=timeout
        ) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (OSError, ValueError, urllib.error.URLError):
        return None
    return data if isinstance(data, dict) and "version" in data else None


def fetch_health_url(base_url: str, *, timeout: float = 2.0) -> dict[str, Any] | None:
    """``GET <base_url>/health`` (PERSONAL-1: сосед по ``DT_EMBED_URL``/``DT_WORK_URL``); ``None`` -
    не ответил. Тот же разбор, что у :func:`fetch_health`."""
    import json
    import urllib.error
    import urllib.request

    try:
        url = f"{base_url.rstrip('/')}/health"
        with urllib.request.urlopen(url, timeout=timeout) as resp:  # noqa: S310 - loopback http
            data = json.loads(resp.read().decode("utf-8"))
    except (OSError, ValueError, urllib.error.URLError):
        return None
    return data if isinstance(data, dict) and "version" in data else None


def footprint_mb(pid: int) -> int | None:
    """Физический footprint процесса, МБ (``footprint -p``, как Монитор активности: ``ps rss`` на
    macOS занижает на порядок из-за сжатой памяти). Нет утилиты/процесса - ``None`` («н/д»)."""
    import re
    import subprocess

    try:
        out = subprocess.run(  # noqa: S603 — фиксированный argv
            ["footprint", "-p", str(int(pid))],  # noqa: S607
            capture_output=True, text=True, timeout=10, check=False,
        ).stdout
    except (OSError, subprocess.SubprocessError, ValueError):
        return None
    m = re.search(r"Footprint:\s+([\d.]+)\s*(KB|MB|GB)", out)
    if not m:
        return None
    return round(float(m.group(1)) * {"KB": 1 / 1024, "MB": 1, "GB": 1024}[m.group(2)])


_fp_cache: dict[int, tuple[float, int | None]] = {}
_fp_inflight: set[int] = set()
_fp_lock = threading.Lock()
FOOTPRINT_TTL_S = 30.0


def footprint_cached(pid: int, ttl: float = FOOTPRINT_TTL_S, *, wait: bool = False) -> int | None:
    """:func:`footprint_mb` с кэшем на ``ttl`` секунд и обновлением В ФОНЕ.

    ``footprint -p`` дорог (десятки-сотни мс, до 10 с при сбое), а ``/health`` отвечает из цикла
    событий демона и его опрашивают клиенты эмбеддера и пульт: ждать подпроцесс там нельзя. Поэтому
    устаревшее значение отдается сразу, а обновление идет в потоке; самый первый вызов, когда
    значения еще нет, возвращает ``None`` (честное «н/д», не ноль). ``wait=True`` - синхронно
    (тесты, разовые замеры)."""
    import time

    now = time.monotonic()
    with _fp_lock:
        hit = _fp_cache.get(pid)
        fresh = hit is not None and now - hit[0] < ttl
        refreshing = pid in _fp_inflight
        if not fresh and not wait and not refreshing:
            _fp_inflight.add(pid)
    if fresh:
        return hit[1] if hit else None
    if wait:
        value = footprint_mb(pid)
        with _fp_lock:
            _fp_cache[pid] = (time.monotonic(), value)
        return value
    if not refreshing:
        threading.Thread(target=_refresh_footprint, args=(pid,), daemon=True,
                         name="dt-footprint").start()
    return hit[1] if hit else None


def _refresh_footprint(pid: int) -> None:
    import time

    try:
        value = footprint_mb(pid)
        with _fp_lock:
            _fp_cache[pid] = (time.monotonic(), value)
    finally:
        with _fp_lock:
            _fp_inflight.discard(pid)


def rss_peak_mb() -> int | None:
    """Пик RSS ЭТОГО процесса за жизнь, МБ (``ru_maxrss``: на macOS байты, на Linux КБ)."""
    import sys

    try:
        import resource

        raw = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    except (ImportError, OSError, ValueError):
        return None
    return round(raw / (1024 * 1024 if sys.platform == "darwin" else 1024))


FOOTPRINT_EVENT = "daemon_footprint"
FOOTPRINT_EVERY_S = 3600.0


class FootprintRecorder(threading.Thread):
    """Раз в час пишет в журнал метрик ``daemon_footprint`` (footprint и пик RSS демона, состояние
    модели) - из этого строится тренд «растет ли демон» (RESOURCE-1 п.5)."""

    def __init__(self, interval: float = FOOTPRINT_EVERY_S, models: Any = None) -> None:
        super().__init__(name="dt-daemon-footprint", daemon=True)
        self.interval = interval
        self._models = models  # вызываемое → {embedder: ..., reranker: ...}; None - без моделей
        self._stop_evt = threading.Event()

    def sample(self) -> dict[str, Any] | None:
        """Один замер → запись в журнал; ``None`` - footprint недоступен (честно не пишем ноль)."""
        from core.metrics import record_event

        pid = os.getpid()
        mb = footprint_mb(pid)
        if mb is None:
            return None
        fields: dict[str, Any] = {"mb": mb, "rss_peak_mb": rss_peak_mb(), "pid": pid}
        try:
            models = self._models() if self._models is not None else {}
        except Exception:  # noqa: BLE001 — состояние модели - справка, не причина молчать
            models = {}
        if models.get("embedder"):
            fields["embedder"] = models["embedder"]
        worker = models.get("worker") or {}
        if worker.get("state") == "down":  # RESOURCE-2: воркер остановлен - его память честный 0
            fields["worker_mb"] = 0
        elif isinstance(worker.get("footprint_mb"), (int, float)):
            fields["worker_mb"] = int(worker["footprint_mb"])
        record_event(FOOTPRINT_EVENT, **fields)
        return fields

    def run(self) -> None:
        self.sample()  # первый замер сразу: тренд начинается со старта демона
        while not self._stop_evt.wait(self.interval):
            self.sample()

    def stop(self) -> None:
        self._stop_evt.set()


def start_footprint_recorder(models: Any = None) -> FootprintRecorder:
    """Запустить :class:`FootprintRecorder` демона (раз в час)."""
    rec = FootprintRecorder(models=models)
    rec.start()
    return rec


def footprint_trend(hours: float = 24.0, *, now: Any = None, path: Any = None
                    ) -> dict[str, Any] | None:
    """Тренд footprint демона по журналу: ``{n, min_mb, max_mb, last_mb, first_mb}`` за окно;
    ``None`` - замеров нет (демон старой версии / окно пусто). RESOURCE-2: ``worker_max_mb`` - пик
    воркера моделей, если замеры его несли."""
    from datetime import UTC, datetime, timedelta

    from core.metrics import read_non_call_events

    end = now if now is not None else datetime.now(UTC)
    try:
        rows = [e for e in read_non_call_events(end - timedelta(hours=hours), path=path)
                if e.get("kind") == FOOTPRINT_EVENT and isinstance(e.get("mb"), (int, float))]
    except Exception:  # noqa: BLE001 — тренд - справка
        return None
    if not rows:
        return None
    values = [float(e["mb"]) for e in rows]
    out = {"n": len(values), "min_mb": round(min(values)), "max_mb": round(max(values)),
           "first_mb": round(values[0]), "last_mb": round(values[-1])}
    workers = [float(e["worker_mb"]) for e in rows if isinstance(e.get("worker_mb"), (int, float))]
    if workers:  # RESOURCE-2: пик памяти воркера моделей за окно (демон измеряется без него)
        out["worker_max_mb"] = round(max(workers))
    return out


def memory_verdict(health: dict[str, Any], *, ram: Any = None) -> dict[str, Any] | None:
    """Память демона по его ``/health`` против порога :func:`core.resources.footprint_warn_gib`
    (``DT_DAEMON_FOOTPRINT_WARN_GIB``, иначе RAM/2): ``{footprint_mb, worker_mb, total_mb,
    rss_peak_mb, limit_gib, status: ok|warn, text, hint}``; ``None`` - демон старой версии не отдает
    footprint.

    RESOURCE-2: модели живут в воркере ``dt-models``, ``footprint_mb`` демона - БЕЗ него. Порог
    действует на СУММУ (``total_mb``): модели занимали память внутри демона, теперь - рядом с ним,
    а нагрузка на машину та же. ``worker_mb`` - ``0`` при остановленном воркере (честный ноль: его
    нет), ``None`` - у демона без воркера (``DT_MODELS_WORKER=0`` или версия до RESOURCE-2) и когда
    воркер жив, но еще не измерен.

    Подсказка зависит от того, кто растет: воркер - перезапуск по порогу/простою уже есть, дальше
    профиль; сам демон при остановленном воркере - не модели (кэши LanceDB, сессии): рестарт."""
    mb = health.get("footprint_mb")
    if not isinstance(mb, (int, float)):
        return None
    from core import resources

    limit = resources.footprint_warn_gib() if ram is None else resources.footprint_warn_gib(ram)
    models = health.get("models") or {}
    worker = models.get("worker") if isinstance(models.get("worker"), dict) else None
    w_state = (worker or {}).get("state")
    w_raw = (worker or {}).get("footprint_mb")
    w_mb: int | None = (0 if w_state == "down" else
                        int(w_raw) if isinstance(w_raw, (int, float)) else None)
    total = int(mb) + (w_mb or 0)
    gib = total / 1024
    if worker is None:  # демон без воркера: одна цифра, как до RESOURCE-2
        text = f"footprint {int(mb) / 1024:.1f} ГБ"
    elif w_state == "down":
        text = f"footprint демона {int(mb) / 1024:.1f} ГБ · воркер моделей остановлен"
    elif w_mb is None:
        text = f"footprint демона {int(mb) / 1024:.1f} ГБ + воркер моделей (замер идет)"
    else:
        text = (f"footprint демона {int(mb) / 1024:.1f} ГБ + воркер моделей {w_mb / 1024:.1f} ГБ "
                f"= {gib:.1f} ГБ")
    out: dict[str, Any] = {
        "footprint_mb": int(mb), "worker_mb": w_mb, "total_mb": total,
        "rss_peak_mb": health.get("rss_peak_mb"), "limit_gib": limit, "status": "ok",
        "text": text, "hint": "",
    }
    if gib <= limit:
        return out
    if worker is not None and (w_mb or 0) >= int(mb):
        why = ("основной расход - воркер моделей: он перезапустится между запросами при "
               f"footprint > DT_MODELS_WORKER_MAX_GIB и завершится после простоя "
               f"(DT_EMBED_IDLE_UNLOAD_S, сейчас {models.get('idle_unload_s', 1800):g} с); легче "
               "профиль - DT_EMBED_DTYPE=fp16, DT_EMBED_BATCH_SIZE меньше")
    elif worker is not None:
        why = ("рост в самом демоне, не в моделях (они в воркере): кэши LanceDB, сессии хостов - "
               "перезапуск демона сбрасывает память")
    elif models.get("embedder") == "loaded":
        why = ("модель эмбеддера загружена: выгрузится после простоя "
               f"(DT_EMBED_IDLE_UNLOAD_S, сейчас {models.get('idle_unload_s', 1800):g} с); легче "
               "профиль - DT_EMBED_DTYPE=fp16, DT_EMBED_BATCH_SIZE меньше")
    elif models.get("embedder") == "unloaded":
        why = ("модель эмбеддера выгружена - рост не от нее (реранкер, кэши LanceDB, сессии): "
               "перезапуск демона сбрасывает память")
    else:
        why = "выгрузка по простою (DT_EMBED_IDLE_UNLOAD_S) и профиль эмбеддера (DT_EMBED_DTYPE)"
    out.update(
        status="warn",
        text=f"{text} > порога {limit:g} ГБ (DT_DAEMON_FOOTPRINT_WARN_GIB, по умолчанию RAM/2)",
        hint=why)
    return out


def worker_notes(health: dict[str, Any], *, now: Any = None) -> tuple[list[str], str]:
    """Что сказать о воркере моделей в строке доктора: ``(части detail, предупреждение)``.

    Части - состояние (``воркер моделей pid …, форм N, перезапусков R, смертей D``), пустые у демона
    без воркера. Предупреждение (``""`` - все в порядке): воркер умирал за последние 24 ч (код
    выхода и время последней смерти - демон поднимал новый и повторял запрос, но кто-то должен
    глянуть в лог) либо torch < 2.13 на MPS (кэш графов не чистится, память воркера растет до
    перезапуска)."""
    from datetime import UTC, datetime

    worker = (health.get("models") or {}).get("worker")
    if not isinstance(worker, dict):
        return [], ""
    parts: list[str] = []
    if worker.get("state") == "up":
        bits = [f"pid {worker.get('pid')}", f"форм {worker.get('shapes', 0)}",
                f"перезапусков {worker.get('recycles', 0)}", f"смертей {worker.get('deaths', 0)}"]
        parts.append("воркер моделей " + ", ".join(bits))
    elif worker.get("deaths") or worker.get("recycles"):
        parts.append(f"воркер моделей остановлен (перезапусков {worker.get('recycles', 0)}, "
                     f"смертей {worker.get('deaths', 0)})")
    warns: list[str] = []
    last = worker.get("last_death") or {}
    when = str(last.get("at") or "")
    if when:
        try:
            delta = (now or datetime.now(UTC)) - datetime.fromisoformat(when)
            age_h: float | None = delta.total_seconds() / 3600
        except ValueError:
            age_h = None
        if age_h is not None and age_h <= 24:
            warns.append(f"воркер моделей умирал ({last.get('reason') or 'причина в логе'}); демон "
                         "поднял новый и повторил запрос - смотри launchd.server.err.log "
                         "(«воркер моделей умер»)")
    if worker.get("graph_cache_clear") is False and worker.get("device") == "mps":
        warns.append(f"torch {worker.get('torch') or '?'} < 2.13: кэш графов MPS не чистится, "
                     "память воркера растет до его перезапуска - `uv sync --all-extras` и рестарт "
                     "демона")
    return parts, "; ".join(warns)


def sessions_by_host(hours: float = 24.0, *, now: Any = None, path: Any = None
                     ) -> dict[str, int] | None:
    """Сессии MCP-http по хостам за окно: ``{хост: число различных ``sid``}`` из ``tool_call`` с
    полем ``sid`` (его ставит граница http, :func:`core.host.set_request`). Вызовы без ``sid``
    (stdio, пульт) не считаются. ``None`` - журнал не прочитался."""
    from datetime import UTC, datetime, timedelta

    from core.metrics import read_tool_calls

    end = now if now is not None else datetime.now(UTC)
    events = read_tool_calls(end - timedelta(hours=hours), path=path)
    if events is None:
        return None
    seen: dict[str, set[str]] = {}
    for e in events:
        sid = str(e.get("sid") or "")
        if sid:
            seen.setdefault(str(e.get("host") or "unknown"), set()).add(sid)
    return {host: len(sids) for host, sids in sorted(seen.items())}


def stdio_calls_by_host(hours: float = 24.0, *, now: Any = None, path: Any = None
                        ) -> dict[str, int] | None:
    """Вызовы инструментов по хостам БЕЗ ``sid`` за окно - то есть по stdio (свой процесс движка на
    хост): ``{хост: число вызовов}``. Вызовы пульта (``surface=webpult``) не считаются. ``None`` -
    журнал не прочитался. Парная к :func:`sessions_by_host` (там - сессии по url/мосту, ``sid``)."""
    from datetime import UTC, datetime, timedelta

    from core.metrics import read_tool_calls

    end = now if now is not None else datetime.now(UTC)
    events = read_tool_calls(end - timedelta(hours=hours), path=path)
    if events is None:
        return None
    out: dict[str, int] = {}
    for e in events:
        if e.get("sid") or e.get("surface") != "mcp":
            continue
        host = str(e.get("host") or "unknown")
        out[host] = out.get(host, 0) + 1
    return dict(sorted(out.items()))


def tailscale_clients(hours: float = 24.0, *, now: Any = None, path: Any = None) -> int | None:
    """Сколько РАЗНЫХ клиентов по Tailscale ходили на ``/mcp`` за окно (режим ``server``): различные
    peer-адреса из ``tool_call`` (``surface=mcp``) из сети Tailscale; loopback не считается.
    ``None`` - журнал не прочитался."""
    from datetime import UTC, datetime, timedelta

    from core.metrics import read_tool_calls

    end = now if now is not None else datetime.now(UTC)
    events = read_tool_calls(end - timedelta(hours=hours), path=path)
    if events is None:
        return None
    peers = {
        str(e.get("peer") or "")
        for e in events
        if e.get("surface") == "mcp" and is_tailscale(str(e.get("peer") or ""))
    }
    return len(peers)


# маркеры хоста-владельца по цепочке родителей процесса (только для подписи, не для логики)
_OWNER_MARKERS = (("claude", "Claude Desktop/Cowork"), ("kimi", "Kimi"), ("cursor", "Cursor"),
                  ("cherry", "Cherry Studio"))


def _owner_of(pid: int, table: dict[int, tuple[int, str]]) -> str:
    seen = 0
    cur = table.get(pid, (0, ""))[0]
    while cur and seen < 8:
        _ppid, cmd = table.get(cur, (0, ""))
        low = cmd.casefold()
        for marker, label in _OWNER_MARKERS:
            if marker in low:
                return label
        cur = table.get(cur, (0, ""))[0]
        seen += 1
    return "?"


def stdio_server_processes(ps_output: str | None = None) -> list[dict[str, Any]] | None:
    """Живые stdio-процессы движка: ``python … mcp-server/server.py`` БЕЗ ``--transport http`` и без
    ``--selftest`` (обертки ``uv run``/``disclaimer`` не считаются) -> ``[{pid, owner}]``, где
    ``owner`` - хост по цепочке родителей (``?`` - не виден). ``ps_output`` - инъекция вывода
    ``ps -axo pid=,ppid=,command=`` для тестов; ``None`` - ``ps`` не выполнился (неизвестно)."""
    import subprocess

    if ps_output is None:
        try:
            ps_output = subprocess.run(
                ["ps", "-axo", "pid=,ppid=,command="],  # noqa: S607
                capture_output=True, text=True, timeout=10, check=False,
            ).stdout
        except (OSError, subprocess.SubprocessError):
            return None
    table: dict[int, tuple[int, str]] = {}
    for line in ps_output.splitlines():
        parts = line.strip().split(None, 2)
        if len(parts) == 3 and parts[0].isdigit() and parts[1].isdigit():
            table[int(parts[0])] = (int(parts[1]), parts[2])
    found = []
    for pid, (_ppid, cmd) in table.items():
        words = cmd.split()
        exe = os.path.basename(words[0]) if words else ""
        if not exe.startswith("python") or "--transport" in words or "--selftest" in words:
            continue
        if any(w.endswith("mcp-server/server.py") for w in words):
            found.append({"pid": pid, "owner": _owner_of(pid, table)})
    return sorted(found, key=lambda r: r["pid"])


# --------------------------------------------------------------------------- #
# SANDBOX-DAEMON: живые потоки инструментов                                    #
# --------------------------------------------------------------------------- #
# Инструмент демона идет в потоке (``anyio.to_thread``, не отменяемом: обрыв клиента поток не
# останавливает). Счетчик живых вызовов нужен тому, кто гасит демон (тесты с in-process демоном):
# откат env песочницы (``DT_DERIVED_ROOT``) ДО конца потока давал запись ``tool_call`` в боевой
# журнал (DAEMON-1: ``host=idle-test``). ``shutdown`` тестового сервера ждет :func:`wait_idle`.
_inflight = 0
_inflight_lock = threading.Lock()


@contextlib.contextmanager
def track_tool() -> Iterator[None]:
    """Вызов инструмента идет (счетчик живых потоков); выходит - и при исключении."""
    global _inflight
    with _inflight_lock:
        _inflight += 1
    try:
        yield
    finally:
        with _inflight_lock:
            _inflight -= 1


def inflight() -> int:
    """Сколько вызовов инструментов сейчас исполняется в потоках демона."""
    with _inflight_lock:
        return _inflight


def wait_idle(timeout: float = 10.0) -> int:
    """Ждать, пока потоки инструментов закончатся (не дольше ``timeout`` с); возвращает, сколько
    еще живо (``0`` - все закончились)."""
    import time

    deadline = time.monotonic() + max(0.0, timeout)
    while inflight() and time.monotonic() < deadline:
        time.sleep(0.02)
    return inflight()
