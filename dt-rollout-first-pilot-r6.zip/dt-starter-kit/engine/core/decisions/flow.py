"""USE-LOOP-1 - слой потока очереди: пакет недели (п.2) и, дальше, бюджет выпуска (п.4).

Это НЕ стор детекторов и не новый стор решений: карточки по-прежнему живут в сторах своих видов,
решения идут через ``decide`` по каждой. Здесь только бухгалтерия слоя очереди - один файл
``.derived/queue_flow.json`` (``core.config.queue_flow_path``), производный и перестраиваемый.

**Пакет недели** (``pult_cards(view="week")``): не больше ``DT_QUEUE_WEEK_SIZE`` (дефолт 15)
ПОЗИЦИЙ по ``priority`` (позиция - карточка либо группа, п.3). Состав фиксируется при ПЕРВОМ запросе
ISO-недели (понедельник, UTC) и хранится в ``week``: ``{id, fixed_at, size, extended, positions:
[{id, members}]}``. Дальше состав стабилен: решенная карточка уходит из выдачи, а место НЕ
добирается (иначе разбор не кончается); ``more=True`` («еще») добирает следующую порцию явно. Новая
неделя - новый состав. Порядок позиций - как при фиксации (не прыгает от пересчета приоритета).
«Решено» - позиция, из которой ушли все карточки, при условии что вид читается: сбой вида
(``errors``) не засчитывается за решение, а пока вид не читается, состав недели не фиксируется
(``week.provisional``). Потеря файла = фиксация заново при следующем запросе, ничего не теряется.

**Бюджет выпуска без потерь** (п.4, ``DT_QUEUE_BUDGET``, дефолт ``lint=15,gold=10,memory=5``;
остальные виды без бюджета; ``вид=off`` снимает бюджет вида). Реестр ``cards`` ведет у каждой
карточки: первое появление ``fs``, ``st`` (``v`` - видна, ``r`` - в запасе), неделю выпуска
``aw``, ``gone``
(из очереди ушла). Новая карточка вида с бюджетом ``B`` видна, пока на этой ISO-неделе выпущено
меньше ``B``; сверх - ``reserve``: детектор записал ее как обычно (стор вида не тронут), но она не
входит в счетчик «требуют решения» и в пакет; в пульте - строка «в запасе N». На следующей неделе
запас выпускается ПЕРВЫМ (FIFO по первому появлению), потом новые. Ничего не удаляется и не
архивируется по сроку: запас только скрыт, пока не выпущен; видимые + запас = всё, что ждет.
Карточки, что ждали ДО появления реестра, выпущены сразу (база вида): бюджет лишь не дает очереди
расти дальше. Реестр хранит ушедшие 90 дней - по нему доктор считает «пришло» за неделю.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import fcntl
import json
import logging
import os
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "BUDGET_DEFAULTS",
    "BUDGET_ENV",
    "DEFAULT_WEEK_SIZE",
    "WEEK_SIZE_ENV",
    "FlowStore",
    "apply_budget",
    "arrivals",
    "budgets",
    "iso_week",
    "reserve_counts",
    "week_size",
    "week_view",
]

WEEK_SIZE_ENV = "DT_QUEUE_WEEK_SIZE"
DEFAULT_WEEK_SIZE = 15
BUDGET_ENV = "DT_QUEUE_BUDGET"
# SLEEP-STORE-1 (решение владельца 15.11): memory=5 - новых карточек вида «Память» в неделю (пилот).
BUDGET_DEFAULTS: dict[str, int] = {"lint": 15, "gold": 10, "memory": 5}
GONE_KEEP_DAYS = 90
FLOW_VERSION = 1
_STAMP = "%Y-%m-%dT%H:%M:%SZ"
_LOCK = threading.RLock()


def week_size() -> int:
    """Размер пакета недели (``DT_QUEUE_WEEK_SIZE``; мусор/не положительное - дефолт 15)."""
    raw = (os.environ.get(WEEK_SIZE_ENV) or "").strip()
    return int(raw) if raw.isdigit() and int(raw) > 0 else DEFAULT_WEEK_SIZE


def iso_week(now: datetime) -> str:
    """ISO-неделя (понедельник, UTC) вида ``2026-W46``."""
    year, week, _ = now.isocalendar()
    return f"{year}-W{week:02d}"


def _stamp(now: datetime) -> str:
    return now.strftime(_STAMP)


class FlowStore:
    """Файл потока очереди: загрузка (битый/чужой - пустой), атомарная запись, лок процесса."""

    def __init__(self, path: Path | None = None) -> None:
        if path is None:
            from core.config import queue_flow_path

            path = queue_flow_path()
        self.path = Path(path)
        self.data: dict[str, Any] = {"version": FLOW_VERSION}

    @classmethod
    def load(cls, path: Path | None = None) -> FlowStore:
        store = cls(path)
        try:
            body = json.loads(store.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return store
        if isinstance(body, dict) and body.get("version") == FLOW_VERSION:
            store.data = body
        return store

    def save(self) -> bool:
        """Атомарно (tmp + replace). ``False`` - не записалось (в лог: поток вторичен)."""
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(f".{os.getpid()}.{threading.get_ident()}.tmp")
            tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=1), encoding="utf-8")
            tmp.replace(self.path)
        except (OSError, TypeError, ValueError) as exc:
            logger.warning("поток очереди %s не записан: %s", self.path, exc)
            return False
        return True

    @contextmanager
    def locked(self) -> Iterator[None]:
        """Читать-менять-писать без гонки (потоки процесса + flock между процессами)."""
        with _LOCK:
            lock = self.path.with_suffix(self.path.suffix + ".lock")
            try:
                lock.parent.mkdir(parents=True, exist_ok=True)
                fh = lock.open("a+")
            except OSError:
                yield
                return
            try:
                fcntl.flock(fh, fcntl.LOCK_EX)
                yield
            finally:
                try:
                    fcntl.flock(fh, fcntl.LOCK_UN)
                finally:
                    fh.close()


# --------------------------------------------------------------------------- #
# Пакет недели                                                                  #
# --------------------------------------------------------------------------- #
def _rank_key(card: dict[str, Any]) -> tuple[float, str, str]:
    """Порядок позиций: приоритет по убыванию, затем давнее раньше, затем id (стабильно)."""
    return (-float(card.get("priority") or 0.0), str(card.get("since") or "9999"), str(card["id"]))


def _positions(
    cards: list[dict[str, Any]], titles: dict[str, str] | None = None
) -> list[dict[str, Any]]:
    """Позиции пакета из ВИДИМЫХ карточек: карточка либо группа (:mod:`core.decisions.groups`)."""
    from core.decisions import groups

    return sorted(groups.collapse(cards, titles), key=_rank_key)


def _members(position: dict[str, Any]) -> list[str]:
    group = position.get("group")
    if isinstance(group, dict):
        return [str(m["id"]) for m in group.get("members") or []]
    return [str(position["id"])]


def _kind_of(card_id: str) -> str:
    return str(card_id).partition(":")[0]


def week_view(
    cards: list[dict[str, Any]],
    errors: dict[str, str],
    *,
    now: datetime,
    more: bool = False,
    store: FlowStore | None = None,
    titles: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Пакет недели: ``{cards: [позиции], week: {...}}``.

    ``cards`` - ВСЕ видимые карточки очереди (с ``priority``); ``errors`` - виды, что не прочитались
    (их позиции не считаются решенными); ``more`` - добрать следующую порцию в пакет; ``titles`` -
    заголовки хабов для подписей групп."""
    from core.decisions import groups
    from core.metrics import record_event

    store = store or FlowStore.load()
    size = week_size()
    wk = iso_week(now)
    by_id = {c["id"]: c for c in cards}
    ranked = _positions(cards, titles)
    fixed_now = extended_now = 0
    provisional = False
    persist = not errors   # вид не читается: пакет без него не фиксируем (он выпал бы навсегда)
    with store.locked():
        store = FlowStore.load(store.path)
        week = store.data.get("week")
        if not isinstance(week, dict) or week.get("id") != wk:
            picked = ranked[:size]
            week = {"id": wk, "fixed_at": _stamp(now), "size": size, "extended": 0,
                    "positions": [{"id": p["id"], "members": _members(p)} for p in picked]}
            store.data["week"] = week
            fixed_now = len(picked)
        elif more:
            taken = {m for pos in week["positions"] for m in pos["members"]}
            fresh = [p for p in ranked if not set(_members(p)) & taken][:size]
            week["positions"].extend({"id": p["id"], "members": _members(p)} for p in fresh)
            week["extended"] = int(week.get("extended") or 0) + len(fresh)
            extended_now = len(fresh)
        if (fixed_now or extended_now) and persist:
            store.save()
        elif fixed_now or extended_now:
            provisional = True             # не записано - не событие, состав пересоберется
            fixed_now = extended_now = 0
    shown: list[dict[str, Any]] = []
    done = unknown = 0
    live_members: set[str] = set()
    for pos in week["positions"]:
        live = [by_id[m] for m in pos["members"] if m in by_id]
        if not live:
            if any(_kind_of(m) in errors for m in pos["members"]):
                unknown += 1   # вид не прочитался: не «решено» и показать нечего
            else:
                done += 1
            continue
        live_members.update(c["id"] for c in live)
        grouped = groups.rebuild(live, titles) if groups.is_group_id(pos["id"]) else None
        shown.append(grouped or live[0])
    taken = {m for pos in week["positions"] for m in pos["members"]}
    outside = [p for p in ranked if not set(_members(p)) & taken]
    total = len(week["positions"])
    groups = sum(1 for c in shown if isinstance(c.get("group"), dict))
    info = {
        "id": wk, "fixed_at": week["fixed_at"], "size": int(week.get("size") or size),
        "total": total, "done": done, "left": total - done, "unknown": unknown,
        "groups": groups, "kinds": len({_kind_of(c["id"]) for c in shown}),
        "extended": int(week.get("extended") or 0), "more_available": len(outside),
        "provisional": provisional,
    }
    if fixed_now or extended_now:
        record_event("queue_week", week=wk, size=fixed_now or extended_now, groups=groups,
                     kinds=info["kinds"], phase="fixed" if fixed_now else "extended")
    return {"cards": shown, "week": info, "members": sorted(live_members)}


# --------------------------------------------------------------------------- #
# Бюджет выпуска и запас                                                        #
# --------------------------------------------------------------------------- #
def budgets() -> dict[str, int | None]:
    """Недельный бюджет новых карточек по видам: дефолты ``lint=15,gold=10,memory=5`` +
    ``DT_QUEUE_BUDGET``.

    Формат ``вид=число`` через запятую; ``вид=off`` (или ``none``/отрицательное) - без бюджета;
    вид, которого нет в списке и в дефолтах, бюджета не имеет (``None``). Мусор пропускается."""
    out: dict[str, int | None] = dict(BUDGET_DEFAULTS)
    for part in (os.environ.get(BUDGET_ENV) or "").split(","):
        name, sep, raw = part.partition("=")
        name, raw = name.strip().lower(), raw.strip().lower()
        if not name or not sep:
            continue
        if raw in ("off", "none", "unlimited", "-1"):
            out[name] = None
        elif raw.isdigit():
            out[name] = int(raw)
    return out


def _parse(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=UTC)


def _first_seen(card: dict[str, Any], prev_scan: datetime | None, now: datetime) -> str:
    """Когда карточка появилась: ``since`` карточки, если он после прошлого скана этого вида (пришла
    между сканами), иначе - сейчас (``since`` у старых/возвращенных карточек не момент прихода)."""
    since = _parse(card.get("since"))
    if since is not None and since <= now and (prev_scan is None or since >= prev_scan):
        return _stamp(since)
    return _stamp(now)


def apply_budget(
    pages: dict[str, list[dict[str, Any]]],
    *,
    now: datetime,
    store: FlowStore | None = None,
    write: bool = True,
) -> dict[str, list[dict[str, Any]]]:
    """Сверить реестр с карточками прочитанных видов и вернуть ЗАПАС: ``{вид: [карточки]}``.

    ``pages`` - ВСЕ ждущие карточки каждого прочитанного вида (``{вид: [карточка]}``; вид с ошибкой
    чтения сюда не попадает - его реестр не трогается). Карточки запаса помечаются ``reserve: True``
    и возвращаются отдельно от видимых: вызывающий убирает их из выдачи. Побочный эффект - запись
    реестра в ``queue_flow.json`` (``write=False`` - только посчитать)."""
    store = store or FlowStore.load()
    week = iso_week(now)
    plan = budgets()
    stamp = _stamp(now)
    reserve: dict[str, list[dict[str, Any]]] = {}
    with store.locked():
        fresh = FlowStore.load(store.path)
        reg: dict[str, dict[str, Any]] = fresh.data.setdefault("cards", {})
        scanned: dict[str, str] = fresh.data.setdefault("scanned", {})
        changed = False
        for kind, cards in pages.items():
            prev_scan = _parse(scanned.get(kind))
            baseline = kind not in scanned
            live = {c["id"]: c for c in cards}
            for cid, card in live.items():
                row = reg.get(cid)
                if row is None:
                    first = _first_seen(card, None if baseline else prev_scan, now)
                    reg[cid] = {"k": kind, "fs": first, "st": "v" if baseline else "r",
                                "aw": None, "gone": None}
                    changed = True
                elif row.get("gone"):
                    row["gone"] = None   # вернулась (отложенная/снятая и снова ждет)
                    changed = True
            for cid, row in reg.items():
                if row.get("k") == kind and cid not in live and not row.get("gone"):
                    row["gone"] = stamp
                    changed = True
            limit = plan.get(kind)
            waiting = sorted(
                (cid for cid, row in reg.items()
                 if row.get("k") == kind and row.get("st") == "r" and cid in live),
                key=lambda cid: (str(reg[cid].get("fs") or ""), cid))
            used = sum(1 for row in reg.values()
                       if row.get("k") == kind and row.get("st") == "v" and row.get("aw") == week)
            room = len(waiting) if limit is None else max(0, limit - used)
            for cid in waiting[:room]:
                reg[cid].update(st="v", aw=week)
                changed = True
            held = [live[cid] for cid in waiting[room:]]
            if held:
                reserve[kind] = [{**c, "reserve": True} for c in held]
            scanned[kind] = stamp
            changed = True
        cutoff = _stamp(now - timedelta(days=GONE_KEEP_DAYS))
        for cid in [c for c, r in reg.items() if r.get("gone") and str(r["gone"]) < cutoff]:
            del reg[cid]
            changed = True
        if changed and write:
            fresh.save()
    return reserve


def reserve_counts(store: FlowStore | None = None) -> dict[str, int]:
    """``{вид: в запасе}`` по реестру на диске (read-only; ушедшие не считаются)."""
    store = store or FlowStore.load()
    out: dict[str, int] = {}
    for row in (store.data.get("cards") or {}).values():
        if row.get("st") == "r" and not row.get("gone"):
            out[row["k"]] = out.get(row["k"], 0) + 1
    return out


def arrivals(since: datetime, until: datetime, store: FlowStore | None = None) -> int:
    """Сколько карточек пришло в ``[since, until)`` по реестру (первое появление; read-only)."""
    store = store or FlowStore.load()
    n = 0
    for row in (store.data.get("cards") or {}).values():
        fs = _parse(row.get("fs"))
        if fs is not None and since <= fs < until:
            n += 1
    return n
