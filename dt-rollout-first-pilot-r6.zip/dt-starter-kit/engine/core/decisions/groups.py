"""USE-LOOP-1 п.3 - групповые карточки: однотипные карточки с ОДНИМ предлагаемым решением.

Группа - не новый вид в реестре и не стор: это представление поверх карточек очереди. Она собирается
из видимых карточек по ключу правила (:data:`RULES`), получает id ``group:<вид>:<ключ>``, число
участников, список участников и те же действия, что у участников (общие по имени и по
спецификации параметров). Решение группы - :func:`core.decisions.registry.decide_many`: то же
``decide`` по каждой карточке с одними ``action``/``params`` (обходных записей в сторы нет);
исключить отдельную карточку можно до решения - пульт шлет только отмеченные id.

**Правила и ключи** (минимум участников - :data:`GROUP_MIN`, дефолт 2; один участник - обычная
карточка):

* ``lint:orphan`` - ключ: ЛУЧШИЙ кандидат хаба (``meta.candidates[0]``); одно решение
  ``attach`` с ``hub_id`` = этот хаб (параметр в группе фиксирован, выбора нет);
* ``lint:hub_stale`` - ключ: хаб (``subject``);
* ``alias`` - ключ: хаб (``meta.hub_id``);
* ``gold`` - ключ: «вид ожидания» = инструмент поиска + что ждем (хаб/заметка) + где сегодня
  (топ-5 / глубже / нет в выдаче); ``accept`` в группе - без ``expected_ids`` (принимается ожидание
  каждой карточки как предложено), список ожидания правится по одной карточке.

``hub_stale`` и ``alias`` по построению детекторов - одна карточка на хаб, поэтому групп из них
сегодня не будет: правило объявлено по ТЗ и сработает, когда у хаба появится несколько карточек.

Карточки, у которых нет общего действия, в группу не собираются. ``priority`` группы - максимум по
участникам, ``why_now`` - у лучшего участника. ``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import copy
import hashlib
import json
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "GROUP_MIN",
    "GROUP_PREFIX",
    "RULES",
    "Rule",
    "build_group",
    "collapse",
    "group_id",
    "is_group_id",
    "rebuild",
    "rule_of",
]

GROUP_MIN = 2
GROUP_PREFIX = "group:"


def is_group_id(value: str) -> bool:
    return str(value or "").startswith(GROUP_PREFIX)


def group_id(kind: str, key: str) -> str:
    """``group:<вид>:<ключ>`` (ключ может сам содержать ``:``)."""
    return f"{GROUP_PREFIX}{kind}:{key}"


def _meta(card: dict[str, Any]) -> dict[str, Any]:
    return card.get("meta") or {}


def _orphan_key(card: dict[str, Any]) -> str | None:
    cands = _meta(card).get("candidates") or []
    hub = (cands[0] or {}).get("hub_id") if cands else None
    return f"orphan:{hub}" if hub else None


def _hub_stale_key(card: dict[str, Any]) -> str | None:
    subject = _meta(card).get("subject")
    return f"hub_stale:{subject}" if subject else None


def _alias_key(card: dict[str, Any]) -> str | None:
    hub = _meta(card).get("hub_id")
    return str(hub) if hub else None


def _gold_key(card: dict[str, Any]) -> str | None:
    meta = _meta(card)
    expected = meta.get("expected") or []
    if not expected:
        return None
    what = "hub" if all(e.get("is_hub") for e in expected) else "note"
    rank = meta.get("today_rank")
    where = "none" if rank is None else ("top5" if int(rank) <= 5 else "deep")
    return f"{meta.get('tool') or 'search'}:{what}:{where}"


def _orphan_title(key: str, size: int, hub_title: str) -> str:
    return f"Заметки без хаба: {size}, лучший кандидат - {hub_title}"


@dataclass(frozen=True)
class Rule:
    """Правило группировки: какие карточки, по какому ключу, какие параметры общие."""

    kind: str
    rule: str | None                      # правило линта (``meta.rule``) либо ``None``
    key: Callable[[dict[str, Any]], str | None]
    title: Callable[[str, int, str], str]
    why: str                              # «одно решение: …» в строке причины
    fixed: dict[str, dict[str, Callable[[str], str]]] = field(default_factory=dict)
    drop: dict[str, tuple[str, ...]] = field(default_factory=dict)

    def matches(self, card: dict[str, Any]) -> bool:
        if card.get("kind") != self.kind:
            return False
        return self.rule is None or _meta(card).get("rule") == self.rule


RULES: tuple[Rule, ...] = (
    Rule("lint", "orphan", _orphan_key, _orphan_title, "привязать к лучшему кандидату хаба",
         fixed={"attach": {"hub_id": lambda key: key.partition(":")[2]}}),
    Rule("lint", "hub_stale", _hub_stale_key,
         lambda key, n, hub: f"Хаб устарел: {n} карточек по хабу {hub}", "одно решение по хабу"),
    Rule("alias", None, _alias_key,
         lambda key, n, hub: f"Алиасы хаба {hub}: {n} карточек", "одно решение по хабу"),
    Rule("gold", None, _gold_key,
         lambda key, n, hub: f"В золотой набор? {n} однотипных запросов ({key})",
         "одно решение по однотипным запросам", drop={"accept": ("expected_ids",)}),
)


def rule_of(card: dict[str, Any]) -> Rule | None:
    return next((r for r in RULES if r.matches(card)), None)


def _spec_eq(a: Any, b: Any) -> bool:
    return json.dumps(a, sort_keys=True, ensure_ascii=False) == json.dumps(
        b, sort_keys=True, ensure_ascii=False)


def _common_actions(members: list[dict[str, Any]], rule: Rule, key: str) -> list[dict[str, Any]]:
    """Действия, общие для всех участников: имя и спецификация параметров (после правил группы)."""
    first = members[0]
    out: list[dict[str, Any]] = []
    for act in first.get("actions") or []:
        name = act["action"]
        per_member = []
        for m in members:
            found = next((a for a in m.get("actions") or [] if a["action"] == name), None)
            if found is None:
                per_member = []
                break
            per_member.append(found)
        if not per_member:
            continue
        shaped = []
        for a in per_member:
            params = copy.deepcopy(a.get("params") or {})
            for p in rule.drop.get(name, ()):
                params.pop(p, None)
            for p, make in rule.fixed.get(name, {}).items():
                value = make(key)
                label = next((o.get("label") for o in (params.get(p) or {}).get("options") or []
                              if o.get("value") == value), None)
                params[p] = {"type": "select", "required": True, "default": value,
                             "options": [{"value": value, "label": label or value}]}
            shaped.append(params)
        if not all(_spec_eq(shaped[0], p) for p in shaped[1:]):
            continue   # параметры у участников разные - общего действия нет
        group_act = copy.deepcopy(act)
        group_act["params"] = shaped[0]
        out.append(group_act)
    return out


def _group_rev(members: list[dict[str, Any]]) -> str | None:
    """Отпечаток состава группы: ``rev`` участников (PULT-UX-2 п.5). ``None`` - ревизий нет."""
    pairs = sorted((str(c["id"]), str(c.get("rev") or "")) for c in members)
    if not any(rev for _, rev in pairs):
        return None
    blob = json.dumps(pairs, ensure_ascii=False)
    return hashlib.sha1(blob.encode("utf-8")).hexdigest()[:12]  # noqa: S324 - не криптография


def build_group(
    rule: Rule, key: str, members: list[dict[str, Any]], hub_title: str = ""
) -> dict[str, Any] | None:
    """Карточка группы из участников (``None`` - общих действий нет: группы не будет)."""
    members = sorted(members, key=lambda c: (-float(c.get("priority") or 0.0), str(c["id"])))
    actions = _common_actions(members, rule, key)
    if not actions:
        return None
    best = members[0]
    hub = hub_title or key.partition(":")[2] or key
    since = min((str(c["since"]) for c in members if c.get("since")), default=None)
    return {
        "id": group_id(rule.kind, key),
        "kind": rule.kind,
        "title": rule.title(key, len(members), hub),
        "reason": f"{len(members)} однотипных · {rule.why}",
        "since": since,
        "meta": {"group_key": key, "rule": rule.rule, "hub_id": key.partition(":")[2] or None},
        "actions": actions,
        "explainable": False,
        "priority": float(best.get("priority") or 0.0),
        "why_now": str(best.get("why_now") or ""),
        "rev": _group_rev(members),
        "group": {
            "key": key, "size": len(members), "of": rule.kind,
            "members": [{"id": c["id"], "title": c["title"], "reason": c.get("reason") or "",
                         "since": c.get("since"), "why_now": c.get("why_now") or "",
                         "rev": c.get("rev")}
                        for c in members],
        },
    }


def collapse(
    cards: list[dict[str, Any]], titles: dict[str, str] | None = None
) -> list[dict[str, Any]]:
    """Позиции из карточек: группы (``>= GROUP_MIN`` участников с общим действием) и одиночки.

    Порядок не гарантируется - его задает вызывающий (по ``priority``)."""
    titles = titles or {}
    buckets: dict[tuple[str, str], list[dict[str, Any]]] = {}
    order: list[tuple[str, str] | str] = []
    for card in cards:
        rule = rule_of(card)
        key = rule.key(card) if rule else None
        if rule is None or key is None:
            order.append(card["id"])
            continue
        slot = (rule.kind + ":" + str(rule.rule), key)
        if slot not in buckets:
            order.append(slot)
        buckets.setdefault(slot, []).append(card)
    by_id = {c["id"]: c for c in cards}
    out: list[dict[str, Any]] = []
    for item in order:
        if isinstance(item, str):
            out.append(by_id[item])
            continue
        members = buckets[item]
        rule = rule_of(members[0])
        group = None
        if rule is not None and len(members) >= GROUP_MIN:
            hub = item[1].partition(":")[2] or item[1]
            group = build_group(rule, item[1], members, titles.get(hub, ""))
        out.extend([group] if group else members)
    return out


def rebuild(
    members: list[dict[str, Any]], titles: dict[str, str] | None = None
) -> dict[str, Any] | None:
    """Карточка группы из ЖИВЫХ участников зафиксированной позиции (``None`` - не группа)."""
    if len(members) < 2:
        return None
    rule = rule_of(members[0])
    key = rule.key(members[0]) if rule else None
    if rule is None or key is None:
        return None
    hub = key.partition(":")[2] or key
    return build_group(rule, key, members, (titles or {}).get(hub, ""))
