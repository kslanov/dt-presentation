"""USE-LOOP-1 п.1 - приоритет карточки очереди: близость к работе К., вес вида, возраст.

Каждой карточке ``queue`` дописывает ``priority`` (число, больше - раньше) и ``why_now`` (короткая
причина: «сделка в работе: <хаб>», «встреча 18.11: <хаб>», «ждет 14 дн»). Это данные в контракте
карточки: пульт и MCP-клиент не знают ни видов, ни формулы.

**Формула** (лексикографическая по составу, одним числом)::

    priority = NEAR_BONUS * близость + вес_вида + возраст

* ``близость`` = 1, если карточка относится к хабу АКТИВНОЙ сделки К. (кольцо ``mine`` + «слежу»,
  стадия не терминальная) либо к хабу встречи в ближайшие ``MEETING_DAYS`` (7) дней; иначе 0.
  Карточка кандидата в хаб ``hub`` от сделки Timetta (``meta.deal``) близка, когда эта сделка
  активна: хаба у нее еще нет, а сигнал - есть.
* ``вес_вида``: противоречие фактов 90 > хаб устарел 80 > кандидат в хаб/алиас 70 > orphan 60 >
  золотой набор 50 > прочее 40 (таблица :data:`WEIGHTS`, данные, не код).
* ``возраст`` = дни ожидания (с ``since``), потолок ``AGE_CAP_DAYS``, шкала 0..9 (меньше шага
  веса: вес вида важнее возраста, возраст разводит карточки одного вида).

**Откуда сигналы** (те же механизмы, что у вкладки «Работа» и ``hub_synth_context``, нового
сопоставления нет): активные сделки - зеркало Timetta (``orbit.visible`` + ``work._is_active``),
сделка → хаб - ``hub_collect.clients_of`` по тексту «организация + имя» и ``timetta_id`` хаба
(guid сделки или организации); встречи - кэш календаря ``meetings.cached`` (его ``clients`` плюс
``_resolve_clients`` по каталогу хабов); карточка → хаб: ``meta.hub_id``, иначе хаб заметки
``subject`` (frontmatter ``client``/``project``; ``subject`` правила линта, который сам является
хабом, - он же), иначе нет.

**Сбой сигнала не роняет очередь и не врет.** Коннектор выключен (``DT_CONNECTORS``), зеркало или
кэш встреч недоступны, кэш встреч старше порога (``stale``) - этот сигнал молча пропускается:
приоритет считается без него, ``why_now`` не называет сделку/встречу, которых не видели.
``core`` ⊥ mcp/cli; ни сети, ни LLM; на диске ничего не пишется.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "AGE_CAP_DAYS",
    "MEETING_DAYS",
    "NEAR_BONUS",
    "WEIGHTS",
    "Signals",
    "annotate",
    "load_signals",
    "kind_weight",
]

NEAR_BONUS = 1000.0
MEETING_DAYS = 7
AGE_CAP_DAYS = 90
DEFAULT_WEIGHT = 40
# Ключ: ``<вид>`` или ``<вид>:<правило линта>`` (точнее - сильнее). Остальное - DEFAULT_WEIGHT.
WEIGHTS: dict[str, int] = {
    "lint:fact_conflict": 90,   # противоречие фактов
    "lint:hub_stale": 80,       # хаб устарел
    "hub": 70,                  # кандидат в хаб
    "alias": 70,                # кандидат в алиасы
    "lint:orphan": 60,
    "gold": 50,                 # золотой набор
    "memory": 55,               # SLEEP-STORE-1: предложение Сна изменить память (выше золотого)
}

_WIKILINK = re.compile(r"\[\[([^\[\]|]+?)(?:\|[^\]]*)?\]\]")
_TT_RE = re.compile(r"^timetta_id:\s*[\"']?([^\s\"'#]+)", re.MULTILINE)
_HUB_MEMO: dict[tuple[str, int, int], dict[str, Any]] = {}


def kind_weight(card: dict[str, Any]) -> int:
    """Вес вида карточки (для lint - по правилу ``meta.rule``)."""
    kind = str(card.get("kind") or "")
    rule = str((card.get("meta") or {}).get("rule") or "")
    return WEIGHTS.get(f"{kind}:{rule}") or WEIGHTS.get(kind) or DEFAULT_WEIGHT


def _day(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)


def age_days(card: dict[str, Any], now: datetime) -> int | None:
    """Целые дни ожидания карточки; ``None`` - даты нет (или она в будущем и не читается)."""
    since = _day(card.get("since"))
    if since is None:
        return None
    return max(0, (now - since).days)


@dataclass
class Signals:
    """Что известно о близости хабов к работе на момент ``now`` (пусто - сигнала нет)."""

    titles: dict[str, str] = field(default_factory=dict)          # hub_id -> заголовок
    deals: dict[str, list[dict[str, Any]]] = field(default_factory=dict)      # hub_id -> сделки
    deal_codes: dict[str, dict[str, Any]] = field(default_factory=dict)       # code -> сделка
    meetings: dict[str, list[dict[str, Any]]] = field(default_factory=dict)   # hub_id -> встречи
    status: dict[str, str] = field(default_factory=dict)  # deals|meetings -> ok|off|unavailable
    _metas: list[Any] | None = None     # срезы frontmatter vault (один обход на расчет сигналов)
    _notes: dict[str, tuple[str, ...]] | None = None

    def note_hubs(self, note_id: str) -> tuple[str, ...]:
        """Хабы заметки: ``client``/``project`` ее frontmatter (ленивый снимок frontmatter)."""
        if self._notes is None:
            self._notes = {}
            for meta in self._metas or []:
                ids: list[str] = []
                for text in meta.texts(("client", "project")):
                    hit = _WIKILINK.search(text)
                    ids.append((hit.group(1) if hit else text).strip())
                if ids:
                    self._notes[meta.id] = tuple(dict.fromkeys(i for i in ids if i))
        return self._notes.get(str(note_id), ())

    def card_hubs(self, card: dict[str, Any]) -> list[str]:
        """Хабы карточки: ``meta.hub_id``, иначе хаб заметки ``subject`` (линт), иначе ``[]``."""
        meta = card.get("meta") or {}
        found: list[str] = []
        hub_id = meta.get("hub_id")
        if isinstance(hub_id, str) and hub_id.strip():
            found.append(hub_id.strip())
        elif card.get("kind") == "memory":
            # SLEEP-STORE-1: область утверждения (area) совпала с id известного хаба
            for ref in (meta.get("area"), *[c.get("area") for c in meta.get("after") or []]):
                ref = str(ref or "").strip()
                if ref and ref in self.titles:
                    found.append(ref)
        elif card.get("kind") == "lint":
            for ref in (meta.get("subject"), meta.get("note_id")):
                ref = str(ref or "").strip()
                if not ref:
                    continue
                found.extend([ref] if ref in self.titles else self.note_hubs(ref))
        return list(dict.fromkeys(found))

    def near(self, card: dict[str, Any]) -> dict[str, Any] | None:
        """Ближайшая работа, к которой относится карточка: ``{kind, label, ...}`` либо ``None``.

        Сделка в работе сильнее встречи; из встреч - ближайшая."""
        hubs = self.card_hubs(card)
        for hub in hubs:
            if self.deals.get(hub):
                deal = self.deals[hub][0]
                return {"kind": "deal", "hub_id": hub, "code": deal.get("code"),
                        "label": self.titles.get(hub) or deal.get("name") or hub}
        deal_ref = ((card.get("meta") or {}).get("deal") or {}) if card.get("kind") == "hub" else {}
        code = str(deal_ref.get("code") or "") if isinstance(deal_ref, dict) else ""
        if code and code in self.deal_codes:
            hit = self.deal_codes[code]
            return {"kind": "deal", "hub_id": None, "code": code,
                    "label": str(hit.get("name") or code)}
        best: tuple[int, str, str] | None = None
        for hub in hubs:
            for meeting in self.meetings.get(hub, ()):
                key = (int(meeting["days"]), str(meeting["day"]), hub)
                if best is None or key < best:
                    best = key
        if best is not None:
            days, day, hub = best
            return {"kind": "meeting", "hub_id": hub, "day": day, "days": days,
                    "label": self.titles.get(hub) or hub}
        return None


def _hub_card(vault: Path, rel: str) -> dict[str, Any] | None:
    """Хаб для сопоставления (``meetings._read_hub`` + ``timetta_id``), с памятью по ``stat``."""
    from core.operational import meetings

    path = vault / rel
    try:
        st = path.stat()
    except OSError:
        return None
    key = (str(path), st.st_mtime_ns, st.st_size)
    hit = _HUB_MEMO.get(key)
    if hit is not None:
        return hit
    card = meetings._read_hub(path)
    if not card.get("id"):
        return None
    try:
        head = path.read_text(encoding="utf-8", errors="ignore")[:4000]
        tt = _TT_RE.search(head)
    except OSError:
        tt = None
    card = {**card, "timetta_id": tt.group(1) if tt else ""}
    if len(_HUB_MEMO) > 2000:
        _HUB_MEMO.clear()
    _HUB_MEMO[key] = card
    return card


def _connector_on(name: str) -> bool:
    try:
        from core import connectors

        return bool(connectors.enabled(name))
    except Exception:  # noqa: BLE001 - не удалось спросить: сигнал не используем
        return False


def _load_deals(sig: Signals, env: Any, hubs: list[dict[str, Any]]) -> None:
    from core.operational import hub_collect, orbit, work
    from core.operational.timetta.mirror import MirrorStore

    store = MirrorStore(env.mirror_path())
    deals = orbit.visible(store.all("deals"))   # кольцо mine (+ «слежу»), без удаленных
    code_by_id = work._state_code_map(store)
    by_tt: dict[str, list[str]] = {}
    for hub in hubs:
        if hub.get("timetta_id"):
            by_tt.setdefault(str(hub["timetta_id"]), []).append(hub["id"])
    for deal in deals:
        code = str(deal.get("code") or "").strip()
        if not code or not work._is_active(deal, code_by_id):
            continue
        ref = {"code": code, "name": deal.get("name")}
        sig.deal_codes[code[:24]] = ref
        text = f"{deal.get('organization_name') or ''} {deal.get('name') or ''}"
        ids = set(hub_collect.clients_of(text, hubs))
        for guid in (deal.get("id"), deal.get("organization_id")):
            ids.update(by_tt.get(str(guid or ""), ()))
        for hub_id in sorted(ids):
            sig.deals.setdefault(hub_id, []).append(ref)


def _load_meetings(sig: Signals, env: Any, now: datetime, hubs: list[dict[str, Any]]) -> str:
    from core.operational import meetings

    res = meetings.cached(MEETING_DAYS, now=now, cache_path=env.meetings_cache)
    if res.get("status") in ("no_cache", "store_unavailable") or res.get("stale") is not False:
        return "unavailable"   # нет кэша, кэш битый или несвежий: встречам не верим
    today = now.date()
    for item in res.get("meetings") or []:
        day = str(item.get("start") or "")[:10]
        try:
            days = (datetime.fromisoformat(day).date() - today).days
        except ValueError:
            continue
        if not 0 <= days <= MEETING_DAYS:
            continue
        ids = {str(c.get("id")) for c in item.get("clients") or [] if isinstance(c, dict)}
        ids.update(c["id"] for c in meetings._resolve_clients(
            list(item.get("counterparty_domains") or []), str(item.get("subject") or ""), hubs))
        for hub_id in sorted(i for i in ids if i):
            sig.meetings.setdefault(hub_id, []).append(
                {"day": day, "days": days, "subject": str(item.get("subject") or "")})
    return "ok"


def load_signals(
    env: Any, now: datetime | None = None, *,
    load_metas: Callable[[Path], tuple[list[Any], list[Any]]] | None = None,
) -> Signals:
    """Собрать сигналы близости. Каждый источник изолирован: сбой одного не мешает другому.

    ``load_metas`` подменяет загрузчик срезов frontmatter (по умолчанию - кэшируемый, он при
    изменении набора ПИШЕТ кэш на диск): план Сна без ``--apply`` передает читающий без записи."""
    now = now or env.utcnow()
    sig = Signals()
    hubs: list[dict[str, Any]] = []
    try:
        from core.retrieval.fm_cache import load_metas_cached
        from core.retrieval.hubcat import build_catalog

        vault = env.vault_path()
        metas_loader = load_metas or load_metas_cached
        metas, _warnings = metas_loader(Path(vault))   # один обход vault на весь расчет
        sig._metas = metas
        for entry in build_catalog(metas, None):
            sig.titles[entry.note_id] = (entry.h1 or "").strip() or entry.note_id
            card = _hub_card(vault, entry.path) if entry.path else None
            if card:
                hubs.append(card)
    except Exception as exc:  # noqa: BLE001 - без каталога сигналы по хабам пусты, очередь жива
        logger.warning("каталог хабов для приоритета не прочитан: %s", exc)
    for name, connector, loader in (
        ("deals", "timetta", lambda: _load_deals(sig, env, hubs)),
        ("meetings", "outlook", lambda: _load_meetings(sig, env, now, hubs)),
    ):
        if not _connector_on(connector):
            sig.status[name] = "off"
            continue
        try:
            sig.status[name] = loader() or "ok"
        except Exception as exc:  # noqa: BLE001 - сбой сигнала не роняет очередь
            logger.warning("сигнал близости %s не прочитан: %s", name, exc)
            sig.status[name] = "unavailable"
            if name == "deals":
                sig.deals.clear()
                sig.deal_codes.clear()
            else:
                sig.meetings.clear()
    return sig


def _ru_day(day: str) -> str:
    return f"{day[8:10]}.{day[5:7]}"


def annotate(cards: list[dict[str, Any]], env: Any, now: datetime | None = None) -> Signals | None:
    """Дописать ``priority`` и ``why_now`` каждой карточке (на месте). Не бросает.

    Возвращает использованные сигналы (``None`` - сигналы не собирались: сбой целиком)."""
    now = now or env.utcnow()
    try:
        sig: Signals | None = load_signals(env, now)
    except Exception as exc:  # noqa: BLE001 - любой сбой: приоритет без близости
        logger.warning("сигналы близости не собраны: %s", exc)
        sig = None
    for card in cards:
        near = None
        if sig is not None:
            try:
                near = sig.near(card)
            except Exception as exc:  # noqa: BLE001
                logger.warning("близость карточки %s не определена: %s", card.get("id"), exc)
        age = age_days(card, now)
        score = (NEAR_BONUS if near else 0.0) + kind_weight(card)
        score += round(min(age or 0, AGE_CAP_DAYS) * 9.0 / AGE_CAP_DAYS, 2)
        card["priority"] = round(score, 2)
        if near and near["kind"] == "deal":
            card["why_now"] = f"сделка в работе: {near['label']}"
        elif near:
            card["why_now"] = f"встреча {_ru_day(near['day'])}: {near['label']}"
        elif age is None:
            card["why_now"] = ""
        else:
            card["why_now"] = f"ждет {age} дн" if age >= 1 else "пришла сегодня"
    return sig
