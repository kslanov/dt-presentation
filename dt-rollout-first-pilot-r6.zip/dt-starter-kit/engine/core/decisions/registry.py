"""QUEUE-SERVER-1 — реестр видов карточек очереди решений: один контракт, один list/decide/explain.

Решение человека - это КАРТОЧКА реестра. Вид (``CardKind``) умеет три вещи: отдать свои карточки
единой формы, принять решение ``(id, action, params)`` и объяснить «почему». Каждый вид - фасад над
своим готовым ядром (``decide_link``, ``decide_hub_candidate``, ``decide_hub_alias``,
``hub_synth.apply_card`` (HUB-SYNTH-1), ``decide_reattr``, ``decide_golden_candidate``,
``decide_assignment``, ``route_capture``, ``snooze_lead``/``reject_lead``):
ядро решений и сторы видов НЕ меняются, единого стора очереди нет. Новый детектор = новый вид в
реестре, а не новая пара инструментов MCP и не новый код в пульте.

**Карточка** (одной формы для всех видов)::

    {id: "<kind>:<native>", kind, title, reason, since, meta: {...поля вида},
     actions: [{action, label, style: primary|secondary|danger, params: {имя: {type, options?,
     default?, required?}}, confirm?, more?}], explainable: bool}

``params[имя].type``: ``select`` (``options: [{value, label, ...}]``; ``ui: "buttons"`` - по кнопке
на вариант) | ``multiselect`` (``options`` с ``selected``) | ``text``; ``more: true`` - виджет
параметра живет в раскрытии строки («ещё…»), ``label`` - подпись, ``allow_custom`` - можно ввести
свое значение.

**Исход** (одной формы)::

    {ok, outcome: applied|rejected|snoozed|routed|stale|refused, code?, detail, effects: [...],
     card_id, kind, action}

``effects`` - что реально сделано («хаб создан <путь>», «timetta_id записан»). ``stale`` - карточка
уже решена (не ошибка); ``refused`` - решение не принято, ничего не записано (``code``:
``unknown_card`` | ``bad_action`` | ``invalid_params`` | ``no_deal`` | ... из ядра вида).

**Аудит и телеметрия - здесь, в одном месте** (:func:`decide`): одна строка ``pult-actions.log``
(``pult_card_decide``: вид, id, действие, исход, хост/поверхность - БЕЗ текста карточки) и, если
решение состоялось (``applied|rejected|snoozed|routed``), событие метрик ``queue_decision``
(``card_kind``, ``decision``, ``host``). Ядра видов пишут и свои прежние события
(``hub_decision``/``link_decision``) - они сохраняются.

**Ревизия карточки** (PULT-UX-2 п.5): каждая карточка очереди несет ``rev`` - короткий отпечаток
содержимого, от которого зависит решение (вид, заголовок, мета без дрейфующих по времени счетчиков,
действия с параметрами; без ``reason``/``why_now``/``priority``/``since``). Пульт возвращает
``rev``, который видел человек, в ``decide(expected_rev=...)`` / ``decide_many(expected_revs=...)``:
если карточка изменилась или исчезла, исход - ``stale`` с кодом ``card_changed``/``card_gone``,
новая карточка и ``diff`` в ответе, а в сторы НИЧЕГО не пишется (тихой перезаписи нет). Без
``expected_rev`` поведение прежнее.

``core`` ⊥ mcp/cli; ни сети, ни LLM. Что зависит от слоя MCP (проба «сегодняшней выдачи» для
eval-кандидатов), приходит инъекцией через :class:`QueueEnv`.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "ActionSpec",
    "CardKind",
    "KindPage",
    "KindUnavailable",
    "QueueEnv",
    "STYLES",
    "OUTCOMES",
    "DECIDED_OUTCOMES",
    "card_id",
    "split_card_id",
    "get_registry",
    "kind_order",
    "queue",
    "VIEWS",
    "decide",
    "decide_many",
    "explain",
    "pending_totals",
    "card_rev",
    "card_diff",
]

STYLES = ("primary", "secondary", "danger")
OUTCOMES = ("applied", "rejected", "snoozed", "routed", "stale", "refused")
# Исходы, при которых решение СОСТОЯЛОСЬ (идет в метрики); stale/refused решением не считаются.
DECIDED_OUTCOMES = ("applied", "rejected", "snoozed", "routed")
_DECISION_OF = {"applied": "approved", "rejected": "rejected", "snoozed": "snoozed",
                "routed": "routed"}
AUDIT_TOOL = "pult_card_decide"
EVENT_KIND = "queue_decision"


class KindUnavailable(Exception):
    """Вид не смог прочитать свой стор: ``code`` уходит в ``errors[kind]`` (ошибка ≠ пусто)."""

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(detail or code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class ActionSpec:
    """Действие над карточкой вида: кнопка + параметры, которые она принимает."""

    action: str
    label: str
    style: str = "secondary"
    params: dict[str, dict[str, Any]] = field(default_factory=dict)
    confirm: str = ""
    more: bool = False  # редкое действие: пульт прячет его в раскрытие строки («ещё…»)

    def to_dict(self, params: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
        out: dict[str, Any] = {
            "action": self.action,
            "label": self.label,
            "style": self.style,
            "params": dict(self.params if params is None else params),
        }
        if self.confirm:
            out["confirm"] = self.confirm
        if self.more:
            out["more"] = True
        return out


# --------------------------------------------------------------------------- #
# Ревизия карточки (PULT-UX-2 п.5): отпечаток содержимого, stale с diff           #
# --------------------------------------------------------------------------- #
# Поля меты, которые дрейфуют со временем сами по себе (возраст, дни активности): от них решение
# не зависит, и карточка не должна «меняться» каждый день.
REV_VOLATILE_META = frozenset({"age_days", "activity_days", "deadline_days", "reasons"})
REV_LEN = 12
_SNAP_MAX = 2000
# «card_id@rev» -> легкий снимок для diff
_SNAPSHOTS: OrderedDict[str, dict[str, Any]] = OrderedDict()
_DIFF_MAX = 12
_DIFF_CUT = 160


def _rev_meta(meta: Any) -> Any:
    return {k: v for k, v in (meta or {}).items() if k not in REV_VOLATILE_META} \
        if isinstance(meta, dict) else meta


def card_rev(card: dict[str, Any]) -> str:
    """Отпечаток содержимого карточки (``REV_LEN`` hex): меняется, когда меняется то, на что
    опирается решение (заголовок, мета, действия и их параметры), и НЕ меняется от времени
    (``reason``/``why_now``/``priority``/``since`` и счетчики дней в отпечаток не входят)."""
    material = {
        "kind": card.get("kind"), "title": card.get("title"), "meta": _rev_meta(card.get("meta")),
        "actions": [[a.get("action"), a.get("label"), a.get("params")]
                    for a in card.get("actions") or []],
    }
    blob = json.dumps(material, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha1(blob.encode("utf-8")).hexdigest()[:REV_LEN]  # noqa: S324 - не криптография


def _flat(value: Any) -> str:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False,
                                                           sort_keys=True, default=str)
    text = " ".join(str(text).split())
    return text if len(text) <= _DIFF_CUT else text[: _DIFF_CUT - 1] + "…"


def _snapshot(card: dict[str, Any]) -> dict[str, Any]:
    meta = _rev_meta(card.get("meta")) or {}
    return {
        "title": card.get("title"), "reason": card.get("reason"),
        "meta": {str(k): _flat(v) for k, v in meta.items()},
        "actions": [str(a.get("label") or a.get("action")) for a in card.get("actions") or []],
    }


def _remember(card: dict[str, Any]) -> None:
    key = f"{card['id']}@{card['rev']}"
    _SNAPSHOTS[key] = _snapshot(card)
    _SNAPSHOTS.move_to_end(key)
    while len(_SNAPSHOTS) > _SNAP_MAX:
        _SNAPSHOTS.popitem(last=False)


def card_diff(old: dict[str, Any] | None, new: dict[str, Any]) -> list[dict[str, str]] | None:
    """``[{field, before, after}]`` между снимком, который видел человек, и текущей карточкой;
    ``None`` - прежний снимок не сохранен (процесс перезапускался): новая карточка все равно
    в ответе."""
    if old is None:
        return None
    cur = _snapshot(new)
    rows: list[dict[str, str]] = []
    for name, label in (("title", "заголовок"), ("reason", "причина")):
        if old.get(name) != cur.get(name):
            rows.append({"field": label, "before": _flat(old.get(name) or "-"),
                         "after": _flat(cur.get(name) or "-")})
    for key in sorted(set(old.get("meta") or {}) | set(cur["meta"])):
        before, after = (old.get("meta") or {}).get(key), cur["meta"].get(key)
        if before != after:
            rows.append({"field": f"meta.{key}", "before": before if before is not None else "-",
                         "after": after if after is not None else "-"})
    if old.get("actions") != cur["actions"]:
        rows.append({"field": "действия", "before": ", ".join(old.get("actions") or []) or "-",
                     "after": ", ".join(cur["actions"]) or "-"})
    return rows[:_DIFF_MAX]


def _revise(cards: list[dict[str, Any]]) -> None:
    """Дописать ``rev`` карточкам (и участникам групп) и запомнить снимки для diff."""
    for card in cards:
        card["rev"] = card_rev(card)
        _remember(card)


def _find_card(kind: CardKind, env: QueueEnv, card: str) -> dict[str, Any] | None:
    """Текущая карточка вида по id (с ``rev``) или ``None``: читаем страницу вида целиком."""
    page = _list_page(kind, env, 0, False)
    for row in page.cards:
        if row.get("id") == card:
            found = dict(row)
            found["rev"] = card_rev(found)
            return found
    return None


def _stale_by_rev(
    kind: CardKind, env: QueueEnv, card: str, action: str, expected: str
) -> dict[str, Any] | None:
    """Исход ``stale``/``refused``, если карточка не совпала с версией, которую видел человек;
    ``None`` - совпала, решать можно."""
    try:
        current = _find_card(kind, env, card)
    except Exception as exc:  # noqa: BLE001 - не смогли сверить версию: решение НЕ принимается
        logger.warning("версия карточки %s не сверена: %s", card, exc)
        return _refused(card, action, "rev_unverified",
                        "версию карточки сверить не удалось - решение не принято, повторите",
                        kind.kind)
    if current is None:
        out = _outcome(kind.kind, card, action, outcome="stale", code="card_gone",
                       detail="карточки уже нет в очереди (решена или снята) - "
                              "решение не применено")
        out["rev"] = None
        return out
    if current["rev"] == expected:
        return None
    out = _outcome(kind.kind, card, action, outcome="stale", code="card_changed",
                   detail="карточка изменилась после загрузки - решение не применено, "
                          "проверьте новую версию")
    out["rev"] = current["rev"]
    out["card"] = current
    out["diff"] = card_diff(_SNAPSHOTS.get(f"{card}@{expected}"), current)
    return out


CACHE_PREFIX = "cards-"


@dataclass
class KindPage:
    """Результат ``CardKind.list``: карточки (не больше limit), сколько ждут всего, ошибка вида."""

    cards: list[dict[str, Any]]
    total: int
    error: str = ""  # код деградации; карточки при этом отдаются как есть (канон eval не читается)
    as_of: str = ""  # PULT-SURFACE-2: когда посчитан кэшируемый вид (gold); пусто - читается живьем


@dataclass
class QueueEnv:
    """Окружение видов: пути сторов и инъекции. Пусто - боевые значения из ``core.config``.

    Тесты подставляют пути фейковых сторов; боевой путь не нужен нигде, кроме конфигурации."""

    vault: Path | None = None
    link_proposals: Path | None = None
    reattr_proposals: Path | None = None
    hub_candidates: Path | None = None
    hub_alias_candidates: Path | None = None
    hub_synth: Path | None = None  # HUB-SYNTH-1: стор карточек «Состояние хаба?»
    lint_findings: Path | None = None  # KNOWLEDGE-LINT-1: стор находок линта (вид ``lint``)
    capture_state: Path | None = None
    inbox_dir: Path | None = None
    mirror: Path | None = None
    golden_candidates: Path | None = None
    eval_journal: Path | None = None
    golden_file: Path | None = None
    ripe_snooze: Path | None = None
    admin_email: str | None = None
    admin_email_set: bool = False  # True - admin_email задан явно (в т.ч. None), не читать из env
    # «Сегодняшняя выдача» для ранга eval-кандидата: зависит от слоя MCP (find_notes), инъекция.
    golden_probe: Callable[[str, dict[str, Any]], list[str]] | None = None
    # USE-LOOP-1: кэш встреч для близости к работе (пусто - боевой ``meetings_cache_path``)
    meetings_cache: Path | None = None
    # SLEEP-STORE-1: ledger Сна - dt.db (пусто - боевой ``dt_db_path``) и инъекции применителя
    # (хеши источников для CAS, точки имитации сбоя, индексатор): боевой код их не задает.
    sleep_db: Path | None = None
    sleep_source_hash: Callable[[str], str | None] | None = None
    sleep_hooks: dict[str, Callable[[], None]] | None = None
    sleep_indexer: Callable[[Path, str], None] | None = None
    now: datetime | None = None

    def vault_path(self) -> Path:
        from core.config import default_vault_path

        return Path(self.vault) if self.vault else default_vault_path()

    def hub_synth_file(self) -> Path:
        from core.config import hub_synth_path

        return Path(self.hub_synth) if self.hub_synth else hub_synth_path()

    def lint_findings_file(self) -> Path:
        from core.config import lint_findings_path

        return Path(self.lint_findings) if self.lint_findings else lint_findings_path()

    def capture_state_path(self) -> Path:
        if self.capture_state:
            return Path(self.capture_state)
        from core.config import ticktick_state_path

        return ticktick_state_path() / "capture_state.json"

    def inbox_path(self) -> Path:
        from core.config import staging_inbox_path

        return Path(self.inbox_dir) if self.inbox_dir else staging_inbox_path()

    def mirror_path(self) -> Path:
        from core.config import timetta_mirror_path

        return Path(self.mirror) if self.mirror else timetta_mirror_path()

    def admin(self) -> str | None:
        if self.admin_email_set:
            return self.admin_email
        from core.config import crm_admin_email

        return crm_admin_email()

    def utcnow(self) -> datetime:
        return self.now or datetime.now(UTC)

    def sleep_ctx(self) -> Any:
        """Контекст операций ledger Сна (:class:`core.sleep_store.ctx.Ctx`) для вида ``memory``."""
        from core.host import current_host
        from core.sleep_store.ctx import Ctx
        from core.sleep_store.store import now_iso

        return Ctx(
            vault=self.vault_path(), db_path=self.sleep_db, now=now_iso(self.utcnow()),
            host=str(current_host().get("name") or "cli"), source_hash=self.sleep_source_hash,
            hooks=dict(self.sleep_hooks or {}), indexer=self.sleep_indexer)


class CardKind:
    """Вид карточки. Подклассы лежат в :mod:`core.decisions.kinds`; здесь - контракт."""

    kind: str = ""
    label: str = ""  # подпись фильтра-чипа вкладки
    actions: tuple[ActionSpec, ...] = ()  # ВСЕ действия вида (допустимые имена decide)

    def spec(self, action: str) -> ActionSpec | None:
        return next((a for a in self.actions if a.action == action), None)

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        raise NotImplementedError

    def count(self, env: QueueEnv) -> int:
        """Сколько ждут решения (для доктора): без дорогих пересчетов и без записи в сторы."""
        return self.list(env, 0).total

    def cache_stamp(self, env: QueueEnv) -> Any:
        """Токен «от чего зависит выдача вида» (SURFACE-HYGIENE-1 п.3): mtime/размер сторов и
        каталога хабов. ``None`` - вид не кэшируется (читается живьем, как раньше). Выдача вида
        кэшируется
        тем же :func:`core.operational.snapshot.cached_read`, что в PULT-SURFACE-2:
        второго кэша нет."""
        return None

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        """Решение: ``{outcome, detail?, effects?, code?}`` - исходная форма вида приводится к
        единой в :func:`decide`. ``ValueError`` ядра (неизвестный id/решение) ловит диспетчер."""
        raise NotImplementedError

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        """«Почему» по карточке; ``None`` - вид не объясняется или карточки нет."""
        return None

    def explain_with(
        self, env: QueueEnv, native_id: str, params: dict[str, Any]
    ) -> dict[str, Any] | None:
        """«Почему» с параметрами (``pult_card_explain(card_id, params)``). По умолчанию параметры
        игнорируются; ``assignment`` собирает по ним черновик под выбранную сделку
        (SURFACE-HYGIENE-1)."""
        return self.explain(env, native_id)


# --------------------------------------------------------------------------- #
# Идентификаторы карточек                                                        #
# --------------------------------------------------------------------------- #
def card_id(kind: str, native_id: str) -> str:
    """Уникальный id карточки: ``<вид>:<родной id>`` (родной id может сам содержать ``:``)."""
    return f"{kind}:{native_id}"


def split_card_id(value: str) -> tuple[str, str]:
    """``"hub:abc"`` → ``("hub", "abc")``; нет префикса - ``("", value)``."""
    head, sep, tail = str(value or "").partition(":")
    return (head, tail) if sep else ("", str(value or ""))


# --------------------------------------------------------------------------- #
# Реестр                                                                         #
# --------------------------------------------------------------------------- #
_REGISTRY: dict[str, CardKind] | None = None
_REGISTRY_KINDS: tuple[str, ...] = ()


def get_registry() -> dict[str, CardKind]:
    """Реестр видов (порядок - порядок вкладки): создается лениво, один на процесс.

    DEV-3-CORE: состав видов зависит от коннекторов (``DT_CONNECTORS`` читается после
    ``load_env``, а реестр могли построить раньше) - реестр пересобирается, если набор видов
    манифеста сменился."""
    global _REGISTRY, _REGISTRY_KINDS
    from core.surface import manifest

    kinds = tuple(manifest.card_kinds())
    if _REGISTRY is None or kinds != _REGISTRY_KINDS:
        from core.decisions.kinds import build_kinds

        _REGISTRY = {k.kind: k for k in build_kinds()}
        _REGISTRY_KINDS = kinds
    return _REGISTRY


def kind_order() -> tuple[str, ...]:
    return tuple(get_registry())


def _error_code(exc: BaseException) -> str:
    if isinstance(exc, KindUnavailable):
        return exc.code
    return "store_unavailable" if isinstance(exc, OSError) else "error"


CARDS_TTL_ENV = "DT_PULT_CARDS_TTL_S"


def _list_page(kind: CardKind, env: QueueEnv, cap: int, refresh: bool) -> KindPage:
    """Страница вида: живьем либо из снимка (``cache_stamp`` != None): hub/alias/link считают
    ``similar_hubs``/алиасы/каталог (200-900 мс): второй вызов берет файл, пока сторы те же."""
    stamp = kind.cache_stamp(env)
    if stamp is None:
        return kind.list(env, cap, refresh=refresh)
    from core.operational.snapshot import cached_read, ttl_from_env

    def compute() -> dict[str, Any]:
        page = kind.list(env, cap, refresh=False)
        return {"cards": page.cards, "total": page.total, "error": page.error, "as_of": ""}

    payload, meta = cached_read(
        f"{CACHE_PREFIX}{kind.kind}-{cap}", ttl_from_env(CARDS_TTL_ENV, 600), compute, stamp=stamp)
    return KindPage(payload["cards"], int(payload["total"]), str(payload.get("error") or ""),
                    as_of=str(meta["as_of"]))


def _drop_cached_pages(kind: str) -> None:
    """Решение по карточке меняет сторы - снимки страниц вида устарели (stamp поймал бы позже)."""
    try:
        from core.operational.snapshot import invalidate

        invalidate(f"{CACHE_PREFIX}{kind}-")
    except Exception:  # noqa: BLE001, S110 - сброс снимка не должен ломать решение
        pass


VIEWS = ("week", "reserve")
# Виды, которых нет в пакете недели: у «Дозрели» своя секция пульта.
WEEK_SKIP_KINDS = ("ripe_lead",)


def _collect(
    env: QueueEnv, wanted: list[str], cap: int, refresh: bool
) -> tuple[list[dict[str, Any]], dict[str, int], dict[str, str], dict[str, int], dict[str, str]]:
    """Карточки видов ``wanted`` (``cap`` на вид, ``0`` - все): ``(cards, totals, errors, timings,
    as_of_kinds)``. Сбой вида - в ``errors``, остальные виды отдаются."""
    registry = get_registry()
    cards: list[dict[str, Any]] = []
    totals: dict[str, int] = {}
    errors: dict[str, str] = {}
    timings: dict[str, int] = {}
    as_of_kinds: dict[str, str] = {}
    for name in wanted:
        kind = registry.get(name)
        if kind is None:
            errors[name] = "unknown_kind"
            continue
        started = time.perf_counter()
        try:
            page = _list_page(kind, env, max(0, cap), bool(refresh))
        except Exception as exc:  # noqa: BLE001 - сбой вида не роняет остальные
            logger.warning("вид очереди %s не прочитан: %s", name, exc)
            errors[name] = _error_code(exc)
            timings[name] = int((time.perf_counter() - started) * 1000)
            continue
        timings[name] = int((time.perf_counter() - started) * 1000)
        if page.as_of:
            as_of_kinds[name] = page.as_of
        cards.extend(page.cards)
        totals[name] = page.total
        if page.error:
            errors[name] = page.error
    return cards, totals, errors, timings, as_of_kinds


def _split_reserve(
    cards: list[dict[str, Any]], totals: dict[str, int], env: QueueEnv
) -> dict[str, list[dict[str, Any]]]:
    """USE-LOOP-1 п.4: сверить реестр потока и вернуть ЗАПАС (``{вид: [карточки]}``, FIFO).

    Сбой реестра не роняет очередь: бюджет в этот раз не применяется (запаса нет)."""
    from core.decisions import flow

    pages = {k: [c for c in cards if c["kind"] == k] for k in totals}
    try:
        return flow.apply_budget(pages, now=env.utcnow())
    except Exception as exc:  # noqa: BLE001 - бюджет вторичен: очередь отдается целиком
        logger.warning("реестр потока очереди не сверен: %s", exc)
        return {}


def queue(
    env: QueueEnv | None = None,
    *,
    kinds: list[str] | None = None,
    limit: int = 50,
    refresh: bool = False,
    view: str | None = None,
    more: bool = False,
) -> dict[str, Any]:
    """Карточки очереди: ``{cards, totals: {kind: pending}, errors: {kind: code}, as_of}``.

    Сбой одного вида - в ``errors``, остальные виды отдаются («ошибка ≠ пусто» в контракте).
    ``limit`` - карточек НА ВИД (``<=0`` - все); ``totals`` - сколько ждут решения на самом деле
    (без запаса). ``refresh`` пересчитывает только ``gold`` (дорого: реранкер); без него ``gold``
    НИКОГДА не считается на чтении - отдается последний расчет (его ведет шаг ``eval`` ночной
    цепочки либо кнопка), ``as_of_kinds`` называет время расчета, ``timings`` - мс на каждый вид.

    Каждой карточке дописаны ``priority`` и ``why_now`` (:mod:`core.decisions.proximity`); порядок
    выдачи - по видам, как раньше.

    **Запас** (USE-LOOP-1 п.4, :mod:`core.decisions.flow`): новые карточки сверх недельного бюджета
    вида (``DT_QUEUE_BUDGET``) в выдачу и ``totals`` не входят, их число - ``reserve: {вид: n}``
    (ключа нет, пока запаса нет); сами карточки - ``view="reserve"`` (``reserve: true``, FIFO).

    ``view="week"`` - пакет недели: не больше ``DT_QUEUE_WEEK_SIZE`` позиций по ``priority`` из
    карточек ВСЕХ видов (``kinds``/``limit`` игнорируются), состав фиксируется при первом запросе
    ISO-недели; ``more=True`` добирает следующую порцию. Выдача та же по форме + ``week: {id,
    fixed_at, size, total, done, left, groups, kinds, extended, more_available}``.
    Другой ``view`` - ``ValueError``."""
    env = env or QueueEnv()
    if view is not None and view not in VIEWS:
        raise ValueError(f"неизвестный view {view!r}: допустимо {', '.join(VIEWS)}")
    registry = get_registry()
    if view == "week":
        wanted = [k for k in registry if k not in WEEK_SKIP_KINDS]
    else:
        wanted = list(kinds) if kinds else list(registry)
    cap = 0 if view == "week" else (int(limit) if limit else 0)
    cards, totals, errors, timings, as_of_kinds = _collect(env, wanted, 0, bool(refresh))
    titles = _annotate(cards, env)
    _revise(cards)  # PULT-UX-2 п.5: версия карточки для проверки при решении
    held = _split_reserve(cards, totals, env)
    held_ids = {c["id"] for rows in held.values() for c in rows}
    for name, rows in held.items():
        totals[name] = max(0, totals[name] - len(rows))
    if view == "reserve":
        shown_cards = [c for rows in held.values() for c in rows]
        totals = {name: len(rows) for name, rows in held.items()}
    else:
        shown_cards = [c for c in cards if c["id"] not in held_ids]
    if cap and view != "week":
        taken: dict[str, int] = {}
        capped = []
        for card in shown_cards:
            taken[card["kind"]] = taken.get(card["kind"], 0) + 1
            if taken[card["kind"]] <= cap:
                capped.append(card)
        shown_cards = capped
    out: dict[str, Any] = {
        "cards": shown_cards,
        "totals": totals,
        "errors": errors,
        "as_of": env.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "as_of_kinds": as_of_kinds,
        "timings": timings,
    }
    if held:
        out["reserve"] = {name: len(rows) for name, rows in held.items()}
    if view == "week":
        from core.decisions import flow

        packed = flow.week_view(
            shown_cards, errors, now=env.utcnow(), more=bool(more), titles=titles)
        out["cards"] = packed["cards"]
        out["week"] = packed["week"]
    return out


def _annotate(cards: list[dict[str, Any]], env: QueueEnv) -> dict[str, str]:
    """USE-LOOP-1 п.1: ``priority`` и ``why_now`` каждой карточке (:mod:`core.decisions.proximity`).

    Сбой сигнала близости не роняет очередь: карточки остаются как были, поля - без сигнала.
    Возвращает заголовки хабов (для подписей групп)."""
    from core.decisions import proximity

    try:
        sig = proximity.annotate(cards, env)
        return dict(sig.titles) if sig is not None else {}
    except Exception as exc:  # noqa: BLE001 - приоритет вторичен: очередь отдается всегда
        logger.warning("приоритет карточек не посчитан: %s", exc)
        for card in cards:
            card.setdefault("priority", float(proximity.kind_weight(card)))
            card.setdefault("why_now", "")
        return {}


def pending_totals(env: QueueEnv | None = None) -> tuple[dict[str, int], dict[str, str]]:
    """``({kind: ждут}, {kind: код ошибки})`` - для доктора: без пересчета eval-кандидатов.

    ``ждут`` - без запаса (карточки сверх недельного бюджета не входят в счетчик)."""
    env = env or QueueEnv()
    totals: dict[str, int] = {}
    errors: dict[str, str] = {}
    for name, kind in get_registry().items():
        try:
            totals[name] = kind.count(env)
        except Exception as exc:  # noqa: BLE001
            errors[name] = _error_code(exc)
    try:  # запас (USE-LOOP-1 п.4) в счетчик «требуют решения» не входит
        from core.decisions import flow

        for name, held in flow.reserve_counts().items():
            if name in totals:
                totals[name] = max(0, totals[name] - held)
    except Exception as exc:  # noqa: BLE001 - реестр потока недоступен: счет без поправки
        logger.warning("запас очереди не учтен в счетчике: %s", exc)
    return totals, errors


def _outcome(
    kind: str,
    card: str,
    action: str,
    *,
    outcome: str,
    detail: str = "",
    effects: list[str] | None = None,
    code: str | None = None,
) -> dict[str, Any]:
    out: dict[str, Any] = {
        "ok": outcome not in ("refused",),
        "outcome": outcome,
        "detail": detail,
        "effects": list(effects or []),
        "card_id": card,
        "kind": kind,
        "action": action,
    }
    if code:
        out["code"] = code
    return out


def _refused(card: str, action: str, code: str, detail: str, kind: str = "") -> dict[str, Any]:
    return _outcome(kind, card, action, outcome="refused", code=code, detail=detail)


def _audit(result: dict[str, Any], *, group: bool = False) -> None:
    """Аудит решения ОДИН раз: строка ``pult-actions.log`` + (если решение состоялось) событие.

    Только идентификаторы, вид, действие, исход и кто решал; текста карточки здесь нет.
    ``group`` - решение принято в составе группового (``decide_many``): метка в строке и событии."""
    from core.host import current_host
    from core.metrics import record_event
    from core.operational.pult import record_action

    who = current_host()
    params: dict[str, Any] = {
        "kind": result["kind"] or "-",
        "id": result["card_id"],
        "action": result["action"],
        "host": who["name"],
        "surface": who["surface"],
    }
    if result.get("code"):
        params["code"] = result["code"]
    if group:
        params["group"] = True
    record_action(AUDIT_TOOL, params, result["outcome"])
    if result["outcome"] in DECIDED_OUTCOMES and result["kind"]:
        extra = {"group": True} if group else {}
        record_event(
            EVENT_KIND,
            card_kind=result["kind"],  # ``kind`` занят самим событием
            decision=_DECISION_OF[result["outcome"]],
            host=who["name"],
            **extra,
        )


def decide(
    card: str,
    action: str,
    params: dict[str, Any] | None = None,
    *,
    env: QueueEnv | None = None,
    audit: bool = True,
    group: bool = False,
    expected_rev: str | None = None,
) -> dict[str, Any]:
    """Принять решение по карточке ``<kind>:<id>``. Исход - единой формы (см. док модуля).

    Неизвестная карточка/действие - ``refused`` без записи в сторы; ``ValueError`` ядра
    (неверный параметр) тоже становится ``refused``: отказ пересекает границу как ДАННЫЕ.
    ``expected_rev`` - ``rev`` карточки, который видел человек: карточка изменилась
    (``card_changed``) или исчезла (``card_gone``) - исход ``stale`` с новой карточкой и ``diff``,
    решение не применяется."""
    env = env or QueueEnv()
    name, native = split_card_id(card)
    kind = get_registry().get(name)
    if kind is None or not native:
        result = _refused(card, action, "unknown_card",
                          f"карточка {str(card)[:60]!r} не найдена: id вида «<вид>:<id>»")
    elif kind.spec(action) is None:
        result = _refused(card, action, "bad_action",
                          f"у вида {name} нет действия {action!r}: "
                          + ", ".join(a.action for a in kind.actions), name)
    elif expected_rev and (
            stale := _stale_by_rev(kind, env, card, action, str(expected_rev))) is not None:
        result = stale
    else:
        try:
            raw = kind.decide(env, native, action, dict(params or {}))
            result = _outcome(
                name, card, action,
                outcome=str(raw.get("outcome") or "refused"),
                detail=str(raw.get("detail") or ""),
                effects=list(raw.get("effects") or []),
                code=raw.get("code"),
            )
        except ValueError as exc:
            missing = "не найден" in str(exc)
            result = _refused(card, action, "unknown_card" if missing else "invalid_params",
                              str(exc)[:240], name)
        except Exception as exc:  # noqa: BLE001 - отказ данными, а не исключением через границу
            logger.warning("решение %s/%s не принято: %s", card, action, exc)
            result = _refused(card, action, "error",
                              f"{type(exc).__name__}: {str(exc)[:200]}", name)
    if kind is not None:
        _drop_cached_pages(name)
    if audit:
        _audit(result, group=group)
    return result


GROUP_AUDIT_TOOL = "pult_cards_decide"
MAX_BATCH = 200


def decide_many(
    card_ids: list[str],
    action: str,
    params: dict[str, Any] | None = None,
    *,
    env: QueueEnv | None = None,
    group: str | None = None,
    expected_revs: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Групповое решение (USE-LOOP-1 п.3): ОДНО ``action``/``params`` по списку карточек.

    Это ровно те же :func:`decide` по каждой карточке - без обходных записей в сторы: каждая
    решается ядром своего вида, исход каждой - своей формы (``applied``/``refused`` с ``code``).
    Частичный отказ показан честно (``partial``), остальные карточки применены; повтор
    идемпотентен (решенная карточка при повторе - ``stale``/``refused``, второй записи в стор нет).
    Дубли id схлопываются, порядок сохраняется. Больше ``MAX_BATCH`` карточек или пустой список -
    отказ целиком (``bad_batch``, ничего не применено).

    Аудит: запись КАЖДОЙ карточки (``pult_card_decide`` с меткой ``group``, событие
    ``queue_decision`` с ``group: true``) плюс ОДНА запись группы (``pult_cards_decide``: действие,
    число карточек, счетчики исходов; ``group`` - id группы, если пульт его назвал).

    ``{ok, action, group?, total, decided, partial, summary: {исход: n}, results: [исход]}``;
    ``ok`` - нет ни одного отказа и ни одной изменившейся карточки.

    ``expected_revs`` (PULT-UX-2 п.5) - ``{id карточки: rev}`` из состава группы, который видел
    человек: изменившаяся/исчезнувшая карточка дает свой ``stale`` (``card_changed``/``card_gone``,
    новая карточка и ``diff`` внутри исхода) и не применяется, остальные решаются; число таких -
    ``changed``."""
    from core.operational.pult import record_action

    env = env or QueueEnv()
    ids = list(dict.fromkeys(str(c) for c in (card_ids or []) if str(c).strip()))
    if not ids or len(ids) > MAX_BATCH:
        why = "пустой список карточек" if not ids else f"больше {MAX_BATCH} карточек за раз"
        out: dict[str, Any] = {"ok": False, "refused": True, "code": "bad_batch", "detail": why,
                               "action": action, "total": len(ids), "decided": 0, "partial": False,
                               "summary": {}, "results": []}
        record_action(GROUP_AUDIT_TOOL, {"action": action, "cards": len(ids)}, "refused")
        return out
    revs = {str(k): str(v) for k, v in (expected_revs or {}).items() if v}
    results = [decide(c, action, params, env=env, group=True, expected_rev=revs.get(c))
               for c in ids]
    summary: dict[str, int] = {}
    for r in results:
        summary[r["outcome"]] = summary.get(r["outcome"], 0) + 1
    decided = sum(summary.get(o, 0) for o in DECIDED_OUTCOMES)
    refused = summary.get("refused", 0)
    changed = sum(1 for r in results if r.get("code") in ("card_changed", "card_gone"))
    out = {"ok": refused == 0 and changed == 0, "action": action, "total": len(ids),
           "decided": decided, "changed": changed,
           "partial": bool((refused or changed) and (decided or summary.get("stale"))),
           "summary": summary, "results": results}
    if group:
        out["group"] = str(group)
    audit: dict[str, Any] = {"action": action, "cards": len(ids), "group": str(group or "-")[:120],
                             **{k: v for k, v in sorted(summary.items())}}
    if changed:
        audit["changed"] = changed
    record_action(GROUP_AUDIT_TOOL, audit,
                  "refused" if refused == len(ids) else "partial" if (refused or changed)
                  else "applied")
    return out


def explain(
    card: str, *, env: QueueEnv | None = None, params: dict[str, Any] | None = None
) -> dict[str, Any]:
    """«Почему» по карточке: ``{ok, card_id, kind, why}``; ``why: null`` - вид не объясняется.

    Неизвестная карточка - ``{ok: false, refused: true, code: "unknown_card"}``."""
    env = env or QueueEnv()
    name, native = split_card_id(card)
    kind = get_registry().get(name)
    if kind is None or not native:
        return {"ok": False, "refused": True, "code": "unknown_card", "card_id": card,
                "detail": f"карточка {str(card)[:60]!r} не найдена: id вида «<вид>:<id>»"}
    try:
        why = kind.explain_with(env, native, dict(params or {}))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "refused": True, "code": _error_code(exc), "card_id": card,
                "kind": name, "detail": str(exc)[:200]}
    if why is None and kind.explain.__func__ is not CardKind.explain:  # type: ignore[attr-defined]
        # вид умеет объяснять, но карточки уже нет (решена/снята) - не то же, что «не объясняется»
        return {"ok": False, "refused": True, "code": "unknown_card", "card_id": card,
                "kind": name, "detail": "карточки нет в очереди (решена или снята)"}
    return {"ok": True, "card_id": card, "kind": name, "why": why}
