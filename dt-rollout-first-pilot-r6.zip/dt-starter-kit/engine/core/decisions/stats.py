"""QUEUE-SERVER-1 п.3 — статистика решений по видам для доктора «Очередь решений».

Источник - журнал метрик: событие ``queue_decision`` (``card_kind``, ``decision``) пишет
:func:`core.decisions.registry.decide`; до появления фасада решения по ссылкам и кандидатам в хабы
писали сами ядра (``link_decision``/``hub_decision``) - их считаем ТОЛЬКО за период до первого
``queue_decision`` (иначе решение через фасад посчиталось бы дважды: событием ядра и событием
реестра). Доля принятых = принятые / (принятые + отклоненные); отложенные и маршрутизации в долю
не входят. Это ЗАМЕР детектора, не правка: порог ``warn`` - в :func:`noisy_kinds`.

**Баланс «пришло / решено»** (USE-LOOP-1 п.6, :func:`balance`): за семидневку пришло N (реестр
потока, :func:`core.decisions.flow.arrivals`), решено M (любое состоявшееся решение: принято,
отклонено, отложено, маршрутизировано - событие ``queue_decision``, групповые поэлементно), запас K.
Две семидневки подряд с «пришло > решено» - очередь растет (:func:`growing`); это и есть метрика
выдержки ТЗ («решено за неделю >= пришло, четыре недели подряд»).
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

__all__ = [
    "MIN_DECISIONS",
    "balance",
    "decided_between",
    "growing",
    "PENDING_WARN",
    "SHARE_WARN",
    "WINDOW_DAYS",
    "decision_stats",
    "noisy_kinds",
    "share",
]

WINDOW_DAYS = 30
PENDING_WARN = 100      # у вида больше стольких ждущих карточек - очередь копится
SHARE_WARN = 0.2        # доля принятых ниже этой при MIN_DECISIONS решениях - детектор шумит
MIN_DECISIONS = 30

_APPROVED = ("approved", "auto")
# Решения, которые до фасада писали ядра: вид карточки по виду события.
_LEGACY_KIND = {"hub_decision": "hub", "link_decision": "link"}


def decision_stats(events: list[dict[str, Any]]) -> dict[str, dict[str, int]]:
    """``{вид: {approved, rejected}}`` по событиям окна (см. док модуля про двойной счет)."""
    stats: dict[str, dict[str, int]] = {}

    def bump(kind: str, decision: str) -> None:
        row = stats.setdefault(kind, {"approved": 0, "rejected": 0})
        if decision in _APPROVED:
            row["approved"] += 1
        elif decision == "rejected":
            row["rejected"] += 1

    queue_events = [e for e in events if e.get("kind") == "queue_decision" and e.get("card_kind")]
    first = min((str(e.get("ts") or "") for e in queue_events), default=None)
    for e in queue_events:
        bump(str(e["card_kind"]), str(e.get("decision") or ""))
    for e in events:
        legacy = _LEGACY_KIND.get(str(e.get("kind")))
        if legacy and (first is None or str(e.get("ts") or "") < first):
            bump(legacy, str(e.get("decision") or ""))
    return stats


def share(row: dict[str, int]) -> float | None:
    """Доля принятых среди принятых+отклоненных; ``None`` - решений нет."""
    total = row["approved"] + row["rejected"]
    return row["approved"] / total if total else None


def noisy_kinds(stats: dict[str, dict[str, int]]) -> list[str]:
    """Виды, у которых при ``MIN_DECISIONS``+ решениях доля принятых ниже ``SHARE_WARN``."""
    out = []
    for kind, row in stats.items():
        total = row["approved"] + row["rejected"]
        s = share(row)
        if total >= MIN_DECISIONS and s is not None and s < SHARE_WARN:
            out.append(kind)
    return sorted(out)


def _ts(value: Any) -> datetime | None:
    from core.metrics import _parse_ts

    return _parse_ts(value)


def decided_between(events: list[dict[str, Any]], since: datetime, until: datetime) -> int:
    """Сколько решений СОСТОЯЛОСЬ в ``[since, until)``: ``queue_decision`` (все исходы, кроме stale
    и refused - их событие не пишется) плюс решения ядер ``hub_decision``/``link_decision`` до
    первого ``queue_decision`` (как в :func:`decision_stats`: иначе одно решение считалось бы
    дважды)."""
    queue_events = [e for e in events if e.get("kind") == "queue_decision"]
    first = min((str(e.get("ts") or "") for e in queue_events), default=None)
    n = 0
    for e in events:
        at = _ts(e.get("ts"))
        if at is None or not since <= at < until:
            continue
        kind = e.get("kind")
        if kind == "queue_decision" and e.get("card_kind"):
            n += 1
        elif kind in _LEGACY_KIND and (first is None or str(e.get("ts") or "") < first):
            n += 1
    return n


def balance(
    events: list[dict[str, Any]], arrived: tuple[int, int] | None, reserve: int | None,
    now: datetime,
) -> dict[str, Any]:
    """Баланс двух последних семидневок: ``{prev: {arrived, decided}, cur: {...}, reserve}``.

    ``arrived`` - ``(за предыдущие 7 дн, за последние 7 дн)`` по реестру потока либо ``None``
    (реестра нет - баланса нет: ``known=False``, предупреждать не по чему)."""
    week = timedelta(days=7)
    cur_from, prev_from = now - week, now - 2 * week
    out: dict[str, Any] = {
        "known": arrived is not None, "reserve": reserve or 0,
        "cur": {"arrived": arrived[1] if arrived else 0,
                "decided": decided_between(events, cur_from, now + timedelta(seconds=1))},
        "prev": {"arrived": arrived[0] if arrived else 0,
                 "decided": decided_between(events, prev_from, cur_from)},
    }
    return out


def growing(bal: dict[str, Any]) -> bool:
    """Две семидневки подряд пришло больше, чем решено (и данные о приходе есть)."""
    return bool(bal["known"]) and all(
        bal[w]["arrived"] > bal[w]["decided"] for w in ("prev", "cur"))
