"""Universal domain model; independent of vocabulary/instance authorization roles.

2A provides read-only contracts. Persistence, indexing and owner-approved model
changes are subsequent stages, not hidden side effects of validation.
"""

from core.domain.schema import Issue, Registry, parse_model

__all__ = ["Issue", "Registry", "parse_model"]
