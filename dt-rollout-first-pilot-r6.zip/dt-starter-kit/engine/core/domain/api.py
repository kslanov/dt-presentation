"""Read-only facade shared by CLI/MCP; one instance, no caller-controlled paths."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.domain.compare import compare_models
from core.domain.load import load_model
from core.domain.objects import context, form, validate_object
from core.domain.schema import bounded_json, positive_int

OPS = {
    "show": frozenset(),
    "validate": frozenset({"object", "related", "previous"}),
    "form": frozenset({"type", "version"}),
    "context": frozenset({"object", "related", "view"}),
    "compare": frozenset({"model", "expected_version"}),
}


def domain_model(
    op: str = "show", args: dict | None = None, *, vault_path: Path | None = None
) -> dict[str, Any]:
    if not isinstance(op, str) or op not in OPS:
        return {"ok": False, "code": "model_op_unknown", "allowed": list(OPS)}
    args = {} if args is None else args
    if not isinstance(args, dict) or not bounded_json(args) or set(args) - OPS[op]:
        return {"ok": False, "code": "model_args"}
    loaded = load_model(vault_path)
    if op == "show":
        return loaded.to_dict()
    if not loaded.registry.ok:
        return loaded.to_dict()
    if op == "compare":
        if "expected_version" not in args or args["expected_version"] != loaded.version:
            return {
                "ok": False,
                "code": "model_version_conflict",
                "version": loaded.version,
                "applied": False,
            }
        return {**compare_models(loaded.registry, args.get("model")), "version": loaded.version}
    if not loaded.present:
        return {"ok": False, "code": "model_not_configured", "present": False}
    if op == "form":
        if not isinstance(args.get("type"), str) or (
            "version" in args and not positive_int(args["version"])
        ):
            return {"ok": False, "code": "model_args"}
        out = form(loaded.registry, args["type"], args.get("version"))
    elif op == "validate":
        out = validate_object(
            loaded.registry,
            args.get("object"),
            related=args.get("related"),
            previous=args.get("previous"),
        )
    else:
        if not isinstance(args.get("object"), dict) or (
            "view" in args and not isinstance(args["view"], str)
        ):
            return {"ok": False, "code": "model_args"}
        out = context(loaded.registry, args["object"], args.get("related"), args.get("view"))
    return {**out, "model_version": loaded.version}
