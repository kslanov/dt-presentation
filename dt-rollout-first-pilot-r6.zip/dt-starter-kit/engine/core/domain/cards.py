"""One generic kind in the existing owner decision queue."""

from __future__ import annotations

from typing import Any

from core.decisions.registry import ActionSpec, CardKind, KindPage, QueueEnv, card_id
from core.domain.load import load_model
from core.domain.objects import definition
from core.domain.store import DomainError, DomainStore
from core.note_writer import NoteWriteError


class DomainKind(CardKind):
    kind = "domain"
    label = "Предметные объекты"
    actions = (
        ActionSpec("approve", "Сохранить объект", "primary"),
        ActionSpec("reject", "Отклонить", "secondary"),
    )

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        rows = DomainStore(env.vault_path()).pending()
        cards = [
            {
                "id": card_id(self.kind, p["id"]),
                "kind": self.kind,
                "title": ("Изменить" if p["expected"] else "Создать")
                + ": "
                + next(
                    (
                        str(v)[:100]
                        for v in p["object"].get("fields", {}).values()
                        if isinstance(v, str)
                    ),
                    p["object"]["id"],
                ),
                "reason": "Проверьте поля и источники перед сохранением",
                "since": p["at"],
                "meta": {
                    "object": p["object"],
                    "sources": p["sources"],
                    "before_version": p["expected"],
                    "after_version": p["after"],
                    "model_version": p["model_version"],
                },
                "actions": [a.to_dict() for a in self.actions],
                "explainable": True,
            }
            for p in (rows[:limit] if limit > 0 else rows)
        ]
        return KindPage(cards, len(rows))

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        try:
            return DomainStore(env.vault_path()).decide(native_id, action)
        except (DomainError, NoteWriteError) as exc:
            return {"outcome": "refused", "code": exc.code, "detail": str(exc)}

    def explain(self, env: QueueEnv, native_id: str) -> dict | None:
        store = DomainStore(env.vault_path())
        _, row = store.proposal(native_id)
        if not row:
            return None
        before = store.get(row["object"]["id"])
        spec = (
            definition(
                load_model(env.vault_path()).registry,
                row["object"]["type"],
                row["object"]["version"],
            )
            or {}
        )
        old = (before.get("object") or {}).get("fields", {})
        new = row["object"].get("fields", {})
        fields = [
            {"label": fs["label"], "before": old.get(key), "after": new.get(key)}
            for key, fs in spec.get("fields", {}).items()
            if old.get(key) != new.get(key)
        ]
        previous = before.get("object") or {}
        obj = row["object"]
        if previous.get("state") != obj.get("state"):
            labels = spec.get("state_labels", {})
            fields.append(
                {
                    "label": "Состояние",
                    "before": labels.get(previous.get("state")),
                    "after": labels.get(obj.get("state"), obj.get("state")),
                }
            )

        def relation_name(value: Any) -> Any:
            if isinstance(value, list):
                return ", ".join(str(relation_name(v)) for v in value)
            if not isinstance(value, dict):
                return value
            target = store.get(value["id"])
            if not target.get("ok"):
                return "Связанный объект не найден"
            return next(
                (str(v) for v in target["object"].get("fields", {}).values() if isinstance(v, str)),
                value["id"],
            )

        for key, relation in spec.get("relations", {}).items():
            a, b = previous.get("relations", {}).get(key), obj.get("relations", {}).get(key)
            if a != b:
                fields.append(
                    {
                        "label": relation["label"],
                        "before": relation_name(a),
                        "after": relation_name(b),
                    }
                )
        if before.get("sources", []) != row["sources"]:
            fields.append(
                {
                    "label": "Основания",
                    "before": [s.get("title", s["note_id"]) for s in before.get("sources", [])],
                    "after": [s.get("title", s["note_id"]) for s in row["sources"]],
                }
            )
        return {
            "before": before.get("object"),
            "after": row["object"],
            "fields": fields,
            "sources": row["sources"],
            "model_version": row["model_version"],
            "effects": ["Запись только отдельной предметной заметки; исходники не меняются"],
            "source_verified": False,
        }
