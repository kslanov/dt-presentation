"""Read-only compatibility preview. It never applies or migrates a model."""

from __future__ import annotations

import copy
from typing import Any

from core.domain.schema import Registry, parse_model


def compare_models(before: Registry, proposed: Any) -> dict[str, Any]:
    after = parse_model(proposed)
    if not before.ok or not after.ok:
        return {
            "ok": False,
            "applied": False,
            "issues": [i.to_dict() for i in (*before.issues, *after.issues)],
        }
    old, new = before.document, after.document
    issues: list[dict] = []
    changes: list[dict] = []

    def incompatible(path: str, reason: str) -> None:
        issues.append(
            {"code": "model_history_conflict", "path": path, "reason": reason, "severity": "error"}
        )

    if old and new["revision"] <= old["revision"]:
        incompatible("revision", "Новая редакция должна быть больше текущей")
    for tid, typ in old.get("types", {}).items():
        current = new["types"].get(tid)
        if current is None:
            incompatible("types." + tid, "Нельзя удалить тип с историческими определениями")
            continue
        if current["current"] < typ["current"]:
            incompatible("types." + tid + ".current", "Возврат версии требует отдельного решения")
        for ver, spec in typ["versions"].items():
            if current["versions"].get(ver) != spec:
                incompatible(
                    f"types.{tid}.versions.{ver}",
                    "Историческая версия должна сохраняться без изменений",
                )

    # A path-based diff is deterministic and independent of profession.
    def walk(a: Any, b: Any, path: str) -> None:
        if a == b:
            return
        if isinstance(a, dict) and isinstance(b, dict):
            for key in sorted(set(a) | set(b), key=str):
                p = f"{path}.{key}" if path else str(key)
                if key not in a:
                    changes.append({"path": p, "change": "add", "after": copy.deepcopy(b[key])})
                elif key not in b:
                    changes.append({"path": p, "change": "remove", "before": copy.deepcopy(a[key])})
                else:
                    walk(a[key], b[key], p)
        else:
            changes.append(
                {
                    "path": path,
                    "change": "update",
                    "before": copy.deepcopy(a),
                    "after": copy.deepcopy(b),
                }
            )

    walk(old, new, "")
    changed_types = [
        tid
        for tid, spec in new["types"].items()
        if tid in old.get("types", {}) and spec["current"] != old["types"][tid]["current"]
    ]
    return {
        "ok": not issues,
        "applied": False,
        "issues": issues,
        "changes": changes,
        "migration_required": changed_types,
        "hint": "Только предпросмотр. Перепривязка существующих объектов требует отдельного плана.",
    }
