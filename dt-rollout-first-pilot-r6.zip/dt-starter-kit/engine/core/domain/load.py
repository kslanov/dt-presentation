"""Single bounded reader of the optional instance domain registry. No writes."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from core.config import default_vault_path
from core.domain.schema import MAX_BYTES, Issue, Registry, parse_model
from core.privacy import any_nda

FILE = "domain-model.yaml"


class ModelLoader(yaml.SafeLoader):
    """Reject duplicate keys; preserve ISO dates as strings for the shared validator."""


def _mapping(loader: ModelLoader, node: Any, deep: bool = False) -> dict:
    # No merges: they can hide duplicate keys and turn review diffs ambiguous.
    out: dict = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if not isinstance(key, (str, int)) or isinstance(key, bool) or key in out:
            raise ValueError("duplicate or invalid key")
        out[key] = loader.construct_object(value_node, deep=deep)
    return out


ModelLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)
ModelLoader.add_constructor("tag:yaml.org,2002:timestamp", yaml.SafeLoader.construct_scalar)


@dataclass(frozen=True)
class LoadedModel:
    registry: Registry
    present: bool = False
    version: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "present": self.present,
            "ok": self.registry.ok,
            "version": self.version,
            "model": self.registry.to_dict(),
            "issues": [i.to_dict() for i in self.registry.issues],
        }


def load_legacy_model(vault_path: Path | None = None) -> LoadedModel:
    root = Path(vault_path or default_vault_path()).absolute()
    path = root / "_system" / FILE

    def refused(code: str, message: str, version: str = "") -> LoadedModel:
        return LoadedModel(Registry(issues=(Issue(code, FILE, message),)), True, version)

    try:
        resolved = path.resolve()
        if (
            not resolved.is_relative_to(root.resolve())
            or any_nda(path, resolved)
            or path.is_symlink()
            or path.parent.is_symlink()
        ):
            return refused("model_path_refused", "Модель вне разрешенного контура")
        if not path.exists() and not path.is_symlink():
            return LoadedModel(Registry())
        if not path.is_file():
            return refused("model_unavailable", "Конфигурация модели недоступна")
        with path.open("rb") as stream:
            raw = stream.read(MAX_BYTES + 1)
        version = hashlib.sha256(raw).hexdigest()[:12]
        if len(raw) > MAX_BYTES:
            return refused("model_budget", "Превышен размер модели", version)
        try:
            loader = ModelLoader(raw.decode("utf-8"))
            try:
                data = loader.get_single_data()
            finally:
                loader.dispose()
            return LoadedModel(parse_model(data), True, version)
        except (yaml.YAMLError, ValueError, UnicodeError, RecursionError):
            return refused("model_yaml", "Некорректный YAML или повтор ключей", version)
    except (OSError, RuntimeError):
        return refused("model_unavailable", "Конфигурация модели не прочитана")


def load_model(vault_path: Path | None = None) -> LoadedModel:
    from core.activity.read import model_hash, read_current

    legacy = load_legacy_model(vault_path)
    if not legacy.registry.ok:
        return legacy
    try:
        state = read_current(vault_path)
        if not state["present"]:
            return legacy
        bundle = state["bundle"]
        if not legacy.registry.ok or legacy.version != bundle["baseline_legacy"]:
            return LoadedModel(
                Registry(
                    issues=(
                        Issue(
                            "activity_external_conflict",
                            FILE,
                            "Внешняя схема изменена после принятия. Нужна сверка через Мою модель",
                        ),
                    )
                ),
                True,
            )
        return LoadedModel(parse_model(bundle["model"]), True, model_hash(bundle["model"]))
    except (ValueError, OSError, RuntimeError, TypeError, KeyError):
        return LoadedModel(
            Registry(
                issues=(
                    Issue(
                        "activity_unavailable",
                        FILE,
                        "Снимок деятельности недоступен; предметная модель не подменяется",
                    ),
                )
            ),
            True,
        )
