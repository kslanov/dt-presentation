"""Schema-bound object checks and shared read models for forms/task context."""

from __future__ import annotations

import copy
import math
from collections.abc import Callable
from datetime import date
from typing import Any

from core.domain.schema import Registry, bounded_json, finite_number, positive_int


def definition(registry: Registry, type_id: Any, version: Any = None) -> dict | None:
    if not registry.ok or not isinstance(type_id, str):
        return None
    typ = registry.document.get("types", {}).get(type_id)
    if typ is None:
        return None
    v = typ["current"] if version is None else version
    return typ["versions"].get(v) if positive_int(v) else None


def _scalar(value: Any, spec: dict) -> bool:
    kind = spec["type"]
    if kind in ("string", "enum", "date"):
        if not isinstance(value, str):
            return False
        if kind == "enum" and value not in spec["values"]:
            return False
        if kind == "date":
            try:
                if date.fromisoformat(value).isoformat() != value:
                    return False
            except ValueError:
                return False
        if len(value) < spec.get("min_length", 0) or len(value) > spec.get("max_length", math.inf):
            return False
    elif kind == "boolean":
        return type(value) is bool
    elif not finite_number(value) or (kind == "integer" and type(value) is not int):
        return False
    elif value < spec.get("min", -math.inf) or value > spec.get("max", math.inf):
        return False
    return True


def _check_fields(obj: dict, spec: dict, fail: Callable[..., None]) -> None:
    fields = obj.get("fields", {})
    if not isinstance(fields, dict):
        fail("object_fields", "fields", "Ожидается словарь")
    else:
        declared = spec.get("fields", {})
        for key in fields:
            if key not in declared:
                fail(
                    "object_field_unknown", "fields." + str(key), "Поле не объявлено в этой версии"
                )
        for key, fs in declared.items():
            value = fields.get(key)
            if key not in fields:
                if fs.get("required"):
                    fail("object_required", "fields." + key, "Обязательное поле отсутствует")
                continue
            if fs.get("many"):
                valid = (
                    isinstance(value, list)
                    and all(_scalar(v, fs) for v in value)
                    and (bool(value) or not fs.get("required"))
                )
            else:
                valid = _scalar(value, fs)
            if not valid:
                fail("object_value", "fields." + key, "Значение не соответствует типу/ограничению")


def validate_object(
    registry: Registry, obj: Any, *, related: list | None = None, previous: dict | None = None
) -> dict[str, Any]:
    issues: list[dict[str, str]] = []

    def fail(code: str, path: str, reason: str, severity: str = "error") -> None:
        issues.append({"code": code, "path": path, "reason": reason, "severity": severity})

    def result() -> dict[str, Any]:
        return {
            "ok": not any(i["severity"] == "error" for i in issues),
            "complete": not issues,
            "issues": issues,
        }

    if not registry.ok:
        return {"ok": False, "complete": False, "issues": [i.to_dict() for i in registry.issues]}
    if not bounded_json({"object": obj, "related": related, "previous": previous}):
        fail("object_budget", "", "Размер, вложенность или тип данных")
        return result()
    if not isinstance(obj, dict):
        fail("object_shape", "", "Ожидается объект")
        return result()
    for key in obj:
        if key not in {"id", "type", "version", "fields", "relations", "state"}:
            fail("object_key", str(key), "Неизвестное поле объекта")
    if not isinstance(obj.get("id"), str) or not obj["id"].strip():
        fail("object_id", "id", "Нужен непустой стабильный ID")
    if not positive_int(obj.get("version")):
        fail("object_version", "version", "Объект должен явно указывать версию типа")
    spec = definition(registry, obj.get("type"), obj.get("version"))
    if spec is None:
        fail("object_type", "type", "Тип или историческая версия не найдены")
        return result()
    _check_fields(obj, spec, fail)
    state = obj.get("state")
    states = spec.get("states", [])
    if states and state not in states:
        fail("object_state", "state", "Нужно состояние из жизненного цикла")
    if not states and "state" in obj:
        fail("object_state", "state", "У типа нет жизненного цикла")
    if previous is not None:
        prior = validate_object(registry, previous)
        if not prior["ok"]:
            fail("object_previous", "previous", "Прежний объект некорректен")
        elif any(previous.get(k) != obj.get(k) for k in ("id", "type", "version")):
            fail(
                "object_migration",
                "previous",
                "Изменение идентичности/схемы требует плана миграции",
            )
        elif (
            states
            and previous.get("state") != state
            and state not in spec.get("transitions", {}).get(previous.get("state"), [])
        ):
            fail("object_transition", "state", "Переход не разрешен")
    known: dict[str, dict] = {}
    if related is not None:
        if not isinstance(related, list):
            fail("object_context", "related", "Ожидается список объектов")
        else:
            for item in related:
                checked = validate_object(registry, item)
                if not checked["ok"]:
                    fail("object_context", "related", "Некорректный объект в контексте")
                elif item["id"] in known:
                    fail("object_context", "related", "Повтор ID в контексте")
                elif item["id"] == obj.get("id") and item != obj:
                    fail("object_context", "related", "Один ID у разных объектов")
                else:
                    known[item["id"]] = item
    relations = obj.get("relations", {})
    if not isinstance(relations, dict):
        fail("object_relations", "relations", "Ожидается словарь")
        return result()
    declared_rel = spec.get("relations", {})
    for key in relations:
        if key not in declared_rel:
            fail("object_relation_unknown", "relations." + str(key), "Связь не объявлена")
    for key, rs in declared_rel.items():
        if key not in relations:
            if rs.get("required"):
                fail("object_required", "relations." + key, "Обязательная связь отсутствует")
            continue
        value = relations[key]
        refs = value if rs.get("many") and isinstance(value, list) else [value]
        if rs.get("many") and not isinstance(value, list):
            fail("object_relation", "relations." + key, "Ожидается список ссылок")
            continue
        if rs.get("required") and not refs:
            fail("object_required", "relations." + key, "Обязательная связь пуста")
        seen: set[str] = set()
        for ref in refs:
            p = "relations." + key
            if (
                not isinstance(ref, dict)
                or set(ref) != {"id", "type"}
                or not isinstance(ref.get("id"), str)
                or not ref["id"].strip()
                or ref.get("type") not in rs["targets"]
            ):
                fail("object_relation", p, "Некорректная ссылка или неподходящий тип конца")
                continue
            if ref["id"] in seen:
                fail("object_relation_duplicate", p, "Повтор ссылки")
            seen.add(ref["id"])
            target = known.get(ref["id"])
            if related is None:
                fail("object_reference_unchecked", p, "Существование ссылки не проверено", "warn")
            elif target is None or target["type"] != ref["type"]:
                fail("object_reference_missing", p, "В контексте нет такого объекта")
    return result()


def form(registry: Registry, type_id: str, version: int | None = None) -> dict[str, Any]:
    spec = definition(registry, type_id, version)
    if spec is None or "form" not in spec.get("capabilities", []):
        return {"ok": False, "code": "model_form_unavailable"}
    typ = registry.document["types"][type_id]
    return {
        "ok": True,
        "type": type_id,
        "version": version or typ["current"],
        "label": typ["label"],
        **copy.deepcopy(spec),
    }


def context(
    registry: Registry, obj: dict, related: list | None = None, view: str | None = None
) -> dict[str, Any]:
    checked = validate_object(registry, obj, related=related)
    if not checked["ok"]:
        return checked
    spec = definition(registry, obj["type"], obj["version"])
    if "context" not in spec.get("capabilities", []):
        return {"ok": False, "code": "model_context_unavailable"}
    fields = spec.get("fields", {})
    if view is not None:
        if view not in spec.get("views", {}):
            return {"ok": False, "code": "model_view_unknown"}
        keys = spec["views"][view]
    else:
        keys = list(fields)
    return {
        **checked,
        "object": {
            "id": obj["id"],
            "type": obj["type"],
            "version": obj["version"],
            "state": obj.get("state"),
            "fields": [
                {
                    "id": key,
                    "label": fields[key]["label"],
                    "value": copy.deepcopy(obj.get("fields", {}).get(key)),
                    "present": key in obj.get("fields", {}),
                }
                for key in keys
            ],
            "relations": copy.deepcopy(obj.get("relations", {})),
        },
        "provenance": "supplied_context",
        "source_verified": False,
    }
