"""Domain object facade. Propose is the only write; publication uses the queue."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.config import default_vault_path
from core.domain.load import load_model
from core.domain.objects import context, validate_object
from core.domain.schema import bounded_json
from core.domain.store import DomainError, DomainStore
from core.note_writer import NoteWriteError

OPS = {
    "search": {"query", "type", "offset", "limit"},
    "get": {"id"},
    "context": {"id", "view"},
    "history": {"id", "offset", "limit"},
    "propose": {"object", "sources", "expected_version", "model_version"},
}


def domain_objects(
    op: str = "search", args: dict | None = None, *, vault_path: Path | None = None
) -> dict[str, Any]:
    from core.operational.pult import record_action

    result: dict[str, Any] = {}
    try:
        if not isinstance(op, str) or op not in OPS:
            raise DomainError("domain_op", "Неизвестная операция")
        args = {} if args is None else args
        if not isinstance(args, dict) or not bounded_json(args) or set(args) - OPS[op]:
            raise DomainError("domain_args", "Некорректные аргументы")
        store = DomainStore(vault_path or default_vault_path())
        loaded = load_model(store.vault)
        if not loaded.present or not loaded.registry.ok:
            return {
                "ok": False,
                "code": "domain_model_unavailable",
                "issues": [i.to_dict() for i in loaded.registry.issues],
            }
        if op == "search":
            result = store.search(
                loaded.registry,
                args.get("query", ""),
                args.get("type"),
                args.get("offset", 0),
                args.get("limit", 20),
            )
        elif op == "propose":
            obj = args.get("object")
            if not validate_object(loaded.registry, obj)["ok"]:
                return validate_object(loaded.registry, obj)
            if not isinstance(args.get("expected_version"), str) or not isinstance(
                args.get("model_version"), str
            ):
                raise DomainError("domain_args", "Нужны версии объекта и модели")
            result = store.propose(
                obj, args.get("sources", []), args["expected_version"], args["model_version"]
            )
        elif op == "history":
            result = store.history(args.get("id"), args.get("offset", 0), args.get("limit", 20))
        else:
            result = store.get(args.get("id"))
            if result.get("ok") and not validate_object(loaded.registry, result["object"])["ok"]:
                raise DomainError("domain_corrupt", "Объект не соответствует своей версии модели")
            if result.get("ok") and op == "context":
                if "view" in args and not isinstance(args["view"], str):
                    raise DomainError("domain_args", "Некорректное представление")
                related, _ = store.linked(result["object"])
                result = {
                    **context(loaded.registry, result["object"], related, args.get("view")),
                    "path": result["path"],
                    "sources": result["sources"],
                    "source_status": result.get("source_status", []),
                }
        return {**result, "model_version": loaded.version}
    except (DomainError, NoteWriteError) as exc:
        result = {"ok": False, "code": exc.code, "error": str(exc)}
        return result
    except (ValueError, OSError, TypeError, KeyError, UnicodeError) as exc:
        result = {"ok": False, "code": "domain_unavailable", "error": type(exc).__name__}
        return result
    finally:
        if op == "propose":
            record_action(
                "domain_objects", {"op": "propose"}, "proposed" if result.get("ok") else "refused"
            )
