"""ROLE-DATA-2A: declarative, profession-independent model. Pure validation.

No executable expressions, arbitrary validators, source permissions or implicit
migrations. The entire document is rejected on an error; history is explicit.
"""

from __future__ import annotations

import copy
import json
import math
import re
from dataclasses import dataclass, field
from typing import Any

SCHEMA = 1
MAX_BYTES = 262_144
MAX_NODES = 20_000
MAX_DEPTH = 16
ID = re.compile(r"^[a-z][a-z0-9_-]{0,63}$")
VALUE_TYPES = frozenset({"string", "integer", "number", "boolean", "date", "enum"})
CAPABILITIES = frozenset({"search", "form", "context"})


@dataclass(frozen=True)
class Issue:
    code: str
    path: str
    message: str
    severity: str = "error"

    def to_dict(self) -> dict[str, str]:
        return {
            "code": self.code,
            "path": self.path,
            "reason": self.message,
            "severity": self.severity,
        }


@dataclass(frozen=True)
class Registry:
    document: dict[str, Any] = field(default_factory=dict)
    issues: tuple[Issue, ...] = ()

    @property
    def ok(self) -> bool:
        return not self.issues

    def to_dict(self) -> dict[str, Any]:
        return copy.deepcopy(self.document)


def finite_number(value: Any) -> bool:
    return type(value) is int or (type(value) is float and math.isfinite(value))


def positive_int(value: Any) -> bool:
    return type(value) is int and value > 0


def bounded_json(value: Any) -> bool:
    """Bound input before deepcopy/traversal; reject cycles and non-JSON values."""
    count = 0
    ancestors: set[int] = set()

    def visit(item: Any, depth: int) -> bool:
        nonlocal count
        count += 1
        if count > MAX_NODES or depth > MAX_DEPTH:
            return False
        if item is None or type(item) in (str, bool, int):
            return True
        if type(item) is float:
            return math.isfinite(item)
        if type(item) not in (list, dict) or id(item) in ancestors:
            return False
        ancestors.add(id(item))
        try:
            if isinstance(item, dict):
                return all(type(k) in (str, int) and visit(v, depth + 1) for k, v in item.items())
            return all(visit(v, depth + 1) for v in item)
        finally:
            ancestors.remove(id(item))

    if not visit(value, 0):
        return False
    try:
        return len(json.dumps(value, ensure_ascii=False).encode()) <= MAX_BYTES
    except (ValueError, OverflowError, UnicodeError):
        return False


class _Parser:
    def __init__(self) -> None:
        self.issues: list[Issue] = []

    def fail(self, path: str, message: str, code: str = "model_schema") -> None:
        self.issues.append(Issue(code, path, message))

    def mapping(self, obj: Any, path: str, keys: set[str] | None = None) -> bool:
        if not isinstance(obj, dict):
            self.fail(path, "Ожидается словарь")
            return False
        if keys is not None:
            for key in obj:
                if key not in keys:
                    self.fail(f"{path}.{key}", "Неизвестный ключ")
        return True

    def name(self, value: Any, path: str) -> bool:
        if not isinstance(value, str) or not ID.fullmatch(value):
            self.fail(path, "Нужен стабильный ID: латиница, цифры, _ или -; с буквы")
            return False
        return True

    def label(self, obj: dict, path: str) -> None:
        if not isinstance(obj.get("label"), str) or not obj["label"].strip():
            self.fail(f"{path}.label", "Нужна непустая подпись")

    def names(self, value: Any, path: str, allowed: set | frozenset | None = None) -> bool:
        if not isinstance(value, list) or any(not isinstance(v, str) for v in value):
            self.fail(path, "Ожидается список ID")
            return False
        if len(set(value)) != len(value):
            self.fail(path, "Повтор ID")
        for v in value:
            self.name(v, path)
            if allowed is not None and v not in allowed:
                self.fail(path, f"Неизвестный ID: {v}")
        return True

    def parse_document(self, document: dict) -> None:
        if not self.mapping(document, "model", {"schema", "revision", "types"}):
            return
        if type(document.get("schema")) is not int or document["schema"] != SCHEMA:
            self.fail("schema", f"Поддерживается schema: {SCHEMA}", "model_version")
        if not positive_int(document.get("revision")):
            self.fail("revision", "Нужна положительная целая версия документа")
        types = document.get("types")
        if not self.mapping(types, "types"):
            return
        for tid, typ in types.items():
            self.type_definition(tid, typ, types)

    def type_definition(self, tid: str, typ: dict, types: dict) -> None:
        p = f"types.{tid}"
        self.name(tid, p)
        if not self.mapping(typ, p, {"label", "current", "versions"}):
            return
        self.label(typ, p)
        versions = typ.get("versions")
        if not self.mapping(versions, p + ".versions"):
            return
        # JSON object keys are strings; accept their canonical integer spelling.
        canonical = {}
        for key, value in versions.items():
            vk = int(key) if isinstance(key, str) and re.fullmatch(r"[1-9][0-9]{0,8}", key) else key
            if vk in canonical:
                self.fail(p + ".versions", "Повтор версии типа")
            canonical[vk] = value
        versions = typ["versions"] = canonical
        if not versions:
            self.fail(p + ".versions", "Нужна хотя бы одна версия типа")
        if not positive_int(typ.get("current")) or typ.get("current") not in versions:
            self.fail(p + ".current", "Текущая версия должна существовать")
        for version, spec in versions.items():
            self.version_definition(version, spec, p, types)

    def version_definition(self, version: int, spec: dict, p: str, types: dict) -> None:
        q = f"{p}.versions.{version}"
        if not positive_int(version):
            self.fail(q, "Ключ версии должен быть положительным целым числом")
        if not self.mapping(
            spec,
            q,
            {
                "fields",
                "relations",
                "states",
                "state_labels",
                "initial",
                "transitions",
                "views",
                "capabilities",
            },
        ):
            return
        fields = spec.get("fields", {})
        if self.mapping(fields, q + ".fields"):
            for fid, fs in fields.items():
                self.field_definition(fid, fs, q)
        relations = spec.get("relations", {})
        if self.mapping(relations, q + ".relations"):
            for rid, rs in relations.items():
                self.relation_definition(rid, rs, q, types)
        self.lifecycle(spec, q)
        views = spec.get("views", {})
        if self.mapping(views, q + ".views") and isinstance(fields, dict):
            for vid, columns in views.items():
                self.name(vid, q + ".views")
                self.names(columns, q + ".views." + str(vid), set(fields))
        self.names(spec.get("capabilities", []), q + ".capabilities", CAPABILITIES)

    def field_definition(self, fid: str, fs: dict, q: str) -> None:
        fp = q + ".fields." + str(fid)
        self.name(fid, fp)
        if not self.mapping(
            fs,
            fp,
            {
                "label",
                "type",
                "required",
                "many",
                "values",
                "min",
                "max",
                "min_length",
                "max_length",
            },
        ):
            return
        self.label(fs, fp)
        kind = fs.get("type")
        if not isinstance(kind, str) or kind not in VALUE_TYPES:
            self.fail(fp + ".type", "Неизвестный тип значения")
        for flag in ("required", "many"):
            if flag in fs and type(fs[flag]) is not bool:
                self.fail(fp + "." + flag, "Ожидается bool")
        for lo, hi, numeric in (("min", "max", True), ("min_length", "max_length", False)):
            for key in (lo, hi):
                if key not in fs:
                    continue
                v = fs[key]
                applicable = kind in (("integer", "number") if numeric else ("string",))
                valid = finite_number(v) if numeric else type(v) is int and v >= 0
                if not applicable or not valid:
                    self.fail(fp + "." + key, "Недопустимое ограничение для типа")
            if lo in fs and hi in fs:
                try:
                    if fs[lo] > fs[hi]:
                        self.fail(fp, "Нижняя граница больше верхней")
                except TypeError:
                    pass  # individual bounds already reported
        if kind == "enum":
            values = fs.get("values")
            if (
                not isinstance(values, list)
                or not values
                or any(not isinstance(v, str) or not v for v in values)
            ):
                self.fail(fp + ".values", "Нужен непустой список строк")
            elif len(set(values)) != len(values):
                self.fail(fp + ".values", "Повтор значения enum")
        elif "values" in fs:
            self.fail(fp + ".values", "values допустимо только для enum")

    def relation_definition(self, rid: str, rs: dict, q: str, types: dict) -> None:
        rp = q + ".relations." + str(rid)
        self.name(rid, rp)
        if not self.mapping(rs, rp, {"label", "targets", "many", "required"}):
            return
        self.label(rs, rp)
        if self.names(rs.get("targets"), rp + ".targets", set(types)):
            if not rs["targets"]:
                self.fail(rp + ".targets", "Нужен хотя бы один тип конца связи")
        for flag in ("many", "required"):
            if flag in rs and type(rs[flag]) is not bool:
                self.fail(rp + "." + flag, "Ожидается bool")

    def lifecycle(self, spec: dict, q: str) -> None:
        states = spec.get("states", [])
        states_ok = self.names(states, q + ".states")
        if states_ok:
            labels = spec.get("state_labels", {})
            if self.mapping(labels, q + ".state_labels"):
                for key, value in labels.items():
                    if key not in states or not isinstance(value, str) or not value.strip():
                        self.fail(q + ".state_labels", "Нужна подпись объявленного состояния")
            initial = spec.get("initial")
            if states and initial not in states:
                self.fail(q + ".initial", "Начальное состояние должно существовать")
            if not states and initial is not None:
                self.fail(q + ".initial", "Начальное состояние без жизненного цикла")
            transitions = spec.get("transitions", {})
            if self.mapping(transitions, q + ".transitions"):
                for start, ends in transitions.items():
                    if start not in states:
                        self.fail(q + ".transitions", "Неизвестное исходное состояние")
                    self.names(ends, q + ".transitions." + str(start), set(states))


def parse_model(document: Any) -> Registry:
    if not bounded_json(document):
        return Registry(issues=(Issue("model_budget", "", "Размер, вложенность или тип данных"),))
    parser = _Parser()
    data = copy.deepcopy(document)
    parser.parse_document(data)
    if parser.issues:
        return Registry(issues=tuple(parser.issues))
    return Registry(data)
