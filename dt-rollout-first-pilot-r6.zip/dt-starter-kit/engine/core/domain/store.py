"""ROLE-DATA-2B: vault-backed objects and proposals; only queue decisions publish.

No professional types, database migration or source rewriting. The global vault
transaction lock serializes cooperating proposal/record writers; note publication
uses the shared CAS writer. Prepared deterministic text permits crash recovery.
"""

from __future__ import annotations

import hashlib
import json
import unicodedata
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import frontmatter

from core.domain.load import load_model
from core.domain.objects import definition, validate_object
from core.domain.schema import MAX_BYTES, bounded_json
from core.file_lock import file_lock
from core.note_writer import sha256_bytes, write_note_atomic
from core.privacy import any_nda
from core.privacy_scope import exclusion_reason
from core.sleep.validate import contains_secret
from core.vault import RawYaml, set_frontmatter_fields_text

OBJECTS = "02-knowledge/objects/"
SYSTEM = "_system/domain/"
BEGIN, END = "<!-- domain:object -->", "<!-- /domain:object -->"


class DomainError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def digest(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()


def fold(value: str) -> str:
    return unicodedata.normalize("NFC", value).casefold().replace("ё", "е")


class DomainStore:
    def __init__(self, vault: Path):
        self.vault = Path(vault).absolute()
        self.lock = self.vault / SYSTEM / "transaction"

    def path(self, rel: str) -> Path:
        p = self.vault / rel
        if (
            Path(rel).is_absolute()
            or ".." in Path(rel).parts
            or "\\" in rel
            or not p.resolve().is_relative_to(self.vault.resolve())
            or any_nda(rel, p.resolve())
        ):
            raise DomainError("domain_path", "Путь вне разрешенного контура")
        cur = p
        while cur != self.vault:
            if cur.is_symlink():
                raise DomainError("domain_path", "Симлинки не разрешены")
            cur = cur.parent
        return p

    def raw(self, rel: str) -> bytes | None:
        path = self.path(rel)
        try:
            with path.open("rb") as f:
                data = f.read(MAX_BYTES + 1)
        except FileNotFoundError:
            return None
        if len(data) > MAX_BYTES:
            raise DomainError("domain_budget", "Превышен размер файла")
        return data

    def publish(self, rel: str, text: str, expected: str | None) -> dict:
        self.path(rel)
        return write_note_atomic(
            self.vault, rel, text, expect_sha=expected, allowed_prefix=rel.split("/")[0] + "/"
        )

    def json(self, rel: str) -> dict | None:
        raw = self.raw(rel)
        if raw is None:
            return None
        data = json.loads(raw)
        if not isinstance(data, dict) or not bounded_json(data):
            raise DomainError("domain_corrupt", "Повреждено состояние предметной модели")
        return data

    def put_json(self, rel: str, value: dict) -> None:
        raw = self.raw(rel)
        text = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2)
        if len(text.encode()) > MAX_BYTES:
            raise DomainError("domain_budget", "Превышен размер состояния")
        self.publish(rel, text, sha256_bytes(raw) if raw is not None else None)

    def object_rel(self, object_id: str) -> str:
        if not isinstance(object_id, str) or not object_id.strip():
            raise DomainError("domain_id", "Нужен стабильный ID объекта")
        return OBJECTS + "domain-" + hashlib.sha256(object_id.encode()).hexdigest() + ".md"

    def get(self, object_id: str) -> dict:
        rel = self.object_rel(object_id)
        raw = self.raw(rel)
        if raw is None:
            return {"ok": False, "code": "domain_not_found"}
        post = frontmatter.loads(raw.decode())
        obj = post.get("domain_object")
        if not isinstance(obj, dict) or obj.get("id") != object_id:
            raise DomainError("domain_corrupt", "Идентичность объекта не совпадает")
        if exclusion_reason(rel, dict(post.metadata)) and not self._personal_allowed(rel, post):
            raise DomainError("domain_private", "Объект закрыт политикой контура")
        if contains_secret(raw.decode()):
            raise DomainError("domain_secret", "Объект содержит возможный секрет")
        source_status = []
        for pin in post.get("domain_sources", []):
            current = self.source(pin["path"])
            source_status.append({"path": pin["path"], "unchanged": current == pin})
        return {
            "ok": True,
            "source_status": source_status,
            "object": obj,
            "version": sha256_bytes(raw),
            "path": rel,
            "note_id": post.get("id"),
            "sources": post.get("domain_sources", []),
        }

    def _personal_allowed(self, rel: str, post: Any) -> bool:
        from core.instance import is_personal

        return is_personal() and exclusion_reason(rel, dict(post.metadata)) == "personal"

    def history(self, object_id: str, offset: int = 0, limit: int = 20) -> dict:
        if type(offset) is not int or offset < 0 or type(limit) is not int or not 1 <= limit <= 100:
            raise DomainError("domain_args", "Некорректная страница истории")
        current = self.get(object_id)
        if not current.get("ok"):
            return current
        self.object_rel(object_id)  # validate identity, not a caller-controlled path
        prefix = SYSTEM + "history/" + hashlib.sha256(object_id.encode()).hexdigest() + "/"
        folder = self.path(prefix)
        rows = []
        paths = list(folder.glob("*.md")) if folder.exists() else []
        paths = [self.path(p.relative_to(self.vault).as_posix()) for p in paths]
        paths.sort(key=lambda p: (p.stat().st_mtime_ns, p.name), reverse=True)
        for path in paths[offset : offset + limit]:
            raw = self.raw(path.relative_to(self.vault).as_posix())
            if path.stem != sha256_bytes(raw):
                raise DomainError("domain_corrupt", "История изменена вне протокола")
            post = frontmatter.loads(raw.decode())
            if post.get("domain_object", {}).get("id") != object_id:
                raise DomainError("domain_corrupt", "Повреждена история объекта")
            reason = exclusion_reason(path.relative_to(self.vault).as_posix(), dict(post.metadata))
            if reason and not self._personal_allowed(path.relative_to(self.vault).as_posix(), post):
                raise DomainError("domain_private", "История закрыта политикой контура")
            for pin in post.get("domain_sources", []):
                self.source(pin["path"])
            rows.append(
                {
                    "version": sha256_bytes(raw),
                    "object": post["domain_object"],
                    "modified": str(post.get("modified") or ""),
                    "sources": post.get("domain_sources", []),
                }
            )
        return {
            "ok": True,
            "versions": rows,
            "total": len(paths),
            "offset": offset,
            "more": offset + limit < len(paths),
        }

    def source(self, rel: str) -> dict:
        if (
            not isinstance(rel, str)
            or not rel.endswith(".md")
            or any(p.startswith(("_", ".")) and p != "_legacy" for p in Path(rel).parts)
            or rel.startswith(OBJECTS)
        ):
            raise DomainError("domain_source", "Нужна исходная заметка доступного vault")
        # Path/privacy before opening. No source_path lifting, network or external files.
        reason = exclusion_reason(rel)
        from core.instance import is_personal

        if reason and not (reason == "personal" and is_personal()):
            raise DomainError("domain_source", "Источник закрыт политикой контура")
        raw = self.raw(rel)
        if raw is None:
            raise DomainError("domain_source", "Источник не найден")
        post = frontmatter.loads(raw.decode())
        reason = exclusion_reason(rel, dict(post.metadata))
        if (
            (reason and not (reason == "personal" and is_personal()))
            or any_nda(str(post.get("source_path") or ""))
            or contains_secret(raw.decode())
        ):
            raise DomainError("domain_source", "Источник закрыт политикой контура")
        for key in ("privacy", "visibility", "access"):
            value = post.get(key)
            if value and value not in ("work", "public", "internal", "personal", "private"):
                raise DomainError("domain_source", "Неизвестная политика источника")
        return {
            "path": rel,
            "note_id": str(post.get("id") or rel[:-3]),
            "title": str(post.get("title") or post.get("id") or rel[:-3]),
            "sha256": sha256_bytes(raw),
        }

    def linked(self, obj: dict) -> tuple[list, list]:
        related, pins = [], []
        for val in obj.get("relations", {}).values():
            refs = val if isinstance(val, list) else [val]
            for ref in refs:
                if not isinstance(ref, dict) or not isinstance(ref.get("id"), str):
                    continue  # shared validator reports the shape
                if ref["id"] == obj.get("id"):
                    related.append(obj)
                    continue
                found = self.get(ref["id"])
                if found.get("ok") and not any(x["id"] == ref["id"] for x in related):
                    related.append(found["object"])
                    pins.append({"id": ref["id"], "version": found["version"]})
        return related, pins

    def search(
        self,
        registry: Any,
        query: str = "",
        type_id: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> dict:
        if not isinstance(query, str) or type(offset) is not int or not 0 <= offset <= 2000:
            raise DomainError("domain_args", "Некорректный запрос")
        if type(limit) is not int or not 1 <= limit <= 100:
            raise DomainError("domain_args", "Лимит от 1 до 100")
        if type_id is not None and definition(registry, type_id) is None:
            raise DomainError("domain_type", "Неизвестный тип")
        folder = self.path(OBJECTS)
        rows, warnings = [], []
        # Bound inventory before parsing and reject symlinks in path(), before content.
        paths = []
        if folder.exists():
            for path in folder.glob("*.md"):
                paths.append(path)
                if len(paths) > 2000:
                    break
        paths.sort()
        truncated = len(paths) > 2000
        for path in paths[:2000]:
            try:
                rel = path.relative_to(self.vault).as_posix()
                raw = self.raw(rel)
                if raw is None:
                    continue
                post = frontmatter.loads(raw.decode())
                obj = post.get("domain_object")
                if not isinstance(obj, dict):
                    raise DomainError("domain_corrupt", "Некорректная запись")
                found = self.get(obj.get("id"))
                if found.get("path") != rel:
                    raise DomainError("domain_corrupt", "Имя файла не соответствует ID")
                spec = definition(registry, obj.get("type"), obj.get("version"))
                if spec is None or not validate_object(registry, obj)["ok"]:
                    raise DomainError("domain_corrupt", "Объект не соответствует своей схеме")
                if "search" not in spec.get("capabilities", []):
                    continue
                if type_id and obj.get("type") != type_id:
                    continue
                if not all(
                    t
                    in fold(
                        json.dumps(obj, ensure_ascii=False)
                        + " "
                        + json.dumps(spec, ensure_ascii=False)
                        + " "
                        + registry.document["types"][obj["type"]]["label"]
                    )
                    for t in fold(query).split()
                ):
                    continue
                keys = spec.get("views", {}).get("summary", list(spec.get("fields", {}))[:3])
                summary = {k: obj.get("fields", {}).get(k) for k in keys}
                rows.append(
                    {
                        "id": obj["id"],
                        "type": obj["type"],
                        "fields": summary,
                        "schema_version": obj["version"],
                        "state": obj.get("state"),
                        "version": sha256_bytes(raw),
                        "path": rel,
                        "note_id": post.get("id"),
                    }
                )
            except (ValueError, OSError, UnicodeError) as exc:
                warnings.append({"code": "domain_partial", "reason": type(exc).__name__})
        return {
            "ok": True,
            "objects": rows[offset : offset + limit],
            "total": len(rows),
            "offset": offset,
            "more": offset + limit < len(rows),
            "complete": not truncated and not warnings,
            "warnings": warnings,
            "scan_limit": 2000,
            "truncated": truncated,
        }

    def render(self, obj: dict, sources: list, registry: Any, old: bytes | None) -> str:
        spec = definition(registry, obj["type"], obj["version"])
        ctx = {
            "object": {
                "fields": [
                    {"label": f["label"], "value": obj.get("fields", {}).get(k)}
                    for k, f in spec.get("fields", {}).items()
                ]
            }
        }
        block = (
            BEGIN
            + "\n"
            + "\n".join(
                "- "
                + f["label"]
                + ": "
                + json.dumps(f["value"], ensure_ascii=False).replace("<", "&lt;")
                for f in ctx["object"]["fields"]
            )
            + "\n"
            + END
        )
        lines = []
        if obj.get("state") is not None:
            lines.append(
                "- Состояние: " + spec.get("state_labels", {}).get(obj["state"], obj["state"])
            )
        for key, refs in obj.get("relations", {}).items():
            label = spec.get("relations", {}).get(key, {}).get("label", key)
            lines.append("- " + label + ": " + json.dumps(refs, ensure_ascii=False))
        if sources:
            lines.append("Основания: " + ", ".join(s["note_id"] for s in sources))
        block = block.replace(END, "\n".join(lines).replace("<", "&lt;") + "\n" + END)
        title = next(
            (str(v) for v in obj.get("fields", {}).values() if isinstance(v, str)), obj["id"]
        )
        fields = {
            "domain_object": obj,
            "domain_sources": sources,
            "title": title,
            "modified": datetime.now(UTC).isoformat(),
        }
        if old is None:
            post = frontmatter.Post(
                "# Предметный объект\n\n" + block,
                id="domain-" + hashlib.sha256(obj["id"].encode()).hexdigest(),
                type="note",
                created=fields["modified"],
                **fields,
            )
            return frontmatter.dumps(post) + "\n"
        text = old.decode()
        body = frontmatter.loads(text).content
        if body.count(BEGIN) != 1 or body.count(END) != 1 or body.index(BEGIN) >= body.index(END):
            raise DomainError("domain_block", "Управляемый блок изменен; нужна ручная сверка")
        start = text.rfind(BEGIN)
        end = text.rfind(END)
        text = text[:start] + block + text[end + len(END) :]
        values = {
            k: RawYaml(json.dumps(v, ensure_ascii=False)) if isinstance(v, (dict, list)) else v
            for k, v in fields.items()
        }
        return set_frontmatter_fields_text(text, values)[0]

    def propose(self, obj: dict, sources: list, expected: str, model_version: str) -> dict:
        with file_lock(self.lock):
            loaded = load_model(self.vault)
            if not loaded.present or not loaded.registry.ok or loaded.version != model_version:
                raise DomainError("domain_model_stale", "Модель изменилась или недоступна")
            if len(json.dumps(obj, ensure_ascii=False).encode()) > 32768:
                raise DomainError("domain_budget", "Объект больше 32 КиБ")
            old = self.get(obj.get("id"))
            if (old.get("version") or "") != expected:
                raise DomainError("domain_stale", "Объект изменился; перечитайте его")
            related, pins = self.linked(obj)
            checked = validate_object(
                loaded.registry, obj, related=related, previous=old.get("object")
            )
            if not checked["complete"]:
                return checked
            spec = definition(loaded.registry, obj["type"], obj["version"])
            if "form" not in spec.get("capabilities", []):
                raise DomainError("domain_capability", "Редактирование типа не объявлено")
            if not old.get("ok") and spec.get("states") and obj.get("state") != spec["initial"]:
                raise DomainError(
                    "domain_initial", "Новый объект должен начать с начального состояния"
                )
            if (
                not isinstance(sources, list)
                or len(sources) > 20
                or len(set(sources)) != len(sources)
            ):
                raise DomainError("domain_sources", "Нужен список до 20 разных заметок")
            if contains_secret(json.dumps(obj, ensure_ascii=False)):
                raise DomainError("domain_secret", "Объект содержит возможный секрет")
            source_pins = [self.source(s) for s in sources]
            if old.get("object") == obj and old.get("sources") == source_pins:
                return {"ok": True, "status": "unchanged", "path": old["path"]}
            request = {
                "object": obj,
                "sources": source_pins,
                "expected": expected,
                "model_version": model_version,
                "related": pins,
            }
            pid = digest(request)
            rel = SYSTEM + "proposals/" + pid + ".json"
            existing = self.json(rel)
            if existing:
                return {
                    "ok": True,
                    "id": pid,
                    "card_id": "domain:" + pid,
                    "status": existing["status"],
                    "duplicate": True,
                }
            old_raw = self.raw(self.object_rel(obj["id"]))
            text = self.render(obj, source_pins, loaded.registry, old_raw)
            row = {
                **request,
                "id": pid,
                "status": "pending",
                "text": text,
                "after": sha256_bytes(text.encode()),
                "at": datetime.now(UTC).isoformat(),
            }
            self.put_json(rel, row)
            return {"ok": True, "id": pid, "card_id": "domain:" + pid, "status": "pending"}

    def pending(self) -> list[dict]:
        folder = self.path(SYSTEM + "proposals/")
        rows = []
        paths = list(folder.glob("*.json")) if folder.exists() else []
        if len(paths) > 5000:
            raise DomainError("domain_budget", "Слишком много предложений; требуется обслуживание")
        for path in sorted(paths):
            row = self.json(path.relative_to(self.vault).as_posix())
            if row and row.get("status") == "pending":
                rows.append(row)
        return rows

    def proposal(self, pid: str) -> tuple[str, dict | None]:
        if (
            not isinstance(pid, str)
            or len(pid) != 64
            or any(c not in "0123456789abcdef" for c in pid)
        ):
            raise DomainError("domain_id", "Неизвестный ID предложения")
        rel = SYSTEM + "proposals/" + pid + ".json"
        return rel, self.json(rel)

    def decide(self, pid: str, action: str) -> dict:
        with file_lock(self.lock):
            rel, row = self.proposal(pid)
            if row is None or row["status"] != "pending":
                return {"outcome": "stale", "detail": "Предложение уже решено или отсутствует"}
            if action == "reject":
                if row.get("accepted_at"):
                    raw = self.raw(self.object_rel(row["object"]["id"]))
                    current = sha256_bytes(raw) if raw is not None else ""
                    if current != row["expected"]:
                        raise DomainError(
                            "domain_prepared",
                            "Запись могла завершиться; сначала восстановите квитанцию",
                        )
                row["status"] = "rejected"
                self.put_json(rel, row)
                return {"outcome": "rejected", "effects": ["Предложение отклонено"]}
            if action != "approve":
                raise DomainError("domain_action", "Неизвестное действие")
            loaded = load_model(self.vault)
            request = {
                k: row[k] for k in ("object", "sources", "expected", "model_version", "related")
            }
            if digest(request) != pid or sha256_bytes(row["text"].encode()) != row["after"]:
                raise DomainError("domain_corrupt", "Предложение изменено вне протокола")
            if frontmatter.loads(row["text"]).get("domain_object") != row["object"]:
                raise DomainError("domain_corrupt", "План записи не соответствует объекту")
            obj = row["object"]
            target = self.object_rel(obj["id"])
            raw = self.raw(target)
            current = sha256_bytes(raw) if raw is not None else ""

            def accepted_text() -> str:
                if not row.get("accepted_at"):
                    return row["text"]
                metadata = {"modified": row["accepted_at"], "domain_proposal": pid}
                if not row["expected"]:
                    metadata["created"] = row["accepted_at"]
                return set_frontmatter_fields_text(row["text"], metadata)[0]

            text = accepted_text()
            after = sha256_bytes(text.encode())
            # A prepared publication is finalizable even if the model changed after the write.
            if not row.get("accepted_at") or current != after:
                if not loaded.registry.ok or loaded.version != row["model_version"]:
                    raise DomainError(
                        "domain_model_stale", "Модель изменилась; пересоберите предложение"
                    )
                if current != row["expected"]:
                    raise DomainError("domain_stale", "Цель изменена после предложения")
                related, pins = self.linked(obj)
                if (
                    pins != row["related"]
                    or not validate_object(loaded.registry, obj, related=related)["complete"]
                ):
                    raise DomainError("domain_stale", "Связанные объекты изменились")
                if [self.source(s["path"]) for s in row["sources"]] != row["sources"]:
                    raise DomainError("domain_source_stale", "Источники изменились")
                if not row.get("accepted_at"):
                    row["accepted_at"] = datetime.now(UTC).isoformat()
                    self.put_json(rel, row)  # durable intent, before note/history publication
                    text = accepted_text()
                if raw is not None:
                    hist = (
                        SYSTEM
                        + "history/"
                        + hashlib.sha256(obj["id"].encode()).hexdigest()
                        + "/"
                        + current
                        + ".md"
                    )
                    historical = self.raw(hist)
                    if historical is None:
                        self.publish(hist, raw.decode(), None)
                    elif historical != raw:
                        raise DomainError("domain_history", "Исторический снимок изменен")
                self.publish(target, text, row["expected"] or None)
            row["status"] = "applied"
            self.put_json(rel, row)
            return {
                "outcome": "applied",
                "effects": ["Объект сохранен: " + target],
                "path": target,
                "index_pending": True,
            }
