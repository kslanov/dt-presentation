"""Embeddings — local BGE-M3 via sentence-transformers (architecture §2).

Dense, multilingual (strong Russian) embeddings, dim 1024, L2-normalized for
cosine/inner-product search. The model is loaded lazily and once per process.

Design note — the :class:`Embedder` interface exists so the backend can be
swapped later (e.g. an API fallback such as voyage-multilingual-2). Per ТЗ we
implement ONLY the local BGE-M3 target. If the local model fails to load
(RAM/MPS), we raise an explicit :class:`EmbeddingModelError` with diagnostics —
we never silently fall back to a remote API.

Query vs document: BGE-M3 dense retrieval is symmetric — the official usage
prepends no instruction to queries (unlike e5-style models). So ``embed_query``
embeds the raw text, identically to documents.
"""

from __future__ import annotations

import logging
import os
import threading
import time

# Route BGE-M3 ops that have no MPS kernel to CPU *per op* instead of silently
# hanging the whole process (the 20-hour stall we hit). This MUST be set BEFORE
# torch is first imported — including transitively via sentence-transformers — so
# we set it at module import, ahead of every (lazy) ``import torch`` below. MPS
# stays the default device, so the bulk of the work still runs on the GPU and a
# full run drops to ~20–40 min; only unsupported ops trickle to CPU.
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

# SYNC-OFFLINE-1 insurance: bound EVERY huggingface_hub network op so a background
# run can never hang forever on a socket read (the 36h stall: the Mac slept mid-
# read of the model-update check → half-dead ESTABLISHED, infinite read). At a live
# cache the load is offline (``local_files_only``; PART-1) so these never fire — but
# if any legitimate network call remains, it now times out instead of wedging.
# ETAG timeout guards the metadata/HEAD check that actually hung; DOWNLOAD the body.
os.environ.setdefault("HF_HUB_ETAG_TIMEOUT", "10")
os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "30")

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

from core.shape_buckets import (
    ShapeCounter,
    bucket_for,
    pad_texts,
    padding_kwargs,
    token_lengths,
    tokenizer_of,
)

if TYPE_CHECKING:
    import numpy as np

logger = logging.getLogger(__name__)

__all__ = [
    "Embedder",
    "BGEEmbedder",
    "EmbeddingModelError",
    "EMBEDDING_DIM",
    "MODEL_NAME",
    "get_embedder",
    "embed_texts",
    "embed_query",
]

MODEL_NAME = "BAAI/bge-m3"
EMBEDDING_DIM = 1024

# Hard cap on tokens per sequence. BGE-M3 supports up to 8192, but a single
# pathological long chunk (e.g. a legacy note the chunker under-split) padded to
# that length blows up memory. The chunker already targets 500–800 tokens; this
# is a backstop so one anomalous chunk can't allocate a giant tensor.
MAX_SEQ_LENGTH = 1024

# Only the files needed for dense embeddings: tokenizer/config + ONE weights file
# (~2.27GB), never the onnx tree. KIT-MODELS-1 (08.11): на Hub у BAAI/bge-m3 весов в
# ``*.safetensors`` НЕТ - только ``pytorch_model.bin``; шаблон с одним safetensors на чистой
# машине качал 21 МБ служебных файлов и ни байта весов (у владельца работало только потому, что
# в кэше лежал старый ``pytorch_model.bin``). Оба формата в списке; какой из них реально качать,
# решает ``core.install.models.prefer_single_weights`` по перечню файлов репозитория (safetensors,
# если есть, иначе bin - двойной загрузки нет). Офлайн-резолв берет то, что лежит в кэше.
_ALLOW_PATTERNS = [
    "config.json",
    "config_sentence_transformers.json",
    "sentence_bert_config.json",
    "modules.json",
    "tokenizer.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
    "sentencepiece.bpe.model",
    "1_Pooling/*",
    "*.safetensors",
    "pytorch_model.bin",
]


def _download_allowed() -> bool:
    """Разрешён ли разовый онлайн-докач модели (SYNC-OFFLINE-1).

    По умолчанию НЕТ — reindex офлайн (Path B). Включается только явным
    ``DT_EMBED_ALLOW_DOWNLOAD=1`` (``1``/``true``/``yes``) для разового прогрева кэша.
    """
    return os.environ.get("DT_EMBED_ALLOW_DOWNLOAD", "").strip().lower() in {
        "1", "true", "yes",
    }


class EmbeddingModelError(RuntimeError):
    """Raised when the local embedding model cannot be loaded or run.

    Carries diagnostics so a failure to start BGE-M3 (RAM/MPS) is a visible
    blocker rather than a silent degradation.
    """


class Embedder(ABC):
    """Interface for embedding backends. Implementations return (n, dim) arrays."""

    @abstractmethod
    def embed(self, texts: list[str], batch_size: int | None = None) -> np.ndarray:
        """Embed a list of texts into normalized vectors."""

    @property
    @abstractmethod
    def dim(self) -> int:
        """Embedding dimensionality."""

    @property
    def model_id(self) -> str:
        """Идентификатор модели (VEC-REUSE-1 п.5): вектор из индекса реюзается только при
        совпадении с меткой модели индекса. Фейки без переопределения = модель по умолчанию."""
        return MODEL_NAME

    @property
    def device(self) -> str:
        """Compute device the embedder runs on (for diagnostics/stats)."""
        return "unknown"

    @property
    def fallback_reason(self) -> str:
        """Почему устройство сменилось (``mps→cpu: …``); ``""`` — не менялось.

        WAVE0-HYGIENE п.7 (аудит B7): фолбэк MPS→CPU был немым — в логах только второй
        «Loading SentenceTransformer», причина проглатывалась. Теперь причина копится здесь
        и уходит в итоги reindex / событие index / doctor.
        """
        return ""

    @property
    def fallback_info(self) -> dict[str, Any]:
        """Структурная причина фолбэка (RESOURCE-1 п.2): ``{reason, at, kind, retries}``.

        ``at`` — ISO-время UTC смены устройства, ``kind`` — ``oom`` | ``error`` | ``load``,
        ``retries`` — сколько раз перед уходом на CPU уменьшали батч (только ``oom``).
        Пусто — фолбэка нет. Эти поля пересекают границу процесса в ответе ``/internal/embed``.
        """
        reason = self.fallback_reason
        return {"reason": reason, "at": "", "kind": "", "retries": 0} if reason else {}

    @property
    def request_info(self) -> dict[str, int]:
        """Счётчики OOM, набежавшие в ПОСЛЕДНЕМ ``embed`` этого потока (точная дельта запроса;
        демон отдает её клиенту: прогон считает свои OOM, а не жизнь демона). Пусто у фейков."""
        return {}

    @property
    def embed_stats(self) -> dict[str, Any]:
        """Накопленные за жизнь процесса счётчики: чанки/секунды по устройствам, OOM-повторы.

        WAVE1-MEASURE п.5: доля чанков на MPS/CPU и скорость — в отчёт reindex (по
        разности снимков до/после прогона). Пусто у фейков/бэкендов без учёта.
        """
        return {}

    def model_state(self) -> dict[str, Any]:
        """Состояние модели для ``/health.models``; фейки и бэкенды без выгрузки - пусто."""
        return {}

    def unload_if_idle(self, idle_s: float) -> bool:
        """Выгрузить модель после простоя (RESOURCE-1 п.4); по умолчанию - нечего выгружать."""
        return False

    def release_cache(self) -> None:
        """Release accelerator memory cached between encode calls (PERF-1).

        PyTorch's MPS allocator keeps freed tensors in a process-level cache
        that only ever grows across a long reindex; the streaming index loop
        calls this once per window so peak memory stays one-window-sized.
        No-op by default (CPU backends / test fakes) — override where it matters.
        """
        return None


# RESOURCE-2 п.5: с PyTorch 2.13 ``torch.mps.empty_cache()`` чистит еще и кэш графов MPSGraph
# (примечания к выпуску 2.13: «Clear the MPSGraph cache in torch.mps.empty_cache()», #181485). В
# 2.12 кэш графов (по ядру Metal на каждую уникальную форму тензора) не освобождался ничем и копил
# десятки ГБ ``IOAccelerator`` после ночного reindex. Отдельного вызова нет: это тот же
# ``empty_cache``.
GRAPH_CACHE_CLEAR_MIN_TORCH = (2, 13)


def torch_graph_cache_clear_supported() -> bool | None:
    """Чистит ли ``torch.mps.empty_cache()`` кэш графов MPS (torch ≥ 2.13). ``None`` - torch не
    импортируется (CLI без torch, подделки)."""
    try:
        import torch

        parts = tuple(int(x) for x in torch.__version__.split("+")[0].split(".")[:2])
    except Exception:  # noqa: BLE001 — нет torch или нестандартная версия
        return None
    return parts >= GRAPH_CACHE_CLEAR_MIN_TORCH


def release_mps_cache() -> bool:
    """Вернуть драйверу кэш аллокатора и (torch ≥ 2.13) кэш графов MPS: ``torch.mps.empty_cache()``.

    ``True`` - вызов был; нет torch/``torch.mps.empty_cache`` (старая сборка, подделка) - ``False``
    без исключения: освобождение кэша никогда не ломает запрос, который оно защищает."""
    try:
        import torch

        mps = getattr(torch, "mps", None)
        if mps is not None and hasattr(mps, "empty_cache"):
            mps.empty_cache()
            return True
    except Exception:  # noqa: BLE001, S110 — освобождение кэша не роняет прогон
        pass
    return False


def _detect_device() -> str:
    """Auto-pick a compute device: ``DT_EMBED_DEVICE`` override → MPS (Apple
    Silicon) → CUDA → CPU.

    The env override is the escape hatch when a backend misbehaves (e.g. forcing
    ``cpu`` if BGE-M3 hits an MPS kernel issue) — it short-circuits detection.
    """
    override = os.environ.get("DT_EMBED_DEVICE")
    if override and override.strip():
        return override.strip()
    try:
        import torch

        if torch.backends.mps.is_available():
            return "mps"
        if torch.cuda.is_available():
            return "cuda"
    except Exception:  # noqa: BLE001, S110 — torch import issues → CPU
        pass
    return "cpu"


def _default_batch_size(device: str) -> int:
    """Батч кодирования для устройства. RESOURCE-1 п.3: на MPS - по RAM машины (профиль
    :func:`core.resources.embed_profile`: 64/32/16), явный ``DT_EMBED_BATCH_SIZE`` побеждает;
    CUDA 64, CPU 32 - как было."""
    from core import resources

    return int(resources.embed_profile(device=device)["batch_size"])


def _dtype_for(device: str) -> str:
    """``fp16``/``fp32`` для устройства по профилю (:func:`core.resources.embed_profile`);
    на CPU - всегда fp32."""
    from core import resources

    return str(resources.embed_profile(device=device)["dtype"])


# WAVE1-MEASURE п.5: MPS OOM → батч/2 и повтор НА MPS; на CPU — только после стольких
# подряд неудач на одном срезе (при 2,96 ГБ прогон уходил на CPU с первой же OOM-ошибки,
# хотя вдвое меньший батч помещался). Env ``DT_EMBED_OOM_RETRIES``.
DEFAULT_OOM_RETRIES = 4


def _oom_retries() -> int:
    raw = os.environ.get("DT_EMBED_OOM_RETRIES")
    if raw and raw.strip().isdigit():
        return max(0, int(raw.strip()))
    return DEFAULT_OOM_RETRIES


# RESOURCE-1 п.1: фолбэк MPS→CPU - на время, не навсегда. Через ``DT_EMBED_MPS_RETRY_S`` после
# фолбэка следующий ``embed`` пробует MPS снова (перезагрузка модели на MPS под тем же локом).
# ``0`` - проб нет (липкий фолбэк, как было); явный ``DT_EMBED_DEVICE=cpu`` проб не имеет по
# построению (домашнее устройство - cpu).
DEFAULT_MPS_RETRY_S = 900.0


def _mps_retry_s() -> float:
    raw = (os.environ.get("DT_EMBED_MPS_RETRY_S") or "").strip()
    try:
        value = float(raw) if raw else DEFAULT_MPS_RETRY_S
    except ValueError:
        return DEFAULT_MPS_RETRY_S
    return max(0.0, value)


def _now() -> float:
    """Монотонные секунды для таймера пробы MPS (в тестах подменяется)."""
    return time.monotonic()


def _is_oom(exc: BaseException) -> bool:
    """Нехватка памяти ускорителя (MPS/CUDA): по имени класса и тексту — torch их не унифицирует."""
    if "outofmemory" in type(exc).__name__.lower():
        return True
    text = str(exc).lower()
    return any(
        marker in text
        for marker in ("out of memory", "invalid buffer size", "mps allocated")
    )


class BGEEmbedder(Embedder):
    """Local BGE-M3 dense embedder (the production target)."""

    def __init__(self, device: str | None = None, cache_folder: str | None = None,
                 shape_buckets: bool = False) -> None:
        self._device = device or _detect_device()
        # RESOURCE-2 п.4: корзины форм (включает воркер моделей); ``_buckets_ok`` гаснет, если
        # библиотека/модель корзин не умеет (один WARNING, дальше - обычный encode)
        self._buckets = bool(shape_buckets)
        self._buckets_ok = True
        self._shapes = ShapeCounter()
        # RESOURCE-1 п.1: «домашнее» устройство (куда вернуться после фолбэка), момент фолбэка
        # (монотонные секунды; ``None`` - не было), счетчики проб, идет ли проба (до первого
        # удачного encode на MPS восстановление не объявляется).
        self._home_device = self._device
        self._fallback_mono: float | None = None
        self._mps_retries = 0
        self._mps_recovered = 0
        self._probing = False
        # RESOURCE-1 п.4: когда модель поднята/использована (монотонные секунды + ISO для /health);
        # ``None`` - модель не загружена.
        self._loaded_mono: float | None = None
        self._loaded_wall = ""
        self._used_mono: float | None = None
        self._used_wall = ""
        self._unloads = 0
        self._cache_folder = cache_folder
        self._batch_size = _default_batch_size(self._device)
        self._dtype = _dtype_for(self._device)  # RESOURCE-1 п.3: в чем считает модель
        self._model = None  # lazily loaded
        # DAEMON-1-SPIKE: один эмбеддер на процесс, вызовы из потоков (демон на несколько хостов,
        # веб-пульт) - MPS/torch не потокобезопасны; RLock: ``embed`` зовет внутренние шаги.
        self._lock = threading.RLock()
        self._fallback_reason = ""
        self._fallback_at = ""  # RESOURCE-1: ISO UTC момента фолбэка
        self._fallback_kind = ""
        self._fallback_retries = 0
        self._tl = threading.local()  # дельта OOM последнего embed() этого потока
        # WAVE1-MEASURE п.5: учёт для index_report (кумулятивно за процесс).
        self._chunks_by_device: dict[str, int] = {}
        self._seconds_by_device: dict[str, float] = {}
        self._oom_retries_done = 0
        self._oom_cpu_fallbacks = 0

    def _load_on(self, device: str, cache: str) -> Any:
        from huggingface_hub import snapshot_download
        from sentence_transformers import SentenceTransformer

        # SYNC-OFFLINE-1 (Path B on практике): reindex must NOT touch the network.
        # Resolve the snapshot from the local cache ONLY (``local_files_only`` — no
        # Hub round-trip, so at a live cache there are zero network calls and the
        # eternal-read class is impossible). A cache MISS is a **hard, honest error**
        # with a hint — NOT a silent trip to the Hub (that silent fallback caused the
        # 36h hang). A one-time online fetch is opt-in only, via
        # ``DT_EMBED_ALLOW_DOWNLOAD=1`` (with the timeouts above as a backstop).
        try:
            local_path = snapshot_download(
                MODEL_NAME,
                cache_dir=cache,
                allow_patterns=_ALLOW_PATTERNS,
                local_files_only=True,
            )
        except Exception as exc:  # cache miss / offline resolve failed (re-raised below)
            if not _download_allowed():
                raise EmbeddingModelError(
                    f"Модель {MODEL_NAME!r} не найдена в локальном кэше ({cache}). "
                    "reindex работает офлайн (Path B) и в сеть НЕ ходит. Прогрей кэш "
                    "один раз явным онлайн-прогоном: "
                    f"DT_EMBED_ALLOW_DOWNLOAD=1 <reindex/dt-sync index> "
                    f"(качается ~2.27GB: {MODEL_NAME}). "
                    f"Исходная ошибка resolve: {exc!r}"
                ) from exc
            # Explicit opt-in: one-time network fetch of the allow-listed files (one
            # weights format - see prefer_single_weights).
            from core.install.models import prefer_single_weights

            local_path = snapshot_download(
                MODEL_NAME,
                cache_dir=cache,
                allow_patterns=prefer_single_weights(MODEL_NAME, _ALLOW_PATTERNS),
            )

        # Load strictly from the resolved local path; local_files_only=True stops
        # SentenceTransformer from re-syncing the repo by id (no Hub call ever, even
        # on the opt-in download path — the files are already on disk by now).
        # RESOURCE-1 п.3: fp16 (профиль 16-31/<16 ГБ) - через model_kwargs; torch_dtype понимают и
        # старый transformers, и новый (там он оставлен для совместимости). На CPU - только fp32.
        kwargs: dict[str, Any] = {"device": device, "local_files_only": True}
        dtype = _dtype_for(device)
        if dtype == "fp16":
            import torch

            kwargs["model_kwargs"] = {"torch_dtype": torch.float16}
        model = SentenceTransformer(local_path, **kwargs)
        self._dtype = dtype  # после удачной загрузки: сбой пробы MPS не меняет dtype CPU
        return model

    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        started = time.perf_counter()
        self._ensure_model_body()
        self._mark_loaded(started)

    def _mark_loaded(self, started: float) -> None:
        """Модель поднята: метки для idle-выгрузки и ``/health.models`` + строка в логе."""
        from datetime import UTC, datetime

        self._loaded_mono = _now()
        self._loaded_wall = datetime.now(UTC).isoformat(timespec="seconds")
        logger.info("[embeddings] модель поднята за %.1f с (device=%s dtype=%s)",
                    time.perf_counter() - started, self._device, self._dtype)

    def _ensure_model_body(self) -> None:
        from core.config import models_path

        cache = self._cache_folder or str(models_path())
        try:
            self._model = self._load_on(self._device, cache)
            self._cap_seq_length()
        except EmbeddingModelError:
            # SYNC-OFFLINE-1: offline cache-miss hint from _load_on is device-
            # independent — surface it as-is (not an MPS kernel issue → no CPU retry).
            raise
        except Exception as exc:
            # MPS can fail to load/run some kernels for BGE-M3. Rather than hard-fail
            # on Apple Silicon, fall back once to CPU (still local, just slower) so
            # indexing keeps working; the override DT_EMBED_DEVICE=cpu makes it sticky.
            if self._device == "mps":
                self._note_fallback("загрузка модели", exc)
                try:
                    self._model = self._load_on("cpu", cache)
                    self._set_device("cpu")
                    self._cap_seq_length()
                    return
                except Exception as cpu_exc:  # noqa: BLE001 — fall through to the raise below
                    logger.error(
                        "[embeddings] загрузка на CPU после сбоя MPS тоже не удалась: %r", cpu_exc
                    )
            raise EmbeddingModelError(
                f"Failed to load local embedding model {MODEL_NAME!r} "
                f"on device {self._device!r} (cache: {cache}). "
                "This is a hard blocker — no silent API fallback. "
                "Check available RAM/disk, MPS/torch install, and network for the "
                f"first ~2GB download. Original error: {exc!r}"
            ) from exc

    def _cap_seq_length(self) -> None:
        """Clamp the model's max sequence length to :data:`MAX_SEQ_LENGTH`.

        Bounds per-sequence padding so one anomalously long chunk can't allocate
        a giant tensor (a contributor to the 14 GB full-rebuild stall).
        """
        model = self._model
        if model is None:
            return
        current = getattr(model, "max_seq_length", None)
        if current is None or current > MAX_SEQ_LENGTH:
            model.max_seq_length = MAX_SEQ_LENGTH

    def _set_device(self, device: str) -> None:
        """Сменить устройство вместе с батчем и dtype профиля (CPU - fp32, MPS - по RAM)."""
        self._device = device
        self._batch_size = _default_batch_size(device)
        self._dtype = _dtype_for(device)

    @property
    def dim(self) -> int:
        return EMBEDDING_DIM

    @property
    def device(self) -> str:
        return self._device

    @property
    def dtype(self) -> str:
        return self._dtype

    @property
    def fallback_reason(self) -> str:
        return self._fallback_reason

    @property
    def fallback_info(self) -> dict[str, Any]:
        if not self._fallback_reason:
            return {}
        return {"reason": self._fallback_reason, "at": self._fallback_at,
                "kind": self._fallback_kind, "retries": self._fallback_retries}

    @property
    def request_info(self) -> dict[str, int]:
        return dict(getattr(self._tl, "req", {}) or {})

    def _note_fallback(
        self, stage: str, exc: BaseException, *, kind: str = "error", retries: int = 0
    ) -> None:
        """WARNING с причиной + запись в :attr:`fallback_reason` (no-silent-fallback, п.7)."""
        from datetime import UTC, datetime

        self._fallback_reason = f"mps→cpu ({stage}): {type(exc).__name__}: {exc}"[:400]
        self._fallback_at = datetime.now(UTC).isoformat(timespec="seconds")
        self._fallback_kind = "load" if stage == "загрузка модели" else kind
        self._fallback_retries = retries
        self._fallback_mono = _now()  # новый отсчет до следующей пробы MPS
        self._probing = False
        logger.warning(
            "[embeddings] ФОЛБЭК MPS→CPU (%s): %r — прогон продолжится на CPU, медленнее; "
            "причина попадёт в итоги reindex/doctor (DT_EMBED_DEVICE=cpu делает выбор явным)",
            stage, exc,
        )

    def release_cache(self) -> None:
        """Flush the MPS allocator cache (PERF-1); no-op on CPU/CUDA-less setups.

        Best-effort by design: a failure to release cache must never break the
        run it is trying to protect.
        """
        if self._device != "mps":
            return
        # RESOURCE-1 п.3: освобождение - под тем же локом, что encode (MPS не потокобезопасен),
        # но не блокируясь: чужой embed в разгаре - он сам освободит кэш по завершении.
        if not self._lock.acquire(blocking=False):
            return
        try:
            release_mps_cache()
        finally:
            self._lock.release()

    @property
    def shape_count(self) -> int:
        """Уникальных форм тензоров, виденных моделью (счетчик корзин; 0 - корзины выключены)."""
        return self._shapes.count

    def _encode_bucketed(self, texts: list[str], pad_to: int) -> np.ndarray | None:
        """Батч одной формы ``(pad_to, корзина длины)``: тексты добиты пустыми строками до
        ``pad_to``, длина - до ближайшей корзины; результаты добивки отбрасываются. ``None`` -
        корзины недоступны (нет токенайзера/``processing_kwargs``): кодирует вызывающий."""
        import numpy as np

        model = self._model
        tok = tokenizer_of(model)
        if tok is None:
            self._buckets_ok = False
            logger.warning("[embeddings] корзины форм выключены: у модели нет токенайзера")
            return None
        cap = int(getattr(model, "max_seq_length", None) or MAX_SEQ_LENGTH)
        length = bucket_for(max(token_lengths(tok, texts, None, cap)), cap)
        batch = pad_texts(texts, max(pad_to, len(texts)))
        try:
            vectors = model.encode(
                batch, batch_size=len(batch), normalize_embeddings=True, convert_to_numpy=True,
                show_progress_bar=False, **padding_kwargs(length),
            )
        except TypeError as exc:
            if "processing_kwargs" not in str(exc):
                raise
            self._buckets_ok = False
            logger.warning("[embeddings] корзины форм выключены: sentence-transformers без "
                           "processing_kwargs (нужна версия ≥ 5.5): %s", exc)
            return None
        self._shapes.add(len(batch), length)
        return np.asarray(vectors)[: len(texts)]

    def _encode(self, texts: list[str], batch_size: int | None,
                pad_to: int | None = None) -> np.ndarray:
        import numpy as np

        vectors = None
        if self._buckets and self._buckets_ok and pad_to:
            vectors = self._encode_bucketed(texts, pad_to)
        if vectors is None:
            vectors = self._model.encode(
                texts,
                batch_size=batch_size or self._batch_size,
                normalize_embeddings=True,
                convert_to_numpy=True,
                show_progress_bar=False,
            )
        out = np.asarray(vectors, dtype=np.float32)
        if self._dtype == "fp16" and out.size:
            # fp16 нормирует с точностью ~1e-3: перенормируем в float32, чтобы норма была 1
            # (скалярное произведение в индексе = косинус), а вектор - тот же направлением
            norms = np.linalg.norm(out, axis=1, keepdims=True)
            out = out / np.where(norms > 0, norms, 1.0)
        return out

    def _switch_to_cpu(
        self, exc: BaseException | None = None, *, kind: str = "error", retries: int = 0
    ) -> bool:
        """Reload the model on CPU after an MPS failure; ``True`` on success.

        Companion to the load-time CPU fallback in :meth:`_ensure_model` — here we
        recover from an *encode-time* MPS kernel error so a multi-hour index run
        is not lost. The switch is sticky for the rest of the process.
        """
        from core.config import models_path

        if exc is not None:
            self._note_fallback("inference", exc, kind=kind, retries=retries)
        cache = self._cache_folder or str(models_path())
        try:
            started = time.perf_counter()
            self._model = self._load_on("cpu", cache)
            self._set_device("cpu")
            self._cap_seq_length()
            self._mark_loaded(started)
            return True
        except Exception as cpu_exc:  # noqa: BLE001 — fall through to the caller's raise
            logger.error("[embeddings] перезагрузка на CPU после сбоя MPS не удалась: %r", cpu_exc)
            return False

    @property
    def embed_stats(self) -> dict[str, Any]:
        return {
            "chunks_by_device": dict(self._chunks_by_device),
            "seconds_by_device": {k: round(v, 3) for k, v in self._seconds_by_device.items()},
            "oom_retries": self._oom_retries_done,
            "oom_cpu_fallbacks": self._oom_cpu_fallbacks,
            "batch_size": self._batch_size,
            "mps_retries": self._mps_retries,
            "mps_recovered": self._mps_recovered,
            "dtype": self._dtype,
        }

    def _maybe_probe_mps(self) -> None:
        """RESOURCE-1 п.1: спустя ``DT_EMBED_MPS_RETRY_S`` после фолбэка - модель заново на MPS.

        Вызывается в начале ``_embed_unlocked``, то есть ПОД ``RLock`` эмбеддера: параллельный
        ``embed`` не увидит модель в промежуточном состоянии (MPS не потокобезопасен, лок не
        ослаблялся). Таймер - ``_fallback_mono``, выставляется в ``_note_fallback``; фонового потока
        нет, проба ленивая (платит тот запрос, что пришел первым после интервала). Загрузка на
        MPS не удалась - CPU-модель остается, отсчет начинается заново; удалась - восстановление
        объявляется после ПЕРВОГО удачного encode на MPS (:meth:`_mark_recovered`), а снова OOM/сбой
        отправит на CPU обычным путем с новым ``fallback_at``.
        """
        if (
            self._device != "cpu"
            or self._home_device != "mps"
            or self._fallback_mono is None
            or self._probing
        ):
            return
        retry = _mps_retry_s()
        if retry <= 0 or _now() - self._fallback_mono < retry:
            return
        from core.config import models_path

        cache = self._cache_folder or str(models_path())
        self._mps_retries += 1
        logger.info(
            "[embeddings] проба MPS после фолбэка (прошло %.0f с, DT_EMBED_MPS_RETRY_S=%.0f; "
            "проба №%d)", _now() - self._fallback_mono, retry, self._mps_retries,
        )
        probe_started = time.perf_counter()
        try:
            model = self._load_on("mps", cache)
        except Exception as exc:  # noqa: BLE001 — остаемся на CPU, отсчет заново
            self._fallback_mono = _now()
            logger.warning(
                "[embeddings] проба MPS не удалась (%s: %s) - остаемся на CPU, следующая через "
                "%.0f с", type(exc).__name__, str(exc)[:160], retry,
            )
            return
        self._model = model
        self._set_device("mps")
        self._cap_seq_length()
        self._probing = True
        self._mark_loaded(probe_started)
        self.release_cache()

    def _mark_recovered(self) -> None:
        """Первый удачный encode на MPS после пробы: восстановление, причина фолбэка снимается."""
        self._probing = False
        self._mps_recovered += 1
        was = self._fallback_reason
        self._fallback_reason = ""
        self._fallback_at = ""
        self._fallback_kind = ""
        self._fallback_retries = 0
        self._fallback_mono = None
        logger.info("[embeddings] MPS восстановлен (проба №%d удалась; прежняя причина: %s)",
                    self._mps_retries, was[:160])

    def _touch(self) -> None:
        """Метка «использовалась сейчас» (для idle-выгрузки и ``/health.models``)."""
        from datetime import UTC, datetime

        self._used_mono = _now()
        self._used_wall = datetime.now(UTC).isoformat(timespec="seconds")

    def model_state(self) -> dict[str, Any]:
        """Срез для ``/health.models``: ``{state: loaded|unloaded, device, dtype, loaded_at,
        last_used, unloads}``. Без лока и без загрузки - дешево и не ждет идущий encode."""
        loaded = self._model is not None
        return {
            "state": "loaded" if loaded else "unloaded", "device": self._device,
            "dtype": self._dtype, "loaded_at": self._loaded_wall if loaded else "",
            "last_used": self._used_wall, "unloads": self._unloads,
        }

    def unload_if_idle(self, idle_s: float) -> bool:
        """RESOURCE-1 п.4: выгрузить модель, если ею не пользовались ``idle_s`` секунд.

        Под тем же ``RLock``, что encode, но без блокировки: лок занят - идет запрос, значит не
        простой (``False``). Следующий ``embed`` поднимет модель заново (:meth:`_ensure_model`,
        строка «модель поднята за N с»). ``True`` - выгрузили. Освобождает кэш аллокатора MPS и
        собирает мусор - иначе память процесса не возвращается."""
        if idle_s <= 0 or not self._lock.acquire(blocking=False):
            return False
        try:
            if self._model is None:
                return False
            last = max(m for m in (self._used_mono, self._loaded_mono, 0.0) if m is not None)
            idle = _now() - last
            if idle < idle_s:
                return False
            self._model = None
            self._loaded_mono = None
            self._unloads += 1
            import gc

            gc.collect()
            self.release_cache()
            logger.info("[embeddings] модель выгружена после %.0f с простоя (DT_EMBED_IDLE_UNLOAD_S"
                        "=%.0f); следующий запрос поднимет её заново", idle, idle_s)
            return True
        finally:
            self._lock.release()

    def _bump_req(self, key: str) -> None:
        req = getattr(self._tl, "req", None)
        if req is not None:
            req[key] = req.get(key, 0) + 1

    def _count(self, device: str, n: int, seconds: float) -> None:
        self._chunks_by_device[device] = self._chunks_by_device.get(device, 0) + n
        self._seconds_by_device[device] = self._seconds_by_device.get(device, 0.0) + seconds

    def _on_oom(self, exc: BaseException, bs: int, failures: int, limit: int) -> int | None:
        """MPS OOM на срезе из ``bs`` текстов: новый (вдвое меньший) батч или ``None`` → на CPU.

        Освобождает кэш аллокатора и держит уменьшенный батч до конца процесса —
        прогоняемый корпус тот же, второй раз упираться в тот же потолок незачем.
        """
        if failures > limit or bs <= 1:
            return None
        self.release_cache()
        smaller = max(1, bs // 2)
        self._batch_size = min(self._batch_size, smaller)
        self._oom_retries_done += 1
        self._bump_req("oom_retries")
        logger.warning(
            "[embeddings] MPS OOM (%s: %s) — батч %d→%d, повтор на MPS (%d из %d)",
            type(exc).__name__, str(exc)[:160], bs, smaller, failures, limit,
        )
        return smaller

    def embed(self, texts: list[str], batch_size: int | None = None) -> np.ndarray:
        """Потокобезопасная обертка: вызовы сериализуются (см. ``_embed_unlocked``)."""
        with self._lock:
            self._tl.req = {"oom_retries": 0, "oom_cpu_fallbacks": 0}
            try:
                return self._embed_unlocked(texts, batch_size)
            finally:
                self._touch()

    def _embed_unlocked(self, texts: list[str], batch_size: int | None = None) -> np.ndarray:
        """Embed ``texts`` срезами по батчу, с адаптацией под память ускорителя.

        WAVE1-MEASURE п.5. Срез за срезом (между срезами на MPS — ``empty_cache``):
        OOM на MPS → батч/2 и повтор ТОГО ЖЕ среза на MPS (уже посчитанное не
        теряется); после ``DT_EMBED_OOM_RETRIES`` подряд неудач (или при батче 1) —
        на CPU с WARNING и причиной. Любая другая ошибка MPS (не память) — на CPU сразу,
        как раньше. Зависание без исключения здесь не ловится (``DT_EMBED_DEVICE=cpu``).
        """
        import numpy as np

        if not texts:
            return np.empty((0, EMBEDDING_DIM), dtype=np.float32)
        self._maybe_probe_mps()
        self._ensure_model()
        parts: list[np.ndarray] = []
        at = 0
        # Приемка RESOURCE-1 (09.11): батч профиля - потолок для любого вызывающего. Запрошенный
        # ``batch_size`` может только уменьшить срез: ``/internal/embed`` с batch_size=256 на 16 ГБ
        # уронил демон не исключением OOM, а abort'ом MPSGraph («Failed to allocate MTLBuffer of
        # 16 GiB for oversized fused alloc») - его не поймать, поднимал launchd.
        full = max(1, min(batch_size or self._batch_size, self._batch_size))
        bs = max(1, min(full, len(texts)))
        failures = 0
        limit = _oom_retries()
        while at < len(texts):
            piece = texts[at : at + bs]
            device = self._device
            started = time.perf_counter()
            try:
                # pad_to: форма батча в корзинах - размер батча, а не длина запроса (иначе у
                # каждой длины запроса своя форма); после OOM ``_batch_size`` уже уменьшен
                vectors = self._encode(piece, bs, pad_to=min(full, self._batch_size))
            except Exception as exc:
                if device != "mps":
                    raise EmbeddingModelError(
                        f"Embedding inference failed on device {device!r}: {exc!r}"
                    ) from exc
                cause: BaseException = exc
                kind, used = "error", 0
                if _is_oom(exc):
                    failures += 1
                    smaller = self._on_oom(exc, bs, failures, limit)
                    if smaller is not None:
                        bs = smaller
                        continue
                    self._oom_cpu_fallbacks += 1
                    self._bump_req("oom_cpu_fallbacks")
                    kind, used = "oom", min(failures - 1, limit)
                    cause = RuntimeError(
                        f"MPS OOM: после {used} повторов с меньшим "
                        f"батчем (последний {bs}) память всё ещё не хватает "
                        f"(последняя ошибка: {exc})"
                    )
                # Не память либо исчерпаны повторы: перезагрузка на CPU один раз, остаток — там.
                if not self._switch_to_cpu(cause, kind=kind, retries=used):
                    raise EmbeddingModelError(
                        f"Embedding inference failed on device 'mps' and CPU reload "
                        f"failed: {cause!r}"
                    ) from exc
                bs = max(1, min(bs, self._batch_size))
                failures = 0
                continue
            self._count(device, len(piece), time.perf_counter() - started)
            if self._probing and device == "mps":
                self._mark_recovered()
            parts.append(vectors)
            at += len(piece)
            failures = 0
            if device == "mps" and at < len(texts):
                self.release_cache()  # между батчами: MPS-аллокатор не копит буферы
        return parts[0] if len(parts) == 1 else np.concatenate(parts, axis=0)


# Process-wide singleton (model loaded once).
_embedder: Embedder | None = None
_embedder_lock = threading.Lock()
_routed: Embedder | None = None


def _new_local_embedder() -> Embedder:
    """RESOURCE-2: демон-владелец моделей не грузит их сам - его эмбеддер это прокси к воркеру
    ``dt-models`` (:class:`core.models_worker.WorkerEmbedder`, тот же интерфейс); остальные процессы
    (CLI, ``DT_MODELS_WORKER=0``) грузят BGE-M3 у себя, как раньше."""
    from core import embed_daemon, models_worker

    if embed_daemon.is_model_owner() and models_worker.worker_enabled():
        return models_worker.WorkerEmbedder()
    return BGEEmbedder()


def local_embedder() -> Embedder:
    """Локальный эмбеддер процесса (BGE-M3, синглтон). Им считает демон на ``/internal/embed`` и
    откатывается клиент, когда демона нет; сама модель грузится лениво при первом ``embed`` (в
    демоне - в воркере, RESOURCE-2)."""
    global _embedder
    if _embedder is None:
        with _embedder_lock:  # два потока на холодном старте не создают два эмбеддера
            if _embedder is None:
                _embedder = _new_local_embedder()
    return _embedder


def get_embedder() -> Embedder:
    """Эмбеддер процесса для потребителей (индексатор, поиск, eval, плановые джобы).

    NIGHT-CHAIN-1: один эмбеддер на машину. Процесс, не владеющий моделью (не демон), при
    ``DT_EMBED_VIA_DAEMON`` не 0 получает маршрутизатор :class:`core.embed_daemon.RoutedEmbedder`:
    вектора считает демон (``/internal/embed``), при его недоступности - локальная загрузка.
    Демон и ``DT_EMBED_VIA_DAEMON=0`` - прежний локальный синглтон (:func:`local_embedder`)."""
    from core import embed_daemon

    if not embed_daemon.should_route():
        return local_embedder()
    global _routed
    if _routed is None:
        with _embedder_lock:
            if _routed is None:
                _routed = embed_daemon.RoutedEmbedder(local_embedder)
    return _routed


def set_embedder(embedder: Embedder) -> None:
    """Override the singleton (e.g. a fake in tests, or a future backend)."""
    global _embedder
    _embedder = embedder


def embed_texts(texts: list[str], batch_size: int | None = None) -> np.ndarray:
    """Embed a batch of texts → (n, 1024) normalized float32 array."""
    return get_embedder().embed(texts, batch_size=batch_size)


def embed_query(text: str) -> np.ndarray:
    """Embed a single query → (1024,) normalized float32 vector.

    No query instruction prefix — BGE-M3 dense retrieval is symmetric.
    """
    return get_embedder().embed([text])[0]
