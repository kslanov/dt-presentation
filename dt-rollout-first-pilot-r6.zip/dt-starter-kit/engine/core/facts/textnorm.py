"""Нормализация чисел и дат в ТЕКСТЕ - одна на экстрактор фактов и на сверку выхода (PROV-CITED-1).

Раньше разбор «654,1» / «1 200,50 ₸» жил внутри :mod:`core.facts.extract` как две копии, и сверка
цитат и чисел выхода (:mod:`core.cited`) вынуждена была писать свою - две нормализации разойдутся
на первом же «0,48 млн». Здесь - ЕДИНАЯ точка:

* :func:`parse_number` - строка → ``float`` (пробелы/неразрывные, запятая/точка);
* :func:`scan_numbers` - числа текста с масштабом (``млн``/``тыс.``/``млрд``), валютой, единицей и
  ``%`` - через :mod:`core.facts.units` (``detect_scale``/``detect_currency``/``detect_unit``/
  ``has_percent``), а не через свои словари;
* :func:`scan_dates` - даты текста (``14.11.2026``, ``2026-11-14``, «14 ноября 2026», «ноябрь
  2026») → ISO ``YYYY-MM-DD``/``YYYY-MM`` через :func:`core.facts.temporal._valid_date`.

Чистые функции, без I/O, сети и модели. ``value`` числа НИКОГДА не домножается на масштаб (как
``Fact.value_num``): ``base`` - производное, ``value × scale``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from core.facts.temporal import _valid_date
from core.facts.units import detect_currency, detect_scale, detect_unit, has_percent

__all__ = [
    "DateMention",
    "NumberMention",
    "digit_signature",
    "parse_number",
    "scan_dates",
    "scan_numbers",
    "scale_word",
]

_SPACES_RE = re.compile(r"[ \u00a0\u2009\u202f]+")  # пробел, неразрывный, тонкий, узкий


def parse_number(raw: str, *, lenient: bool = False) -> float | None:
    """«1 200,50» / «654,1» / «480» → число; не число → ``None``.

    Пробелы (в том числе неразрывные) убираются, запятая - десятичный разделитель. ``lenient``
    дополнительно понимает смесь разделителей («1.234,56», «1,234.56»: последний - десятичный,
    остальные - тысячные); без него смесь не число (как всегда было у экстрактора фактов).
    """
    text = _SPACES_RE.sub("", str(raw or ""))
    if lenient and "," in text and "." in text:
        decimal = "," if text.rfind(",") > text.rfind(".") else "."
        thousands = "." if decimal == "," else ","
        text = text.replace(thousands, "")
    try:
        return float(text.replace(",", "."))
    except ValueError:
        return None


# --------------------------------------------------------------------------- #
# Числа                                                                         #
# --------------------------------------------------------------------------- #
# Число: группы по три цифры через пробел (``1 200 000``) либо просто цифры; с дробной частью.
# ``(?<![\w.,/-])`` - не середина слова/другого числа/диапазона («2026-2029», «1.2.3»).
_NUMBER_RE = re.compile(
    r"(?<![\w.,/\-])(\d{1,3}(?:[ \u00a0\u202f]\d{3})+(?:[.,]\d+)?|\d+(?:[.,]\d+)?)(?![\w/]|[.,]\d)"
)
_TAIL_WORDS = 3
_TAIL_CHARS = 40
_EDGE = ".,;:!?()[]«»\"'"
_SCALE_WORDS = {1e3: "тыс.", 1e6: "млн", 1e9: "млрд"}


def scale_word(scale: float | None) -> str:
    """Слово масштаба для описания находки (``1e6`` → «млн»); нет масштаба - пустая строка."""
    return _SCALE_WORDS.get(scale, "") if scale else ""


@dataclass(frozen=True)
class NumberMention:
    """Число текста: как написано (``raw``), значение ``как в тексте``, масштаб и единица.

    ``unit`` - код валюты (``KZT``…), канон единицы (``чел.-дн``…) или ``%``; ``None`` - не сказано.
    ``base`` = ``value × scale`` (без масштаба - само значение).
    """

    raw: str
    value: float
    scale: float | None
    unit: str | None
    start: int
    end: int

    @property
    def base(self) -> float:
        return self.value * (self.scale or 1.0)


def _tail_attrs(tail: str) -> tuple[float | None, str | None]:
    """Масштаб и единица по слову(ам) сразу за числом - теми же детекторами, что у фактов."""
    scale: float | None = None
    unit: str | None = None
    if tail.lstrip().startswith("%"):
        return None, "%"
    for word in tail.split()[:_TAIL_WORDS]:
        w = word.strip(_EDGE)
        if not w:
            break
        if scale is None and detect_scale(w) is not None:
            scale = detect_scale(w)
            continue
        cur = detect_currency(w)
        if cur is not None:
            return scale, cur
        if has_percent(w):
            return scale, "%"
        canon = detect_unit(w)
        if canon is not None and unit is None:
            return scale, canon
        break
    return scale, unit


def scan_numbers(text: str) -> list[NumberMention]:
    """Все числа текста с масштабом/единицей (по порядку появления)."""
    out: list[NumberMention] = []
    for m in _NUMBER_RE.finditer(text):
        value = parse_number(m.group(1), lenient=True)
        if value is None:
            continue
        scale, unit = _tail_attrs(text[m.end(): m.end() + _TAIL_CHARS])
        out.append(NumberMention(
            raw=m.group(1).strip(), value=value, scale=scale, unit=unit,
            start=m.start(1), end=m.end(1)))
    return out


def digit_signature(value: float) -> str:
    """Значащие цифры без нулей на конце: ``480000`` и ``0,48`` дают одну подпись («48»).

    Две величины с одной подписью отличаются степенью десяти - классическая ошибка масштаба
    (тыс./млн). ``0`` - подпись «0».
    """
    if value == 0:
        return "0"
    mantissa = f"{abs(value):.9e}".split("e")[0].replace(".", "").rstrip("0")
    return mantissa or "0"


# --------------------------------------------------------------------------- #
# Даты                                                                          #
# --------------------------------------------------------------------------- #
_MONTHS = (
    ("январ", 1), ("феврал", 2), ("март", 3), ("апрел", 4), ("ма", 5), ("июн", 6),
    ("июл", 7), ("август", 8), ("сентябр", 9), ("октябр", 10), ("ноябр", 11), ("декабр", 12),
)
_MONTH_WORD = (
    r"(январ[ьяе]|феврал[ьяе]|март[аеу]?|апрел[ьяе]|ма[йяе]|июн[ьяе]|июл[ьяе]|август[аеу]?"
    r"|сентябр[ьяе]|октябр[ьяе]|ноябр[ьяе]|декабр[ьяе])"
)
_ISO_RE = re.compile(r"(?<!\d)(\d{4})-(\d{2})-(\d{2})(?!\d)")
_DMY_RE = re.compile(r"(?<![\d.])(\d{1,2})[./](\d{1,2})[./](\d{4}|\d{2})(?![\d])")
_DAY_MONTH_RE = re.compile(rf"(?<!\d)(\d{{1,2}})\s+{_MONTH_WORD}\s+(\d{{4}})(?!\d)", re.IGNORECASE)
_MONTH_YEAR_RE = re.compile(rf"(?<![\w]){_MONTH_WORD}\s+(\d{{4}})(?!\d)", re.IGNORECASE)


def _month_no(word: str) -> int | None:
    low = word.lower()
    for stem, no in _MONTHS:
        if low.startswith(stem):
            return no
    return None


@dataclass(frozen=True)
class DateMention:
    """Дата текста: ``iso`` - ``YYYY-MM-DD`` (день) либо ``YYYY-MM`` (месяц), ``start``/``end``."""

    raw: str
    iso: str
    start: int
    end: int

    @property
    def is_day(self) -> bool:
        return len(self.iso) == 10


def scan_dates(text: str) -> list[DateMention]:
    """Даты текста в любой из форм → ISO; невалидные («31.02.2026») пропускаются."""
    found: list[DateMention] = []
    taken: list[tuple[int, int]] = []

    def free(span: tuple[int, int]) -> bool:
        return not any(span[0] < b and a < span[1] for a, b in taken)

    def add(raw: str, iso: str | None, span: tuple[int, int]) -> None:
        if iso and free(span):
            found.append(DateMention(raw=raw, iso=iso, start=span[0], end=span[1]))
            taken.append(span)

    for m in _ISO_RE.finditer(text):
        add(m.group(0), _valid_date(int(m.group(1)), int(m.group(2)), int(m.group(3))), m.span())
    for m in _DAY_MONTH_RE.finditer(text):
        month = _month_no(m.group(2))
        iso = _valid_date(int(m.group(3)), month, int(m.group(1))) if month else None
        add(m.group(0), iso, m.span())
    for m in _DMY_RE.finditer(text):
        year = int(m.group(3))
        year = year if year >= 100 else 2000 + year
        add(m.group(0), _valid_date(year, int(m.group(2)), int(m.group(1))), m.span())
    for m in _MONTH_YEAR_RE.finditer(text):
        month = _month_no(m.group(1))
        if month and free(m.span()):
            add(m.group(0), f"{int(m.group(2)):04d}-{month:02d}", m.span())
    found.sort(key=lambda d: d.start)
    return found
