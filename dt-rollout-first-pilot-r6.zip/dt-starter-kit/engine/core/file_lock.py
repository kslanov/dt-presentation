"""Reentrant per-path lock for file read/modify/publish transactions.

RLock serializes threads, flock serializes processes. The sidecar inode is stable:
never unlink it on release. All cooperating writers must use the same target path.
External editors do not take this lock; callers must still check expected hashes.
"""

from __future__ import annotations

import fcntl
import hashlib
import os
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

_guard = threading.Lock()
_locks: dict[str, threading.RLock] = {}
_held = threading.local()


@contextmanager
def file_lock(path: Path) -> Iterator[None]:
    target = Path(path).resolve()
    key = str(target)
    with _guard:
        lock = _locks.setdefault(key, threading.RLock())
    with lock:
        held = getattr(_held, "paths", None)
        if held is None:
            held = _held.paths = set()
        if key in held:
            yield
            return
        # A process-independent path, outside vault: locks are not knowledge or temp notes.
        # launchd and shell can have different TMPDIR values; the lock root must not.
        directory = Path("/tmp") / f"dt-file-locks-{os.getuid()}"  # noqa: S108 - shared host lock root
        directory.mkdir(mode=0o700, exist_ok=True)
        if (directory.is_symlink() or directory.stat().st_uid != os.getuid()
                or directory.stat().st_mode & 0o077):
            raise OSError("unsafe file-lock directory")
        sidecar = directory / (hashlib.sha256(key.encode()).hexdigest() + ".lock")
        fd = os.open(sidecar, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX)
            held.add(key)
            try:
                yield
            finally:
                held.remove(key)
                fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)
