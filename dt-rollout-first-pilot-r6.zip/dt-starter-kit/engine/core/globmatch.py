"""Один матчер глобов по относительному пути: скан ``file_ingest`` и обход ``legacy.discover``.

INGEST-SAFETY-1 п.5. Раньше путь якорился (``"/" + rel``), а шаблон - нет: ``tracker/*.md`` не
совпадал с ``/tracker/x.md``, и корень с таким include молча исключался целиком (``**/*`` работало
лишь потому, что ``**`` сводится к ``*``). Теперь шаблон нормализуется с обеих сторон:

* шаблон начинается с ``/`` - якорь к корню (``/tracker/*.md`` - ``tracker`` верхнего уровня);
* шаблон начинается с ``*`` (в т.ч. ``**/``) - как есть, любая глубина;
* иначе (``tracker/*.md``, ``readme.md``) - ``/<шаблон>`` ИЛИ ``*/<шаблон>``: на любой глубине,
  то есть ``tracker/*.md`` = ``/tracker/*.md`` ∪ ``**/tracker/*.md``.

``**`` сводится к ``*`` (``*`` fnmatch и так пересекает ``/``); регистр не важен; обе стороны NFC
(macOS отдает имена в NFD, шаблоны - NFC). Stdlib only, детерминированно.
"""

from __future__ import annotations

import fnmatch
import unicodedata

__all__ = ["glob_match", "pattern_variants"]


def _nfc(text: str) -> str:
    return unicodedata.normalize("NFC", text)


def pattern_variants(pattern: str) -> tuple[str, ...]:
    """Нормализованные шаблоны (регистр, NFC, ``**``→``*``): якорный либо пара корень/глубина."""
    pat = _nfc(pattern).strip().replace("**", "*").lower()
    if not pat or pat.startswith(("/", "*")):
        return (pat,)
    return ("/" + pat, "*/" + pat)


def glob_match(rel_posix: str, pattern: str) -> bool:
    """Совпадает ли относительный путь ``rel_posix`` с шаблоном (правила - в докстринге модуля)."""
    hay = ("/" + _nfc(rel_posix).lstrip("/")).lower()
    return any(fnmatch.fnmatchcase(hay, pat) for pat in pattern_variants(pattern))
