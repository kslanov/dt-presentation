"""DT-OPTIONS-1: декларативный план возможностей установки (ядро + независимые опции).

Состав (данные, не ветвления установщика):

* ``core`` - всегда: знания, поиск, генерация, пульт; отключить нельзя;
* ``outlook`` (коннектор ``outlook``), ``crm`` (``timetta``), ``capture`` (``ticktick``) - три
  независимые опции: каждая включается и выключается отдельно, друг друга не требует;
* ``sleep`` - режим Сна ``off`` | ``manual`` | ``scheduled`` (по умолчанию ``off``). Здесь только
  ПОНЯТИЕ и ворота; рантайм и планировщик Сна - чужая зона (``core/sleep*``), этот модуль ничего
  из них не импортирует, не ставит заданий и не пишет ручек Сна.

Правила (порядок важен, он и есть контракт):

1. **Пресет рекомендует** (``recommended``), но не включает. Источник рекомендаций - встроенный
   пресет роли (``core.role.load.builtin_preset``: коннекторы, задания, виды карточек, исключения
   доктора); пресет без явного выбора плана не меняет.
2. **Явный выбор решает**: ``--enable``/``--disable`` (и ответы диалога) сильнее пресета и
   умолчаний; «включить» и «выключить» одной возможности сразу - отказ, а не молчаливый выбор.
3. **Предпосылки определяют итог**: выбранная, но не готовая возможность получает статус
   ``blocked`` (в ``DT_CONNECTORS`` не попадает) и список «чего не хватает»; готовой она станет
   только при следующем прогоне и ПОСЛЕ повторного подтверждения плана.
4. **Сон**: выкл. по умолчанию; явный выбор «включить» без режима предлагает ``manual``;
   ``scheduled`` - только за воротами: проверенный ручной прогон, явное подтверждение расписания
   (``--yes`` его НЕ заменяет), исполнитель, источники, бюджет. Нет любого - действует ``manual``
   (если есть проверяющий и внимание) либо ``off``, причина названа. Даже при всех воротах план
   только ЗАПИСЫВАЕТ режим: установки расписания не происходит.
5. Проверяющий находки и недельное внимание (``none``/30/60/120+ минут) - предпосылка Сна любого
   режима: находки без читателя не нужны. Они же дают рекомендацию (``manual``, если есть кому и
   когда читать; ``scheduled`` не рекомендуется никогда).

Модуль чистый: ``resolve`` - функция от ``Choices`` и ``Facts`` (факты собирает
:func:`facts_from_ctx` из ``.env`` цели, подделываемых инструментов и ответов мастера); ни файлов,
ни сети, ни Keychain напрямую.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from core import connectors
from core.install.base import InstallError

if TYPE_CHECKING:  # pragma: no cover
    from core.install.context import Answers, InstallContext

__all__ = [
    "ATTENTION", "CAPABILITIES", "Capability", "CapabilityState", "Choices", "Facts", "OPTIONAL",
    "PLAN_SCHEMA", "Plan", "SLEEP_MODES", "SleepState", "choices_from_answers", "confirm_plan",
    "effective_connectors", "facts_from_ctx", "is_managed", "normalize_attention",
    "normalize_capability", "normalize_reviewer", "ask_dialogue", "preset_recommendations",
    "render_plan", "resolve", "stored_plan_line",
]

PLAN_SCHEMA = 1
OPTIONAL = ("outlook", "crm", "capture")
CAPABILITIES = ("core", *OPTIONAL, "sleep")
SLEEP_MODES = ("off", "manual", "scheduled")
ATTENTION = ("none", "30", "60", "120+")
REVIEWERS = ("none", "owner", "delegate")
#: опция плана -> ключ коннектора реестра ``core.connectors`` (``DT_CONNECTORS``)
CONNECTOR_OF = {"outlook": "outlook", "crm": "timetta", "capture": "ticktick"}
_ALIASES = {"timetta": "crm", "ticktick": "capture", "mail": "outlook", "calendar": "outlook",
            "почта": "outlook", "сон": "sleep"}
_REVIEWER_WORDS = {"owner": "owner", "me": "owner", "я": "owner", "сам": "owner",
                   "delegate": "delegate", "делегат": "delegate", "none": "none",
                   "никто": "none", "нет": "none"}
_ON_WORDS = {"on", "yes", "да", "вкл"}
_OFF_WORDS = {"off", "none", "no", "нет", "выкл", ""}


@dataclass(frozen=True)
class Capability:
    key: str
    label: str
    summary: str
    #: ключ реестра коннекторов (``None`` - не коннектор)
    connector: str | None = None


CATALOG: dict[str, Capability] = {
    "core": Capability("core", "Ядро", "знания, поиск, генерация, пульт (всегда)"),
    "outlook": Capability("outlook", "Outlook", "почта и календарь, только чтение",
                          CONNECTOR_OF["outlook"]),
    "crm": Capability("crm", "CRM (Timetta)", "сделки и проекты, зеркало только чтение",
                      CONNECTOR_OF["crm"]),
    "capture": Capability("capture", "Захват (TickTick)", "быстрые мысли и поручения с тегами",
                          CONNECTOR_OF["capture"]),
    "sleep": Capability("sleep", "Сон", "ночной разбор знаний: off | manual | scheduled"),
}


# --------------------------------------------------------------------------- вход ----------- #
@dataclass(frozen=True)
class Choices:
    """Что человек выбрал (флаги/диалог/состояние). Пустое = «не выбирал»."""

    preset: str = ""
    enable: tuple[str, ...] = ()
    disable: tuple[str, ...] = ()
    reviewer: str = ""  # '' | none | owner | delegate
    attention: str = ""  # '' | none | 30 | 60 | 120+
    sleep: str = ""  # '' | off | manual | scheduled | on
    sleep_executor: str = ""
    sleep_sources: tuple[str, ...] = ()
    sleep_budget: str = ""
    sleep_manual_tested: str = ""  # ссылка/метка проверенного ручного прогона
    sleep_confirmed: bool = False  # явное подтверждение расписания (не ``--yes``)
    asked: bool = False  # диалог уже проводился (ответы - в полях выше)


@dataclass(frozen=True)
class Facts:
    """Что известно о машине и цели (собирает установщик; в тестах - литералы)."""

    macos: bool = True
    #: имена секретов/ручек, которые есть (значения сюда не попадают)
    present: frozenset[str] = frozenset()
    mailboxes: bool = False  # ящики Outlook выбраны (ответ мастера или DT_OUTLOOK_FOLDERS)
    domains: bool = False  # домены компании известны (иначе вся почта «внешняя»)
    presets: tuple[str, ...] = ()  # имена встроенных пресетов (для проверки ввода)


# --------------------------------------------------------------------------- нормализация --- #
def normalize_capability(raw: str) -> str:
    key = raw.strip().lower()
    key = _ALIASES.get(key, key)
    if key not in CAPABILITIES:
        raise InstallError("bad_capability", f"неизвестная возможность {raw!r}",
                           f"допустимо: {', '.join(CAPABILITIES)}")
    return key


def normalize_reviewer(raw: str) -> str:
    key = raw.strip().lower()
    if key in ("",):
        return ""
    if key not in _REVIEWER_WORDS:
        raise InstallError("bad_reviewer", f"неизвестный проверяющий {raw!r}",
                           f"допустимо: {', '.join(REVIEWERS)}")
    return _REVIEWER_WORDS[key]


def normalize_attention(raw: str) -> str:
    key = raw.strip().lower().replace(" ", "").replace("мин", "")
    if key == "":
        return ""
    if key in ("0", "none", "нет", "никакого"):
        return "none"
    if key in ("30", "60"):
        return key
    if key in ("120", "120+", "120плюс", "больше"):
        return "120+"
    raise InstallError("bad_attention", f"недельное внимание {raw!r} не из списка",
                       f"допустимо: {', '.join(ATTENTION)} (минут в неделю)")


def _normalize_sleep(raw: str) -> str:
    key = raw.strip().lower()
    if key == "":
        return ""
    if key in _ON_WORDS:
        return "on"  # «включить» без режима: предложим manual
    if key in _OFF_WORDS:
        return "off"
    if key in SLEEP_MODES:
        return key
    raise InstallError("bad_sleep_mode", f"режим Сна {raw!r} неизвестен",
                       f"допустимо: {', '.join(SLEEP_MODES)}")


def _budget(raw: str) -> float | None:
    try:
        value = float(raw.replace(",", ".")) if raw.strip() else None
    except ValueError:
        raise InstallError("bad_sleep_budget", f"бюджет Сна {raw!r} - не число",
                           "положительное число (единицы бюджета задает исполнитель)") from None
    return value


def choices_from_answers(ans: Answers) -> Choices:
    """Ответы мастера -> :class:`Choices`; плохой ввод - отказ с кодом (не молчаливая замена)."""
    enable = tuple(dict.fromkeys(normalize_capability(t) for t in ans.enable))
    disable = tuple(dict.fromkeys(normalize_capability(t) for t in ans.disable))
    both = [k for k in enable if k in disable]
    if both:
        raise InstallError("capability_conflict",
                           f"одновременно включено и выключено: {', '.join(both)}",
                           "оставь одно из двух: --enable или --disable")
    if "core" in disable:
        raise InstallError("core_required", "ядро отключить нельзя",
                           "уберите core из --disable (ядро - то, что ставит dt install)")
    return Choices(
        preset=ans.preset.strip().lower(), enable=enable, disable=disable,
        reviewer=normalize_reviewer(ans.reviewer), attention=normalize_attention(ans.attention),
        sleep=_normalize_sleep(ans.sleep), sleep_executor=ans.sleep_executor.strip(),
        sleep_sources=tuple(s.strip() for s in ans.sleep_sources if s.strip()),
        sleep_budget=ans.sleep_budget.strip(),
        sleep_manual_tested=ans.sleep_manual_tested.strip(),
        sleep_confirmed=ans.sleep_confirmed.strip().lower() in ("yes", "true", "1"),
        asked=ans.capabilities_asked.strip().lower() == "yes")


def is_managed(ch: Choices) -> bool:
    """План управляет установкой, только если человек что-то выбрал/ответил; иначе - прежний
    путь (``--connectors``, ``DT_CONNECTORS`` из ``.env``), байт в байт."""
    return bool(ch.preset or ch.enable or ch.disable or ch.reviewer or ch.attention or ch.sleep
                or ch.asked)


# --------------------------------------------------------------------------- пресеты --------- #
@dataclass(frozen=True)
class Recommendation:
    recommended: bool
    why: str = ""


def preset_recommendations(name: str) -> dict[str, Recommendation]:
    """Что рекомендует пресет роли: по данным пресета, а не по таблице в этом модуле.

    * коннектор в ``surface.connectors`` - основание; ``outlook`` дополнительно требует задания
      ``outlook_read``, ``crm`` - вида карточки ``assignment`` (у ролей без них опция не нужна);
    * Сон не рекомендуется, если пресет исключает у доктора строки «Сон: …» (личный контур).
    """
    from core.role.load import builtin_preset

    role = builtin_preset(name)
    surf = role.surface
    ops = {j.op for j in surf.jobs}
    have = set(surf.connectors)
    rec: dict[str, Recommendation] = {}
    for cap in OPTIONAL:
        key = CONNECTOR_OF[cap]
        ok = key in have
        if cap == "outlook":
            ok = ok and "outlook_read" in ops
        if cap == "crm":
            ok = ok and "assignment" in surf.card_kinds
        rec[cap] = Recommendation(ok, f"пресет {name}: " + (
            f"коннектор {key} в составе роли" if ok else f"{cap} роли не нужен"))
    sleep_ok = not any(x.startswith("Сон") for x in surf.doctor_excluded)
    rec["sleep"] = Recommendation(sleep_ok, f"пресет {name}: " + (
        "Сон возможен (manual - после выбора)" if sleep_ok else "Сон исключен у роли"))
    return rec


# --------------------------------------------------------------------------- итог ------------ #
@dataclass(frozen=True)
class CapabilityState:
    key: str
    choice: str  # explicit-on | explicit-off | default
    recommended: bool
    why: str
    status: str  # on | off | blocked
    missing: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {"choice": self.choice, "recommended": self.recommended, "status": self.status,
                "missing": list(self.missing), "notes": list(self.notes)}


@dataclass(frozen=True)
class SleepState:
    requested: str  # off | manual | scheduled
    effective: str  # off | manual | scheduled
    suggested: str  # что предлагаем следующим шагом ('' - ничего)
    choice: str
    recommended: str
    missing: tuple[str, ...] = ()  # чего не хватает для запрошенного режима
    notes: tuple[str, ...] = ()
    #: что ЭТОТ план ставит в систему для Сна: всегда пусто (расписание - рантайм Сна)
    installs: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {"requested": self.requested, "effective": self.effective,
                "suggested": self.suggested, "choice": self.choice,
                "recommended": self.recommended, "missing": list(self.missing),
                "notes": list(self.notes), "installs": list(self.installs)}


@dataclass(frozen=True)
class Plan:
    preset: str
    capabilities: dict[str, CapabilityState]
    sleep: SleepState
    reviewer: str
    attention: str
    managed: bool
    notes: tuple[str, ...] = field(default=())

    def active(self) -> list[str]:
        out = ["core"] + [k for k in OPTIONAL if self.capabilities[k].status == "on"]
        if self.sleep.effective != "off":
            out.append(f"sleep:{self.sleep.effective}")
        return out

    def as_dict(self) -> dict[str, Any]:
        return {"schema": PLAN_SCHEMA, "preset": self.preset, "reviewer": self.reviewer,
                "attention": self.attention, "connectors": effective_connectors(self),
                "capabilities": {k: v.as_dict() for k, v in self.capabilities.items()},
                "sleep": self.sleep.as_dict(), "notes": list(self.notes)}

    def digest(self) -> str:
        blob = json.dumps(self.as_dict(), sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


def effective_connectors(plan: Plan) -> str:
    """Значение ``DT_CONNECTORS``: ровно включенные и готовые опции (``none`` - ни одной)."""
    keys = [CONNECTOR_OF[k] for k in OPTIONAL if plan.capabilities[k].status == "on"]
    return ",".join(keys) if keys else "none"


def _missing_for(cap: str, facts: Facts) -> tuple[list[str], list[str]]:
    """(жесткие предпосылки, предупреждения) возможности ``cap``."""
    hard: list[str] = []
    soft: list[str] = []
    if cap == "outlook":
        if not facts.macos:
            hard.append("macOS: Outlook-мост работает только на Mac")
        if not facts.mailboxes:
            hard.append("ящики Outlook не выбраны (DT_OUTLOOK_FOLDERS)")
        if not facts.domains:
            soft.append("домены компании не заданы: вся почта станет внешней")
    elif cap in ("crm", "capture"):
        for req in connectors.CONNECTORS[CONNECTOR_OF[cap]].requires:
            if req.name not in facts.present:
                hard.append(f"нет {req.name} (ключ вводит человек: dt config set {req.name} "
                            "--stdin)")
    return hard, soft


def _resolve_sleep(ch: Choices, rec_on: bool, why: str) -> SleepState:
    notes: list[str] = []
    in_enable = "sleep" in ch.enable
    in_disable = "sleep" in ch.disable
    mode = ch.sleep
    if in_disable or mode == "off":
        requested, choice = "off", "explicit-off"
    elif mode == "on" or (in_enable and mode in ("", "on")):
        requested, choice = "manual", "explicit-on"
        notes.append("режим не назван: предлагаем manual (ручной запуск, ничего не ставится)")
    elif mode in ("manual", "scheduled"):
        requested, choice = mode, "explicit-on"
    else:
        requested, choice = "off", "default"
    can_review = ch.reviewer in ("owner", "delegate") and ch.attention in ("30", "60", "120+")
    recommended = "manual" if (rec_on and can_review) else "off"
    if requested == "off":
        suggested = "manual" if (recommended == "manual" and choice == "default") else ""
        if suggested:
            notes.append("рекомендация: manual (есть кому и когда читать находки); "
                         "включается только явным выбором")
        return SleepState("off", "off", suggested, choice, recommended, notes=tuple(notes))

    missing: list[str] = []
    if ch.reviewer not in ("owner", "delegate"):
        missing.append("проверяющий находки не назван (owner/delegate)")
    if ch.attention not in ("30", "60", "120+"):
        missing.append("нет недельного внимания (30/60/120+ минут)")
    if not rec_on:
        notes.append(why)
    if missing:
        notes.append("Сон выключен: без читателя находки не нужны")
        return SleepState(requested, "off", "", choice, recommended, tuple(missing), tuple(notes))
    if requested == "manual":
        return SleepState("manual", "manual", "", choice, recommended, notes=tuple(notes))

    gates: list[str] = []
    if not ch.sleep_manual_tested:
        gates.append("нет проверенного ручного прогона (--sleep-manual-tested <метка>)")
    if not ch.sleep_confirmed:
        gates.append("нет явного подтверждения расписания (--confirm-sleep-schedule; --yes "
                     "его не заменяет)")
    if not ch.sleep_executor:
        gates.append("не назван исполнитель (--sleep-executor)")
    if not ch.sleep_sources:
        gates.append("не названы источники (--sleep-source)")
    budget = _budget(ch.sleep_budget)
    if budget is None or budget <= 0:
        gates.append("нет бюджета > 0 (--sleep-budget)")
    if gates:
        notes.append("scheduled закрыт воротами: действует manual")
        return SleepState("scheduled", "manual", "", choice, recommended, tuple(gates),
                          tuple(notes))
    notes.append("режим scheduled записан; расписание НЕ ставится этим планом (рантайм Сна)")
    return SleepState("scheduled", "scheduled", "", choice, recommended, notes=tuple(notes))


def resolve(ch: Choices, facts: Facts) -> Plan:
    """План возможностей: пресет рекомендует, явный выбор и предпосылки решают."""
    if ch.preset and facts.presets and ch.preset not in facts.presets:
        raise InstallError("bad_preset", f"нет встроенного пресета {ch.preset!r}",
                           f"допустимо: {', '.join(facts.presets)}")
    recs = preset_recommendations(ch.preset) if ch.preset else {}
    states: dict[str, CapabilityState] = {
        "core": CapabilityState("core", "default", True, "всегда", "on")}
    for cap in OPTIONAL:
        rec = recs.get(cap, Recommendation(False))
        if cap in ch.disable:
            choice = "explicit-off"
        elif cap in ch.enable:
            choice = "explicit-on"
        else:
            choice = "default"
        if choice != "explicit-on":
            note = (rec.why + "; не выбрана - остается выключенной"
                    if rec.recommended and choice == "default" else "")
            states[cap] = CapabilityState(cap, choice, rec.recommended, rec.why, "off",
                                          notes=(note,) if note else ())
            continue
        hard, soft = _missing_for(cap, facts)
        states[cap] = CapabilityState(
            cap, choice, rec.recommended, rec.why, "blocked" if hard else "on",
            tuple(hard), tuple(soft))
    srec = recs.get("sleep", Recommendation(True, ""))
    sleep = _resolve_sleep(ch, srec.recommended, srec.why)
    states["sleep"] = CapabilityState(
        "sleep", sleep.choice, sleep.recommended == "manual", srec.why,
        "off" if sleep.effective == "off" else "on", sleep.missing)
    return Plan(preset=ch.preset, capabilities=states, sleep=sleep, reviewer=ch.reviewer,
                attention=ch.attention, managed=is_managed(ch))


# --------------------------------------------------------------------------- показ ----------- #
_STATUS = {"on": "включено", "off": "выключено", "blocked": "ждет предпосылок"}
_CHOICE = {"explicit-on": "выбрано явно", "explicit-off": "выключено явно", "default": "умолчание"}


def render_plan(plan: Plan) -> list[str]:
    """План человеку: что включено, что рекомендовано, чего не хватает; без значений секретов."""
    lines = ["План возможностей" + (f" (пресет {plan.preset})" if plan.preset else "") + ":"]
    for key in CAPABILITIES:
        if key == "sleep":
            continue
        st, cat = plan.capabilities[key], CATALOG[key]
        mark = {"on": "✓", "off": "·", "blocked": "!"}[st.status]
        rec = " [рекомендовано]" if (st.recommended and key != "core") else ""
        lines.append(f"  {mark} {cat.label}: {_STATUS[st.status]} ({_CHOICE.get(st.choice, '-')})"
                     f"{rec}")
        lines.extend(f"      нужно: {m}" for m in st.missing)
        lines.extend(f"      · {n}" for n in st.notes if n)
    sl = plan.sleep
    lines.append(f"  {'✓' if sl.effective != 'off' else '·'} Сон: режим {sl.effective}"
                 f" (запрошен {sl.requested}; {_CHOICE.get(sl.choice, '-')})"
                 + (" [рекомендовано: manual]" if sl.recommended == "manual" else ""))
    lines.extend(f"      нужно: {m}" for m in sl.missing)
    lines.extend(f"      · {n}" for n in sl.notes if n)
    lines.append(f"  проверяющий находки: {plan.reviewer or 'не назван'}; "
                 f"внимание в неделю: {plan.attention or 'не названо'}")
    lines.append(f"  DT_CONNECTORS по плану: {effective_connectors(plan)}; "
                 "расписание Сна этим планом не ставится")
    return lines


def stored_plan_line(stored: Mapping[str, Any] | None) -> str:
    if not stored:
        return ""
    state = "подтвержден" if stored.get("confirmed") else "не подтвержден"
    plan = stored.get("plan") or {}
    sleep = (plan.get("sleep") or {}).get("effective", "off")
    return (f"план возможностей: {state}; DT_CONNECTORS={plan.get('connectors', 'none')}; "
            f"Сон: {sleep}")


# --------------------------------------------------------------------------- установщик ------ #
def facts_from_ctx(ctx: InstallContext) -> Facts:
    """Факты цели: ``.env`` цели + инструменты установки (Keychain/платформа - подделываемые)."""
    from core.role.load import builtin_presets

    env = ctx.environ()
    ans = ctx.answers
    # Keychain опрашиваем только про секреты ВЫБРАННЫХ опций (факт наличия, не значение)
    chosen = {normalize_capability(t) for t in ans.enable} - {normalize_capability(t)
                                                              for t in ans.disable}
    names = {req.name for k in OPTIONAL if k in chosen
             for req in connectors.CONNECTORS[CONNECTOR_OF[k]].requires if req.kind == "secret"}
    present = {n for n in names if (env.get(n) or "").strip() or ctx.tools.has_secret(n)}
    return Facts(
        macos=ctx.tools.probe.system() == "Darwin", present=frozenset(present),
        mailboxes=bool(ans.mailbox_specs or (env.get("DT_OUTLOOK_FOLDERS") or "").strip()),
        domains=bool(ans.domains), presets=builtin_presets())


_Q = {
    "reviewer": "Кто будет просматривать находки Сна (owner = я сам / delegate / none)",
    "attention": "Сколько минут в неделю готовы уделять разбору (none/30/60/120+)",
    "enable": "Какие опции включить (outlook, crm, capture; none - ни одной)",
    "sleep": "Сон (off/manual/scheduled; off - по умолчанию)",
}


def ask_dialogue(ctx: InstallContext) -> None:
    """Диалог плана: проверяющий, недельное внимание, опции, Сон. Спрашивает только то, чего еще
    нет в ответах; ``--yes`` не спрашивает (пусто = «не выбрано»: опции выкл., Сон off)."""
    ans = ctx.answers
    if ans.capabilities_asked == "yes" and not ctx.capability_dialogue:
        return
    if ctx.yes:
        ans.capabilities_asked = "yes"
        return

    def ask(field: str, default: str) -> str:
        return ctx.tools.prompt(_Q[field], default)

    if not ans.reviewer:
        ans.reviewer = normalize_reviewer(ask("reviewer", "none")) or "none"
    if not ans.attention:
        ans.attention = normalize_attention(ask("attention", "none")) or "none"
    if not (ans.enable or ans.disable):
        if ans.preset:
            try:
                rec = preset_recommendations(ans.preset.strip().lower())
            except KeyError:
                rec = {}
            names = [k for k in OPTIONAL if rec.get(k, Recommendation(False)).recommended]
            if names:
                ctx.say(f"Пресет {ans.preset} рекомендует: {', '.join(names)} (рекомендует, "
                        "не включает)")
        raw = ask("enable", "none").strip().lower()
        if raw not in _OFF_WORDS:
            ans.enable = [normalize_capability(t) for t in raw.replace(";", ",").split(",")
                          if t.strip()]
    if not ans.sleep:
        ans.sleep = _normalize_sleep(ask("sleep", "off")) or "off"
    ans.capabilities_asked = "yes"


def confirm_plan(ctx: InstallContext, plan: Plan) -> bool:
    """Подтверждение плана: ``--yes`` или явное «да» в диалоге (умолчание - нет)."""
    if ctx.yes:
        return True
    answer = ctx.tools.prompt("Применить этот план? (да/нет)", "нет").strip().lower()
    return answer in ("да", "yes", "y", "д")
