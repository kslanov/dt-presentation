"""Optional macOS Obsidian setup for the vault configured by DT."""

from __future__ import annotations

import hashlib
import json
import os
import plistlib
import re
import time
import uuid
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.parse import quote

from core.file_lock import file_lock
from core.install.base import ABSENT, DONE, PARTIAL, InstallError, Step, StepCheck, StepResult
from core.install.context import InstallContext
from core.mcp_json_edit import write_text_atomic

APP = "Obsidian.app"
BUNDLE = "md.obsidian"
_RELEASES = "https://api.github.com/repos/obsidianmd/obsidian-releases/releases/latest"
_ASSET = "https://github.com/obsidianmd/obsidian-releases/releases/download/"
_SIGNER = ('identifier "md.obsidian" and anchor apple generic '
           'and certificate leaf[subject.OU] = "6JSW4SJWN9"')
_GUIDE = "https://obsidian.md/download"
_VAULT_MARKERS = ("_system/ingest-roots.yaml", "_system/retrieval-policies")


def _target(ctx: InstallContext) -> Path:
    value = ctx.env_values().get("DT_VAULT_PATH")
    configured = (Path(value).expanduser() if value else ctx.workspace / "vault").resolve()
    if ctx.vault.resolve() != configured:
        raise InstallError("obsidian_vault", "выбранный vault отличается от настроенного в DT",
                           f"повтори шаг для vault, подключенного к DT: {configured}")
    if not ctx.env_path.is_file() or not all((configured / p).exists() for p in _VAULT_MARKERS):
        raise InstallError("obsidian_vault", "сначала подготовь vault установщиком DT",
                           "выполни dt install с выбранным путем --vault")
    return configured


def _app(ctx: InstallContext) -> Path | None:
    for candidate in (ctx.home / "Applications" / APP, Path("/Applications") / APP):
        try:
            info = plistlib.loads((candidate / "Contents/Info.plist").read_bytes())
            if isinstance(info, dict) and info.get("CFBundleIdentifier") == BUNDLE:
                return candidate
        except (OSError, ValueError):
            continue
    return None


def _registry_path(ctx: InstallContext) -> Path:
    return ctx.home / "Library/Application Support/obsidian/obsidian.json"


def _registry(path: Path) -> dict:
    if path.is_symlink():
        raise InstallError("obsidian_config", "список vault Obsidian является ссылкой")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (ValueError, OSError) as exc:
        raise InstallError("obsidian_config", "список vault Obsidian не читается",
                           "открой выбранный vault в Obsidian и повтори шаг") from exc
    if not isinstance(data, dict) or not isinstance(data.get("vaults", {}), dict):
        raise InstallError("obsidian_config", "формат списка vault Obsidian не поддерживается")
    return data


def _entry(data: dict, target: Path) -> tuple[str, dict] | None:
    for key, value in data.get("vaults", {}).items():
        if isinstance(value, dict) and isinstance(value.get("path"), str):
            if Path(value["path"]).expanduser().resolve() == target:
                return key, value
    return None


def _capture(ctx: InstallContext, argv: list[str], code: str, reason: str) -> str:
    status, output = ctx.tools.capture(argv, ctx.engine_dir, None)
    if status:
        raise InstallError(code, reason, output.strip().splitlines()[-1] if output.strip() else "")
    return output


def _release(ctx: InstallContext) -> tuple[str, str]:
    info = _capture(ctx, ["/usr/bin/curl", "-fsS", "--proto", "=https", _RELEASES],
                    "obsidian_download", "не удалось получить выпуск Obsidian")
    try:
        release = json.loads(info)
        tag = release["tag_name"]
        assets = release["assets"]
        if not re.fullmatch(r"v[0-9]+\.[0-9]+\.[0-9]+", tag):
            raise ValueError
        names = {f"Obsidian-{tag[1:]}.dmg", f"Obsidian-{tag[1:]}-universal.dmg"}
        for asset in assets:
            name = asset["name"]
            digest = asset.get("digest") or ""
            url = f"{_ASSET}{tag}/{name}"
            if name in names and asset.get("browser_download_url") == url and re.fullmatch(
                    r"sha256:[a-f0-9]{64}", digest):
                return url, digest.removeprefix("sha256:")
    except (ValueError, KeyError, TypeError):
        pass
    raise InstallError("obsidian_download", "в выпуске нет официального DMG с контрольной суммой",
                       _GUIDE)


def _install(ctx: InstallContext) -> Path:
    dest = ctx.home / "Applications" / APP
    ctx.guard(dest.resolve())
    if dest.exists() or dest.is_symlink():
        raise InstallError("obsidian_app", f"нельзя установить поверх существующего {dest}")
    url, expected = _release(ctx)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".dt-obsidian-", dir=dest.parent) as work:
        base = Path(work)
        dmg = base / "Obsidian.dmg"
        ctx.say("  скачиваю Obsidian с официальной страницы выпусков")
        status, _ = ctx.tools.run_cmd(
            ["/usr/bin/curl", "-fLSs", "--proto", "=https", "--proto-redir", "=https",
             "--retry", "3", "--connect-timeout", "20", "--speed-time", "60",
             "--speed-limit", "1024", "--output", str(dmg), url], ctx.engine_dir, None)
        if status:
            raise InstallError("obsidian_download", "скачивание Obsidian прервалось", _GUIDE)
        with dmg.open("rb") as stream:
            if hashlib.file_digest(stream, "sha256").hexdigest() != expected:
                raise InstallError("obsidian_download", "контрольная сумма DMG не совпала")
        mount = base / "mount"
        mount.mkdir()
        _capture(ctx, ["/usr/bin/hdiutil", "attach", "-readonly", "-nobrowse", "-mountpoint",
                       str(mount), str(dmg)], "obsidian_app", "не удалось открыть DMG")
        try:
            app = mount / APP
            _verify(ctx, app)
            _capture(ctx, ["/usr/bin/syspolicy_check", "distribution", str(app)],
                     "obsidian_app", "Obsidian не прошел проверку macOS перед установкой")
            staged = base / APP
            _capture(ctx, ["/usr/bin/ditto", str(app), str(staged)],
                     "obsidian_app", "не удалось скопировать Obsidian")
        finally:
            _capture(ctx, ["/usr/bin/hdiutil", "detach", str(mount)],
                     "obsidian_app", "не удалось закрыть DMG")
        if dest.exists() or dest.is_symlink():
            raise InstallError("obsidian_app", "Obsidian появился во время установки, повтори шаг")
        os.rename(staged, dest)
    return dest


def _verify(ctx: InstallContext, app: Path) -> None:
    _capture(ctx, ["/usr/bin/codesign", "--verify", "--deep", "--strict", f"-R={_SIGNER}",
                   str(app)],
             "obsidian_app", "подпись Obsidian не совпала с подписью издателя")


def _running(ctx: InstallContext) -> bool:
    status, _ = ctx.tools.capture(["/usr/bin/pgrep", "-x", "-u", str(ctx.home.stat().st_uid),
                                   "Obsidian"], ctx.engine_dir, None)
    return status == 0


def _register(ctx: InstallContext, path: Path, target: Path, data: dict) -> str:
    if _running(ctx):
        raise InstallError("obsidian_running", "Obsidian уже открыт с другим vault",
                           "закрой Obsidian и повтори шаг или открой указанную папку в приложении")
    ctx.guard(path.resolve())
    if _registry(path) != data:
        raise InstallError("obsidian_config", "список vault изменился, повтори шаг")
    key = uuid.uuid4().hex[:16]
    data.setdefault("vaults", {})[key] = {"path": str(target), "ts": int(time.time() * 1000)}
    path.parent.mkdir(parents=True, exist_ok=True)
    write_text_atomic(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    return key


def check(ctx: InstallContext) -> StepCheck:
    target = _target(ctx)
    if _app(ctx) is None:
        return StepCheck(ABSENT, "Obsidian не установлен")
    match = _entry(_registry(_registry_path(ctx)), target)
    if match and (match[1].get("open") is True or (target / ".obsidian/workspace.json").is_file()):
        return StepCheck(DONE, f"vault подключен к Obsidian: {target}")
    return StepCheck(PARTIAL, f"Obsidian установлен, vault еще не открыт: {target}")


def run(ctx: InstallContext) -> StepResult:
    target = _target(ctx)
    if ctx.tools.probe.system() != "Darwin" or ctx.home != Path.home().resolve():
        raise InstallError("obsidian_platform", "шаг открывает Obsidian в текущем сеансе macOS",
                           "запусти его в Terminal под своим пользователем")
    path = _registry_path(ctx)
    ctx.guard(path.resolve())
    with file_lock(path):
        data = _registry(path)
        match = _entry(data, target)
        app = _app(ctx) or _install(ctx)
        _verify(ctx, app)
        key = match[0] if match else _register(ctx, path, target, data)
        uri = "obsidian://open?vault=" + quote(key, safe="")
        _capture(ctx, ["/usr/bin/open", "-a", str(app), uri],
                 "obsidian_open", "не удалось открыть vault в Obsidian")
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            current = _entry(_registry(path), target)
            if current and current[1].get("open") is True:
                return StepResult(note=f"Obsidian открыл vault DT: {target}")
            time.sleep(0.25)
    raise InstallError("obsidian_open", f"Obsidian не подтвердил открытие: {target}",
                       "проверь окно Obsidian и повтори dt install --step obsidian")


STEP = Step("obsidian", "Obsidian", "Установить при необходимости и открыть vault DT",
            check, run, "Obsidian для macOS")
