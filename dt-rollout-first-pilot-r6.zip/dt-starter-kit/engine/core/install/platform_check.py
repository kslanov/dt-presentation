"""Шаг ``platform``: macOS ≥ 14, arm64/x86_64, место, RAM, ``uv``, ``git``, Python из ``uv``.

RESOURCE-1 п.6: шаг знает железо - RAM и выбранный профиль эмбеддера (``core.resources``) идут в
вывод; меньше :data:`MIN_RAM_GIB` - отказ ``platform_low_ram`` (модель поиска bge-m3 не поместится,
двойник не поедет).

KIT-FIT-1 п.5: ``uv`` ищется и там, куда его кладет установщик (``~/.local/bin``, ``~/.cargo/bin``);
найден, но каталога нет в PATH - отказ ``not_on_path`` с готовой строкой ``export PATH=...`` для
``~/.zprofile`` (zsh - оболочка macOS по умолчанию), а не «открой новый терминал».

Только проверка и подсказка: ``uv``/Xcode CLT/``brew`` установщик НЕ ставит (решение ТЗ DEV-3-KIT) -
отказ называет команду, которую человек выполнит сам. Факты о машине - через :class:`PlatformProbe`
(тесты подставляют «не macOS», «мало места»).
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from collections.abc import Sequence
from pathlib import Path

__all__ = [
    "LOW_RAM_CODE",
    "MIN_MACOS",
    "NOT_ON_PATH_CODE",
    "MIN_RAM_GIB",
    "NEED_FREE_GIB",
    "PlatformProbe",
    "evaluate",
    "export_line",
    "has_low_ram",
    "has_not_on_path",
    "profile_line",
]

MIN_MACOS = 14
MIN_RAM_GIB = 8.0  # меньше - отказ platform_low_ram: bge-m3 (2,3 ГБ весов) + система не помещаются
LOW_RAM_CODE = "platform_low_ram"
_LOW_RAM_MARK = "памяти "
NOT_ON_PATH_CODE = "not_on_path"
_NOT_ON_PATH_MARK = "не в PATH: "
#: где установщики кладут свои программы (``uv``: ``~/.local/bin``; прежние - ``~/.cargo/bin``)
EXTRA_BIN_DIRS = (".local/bin", ".cargo/bin")
NEED_FREE_GIB = 12.0  # модели ~4.5 ГБ + индекс + запас на первую индексацию
NEED_FREE_WITH_MODELS_GIB = 2.0  # модели уже на диске: нужен только индекс
SUPPORTED_ARCH = ("arm64", "x86_64")
_GIB = 1024**3

UV_HINT = ("поставь uv: curl -LsSf https://astral.sh/uv/install.sh | sh "
           "(затем открой новый терминал; не нашелся - проверь, что ~/.local/bin есть в PATH: "
           "echo 'export PATH=\"$HOME/.local/bin:$PATH\"' >> ~/.zprofile)")
CLAUDE_HINT = ("поставь Claude Code: curl -fsSL https://claude.ai/install.sh | bash "
               "(или npm i -g @anthropic-ai/claude-code) и повтори")
GIT_HINT = "поставь git: xcode-select --install (Command Line Tools) и повтори"


class PlatformProbe:
    """Факты о машине; каждый метод - одна проба (подменяется в тестах целиком)."""

    def system(self) -> str:
        return platform.system()

    def mac_version(self) -> str:
        return platform.mac_ver()[0]

    def machine(self) -> str:
        return platform.machine()

    def free_bytes(self, path: Path) -> int:
        probe = Path(path)
        while not probe.exists() and probe != probe.parent:
            probe = probe.parent
        return shutil.disk_usage(probe).free

    def home(self) -> Path:
        """Домашний каталог (в тестах - временный ``HOME``)."""
        return Path.home()

    def on_path(self, name: str) -> str | None:
        """Путь программы по PATH процесса (как ее найдет шелл) либо ``None``."""
        return shutil.which(name)

    def which(self, name: str) -> str | None:
        """PATH, затем ``~/.local/bin`` и ``~/.cargo/bin``: программа могла быть поставлена, а
        каталог - еще не в PATH (``uv`` из официального установщика)."""
        found = self.on_path(name)
        if found:
            return found
        for rel in EXTRA_BIN_DIRS:
            cand = self.home() / rel / name
            if cand.is_file() and os.access(cand, os.X_OK):
                return str(cand)
        return None

    def ram_gib(self) -> float | None:
        """Физическая память, ГБ (``None`` - не определилась)."""
        from core import resources

        return resources.ram_gib()

    def daemon_health(self) -> dict | None:
        """``/health`` живого демона (``None`` - не отвечает): для пункта «демон не больше RAM/2»
        в ``dt install --check``."""
        from core import daemon

        return daemon.fetch_health(timeout=1.5)

    def uv_python(self, cwd: Path) -> str | None:
        """Путь Python, который выберет ``uv`` для проекта (``uv python find``); нет - ``None``."""
        argv: Sequence[str] = ["uv", "python", "find"]
        try:
            done = subprocess.run(argv, cwd=str(cwd), capture_output=True, text=True,  # noqa: S603
                                  timeout=30, check=False,
                                  env={k: v for k, v in os.environ.items() if k != "VIRTUAL_ENV"})
        except (OSError, subprocess.SubprocessError):
            return None
        out = done.stdout.strip().splitlines()
        return out[-1] if done.returncode == 0 and out else None


def _major(version: str) -> int:
    head = version.split(".", 1)[0]
    return int(head) if head.isdigit() else 0


def has_low_ram(problems: Sequence[str]) -> bool:
    """Среди замечаний есть «мало памяти» (код отказа :data:`LOW_RAM_CODE`)."""
    return any(p.startswith(_LOW_RAM_MARK) for p in problems)


def has_not_on_path(problems: Sequence[str]) -> bool:
    """Среди замечаний есть «найден, но не в PATH» (код отказа :data:`NOT_ON_PATH_CODE`)."""
    return any(p.startswith(_NOT_ON_PATH_MARK) for p in problems)


def export_line(directory: Path, home: Path) -> str:
    """Строка для ``~/.zprofile``: ``export PATH="$HOME/.local/bin:$PATH"`` (внутри дома - через
    ``$HOME``, чтобы строка переживала переезд учетной записи)."""
    try:
        shown = "$HOME/" + str(Path(directory).relative_to(home))
    except ValueError:
        shown = str(directory)
    return f'export PATH="{shown}:$PATH"'


def _off_path(probe: PlatformProbe, name: str) -> tuple[str, str] | None:
    """``(замечание, подсказка)``, если ``name`` стоит, но не виден шеллу; иначе ``None``."""
    found = probe.which(name)
    if not found or probe.on_path(name):
        return None
    line = export_line(Path(found).parent, probe.home())
    return (f"{_NOT_ON_PATH_MARK}{name} стоит в {Path(found).parent}, но этого каталога нет в PATH",
            f"добавь строку в ~/.zprofile и открой новое окно Terminal: "
            f"echo '{line}' >> ~/.zprofile (одноразово в этом окне - сама строка {line})")


def profile_line(probe: PlatformProbe) -> str:
    """Что получит эта машина: «16 ГБ: эмбеддер mps/fp16, батч 32; предупреждение: ...».

    Устройство - mps на arm64 (Apple Silicon), иначе cpu; явные ``DT_EMBED_*`` перекрывают
    профиль (как и в самом эмбеддере). RAM неизвестна - честно так и пишем. Предупреждение про своп
    - когда профиль легкий (RAM < 32 ГБ): рядом с браузером и почтой память делится с ними."""
    from core import embed_daemon, resources

    ram = probe.ram_gib()
    device = "mps" if probe.machine() == "arm64" else "cpu"
    prof = resources.embed_profile(ram, device=device)
    head = f"{ram:.0f} ГБ" if ram is not None else "RAM не определилась"
    line = f"{head}: эмбеддер {prof['device']}/{prof['dtype']}, батч {prof['batch_size']}"
    if ram is None or ram < resources.RAM_TIERS[0][0]:
        idle = embed_daemon.idle_unload_s()
        tail = (f"воркер моделей завершается после {idle / 60:g} мин простоя" if idle > 0
                else "выгрузка по простою выключена (DT_EMBED_IDLE_UNLOAD_S=0)")
        line += f"; предупреждение: рядом с браузером и почтой возможен своп, {tail}"
    return line


def evaluate(probe: PlatformProbe, *, workspace: Path, engine_dir: Path,
             models_present: bool = False, host: str = "") -> tuple[list[str], list[str]]:
    """``(замечания, подсказки)``: пусто - машина подходит; порядок - от главного к мелкому.

    ``host`` - выбранный хост ассистента: CLI ``claude`` проверяется, только если это Claude Code
    (``claude-code``); для Desktop и остальных он не нужен."""
    problems: list[str] = []
    hints: list[str] = []
    if probe.system() != "Darwin":
        return [f"система {probe.system() or '?'}: поддерживается только macOS"], [
            "Linux/Windows - отдельная ветка, в этой версии не входит"]
    ver = probe.mac_version()
    if _major(ver) < MIN_MACOS:
        problems.append(f"macOS {ver or '?'}: нужна {MIN_MACOS} или новее")
        hints.append("обнови macOS (Системные настройки → Основные → Обновление ПО)")
    if probe.machine() not in SUPPORTED_ARCH:
        problems.append(f"архитектура {probe.machine() or '?'}: нужна arm64 или x86_64")
    ram = probe.ram_gib()
    if ram is not None and ram < MIN_RAM_GIB:
        problems.append(f"{_LOW_RAM_MARK}{ram:.0f} ГБ: нужно не меньше {MIN_RAM_GIB:g} ГБ "
                        "(модель поиска не поместится, двойник не поедет)")
        hints.append("двойнику нужен Mac с 8 ГБ памяти или больше (комфортно - от 16 ГБ)")
    need = NEED_FREE_WITH_MODELS_GIB if models_present else NEED_FREE_GIB
    free = probe.free_bytes(workspace) / _GIB
    if free < need:
        problems.append(f"свободно {free:.1f} ГБ, нужно не меньше {need:g} ГБ")
        hints.append("освободи место на диске, где лежит рабочая папка, и повтори")
    if probe.which("uv") is None:
        problems.append("нет uv")
        hints.append(UV_HINT)
    elif (uv_off := _off_path(probe, "uv")) is not None:
        problems.append(uv_off[0])
        hints.append(uv_off[1])
    if probe.which("git") is None:
        problems.append("нет git")
        hints.append(GIT_HINT)
    if host == "claude-code" and probe.which("claude") is None:
        problems.append("нет claude (CLI Claude Code)")
        hints.append(CLAUDE_HINT)
    elif host == "claude-code" and (off := _off_path(probe, "claude")) is not None:
        problems.append(off[0])
        hints.append(off[1])
    uv_found = probe.which("uv") is not None
    if uv_found and probe.on_path("uv") and probe.uv_python(engine_dir) is None:
        problems.append("uv не нашел Python для проекта")
        hints.append("uv python install 3.12 (uv сам скачает Python, sudo не нужен)")
    return problems, hints
