"""Мастер вопросов ``dt install``: vault, имя/почты/компания/домены владельца, хост, коннекторы.

Спрашивает только то, чего еще нет ни во флагах, ни в ``state.json`` (повтор не переспрашивает).
Ключей и токенов мастер НЕ просит никогда: секреты - отдельной командой
(``dt config set KEY --stdin``, см. ``installer/brain/04-integrations.md``). ``--yes`` - без
вопросов: значения из флагов/состояния, умолчания для необязательного; нет обязательного
(имя, почта) - отказ с подсказкой флага.
Ответы сохраняются в ``state.json`` (это не секреты).
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from core import connectors
from core.install import capabilities
from core.install.base import InstallError
from core.install.context import HOST_CHOICES, InstallContext

__all__ = ["ALL_FIELDS", "apply_capabilities", "complete", "parse_list", "plan_lines",
           "prepare_capabilities", "validate_connectors"]

ALL_FIELDS = ("vault", "name", "emails", "company", "domains", "internal_domains", "host",
              "connectors", "mailboxes")
_REQUIRED_YES = {"name": "--name", "emails": "--email"}
_LIST_FIELDS = {"emails", "domains", "internal_domains", "mailboxes"}
_QUESTIONS = {
    "vault": "Где лежит ваш vault (папка с заметками)",
    "name": "Как вас зовут (имя и фамилия)",
    "emails": "Ваши рабочие адреса почты (через запятую)",
    "company": "Компания (можно пропустить)",
    "domains": "Почтовые домены компании (через запятую; можно пропустить)",
    "internal_domains": "Служебные домены группы (через запятую; можно пропустить)",
    "host": f"Какой ассистент подключаем ({'/'.join(HOST_CHOICES)})",
    "connectors": "Внешние коннекторы: none или список (timetta, ticktick, outlook)",
    "mailboxes": "Какие ящики Outlook читать (адреса через запятую; all - все живые, none - ни "
                 "одного)",
}


def parse_list(raw: str) -> list[str]:
    return [p.strip() for p in raw.replace(";", ",").split(",") if p.strip()]


def validate_connectors(value: str) -> str:
    """``none`` | ``auto`` | список известных коннекторов (через запятую); иначе - отказ."""
    text = (value or "").strip().lower()
    if text in ("", "none"):
        return "none"
    if text == "auto":
        return "auto"
    keys: list[str] = []
    for tok in parse_list(text):
        try:
            keys.append(connectors.normalize(tok))
        except KeyError:
            raise InstallError(
                "bad_connector", f"неизвестный коннектор {tok!r}",
                f"допустимо: none, auto, {', '.join(connectors.CONNECTORS)}") from None
    return ",".join(dict.fromkeys(keys))


def _default(ctx: InstallContext, field: str) -> str:
    return {"vault": str(ctx.vault), "host": "claude", "connectors": "none"}.get(field, "")


def _get(ctx: InstallContext, field: str) -> str | list[str]:
    return getattr(ctx.answers, field)


def complete(ctx: InstallContext, need: Sequence[str] = ALL_FIELDS) -> None:
    """Дополнить ``ctx.answers`` недостающим по ``need``; сохранить в состояние (не при dry-run)."""
    changed = False
    asked: set[str] = set(ctx.state.answers.get("_asked", [])) if ctx.state else set()
    for field in need:
        if field == "mailboxes":
            changed = _ask_mailboxes(ctx, asked) or changed
            continue
        if _get(ctx, field) or field in asked:
            continue
        if ctx.yes:
            if field in _REQUIRED_YES:
                raise InstallError(
                    "answers_missing", f"в режиме --yes не задано: {field}",
                    f"передай {_REQUIRED_YES[field]} (или запусти без --yes - спрошу)")
            default = _default(ctx, field)
            if default:
                _put(ctx, field, default)
            continue
        default = _default(ctx, field)
        answer = ctx.tools.prompt(_QUESTIONS[field], default)
        if not answer and field in _REQUIRED_YES:
            raise InstallError("answers_missing", f"нужно значение: {field}",
                               "повтори `dt install` и ответь на вопрос")
        asked.add(field)  # пропущенное необязательное повтор не переспрашивает
        changed = True
        if answer:
            _put(ctx, field, answer)
    _normalize(ctx)
    if ctx.answers.vault:
        ctx.vault = Path(ctx.answers.vault).expanduser().resolve()
    if (changed or ctx.state is not None) and not ctx.dry_run and ctx.state is not None:
        ctx.guard(ctx.state.path)
        ctx.state.answers = {**ctx.answers.as_dict(), "_asked": sorted(asked)}
        ctx.state.save()


def _outlook_on(ctx: InstallContext) -> bool:
    """Outlook выбран явно (``outlook`` в коннекторах); для auto/none ящики не спрашиваем."""
    keys = [t.strip() for t in (ctx.answers.connectors or "").split(",")]
    return "outlook" in keys


def _ask_mailboxes(ctx: InstallContext, asked: set[str]) -> bool:
    """Вопрос «какие ящики читать» (MAIL-ACCOUNTS-1 п.6): ящики из живого Outlook, по умолчанию -
    все живые (без «On My Computer» и архивов без аккаунта). Результат: ``answers.mailboxes`` +
    ``answers.mailbox_specs`` (JSON для ``DT_OUTLOOK_FOLDERS``). Outlook недоступен - вопрос
    пропускается с пояснением (остаются умолчания, доктор пометит «папка без аккаунта»)."""
    from core.install import mailboxes as mb

    if ctx.answers.mailbox_specs or "mailboxes" in asked or not _outlook_on(ctx):
        return False
    boxes = mb.discover(ctx.tools.list_mailboxes())
    if not boxes:
        ctx.tools.out("Ящики Outlook не прочитаны (Outlook не запущен или в новом режиме): "
                      "вопрос пропущен. Позже: dt_mail_ingest.py --list-folders и "
                      "`dt config set DT_OUTLOOK_FOLDERS …`.")
        return False
    if ctx.yes:
        chosen = mb.default_selection(boxes)
    else:
        ctx.tools.out("Живые ящики Outlook:")
        for line in mb.describe(boxes):
            ctx.tools.out(line)
        ctx.tools.out("Архивы без аккаунта («On My Computer», PST) не предлагаются.")
        default = ",".join(b.account for b in mb.default_selection(boxes))
        chosen = mb.select(ctx.tools.prompt(_QUESTIONS["mailboxes"], default), boxes)
    asked.add("mailboxes")
    ctx.answers.mailboxes = [b.account for b in chosen]
    ctx.answers.mailbox_specs = mb.specs_json(chosen) if chosen else ""
    return True


def _put(ctx: InstallContext, field: str, value: str) -> None:
    setattr(ctx.answers, field, parse_list(value) if field in _LIST_FIELDS else value)


def _normalize(ctx: InstallContext) -> None:
    ans = ctx.answers
    if ans.host and ans.host not in HOST_CHOICES:
        raise InstallError("bad_host", f"неизвестный хост {ans.host!r}",
                           f"допустимо: {', '.join(HOST_CHOICES)}")
    if ans.connectors:
        ans.connectors = validate_connectors(ans.connectors)


# --------------------------------------------------------------------------- DT-OPTIONS-1 ----- #
def _choices(ctx: InstallContext) -> capabilities.Choices:
    return capabilities.choices_from_answers(ctx.answers)


def prepare_capabilities(ctx: InstallContext) -> None:
    """До вопросов мастера: диалог плана (``--capabilities``) и предварительные коннекторы.

    План управляет установкой, только если человек что-то выбрал; иначе функция ничего не делает и
    мастер/``--connectors`` работают как раньше. Выбранное явно - кандидаты для вопроса о ящиках
    Outlook (он спрашивается, если ``outlook`` в коннекторах); итог (с предпосылками) подводит
    :func:`apply_capabilities` ПОСЛЕ мастера."""
    if ctx.capability_dialogue:
        capabilities.ask_dialogue(ctx)
    choices = _choices(ctx)
    if not capabilities.is_managed(choices):
        return
    wanted = [capabilities.CONNECTOR_OF[k] for k in capabilities.OPTIONAL
              if k in choices.enable and k not in choices.disable]
    ctx.answers.connectors = ",".join(wanted) or "none"


def apply_capabilities(ctx: InstallContext) -> capabilities.Plan | None:
    """После мастера: свести выбор и предпосылки в план, показать, подтвердить, записать.

    Подтверждение - ``--yes`` или явное «да»; отказ - ``plan_not_confirmed`` (ничего не записано).
    Подтвержденный план лежит в ``state.json`` (``capabilities``); ``answers.connectors`` берется
    из плана (готовые опции), поэтому ``DT_CONNECTORS`` пишет существующий шаг ``config``. Сну
    план ничего не ставит и не пишет: режим только записан (расписание - рантайм Сна)."""
    choices = _choices(ctx)
    if not capabilities.is_managed(choices):
        return None
    plan = capabilities.resolve(choices, capabilities.facts_from_ctx(ctx))
    for line in capabilities.render_plan(plan):
        ctx.say(line)
    stored = ctx.state.capabilities if ctx.state else {}
    same = bool(stored.get("confirmed")) and stored.get("digest") == plan.digest()
    if not same and not capabilities.confirm_plan(ctx, plan):
        raise InstallError("plan_not_confirmed", "план возможностей не подтвержден: ничего не "
                           "записано", "повтори `dt install --step config` и ответь «да» "
                           "(или --yes)")
    ctx.answers.connectors = capabilities.effective_connectors(plan)
    if ctx.state is not None and not ctx.dry_run:
        from datetime import UTC, datetime

        ctx.guard(ctx.state.path)
        asked = ctx.state.answers.get("_asked", [])
        ctx.state.answers = {**ctx.answers.as_dict(), "_asked": asked}
        if not same:
            ctx.state.capabilities = {
                "confirmed": True, "digest": plan.digest(), "plan": plan.as_dict(),
                "confirmed_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")}
        ctx.state.save()
    return plan


def plan_lines(ctx: InstallContext) -> list[str]:
    """Строки плана для ``--check``/``--dry-run``/``--plan`` (только чтение; пусто - плана нет)."""
    stored = ctx.state.capabilities if ctx.state else {}
    try:
        choices = _choices(ctx)
        if not capabilities.is_managed(choices):
            line = capabilities.stored_plan_line(stored)
            return [line] if line else []
        lines = capabilities.render_plan(
            capabilities.resolve(choices, capabilities.facts_from_ctx(ctx)))
    except InstallError as exc:
        return [f"план возможностей: {exc.reason}" + (f" ({exc.hint})" if exc.hint else "")]
    line = capabilities.stored_plan_line(stored)
    return [*lines, line] if line else lines
