"""Jupyter-блокноты ``.ipynb`` (KIT-FIT-1 п.7): JSON без новых зависимостей.

Markdown-ячейки идут текстом, код-ячейки - блоком кода (язык из метаданных ядра), к ячейке
прикладываются только ТЕКСТОВЫЕ выводы (``stream``, ``text/plain``, имя и текст ошибки): картинки,
HTML и прочие бинарные представления (base64 способен весить десятки МБ) отбрасываются, число
отброшенных - в ``meta``. Длинный вывод режется до :data:`OUTPUT_CAP` символов, у блокнота есть
общий потолок :data:`TOTAL_OUTPUT_CAP` на все выводы. Формат nbformat 4 (``cells``) и 3
(``worksheets[].cells``). Битый JSON или не блокнот - ``status="error"`` с причиной
(``extract`` и без этого превращает исключение в ``error``; здесь причина названа по-человечески).
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from ._base import STATUS_ERROR, LegacyDoc, LegacyUnit, register

__all__ = ["OUTPUT_CAP", "TOTAL_OUTPUT_CAP"]

OUTPUT_CAP = 2000  # символов на один вывод ячейки
TOTAL_OUTPUT_CAP = 20000  # символов выводов на весь блокнот
_ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")  # цвета трассировок ошибок


def _text(value: Any) -> str:
    """Поле ``source``/``text``: строка либо список строк (так хранит nbformat)."""
    if isinstance(value, list):
        return "".join(str(part) for part in value)
    return value if isinstance(value, str) else ""


def _cells(nb: dict[str, Any]) -> list[Any] | None:
    cells = nb.get("cells")
    if isinstance(cells, list):
        return cells
    sheets = nb.get("worksheets")  # nbformat 3
    if isinstance(sheets, list):
        merged: list[Any] = []
        for sheet in sheets:
            if isinstance(sheet, dict) and isinstance(sheet.get("cells"), list):
                merged.extend(sheet["cells"])
        return merged
    return None


def _language(nb: dict[str, Any]) -> str:
    meta = nb.get("metadata")
    meta = meta if isinstance(meta, dict) else {}
    for key, field in (("language_info", "name"), ("kernelspec", "language")):
        block = meta.get(key)
        if isinstance(block, dict) and isinstance(block.get(field), str) and block[field].strip():
            return re.sub(r"[^A-Za-z0-9_+#-]", "", block[field].strip().lower()) or "python"
    return "python"


def _output_text(out: Any) -> tuple[str, bool]:
    """``(текст, отброшено ли нетекстовое представление)`` одного вывода ячейки."""
    if not isinstance(out, dict):
        return "", False
    kind = out.get("output_type")
    if kind == "stream":
        return _text(out.get("text")), False
    if kind in ("error", "pyerr"):
        return f"{out.get('ename', '')}: {out.get('evalue', '')}".strip(": ").strip(), False
    if kind in ("execute_result", "display_data", "pyout"):
        data = out.get("data")
        if isinstance(data, dict):  # nbformat 4: словарь MIME-представлений
            return _text(data.get("text/plain")), any(k != "text/plain" for k in data)
        return _text(out.get("text")), any(k in _V3_BINARY for k in out)  # nbformat 3
    return "", False


_V3_BINARY = frozenset({"png", "jpeg", "svg", "html", "latex", "javascript", "pdf"})


def _clip(text: str, cap: int) -> tuple[str, int]:
    """Режет ``text`` до ``cap`` символов с пометкой; второе значение - сколько срезано."""
    text = _ANSI.sub("", text).strip("\n")
    if len(text) <= cap:
        return text, 0
    cut = len(text) - cap
    return text[:cap].rstrip() + f"\n... [вывод обрезан: еще {cut} симв.]", cut


@register(".ipynb")
def _extract_notebook(path: Path, source_type: str) -> LegacyDoc:
    try:
        nb = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return LegacyDoc(source_type=source_type, status=STATUS_ERROR,
                         error=f"ipynb: не JSON (строка {exc.lineno}, столбец {exc.colno}): "
                               f"{exc.msg}")
    except UnicodeDecodeError as exc:
        return LegacyDoc(source_type=source_type, status=STATUS_ERROR,
                         error=f"ipynb: не UTF-8 ({exc.reason})")
    cells = _cells(nb) if isinstance(nb, dict) else None
    if cells is None:
        return LegacyDoc(source_type=source_type, status=STATUS_ERROR,
                         error="ipynb: нет списка ячеек (cells) - это не блокнот Jupyter")

    lang = _language(nb)
    units: list[LegacyUnit] = []
    budget = TOTAL_OUTPUT_CAP
    dropped = clipped = 0
    for no, cell in enumerate(cells, start=1):
        if not isinstance(cell, dict):
            continue
        kind = cell.get("cell_type")
        body = _text(cell.get("source") if "source" in cell else cell.get("input")).strip("\n")
        if kind == "code":
            parts = [f"```{lang}\n{body}\n```"] if body.strip() else []
            for out in cell.get("outputs") or []:
                text, binary = _output_text(out)
                dropped += 1 if binary else 0
                if not text.strip():
                    continue
                if budget <= 0:
                    clipped += len(text)
                    continue
                text, cut = _clip(text, min(OUTPUT_CAP, budget))
                clipped += cut
                budget -= min(len(text), budget)
                parts.append(f"Вывод:\n```text\n{text}\n```")
            if parts:
                units.append(LegacyUnit(kind="block", no=no, text="\n\n".join(parts)))
        elif kind in ("markdown", "raw", "heading"):
            if kind == "heading":  # nbformat 3: уровень в ``level``
                level = cell.get("level") if isinstance(cell.get("level"), int) else 1
                body = f"{'#' * max(1, min(level, 6))} {body}"
            if body.strip():
                units.append(LegacyUnit(kind="block", no=no, text=body))
    meta: dict[str, Any] = {"cells": len(cells), "language": lang}
    if dropped:
        meta["outputs_dropped"] = dropped  # картинки, HTML и т. п.: в текст не попадают
    if clipped:
        meta["output_chars_clipped"] = clipped
    return LegacyDoc(source_type=source_type, units=units, meta=meta)
