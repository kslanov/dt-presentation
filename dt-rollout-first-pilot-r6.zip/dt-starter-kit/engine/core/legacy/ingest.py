"""File→note ingest orchestration for layer B (ТЗ phase5, stage 4; INGEST-DEDUP).

Ties discovery → extraction-cache → dedup → note rendering, governed by the
file→note manifest (``legacy_ingest_manifest.json``) for idempotency and
incrementality. Identity is **content-addressed** (INGEST-DEDUP): each manifest
entry carries a ``source_content_hash`` = sha256 of the file's *bytes*
(:func:`core.sources.cache.file_content_hash`), path-independent — so a folder
moved or renamed (iCloud→disk — the real K. case) is recognised as the *same*
files, not re-imported. The per-source decision order:

- **fast-path unchanged** — the same ``source_path`` with matching ``mtime+size``
  and its note on disk → left untouched, **without hashing** (cheap steady state);
- **relocated** — a new/changed path whose *bytes* match a manifest entry that has
  vanished from discovery → the note is kept and the entry re-pointed to the new
  path; **no re-extraction, no duplicate note**;
- **duplicate of an existing note** — bytes match a still-present entry → no note;
- **genuinely new / changed** — bytes never seen (or the same path with new bytes)
  → (re)extract + (re)render its ``_legacy/*.md`` note as before;
- source that vanished / became excluded / privacy / duplicate / unreadable →
  its previously-rendered note and manifest entry are dropped.

The byte-hash is the incrementality axis; the *text* content-hash
(:func:`core.legacy.dedup.content_hash` over normalised text) still drives
exact-dedup **within a run** over the files that get extracted (unchanged — INGEST-
DEDUP does not touch it). A repeated run with no changes does nothing (0 writes,
0 hashing). This module does **not** embed/index — the normal ``dt_index`` pass
picks up the notes afterwards. CLI depends on this; core never depends on the CLI.
No LLM (Path B).
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core import runlock
from core.adapters import AdapterError, AdapterInterrupted, load_json_store
from core.config import current_ingest_manifest_path, legacy_ingest_manifest_path
from core.contract import CODE_INGEST_NO_ROOTS, CODE_INGEST_ROOT_MISSING
from core.fsguard import guarded_call, is_dataless
from core.legacy.cache import extract_cached, peek_cached
from core.legacy.dedup import find_duplicates
from core.legacy.discover import LegacyFile, RootSpec, as_root_spec, discover
from core.legacy.linking import (
    backlink_curated,
    entity_catalog,
    generate_mocs,
    write_hub_candidates,
)
from core.legacy.manifest_roots import (
    ROOT_FIELD,
    assign_roots,
    layer_candidates,
    snapshot_manifest,
)
from core.legacy.render import (
    legacy_note_id,
    note_relpath,
    scan_fields,
    truncation_fields,
    write_legacy_note,
)
from core.legacy.repoint import repoint_note

# Byte-hash of the file's raw bytes — the path-independent identity axis for
# incrementality (INGEST-DEDUP). Reused from SRC-1; ``core.sources.cache`` depends
# only on ``core.config``, so this import introduces no cycle. Imported at module
# level (not lazily) so tests can spy on it to assert the fast-path does NOT hash.
from core.sources.cache import file_content_hash

logger = logging.getLogger(__name__)

__all__ = [
    "IngestNoRoots",
    "IngestRootMissing",
    "IngestStats",
    "ingest_corpus",
    "backfill_hashes",
    "manifest_hash_coverage",
    "mark_ocr_refresh",
    "pending_ocr_refresh",
    "MISSING_FIELD",
    "OCR_REFRESH_FIELD",
]

# Manifest field holding the file byte-hash (INGEST-DEDUP). Additive: pre-existing
# entries without it stay path-keyed (as before) until a re-ingest or --backfill.
HASH_FIELD = "source_content_hash"

# OCR-1 п.4: распознанный скан просит перерисовать свою заметку. Маркер в записи манифеста (ставит
# ``mark_ocr_refresh``, снимается самой перерисовкой - новая запись его не несет): fast-path и ветка
# «те же байты, сдвинулся mtime» заглушку бы сохранили. Это то самое «снять mtime» из ТЗ, но
# явное и не теряющее byte-hash.
OCR_REFRESH_FIELD = "ocr_refresh"

# DOCTOR-HONEST-1: исходник записи физически исчез с диска (backfill увидел
# ``skipped(missing)``). Запись остаётся — история переносов нужна дедупу, — но в
# знаменатель покрытия byte-hash'ем не идёт: требовать backfill того, чего нет, значит
# держать доктора вечно жёлтым без выполнимого действия.
MISSING_FIELD = "source_missing"
MISSING_AT_FIELD = "source_missing_at"


class IngestNoRoots(AdapterError):
    """``ingest_corpus`` вызван без корней (INGEST-SAFETY-1 п.2).

    Пустой набор корней = пустой обход = пустой манифест прогона; prune по нему удалил бы ВСЕ
    заметки слоя (так «фантом Легаси-корпус» стирал 596 заметок чужих адаптеров одним кликом).
    Это отказ с кодом, а не «нечего делать»: ничего не удалено, ничего не записано."""

    code = CODE_INGEST_NO_ROOTS
    default_adapter = "legacy"


class IngestRootMissing(IngestNoRoots):
    """Ни один корень прогона не каталог на этом устройстве (диск/шара не смонтированы, iCloud
    не поднялся): обход пуст не потому, что файлов нет. Отказ тем же смыслом, свой код."""

    code = CODE_INGEST_ROOT_MISSING


@dataclass
class IngestStats:
    """Disposition of one ingest run."""

    new: int = 0
    changed: int = 0
    unchanged: int = 0
    relocated: int = 0  # recognised by byte-hash as a moved/renamed file (no re-extract)
    relocated_note_updates: int = 0  # SRC-PATH-1: из них заметок, где переписан source_path
    reattr_proposed: int = 0  # REATTR-1: переносы между сущностными каталогами → очередь
    deleted: int = 0
    # INGEST-SAFETY-1: файлы, чей ключ манифеста (путь от корня) уже занят записью ДРУГОГО корня
    # слоя - пропущены (не перетираем чужое); записи манифеста без назначенного корня (миграция)
    collisions: int = 0
    migrated_roots: int = 0  # записям манифеста слоя поставлена метка root в этом прогоне
    # INGEST-SAFETY-1 п.3: гард массового удаления. ``prune_guard`` - сработавшие корни
    # (``[{root, n, total, pct, paths, ...}]``), ``prune_blocked`` - сколько заметок НЕ удалено
    # из-за гарда; ``snapshot`` - снимок манифеста слоя, снятый перед удалением/миграцией.
    prune_guard: list[dict[str, Any]] = field(default_factory=list)
    prune_blocked: int = 0
    snapshot: str = ""
    skipped_exclude: int = 0
    skipped_privacy: int = 0
    duplicate: int = 0
    needs_ocr: int = 0
    needs_conversion: int = 0
    skipped_unsupported: int = 0
    # KIT-FIT-1 п.11: заметки этого прогона, чей xlsx обрезан потолком ячеек при входе
    # (``DT_LEGACY_XLSX_CELL_CAP``): кэш экстракции помнил это, заметка и статистика - нет
    truncated: int = 0
    # WAVE0-HYGIENE п.3: файлы, которые НЕ читали — iCloud-заглушка (dataless) или чтение
    # оборвано таймаутом/сном (``adapter_interrupted``). Заметка прежней версии при этом
    # остаётся (запись манифеста переносится как есть), следующий проход повторит.
    pending_download: int = 0
    interrupted: int = 0
    errors: int = 0
    notes_total: int = 0
    mocs: int = 0  # _index.md MOCs written
    hub_candidates: int = 0  # clients with legacy material but no hub
    backlinks: int = 0  # curated notes that got a legacy back-link
    backlinked: list[str] = field(default_factory=list)  # which curated note ids
    elapsed_s: float = 0.0
    dry_run: bool = False
    scope: str = "incremental"
    manifest_path: str = ""
    examples: list[str] = field(default_factory=list)  # a few rendered note paths
    report_path: str = ""  # diagnostic per-bucket report, when one was written


# --------------------------------------------------------------------------- #
# Manifest                                                                    #
# --------------------------------------------------------------------------- #


def _load_manifest(path: Path) -> dict[str, dict[str, Any]]:
    """Манифест легаси-инжеста. Нет файла → ``{}``; битый → ``StoreUnavailableError``
    (ADAPTER-HONEST-1): «битый ⇒ пусто» объявляло бы все файлы новыми — дубли заметок,
    потерянная привязка переносов."""
    data = load_json_store(path, adapter="legacy_manifest", expect=dict)
    if data is None:
        return {}
    return {str(k): v for k, v in data.items() if isinstance(v, dict)}


def _save_manifest(path: Path, manifest: dict[str, dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    tmp.replace(path)


def _byte_hash(lf: LegacyFile, content_hashes: dict[str, str] | None) -> str:
    """Byte-hash of ``lf`` — reuse a caller-supplied hash (by absolute path) or
    compute it. The reuse path lets INGEST-1 ``scan`` avoid a second read (PART-3);
    the compute path is the sole place this module hashes bytes (spied on in tests
    to prove the fast-path never hashes)."""
    if content_hashes:
        precomputed = content_hashes.get(str(lf.path))
        if precomputed:
            return precomputed
    return file_content_hash(lf.path)


# WAVE0-HYGIENE п.3: столько подряд оборванных чтений — iCloud/диск не отвечает, дальше
# каждое чтение стоило бы полного таймаута: шаг останавливает себя (отказ, не вечное
# ожидание) и ночная цепочка идёт дальше. ``DT_INGEST_MAX_INTERRUPTED`` (дефолт 3).
def _max_consecutive_interrupted() -> int:
    import os

    raw = (os.environ.get("DT_INGEST_MAX_INTERRUPTED") or "").strip()
    return int(raw) if raw.isdigit() and int(raw) > 0 else 3


def _guarded_byte_hash(lf: LegacyFile, content_hashes: dict[str, str] | None) -> str:
    """:func:`_byte_hash` под таймаутом (читает файл) — но без потока, если хэш уже известен."""
    if content_hashes and content_hashes.get(str(lf.path)):
        return _byte_hash(lf, content_hashes)
    return guarded_call(_byte_hash, lf, content_hashes, what="хэш файла")


def _refreshed(entry: dict[str, Any], lf: LegacyFile, byte_hash: str) -> dict[str, Any]:
    """Carry an existing entry's note forward under a new/refreshed identity.

    Keeps ``note_path``/``content_hash``/``status`` (the note is untouched) and
    refreshes ``mtime``/``size`` to the live file plus the byte-hash — used for a
    relocation (re-pointed to a new ``source_path`` key) or an identical-bytes
    touch (same key, shifted mtime)."""
    refreshed = dict(entry)
    refreshed["mtime"] = lf.mtime
    refreshed["size"] = lf.size
    refreshed[HASH_FIELD] = byte_hash
    return refreshed


def _run_specs(
    roots: list[Path | RootSpec] | None, root_names: list[str] | None
) -> list[RootSpec]:
    """Корни прогона → ``RootSpec`` с метками. ``None`` - ``config.legacy_roots()``.

    ``root_names[i]`` называет i-й корень, если он передан путем (не ``RootSpec`` с именем)."""
    from dataclasses import replace

    from core.config import legacy_roots

    raw = list(roots) if roots is not None else list(legacy_roots())
    specs: list[RootSpec] = []
    for i, r in enumerate(raw):
        spec = as_root_spec(r)
        if not spec.name and root_names and i < len(root_names) and root_names[i]:
            spec = replace(spec, name=root_names[i])
        specs.append(spec)
    return specs


# --------------------------------------------------------------------------- #
# Diagnostic report                                                           #
# --------------------------------------------------------------------------- #


def _write_dryrun_report(
    path: Path,
    *,
    roots: list[Path] | None,
    stats: IngestStats,
    excluded: list[tuple[str, str]],
    privacy: list[tuple[str, str]],
    errors: list[tuple[str, str]],
    needs_ocr: list[str],
    needs_conversion: list[str],
    unsupported: list[tuple[str, str]],
    duplicates: list[tuple[str, str]],
) -> None:
    """Write a human-readable per-bucket report of every non-note disposition.

    Lets the path lists behind ``skipped(privacy)`` / ``skipped(exclude)`` /
    ``errors`` / ``needs_ocr`` / ``unsupported`` / ``duplicate`` be eyeballed
    before a large ingest — to confirm privacy/exclude caught the right files and
    that ``errors`` are not valuable documents.
    """
    lines: list[str] = []
    lines.append("# Legacy ingest dry-run report")
    lines.append(f"scope={stats.scope} dry_run={stats.dry_run}")
    root_str = ", ".join(str(r) for r in roots) if roots else "(config default)"
    lines.append(f"roots: {root_str}")
    lines.append(
        "totals: "
        f"notes={stats.notes_total} privacy={len(privacy)} exclude={len(excluded)} "
        f"duplicate={len(duplicates)} needs_ocr={len(needs_ocr)} "
        f"needs_conversion={len(needs_conversion)} "
        f"unsupported={len(unsupported)} errors={len(errors)}"
    )

    def _plain(title: str, items: list[str]) -> None:
        lines.append("")
        lines.append(f"## {title} ({len(items)})")
        lines.extend(f"  {sp}" for sp in sorted(items))

    def _annotated(title: str, items: list[tuple[str, str]]) -> None:
        lines.append("")
        lines.append(f"## {title} ({len(items)})")
        for sp, why in sorted(items):
            lines.append(f"  {sp}    [{why}]" if why else f"  {sp}")

    _annotated("skipped(privacy)", privacy)
    _annotated("skipped(exclude)", excluded)
    _annotated("errors", errors)
    _plain("needs_ocr", needs_ocr)
    _plain("needs_conversion", needs_conversion)
    _annotated("unsupported", unsupported)
    _annotated("duplicate (→ representative)", duplicates)

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------- #
# Ingest                                                                      #
# --------------------------------------------------------------------------- #


def _under_scope(source_path: str, prefix: str) -> bool:
    """Whether a root-relative ``source_path`` is under the ``prefix`` folder.

    Segment-anchored so ``Kazakhstan/Acme`` matches ``Kazakhstan/Acme/x`` and the
    folder itself, but never ``Kazakhstan/AcmeX``. Empty prefix matches everything.
    """
    if not prefix:
        return True
    sp = source_path.replace("\\", "/")
    return sp == prefix or sp.startswith(prefix + "/")


def _indexable(record: dict[str, Any]) -> bool:
    """A record yields a note iff it extracted OK and has at least one unit."""
    return record.get("status") == "ok" and bool(record.get("units"))


def _is_stub(record: dict[str, Any]) -> bool:
    """OCR-1 п.1: скан без текстового слоя - не отказ, а заметка-заглушка (имя, страницы)."""
    return bool(record.get("needs_ocr")) and record.get("status") == "skipped"


def _count_candidates(path: Path | None) -> int:
    """Count data rows in the hub-candidates table (0 when the file is absent)."""
    if path is None or not path.is_file():
        return 0
    rows = [
        ln
        for ln in path.read_text(encoding="utf-8").splitlines()
        if ln.startswith("| ") and not ln.startswith("| ---") and "| ---" not in ln
    ]
    # Subtract the header row ("| клиент | …").
    return max(0, len(rows) - 1)


def _propose_reattr(
    relocations: list[dict[str, str]], vault_path: Path, catalog: list[Any]
) -> int:
    """REATTR-1: переносы прогона → предложения переатрибуции. Сколько добавлено.

    Каталог хабов строим ЛЕНИВО и только здесь: при ``link=False`` его в прогоне нет,
    а обход vault ради каждого файла был бы дороже самого инжеста. Сбой детектора не
    имеет права уронить инжест (перенос уже записан в манифест — падение здесь
    означало бы, что тысяча файлов не доехала из-за одной карточки), но и молчать
    он не должен: WARNING в общий лог, который читает пульт.
    """
    try:
        # Лениво: ``core.linking`` тянет линковочный слой, инжесту на общем пути
        # ненужный (и импортируется он через legacy-линковку — цикла не создаём).
        from core.linking.reattr import propose_reattributions

        hubs = catalog or entity_catalog(vault_path)
        return len(propose_reattributions(relocations, catalog=hubs))
    except Exception as exc:  # noqa: BLE001 — предложение не важнее самого инжеста
        logger.warning(
            "reattr: предложения не собраны (переносов %d): %s", len(relocations), exc
        )
        return 0


class _ReadGuard:
    """Гард чтения файлов одного прогона ingest (WAVE0-HYGIENE п.3, аудит B3).

    * dataless iCloud-заглушку не читаем (``pending``): чтение блокируется в ядре;
    * хэш и экстракция идут под таймаутом (:func:`core.fsguard.guarded_call`), оборванный
      файл — ``adapter_interrupted`` (счётчик ``stats.interrupted``), НЕ вечное ожидание;
    * пропущенный файл остаётся со старой записью манифеста (заметка прежней версии жива,
      следующий проход повторит) — иначе drop-цикл счёл бы его «исчезнувшим» и снёс заметку;
    * ``DT_INGEST_MAX_INTERRUPTED`` оборванных подряд — отказ всего шага (iCloud не
      отвечает; каждое следующее чтение стоило бы полного таймаута), цепочка идёт дальше.
    """

    def __init__(
        self,
        stats: IngestStats,
        prev: dict[str, dict[str, Any]],
        manifest: dict[str, dict[str, Any]],
        carried_notes: list[str],
        consumed_hashes: set[str],
    ) -> None:
        self.stats = stats
        self.prev = prev
        self.manifest = manifest
        self.carried_notes = carried_notes
        self.consumed_hashes = consumed_hashes
        self.streak = 0

    def skip(self, lf: LegacyFile, why: str) -> None:
        entry = self.prev.get(lf.source_path)
        if entry is not None:
            self.manifest[lf.source_path] = dict(entry)
            self.carried_notes.append(lf.source_path)
            bh_prev = entry.get(HASH_FIELD)
            if bh_prev:
                self.consumed_hashes.add(str(bh_prev))
        logger.warning("[ingest] %s: %s — пропущен, повторим в следующем проходе",
                       lf.source_path, why)

    def interrupted(self, lf: LegacyFile, exc: AdapterInterrupted) -> None:
        self.stats.interrupted += 1
        self.streak += 1
        self.skip(lf, f"{exc.code}: {exc.reason}")
        if self.streak >= _max_consecutive_interrupted():
            raise AdapterInterrupted(
                f"{self.streak} чтения подряд оборваны (iCloud/диск не отвечает) — шаг "
                "остановлен, прогон идёт дальше; повторим в следующем проходе",
                adapter="file_read", interrupted=self.stats.interrupted,
                pending_download=self.stats.pending_download,
            ) from exc

    def byte_hash(
        self, lf: LegacyFile, content_hashes: dict[str, str] | None
    ) -> str | None:
        """Byte-hash файла, либо ``None`` (заглушка/обрыв — файл пропущен)."""
        if is_dataless(lf.path):
            self.stats.pending_download += 1
            self.skip(lf, "iCloud dataless (не скачан)")
            return None
        try:
            digest = _guarded_byte_hash(lf, content_hashes)
        except AdapterInterrupted as exc:
            self.interrupted(lf, exc)
            return None
        self.streak = 0
        return digest


def _extract_pending(
    to_extract: list[tuple[LegacyFile, str]],
    *,
    dry_run: bool,
    scope: str,
    guard: _ReadGuard,
) -> dict[str, dict[str, Any]]:
    """Экстракция новых/изменённых файлов → ``{source_path: record}`` (с heartbeat'ом на
    файл; оборванный файл в результат не попадает — см. :class:`_ReadGuard`)."""
    records: dict[str, dict[str, Any]] = {}
    for lf, bh in to_extract:
        runlock.beat()
        try:
            result = (
                peek_cached(lf)
                if dry_run
                else guarded_call(
                    extract_cached, lf, force=(scope == "full"), what="экстракция файла"
                )
            )
        except AdapterInterrupted as exc:
            guard.interrupted(lf, exc)
            continue
        guard.streak = 0
        rec = result.record
        rec[HASH_FIELD] = bh  # ride the byte-hash into the note frontmatter + manifest
        records[lf.source_path] = rec
    return records


def _manifest_entry(
    lf: LegacyFile, rec: dict[str, Any], rel: str
) -> tuple[dict[str, Any], str | None]:
    """Запись манифеста для отрисованной заметки + состояние скана (OCR-1), если это скан.

    Заглушка идентифицируется БАЙТАМИ (текста нет, ``content_hash`` у всех пустой); состояние
    ``ocr`` и ``pages`` кладутся в запись - сводка доктора/пульта обходится без чтения заметок."""
    entry: dict[str, Any] = {
        "mtime": lf.mtime,
        "size": lf.size,
        "content_hash": rec[HASH_FIELD] if _is_stub(rec) else rec["content_hash"],
        HASH_FIELD: rec[HASH_FIELD],
        "note_path": rel,
        "status": "note",
    }
    cut = truncation_fields(rec)
    if cut:  # KIT-FIT-1 п.11: доктор считает обрезанные заметки по манифесту (без чтения заметок)
        entry["truncated"] = True
        if "cell_cap" in cut:
            entry["cell_cap"] = cut["cell_cap"]
    ocr_state = scan_fields(lf, rec).get("ocr")
    if ocr_state:
        entry["ocr"] = ocr_state
        pages = (rec.get("meta") or {}).get("pages")
        if isinstance(pages, int):
            entry["pages"] = pages
    return entry, ocr_state


def _log_ocr_signals(adapter: str, privacy_probe: int, low_paths: list[str]) -> None:
    """OCR-1: заглушки ``ocr: refused`` - только счетчик (counter-политика, без hint); распознанное
    с низкой уверенностью - предупреждение ``ocr_low_confidence`` с путем."""
    from core.ingress.refusals import refuse_many

    refuse_many(adapter, "privacy_probe", [(None, None)] * privacy_probe)
    refuse_many(adapter, "ocr_low_confidence", [(p, None) for p in low_paths])


def _log_refusals(
    corpus: str, *, excluded: list[tuple[str, str]], privacy: list[tuple[str, str, str]],
    needs_conversion: list[tuple[str, str]], unsupported: list[tuple[str, str]],
    errors: list[tuple[str, str]], needs_ocr: list[tuple[str, str]] | None = None,
) -> None:
    """Отказы прохода → ``core.ingress.refusals`` (политика hint — в самом модуле отказов).

    Каждый элемент - ``(метка корня, путь[, причина])``: ключ журнала - по КОРНЮ
    (:func:`_refusal_adapter`, INGEST-SAFETY-1 п.4). Вызывается только при записи (не dry-run)."""
    from core.ingress.refusals import refuse_many

    adapters = sorted({
        _refusal_adapter(corpus, item[0])
        for bucket in (excluded, privacy, needs_conversion, unsupported, errors, needs_ocr or [])
        for item in bucket
    })
    for adapter in adapters:
        def mine(bucket: list, adapter: str = adapter) -> list:
            return [it for it in bucket if _refusal_adapter(corpus, it[0]) == adapter]

        refuse_many(adapter, "exclude_rule", [(p, None) for _r, p in mine(excluded)])
        # приватность: только счетчик (в журнал ни пути, ни причины)
        priv = mine(privacy)
        refuse_many(adapter, "nda_path", [(p, None) for _r, p, why in priv if why == "nda"])
        refuse_many(adapter, "eval_quarantine",
                    [(p, None) for _r, p, why in priv if why == "eval_quarantine"])
        refuse_many(adapter, "privacy_personal",
                    [(p, None) for _r, p, why in priv if why not in ("nda", "eval_quarantine")])
        refuse_many(adapter, "needs_ocr", [(p, None) for _r, p in mine(needs_ocr or [])])
        refuse_many(adapter, "needs_conversion", [(p, None) for _r, p in mine(needs_conversion)])
        refuse_many(adapter, "unsupported", [(p, None) for _r, p in mine(unsupported)])
        refuse_many(adapter, "error", [(p, None) for _r, p in mine(errors)])


def _own_roots(specs: list[RootSpec], corpus: str) -> set[str]:
    """Метки корней прогона, чей каталог есть на этом устройстве (INGEST-SAFETY-1 п.2).

    Пустой набор корней - отказ ``ingest_no_roots``; ни одного существующего каталога - отказ
    ``ingest_root_missing`` (обход пуст из-за недоступного диска, не из-за отсутствия файлов).
    Недоступный корень среди доступных исключается из владения прогона: его записи не удаляются
    «за то, что корня не видно»."""
    if not specs:
        raise IngestNoRoots(
            "ingest без корней: prune по пустому обходу удалил бы все заметки слоя "
            f"{corpus!r} - ничего не сделано",
            adapter="legacy" if corpus == "legacy" else "files:knowledge",
            layer=corpus,
            hint="укажите корень (ingest-roots.yaml / DT_LEGACY_ROOTS / --roots)",
        )
    alive = [s for s in specs if Path(s.path).is_dir()]
    if not alive:
        raise IngestRootMissing(
            "ни один корень прогона не найден на диске: "
            + ", ".join(str(s.path) for s in specs)
            + " - обход пуст, prune удалил бы заметки слоя; ничего не сделано",
            adapter="legacy" if corpus == "legacy" else "files:knowledge",
            layer=corpus,
            hint="проверьте, что диск/шара/iCloud смонтированы",
        )
    for s in specs:
        if s not in alive:
            logger.warning("[ingest] корень %s (%s) не найден — его записи не трогаем",
                           s.label, s.path)
    return {s.label for s in alive}


class _Foreign:
    """Запись другого НАСТРОЕННОГО корня слоя - этот прогон ее не трогает (INGEST-SAFETY-1)."""

    def __init__(self, own: set[str], configured: set[str]) -> None:
        self.own = own
        self.configured = configured

    def __call__(self, entry: dict[str, Any] | None) -> bool:
        label = (entry or {}).get(ROOT_FIELD)
        return bool(label) and label in self.configured and label not in self.own


def _stamp_roots(manifest: dict[str, dict[str, Any]], by_sp: dict[str, LegacyFile]) -> None:
    """Запись манифеста прогона несет метку корня файла (ключ записи - всегда найденный файл)."""
    for sp, entry in manifest.items():
        if sp in by_sp:
            entry[ROOT_FIELD] = by_sp[sp].root


def _final_manifest(
    prev: dict[str, dict[str, Any]], manifest: dict[str, dict[str, Any]], own_roots: set[str],
    relocated_from: set[str], *, pruned: bool,
) -> dict[str, dict[str, Any]]:
    """Манифест к записи. Непрунящий (частичный) прогон - слияние поверх прежнего. Прунящий:
    чужое и ничье переживает, свои старые записи заменены решениями прогона, а ключ, чья заметка
    переехала под новый ключ (даже ничья), снят - заметка живет под новым."""
    if not pruned:
        return {**prev, **manifest}
    final = {
        sp: e for sp, e in prev.items()
        if e.get(ROOT_FIELD) not in own_roots and sp not in relocated_from
    }
    final.update(manifest)
    return final


def _doomed_entries(
    prev: dict[str, dict[str, Any]], manifest: dict[str, dict[str, Any]], own_roots: set[str]
) -> list[tuple[str, dict[str, Any]]]:
    """Записи прежнего манифеста, чьи заметки прогон удаляет (drop-loop, INGEST-SAFETY-1).

    Исчезнувший / ставший исключенным / приватным / дубликатом / нечитаемым исходник → его запись и
    заметка. Заметка, пережившая перенос (ее путь держит другая запись нового манифеста), НЕ
    удаляется. Берем только записи КОРНЕЙ ЭТОГО ПРОГОНА: чужой настроенный корень слоя и запись
    без владельца (``root: "?"`` / корень убран из конфига) - не наши, их не удаляет никто."""
    kept_note_paths = {e.get("note_path") for e in manifest.values() if e.get("note_path")}
    doomed: list[tuple[str, dict[str, Any]]] = []
    for sp, entry in prev.items():
        if entry.get(ROOT_FIELD) not in own_roots or sp in manifest:
            continue
        if entry.get("note_path") in kept_note_paths:
            continue  # relocated: the note lives on under a re-pointed entry
        doomed.append((sp, entry))
    return doomed


def _run_adapter(corpus: str, own_roots: set[str]) -> str:
    """Ключ журнала для сигналов всего прогона: корень один - по корню, иначе общий."""
    if corpus == "legacy":
        return "legacy"
    return _refusal_adapter(corpus, next(iter(own_roots))) if len(own_roots) == 1 \
        else "files:knowledge"


def _refusal_adapter(corpus: str, label: str) -> str:
    """Ключ отказа ingest'а: слой legacy - ``legacy``; знаниевый корень -
    ``files:knowledge:<корень>`` (атрибуция по корню, INGEST-SAFETY-1 п.4)."""
    return "legacy" if corpus == "legacy" else f"files:knowledge:{label}"


def _guarded(
    doomed: list[tuple[str, dict[str, Any]]], prev: dict[str, dict[str, Any]],
    own_roots: set[str], corpus: str, stats: IngestStats, *, allow_prune: bool, dry_run: bool,
    run_id: str,
) -> tuple[list[tuple[str, dict[str, Any]]], set[str]]:
    """Гард массового удаления по корням прогона → ``(разрешенное к удалению, сработавшие корни)``.

    Для каждого корня: ``len(doomed) > MAX_PCT% от его записей`` И ``> MIN_N`` - корень НЕ
    чистится (остальные корни прогона - в обычном порядке). Срабатывание: отказ ``prune_guard`` в
    журнал и метку-состояние для доктора (оба - не в dry-run), запись в ``stats.prune_guard``.
    Корень без срабатывания снимает прежнюю метку. ``allow_prune`` пропускает проверку."""
    from core.ingress.refusals import refuse_many
    from core.legacy import prune_guard as pg

    totals: dict[str, int] = {}
    for entry in prev.values():
        totals[entry.get(ROOT_FIELD, "")] = totals.get(entry.get(ROOT_FIELD, ""), 0) + 1
    by_root: dict[str, list[str]] = {}
    for sp, entry in doomed:
        by_root.setdefault(str(entry.get(ROOT_FIELD)), []).append(sp)
    blocked: set[str] = set()
    for root in sorted(own_roots):
        trip = None if allow_prune else pg.evaluate(
            root, by_root.get(root, []), totals.get(root, 0)
        )
        if trip is None:
            if not dry_run:
                pg.clear_trip(corpus, root)
            continue
        blocked.add(root)
        stats.prune_guard.append(trip)
        stats.prune_blocked += trip["n"]
        logger.error(
            "[ingest] prune_guard: корень %r - к удалению %d из %d (%.1f%%), порог %g%% и %d: "
            "НЕ удалено (снять - allow_prune / --allow-prune)",
            root, trip["n"], trip["total"], trip["pct"], trip["max_pct"], trip["min_n"],
        )
        if not dry_run:
            pg.record_trip(corpus, trip, run_id=run_id)
            refuse_many(_refusal_adapter(corpus, root), "prune_guard",
                        [(pg.hint_of(trip), f"prune_guard:{corpus}:{root}")], run_id=run_id)
    return [(sp, e) for sp, e in doomed if str(e.get(ROOT_FIELD)) not in blocked], blocked


def _prune_and_save(
    prev: dict[str, dict[str, Any]], manifest: dict[str, dict[str, Any]], stats: IngestStats,
    *, vault_path: Path, manifest_path: Path, corpus: str, own_roots: set[str],
    relocated_from: set[str], effective_prune: bool, allow_prune: bool, dry_run: bool, run_id: str,
) -> None:
    """Хвост прогона: drop-loop под гардом → снимок манифеста → удаление заметок → запись манифеста.

    Порядок важен (INGEST-SAFETY-1 п.3): снимок манифеста слоя - ДО удаления и до записи нового
    (при намерении удалять, в т.ч. при отказе гарда, и перед записью мигрированного). Корень,
    упершийся в гард, не чистится и сохраняет свои записи в манифесте (заметки не осиротеют)."""
    blocked_roots: set[str] = set()
    snapshot_wanted = bool(stats.migrated_roots)
    doomed: list[tuple[str, dict[str, Any]]] = []
    if effective_prune:
        intended = _doomed_entries(prev, manifest, own_roots)
        doomed, blocked_roots = _guarded(
            intended, prev, own_roots, corpus, stats,
            allow_prune=allow_prune, dry_run=dry_run, run_id=run_id,
        )
        stats.deleted += len(doomed)
        # снимок и когда гард отказал: «отказ и снимок, не удаление» (состояние ДО прогона)
        snapshot_wanted = snapshot_wanted or bool(intended)
    final_manifest = _final_manifest(
        prev, manifest, own_roots - blocked_roots, relocated_from, pruned=effective_prune
    )
    if dry_run:
        return
    if snapshot_wanted:
        snap = snapshot_manifest(manifest_path, corpus)
        stats.snapshot = str(snap) if snap else ""
    for _sp, entry in doomed:
        if entry.get("note_path"):
            (vault_path / entry["note_path"]).unlink(missing_ok=True)
    _save_manifest(manifest_path, final_manifest)


def ingest_corpus(
    vault_path: Path,
    roots: list[Path | RootSpec] | None = None,
    *,
    root_names: list[str] | None = None,
    scope: str = "incremental",
    dry_run: bool = False,
    link: bool = True,
    report_path: Path | None = None,
    content_hashes: dict[str, str] | None = None,
    corpus: str = "legacy",
    prune: bool = True,
    limit: int | None = None,
    path_scope: str | None = None,
    allow_prune: bool = False,
) -> IngestStats:
    """Render/update/drop ``_legacy`` notes for the discovered corpus.

    ``scope="full"`` re-extracts and re-renders every note (ignoring both the
    unchanged optimisation and relocation-recognition); ``"incremental"`` is
    content-addressed (INGEST-DEDUP): a fast-path skips sources whose
    ``path+mtime+size`` are unchanged **without hashing**, and any ambiguous file
    (new path / changed mtime|size) is identified by its **byte-hash** — a match
    against a vanished manifest entry is a *relocation* (note kept, entry
    re-pointed, no re-extraction/duplicate), a match against a still-present entry
    is a duplicate, and an unseen hash is genuinely new/changed.
    ``dry_run`` computes the full disposition but writes nothing (no notes, no
    cache, no manifest). ``link=True`` runs the stage-5 navigation post-pass
    (``_index.md`` MOCs, hub-candidates report, conservative curated back-links);
    ``--no-link`` turns it off. Per-note ``[[hub]]`` links are NOT written at
    render time anymore (Phase 9) — их проставляет проход ``core/linking``.
    ``content_hashes`` maps an *absolute* source path → its byte-hash so a caller
    that already hashed the files (INGEST-1 ``scan``, PART-3) is not re-hashed;
    a missing entry falls back to computing the hash. When ``report_path`` is
    given, a full per-bucket diagnostic report (the path lists behind every
    disposition — errors / needs_ocr / unsupported / privacy / exclude /
    duplicate) is written there, so a dry run can be eyeballed before a big ingest.

    ``corpus`` (CORPUS-INGEST-CURRENT) selects the layer: ``legacy`` (default,
    backward compatible — legacy manifest, ``corpus: legacy`` notes) or ``current``
    (the current-knowledge manifest, ``corpus: current`` notes). Dedup/relocation by
    byte-hash works against whichever manifest is chosen, so a migrated file already
    in the current manifest is recognised (relocated), never re-created. ``prune``
    (default True) enables the drop-loop; ``limit`` caps the new/changed notes a run
    renders (a canary batch). A ``limit`` — or ``prune=False`` — makes the run
    *partial*: it never drops and it merges into the manifest instead of rebuilding
    it, so out-of-scope notes are neither lost nor duplicated. ``path_scope``
    (CORPUS-INGEST-CURRENT PART-3.0) *filters* discovery to files whose root-relative
    ``source_path`` is under that folder — the discover base stays the root, so keys
    are identical to a full run (never bare filenames).

    **INGEST-SAFETY-1.** Корень прогона - единица владения: запись манифеста несет ``root`` (метка
    корня: имя из ingest-roots.yaml либо ``legacy:<путь>``), prune удаляет ТОЛЬКО записи корней
    этого прогона, чужие корни слоя (и записи без владельца, ``root: "?"``) не трогает. ``roots`` -
    пути или :class:`~core.legacy.discover.RootSpec`; ``root_names`` (параллельный ``roots``)
    задает метки для путей. Манифест без поля ``root`` мигрирует на лету (см.
    :mod:`core.legacy.manifest_roots`).

    **Гард массового удаления** (``allow_prune``): prune, собравшийся удалить больше
    ``DT_INGEST_PRUNE_MAX_PCT`` % записей корня И больше ``DT_INGEST_PRUNE_MIN_N`` штук, НЕ
    удаляет - пишет отказ ``prune_guard`` и ``stats.prune_guard``; ``allow_prune=True`` снимает
    гард на этот прогон. Перед любым удалением (и перед записью мигрированного манифеста) -
    снимок манифеста слоя рядом (:func:`~core.legacy.manifest_roots.snapshot_manifest`).
    """
    start = time.perf_counter()
    vault_path = Path(vault_path)
    # CORPUS-INGEST-CURRENT: the manifest is per-layer, so a current-knowledge run
    # owns/dedups/prunes only its own notes and never touches the legacy layer's.
    manifest_path = (
        current_ingest_manifest_path()
        if corpus == "current"
        else legacy_ingest_manifest_path()
    )
    prev = _load_manifest(manifest_path)
    stats = IngestStats(
        dry_run=dry_run, scope=scope, manifest_path=str(manifest_path)
    )

    specs = _run_specs(roots, root_names)
    own_roots = _own_roots(specs, corpus)
    # Метки корней слоя (конфиг + этот прогон): запись с меткой вне этого набора - «без живого
    # корня» (корень убран/переименован) - не чужая, а ничья: ее можно перенести, нельзя удалить.
    candidates = layer_candidates(corpus, vault_path, [(s_.label, s_.path) for s_ in specs])
    _foreign = _Foreign(own_roots, {label for label, _p in candidates})
    stats.migrated_roots, _unk = assign_roots(prev, candidates)

    discovery = discover(specs)
    # CORPUS-INGEST-CURRENT PART-3.0: ``path_scope`` is a canary *filter* over the
    # discovered files — never a different discover base. ``source_path`` stays
    # relative to the ROOT (as in a full run), so a scoped run yields the identical
    # root-relative key (not a bare filename that would not resolve/would dup).
    if path_scope:
        prefix = path_scope.strip("/").replace("\\", "/")
        discovery.files = [
            f for f in discovery.files if _under_scope(f.source_path, prefix)
        ]
    stats.skipped_exclude = len(discovery.excluded)
    stats.skipped_privacy = len(discovery.skipped_privacy)

    by_sp: dict[str, LegacyFile] = {f.source_path: f for f in discovery.files}

    # Byte-hash → the manifest key that owns a note for those bytes. Only entries
    # that carry a hash AND a note participate (pre-backfill entries stay path-
    # keyed). Deterministic: first key in sorted order wins a collision.
    prev_by_hash: dict[str, str] = {}
    for key in sorted(prev):
        prev_entry = prev[key]
        bh_prev = prev_entry.get(HASH_FIELD)
        if bh_prev and prev_entry.get("note_path"):
            prev_by_hash.setdefault(str(bh_prev), key)

    incremental = scope != "full"
    manifest: dict[str, dict[str, Any]] = {}  # rebuilt fresh from this run's decisions
    carried_notes: list[str] = []  # sps whose note is kept without re-extraction
    consumed_hashes: set[str] = set()  # byte-hashes already claimed a note this run
    to_extract: list[tuple[LegacyFile, str]] = []  # (file, byte-hash) genuinely new/changed

    # PULT-EVENTLOG: одно run-событие на прогон; per-artifact ingest-события
    # (сшивка файл→заметка: note_id+source_hash) копим и пишем одной пачкой.
    from core.eventlog import emit_batch, new_run_id

    run_id = new_run_id()
    ingest_events: list[dict[str, Any]] = []
    # REATTR-1: переносы этого прогона (note_id + старый/новый путь) — сырьё для
    # детектора переатрибуции ниже.
    relocations: list[dict[str, str]] = []

    guard = _ReadGuard(stats, prev, manifest, carried_notes, consumed_hashes)

    relocated_from: set[str] = set()  # ключи prev, чья заметка переехала под новый ключ

    for lf in discovery.files:
        sp = lf.source_path
        entry: dict[str, Any] | None = prev.get(sp)
        runlock.beat()  # WAVE0-HYGIENE п.3: heartbeat на файл — сторож видит прогресс

        # 0. INGEST-SAFETY-1: ключ занят записью другого корня слоя (одинаковый путь от корня в
        # двух корнях) - не перетираем чужую заметку и не гоняем ее туда-сюда: пропуск + счетчик.
        if _foreign(entry):
            stats.collisions += 1
            logger.warning(
                "[ingest] %s: ключ манифеста занят корнем %r (этот прогон: %s) — пропущен",
                sp, entry.get(ROOT_FIELD) if entry else "", lf.root,
            )
            continue

        # 1. Fast-path: same path, unchanged mtime+size, note on disk → skip, NO hash.
        if incremental and entry is not None and entry.get("mtime") == lf.mtime \
                and entry.get("size") == lf.size and not entry.get(OCR_REFRESH_FIELD):
            note_rel = str(entry.get("note_path") or "")
            if note_rel and (vault_path / note_rel).is_file():
                stats.unchanged += 1
                manifest[sp] = dict(entry)  # carry as-is (may lack a hash pre-backfill)
                carried_notes.append(sp)
                bh_prev = entry.get(HASH_FIELD)
                if bh_prev:
                    consumed_hashes.add(str(bh_prev))
                continue

        # 1b + 2. WAVE0-HYGIENE п.3: iCloud-заглушку (dataless) НЕ читаем, остальное
        # хэшируем под таймаутом; ``None`` — файл пропущен (прежняя запись остаётся).
        bh = guard.byte_hash(lf, content_hashes)
        if bh is None:
            continue

        refresh_wanted = bool(prev.get(sp, {}).get(OCR_REFRESH_FIELD)) and \
            prev_by_hash.get(bh) == sp
        if incremental and bh in prev_by_hash and bh not in consumed_hashes \
                and not refresh_wanted:
            k = prev_by_hash[bh]
            old = prev.get(k, {})
            note_rel = str(old.get("note_path") or "")
            note_ok = bool(note_rel) and (vault_path / note_rel).is_file()
            if note_ok:
                if k == sp:
                    # Same path, identical bytes, only mtime/size shifted (a touch)
                    # → not really changed: refresh the record, keep the note.
                    stats.unchanged += 1
                    manifest[sp] = _refreshed(old, lf, bh)
                    carried_notes.append(sp)
                    consumed_hashes.add(bh)
                    continue
                if k not in by_sp and not _foreign(old):
                    # The old path vanished and these bytes reappeared here →
                    # moved/renamed. Keep the note (note_path unchanged), re-point
                    # the entry to the new source_path. No extraction, no new note.
                    stats.relocated += 1
                    manifest[sp] = _refreshed(old, lf, bh)
                    relocated_from.add(k)
                    carried_notes.append(sp)
                    consumed_hashes.add(bh)
                    # SRC-PATH-1: заметка переезжает вместе с записью манифеста - иначе ее
                    # ``source_path``/``source_id`` остаются старыми и перестают резолвиться.
                    # Dry-run считает, что было бы переписано, и ничего не пишет.
                    note_updated = repoint_note(
                        vault_path, note_rel, sp, old_source_path=k, dry_run=dry_run
                    ) == "rewritten"
                    if note_updated:
                        stats.relocated_note_updates += 1
                    if not dry_run:
                        ingest_events.append({
                            "stage": "ingest", "status": "relocated",
                            "note_id": legacy_note_id(k), "source_hash": bh,
                            "path": str(old.get("note_path") or sp), "run_id": run_id,
                            "detail": {"route": "knowledge", "note_updated": note_updated},
                        })
                        # REATTR-1: перенос заметили — предложение (если он между
                        # сущностными каталогами) соберём ПОСЛЕ цикла, там уже есть
                        # каталог хабов; строить его на каждый файл незачем.
                        relocations.append({
                            "note_id": legacy_note_id(k), "old_path": k, "new_path": sp,
                        })
                    continue
                # k is still present and owns the note → this file is a duplicate.
                stats.duplicate += 1
                consumed_hashes.add(bh)
                continue

        # 3. Genuinely new byte-content (or full scope) → extract + render below.
        to_extract.append((lf, bh))

    # Extract only the genuinely-new/changed files (relocations/unchanged skipped).
    records = _extract_pending(to_extract, dry_run=dry_run, scope=scope, guard=guard)
    to_extract = [(lf, bh) for lf, bh in to_extract if lf.source_path in records]

    # Classify non-indexable dispositions of the extracted set (kept out of notes).
    indexable: list[str] = []
    needs_ocr_paths: list[str] = []
    needs_conversion_paths: list[str] = []
    error_paths: list[tuple[str, str]] = []
    unsupported_paths: list[tuple[str, str]] = []
    for lf, _bh in to_extract:
        sp = lf.source_path
        rec = records[sp]
        if _indexable(rec):
            indexable.append(sp)
        elif _is_stub(rec):
            # OCR-1 п.1: скан = заметка-заглушка, а не отказ (в журнал отказов не идет).
            stats.needs_ocr += 1
            needs_ocr_paths.append(sp)
            indexable.append(sp)
        elif rec.get("needs_conversion"):
            stats.needs_conversion += 1
            needs_conversion_paths.append(sp)
        elif rec.get("status") == "error":
            stats.errors += 1
            error_paths.append((sp, str(rec.get("error", ""))))
        else:
            stats.skipped_unsupported += 1
            unsupported_paths.append((sp, str(rec.get("skip_reason", ""))))

    # Exact-dedup (text content_hash, unchanged) over the extracted indexable set,
    # in discovery (source_path) order — collapses different-byte/same-text copies.
    # Заглушки (текста нет, ``content_hash`` у всех - хэш пустой строки) сравниваются по БАЙТАМ.
    hashes = {
        sp: (records[sp][HASH_FIELD] if _is_stub(records[sp]) else records[sp]["content_hash"])
        for sp in indexable
    }
    dup_map = find_duplicates(hashes)
    stats.duplicate += len(dup_map)
    render_sps = [sp for sp in indexable if sp not in dup_map]
    # Canary batch (CORPUS-INGEST-CURRENT): cap the genuinely-new/changed notes this
    # run renders. Deterministic (sorted) selection; unchanged/relocated (dedup by
    # byte-hash) are cheap and safe, so only the writes are bounded. A limited run
    # implies prune=False (the caller sets it) so untouched sources are never dropped.
    if limit is not None and limit >= 0:
        render_sps = sorted(render_sps)[:limit]
    stats.notes_total = len(carried_notes) + len(render_sps)

    # INGRESS-1 п.4: отказы прохода — в общий журнал; INGEST-SAFETY-1: ключ - по корню, а dry-run
    # журнал НЕ пишет («что отброшено» видно в stats и отчете ``report_path``). Приватность -
    # счетчик без строки; остальное — с путем относительно корня.
    if not dry_run:
        _log_refusals(
            corpus,
            excluded=[(e.root, e.source_path) for e in discovery.excluded],
            privacy=[(e.root, e.source_path, e.reason) for e in discovery.skipped_privacy],
            needs_ocr=[],  # OCR-1: скан - заметка-заглушка, не отказ
            needs_conversion=[(by_sp[p].root, p) for p in needs_conversion_paths],
            unsupported=[(by_sp[p].root, p) for p, _r in unsupported_paths],
            errors=[(by_sp[p].root, p) for p, _r in error_paths],
        )

    # Diagnostic report (path lists per disposition). Written regardless of
    # dry_run when requested; the CLI defaults it on for dry runs.
    if report_path is not None:
        _write_dryrun_report(
            Path(report_path),
            roots=[s_.path for s_ in specs] if roots is not None else None,
            stats=stats,
            excluded=[(e.source_path, e.reason) for e in discovery.excluded],
            privacy=[(e.source_path, e.reason) for e in discovery.skipped_privacy],
            errors=error_paths,
            needs_ocr=needs_ocr_paths,
            needs_conversion=needs_conversion_paths,
            unsupported=unsupported_paths,
            duplicates=sorted(dup_map.items()),
        )
        stats.report_path = str(report_path)

    # Hub catalog (built once) drives the navigation post-pass (MOCs / hub
    # candidates); only when linking and actually writing. Per-note [[hub]]
    # links are NOT rendered anymore (Phase 9, этап 3) — их проставляет
    # отдельный проход core/linking по сигналам client/section из frontmatter.
    do_link = link and not dry_run
    catalog = entity_catalog(vault_path) if do_link else []

    # (Re)render genuinely new/changed representatives; classify new vs changed.
    privacy_probe = 0  # OCR-1 п.2: заглушки с ``ocr: refused`` (только счетчик - причина без hint)
    ocr_low: list[str] = []  # OCR-1 п.4: распознано с низкой уверенностью - предупреждение в журнал
    for sp in render_sps:
        lf = by_sp[sp]
        rec = records[sp]
        rel = note_relpath(lf).as_posix()
        if prev.get(sp) is None:
            stats.new += 1
        else:
            stats.changed += 1
        if not dry_run:
            write_legacy_note(lf, rec, vault_path, corpus=corpus)
            stub = _is_stub(rec)
            manifest[sp], ocr_state = _manifest_entry(lf, rec, rel)
            stats.truncated += 1 if manifest[sp].get("truncated") else 0
            privacy_probe += ocr_state == "refused"
            if ocr_state == "low":
                ocr_low.append(sp)
            # PULT-EVENTLOG: файл стал заметкой — сшивка source_hash→note_id. Скан-заглушка -
            # событие ``scan_stub`` (OCR-1 п.1): документ в корпусе, но текста пока нет.
            ingest_events.append({
                "stage": "ingest", "status": "scan_stub" if stub else "done",
                "note_id": legacy_note_id(lf.source_path),
                "source_hash": rec[HASH_FIELD], "path": rel, "run_id": run_id,
                "detail": {
                    "route": "knowledge",
                    "disposition": "new" if prev.get(sp) is None else "changed",
                    **({"ocr": ocr_state} if ocr_state else {}),
                },
            })
        if len(stats.examples) < 5:
            stats.examples.append(rel)

    if not dry_run:
        _log_ocr_signals(_run_adapter(corpus, own_roots), privacy_probe, ocr_low)

    # INGEST-SAFETY-1: каждая запись этого прогона несет метку корня, чьим обходом найден файл.
    _stamp_roots(manifest, by_sp)

    # A partial run (canary --scope/--limit) sees only a subset of the corpus, so it
    # must NOT prune (untouched sources look "vanished") and must MERGE its decisions
    # into the existing manifest rather than overwrite it — otherwise out-of-scope
    # entries would be lost and later re-imported as duplicates. Full runs prune and
    # rebuild fresh, as before. A ``limit`` always implies a partial run.
    effective_prune = prune and limit is None

    _prune_and_save(
        prev, manifest, stats, vault_path=vault_path, manifest_path=manifest_path, corpus=corpus,
        own_roots=own_roots, relocated_from=relocated_from, effective_prune=effective_prune,
        allow_prune=allow_prune, dry_run=dry_run, run_id=run_id,
    )

    # Graph linking post-pass: MOCs + conservative curated back-links. Runs after
    # all notes exist (and after drops), so MOCs reflect the final folder state.
    if do_link:
        stats.mocs = len(generate_mocs(vault_path, catalog))
        candidates = write_hub_candidates(vault_path, catalog)
        stats.hub_candidates = _count_candidates(candidates)
        backlinks = backlink_curated(vault_path)
        stats.backlinks = len(backlinks.touched)
        stats.backlinked = backlinks.touched

    # REATTR-1: переносы между сущностными каталогами → очередь переатрибуции.
    if relocations and not dry_run:
        stats.reattr_proposed = _propose_reattr(relocations, vault_path, catalog)

    # PULT-EVENTLOG: одна пачка на прогон (не N транзакций). Best-effort внутри.
    emit_batch(ingest_events)

    if stats.pending_download or stats.interrupted:
        logger.warning(
            "[ingest] не прочитано: pending_download=%d interrupted=%d (заметки прежних "
            "версий остались, следующий проход повторит)",
            stats.pending_download, stats.interrupted,
        )
    stats.elapsed_s = time.perf_counter() - start
    return stats


# --------------------------------------------------------------------------- #
# OCR-1 п.4: распознанный скан просит перерисовать заметку                       #
# --------------------------------------------------------------------------- #


def pending_ocr_refresh(corpus: str = "current") -> int:
    """Сколько записей манифеста слоя ``corpus`` ждут перерисовки после OCR (``ocr_refresh``).

    Приемка OCR-1 29.10: скан после OCR НЕ меняется как файл (mtime/size те же), поэтому
    ``file_ingest.scan`` не видел «изменений» и не звал ``ingest_corpus`` - заглушки оставались
    заглушками. Скан спрашивает здесь и зовет знаниевый маршрут даже при нуле измененных файлов.
    Битый манифест → 0 (это подсказка планировщику, не операция)."""
    path = current_ingest_manifest_path() if corpus == "current" else legacy_ingest_manifest_path()
    try:
        manifest = _load_manifest(path)
    except Exception:  # noqa: BLE001 - нечитаемый манифест починит ingest, не планировщик
        return 0
    return sum(1 for e in manifest.values() if isinstance(e, dict) and e.get(OCR_REFRESH_FIELD))


def mark_ocr_refresh(source_paths: Iterable[str]) -> int:
    """Пометить записи манифестов (legacy и current) ``ocr_refresh`` - сколько помечено.

    Следующий ``ingest_corpus`` пере-извлечет такие записи (L1-кэш к тому времени уже пересобран
    с текстом OCR) и перерисует заметку; маркер уходит вместе со старой записью. Записи нет
    (заглушка еще не рисовалась) - ничего не делаем: заметка сразу родится с текстом. Битый
    манифест не трогаем (``StoreUnavailableError`` поднимется - ADAPTER-HONEST-1)."""
    wanted = set(source_paths)
    if not wanted:
        return 0
    marked = 0
    for path in (legacy_ingest_manifest_path(), current_ingest_manifest_path()):
        manifest = _load_manifest(path)
        changed = False
        for sp in wanted:
            entry = manifest.get(sp)
            if entry is not None and entry.get("note_path") and not entry.get(OCR_REFRESH_FIELD):
                entry[OCR_REFRESH_FIELD] = True
                changed = True
                marked += 1
        if changed:
            _save_manifest(path, manifest)
    return marked


# --------------------------------------------------------------------------- #
# Backfill + coverage (INGEST-DEDUP PART-4/5)                                  #
# --------------------------------------------------------------------------- #


def manifest_hash_coverage(
    manifest_path: Path | None = None,
) -> tuple[int, int, int]:
    """``(with_hash, total, missing)`` — покрытие byte-hash'ем по ЖИВЫМ исходникам.

    Powers the ``dt doctor`` line that shows whether a ``--backfill-hashes`` is
    still needed (a low ratio ⇒ moving the corpus would look like re-imports).

    **DOCTOR-HONEST-1.** ``total`` считает только записи, чей исходник ещё на диске:
    запись с маркером :data:`MISSING_FIELD` (файл физически исчез — backfill отметил
    его как ``skipped(missing)``) в знаменатель не идёт и уходит третьим числом.
    Иначе гард горел бы жёлтым ВЕЧНО, не предлагая выполнимого действия — а доктор,
    который жёлтый всегда, перестают читать. Записи при этом НЕ удаляются: история
    переносов нужна дедупу.
    """
    prev = _load_manifest(manifest_path or legacy_ingest_manifest_path())
    total = 0
    with_hash = 0
    missing = 0
    for entry in prev.values():
        if not entry.get("note_path"):
            continue
        if entry.get(MISSING_FIELD):
            missing += 1
            continue
        total += 1
        if entry.get(HASH_FIELD):
            with_hash += 1
    return with_hash, total, missing


def backfill_hashes(
    roots: list[Path] | None = None,
    *,
    dry_run: bool = False,
    log: Callable[[str], None] | None = None,
) -> dict[str, int | bool]:
    """Stamp ``source_content_hash`` onto existing manifest entries (one-off).

    Walks the note-bearing manifest entries; for each whose ``source_path`` is a
    still-live discovered file **without** a byte-hash, reads its bytes (never
    extracts) and records the hash. An entry that already has a hash is left
    untouched (idempotent). Progress is emitted per entry (принцип 11). After a
    backfill, moving/renaming the corpus is recognised by content. Returns
    per-bucket counts.

    **DOCTOR-HONEST-1.** Исчезнувший с диска исходник помечается в записи
    (:data:`MISSING_FIELD` + дата) и больше не считается недо-backfill'ом:
    ``manifest_hash_coverage`` исключает такие записи из знаменателя, и doctor
    перестаёт вечно светить жёлтым там, где выполнимого действия нет. Запись
    **остаётся** (path-keyed, как раньше) — история переносов нужна дедупу; маркер
    снимается сам, если файл вернётся (ветка ``filled``).
    """
    log = log or (lambda _m: None)
    manifest_path = legacy_ingest_manifest_path()
    manifest = _load_manifest(manifest_path)
    by_sp: dict[str, LegacyFile] = {f.source_path: f for f in discover(roots).files}

    keys = [sp for sp, e in manifest.items() if e.get("note_path")]
    total = len(keys)
    filled = already = skipped_missing = 0
    marked_missing = 0
    stamp = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    for i, sp in enumerate(sorted(keys), start=1):
        entry = manifest[sp]
        if entry.get(HASH_FIELD):
            already += 1
            status = "already"
            if entry.pop(MISSING_FIELD, None) is not None:
                entry.pop(MISSING_AT_FIELD, None)  # файл вернулся — маркер снят
                marked_missing += 1
        else:
            lf = by_sp.get(sp)
            if lf is None:
                skipped_missing += 1
                status = "missing"
                if not entry.get(MISSING_FIELD):
                    # Пометить, а не удалить: доктор перестанет требовать невозможного,
                    # а запись остаётся историей переноса для дедупа.
                    entry[MISSING_FIELD] = True
                    entry[MISSING_AT_FIELD] = stamp
                    marked_missing += 1
            else:
                entry[HASH_FIELD] = file_content_hash(lf.path)
                filled += 1
                status = "filled"
                if entry.pop(MISSING_FIELD, None) is not None:
                    entry.pop(MISSING_AT_FIELD, None)  # файл вернулся
                    marked_missing += 1
        log(f"[backfill] {i}/{total} | {status} | {sp}")

    if not dry_run and (filled or marked_missing):
        _save_manifest(manifest_path, manifest)
    return {
        "total": total,
        "filled": filled,
        "already": already,
        "skipped_missing": skipped_missing,
        "marked_missing": marked_missing,
        "dry_run": dry_run,
    }
