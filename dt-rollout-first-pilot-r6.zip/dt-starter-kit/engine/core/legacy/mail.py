"""Outlook correspondence → per-thread layer-B notes (ТЗ phase5; принцип 11).

Archival, read-only intake of Classic Outlook mail into the vault as ONE note
per conversation (``conversationId``) — not one per message — so quoted history
isn't duplicated and a discussion isn't fragmented across notes. A thread note
lives at ``_legacy/correspondence/<subject-slug>-<hash>.md`` and accumulates
messages from BOTH Inbox and Sent, across folders and incremental runs; its body
lists each message chronologically with only its NEW text (the quoted reply/
forward tail is stripped).

Incrementality is governed by a dedicated thread manifest
(``outlook_ingest_manifest.json``), keyed by conversationId, recording each
included message (id → date/from/is-me/stripped-text/bucket/hash). Resume skips
messages already recorded; a new message appends and re-renders the whole thread
from the manifest (no re-fetch of old messages); the per-folder ``since`` cursor
is the newest manifested message date for that bucket MINUS ``DT_MAIL_CURSOR_OVERLAP_DAYS``
(MAIL-GAP-1: mail reaching the local Outlook later than newer mail is backdated; MAIL-OVERLAP-1:
2 days, stretched after downtime to the last successful read, ``DT_MAIL_CURSOR_DEEP_DAYS`` in the
daily full pass).
Per-message filters: third-party privacy (:mod:`core.legacy.discover`) and noise — decided by the
DATA rules of ``_system/mail-filter.yaml`` (:mod:`core.legacy.mail_filter`, MAIL-FILTER-1:
Inbox full set, Sent only auto-reply prefixes); a thread that is entirely noise is skipped, a
mixed thread keeps only its non-noise messages. Deterministic, no LLM; run ``dt_index``
afterwards to embed.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Protocol

from core import runlock
from core.adapters import StoreUnavailableError, load_json_store
from core.config import (
    folder_label,
    legacy_privacy_salary_terms,
    mail_a2_context_extra,
    mail_batch_size,
    mail_cursor_deep_days,
    mail_cursor_overlap_days,
    mail_full_every_h,
    mail_owner_domains,
    outlook_folders,
    outlook_ingest_manifest_path,
    outlook_legacy_account,
    outlook_pull_window,
    outlook_self_tokens,
)
from core.contract import CODE_FOLDER_EMPTY_SUSPICIOUS
from core.ingress.provenance import stamp_fields
from core.ingress.refusals import refuse, subject_domain_hint
from core.legacy.discover import first_term_hit, nfc, privacy_reason
from core.legacy.mail_filter import (
    Decision,
    RefusedMemory,
    Rules,
    decide,
    decide_meta,
    load_rules,
)
from core.legacy.mail_integrity import detect_splices
from core.legacy.render import legacy_note_id, slugify
from core.operational.mail_folder_ids import FolderIdStore, full_pass_due
from core.operational.outlook_bridge import FolderUnresolvedError
from core.operational.outlook_bridge import _filter_since as filter_since
from core.progress import ProgressBeacon
from core.vault import Note, write_note

logger = logging.getLogger(__name__)

__all__ = ["MailIngestStats", "MailBridge", "ingest_mail", "CORRESPONDENCE_SECTION"]

# Vault section (folder) all correspondence lands under: _legacy/correspondence/.
CORRESPONDENCE_SECTION = "correspondence"

# Sort fallback for messages whose date failed to parse (they sink to the end).
_EPOCH = datetime(1970, 1, 1, tzinfo=UTC)


class MailBridge(Protocol):
    """The read-only surface :func:`ingest_mail` needs from an Outlook bridge.

    Satisfied by :class:`core.operational.outlook_bridge.OutlookBridge`; tests
    pass a fake exposing ``list_folder_meta`` (cheap metadata for the whole
    folder) and ``fetch_by_ids`` (heavy full objects for an EXACT id batch — a
    direct hash lookup, replacing the old date-range fetch that dragged in months
    of bodies on sparse resumes).
    """

    def list_folder_meta(
        self, folder: str, since: str | None = ..., **kw: Any
    ) -> list[dict[str, Any]]: ...

    def fetch_by_ids(
        self, folder: str, ids: list[str], **kw: Any
    ) -> list[dict[str, Any]]: ...

    # MAIL-ACCOUNTS-1: ``kw`` несет ``account=<адрес>`` ТОЛЬКО у спецификации с аккаунтом -
    # мост-подделка без поддержки аккаунтов продолжает работать для записей без него.


@dataclass
class MailIngestStats:
    """Disposition of one mail-ingest run."""

    new: int = 0  # threads newly created this run
    changed: int = 0  # existing threads that gained message(s) → re-rendered
    unchanged: int = 0
    resumed: int = 0  # message already in the manifest thread → skipped (resume)
    msgs_added: int = 0  # messages appended to threads this run
    skipped_privacy: int = 0
    skipped_noise: int = 0  # Inbox-only sender/subject noise → skipped before bodies
    skipped_empty: int = 0
    duplicate: int = 0  # message collapsed by content hash within its thread
    notes_total: int = 0  # thread notes written/updated
    elapsed_s: float = 0.0
    dry_run: bool = False
    scope: str = "incremental"
    manifest_path: str = ""
    folders: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)
    noise_examples: list[str] = field(default_factory=list)
    # MAIL-THREAD-1: сообщения, которые инжест отказался положить во ВТОРОЙ тред
    # (инвариант «msg_id в ровно одном треде»); примеры — без тем/адресов.
    rejected_multi_thread: int = 0
    reject_examples: list[str] = field(default_factory=list)
    # Конверты ``bridge_misaligned`` моста за прогон (страницы, перечитанные мельче).
    bridge_misaligned: int = 0
    # Треды с подозрением на склейку (смена темы + смена круга доменов).
    splice_suspects: int = 0
    # ADAPTER-HONEST-1: треды, чей сайдкар нечитаем — пропущены (не затёрты), сообщения
    # остаются на повтор после починки файла.
    thread_store_errors: int = 0
    # MAIL-FILTER-1: шум по правилам yaml (имя правила → сообщений), сообщения, пропущенные по
    # памяти «отказано» (снятые прежде), и диагностика приватности (только при --explain-privacy).
    noise_by_rule: dict[str, int] = field(default_factory=dict)
    refused_resumed: int = 0
    privacy_before: dict[str, int] = field(default_factory=dict)  # «правило/папка» → сообщений
    privacy_after: dict[str, int] = field(default_factory=dict)
    filter_source: str = ""  # file | defaults (откуда правила фильтра)
    # MAIL-GAP-1: «отказ ≠ пропуск». ``skipped_since`` - сообщения, отрезанные границей ``since``
    # (курсор с перекрытием / окно выгрузки / явный --since); ``resumed`` - уже в манифесте.
    # Единицы - СООБЩЕНИЯ. ``since_effective`` - граница по папкам (``all`` = вся папка).
    skipped_since: int = 0
    skipped_since_by_folder: dict[str, int] = field(default_factory=dict)
    since_effective: dict[str, str] = field(default_factory=dict)
    since_notes: dict[str, str] = field(default_factory=dict)  # папка → строка для лога/CLI
    # Кандидаты на добавление по папкам и их даты (дни) - для смоука С-13 «дыра курсора».
    # SMOKE-DRIFT-1: из них - НОВЕЕ новейшего письма папки в манифесте (``added_by_folder`` включает
    # их): очередь обычной синхронизации, а не дыра курсора - в ``added_dates`` их дни не входят.
    added_by_folder: dict[str, int] = field(default_factory=dict)
    added_dates: dict[str, list[str]] = field(default_factory=dict)
    added_after_cursor_by_folder: dict[str, int] = field(default_factory=dict)
    # MAIL-ACCOUNTS-1: деградации по спецификациям (код ``folder_unresolved`` /
    # ``folder_empty_suspicious``) - не «0 новых»; остальные ящики читаются дальше, а шаг
    # синхронизации и CLI не ``ok`` (код выхода 5).
    folder_problems: list[dict[str, str]] = field(default_factory=list)
    # Снимок по спецификациям для доктора: метка → {account, bucket, name, total, newest,
    # resolved, history}. ``total`` - писем в папке по данным моста (без среза ``since``).
    folder_snapshot: dict[str, dict[str, Any]] = field(default_factory=dict)
    # MAIL-BRIDGE-INC-1: как прочитана спецификация - ``head`` (окно с головы папки) | ``full``
    # (весь листинг); причина, по которой окно отвергнуто мостом (``""`` - окно использовано);
    # итог суточной сверки окна с полным листингом {ok, window, full, missing, extra, why}.
    bridge_calls: int = 0  # вызовов моста (osascript) за прогон, листинги и fetch вместе
    window_mode: dict[str, str] = field(default_factory=dict)
    window_fallback: dict[str, str] = field(default_factory=dict)
    full_pass: dict[str, dict[str, Any]] = field(default_factory=dict)
    # MAIL-OVERLAP-1: прогон остановлен сигналом посреди фазы 2 (часть выживших не обработана) -
    # время успешного чтения спецификаций такой прогон не сдвигает.
    stopped: bool = False


# --------------------------------------------------------------------------- #
# Manifest                                                                    #
# --------------------------------------------------------------------------- #


def _load_manifest(path: Path) -> dict[str, dict[str, Any]]:
    """Индекс манифеста почты. Нет файла → ``{}`` (первый запуск); файл есть, но битый →
    :class:`~core.adapters.StoreUnavailableError` (ADAPTER-HONEST-1): прежнее «битый ⇒ пусто»
    заставляло инжест считать, что истории нет, переимпортировать всё и затереть индекс."""
    data = load_json_store(path, adapter="mail_manifest", expect=dict)
    if data is None:
        return {}
    return {str(k): v for k, v in data.items() if isinstance(v, dict)}


def _save_manifest(path: Path, manifest: dict[str, dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    tmp.replace(path)


# --------------------------------------------------------------------------- #
# Thread state store: a LIGHTWEIGHT index (manifest_path) + one sidecar file   #
# per thread holding the bodies. This keeps per-batch writes proportional to   #
# the batch, not the whole corpus — the single-file manifest with every body   #
# grew to 127 MB and got fully rewritten each batch (O(n²) → it stalled).      #
# --------------------------------------------------------------------------- #


def _state_dir(manifest_path: Path) -> Path:
    """Directory holding per-thread sidecar files (beside the index manifest)."""
    return manifest_path.parent / "mail_threads"


def _thread_file(state_dir: Path, thread_key: str) -> Path:
    """Sidecar path for a thread — hashed so ``conv:…`` keys are filesystem-safe."""
    return state_dir / (hashlib.sha1(thread_key.encode("utf-8")).hexdigest() + ".json")  # noqa: S324 — content hash (identity/dedup), not security


def _load_thread_rec(state_dir: Path, thread_key: str) -> dict[str, Any]:
    """Load a thread's full record (with ``messages``) from its sidecar, or a
    fresh empty record when none exists yet.

    Сайдкар ЕСТЬ, но нечитаем → :class:`~core.adapters.StoreUnavailableError`: свежая
    пустая запись поверх битой молча потеряла бы все накопленные сообщения треда при
    следующей записи (ADAPTER-HONEST-1)."""
    p = _thread_file(state_dir, thread_key)
    data = load_json_store(p, adapter="mail_thread", expect=dict)
    if data is None:
        return {"messages": {}}
    if not isinstance(data.get("messages"), dict):
        raise StoreUnavailableError(
            f"{p.name}: в сайдкаре треда нет словаря messages", adapter="mail_thread", path=str(p)
        )
    return data


def _save_thread_rec(state_dir: Path, thread_key: str, rec: dict[str, Any]) -> None:
    """Write one thread's sidecar atomically (only the touched thread each batch)."""
    state_dir.mkdir(parents=True, exist_ok=True)
    p = _thread_file(state_dir, thread_key)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(rec, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


def _index_entry(rec: dict[str, Any]) -> dict[str, Any]:
    """Lightweight index row for a thread — everything resume + the incremental
    cursor need, WITHOUT the bodies (which live in the sidecar)."""
    msgs = rec.get("messages") or {}
    bucket_dates: dict[str, str] = {}
    for mm in msgs.values():
        b = str(mm.get("bucket") or "")
        d = str(mm.get("date") or "")
        # MAIL-ACCOUNTS-1: курсор - по ПАРЕ аккаунт+папка. Сообщение с аккаунтом пишет в
        # ``inbox[a@b.c]``, без аккаунта - в ``inbox`` (старый ключ, манифесты читаются как есть).
        key = folder_label({"bucket": b, "account": mm.get("account")})
        if b and d and d > bucket_dates.get(key, ""):  # ISO strings sort chronologically
            bucket_dates[key] = d
    return {
        "conversationId": rec.get("conversationId", ""),
        "subject": rec.get("subject", ""),
        "note_path": rec.get("note_path", ""),
        "content_hash": rec.get("content_hash", ""),
        "count": len(msgs),
        "first_date": rec.get("first_date", ""),
        "last_date": rec.get("last_date", ""),
        "buckets": rec.get("buckets", []),
        "bucket_dates": bucket_dates,
        "msg_ids": sorted(msgs.keys()),
        **({"has_attachments": True} if any(m.get("attachments") for m in msgs.values()) else {}),
        # MAIL-THREAD-1: сколько подозрений на склейку нашёл рендер (doctor читает
        # индекс, а не тела сайдкаров).
        "splice_suspects": len(rec.get("splice_suspects") or []),
        # MAIL-ACCOUNTS-1: ящик треда и якорь заметки (``anchor_key`` - исходный ключ треда у
        # мигрированных: id/путь заметки от него не меняются).
        "account": rec.get("account", ""),
        "anchor_key": rec.get("anchor_key", ""),
    }


def _migrate_manifest_if_needed(manifest_path: Path, state_dir: Path) -> bool:
    """One-time: split a legacy single-file manifest (thread records WITH bodies)
    into per-thread sidecars + a lightweight index at ``manifest_path``. Returns
    True if a migration ran. No-op when already in index format or absent."""
    data = _load_manifest(manifest_path)
    if not data:
        return False
    sample = next(iter(data.values()), {})
    if not isinstance(sample, dict) or "msg_ids" in sample:
        return False  # already the lightweight index format
    index: dict[str, dict[str, Any]] = {}
    for tkey, rec in data.items():
        if not isinstance(rec, dict) or "messages" not in rec:
            continue
        _save_thread_rec(state_dir, tkey, rec)
        index[tkey] = _index_entry(rec)
    _save_manifest(manifest_path, index)  # replaces the giant file with the index
    return True


# --------------------------------------------------------------------------- #
# Message → LegacyFile / cursor helpers                                       #
# --------------------------------------------------------------------------- #


def _parse_dt(value: Any) -> datetime | None:
    """Parse an ISO 8601 date(-time) string into an aware datetime, else ``None``."""
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=UTC)


def _window_since() -> str:
    """Default look-back cursor: ``today − outlook_pull_window`` as ``YYYY-MM-DD``."""
    cutoff = datetime.now(UTC) - timedelta(days=outlook_pull_window())
    return cutoff.date().isoformat()


@dataclass(frozen=True)
class SinceCursor:
    """Граница ``since`` одной папки и откуда она взялась (для лога и ``last_runs.json``)."""

    since: str | None  # YYYY-MM-DD; ``None`` - вся папка
    mode: str  # all | explicit | full | cursor | resume | window
    cursor: str | None = None  # дата новейшего проиндексированного письма (режимы cursor, resume)
    overlap_days: int = 0
    # MAIL-OVERLAP-1: дата последнего успешного чтения спецификации (режим resume: граница
    # растянута на простой - ``min(курсор, чтение) − перекрытие``) и признак простоя: с этой даты
    # прошло больше перекрытия (Outlook мог не докачать письма - время чтения не сдвигается, см.
    # ``_mark_read_ok``).
    last_ok: str | None = None
    downtime: bool = False
    # MAIL-OVERLAP-1: граница ДАННЫХ в суточном полном проходе - ``min(курсор − DEEP, since)``
    # (``DT_MAIL_CURSOR_DEEP_DAYS``), не раньше окна выгрузки; у режимов без курсора ``None``.
    deep_since: str | None = None
    deep_days: int = 0

    def note(self, *, pull_window: int | None = None, daily: bool = False) -> str:
        """«since 2026-10-28 (курсор 2026-10-30 − 2 дн)» - человекочитаемо, без тем/адресов.

        ``daily`` - данные берутся из суточного полного прохода: если его граница шире узкой,
        «since 2026-10-16 (суточный проход: курсор 2026-10-30 − 14 дн)»."""
        if daily and self.deep_since and self.deep_since != self.since:
            return (f"since {self.deep_since} (суточный проход: курсор {self.cursor} − "
                    f"{self.deep_days} дн)")
        if self.mode == "all":
            return "вся папка (--all)"
        if self.mode == "explicit":
            return f"since {self.since} (явный --since)"
        if self.mode == "full":
            return f"since {self.since} (scope=full: окно выгрузки {pull_window} дн)"
        if self.mode == "cursor":
            return f"since {self.since} (курсор {self.cursor} − {self.overlap_days} дн)"
        if self.mode == "resume":
            return (f"since {self.since} (возобновление с {self.last_ok}: последнее успешное "
                    f"чтение − {self.overlap_days} дн, курсор {self.cursor})")
        return f"since {self.since} (истории нет: окно выгрузки {pull_window} дн)"


def _newest_bucket_date(
    index: dict[str, dict[str, Any]], bucket: str, account: str = ""
) -> str:
    """Дата-время новейшего письма пары аккаунт+папка в манифесте (ISO, как записано); пусто -
    истории нет.

    MAIL-ACCOUNTS-1: ключ курсора - ``folder_label`` (``inbox`` / ``inbox[a@b.c]``). Спецификация
    с аккаунтом, равным ``DT_OUTLOOK_LEGACY_ACCOUNT``, учитывает и СТАРЫЙ ключ ``bucket``
    (манифест до миграции): курсор ящика не теряется, история не читается заново.
    """
    keys = [folder_label({"bucket": bucket, "account": account})]
    if account and account == outlook_legacy_account():
        keys.append(bucket)
    best = ""
    for entry in index.values():
        dates = entry.get("bucket_dates") or {}
        for key in keys:
            d = str(dates.get(key, ""))
            if d > best:
                best = d
    return best


def _cursor_for(
    index: dict[str, dict[str, Any]], bucket: str, scope: str,
    *, since: str | None = None, all_history: bool = False, account: str = "",
    last_ok: str = "", now: datetime | None = None,
) -> SinceCursor:
    """Граница папки: ``--all`` > явный ``--since`` > ``scope=full`` (окно) > курсор с
    перекрытием > окно выгрузки (нет истории).

    Курсор = дата новейшего письма пары аккаунт+папка в манифесте МИНУС
    ``DT_MAIL_CURSOR_OVERLAP_DAYS`` (MAIL-GAP-1, дефолт 2), но не раньше окна выгрузки.
    MAIL-OVERLAP-1, возобновление: если известно время последнего успешного чтения спецификации
    (``last_ok``, ISO), граница = ``min(курсор, чтение) − перекрытие`` (режим ``resume``, когда ее
    задает чтение, а не курсор). ``downtime`` - с чтения прошло больше перекрытия (``now`` -
    подмена текущего момента). Нет записи - прежнее поведение по курсору."""
    if all_history:
        return SinceCursor(None, "all")
    if since:
        return SinceCursor(since, "explicit")
    window = _window_since()
    if scope == "full":
        return SinceCursor(window, "full")
    best = _newest_bucket_date(index, bucket, account)
    dt = _parse_dt(best) if best else None
    if dt is None:
        return SinceCursor(window, "window")
    newest = dt.date()
    overlap = mail_cursor_overlap_days()
    deep = mail_cursor_deep_days()
    # суточный проход: курсор − DEEP, но не позже узкой границы и не раньше окна выгрузки
    deep_cut = max((newest - timedelta(days=deep)).isoformat(), window)
    ok_dt = _parse_dt(last_ok) if last_ok else None
    if ok_dt is None:
        since_eff = max((newest - timedelta(days=overlap)).isoformat(), window)
        return SinceCursor(
            since_eff, "cursor", cursor=newest.isoformat(), overlap_days=overlap,
            deep_since=min(deep_cut, since_eff), deep_days=deep,
        )
    ok_date = ok_dt.date()
    now_date = (now or datetime.now(UTC)).astimezone(UTC).date()
    base = min(newest, ok_date)
    since_eff = max((base - timedelta(days=overlap)).isoformat(), window)
    return SinceCursor(
        since_eff, "resume" if ok_date < newest else "cursor", cursor=newest.isoformat(),
        overlap_days=overlap, last_ok=ok_date.isoformat(),
        downtime=(now_date - ok_date).days > overlap,
        deep_since=min(deep_cut, since_eff), deep_days=deep,
    )


def _incremental_since(
    index: dict[str, dict[str, Any]], bucket: str, scope: str
) -> str:
    """Per-folder ``since`` cursor: newest indexed message date for ``bucket`` (из ``bucket_dates``
    манифеста, тела не нужны) МИНУС перекрытие ``DT_MAIL_CURSOR_OVERLAP_DAYS`` (MAIL-GAP-1: письма,
    пришедшие в локальный Outlook позже более свежих, иначе отрезались бы навсегда), но не раньше
    окна выгрузки. Нет истории (или всегда при ``scope="full"``) - окно выгрузки."""
    cur = _cursor_for(index, bucket, scope)
    assert cur.since is not None  # noqa: S101 - без all_history граница всегда задана
    return cur.since


# --------------------------------------------------------------------------- #
# Thread helpers                                                              #
# --------------------------------------------------------------------------- #

# We DELIBERATELY keep each message's FULL body (per-thread grouping already
# removes fragmentation; aggressive quote-stripping produced near-empty cards).
# The only reduction is collapsing EXACT duplicate blocks WITHIN a thread at
# render time — no unique text is ever lost (a dropped block is byte-identical
# to one already shown earlier in the same card).
_BLOCK_SPLIT_RE = re.compile(r"\n\s*\n")
_MIN_COLLAPSE_LEN = 40  # only collapse substantial blocks; keep short lines


def _block_key(block: str) -> str:
    """Normalise a block for exact-duplicate detection: strip ``>`` quote markers
    and collapse whitespace, so a quoted copy matches its original."""
    lines = [re.sub(r"^\s*>+\s?", "", ln).rstrip() for ln in block.splitlines()]
    return re.sub(r"\s+", " ", " ".join(lines)).strip()


def _collapse_seen(text: str, seen: set[str]) -> str:
    """Drop blocks whose normalised form was already emitted earlier in the thread
    (exact quoted history); keep everything else verbatim. ``seen`` accumulates
    across the thread's messages in chronological order."""
    kept: list[str] = []
    for block in _BLOCK_SPLIT_RE.split(text):
        key = _block_key(block)
        if len(key) >= _MIN_COLLAPSE_LEN:
            if key in seen:
                continue
            seen.add(key)
        kept.append(block)
    return "\n\n".join(b for b in kept if b.strip()).strip()


def _split_addrs(value: str) -> list[str]:
    """Split a joined recipient string (``"Name <a>, Name2 <b>"``) into parts."""
    return [p.strip() for p in str(value or "").split(",") if p.strip()]


def _addr_domain(value: str) -> str:
    """Lower-cased e-mail domain from a ``"Name <x@dom>"`` / ``"x@dom"`` string."""
    m = re.search(r"@([A-Za-z0-9.-]+)", value or "")
    return m.group(1).lower().rstrip(".") if m else ""


def _is_owner_addr(value: str, owner_domains: list[str], self_tokens: list[str]) -> bool:
    """True when a participant is us: an owner e-mail domain or a self-token."""
    dom = _addr_domain(value)
    if dom and any(dom == od or dom.endswith("." + od) for od in owner_domains):
        return True
    hay = nfc(str(value or "")).lower()
    return any(nfc(t).lower() in hay for t in self_tokens if t.strip())


def _sender_is_me(from_str: str, self_tokens: list[str]) -> bool:
    """True when the sender matches an owner self-token (case-insensitive, NFC)."""
    hay = nfc(str(from_str or "")).lower()
    return any(nfc(t).lower() in hay for t in self_tokens if t.strip())


def _thread_key(conversation_id: Any, entry_id: str, account: str = "") -> str:
    """Manifest/thread key: the conversationId when present, else a per-message
    singleton (``msg:<entryID>``) so lone messages still get a note.

    MAIL-ACCOUNTS-1: у записи с аккаунтом ключ ``conv:<account>:<id>`` (один и тот же id разговора
    в двух ящиках - два разных треда, ключи не пересекаются); без аккаунта - прежний
    ``conv:<id>``. Одиночки ``msg:<entryID>`` без аккаунта: entryID уникален в рамках стора.
    """
    conv = str(conversation_id or "").strip()
    if not conv:
        return f"msg:{entry_id}"
    acc = str(account or "").strip().lower()
    return f"conv:{acc}:{conv}" if acc else f"conv:{conv}"


def split_thread_key(key: str) -> tuple[str, str]:
    """``conv:<account>:<id>`` → ``(account, id)``; ``conv:<id>`` → ``("", id)``; иное - пусто.

    Аккаунт узнается по ``@`` до первого ``:`` (id разговора Outlook - число, ``@`` в нем нет).
    """
    if not key.startswith("conv:"):
        return "", ""
    rest = key[5:]
    head, sep, tail = rest.partition(":")
    if sep and "@" in head:
        return head, tail
    return "", rest


def resolve_thread_key(
    index: dict[str, dict[str, Any]], conversation_id: Any, entry_id: str, account: str = ""
) -> str:
    """Ключ треда сообщения с учетом СТАРЫХ ключей манифеста (MAIL-ACCOUNTS-1).

    Запись с аккаунтом, равным ``DT_OUTLOOK_LEGACY_ACCOUNT``, продолжает уже существующий тред
    ``conv:<id>`` (манифест до миграции) - иначе тот же разговор лег бы вторым тредом и
    сработал отказ ``multi_thread``. Во всех остальных случаях - :func:`_thread_key`.
    """
    key = _thread_key(conversation_id, entry_id, account)
    acc = str(account or "").strip().lower()
    if acc and acc == outlook_legacy_account() and key not in index:
        old = _thread_key(conversation_id, entry_id, "")
        if old in index:
            return old
    return key




def _thread_source_path(thread_key: str) -> str:
    """Stable provenance/id anchor for a thread note (drives ``legacy-<hash>``).

    Передавать ЯКОРЬ: ``rec["anchor_key"]`` у мигрированного треда (его id/путь заметки не
    меняются от смены ключа), иначе сам ключ треда.
    """
    return f"{CORRESPONDENCE_SECTION}/{thread_key}"


def _sorted_messages(rec: dict[str, Any]) -> list[dict[str, Any]]:
    """Thread messages in chronological order (undated sink to the end)."""
    msgs = list(rec.get("messages", {}).values())
    return sorted(msgs, key=lambda m: (_parse_dt(m.get("date")) or _EPOCH))


def _update_thread_meta(
    rec: dict[str, Any], owner_domains: list[str], self_tokens: list[str]
) -> None:
    """Recompute participants (senders + to/cc), counterparties (external, non-owner),
    first/last date, count, and pick a subject (first non-empty chronologically)."""
    msgs = _sorted_messages(rec)
    parts: list[str] = []
    for m in msgs:
        for value in (m.get("from"), m.get("to"), m.get("cc")):
            for addr in _split_addrs(str(value or "")) or ([str(value).strip()] if value else []):
                addr = addr.strip()
                if addr and addr not in parts:
                    parts.append(addr)
    counterparties = [
        p for p in parts if not _is_owner_addr(p, owner_domains, self_tokens)
    ]
    cp_domains: list[str] = []
    for p in counterparties:
        dom = _addr_domain(p)
        if dom and dom not in cp_domains:
            cp_domains.append(dom)
    dated = [d for d in (_parse_dt(m.get("date")) for m in msgs) if d]
    rec["participants"] = parts
    rec["counterparties"] = counterparties
    rec["counterparty_domains"] = cp_domains
    rec["first_date"] = min(dated).isoformat() if dated else ""
    rec["last_date"] = max(dated).isoformat() if dated else ""
    rec["count"] = len(msgs)
    # MAIL-THREAD-1: кто написал ПОСЛЕДНЕЕ сообщение (find_notes/превью показывают
    # «чем кончился тред» из frontmatter, не читая тело).
    last = msgs[-1] if msgs else None
    rec["last_from"] = str(last.get("from") or "").strip() if last else ""
    rec["last_from_me"] = bool(last.get("is_me")) if last else False
    rec["buckets"] = sorted({str(m.get("bucket") or "") for m in msgs if m.get("bucket")})
    if not rec.get("subject"):
        rec["subject"] = next(
            (str(m.get("subject") or "").strip() for m in msgs if m.get("subject")), ""
        )


def _thread_body(rec: dict[str, Any], source_path: str) -> str:
    """Provenance preamble + each message chronologically. Full text is kept;
    only EXACT duplicate blocks already shown earlier in the thread are collapsed.
    Message header: ``## <date> — <sender> → <to[, cc]>``. Data only — no
    ``[[links]]``: связывание — отдельный проход linking-engine (Phase 9)."""
    lines = [f"Источник: {source_path}"]
    subj = rec.get("subject") or rec.get("conversationId") or "(без темы)"
    lines.append(f"Тред: {subj}")
    parts = rec.get("participants") or []
    if parts:
        lines.append("Участники: " + ", ".join(parts))
    cps = rec.get("counterparties") or []
    if cps:
        lines.append("Контрагенты: " + ", ".join(cps))
    span = " … ".join(x[:10] for x in (rec.get("first_date", ""), rec.get("last_date", "")) if x)
    lines.append(f"Сообщений: {rec.get('count', 0)}" + (f" · {span}" if span else ""))
    seen: set[str] = set()
    for m in _sorted_messages(rec):
        when = str(m.get("date") or "")[:16].replace("T", " ")
        who = "Я" if m.get("is_me") else (str(m.get("from") or "").strip() or "(?)")
        recips = _split_addrs(str(m.get("to") or "")) + _split_addrs(str(m.get("cc") or ""))
        arrow = f" → {', '.join(recips)}" if recips else ""
        lines.append("")
        lines.append(f"## {when} — {who}{arrow}")
        text = _collapse_seen(str(m.get("text") or ""), seen)
        if text:
            lines.append(text)
    return "\n".join(lines).strip() + "\n"


def _render_thread(
    thread_key: str,
    rec: dict[str, Any],
    vault_path: Path,
    *,
    owner_domains: list[str],
    self_tokens: list[str],
    dry_run: bool,
) -> tuple[str, str]:
    """Render one thread → a single note (frontmatter + chronological body). Returns
    ``(note_relpath, content_hash)``. One note per conversation, spanning folders.

    Data only (Phase 9, этап 3): counterparties / domains / subject идут во
    frontmatter как СИГНАЛЫ; ``[[hub]]``-ссылки рендер не проставляет никогда —
    их добавляет отдельный проход ``core/linking`` (deterministic-резолвер кроет
    домен→client-хаб) без переимпорта."""
    _update_thread_meta(rec, owner_domains, self_tokens)
    # MAIL-THREAD-1 (гард 2-го уровня): подозрение на склейку — только сигнал в лог.
    suspects = detect_splices(_sorted_messages(rec), owner_domains)
    rec["splice_suspects"] = suspects
    if suspects:
        logger.warning(
            "[mail] подозрение на склейку: %s — %d границ(ы) (смена темы + смена круга "
            "доменов), напр. между сообщениями %s",
            thread_key, len(suspects), suspects[0]["between"],
        )
    source_path = _thread_source_path(str(rec.get("anchor_key") or thread_key))
    base = slugify(rec.get("subject") or "") or "thread"
    suffix = hashlib.sha1(source_path.encode("utf-8")).hexdigest()[:8]  # noqa: S324 — content hash (identity/dedup), not security
    rel = f"_legacy/{CORRESPONDENCE_SECTION}/{base}-{suffix}.md"
    body = _thread_body(rec, source_path)
    content_hash = hashlib.sha1(body.encode("utf-8")).hexdigest()  # noqa: S324 — content hash (identity/dedup), not security

    created = (rec.get("first_date") or "")[:10]
    thread_id = legacy_note_id(source_path)
    fm: dict[str, Any] = {
        "id": thread_id,
        "aliases": [thread_id],  # KIT-FIT-1 п.9: ссылка [[legacy-…]] находится в Obsidian
        "type": "legacy-source",
        "corpus": "legacy",
        "curated": False,
        "status": "raw",
        "source_type": "email-thread",
        "source_path": source_path,
        "section": CORRESPONDENCE_SECTION,
        "conversation_id": rec.get("conversationId", ""),
        "account": rec.get("account", ""),
        "subject": rec.get("subject", ""),
        "participants": rec.get("participants", []),
        "counterparties": rec.get("counterparties", []),
        "counterparty_domains": rec.get("counterparty_domains", []),
        "first_date": rec.get("first_date", ""),
        "last_date": rec.get("last_date", ""),
        "last_from": rec.get("last_from", ""),
        "last_from_me": rec.get("last_from_me", False),
        "message_count": rec.get("count", 0),
        "created": created,
        "tags": ["legacy", CORRESPONDENCE_SECTION],
        # INGRESS-1 п.3: единый провенанс входа; ``source_id`` треда — conversation_id.
        **stamp_fields("mail", str(rec.get("conversationId") or source_path)),
    }
    fm = {k: v for k, v in fm.items() if v not in ("", []) or k in ("curated",)}

    if not dry_run:
        note = Note(
            id=fm["id"],
            type="legacy-source",
            path=vault_path / rel,
            frontmatter=fm,
            body=body,
        )
        note.path.parent.mkdir(parents=True, exist_ok=True)
        write_note(note)
    return rel, content_hash


def _privacy_probe(message: dict[str, Any]) -> str:
    """Text the privacy rules check for a message: participants + subject.

    Third-party surnames in the senders/recipients/subject trip the same
    name-token rule that excludes personal-data files in discovery. The owner's
    own identity (:func:`config.outlook_self_tokens`) is stripped first — they
    are a participant in every message, so their surname must not filter their
    own correspondence (it is on the privacy list to keep *their files* out).
    """
    parts = [str(message.get(k) or "") for k in ("subject", "from", "to", "cc")]
    # NFC-normalize both the probe text and the self-tokens so stripping (and the
    # downstream privacy match) works for Cyrillic regardless of normal form. Join
    # with spaces and drop "/" so privacy_reason sees one segment (an email has no
    # folder path): rules A1/A2 apply, the folder rule A3 is naturally inert.
    text = nfc(" ".join(p for p in parts if p.strip())).replace("/", " ")
    for token in outlook_self_tokens():
        token = nfc(token)
        if token:
            text = re.sub(re.escape(token), " ", text, flags=re.IGNORECASE)
    return text


_MAIL_SALARY_CONTEXT = ("зарплат", "оклад", "штатн", "премии")
# A1-термины, которые в теме письма значат что-то только при зарплатном контексте: «Личный
# кабинет», «вилка цен». Остальные A1-термины (зарплат/оклад) - сами контекст.
_A1_NEEDS_CONTEXT = ("личн", "вилк")
# MAIL-PRIVACY-2: контекст A2 («фамилия + контекст») для почты - БЕЗ голого «договор»: коммерческая
# переписка («договор ИТС», «ДС к договору субподряда») не персональные данные, а владелец ведет
# коммерцию. Персональное остается: ГПХ/оклад/зарплата/штат/кадры в строке. Расширение - env
# ``DT_MAIL_A2_CONTEXT`` (только добавляет). Файловый A2 (legacy discovery) этим не затронут.
_MAIL_A2_CONTEXT = ("гпх", "оклад", "зарплат", "штат", "кадр")


def _is_inbox(bucket: str) -> bool:
    return str(bucket or "").strip().lower() in ("inbox", "входящие")


def _privacy_check(message: dict[str, Any], *, sent: bool) -> str | None:
    """Приватность письма (MAIL-FILTER-1 п.3): участники + тема через файловые правила A1/A2.

    * A1 для ``личн``/``вилк`` - только при зарплатном контексте в ТЕМЕ (``зарплат|оклад|штатн|
      премии``): «Личный кабинет», «вилка цен» проходят;
    * A2 («фамилия + ГПХ/оклад/зарплата/штат/кадры») не применяется к Sent: свое письмо клиенту -
      не персональные данные третьих лиц; голое «договор» контекстом A2 для почты не является
      (MAIL-PRIVACY-2): «договор ИТС» коммерция, «Договор ГПХ <фамилия>» по-прежнему снимается.
    """
    terms = list(legacy_privacy_salary_terms())
    if first_term_hit(nfc(str(message.get("subject") or "")), _MAIL_SALARY_CONTEXT) is None:
        terms = [t for t in terms if t not in _A1_NEEDS_CONTEXT]
    context = list(dict.fromkeys([*_MAIL_A2_CONTEXT, *mail_a2_context_extra()]))
    return privacy_reason(
        _privacy_probe(message), salary_terms=terms, surname_rule=not sent, context_terms=context
    )


def _privacy_class(reason: str | None) -> str:
    """``privacy-term:зарплат`` → ``A1``, ``privacy-term:кадр`` → ``A1b``, ``privacy-name:`` →
    ``A2``, ``privacy-contract:`` → ``A3`` (счетчики диагностики)."""
    text = str(reason or "")
    kind, _, term = text.partition(":")
    if kind == "privacy-term":
        return "A1" if term in legacy_privacy_salary_terms() else "A1b"
    return {"privacy-name": "A2", "privacy-contract": "A3"}.get(kind, kind or "-")


def _record_noise(
    stats: MailIngestStats, memory: RefusedMemory, d: Decision, *, eid: str,
    subject: str, sender: str, dry_run: bool,
) -> None:
    """Шум: счетчик + пример + журнал отказов (с именем правила) + память «отказано»."""
    stats.skipped_noise += 1
    rule = d.rule or "?"
    stats.noise_by_rule[rule] = stats.noise_by_rule.get(rule, 0) + 1
    if len(stats.noise_examples) < 5:
        stats.noise_examples.append(f"{rule} · {subject[:60]}")
    refuse("mail", str(d.reason), source_id=eid, rule=d.rule,
           hint=subject_domain_hint(subject, sender))
    if not dry_run:
        memory.add(eid, d.reason, d.rule, datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"))


def _emit_refusals(refusals: list[dict[str, str]]) -> None:
    """Журнал стадий: отказы класть msg_id во второй тред (best-effort, одной пачкой)."""
    try:
        from core.eventlog import emit_batch, new_run_id

        run_id = new_run_id()
        emit_batch(
            [
                {
                    "stage": "ingest",
                    "status": "msg_multi_thread_refused",
                    "detail": r,
                    "run_id": run_id,
                }
                for r in refusals[:200]
            ]
        )
    except Exception:  # noqa: BLE001 — журнал не критичный путь
        logger.debug("eventlog emit(msg_multi_thread_refused) failed", exc_info=True)


def _record_folder_problem(
    stats: MailIngestStats, emit: Callable[[str], None], label: str, account: str,
    code: str, reason: str,
) -> None:
    """Деградация спецификации: строка в статистику, ``warn`` в журнал и в консоль, событие."""
    stats.folder_problems.append(
        {"folder": label, "account": account, "code": code, "reason": reason}
    )
    logger.warning("[mail] %s: %s - %s", label, code, reason)
    emit(f"[mail] {label}: {code} - {reason}")
    try:
        from core.eventlog import emit as emit_event

        emit_event("ingest", code, detail={"folder": label, "account": account})
    except Exception:  # noqa: BLE001 - журнал стадий не критичный путь
        logger.debug("eventlog emit(%s) failed", code, exc_info=True)


def _fmt_eta(seconds: float) -> str:
    """Human ETA: ``42s`` / ``7m`` / ``2h``."""
    if seconds < 90:
        return f"{int(seconds)}s"
    if seconds < 5400:
        return f"{int(seconds / 60)}m"
    return f"{seconds / 3600:.1f}h"


# --------------------------------------------------------------------------- #
# Ingest                                                                      #
# --------------------------------------------------------------------------- #


def _flush_threads(
    batch_recs: dict[str, dict[str, Any]],
    *,
    index: dict[str, dict[str, Any]],
    included: dict[str, set[str]],
    prev_keys: set[str],
    rendered: set[str],
    owner_domains: list[str],
    self_tokens: list[str],
    stats: MailIngestStats,
    vault_path: Path,
    state_dir: Path,
    manifest_path: Path,
    run_id: str | None = None,
) -> None:
    """Re-render each thread touched this batch, write ONLY its sidecar (bodies),
    then flush the lightweight index once. Render BEFORE persisting so the index
    only records messages whose note + sidecar are on disk (resume-safe).

    INGRESS-1 п.5: по каждому отрисованному треду — ``ingest``-событие (``note_id``, ``path``,
    ``run_id``, ``detail {route: mail, msgs, disposition}``), пачкой на вызов."""
    events: list[dict[str, Any]] = []
    for tkey, rec in batch_recs.items():
        runlock.beat()  # MAIL-LOCK-1: писатель держит dt-sync.lock - сторож видит прогресс
        rel, chash = _render_thread(
            tkey, rec, vault_path,
            owner_domains=owner_domains, self_tokens=self_tokens, dry_run=False,
        )
        rec["note_path"] = rel
        rec["content_hash"] = chash
        if rec.get("splice_suspects"):
            stats.splice_suspects += 1
        _save_thread_rec(state_dir, tkey, rec)  # per-thread bodies (small write)
        index[tkey] = _index_entry(rec)
        included[tkey] = set(index[tkey]["msg_ids"])
        events.append({
            "stage": "ingest", "status": "done",
            "note_id": legacy_note_id(_thread_source_path(str(rec.get("anchor_key") or tkey))),
            "source_hash": chash, "path": rel,
            "detail": {"route": "mail", "msgs": len(rec.get("messages") or {}),
                       "disposition": "changed" if tkey in prev_keys else "new"},
        })
        if tkey not in rendered:
            rendered.add(tkey)
            if tkey in prev_keys:
                stats.changed += 1
            else:
                stats.new += 1
            if len(stats.examples) < 5:
                stats.examples.append(rel)
    _save_manifest(manifest_path, index)  # lightweight index only
    _emit_thread_events(events, run_id)


def _emit_thread_events(events: list[dict[str, Any]], run_id: str | None) -> None:
    """Лента событий: отрисованные треды (INGRESS-1 п.5). Best-effort — не ломает ingest."""
    if not events:
        return
    try:
        from core.eventlog import emit_batch, new_run_id
        from core.ingress.run import current_run

        run = current_run()
        rid = run_id or (run.run_id if run is not None else new_run_id())
        emit_batch([{**e, "run_id": rid} for e in events])
    except Exception:  # noqa: BLE001 — лента событий не критичный путь
        logger.debug("eventlog emit(mail thread) failed", exc_info=True)


def _acct_kw(account: str) -> dict[str, str]:
    """Именованные аргументы моста для спецификации: ``account`` ТОЛЬКО когда он задан."""
    return {"account": account} if account else {}


def _explain_privacy_batch(
    bridge: MailBridge, batch: list[tuple[tuple[str, str], str, dict[str, Any]]],
    stats: MailIngestStats, out: Callable[[str], None],
) -> None:
    """Диагностика приватности пачки (dry-run, ``--explain-privacy``): читает тела (read-only),
    печатает ``правило · дата · тема[:60]`` каждого отказа ТОЛЬКО в ``out`` (консоль), считает
    «до» (прежнее правило) и «после» (суженное) по классу правила и папке. Журнал/файл не
    трогает."""
    for ref in sorted({b[0] for b in batch}):
        fname, facc = ref
        fbatch = [(bk, m) for (fn, bk, m) in batch if fn == ref]
        ids = [str(m.get("entryID") or "") for _bk, m in fbatch]
        by_id = {
            str(f.get("entryID") or ""): f
            for f in bridge.fetch_by_ids(fname, ids, **_acct_kw(facc))
        }
        for bk, m in fbatch:
            msg = by_id.get(str(m.get("entryID") or ""))
            if msg is None:
                continue
            side = "inbox" if _is_inbox(bk) else "sent"
            before = privacy_reason(_privacy_probe(msg))
            after = _privacy_check(msg, sent=side == "sent")
            if before is not None:
                key = f"{_privacy_class(before)}/{side}"
                stats.privacy_before[key] = stats.privacy_before.get(key, 0) + 1
            if after is not None:
                key = f"{_privacy_class(after)}/{side}"
                stats.privacy_after[key] = stats.privacy_after.get(key, 0) + 1
                when = str(msg.get("date") or m.get("date") or "")[:10]
                subj = " ".join(str(msg.get("subject") or m.get("subject") or "").split())[:60]
                out(f"[privacy] {side} · {after} · {when} · {subj}")


def _explain_privacy_summary(stats: MailIngestStats, out: Callable[[str], None]) -> None:
    keys = sorted(set(stats.privacy_before) | set(stats.privacy_after))
    if not keys:
        out("[privacy] отказов приватности в окне нет (ни по прежнему, ни по новому правилу)")
        return
    out("[privacy] до → после (класс правила/папка):")
    for k in keys:
        out(f"[privacy]   {k}: {stats.privacy_before.get(k, 0)} → {stats.privacy_after.get(k, 0)}")


@dataclass
class _Phase1:
    """Общее состояние фазы 1 (метаданные → фильтры → выжившие) по всем спецификациям."""

    bridge: MailBridge
    index: dict[str, dict[str, Any]]
    included: dict[str, set[str]]
    owner: dict[str, str]
    memory: RefusedMemory
    rules: Rules
    stats: MailIngestStats
    emit: Callable[[str], None]
    scope: str
    since: str | None
    all_history: bool
    limit: int | None
    dry_run: bool
    survivors: list[tuple[tuple[str, str], str, dict[str, Any]]]
    refusals: list[dict[str, str]]
    eid_thread: dict[str, str]
    thread_keys: set[str]
    # MAIL-BRIDGE-INC-1: ``full_listing`` - читать каждую спецификацию целиком (замер дыры курсора,
    # ``--full-listing``); ``verify_full`` - суточная сверка окна с полным листингом (``id_store`` -
    # стор отметок; ``now_local`` - местное время для правила «после 03:00»).
    full_listing: bool = False
    verify_full: bool = False
    id_store: FolderIdStore | None = None
    now_local: datetime | None = None
    # MAIL-OVERLAP-1: метка спецификации → время последнего успешного чтения (ISO, из снимка
    # ``mail_accounts.json``); нет записи - граница по курсору, как прежде.
    last_ok: dict[str, str] = field(default_factory=dict)
    resume_at: dict[str, str] = field(default_factory=dict)


def _total_of(rows: list[dict[str, Any]]) -> int:
    """Писем в папке: ``total`` ответа моста (счетчик Outlook), иначе длина листинга (подделка)."""
    total = getattr(rows, "total", None)
    return int(total) if total is not None else len(rows)


def _newest_of(rows: list[dict[str, Any]]) -> str:
    """Дата новейшего прочитанного письма: ``newest`` моста (голова папки), иначе максимум."""
    newest = getattr(rows, "newest", "")
    return str(newest) if newest else max((str(m.get("date") or "") for m in rows), default="")


@dataclass
class _SpecRead:
    """Прочитанное по спецификации: строки окна (уже по ``since``) и сведения для счетчиков."""

    rows: list[dict[str, Any]]
    total: int
    newest: str
    mode: str  # head | full
    fallback: str = ""
    daily: bool = False  # суточный полный проход (``full_pass_due``): читался полный листинг
    since: str | None = None  # граница, по которой отрезаны ``rows`` (``None`` - вся папка)


def _compare_window(
    window: list[dict[str, Any]], full: list[dict[str, Any]]
) -> tuple[int, int]:
    """``(missing, extra)``: писем полного листинга (при том же ``since``), которых нет в окне, и
    писем окна, которых нет в полном. Равенство множеств entryID - инвариант окна."""
    win_ids = {str(m.get("entryID") or "") for m in window}
    full_ids = {str(m.get("entryID") or "") for m in full}
    return len(full_ids - win_ids), len(win_ids - full_ids)


def _read_spec(
    c: _Phase1, name: str, account: str, label: str, cur: SinceCursor
) -> _SpecRead:
    """Один листинг спецификации: окно с головы по курсору либо полный (ТЗ MAIL-BRIDGE-INC-1).

    Окно - по умолчанию: быстрый цикл не листает всю папку. Полный листинг - когда он нужен
    самому прогону (``--all``, ``full_listing``: замер дыры курсора) либо суточной сверке: тогда
    читаются ОБА (окно и полный, папка ищется обходом - запись id обновляется), множества
    сравниваются, итог пишется в стор и в статистику, а данные берутся из ПОЛНОГО листинга.

    MAIL-OVERLAP-1: сверка окна с полным считается при ОДНОЙ узкой границе ``cur.since`` (иначе
    она всегда показывала бы расхождение: окно с головы по узкой границе короче полного), а
    данные суточного прохода режутся по широкой ``cur.deep_since`` (курсор − ``DT_MAIL_CURSOR_
    DEEP_DAYS``, не позже узкой): листинг уже прочитан, граница ничего не стоит и подбирает
    письма, пришедшие в Outlook с датой старше узкого перекрытия. ``--all``/``full_listing``/
    явный ``--since``/``scope=full`` суточным проходом не бывают - там граница прежняя."""
    bridge, kw = c.bridge, _acct_kw(account)
    forced = c.full_listing or cur.since is None
    due, why = False, ""
    if c.verify_full and not forced:
        store = c.id_store or FolderIdStore()
        due, why = full_pass_due(
            store.last_full_pass(label),
            now=c.now_local or datetime.now().astimezone(), every_h=mail_full_every_h(),
        )
    window = None if forced else bridge.list_folder_meta(name, cur.since, **kw)
    full = None
    if forced or due:
        full_kw = {**kw, "refresh_id": True} if (due and account) else kw
        full = bridge.list_folder_meta(name, None, **full_kw)
    win_rows = None if window is None else filter_since(list(window), cur.since)
    if full is None:
        assert window is not None and win_rows is not None  # noqa: S101 - иначе forced
        return _SpecRead(
            win_rows, _total_of(window), _newest_of(window),
            str(getattr(window, "mode", "full")), str(getattr(window, "fallback", "")),
            since=cur.since,
        )
    full_rows = filter_since(list(full), cur.since)  # узкая граница: для сверки с окном
    data_since = (cur.deep_since or cur.since) if due else cur.since
    data_rows = full_rows if data_since == cur.since else filter_since(list(full), data_since)
    read = _SpecRead(
        data_rows, _total_of(full), _newest_of(full), "full", daily=due, since=data_since
    )
    if due and window is not None and win_rows is not None:
        read.fallback = str(getattr(window, "fallback", ""))
        _verify_window(
            c, label, win_rows, full_rows, str(getattr(window, "mode", "full")), why,
            since=cur.since, data_since=data_since, data_len=len(data_rows),
        )
    return read


def _verify_window(
    c: _Phase1, label: str, window: list[dict[str, Any]], full: list[dict[str, Any]],
    window_mode: str, why: str, *, since: str | None = None, data_since: str | None = None,
    data_len: int | None = None,
) -> None:
    """Суточная сверка: окно ≡ полный листинг при том же ``since``. Итог - стор, статистика, лог.

    ``since`` - узкая граница, при которой считается сверка; ``data_since``/``data_len`` - широкая
    граница данных суточного прохода и сколько писем она отдала (MAIL-OVERLAP-1, только лог)."""
    missing, extra = _compare_window(window, full)
    ok = not missing and not extra
    result = {
        "ok": ok, "window": len(window), "full": len(full), "missing": missing, "extra": extra,
        "why": why, "window_mode": window_mode,
    }
    c.stats.full_pass[label] = result
    (c.id_store or FolderIdStore()).record_full_pass(
        label, ok=ok, window=len(window), full=len(full), missing=missing, extra=extra,
        now=c.now_local,
    )
    deep = ""
    if data_since is not None and data_since != since:
        deep = f"; данные суточного прохода с {data_since}: {data_len} писем"
    if ok:
        c.emit(f"[mail] {label}: суточная сверка ({why}): окно = полный листинг, "
               f"{len(full)} писем в узкой границе {since}{deep}")
        return
    logger.warning(
        "[mail] %s: окно с головы НЕ равно полному листингу: в окне не хватает %d, лишних %d "
        "(окно %d, полный %d, узкая граница %s) - данные взяты из полного листинга",
        label, missing, extra, len(window), len(full), since,
    )
    c.emit(f"[mail] {label}: ВНИМАНИЕ окно с головы не равно полному листингу: не хватает "
           f"{missing}, лишних {extra}")


def _bridge_calls(bridge: MailBridge) -> int | None:
    """Сколько раз мост запускал osascript (``None`` - подделка без счетчика)."""
    calls = getattr(bridge, "calls", None)
    return calls if isinstance(calls, int) else None


def _bridge_walks(bridge: MailBridge, name: str, account: str) -> int:
    """Сколько обходов дерева мост сделал для пары аккаунт+папка (0 - нет сведений)."""
    of = getattr(bridge, "addressing_of", None)
    return int((of(name, account) or {}).get("walks", 0)) if callable(of) else 0


def _addressing_row(
    bridge: MailBridge, name: str, account: str, walks0: int, calls0: int | None, seconds: float
) -> dict[str, Any]:
    """Сведения шага по спецификации для снимка/лога/доктора: способ адресации, причина обхода,
    вызовы моста и время. Без сведений от моста (подделка) - ``addressing: ""``."""
    of = getattr(bridge, "addressing_of", None)
    info = (of(name, account) or {}) if callable(of) else {}
    row: dict[str, Any] = {"addressing": "", "walk_reason": "", "seconds": round(seconds, 2)}
    calls = _bridge_calls(bridge)
    if calls is not None and calls0 is not None:
        row["bridge_calls"] = calls - calls0
    if info:
        walked = int(info.get("walks", 0)) > walks0
        row["addressing"] = "walk" if walked else str(info.get("mode") or "")
        row["walk_reason"] = str(info.get("walk_reason") or "") if walked else ""
    return row


def _spec_line(label: str, row: dict[str, Any], fallback: str) -> str:
    """``[mail] inbox[a@b.c]: адресация id · окно с головы · вызовов моста 2 · 3.1 с`` - одна строка
    на спецификацию в журнал шага (без тем и адресов писем)."""
    from core.operational.mail_folder_ids import walk_reason_text

    addr = str(row.get("addressing") or "")
    if addr == "walk":
        reason = walk_reason_text(str(row.get("walk_reason") or ""))
        parts = [f"адресация обход ({reason})" if reason else "адресация обход"]
    elif addr:
        parts = [f"адресация {addr}"]
    else:
        parts = ["адресация не определена"]
    window = "окно с головы" if row.get("window") == "head" else "полный листинг"
    if fallback:
        window += f" (окно отвергнуто: {fallback})"
    parts.append(window)
    if row.get("bridge_calls") is not None:
        parts.append(f"вызовов моста {row['bridge_calls']}")
    parts.append(f"{float(row.get('seconds') or 0.0):.1f} с")
    return f"[mail] {label}: " + " · ".join(parts)


def _mark_read_ok(c: _Phase1, label: str, cur: SinceCursor, read: _SpecRead) -> None:
    """Отметить спецификацию как успешно прочитанную в этом прогоне (MAIL-OVERLAP-1).

    Время успешного чтения (``read_ok_at`` в снимке спецификации; ``record_run`` кладет его в
    ``mail_accounts.json`` как ``last_ok_read``) сдвигает только БОЕВОЙ прогон без отказа
    спецификации. Не сдвигают: сухой прогон; прогон с ``--limit`` (хвост кандидатов не взят);
    явный ``--since`` (читалось окно, уже обычного).

    Прогон после простоя (``cur.downtime``: с последнего чтения прошло больше перекрытия) время
    тоже не сдвигает: Outlook после простоя докачивает письма кусками, свежие первыми, и письма
    отпуска появятся ПОЗЖЕ первого прогона. Сдвинуть чтение сразу - значит вернуть узкую границу
    раньше, чем эти письма придут. Поэтому растянутая граница держится (``resume_at`` - начало
    удержания) до суточного полного прохода, который случился не раньше ``DT_MAIL_FULL_EVERY_H``
    часов после начала: он читает полный листинг, подбирает все, что докачано, и снимает
    удержание. Стоимость - до суток широкого окна после простоя дольше перекрытия."""
    row = c.stats.folder_snapshot.get(label)
    if row is None or c.dry_run or c.limit:
        return
    if cur.mode not in ("cursor", "resume", "window", "full", "all"):
        return
    now = (c.now_local or datetime.now(UTC)).astimezone(UTC)
    stamp = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    if cur.downtime and cur.mode in ("cursor", "resume"):
        began = _parse_dt(c.resume_at.get(label, ""))
        if began is None:
            row["resume_at"] = stamp  # удержание началось с этого прогона
            return
        if read.daily and (now - began).total_seconds() >= mail_full_every_h() * 3600:
            row["read_ok_at"] = stamp  # суточный проход после выдержки: удержание снято
            return
        row["resume_at"] = c.resume_at[label]  # удержание продолжается
        return
    row["read_ok_at"] = stamp


def _scan_spec(c: _Phase1, spec: dict[str, str]) -> None:
    """Фаза 1 для ОДНОЙ спецификации ``{bucket, name[, account]}``: листинг метаданных, срез по
    ``since``, фильтры до тела, выжившие - в ``c.survivors``. Деградация спецификации
    (``folder_unresolved`` / ``folder_empty_suspicious``) - запись в ``c.stats.folder_problems``,
    остальные спецификации не страдают."""
    stats, index = c.stats, c.index
    bucket, name = spec["bucket"], spec["name"]
    account = str(spec.get("account") or "")
    label = folder_label(spec)
    is_inbox = bucket.strip().lower() in ("inbox", "входящие")
    cur = _cursor_for(
        index, bucket, c.scope, since=c.since, all_history=c.all_history, account=account,
        last_ok=c.last_ok.get(label, ""), now=c.now_local,
    )
    history = _newest_bucket_date(index, bucket, account)
    # MAIL-BRIDGE-INC-1: окно с головы по курсору (мост читает начало папки страницами по индексу),
    # а не полный листинг; счетчики те же: ``total`` - из ответа моста (счетчик папки),
    # ``skipped_since = total − длина окна``, ``newest`` - из головы. Полный листинг - только когда
    # он нужен самому прогону (``--all``, замер дыры) и раз в сутки для сверки окна.
    began = time.perf_counter()
    calls0 = _bridge_calls(c.bridge)
    walks0 = _bridge_walks(c.bridge, name, account)
    try:
        read = _read_spec(c, name, account, label, cur)
    except FolderUnresolvedError as exc:
        # Папка не нашлась (нет такого ящика/имени): отказ с кодом, не «0 новых». Остальные
        # спецификации читаются дальше; шаг синхронизации и CLI не ``ok``.
        _record_folder_problem(stats, c.emit, label, account, exc.code, exc.reason)
        stats.folder_snapshot[label] = {
            "account": account, "bucket": bucket, "name": name, "total": None,
            "newest": "", "resolved": False, "history": history,
        }
        return
    stats.folder_snapshot[label] = {
        "account": account, "bucket": bucket, "name": name, "total": read.total,
        "newest": read.newest, "resolved": True, "history": history, "window": read.mode,
        **_addressing_row(c.bridge, name, account, walks0, calls0, time.perf_counter() - began),
    }
    stats.window_mode[label] = read.mode
    stats.window_fallback[label] = read.fallback
    if read.total == 0 and history:
        # Папка разрешилась в 0 писем при непустой истории - так выглядел инцидент 02.11
        # (ключевое слово inbox сменило адресата на пустую «On My Computer»). «Пусто» здесь
        # неотличимо от «писем нет» - это НЕ здоровый ноль: отказ с кодом.
        _record_folder_problem(
            stats, c.emit, label, account, CODE_FOLDER_EMPTY_SUSPICIOUS,
            f"папка вернула 0 писем, а в манифесте по ней есть история (новейшее "
            f"{history[:10]}): ящик/папка могли смениться - чтение прервано без «0 новых»",
        )
        return
    _mark_read_ok(c, label, cur, read)
    meta = read.rows
    cut = max(0, read.total - len(meta))
    stats.skipped_since += cut
    stats.skipped_since_by_folder[label] = cut
    stats.since_effective[label] = read.since or "all"
    stats.since_notes[label] = (
        f"{label}: {cur.note(pull_window=outlook_pull_window(), daily=read.daily)}"
    )
    c.emit(f"[mail] {stats.since_notes[label]}, отрезано границей {cut}")
    if stats.folder_snapshot[label].get("addressing"):  # мост-подделка без сведений - молчим
        c.emit(_spec_line(label, stats.folder_snapshot[label], read.fallback))
    meta.sort(key=lambda m: (_parse_dt(m.get("date")) or _EPOCH), reverse=True)
    # SMOKE-DRIFT-1: письмо новее новейшего в манифесте - не дыра, а очередь синхронизации
    # (граница не зависит от режима ``since``: явный ``--since`` курсора не несет).
    newest_indexed = _parse_dt(history)
    taken = 0
    for m in meta:
        eid = str(m.get("entryID") or "")
        if not eid:
            continue
        if c.limit and taken >= c.limit:
            break  # --limit: потолок кандидатов на папку (канарейка бэкфилла), новейшие первыми
        tkey = resolve_thread_key(index, m.get("conversationId"), eid, account)
        # resume: this message is already recorded in its thread → skip.
        if c.scope != "full" and eid in c.included.get(tkey, ()):
            stats.resumed += 1
            continue
        # MAIL-FILTER-1: снятое фильтром прежде не возвращаем (``scope=full`` - решает yaml).
        if c.scope != "full" and eid in c.memory:
            stats.refused_resumed += 1
            continue
        # Темовые правила ДО чтения тела (в метаданных отправителя нет): Sent - только
        # авто-префиксы; Inbox - при пустом allow, иначе решит чтение письма (allow бьет все).
        nd = decide_meta(m.get("subject"), inbox=is_inbox, rules=c.rules)
        if nd is not None:
            _record_noise(stats, c.memory, nd, eid=eid, subject=str(m.get("subject") or ""),
                          sender=str(m.get("from") or ""), dry_run=c.dry_run)
            continue
        prior = c.owner.get(eid)
        if prior is not None and prior != tkey:
            # Второй тред для того же msg_id — отказ с журналом, не тихий дубль.
            stats.rejected_multi_thread += 1
            refuse("mail", "multi_thread", source_id=eid)
            c.refusals.append({"msg_id": eid, "have": prior, "want": tkey, "folder": name})
            if len(stats.reject_examples) < 5:
                stats.reject_examples.append(f"{eid}: {prior} ≠ {tkey}")
            logger.warning(
                "[mail] msg_id %s уже в треде %s — отказ класть во второй (%s)",
                eid, prior, tkey,
            )
            continue
        c.owner[eid] = tkey
        c.eid_thread[eid] = tkey
        c.thread_keys.add(tkey)
        c.survivors.append(((name, account), bucket, m))
        taken += 1
        stats.added_by_folder[label] = stats.added_by_folder.get(label, 0) + 1
        received = _parse_dt(m.get("date"))
        if newest_indexed is not None and received is not None and received > newest_indexed:
            stats.added_after_cursor_by_folder[label] = (
                stats.added_after_cursor_by_folder.get(label, 0) + 1
            )
            continue
        day = str(m.get("date") or "")[:10]
        days = stats.added_dates.setdefault(label, [])
        if day and day not in days:
            days.append(day)


def _load_last_ok(manifest_path: Path | None = None) -> tuple[dict[str, str], dict[str, str]]:
    """Из снимка ``mail_accounts.json`` (MAIL-OVERLAP-1): метка спецификации → время последнего
    успешного чтения и → начало удержания после простоя (``resume_at``); нет снимка / нет записи -
    пусто (граница по курсору)."""
    from core.legacy.mail_accounts import load_state  # лениво: mail_accounts импортирует mail

    specs = load_state(manifest_path).get("specs")
    if not isinstance(specs, dict):
        return {}, {}
    rows = {str(k): v for k, v in specs.items() if isinstance(v, dict)}
    return (
        {k: str(v["last_ok_read"]) for k, v in rows.items() if v.get("last_ok_read")},
        {k: str(v["resume_at"]) for k, v in rows.items() if v.get("resume_at")},
    )


def ingest_mail(
    vault_path: Path,
    bridge: MailBridge,
    *,
    folders: list[dict[str, str]] | None = None,
    since: str | None = None,
    scope: str = "incremental",
    dry_run: bool = False,
    all_history: bool = False,
    batch_size: int | None = None,
    limit: int | None = None,
    should_stop: Callable[[], bool] | None = None,
    on_progress: Callable[[str], None] | None = None,
    explain_privacy: Callable[[str], None] | None = None,
    full_listing: bool = False,
    verify_full: bool = False,
    now: datetime | None = None,
) -> MailIngestStats:
    """PER-THREAD pull of Outlook folders → ``_legacy/correspondence/`` notes
    (принцип 11: optimised, transparent, interruptible, resumable).

    ONE note per conversation (``conversationId``), NOT one per message — a thread
    may span Inbox AND Sent, and the note accumulates across folders and runs
    (dedup + fragmentation gone). Two phases:

      1. CHEAP — ``list_folder_meta`` returns metadata (id/subject/from/date/
         conversationId) for every message in the window; per-message filters
         apply BEFORE any body: resume (message already in its thread's manifest
         record), then — Inbox only — noise (automated senders / bulk subjects).
         Survivors are grouped by conversationId.
      2. HEAVY — survivors are fetched in date-descending batches of ``batch_size``
         (``DT_MAIL_BATCH``, default 300) via ``fetch_by_ids``; privacy is
         re-checked with recipients, sender-noise (Inbox) is applied, and each
         message's FULL body (no quote-stripping) is appended to its thread record
         (content-hash dedup within the thread). Threads touched by a batch are
         re-rendered from their full (accumulated) record — messages sorted
         chronologically, exact duplicate blocks collapsed at render — and the
         manifest is flushed. Resume-safe: the manifest stores each included
         message's full text, so a later message (or the second folder) re-renders
         the whole thread without re-fetching the old ones. Meeting/calendar
         auto-responses are noise in both folders; frontmatter carries
         participants (senders + to/cc) and counterparties (external, non-owner)
         with their domains — as DATA (signals). No ``[[links]]`` are written
         here: связывание — отдельный проход ``core/linking`` (Phase 9).

    ``since`` windows the scan; ``all_history=True`` reads the whole folder (all
    years). ``dry_run`` counts threads/messages without fetching bodies or writing.
    ``should_stop`` is polled after each batch (graceful SIGTERM — the in-flight
    batch is flushed first); ``on_progress`` gets one ``[mail] …`` line per batch.
    Sent is never noise-filtered (only auto-reply prefixes). Noise is decided by
    :func:`core.legacy.mail_filter.decide` over ``_system/mail-filter.yaml``; a removed message is
    remembered (:class:`RefusedMemory`) so an incremental run never brings it back.
    ``explain_privacy`` (только с ``dry_run``; MAIL-FILTER-1 п.3) печатает в переданный
    callback - НЕ в журнал и не в файл - правило/дату/тему[:60] каждого privacy-отказа окна и
    счетчики «до/после» (читает тела писем, ничего не пишет). State is a LIGHTWEIGHT index
    manifest plus one
    sidecar file per thread (bodies) — each batch writes only its touched sidecars
    + the small index, so per-batch I/O is bounded (not O(corpus)). Memory holds
    the index + one batch, never all bodies. No LLM.

    MAIL-BRIDGE-INC-1: спецификация читается окном с головы папки (по курсору), а не полным
    листингом. ``full_listing=True`` - всегда целиком (замер дыры курсора ``measure_gap``).
    ``verify_full=True`` - раз в сутки (первый прогон после 03:00 местного либо старше
    ``DT_MAIL_FULL_EVERY_H``) спецификация читается и целиком, окно сверяется с полным листингом
    (расхождение - WARNING и строка доктора); только для боевого инкрементального прогона без
    явной границы. ``now`` - местное время (подмена в тестах).

    Raises :class:`~core.operational.outlook_bridge.OutlookUnavailableError`
    (propagated from the bridge) when Outlook cannot be read.
    """
    start = time.perf_counter()
    calls_at_start = _bridge_calls(bridge)
    vault_path = Path(vault_path)
    manifest_path = outlook_ingest_manifest_path()
    state_dir = _state_dir(manifest_path)
    # One-time: split a legacy 127 MB single-file manifest into sidecars + index.
    _migrate_manifest_if_needed(manifest_path, state_dir)
    # The index is lightweight (no bodies) — safe to hold fully in memory.
    index = {
        k: v
        for k, v in _load_manifest(manifest_path).items()
        if isinstance(v, dict) and "msg_ids" in v
    }
    prev_keys = set(index.keys())
    included = {k: set(v.get("msg_ids") or []) for k, v in index.items()}
    # MAIL-THREAD-1 инвариант: msg_id принадлежит РОВНО одному треду. Карта владельцев
    # строится из индекса; для уже задвоенных (до ремонта) владельцем считается первый
    # тред — их разбирает mail_repair, а не инжест.
    owner: dict[str, str] = {}
    for tk, ent in index.items():
        for mid in ent.get("msg_ids") or []:
            owner.setdefault(str(mid), tk)
    # INGRESS-1: ``run_id`` прогона — общий с итогом (контекст ``ingress_run``), иначе свой.
    from core.ingress.run import current_run

    _run = current_run()
    run_id = _run.run_id if _run is not None else None
    stats = MailIngestStats(
        dry_run=dry_run, scope=scope, manifest_path=str(manifest_path)
    )

    folder_specs = folders if folders is not None else outlook_folders()
    stats.folders = [folder_label(spec) for spec in folder_specs]
    batch_n = batch_size if (batch_size and batch_size > 0) else mail_batch_size()
    rules: Rules = load_rules(vault_path)
    stats.filter_source = rules.source
    memory = RefusedMemory()
    owner_domains = mail_owner_domains()
    # ACT-1 / хвост PERF-1: прогресс виден живьём и под пайпом launchd (flush).
    emit = on_progress if on_progress is not None else (lambda msg: print(msg, flush=True))
    stop = should_stop if should_stop is not None else (lambda: False)
    # MAIL-ACCOUNTS-1: адрес КАЖДОГО читаемого ящика - «свой» (is_me, проба приватности,
    # контрагенты), даже если профиль владельца перечисляет не все адреса.
    self_tokens = list(dict.fromkeys([
        *outlook_self_tokens(),
        *(str(spec["account"]) for spec in folder_specs if spec.get("account")),
    ]))

    # ---- Phase 1: META across all folders → per-message filters → survivors. ---
    survivors: list[tuple[str, str, dict[str, Any]]] = []  # (folder, bucket, meta)
    refusals: list[dict[str, str]] = []
    eid_thread: dict[str, str] = {}
    thread_keys: set[str] = set()
    last_ok, resume_at = _load_last_ok(manifest_path)
    scan = _Phase1(
        bridge=bridge, index=index, included=included, owner=owner, memory=memory, rules=rules,
        stats=stats, emit=emit, scope=scope, since=since, all_history=all_history, limit=limit,
        dry_run=dry_run, survivors=survivors, refusals=refusals, eid_thread=eid_thread,
        thread_keys=thread_keys, full_listing=full_listing,
        verify_full=(
            verify_full and not dry_run and scope == "incremental" and since is None
            and not all_history and not full_listing
        ),
        id_store=getattr(bridge, "id_store", None) or (FolderIdStore() if verify_full else None),
        now_local=now, last_ok=last_ok, resume_at=resume_at,
    )
    for spec in folder_specs:
        _scan_spec(scan, spec)

    stats.bridge_misaligned = len(getattr(bridge, "misaligned", []) or [])

    def _count_bridge_calls() -> None:
        calls_now = _bridge_calls(bridge)
        if calls_now is not None and calls_at_start is not None:
            stats.bridge_calls = calls_now - calls_at_start

    _count_bridge_calls()
    memory.save()
    if refusals:
        _emit_refusals(refusals)
    total_msgs = len(survivors)
    total_threads = len(thread_keys)
    rendered: set[str] = set()

    if total_msgs == 0:
        emit("[mail] 0/0 threads | msgs 0 | done")
        stats.elapsed_s = time.perf_counter() - start
        return stats  # вызовов моста за прогон - уже посчитаны (одни листинги)

    # ACT-1: маяк для pult_activity — счётчики тредов/сообщений, без тем/адресов.
    beacon = ProgressBeacon("mail", total_threads, emit=emit)

    # ---- Phase 2: fetch bodies per batch (by EXACT id), accumulate + render. ---
    consumed = 0
    stopped = False
    broken_threads: set[str] = set()
    i = 0
    while i < total_msgs:
        batch = survivors[i:i + batch_n]
        i += batch_n
        consumed += len(batch)

        if not dry_run:
            # Threads touched this batch — their bodies live in batch_recs (loaded
            # from the sidecar on first touch), so memory holds one batch, not all.
            batch_recs: dict[str, dict[str, Any]] = {}
            for ref in dict.fromkeys(b[0] for b in batch):
                fname, facc = ref
                fbatch = [(bk, m) for (fn, bk, m) in batch if fn == ref]
                ids = [str(m.get("entryID") or "") for _bk, m in fbatch]
                # Direct id lookups — only these messages, no date-span over-fetch.
                by_id = {
                    str(f.get("entryID") or ""): f
                    for f in bridge.fetch_by_ids(fname, ids, **_acct_kw(facc))
                }
                for bk, m in fbatch:
                    eid = str(m.get("entryID") or "")
                    msg = by_id.get(eid)
                    if msg is None:
                        continue
                    sent_msg = not _is_inbox(bk)
                    p_reason = _privacy_check(msg, sent=sent_msg)
                    if p_reason is not None:
                        stats.skipped_privacy += 1
                        # MAIL-PRIVACY-2: строка журнала - id письма, КЛАСС правила и папка·дата;
                        # ни темы, ни участников, ни фамилии (значение правила отрезано)
                        when = str(msg.get("date") or m.get("date") or "")[:10]
                        side = "sent" if sent_msg else "inbox"
                        rule_class = p_reason.partition(":")[0]
                        refuse("mail", "privacy_probe", source_id=eid,
                               rule=rule_class,
                               hint=f"{side} · {when}" if when else side)
                        # Память «отказано» (id + класс правила, без темы и значения): сухой
                        # проход (С-13 дыра курсора) тел не читает и иначе считал бы снятое
                        # приватностью письмо «дырой» каждую неделю (08.11: 6 из 6 - это).
                        # Как и шум, при scope=full решает текущая политика, не память.
                        memory.add(eid, "privacy_probe", rule_class,
                                   datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"))
                        continue
                    frm = str(msg.get("from") or m.get("from") or "")
                    # Шум по полному правилу (отправитель известен только теперь): Inbox -
                    # весь набор yaml, Sent - только авто-префиксы.
                    subj_now = str(msg.get("subject") or m.get("subject") or "")
                    nd = decide({"subject": subj_now, "from": frm}, inbox=not sent_msg, rules=rules)
                    if nd.noise:
                        _record_noise(stats, memory, nd, eid=eid, subject=subj_now, sender=frm,
                                      dry_run=False)
                        continue
                    tkey = eid_thread[eid]
                    if tkey in broken_threads:
                        continue
                    if tkey not in batch_recs:
                        # Load the thread's existing bodies (prior runs/folders)
                        # from its sidecar so re-render has the whole conversation.
                        try:
                            rec = _load_thread_rec(state_dir, tkey)
                        except StoreUnavailableError as exc:
                            # Битый сайдкар: НЕ подменяем пустой записью (потеряли бы
                            # накопленные сообщения) и не валим остальные треды —
                            # изолируем тред, считаем, оставляем сообщение на повтор.
                            broken_threads.add(tkey)
                            stats.thread_store_errors += 1
                            refuse("mail", "error", source_id=str(tkey))
                            if len(stats.reject_examples) < 5:
                                stats.reject_examples.append(f"{tkey}: {exc.reason[:80]}")
                            logger.error("[mail] сайдкар треда %s нечитаем: %s", tkey, exc)
                            continue
                        rec.setdefault("conversationId", str(m.get("conversationId") or "").strip())
                        rec.setdefault("subject", "")
                        if facc:
                            rec.setdefault("account", facc)  # ящик треда - в сайдкаре и заметке
                        batch_recs[tkey] = rec
                    rec = batch_recs[tkey]
                    date = str(msg.get("date") or m.get("date") or "")
                    # FULL body — no quote-stripping (per-thread already removes
                    # fragmentation; exact dup blocks are collapsed only at render).
                    text = str(msg.get("body") or "").strip()
                    to_str = str(msg.get("to") or "")
                    cc_str = str(msg.get("cc") or "")
                    chash = hashlib.sha1(f"{date}|{frm}|{text}".encode()).hexdigest()  # noqa: S324 — content hash (identity/dedup), not security
                    from core.mail_attachments import attachment_names

                    attachments = attachment_names(msg.get("attachments"))
                    # Имена не доказывают равенство вложений в разных письмах.
                    if not attachments and any(
                        mm.get("hash") == chash and not mm.get("attachments")
                        for mm in rec["messages"].values()
                    ):
                        stats.duplicate += 1
                        continue
                    rec["messages"][eid] = {
                        "date": date, "from": frm, "to": to_str, "cc": cc_str,
                        "is_me": _sender_is_me(frm, self_tokens),
                        "text": text, "bucket": bk, "hash": chash,
                        "attachments": attachments,
                        **({"account": facc} if facc else {}),
                        # MAIL-THREAD-1: тема САМОГО сообщения — по ней определяется
                        # родной тред при ремонте и считается детект склейки.
                        "subject": str(msg.get("subject") or m.get("subject") or "").strip(),
                    }
                    if not rec.get("subject"):
                        rec["subject"] = str(msg.get("subject") or m.get("subject") or "").strip()
                    stats.msgs_added += 1
            _flush_threads(
                batch_recs, index=index, included=included, prev_keys=prev_keys,
                rendered=rendered, owner_domains=owner_domains,
                self_tokens=self_tokens, stats=stats, vault_path=vault_path,
                state_dir=state_dir, manifest_path=manifest_path, run_id=run_id,
            )
            memory.save()
        else:
            if explain_privacy is not None:
                _explain_privacy_batch(bridge, batch, stats, explain_privacy)
            # Preview: count messages + threads, no fetch, no write.
            for _fn, _bk, m in batch:
                tkey = eid_thread[str(m.get("entryID") or "")]
                stats.msgs_added += 1
                if tkey not in rendered:
                    rendered.add(tkey)
                    if tkey in prev_keys:
                        stats.changed += 1
                    else:
                        stats.new += 1

        elapsed = time.perf_counter() - start
        eta = _fmt_eta(elapsed / consumed * (total_msgs - consumed)) if consumed else "?"
        beacon.update(
            len(rendered),
            {"msgs": stats.msgs_added},
            line=f"[mail] {len(rendered)}/{total_threads} threads | "
            f"msgs {stats.msgs_added} | ~{eta}",
        )
        if stop():
            stopped = True
            stats.stopped = True
            break

    stats.notes_total = len(rendered)
    if explain_privacy is not None and dry_run:
        _explain_privacy_summary(stats, explain_privacy)
    beacon.update(
        len(rendered),
        {"msgs": stats.msgs_added},
        line=f"[mail] {len(rendered)}/{total_threads} threads | msgs {stats.msgs_added} | "
        f"{'stopped' if stopped else 'done'}",
    )
    # Остановка сигналом оставляет маяк незавершённым → interrupted в activity
    # (прогресс уже слит батчами, повторный запуск продолжит с курсора).
    if not stopped:
        beacon.done(f"{len(rendered)} threads, {stats.msgs_added} msgs")
    _count_bridge_calls()  # листинги + fetch тел
    stats.elapsed_s = time.perf_counter() - start
    return stats
