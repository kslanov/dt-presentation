"""INGEST-SAFETY-1 п.1 — поле ``root`` в записях манифеста слоя: кто «свой», миграция, снимок.

Манифест слоя (``legacy_ingest_manifest.json`` / ``current_ingest_manifest.json``) один на слой,
а корней в слое может быть несколько. Раньше prune прогона удалял каждую запись слоя, которой нет
в ЭТОМ прогоне, - прогон корня A стирал заметки корня B. Теперь запись несет ``root`` - метку
корня, чьим прогоном она создана (имя из ``_system/ingest-roots.yaml`` либо ``legacy:<путь>`` для
``DT_LEGACY_ROOTS``), и прогон удаляет ТОЛЬКО записи своего корня.

Кто «свой» для записи (``ownership``):

* ``own``   - ``root`` входит в метки корней прогона: прогон вправе обновить и удалить;
* ``unowned`` - ``root == "?"`` (владелец не определен миграцией) либо метки нет в конфиге слоя
  (корень убран/переименован): НЕ удаляется никем, но по совпадению байт может быть перенесена
  (relocation) или усыновлена прогоном с тем же ключом - заметка остается жить;
* ``foreign`` - ``root`` - другой НАСТРОЕННЫЙ корень слоя: прогон его не трогает (ни prune, ни
  relocation; одинаковые байты - «дубликат», одинаковый ключ - ``collision``).

Миграция (:func:`migrate_roots`) - одноразовая и идемпотентная: записям без поля ``root`` метка
ставится по тому, под каким корнем лежит исходник (``source_path`` относится к корню - или к
родителю корня-эпохи ``YYYY-YYYY``, как в ``discover.file_metadata``); один кандидат в слое
забирает и записи с исчезнувшим исходником, при двух и более такие получают ``"?"``. Запись с уже
выставленным ``root`` не меняется (повтор - байт-в-байт), ``"?"`` пытаемся уточнить только по
совпадению файла.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import current_ingest_manifest_path, legacy_ingest_manifest_path
from core.legacy.discover import _ERA_RE, legacy_root_label

logger = logging.getLogger(__name__)

__all__ = [
    "ROOT_FIELD",
    "UNKNOWN_ROOT",
    "MigrationReport",
    "SNAPSHOT_KEEP",
    "assign_roots",
    "layer_candidates",
    "layer_manifest_path",
    "migrate_roots",
    "snapshot_manifest",
]

ROOT_FIELD = "root"
UNKNOWN_ROOT = "?"
SNAPSHOT_KEEP = 5  # снимков манифеста слоя рядом (п.3 ТЗ)

Candidate = tuple[str, Path]  # (метка корня, путь корня)


def layer_manifest_path(layer: str) -> Path:
    return current_ingest_manifest_path() if layer == "current" else legacy_ingest_manifest_path()


# --------------------------------------------------------------------------- #
# Кандидаты слоя                                                              #
# --------------------------------------------------------------------------- #


def layer_candidates(
    layer: str, vault_path: Path | None = None, extra: list[Candidate] | None = None
) -> list[Candidate]:
    """Корни слоя: знаниевые корни ``ingest-roots.yaml`` с ``corpus == layer`` и (для legacy)
    ``DT_LEGACY_ROOTS`` + ``extra`` (корни этого прогона). Метка - ключ: повтор не дублируется,
    ``extra`` перекрывает путь той же метки."""
    from core.config import legacy_roots
    from core.file_ingest.config import ROUTE_KNOWLEDGE, load_ingest_roots

    out: dict[str, Path] = {}
    try:
        for root in load_ingest_roots(vault_path):
            if root.route == ROUTE_KNOWLEDGE and root.corpus == layer:
                out[root.name] = Path(root.path)
    except Exception:  # noqa: BLE001 - конфиг корней не должен ронять прогон: берем то, что есть
        logger.debug("layer_candidates: ingest-roots не прочитался", exc_info=True)
    if layer == "legacy":
        for p in legacy_roots():
            out.setdefault(legacy_root_label(p), Path(p))
    for label, path in extra or []:
        out[label] = Path(path)
    return list(out.items())


# --------------------------------------------------------------------------- #
# Назначение метки                                                            #
# --------------------------------------------------------------------------- #


def _base_of(root: Path) -> Path:
    """База ``source_path``: корень-эпоха ``YYYY-YYYY`` - родитель корня (как в discover)."""
    resolved = root.resolve()
    return resolved.parent if _ERA_RE.match(resolved.name) else resolved


def _owners_by_file(source_path: str, candidates: list[Candidate]) -> list[str]:
    hits: list[str] = []
    for label, path in candidates:
        try:
            if (_base_of(path) / source_path).is_file():
                hits.append(label)
        except OSError:
            continue
    return hits


def assign_roots(
    manifest: dict[str, dict[str, Any]], candidates: list[Candidate]
) -> tuple[int, int]:
    """Проставить ``root`` записям без метки (на месте). → ``(назначено, из них '?')``.

    Запись с меткой не меняется; запись ``"?"`` уточняется, только если ее исходник нашелся ровно
    под одним кандидатом (счетчик «назначено» ее не включает, если метка осталась ``"?"``).
    """
    migrated = unknown = 0
    sole = candidates[0][0] if len(candidates) == 1 else None
    for sp, entry in manifest.items():
        current = entry.get(ROOT_FIELD)
        if current and current != UNKNOWN_ROOT:
            continue
        hits = _owners_by_file(sp, candidates)
        if len(hits) == 1:
            label = hits[0]
        elif not current and not hits and sole is not None:
            label = sole  # единственный корень слоя владеет и записью с исчезнувшим исходником
        else:
            label = UNKNOWN_ROOT
        if current == UNKNOWN_ROOT and label == UNKNOWN_ROOT:
            continue  # без изменений (идемпотентность)
        entry[ROOT_FIELD] = label
        migrated += 1
        unknown += label == UNKNOWN_ROOT
    return migrated, unknown


# --------------------------------------------------------------------------- #
# Снимок манифеста                                                            #
# --------------------------------------------------------------------------- #


def snapshot_manifest(path: Path, layer: str, *, keep: int = SNAPSHOT_KEEP) -> Path | None:
    """Копия манифеста слоя рядом: ``manifest_backup_<layer>_<ts>.json`` (последние ``keep``).

    Нет файла манифеста → ``None`` (снимать нечего). Копия байт-в-байт, прежний манифест не
    трогается; лишние старые снимки этого слоя удаляются."""
    path = Path(path)
    if not path.is_file():
        return None
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ")
    target = path.parent / f"manifest_backup_{layer}_{stamp}.json"
    tmp = target.with_suffix(".json.tmp")
    tmp.write_bytes(path.read_bytes())
    os.replace(tmp, target)
    old = sorted(path.parent.glob(f"manifest_backup_{layer}_*.json"))
    for stale in old[:-keep] if keep > 0 else old:
        stale.unlink(missing_ok=True)
    return target


# --------------------------------------------------------------------------- #
# Миграция                                                                    #
# --------------------------------------------------------------------------- #


@dataclass
class MigrationReport:
    layer: str
    total: int = 0
    migrated: int = 0  # записей, которым в этом вызове поставлена/уточнена метка
    unknown: int = 0  # из них получили '?'
    already: int = 0  # записей, у которых метка уже была и не изменилась
    by_root: dict[str, int] = field(default_factory=dict)  # итог ПОСЛЕ миграции
    backup: str = ""
    dry_run: bool = True
    manifest_path: str = ""

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


def migrate_roots(
    layer: str,
    candidates: list[Candidate],
    *,
    apply: bool = False,
    manifest_path: Path | None = None,
) -> MigrationReport:
    """Одноразовая миграция поля ``root`` манифеста слоя. Dry-run по умолчанию (ничего не пишет).

    ``--apply``: снимок манифеста рядом, затем запись (атомарно). Повтор на мигрированном
    манифесте - ``migrated == 0``, файл не переписывается, снимок не создается."""
    from core.legacy.ingest import _load_manifest, _save_manifest

    path = manifest_path or layer_manifest_path(layer)
    manifest = _load_manifest(path)
    report = MigrationReport(layer=layer, total=len(manifest), dry_run=not apply,
                             manifest_path=str(path))
    report.migrated, report.unknown = assign_roots(manifest, candidates)
    report.by_root = manifest_roots_summary(manifest)
    report.already = report.total - report.migrated
    if apply and report.migrated:
        snap = snapshot_manifest(path, layer)
        report.backup = str(snap) if snap else ""
        _save_manifest(path, manifest)
    return report


def manifest_roots_summary(manifest: dict[str, dict[str, Any]]) -> dict[str, int]:
    """``{метка: записей}`` по манифесту (``"?"`` - без владельца; нет поля - тоже ``"?"``)."""
    out: dict[str, int] = {}
    for entry in manifest.values():
        label = str(entry.get(ROOT_FIELD) or UNKNOWN_ROOT)
        out[label] = out.get(label, 0) + 1
    return out

