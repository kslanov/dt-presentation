"""INGEST-SAFETY-1 п.3 — гард массового удаления заметок ingest'ом.

Prune удаляет заметки, чей исходник «исчез» из обхода. Исчезнуть могло и по-настоящему, и из-за
сбоя среды (диск не примонтировался, iCloud отдал заглушки, include/exclude сузили корень):
обход тогда пуст, а манифест верит ему больше, чем диску. Гард ловит масштаб: если прогон
собирается удалить БОЛЬШЕ ``DT_INGEST_PRUNE_MAX_PCT`` процентов записей корня (умолчание 20) И
БОЛЬШЕ ``DT_INGEST_PRUNE_MIN_N`` штук (умолчание 20) - НЕ удаляет, пишет отказ ``prune_guard`` и
оставляет метку-состояние (ее читает доктор: «последний прогон корня уперся в гард»). Снимает
гард явный ``allow_prune`` на ОДИН прогон (CLI ``--allow-prune``).

Метка-состояние - ``.derived/ingress/prune_guard.json`` ``{слой: {корень: {...}}}``: пишется при
срабатывании, снимается следующим прогоном корня, которому гард не помешал (удалил в пределах
порога / по ``allow_prune`` / удалять нечего). Dry-run ничего не пишет, но видит срабатывание.

Формат отказа в журнале (причина ``prune_guard``, политика ``guard``): ``hint`` =
``<корень>: <n> из <всего> (<pct>%) - <первые 5 путей через "; ">``, ``source_id`` =
``prune_guard:<слой>:<корень>``. Пути под NDA-барьером в строку не попадают.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import ingress_dir

logger = logging.getLogger(__name__)

__all__ = [
    "DEFAULT_MAX_PCT",
    "DEFAULT_MIN_N",
    "clear_trip",
    "evaluate",
    "max_pct",
    "min_n",
    "read_trips",
    "record_trip",
    "state_path",
    "trips_since",
]

DEFAULT_MAX_PCT = 20.0
DEFAULT_MIN_N = 20
PATHS_IN_REPORT = 5


def max_pct() -> float:
    """Порог доли удаляемых записей корня, % (``DT_INGEST_PRUNE_MAX_PCT``, умолчание 20)."""
    raw = (os.environ.get("DT_INGEST_PRUNE_MAX_PCT") or "").strip()
    try:
        value = float(raw)
    except ValueError:
        return DEFAULT_MAX_PCT
    return value if 0 <= value <= 100 else DEFAULT_MAX_PCT


def min_n() -> int:
    """Порог числа удаляемых записей (``DT_INGEST_PRUNE_MIN_N``, умолчание 20)."""
    raw = (os.environ.get("DT_INGEST_PRUNE_MIN_N") or "").strip()
    return int(raw) if raw.isdigit() else DEFAULT_MIN_N


def state_path() -> Path:
    return ingress_dir() / "prune_guard.json"


def evaluate(root: str, doomed_paths: list[str], total: int) -> dict[str, Any] | None:
    """Срабатывает ли гард для корня: ``len(doomed) > max_pct% от total`` И ``> min_n``.

    ``None`` - не сработал; иначе сведения для отказа/состояния (первые пять путей без NDA)."""
    n = len(doomed_paths)
    if not n or not total:
        return None
    pct = 100.0 * n / total
    if not (pct > max_pct() and n > min_n()):
        return None
    from core.privacy import is_eval, is_nda

    shown = [p for p in sorted(doomed_paths) if not is_nda(p) and not is_eval(p)]
    return {
        "root": root, "n": n, "total": total, "pct": round(pct, 1),
        "max_pct": max_pct(), "min_n": min_n(), "paths": shown[:PATHS_IN_REPORT],
    }


def hint_of(trip: dict[str, Any]) -> str:
    """Подсказка строки журнала отказов (см. модуль)."""
    paths = "; ".join(trip.get("paths", []))
    return f"{trip['root']}: {trip['n']} из {trip['total']} ({trip['pct']}%) - {paths}"[:240]


# --------------------------------------------------------------------------- #
# Состояние                                                                   #
# --------------------------------------------------------------------------- #


def _read(path: Path) -> dict[str, dict[str, Any]]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write(path: Path, data: dict[str, dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1, sort_keys=True),
                   encoding="utf-8")
    tmp.replace(path)


def record_trip(layer: str, trip: dict[str, Any], *, run_id: str | None = None) -> None:
    """Запомнить срабатывание (best-effort: учет не ломает прогон)."""
    try:
        data = _read(state_path())
        data.setdefault(layer, {})[trip["root"]] = {
            **trip, "ts": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            **({"run_id": run_id} if run_id else {}),
        }
        _write(state_path(), data)
    except Exception:  # noqa: BLE001
        logger.debug("prune_guard: состояние не записано", exc_info=True)


def clear_trip(layer: str, root: str) -> None:
    """Снять метку корня (его прогон прошел без упора в гард). Нет метки - файл не трогаем."""
    try:
        data = _read(state_path())
        if root not in data.get(layer, {}):
            return
        data[layer].pop(root, None)
        if not data[layer]:
            data.pop(layer)
        _write(state_path(), data)
    except Exception:  # noqa: BLE001
        logger.debug("prune_guard: метка не снята", exc_info=True)


def read_trips(path: Path | None = None) -> list[dict[str, Any]]:
    """Все действующие срабатывания: ``[{layer, root, n, total, pct, paths, ts, ...}]``."""
    out: list[dict[str, Any]] = []
    for layer, roots in sorted(_read(path or state_path()).items()):
        for root, info in sorted((roots or {}).items()):
            if isinstance(info, dict):
                out.append({"layer": layer, **info, "root": root})
    return out


def trips_since(moment: datetime, roots: set[str] | None = None) -> list[dict[str, Any]]:
    """Срабатывания не раньше ``moment`` (скан отдает их в итог); ``roots`` - только эти корни."""
    stamp = moment.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    return [t for t in read_trips()
            if str(t.get("ts", "")) >= stamp and (roots is None or t["root"] in roots)]
