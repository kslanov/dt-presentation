"""INGEST-SAFETY-1 п.7 — сверка входа с диском по корням (доктор «Вход: сверка с диском» и пульт).

Доктор «Вход: источники» считал прогоны и отказы, но не сравнивал «что вошло» с «что лежит в
vault»: потеря 513 из 623 заметок была невидима. По каждому корню слоя сверяем три числа:

* ``processed`` - файлов, прошедших скан ``file_ingest`` (манифест скана, записи корня; у корней
  ``DT_LEGACY_ROOTS`` скана нет - ``None``);
* ``entries``   - записей манифеста слоя с ``root`` этого корня;
* ``notes``     - из них заметок, реально лежащих в vault на диске.

``warn``: заметок меньше записей (запись есть, заметки нет) либо есть записи ``root: "?"`` (владелец
не определен - ни один прогон их не удалит); ``fail``: последний прогон корня упёрся в гард
массового удаления (метка :mod:`core.legacy.prune_guard`). Только чтение.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.legacy.manifest_roots import ROOT_FIELD, UNKNOWN_ROOT, layer_candidates

__all__ = ["Reconcile", "RootRecon", "reconcile"]

LAYERS = ("current", "legacy")


@dataclass
class RootRecon:
    layer: str
    root: str
    path: str = ""
    processed: int | None = None
    entries: int = 0
    notes: int = 0

    @property
    def missing(self) -> int:
        """Записей манифеста, чьей заметки нет на диске."""
        return max(0, self.entries - self.notes)

    def to_dict(self) -> dict[str, Any]:
        return {**self.__dict__, "missing": self.missing}


@dataclass
class Reconcile:
    roots: list[RootRecon] = field(default_factory=list)
    unknown: dict[str, int] = field(default_factory=dict)  # слой -> записей root "?"
    trips: list[dict[str, Any]] = field(default_factory=list)  # метки prune_guard
    unreadable: list[str] = field(default_factory=list)  # манифесты, которые не прочитались

    def for_root(self, root: str) -> RootRecon | None:
        return next((r for r in self.roots if r.root == root), None)


def _processed_by_root() -> dict[str, int]:
    """Файлов в манифесте скана по имени корня (знаниевый маршрут)."""
    from core.config import file_ingest_manifest_path
    from core.file_ingest.manifest import load_manifest

    out: dict[str, int] = {}
    for entry in load_manifest(file_ingest_manifest_path()).values():
        if entry.get("route") != "knowledge":
            continue
        paths = entry.get("paths")
        out[str(entry.get("root") or "")] = out.get(str(entry.get("root") or ""), 0) + (
            len(paths) if isinstance(paths, list) else 1
        )
    return out


def reconcile(vault_path: Path | None = None) -> Reconcile:
    """Сверка по корням обоих слоев (корни из конфига + метки, уже стоящие в манифестах)."""
    from core.adapters import AdapterError
    from core.config import default_vault_path
    from core.legacy.ingest import _load_manifest
    from core.legacy.manifest_roots import layer_manifest_path
    from core.legacy.prune_guard import read_trips

    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    out = Reconcile(trips=read_trips())
    try:
        processed = _processed_by_root()
    except AdapterError:
        processed = {}
        out.unreadable.append("file_ingest_manifest")
    for layer in LAYERS:
        cands = dict(layer_candidates(layer, vault))
        try:
            manifest = _load_manifest(layer_manifest_path(layer))
        except AdapterError:
            out.unreadable.append(f"{layer}_ingest_manifest")
            continue
        rows: dict[str, RootRecon] = {
            label: RootRecon(layer, label, str(path),
                             processed.get(label) if layer == "current" or label in processed
                             else None)
            for label, path in cands.items()
        }
        unknown = 0
        for entry in manifest.values():
            label = str(entry.get(ROOT_FIELD) or UNKNOWN_ROOT)
            if label == UNKNOWN_ROOT:
                unknown += 1
                continue
            row = rows.setdefault(label, RootRecon(layer, label, processed=processed.get(label)))
            if not entry.get("note_path"):
                continue
            row.entries += 1
            row.notes += (vault / str(entry["note_path"])).is_file()
        if unknown:
            out.unknown[layer] = unknown
        out.roots.extend(sorted(rows.values(), key=lambda r: r.root))
    return out
