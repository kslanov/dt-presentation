"""Render layer-B legacy notes into the vault (ТЗ phase5, layer B, stage 4).

Turns a discovered source + its extraction record into a markdown note under
``vault/_legacy/<era>/<section>/<client>/<slug>.md``: frontmatter marking it as
``corpus: legacy``, ``curated: false``, ``status: raw`` with provenance, plus the
normalized body (preamble + ``##`` units) from :mod:`core.legacy.normalize`.

Deterministic, no LLM. The render writes ONLY data-signals (client, section,
source provenance, body) — never ``links`` frontmatter or ``[[hub]]`` wikilinks:
связывание — отдельный перезапускаемый проход ``core/linking`` (Phase 9),
который читает эти сигналы из заметок без переимпорта. Writing a note here does
not index it; the normal ``dt_index`` pass picks ``_legacy/*.md`` up afterwards.
"""

from __future__ import annotations

import hashlib
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from core.ingress.provenance import stamp_fields
from core.legacy.discover import LegacyFile
from core.vault import Note, write_note

__all__ = [
    "legacy_note_id",
    "slugify",
    "note_relpath",
    "build_note",
    "write_legacy_note",
    "scan_fields",
    "truncation_fields",
    "LEGACY_ROOT",
]

# Single root for the whole layer-B corpus inside the vault.
LEGACY_ROOT = "_legacy"

# Minimal RU→Latin transliteration for stable, filesystem-safe slugs.
_TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch", "ъ": "",
    "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
}
_SLUG_STRIP_RE = re.compile(r"[^a-z0-9]+")
_PATH_UNSAFE_RE = re.compile(r"[\\/]+")


def _stable_hash(source_path: str) -> str:
    """12-hex stable digest of a source path (drives the note id + slug suffix)."""
    return hashlib.sha1(source_path.encode("utf-8")).hexdigest()[:12]  # noqa: S324 — content hash (identity/dedup), not security


def legacy_note_id(source_path: str) -> str:
    """Stable note id ``legacy-<hash(source_path)>`` — survives renames of label."""
    return f"legacy-{_stable_hash(source_path)}"


def _transliterate(text: str) -> str:
    return "".join(_TRANSLIT.get(ch, ch) for ch in text.lower())


def slugify(text: str) -> str:
    """Filesystem-safe, stable slug from arbitrary text (RU transliterated)."""
    slug = _SLUG_STRIP_RE.sub("-", _transliterate(text)).strip("-")
    return slug


def _safe_dir(component: str) -> str:
    """Sanitize a path component for a directory name (keep it human-readable)."""
    return _PATH_UNSAFE_RE.sub("-", component).strip().strip(".") or "_"


def note_relpath(lf: LegacyFile) -> Path:
    """Note path relative to the vault: ``_legacy/<era>/<section>/<client>/<slug>.md``.

    Empty era/section/client levels are dropped. The slug is the transliterated
    filename stem plus a short stable hash so two sources sharing a stem in the
    same folder never collide and the name is reproducible across runs.
    """
    parts = [LEGACY_ROOT]
    for level in (lf.era, lf.section, lf.client):
        if level:
            parts.append(_safe_dir(level))
    stem = Path(lf.filename).stem
    base = slugify(stem)
    suffix = _stable_hash(lf.source_path)[:8]
    slug = f"{base}-{suffix}" if base else f"legacy-{suffix}"
    parts.append(f"{slug}.md")
    return Path(*parts)


def _created_date(mtime: float) -> str:
    """Source mtime → ``YYYY-MM-DD`` (the note's ``created`` date)."""
    return datetime.fromtimestamp(mtime).strftime("%Y-%m-%d")


_H1_RE = re.compile(r"^#[ \t]+(\S.*?)[ \t#]*$")
_FENCE_RE = re.compile(r"^\s*(```|~~~)")
#: источники, чьи ячейки/текст - markdown: первый H1 из них годится в заголовок заметки
_MARKDOWN_TYPES = frozenset({"md", "markdown", "ipynb"})


def _first_h1(record: dict[str, Any]) -> str:
    """Первый H1 (``# Заголовок``) markdown-источника вне блоков кода либо ``""``."""
    if str(record.get("source_type") or "") not in _MARKDOWN_TYPES:
        return ""
    for unit in record.get("units") or []:
        fenced = False
        for line in str(unit.get("text") or "").splitlines():
            if _FENCE_RE.match(line):
                fenced = not fenced
                continue
            match = None if fenced else _H1_RE.match(line)
            if match:
                return match.group(1).strip()
    return ""


def truncation_fields(record: dict[str, Any]) -> dict[str, Any]:
    """KIT-FIT-1 п.11: обрезка ячеек xlsx при входе - во frontmatter (``truncated_sheets``,
    ``cell_cap``), чтобы потеря покрытия была видна у самой заметки, а не только в кэше
    экстракции. Пусто, если ничего не обрезано."""
    meta = record.get("meta") or {}
    sheets = [str(x) for x in (meta.get("truncated_sheets") or []) if str(x).strip()]
    if not sheets:
        return {}
    out: dict[str, Any] = {"truncated_sheets": sheets}
    if isinstance(meta.get("cell_cap"), int):
        out["cell_cap"] = meta["cell_cap"]
    return out


def source_title(lf: LegacyFile, record: dict[str, Any]) -> str:
    """Заголовок заметки по источнику (KIT-FIT-1 п.8): тема письма, иначе первый H1 markdown,
    иначе имя файла без расширения. Детерминирован; заголовок - только из самого источника."""
    meta = record.get("meta") or {}
    subject = " ".join(str(meta.get("subject") or "").split())
    if subject and str(record.get("source_type") or "") in ("eml", "msg", "email"):
        return subject
    return _first_h1(record) or Path(lf.filename).stem


def _frontmatter(
    lf: LegacyFile, record: dict[str, Any], *, corpus: str = "legacy"
) -> dict[str, Any]:
    """Build the layer-B frontmatter dict — data-signals only, no ``links``.

    ``corpus`` (CORPUS-INGEST-CURRENT) sets the layer: ``legacy`` (archive, default)
    or ``current`` (live curated root). It stays raw source either way
    (``curated: false``, ``status: raw``) — only the layer differs, which drives the
    retrieval boost (CORPUS-LAYER-1).
    """
    tags = [corpus]
    for label in (lf.section, lf.client):
        slug = slugify(label) if label else ""
        if slug:
            tags.append(slug)

    note_id = legacy_note_id(lf.source_path)
    fm: dict[str, Any] = {
        "id": note_id,
        # KIT-FIT-1 п.9: ссылки ``[[legacy-<hash12>]]`` пишет весь движок (MOC, обратные, связанные,
        # источники синтеза), а файл называется ``<slug>-<hash8>.md``: Obsidian находит заметку
        # по алиасу. aliases не входит ни в текст чанка, ни в колонки индекса - переэмбеддинга нет
        "aliases": [note_id],
        "type": "legacy-source",
        "corpus": corpus,
        "curated": False,
        "status": "raw",
        "source_path": lf.source_path,
        # Byte-hash of the file (INGEST-DEDUP): path-independent identity so a moved
        # corpus is recognised, not re-imported. Empty when the caller didn't supply
        # one (e.g. mail ingest builds a record from a live message, not a file).
        "source_content_hash": record.get("source_content_hash", ""),
        "source_type": record.get("source_type", lf.ext.lstrip(".")),
        "era": lf.era,
        "client": lf.client,
        "section": lf.section,
        # KIT-FIT-1 п.8: ``title`` - из источника; ``created`` НЕ трогаем (это дата заметки: mtime
        # файла на момент рендера, на нее опираются потребители), дата самого документа -
        # ``source_date`` (из метаданных источника, если они есть)
        "title": source_title(lf, record),
        "created": _created_date(lf.mtime),
        "source_date": str((record.get("meta") or {}).get("doc_date") or ""),
        **truncation_fields(record),
        "tags": tags,
        # INGRESS-1 п.3: единый провенанс входа (source/source_id/ingested/ingress_run) — рядом с
        # прежними ``source_path``/``source_content_hash``; читает ``core.ingress.provenance``.
        **stamp_fields("files", lf.source_path),
    }
    fm.update(scan_fields(lf, record))
    # Drop empties so the frontmatter stays clean (era/client/section may be "").
    return {k: v for k, v in fm.items() if v != "" or k in ("curated",)}


def scan_fields(lf: LegacyFile, record: dict[str, Any]) -> dict[str, Any]:
    """OCR-1: поля скана во frontmatter (пусто для обычных документов).

    * заглушка (``needs_ocr``): ``source_type: pdf-scan``, ``ocr`` (pending|refused|refused_text|
      empty), ``pages``, ``title`` из имени файла;
    * распознанный документ (``source_type: pdf-ocr``): ``ocr: done`` либо ``low`` (средняя
      уверенность ниже ``DT_OCR_MIN_CONF``), ``ocr_engine``, ``ocr_confidence`` 0..1, ``pages``.
    """
    meta = record.get("meta") or {}
    pages = meta.get("pages")
    if record.get("needs_ocr"):
        from core.ocr.state import stub_state

        return {
            "source_type": "pdf-scan",
            "ocr": stub_state(lf.source_path, meta),
            "pages": pages if isinstance(pages, int) else "",
            "title": Path(lf.filename).stem,
        }
    if record.get("source_type") == "pdf-ocr":
        from core.ocr.settings import min_conf

        conf = float(meta.get("ocr_confidence") or 0.0)
        return {
            "ocr": "low" if conf < min_conf() else "done",
            "ocr_engine": str(meta.get("ocr_engine") or ""),
            "ocr_confidence": round(conf, 2),
            "pages": pages if isinstance(pages, int) else "",
            "title": Path(lf.filename).stem,
        }
    return {}


def build_note(
    lf: LegacyFile, record: dict[str, Any], vault_path: Path, *, corpus: str = "legacy"
) -> Note:
    """Assemble the in-memory :class:`Note` for a source (frontmatter + body).

    Data only: ``client``/``section`` идут во frontmatter как сигналы;
    ``[[hub]]``-ссылки проставляет отдельный проход ``core/linking`` (Phase 9).
    ``corpus`` selects the layer (legacy/current — CORPUS-INGEST-CURRENT).
    """
    rel = note_relpath(lf)
    fm = _frontmatter(lf, record, corpus=corpus)
    body = record.get("body", "")
    if record.get("needs_ocr"):
        from core.ocr.state import stub_body

        body = stub_body(fm.get("pages") or None, str(fm.get("ocr") or "pending"))
    return Note(
        id=fm["id"],
        type="legacy-source",
        path=Path(vault_path) / rel,
        frontmatter=fm,
        body=body,
    )


def write_legacy_note(
    lf: LegacyFile, record: dict[str, Any], vault_path: Path, *, corpus: str = "legacy"
) -> Path:
    """Render and write the note to disk; returns its absolute path.

    ``corpus`` (default ``legacy``) sets the note's layer — ``current`` for a live
    curated root (CORPUS-INGEST-CURRENT). The note still lands under ``_legacy/``
    (the layer is defined by frontmatter, not the folder)."""
    note = build_note(lf, record, vault_path, corpus=corpus)
    note.path.parent.mkdir(parents=True, exist_ok=True)
    write_note(note)
    return note.path
