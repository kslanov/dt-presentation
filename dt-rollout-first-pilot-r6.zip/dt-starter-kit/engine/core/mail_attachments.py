"""Reminders for saving originals from mail, reconciled against the file ingest manifests."""

from __future__ import annotations

import fcntl
import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from datetime import UTC, datetime, timedelta
from pathlib import Path

from core.adapters import StoreUnavailableError, load_json_store
from core.config import (
    current_ingest_manifest_path,
    default_vault_path,
    file_ingest_manifest_path,
    legacy_ingest_manifest_path,
    operational_derived_path,
    outlook_ingest_manifest_path,
)
from core.file_ingest.aliases import resolve_alias
from core.file_ingest.config import load_ingest_roots
from core.file_ingest.write_target import WriteTargetError, resolve_write_target
from core.privacy import is_nda
from core.retrieval.fm_cache import load_metas_cached
from core.retrieval.hubcat import build_catalog, match_hubs
from core.retrieval.notemeta import owner_ids

_DOCUMENTS = {
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt",
    ".csv", ".odt", ".ods", ".zip", ".7z", ".dwg", ".dxf", ".vsdx", ".mpp",
}


def attachment_names(values: object) -> list[str]:
    """Keep safe display names from the Outlook bridge. Positions distinguish same-name parts."""
    if not isinstance(values, list):
        return []
    return [
        unicodedata.normalize("NFC", value.strip())
        for value in values
        if isinstance(value, str) and 0 < len(value.strip()) <= 255
        and not re.search(r"[/\\\x00-\x1f\x7f]", value)
        and not is_nda(value)
    ]


def _load(path: Path) -> dict:
    return load_json_store(path, adapter="mail_attachments", expect=dict) or {}


def _key(name: str) -> str:
    return unicodedata.normalize("NFC", name).casefold()


def _folder(hub, vault: Path) -> Path | None:
    if hub is None:
        return None
    aliases = {(alias.root_name, alias.rel_path)
               for name in (hub.note_id, hub.h1, *(n.text for n in hub.names))
               if name and (alias := resolve_alias(name, vault_path=vault)) is not None}
    if len(aliases) != 1:
        return None
    root, rel = next(iter(aliases))
    try:
        target = resolve_write_target(root, rel, vault_path=vault, allow_root=True)
    except WriteTargetError:
        return None
    return target.path if not is_nda(target.path) and target.path.is_dir() else None


def _processed(vault: Path, names: set[str]) -> dict[str, set[str]]:
    """Processed originals in watched roots, indexed by exact normalized basename."""
    paths: dict[str, set[str]] = defaultdict(set)
    roots = [r.path.resolve() for r in load_ingest_roots(vault) if not is_nda(r.path)]

    def add(ref: str, entry: dict) -> None:
        path = Path(ref)
        if _key(path.name) not in names or not path.is_absolute() or is_nda(path):
            return
        # Do not inspect archive trees or paths outside the configured roots.
        if not any(path.is_relative_to(root) for root in roots):
            return
        target = path.resolve()
        if is_nda(target) or not any(target.is_relative_to(root) for root in roots):
            return
        try:
            stat = target.stat()
        except OSError:
            return
        if (stat.st_mtime == entry.get("mtime") and stat.st_size == entry.get("size")
                and target.is_file()):
            paths[_key(path.name)].add(str(target))

    for entry in _load(file_ingest_manifest_path()).values():
        if isinstance(entry, dict) and entry.get("status") == "processed":
            for path in entry.get("paths") or []:
                add(str(path), entry)
    for manifest in (current_ingest_manifest_path(), legacy_ingest_manifest_path()):
        for path, entry in _load(manifest).items():
            if (isinstance(entry, dict) and entry.get("note_path")
                    and not is_nda(entry["note_path"])):
                add(path, entry)
    return paths


def _rows(decisions: dict, now: datetime) -> tuple[list[dict], list[dict]]:
    from core.legacy.mail import _load_thread_rec, _state_dir

    manifest_path = outlook_ingest_manifest_path()
    index = _load(manifest_path)
    entries = [(key, row) for key, row in index.items()
               if isinstance(row, dict) and row.get("has_attachments")]
    if not entries:
        return [], []
    vault = default_vault_path()
    mets, _ = load_metas_cached(vault)
    meta_by_path = {m.path: m for m in mets}
    catalog = [h for h in build_catalog(mets, entities=None) if not is_nda(h.path)]
    hubs = {h.note_id: h for h in catalog}
    titles = {h.note_id: h.h1 or (h.names[0].text if h.names else h.note_id) for h in catalog}
    choices = [{"id": key, "title": title} for key, title in titles.items()]
    threads = {}
    names = set()
    for thread_key, entry in entries:
        note_path = str(entry.get("note_path") or "")
        if note_path not in meta_by_path or is_nda(note_path):
            continue
        thread = _load_thread_rec(_state_dir(manifest_path), thread_key)
        threads[thread_key] = thread
        for msg in thread["messages"].values():
            names.update(_key(n) for n in attachment_names(msg.get("attachments")))
    processed = _processed(vault, names) if names else {}
    folders = {}
    rows = []
    for thread_key, entry in entries:
        note_path = str(entry.get("note_path") or "")
        if thread_key not in threads:
            continue
        thread = threads[thread_key]
        owners = owner_ids(meta_by_path[note_path]) & hubs.keys()
        for message_id, msg in thread["messages"].items():
            for position, name in enumerate(attachment_names(msg.get("attachments"))):
                if Path(name).suffix.casefold() not in _DOCUMENTS:
                    continue
                account = msg.get("account") or entry.get("account") or thread_key
                key = hashlib.sha256(json.dumps([account, message_id, position, name],
                                                ensure_ascii=False).encode()).hexdigest()[:32]
                state = decisions.get(key) or {}
                if state.get("dismissed") or (state.get("snoozed_until") or "") > now.isoformat():
                    continue
                subject = str(msg.get("subject") or entry.get("subject") or "")
                matched = owners or {x.note_id for x in match_hubs(subject, catalog)}
                hub = hubs.get(state.get("hub_id") or (
                    next(iter(matched)) if len(matched) == 1 else ""
                ))
                if not matched and hub is None:
                    continue
                folder = None
                if hub:
                    if hub.note_id not in folders:
                        folders[hub.note_id] = _folder(hub, vault)
                    folder = folders[hub.note_id]
                indexed = processed.get(_key(name), set())
                selected = state.get("file")
                matches = [{"path": p, "processed": True} for p in sorted(indexed)]
                if folder:
                    target = folder / name
                    real = target.resolve()
                    if real == target and str(real) not in indexed and target.is_file():
                        matches.append({"path": str(real), "processed": False})
                selected_here = any(m["path"] == selected for m in matches)
                same_version = selected_here and _stamp(Path(selected)) == state.get("file_stamp")
                if same_version and selected in indexed:
                    continue
                status = ("waiting" if same_version else "choose_hub" if not hub
                          else "match" if matches else "save")
                rows.append({
                    "id": key, "filename": name, "subject": subject, "sender": msg.get("from", ""),
                    "date": msg.get("date", ""), "note_path": note_path, "status": status,
                    "hub": {"id": hub.note_id, "title": titles[hub.note_id]} if hub else None,
                    "folder": str(folder) if folder else "", "matches": matches,
                    "version": int(state.get("version") or 0),
                })
    rows.sort(key=lambda x: (x["date"], x["id"]), reverse=True)
    rows.sort(key=lambda x: x["status"] == "waiting")
    return rows, choices


def _state_path() -> Path:
    return operational_derived_path() / "mail-attachment-decisions.json"


def _stamp(path: Path) -> list[int] | None:
    if is_nda(path) or path.is_symlink():
        return None
    try:
        stat = path.stat()
    except OSError:
        return None
    return [stat.st_mtime_ns, stat.st_size]


def list_reminders(limit: int = 5, offset: int = 0) -> dict:
    try:
        rows, hubs = _rows(_load(_state_path()), datetime.now(UTC))
    except (StoreUnavailableError, OSError):
        return {"ok": False, "error": "Не удалось проверить письма или файловый инджест"}
    start = max(0, offset)
    return {"ok": True, "rows": rows[start:start + max(0, min(limit, 100))],
            "total": len(rows), "actionable": sum(r["status"] != "waiting" for r in rows),
            "hubs": sorted(hubs, key=lambda h: h["title"].casefold()) if limit > 0 else []}


def decide(item_id: str, action: str, value: str, expected_version: int) -> dict:
    path = _state_path()
    now = datetime.now(UTC)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.with_suffix(".lock").open("a") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            states = _load(path)
            rows, hubs = _rows(states, now)
            row = next((r for r in rows if r["id"] == item_id), None)
            if row is None or row["version"] != expected_version:
                return {"ok": False, "error": "Карточка изменилась. Обновите список."}
            state = dict(states.get(item_id) or {})
            if action == "hub" and any(h["id"] == value for h in hubs):
                state["hub_id"] = value
                state.pop("file", None)
            elif action == "file" and any(m["path"] == value for m in row["matches"]):
                stamp = _stamp(Path(value))
                if stamp is None:
                    return {"ok": False, "error": "Файл изменился. Обновите список."}
                state["file"] = value
                state["file_stamp"] = stamp
            elif action == "dismiss":
                state["dismissed"] = True
            elif action == "snooze":
                state["snoozed_until"] = (now + timedelta(days=3)).isoformat()
            else:
                return {"ok": False, "error": "Действие или выбранный файл недоступны"}
            state["version"] = expected_version + 1
            states[item_id] = state
            temp = path.with_suffix(".tmp")
            temp.write_text(json.dumps(states, ensure_ascii=False), encoding="utf-8")
            temp.replace(path)
    except (StoreUnavailableError, OSError):
        return {"ok": False, "error": "Не удалось сохранить решение"}
    return {"ok": True}
