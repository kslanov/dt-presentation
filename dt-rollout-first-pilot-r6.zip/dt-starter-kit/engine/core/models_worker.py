"""RESOURCE-2 — модели живут в дочернем процессе ``dt-models``, а не в демоне.

Зачем. Демон живет сутками, а память драйвера MPS ему неподконтрольна: после ночного reindex
``footprint`` демона - 17 ГБ ``IOAccelerator`` при выгруженных моделях (кэш графов Metal не
чистится ``torch.mps.empty_cache()``), и реранкер в 03:30 получал OOM от остатка. Выгрузить
объект модели из процесса, который держит пульт, MCP и сессии хостов, память не возвращает;
завершить процесс - возвращает всю. Поэтому демон-владелец (``DT_EMBED_OWNER=1``) сам модели не
грузит и ``torch`` не импортирует: эмбеддер и реранкер живут в ОДНОМ воркере, который демон
поднимает лениво по первому запросу и убивает по простою, по росту памяти и по смерти.

Протокол демон ⇄ воркер. Канал - ``socket.socketpair()`` (пара unix-сокетов, пишет только родитель
и воркер, на диске ничего нет), воркер стартует ЧИСТЫМ интерпретатором (``python -m
core.models_worker``: это ``spawn``, не ``fork`` - ``fork`` процесса с потоками и Metal небезопасен,
а ``multiprocessing.spawn`` переимпортировал бы главный модуль демона). Кадр::

    u32 BE длина заголовка | u64 BE длина блоба | заголовок (JSON, UTF-8) | блоб

Заголовок - запрос ``{"op": "embed"|"score"|"state"|"ping"|"shutdown", ...}`` или ответ ``{"ok":
true, ...}`` / ``{"ok": false, "err": <класс>, "message": ...}``; блоб - вектора (float32 little-
endian, форма в заголовке) либо логиты (float64). Тексты идут в заголовке JSON: они уже там, где
их читает loopback ``/internal/embed``. Запросы сериализованы: воркер однопоточный, а у демона
запрос держит замок супервизора - те же очереди, что давал ``RLock`` эмбеддера (MPS не
потокобезопасен).

Первым кадром воркер присылает ``{"op": "ready", "pid", "profile"}`` - профиль устройства/батча
считает он (демон ``torch`` не импортирует, а профиль без него не определить).

Смерть воркера не роняет демон: супервизор видит EOF/обрыв сокета, забирает код выхода и бросает
:class:`WorkerDied`; повтор запроса и CPU-фолбэк решает прокси (:class:`WorkerEmbedder`,
:class:`WorkerReranker`), причина остается в ``fallback_info`` (``kind: worker_died``).
"""

from __future__ import annotations

import atexit
import contextlib
import importlib
import json
import logging
import os
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import weakref
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Any

from core.embeddings import Embedder

if TYPE_CHECKING:
    import numpy as np

logger = logging.getLogger("dt.models_worker")

__all__ = [
    "DEFAULT_BACKEND",
    "ModelsWorker",
    "WorkerDied",
    "WorkerEmbedder",
    "WorkerReranker",
    "WorkerRequestError",
    "get_supervisor",
    "reset_supervisor",
    "worker_enabled",
]

ENABLE_ENV = "DT_MODELS_WORKER"
MAX_GIB_ENV = "DT_MODELS_WORKER_MAX_GIB"
START_TIMEOUT_ENV = "DT_MODELS_WORKER_START_TIMEOUT_S"
DEFAULT_START_TIMEOUT_S = 180.0  # импорт torch + профиль; модель грузится позже, на первом запросе
STOP_GRACE_S = 10.0  # SIGTERM → столько ждем → SIGKILL
FOOTPRINT_EVERY_S = 30.0  # как часто освежать замер footprint воркера (``footprint -p`` дорог)
DEFAULT_BACKEND = "core.models_worker:RealBackend"
_ENGINE_ROOT = Path(__file__).resolve().parent.parent
_HEADER = struct.Struct(">IQ")
_MAX_HEADER = 256 * 1024 * 1024  # потолок на заголовок: тексты до ~8 МБ + запас; защита от мусора

_TRUE = ("1", "true", "yes", "on")

# Формат лога воркера: тот же вид, что у демона (``время уровень [corr] имя: текст``), но без поля
# ``corr_id`` - его ставит фильтр ``core.logging_setup``, а в воркере этого фильтра нет.
# stderr воркера наследован от демона: строки идут в тот же launchd.server.err.log.
WORKER_LOG_FORMAT = "%(asctime)s %(levelname)s [worker] %(name)s: %(message)s"


def worker_enabled() -> bool:
    """``DT_MODELS_WORKER`` (дефолт 1; ``0/false/no/off`` - модели в процессе демона, как до
    RESOURCE-2: аварийный откат). Действует только на демоне-владельце: CLI модели и так грузит
    у себя."""
    raw = (os.environ.get(ENABLE_ENV) or "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


# --------------------------------------------------------------------------- #
# Кадры                                                                         #
# --------------------------------------------------------------------------- #
def _recv_exact(sock: socket.socket, n: int) -> bytes | None:
    """Ровно ``n`` байт; ``None`` - собеседник закрыл канал (EOF) до начала кадра. Обрыв ПОСРЕДИ
    кадра - ``ConnectionError``."""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(1 << 20, n - len(buf)))
        if not chunk:
            if not buf:
                return None
            raise ConnectionError("канал закрыт посреди кадра")
        buf += chunk
    return bytes(buf)


def send_frame(sock: socket.socket, header: dict[str, Any], blob: bytes = b"") -> None:
    raw = json.dumps(header, ensure_ascii=False).encode("utf-8")
    sock.sendall(_HEADER.pack(len(raw), len(blob)) + raw)
    if blob:
        sock.sendall(blob)


def recv_frame(sock: socket.socket) -> tuple[dict[str, Any], bytes] | None:
    """Один кадр ``(заголовок, блоб)``; ``None`` - EOF между кадрами."""
    head = _recv_exact(sock, _HEADER.size)
    if head is None:
        return None
    hlen, blen = _HEADER.unpack(head)
    if hlen > _MAX_HEADER:
        raise ConnectionError(f"заголовок кадра {hlen} байт - канал испорчен")
    raw = _recv_exact(sock, hlen) if hlen else b""
    blob = _recv_exact(sock, blen) if blen else b""
    if raw is None or blob is None:
        raise ConnectionError("канал закрыт посреди кадра")
    header = json.loads(raw.decode("utf-8")) if raw else {}
    if not isinstance(header, dict):
        raise ConnectionError("заголовок кадра - не объект")
    return header, blob


# --------------------------------------------------------------------------- #
# Сторона воркера                                                               #
# --------------------------------------------------------------------------- #
class RealBackend:
    """Настоящие модели воркера: ``BGEEmbedder`` и ``Reranker`` в ОДНОМ процессе, создаются лениво.

    Интерфейс бэкенда (его же реализует подделка в тестах, ``tests/_fake_models_backend.py``):
    ``profile()``, ``embed(texts, batch_size) -> (vectors, info)``, ``score(query, texts)
    -> (logits, info)``, ``state()``, ``release()``, ``shutdown()``."""

    def __init__(self) -> None:
        self._embedder: Any = None
        self._reranker: Any = None

    # -- модели ------------------------------------------------------------------------- #
    def _emb(self) -> Any:
        if self._embedder is None:
            from core.embeddings import BGEEmbedder

            self._embedder = BGEEmbedder(shape_buckets=_buckets_enabled())
        return self._embedder

    def _rr(self) -> Any:
        if self._reranker is None:
            from core.retrieval.rerank import Reranker

            self._reranker = Reranker(shape_buckets=_buckets_enabled())
        return self._reranker

    # -- интерфейс ---------------------------------------------------------------------- #
    def profile(self) -> dict[str, Any]:
        from core import resources
        from core.embeddings import torch_graph_cache_clear_supported

        prof = resources.embed_profile()
        version = _torch_version()
        supported = torch_graph_cache_clear_supported()
        if prof["device"] == "mps" and supported is False:
            logger.warning(
                "[models-worker] torch %s < 2.13: torch.mps.empty_cache() не чистит кэш графов "
                "MPS, память воркера растет с числом форм до его перезапуска (uv sync с "
                "torch>=2.13)", version)
        return {"device": prof["device"], "dtype": prof["dtype"],
                "batch_size": prof["batch_size"], "ram_gib": prof["ram_gib"],
                "tier": prof["tier"], "torch": version, "graph_cache_clear": supported}

    def embed(self, texts: list[str], batch_size: int | None) -> tuple[np.ndarray, dict[str, Any]]:
        from core import embed_daemon

        emb = self._emb()
        vectors = emb.embed(texts, batch_size=batch_size)
        info = {"model": emb.model_id, "device": emb.device, "dtype": emb.dtype,
                "diag": embed_daemon._diagnostics(emb)}
        return vectors, info

    def score(self, query: str, texts: Sequence[str]) -> tuple[list[float], dict[str, Any]]:
        rr = self._rr()
        logits = rr.score(query, list(texts))
        return logits, {"device": rr.device, "reranker": rr.model_state(),
                        "load_seconds": rr.load_seconds, "fallback": rr.fallback_reason}

    def state(self) -> dict[str, Any]:
        emb = self._embedder.model_state() if self._embedder is not None else {}
        rr = self._reranker.model_state() if self._reranker is not None else {}
        return {
            "embedder": emb.get("state") or "unloaded", "device": emb.get("device") or "",
            "dtype": emb.get("dtype") or "", "loaded_at": emb.get("loaded_at") or "",
            "reranker": (rr.get("state") or "unloaded") if self._reranker is not None else "off",
            "reranker_device": rr.get("device") or "",
            "shapes": self.shapes(),
        }

    def shapes(self) -> int:
        """Сколько уникальных форм тензоров видели модели воркера (счетчик корзин)."""
        total = 0
        for model in (self._embedder, self._reranker):
            if model is not None:
                total += int(getattr(model, "shape_count", 0) or 0)
        return total

    def release(self) -> None:
        """Освободить кэш ускорителя после запроса (идемпотентно; ошибка освобождения - не сбой)."""
        for model in (self._embedder, self._reranker):
            if model is not None:
                with contextlib.suppress(Exception):
                    model.release_cache()

    def shutdown(self) -> None:
        self.release()


def _torch_version() -> str:
    try:
        import torch

        return str(torch.__version__)
    except ImportError:  # без torch профиль все равно отдаем
        return ""


def _buckets_enabled() -> bool:
    """``DT_EMBED_SHAPE_BUCKETS`` (дефолт 1): корзины форм в воркере; ``0`` - отключить."""
    raw = (os.environ.get("DT_EMBED_SHAPE_BUCKETS") or "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


def _load_backend(spec: str) -> Any:
    mod_name, _, attr = spec.partition(":")
    if not mod_name or not attr:
        raise ValueError(f"backend: ожидалось 'модуль:имя', получено {spec!r}")
    return getattr(importlib.import_module(mod_name), attr)()


def _err_header(exc: BaseException) -> dict[str, Any]:
    return {"ok": False, "err": type(exc).__name__, "message": str(exc)[:2000],
            "cache_miss": bool(getattr(exc, "cache_miss", False))}


def serve_loop(sock: socket.socket, backend: Any) -> None:
    """Цикл воркера: кадр запроса → бэкенд → кадр ответа, пока канал не закрыт или не пришел
    ``shutdown``. После каждого ``embed``/``score`` - ``backend.release()`` (кэш графов ускорителя
    не переживает запрос). Исключение бэкенда - ответ ``ok: false`` с классом (процесс живет:
    ошибка модели не равна смерти воркера); авария самого процесса (abort Metal, OOM-kill) -
    именно та смерть, которую ловит демон."""
    import numpy as np

    while True:
        got = recv_frame(sock)
        if got is None:
            return  # родитель закрыл канал или умер: уходим
        req, _blob = got
        op = req.get("op")
        started = time.perf_counter()
        try:
            if op == "embed":
                vectors, info = backend.embed(list(req.get("texts") or []),
                                              req.get("batch_size"))
                backend.release()
                arr = np.ascontiguousarray(vectors, dtype="<f4")
                header = {"ok": True, "shape": [int(arr.shape[0]), int(arr.shape[1])],
                          "ms": int((time.perf_counter() - started) * 1000), **info,
                          "state": backend.state()}
                send_frame(sock, header, arr.tobytes())
            elif op == "score":
                logits, info = backend.score(str(req.get("query") or ""),
                                             list(req.get("texts") or []))
                backend.release()
                arr = np.ascontiguousarray(logits, dtype="<f8")
                header = {"ok": True, "n": int(arr.shape[0]),
                          "ms": int((time.perf_counter() - started) * 1000), **info,
                          "state": backend.state()}
                send_frame(sock, header, arr.tobytes())
            elif op == "state":
                send_frame(sock, {"ok": True, "state": backend.state()})
            elif op == "ping":
                send_frame(sock, {"ok": True, "pid": os.getpid()})
            elif op == "shutdown":
                send_frame(sock, {"ok": True})
                return
            else:
                send_frame(sock, {"ok": False, "err": "bad_op", "message": f"op={op!r}"})
        except (ConnectionError, BrokenPipeError):
            return
        except Exception as exc:  # noqa: BLE001 — ошибка модели уходит в ответ, не убивает воркер
            logger.warning("[models-worker] запрос %s не удался: %s: %s", op,
                           type(exc).__name__, str(exc)[:300])
            with contextlib.suppress(Exception):
                backend.release()
            send_frame(sock, _err_header(exc))


def worker_main(argv: Sequence[str] | None = None) -> int:
    """Точка входа процесса ``dt-models`` (``python -m core.models_worker --fd N``)."""
    import argparse

    ap = argparse.ArgumentParser(prog="dt-models")
    ap.add_argument("--fd", type=int, required=True, help="дескриптор сокета к демону")
    ap.add_argument("--backend", default=DEFAULT_BACKEND)
    ap.add_argument("--device", default="", help="принудительное устройство (после аварий: cpu)")
    args = ap.parse_args(list(argv) if argv is not None else None)

    logging.basicConfig(level=logging.INFO, format=WORKER_LOG_FORMAT, stream=sys.stderr,
                        force=True)
    for noisy in ("httpx", "urllib3", "huggingface_hub", "sentence_transformers", "filelock"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    if args.device:
        # принудительное устройство - явные ручки: побеждают профиль, пробы MPS не будет
        os.environ["DT_EMBED_DEVICE"] = args.device
        os.environ["DT_RERANK_DEVICE"] = args.device
    sock = socket.socket(fileno=args.fd)
    backend = _load_backend(args.backend)

    def _term(_signum: int, _frame: Any) -> None:
        raise SystemExit(0)  # SIGTERM демона: размотать стек → release_cache в finally

    signal.signal(signal.SIGTERM, _term)
    try:
        send_frame(sock, {"op": "ready", "pid": os.getpid(), "profile": backend.profile(),
                          "device_pin": args.device})
        serve_loop(sock, backend)
    except SystemExit:
        pass
    except (ConnectionError, BrokenPipeError):
        pass
    finally:
        with contextlib.suppress(Exception):
            backend.shutdown()  # release_cache перед завершением
        with contextlib.suppress(Exception):
            sock.close()
    return 0


# --------------------------------------------------------------------------- #
# Сторона демона: супервизор                                                    #
# --------------------------------------------------------------------------- #
class WorkerDied(RuntimeError):
    """Воркер умер (или не поднялся) посреди обмена: ``exit_code`` (отрицательный - сигнал),
    ``phase`` - ``start`` | ``request`` | ``idle``."""

    def __init__(self, exit_code: int | None, phase: str, detail: str = "") -> None:
        self.exit_code, self.phase = exit_code, phase
        self.detail = detail
        super().__init__(self.describe())

    def describe(self) -> str:
        if self.exit_code is None:
            how = "код выхода неизвестен"
        elif self.exit_code < 0:
            try:
                name = signal.Signals(-self.exit_code).name
            except ValueError:
                name = f"сигнал {-self.exit_code}"
            how = f"убит сигналом {name} (код {self.exit_code})"
        else:
            how = f"код выхода {self.exit_code}"
        where = {"start": "при старте", "idle": "между запросами"}.get(
            self.phase, "посреди запроса")
        return f"воркер моделей умер {where}: {how}" + (f" ({self.detail})" if self.detail else "")


class WorkerRequestError(RuntimeError):
    """Воркер жив, но модель отказала: ``err`` - класс исключения воркера."""

    def __init__(self, err: str, message: str, cache_miss: bool = False) -> None:
        self.err, self.cache_miss = err, cache_miss
        super().__init__(message)


_LIVE: weakref.WeakSet[ModelsWorker] = weakref.WeakSet()


@atexit.register
def _stop_all_at_exit() -> None:
    """Выход демона: воркеры не остаются сиротами (SIGKILL демона их тоже убирает - EOF сокета)."""
    for sup in list(_LIVE):
        with contextlib.suppress(Exception):
            sup.stop("завершение демона")


def _iso_now() -> str:
    from datetime import UTC, datetime

    return datetime.now(UTC).isoformat(timespec="seconds")


def max_worker_gib() -> float:
    """Порог footprint воркера, ГБ: ``DT_MODELS_WORKER_MAX_GIB``, иначе RAM/2 (неизвестна - 8)."""
    from core import resources

    return resources.models_worker_max_gib()


class ModelsWorker:
    """Супервизор воркера моделей в процессе демона: ленивый старт, один запрос за раз, завершение
    по простою и по росту памяти, учет смертей. Не импортирует ``torch`` и не держит моделей."""

    def __init__(
        self,
        *,
        argv: Sequence[str] | None = None,
        backend: str | None = None,
        extra_pythonpath: Sequence[str] = (),
        footprint_fn: Callable[[int], int | None] | None = None,
        idle_s: float | None = None,
        max_gib: float | None = None,
        start_timeout_s: float | None = None,
        now: Callable[[], float] = time.time,
    ) -> None:
        # Часы - wall clock, не monotonic: на macOS монотонные часы НЕ идут, пока машина спит
        # (CLOCK_MONOTONIC замерзает в сне), и воркер, простоявший ночь, для сторожа «простоял»
        # минуты - найдено на живой приемке RESOURCE-2 (12.11: воркер жив после ~5 ч простоя
        # через сон, idle_stops=0). Простой - понятие календаря, а не процессора.
        self._argv = list(argv) if argv is not None else None
        self._backend = backend or DEFAULT_BACKEND
        self._extra_pp = [str(p) for p in extra_pythonpath]
        self._footprint_fn = footprint_fn
        self._idle_s = idle_s
        self._max_gib = max_gib
        self._start_timeout = start_timeout_s
        self._now = now
        self._lock = threading.Lock()  # один запрос за раз; старт/остановка - под ним же
        # состояние воркера (читается без замка - только для /health)
        self._proc: subprocess.Popen[bytes] | None = None
        self._sock: socket.socket | None = None
        self._pin = ""  # принудительное устройство ЭТОГО воркера ("" - по профилю)
        self.pid: int | None = None
        self.started_wall = ""
        self._started_at: float | None = None
        self._last_used: float | None = None
        self._last_used_wall = ""
        self.profile: dict[str, Any] = {}
        self.state_info: dict[str, Any] = {}
        self._reranker_seen = False
        # счетчики за жизнь супервизора (демона)
        self.starts = 0
        self.deaths = 0
        self.recycles = 0
        self.idle_stops = 0
        self.shapes = 0
        self._incident: dict[str, Any] | None = None  # открытая авария: пока жив пост-аварийный
        self.last_death: dict[str, Any] = {}          # воркер (и дольше - как справка)
        # footprint воркера: последний замер (МБ), момент, идет ли замер; рост выше порога → recycle
        self.footprint: int | None = None
        self._fp_at = 0.0
        self._fp_inflight = False
        self._recycle_pending = ""
        self._monitor: _Monitor | None = None
        _LIVE.add(self)

    # -- конфигурация ------------------------------------------------------------------- #
    def idle_s(self) -> float:
        if self._idle_s is not None:
            return self._idle_s
        from core import embed_daemon

        return embed_daemon.idle_unload_s()

    def max_mb(self) -> float:
        gib = self._max_gib if self._max_gib is not None else max_worker_gib()
        return gib * 1024

    def _start_timeout_s(self) -> float:
        if self._start_timeout is not None:
            return self._start_timeout
        raw = (os.environ.get(START_TIMEOUT_ENV) or "").strip()
        try:
            return float(raw) if raw else DEFAULT_START_TIMEOUT_S
        except ValueError:
            return DEFAULT_START_TIMEOUT_S

    # -- состояние ---------------------------------------------------------------------- #
    @property
    def up(self) -> bool:
        proc = self._proc
        return proc is not None and proc.poll() is None

    def incident(self) -> dict[str, Any]:
        """Открытая авария воркера (``kind: worker_died``), пока жив пост-аварийный воркер."""
        return dict(self._incident) if self._incident else {}

    def snapshot(self) -> dict[str, Any]:
        """``/health.models.worker``: ``{state, pid, started_at, footprint_mb, shapes, recycles,
        deaths, ...}``. Без замка и без запуска воркера; замер footprint освежается в фоне."""
        up = self.up
        if up:
            self._refresh_footprint_async()
        out: dict[str, Any] = {
            "state": "up" if up else "down",
            "pid": self.pid if up else None,
            "started_at": self.started_wall if up else "",
            "footprint_mb": self.footprint if up else None,
            "shapes": self.shapes if up else 0,
            "recycles": self.recycles, "deaths": self.deaths,
            "starts": self.starts, "idle_stops": self.idle_stops,
            "device": (self.profile.get("device") if not self._pin else self._pin) if up else "",
            "torch": self.profile.get("torch", "") if up else "",
            "graph_cache_clear": self.profile.get("graph_cache_clear") if up else None,
        }
        if self.last_death:
            out["last_death"] = dict(self.last_death)
        return out

    def models_state(self) -> dict[str, str]:
        """``embedder``/``reranker`` для ``/health.models`` по состоянию воркера."""
        if not self.up:
            return {"embedder": "unloaded",
                    "reranker": "unloaded" if self._reranker_seen else "off"}
        st = self.state_info
        return {"embedder": str(st.get("embedder") or "unloaded"),
                "reranker": str(st.get("reranker") or "off"),
                "device": str(st.get("device") or ""), "dtype": str(st.get("dtype") or ""),
                "loaded_at": str(st.get("loaded_at") or "")}

    def last_used_wall(self) -> str:
        return self._last_used_wall

    # -- запуск и остановка ------------------------------------------------------------- #
    def _spawn_argv(self, pin: str, fd: int) -> list[str]:
        base = list(self._argv) if self._argv is not None else [
            sys.executable, "-m", "core.models_worker"]
        return [*base, "--fd", str(fd), "--backend", self._backend,
                *(["--device", pin] if pin else [])]

    def _child_env(self) -> dict[str, str]:
        env = dict(os.environ)
        paths = [str(_ENGINE_ROOT), *self._extra_pp]
        if env.get("PYTHONPATH"):
            paths.append(env["PYTHONPATH"])
        env["PYTHONPATH"] = os.pathsep.join(paths)
        env.pop("DT_MODELS_WORKER", None)  # воркер сам по себе - не повод спавнить воркера
        return env

    def _start_locked(self, pin: str) -> None:
        began = time.perf_counter()
        parent, child = socket.socketpair()
        argv = self._spawn_argv(pin, child.fileno())
        try:
            proc = subprocess.Popen(  # noqa: S603 — фиксированный argv, свой интерпретатор
                argv, pass_fds=(child.fileno(),), cwd=str(_ENGINE_ROOT), env=self._child_env(),
                stdin=subprocess.DEVNULL, close_fds=True)
        except OSError as exc:
            parent.close()
            child.close()
            raise WorkerDied(None, "start", f"не запустился: {exc}") from exc
        child.close()
        parent.settimeout(self._start_timeout_s())
        try:
            got = recv_frame(parent)
        except (OSError, ConnectionError, TimeoutError, ValueError) as exc:
            code = self._reap(proc, kill=True)
            parent.close()
            raise WorkerDied(code, "start", f"{type(exc).__name__}") from exc
        if got is None or got[0].get("op") != "ready":
            code = self._reap(proc, kill=False)
            parent.close()
            raise WorkerDied(code, "start", "нет ready")
        parent.settimeout(None)
        header = got[0]
        self._proc, self._sock, self._pin = proc, parent, pin
        self.pid = int(header.get("pid") or proc.pid)
        self.profile = dict(header.get("profile") or {})
        self.state_info = {}
        self.shapes = 0
        self.footprint = None
        self._fp_at = 0.0
        self._recycle_pending = ""
        self.started_wall = _iso_now()
        self._started_at = self._now()
        self._last_used = self._started_at
        self.starts += 1
        logger.info("[models-worker] воркер моделей поднят за %.1f с (pid %s, устройство по %s)",
                    time.perf_counter() - began, self.pid,
                    f"принуждению {pin}" if pin else "профилю")

    def _reap(self, proc: subprocess.Popen[bytes], *, kill: bool) -> int | None:
        """Дождаться конца процесса и вернуть код выхода (``kill`` - добить, если жив)."""
        if kill and proc.poll() is None:
            with contextlib.suppress(OSError):
                proc.kill()
        try:
            return proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            with contextlib.suppress(OSError):
                proc.kill()
            with contextlib.suppress(subprocess.TimeoutExpired):
                return proc.wait(timeout=5)
            return None

    def _drop_dead_locked(self) -> int | None:
        """Воркер умер: забрать код выхода, закрыть канал. Авария остается открытой."""
        proc, sock = self._proc, self._sock
        code = self._reap(proc, kill=True) if proc is not None else None
        if sock is not None:
            with contextlib.suppress(OSError):
                sock.close()
        self._proc = self._sock = None
        self.pid = None
        self._pin = ""
        return code

    def _stop_locked(self, reason: str, *, keep_incident: bool = False) -> bool:
        proc, sock = self._proc, self._sock
        if proc is None:
            return False
        pid, fp = self.pid, self.footprint
        if proc.poll() is None:
            with contextlib.suppress(OSError):
                proc.terminate()
            try:
                proc.wait(timeout=STOP_GRACE_S)
            except subprocess.TimeoutExpired:
                logger.warning("[models-worker] воркер (pid %s) не ушел за %.0f с после SIGTERM - "
                               "SIGKILL", pid, STOP_GRACE_S)
                with contextlib.suppress(OSError):
                    proc.kill()
                with contextlib.suppress(subprocess.TimeoutExpired):
                    proc.wait(timeout=5)
        if sock is not None:
            with contextlib.suppress(OSError):
                sock.close()
        self._proc = self._sock = None
        self.pid = None
        self._pin = ""
        if not keep_incident:  # пост-аварийный воркер ушел: следующий стартует по профилю
            self._incident = None
        logger.info("[models-worker] воркер моделей остановлен (%s; pid %s, footprint %s МБ)",
                    reason, pid, fp if fp is not None else "н/д")
        return True

    def stop(self, reason: str = "остановка") -> bool:
        """Остановить воркер (SIGTERM → 10 с → SIGKILL), если он есть. Ждет идущий запрос."""
        with self._lock:
            return self._stop_locked(reason)

    # -- обмен ---------------------------------------------------------------------------- #
    def request(self, header: dict[str, Any], *, pin_device: str = ""
                ) -> tuple[dict[str, Any], bytes]:
        """Один запрос к воркеру (поднимет его, если нет). ``pin_device`` - принудительное
        устройство: воркер без такого пина перезапускается. Исключения: :class:`WorkerDied` -
        воркер умер, :class:`WorkerRequestError` - модель отказала, воркер жив."""
        with self._lock:
            if self._recycle_pending and self.up:
                self.recycles += 1
                self._stop_locked(self._recycle_pending)
            if self.up and pin_device and self._pin != pin_device:
                self._stop_locked(f"перезапуск на {pin_device}", keep_incident=True)
            if self.proc_dead():
                self._note_idle_death_locked()
            if not self.up:
                self._start_locked(pin_device)
            sock = self._sock
            if sock is None:  # pragma: no cover - _start_locked выставил канал
                raise WorkerDied(None, "start", "нет канала")
            try:
                send_frame(sock, header)
                got = recv_frame(sock)
                if got is None:
                    raise ConnectionError("EOF")
            except (OSError, ConnectionError, ValueError) as exc:
                code = self._drop_dead_locked()
                raise WorkerDied(code, "request", type(exc).__name__) from exc
            resp, blob = got
            self._last_used = self._now()
            self._last_used_wall = _iso_now()
            if not resp.get("ok"):
                raise WorkerRequestError(str(resp.get("err") or "error"),
                                         str(resp.get("message") or ""),
                                         bool(resp.get("cache_miss")))
            state = resp.get("state")
            if isinstance(state, dict):
                self.state_info = state
                self.shapes = int(state.get("shapes") or 0)
                if state.get("reranker") not in (None, "off"):
                    self._reranker_seen = True
            self._after_request_locked()
            return resp, blob

    def _note_idle_death_locked(self) -> None:
        """Воркер умер МЕЖДУ запросами (OOM-kill, ``kill -9``): забрать код, записать смерть."""
        code = self._drop_dead_locked()
        self.note_death(WorkerDied(code, "idle"),
                        retry="следующий запрос поднимет новый воркер по профилю")

    def proc_dead(self) -> bool:
        proc = self._proc
        return proc is not None and proc.poll() is not None

    def note_death(self, died: WorkerDied, *, retry: str) -> dict[str, Any]:
        """Записать смерть воркера: счетчик, лог WARNING и открытая авария (``fallback_info``)."""
        self.deaths += 1
        in_incident = int((self._incident or {}).get("retries") or 0) + 1
        record = {
            "reason": f"{died.describe()}; {retry}"[:400], "at": _iso_now(),
            "kind": "worker_died", "retries": in_incident, "exit_code": died.exit_code,
            "deaths": self.deaths,
        }
        self.last_death = dict(record)
        self._incident = dict(record)
        logger.warning("[models-worker] %s (смертей за жизнь демона: %d)", record["reason"],
                       self.deaths)
        return record

    def known_batch(self) -> int:
        """Батч профиля воркера (для повтора вдвое меньшим); неизвестен - 32."""
        try:
            return max(1, int(self.profile.get("batch_size") or 32))
        except (TypeError, ValueError):
            return 32

    # -- память и простой ------------------------------------------------------------------ #
    def _after_request_locked(self) -> None:
        self._refresh_footprint_async(force=False)

    def _footprint_of(self, pid: int) -> int | None:
        fn = self._footprint_fn
        if fn is None:
            from core import daemon

            fn = daemon.footprint_mb
        return fn(pid)

    def _refresh_footprint_async(self, force: bool = False) -> None:
        pid = self.pid
        if pid is None or self._fp_inflight:
            return
        fresh = self.footprint is not None and self._now() - self._fp_at < FOOTPRINT_EVERY_S
        if fresh and not force:
            return
        self._fp_inflight = True
        threading.Thread(target=self._measure, args=(pid,), daemon=True,
                         name="dt-models-footprint").start()

    def _measure(self, pid: int) -> None:
        try:
            mb = self._footprint_of(pid)
        except Exception:  # noqa: BLE001 — замер - справка, не причина падать
            mb = None
        finally:
            self._fp_inflight = False
        if self.pid != pid:  # воркер уже другой - старый замер не пишем
            return
        self._fp_at = self._now()
        if mb is None:
            return
        self.footprint = int(mb)
        if mb > self.max_mb() and not self._recycle_pending:
            self._recycle_pending = (
                f"footprint {mb / 1024:.1f} ГБ > порога {self.max_mb() / 1024:g} ГБ "
                "(DT_MODELS_WORKER_MAX_GIB): перезапуск между запросами")
            logger.warning("[models-worker] %s", self._recycle_pending)

    def sweep(self) -> str:
        """Один проход сторожа: ``"idle"`` - остановлен по простою, ``"recycle"`` - перезапущен по
        памяти, ``""`` - ничего. Не блокируется: идущий запрос - не простой."""
        if not self._lock.acquire(blocking=False):
            return ""
        try:
            if not self.up:
                if self.proc_dead():
                    self._note_idle_death_locked()
                return ""
            if self._recycle_pending:
                self.recycles += 1
                self._stop_locked(self._recycle_pending)
                return "recycle"
            idle_s = self.idle_s()
            last = self._last_used if self._last_used is not None else self._started_at or 0.0
            if idle_s > 0 and self._now() - last >= idle_s:
                self.idle_stops += 1
                self._stop_locked(f"простой {self._now() - last:.0f} с "
                                  f"(DT_EMBED_IDLE_UNLOAD_S={idle_s:g})")
                return "idle"
        finally:
            self._lock.release()
        self._refresh_footprint_async()
        return ""

    def start_monitor(self, interval: float | None = None) -> _Monitor:
        """Сторож простоя и памяти (поток демона-владельца)."""
        if self._monitor is None:
            idle = self.idle_s()
            every = interval if interval is not None else max(
                1.0, min(30.0, idle / 4 if idle else 30.0))
            self._monitor = _Monitor(self, every)
            self._monitor.start()
        return self._monitor


class _Monitor(threading.Thread):
    def __init__(self, worker: ModelsWorker, interval: float) -> None:
        super().__init__(name="dt-models-monitor", daemon=True)
        self.worker, self.interval = worker, interval
        self._stop_evt = threading.Event()

    def run(self) -> None:
        while not self._stop_evt.wait(self.interval):
            try:
                self.worker.sweep()
            except Exception:  # noqa: BLE001 — сторож не должен умирать
                logger.warning("[models-worker] проход сторожа не удался", exc_info=True)

    def stop(self) -> None:
        self._stop_evt.set()


# --------------------------------------------------------------------------- #
# Единственный супервизор процесса                                              #
# --------------------------------------------------------------------------- #
_supervisor: ModelsWorker | None = None
_supervisor_lock = threading.Lock()


def get_supervisor() -> ModelsWorker:
    """Супервизор процесса (создается при первом обращении; воркер - при первом запросе)."""
    global _supervisor
    if _supervisor is None:
        with _supervisor_lock:
            if _supervisor is None:
                _supervisor = ModelsWorker()
    return _supervisor


def reset_supervisor(instance: ModelsWorker | None = None) -> None:
    """Подменить/сбросить супервизор (тесты): прежний воркер останавливается."""
    global _supervisor
    with _supervisor_lock:
        old, _supervisor = _supervisor, instance
    if old is not None and old is not instance:
        with contextlib.suppress(Exception):
            old.stop("сброс супервизора")
        if old._monitor is not None:
            old._monitor.stop()


# --------------------------------------------------------------------------- #
# Прокси: тот же интерфейс, что у BGEEmbedder / Reranker                        #
# --------------------------------------------------------------------------- #
class WorkerEmbedder(Embedder):
    """Эмбеддер демона-владельца: тот же интерфейс :class:`core.embeddings.Embedder`, вектора
    считает воркер. Авария воркера посреди запроса: новый воркер и ОДИН повтор запроса батчем вдвое
    меньше; повторная смерть - еще один воркер, принудительно на CPU; третья - честная ошибка
    :class:`core.embeddings.EmbeddingModelError`. Причина и счетчик смертей - в ``fallback_info``
    (``kind: worker_died``), без тихих фолбэков."""

    def __init__(self, supervisor: ModelsWorker | None = None) -> None:
        self._sup_override = supervisor
        self._tl = threading.local()
        self._last: dict[str, Any] = {}  # последний ответ воркера: model/device/dtype/diag

    @property
    def _sup(self) -> ModelsWorker:
        return self._sup_override or get_supervisor()

    # -- Embedder ------------------------------------------------------------------------ #
    def embed(self, texts: list[str], batch_size: int | None = None) -> np.ndarray:
        import numpy as np

        from core.embeddings import EMBEDDING_DIM, EmbeddingModelError

        if not texts:
            return np.empty((0, EMBEDDING_DIM), dtype=np.float32)
        sup = self._sup
        self._tl.req = {"oom_retries": 0, "oom_cpu_fallbacks": 0}
        base = int(batch_size) if batch_size else sup.known_batch()
        plan: list[tuple[int | None, str, str]] = [
            (batch_size, "", ""),
            (max(1, base // 2), "", "повтор запроса с батчем вдвое меньше"),
            (max(1, base // 2), "cpu", "повтор запроса на CPU"),
        ]
        last: WorkerDied | None = None
        for attempt, (bs, pin, retry_note) in enumerate(plan):
            if attempt:
                logger.warning("[models-worker] %s: батч %s, устройство %s", retry_note, bs,
                               pin or "по профилю")
            try:
                resp, blob = sup.request({"op": "embed", "texts": texts, "batch_size": bs},
                                         pin_device=pin)
            except WorkerDied as died:
                last = died
                nxt = plan[attempt + 1][2] if attempt + 1 < len(plan) else "попытки исчерпаны"
                sup.note_death(died, retry=nxt)
                continue
            except WorkerRequestError as err:
                raise EmbeddingModelError(str(err)) from err
            return self._finish(resp, blob, len(texts))
        raise EmbeddingModelError(
            f"воркер моделей умер трижды подряд на одном запросе ({last}); CPU-повтор тоже не "
            "помог - см. лог демона (WARNING models-worker) и код выхода")

    def _finish(self, resp: dict[str, Any], blob: bytes, n: int) -> np.ndarray:
        import numpy as np

        from core.embeddings import EMBEDDING_DIM, EmbeddingModelError

        shape = resp.get("shape")
        if shape != [n, EMBEDDING_DIM] or len(blob) != n * EMBEDDING_DIM * 4:
            raise EmbeddingModelError(f"воркер вернул вектора формы {shape}, ожидалось "
                                      f"{[n, EMBEDDING_DIM]}")
        vectors = np.frombuffer(blob, dtype="<f4").reshape(n, EMBEDDING_DIM).astype(
            np.float32, copy=True)
        self._last = {k: resp.get(k) for k in ("model", "device", "dtype", "diag")}
        diag = self._last.get("diag") or {}
        self._tl.req = {"oom_retries": int(diag.get("oom_retries_req", 0)),
                        "oom_cpu_fallbacks": int(diag.get("oom_cpu_fallbacks_req", 0))}
        return vectors

    @property
    def dim(self) -> int:
        from core.embeddings import EMBEDDING_DIM

        return EMBEDDING_DIM

    @property
    def model_id(self) -> str:
        from core.embeddings import MODEL_NAME

        return str(self._last.get("model") or MODEL_NAME)

    @property
    def device(self) -> str:
        return str(self._last.get("device") or self._sup.profile.get("device") or "unknown")

    @property
    def dtype(self) -> str:
        return str(self._last.get("dtype") or self._sup.profile.get("dtype") or "")

    @property
    def fallback_info(self) -> dict[str, Any]:
        """Авария воркера (приоритет) либо фолбэк MPS→CPU ВНУТРИ воркера (его собственная
        причина, ``kind`` oom/error/load)."""
        incident = self._sup.incident()
        if incident:
            return incident
        diag = self._last.get("diag") or {}
        if diag.get("fallback_reason"):
            return {"reason": str(diag["fallback_reason"]),
                    "at": str(diag.get("fallback_at") or ""),
                    "kind": str(diag.get("fallback_kind") or ""),
                    "retries": int(diag.get("fallback_retries") or 0)}
        return {}

    @property
    def fallback_reason(self) -> str:
        return str(self.fallback_info.get("reason") or "")

    @property
    def request_info(self) -> dict[str, int]:
        return dict(getattr(self._tl, "req", {}) or {})

    @property
    def embed_stats(self) -> dict[str, Any]:
        diag = self._last.get("diag") or {}
        out = {k: diag[k] for k in ("oom_retries", "oom_cpu_fallbacks", "batch_size",
                                    "mps_retries", "mps_recovered", "dtype") if k in diag}
        out["worker_deaths"] = self._sup.deaths
        return out

    def model_state(self) -> dict[str, Any]:
        sup = self._sup
        st = sup.models_state()
        return {"state": st.get("embedder", "unloaded"), "device": st.get("device", ""),
                "dtype": st.get("dtype", ""), "loaded_at": st.get("loaded_at", ""),
                "last_used": sup.last_used_wall(), "unloads": sup.idle_stops}

    def unload_if_idle(self, idle_s: float) -> bool:
        """Простой - дело сторожа супервизора (завершает воркер целиком)."""
        return False

    def release_cache(self) -> None:
        """Кэш графов чистит сам воркер после каждого запроса и перед завершением."""
        return None


class WorkerReranker:
    """Реранкер демона-владельца: интерфейс :class:`core.retrieval.rerank.Reranker`
    (``score``/``device``/``loaded``/``load_seconds``/``fallback_reason``/``model_state``), логиты
    считает тот же воркер, что и вектора. Авария воркера: один повтор на новом воркере; вторая -
    :class:`core.retrieval.rerank.RerankUnavailable` (``find_notes`` отдает порядок слияния и
    предупреждение ``rerank_unavailable``)."""

    def __init__(self, supervisor: ModelsWorker | None = None) -> None:
        self._sup_override = supervisor
        self._info: dict[str, Any] = {}
        self.load_seconds: float | None = None
        self.fallback_reason = ""

    @property
    def _sup(self) -> ModelsWorker:
        return self._sup_override or get_supervisor()

    @property
    def device(self) -> str:
        return str(self._info.get("device") or self._sup.profile.get("device") or "unknown")

    @property
    def loaded(self) -> bool:
        return self._sup.models_state().get("reranker") == "loaded"

    @property
    def unloads(self) -> int:
        return self._sup.idle_stops

    def score(self, query: str, texts: Sequence[str]) -> list[float]:
        import numpy as np

        from core.retrieval.rerank import RerankUnavailable

        if not texts:
            return []
        sup = self._sup
        last: WorkerDied | None = None
        for attempt in range(2):
            try:
                resp, blob = sup.request({"op": "score", "query": query, "texts": list(texts)})
            except WorkerDied as died:
                last = died
                sup.note_death(died, retry="повтор запроса реранкера" if attempt == 0
                               else "попытки исчерпаны")
                continue
            except WorkerRequestError as err:
                raise RerankUnavailable(str(err), cache_miss=err.cache_miss) from err
            n = int(resp.get("n") or 0)
            if n != len(texts) or len(blob) != n * 8:
                raise RerankUnavailable(f"воркер вернул {n} оценок на {len(texts)} пар")
            self._info = resp
            self.load_seconds = resp.get("load_seconds")
            self.fallback_reason = str(resp.get("fallback") or "")
            return [float(x) for x in np.frombuffer(blob, dtype="<f8")]
        raise RerankUnavailable(f"воркер моделей умер дважды на одном запросе ({last})")

    def model_state(self) -> dict[str, Any]:
        sup = self._sup
        return {"state": "loaded" if self.loaded else "unloaded", "device": self.device,
                "last_used": sup.last_used_wall(), "unloads": sup.idle_stops}

    def unload_if_idle(self, idle_s: float) -> bool:
        return False


if __name__ == "__main__":  # pragma: no cover - вход воркера
    sys.exit(worker_main())
