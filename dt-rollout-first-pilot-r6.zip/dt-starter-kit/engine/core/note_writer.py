"""SLEEP-STORE-1 - писатель заметки vault: атомарная замена, CAS по sha, квитанция.

Единственный путь записи заметки, которую ведет ledger Сна (:mod:`core.sleep_store.applier`):

* **атомарно** - временный файл рядом с целью, ``fsync``, ``os.replace``, ``fsync`` каталога:
  читатель видит либо прежний файл, либо целиком новый;
* **CAS** - ``expect_sha`` (``None`` - файла быть не должно): если на диске уже другое, запись
  отказывается (``cas_mismatch``), чужая правка не затирается слепо;
* **квитанция** - ``{path, sha_before, sha_after, bytes, created, at}``: по ней восстановитель
  понимает, на каком шаге оборвался предыдущий проход (сверкой sha), а прежнее состояние можно
  вернуть, не трогая посторонние изменения;
* **гарды** - путь относительный, без ``..``, внутри vault (resolve, симлинк-эскейп - отказ), без
  NDA-маркеров (:func:`core.privacy.is_nda`), под заданным префиксом ``allowed_prefix`` (применитель
  сужает запись одним каталогом ``02-knowledge/memory/``: нового верхнего каталога нет).

Предыдущая версия хранится в журнале ledger. Проверка sha и публикация защищены общей
блокировкой по пути (потоки и процессы); вызывающий код может взять ее на всю операцию
read/merge/write. Создание использует link без замены существующего файла. Внешние редакторы,
не использующие блокировку, не входят в этот протокол.

``core`` ⊥ cli/mcp; ни сети, ни модели.
"""

from __future__ import annotations

import contextlib
import hashlib
import os
import tempfile
from pathlib import Path
from typing import Any

from core.file_lock import file_lock
from core.privacy import is_nda

__all__ = ["NoteWriteError", "create_note_atomic", "read_sha", "remove_note_atomic",
           "sha256_bytes", "write_note_atomic"]


class NoteWriteError(RuntimeError):
    """Отказ записи заметки. ``code``: ``bad_path`` | ``nda`` | ``outside`` | ``cas_mismatch``."""

    def __init__(self, code: str, message: str, *, current_sha: str | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.current_sha = current_sha


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_sha(path: Path) -> str | None:
    """sha256 файла или ``None``, если файла нет."""
    try:
        return sha256_bytes(path.read_bytes())
    except FileNotFoundError:
        return None


def _target(vault: Path, rel: str, allowed_prefix: str | None) -> Path:
    raw = str(rel or "").strip()
    rp = Path(raw)
    if not raw or rp.is_absolute() or ".." in rp.parts or raw.endswith("/"):
        raise NoteWriteError("bad_path", f"путь заметки: непустой относительный, не {rel!r}")
    if is_nda(raw):
        raise NoteWriteError("nda", "NDA-путь: запись запрещена")
    if allowed_prefix and not raw.startswith(allowed_prefix):
        raise NoteWriteError("outside", f"запись только под {allowed_prefix}")
    root = Path(vault).resolve()
    target = root / rp
    if target.is_symlink():
        raise NoteWriteError("outside", "цель - симлинк: запись запрещена")
    parent = target.parent
    # самый глубокий существующий предок обязан лежать под корнем vault (симлинк-эскейп)
    probe = parent
    while not probe.exists() and probe != root:
        probe = probe.parent
    if root != probe.resolve() and root not in probe.resolve().parents:
        raise NoteWriteError("outside", "путь выходит за пределы vault")
    return target


def _fsync_dir(directory: Path) -> None:
    with contextlib.suppress(OSError):
        fd = os.open(str(directory), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def write_note_atomic(
    vault: Path, rel: str, text: str, *, expect_sha: str | None, now: str = "",
    allowed_prefix: str | None = None,
) -> dict[str, Any]:
    """Записать заметку ``rel`` под ``vault`` атомарно; вернуть квитанцию. ``expect_sha`` -
    sha256 того, что должно лежать сейчас (``None`` - файла нет); иное - ``cas_mismatch``."""
    target = _target(Path(vault), rel, allowed_prefix)
    with file_lock(target):
        return _write_locked(target, rel, text, expect_sha=expect_sha, now=now)


def _write_locked(target: Path, rel: str, text: str, *, expect_sha: str | None,
                  now: str) -> dict[str, Any]:
    cur = read_sha(target)
    if cur != expect_sha:
        want, have = (expect_sha or "нет файла")[:12], (cur or "нет файла")[:12]
        raise NoteWriteError("cas_mismatch", f"{rel} изменена третьей стороной: ожидали {want}, "
                             f"лежит {have}", current_sha=cur)
    data = text.encode("utf-8")
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{target.name}.dt-note.", suffix=".tmp", dir=target.parent)
    tmp = Path(name)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        if expect_sha is None:
            try:
                os.link(tmp, target)  # atomic no-clobber, including a non-cooperating creator
            except FileExistsError as exc:
                raise NoteWriteError("cas_mismatch", f"{rel}: файл уже существует",
                                     current_sha=read_sha(target)) from exc
        else:
            os.replace(tmp, target)
    finally:
        with contextlib.suppress(OSError):
            tmp.unlink()
    _fsync_dir(target.parent)
    return {"path": rel, "sha_before": cur, "sha_after": sha256_bytes(data), "bytes": len(data),
            "created": cur is None, "at": now}


def remove_note_atomic(vault: Path, rel: str, *, expect_sha: str, now: str = "",
                       allowed_prefix: str | None = None) -> dict[str, Any]:
    """Убрать заметку, которую только что создали мы (откат неудавшегося применения), если на диске
    все еще наш ``expect_sha``; посторонняя правка - ``cas_mismatch``, файл остается."""
    target = _target(Path(vault), rel, allowed_prefix)
    with file_lock(target):
        return _remove_locked(target, rel, expect_sha=expect_sha, now=now)


def _remove_locked(target: Path, rel: str, *, expect_sha: str, now: str) -> dict[str, Any]:
    cur = read_sha(target)
    if cur != expect_sha:
        raise NoteWriteError("cas_mismatch", f"{rel} изменена после записи: откат не трогает ее",
                             current_sha=cur)
    target.unlink()
    _fsync_dir(target.parent)
    return {"path": rel, "sha_before": cur, "sha_after": None, "removed": True, "at": now}


def create_note_atomic(target: Path, text: str) -> None:
    """Publish a new note only; a collision never replaces existing bytes."""
    try:
        write_note_atomic(target.parent, target.name, text, expect_sha=None)
    except NoteWriteError as exc:
        if exc.code == "cas_mismatch":
            raise FileExistsError(
                f"target_path already exists: {target.name}; choose another path") from exc
        raise
