"""Догоняющий проход ``aliases: [<id>]`` по существующим файловым заметкам (KIT-FIT-1 п.9).

Движок и все его эмиттеры (MOC, обратные ссылки, связанные, источники синтеза хаба) пишут ссылки
``[[legacy-<hash12>]]`` по ``id`` заметки, а файл называется ``<slug>-<hash8>.md``: Obsidian по
такой ссылке файл не находит. Новые заметки получают ``aliases: [<id>]`` при рендере
(``core.legacy.render``, ``core.legacy.mail``); этот проход чинит уже лежащие.

Правка ТОЛЬКО frontmatter и хирургическая (:func:`core.vault.set_frontmatter_fields_text`: остальное
байт-в-байт, CRLF сохраняется), запись атомарная (временный файл рядом + ``os.replace``), аудит -
``record_action`` в ``pult-actions.log`` (одна строка на прогон, без содержимого заметок). Файл,
изменившийся между чтением и записью (параллельный инжест), пропускается и считается. Идемпотентно:
повтор ничего не меняет. ``dry_run`` не пишет ничего (и в аудит тоже). NDA-пути не трогаются
никогда (тот же обход, что у индекса).

Реиндекс: ``aliases`` не входит ни в текст чанка, ни в метаданные-колонки индекса, поэтому после
прохода ``reindex_inc`` пересчитывает хеш заметок и чанки, но НЕ эмбеддит заново (проверено тестом
на фикстуре: ноль вызовов эмбеддера)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.vault import (
    FrontmatterError,
    RawYaml,
    iter_vault_paths,
    read_frontmatter_fields_text,
    set_frontmatter_fields_text,
)

__all__ = ["BackfillReport", "backfill_aliases", "format_report"]

LEGACY_ROOT = "_legacy"
_ID_PREFIX = "legacy-"
AUDIT_TOOL = "notes_backfill_aliases"


@dataclass
class BackfillReport:
    dry_run: bool
    limit: int | None
    scanned: int = 0  # файловые заметки, у которых id вида legacy-…
    already: int = 0  # алиас уже есть
    to_update: int = 0  # нужна правка (при dry_run - сколько будет изменено)
    updated: int = 0  # записано
    raced: int = 0  # файл изменился между чтением и записью - пропущен
    unreadable: int = 0  # нет frontmatter / не читается
    limited: bool = False  # остановились на --limit
    examples: list[str] = field(default_factory=list)  # первые пути (vault-относительные)

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


def _existing_aliases(text: str) -> list[str]:
    """Алиасы заметки списком (``aliases`` бывает списком, скаляром или отсутствует)."""
    import yaml  # type: ignore[import-untyped]

    from core.vault import _FM_BLOCK_RE  # тот же разбор блока, что у писателя

    m = _FM_BLOCK_RE.match(text)
    if not m:
        raise FrontmatterError("во frontmatter нет YAML-блока")
    try:
        data = yaml.safe_load(m.group(1)) or {}
    except yaml.YAMLError as exc:
        raise FrontmatterError(f"frontmatter не разобран: {exc}") from exc
    if not isinstance(data, dict):
        raise FrontmatterError("frontmatter не словарь")
    raw = data.get("aliases")
    if raw in (None, "", []):
        return []
    return [str(x) for x in (raw if isinstance(raw, list) else [raw])]


def _with_alias(items: list[str], note_id: str) -> RawYaml | None:
    """Значение ``aliases`` (YAML-flow) с дописанным ``note_id`` либо ``None``, если он уже есть.

    Чужие алиасы сохраняются, ``note_id`` идет в конец."""
    import yaml  # type: ignore[import-untyped]

    if note_id in items:
        return None
    flow = yaml.safe_dump([*items, note_id], allow_unicode=True, default_flow_style=True)
    return RawYaml(flow.strip().removesuffix("...").strip())


def _note_id(text: str) -> str:
    """``id`` файловой заметки-источника (``type: legacy-source``) либо ``""`` (служебная)."""
    got = read_frontmatter_fields_text(text, ("id", "type"))
    return got["id"].strip() if got["type"].strip() == "legacy-source" else ""


def _write_atomic(path: Path, text: str, *, mode: int) -> None:
    tmp = path.with_name(f".{path.name}.aliases.tmp")
    try:
        with tmp.open("w", encoding="utf-8", newline="") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def backfill_aliases(
    vault_path: Path, *, dry_run: bool = False, limit: int | None = None,
) -> BackfillReport:
    """Дописать ``aliases: [<id>]`` файловым заметкам ``_legacy/`` (id вида ``legacy-…``).

    ``limit`` - сколько заметок изменить за прогон (порядок - по пути, повтор продолжит с
    оставшихся). ``dry_run`` - только посчитать."""
    vault_path = Path(vault_path)
    report = BackfillReport(dry_run=dry_run, limit=limit)
    for path in iter_vault_paths(vault_path):
        rel = path.relative_to(vault_path).as_posix()
        if not rel.startswith(LEGACY_ROOT + "/") or path.name == "_index.md":
            continue
        try:
            before = path.stat()
            with path.open(encoding="utf-8", newline="") as fh:
                text = fh.read()
            note_id = _note_id(text)
        except (OSError, UnicodeDecodeError, FrontmatterError):
            report.unreadable += 1
            continue
        if not note_id.startswith(_ID_PREFIX):
            continue
        report.scanned += 1
        try:
            value = _with_alias(_existing_aliases(text), note_id)
        except FrontmatterError:
            report.unreadable += 1
            continue
        if value is None:
            report.already += 1
            continue
        if limit is not None and report.to_update >= limit:
            report.limited = True
            break
        report.to_update += 1
        if len(report.examples) < 5:
            report.examples.append(rel)
        if dry_run:
            continue
        new_text, _prev, changed = set_frontmatter_fields_text(text, {"aliases": value})
        if not changed:
            continue
        try:
            now = path.stat()
            if (now.st_mtime_ns, now.st_size) != (before.st_mtime_ns, before.st_size):
                report.raced += 1  # параллельный инжест переписал файл - не затираем его
                continue
            _write_atomic(path, new_text, mode=now.st_mode & 0o777)
        except OSError:
            report.unreadable += 1
            continue
        report.updated += 1
    if not dry_run:
        from core.operational.pult import record_action

        record_action(AUDIT_TOOL, {"scanned": report.scanned, "updated": report.updated,
                                   "already": report.already, "raced": report.raced,
                                   "limit": limit if limit is not None else "-"},
                      "ok" if not report.raced else "partial")
    return report


def format_report(report: BackfillReport) -> str:
    """Человеческий отчет прохода."""
    mode = "ПЛАН (ничего не записано)" if report.dry_run else "выполнено"
    lines = [
        f"aliases для ссылок [[legacy-…]] в Obsidian: {mode}",
        f"  заметок с id legacy-…: {report.scanned}; алиас уже есть: {report.already}",
        f"  нужна правка: {report.to_update}"
        + ("" if report.dry_run else f"; записано: {report.updated}"),
    ]
    if report.raced:
        lines.append(f"  пропущено, файл менялся во время прохода: {report.raced} (повторить)")
    if report.unreadable:
        lines.append(f"  не прочитано (нет frontmatter и т. п.): {report.unreadable}")
    if report.limited:
        lines.append(f"  остановлено на --limit {report.limit}; повтор продолжит с остальных")
    for ex in report.examples:
        lines.append(f"  - {ex}")
    return "\n".join(lines)
