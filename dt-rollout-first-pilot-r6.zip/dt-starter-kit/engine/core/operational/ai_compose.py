"""PULT-UX-2 п.4 - оркестрация текстовых сценариев в ОБЩЕМ шлюзе: задача -> parse_task -> generate.

Пульт без чата пишет два вида текста (ТЗ-UX §8.1-8.2): справку к встрече и черновик ответа на
письмо. Шлюз (:mod:`core.operational.ai_gateway`) умел «промпт -> текст» (вид ``draft``), а сборку
контекста делал браузер из пяти вызовов. Здесь та же оркестрация поднята в ОДИН серверный контракт -
виды ``reply`` и ``meeting`` инструмента ``pult_ai`` (класс задач ``draft``: тот же маршрут,
профиль, ключ, лимиты, кэш и аудит, что у остальных видов; ключ нигде не покидает демона)::

    pult_ai("reply",   {item_id|thread, task?, use_case_id?, client?, corpus?, stage?,
                        confirm_thin?})
    pult_ai("meeting", {subject, counterparty_domains?, client_ids?, entity_id?, scope_all?,
                        stage?})

``stage="prepare"`` - все, кроме модели: тред/досье, ``parse_task``, гейт ``generate``,
достаточность контекста и состояние маршрута модели; ничего не пишется. ``stage="write"`` (по
умолчанию) - то же и текст. Ответ одной формы::

    {ok, kind, class, route, profile, provider, model, cached, ms, stage,
     status: ready | partial | written | blocked | needs_confirm | needs_clarification
             | unavailable,
     parsed?, gate?, sufficiency?, thread?|dossier?, sources, facts, exemplar?,
     provenance: [{path, what_taken}], text?, skeleton?, prompt?, prompt_chars?,
     code?, reason?, fix?, provider_status}

* гейт ``generate`` (``blocked``): текста и вызова модели нет, ``gate.missing`` - что добыть;
* достаточность (``sufficiency.level``: ``ok | thin | insufficient``) показывается ДО текста; при
  ``insufficient`` модель не зовется без ``confirm_thin`` (``status: needs_confirm``);
* провайдер не настроен (маршрут ``none``/``host``, нет ключа...): ``ok: false`` с ``code`` и
  русской ``reason`` + ``fix`` (переход в «Настройки / ИИ и профиль»); у справки при этом приходит
  заготовка ``skeleton`` из досье без модели, у ответа - ``prompt`` для ручного копирования
  (дополнительно, а не вместо черновика);
* письма не отправляются, vault не пишется: сохранение - ``output_begin``/``save_output`` из
  пульта; ``provenance`` - готовый список ``sources`` для ``save_output``.

``core`` ⊥ mcp/cli: зависимости, которым нужен слой MCP (``generate``, ``work_meeting_prep``),
приходят инъекцией (:class:`Deps`). Сети нет нигде, кроме провайдерских адаптеров ``ai_layer``.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from core.operational import ai_gateway as gw
from core.operational import meeting_dossier as md

__all__ = ["COMPOSE_KINDS", "Deps", "explain_refusal", "run"]

COMPOSE_KINDS = ("reply", "meeting")
DEFAULT_REPLY_CASE = "client_correspondence"
FIX_AI = {"section": "set/ai", "label": "Настройки / ИИ и профиль"}
_MAX_PROVENANCE = 30
_LIMIT_WARNINGS = ("client_unresolved", "plan_inconsistent", "source_unavailable")


@dataclass
class Deps:
    """Что нужно оркестрации от слоя MCP и окружения; пустое - боевое значение из ``core``."""

    generate: Callable[..., dict[str, Any]] | None = None         # mcp-server: generate
    prepare_meeting: Callable[..., dict[str, Any]] | None = None  # mcp-server: work_meeting_prep
    synthesize: Callable[..., dict[str, Any]] | None = None       # ai_layer.synthesize
    parse: Callable[..., Any] | None = None                       # core.parse_task.parse_task
    read_inbound: Callable[..., dict[str, Any]] | None = None     # mail_reply.read_inbound
    settings: Callable[[], Any] | None = None                     # ai_layer.get_settings
    stores: Callable[[], dict[str, bool]] | None = None           # доступность хранилищ досье
    genres: Callable[[], list[dict[str, str]]] | None = None      # жанры для выбора
    now: Callable[[], datetime] = field(default=lambda: datetime.now(UTC))


# --------------------------------------------------------------------------- #
# Маршрут модели и честные причины отказа                                        #
# --------------------------------------------------------------------------- #
_CLASS_RU = {"draft": "черновик", "triage": "подсказки", "synth": "синтез"}
_REASONS = {
    "ai_disabled": "Для класса задач «{cls}» модель выключена (маршрут none): "
                   "текст без нее не пишется.",
    "ai_host_side": "Класс задач «{cls}» направлен на модель хоста (Claude Desktop): из "
                    "браузера она недоступна, нужен профиль провайдера.",
    "unknown_profile": "Маршрут класса «{cls}» указывает на профиль, которого нет в настройках.",
    "no_key": "Для профиля провайдера не задан ключ: выполните `dt ai set-key --profile <имя>`.",
    "rate_limited_local": "Исчерпан местный лимит вызовов провайдеру в час: повторите позже.",
    "rate_limited": "Провайдер ответил «слишком часто»: повторите позже.",
    "auth": "Провайдер отклонил ключ (авторизация): проверьте ключ профиля.",
    "timeout": "Провайдер не ответил за отведенное время: повторите или увеличьте timeout_s "
               "профиля.",
    "network": "Нет связи с провайдером: ввод сохранен, повторите после восстановления сети.",
    "provider_error": "Провайдер вернул ошибку сервера: повторите позже.",
    "bad_request": "Провайдер отклонил запрос (формат или размер): сузьте задачу.",
    "bad_response": "Провайдер вернул нечитаемый ответ: повторите.",
    "bad_format": "Провайдер вернул пустой или неподходящий ответ: повторите.",
    "payload_too_large": "Контекст для модели слишком велик: сузьте задачу или выберите клиента.",
    "bad_payload": "Для модели не собран промпт: повторите подготовку.",
}
_NEEDS_SETTINGS = {"ai_disabled", "ai_host_side", "unknown_profile", "no_key", "auth"}


def explain_refusal(code: str, res: dict[str, Any] | None = None) -> dict[str, Any]:
    """``{code, reason, fix?}`` по коду отказа шлюза; ``fix`` - куда идти, если нужна настройка."""
    profile = (res or {}).get("profile")
    cls = _CLASS_RU.get(str((res or {}).get("class") or "draft"), "черновик")
    reason = _REASONS.get(code, f"Модель не вернула текст ({code}).").replace("{cls}", cls)
    if code == "no_key" and profile:
        reason = (f"Для профиля «{profile}» не задан ключ: выполните "
                  f"`dt ai set-key --profile {profile}`.")
    out: dict[str, Any] = {"code": code, "reason": reason}
    if code in _NEEDS_SETTINGS:
        out["fix"] = dict(FIX_AI)
    return out


def _provider_status(kind: str, deps: Deps) -> dict[str, Any]:
    """Маршрут модели ДО вызова: ``{available, side, route, profile, provider, model, ...}``."""
    from core.operational import ai_layer

    cfg = gw.normalize(deps.settings() if deps.settings else ai_layer.get_settings())
    cls = {"class": gw.KIND_CLASS.get(kind)}
    none = {"available": False, "side": "none", "route": None, "profile": None,
            "provider": "none", "model": ""}
    try:
        res = gw.resolve(kind, cfg)
    except gw.SettingsError as exc:
        return {**none, **explain_refusal(exc.code, cls)}
    status: dict[str, Any] = {
        "available": res.side == "daemon", "side": res.side, "route": res.route,
        "profile": res.profile, "provider": res.provider, "model": res.model,
        "sends_data_out": gw.sends_data_out(res)}
    if res.side == "none":
        status.update(explain_refusal("ai_disabled", {**cls, "profile": res.profile}))
    elif res.side == "host":
        status.update(explain_refusal("ai_host_side", cls))
    elif not ai_layer.key_status(res.profile or gw.DEFAULT_PROFILE, settings=cfg)["configured"]:
        status["available"] = False
        status.update(explain_refusal("no_key", {**cls, "profile": res.profile}))
    return status


def _call_model(kind: str, prompt: str, deps: Deps) -> dict[str, Any]:
    from core.operational import ai_layer

    return (deps.synthesize or ai_layer.synthesize)(kind, {"prompt": prompt})


def _merge_model(out: dict[str, Any], res: dict[str, Any]) -> None:
    """Результат ``synthesize`` в ответ сценария: маршрут, провайдер, текст или причина отказа."""
    for key in ("class", "route", "profile", "provider", "model", "cached", "ms"):
        if key in res:
            out[key] = res[key]
    if res.get("ok") and res.get("text"):
        out.update(ok=True, status="written", text=str(res["text"]))
        return
    out.update(ok=False, status="unavailable", text=None)
    out.update(explain_refusal(str(res.get("code") or "provider_error"), res))


def _head(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    stage = "prepare" if str(payload.get("stage") or "").lower() == "prepare" else "write"
    return {"ok": True, "kind": kind, "class": gw.KIND_CLASS.get(kind), "route": None,
            "profile": None, "provider": "none", "model": "", "cached": False, "ms": 0,
            "stage": stage, "status": "ready", "sources": [], "facts": [], "provenance": []}


def _dedup(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    seen: set[tuple[str, str]] = set()
    out = []
    for row in rows:
        key = (row["path"], row["what_taken"])
        if key not in seen:
            seen.add(key)
            out.append(row)
    return out[:_MAX_PROVENANCE]


# --------------------------------------------------------------------------- #
# Сценарий «Черновик ответа» (§8.2)                                              #
# --------------------------------------------------------------------------- #
def _default_genres() -> list[dict[str, str]]:
    from core.config import default_vault_path
    from core.role import get_role

    try:
        labels = dict(get_role(default_vault_path()).role.scenarios.labels)
    except Exception:  # noqa: BLE001 - жанры - подсказка выбора, не условие работы
        return []
    return [{"use_case_id": k, "label": v} for k, v in labels.items()]


def _sufficiency(*, sources_n: int, facts_n: int, client: str | None,
                 warnings: list[dict[str, Any]], skipped: list[Any]) -> dict[str, Any]:
    """Достаточность контекста ДО текста: ``{level, reasons, sources_n, facts_n, client}``.

    ``insufficient`` - в промпт не легло ни одной заметки DT (текст был бы «из головы» модели);
    ``thin`` - мало опоры: меньше двух источников, клиент не определен, слайсы не отработали."""
    reasons: list[str] = []
    level = "ok"
    if sources_n == 0:
        level = "insufficient"
        reasons.append("по задаче в DT не найдено ни одной заметки: источников нет")
    elif sources_n < 2:
        level = "thin"
        reasons.append(f"найден {sources_n} источник: опора на контекст слабая")
    if not client:
        level = "thin" if level == "ok" else level
        reasons.append("клиент не определен: переписка и сделки клиента не подняты")
    reasons += [str(w.get("reason") or w.get("code"))[:200] for w in warnings
                if w.get("code") in _LIMIT_WARNINGS]
    if skipped:
        names = ", ".join(str(s.get("name") if isinstance(s, dict) else s) for s in skipped)
        level = "thin" if level == "ok" else level
        reasons.append(f"часть слайсов не отработала: {names[:120]}")
    return {"level": level, "reasons": reasons, "sources_n": sources_n, "facts_n": facts_n,
            "client": client}


def _reply_provenance(thread: dict[str, Any], sources: list[dict[str, Any]],
                      facts: list[dict[str, Any]]) -> list[dict[str, str]]:
    inbound = thread["inbound"]
    rows = [{"path": str(thread.get("ref") or "mail"),
             "what_taken": f"последнее входящее письмо {inbound.get('date') or ''} "
                           f"«{thread.get('subject') or ''}»".strip()}]
    for s in sources:
        path = str(s.get("source_path") or s.get("note_id") or "")
        if path:
            what = str(s.get("heading_path") or s.get("note_id") or "заметка")
            rows.append({"path": path, "what_taken": f"{what} (слайс {s.get('slice') or '-'})"})
    for f in facts:
        if f.get("source_path"):
            rows.append({"path": str(f["source_path"]),
                         "what_taken": f"факт: {f.get('label') or f.get('kind') or ''}"})
    return _dedup(rows)


def _reply_parse(payload: dict[str, Any], thread: dict[str, Any], deps: Deps) -> dict[str, Any]:
    from core.parse_task import parse_task as core_parse

    subject = str(thread.get("subject") or "")
    task = str(payload.get("task") or "").strip() or (
        f"Ответ на входящее письмо «{subject}»" if subject else "Ответ на входящее письмо")
    forced = str(payload.get("use_case_id") or "").strip()
    parsed = (deps.parse or core_parse)(
        f"{task}\n{subject}".strip(), params={"use_case": forced} if forced else None)
    sure = bool(parsed.detected or forced)
    params = dict(parsed.params)
    client = str(payload.get("client") or "").strip() or params.get("client_id") or None
    if client:
        params["client_id"] = params["client"] = client
    if isinstance(payload.get("params"), dict):
        params.update({str(k): v for k, v in payload["params"].items()})
    view: dict[str, Any] = {
        "use_case_id": parsed.use_case_id if sure else DEFAULT_REPLY_CASE, "detected": sure,
        "task": task, "params": params, "client": client,
        "interpretation": parsed.interpretation,
        "genres": (deps.genres or _default_genres)()}
    if not sure:
        view["note"] = ("жанр по задаче не распознан - взято «письмо клиенту»; выберите жанр, "
                        "если задача другая")
    return view


def _run_reply(payload: dict[str, Any], deps: Deps) -> dict[str, Any]:
    from core.operational import mail_reply

    out = _head("reply", payload)
    thread = (deps.read_inbound or mail_reply.read_inbound)(
        item_id=payload.get("item_id") or None, thread=payload.get("thread") or None)
    out["thread"] = thread
    if not thread.get("found") or not thread.get("inbound"):
        out.update(ok=False, status="unavailable", code=str(thread.get("code") or "unavailable"),
                   reason=str(thread.get("reason") or "тред не прочитан"))
        return out
    parsed = _reply_parse(payload, thread, deps)
    out["parsed"] = parsed
    if deps.generate is None:
        raise RuntimeError("ai_compose: не передан generate (слой MCP)")
    gen_task = ("Входящее письмо, на которое отвечаем:\n«" + thread["inbound"]["text"]
                + f"»\n\nЗадача: {parsed['task']}")
    gargs: dict[str, Any] = {"use_case_id": parsed["use_case_id"], "task": gen_task,
                             "params": parsed["params"], "persist": False, "use_plan": True}
    for key in ("corpus", "require_facts"):
        if payload.get(key):
            gargs[key] = payload[key]
    g = deps.generate(**gargs)
    out["provider_status"] = _provider_status("reply", deps)
    warnings = [w for w in (g.get("warning") or []) if isinstance(w, dict)]
    out["warning"] = warnings
    if g.get("status") == "blocked":
        out.update(ok=False, status="blocked", code="blocked", reason=str(g.get("reason") or ""),
                   gate={"status": "blocked", "missing": g.get("missing") or []})
        return out
    sources, facts = list(g.get("sources") or []), list(g.get("facts") or [])
    out.update(sources=sources, facts=facts, gate={"status": "ok", "missing": []})
    if g.get("exemplar"):
        out["exemplar"] = g["exemplar"]
    out["sufficiency"] = _sufficiency(
        sources_n=len(sources), facts_n=len(facts), client=parsed["client"], warnings=warnings,
        skipped=list(g.get("skipped_slices") or []))
    out["provenance"] = _reply_provenance(thread, sources, facts)
    prompt = str(g.get("prompt") or "")
    out["prompt_chars"] = len(prompt)
    if thread.get("last_from_me"):
        out["warning"] = [*warnings, {
            "code": "already_answered",
            "reason": "последнее сообщение в треде - ваше: входящего без ответа нет"}]
    if out["stage"] == "prepare":
        if not out["provider_status"]["available"]:
            out["prompt"] = prompt   # нет модели в браузере: промпт для хоста/копирования
        return out
    if out["sufficiency"]["level"] == "insufficient" and not payload.get("confirm_thin"):
        out.update(status="needs_confirm", code="context_insufficient",
                   reason="Контекста DT недостаточно: текст получился бы без опоры на источники. "
                          "Подтвердите, чтобы писать без контекста.")
        return out
    _merge_model(out, _call_model("reply", prompt, deps))
    if not out.get("ok"):
        out["prompt"] = prompt   # «Копировать промпт» - дополнительно к черновику, не вместо него
    return out


# --------------------------------------------------------------------------- #
# Сценарий «Справка к встрече» (§8.1)                                            #
# --------------------------------------------------------------------------- #
def _meeting_provenance(view: dict[str, Any]) -> list[dict[str, str]]:
    rows = []
    for s in view["sources"]:
        if s.get("ref") or s.get("title"):
            date = f" ({s['date']})" if s.get("date") else ""
            rows.append({"path": s["ref"] or s["title"],
                         "what_taken": f"{s['kind']}: {s['title']}{date}"})
    return _dedup(rows)


def _run_meeting(payload: dict[str, Any], deps: Deps) -> dict[str, Any]:
    out = _head("meeting", payload)
    if deps.prepare_meeting is None:
        raise RuntimeError("ai_compose: не передан work_meeting_prep (слой MCP)")
    subject = str(payload.get("subject") or "").strip()
    if not subject:
        out.update(ok=False, status="unavailable", code="bad_payload", reason="у встречи нет темы")
        return out
    raw = deps.prepare_meeting(
        subject=subject,
        counterparty_domains=[str(x) for x in payload.get("counterparty_domains") or []],
        client_ids=[str(x) for x in payload.get("client_ids") or []] or None,
        entity_id=str(payload.get("entity_id") or "") or None)
    view = md.dossier_view(raw, stores=(deps.stores or md.store_state)(), now=deps.now())
    out.update(dossier=view, sources=view["sources"], provenance=_meeting_provenance(view),
               skeleton=md.meeting_skeleton(view),
               provider_status=_provider_status("meeting", deps))
    scoped = bool(payload.get("entity_id") or payload.get("scope_all"))
    if view["needs_clarification"] and not scoped:
        out.update(status="needs_clarification", code="needs_clarification",
                   reason="тема совпала неоднозначно: выберите, к чему встреча, "
                          "или возьмите весь клиент")
        return out
    partial = view["coverage"]["status"] == "partial"
    out["status"] = "partial" if partial else "ready"
    prompt = md.meeting_prompt(view)
    out["prompt_chars"] = len(prompt)
    if out["stage"] == "prepare":
        if not out["provider_status"]["available"]:
            out["prompt"] = prompt   # нет модели в браузере: промпт для хоста/копирования
        return out
    _merge_model(out, _call_model("meeting", prompt, deps))
    if out.get("ok"):
        out["partial"] = partial   # справка написана по неполному досье - пульт покажет рядом
    else:
        out["prompt"] = prompt
    return out


def run(kind: str, payload: dict[str, Any] | None, deps: Deps) -> dict[str, Any]:
    """Сценарий ``kind`` (``reply`` | ``meeting``).

    Ожидаемые отказы (нет данных, тред не найден, гейт, провайдер) - ``ok: false`` с ``code`` и
    ``reason``, а не исключение."""
    data = payload if isinstance(payload, dict) else {}
    started = time.monotonic()
    if kind not in COMPOSE_KINDS:
        return {"ok": False, "kind": kind, "class": gw.KIND_CLASS.get(kind),
                "status": "unavailable", "code": "bad_kind", "text": None,
                "reason": f"вид {kind!r}: {', '.join(COMPOSE_KINDS)}"}
    out = _run_reply(data, deps) if kind == "reply" else _run_meeting(data, deps)
    out.setdefault("text", None)
    out["ms_total"] = round((time.monotonic() - started) * 1000)
    try:
        from core.metrics import record_event

        record_event("ai_compose", scenario=kind, stage=out.get("stage"),
                     status=out.get("status"), ok=bool(out.get("ok")), code=out.get("code") or "-",
                     level=(out.get("sufficiency") or {}).get("level") or "-")
    except Exception:  # noqa: BLE001, S110 - метрика не должна ронять сценарий
        pass
    return out
