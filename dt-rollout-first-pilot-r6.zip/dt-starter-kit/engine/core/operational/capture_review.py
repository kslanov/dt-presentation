"""PULT-UX-2 п.3 - разбор захвата без чата: предложение размещения знания (ТЗ-UX §8.3).

Знаниевый захват лежит в ``_staging/inbox``. Раньше его «разбирали» в чате: промпт запроса
уточнения (:func:`core.ingest.build_refinement_request`) отдавали модели хоста, она отвечала
предложением ``{type, target_path, frontmatter, summary?}``, человек подтверждал,
``apply_refinement`` писал заметку. Здесь тот же путь поднят в общий шлюз (вид ``refine``, класс
``triage`` инструмента ``pult_ai``):

* ``stage="prepare"`` - БЕЗ модели: исходный текст, предложение по правилам (сущности из
  ``parse_task``, папка из тех же кандидатов), справочники для правки (типы, папки, каталог
  хабов) и маршрут модели;
* ``stage="write"`` - то же, но предложение пишет модель маршрута; ответ провайдера проверяется
  теми же правилами (:func:`validate_proposal`): неизвестный хаб не записывается в связи, путь -
  только ``.md`` внутри vault, не под ``_nda``, существующий файл не затирается (имя получает
  суффикс).

Пульт показывает предложение и обоснование, человек правит маршрут, сущность и атрибуты, и
только его явное «Применить» зовет ``apply_refinement`` (прямой записи в vault нет). Операционный
захват (поручение администратору CRM) и личный сюда не попадают: поручение - карточка очереди,
личное остается в TickTick; ``inbox_lane`` поручения отвергается кодом ``assignment_lane``.

``core`` ⊥ mcp/cli; сети нет (модель - через инъектированный ``synthesize``).
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from dataclasses import field as dc_field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core import ingest
from core.operational import ai_compose as ac
from core.operational import ai_gateway as gw
from core.privacy import any_nda

__all__ = ["Deps", "analyze", "validate_proposal", "rules_proposal"]

KIND = "refine"
MAX_TEXT = 4000
# поле frontmatter -> ключ подсказки parse_task / сущность каталога
_LINKS = {"client": "client", "project": "project", "industry": "industry",
          "direction": "direction", "product": "product"}
_HINT_TO_FIELD = {"client_id": "client", "project_id": "project", "industry_id": "industry",
                  "product_id": "product"}
_FM_PASS = ("id", "type", "created", "modified", "status", "tags", "title", "genre")
_FM_RE = re.compile(r"\[\[([^\]|#]+)")


@dataclass
class Deps:
    synthesize: Callable[..., dict[str, Any]] | None = None
    settings: Callable[[], Any] | None = None
    vault: Path | None = None
    inbox: Path | None = None
    now: Callable[[], datetime] = dc_field(default=lambda: datetime.now(UTC))


def _vault(deps: Deps) -> Path:
    from core.config import default_vault_path

    return Path(deps.vault) if deps.vault else default_vault_path()


def _inbox_root(deps: Deps) -> Path:
    from core.config import staging_inbox_path

    return Path(deps.inbox) if deps.inbox else staging_inbox_path(_vault(deps))


def _read_item(
    inbox_file: str, deps: Deps
) -> tuple[ingest.InboxItem | None, dict[str, Any] | None]:
    """Файл захвата или отказ данными: только внутри inbox, не NDA, не поручение."""
    path = Path(str(inbox_file or "")).expanduser()
    root = _inbox_root(deps).resolve()
    try:
        resolved = path.resolve()
    except OSError:
        resolved = path
    if not str(inbox_file or "").strip() or not resolved.is_relative_to(root):
        return None, {"code": "outside_inbox",
                      "reason": "файл вне входящих (_staging/inbox): разбор не начат"}
    if any_nda(resolved):
        return None, {"code": "nda", "reason": "файл под барьером NDA: содержимое не читается"}
    if not resolved.is_file():
        return None, {"code": "not_found", "reason": "файла захвата уже нет во входящих"}
    item = ingest.InboxItem(path=resolved, text=resolved.read_text(encoding="utf-8"))
    if ingest.is_assignment(item):
        return None, {"code": "assignment_lane",
                      "reason": "это поручение администратору CRM: оно ведется карточкой очереди, "
                                "а не размещением знания"}
    return item, None


# --------------------------------------------------------------------------- #
# Справочники и предложение по правилам                                          #
# --------------------------------------------------------------------------- #
def _title_of(item: ingest.InboxItem) -> str:
    for line in item.text.splitlines():
        line = re.sub(r"^[#>*\-\s]+", "", line).strip()
        if line and not line.lower().startswith(("lane:", "источник:", "---")):
            return line[:70]
    return item.path.stem


def _catalog_view(req: ingest.RefinementRequest) -> list[dict[str, Any]]:
    return [{"id": r.id, "entity": r.entity, "label": (r.aliases[0] if r.aliases else r.id)}
            for r in req.catalog]


def _link(value: str) -> str:
    return f'"[[{value}]]"'


def _slug(text: str) -> str:
    from core.output import slugify

    return slugify(text, max_words=6, max_len=48) or "zahvat"


def _unique(vault: Path, rel: str) -> str:
    target = Path(rel)
    n = 2
    while (vault / target).exists():
        target = target.with_name(f"{Path(rel).stem}-{n}{Path(rel).suffix}")
        n += 1
    return target.as_posix()


def rules_proposal(req: ingest.RefinementRequest, vault: Path, now: datetime) -> dict[str, Any]:
    """Предложение БЕЗ модели: сущности из ``parse_task``, первая папка кандидатов, тип ``note``."""
    day = now.date().isoformat()
    fields: dict[str, Any] = {}
    for hint, field in _HINT_TO_FIELD.items():
        if req.hints.get(hint):
            fields[field] = req.hints[hint]
    title = _title_of(req.item)
    folder = req.target_folders[0] if req.target_folders else "02-knowledge/"
    rel = _unique(vault, f"{folder.rstrip('/')}/{day}-{_slug(title)}.md")
    fm: dict[str, Any] = {"id": Path(rel).stem, "type": "note", "created": day, "modified": day,
                          "status": "active", "tags": []}
    for field, value in fields.items():
        fm[field] = [_link(value)] if field == "product" else _link(value)
    found = ", ".join(f"{k}: {v}" for k, v in fields.items())
    why = (f"в тексте найдены сущности ({found}); папка - по ним" if fields
           else "сущности в тексте не найдены: проверьте клиента/проект и папку")
    return {"type": "note", "target_path": rel, "frontmatter": fm, "summary": None,
            "rationale": why, "source": "rules"}


# --------------------------------------------------------------------------- #
# Проверка предложения (правил и модели одинаково)                                #
# --------------------------------------------------------------------------- #
def _link_id(value: Any) -> str:
    m = _FM_RE.search(str(value))
    return (m.group(1) if m else str(value)).strip().strip('"')


def validate_proposal(raw: Any, req: ingest.RefinementRequest, vault: Path,
                      fallback: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    """Предложение -> безопасное: ``(proposal, issues)``. Ничего не пишет и не бросает.

    Тип из ``CONTENT_TYPES``; путь - только ``.md`` внутри vault, не ``_nda``, без ``..``;
    существующий файл не затирается; связи - только на хабы каталога (неизвестный хаб
    отбрасывается и называется)."""
    issues: list[str] = []
    src = raw if isinstance(raw, dict) else {}
    ctype = str(src.get("type") or "").strip()
    if ctype not in ingest.CONTENT_TYPES:
        if ctype:
            issues.append(f"тип «{ctype}» не из списка: взят «{fallback['type']}»")
        ctype = fallback["type"]
    rel = str(src.get("target_path") or "").strip()
    bad = ""
    if not rel:
        bad = "путь не указан"
    elif Path(rel).suffix.lower() != ".md":
        bad = "путь должен вести в файл .md"
    else:
        cand = Path(rel)
        if cand.is_absolute():
            try:
                cand = cand.resolve().relative_to(vault.resolve())
            except ValueError:
                bad = "путь вне vault"
        if not bad and (".." in cand.parts or any_nda(cand)):
            bad = "путь с «..» или под барьером NDA"
        if not bad:
            rel = cand.as_posix()
    if bad:
        issues.append(f"{bad}: взят предложенный по правилам путь")
        rel = fallback["target_path"]
    elif (vault / rel).exists():
        issues.append("файл с таким именем уже есть: имя изменено, чтобы не затереть его")
        rel = _unique(vault, rel)
    ids = {r.id: r.entity for r in req.catalog}
    fm_in = src.get("frontmatter") if isinstance(src.get("frontmatter"), dict) else {}
    fm: dict[str, Any] = {k: fm_in[k] for k in _FM_PASS if k in fm_in}
    for field, entity in _LINKS.items():
        if field not in fm_in:
            continue
        values = fm_in[field] if isinstance(fm_in[field], list) else [fm_in[field]]
        keep = []
        for v in values:
            hub = _link_id(v)
            if ids.get(hub) == entity:
                keep.append(_link(hub))
            else:
                issues.append(f"хаб «{hub}» не найден среди {entity}: связь не записана")
        if keep:
            fm[field] = keep if (field == "product" or len(keep) > 1) else keep[0]
    fm["type"] = ctype
    fm.setdefault("id", Path(rel).stem)
    for key in ("created", "modified", "status"):
        fm.setdefault(key, fallback["frontmatter"].get(key))
    summary = str(src.get("summary") or "").strip() or None
    return ({"type": ctype, "target_path": rel, "frontmatter": fm, "summary": summary,
             "rationale": str(src.get("rationale") or fallback.get("rationale") or "")[:300],
             "source": str(src.get("source") or "model")}, issues)


def _parse_model_json(text: str) -> Any:
    body = (text or "").strip()
    body = re.sub(r"^```(?:json)?\s*|\s*```$", "", body, flags=re.IGNORECASE)
    start, end = body.find("{"), body.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        return json.loads(body[start:end + 1])
    except ValueError:
        return None


_INSTRUCTION = (
    "\n\n## Формат ответа\nВерни ТОЛЬКО один JSON-объект без пояснений и без ```: "
    '{"type": "<из списка типов>", "target_path": "<путь .md внутри vault из списка папок>", '
    '"frontmatter": {"client": "[[id]]", "project": "[[id]]", ...только хабы из каталога}, '
    '"summary": "<только если текст длинный>", "rationale": "<5-15 слов: почему так>"}. '
    "Не выдумывай хабы: только id из каталога. Без длинных тире и буквы ё."
)


def analyze(payload: dict[str, Any] | None, deps: Deps) -> dict[str, Any]:
    """Разбор захвата ``{inbox_file, stage?}`` -> ответ вида ``refine`` (см. док модуля)."""
    data = payload if isinstance(payload, dict) else {}
    stage = "write" if str(data.get("stage") or "").lower() == "write" else "prepare"
    out: dict[str, Any] = {
        "ok": True, "kind": KIND, "class": gw.KIND_CLASS.get(KIND), "route": None,
        "profile": None, "provider": "none", "model": "", "cached": False, "ms": 0,
        "stage": stage, "status": "ready", "text": None}
    item, refused = _read_item(str(data.get("inbox_file") or ""), deps)
    if item is None or refused:
        out.update(ok=False, status="unavailable", **(refused or {"code": "bad_payload"}))
        return out
    vault = _vault(deps)
    req = ingest.build_refinement_request(item, vault_path=vault)
    fallback = rules_proposal(req, vault, deps.now())
    proposal, issues = validate_proposal(fallback, req, vault, fallback)
    text = item.text.split("\n---")[0].strip()
    out.update(
        source={"file": str(item.path), "name": item.path.name, "chars": len(item.text),
                "text": text[:MAX_TEXT], "truncated": len(text) > MAX_TEXT},
        routes=[{"value": "knowledge", "label": "Знание в vault", "available": True,
                 "effect": "заметка записывается в vault через apply_refinement; захват уходит "
                           "из входящих"}],
        options={"types": list(ingest.CONTENT_TYPES), "folders": list(req.target_folders),
                 "entities": _catalog_view(req), "link_fields": list(_LINKS)},
        proposal=proposal, issues=issues,
        provider_status=ac._provider_status(KIND, _compose_deps(deps)))
    if stage == "prepare":
        return out
    prompt = req.render() + _INSTRUCTION
    res = (deps.synthesize or _synthesize)(KIND, {"prompt": prompt})
    for key in ("class", "route", "profile", "provider", "model", "cached", "ms"):
        if key in res:
            out[key] = res[key]
    if not (res.get("ok") and res.get("text")):
        out.update(ok=False, status="unavailable")
        out.update(ac.explain_refusal(str(res.get("code") or "provider_error"), res))
        out["prompt"] = prompt
        return out
    parsed = _parse_model_json(str(res["text"]))
    if not isinstance(parsed, dict):
        out.update(ok=False, status="unavailable", prompt=prompt)
        out.update(ac.explain_refusal("bad_format", res))
        return out
    parsed.setdefault("source", "model")
    proposal, issues = validate_proposal(parsed, req, vault, fallback)
    out.update(status="written", proposal=proposal, issues=issues)
    return out


def _compose_deps(deps: Deps) -> ac.Deps:
    return ac.Deps(settings=deps.settings, synthesize=deps.synthesize)


def _synthesize(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    from core.operational import ai_layer

    return ai_layer.synthesize(kind, payload)
