"""MAIL-BRIDGE-INC-1: запомненные id папок Outlook и отметки суточного полного прохода.

Поиск папки по имени в AppleScript обходит все дерево папок Outlook (7,6 с на вызов, одинаково для
любой папки); чтение по ``mail folder id N`` - 0,3 с. Мост запоминает id найденной папки в
производном сторе ``<derived>/mail_folder_ids.json`` и при следующем вызове передает его скрипту.
Скрипт ПРОВЕРЯЕТ, что по id лежит та же папка (аккаунт и вид по имени), и только тогда читает;
иначе обход дерева как раньше, а мост обновляет запись и пишет WARNING со старым и новым id.

Ключ записи - пара ``аккаунт + имя папки`` (имя спецификации: ``Inbox``, ``Sent Items``). ``bucket``
в ключ не входит: мосту он неизвестен, а вид папки (входящие / отправленные / точное имя) скрипт
выводит из имени. Папка БЕЗ аккаунта по id не читается вовсе: проверять id не с чем (аккаунт - то,
что делает чужую папку отличимой), такая спецификация идет обходом, как прежде.

Как id устаревает: (1) проверкой скрипта при чтении (папку удалили/пересоздали, сменился ящик,
по id оказалась другая папка) - запись заменяется найденным заново id; (2) принудительно раз в
сутки: суточный полный проход (:mod:`core.legacy.mail`) идет обходом дерева, не по id, и
обновляет запись. Времени жизни у записи нет - проверка при каждом чтении надежнее часов.

Здесь же - подсказка размера окна с головы по паре (``windows``: сколько писем понадобилось в
прошлый раз; по ней окно в установившемся режиме укладывается в ОДИН вызов моста) и отметки
суточного полного прохода по спецификациям (``full_pass``): когда последний раз окно с головы
было сверено с полным листингом и чем это кончилось. Файл - кэш: нечитаемый сбрасывается
(следующий вызов найдет папки обходом и перезапишет), а не отказывает.

Запись атомарная (tmp + replace), под ``derived_root()``. Пишет шаг ``mail_ingest`` (fast sync).
``core`` ⊥ mcp/cli; Outlook не читается и не пишется.
"""

from __future__ import annotations

import json
import logging
import os
import unicodedata
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

__all__ = [
    "FULL_PASS_HOUR",
    "STORE_NAME",
    "WALK_REASONS",
    "FolderIdStore",
    "folder_ids_enabled",
    "full_pass_due",
    "walk_reason_text",
]

logger = logging.getLogger(__name__)

STORE_NAME = "mail_folder_ids.json"

# С какого местного часа суток «первый быстрый прогон» читает спецификацию полностью.
FULL_PASS_HOUR = 3

# Причины, по которым спецификация прочитана обходом дерева, а не по id. Коды ``no_account`` ..
# ``id_kind`` отдает скрипт (``walk_reason``), ``refresh`` ставит мост при суточном полном проходе.
WALK_REASONS: dict[str, str] = {
    "no_account": "папка без аккаунта",
    "no_id": "id еще не запомнен",
    "id_missing": "папки с таким id нет",
    "id_account": "по id лежит папка другого ящика",
    "id_kind": "по id лежит папка другого вида",
    "refresh": "суточная сверка",
    "disabled": "адресация по id выключена",
}


def walk_reason_text(code: str) -> str:
    """Человекочитаемая причина обхода (неизвестный код - как есть, пустой - ``""``)."""
    return WALK_REASONS.get(code, code)


def folder_ids_enabled() -> bool:
    """Адресация по id включена (``DT_MAIL_FOLDER_ID``, дефолт ``1``; ``0`` - всегда обход)."""
    raw = (os.environ.get("DT_MAIL_FOLDER_ID") or "").strip().lower()
    return raw not in {"0", "false", "no", "off", "нет"}


def _norm(value: object) -> str:
    return unicodedata.normalize("NFC", str(value or "")).strip().casefold()


def _key(account: str | None, name: str) -> str:
    return f"{_norm(account)}|{_norm(name)}"


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def full_pass_due(
    last: dict[str, Any] | None, *, now: datetime, every_h: int
) -> tuple[bool, str]:
    """Пора ли сверять окно с полным листингом: ``(пора, причина)``.

    ``now`` - местное время с поясом (``datetime.now().astimezone()``). Пора, если отметки нет;
    или прошлая сверка старше ``every_h`` часов; или она была ДО последнего 03:00 по местному
    времени (первый быстрый прогон после 03:00 читает полностью). Причина - для лога.
    """
    if not last or not last.get("ts"):
        return True, "сверки еще не было"
    try:
        then = datetime.fromisoformat(str(last["ts"]).replace("Z", "+00:00"))
    except ValueError:
        return True, "отметка сверки нечитаема"
    if then.tzinfo is None:
        then = then.replace(tzinfo=UTC)
    then = then.astimezone(now.tzinfo)
    if now - then >= timedelta(hours=every_h):
        return True, f"прошлая сверка старше {every_h} ч"
    boundary = now.replace(hour=FULL_PASS_HOUR, minute=0, second=0, microsecond=0)
    if now < boundary:
        boundary -= timedelta(days=1)
    if then < boundary:
        return True, f"прошлая сверка до {FULL_PASS_HOUR:02d}:00"
    return False, ""


class FolderIdStore:
    """Файловый стор ``{аккаунт|имя → id папки}`` + отметки полного прохода.

    ``path=None`` - ``<derived_root()>/mail_folder_ids.json`` (корень вычисляется при каждом
    обращении: песочница ``DT_DERIVED_ROOT`` в тестах работает без перенастройки).
    """

    def __init__(self, path: Path | None = None) -> None:
        self._path = Path(path) if path is not None else None

    @property
    def path(self) -> Path:
        if self._path is not None:
            return self._path
        from core.config import derived_root

        return Path(derived_root()) / STORE_NAME

    # -- файл ---------------------------------------------------------------------------

    def _load(self) -> dict[str, Any]:
        path = self.path
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as exc:
            logger.warning("[outlook] %s нечитаем (%s) - сброшен, папки найдутся обходом",
                           path.name, type(exc).__name__)
            return {}
        return data if isinstance(data, dict) else {}

    def _save(self, state: dict[str, Any]) -> None:
        path = self.path
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
        tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True),
                       encoding="utf-8")
        tmp.replace(path)

    # -- id папок -----------------------------------------------------------------------

    def get_id(self, account: str | None, name: str) -> int | None:
        """Запомненный id пары аккаунт+имя; ``None`` - нет записи (или аккаунт не задан)."""
        if not _norm(account):
            return None
        entry = (self._load().get("folders") or {}).get(_key(account, name))
        try:
            value = int((entry or {}).get("id") or 0)
        except (TypeError, ValueError):
            return None
        return value if value > 0 else None

    def put_id(self, account: str | None, name: str, folder_id: int, *, via: str) -> int | None:
        """Запомнить id; вернуть прежний (``None`` - не было). Без аккаунта не пишет."""
        if not _norm(account) or folder_id < 1:
            return None
        state = self._load()
        folders = dict(state.get("folders") or {})
        key = _key(account, name)
        old = None
        try:
            old = int((folders.get(key) or {}).get("id") or 0) or None
        except (TypeError, ValueError):
            old = None
        if old == folder_id:
            return old
        folders[key] = {
            "account": _norm(account), "name": str(name), "id": int(folder_id),
            "ts": _now_iso(), "via": via,
        }
        state["folders"] = folders
        self._save(state)
        return old

    def forget(self, account: str | None, name: str) -> None:
        state = self._load()
        folders = dict(state.get("folders") or {})
        if folders.pop(_key(account, name), None) is not None:
            state["folders"] = folders
            self._save(state)

    # -- подсказка размера окна ---------------------------------------------------------

    def get_window_hint(self, account: str | None, name: str) -> int | None:
        """Сколько писем с головы понадобилось окну в прошлый раз (с остановкой и контрольной
        страницей); ``None`` - подсказки нет. По ней первый вызов окна берет ровно столько, чтобы
        окно уложилось в ОДИН вызов моста (цена вызова - запуск и адресация, не строки)."""
        if not _norm(account):
            return None
        entry = (self._load().get("windows") or {}).get(_key(account, name))
        try:
            value = int((entry or {}).get("rows") or 0)
        except (TypeError, ValueError):
            return None
        return value if value > 0 else None

    def put_window_hint(self, account: str | None, name: str, rows: int) -> None:
        """Запомнить размер окна (без записи, если не изменился). Без аккаунта не пишет."""
        if not _norm(account) or rows < 1:
            return
        state = self._load()
        windows = dict(state.get("windows") or {})
        key = _key(account, name)
        if int((windows.get(key) or {}).get("rows") or 0) == rows:
            return
        windows[key] = {"rows": int(rows), "ts": _now_iso()}
        state["windows"] = windows
        self._save(state)

    # -- суточный полный проход ---------------------------------------------------------

    def last_full_pass(self, label: str) -> dict[str, Any] | None:
        """Отметка последнего полного прохода спецификации (``inbox[a@b.c]``) или ``None``."""
        entry = (self._load().get("full_pass") or {}).get(label)
        return dict(entry) if isinstance(entry, dict) else None

    def record_full_pass(
        self, label: str, *, ok: bool, window: int, full: int, missing: int, extra: int,
        now: datetime | None = None,
    ) -> None:
        """Итог сверки «окно с головы ↔ полный листинг» спецификации (для доктора и графика).

        ``missing`` - письма, которые есть в полном листинге при том же ``since``, а окно их не
        отдало (опасное расхождение); ``extra`` - окно отдало то, чего нет в полном (подделка).
        """
        state = self._load()
        passes = dict(state.get("full_pass") or {})
        ts = (now or datetime.now(UTC)).astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        passes[label] = {
            "ts": ts, "ok": bool(ok), "window": int(window), "full": int(full),
            "missing": int(missing), "extra": int(extra),
        }
        state["full_pass"] = passes
        self._save(state)
