"""PULT-UX-2 п.2 - чтение письма ДО последнего входящего для «Черновика ответа» (ТЗ-UX §8.2).

Ответ нельзя писать по теме письма: нужен текст последнего входящего сообщения и факт, что на него
еще не ответили. Два входа, один ответ:

* ``item_id`` пункта ленты внимания (``mail:<хеш темы>``) - тред из манифеста почты и сайдкара
  (то же, что ``work_context``), текст последнего ВХОДЯЩЕГО сообщения берется целиком до потолка;
* ``thread`` - ссылка на заметку-тред vault любой формы (путь, id, ``correspondence/conv:...``) -
  ядро чтения заметок (:func:`core.retrieval.find.read_full_note`, ``messages="inbound_last"``):
  тот же NDA-барьер и та же сводка «что не показано», что у ``read_note``.

Ответ - данные, а не исключение: ``{found, via, subject, domains, total, last_from_me, last_date,
inbound: {date, from, text, chars, truncated} | None, needs_reply, ref, code?, reason?}``.
Последнее сообщение - наше (``last_from_me``) - ``needs_reply: false``: пульт скажет об этом ДО
текста. Тред не найден/не читается - ``found: false`` с ``code`` (``not_found``/``unavailable``/
``nda``), а не пустой черновик. ``core`` ⊥ mcp/cli; ни сети, ни модели. Письма не отправляются.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import outlook_ingest_manifest_path
from core.operational import work

__all__ = ["MAX_INBOUND_CHARS", "read_inbound"]

MAX_INBOUND_CHARS = 6000
_MAIL_PREFIX = "mail:"


def _result(**fields: Any) -> dict[str, Any]:
    base: dict[str, Any] = {
        "found": False, "via": None, "subject": "", "domains": [], "total": 0,
        "last_from_me": None, "last_date": None, "inbound": None, "needs_reply": False,
        "ref": None,
    }
    base.update(fields)
    return base


def _clip(text: str, limit: int) -> tuple[str, bool]:
    text = (text or "").strip()
    return (text, False) if len(text) <= limit else (text[:limit].rstrip(), True)


def _from_item(item_id: str, manifest_path: Path | None, threads_dir: Path | None,
               limit: int) -> dict[str, Any]:
    ref_hash = item_id[len(_MAIL_PREFIX):]
    mail_path = manifest_path or outlook_ingest_manifest_path()
    manifest = work._load_json(mail_path)
    if not isinstance(manifest, dict):
        return _result(via="mail_item", ref=item_id, code="unavailable",
                       reason="манифест почты недоступен: тред не прочитан")
    tdir = threads_dir or (Path(mail_path).parent / "mail_threads")
    for key, entry in manifest.items():
        if not isinstance(entry, dict) or work._hash(entry.get("subject")) != ref_hash:
            continue
        subject = str(entry.get("subject") or "(без темы)").strip()
        sidecar = work._load_sidecar(tdir, str(key))
        if not isinstance(sidecar, dict):
            return _result(via="mail_item", ref=item_id, subject=subject, code="unavailable",
                           reason="сайдкар треда недоступен: текст сообщений не прочитан")
        msgs = [m for m in (sidecar.get("messages") or {}).values() if isinstance(m, dict)]
        floor = datetime.min.replace(tzinfo=UTC)
        msgs.sort(key=lambda m: work._parse_iso(m.get("date")) or floor)
        domains = [d for d in (sidecar.get("counterparty_domains") or []) if d]
        if not msgs:
            return _result(via="mail_item", ref=item_id, subject=subject, domains=domains,
                           code="unavailable", reason="в треде нет сообщений")
        last = msgs[-1]
        inbound = next((m for m in reversed(msgs) if not m.get("is_me")), None)
        out = _result(
            found=True, via="mail_item", ref=item_id, subject=subject, domains=domains,
            total=len(msgs), last_from_me=bool(last.get("is_me")),
            last_date=work._date(last.get("date")),
        )
        if inbound is None:
            out.update(code="no_inbound",
                       reason="в треде нет входящих сообщений: отвечать не на что")
            return out
        text, truncated = _clip(str(inbound.get("text") or ""), limit)
        out["inbound"] = {
            "date": work._date(inbound.get("date")), "from": str(inbound.get("from") or "").strip(),
            "text": text, "chars": len(text), "truncated": truncated,
        }
        out["needs_reply"] = not out["last_from_me"]
        return out
    return _result(via="mail_item", ref=item_id, code="not_found",
                   reason="тред не найден в манифесте")


def _from_note(thread: str, vault_path: Path | None, limit: int) -> dict[str, Any]:
    from core.retrieval.find import ReadNoteError, read_full_note
    from core.retrieval.mail_read import parse_thread

    try:
        note = read_full_note(thread, max_chars=limit, vault_path=vault_path,
                              messages="inbound_last")
    except ReadNoteError as exc:
        text = str(exc)
        code = "nda" if "NDA" in text else "not_found"
        return _result(via="thread_note", ref=thread, code=code, reason=text[:200])
    fm = note.get("frontmatter") or {}
    summary = note.get("messages")
    if not isinstance(summary, dict):
        return _result(via="thread_note", ref=thread, subject=str(fm.get("title") or ""),
                       code="unavailable",
                       reason="заметка - не почтовый тред: сообщения не разобраны")
    last_from_me = bool(summary.get("last_from_me"))
    out = _result(
        found=True, via="thread_note", ref=str(note.get("path") or thread),
        subject=str(fm.get("title") or fm.get("subject") or ""),
        domains=[str(d) for d in (fm.get("counterparty_domains") or []) if d],
        total=int(summary.get("total") or 0), last_from_me=last_from_me,
        last_date=summary.get("last_date"),
    )
    parsed = parse_thread(str(note.get("body") or ""))
    inbound = next((m for m in reversed(parsed.messages) if not m.is_me), None) if parsed else None
    if inbound is None or not inbound.text.strip():
        out.update(code="no_inbound", reason="входящего сообщения в треде не прочитано")
        return out
    text, truncated = _clip(inbound.text, limit)
    out["inbound"] = {"date": inbound.date, "from": inbound.sender, "text": text,
                      "chars": len(text),
                      "truncated": truncated or bool(note.get("truncated"))}
    out["needs_reply"] = not last_from_me
    return out


def read_inbound(
    *,
    item_id: str | None = None,
    thread: str | None = None,
    manifest_path: Path | None = None,
    threads_dir: Path | None = None,
    vault_path: Path | None = None,
    max_chars: int = MAX_INBOUND_CHARS,
) -> dict[str, Any]:
    """Тред письма до последнего входящего (см. док модуля). Нужен ``item_id`` либо ``thread``."""
    limit = max(200, int(max_chars))
    if item_id and str(item_id).startswith(_MAIL_PREFIX):
        return _from_item(str(item_id), manifest_path, threads_dir, limit)
    if thread and str(thread).strip():
        return _from_note(str(thread).strip(), vault_path, limit)
    return _result(code="bad_payload",
                   reason="нужен item_id пункта «mail:...» или ссылка thread на тред")
