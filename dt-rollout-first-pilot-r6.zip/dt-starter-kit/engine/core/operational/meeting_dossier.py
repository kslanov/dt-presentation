"""PULT-UX-2 п.1 - вид досье встречи для пульта и заготовка справки без модели (ТЗ-UX §8.1).

Досье :func:`core.operational.meeting_prep.prepare` (сделки, внешняя переписка, заметки vault)
превращается в вид для экрана: участники и сущности, последние договоренности, изменения,
открытые вопросы, источники с датами и ПОКРЫТИЕ - что недоступно, что обрезано, чего в данных нет.
Все пункты выводятся детерминированно из данных досье; чего в данных нет, названо прямо
(``coverage.missing``), а не придумано. Клиенты не смешиваются: каждый факт несет ``client_id``,
а в тексте заготовки и промпта у каждого клиента свой раздел.

Пустой срез при недоступном хранилище (зеркало Timetta, манифест почты) не выдается за «у клиента
ничего нет»: он идет в ``coverage.unavailable``. Предел выдачи (число сделок/тредов/заметок)
показывается как ``coverage.truncated`` (точно, если известен остаток, иначе «возможно, есть еще»).

``core`` ⊥ mcp/cli; ни сети, ни модели.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta
from typing import Any

__all__ = ["CHANGES_DAYS", "dossier_view", "meeting_prompt", "meeting_skeleton", "store_state"]

CHANGES_DAYS = 14
_AGREEMENT_RE = re.compile(r"протокол|итог|договор|решени|встреч|созвон|minutes", re.IGNORECASE)
_WAY = {"inbound": "входящее", "outbound": "исходящее"}


def store_state() -> dict[str, bool]:
    """Какие хранилища досье существуют: ``{mirror, mail}`` (файл есть - читать можно)."""
    from core.config import outlook_ingest_manifest_path, timetta_mirror_path

    return {"mirror": timetta_mirror_path().exists(),
            "mail": outlook_ingest_manifest_path().exists()}


def _src(kind: str, ref: Any, title: Any, date: Any, client: str | None) -> dict[str, Any]:
    return {"kind": kind, "ref": str(ref or ""), "title": str(title or ""), "date": date or None,
            "client_id": client}


def _origin(kind: str, ref: Any, date: Any) -> dict[str, Any]:
    return {"kind": kind, "ref": str(ref or ""), "date": date}


def _deal_lines(deal: dict[str, Any], today: str, since: str) -> tuple[list, list]:
    """Открытые вопросы и изменения по одной сделке."""
    ref = deal.get("code") or deal.get("name")
    head = f"сделка [{deal.get('code') or '-'}] {deal.get('name') or ''}"
    origin = _origin("deal", ref, deal.get("last_activity"))
    asked: list[dict[str, Any]] = []
    changed: list[dict[str, Any]] = []
    if deal.get("open_items"):
        text = f"{head}: открытых пунктов {deal['open_items']}"
        due = deal.get("nearest_due")
        if due:
            text += f", ближайший срок {due}" + (" - просрочен" if due < today else "")
        asked.append({"text": text, "source": origin})
    if (deal.get("last_activity") or "") >= since:
        text = f"{head}: активность {deal['last_activity']}"
        if deal.get("stage"):
            text += f", стадия {deal['stage']}"
        changed.append({"text": text, "source": origin})
    return asked, changed


def _mail_lines(mail: dict[str, Any], since: str) -> tuple[list, list]:
    subject = mail.get("subject") or "(без темы)"
    date = mail.get("date")
    origin = _origin("mail", mail.get("subject"), date)
    asked: list[dict[str, Any]] = []
    changed: list[dict[str, Any]] = []
    if mail.get("direction") == "inbound":
        asked.append({"text": f"письмо «{subject}» от {date or '?'}: последнее сообщение "
                              "входящее, ответа нет", "source": origin})
    if (date or "") >= since:
        way = _WAY.get(str(mail.get("direction")), "направление неизвестно")
        changed.append({"text": f"переписка «{subject}» {date}: {way}", "source": origin})
    return asked, changed


def _note_rows(notes: list[dict[str, Any]], cid: str | None,
               sources: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for note in notes:
        title = note.get("title") or note.get("note_id")
        sources.append(_src("note", note.get("note_id") or note.get("path"), title,
                            note.get("date"), cid))
        rows.append({"title": title, "path": note.get("path"), "note_id": note.get("note_id"),
                     "date": note.get("date"), "agreement": bool(_AGREEMENT_RE.search(str(title)))})
    return rows


class _Coverage:
    """Накопитель покрытия: недоступное, отсутствующее, обрезанное."""

    def __init__(self, stores: dict[str, bool]) -> None:
        self.stores = stores
        self.missing: list[dict[str, str]] = []
        self.truncated: list[dict[str, Any]] = []
        self.unavailable: list[dict[str, str]] = []

    def absent(self, store: str, what: str, why: str, store_why: str) -> None:
        """Пусто: «данных нет» при живом хранилище, «недоступно» при мертвом."""
        if self.stores.get(store, True):
            self.missing.append({"what": what, "why": why})
        else:
            self.unavailable.append({"what": what, "why": store_why})

    def cut(self, what: str, shown: int, total: int | None) -> None:
        self.truncated.append({"what": what, "shown": shown, "total": total,
                               "exact": total is not None})

    def view(self) -> dict[str, Any]:
        partial = bool(self.missing or self.truncated or self.unavailable)
        return {"status": "partial" if partial else "ok", "missing": self.missing,
                "truncated": self.truncated, "unavailable": self.unavailable,
                "stores": dict(self.stores)}


def _client_view(c: dict[str, Any], meeting: dict[str, Any], cov: _Coverage, today: str,
                 since: str, sources: list[dict[str, Any]]) -> dict[str, Any]:
    from core.operational.meeting_prep import MAX_DEALS, MAX_MAIL, MAX_NOTES

    cid, name = c.get("id"), str(c.get("name") or c.get("id") or "")
    deals, other = list(c.get("deals") or []), int(c.get("other_deals") or 0)
    mail, notes = list(c.get("recent_mail") or []), list(c.get("notes") or [])
    asked: list[dict[str, Any]] = []
    changed: list[dict[str, Any]] = []
    for deal in deals:
        sources.append(_src("deal", deal.get("code") or deal.get("name"), deal.get("name"),
                            deal.get("last_activity"), cid))
        a, ch = _deal_lines(deal, today, since)
        asked += a
        changed += ch
    for item in mail:
        sources.append(_src("mail", item.get("subject"), item.get("subject"),
                            item.get("date"), cid))
        a, ch = _mail_lines(item, since)
        asked += a
        changed += ch
    rows = _note_rows(notes, cid, sources)
    agreements = [n for n in rows if n["agreement"]]
    if not deals:
        cov.absent("mirror", f"{name}: сделки", "активных сделок в зеркале нет",
                   "зеркало Timetta недоступно")
    if not mail:
        cov.absent("mail", f"{name}: переписка", "недавних внешних тредов нет",
                   "манифест почты недоступен")
    if not notes:
        cov.missing.append({"what": f"{name}: заметки",
                            "why": "релевантных заметок vault не найдено"})
    if not agreements:
        cov.missing.append({"what": f"{name}: договоренности",
                            "why": "среди найденных заметок нет протоколов и итогов встреч"})
    if other:
        cov.cut(f"{name}: сделки", len(deals), len(deals) + other)
    elif len(deals) >= MAX_DEALS:
        cov.cut(f"{name}: сделки", len(deals), None)
    if len(mail) >= MAX_MAIL:
        cov.cut(f"{name}: переписка", len(mail), None)
    if len(notes) >= MAX_NOTES:
        cov.cut(f"{name}: заметки", len(notes), None)
    return {"id": cid, "name": name, "entity": c.get("entity"), "deals": deals,
            "other_deals": other, "recent_mail": mail, "notes": rows, "agreements": agreements,
            "open_questions": asked, "changes": changed,
            "participants": [str(x) for x in meeting.get("domains") or []]}


def dossier_view(d: dict[str, Any], *, stores: dict[str, bool] | None = None,
                 now: datetime | None = None) -> dict[str, Any]:
    """Досье ``work_meeting_prep`` -> вид для пульта (см. док модуля).

    ``stores`` - доступны ли зеркало Timetta и манифест почты (по умолчанию - по наличию файлов)."""
    cov = _Coverage(stores if stores is not None else store_state())
    now = now or datetime.now(UTC)
    today = now.date().isoformat()
    since = (now - timedelta(days=CHANGES_DAYS)).date().isoformat()
    meeting = d.get("meeting") or {}
    sources: list[dict[str, Any]] = []
    if not cov.stores.get("mirror", True):
        cov.unavailable.append({"what": "сделки", "why": "зеркало Timetta недоступно"})
    if not cov.stores.get("mail", True):
        cov.unavailable.append({"what": "переписка", "why": "манифест почты недоступен"})
    for warn in d.get("warning") or []:
        if isinstance(warn, dict):
            cov.unavailable.append({"what": str(warn.get("code") or "досье"),
                                    "why": str(warn.get("reason") or "")[:240]})
    clients = [_client_view(c, meeting, cov, today, since, sources) for c in d.get("clients") or []]
    notes: list[dict[str, Any]] = []
    if not clients:
        notes = _note_rows(list(d.get("notes") or []), None, sources)
        if not notes:
            cov.missing.append({"what": "контекст по теме", "why": str(
                d.get("hint") or "клиент не определен, по теме ничего не нашлось")})
    for dom in d.get("unresolved_domains") or []:
        cov.missing.append({"what": f"домен {dom}", "why": "нет хаба клиента для домена"})
    return {
        "as_of": d.get("generated_at"),
        "meeting": {"subject": meeting.get("subject") or "",
                    "domains": list(meeting.get("domains") or [])},
        "internal": not clients, "matched_by": d.get("matched_by"), "clients": clients,
        "entities": list(d.get("entities") or []), "notes": notes,
        "needs_clarification": bool(d.get("needs_clarification")),
        "entity_candidates": list(d.get("entity_candidates") or []),
        "unresolved_domains": list(d.get("unresolved_domains") or []),
        "coverage": cov.view(), "sources": sources,
    }


def _tag(src: dict[str, Any]) -> str:
    bits = [str(src.get("kind") or ""), str(src.get("ref") or "")[:60], str(src.get("date") or "")]
    return "[" + ", ".join(b for b in bits if b) + "]"


def _bullets(rows: list[str], empty: str) -> list[str]:
    return [f"- {r}" for r in rows] or [f"- {empty}"]


def _note_line(n: dict[str, Any]) -> str:
    return f"{n['title']}" + (f" ({n['date']})" if n.get("date") else "")


def meeting_skeleton(view: dict[str, Any]) -> str:
    """Заготовка справки ИЗ ДОСЬЕ, без модели: раздел на клиента, у каждого пункта источник и дата.

    То, чего в данных нет, названо прямо («нет данных»): пустой раздел не выдается за
    «все хорошо»."""
    meeting = view["meeting"]
    lines = [f"Справка к встрече: {meeting['subject'] or 'встреча'}", ""]
    if meeting["domains"]:
        lines += ["Контрагенты по календарю: " + ", ".join(meeting["domains"]), ""]
    for c in view["clients"]:
        lines.append(f"Клиент: {c['name']}")
        if isinstance(c.get("entity"), dict):
            lines.append(f"Фокус встречи: {c['entity'].get('name')}")
        lines.append("Последние договоренности:")
        lines += _bullets(
            [f"{n['title']} " + _tag({"kind": "заметка", "ref": n.get("note_id"),
                                      "date": n.get("date")}) for n in c["agreements"]],
            "нет данных: протоколов и итогов встреч в досье нет")
        lines.append(f"Изменения за последние {CHANGES_DAYS} дней:")
        lines += _bullets([f"{x['text']} {_tag(x['source'])}" for x in c["changes"]],
                          "нет данных за этот срок")
        lines.append("Открытые вопросы:")
        lines += _bullets([f"{x['text']} {_tag(x['source'])}" for x in c["open_questions"]],
                          "нет данных")
        if c["notes"]:
            lines.append("Заметки vault:")
            lines += _bullets([_note_line(n) for n in c["notes"]], "")
        lines.append("")
    if view["internal"]:
        lines.append("Внутренняя встреча: контекст по теме")
        lines += _bullets([_note_line(n) for n in view["notes"]],
                          "нет данных: по теме ничего не найдено")
        lines.append("")
    cov = view["coverage"]
    gaps = [f"{m['what']}: {m['why']}" for m in [*cov["unavailable"], *cov["missing"]]]
    gaps += [f"{t['what']}: показано {t['shown']}" + (f" из {t['total']}" if t.get("total")
                                                     else " (возможно, есть еще)")
             for t in cov["truncated"]]
    if gaps:
        lines += ["Чего нет в данных:", *_bullets(gaps, "")]
    return "\n".join(lines).rstrip() + "\n"


def meeting_prompt(view: dict[str, Any]) -> str:
    """Промпт справки: инструкция + досье (то же, что заготовка); фактов извне модель не берет."""
    subject = view["meeting"]["subject"] or "встреча"
    rules = (
        f"Подготовь краткую справку к встрече «{subject}» для ее участника на русском языке.\n"
        "Используй ТОЛЬКО факты из блока [Досье]; ничего не добавляй из общих знаний. "
        "Если по разделу в досье нет данных, напиши «нет данных».\n"
        "Разделы: контекст встречи; последние договоренности; изменения; открытые вопросы; "
        "чего нет в данных.\n"
        "Если клиентов несколько, для каждого свой раздел: факты разных клиентов не смешивать.\n"
        "После каждого факта оставь источник в квадратных скобках так, как он дан в досье.\n"
        "Пиши коротко, без длинных тире и без буквы ё; верни только текст справки."
    )
    return f"{rules}\n\n[Досье]\n{meeting_skeleton(view)}"
