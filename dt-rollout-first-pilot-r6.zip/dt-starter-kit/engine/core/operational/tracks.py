"""Единый контракт значений трека хаба (TRACK-2) — один источник правды.

Трек хаба трёхзначный: ``presale`` (лид → сделка Timetta) / ``project``
(коммерческий проект — клиентская работа в исполнении) / ``internal`` (внутренний
проект). Значения живут **здесь и только здесь**; детектор
(:mod:`core.operational.ripe_leads`), запись (:mod:`core.operational.hub_link`) и
скаффолд (:mod:`core.legacy.linking`) импортируют этот набор, а не заводят свой
литерал (иначе двузначность/трёхзначность разъезжается между модулями — так и
случилось в TRACK-1: контракт был продублирован комментарием, не кодом).

Лист-модуль без внутренних импортов — импортируется кем угодно без риска цикла.
"""

from __future__ import annotations

__all__ = ["TRACKS", "track_label"]

# Допустимые значения явного поля ``track:`` во frontmatter хаба.
TRACKS: frozenset[str] = frozenset({"presale", "project", "internal"})


def track_label(track: str) -> str:
    """Подпись трека человеку по профилю роли (ROLE-DATA-1): ключ ``presale`` остается ключом, а
    показывается «пресейл» (или «гипотеза» у другой роли). Неизвестное значение - как есть."""
    if track not in TRACKS:
        return track
    from core.role.terms import T

    return T(f"track.{track}")
