"""Рабочий сон: что в него не входит - ``_nda``, личное, карантин eval/selftest (один предикат).

Инвариант sleep-1.md §2 п.7: личное и ``_nda`` не входят в рабочий сон. Один предикат на всех
потребителей: заморозка корпуса и кандидаты оценки (SLEEP-EVAL-1, реэкспорт из его ``privacy``) и
реестр входов Сна (SLEEP-INPUT-1). Решение принимается по СТРУКТУРЕ пути и frontmatter (как
:func:`core.privacy.is_nda`), без модели; тело заметки не читается.

Возврат - причина (``nda`` | ``personal`` | ``quarantine``) либо ``None``: заметку брать можно.
Модуль нейтральный (вне пакета оценки): конвейер сна импортирует его, не задевая контрольные ответы.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

from core.privacy import any_eval, is_nda

__all__ = ["REASON_NDA", "REASON_PERSONAL", "REASON_QUARANTINE", "exclusion_reason"]

REASON_NDA, REASON_PERSONAL, REASON_QUARANTINE = "nda", "personal", "quarantine"

_PERSONAL_WORDS = frozenset({"personal", "private", "личное", "личные", "личный", "личная"})
_NDA_WORDS = frozenset({"nda", "confidential", "секретно", "конфиденциально"})
_SPLIT_RE = re.compile(r"[\s_\-./]+")
_FM_FLAG_KEYS = ("privacy", "приватность", "access", "visibility")


def _tokens(value: Any) -> set[str]:
    if isinstance(value, (list, tuple, set)):
        out: set[str] = set()
        for item in value:
            out |= _tokens(item)
        return out
    return {t for t in _SPLIT_RE.split(str(value or "").casefold().replace("ё", "е")) if t}


def _fm_reason(fm: Mapping[str, Any]) -> str | None:
    words: set[str] = set()
    for key in _FM_FLAG_KEYS:
        words |= _tokens(fm.get(key))
    words |= _tokens(fm.get("tags"))
    words |= _tokens(fm.get("type"))
    if fm.get("nda") is True or words & _NDA_WORDS:
        return REASON_NDA
    if fm.get("personal") is True or fm.get("private") is True or words & _PERSONAL_WORDS:
        return REASON_PERSONAL
    purpose = str(fm.get("purpose") or "").strip().lower()
    if purpose in {"eval", "selftest"}:
        return REASON_QUARANTINE
    return None


def exclusion_reason(rel_posix: str, frontmatter: Mapping[str, Any] | None = None, *,
                     source_path: str = "") -> str | None:
    """Причина исключить заметку (``nda`` | ``personal`` | ``quarantine``) или ``None``.

    ``rel_posix`` - путь внутри vault; ``source_path`` - путь исходного файла из frontmatter (у
    нее может быть свой маркер: слаг имени заметки маркер теряет, источник - нет)."""
    if is_nda(rel_posix) or is_nda(source_path):
        return REASON_NDA
    if any_eval(rel_posix, source_path):
        return REASON_QUARANTINE
    fm = frontmatter or {}
    reason = _fm_reason(fm)
    if reason:
        return reason
    if _tokens(rel_posix.split("/")[:-1]) & _PERSONAL_WORDS:
        return REASON_PERSONAL
    from core.legacy.discover import privacy_reason

    if privacy_reason(rel_posix):
        return REASON_PERSONAL
    return None
