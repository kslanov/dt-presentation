"""PROV-CITED-1 - три раздельные квитанции на источник: прочитано / вошло в промпт / обрезано.

Провенанс выхода говорил, ЧТО сессия читала, но не говорил, СКОЛЬКО и что из этого дошло до
модели. «Вернул инструмент» и «вошло в промпт» - разные события (`docs/tz/sleep-1.md` §4.3), а
обрезку по бюджету не видит даже recall@k. Модуль собирает три квитанции только из того, что
движок реально знает:

* **прочитано** - ``rc`` событий журнала запросов (:mod:`core.eval_journal`): сколько символов
  ``read_note``/``lift_source`` отдали хосту, сколько фактов отдал ``get_facts``
  (:class:`core.provenance.ReadPart`);
* **вошло в промпт** и **обрезано** - сборка ``generate``: чанки контекста и образцов с их длиной
  (:func:`prompt_receipt`), а «обрезано» - то, что секция хотела войти, но бюджет родительских
  секций (:mod:`core.retrieval.parent`) не пустил;
* **неизвестно** - не «нет»: чтение хостом в обход DT движок не видит (ручные строки), журнал до
  PROV-CITED-1 объём и обрезку не записывал, выход ``generate`` до PROV-CITED-1 не хранил состав
  промпта. Во всех этих случаях квитанция говорит «неизвестно» и называет причину.

Только числа и пути; тексты не хранятся. Путь/id под NDA в квитанцию не попадают (второй замок
``any_nda``). Сети и модели нет. ``core`` не импортирует ``cli``/``mcp-server``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.provenance import ORIGIN_FACTS, ORIGIN_LIFT, ORIGIN_READ, ReadPart, SourceRow

__all__ = [
    "BYPASS_NOTE",
    "LEGACY_JOURNAL_NOTE",
    "LEGACY_PROMPT_NOTE",
    "RECEIPTS_HEADING",
    "RECEIPTS_MARKER",
    "RECEIPTS_VERSION",
    "ReceiptRow",
    "Receipts",
    "build_receipts",
    "prompt_receipt",
    "render_section",
    "summarize",
]

RECEIPTS_VERSION = 1  # версия формата квитанций в ``meta.yaml: receipts`` (старые - без ключа)


def _nda(*refs: Any) -> bool:
    from core.privacy import any_nda

    return any_nda(*[str(r) for r in refs if r])


def prompt_receipt(assembled: Any) -> dict[str, Any]:
    """Квитанции «вошло в промпт» и «обрезано» собранного промпта ``generate`` (чистые числа).

    Что считается: чанки контекста и стилевые образцы (:class:`core.generation.AssembledPrompt`) -
    число чанков и их длина в символах - ровно то, что :mod:`core.generation` вставил в промпт.
    «Обрезано» - сумма ``metadata["parent_cut"]`` хитов по секциям (одна секция - один раз):
    чанки и символы секции, которые она хотела получить, но бюджет/потолок секции не пустил.
    Возврат::

        {chunks, chars, prompt_chars, facts, cut: {chunks, chars, sections},
         sources: [{note_id, path, chunks, chars, cut_chunks, cut_chars}]}

    NDA-источники в итоги входят, а в список ``sources`` - нет (путь не пишем).
    """
    items: list[Any] = [*getattr(assembled, "exemplars", []),
                        *(ch.result for ch in getattr(assembled, "context", []))]
    per: dict[str, dict[str, Any]] = {}
    sections: dict[str, dict[str, Any]] = {}  # section -> parent_cut (одна секция - один раз)
    chunks = chars = 0
    for r in items:
        text_len = len(getattr(r, "text", "") or "")
        chunks += 1
        chars += text_len
        key = str(r.note_id or r.source_path or "")
        entry = per.setdefault(key, {
            "note_id": str(r.note_id or ""), "path": str(r.source_path or ""),
            "chunks": 0, "chars": 0, "cut_chunks": 0, "cut_chars": 0, "_sections": set()})
        entry["chunks"] += 1
        entry["chars"] += text_len
        cut = (getattr(r, "metadata", None) or {}).get("parent_cut")
        if isinstance(cut, dict) and cut.get("chunks"):
            section = str(cut.get("section") or key)
            prev = sections.get(section)
            if prev is None or int(cut.get("chars") or 0) > int(prev.get("chars") or 0):
                sections[section] = cut
            if section not in entry["_sections"]:
                entry["_sections"].add(section)
    for entry in per.values():
        for section in entry.pop("_sections"):
            entry["cut_chunks"] += int(sections[section].get("chunks") or 0)
            entry["cut_chars"] += int(sections[section].get("chars") or 0)
    visible = [e for e in per.values() if not _nda(e["note_id"], e["path"])]
    return {
        "chunks": chunks,
        "chars": chars,
        "prompt_chars": len(getattr(assembled, "prompt", "") or ""),
        "facts": len(getattr(assembled, "facts", []) or []),
        "cut": {
            "chunks": sum(int(c.get("chunks") or 0) for c in sections.values()),
            "chars": sum(int(c.get("chars") or 0) for c in sections.values()),
            "sections": len(sections),
        },
        "sources": visible,
    }


# --------------------------------------------------------------------------- #
# Сводка по выходу                                                               #
# --------------------------------------------------------------------------- #
RECEIPTS_HEADING = "## Квитанции"
# Первая ячейка строк таблицы квитанций: потребители, читающие ЛЮБУЮ таблицу ``sources.md`` по
# первой ячейке (eval ``sources_min``, доктор), по ней отличают квитанцию от источника.
RECEIPTS_MARKER = "rcpt"

LEGACY_JOURNAL_NOTE = ("журнал до PROV-CITED-1 - объем чтения и обрезка не записывались: у части "
                       "чтений объем неизвестен (это не «ноль»)")
LEGACY_PROMPT_NOTE = ("выход до PROV-CITED-1 - состав промпта и обрезка не записывались: "
                      "что вошло и что обрезано, неизвестно")
BYPASS_NOTE = ("чтение в обход DT (ручные строки `sources=`) движок не видит: объем и обрезка "
               "неизвестны, это не «не читалось»")
_ROWS_MAX = 60

# Состояние квитанций промпта: известны (generate записал) | нет (выход без generate) | legacy.
PROMPT_KNOWN, PROMPT_NONE, PROMPT_LEGACY = "known", "none", "legacy"


@dataclass(frozen=True)
class ReceiptRow:
    """Три квитанции на один источник. ``in_prompt`` - запись источника из квитанции промпта."""

    path: str
    note_id: str
    origin: str
    reads: tuple[ReadPart, ...]
    seen: bool  # движок видел чтение (read/lift/facts)
    in_prompt: dict[str, Any] | None = None


@dataclass
class Receipts:
    rows: list[ReceiptRow]
    prompt: dict[str, Any] | None
    prompt_state: str
    journal_on: bool = True
    legacy_events: int = 0
    manual: int = 0  # строк, о чтении которых движок ничего не видит


def build_receipts(
    rows: list[SourceRow],
    *,
    meta: dict[str, Any] | None = None,
    generate: bool = False,
    journal_on: bool = True,
    legacy_events: int = 0,
) -> Receipts:
    """Квитанции выхода: строки сессии + квитанция промпта из ``meta.yaml: receipts``.

    ``generate`` - папка от ``generate`` (у ad-hoc-выхода промпта нет: ``prompt_state: none``).
    Папка ``generate`` без ``receipts`` в мете - выход до PROV-CITED-1 (``legacy``).
    """
    raw = (meta or {}).get("receipts")
    prompt = raw.get("prompt") if isinstance(raw, dict) else None
    prompt = prompt if isinstance(prompt, dict) else None
    state = PROMPT_KNOWN if prompt is not None else (PROMPT_LEGACY if generate else PROMPT_NONE)
    entries = [e for e in (prompt or {}).get("sources") or [] if isinstance(e, dict)]
    used: set[int] = set()
    out: list[ReceiptRow] = []
    manual = 0
    for r in rows:
        parts = set(r.origin.split("+"))
        seen = bool(parts & {ORIGIN_READ, ORIGIN_LIFT, ORIGIN_FACTS})
        if not seen:
            manual += 1
        entry = next((i for i, e in enumerate(entries)
                      if i not in used and ((r.note_id and e.get("note_id") == r.note_id)
                                            or (r.path and e.get("path") == r.path))), None)
        if entry is not None:
            used.add(entry)
        out.append(ReceiptRow(
            path=r.path, note_id=r.note_id, origin=r.origin, reads=r.reads, seen=seen,
            in_prompt=entries[entry] if entry is not None else None))
    for i, e in enumerate(entries):  # источники, попавшие в промпт сами (хост их не открывал)
        if i not in used:
            out.append(ReceiptRow(
                path=str(e.get("path") or ""), note_id=str(e.get("note_id") or ""),
                origin="prompt", reads=(), seen=False, in_prompt=e))
    return Receipts(rows=out, prompt=prompt, prompt_state=state, journal_on=journal_on,
                    legacy_events=legacy_events, manual=manual)


def _num(n: int) -> str:
    return f"{n:,}".replace(",", " ")


def _plural(n: int, one: str, few: str, many: str) -> str:
    n10, n100 = n % 10, n % 100
    if n10 == 1 and n100 != 11:
        return one
    if 2 <= n10 <= 4 and not 12 <= n100 <= 14:
        return few
    return many


def _chunks(n: int) -> str:
    return f"{n} {_plural(n, 'чанк', 'чанка', 'чанков')}"


def _sources_word(n: int) -> str:
    return f"{n} {_plural(n, 'источник', 'источника', 'источников')}"


def _read_totals(rows: list[ReceiptRow]) -> dict[str, Any]:
    """Свод «прочитано»: источники, символы, факты, усечённые чтением, источники без объема."""
    sources = chars = facts = truncated = unknown = 0
    for r in rows:
        if not r.seen:
            continue
        sources += 1
        row_unknown = False
        row_truncated = False
        for part in r.reads or (ReadPart("?"),):
            if part.facts is not None:
                facts += part.facts
            if part.tool == "get_facts":
                row_unknown |= part.facts is None
                continue
            if part.chars is None:
                row_unknown = True
                continue
            chars += part.chars
            row_truncated |= bool(part.truncated)
        unknown += row_unknown
        truncated += row_truncated
    return {"sources": sources, "chars": chars, "facts": facts, "truncated": truncated,
            "unknown": unknown}


def summarize(rc: Receipts) -> dict[str, Any]:
    """Свод квитанций выхода: числа, состояние, строка и заметки (для ответа ``save_output``)."""
    read = _read_totals(rc.rows)
    prompt: dict[str, Any] = {"state": rc.prompt_state}
    cut: dict[str, Any] = {"state": rc.prompt_state}
    if rc.prompt is not None:
        known = rc.prompt
        prompt |= {"chunks": int(known.get("chunks") or 0),
                   "chars": int(known.get("chars") or 0)}
        cut_raw = known.get("cut")
        raw_cut: dict[str, Any] = cut_raw if isinstance(cut_raw, dict) else {}
        cut |= {"chunks": int(raw_cut.get("chunks") or 0), "chars": int(raw_cut.get("chars") or 0),
                "sections": int(raw_cut.get("sections") or 0)}
    notes: list[str] = []
    if rc.legacy_events:
        notes.append(LEGACY_JOURNAL_NOTE)
    if rc.prompt_state == PROMPT_LEGACY:
        notes.append(LEGACY_PROMPT_NOTE)
    if rc.manual:
        notes.append(BYPASS_NOTE)
    out = {"read": read, "prompt": prompt, "cut": cut, "manual": rc.manual,
           "legacy_events": rc.legacy_events, "journal": "on" if rc.journal_on else "off",
           "notes": notes}
    out["line"] = _line(out)
    return out


def _line(s: dict[str, Any]) -> str:
    """Одна строка: «прочитано N · в промпте M · обрезано K (символов/чанков)»."""
    read, prompt, cut = s["read"], s["prompt"], s["cut"]
    if s["journal"] == "off":
        first = "прочитано: неизвестно (журнал запросов выключен, DT_EVAL_QUERY_LOG=0)"
    else:
        extra = [f"{_num(read['chars'])} симв."] if read["sources"] else []
        if read["facts"]:
            extra.append(f"{read['facts']} фактов")
        if read["truncated"]:
            extra.append(f"усечено чтением: {read['truncated']}")
        if read["unknown"]:
            extra.append(f"объем неизвестен у {read['unknown']}")
        first = f"прочитано {_sources_word(read['sources'])}" + (
            f" ({'; '.join(extra)})" if extra else "")
    if prompt["state"] == PROMPT_KNOWN:
        second = f"в промпте {_chunks(prompt['chunks'])} ({_num(prompt['chars'])} симв.)"
        third = (f"обрезано {_chunks(cut['chunks'])} ({_num(cut['chars'])} симв.)"
                 if cut["chunks"] else "обрезано 0")
    elif prompt["state"] == PROMPT_LEGACY:
        second = "в промпте: неизвестно (выход до PROV-CITED-1)"
        third = "обрезано: неизвестно (выход до PROV-CITED-1)"
    else:
        second = "в промпте: нет (generate не вызывался)"
        third = "обрезано: нет (generate не вызывался)"
    tail = ""
    if s["manual"]:
        tail += f" · мимо DT: {_sources_word(s['manual'])} (объем неизвестен)"
    if s["legacy_events"]:
        n = s["legacy_events"]
        tail += (f" · журнал до PROV-CITED-1: у {n} {_plural(n, 'чтения', 'чтений', 'чтений')} "
                 "объем не записан")
    return f"Квитанции: {first} · {second} · {third}{tail}"


def _cell(value: str) -> str:
    return " ".join(str(value or "").split()).replace("|", "/")


def _read_cell(r: ReceiptRow) -> str:
    if not r.seen:
        return "мимо DT: неизвестно" if r.origin != "prompt" else "нет вызовов DT"
    texts: list[str] = []
    unknown = False
    chars = 0
    cut_by_read = False
    for part in r.reads or (ReadPart("?"),):
        if part.tool == "get_facts":
            texts.append(f"факты: {part.facts}" if part.facts is not None else "факты: неизвестно")
        elif part.chars is None:
            unknown = True
        else:
            chars += part.chars
            cut_by_read |= bool(part.truncated)
    sized = [p for p in r.reads if p.tool != "get_facts" and p.chars is not None]
    if sized and not unknown:
        total = sum(p.total or 0 for p in sized) if all(p.total for p in sized) else None
        head = f"{_num(chars)} симв."
        if cut_by_read and total:
            head = f"{_num(chars)} из {_num(total)} симв. (усечено чтением)"
        elif cut_by_read:
            head += " (усечено чтением)"
        texts.insert(0, head)
    elif unknown and sized:
        texts.insert(0, f"не менее {_num(chars)} симв. (часть чтений без объема)")
    elif unknown:
        texts.insert(0, "неизвестно (журнал до PROV-CITED-1)")
    return "; ".join(texts) or "неизвестно"


def _prompt_cell(r: ReceiptRow, state: str) -> str:
    if state == PROMPT_NONE:
        return "-"
    if state == PROMPT_LEGACY:
        return "неизвестно"
    e = r.in_prompt
    if not e:
        return "нет"
    return f"{_chunks(int(e.get('chunks') or 0))} · {_num(int(e.get('chars') or 0))} симв."


def _cut_cell(r: ReceiptRow, state: str) -> str:
    if state == PROMPT_NONE:
        return "-"
    if state == PROMPT_LEGACY:
        return "неизвестно"
    e = r.in_prompt or {}
    k = int(e.get("cut_chunks") or 0)
    return f"{_chunks(k)} · {_num(int(e.get('cut_chars') or 0))} симв." if k else "нет"


def render_section(rc: Receipts) -> str:
    """Автосекция ``## Квитанции``: строка-свод + таблица по источникам + заметки о неполноте.

    Первая ячейка каждой строки таблицы - :data:`RECEIPTS_MARKER` (не источник, не ручная строка).
    Пустой набор строк (читать/промптить было нечего) и известное «нет generate» - секции нет.
    """
    if not rc.rows and rc.prompt_state == PROMPT_NONE:
        return ""
    summary = summarize(rc)
    head = [RECEIPTS_HEADING, "", summary["line"], ""]
    lines = ["| rcpt | источник | прочитано | в промпте | обрезано |",
             "| --- | --- | --- | --- | --- |"]
    for r in rc.rows[:_ROWS_MAX]:
        name = r.path or r.note_id
        label = f"{name} ({r.note_id})" if r.note_id and r.path and r.note_id != r.path else name
        lines.append(f"| {RECEIPTS_MARKER} | {_cell(label)} | {_cell(_read_cell(r))} | "
                     f"{_cell(_prompt_cell(r, rc.prompt_state))} | "
                     f"{_cell(_cut_cell(r, rc.prompt_state))} |")
    if len(rc.rows) > _ROWS_MAX:
        lines.append(f"| {RECEIPTS_MARKER} | … и еще {len(rc.rows) - _ROWS_MAX} | - | - | - |")
    body = head + (lines if rc.rows else [])
    if summary["notes"]:
        body += ["", *(f"- {n}" for n in summary["notes"])]
    return "\n".join(body) + "\n"
