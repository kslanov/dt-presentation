"""RESOURCE-1 п.3 — ресурсы по железу: сколько RAM и какой профиль эмбеддера из этого следует.

Было: модель грузилась fp32 (2,27 ГБ весов, на MPS ~5 ГБ с активациями), батч по умолчанию 64 на
MPS независимо от RAM; на Mac с 16 ГБ рядом с браузером и почтой это штатный MPS OOM. Стало:
профиль выбирается один раз по памяти машины, а явные ручки его перекрывают.

========  ======  =====  =====
RAM, ГБ   device  dtype  батч
========  ======  =====  =====
>= 32     mps     fp32   64     (как раньше)
16 - 31   mps     fp16   32
< 16      mps     fp16   16
========  ======  =====  =====

``device`` в таблице - целевое устройство Apple Silicon; без MPS (CUDA/CPU) профиль по RAM не
применяется: fp32, батч 64 на CUDA и 32 на CPU, как было. fp16 на CPU не используется никогда
(медленнее и без части ядер) - после фолбэка MPS→CPU модель грузится fp32.

Приоритет: явные ``DT_EMBED_DEVICE``/``DT_EMBED_BATCH_SIZE``/``DT_EMBED_DTYPE`` > профиль по RAM.
Вектора наружу всегда float32 и той же размерности (1024): профиль меняет только то, В ЧЕМ считает
модель, а не что она отдает; индекс LanceDB не перестраивается.
"""

from __future__ import annotations

import functools
import os
import subprocess
from typing import Any

__all__ = [
    "RAM_TIERS",
    "dtype_override",
    "embed_profile",
    "footprint_warn_gib",
    "models_worker_max_gib",
    "ram_gib",
]

_GIB = 1024 ** 3

# (нижняя граница RAM, ГБ; dtype; батч на MPS) - сверху вниз, первое совпадение.
RAM_TIERS: tuple[tuple[float, str, int], ...] = (
    (32.0, "fp32", 64),
    (16.0, "fp16", 32),
    (0.0, "fp16", 16),
)

_DTYPE_ALIASES = {"fp16": "fp16", "float16": "fp16", "half": "fp16",
                  "fp32": "fp32", "float32": "fp32", "float": "fp32"}


@functools.cache
def ram_gib() -> float | None:
    """Физическая память машины, ГБ (``sysctl -n hw.memsize``; нет утилиты - ``os.sysconf``).
    ``None`` - не определилась (профиль идет по среднему уровню, честно помечено в ``tier``).
    Память не меняется за жизнь процесса - кэшируется (в тестах: ``ram_gib.cache_clear()``)."""
    try:
        out = subprocess.run(
            ["sysctl", "-n", "hw.memsize"],  # noqa: S607
            capture_output=True, text=True, timeout=5, check=False,
        ).stdout.strip()
        if out.isdigit() and int(out) > 0:
            return int(out) / _GIB
    except (OSError, subprocess.SubprocessError):
        pass
    try:
        pages, size = os.sysconf("SC_PHYS_PAGES"), os.sysconf("SC_PAGE_SIZE")
        if pages > 0 and size > 0:
            return pages * size / _GIB
    except (ValueError, OSError, AttributeError):
        pass
    return None


def dtype_override() -> str | None:
    """``DT_EMBED_DTYPE`` как ``fp16``/``fp32``; пусто или мусор - ``None`` (решает профиль)."""
    raw = (os.environ.get("DT_EMBED_DTYPE") or "").strip().lower()
    return _DTYPE_ALIASES.get(raw)


_TIER_LABELS = ("≥ 32 ГБ", "16-31 ГБ", "< 16 ГБ")  # по строкам RAM_TIERS


def _tier(ram: float | None) -> tuple[str, str, int]:
    """``(метка уровня, dtype, батч)``; RAM неизвестна - средний уровень."""
    if ram is None:
        return "RAM неизвестна → как 16-31 ГБ", RAM_TIERS[1][1], RAM_TIERS[1][2]
    for (low, dtype, batch), label in zip(RAM_TIERS, _TIER_LABELS, strict=True):
        if ram >= low:
            return label, dtype, batch
    return _TIER_LABELS[-1], RAM_TIERS[-1][1], RAM_TIERS[-1][2]


_UNSET: Any = object()


def embed_profile(ram: Any = _UNSET, device: str | None = None) -> dict[str, Any]:
    """Профиль эмбеддера: ``{device, dtype, batch_size, ram_gib, tier, source}``.

    ``ram`` - ГБ (не задан - :func:`ram_gib`; ``None`` явно - «неизвестна»); ``device`` - устройство
    (не задано - автоопределение ``core.embeddings._detect_device``, там же ``DT_EMBED_DEVICE``).
    ``source`` - откуда взято каждое поле (``env`` | ``профиль`` | ``устройство``), чтобы доктор и
    инсталлер говорили «почему так», а не только «как».
    """
    from core import embeddings

    if ram is _UNSET:
        ram = ram_gib()
    explicit_device = bool((os.environ.get("DT_EMBED_DEVICE") or "").strip())
    dev = device or embeddings._detect_device()
    label, tier_dtype, tier_batch = _tier(ram)
    source: dict[str, str] = {"device": "env" if explicit_device else "авто"}

    if dev == "mps":
        dtype, batch = tier_dtype, tier_batch
        source["dtype"] = source["batch_size"] = "профиль"
    else:  # CUDA/CPU: профиль по RAM не применяется (он калибровался под общую память MPS)
        dtype, batch = "fp32", (64 if dev == "cuda" else 32)
        source["dtype"] = source["batch_size"] = "устройство"
    forced = dtype_override()
    if forced is not None:
        dtype, source["dtype"] = forced, "env"
    if dev == "cpu" and dtype == "fp16":
        dtype, source["dtype"] = "fp32", "устройство"  # fp16 на CPU не поддержан
    raw_batch = (os.environ.get("DT_EMBED_BATCH_SIZE") or "").strip()
    if raw_batch.isdigit():
        batch, source["batch_size"] = max(1, int(raw_batch)), "env"
    return {
        "device": dev, "dtype": dtype, "batch_size": batch,
        "ram_gib": round(ram, 1) if ram is not None else None,
        "tier": label, "source": source,
    }


def footprint_warn_gib(ram: Any = _UNSET) -> float:
    """Порог предупреждения о памяти демона, ГБ: ``DT_DAEMON_FOOTPRINT_WARN_GIB``, иначе RAM/2
    (RAM неизвестна - 8 ГБ). Один порог для доктора, монитора и ``dt install --check``."""
    raw = (os.environ.get("DT_DAEMON_FOOTPRINT_WARN_GIB") or "").strip()
    try:
        value = float(raw) if raw else 0.0
    except ValueError:
        value = 0.0
    if value > 0:
        return value
    if ram is _UNSET:
        ram = ram_gib()
    return round(ram / 2, 1) if ram else 8.0


def models_worker_max_gib(ram: Any = _UNSET) -> float:
    """Порог footprint воркера моделей, ГБ (RESOURCE-2): ``DT_MODELS_WORKER_MAX_GIB``, иначе RAM/2
    (RAM неизвестна - 8 ГБ). Воркер, переросший порог между запросами, перезапускается сразу."""
    raw = (os.environ.get("DT_MODELS_WORKER_MAX_GIB") or "").strip()
    try:
        value = float(raw) if raw else 0.0
    except ValueError:
        value = 0.0
    if value > 0:
        return value
    if ram is _UNSET:
        ram = ram_gib()
    return round(ram / 2, 1) if ram else 8.0
