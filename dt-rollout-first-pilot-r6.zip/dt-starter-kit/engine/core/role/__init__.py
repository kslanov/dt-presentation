"""ROLE-DATA-1: профиль роли как данные - ``vault/_system/role.yaml`` поверх пресета.

* :mod:`core.role.schema` - схема v1, разбор документа, коды отказа (чистые функции);
* :mod:`core.role.load` - единственная точка чтения, кэш по mtime (:func:`get_role`);
* :mod:`core.role.terms` - ``T(key)`` и закрытый список терминов;
* ``presets/`` - пресеты ``consulting-sales``, ``personal``, ``product-analytics`` (YAML).

Потребители (манифест поверхности, сканер хабов, ``parse_task``/``planner``, экспорт скиллов,
строки движка) читают роль отсюда и файл ``role.yaml`` сами не открывают.
"""

from core.role.load import Loaded, builtin_preset, builtin_presets, get_role, role_file
from core.role.schema import Role, RoleIssue
from core.role.terms import T

__all__ = [
    "Loaded", "Role", "RoleIssue", "T", "builtin_preset", "builtin_presets", "get_role",
    "role_file",
]
