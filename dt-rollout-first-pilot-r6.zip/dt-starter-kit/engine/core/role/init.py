"""ROLE-DATA-1: разовое создание ``vault/_system/role.yaml`` (``dt role init``,
``dt vault init --role``).

Движок профиль только ЧИТАЕТ; единственный писатель - эта функция по явной команде человека:
файл с одной строкой ``preset`` и закомментированными примерами правок. Существующий файл без
``force`` не трогается; с ``force`` - перезапись с бэкапом ``role.yaml.bak-<ts>``. Запись атомарная
(temp+rename), в vault шеллом не пишем.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from core.mcp_json_edit import backup_file, write_text_atomic
from core.role.load import VAULT_PRESETS_DIRNAME, builtin_presets, role_file
from core.role.schema import SCHEMA_VERSION

__all__ = ["InitResult", "ROLE_TEMPLATE", "init_role", "known_presets", "readme_captions"]

ROLE_TEMPLATE = """\
# Профиль роли (ROLE-DATA-1): правки поверх пресета. Файл пишет человек, движок его только читает.
# Ключи сущностей и папки vault не меняются (client, 04-clients, track: presale): меняются подписи.
# Проверка: `dt role check`; что действует: `dt role show --effective`. Правка видна без рестарта.
# Список-поле пишется {{add: [...], remove: [...]}}; блок с ошибкой отбрасывается, действует пресет.
schema: {schema}
preset: {preset}
# label: "Название роли в заголовке пульта"
# vocabulary:
#   entities:
#     client: {{label: заказчик, plural: заказчики}}
#   terms: {{deal: заявка}}
# surface:
#   sections: {{remove: [work-kpis]}}
#   card_kinds: {{remove: [assignment]}}
# scanner:
#   stop_words_add: [тест]
#   deal_signal: false
# scenarios:
#   keywords: {{rnd: [аналитик]}}
# skills:
#   exclude: [capture-to-assignment]
#   overlays: true
"""


@dataclass
class InitResult:
    path: Path
    created: bool = False
    skipped: bool = False
    backup: str = ""
    preset: str = ""
    notes: list[str] = field(default_factory=list)


def known_presets(vault_path: Path | None = None) -> tuple[str, ...]:
    """Встроенные пресеты и пресеты ``vault/_system/role-presets/``."""
    out = list(builtin_presets())
    pdir = role_file(vault_path).parent / VAULT_PRESETS_DIRNAME
    if pdir.is_dir():
        out += sorted(p.stem for p in pdir.glob("*.yaml") if p.stem not in out)
    return tuple(out)


def init_role(vault_path: Path | None, preset: str, *, force: bool = False) -> InitResult:
    """Создать ``role.yaml`` с пресетом ``preset``. Неизвестный пресет - ``ValueError`` (файл не
    создается: профиль с несуществующим пресетом был бы ошибкой с первой секунды)."""
    names = known_presets(vault_path)
    if preset not in names:
        raise ValueError(f"пресет {preset!r}: допустимы {', '.join(names)}")
    target = role_file(vault_path)
    result = InitResult(target, preset=preset)
    if target.exists():
        if not force:
            result.skipped = True
            return result
        result.backup = backup_file(target).name
    target.parent.mkdir(parents=True, exist_ok=True)
    write_text_atomic(target, ROLE_TEMPLATE.format(schema=SCHEMA_VERSION, preset=preset))
    result.created = True
    return result


def readme_captions(preset: str, vault_path: Path | None = None) -> dict[str, str]:
    """Подписи роли для README папок каркаса: ``{папка: текст}``.

    Папки хабов (``04-clients``, ``03-projects``, ``02-knowledge``) называют сущности по-старому;
    текст говорит, как их называет роль (ключи и имена папок прежние). Пусто, если роль называет
    сущности так же, как пресет ``consulting-sales`` (каркас остается байт в байт прежним)."""
    from core.role.load import builtin_preset, get_role

    base = builtin_preset("consulting-sales").entities
    role = (builtin_preset(preset) if preset in builtin_presets()
            else get_role(vault_path).role)
    if all(role.entities[k] == base[k] for k in base):
        return {}

    def cap(keys: tuple[str, ...]) -> str:
        parts = [f"`{k}` - «{role.entities[k].one}»" for k in keys]
        return ("\n## Подписи роли «" + (role.label or preset) + "»\n\nКлючи и папки прежние, "
                "человеку они называются так: " + ", ".join(parts) + ".\n")

    return {
        "04-clients/README.md": cap(("client",)),
        "03-projects/README.md": cap(("project",)),
        "02-knowledge/README.md": cap(("product", "direction", "industry")),
    }
