"""ROLE-DATA-1: единственная точка чтения профиля роли ``vault/_system/role.yaml``.

Порядок применения (дизайн ROLE-AS-DATA §3.1): **пресет -> правки профиля -> вентили коннекторов
(``core.surface.manifest``) -> ingest-корни**. Без файла экземпляр работает по пресету своей роли
(``work`` -> ``consulting-sales``, ``personal`` -> ``personal``): ``role.yaml`` в vault владельца не
заводится, поведение байт в байт прежнее.

Образец - :mod:`core.owner.store`: кэш по ``(путь, mtime_ns, размер)`` файлов, от которых зависит
результат (``role.yaml``, пресет из ``_system/role-presets/``, каталог политик), правка в Obsidian
видна следующему вызову без рестарта демона; горячий путь (``T()`` в строке движка) - несколько
``stat``. Движок профиль только ЧИТАЕТ; пишет человек или разовый ``dt role init``.

Читатель не падает и не подменяет молча (§9 п.22): нет файла/битый YAML/версия новее - действует
пресет, причина лежит в :attr:`Loaded.issues` (доктор, ``dt role check``,
``pult_manifest.warnings``).
Файл ``role.yaml`` читается ТОЛЬКО здесь (гард ``tests/test_role_guards.py``).
"""

from __future__ import annotations

import hashlib
import re
import threading
from dataclasses import dataclass, field, replace
from functools import cache
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]  # стаб-гэп PyYAML - как в core.owner.schema

from core.config import ENGINE_ROOT, retrieval_policies_path, vault_system_path
from core.role.schema import (
    CODES,
    SCHEMA_VERSION,
    Ctx,
    Role,
    RoleIssue,
    apply_doc,
    empty_role,
)

__all__ = [
    "DEFAULT_PRESET",
    "Loaded",
    "PRESETS_DIR",
    "ROLE_FILE",
    "VAULT_PRESETS_DIRNAME",
    "builtin_preset",
    "builtin_presets",
    "default_preset",
    "get_role",
    "role_file",
]

ROLE_FILE = "role.yaml"
VAULT_PRESETS_DIRNAME = "role-presets"
PRESETS_DIR = Path(__file__).resolve().parent / "presets"
#: пресет по роли экземпляра (``DT_INSTANCE_ROLE``), если ``role.yaml`` не задает свой
DEFAULT_PRESET = {"work": "consulting-sales", "personal": "personal"}
_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]*$")


@dataclass(frozen=True)
class Loaded:
    """Результат чтения: действующая роль и все, что о ней надо знать диагностике."""

    role: Role
    issues: tuple[RoleIssue, ...] = ()
    path: Path = Path(ROLE_FILE)
    present: bool = False  # лежит ли role.yaml
    requested: str = ""  # preset из файла (пусто - не задан)
    version: str = ""  # sha256 файла(ов) профиля, 12 символов; пусто без файла
    customized: bool = False  # действующая роль отличается от умолчательного пресета
    deps: tuple[Path, ...] = field(default=(), repr=False, compare=False)

    @property
    def errors(self) -> list[RoleIssue]:
        return [i for i in self.issues if i.severity == "error"]

    @property
    def warnings(self) -> list[RoleIssue]:
        return [i for i in self.issues if i.severity == "warn"]


# --------------------------------------------------------------------------- #
# Пресеты                                                                       #
# --------------------------------------------------------------------------- #
def builtin_presets() -> tuple[str, ...]:
    """Имена пресетов, которые едут с движком."""
    return tuple(sorted(p.stem for p in PRESETS_DIR.glob("*.yaml")))


def default_preset(role: str) -> str:
    return DEFAULT_PRESET.get(role, DEFAULT_PRESET["work"])


@cache
def _builtin(name: str) -> tuple[Role, tuple[RoleIssue, ...]]:
    data = yaml.safe_load((PRESETS_DIR / f"{name}.yaml").read_text(encoding="utf-8")) or {}
    base = empty_role()
    extends = data.get("extends")
    if extends:
        base = _builtin(str(extends))[0]
    role, issues = apply_doc(base, data, check=False)
    return replace(role, preset=name), tuple(issues)


def builtin_preset(name: str) -> Role:
    """Встроенный пресет как роль. Битый встроенный пресет - ошибка разработки, не профиля."""
    if name not in builtin_presets():
        raise KeyError(f"нет встроенного пресета {name!r}")
    role, issues = _builtin(name)
    if issues:  # гард tests/test_role_presets.py: встроенные пресеты читаются без замечаний
        raise ValueError(f"пресет {name}: {'; '.join(str(i) for i in issues)}")
    return role


# --------------------------------------------------------------------------- #
# Чтение                                                                        #
# --------------------------------------------------------------------------- #
def role_file(vault_path: Path | None = None) -> Path:
    """``<vault>/_system/role.yaml`` (без vault_path - vault по умолчанию)."""
    return vault_system_path(vault_path) / ROLE_FILE


def _vault_preset_path(vault_path: Path | None, name: str) -> Path:
    return vault_system_path(vault_path) / VAULT_PRESETS_DIRNAME / f"{name}.yaml"


def _stat(path: Path) -> tuple[int, int]:
    try:
        st = path.stat()
        return (st.st_mtime_ns, st.st_size)
    except OSError:
        return (-1, -1)


def _make_ctx(vault_path: Path | None) -> Ctx:
    policies = retrieval_policies_path(vault_path)

    def policy_exists(case: str) -> bool:
        if not _NAME_RE.match(case.replace("_", "-")):
            return False
        if (policies / f"{case}.yaml").is_file():
            return True
        try:
            for path in sorted(policies.glob("*.yaml")):
                data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                if isinstance(data, dict) and data.get("use_case") == case:
                    return True
        except (OSError, yaml.YAMLError):
            return False
        return False

    def skill_exists(name: str) -> bool:
        if name == "dt-owner":  # генерируется из профиля владельца при экспорте
            return True
        return any((ENGINE_ROOT / d / name / "SKILL.md").is_file()
                   for d in ("skills", "skills-personal"))

    vault_presets: list[str] = []
    pdir = vault_system_path(vault_path) / VAULT_PRESETS_DIRNAME
    if pdir.is_dir():
        vault_presets = sorted(p.stem for p in pdir.glob("*.yaml"))
    return Ctx(policy_exists, skill_exists, (*builtin_presets(), *vault_presets))


def _issue(code: str, path: str, message: str) -> RoleIssue:
    return RoleIssue(code, CODES[code], path, message)


def _read_yaml(path: Path, label: str) -> tuple[dict[str, Any] | None, bytes, list[RoleIssue]]:
    """``(документ, байты, замечания)``; документ ``None`` - файл не читается/не YAML/не словарь."""
    try:
        raw = path.read_bytes()
    except OSError as exc:
        return None, b"", [_issue("role_yaml_unreadable", label,
                                  f"не читается: {type(exc).__name__}")]
    try:
        data = yaml.safe_load(raw.decode("utf-8", errors="replace"))
    except yaml.YAMLError as exc:
        first = str(exc).strip().splitlines()[0] if str(exc).strip() else "ошибка YAML"
        return None, raw, [_issue("role_yaml_invalid", label, f"не YAML: {first}")]
    if data is None:
        data = {}
    if not isinstance(data, dict):
        return None, raw, [_issue("role_yaml_invalid", label,
                                  f"верхний уровень - {type(data).__name__}, нужен словарь")]
    return data, raw, []


def _resolve_preset(
    name: str, base_default: str, vault_path: Path | None, ctx: Ctx, issues: list[RoleIssue],
    deps: list[Path], raws: list[bytes],
) -> tuple[Role, bool]:
    """Роль выбранного пресета. ``(роль, найден)``: нет пресета - ``role_unknown_preset`` и
    умолчание (профиль применяется поверх умолчания, а не подменяется молча: причина в
    замечаниях)."""
    if name in builtin_presets():
        return builtin_preset(name), True
    path = _vault_preset_path(vault_path, name) if _NAME_RE.match(name) else None
    deps.append(path or _vault_preset_path(vault_path, "_"))
    if path is not None and path.is_file():
        data, raw, errs = _read_yaml(path, f"preset:{name}")
        raws.append(raw)
        if data is None:
            issues.extend(errs)
            return builtin_preset(base_default), False
        extends = str(data.get("extends") or base_default)
        if extends not in builtin_presets():
            issues.append(_issue("role_unknown_preset", f"preset:{name}.extends",
                                 f"базовый пресет {extends!r} не найден среди встроенных"))
            extends = base_default
        role, errs2 = apply_doc(builtin_preset(extends), data, ctx)
        issues.extend(RoleIssue(i.code, i.severity, f"preset:{name}:{i.path}", i.message)
                      for i in errs2)
        return replace(role, preset=name), True
    known = ", ".join(ctx.presets) or "-"
    issues.append(_issue("role_unknown_preset", "preset",
                         f"пресета {name!r} нет (встроенные и vault/_system/role-presets: "
                         f"{known}); действует {base_default}"))
    return builtin_preset(base_default), False


def _read(vault_path: Path | None, role_name: str) -> Loaded:
    base_default = default_preset(role_name)
    path = role_file(vault_path)
    deps: list[Path] = [path]
    ctx = _make_ctx(vault_path)
    deps.append(retrieval_policies_path(vault_path))
    default_role = builtin_preset(base_default)
    if not path.is_file():
        unreadable = path.exists() and not path.is_file()
        issues = ([_issue("role_yaml_unreadable", ROLE_FILE, "role.yaml - не файл")]
                  if unreadable else [])
        return Loaded(default_role, tuple(issues), path, present=False, deps=tuple(deps))
    data, raw, issues = _read_yaml(path, ROLE_FILE)
    if data is None:
        return Loaded(default_role, tuple(issues), path, present=True,
                      version=hashlib.sha256(raw).hexdigest()[:12], deps=tuple(deps))
    schema = data.get("schema", SCHEMA_VERSION)
    if isinstance(schema, bool) or not isinstance(schema, int):
        issues.append(_issue("role_bad_type", "schema",
                             f"ожидается целое, получено {type(schema).__name__}; "
                             "профиль не применен"))
        return Loaded(default_role, tuple(issues), path, present=True,
                      version=hashlib.sha256(raw).hexdigest()[:12], deps=tuple(deps))
    if schema > SCHEMA_VERSION:
        issues.append(_issue("role_schema_newer", "schema",
                             f"schema {schema} новее известной {SCHEMA_VERSION}; профиль не "
                             "применен, обнови движок"))
        return Loaded(default_role, tuple(issues), path, present=True,
                      version=hashlib.sha256(raw).hexdigest()[:12], deps=tuple(deps))
    requested_raw = data.get("preset")
    requested = str(requested_raw).strip() if requested_raw else ""
    if requested_raw is not None and not isinstance(requested_raw, str):
        issues.append(_issue("role_bad_type", "preset",
                             f"ожидается строка, получено {type(requested_raw).__name__}"))
        requested = ""
    raws = [raw]
    base, _found = _resolve_preset(requested or base_default, base_default, vault_path, ctx,
                                   issues, deps, raws)
    role, doc_issues = apply_doc(base, data, ctx)
    issues.extend(doc_issues)
    role = replace(role, preset=base.preset)
    version = hashlib.sha256(b"\0".join(raws)).hexdigest()[:12]
    return Loaded(role, tuple(issues), path, present=True, requested=requested, version=version,
                  customized=role != default_role, deps=tuple(deps))


_cache: dict[tuple[Path, str], tuple[tuple[tuple[int, int], ...], Loaded]] = {}
_lock = threading.Lock()


def _stat_key(deps: tuple[Path, ...]) -> tuple[tuple[int, int], ...]:
    return tuple(_stat(p) for p in deps)


def _process_role() -> str:
    try:
        from core.instance import instance_role

        return instance_role()
    except Exception:  # noqa: BLE001 - ошибка роли процесса не должна ронять подписи
        return "work"


def get_role(vault_path: Path | None = None, role: str | None = None) -> Loaded:
    """Действующий профиль роли vault'а (по умолчанию - боевого). Не бросает исключений.

    ``role`` - роль экземпляра (``work|personal``) для выбора пресета по умолчанию; без нее - роль
    процесса (``DT_INSTANCE_ROLE``). Кэш по mtime/размеру ``role.yaml`` и зависимостей."""
    role_name = role or _process_role()
    key = (vault_system_path(vault_path), role_name)
    with _lock:
        hit = _cache.get(key)
    if hit is not None and hit[0] == _stat_key(hit[1].deps):
        return hit[1]
    try:
        loaded = _read(vault_path, role_name)
    except Exception as exc:  # noqa: BLE001 - ошибка профиля не роняет движок (код + доктор)
        loaded = Loaded(
            builtin_preset(default_preset(role_name)),
            (_issue("role_yaml_unreadable", ROLE_FILE,
                    f"сбой чтения профиля: {type(exc).__name__}"),),
            role_file(vault_path), present=role_file(vault_path).exists(),
            deps=(role_file(vault_path),))
    with _lock:
        _cache[key] = (_stat_key(loaded.deps), loaded)
    return loaded
