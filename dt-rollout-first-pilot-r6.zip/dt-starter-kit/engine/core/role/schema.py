"""ROLE-DATA-1: схема профиля роли ``vault/_system/role.yaml`` (v1) и разбор документа.

Профиль - **правки поверх пресета**, не копия: пресеты едут с движком
(``core/role/presets/*.yaml``), файл владельца хранит только отличия. Один и тот же разбор читает и
пресет, и профиль (и пресет из ``vault/_system/role-presets/``): поле-список - полная замена (так
пишется пресет), ``{add, remove}`` - правка (так пишется профиль).

Ключи сущностей и папки vault НЕ меняются (``client``, ``04-clients``, ``{client_id}``, ``track:
presale``): профиль меняет только подписи человеку. Новые виды сущностей с поведением - ROLE-DATA-2.

Схема v1 (все блоки необязательны)::

    schema: 1                         # целое; больше известного - role_schema_newer
    preset: product-analytics         # consulting-sales | personal | product-analytics | имя из
                                      # vault/_system/role-presets/; без файла - по роли экземпляра
    label: "Продуктовая аналитика"    # заголовок пульта; subtitle - подзаголовок
    vocabulary:
      entities:                       # ключи закрыты: client, product, project, direction, industry
        client:  {label: "заказчик", plural: "заказчики"}   # + формы: few, many, acc, ins, prep
      tracks:   {presale: "гипотеза", project: "в работе", internal: "внутреннее"}
      terms:    {deal: "заявка"}      # закрытый список (core.role.terms.TERM_KEYS); строка или
                                      # {one, plural, few, many, acc, ins, prep}
    surface:                          # поля как у Surface манифеста; add/remove правят пресет
      sections:      {remove: [work-kpis]}
      card_kinds:    {remove: [assignment, ripe_lead]}
      jobs:          {remove: [outlook_read]}      # по op; add: [{label, op, args}]
    labels:                           # подписи по ключу секции / вида карточки
      work-attention: "Требует внимания по экспериментам"
    scanner:
      min_mentions: 3                 # + min_domain_days, fresh_days
      stop_words_add: [тест, пилот]   # только расширяет стоп-лист
      title_patterns:                 # регэксп с группой имени -> вид сущности (дополняет пресет)
        - {regex: '(?:эксперимент|experiment)\\s*[.:-]\\s*(.{2,60})', entity: project}
      deal_signal: false              # не искать «сделки без хаба» в зеркале CRM
    scenarios:
      default: rnd                    # кейс по умолчанию (должна быть политика в vault)
      keywords: {rnd: [аналитик, дашборд, метрик]}   # дополняют, не заменяют
      labels:   {rnd: "кейс 2: аналитическая справка"}
      plan:     {rnd: [{name: Контекст, kind: context, critical: true}]}
    skills:
      include: [generate-artifact, save-output]      # белый список (нет - весь реестр)
      exclude: [capture-to-assignment]
      overlays: true                  # добавки vault/_system/skills/<имя>.md
    sources:                          # привязка возможностей к адаптерам (SRC-PORTS-1)
      mail: outlook-applescript

Ошибки - не исключение, а список :class:`RoleIssue` (``code``, ``severity``, ``path``,
``message``): ошибка блока отбрасывает ТОЛЬКО блок (действует пресет), предупреждение - только ключ.
Таблица кодов - :data:`CODES` (принцип 22: ни одной молчаливой подмены). Модуль чистый: ни файлов,
ни конфига; проверки существования (политики, скиллы) - через :class:`Ctx`.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field, replace
from functools import lru_cache
from typing import Any

__all__ = [
    "ADAPTER_KEYS", "BLOCKS", "CARD_KINDS", "CODES", "Ctx", "ENTITY_KEYS", "FORMS", "JobData",
    "KNOWN_MONITOR_BLOCKS", "KNOWN_SECTIONS", "PLAN_KINDS", "PlanStep", "Role", "RoleIssue",
    "SCHEMA_VERSION", "ScannerRules", "Scenarios", "SkillsSpec", "SurfaceData", "TERM_KEYS",
    "TRACK_KEYS", "TitlePattern", "Word", "apply_doc", "compile_pattern", "empty_role",
    "role_to_dict",
]

SCHEMA_VERSION = 1

# --- закрытые списки ключей (источник правды: инвентарь design-role-as-data §2) ------------------
ENTITY_KEYS = ("client", "product", "project", "direction", "industry")
TRACK_KEYS = ("presale", "project", "internal")
#: термины движка, кроме сущностей и треков; значение - слово с формами (:class:`Word`)
TERM_KEYS = ("deal", "presale", "lead", "assignment", "crm", "orbit", "ring")
#: падежные формы слова для строк движка: nominative plural, genitive singular (``few``),
#: genitive plural (``many``), accusative, instrumental, prepositional
FORMS = ("plural", "few", "many", "acc", "ins", "prep")

#: ключи секций пульта (``data-sec`` в pult.html; тест сверяет)
KNOWN_SECTIONS = (
    "domain-objects", "activity-model", "activity-settings",
    "ai-synth", "brief", "connectors", "create", "doctor", "eval-quality", "function", "hosts",
    "inbox", "links", "log", "monitor", "owner", "pers-bridge", "pers-bridge-settings",
    "pers-folders", "pers-recall", "pers-today", "queue", "rings", "ripe", "services",
    "store-actions", "store-journal", "store-paths", "store-refusals", "store-sources",
    "store-trace", "synth-entry", "trend", "webpult", "work-attention", "work-kpis",
    "work-meetings", "work-resurface", "work-stale", "mail-attachments", "work-mail-attachments",
    # SLEEP-PULT-1: Сон (Двойник: результаты, предложения, контроль; Мониторинг: прогоны; Настройки)
    "sleep-markup", "sleep-proposals", "sleep-results", "sleep-runs", "sleep-settings",
)
CARD_KINDS = (
    "domain", "activity",
    "assignment", "untriaged", "hub", "alias", "synth", "lint", "gold", "reattr", "link",
    "ripe_lead", "bridge", "memory",
)
KNOWN_MONITOR_BLOCKS = (
    "health", "night_chain", "sync", "jobs", "freshness", "storage", "activity", "long_ops",
)
#: виды узлов плана: словарь гейта (``core.orchestration.gate``) + терминальный ``assemble``
PLAN_KINDS = (
    "money", "quantity", "date", "rate", "requisite", "bin", "contact", "context", "exemplar",
    "assemble",
)
#: адаптеры, существующие до SRC-PORTS-1 (загрузчик ``_system/adapters/`` - его ТЗ)
ADAPTER_KEYS = {
    "mail": ("outlook-applescript",),
    "calendar": ("outlook-applescript",),
    "tasks": ("ticktick",),
}

BLOCKS = ("vocabulary", "surface", "labels", "scanner", "scenarios", "skills", "sources")
_TOP_KEYS = ("schema", "preset", "label", "subtitle", "extends", *BLOCKS)
_SURFACE_LISTS = ("sections", "roots_sections", "monitor_blocks", "card_kinds", "roots_freshness",
                  "doctor_excluded", "connectors", "connector_sections")

ERROR, WARN = "error", "warn"
#: код -> серьезность (``dt role check`` падает только на error)
CODES: dict[str, str] = {
    "role_yaml_unreadable": ERROR,
    "role_yaml_invalid": ERROR,
    "role_schema_newer": ERROR,
    "role_unknown_preset": ERROR,
    "role_bad_type": ERROR,
    "role_unknown_key": WARN,
    "role_entity_unknown": WARN,
    "role_term_unknown": WARN,
    "role_regex_invalid": ERROR,
    "role_surface_unknown_section": WARN,
    "role_skill_unknown": WARN,
    "role_scenario_unknown": WARN,
    "role_source_unknown": ERROR,
}


@dataclass(frozen=True)
class RoleIssue:
    """Замечание к профилю. ``path`` - место в файле (``scanner.title_patterns[0].regex``)."""

    code: str
    severity: str
    path: str
    message: str

    def __str__(self) -> str:
        return f"[{self.severity}] {self.code} {self.path}: {self.message}"

    def to_dict(self) -> dict[str, str]:
        return {"code": self.code, "severity": self.severity, "path": self.path,
                "reason": self.message}


# --------------------------------------------------------------------------- #
# Данные роли                                                                   #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Word:
    """Слово с падежными формами. ``one`` - основная форма (именительный, единственное). Формы,
    которых нет, дают ``one``: профиль с одной строкой подставляет ее всюду."""

    one: str
    forms: Mapping[str, str] = field(default_factory=dict)

    def form(self, name: str | None = None) -> str:
        if not name or name in ("one", "label"):
            return self.one
        return self.forms.get(name) or self.one

    def to_dict(self, *, entity: bool = False) -> dict[str, str]:
        out = {("label" if entity else "one"): self.one}
        out.update({k: v for k, v in self.forms.items() if v})
        return out


@dataclass(frozen=True)
class JobData:
    label: str
    op: str
    args: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SurfaceData:
    """Поверхность роли как данные (поля :class:`core.surface.manifest.Surface` без заголовка)."""

    sections: tuple[str, ...] = ()
    roots_sections: tuple[str, ...] = ()
    monitor_blocks: tuple[str, ...] = ()
    jobs: tuple[JobData, ...] = ()
    card_kinds: tuple[str, ...] = ()
    roots_freshness: tuple[str, ...] = ()
    doctor_excluded: tuple[str, ...] = ()
    connectors: tuple[str, ...] = ()
    connector_sections: tuple[str, ...] = ()


@dataclass(frozen=True)
class TitlePattern:
    """Шаблон заголовка заметки: ``regex`` (регистр не важен, группа 1 - имя) -> ``entity``."""

    regex: str
    entity: str


@dataclass(frozen=True)
class ScannerRules:
    min_mentions: int = 3
    min_domain_days: int = 2
    fresh_days: int = 14
    stop_words_add: tuple[str, ...] = ()
    title_patterns: tuple[TitlePattern, ...] = ()
    deal_signal: bool = True


@dataclass(frozen=True)
class PlanStep:
    name: str
    kind: str
    critical: bool


@dataclass(frozen=True)
class Scenarios:
    default: str = "client_correspondence"
    #: упорядоченные группы ключевых слов: первая сработавшая группа выигрывает (узкие - раньше
    #: широких); кейс может встречаться дважды
    groups: tuple[tuple[str, tuple[str, ...]], ...] = ()
    labels: Mapping[str, str] = field(default_factory=dict)
    plan: Mapping[str, tuple[PlanStep, ...]] = field(default_factory=dict)


@dataclass(frozen=True)
class SkillsSpec:
    include: tuple[str, ...] | None = None  # None - весь реестр
    exclude: tuple[str, ...] = ()
    overlays: bool = False


@dataclass(frozen=True)
class Role:
    """Действующий профиль: пресет + правки профиля. Только чтение."""

    preset: str = ""
    label: str = ""
    subtitle: str = ""
    entities: Mapping[str, Word] = field(default_factory=dict)
    tracks: Mapping[str, str] = field(default_factory=dict)
    terms: Mapping[str, Word] = field(default_factory=dict)
    surface: SurfaceData = field(default_factory=SurfaceData)
    labels: Mapping[str, str] = field(default_factory=dict)
    scanner: ScannerRules = field(default_factory=ScannerRules)
    scenarios: Scenarios = field(default_factory=Scenarios)
    skills: SkillsSpec = field(default_factory=SkillsSpec)
    sources: Mapping[str, str] = field(default_factory=dict)


def empty_role() -> Role:
    return Role()


@dataclass(frozen=True)
class Ctx:
    """Что нужно проверкам снаружи документа (подставляет загрузчик; в тестах - заглушки)."""

    policy_exists: Callable[[str], bool] = lambda _case: True
    skill_exists: Callable[[str], bool] = lambda _name: True
    presets: tuple[str, ...] = ()  # известные имена пресетов (встроенные + vault)


# --------------------------------------------------------------------------- #
# Разбор                                                                        #
# --------------------------------------------------------------------------- #
class _Bad(Exception):
    """Ошибка блока: блок отбрасывается целиком (``role_bad_type`` и родня)."""

    def __init__(self, code: str, path: str, message: str) -> None:
        super().__init__(message)
        self.code, self.path, self.message = code, path, message


def _issue(code: str, path: str, message: str) -> RoleIssue:
    return RoleIssue(code, CODES[code], path, message)


def _type_name(value: Any) -> str:
    return type(value).__name__


def _need(value: Any, kind: type | tuple[type, ...], path: str, what: str) -> Any:
    if isinstance(value, bool) and kind in (int, (int,)):
        raise _Bad("role_bad_type", path, f"ожидается {what}, получено bool")
    if not isinstance(value, kind):
        raise _Bad("role_bad_type", path, f"ожидается {what}, получено {_type_name(value)}")
    return value


def _str(value: Any, path: str) -> str:
    return str(_need(value, str, path, "строка")).strip()


def _str_list(value: Any, path: str) -> list[str]:
    seq = _need(value, list, path, "список строк")
    return [_str(v, f"{path}[{i}]") for i, v in enumerate(seq)]


def _kw_list(value: Any, path: str) -> list[str]:
    """Ключевые слова кейса: пробелы по краям - часть якоря («кп », «доклад ») и сохраняются."""
    seq = _need(value, list, path, "список строк")
    out = []
    for i, v in enumerate(seq):
        word = _need(v, str, f"{path}[{i}]", "строка")
        if word.strip():
            out.append(word)
    return out


def _unknown_keys(data: Mapping[str, Any], known: tuple[str, ...], path: str,
                  issues: list[RoleIssue]) -> None:
    for key in data:
        if key not in known:
            issues.append(_issue("role_unknown_key", f"{path}.{key}" if path else str(key),
                                 "неизвестный ключ, игнорируется"))


def _dedupe(items: list[str]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(items))


# -- vocabulary ---------------------------------------------------------------------------------
def _word(value: Any, path: str, *, entity: bool) -> Word:
    """Слово из строки либо из {label|one, plural, few, ...}."""
    if isinstance(value, str):
        text = value.strip()
        if not text:
            raise _Bad("role_bad_type", path, "пустая строка вместо слова")
        return Word(text)
    data = _need(value, dict, path, "строка или словарь форм")
    head = "label" if entity else "one"
    one = _str(data.get(head) or data.get("one") or data.get("label") or "", f"{path}.{head}")
    if not one:
        raise _Bad("role_bad_type", path, f"нет основной формы {head!r}")
    forms: dict[str, str] = {}
    for key, val in data.items():
        if key in ("one", "label"):
            continue
        if key not in FORMS:
            continue  # неизвестные формы - предупреждение даст вызывающий (unknown_key)
        forms[key] = _str(val, f"{path}.{key}")
    return Word(one, forms)


def _apply_vocabulary(base: Role, raw: Any, issues: list[RoleIssue]) -> Role:
    data = _need(raw, dict, "vocabulary", "словарь")
    local: list[RoleIssue] = []
    _unknown_keys(data, ("entities", "tracks", "terms"), "vocabulary", local)
    entities = dict(base.entities)
    tracks = dict(base.tracks)
    terms = dict(base.terms)
    if "entities" in data:
        ents = _need(data["entities"], dict, "vocabulary.entities", "словарь")
        for key, val in ents.items():
            path = f"vocabulary.entities.{key}"
            if key not in ENTITY_KEYS:
                local.append(_issue("role_entity_unknown", path,
                                    f"ключ вне закрытого списка {', '.join(ENTITY_KEYS)}"))
                continue
            word = _word(val, path, entity=True)
            if isinstance(val, dict):
                for fk in val:
                    if fk not in ("label", "one", *FORMS):
                        local.append(_issue("role_unknown_key", f"{path}.{fk}",
                                            "неизвестный ключ, игнорируется"))
            entities[key] = word
    if "tracks" in data:
        trk = _need(data["tracks"], dict, "vocabulary.tracks", "словарь")
        for key, val in trk.items():
            path = f"vocabulary.tracks.{key}"
            if key not in TRACK_KEYS:
                local.append(_issue("role_unknown_key", path,
                                    f"трек вне списка {', '.join(TRACK_KEYS)}, игнорируется"))
                continue
            text = _str(val, path)
            if not text:
                raise _Bad("role_bad_type", path, "пустая подпись трека")
            tracks[key] = text
    if "terms" in data:
        trm = _need(data["terms"], dict, "vocabulary.terms", "словарь")
        for key, val in trm.items():
            path = f"vocabulary.terms.{key}"
            if key not in TERM_KEYS:
                local.append(_issue("role_term_unknown", path,
                                    f"термин вне закрытого списка {', '.join(TERM_KEYS)}"))
                continue
            word = _word(val, path, entity=False)
            if isinstance(val, dict):
                for fk in val:
                    if fk not in ("label", "one", *FORMS):
                        local.append(_issue("role_unknown_key", f"{path}.{fk}",
                                            "неизвестный ключ, игнорируется"))
            terms[key] = word
    issues.extend(local)
    return replace(base, entities=entities, tracks=tracks, terms=terms)


# -- surface ------------------------------------------------------------------------------------
def _job(value: Any, path: str) -> JobData:
    data = _need(value, dict, path, "словарь {label, op, args}")
    label = _str(data.get("label") or "", f"{path}.label")
    op = _str(data.get("op") or "", f"{path}.op")
    if not label or not op:
        raise _Bad("role_bad_type", path, "у задания нужны непустые label и op")
    args = data.get("args") or {}
    _need(args, dict, f"{path}.args", "словарь")
    return JobData(label, op, dict(args))


def _edit_list(cur: tuple[str, ...], raw: Any, path: str, known: tuple[str, ...] | None,
               unknown_code: str, issues: list[RoleIssue]) -> tuple[str, ...]:
    """Список-поле поверхности: полная замена (``[...]``) либо правка (``{add, remove}``)."""
    if isinstance(raw, list):
        items = _str_list(raw, path)
        return _dedupe(_check_known(items, path, known, unknown_code, issues))
    data = _need(raw, dict, path, "список или {add, remove}")
    _unknown_keys(data, ("add", "remove"), path, issues)
    out = list(cur)
    if "remove" in data:
        gone = _str_list(data["remove"], f"{path}.remove")
        out = [x for x in out if x not in gone]
    if "add" in data:
        add = _check_known(_str_list(data["add"], f"{path}.add"), f"{path}.add", known,
                           unknown_code, issues)
        out += [x for x in add if x not in out]
    return tuple(out)


def _check_known(items: list[str], path: str, known: tuple[str, ...] | None, code: str,
                 issues: list[RoleIssue]) -> list[str]:
    if known is None:
        return items
    keep: list[str] = []
    for i, item in enumerate(items):
        if item in known:
            keep.append(item)
        else:
            what = ("ключ секции, которого нет среди data-sec пульта"
                    if code == "role_surface_unknown_section" else "неизвестное значение")
            issues.append(_issue(code, f"{path}[{i}]", f"{item!r}: {what}; игнорируется"))
    return keep


def _edit_jobs(cur: tuple[JobData, ...], raw: Any, issues: list[RoleIssue]) -> tuple[JobData, ...]:
    path = "surface.jobs"
    if isinstance(raw, list):
        return tuple(_job(v, f"{path}[{i}]") for i, v in enumerate(raw))
    data = _need(raw, dict, path, "список или {add, remove}")
    _unknown_keys(data, ("add", "remove"), path, issues)
    out = list(cur)
    if "remove" in data:
        gone = _str_list(data["remove"], f"{path}.remove")  # по op (или по подписи)
        out = [j for j in out if j.op not in gone and j.label not in gone]
    if "add" in data:
        add = _need(data["add"], list, f"{path}.add", "список заданий")
        for i, v in enumerate(add):
            job = _job(v, f"{path}.add[{i}]")
            if all((j.label, j.op, dict(j.args)) != (job.label, job.op, dict(job.args))
                   for j in out):
                out.append(job)
    return tuple(out)


def _apply_surface(base: Role, raw: Any, issues: list[RoleIssue]) -> Role:
    data = _need(raw, dict, "surface", "словарь")
    local: list[RoleIssue] = []
    _unknown_keys(data, (*_SURFACE_LISTS, "jobs"), "surface", local)
    cur = base.surface
    known = {
        "sections": (KNOWN_SECTIONS, "role_surface_unknown_section"),
        "roots_sections": (KNOWN_SECTIONS, "role_surface_unknown_section"),
        "connector_sections": (KNOWN_SECTIONS, "role_surface_unknown_section"),
        "card_kinds": (CARD_KINDS, "role_unknown_key"),
        "monitor_blocks": (KNOWN_MONITOR_BLOCKS, "role_unknown_key"),
    }
    changes: dict[str, Any] = {}
    for name in _SURFACE_LISTS:
        if name not in data:
            continue
        keys, code = known.get(name, (None, "role_unknown_key"))
        changes[name] = _edit_list(getattr(cur, name), data[name], f"surface.{name}", keys, code,
                                   local)
    if "jobs" in data:
        changes["jobs"] = _edit_jobs(cur.jobs, data["jobs"], local)
    issues.extend(local)
    return replace(base, surface=replace(cur, **changes))


# -- labels -------------------------------------------------------------------------------------
def _apply_labels(base: Role, raw: Any, issues: list[RoleIssue]) -> Role:
    data = _need(raw, dict, "labels", "словарь ключ -> текст")
    labels = dict(base.labels)
    for key, val in data.items():
        text = _str(val, f"labels.{key}")
        if not text:
            raise _Bad("role_bad_type", f"labels.{key}", "пустая подпись")
        labels[str(key)] = text
    return replace(base, labels=labels)


# -- scanner ------------------------------------------------------------------------------------
@lru_cache(maxsize=256)
def compile_pattern(regex: str) -> re.Pattern[str]:
    """Шаблон заголовка: регистр не важен; нужна хотя бы одна группа (имя - группа 1)."""
    pat = re.compile(regex, re.IGNORECASE)
    if pat.groups < 1:
        raise re.error("нужна группа имени: (...)")
    return pat


def _int_ge1(value: Any, path: str) -> int:
    n = _need(value, int, path, "целое число")
    if n < 1:
        raise _Bad("role_bad_type", path, "ожидается целое >= 1")
    return int(n)


def _apply_scanner(base: Role, raw: Any, issues: list[RoleIssue]) -> Role:
    data = _need(raw, dict, "scanner", "словарь")
    local: list[RoleIssue] = []
    _unknown_keys(data, ("min_mentions", "min_domain_days", "fresh_days", "stop_words_add",
                         "title_patterns", "deal_signal"), "scanner", local)
    cur = base.scanner
    changes: dict[str, Any] = {}
    for key in ("min_mentions", "min_domain_days", "fresh_days"):
        if key in data:
            changes[key] = _int_ge1(data[key], f"scanner.{key}")
    if "stop_words_add" in data:
        words = _str_list(data["stop_words_add"], "scanner.stop_words_add")
        changes["stop_words_add"] = _dedupe([*cur.stop_words_add, *(w for w in words if w)])
    if "deal_signal" in data:
        changes["deal_signal"] = bool(_need(data["deal_signal"], bool, "scanner.deal_signal",
                                            "true/false"))
    if "title_patterns" in data:
        seq = _need(data["title_patterns"], list, "scanner.title_patterns", "список шаблонов")
        pats = list(cur.title_patterns)
        for i, item in enumerate(seq):
            path = f"scanner.title_patterns[{i}]"
            entry = _need(item, dict, path, "словарь {regex, entity}")
            _unknown_keys(entry, ("regex", "entity"), path, local)
            rx = _str(entry.get("regex") or "", f"{path}.regex")
            ent = _str(entry.get("entity") or "", f"{path}.entity")
            if not rx or not ent:
                raise _Bad("role_bad_type", path, "нужны непустые regex и entity")
            if ent not in ENTITY_KEYS:
                raise _Bad("role_bad_type", f"{path}.entity",
                           f"вид {ent!r} вне списка {', '.join(ENTITY_KEYS)}")
            try:
                compile_pattern(rx)
            except re.error as exc:
                raise _Bad("role_regex_invalid", f"{path}.regex",
                           f"не компилируется: {exc}") from exc
            tp = TitlePattern(rx, ent)
            if tp not in pats:
                pats.append(tp)
        changes["title_patterns"] = tuple(pats)
    issues.extend(local)
    return replace(base, scanner=replace(cur, **changes))


# -- scenarios ----------------------------------------------------------------------------------
def _plan_steps(raw: Any, path: str) -> tuple[PlanStep, ...]:
    seq = _need(raw, list, path, "список шагов")
    out = []
    for i, item in enumerate(seq):
        p = f"{path}[{i}]"
        entry = _need(item, dict, p, "словарь {name, kind, critical}")
        name = _str(entry.get("name") or "", f"{p}.name")
        kind = _str(entry.get("kind") or "", f"{p}.kind")
        if not name:
            raise _Bad("role_bad_type", p, "нужно непустое name")
        if kind not in PLAN_KINDS:
            raise _Bad("role_bad_type", f"{p}.kind",
                       f"вид узла {kind!r} вне словаря гейта: {', '.join(PLAN_KINDS)}")
        crit = entry.get("critical", False)
        _need(crit, bool, f"{p}.critical", "true/false")
        out.append(PlanStep(name, kind, bool(crit)))
    return tuple(out)


def _case_ok(ctx: Ctx, case: str, path: str, local: list[RoleIssue], *,
             check: bool) -> bool:
    if check and not ctx.policy_exists(case):
        local.append(_issue("role_scenario_unknown", path,
                            f"нет файла политики для кейса {case!r} в retrieval-policies; "
                            "ключ игнорируется"))
        return False
    return True


def _apply_scenarios(base: Role, raw: Any, issues: list[RoleIssue], ctx: Ctx,
                     check: bool) -> Role:
    data = _need(raw, dict, "scenarios", "словарь")
    local: list[RoleIssue] = []
    _unknown_keys(data, ("default", "keywords", "keyword_groups", "labels", "plan"),
                  "scenarios", local)
    cur = base.scenarios
    default = cur.default
    groups = list(cur.groups)
    labels = dict(cur.labels)
    plan = dict(cur.plan)
    if "default" in data:
        case = _str(data["default"], "scenarios.default")
        if not case:
            raise _Bad("role_bad_type", "scenarios.default", "пустое имя кейса")
        if _case_ok(ctx, case, "scenarios.default", local, check=check):
            default = case
    if "keyword_groups" in data:
        seq = _need(data["keyword_groups"], list, "scenarios.keyword_groups", "список групп")
        groups = []
        for i, item in enumerate(seq):
            p = f"scenarios.keyword_groups[{i}]"
            entry = _need(item, dict, p, "словарь {case, words}")
            case = _str(entry.get("case") or "", f"{p}.case")
            words = _kw_list(entry.get("words") or [], f"{p}.words")
            if not case:
                raise _Bad("role_bad_type", p, "нужно непустое case")
            groups.append((case, tuple(words)))
    if "keywords" in data:
        kw = _need(data["keywords"], dict, "scenarios.keywords", "словарь кейс -> слова")
        for case, words_raw in kw.items():
            p = f"scenarios.keywords.{case}"
            words = _kw_list(words_raw, p)
            if not _case_ok(ctx, str(case), p, local, check=check):
                continue
            for idx, (gcase, gwords) in enumerate(groups):
                if gcase == case:  # дополняет первую группу кейса
                    groups[idx] = (gcase, _dedupe([*gwords, *words]))
                    break
            else:
                groups.append((str(case), _dedupe(words)))
    if "labels" in data:
        lab = _need(data["labels"], dict, "scenarios.labels", "словарь кейс -> текст")
        for case, text_raw in lab.items():
            p = f"scenarios.labels.{case}"
            text = _str(text_raw, p)
            if text and _case_ok(ctx, str(case), p, local, check=check):
                labels[str(case)] = text
    if "plan" in data:
        pl = _need(data["plan"], dict, "scenarios.plan", "словарь кейс -> шаги")
        for case, steps_raw in pl.items():
            p = f"scenarios.plan.{case}"
            steps = _plan_steps(steps_raw, p)
            if _case_ok(ctx, str(case), p, local, check=check):
                plan[str(case)] = steps
    issues.extend(local)
    return replace(base, scenarios=Scenarios(default, tuple(groups), labels, plan))


# -- skills / sources ---------------------------------------------------------------------------
def _apply_skills(base: Role, raw: Any, issues: list[RoleIssue], ctx: Ctx,
                  check: bool) -> Role:
    data = _need(raw, dict, "skills", "словарь")
    local: list[RoleIssue] = []
    _unknown_keys(data, ("include", "exclude", "overlays"), "skills", local)
    cur = base.skills
    changes: dict[str, Any] = {}
    for key in ("include", "exclude"):
        if key not in data:
            continue
        names = _str_list(data[key], f"skills.{key}")
        keep = []
        for i, name in enumerate(names):
            if check and not ctx.skill_exists(name):
                local.append(_issue("role_skill_unknown", f"skills.{key}[{i}]",
                                    f"скилла {name!r} нет в реестре; игнорируется"))
                continue
            keep.append(name)
        changes[key] = _dedupe(keep)
    if "exclude" in changes:
        changes["exclude"] = _dedupe([*cur.exclude, *changes["exclude"]])
    if "overlays" in data:
        changes["overlays"] = bool(_need(data["overlays"], bool, "skills.overlays", "true/false"))
    issues.extend(local)
    return replace(base, skills=replace(cur, **changes))


def _apply_sources(base: Role, raw: Any, issues: list[RoleIssue]) -> Role:
    data = _need(raw, dict, "sources", "словарь возможность -> адаптер")
    local: list[RoleIssue] = []
    _unknown_keys(data, tuple(ADAPTER_KEYS), "sources", local)
    sources = dict(base.sources)
    for cap, val in data.items():
        if cap not in ADAPTER_KEYS:
            continue
        key = _str(val, f"sources.{cap}")
        if not key:  # пустая строка - возможность не привязана (личный контур без почты)
            sources.pop(cap, None)
            continue
        if key not in ADAPTER_KEYS[cap]:
            raise _Bad("role_source_unknown", f"sources.{cap}",
                       f"адаптер {key!r} не найден (известны: {', '.join(ADAPTER_KEYS[cap])}); "
                       "загрузчик внешних адаптеров - SRC-PORTS-1")
        sources[cap] = key
    issues.extend(local)
    return replace(base, sources=sources)


# --------------------------------------------------------------------------- #
# Документ                                                                      #
# --------------------------------------------------------------------------- #
def apply_doc(
    base: Role, data: Mapping[str, Any], ctx: Ctx | None = None, *, check: bool = True,
) -> tuple[Role, list[RoleIssue]]:
    """Применить документ (профиль или пресет) к ``base``: ``(роль, замечания)``.

    Ошибка блока отбрасывает блок (``base`` по нему не меняется), замечание уровня ключа - только
    ключ. ``check`` включает проверки существования (политики, скиллы): для встроенных пресетов
    они не нужны (пресет едет с движком), для профиля владельца - обязательны."""
    ctx = ctx or Ctx()
    issues: list[RoleIssue] = []
    _unknown_keys(data, _TOP_KEYS, "", issues)
    role = base
    for scalar in ("label", "subtitle"):
        if scalar in data:
            try:
                text = _str(data[scalar], scalar)
                role = (replace(role, label=text) if scalar == "label"
                        else replace(role, subtitle=text))
            except _Bad as bad:
                issues.append(_issue(bad.code, bad.path, bad.message))
    appliers: dict[str, Callable[[Role], Role]] = {
        "vocabulary": lambda r: _apply_vocabulary(r, data["vocabulary"], issues),
        "surface": lambda r: _apply_surface(r, data["surface"], issues),
        "labels": lambda r: _apply_labels(r, data["labels"], issues),
        "scanner": lambda r: _apply_scanner(r, data["scanner"], issues),
        "scenarios": lambda r: _apply_scenarios(r, data["scenarios"], issues, ctx, check),
        "skills": lambda r: _apply_skills(r, data["skills"], issues, ctx, check),
        "sources": lambda r: _apply_sources(r, data["sources"], issues),
    }
    for block in BLOCKS:
        if block not in data or data[block] is None:
            continue
        mark = len(issues)
        try:
            role = appliers[block](role)
        except _Bad as bad:
            del issues[mark:]  # замечания блока, из которого вышли ошибкой, не показываем дважды
            issues.append(_issue(bad.code, bad.path, f"блок {block} отброшен: {bad.message}"))
    return role, issues


def role_to_dict(role: Role) -> dict[str, Any]:
    """Действующая роль как обычный словарь (``dt role show --effective``, JSON, YAML)."""
    sc, s, scn, sk = role.scanner, role.surface, role.scenarios, role.skills
    return {
        "preset": role.preset,
        "label": role.label,
        "subtitle": role.subtitle,
        "vocabulary": {
            "entities": {k: w.to_dict(entity=True) for k, w in role.entities.items()},
            "tracks": dict(role.tracks),
            "terms": {k: w.to_dict() for k, w in role.terms.items()},
        },
        "surface": {
            "sections": list(s.sections),
            "roots_sections": list(s.roots_sections),
            "monitor_blocks": list(s.monitor_blocks),
            "jobs": [{"label": j.label, "op": j.op, "args": dict(j.args)} for j in s.jobs],
            "card_kinds": list(s.card_kinds),
            "roots_freshness": list(s.roots_freshness),
            "doctor_excluded": list(s.doctor_excluded),
            "connectors": list(s.connectors),
            "connector_sections": list(s.connector_sections),
        },
        "labels": dict(role.labels),
        "scanner": {
            "min_mentions": sc.min_mentions,
            "min_domain_days": sc.min_domain_days,
            "fresh_days": sc.fresh_days,
            "stop_words_add": list(sc.stop_words_add),
            "title_patterns": [{"regex": p.regex, "entity": p.entity} for p in sc.title_patterns],
            "deal_signal": sc.deal_signal,
        },
        "scenarios": {
            "default": scn.default,
            "keyword_groups": [{"case": c, "words": list(w)} for c, w in scn.groups],
            "labels": dict(scn.labels),
            "plan": {c: [{"name": st.name, "kind": st.kind, "critical": st.critical}
                         for st in steps] for c, steps in scn.plan.items()},
        },
        "skills": {"include": list(sk.include) if sk.include is not None else None,
                   "exclude": list(sk.exclude), "overlays": sk.overlays},
        "sources": dict(role.sources),
    }
