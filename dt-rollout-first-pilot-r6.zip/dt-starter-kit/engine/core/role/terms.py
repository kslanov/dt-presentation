"""ROLE-DATA-1: ``T(key)`` - ЕДИНСТВЕННАЯ функция подписей движка и закрытый список терминов.

Строка движка, в которой стояло слово предметной области («сделка», «клиент», «пресейл»), берет его
отсюда: ``T("term.deal")``, ``T("entity.client", "plural")``. Ключи схемы vault (``client``,
``04-clients``, ``track: presale``) не меняются - меняется только то, как их называют человеку.

Список **закрыт** и выведен из инвентаря design-role-as-data §2 (15 ключей):

* ``entity.<ключ>`` - 5 сущностей хабов: ``client``, ``product``, ``project``, ``direction``,
  ``industry`` (подпись + формы);
* ``track.<ключ>`` - 3 значения трека хаба: ``presale``, ``project``, ``internal`` (одна строка);
* ``term.<ключ>`` - 7 слов движка: ``deal``, ``presale``, ``lead``, ``assignment``, ``crm``,
  ``orbit``, ``ring`` (слово + формы).

Формы (``form``): ``one``/``label`` (по умолчанию, именительный ед.), ``plural``, ``few``
(родительный ед.: «2 сделки», «нет сделки»), ``many`` (родительный мн.: «5 сделок»), ``acc``,
``ins``, ``prep``. Формы, которых профиль не задал, дают основную форму. ``cap=True`` - с заглавной.

Новый термин - только через ТЗ (ограничитель против «словаря на каждую строку»): гард
``tests/test_role_guards.py`` валит слово из списка, оставшееся литералом в строке потребителя.
``T`` не бросает исключений профиля (ошибка файла - пресет и замечание в доктор); неизвестный КЛЮЧ -
``KeyError`` (ошибка разработчика, не данных).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.role.load import get_role
from core.role.schema import ENTITY_KEYS, FORMS, TERM_KEYS, TRACK_KEYS, Role

__all__ = [
    "ALL_KEYS", "ENTITY_KEYS", "FORMS", "T", "TERM_KEYS", "TRACK_KEYS", "plural_form",
    "terms_dict", "vocabulary_dict",
]

#: весь закрытый список ключей ``T()``
ALL_KEYS: tuple[str, ...] = (
    *(f"entity.{k}" for k in ENTITY_KEYS),
    *(f"track.{k}" for k in TRACK_KEYS),
    *(f"term.{k}" for k in TERM_KEYS),
)


def _lookup(role: Role, key: str, form: str | None) -> str:
    kind, _, name = key.partition(".")
    if kind == "entity" and name in ENTITY_KEYS:
        return role.entities[name].form(form)
    if kind == "track" and name in TRACK_KEYS:
        return role.tracks[name]
    if kind == "term" and name in TERM_KEYS:
        return role.terms[name].form(form)
    raise KeyError(f"{key!r}: нет в закрытом списке терминов ({len(ALL_KEYS)} ключей)")


def T(key: str, form: str | None = None, *, cap: bool = False,
      vault_path: Path | None = None, role: Role | None = None) -> str:
    """Подпись ``key`` по действующему профилю роли (пресет + ``role.yaml``).

    ``role`` - готовая роль (чтобы не читать профиль в цикле); ``vault_path`` - другой vault."""
    if form is not None and form not in ("one", "label", *FORMS):
        raise KeyError(f"форма {form!r}: допустимы one, {', '.join(FORMS)}")
    text = _lookup(role if role is not None else get_role(vault_path).role, key, form)
    return text[:1].upper() + text[1:] if cap else text


def plural_form(n: int, key: str, *, role: Role | None = None) -> str:
    """Форма слова ``key`` по числу (1 сделка, 2 сделки, 5 сделок): ``one``/``few``/``many``."""
    r = role if role is not None else get_role().role
    n10, n100 = abs(int(n)) % 10, abs(int(n)) % 100
    if n10 == 1 and n100 != 11:
        form = "one"
    elif 2 <= n10 <= 4 and not 12 <= n100 <= 14:
        form = "few"
    else:
        form = "many"
    return _lookup(r, key, form)


def vocabulary_dict(role: Role) -> dict[str, Any]:
    """Словарь для манифеста: ``{entities: {ключ: {label, plural, ...формы}}, tracks: {...}}``."""
    return {
        "entities": {k: role.entities[k].to_dict(entity=True) for k in ENTITY_KEYS},
        "tracks": {k: role.tracks[k] for k in TRACK_KEYS},
    }


def terms_dict(role: Role) -> dict[str, dict[str, str]]:
    """Термины движка для строк, собираемых в клиенте: ``{ключ: {one, ...формы}}``."""
    return {k: role.terms[k].to_dict() for k in TERM_KEYS}

