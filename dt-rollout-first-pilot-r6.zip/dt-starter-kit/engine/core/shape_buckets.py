"""RESOURCE-2 п.4 — корзины форм: число уникальных форм тензоров ограничено.

Почему. MPS компилирует отдельное ядро Metal на каждую уникальную форму тензора и держит его в
кэше без вытеснения (документация Transformers, «Apple Silicon / Graph cache»); входы переменной
длины растят кэш до исчерпания общей памяти. ``SentenceTransformer.encode`` и
``CrossEncoder.predict`` добивают батч до самой длинной строки - каждая пара (размер батча,
длина) дает новую форму, и за ночной reindex их набегают сотни. Здесь длина добивается до
ближайшей КОРЗИНЫ, а неполный батч - до размера батча пустыми строками (их результаты
отбрасываются): форм за жизнь воркера не больше числа корзин (плюс формы уменьшенных батчей
после OOM).

Значения не меняются: маска внимания исключает добивку, пулинг и классификатор читают только
настоящие токены, строки батча независимы друг от друга. Проверка - косинус ≥ 0,9999 против прогона
без корзин на малой настоящей модели (``tests/test_resource_2_buckets.py``), на приемке - золотой
набор.

Корзины длины - :data:`BASE_BUCKETS` под потолок модели (``MAX_SEQ_LENGTH`` эмбеддера,
``max_length()`` реранкера): все базовые ниже потолка и сам потолок.

Управление: ``processing_kwargs`` на вызов (sentence-transformers ≥ 5.5) - ``{"text": {"padding":
"max_length", "max_length": L}}``; библиотека без него (``TypeError``) - корзины отключаются с
предупреждением, а не молча портят вызов.
"""

from __future__ import annotations

import logging
import threading
from collections.abc import Sequence
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "BASE_BUCKETS",
    "ShapeCounter",
    "bucket_for",
    "buckets_for",
    "pad_pairs",
    "pad_texts",
    "padding_kwargs",
    "token_lengths",
    "tokenizer_of",
]

BASE_BUCKETS: tuple[int, ...] = (64, 128, 256, 384, 512, 768)


def buckets_for(cap: int) -> tuple[int, ...]:
    """Корзины длины под потолок ``cap``: базовые ниже потолка и сам потолок."""
    cap = max(1, int(cap))
    return (*[b for b in BASE_BUCKETS if b < cap], cap)


def bucket_for(length: int, cap: int) -> int:
    """Ближайшая корзина длины ≥ ``length`` (не больше потолка ``cap``)."""
    for bucket in buckets_for(cap):
        if length <= bucket:
            return bucket
    return max(1, int(cap))


def pad_texts(texts: Sequence[str], size: int) -> list[str]:
    """Добить тексты до ``size`` пустыми строками (результаты добивки потом отбрасываются)."""
    out = list(texts)
    if len(out) < size:
        out.extend([""] * (size - len(out)))
    return out


def pad_pairs(pairs: Sequence[tuple[str, str]], size: int) -> list[tuple[str, str]]:
    """То же для пар (запрос, текст) реранкера."""
    out = list(pairs)
    if len(out) < size:
        out.extend([("", "")] * (size - len(out)))
    return out


def padding_kwargs(length: int) -> dict[str, Any]:
    """Аргумент ``processing_kwargs``: добить до ровно ``length`` токенов."""
    return {"processing_kwargs": {"text": {"padding": "max_length", "max_length": int(length),
                                           "truncation": True}}}


def tokenizer_of(model: Any) -> Any:
    """Токенайзер модели sentence-transformers (``None`` - не нашли: корзин не будет)."""
    tok = getattr(model, "tokenizer", None)
    if tok is not None:
        return tok
    try:
        return model[0].processor.tokenizer
    except Exception:  # noqa: BLE001 — подделка/иная модель без токенайзера
        return None


def token_lengths(tokenizer: Any, first: Sequence[str], second: Sequence[str] | None,
                  cap: int) -> list[int]:
    """Длины входов в токенах (с особыми токенами, усечение до ``cap``) - без добивки."""
    kwargs: dict[str, Any] = {"add_special_tokens": True, "truncation": True,
                              "max_length": int(cap), "padding": False}
    enc = (tokenizer(list(first), list(second), **kwargs) if second is not None
           else tokenizer(list(first), **kwargs))
    return [len(ids) for ids in enc["input_ids"]]


class ShapeCounter:
    """Уникальные формы ``(строк в батче, длина)``, виденные моделью за жизнь процесса."""

    def __init__(self) -> None:
        self._seen: set[tuple[int, int]] = set()
        self._lock = threading.Lock()

    def add(self, rows: int, length: int) -> None:
        with self._lock:
            self._seen.add((int(rows), int(length)))

    @property
    def count(self) -> int:
        return len(self._seen)

    def shapes(self) -> list[tuple[int, int]]:
        with self._lock:
            return sorted(self._seen)
