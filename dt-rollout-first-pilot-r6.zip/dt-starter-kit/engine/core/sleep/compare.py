"""SLEEP-CONTRACT-1 - классификация сравнения нового утверждения со старыми (sleep-1.md §5.4).

Результат - закрытое перечисление :class:`CompareResult`: новое / уточнение / временное обновление
/ противоречие / разные основания / требует проверки. Правила проверяются БЕЗ модели, по слоту
(:mod:`core.sleep.slot`), значениям, датам верности и происхождению:

* **разные основания** - единица, масштаб, валюта, состав суммы, налоговое основание, условия или
  непересекающиеся периоды: утверждения не сливаются, не заменяют друг друга и не спорят;
* **временное обновление** - то же измерение, значение другое, и ОБЕ даты начала верности
  (``valid_from``) заданы и различны. «Новее» определяется ТОЛЬКО датой верности: время загрузки/
  записи (``recorded_at``, mtime, ``known_at``) действующим не делает. Опора на механизмы поиска
  действующей версии - ссылкой: FACTS-BITEMPORAL-1 (``core.facts.temporal``: valid_from/valid_to/
  supersedes) и ``find_latest`` (семейство документа); здесь они не реализуются;
* **противоречие** - два основания расходятся в одном измерении без возможности выбрать по
  времени: показываются ОБА (``show_both``), модель истину не выбирает. Решение владельца
  (``owner_decision``) противоречием не отменяется;
* **требует проверки** - отсутствие в одном входе (отрицательное утверждение) прежнее знание не
  отменяет; недатированное «новее по загрузке» не знак действующего; гипотеза, неоднозначный OCR,
  неполное покрытие при расхождении значений;
* **уточнение** - то же значение в том же слоте, но другая формулировка/исключения/период;
* **новое** - в этой теме (субъект + предикат + область) нет действующих утверждений.

Идемпотентность (тот же exact-отпечаток) классификацией не является: ``Comparison.result`` пуст,
``idempotent_of`` указывает на утверждение реестра. Смысловое сходство формулировок кандидатов
подбирает синтез, не эта функция.

Чистые функции: без IO, сети, модели; в знания и facts ничего не пишут.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from typing import Any

from core.sleep.contract import (
    Claim,
    ClaimType,
    Coverage,
    EvidenceRole,
    ReviewState,
    SourceKind,
    claim_fingerprint,
    norm_text,
)
from core.sleep.slot import slot_diff, topic_key

__all__ = ["CompareResult", "Comparison", "classify", "same_value"]


class CompareResult(StrEnum):
    NEW = "new"
    REFINEMENT = "refinement"
    TEMPORAL_UPDATE = "temporal_update"
    CONTRADICTION = "contradiction"
    DIFFERENT_BASIS = "different_basis"
    NEEDS_CHECK = "needs_check"


# Приоритет при нескольких старых утверждениях в теме: важнейшее для владельца - первым.
_PRIORITY = (
    CompareResult.CONTRADICTION, CompareResult.NEEDS_CHECK, CompareResult.TEMPORAL_UPDATE,
    CompareResult.REFINEMENT, CompareResult.DIFFERENT_BASIS,
)
_INACTIVE = (ReviewState.SUPERSEDED, ReviewState.REJECTED)


@dataclass(frozen=True)
class Comparison:
    """Итог сравнения кандидата. ``matched`` - claim_id затронутых утверждений реестра;
    ``reasons`` - машинные причины (не текст для показа); ``dimensions`` - различающиеся измерения
    слота; ``newer`` - ``candidate``/``existing`` для временного обновления (по valid_from);
    ``show_both`` - противоречие показывает обе версии."""

    result: CompareResult | None
    candidate_id: str
    matched: tuple[str, ...] = ()
    reasons: tuple[str, ...] = ()
    dimensions: tuple[str, ...] = ()
    newer: str = ""
    show_both: bool = False
    idempotent_of: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"result": self.result.value if self.result else None,
                "candidate_id": self.candidate_id, "matched": list(self.matched),
                "reasons": list(self.reasons), "dimensions": list(self.dimensions),
                "newer": self.newer, "show_both": self.show_both,
                "idempotent_of": self.idempotent_of}


def same_value(a: str, b: str) -> bool:
    """Значения равны: нормализованные строки либо одно и то же число (``1 000,5`` = ``1000.5``)."""
    if norm_text(a) == norm_text(b):
        return True
    try:
        return _dec(a) == _dec(b)
    except InvalidOperation:
        return False


def _dec(value: str) -> Decimal:
    return Decimal(str(value).replace(" ", "").replace(" ", "").replace(",", "."))


def _period_disjoint(c: Claim, e: Claim) -> bool:
    c_from, c_to = c.valid_from or None, c.valid_to or None
    e_from, e_to = e.valid_from or None, e.valid_to or None
    return bool((c_to and e_from and c_to <= e_from) or (e_to and c_from and e_to <= c_from))


def _origins(c: Claim) -> set[str]:
    return {x.origin for x in c.evidence if x.role is EvidenceRole.SUPPORT}


def _weak_basis(c: Claim) -> list[str]:
    out = []
    for x in c.evidence:
        if x.role is not EvidenceRole.SUPPORT:
            continue
        if x.ocr_ambiguous and not x.ocr_verified:
            out.append("ocr_ambiguous")
        if x.coverage in (Coverage.PARTIAL, Coverage.SUMMARY_ONLY, Coverage.UNKNOWN):
            out.append("partial_coverage")
    return list(dict.fromkeys(out))


def _owner_basis(c: Claim) -> bool:
    return c.type is ClaimType.OWNER_DECISION or any(
        x.source_kind is SourceKind.OWNER_DECISION and x.role is EvidenceRole.SUPPORT
        for x in c.evidence)


def _pair(c: Claim, e: Claim) -> tuple[CompareResult, tuple[str, ...], tuple[str, ...], str]:
    """``(результат, причины, измерения, newer)`` для пары в одной теме."""
    dims = slot_diff(c, e)
    basis_dims = tuple(d for d in dims if d != "period")
    if basis_dims:
        return (CompareResult.DIFFERENT_BASIS, tuple(f"{d}_differs" for d in basis_dims),
                basis_dims, "")
    if _period_disjoint(c, e):
        return CompareResult.DIFFERENT_BASIS, ("period_disjoint",), ("period",), ""
    # слоты совпадают (период, возможно, перекрывается): сравнение по существу
    if c.negative != e.negative:
        why = ["absence_does_not_cancel"]
        if e.type is ClaimType.OWNER_DECISION:
            why.append("owner_decision_stands")
        return CompareResult.NEEDS_CHECK, tuple(why), (), ""
    if c.type is ClaimType.HYPOTHESIS or e.type is ClaimType.HYPOTHESIS:
        return CompareResult.NEEDS_CHECK, ("hypothesis_involved",), (), ""
    if same_value(c.object, e.object):
        why = ["same_value"]
        if set(c.exceptions) - set(e.exceptions):
            why.append("exceptions_added")
        if norm_text(c.statement) != norm_text(e.statement):
            why.append("wording_differs")
        if dims:
            why.append("period_differs")
        if _origins(c) - _origins(e):
            why.append("new_independent_origin")
        return CompareResult.REFINEMENT, tuple(why), dims, ""
    # значения различаются
    weak = _weak_basis(c) + _weak_basis(e)
    if weak:
        return CompareResult.NEEDS_CHECK, tuple(dict.fromkeys(weak)), (), ""
    declared = ("declared_supersedes",) if e.claim_id in c.supersedes else ()
    if e.type is ClaimType.OWNER_DECISION and not _owner_basis(c):
        return (CompareResult.CONTRADICTION, ("owner_decision_stands", *declared), (), "")
    if c.valid_from and e.valid_from and c.valid_from != e.valid_from:
        newer = "candidate" if c.valid_from > e.valid_from else "existing"
        return CompareResult.TEMPORAL_UPDATE, ("newer_by_valid_from", *declared), (), newer
    if c.valid_from and e.valid_from:  # одна дата начала, два значения
        same = bool(_origins(c) & _origins(e))
        return (CompareResult.CONTRADICTION,
                ("same_start_date", "same_origin" if same else "independent_origins", *declared),
                (), "")
    # хотя бы одна дата верности не задана: «новее по загрузке» действующим не делает
    if _origins(c) & _origins(e):
        why = ["undated", "same_origin"]
        if c.recorded_at > e.recorded_at:
            why.append("newer_by_load_not_current")
        return CompareResult.NEEDS_CHECK, (*why, *declared), (), ""
    return CompareResult.CONTRADICTION, ("undated", "independent_origins", *declared), (), ""


def classify(candidate: Claim, existing: Iterable[Claim]) -> Comparison:
    """Классифицировать кандидата относительно утверждений реестра (см. модуль).

    Сначала идентичность: тот же exact-отпечаток у любого утверждения реестра - идемпотентный
    повтор (``result=None``, ``idempotent_of``). Затем тема (субъект + предикат + область): среди
    действующих (не superseded/rejected) утверждений темы выбирается важнейший исход по
    приоритету «противоречие > требует проверки > временное обновление > уточнение > разные
    основания». Предыдущие ревизии самого кандидата (тот же ``claim_id``) не сравниваются."""
    pool = list(existing)
    fp = claim_fingerprint(candidate)
    for e in pool:
        if claim_fingerprint(e) == fp:
            return Comparison(None, candidate.claim_id, (e.claim_id,), idempotent_of=e.claim_id)
    topic = topic_key(candidate)
    same_topic = [e for e in pool if e.claim_id != candidate.claim_id
                  and e.review_state not in _INACTIVE and topic_key(e) == topic]
    if not same_topic:
        return Comparison(CompareResult.NEW, candidate.claim_id)
    verdicts = [(e, *_pair(candidate, e)) for e in same_topic]
    for target in _PRIORITY:
        hit = [v for v in verdicts if v[1] is target]
        if hit:
            reasons = tuple(dict.fromkeys(r for v in hit for r in v[2]))
            dims = tuple(dict.fromkeys(d for v in hit for d in v[3]))
            newer = hit[0][4]
            return Comparison(
                target, candidate.claim_id, tuple(v[0].claim_id for v in hit), reasons, dims,
                newer, show_both=target is CompareResult.CONTRADICTION)
    return Comparison(CompareResult.NEW, candidate.claim_id)  # недостижимо: _PRIORITY полон
