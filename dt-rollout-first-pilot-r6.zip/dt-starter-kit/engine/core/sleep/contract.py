"""SLEEP-CONTRACT-1 - схемы контракта знания и предложения (sleep-1.md §5.1-§5.3).

Только данные: никакого IO, сети, модели, записи в vault/facts. Хранилище (SLEEP-STORE-1), входы
(SLEEP-INPUT-1) и синтез (SLEEP-SYNTH-1) этого модуля не трогают; они читают схему отсюда.

**Три независимых измерения** (§5.1) - три закрытых перечисления, не одна шкала:

* тип - :class:`ClaimType` (source_assertion / inference / hypothesis / owner_decision /
  procedure);
* проверки - :class:`Check`: НАБОР выполненных проверок (:class:`CheckRecord`), а не уровень
  истины;
* рассмотрение - :class:`ReviewState` (draft / ready / pending / accepted / rejected / snoozed /
  stale / superseded). Принятие гипотезы не меняет ее тип.

**Идентичность** (§5.2): ``claim_id`` + ``revision``. :func:`claim_fingerprint` - exact-отпечаток
содержимого утверждения (идемпотентность повтора); он НЕ идентичность: перефразирование того же
знания - новая ревизия под тем же ``claim_id``. Проверки и согласие владельца привязаны к отпечатку
(``CheckRecord.claim_fingerprint``, ``DecisionRecord.pins``): правка текста делает их неприменимыми.

**Версия схемы** :data:`SCHEMA_VERSION` пишется в каждый верхнеуровневый объект (утверждение,
связь, предложение). :func:`claim_from_dict` и родня отказывают на версии новее известной
(``schema_version_unsupported``) и на неизвестных полях (``schema_invalid``): молча терять поля
новой версии нельзя. Круг ``from_dict(to_dict(x)) == x`` - без потерь.

Что такое «хорошее» утверждение или предложение, решает :mod:`core.sleep.validate`; схема
намеренно принимает неполные объекты (иначе валидатор не смог бы назвать причину отказа машинным
кодом).

``core`` ⊥ cli/mcp; ни сети, ни LLM.
"""

from __future__ import annotations

import hashlib
import json
import unicodedata
from dataclasses import dataclass, field, replace
from enum import StrEnum
from typing import Any, TypeVar

__all__ = [
    "SCHEMA_VERSION",
    "CODE_SCHEMA_INVALID",
    "CODE_SCHEMA_VERSION_MISSING",
    "CODE_SCHEMA_VERSION_UNSUPPORTED",
    "ContractError",
    "ClaimType",
    "Check",
    "ReviewState",
    "EvidenceRole",
    "SourceKind",
    "Coverage",
    "Privacy",
    "LinkType",
    "Operation",
    "ApplyState",
    "Risk",
    "StaleRisk",
    "Actor",
    "Decision",
    "PipelineStep",
    "Evidence",
    "CheckRecord",
    "TestReceipt",
    "ProcedureSpec",
    "FactRef",
    "Pin",
    "DecisionRecord",
    "HistoryEntry",
    "Claim",
    "Link",
    "Target",
    "ExpectedRevision",
    "Snapshot",
    "PipelineCheck",
    "Blocker",
    "GroupSpec",
    "Redirect",
    "PromotionSpec",
    "Proposal",
    "norm_text",
    "fragment_fingerprint",
    "claim_fingerprint",
    "evidence_digest",
    "claim_from_dict",
    "link_from_dict",
    "proposal_from_dict",
    "to_json",
    "claim_from_json",
    "proposal_from_json",
]

# Поднимается при любом изменении формы сериализации; новее известной - отказ на чтении.
SCHEMA_VERSION = 1

CODE_SCHEMA_INVALID = "schema_invalid"  # поле/перечисление/тип не по схеме
CODE_SCHEMA_VERSION_MISSING = "schema_version_missing"  # у верхнеуровневого объекта нет версии
CODE_SCHEMA_VERSION_UNSUPPORTED = "schema_version_unsupported"  # версия новее известной


class ContractError(ValueError):
    """Отказ чтения/разбора: машинный ``code`` + человеку ``reason`` + путь поля."""

    def __init__(self, code: str, reason: str, path: str = "") -> None:
        super().__init__(f"{code}: {reason}" + (f" ({path})" if path else ""))
        self.code = code
        self.reason = reason
        self.path = path


# --------------------------------------------------------------------------- #
# Перечисления                                                                  #
# --------------------------------------------------------------------------- #
class ClaimType(StrEnum):
    """Тип знания (§5.1). Решение человека авторитетно как решение, не как довод о внешнем мире."""

    SOURCE_ASSERTION = "source_assertion"
    INFERENCE = "inference"
    HYPOTHESIS = "hypothesis"
    OWNER_DECISION = "owner_decision"
    PROCEDURE = "procedure"


class Check(StrEnum):
    """Выполненная проверка (§5.1): набор, не шкала. ``unsupported`` - «проверок нет»."""

    UNSUPPORTED = "unsupported"
    LOCATED = "located"
    MECHANICALLY_CHECKED = "mechanically_checked"
    SEMANTICALLY_REVIEWED = "semantically_reviewed"
    TESTED = "tested"  # только для приема с квитанцией испытания


class ReviewState(StrEnum):
    """Рассмотрение (§5.1)."""

    DRAFT = "draft"
    READY = "ready"
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    SNOOZED = "snoozed"
    STALE = "stale"
    SUPERSEDED = "superseded"


class EvidenceRole(StrEnum):
    SUPPORT = "support"
    CONTRADICT = "contradict"
    CONTEXT = "context"


class SourceKind(StrEnum):
    """Чем является основание. Цепь происхождения заканчивается только первыми тремя."""

    ORIGINAL = "original"
    OWNER_DECISION = "owner_decision"
    TEST_RECEIPT = "test_receipt"
    WIKI = "wiki"                # построенное представление: не независимое подтверждение
    MODEL_OUTPUT = "model_output"  # ответ модели: не независимое подтверждение
    CLAIM = "claim"              # ссылка на другое утверждение реестра


class Coverage(StrEnum):
    """Покрытие чтения основания (§4.2/§4.3)."""

    FULL = "full"
    PARTIAL = "partial"          # часть страниц/сообщений/листов; область - в coverage_scope
    SUMMARY_ONLY = "summary_only"  # оригинал недоступен: не стенограмма и не проверенный факт
    UNKNOWN = "unknown"


class Privacy(StrEnum):
    """Политика приватности источника (определяет политика источника, не текст внутри него)."""

    WORK = "work"
    PERSONAL = "personal"
    NDA = "nda"
    UNKNOWN = "unknown"  # блокирует включение в рабочий сон (§4.2); значение по умолчанию


class LinkType(StrEnum):
    """Разрешенные типы связи. ``CO_MENTION`` - только навигационная близость."""

    SUPERSEDES = "supersedes"
    DEPENDS_ON = "depends_on"
    CONTRADICTS = "contradicts"
    DUPLICATE_OF = "duplicate_of"
    DERIVED_FROM = "derived_from"
    PART_OF = "part_of"
    BELONGS_TO = "belongs_to"
    CAUSES = "causes"
    ALIAS_OF = "alias_of"
    CO_MENTION = "co_mention"


class Operation(StrEnum):
    """Операции предложения (§5.3). Физического удаления знаний нет."""

    ADD = "add"
    AMEND = "amend"
    SUPERSEDE = "supersede"
    RELATE = "relate"
    MERGE_REPRESENTATION = "merge_representation"
    REPAIR_REFERENCE = "repair_reference"
    PROMOTE_CONTEXT = "promote_context"
    DEMOTE_CONTEXT = "demote_context"


class ApplyState(StrEnum):
    """Состояние применения (§6.3); у несостоявшегося применения - ``none``."""

    NONE = "none"
    PREPARED = "prepared"
    APPLYING = "applying"
    APPLIED = "applied"
    CONFLICT = "conflict"
    FAILED = "failed"
    RECOVERING = "recovering"


class Risk(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class StaleRisk(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    UNKNOWN = "unknown"


class Actor(StrEnum):
    SLEEP = "sleep"
    OWNER = "owner"
    SYSTEM = "system"


class Decision(StrEnum):
    ACCEPT = "accept"
    REJECT = "reject"
    SNOOZE = "snooze"


class PipelineStep(StrEnum):
    """Последовательность проверок предложения (§5.4), в порядке выполнения."""

    POLICY_SCHEMA = "policy_schema"
    VERSION_LOCATOR = "version_locator"
    FRAGMENT = "fragment"
    NUMBERS_UNITS = "numbers_units"
    DUPLICATES_REJECTIONS = "duplicates_rejections"
    SEMANTIC_REVIEW = "semantic_review"
    DIFF_PLAN = "diff_plan"


# --------------------------------------------------------------------------- #
# Нормализация и отпечатки                                                      #
# --------------------------------------------------------------------------- #
def norm_text(value: Any) -> str:
    """NFC, схлопнутые пробелы, casefold: единственная нормализация для отпечатков и сравнения."""
    return " ".join(unicodedata.normalize("NFC", str(value or "")).split()).casefold()


def _sha(parts: list[str]) -> str:
    return hashlib.sha256("\x1f".join(parts).encode("utf-8")).hexdigest()


def fragment_fingerprint(text: str) -> str:
    """Отпечаток фрагмента основания (sha256 hex 64): сам текст оригинала в SQL не копируется."""
    return _sha(["fragment", norm_text(text)])


# --------------------------------------------------------------------------- #
# Чтение словарей                                                               #
# --------------------------------------------------------------------------- #
_E = TypeVar("_E", bound=StrEnum)


def _bad(path: str, reason: str) -> ContractError:
    return ContractError(CODE_SCHEMA_INVALID, reason, path)


class _Reader:
    """Строгий читатель объекта: типы проверяются, неизвестные ключи - отказ (``done``)."""

    def __init__(self, data: Any, path: str) -> None:
        if not isinstance(data, dict):
            raise _bad(path, "ожидался объект")
        self.d = data
        self.path = path
        self.seen: set[str] = set()

    def _get(self, key: str, default: Any) -> Any:
        self.seen.add(key)
        return self.d.get(key, default)

    def _p(self, key: str) -> str:
        return f"{self.path}.{key}" if self.path else key

    def required(self, key: str) -> None:
        if key not in self.d:
            raise _bad(self._p(key), "обязательное поле отсутствует")

    def str(self, key: str, default: str = "", *, req: bool = False) -> str:
        if req:
            self.required(key)
        value = self._get(key, default)
        if not isinstance(value, str):
            raise _bad(self._p(key), "ожидалась строка")
        return value

    def opt_str(self, key: str) -> str | None:
        value = self._get(key, None)
        if value is not None and not isinstance(value, str):
            raise _bad(self._p(key), "ожидалась строка или null")
        return value

    def int(self, key: str, default: int = 0) -> int:
        value = self._get(key, default)
        if isinstance(value, bool) or not isinstance(value, int):
            raise _bad(self._p(key), "ожидалось целое")
        return value

    def bool(self, key: str, default: bool = False) -> bool:
        value = self._get(key, default)
        if not isinstance(value, bool):
            raise _bad(self._p(key), "ожидалось true/false")
        return value

    def opt_float(self, key: str) -> float | None:
        value = self._get(key, None)
        if value is None:
            return None
        if isinstance(value, bool) or not isinstance(value, int | float):
            raise _bad(self._p(key), "ожидалось число или null")
        return float(value)

    def enum(self, key: str, cls: type[_E], default: _E | None = None) -> _E:
        if default is None:
            self.required(key)
        value = self._get(key, default.value if default is not None else None)
        try:
            return cls(value)
        except ValueError:
            allowed = ", ".join(m.value for m in cls)
            raise _bad(
                self._p(key), f"недопустимое значение {value!r}; допустимо: {allowed}") from None

    def strs(self, key: str) -> tuple[str, ...]:
        value = self._get(key, [])
        if not isinstance(value, list) or not all(isinstance(v, str) for v in value):
            raise _bad(self._p(key), "ожидался список строк")
        return tuple(value)

    def objs(self, key: str, parse: Any) -> tuple[Any, ...]:
        value = self._get(key, [])
        if not isinstance(value, list):
            raise _bad(self._p(key), "ожидался список объектов")
        return tuple(parse(v, f"{self._p(key)}[{i}]") for i, v in enumerate(value))

    def obj(self, key: str, parse: Any) -> Any:
        value = self._get(key, None)
        return None if value is None else parse(value, self._p(key))

    def version(self) -> int:
        """Версия верхнеуровневого объекта: нет - отказ, новее известной - отказ."""
        if "schema_version" not in self.d:
            raise ContractError(CODE_SCHEMA_VERSION_MISSING, "нет schema_version", self.path)
        self.seen.add("schema_version")
        value = self.d["schema_version"]
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise _bad(self._p("schema_version"), "версия схемы - целое >= 1")
        if value > SCHEMA_VERSION:
            raise ContractError(
                CODE_SCHEMA_VERSION_UNSUPPORTED,
                f"версия схемы {value} новее известной {SCHEMA_VERSION}", self.path)
        return value

    def done(self) -> None:
        extra = sorted(set(self.d) - self.seen)
        if extra:
            raise _bad(self.path, "неизвестные поля: " + ", ".join(extra))


# --------------------------------------------------------------------------- #
# Основание, проверки, процедура, решение                                       #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Evidence:
    """Основание утверждения (§5.2): версия, locator, отпечаток фрагмента, роль, происхождение,
    покрытие. ``origin_id`` - первый источник семейства: копии с общим происхождением не
    считаются независимыми подтверждениями. ``derived_from`` - claim_id, на которых построено
    представление (вики/ответ модели/ссылка на утверждение)."""

    source_id: str
    role: EvidenceRole
    revision: int = 0
    content_hash: str = ""
    locator: str = ""
    fragment_fingerprint: str = ""
    source_kind: SourceKind = SourceKind.ORIGINAL
    origin_id: str = ""
    coverage: Coverage = Coverage.FULL
    coverage_scope: str = ""
    privacy: Privacy = Privacy.UNKNOWN
    source_path: str = ""
    ocr_ambiguous: bool = False
    ocr_verified: bool = False
    derived_from: tuple[str, ...] = ()
    fragment: str = ""

    @property
    def origin(self) -> str:
        return self.origin_id or self.source_id

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_id": self.source_id, "role": self.role.value, "revision": self.revision,
            "content_hash": self.content_hash, "locator": self.locator,
            "fragment_fingerprint": self.fragment_fingerprint,
            "source_kind": self.source_kind.value, "origin_id": self.origin_id,
            "coverage": self.coverage.value, "coverage_scope": self.coverage_scope,
            "privacy": self.privacy.value, "source_path": self.source_path,
            "ocr_ambiguous": self.ocr_ambiguous, "ocr_verified": self.ocr_verified,
            "derived_from": list(self.derived_from), "fragment": self.fragment,
        }

    @classmethod
    def from_dict(cls, data: Any, path: str = "evidence") -> Evidence:
        r = _Reader(data, path)
        out = cls(
            source_id=r.str("source_id", req=True), role=r.enum("role", EvidenceRole),
            revision=r.int("revision"), content_hash=r.str("content_hash"),
            locator=r.str("locator"), fragment_fingerprint=r.str("fragment_fingerprint"),
            source_kind=r.enum("source_kind", SourceKind, SourceKind.ORIGINAL),
            origin_id=r.str("origin_id"),
            coverage=r.enum("coverage", Coverage, Coverage.FULL),
            coverage_scope=r.str("coverage_scope"),
            privacy=r.enum("privacy", Privacy, Privacy.UNKNOWN),
            source_path=r.str("source_path"), ocr_ambiguous=r.bool("ocr_ambiguous"),
            ocr_verified=r.bool("ocr_verified"), derived_from=r.strs("derived_from"),
            fragment=r.str("fragment"),
        )
        r.done()
        return out


@dataclass(frozen=True)
class CheckRecord:
    """Одна выполненная проверка. Привязана к отпечатку текста, на котором выполнена; смысловая
    рецензия обязана назвать автора/версию (``by``) и причины - она не «независимая гарантия»."""

    check: Check
    claim_fingerprint: str = ""
    at: str = ""
    by: str = ""
    reasons: tuple[str, ...] = ()
    receipt_ref: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"check": self.check.value, "claim_fingerprint": self.claim_fingerprint,
                "at": self.at, "by": self.by, "reasons": list(self.reasons),
                "receipt_ref": self.receipt_ref}

    @classmethod
    def from_dict(cls, data: Any, path: str = "check") -> CheckRecord:
        r = _Reader(data, path)
        out = cls(check=r.enum("check", Check), claim_fingerprint=r.str("claim_fingerprint"),
                  at=r.str("at"), by=r.str("by"), reasons=r.strs("reasons"),
                  receipt_ref=r.str("receipt_ref"))
        r.done()
        return out


@dataclass(frozen=True)
class TestReceipt:
    """Квитанция испытания приема: повторное испытание или fixture, с версией среды."""

    __test__ = False  # не тест-класс для pytest

    receipt_id: str
    kind: str = ""              # retest | fixture
    outcome: str = ""           # passed | failed
    environment_version: str = ""
    at: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"receipt_id": self.receipt_id, "kind": self.kind, "outcome": self.outcome,
                "environment_version": self.environment_version, "at": self.at}

    @classmethod
    def from_dict(cls, data: Any, path: str = "test_receipt") -> TestReceipt:
        r = _Reader(data, path)
        out = cls(receipt_id=r.str("receipt_id", req=True), kind=r.str("kind"),
                  outcome=r.str("outcome"), environment_version=r.str("environment_version"),
                  at=r.str("at"))
        r.done()
        return out


@dataclass(frozen=True)
class ProcedureSpec:
    """Прием (§5.2): условия, действие, наблюдаемый результат, версия среды, способ отмены."""

    conditions: tuple[str, ...] = ()
    action: str = ""
    observable_result: str = ""
    environment_version: str = ""
    undo: str = ""
    test_receipt: TestReceipt | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"conditions": list(self.conditions), "action": self.action,
                "observable_result": self.observable_result,
                "environment_version": self.environment_version, "undo": self.undo,
                "test_receipt": self.test_receipt.to_dict() if self.test_receipt else None}

    @classmethod
    def from_dict(cls, data: Any, path: str = "procedure") -> ProcedureSpec:
        r = _Reader(data, path)
        out = cls(conditions=r.strs("conditions"), action=r.str("action"),
                  observable_result=r.str("observable_result"),
                  environment_version=r.str("environment_version"), undo=r.str("undo"),
                  test_receipt=r.obj("test_receipt", TestReceipt.from_dict))
        r.done()
        return out


@dataclass(frozen=True)
class FactRef:
    """Ссылка утверждения на точное значение в facts (значения в ledger не дублируются)."""

    fact_id: str
    fact_key: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"fact_id": self.fact_id, "fact_key": self.fact_key}

    @classmethod
    def from_dict(cls, data: Any, path: str = "fact_ref") -> FactRef:
        r = _Reader(data, path)
        out = cls(fact_id=r.str("fact_id", req=True), fact_key=r.str("fact_key"))
        r.done()
        return out


@dataclass(frozen=True)
class Pin:
    """«Согласие на ЭТОТ текст»: claim_id + отпечаток, на котором решение принято."""

    claim_id: str
    fingerprint: str

    def to_dict(self) -> dict[str, Any]:
        return {"claim_id": self.claim_id, "fingerprint": self.fingerprint}

    @classmethod
    def from_dict(cls, data: Any, path: str = "pin") -> Pin:
        r = _Reader(data, path)
        out = cls(claim_id=r.str("claim_id", req=True), fingerprint=r.str("fingerprint", req=True))
        r.done()
        return out


@dataclass(frozen=True)
class DecisionRecord:
    """Решение (квитанция): кто, когда, по какому предложению/ревизии и на какие отпечатки.
    Согласие на измененный текст не переносится: отпечатки сверяются с текущими."""

    decision: Decision
    actor: Actor
    at: str = ""
    proposal_id: str = ""
    proposal_revision: int = 0
    pins: tuple[Pin, ...] = ()
    evidence_digest: str = ""
    reason: str = ""
    snooze_until: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"decision": self.decision.value, "actor": self.actor.value, "at": self.at,
                "proposal_id": self.proposal_id, "proposal_revision": self.proposal_revision,
                "pins": [p.to_dict() for p in self.pins], "evidence_digest": self.evidence_digest,
                "reason": self.reason, "snooze_until": self.snooze_until}

    @classmethod
    def from_dict(cls, data: Any, path: str = "decision") -> DecisionRecord:
        r = _Reader(data, path)
        out = cls(decision=r.enum("decision", Decision), actor=r.enum("actor", Actor),
                  at=r.str("at"), proposal_id=r.str("proposal_id"),
                  proposal_revision=r.int("proposal_revision"),
                  pins=r.objs("pins", Pin.from_dict), evidence_digest=r.str("evidence_digest"),
                  reason=r.str("reason"), snooze_until=r.str("snooze_until"))
        r.done()
        return out


@dataclass(frozen=True)
class HistoryEntry:
    revision: int
    at: str = ""
    actor: Actor = Actor.SLEEP
    action: str = ""
    fingerprint: str = ""
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"revision": self.revision, "at": self.at, "actor": self.actor.value,
                "action": self.action, "fingerprint": self.fingerprint, "note": self.note}

    @classmethod
    def from_dict(cls, data: Any, path: str = "history") -> HistoryEntry:
        r = _Reader(data, path)
        out = cls(revision=r.int("revision"), at=r.str("at"),
                  actor=r.enum("actor", Actor, Actor.SLEEP), action=r.str("action"),
                  fingerprint=r.str("fingerprint"), note=r.str("note"))
        r.done()
        return out


# --------------------------------------------------------------------------- #
# Утверждение                                                                   #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Claim:
    """Утверждение (§5.2).

    Слот сравнения (:mod:`core.sleep.compare`): субъект, предикат, область, условия, единица
    (``unit``+``scale``), период (``valid_from``/``valid_to``) и ``basis`` (состав суммы /
    налоговое основание, §5.4: разные основания не сливаются). ``fact_refs`` - ссылки на facts;
    ``premises`` - claim_id посылок вывода; ``negative``+``search_scope`` - отрицательное
    утверждение с явной областью проверки (§4.3). ``valid_to`` - полуинтервал ``[from, to)``,
    пусто - пока верно."""

    claim_id: str
    revision: int
    type: ClaimType
    subject: str
    predicate: str
    object: str
    statement: str
    area: str = ""
    unit: str = ""
    scale: float | None = None
    basis: str = ""
    conditions: tuple[str, ...] = ()
    exceptions: tuple[str, ...] = ()
    valid_from: str | None = None
    valid_to: str | None = None
    recorded_at: str = ""
    negative: bool = False
    search_scope: str = ""
    evidence: tuple[Evidence, ...] = ()
    fact_refs: tuple[FactRef, ...] = ()
    premises: tuple[str, ...] = ()
    explanation: str = ""
    alternatives: tuple[str, ...] = ()
    procedure: ProcedureSpec | None = None
    review_state: ReviewState = ReviewState.DRAFT
    checks: tuple[CheckRecord, ...] = ()
    unknown: tuple[str, ...] = ()
    stale_risk: StaleRisk = StaleRisk.UNKNOWN
    next_check_on: str | None = None
    supersedes: tuple[str, ...] = ()
    depends_on: tuple[str, ...] = ()
    contradicts: tuple[str, ...] = ()
    duplicate_of: str | None = None
    run_id: str = ""
    fingerprint: str = ""
    decisions: tuple[DecisionRecord, ...] = ()
    history: tuple[HistoryEntry, ...] = ()
    schema_version: int = SCHEMA_VERSION

    @property
    def fact_keys(self) -> tuple[str, ...]:
        return tuple(sorted({f.fact_key for f in self.fact_refs if f.fact_key}))

    def with_fingerprint(self) -> Claim:
        """Копия с пересчитанным ``fingerprint`` (валидатор сверяет сохраненный)."""
        return replace(self, fingerprint=claim_fingerprint(self))

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version, "claim_id": self.claim_id,
            "revision": self.revision, "type": self.type.value, "subject": self.subject,
            "predicate": self.predicate, "object": self.object, "statement": self.statement,
            "area": self.area, "unit": self.unit, "scale": self.scale, "basis": self.basis,
            "conditions": list(self.conditions), "exceptions": list(self.exceptions),
            "valid_from": self.valid_from, "valid_to": self.valid_to,
            "recorded_at": self.recorded_at, "negative": self.negative,
            "search_scope": self.search_scope,
            "evidence": [e.to_dict() for e in self.evidence],
            "fact_refs": [f.to_dict() for f in self.fact_refs],
            "premises": list(self.premises), "explanation": self.explanation,
            "alternatives": list(self.alternatives),
            "procedure": self.procedure.to_dict() if self.procedure else None,
            "review_state": self.review_state.value,
            "checks": [c.to_dict() for c in self.checks], "unknown": list(self.unknown),
            "stale_risk": self.stale_risk.value, "next_check_on": self.next_check_on,
            "supersedes": list(self.supersedes), "depends_on": list(self.depends_on),
            "contradicts": list(self.contradicts), "duplicate_of": self.duplicate_of,
            "run_id": self.run_id, "fingerprint": self.fingerprint,
            "decisions": [d.to_dict() for d in self.decisions],
            "history": [h.to_dict() for h in self.history],
        }

    @classmethod
    def from_dict(cls, data: Any, path: str = "claim") -> Claim:
        r = _Reader(data, path)
        version = r.version()
        out = cls(
            claim_id=r.str("claim_id", req=True), revision=r.int("revision", 0),
            type=r.enum("type", ClaimType), subject=r.str("subject"),
            predicate=r.str("predicate"), object=r.str("object"),
            statement=r.str("statement"), area=r.str("area"), unit=r.str("unit"),
            scale=r.opt_float("scale"), basis=r.str("basis"),
            conditions=r.strs("conditions"), exceptions=r.strs("exceptions"),
            valid_from=r.opt_str("valid_from"), valid_to=r.opt_str("valid_to"),
            recorded_at=r.str("recorded_at"), negative=r.bool("negative"),
            search_scope=r.str("search_scope"),
            evidence=r.objs("evidence", Evidence.from_dict),
            fact_refs=r.objs("fact_refs", FactRef.from_dict), premises=r.strs("premises"),
            explanation=r.str("explanation"), alternatives=r.strs("alternatives"),
            procedure=r.obj("procedure", ProcedureSpec.from_dict),
            review_state=r.enum("review_state", ReviewState, ReviewState.DRAFT),
            checks=r.objs("checks", CheckRecord.from_dict), unknown=r.strs("unknown"),
            stale_risk=r.enum("stale_risk", StaleRisk, StaleRisk.UNKNOWN),
            next_check_on=r.opt_str("next_check_on"), supersedes=r.strs("supersedes"),
            depends_on=r.strs("depends_on"), contradicts=r.strs("contradicts"),
            duplicate_of=r.opt_str("duplicate_of"), run_id=r.str("run_id"),
            fingerprint=r.str("fingerprint"),
            decisions=r.objs("decisions", DecisionRecord.from_dict),
            history=r.objs("history", HistoryEntry.from_dict), schema_version=version,
        )
        r.done()
        return out


def claim_fingerprint(claim: Claim) -> str:
    """Exact-отпечаток СОДЕРЖИМОГО утверждения (sha256 hex 64): что утверждается, при каких
    условиях и за какой период. Не входят основания, проверки, статусы, пояснение и альтернативы
    (они не меняют утверждение) и ``claim_id``/``revision``. Повтор того же содержимого дает тот же
    отпечаток (идемпотентность); любое изменение формулировки - другой отпечаток."""
    proc = claim.procedure
    parts = [
        claim.type.value, norm_text(claim.subject), norm_text(claim.predicate),
        norm_text(claim.object), norm_text(claim.statement), norm_text(claim.area),
        norm_text(claim.unit), "" if claim.scale is None else repr(claim.scale),
        norm_text(claim.basis),
        "|".join(sorted(norm_text(c) for c in claim.conditions)),
        "|".join(sorted(norm_text(e) for e in claim.exceptions)),
        claim.valid_from or "", claim.valid_to or "",
        "neg" if claim.negative else "pos", norm_text(claim.search_scope),
        "|".join(sorted(claim.premises)),
    ]
    if proc is not None:
        parts += [
            "|".join(sorted(norm_text(c) for c in proc.conditions)), norm_text(proc.action),
            norm_text(proc.observable_result), norm_text(proc.environment_version),
            norm_text(proc.undo),
        ]
    return _sha(["claim", *parts])


def evidence_digest(evidence: list[Evidence] | tuple[Evidence, ...]) -> str:
    """Отпечаток НАБОРА оснований (sha256 hex 64), не зависящий от порядка и повторов.

    Подавляет повтор отклоненного предложения (§5.4): то же основание - тот же digest; новая версия
    источника, другой locator или другой фрагмент - другой digest, то есть «новое основание»."""
    rows = sorted({
        "|".join([e.origin, e.source_id, str(e.revision), e.content_hash, e.locator,
                  e.fragment_fingerprint, e.role.value])
        for e in evidence
    })
    return _sha(["evidence", *rows])


# --------------------------------------------------------------------------- #
# Связь                                                                         #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Link:
    """Связь (§5.2): тип, направление (``source`` -> ``target``), существующие концы и основание.
    Концы - ссылки ``claim:<id>`` / ``entity:<id>``. ``alias_of`` проходит существующее принятие
    алиасов: нужен ``acceptance_ref``."""

    link_id: str
    type: LinkType
    source: str
    target: str
    evidence: tuple[Evidence, ...] = ()
    acceptance_ref: str = ""
    run_id: str = ""
    schema_version: int = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return {"schema_version": self.schema_version, "link_id": self.link_id,
                "type": self.type.value, "source": self.source, "target": self.target,
                "evidence": [e.to_dict() for e in self.evidence],
                "acceptance_ref": self.acceptance_ref, "run_id": self.run_id}

    @classmethod
    def from_dict(cls, data: Any, path: str = "link") -> Link:
        r = _Reader(data, path)
        version = r.version()
        out = cls(link_id=r.str("link_id", req=True), type=r.enum("type", LinkType),
                  source=r.str("source"), target=r.str("target"),
                  evidence=r.objs("evidence", Evidence.from_dict),
                  acceptance_ref=r.str("acceptance_ref"), run_id=r.str("run_id"),
                  schema_version=version)
        r.done()
        return out


# --------------------------------------------------------------------------- #
# Предложение                                                                   #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Target:
    """Цель операции: ``kind`` - claim | link | representation | context | reference."""

    kind: str
    ref: str

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "ref": self.ref}

    @classmethod
    def from_dict(cls, data: Any, path: str = "target") -> Target:
        r = _Reader(data, path)
        out = cls(kind=r.str("kind", req=True), ref=r.str("ref", req=True))
        r.done()
        return out


@dataclass(frozen=True)
class ExpectedRevision:
    """Ревизия цели, на которой строилось предложение (CAS при применении)."""

    ref: str
    revision: int = 0
    content_hash: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"ref": self.ref, "revision": self.revision, "content_hash": self.content_hash}

    @classmethod
    def from_dict(cls, data: Any, path: str = "expected_revision") -> ExpectedRevision:
        r = _Reader(data, path)
        out = cls(ref=r.str("ref", req=True), revision=r.int("revision"),
                  content_hash=r.str("content_hash"))
        r.done()
        return out


@dataclass(frozen=True)
class Snapshot:
    """«Было»/«стало»: утверждения, связи и описание представления/ссылки/уровня контекста."""

    claims: tuple[Claim, ...] = ()
    links: tuple[Link, ...] = ()
    note: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"claims": [c.to_dict() for c in self.claims],
                "links": [link.to_dict() for link in self.links], "note": self.note}

    @classmethod
    def from_dict(cls, data: Any, path: str = "snapshot") -> Snapshot:
        r = _Reader(data, path)
        out = cls(claims=r.objs("claims", Claim.from_dict), links=r.objs("links", Link.from_dict),
                  note=r.str("note"))
        r.done()
        return out


@dataclass(frozen=True)
class PipelineCheck:
    """Результат одного шага последовательности проверок предложения (§5.4)."""

    step: PipelineStep
    ok: bool
    by: str = ""
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"step": self.step.value, "ok": self.ok, "by": self.by, "detail": self.detail}

    @classmethod
    def from_dict(cls, data: Any, path: str = "check") -> PipelineCheck:
        r = _Reader(data, path)
        out = cls(step=r.enum("step", PipelineStep), ok=r.bool("ok"), by=r.str("by"),
                  detail=r.str("detail"))
        r.done()
        return out


@dataclass(frozen=True)
class Blocker:
    """Блокер предложения: причина, по которой оно не может идти владельцу/в применение."""

    code: str
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"code": self.code, "detail": self.detail}

    @classmethod
    def from_dict(cls, data: Any, path: str = "blocker") -> Blocker:
        r = _Reader(data, path)
        out = cls(code=r.str("code", req=True), detail=r.str("detail"))
        r.done()
        return out


@dataclass(frozen=True)
class GroupSpec:
    """Группа утверждений в одной карточке: одна причина, явный состав, атомарная единица."""

    reason: str = ""
    atomic_unit: str = ""
    members: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {"reason": self.reason, "atomic_unit": self.atomic_unit,
                "members": list(self.members)}

    @classmethod
    def from_dict(cls, data: Any, path: str = "group") -> GroupSpec:
        r = _Reader(data, path)
        out = cls(reason=r.str("reason"), atomic_unit=r.str("atomic_unit"),
                  members=r.strs("members"))
        r.done()
        return out


@dataclass(frozen=True)
class Redirect:
    """Перенаправление при слиянии/переносе представлений: старый ID не теряется."""

    from_ref: str
    to_ref: str

    def to_dict(self) -> dict[str, Any]:
        return {"from_ref": self.from_ref, "to_ref": self.to_ref}

    @classmethod
    def from_dict(cls, data: Any, path: str = "redirect") -> Redirect:
        r = _Reader(data, path)
        out = cls(from_ref=r.str("from_ref", req=True), to_ref=r.str("to_ref", req=True))
        r.done()
        return out


@dataclass(frozen=True)
class PromotionSpec:
    """Условия постоянного повышения в контекст (§8.2): применение, цена контекста, проверка,
    срок/условие снятия."""

    application: str = ""
    context_cost_tokens: int = 0
    verification: str = ""
    expiry_condition: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"application": self.application, "context_cost_tokens": self.context_cost_tokens,
                "verification": self.verification, "expiry_condition": self.expiry_condition}

    @classmethod
    def from_dict(cls, data: Any, path: str = "promotion") -> PromotionSpec:
        r = _Reader(data, path)
        out = cls(application=r.str("application"),
                  context_cost_tokens=r.int("context_cost_tokens"),
                  verification=r.str("verification"), expiry_condition=r.str("expiry_condition"))
        r.done()
        return out


@dataclass(frozen=True)
class Proposal:
    """Конверт предложения (§5.3). Одна карточка - одно связное решение.

    Сверх списка §5.3: ``schema_version``; ``revision`` (ревизия предложения: согласие привязано к
    ней); ``group``/``redirects``/``promotion``/``context_mode`` (условия отдельных операций);
    ``reopens``+``new_basis`` (связанная ревизия после отказа с новым основанием);
    ``created_at``."""

    proposal_id: str
    idempotency_key: str
    operation: Operation
    targets: tuple[Target, ...] = ()
    expected_revisions: tuple[ExpectedRevision, ...] = ()
    before: Snapshot = field(default_factory=Snapshot)
    after: Snapshot = field(default_factory=Snapshot)
    claim_ids: tuple[str, ...] = ()
    evidence_digest: str = ""
    checks: tuple[PipelineCheck, ...] = ()
    blockers: tuple[Blocker, ...] = ()
    why_now: str = ""
    intended_use: str = ""
    risk: Risk = Risk.MEDIUM
    run_id: str = ""
    review_state: ReviewState = ReviewState.DRAFT
    apply_state: ApplyState = ApplyState.NONE
    decision_receipt: DecisionRecord | None = None
    effects: tuple[str, ...] = ()
    revision: int = 1
    created_at: str = ""
    group: GroupSpec | None = None
    redirects: tuple[Redirect, ...] = ()
    promotion: PromotionSpec | None = None
    context_mode: str = "normal"
    reopens: str = ""
    new_basis: str = ""
    schema_version: int = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": self.schema_version, "proposal_id": self.proposal_id,
            "idempotency_key": self.idempotency_key, "operation": self.operation.value,
            "targets": [t.to_dict() for t in self.targets],
            "expected_revisions": [e.to_dict() for e in self.expected_revisions],
            "before": self.before.to_dict(), "after": self.after.to_dict(),
            "claim_ids": list(self.claim_ids), "evidence_digest": self.evidence_digest,
            "checks": [c.to_dict() for c in self.checks],
            "blockers": [b.to_dict() for b in self.blockers], "why_now": self.why_now,
            "intended_use": self.intended_use, "risk": self.risk.value, "run_id": self.run_id,
            "review_state": self.review_state.value, "apply_state": self.apply_state.value,
            "decision_receipt": self.decision_receipt.to_dict() if self.decision_receipt else None,
            "effects": list(self.effects), "revision": self.revision,
            "created_at": self.created_at,
            "group": self.group.to_dict() if self.group else None,
            "redirects": [x.to_dict() for x in self.redirects],
            "promotion": self.promotion.to_dict() if self.promotion else None,
            "context_mode": self.context_mode, "reopens": self.reopens,
            "new_basis": self.new_basis,
        }

    @classmethod
    def from_dict(cls, data: Any, path: str = "proposal") -> Proposal:
        r = _Reader(data, path)
        version = r.version()
        out = cls(
            proposal_id=r.str("proposal_id", req=True),
            idempotency_key=r.str("idempotency_key"),
            operation=r.enum("operation", Operation),
            targets=r.objs("targets", Target.from_dict),
            expected_revisions=r.objs("expected_revisions", ExpectedRevision.from_dict),
            before=r.obj("before", Snapshot.from_dict) or Snapshot(),
            after=r.obj("after", Snapshot.from_dict) or Snapshot(),
            claim_ids=r.strs("claim_ids"), evidence_digest=r.str("evidence_digest"),
            checks=r.objs("checks", PipelineCheck.from_dict),
            blockers=r.objs("blockers", Blocker.from_dict), why_now=r.str("why_now"),
            intended_use=r.str("intended_use"), risk=r.enum("risk", Risk, Risk.MEDIUM),
            run_id=r.str("run_id"),
            review_state=r.enum("review_state", ReviewState, ReviewState.DRAFT),
            apply_state=r.enum("apply_state", ApplyState, ApplyState.NONE),
            decision_receipt=r.obj("decision_receipt", DecisionRecord.from_dict),
            effects=r.strs("effects"), revision=r.int("revision", 1),
            created_at=r.str("created_at"), group=r.obj("group", GroupSpec.from_dict),
            redirects=r.objs("redirects", Redirect.from_dict),
            promotion=r.obj("promotion", PromotionSpec.from_dict),
            context_mode=r.str("context_mode", "normal"), reopens=r.str("reopens"),
            new_basis=r.str("new_basis"), schema_version=version,
        )
        r.done()
        return out


# --------------------------------------------------------------------------- #
# Публичные точки сериализации                                                  #
# --------------------------------------------------------------------------- #
def claim_from_dict(data: Any) -> Claim:
    return Claim.from_dict(data)


def link_from_dict(data: Any) -> Link:
    return Link.from_dict(data)


def proposal_from_dict(data: Any) -> Proposal:
    return Proposal.from_dict(data)


def to_json(obj: Claim | Link | Proposal) -> str:
    """Каноничный JSON (ключи по алфавиту, кириллица как есть): стабилен для diff и хешей."""
    return json.dumps(obj.to_dict(), ensure_ascii=False, sort_keys=True, indent=1)


def _loads(text: str) -> Any:
    try:
        return json.loads(text)
    except ValueError as exc:
        raise ContractError(CODE_SCHEMA_INVALID, f"не JSON: {exc}") from None


def claim_from_json(text: str) -> Claim:
    return Claim.from_dict(_loads(text))


def proposal_from_json(text: str) -> Proposal:
    return Proposal.from_dict(_loads(text))
