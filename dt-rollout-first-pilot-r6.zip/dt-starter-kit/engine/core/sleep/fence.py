"""Shared runtime boundary: synthesis cannot access held-out answers."""

from __future__ import annotations

import contextvars
from collections.abc import Iterator
from contextlib import contextmanager

__all__ = [
    "CODE_FORBIDDEN_IN_PIPELINE",
    "ControlAccessError",
    "assert_control_allowed",
    "in_pipeline",
    "pipeline_scope",
]

CODE_FORBIDDEN_IN_PIPELINE = "control_forbidden_in_pipeline"

_active: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "sleep_pipeline_active", default=False
)


class ControlAccessError(RuntimeError):
    """Конвейер сна обратился к контрольному набору. ``code`` - машинный."""

    def __init__(self, message: str, code: str = CODE_FORBIDDEN_IN_PIPELINE) -> None:
        super().__init__(message)
        self.code = code


@contextmanager
def pipeline_scope() -> Iterator[None]:
    """Участок кода конвейера сна: контрольный набор здесь недоступен."""
    token = _active.set(True)
    try:
        yield
    finally:
        _active.reset(token)


def in_pipeline() -> bool:
    return _active.get()


def assert_control_allowed() -> None:
    """Отказ, если вызов идет из конвейера сна (внутри ``pipeline_scope``)."""
    if in_pipeline():
        raise ControlAccessError(
            "контрольный набор сна недоступен конвейеру сна: ответы не входят во вход синтеза "
            "(sleep-1.md §11)"
        )
