"""SLEEP-CONTRACT-1 - общий ключ проблемы lint/synth/sleep и правило «одна основная карточка».

sleep-1.md §5.4: «общий issue_key согласует lint/synth/sleep: одна проблема имеет основную карточку,
остальные детекторы добавляют основания и сохраняют свой аудит».

**Ключ** ``<категория>:<12 hex>`` = ``sha256(категория | предмет)``: :func:`issue_key`. Категория -
закрытое :class:`IssueCategory`, предмет - то, ЧТО именно сломано (факт, хаб, пара заметок,
утверждение, слот), а не КТО это нашел и КОГДА. Поэтому два детектора об одной проблеме получают
один ключ, а повтор того же детектора - тот же ключ.

**Не ломает чужие ключи.** Ключи lint (``core.lint.store.finding_id``: ``<правило>-<12 hex>``) и
идентификаторы карточек synth (``s-<10 hex>`` от хаба+времени+текста) НЕ меняются и не читаются
заново: issue_key - отдельное ПРОИЗВОДНОЕ значение, вычисляемое адаптерами из полей их записей
(:func:`issue_key_of_finding`, :func:`issue_key_of_synth_card`); код lint/synth не правился, их
хранилища ключа не содержат. Соответствие проверено тестами на живых детекторах и ``propose``.

**Соответствие проблем:**

=======================  =======================================================  ================
категория                кто порождает                                            предмет
=======================  =======================================================  ================
``fact_conflict``        lint ``fact_conflict``; sleep: противоречие утверждений  ``fact_key``
                         с общим ``fact_key``
``hub_state``            lint ``hub_stale``; synth «Состояние хаба?»; sleep      id хаба
``orphan``               lint ``orphan``                                          id заметки
``duplicate``            lint ``duplicate``                                       пара id (без
                                                                                  порядка)
``claim_check``          lint ``claim`` (модельный проход по хабу)                хаб + отпечаток
                                                                                  утверждения
``claim_conflict``       sleep: противоречие без общего ``fact_key``              слот без периода
``claim_update``         sleep: amend / supersede                                 claim_id цели
``new_claim``            sleep: add                                               слот
``link``                 sleep: relate                                            тип + концы
``representation``       sleep: merge_representation                              цели
``reference``            sleep: repair_reference                                  цели + «было»
``context_rule``         sleep: promote_context / demote_context                  claim_id
=======================  =======================================================  ================

**Правило «одна основная карточка»** (:func:`consolidate`), детерминированно, без модели:

1. карточки с одним ключом - одна проблема; группы упорядочены по ключу;
2. решенная (``applied``/``resolved``) закрывает проблему; отклоненная (``rejected``/``dismissed``)
   или отложенная (``snoozed``) подавляет повтор с тем же ``evidence_digest`` или без него
   (воскресшей карточки нет); открытая карточка с другим digest - существенно новое основание:
   ``new_basis=True`` (нужна связанная ревизия с объяснением, §5.4);
3. основной - карточка, которую владелец УЖЕ видит (``visible``): ее не подменяют;
   затем предпочтение источника по категории (:data:`SOURCE_RANK`), затем самая ранняя, затем id;
4. остальные открытые карточки остаются в своих хранилищах (свой аудит не теряется) и входят в
   ``additional_basis`` основной: как дополнительные основания, но НЕ как отдельные карточки очереди
   (``hidden`` - что не считать в «требуют решения» и бюджете USE-LOOP-1).

Этот модуль ничего не пишет и не скрывает сам: он отвечает «какая карточка основная»; применить
ответ в очереди - отдельный пакет (SLEEP-STORE-1 + USE-LOOP-1).

Чистые функции; ``core`` ⊥ cli/mcp; ни сети, ни LLM.
"""

from __future__ import annotations

import hashlib
import unicodedata
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from core.sleep.contract import Claim, LinkType, Operation, Proposal
from core.sleep.slot import slot_key

__all__ = [
    "ISSUE_KEY_VERSION",
    "IssueCategory",
    "IssueSource",
    "IssueCard",
    "IssueGroup",
    "SOURCE_RANK",
    "issue_key",
    "issue_key_of_finding",
    "issue_key_of_synth_card",
    "issue_key_of_proposal",
    "conflict_subject",
    "claim_digest",
    "consolidate",
]

# Версия схемы ключа: при смене формулы ключи не сравнимы между версиями.
ISSUE_KEY_VERSION = 1


class IssueCategory(StrEnum):
    FACT_CONFLICT = "fact_conflict"
    HUB_STATE = "hub_state"
    ORPHAN = "orphan"
    DUPLICATE = "duplicate"
    CLAIM_CHECK = "claim_check"
    CLAIM_CONFLICT = "claim_conflict"
    CLAIM_UPDATE = "claim_update"
    NEW_CLAIM = "new_claim"
    LINK = "link"
    REPRESENTATION = "representation"
    REFERENCE = "reference"
    CONTEXT_RULE = "context_rule"


class IssueSource(StrEnum):
    LINT = "lint"
    SYNTH = "synth"
    SLEEP = "sleep"


# Предпочтение источника при равенстве (меньше - основнее). Хаб: у synth уже готовый текст секции;
# конфликт фактов: у lint есть штатные хирургические действия keep_a/keep_b; в остальном - lint,
# затем sleep. Менять порядок можно только здесь и только решением владельца.
SOURCE_RANK: dict[IssueCategory, tuple[IssueSource, ...]] = {
    IssueCategory.HUB_STATE: (IssueSource.SYNTH, IssueSource.SLEEP, IssueSource.LINT),
    IssueCategory.FACT_CONFLICT: (IssueSource.LINT, IssueSource.SLEEP, IssueSource.SYNTH),
}
_DEFAULT_RANK = (IssueSource.LINT, IssueSource.SLEEP, IssueSource.SYNTH)


def _norm(subject: str) -> str:
    return unicodedata.normalize("NFC", str(subject)).strip()


def issue_key(category: IssueCategory | str, subject: str) -> str:
    """Ключ проблемы: ``<категория>:<12 hex>``. Пустой предмет - ошибка (ключ «ни о чем» склеил бы
    все проблемы категории в одну)."""
    cat = IssueCategory(category)
    subj = _norm(subject)
    if not subj:
        raise ValueError("issue_key: пустой предмет проблемы")
    digest = hashlib.sha256(f"{cat.value}|{subj}".encode()).hexdigest()
    return f"{cat.value}:{digest[:12]}"


def claim_digest(claim_text: str) -> str:
    """Отпечаток текста утверждения хаба (10 hex) - как у lint ``claim`` (нормализация регистра и
    пробелов), чтобы ключ совпадал с идентичностью находки линта."""
    norm = " ".join(str(claim_text).casefold().split())
    return hashlib.sha1(norm.encode()).hexdigest()[:10]  # noqa: S324 - отпечаток, не защита


def conflict_subject(claim: Claim) -> str:
    """Предмет конфликта утверждений: слот без периода (то же измерение в любой период)."""
    return "slot:" + slot_key(claim, period=False)


# --------------------------------------------------------------------------- #
# Адаптеры: из записей lint / synth / sleep                                     #
# --------------------------------------------------------------------------- #
def issue_key_of_finding(finding: Mapping[str, Any]) -> str:
    """Ключ проблемы по находке линта (форма ``core.lint.store``: ``rule``/``subject``/``meta``).
    Неизвестное правило - ``ValueError`` (тихой подстановки ключа нет)."""
    rule = str(finding.get("rule") or "")
    subject = str(finding.get("subject") or "")
    meta = finding.get("meta") or {}
    if rule == "fact_conflict":
        return issue_key(IssueCategory.FACT_CONFLICT, str(meta.get("fact_key") or subject))
    if rule == "hub_stale":
        return issue_key(IssueCategory.HUB_STATE, str(meta.get("hub_id") or subject))
    if rule == "orphan":
        return issue_key(IssueCategory.ORPHAN, str(meta.get("note_id") or subject))
    if rule == "duplicate":
        pair = sorted([str(meta.get("newer") or subject), str(meta.get("older") or "")])
        return issue_key(IssueCategory.DUPLICATE, "|".join(p for p in pair if p))
    if rule == "claim":
        hub = str(meta.get("hub_id") or subject)
        return issue_key(IssueCategory.CLAIM_CHECK,
                         f"{hub}|{claim_digest(str(meta.get('claim') or ''))}")
    raise ValueError(f"issue_key_of_finding: неизвестное правило линта {rule!r}")


def issue_key_of_synth_card(row: Mapping[str, Any]) -> str:
    """Ключ проблемы по карточке synth («Состояние хаба?»): предмет - хаб, не текст секции
    (текст меняется, проблема «состояние хаба устарело» та же)."""
    return issue_key(IssueCategory.HUB_STATE, str(row.get("hub_id") or ""))


_SYMMETRIC = (LinkType.CO_MENTION, LinkType.CONTRADICTS)


def issue_key_of_proposal(
    proposal: Proposal, *, conflict_with: Claim | None = None,
) -> str:
    """Ключ проблемы по предложению сна.

    ``conflict_with`` - утверждение реестра, с которым кандидат предложения классификация
    (:func:`core.sleep.compare.classify`) признала ПРОТИВОРЕЧИЕМ. Тогда проблема - конфликт, и при
    общем ``fact_key`` ключ совпадает с ключом lint ``fact_conflict`` (одна проблема - одна
    основная карточка); без общего ``fact_key`` - конфликт слота."""
    op = proposal.operation
    cand = proposal.after.claims[0] if proposal.after.claims else None
    if conflict_with is not None and cand is not None:
        shared = sorted(set(cand.fact_keys) & set(conflict_with.fact_keys))
        if shared:
            return issue_key(IssueCategory.FACT_CONFLICT, shared[0])
        return issue_key(IssueCategory.CLAIM_CONFLICT, conflict_subject(cand))
    refs = sorted(t.ref for t in proposal.targets)
    if op is Operation.ADD and cand is not None:
        return issue_key(IssueCategory.NEW_CLAIM, "slot:" + slot_key(cand))
    if op in (Operation.AMEND, Operation.SUPERSEDE):
        return issue_key(IssueCategory.CLAIM_UPDATE, "|".join(refs))
    if op is Operation.RELATE and proposal.after.links:
        link = proposal.after.links[0]
        ends = sorted([link.source, link.target]) if link.type in _SYMMETRIC \
            else [link.source, link.target]
        return issue_key(IssueCategory.LINK, "|".join([link.type.value, *ends]))
    if op is Operation.MERGE_REPRESENTATION:
        return issue_key(IssueCategory.REPRESENTATION, "|".join(refs))
    if op is Operation.REPAIR_REFERENCE:
        return issue_key(IssueCategory.REFERENCE, "|".join([*refs, proposal.before.note]))
    if op in (Operation.PROMOTE_CONTEXT, Operation.DEMOTE_CONTEXT):
        return issue_key(IssueCategory.CONTEXT_RULE, "|".join(refs))
    raise ValueError(f"issue_key_of_proposal: нет предмета у операции {op.value} без целей")


# --------------------------------------------------------------------------- #
# Одна проблема - одна основная карточка                                        #
# --------------------------------------------------------------------------- #
_OPEN = ("pending",)
_STOPPED = ("rejected", "dismissed", "snoozed")  # владелец остановил проблему (отказ/отложил)
_DONE = ("applied", "resolved")


@dataclass(frozen=True)
class IssueCard:
    """Карточка любого детектора, приведенная к общему виду. ``status``: ``pending`` (ждет
    решения), ``snoozed``, ``rejected``/``dismissed`` (отказ), ``applied``/``resolved``.
    ``visible`` - владелец ее уже видит в очереди; ``evidence_digest`` - отпечаток основания
    (пусто - у детектора его нет)."""

    issue_key: str
    source: IssueSource
    card_id: str
    status: str = "pending"
    since: str = ""
    evidence_digest: str = ""
    visible: bool = False
    reason: str = ""


@dataclass(frozen=True)
class IssueGroup:
    """Итог по одной проблеме. ``primary`` - основная карточка (``None``, если открытых нет:
    проблема решена, подавлена или отложена); ``additional_basis`` - остальные открытые карточки
    (их аудит остается у них); ``suppressed`` - повтор отклоненного/решенного основания, карточку не
    показывать; ``new_basis`` - есть существенно новое основание после отказа."""

    issue_key: str
    primary: IssueCard | None
    additional_basis: tuple[IssueCard, ...] = ()
    suppressed: bool = False
    new_basis: bool = False
    resolved: bool = False
    stopped: tuple[IssueCard, ...] = field(default=())

    @property
    def hidden(self) -> tuple[str, ...]:
        """card_id карточек, которые не считать отдельными позициями очереди и бюджета."""
        return tuple(c.card_id for c in self.additional_basis)


def _rank(card: IssueCard) -> tuple[Any, ...]:
    category = IssueCategory(card.issue_key.split(":", 1)[0])
    order = SOURCE_RANK.get(category, _DEFAULT_RANK)
    return (0 if card.visible else 1, order.index(card.source), card.since or "~", card.card_id)


def consolidate(cards: Iterable[IssueCard]) -> tuple[IssueGroup, ...]:
    """Свести карточки детекторов в группы «одна проблема - одна основная карточка» (см. модуль)."""
    by_key: dict[str, list[IssueCard]] = {}
    for card in cards:
        by_key.setdefault(card.issue_key, []).append(card)
    out: list[IssueGroup] = []
    for key in sorted(by_key):
        group = by_key[key]
        open_cards = [c for c in group if c.status in _OPEN]
        stopped = tuple(c for c in group if c.status not in _OPEN)
        closed = [c for c in group if c.status in _STOPPED + _DONE]
        closed_digests = {c.evidence_digest for c in closed}
        resolved = any(c.status in _DONE for c in group)
        # повтор: то же основание (или основание неизвестно) после остановки/решения
        repeats = [c for c in open_cards if closed and (
            not c.evidence_digest or c.evidence_digest in closed_digests)]
        fresh = [c for c in open_cards if c not in repeats]
        new_basis = bool(closed) and any(c.evidence_digest for c in fresh)
        if not fresh:
            out.append(IssueGroup(key, None, (), suppressed=bool(repeats), resolved=resolved,
                                  stopped=stopped))
            continue
        ordered = sorted(fresh, key=_rank)
        out.append(IssueGroup(key, ordered[0], tuple(ordered[1:]), suppressed=False,
                              new_basis=new_basis, resolved=resolved, stopped=stopped))
    return tuple(out)
