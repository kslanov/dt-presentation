"""Слот сравнения (sleep-1.md §5.2): субъект, предикат, область, условия, единица, период.

Слот отвечает на вопрос «об одном и том же измерении ли речь»: утверждения с разным слотом не
сливаются, не заменяют друг друга и не считаются противоречием (§5.4: разные единицы, составы суммы,
налоговые основания, валюты и периоды сохраняются). К слоту добавлены ``scale`` (масштаб единицы:
«млн» и «тыс» не смешиваются молча) и ``basis`` (состав суммы / налоговое основание): §5.4 требует
различать их, а в перечне §5.2 им места нет (отклонение, см. отчет пакета).

Смысловое сходство формулировок слота НЕ определяет: здесь только точное сравнение нормализованных
строк (:func:`core.sleep.contract.norm_text`). Подбор кандидатов по смыслу - дело синтеза.

Чистые функции: без IO, сети, модели.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

from core.sleep.contract import Claim, norm_text

__all__ = ["DIMENSIONS", "Slot", "slot_of", "slot_key", "topic_key", "slot_diff"]

# Измерения слота в порядке показа. ``period`` - пара (valid_from, valid_to).
DIMENSIONS = ("subject", "predicate", "area", "conditions", "unit", "scale", "basis", "period")


@dataclass(frozen=True)
class Slot:
    subject: str
    predicate: str
    area: str
    conditions: tuple[str, ...]
    unit: str
    scale: float | None
    basis: str
    valid_from: str | None
    valid_to: str | None


def slot_of(claim: Claim) -> Slot:
    return Slot(
        subject=norm_text(claim.subject), predicate=norm_text(claim.predicate),
        area=norm_text(claim.area),
        conditions=tuple(sorted({norm_text(c) for c in claim.conditions if norm_text(c)})),
        unit=norm_text(claim.unit), scale=claim.scale, basis=norm_text(claim.basis),
        valid_from=claim.valid_from or None, valid_to=claim.valid_to or None)


def slot_key(claim_or_slot: Claim | Slot, *, period: bool = True) -> str:
    """Стабильный ключ слота (sha256, 16 hex): одинаков у утверждений об одном измерении.
    ``period=False`` - без периода: «то же измерение в любой период» (ключ проблемы-конфликта)."""
    s = slot_of(claim_or_slot) if isinstance(claim_or_slot, Claim) else claim_or_slot
    raw = "\x1f".join([
        s.subject, s.predicate, s.area, "|".join(s.conditions), s.unit,
        "" if s.scale is None else repr(s.scale), s.basis,
        (s.valid_from or "") if period else "", (s.valid_to or "") if period else ""])
    return hashlib.sha256(("slot\x1f" + raw).encode("utf-8")).hexdigest()[:16]


def topic_key(claim_or_slot: Claim | Slot) -> str:
    """Ключ темы: субъект + предикат + область (то, о чем речь, без единицы/условий/периода)."""
    s = slot_of(claim_or_slot) if isinstance(claim_or_slot, Claim) else claim_or_slot
    raw = "\x1f".join([s.subject, s.predicate, s.area])
    return hashlib.sha256(("topic\x1f" + raw).encode("utf-8")).hexdigest()[:16]


def slot_diff(a: Claim | Slot, b: Claim | Slot, *, ignore: tuple[str, ...] = ()) -> tuple[str, ...]:
    """Измерения, по которым слоты различаются (пусто - один слот). ``ignore`` - измерения, которые
    в данной операции допускается менять (для замены по времени - ``("period",)``)."""
    x = slot_of(a) if isinstance(a, Claim) else a
    y = slot_of(b) if isinstance(b, Claim) else b
    differ: list[str] = []
    for dim in DIMENSIONS:
        if dim in ignore:
            continue
        if dim == "period":
            same = (x.valid_from, x.valid_to) == (y.valid_from, y.valid_to)
        else:
            same = getattr(x, dim) == getattr(y, dim)
        if not same:
            differ.append(dim)
    return tuple(differ)
