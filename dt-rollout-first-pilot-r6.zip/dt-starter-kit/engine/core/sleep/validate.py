"""SLEEP-CONTRACT-1 - детерминированный валидатор контракта (sleep-1.md §5.2-§5.4, §2, §4).

Строгий БЛОКИРУЮЩИЙ валидатор публикации/применения для сна: предупреждение ``save_output``
(PROV-CITED-1) плохой факт не запрещает, этот валидатор запрещает. Модель не вызывается, ничего не
читается с диска и не пишется: на входе объекты :mod:`core.sleep.contract` и (необязательно) снимок
реестра :class:`Ledger`, который предоставит SLEEP-STORE-1.

Результат - :class:`Verdict`: список :class:`Violation` (машинный ``code`` + путь поля + причина).
Отказ - конверт ядра :func:`core.contract` (``ok: false`` + ``refused`` + ``code``), а проверки,
которые без реестра выполнить НЕЛЬЗЯ (существование концов связи, CAS ревизий), не пропускаются
молча: вердикт получает предупреждение ``store_unavailable`` (принцип 22: деградация с сигналом).

Правила (кратко; полный перечень и таблица «сценарий -> код» - в отчете пакета и матрице):

* обязательные поля по типу: вывод - посылки, объяснение, альтернативы; процедура - условия,
  действие, наблюдаемый результат, версия среды, способ отмены; решение владельца - его запись;
* цепь происхождения заканчивается оригиналом, решением человека или квитанцией испытания;
  вики и ответ модели - не доказательство; цикл подтверждения запрещен (:func:`validate_claim_set`);
* идентичность: ``claim_id``+``revision``; повтор содержимого - идемпотентность (exact-отпечаток),
  перефразирование - ревизия, чужой слот под тем же ``claim_id`` - отказ
  (:func:`validate_revision`);
* переходы рассмотрения: решения принимает только владелец, принятие гипотезы не меняет ее тип;
  согласие и проверки привязаны к отпечатку и после правки текста не переносятся;
* приватность: ``_nda``/личное/неизвестное в основании и цели - отказ; секреты в тексте - отказ;
* предложение: операции §5.3 и их цели, ``before/after``, ожидаемые ревизии, digest оснований,
  отказ с тем же digest не воскресает, группа - явный состав и одна причина.

``core`` ⊥ cli/mcp; ни сети, ни LLM.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from core.contract import CODE_STORE_UNAVAILABLE, warning
from core.privacy import any_nda
from core.sleep.compare import CompareResult, classify
from core.sleep.contract import (
    CODE_SCHEMA_INVALID,
    CODE_SCHEMA_VERSION_MISSING,
    CODE_SCHEMA_VERSION_UNSUPPORTED,
    SCHEMA_VERSION,
    Actor,
    ApplyState,
    Check,
    Claim,
    ClaimType,
    Coverage,
    Decision,
    DecisionRecord,
    Evidence,
    EvidenceRole,
    Link,
    LinkType,
    Operation,
    PipelineStep,
    Privacy,
    Proposal,
    ReviewState,
    SourceKind,
    claim_fingerprint,
    evidence_digest,
    fragment_fingerprint,
    norm_text,
)
from core.sleep.slot import slot_diff

__all__ = [
    "Policy",
    "Ledger",
    "SECRET_PATTERNS",
    "Violation",
    "Verdict",
    "ALL_CODES",
    "validate_evidence",
    "validate_claim",
    "validate_claim_set",
    "validate_revision",
    "check_transition",
    "validate_link",
    "validate_links",
    "validate_proposal",
    "contains_secret",
    "CODE_SCHEMA_INVALID",
    "CODE_SCHEMA_VERSION_MISSING",
    "CODE_SCHEMA_VERSION_UNSUPPORTED",
]

# --------------------------------------------------------------------------- #
# Коды отказа (машиночитаемые; по ним считает телеметрия отказов)               #
# --------------------------------------------------------------------------- #
# общие
CODE_REQUIRED_FIELD_MISSING = "required_field_missing"
CODE_REVISION_INVALID = "revision_invalid"
CODE_FINGERPRINT_MISMATCH = "fingerprint_mismatch"
CODE_VALID_PERIOD_INVALID = "valid_period_invalid"
CODE_HISTORY_INCONSISTENT = "history_inconsistent"
CODE_SECRET_IN_PAYLOAD = "secret_in_payload"  # noqa: S105 - имя кода, не секрет
# тип и основания
CODE_HYPOTHESIS_AS_FACT = "hypothesis_as_fact"
CODE_OWNER_DECISION_AS_FACT = "owner_decision_as_fact"
CODE_DERIVED_EVIDENCE_NOT_PROOF = "derived_evidence_not_proof"
CODE_CHAIN_NO_TERMINAL = "chain_no_terminal"
CODE_CONFIRMATION_CYCLE = "confirmation_cycle"
CODE_REFERENCE_MISSING = "reference_missing"
CODE_INFERENCE_PREMISES_MISSING = "inference_premises_missing"
CODE_INFERENCE_EXPLANATION_MISSING = "inference_explanation_missing"
CODE_INFERENCE_ALTERNATIVES_MISSING = "inference_alternatives_missing"
CODE_PROCEDURE_FIELD_MISSING = "procedure_field_missing"
CODE_PROCEDURE_UNTESTED = "procedure_untested"
CODE_DECISION_RECORD_MISSING = "decision_record_missing"
CODE_NEGATIVE_SCOPE_MISSING = "negative_scope_missing"
# проверки
CODE_CHECKS_INCONSISTENT = "checks_inconsistent"
CODE_CHECK_STALE = "check_stale"
CODE_CHECK_WITHOUT_BASIS = "check_without_basis"
CODE_REVIEW_AUTHOR_MISSING = "review_author_missing"
CODE_TESTED_NOT_PROCEDURE = "tested_not_procedure"
CODE_TESTED_RECEIPT_INVALID = "tested_receipt_invalid"
CODE_FRAGMENT_FINGERPRINT_MISMATCH = "fragment_fingerprint_mismatch"
CODE_NUMBER_NOT_IN_FRAGMENT = "number_not_in_fragment"
# основание: версия, приватность, покрытие
CODE_EVIDENCE_FIELD_MISSING = "evidence_field_missing"
CODE_EVIDENCE_NDA = "evidence_nda"
CODE_EVIDENCE_PERSONAL = "evidence_personal"
CODE_EVIDENCE_PRIVACY_UNKNOWN = "evidence_privacy_unknown"
CODE_COVERAGE_SCOPE_MISSING = "coverage_scope_missing"
CODE_SUMMARY_ONLY_AS_FACT = "summary_only_as_fact"
CODE_OCR_AMBIGUOUS_UNCHECKED = "ocr_ambiguous_unchecked"
CODE_TARGET_NDA = "target_nda"
# идентичность и слот
CODE_CLAIM_ID_REUSE = "claim_id_reuse"
CODE_REVISION_CONFLICT = "revision_conflict"
CODE_REVISION_WITHOUT_CHANGE = "revision_without_change"
CODE_SLOT_MISMATCH = "slot_mismatch"
# рассмотрение
CODE_TRANSITION_FORBIDDEN = "transition_forbidden"
CODE_DECISION_BY_NON_OWNER = "decision_by_non_owner"
CODE_CONSENT_NOT_TRANSFERABLE = "consent_not_transferable"
# связи
CODE_LINK_ENDPOINT_INVALID = "link_endpoint_invalid"
CODE_LINK_ENDPOINT_MISSING = "link_endpoint_missing"
CODE_LINK_SELF_REFERENCE = "link_self_reference"
CODE_LINK_EVIDENCE_MISSING = "link_evidence_missing"
CODE_LINK_COOCCURRENCE_ONLY = "link_cooccurrence_only"
CODE_LINK_CYCLE = "link_cycle"
CODE_ALIAS_NEEDS_ACCEPTANCE = "alias_needs_acceptance"
# предложение
CODE_OPERATION_TARGET_MISSING = "operation_target_missing"
CODE_BEFORE_MISSING = "before_missing"
CODE_AFTER_MISSING = "after_missing"
CODE_EXPECTED_REVISION_MISSING = "expected_revision_missing"
CODE_EXPECTED_REVISION_STALE = "expected_revision_stale"
CODE_SOURCE_CHANGED = "source_changed"
CODE_CLAIM_IDS_MISMATCH = "claim_ids_mismatch"
CODE_EVIDENCE_DIGEST_MISMATCH = "evidence_digest_mismatch"
CODE_BLOCKERS_OPEN = "blockers_open"
CODE_CHECKS_INCOMPLETE = "checks_incomplete"
CODE_CHECKS_OUT_OF_ORDER = "checks_out_of_order"
CODE_APPLY_WITHOUT_ACCEPTANCE = "apply_without_acceptance"
CODE_REJECTED_REPEAT = "rejected_repeat"
CODE_SNOOZED_REPEAT = "snoozed_repeat"
CODE_NEW_BASIS_UNEXPLAINED = "new_basis_unexplained"
CODE_IDEMPOTENCY_CONFLICT = "idempotency_conflict"
CODE_GROUP_UNEXPLAINED = "group_unexplained"
CODE_GROUP_INDEPENDENT_CLAIMS = "group_independent_claims"
CODE_SUPERSEDE_LINK_MISSING = "supersede_link_missing"
CODE_OWNER_DECISION_OVERRIDDEN = "owner_decision_overridden"
CODE_ABSENCE_NOT_BASIS = "absence_not_basis"
CODE_MULTI_NOTE_FORBIDDEN = "multi_note_atomic_forbidden"
CODE_REDIRECT_MISSING = "redirect_missing"
CODE_PROMOTION_SPEC_MISSING = "promotion_spec_missing"
CODE_PROMOTE_NOT_ACCEPTED = "promote_not_accepted"
CODE_HYPOTHESIS_PROMOTED = "hypothesis_promoted"
CODE_OPERATION_MISMATCH = "operation_mismatch"
CODE_CONTRADICTION_NEEDS_BOTH = "contradiction_needs_both_versions"
CODE_SUPERSEDE_UNVERIFIED = "supersede_unverified"
CODE_SUPERSEDE_REVERSED = "supersede_reversed"

ALL_CODES: tuple[str, ...] = tuple(sorted(
    v for k, v in dict(globals()).items() if k.startswith("CODE_") and isinstance(v, str)
    and k not in ("CODE_STORE_UNAVAILABLE",)))

_RELEVANT = (ReviewState.READY, ReviewState.PENDING, ReviewState.ACCEPTED)
_DERIVED_KINDS = (SourceKind.WIKI, SourceKind.MODEL_OUTPUT, SourceKind.CLAIM)
_OWNER_ONLY = (ReviewState.ACCEPTED, ReviewState.REJECTED, ReviewState.SNOOZED)


# --------------------------------------------------------------------------- #
# Политика, реестр, вердикт                                                     #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Policy:
    """Политика валидатора. ``allow_multi_note=False`` - MVP §6.3: одна заметка на атомарное
    предложение, multi-file merge запрещен до отдельной приемки."""

    allow_multi_note: bool = False


@dataclass(frozen=True)
class Ledger:
    """Снимок реестра для проверок «против состояния» (предоставит SLEEP-STORE-1; здесь - данные).

    ``claims`` - действующая ревизия каждого claim_id; ``entities`` - существующие сущности
    (``entity:<id>``); ``sources`` - актуальный ``content_hash`` источников; ``decided`` -
    предложения с решением владельца (отказ/snooze) и применявшиеся; ``now`` - дата/время для
    истечения snooze (пусто - snooze считается действующим)."""

    claims: Mapping[str, Claim] = field(default_factory=dict)
    entities: frozenset[str] = frozenset()
    sources: Mapping[str, str] = field(default_factory=dict)
    decided: tuple[Proposal, ...] = ()
    now: str = ""


@dataclass(frozen=True)
class Violation:
    code: str
    path: str = ""
    reason: str = ""
    detail: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"code": self.code, "path": self.path, "reason": self.reason}
        if self.detail:
            out["detail"] = self.detail
        return out


@dataclass(frozen=True)
class Verdict:
    """Итог проверки: нарушения (блокируют) и предупреждения-конверты ядра (не блокируют)."""

    violations: tuple[Violation, ...] = ()
    warnings: tuple[dict[str, Any], ...] = ()

    @property
    def ok(self) -> bool:
        return not self.violations

    @property
    def codes(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(v.code for v in self.violations))

    def has(self, code: str) -> bool:
        return any(v.code == code for v in self.violations)

    def to_dict(self) -> dict[str, Any]:
        """Ответ границы: здоровый - ``{ok: true, warning?}``; отказ - ``{ok: false, refused, code,
        error, violations}`` (форма ``core.contract``), ``code`` - первое нарушение."""
        if self.ok:
            out: dict[str, Any] = {"ok": True}
        else:
            first = self.violations[0]
            out = {"ok": False, "refused": first.code, "code": first.code,
                   "error": f"{first.code}: {first.reason}" if first.reason else first.code,
                   "violations": [v.to_dict() for v in self.violations]}
        if self.warnings:
            out["warning"] = list(self.warnings)
        return out


class _Sink:
    def __init__(self) -> None:
        self.v: list[Violation] = []
        self.w: list[dict[str, Any]] = []

    def add(self, code: str, path: str, reason: str, **detail: Any) -> None:
        self.v.append(Violation(code, path, reason, {k: x for k, x in detail.items() if x}))

    def warn(self, code: str, reason: str, **ctx: Any) -> None:
        self.w.append(warning(code, reason, **ctx))

    def verdict(self) -> Verdict:
        seen: set[tuple[str, str]] = set()
        uniq = []
        for x in self.v:
            key = (x.code, x.path)
            if key not in seen:
                seen.add(key)
                uniq.append(x)
        return Verdict(tuple(uniq), tuple(self.w))


# --------------------------------------------------------------------------- #
# Вспомогательное                                                               #
# --------------------------------------------------------------------------- #
_SECRET_RES = (
    re.compile(r"\bsk-[A-Za-z0-9_\-]{20,}"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._\-]{20,}"),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\."),
    re.compile(r"(?i)\b(?:api[_-]?key|secret|token|password|passwd|pwd)\b\s*[:=]\s*\S{6,}"),
)
_NUMBER_RE = re.compile(r"\d+(?:[  ]\d{3})*(?:[.,]\d+)?")


SECRET_PATTERNS = _SECRET_RES  # публично: редактор секретов SLEEP-INPUT-1 берет тот же набор


def contains_secret(text: str) -> bool:
    """Консервативный детектор секрета в тексте (ключи API, токены, приватные ключи, пароли)."""
    return any(r.search(text or "") for r in _SECRET_RES)


def _numbers(text: str) -> set[str]:
    out = set()
    for m in _NUMBER_RE.findall(text or ""):
        num = m.replace(" ", "").replace(" ", "").replace(",", ".")
        out.add(num.rstrip("0").rstrip(".") if "." in num else num)
    return out


def _is_date(value: str | None) -> bool:
    try:
        date.fromisoformat(str(value))
    except ValueError:
        return False
    return True


def _is_ts(value: str) -> bool:
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return True


def _empty(value: Any) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def _fp(claim: Claim) -> str:
    return claim_fingerprint(claim)


# --------------------------------------------------------------------------- #
# Основание                                                                     #
# --------------------------------------------------------------------------- #
def _evidence_checks(e: Evidence, path: str, sink: _Sink) -> None:
    missing = [name for name, val in (
        ("source_id", e.source_id), ("content_hash", e.content_hash), ("locator", e.locator),
        ("fragment_fingerprint", e.fragment_fingerprint)) if _empty(val)]
    if e.revision < 1:
        missing.append("revision")
    for name in missing:
        sink.add(CODE_EVIDENCE_FIELD_MISSING, f"{path}.{name}",
                 f"в основании нет обязательного поля {name}: версия, locator и отпечаток "
                 "фрагмента фиксируются всегда", field=name)
    if e.privacy is Privacy.NDA or any_nda(e.source_path, e.locator, e.source_id):
        sink.add(CODE_EVIDENCE_NDA, path, "основание из _nda: в рабочий сон не входит")
    elif e.privacy is Privacy.PERSONAL:
        sink.add(CODE_EVIDENCE_PERSONAL, path, "личное основание: в рабочий сон не входит")
    elif e.privacy is Privacy.UNKNOWN:
        sink.add(CODE_EVIDENCE_PRIVACY_UNKNOWN, path,
                 "приватность источника не определена политикой источника: блокирует включение")
    if e.fragment:
        if contains_secret(e.fragment):
            sink.add(CODE_SECRET_IN_PAYLOAD, f"{path}.fragment", "в фрагменте похоже на секрет")
        if e.fragment_fingerprint and fragment_fingerprint(e.fragment) != e.fragment_fingerprint:
            sink.add(CODE_FRAGMENT_FINGERPRINT_MISMATCH, f"{path}.fragment",
                     "отпечаток не соответствует приложенному фрагменту")
    if e.coverage is Coverage.PARTIAL or e.coverage is Coverage.UNKNOWN:
        if _empty(e.coverage_scope):
            sink.add(CODE_COVERAGE_SCOPE_MISSING, f"{path}.coverage_scope",
                     "покрытие неполное, но область (страницы/сообщения/листы) не названа",
                     coverage=e.coverage.value)


def validate_evidence(evidence: Evidence, path: str = "evidence") -> Verdict:
    """Основание само по себе: версия/locator/отпечаток, приватность, секрет, покрытие."""
    sink = _Sink()
    _evidence_checks(evidence, path, sink)
    return sink.verdict()


# --------------------------------------------------------------------------- #
# Утверждение                                                                   #
# --------------------------------------------------------------------------- #
def _claim_checks(claim: Claim, sink: _Sink, base: str) -> None:
    for name in ("claim_id", "subject", "predicate", "object", "statement", "area", "run_id"):
        if _empty(getattr(claim, name)):
            sink.add(CODE_REQUIRED_FIELD_MISSING, f"{base}.{name}",
                     f"обязательное поле {name} пусто", field=name)
    if claim.revision < 1:
        sink.add(CODE_REVISION_INVALID, f"{base}.revision", "ревизия - целое >= 1")
    if _empty(claim.recorded_at) or not _is_ts(claim.recorded_at):
        sink.add(CODE_REQUIRED_FIELD_MISSING, f"{base}.recorded_at",
                 "recorded_at - время записи в ISO-формате", field="recorded_at")
    for name in ("valid_from", "valid_to", "next_check_on"):
        value = getattr(claim, name)
        if value not in (None, "") and not _is_date(value):
            sink.add(CODE_VALID_PERIOD_INVALID, f"{base}.{name}", f"{name} - дата ГГГГ-ММ-ДД")
    if (claim.valid_from and claim.valid_to and _is_date(claim.valid_from)
            and _is_date(claim.valid_to) and claim.valid_from >= claim.valid_to):
        sink.add(CODE_VALID_PERIOD_INVALID, f"{base}.valid_to",
                 "период - полуинтервал [valid_from, valid_to): конец должен быть позже начала")
    if claim.fingerprint != _fp(claim):
        sink.add(CODE_FINGERPRINT_MISMATCH, f"{base}.fingerprint",
                 "сохраненный отпечаток не соответствует содержимому утверждения")
    for name in ("statement", "object", "explanation"):
        if contains_secret(getattr(claim, name)):
            sink.add(CODE_SECRET_IN_PAYLOAD, f"{base}.{name}", "похоже на секрет в тексте")
    if any(contains_secret(a) for a in claim.alternatives):
        sink.add(CODE_SECRET_IN_PAYLOAD, f"{base}.alternatives", "похоже на секрет в тексте")
    if claim.negative and _empty(claim.search_scope):
        sink.add(CODE_NEGATIVE_SCOPE_MISSING, f"{base}.search_scope",
                 "отрицательное утверждение требует явной области проверки "
                 "(«нет в сообщениях 1-20» не равно «решения не существует»)")
    for ref_name in ("supersedes", "depends_on", "contradicts", "premises"):
        if claim.claim_id in getattr(claim, ref_name):
            sink.add(CODE_LINK_SELF_REFERENCE, f"{base}.{ref_name}",
                     "утверждение ссылается на себя")
    if claim.duplicate_of == claim.claim_id:
        sink.add(CODE_LINK_SELF_REFERENCE, f"{base}.duplicate_of",
                 "утверждение дубль самого себя")
    if claim.history:
        revs = [h.revision for h in claim.history]
        if revs != sorted(set(revs)) or revs[-1] != claim.revision:
            sink.add(CODE_HISTORY_INCONSISTENT, f"{base}.history",
                     "история: ревизии строго возрастают и последняя равна текущей")

    for i, e in enumerate(claim.evidence):
        _evidence_checks(e, f"{base}.evidence[{i}]", sink)
    _grounding_checks(claim, sink, base)
    _type_checks(claim, sink, base)
    _check_records(claim, sink, base)
    _state_checks(claim, sink, base)


def _grounding_checks(claim: Claim, sink: _Sink, base: str) -> None:
    support = [e for e in claim.evidence if e.role is EvidenceRole.SUPPORT]
    direct = [e for e in support if e.source_kind is SourceKind.ORIGINAL]
    derived_only_fail = False
    if claim.type is ClaimType.SOURCE_ASSERTION and not direct:
        derived_only_fail = True
        if not support:
            sink.add(CODE_HYPOTHESIS_AS_FACT, f"{base}.evidence",
                     "утверждение источника без оригинала-основания: это гипотеза под видом факта")
        elif all(e.source_kind is SourceKind.OWNER_DECISION for e in support):
            sink.add(CODE_OWNER_DECISION_AS_FACT, f"{base}.evidence",
                     "решение владельца авторитетно как решение, не как довод о внешнем "
                     "обстоятельстве")
        else:
            sink.add(CODE_DERIVED_EVIDENCE_NOT_PROOF, f"{base}.evidence",
                     "вики, ответ модели и ссылка на другое утверждение - не оригинал: "
                     "цепь должна кончаться оригиналом")
    if not derived_only_fail:
        for i, e in enumerate(claim.evidence):
            if (e.role is EvidenceRole.SUPPORT and e.source_kind in _DERIVED_KINDS
                    and not e.derived_from):
                sink.add(CODE_CHAIN_NO_TERMINAL, f"{base}.evidence[{i}]",
                         "построенное представление без указания утверждений-оснований: "
                         "не доказательство")


def _type_checks(claim: Claim, sink: _Sink, base: str) -> None:
    t = claim.type
    if t is ClaimType.INFERENCE:
        if not claim.premises:
            sink.add(CODE_INFERENCE_PREMISES_MISSING, f"{base}.premises", "вывод без посылок")
        if _empty(claim.explanation):
            sink.add(CODE_INFERENCE_EXPLANATION_MISSING, f"{base}.explanation",
                     "вывод без объяснения")
        if not [a for a in claim.alternatives if not _empty(a)]:
            sink.add(CODE_INFERENCE_ALTERNATIVES_MISSING, f"{base}.alternatives",
                     "вывод без рассмотренных альтернатив")
    elif t is ClaimType.PROCEDURE:
        p = claim.procedure
        if p is None:
            sink.add(CODE_PROCEDURE_FIELD_MISSING, f"{base}.procedure", "у приема нет описания",
                     fields=["conditions", "action", "observable_result", "environment_version",
                             "undo"])
        else:
            absent = [n for n, v in (
                ("conditions", any(not _empty(c) for c in p.conditions)),
                ("action", not _empty(p.action)),
                ("observable_result", not _empty(p.observable_result)),
                ("environment_version", not _empty(p.environment_version)),
                ("undo", not _empty(p.undo))) if not v]
            if absent:
                sink.add(CODE_PROCEDURE_FIELD_MISSING, f"{base}.procedure",
                         "у приема не заполнено: " + ", ".join(absent), fields=absent)
    elif t is ClaimType.OWNER_DECISION:
        if not any(d.actor is Actor.OWNER and d.decision is Decision.ACCEPT
                   for d in claim.decisions):
            sink.add(CODE_DECISION_RECORD_MISSING, f"{base}.decisions",
                     "решение владельца без записи решения (кто, когда, на какой текст)")


def _check_records(claim: Claim, sink: _Sink, base: str) -> None:
    present = {c.check for c in claim.checks}
    fp = _fp(claim)
    if Check.UNSUPPORTED in present and len(present) > 1:
        sink.add(CODE_CHECKS_INCONSISTENT, f"{base}.checks",
                 "unsupported («проверок нет») несовместимо с выполненными проверками")
    for i, rec in enumerate(claim.checks):
        if rec.check is not Check.UNSUPPORTED and rec.claim_fingerprint != fp:
            sink.add(CODE_CHECK_STALE, f"{base}.checks[{i}]",
                     "проверка выполнена на другом тексте: после правки проверка повторяется",
                     check=rec.check.value)
    basis = [e for e in claim.evidence
             if e.role in (EvidenceRole.SUPPORT, EvidenceRole.CONTRADICT)
             and e.locator and e.fragment_fingerprint]
    if Check.LOCATED in present and not basis:
        sink.add(CODE_CHECK_WITHOUT_BASIS, f"{base}.checks",
                 "located без основания с locator и отпечатком фрагмента")
    for later in (Check.MECHANICALLY_CHECKED, Check.SEMANTICALLY_REVIEWED):
        if later in present and Check.LOCATED not in present:
            sink.add(CODE_CHECKS_INCONSISTENT, f"{base}.checks",
                     f"{later.value} без located: проверки идут последовательно")
    for i, rec in enumerate(claim.checks):
        if rec.check is Check.SEMANTICALLY_REVIEWED and (_empty(rec.by) or not rec.reasons):
            sink.add(CODE_REVIEW_AUTHOR_MISSING, f"{base}.checks[{i}]",
                     "смысловая рецензия обязана назвать автора/версию и причины: "
                     "это не независимая гарантия")
    if Check.MECHANICALLY_CHECKED in present:
        _number_check(claim, sink, base)
    if Check.TESTED in present:
        if claim.type is not ClaimType.PROCEDURE:
            sink.add(CODE_TESTED_NOT_PROCEDURE, f"{base}.checks",
                     "tested - только для приема с квитанцией испытания, не метка факта")
        else:
            _tested_receipt(claim, sink, base)


def _number_check(claim: Claim, sink: _Sink, base: str) -> None:
    frags = [e.fragment for e in claim.evidence
             if e.role is EvidenceRole.SUPPORT and e.fragment]
    wanted = _numbers(claim.object)
    if frags and wanted:
        have: set[str] = set()
        for f in frags:
            have |= _numbers(f)
        absent = sorted(wanted - have)
        if absent:
            sink.add(CODE_NUMBER_NOT_IN_FRAGMENT, f"{base}.object",
                     "числа утверждения не найдены в приложенном фрагменте: " + ", ".join(absent),
                     numbers=absent)


def _tested_receipt(claim: Claim, sink: _Sink, base: str) -> None:
    proc = claim.procedure
    receipt = proc.test_receipt if proc else None
    refs = {c.receipt_ref for c in claim.checks if c.check is Check.TESTED}
    ok = (receipt is not None and receipt.kind in ("retest", "fixture")
          and receipt.outcome == "passed" and not _empty(receipt.environment_version)
          and proc is not None and receipt.environment_version == proc.environment_version
          and refs == {receipt.receipt_id})
    if not ok:
        sink.add(CODE_TESTED_RECEIPT_INVALID, f"{base}.checks",
                 "tested требует квитанции испытания: повторное испытание или fixture, "
                 "результат passed, та же версия среды, ссылка receipt_ref")


def _state_checks(claim: Claim, sink: _Sink, base: str) -> None:
    state = claim.review_state
    support = [e for e in claim.evidence if e.role is EvidenceRole.SUPPORT]
    if claim.type is not ClaimType.HYPOTHESIS:
        for i, e in enumerate(claim.evidence):
            if e.role is EvidenceRole.SUPPORT and e.coverage is Coverage.SUMMARY_ONLY:
                sink.add(CODE_SUMMARY_ONLY_AS_FACT, f"{base}.evidence[{i}]",
                         "summary_only: это не стенограмма и не проверенный факт, "
                         "основание годится только гипотезе")
    if state in _RELEVANT or Check.MECHANICALLY_CHECKED in {c.check for c in claim.checks}:
        for i, e in enumerate(claim.evidence):
            if e.ocr_ambiguous and not e.ocr_verified and e in support:
                sink.add(CODE_OCR_AMBIGUOUS_UNCHECKED, f"{base}.evidence[{i}]",
                         "распознавание неоднозначно и не сверено с оригиналом: числа и даты "
                         "не проверены")
    if state is ReviewState.ACCEPTED:
        fp = _fp(claim)
        accepts = [d for d in claim.decisions
                   if d.actor is Actor.OWNER and d.decision is Decision.ACCEPT]
        if not accepts:
            sink.add(CODE_DECISION_RECORD_MISSING, f"{base}.decisions",
                     "принято, но записи решения владельца нет")
        elif not any(p.claim_id == claim.claim_id and p.fingerprint == fp
                     for d in accepts for p in d.pins):
            sink.add(CODE_CONSENT_NOT_TRANSFERABLE, f"{base}.decisions",
                     "согласие дано на другой текст: после правки нужно новое решение")
        done = {c.check for c in claim.checks}
        if claim.type is ClaimType.PROCEDURE and Check.TESTED not in done:
            sink.add(CODE_PROCEDURE_UNTESTED, f"{base}.review_state",
                     "непроверенный прием остается гипотезой, не принимается как правило")


def validate_claim(claim: Claim, *, path: str = "claim") -> Verdict:
    """Одно утверждение: поля по типу, основания, проверки, состояние. Граф ссылок между
    утверждениями (цикл подтверждения, цепь до оригинала) - :func:`validate_claim_set`."""
    sink = _Sink()
    _claim_checks(claim, sink, path)
    return sink.verdict()


# --------------------------------------------------------------------------- #
# Набор утверждений: цепь происхождения, цикл                                   #
# --------------------------------------------------------------------------- #
def _edges(c: Claim) -> list[str]:
    out = list(c.premises) + list(c.depends_on)
    for e in c.evidence:
        if e.role is EvidenceRole.SUPPORT and e.source_kind in _DERIVED_KINDS:
            out += list(e.derived_from)
    return list(dict.fromkeys(out))


def _direct_terminal(c: Claim) -> bool:
    if c.type is ClaimType.OWNER_DECISION:
        return any(d.actor is Actor.OWNER and d.decision is Decision.ACCEPT for d in c.decisions)
    return any(e.role is EvidenceRole.SUPPORT and e.source_kind in (
        SourceKind.ORIGINAL, SourceKind.OWNER_DECISION, SourceKind.TEST_RECEIPT)
        for e in c.evidence)


def validate_claim_set(
    claims: Iterable[Claim], *, context: Mapping[str, Claim] | None = None,
) -> Verdict:
    """Набор кандидатов + граф ссылок. ``context`` - уже принятые утверждения реестра: участвуют в
    графе (по ним идет цепь), но заново не валидируются.

    Запрещено: цикл подтверждения (посылки/зависимости/основания замыкаются друг на друга); цепь,
    не доходящая до оригинала, решения человека или квитанции испытания; ссылка на несуществующее
    утверждение; вывод на посылке-гипотезе. Каждое утверждение дополнительно проходит
    :func:`validate_claim`."""
    cands = list(claims)
    sink = _Sink()
    universe: dict[str, Claim] = dict(context or {})
    universe.update({c.claim_id: c for c in cands})
    for i, c in enumerate(cands):
        sink.v += list(validate_claim(c, path=f"claims[{i}]").violations)
    in_cycle = _find_cycles(universe, {c.claim_id for c in cands}, sink)
    grounded: dict[str, bool] = {}

    def is_grounded(cid: str, stack: tuple[str, ...] = ()) -> bool:
        if cid in grounded:
            return grounded[cid]
        c = universe.get(cid)
        if c is None or cid in stack:
            return False
        result = _direct_terminal(c)
        if not result:
            deps = [d for d in (list(c.premises) + [
                x for e in c.evidence if e.role is EvidenceRole.SUPPORT
                and e.source_kind in _DERIVED_KINDS for x in e.derived_from])]
            result = bool(deps) and all(is_grounded(d, (*stack, cid)) for d in deps)
        grounded[cid] = result
        return result

    for i, c in enumerate(cands):
        base = f"claims[{i}]"
        refs = list(c.premises) + list(c.depends_on) + list(c.supersedes) + list(c.contradicts) \
            + ([c.duplicate_of] if c.duplicate_of else []) \
            + [x for e in c.evidence for x in e.derived_from]
        unknown = [r for r in dict.fromkeys(refs) if r not in universe]
        for r in unknown:
            sink.add(CODE_REFERENCE_MISSING, base, f"ссылка на несуществующее утверждение {r}",
                     claim_id=r)
        dup = universe.get(c.duplicate_of or "")
        if dup is not None and slot_diff(c, dup):
            sink.add(CODE_SLOT_MISMATCH, f"{base}.duplicate_of",
                     "дубль возможен только в том же слоте (единица, масштаб, основание, условия, "
                     "период): разные периоды и основания не сливаются молча",
                     dimensions=list(slot_diff(c, dup)))
        for p in c.premises:
            pc = universe.get(p)
            if pc is not None and pc.type is ClaimType.HYPOTHESIS:
                sink.add(CODE_HYPOTHESIS_AS_FACT, f"{base}.premises",
                         f"посылка {p} - гипотеза: вывод на гипотезе не становится выводом")
        needs_chain = c.type is ClaimType.INFERENCE or any(
            e.role is EvidenceRole.SUPPORT and e.source_kind in _DERIVED_KINDS and e.derived_from
            for e in c.evidence)
        if (needs_chain and not unknown and c.claim_id not in in_cycle
                and not is_grounded(c.claim_id)
                and not any(v.code == CODE_HYPOTHESIS_AS_FACT and v.path.startswith(base)
                            for v in sink.v)):
            sink.add(CODE_CHAIN_NO_TERMINAL, base,
                     "цепь происхождения не доходит до оригинала, решения человека или "
                     "квитанции испытания")
    return sink.verdict()


def _find_cycles(universe: Mapping[str, Claim], cands: set[str], sink: _Sink) -> set[str]:
    """DFS по ребрам «опирается на»; ``confirmation_cycle`` на каждый найденный цикл с
    кандидатом. Возвращает множество claim_id, лежащих на циклах."""
    color: dict[str, int] = {}
    cyc: set[str] = set()
    reported: set[frozenset[str]] = set()

    def visit(node: str, path: list[str]) -> None:
        color[node] = 1
        path.append(node)
        for nxt in _edges(universe[node]):
            if nxt not in universe:
                continue
            if color.get(nxt, 0) == 0:
                visit(nxt, path)
            elif color[nxt] == 1:
                loop = path[path.index(nxt):]
                cyc.update(loop)
                key = frozenset(loop)
                if key not in reported and (key & cands):
                    reported.add(key)
                    sink.add(CODE_CONFIRMATION_CYCLE, f"claims.{loop[0]}",
                             "циклическое подтверждение: цепь замкнулась на себя: "
                             + " -> ".join([*loop, nxt]), cycle=loop)
        path.pop()
        color[node] = 2

    for cid in sorted(universe):
        if color.get(cid, 0) == 0:
            visit(cid, [])
    return cyc


# --------------------------------------------------------------------------- #
# Идентичность и ревизии                                                        #
# --------------------------------------------------------------------------- #
def validate_revision(prev: Claim, new: Claim) -> Verdict:
    """Новая ревизия того же ``claim_id`` против предыдущей.

    Перефразирование того же знания - ревизия (слот тот же, отпечаток другой, revision+1);
    повтор того же содержимого - не ревизия (идемпотентность по отпечатку); другой слот под тем же
    ``claim_id`` - это другое знание, ``claim_id`` занят."""
    if prev.claim_id != new.claim_id:
        raise ValueError("validate_revision: разные claim_id")
    sink = _Sink()
    if new.revision != prev.revision + 1:
        sink.add(CODE_REVISION_CONFLICT, "revision",
                 f"ожидалась ревизия {prev.revision + 1}, пришла {new.revision}")
    differ = slot_diff(prev, new)
    if differ:
        sink.add(CODE_CLAIM_ID_REUSE, "slot",
                 "под тем же claim_id другое знание (слот изменился): "
                 "новое знание получает новый claim_id", dimensions=list(differ))
    if _fp(prev) == _fp(new) and new.revision != prev.revision:
        sink.add(CODE_REVISION_WITHOUT_CHANGE, "revision",
                 "содержимое не изменилось: повтор идемпотентен, новой ревизии нет")
    return sink.verdict()


# --------------------------------------------------------------------------- #
# Переходы рассмотрения                                                         #
# --------------------------------------------------------------------------- #
_S = ReviewState
_TRANSITIONS: dict[ReviewState, frozenset[ReviewState]] = {
    _S.DRAFT: frozenset({_S.READY, _S.SUPERSEDED}),
    _S.READY: frozenset({_S.DRAFT, _S.PENDING, _S.STALE, _S.SUPERSEDED}),
    _S.PENDING: frozenset({_S.ACCEPTED, _S.REJECTED, _S.SNOOZED, _S.STALE, _S.SUPERSEDED}),
    _S.SNOOZED: frozenset({_S.PENDING, _S.REJECTED, _S.STALE, _S.SUPERSEDED}),
    _S.STALE: frozenset({_S.DRAFT, _S.READY, _S.SUPERSEDED}),
    _S.ACCEPTED: frozenset({_S.STALE, _S.SUPERSEDED}),
    _S.REJECTED: frozenset(),
    _S.SUPERSEDED: frozenset(),
}


def check_transition(
    old: ReviewState, new: ReviewState, *, actor: Actor,
    old_type: ClaimType | None = None, new_type: ClaimType | None = None,
) -> Verdict:
    """Допустимость перехода рассмотрения. Принять/отклонить/отложить может только владелец;
    принятие гипотезы не делает ее фактом (тип при принятии не меняется)."""
    sink = _Sink()
    if old is not new and new not in _TRANSITIONS[old]:
        sink.add(CODE_TRANSITION_FORBIDDEN, "review_state",
                 f"переход {old.value} -> {new.value} не предусмотрен",
                 allowed=sorted(s.value for s in _TRANSITIONS[old]))
    elif old is not new and new in _OWNER_ONLY and actor is not Actor.OWNER:
        sink.add(CODE_DECISION_BY_NON_OWNER, "review_state",
                 f"{new.value} - решение владельца; {actor.value} его принять не может")
    if (old_type is ClaimType.HYPOTHESIS and new_type is not None
            and new_type is not ClaimType.HYPOTHESIS):
        sink.add(CODE_HYPOTHESIS_AS_FACT, "type",
                 "принятие гипотезы не превращает ее в факт: тип меняется только новой "
                 "ревизией с основанием")
    return sink.verdict()


# --------------------------------------------------------------------------- #
# Связи                                                                         #
# --------------------------------------------------------------------------- #
_CLAIM_ONLY = (LinkType.SUPERSEDES, LinkType.DEPENDS_ON, LinkType.CONTRADICTS,
               LinkType.DUPLICATE_OF, LinkType.DERIVED_FROM)
_NEEDS_SUPPORT = (LinkType.CAUSES, LinkType.PART_OF, LinkType.BELONGS_TO)
_REF_RE = re.compile(r"^(claim|entity):\S+$")


def validate_link(
    link: Link, exists: Callable[[str], bool] | None = None, *, path: str = "link",
) -> Verdict:
    """Связь: разрешенный тип и направление, существующие концы, доказательство.

    ``exists(ref)`` - проверка существования конца (``claim:<id>``/``entity:<id>``); без нее
    существование не проверено, и вердикт честно несет предупреждение ``store_unavailable``.
    Совместное упоминание (контекстное основание) дает ``co_mention`` (навигация), но не
    причинность/принадлежность."""
    sink = _Sink()
    for name in ("link_id", "source", "target"):
        if _empty(getattr(link, name)):
            sink.add(CODE_REQUIRED_FIELD_MISSING, f"{path}.{name}", f"поле {name} пусто",
                     field=name)
    for end in ("source", "target"):
        ref = getattr(link, end)
        if ref and not _REF_RE.match(ref):
            sink.add(CODE_LINK_ENDPOINT_INVALID, f"{path}.{end}",
                     "конец связи - ссылка claim:<id> или entity:<id>")
        elif ref and link.type in _CLAIM_ONLY and not ref.startswith("claim:"):
            sink.add(CODE_LINK_ENDPOINT_INVALID, f"{path}.{end}",
                     f"связь {link.type.value} соединяет утверждения")
    if link.source and link.source == link.target:
        sink.add(CODE_LINK_SELF_REFERENCE, path, "связь соединяет объект с самим собой")
    if exists is None:
        sink.warn(CODE_STORE_UNAVAILABLE, "существование концов связи не проверено: нет реестра",
                  link_id=link.link_id)
    else:
        for end in ("source", "target"):
            ref = getattr(link, end)
            if ref and _REF_RE.match(ref) and not exists(ref):
                sink.add(CODE_LINK_ENDPOINT_MISSING, f"{path}.{end}",
                         f"конец связи {ref} не существует", ref=ref)
    if not link.evidence:
        sink.add(CODE_LINK_EVIDENCE_MISSING, f"{path}.evidence", "у связи нет доказательства")
    elif (link.type in _NEEDS_SUPPORT
          and not any(e.role is EvidenceRole.SUPPORT for e in link.evidence)):
        sink.add(CODE_LINK_COOCCURRENCE_ONLY, f"{path}.evidence",
                 "совместное упоминание - навигационная близость, не причинность/принадлежность")
    if link.type is LinkType.ALIAS_OF and _empty(link.acceptance_ref):
        sink.add(CODE_ALIAS_NEEDS_ACCEPTANCE, f"{path}.acceptance_ref",
                 "alias сущности проходит существующее принятие алиасов")
    for i, e in enumerate(link.evidence):
        _evidence_checks(e, f"{path}.evidence[{i}]", sink)
    return sink.verdict()


def validate_links(
    links: Iterable[Link], exists: Callable[[str], bool] | None = None,
) -> Verdict:
    """Набор связей: каждая по :func:`validate_link` + цикл замещения/зависимости."""
    ls = list(links)
    sink = _Sink()
    for i, link in enumerate(ls):
        v = validate_link(link, exists, path=f"links[{i}]")
        sink.v += list(v.violations)
        sink.w += list(v.warnings)
    for kind in (LinkType.SUPERSEDES, LinkType.DEPENDS_ON):
        graph: dict[str, list[str]] = {}
        for link in ls:
            if link.type is kind:
                graph.setdefault(link.source, []).append(link.target)
        state: dict[str, int] = {}

        def dfs(n: str, graph: dict[str, list[str]] = graph,
                state: dict[str, int] = state, kind: LinkType = kind) -> bool:
            state[n] = 1
            for m in graph.get(n, []):
                if state.get(m, 0) == 1 or (state.get(m, 0) == 0 and dfs(m)):
                    return True
            state[n] = 2
            return False

        if any(state.get(n, 0) == 0 and dfs(n) for n in list(graph)):
            sink.add(CODE_LINK_CYCLE, f"links.{kind.value}",
                     f"связи {kind.value} образуют цикл")
    return sink.verdict()


# --------------------------------------------------------------------------- #
# Предложение                                                                   #
# --------------------------------------------------------------------------- #
def _claim_refs(p: Proposal) -> set[str]:
    return {t.ref.removeprefix("claim:") for t in p.targets if t.kind == "claim"}


def _all_evidence(p: Proposal) -> list[Evidence]:
    out: list[Evidence] = []
    for c in p.after.claims:
        out += list(c.evidence)
    for link in p.after.links:
        out += list(link.evidence)
    return out


def validate_proposal(
    proposal: Proposal, ledger: Ledger | None = None, policy: Policy | None = None,
) -> Verdict:
    """Предложение целиком: конверт §5.3, операция и ее цели, утверждения «стало», рассмотрение,
    применение, подавление повтора. ``ledger=None`` - проверки против реестра не выполняются, и
    вердикт несет предупреждение ``store_unavailable`` (а не молчаливое «все хорошо»)."""
    policy = policy or Policy()
    p = proposal
    sink = _Sink()
    if p.schema_version > SCHEMA_VERSION:
        sink.add(CODE_SCHEMA_VERSION_UNSUPPORTED, "schema_version", "версия новее известной")
    _envelope(p, sink)
    after_ids = [c.claim_id for c in p.after.claims]

    v = validate_claim_set(p.after.claims, context=ledger.claims if ledger else None)
    sink.v += [Violation(x.code, "after." + x.path, x.reason, x.detail) for x in v.violations]
    if p.after.links:
        lv = validate_links(p.after.links, _exists_fn(p, ledger))
        sink.v += [Violation(x.code, "after." + x.path, x.reason, x.detail) for x in lv.violations]
        sink.w += list(lv.warnings)
    for t in p.targets:
        if any_nda(t.ref):
            sink.add(CODE_TARGET_NDA, f"targets.{t.ref}", "цель операции под _nda: отказ")

    handler = _OPERATIONS[p.operation]
    handler(p, ledger, policy, sink)

    expected_ids = set(after_ids) | _claim_refs(p)
    if p.operation in (Operation.ADD, Operation.AMEND, Operation.SUPERSEDE,
                       Operation.PROMOTE_CONTEXT, Operation.DEMOTE_CONTEXT) \
            and set(p.claim_ids) != expected_ids:
        sink.add(CODE_CLAIM_IDS_MISMATCH, "claim_ids",
                 "claim_ids не совпадает с утверждениями «стало» и целями-утверждениями",
                 expected=sorted(expected_ids), got=sorted(p.claim_ids))
    ev = _all_evidence(p)
    if ev or p.evidence_digest:
        if p.evidence_digest != evidence_digest(ev):
            sink.add(CODE_EVIDENCE_DIGEST_MISMATCH, "evidence_digest",
                     "evidence_digest не соответствует основаниям утверждений и связей")
    _grouping(p, sink)
    _lifecycle(p, sink)
    if ledger is None:
        sink.warn(CODE_STORE_UNAVAILABLE,
                  "реестр не передан: ожидаемые ревизии, источники, прошлые решения и "
                  "существование целей не проверены", proposal_id=p.proposal_id)
    else:
        _against_ledger(p, ledger, sink)
    return sink.verdict()


def _exists_fn(p: Proposal, ledger: Ledger | None) -> Callable[[str], bool] | None:
    if ledger is None:
        return None
    new_claims = {f"claim:{c.claim_id}" for c in p.after.claims}

    def exists(ref: str) -> bool:
        if ref in new_claims or ref in ledger.entities:
            return True
        return ref.startswith("claim:") and ref.removeprefix("claim:") in ledger.claims

    return exists


def _envelope(p: Proposal, sink: _Sink) -> None:
    for name in ("proposal_id", "idempotency_key", "why_now", "intended_use", "run_id"):
        if _empty(getattr(p, name)):
            sink.add(CODE_REQUIRED_FIELD_MISSING, name, f"обязательное поле {name} пусто",
                     field=name)
    if p.revision < 1:
        sink.add(CODE_REVISION_INVALID, "revision", "ревизия предложения - целое >= 1")
    if not p.targets:
        sink.add(CODE_OPERATION_TARGET_MISSING, "targets", "у операции нет цели")


# --- операции ------------------------------------------------------------------------------- #
def _need_expected(p: Proposal, sink: _Sink, ref: str, revision: int | None) -> None:
    got = next((e for e in p.expected_revisions if e.ref == ref), None)
    if got is None:
        sink.add(CODE_EXPECTED_REVISION_MISSING, "expected_revisions",
                 f"нет ожидаемой ревизии цели {ref}: без нее CAS при применении невозможен",
                 ref=ref)
    elif revision is not None and got.revision != revision:
        sink.add(CODE_EXPECTED_REVISION_STALE, "expected_revisions",
                 f"ожидаемая ревизия {ref} - {got.revision}, а предложение строилось на "
                 f"{revision}", ref=ref)


def _op_add(p: Proposal, ledger: Ledger | None, policy: Policy, sink: _Sink) -> None:
    if not p.after.claims:
        sink.add(CODE_AFTER_MISSING, "after", "add без утверждений «стало»")
    if p.before.claims:
        sink.add(CODE_OPERATION_MISMATCH, "before", "add не имеет состояния «было»")
    for c in p.after.claims:
        _need_expected(p, sink, f"claim:{c.claim_id}", 0)
        prior = ledger.claims.get(c.claim_id) if ledger else None
        if prior is not None:
            if _fp(prior) == _fp(c):
                sink.warn("idempotent_noop", "то же содержимое уже в реестре: повтор идемпотентен",
                          claim_id=c.claim_id)
            else:
                sink.add(CODE_CLAIM_ID_REUSE, f"after.{c.claim_id}",
                         "claim_id уже занят другим содержимым: изменение - amend, "
                         "новое знание - новый claim_id")


def _op_amend(p: Proposal, ledger: Ledger | None, policy: Policy, sink: _Sink) -> None:
    if not p.before.claims:
        sink.add(CODE_BEFORE_MISSING, "before", "amend без утверждений «было»")
    if not p.after.claims:
        sink.add(CODE_AFTER_MISSING, "after", "amend без утверждений «стало»")
    old = {c.claim_id: c for c in p.before.claims}
    for c in p.after.claims:
        prev = old.get(c.claim_id)
        if prev is None:
            sink.add(CODE_BEFORE_MISSING, f"before.{c.claim_id}", "нет ревизии «было» для amend")
            continue
        sink.v += [Violation(x.code, f"after.{c.claim_id}.{x.path}", x.reason, x.detail)
                   for x in validate_revision(prev, c).violations]
        _need_expected(p, sink, f"claim:{c.claim_id}", prev.revision)
        if _basis_is_absence([c]):
            sink.add(CODE_ABSENCE_NOT_BASIS, f"after.{c.claim_id}",
                     "отсутствие сведений не основание для изменения знания")


def _basis_is_absence(claims: list[Claim]) -> bool:
    return bool(claims) and all(c.negative for c in claims)


def _op_supersede(p: Proposal, ledger: Ledger | None, policy: Policy, sink: _Sink) -> None:
    if not p.after.claims:
        sink.add(CODE_AFTER_MISSING, "after", "supersede без нового утверждения")
        return
    olds = _claim_refs(p)
    old_claims: dict[str, Claim] = {c.claim_id: c for c in p.before.claims}
    if ledger:
        for oid in olds:
            if oid in ledger.claims:
                old_claims.setdefault(oid, ledger.claims[oid])
    for new in p.after.claims:
        for oid in olds:
            _need_expected(p, sink, f"claim:{oid}", None)
            if oid not in new.supersedes:
                sink.add(CODE_SUPERSEDE_LINK_MISSING, f"after.{new.claim_id}.supersedes",
                         f"новое утверждение не объявляет, что заменяет {oid}")
            prev = old_claims.get(oid)
            if prev is None:
                continue
            differ = slot_diff(prev, new, ignore=("period",))
            if differ:
                sink.add(CODE_SLOT_MISMATCH, f"after.{new.claim_id}",
                         "замена возможна только внутри одного слота (единица, масштаб, основание, "
                         "условия, область): " + ", ".join(differ), dimensions=list(differ))
            if prev.type is ClaimType.OWNER_DECISION:
                if not _is_owner_basis(new):
                    sink.add(CODE_OWNER_DECISION_OVERRIDDEN, f"after.{new.claim_id}",
                             "решение владельца заменяет только решение владельца, не вывод и "
                             "не отрицательный поиск модели")
            elif not differ and not new.negative:
                _supersede_by_classification(new, prev, sink)
    if _basis_is_absence(list(p.after.claims)):
        sink.add(CODE_ABSENCE_NOT_BASIS, "after",
                 "отсутствие сведений не основание для замены знания")


def _supersede_by_classification(new: Claim, prev: Claim, sink: _Sink) -> None:
    """Замена допустима только как временное обновление в сторону нового (или уточнение):
    противоречие двух оснований, непроверенное и обратное по времени - не замена."""
    cmp = classify(new, [prev])
    path = f"after.{new.claim_id}"
    if cmp.result is CompareResult.DIFFERENT_BASIS:
        sink.add(CODE_SLOT_MISMATCH, path,
                 "периоды не пересекаются: это разные периоды, а не замена",
                 dimensions=list(cmp.dimensions))
    elif cmp.result is CompareResult.CONTRADICTION:
        sink.add(CODE_CONTRADICTION_NEEDS_BOTH, path,
                 "два основания расходятся и по дате верности не упорядочены: замена выбирала "
                 "бы истину за владельца; противоречие оформляется связью contradicts с обеими "
                 "версиями", reasons=list(cmp.reasons))
    elif cmp.result is CompareResult.NEEDS_CHECK:
        sink.add(CODE_SUPERSEDE_UNVERIFIED, path,
                 "замена требует проверки: " + ", ".join(cmp.reasons), reasons=list(cmp.reasons))
    elif cmp.result is CompareResult.TEMPORAL_UPDATE and cmp.newer == "existing":
        sink.add(CODE_SUPERSEDE_REVERSED, path,
                 "по дате верности заменяемое утверждение новее заменяющего")


def _is_owner_basis(c: Claim) -> bool:
    return c.type is ClaimType.OWNER_DECISION or any(
        e.source_kind is SourceKind.OWNER_DECISION and e.role is EvidenceRole.SUPPORT
        for e in c.evidence)


def _op_relate(p: Proposal, ledger: Ledger | None, policy: Policy, sink: _Sink) -> None:
    if not p.after.links:
        sink.add(CODE_AFTER_MISSING, "after", "relate без связей")
    known: dict[str, Claim] = dict(ledger.claims) if ledger else {}
    known.update({c.claim_id: c for c in p.after.claims})
    for i, link in enumerate(p.after.links):
        if link.type is not LinkType.DUPLICATE_OF:
            continue
        a = known.get(link.source.removeprefix("claim:"))
        b = known.get(link.target.removeprefix("claim:"))
        if a is not None and b is not None and slot_diff(a, b):
            sink.add(CODE_SLOT_MISMATCH, f"after.links[{i}]",
                     "дубль возможен только в том же слоте: разные единицы, основания и периоды "
                     "не сливаются", dimensions=list(slot_diff(a, b)))


def _op_merge(p: Proposal, ledger: Ledger | None, policy: Policy, sink: _Sink) -> None:
    reps = [t for t in p.targets if t.kind == "representation"]
    if len(reps) < 2:
        sink.add(CODE_OPERATION_TARGET_MISSING, "targets",
                 "merge_representation требует не менее двух представлений")
    if len(reps) > 1 and not policy.allow_multi_note:
        sink.add(CODE_MULTI_NOTE_FORBIDDEN, "targets",
                 "MVP: одна заметка на атомарное предложение; слияние нескольких файлов "
                 "запрещено до отдельной приемки")
    if not p.before.note or not p.after.note:
        sink.add(CODE_BEFORE_MISSING if not p.before.note else CODE_AFTER_MISSING, "before/after",
                 "слияние без описания «было/стало»")
    redirected = {r.from_ref for r in p.redirects}
    for t in reps[1:]:
        if t.ref not in redirected:
            sink.add(CODE_REDIRECT_MISSING, f"redirects.{t.ref}",
                     "слияние/перенос сохраняет старый ID: нужно перенаправление")


def _op_repair(p: Proposal, ledger: Ledger | None, policy: Policy, sink: _Sink) -> None:
    if not p.before.note:
        sink.add(CODE_BEFORE_MISSING, "before", "repair_reference без описания «было»")
    if not p.after.note:
        sink.add(CODE_AFTER_MISSING, "after", "repair_reference без описания «стало»")


def _resolve_claims(p: Proposal, ledger: Ledger | None) -> list[tuple[str, Claim | None]]:
    mine = {c.claim_id: c for c in p.after.claims}
    out = []
    for cid in sorted(_claim_refs(p) | set(mine)):
        out.append((cid, mine.get(cid) or (ledger.claims.get(cid) if ledger else None)))
    return out


def _op_promote(p: Proposal, ledger: Ledger | None, policy: Policy, sink: _Sink) -> None:
    spec = p.promotion
    if spec is None or any(_empty(x) for x in (spec.application, spec.verification,
                                               spec.expiry_condition)) \
            or spec.context_cost_tokens <= 0:
        sink.add(CODE_PROMOTION_SPEC_MISSING, "promotion",
                 "постоянное повышение в контекст требует: применение, цену контекста, "
                 "проверку, срок/условие снятия")
    for cid, c in _resolve_claims(p, ledger):
        if c is None:
            continue
        if c.review_state is not ReviewState.ACCEPTED:
            sink.add(CODE_PROMOTE_NOT_ACCEPTED, f"targets.{cid}",
                     "в контекст повышается только принятое владельцем")
        if c.type is ClaimType.HYPOTHESIS and p.context_mode != "research":
            sink.add(CODE_HYPOTHESIS_PROMOTED, f"targets.{cid}",
                     "гипотеза не входит в обычный контекст как факт; исследовательский режим "
                     "включается явно")
        if c.type is ClaimType.PROCEDURE and Check.TESTED not in {x.check for x in c.checks}:
            sink.add(CODE_PROCEDURE_UNTESTED, f"targets.{cid}",
                     "непроверенный прием - гипотеза, постоянным правилом не становится")


def _op_demote(p: Proposal, ledger: Ledger | None, policy: Policy, sink: _Sink) -> None:
    if not _claim_refs(p):
        sink.add(CODE_OPERATION_TARGET_MISSING, "targets", "demote_context без утверждения-цели")


_OPERATIONS: dict[Operation, Callable[[Proposal, Ledger | None, Policy, _Sink], None]] = {
    Operation.ADD: _op_add,
    Operation.AMEND: _op_amend,
    Operation.SUPERSEDE: _op_supersede,
    Operation.RELATE: _op_relate,
    Operation.MERGE_REPRESENTATION: _op_merge,
    Operation.REPAIR_REFERENCE: _op_repair,
    Operation.PROMOTE_CONTEXT: _op_promote,
    Operation.DEMOTE_CONTEXT: _op_demote,
}


# --- группа ---------------------------------------------------------------------------------- #
def _connected(claims: tuple[Claim, ...]) -> bool:
    if len(claims) < 2:
        return True
    ids = [c.claim_id for c in claims]
    parent = {i: i for i in ids}

    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: str, b: str) -> None:
        parent[find(a)] = find(b)

    for a in claims:
        for b in claims:
            if a.claim_id >= b.claim_id:
                continue
            origins_a = {e.origin for e in a.evidence if e.role is EvidenceRole.SUPPORT}
            origins_b = {e.origin for e in b.evidence if e.role is EvidenceRole.SUPPORT}
            linked = (b.claim_id in _edges(a) or a.claim_id in _edges(b)
                      or bool(origins_a & origins_b)
                      or (norm_text(a.subject), norm_text(a.area))
                      == (norm_text(b.subject), norm_text(b.area)))
            if linked:
                union(a.claim_id, b.claim_id)
    return len({find(i) for i in ids}) == 1


def _grouping(p: Proposal, sink: _Sink) -> None:
    claims = p.after.claims
    if len(claims) < 2:
        return
    g = p.group
    ids = {c.claim_id for c in claims}
    if g is None or _empty(g.reason) or _empty(g.atomic_unit) or set(g.members) != ids:
        sink.add(CODE_GROUP_UNEXPLAINED, "group",
                 "несколько утверждений в одной карточке требуют группы: одна причина, явный "
                 "состав и атомарная единица применения (не «принять все»)")
    elif not _connected(claims):
        sink.add(CODE_GROUP_INDEPENDENT_CLAIMS, "group",
                 "независимые выводы не прячутся в одну карточку: нет общего основания, "
                 "зависимости или темы")


# --- рассмотрение и применение ------------------------------------------------------------- #
def _lifecycle(p: Proposal, sink: _Sink) -> None:
    state = p.review_state
    if p.blockers and state in _RELEVANT:
        sink.add(CODE_BLOCKERS_OPEN, "blockers",
                 "есть блокеры: предложение не идет владельцу и в применение",
                 blockers=[b.code for b in p.blockers])
    if state in _RELEVANT:
        steps = [c.step for c in p.checks if c.ok]
        order = list(PipelineStep)
        if set(steps) != set(order):
            sink.add(CODE_CHECKS_INCOMPLETE, "checks",
                     "не все шаги проверки пройдены: " + ", ".join(
                         s.value for s in order if s not in set(steps)))
        elif [c.step for c in p.checks] != order:
            sink.add(CODE_CHECKS_OUT_OF_ORDER, "checks",
                     "проверки идут последовательно: политика -> версия/locator -> фрагмент -> "
                     "числа/единицы -> дубли/отказы -> смысловая рецензия -> diff/план")
    if state in _OWNER_ONLY:
        _receipt(p, sink)
    if p.apply_state is not ApplyState.NONE and state is not ReviewState.ACCEPTED:
        sink.add(CODE_APPLY_WITHOUT_ACCEPTANCE, "apply_state",
                 "применение без принятия владельцем")


def _receipt(p: Proposal, sink: _Sink) -> None:
    r: DecisionRecord | None = p.decision_receipt
    want = {ReviewState.ACCEPTED: Decision.ACCEPT, ReviewState.REJECTED: Decision.REJECT,
            ReviewState.SNOOZED: Decision.SNOOZE}[p.review_state]
    if r is None or r.decision is not want:
        sink.add(CODE_DECISION_RECORD_MISSING, "decision_receipt",
                 f"состояние {p.review_state.value} без квитанции решения {want.value}")
        return
    if r.actor is not Actor.OWNER:
        sink.add(CODE_DECISION_BY_NON_OWNER, "decision_receipt", "решение принимает владелец")
    if p.review_state is ReviewState.ACCEPTED:
        pins = {x.claim_id: x.fingerprint for x in r.pins}
        stale = [c.claim_id for c in p.after.claims if pins.get(c.claim_id) != _fp(c)]
        if (stale or r.proposal_id != p.proposal_id or r.proposal_revision != p.revision
                or r.evidence_digest != p.evidence_digest):
            sink.add(CODE_CONSENT_NOT_TRANSFERABLE, "decision_receipt",
                     "согласие дано на другую редакцию предложения/текста/оснований: после "
                     "правки нужно новое решение", claims=stale)


def _same_scope(a: Proposal, b: Proposal) -> bool:
    return a.operation is b.operation and {t.ref for t in a.targets} == {t.ref for t in b.targets}


def _against_ledger(p: Proposal, ledger: Ledger, sink: _Sink) -> None:
    for e in p.expected_revisions:
        if not e.ref.startswith("claim:") or e.revision <= 0:
            continue
        cur = ledger.claims.get(e.ref.removeprefix("claim:"))
        if cur is None:
            sink.add(CODE_OPERATION_TARGET_MISSING, f"expected_revisions.{e.ref}",
                     "цель не найдена в реестре", ref=e.ref)
        elif cur.revision != e.revision:
            sink.add(CODE_EXPECTED_REVISION_STALE, f"expected_revisions.{e.ref}",
                     f"цель изменилась: ожидалась ревизия {e.revision}, в реестре "
                     f"{cur.revision}; нужен новый diff и новое решение", ref=e.ref)
    for ev in _all_evidence(p):
        cur_hash = ledger.sources.get(ev.source_id)
        if cur_hash and ev.content_hash and cur_hash != ev.content_hash:
            sink.add(CODE_SOURCE_CHANGED, f"evidence.{ev.source_id}",
                     "источник изменился после предложения: согласие не переносится",
                     source_id=ev.source_id)
    for prior in ledger.decided:
        if prior.proposal_id == p.proposal_id:
            continue
        if prior.idempotency_key == p.idempotency_key and (
                prior.evidence_digest != p.evidence_digest or prior.claim_ids != p.claim_ids):
            sink.add(CODE_IDEMPOTENCY_CONFLICT, "idempotency_key",
                     "тот же idempotency_key с другим содержимым")
        if not _same_scope(prior, p):
            continue
        same_basis = prior.evidence_digest == p.evidence_digest
        if prior.review_state is ReviewState.REJECTED:
            if same_basis:
                sink.add(CODE_REJECTED_REPEAT, "evidence_digest",
                         "это основание уже отклонено владельцем: повтор подавлен",
                         prior=prior.proposal_id)
            elif p.reopens != prior.proposal_id or _empty(p.new_basis):
                sink.add(CODE_NEW_BASIS_UNEXPLAINED, "new_basis",
                         "после отказа новое предложение - связанная ревизия с объяснением "
                         "существенно нового основания", prior=prior.proposal_id)
        elif prior.review_state is ReviewState.SNOOZED and same_basis:
            until = prior.decision_receipt.snooze_until if prior.decision_receipt else ""
            if not (ledger.now and until and ledger.now >= until):
                sink.add(CODE_SNOOZED_REPEAT, "evidence_digest",
                         "предложение отложено владельцем: повтор до срока подавлен",
                         prior=prior.proposal_id)
