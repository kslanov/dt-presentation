"""SLEEP-EVAL-1 п.1 - формат контрольного набора сна и загрузчик (sleep-1.md §11).

Файл ``vault/_system/eval/sleep-control.yaml`` - данные К. (правятся как заметка; прецедент -
``golden-generation.yaml``): движок его только ЧИТАЕТ, никогда не пишет. Русские ключи и их
английские синонимы - один смысл. Схема версионирована (``версия_схемы``, сейчас 1): файл новой
версии отказывается целиком, молча терять поля новой схемы нельзя.

Случай = вопрос + разрешенная область корпуса + ожидаемые утверждения (источник и локатор) +
критические условия + признаки + часть::

    версия_схемы: 1
    метка: pilot-1
    случаи:
      - id: c001
        часть: контроль               # разработка | контроль
        вопрос: "Какой срок и сумма по договору поставки клиента Организация-1?"
        область: ["04-clients/client-demo/**"]       # пути vault, глобы; без ``..`` и абсолютных
        признаки: [несколько_источников, рискованный]   # | один_документ
        ожидания:
          - утверждение: "Срок поставки - 30 рабочих дней с даты предоплаты."
            источник: 04-clients/client-demo/dogovor.md
            локатор: "п. 4.1"
        критические_условия:
          - {тип: число, значение: "1 200 000", единица: тенге}   # число + единица/валюта/масштаб
          - {тип: дата, значение: "14.11.2026"}
          - {тип: период, с: "01.01.2026", по: "31.12.2026"}
          - {тип: исключение, текст: "без НДС", маркеры: ["без НДС"]}   # смысл - решает человек
        заметка: "..."

Тип критического условия: ``число`` (с единицей), ``дата``, ``период`` проверяются
детерминированно (общая нормализация с фактами и сверкой цитат: :mod:`core.facts.textnorm`);
``исключение`` и ``условие`` - смысловые: ответ ищет маркеры, а итог ставит человек.

Отказы - :class:`SleepControlError`: ``code`` верхнего уровня (``control_unreadable``,
``control_bad_yaml``, ``control_empty``, ``control_schema_missing``, ``control_schema_unsupported``,
``control_invalid``) и ``problems`` - все замечания разом, у каждого свой машинный код
(:data:`PROBLEM_CODES`). Предупреждения (не отказ) - ``ControlSet.warnings``.

Загрузчик отказывает конвейеру сна (:mod:`core.sleep_eval.fence`).
"""

from __future__ import annotations

import hashlib
import json
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from core.eval import GoldenError
from core.facts.textnorm import NumberMention, scan_dates, scan_numbers
from core.globmatch import glob_match
from core.privacy import any_nda
from core.sleep_eval.fence import assert_control_allowed

__all__ = [
    "CONTROL_REL",
    "SCHEMA_VERSION",
    "PILOT_TOTAL",
    "PILOT_MULTI",
    "PILOT_RISKY",
    "PROBLEM_CODES",
    "PART_DEV",
    "PART_CONTROL",
    "FLAG_MULTI",
    "FLAG_RISKY",
    "FLAG_SINGLE",
    "Case",
    "ControlSet",
    "Coverage",
    "Critical",
    "Expectation",
    "Problem",
    "SleepControlError",
    "control_path",
    "coverage",
    "load_control",
    "parse_control",
    "questions_hash",
    "scope_match",
]

CONTROL_REL = Path("_system") / "eval" / "sleep-control.yaml"
SCHEMA_VERSION = 1

# Пилот (sleep-1.md §11): минимум 30 размеченных, из них 10 по нескольким источникам и 10
# рискованных (пересечение допустимо). Инженерный пилот, не доказательство универсального эффекта.
PILOT_TOTAL, PILOT_MULTI, PILOT_RISKY = 30, 10, 10

PART_DEV, PART_CONTROL = "development", "control"
FLAG_MULTI, FLAG_RISKY, FLAG_SINGLE = "multi_source", "risky", "single_doc"
KIND_NUMBER, KIND_DATE, KIND_PERIOD = "number", "date", "period"
KIND_EXCEPTION, KIND_CONDITION = "exception", "condition"
DETERMINISTIC_KINDS = (KIND_NUMBER, KIND_DATE, KIND_PERIOD)
SEMANTIC_KINDS = (KIND_EXCEPTION, KIND_CONDITION)

_TOP_KEYS = {
    "версия_схемы": "schema_version", "schema_version": "schema_version",
    "метка": "label", "label": "label", "случаи": "cases", "cases": "cases",
}
_CASE_KEYS = {
    "id": "id", "часть": "part", "part": "part", "вопрос": "question", "question": "question",
    "область": "scope", "scope": "scope", "признаки": "flags", "flags": "flags",
    "ожидания": "expect", "expect": "expect",
    "критические_условия": "critical", "critical": "critical",
    "заметка": "note", "note": "note",
    "происхождение": "origin", "origin": "origin",   # SLEEP-PULT-1: необязательное поле (схема v1)
}
_ORIGIN_KEYS = {
    "кандидат": "candidate", "candidate": "candidate",
    "черновик_модели": "model_draft", "model_draft": "model_draft",
    "правки_владельца": "owner_edited", "owner_edited": "owner_edited",
    "хост": "host", "host": "host", "дата": "at", "at": "at",
}
_EXPECT_KEYS = {
    "утверждение": "claim", "claim": "claim", "источник": "source", "source": "source",
    "локатор": "locator", "locator": "locator",
}
_CRIT_KEYS = {
    "тип": "kind", "kind": "kind", "значение": "value", "value": "value",
    "единица": "unit", "unit": "unit", "с": "from", "from": "from", "по": "to", "to": "to",
    "текст": "text", "text": "text", "маркеры": "markers", "markers": "markers",
}
_PARTS = {"разработка": PART_DEV, "development": PART_DEV, "dev": PART_DEV,
          "контроль": PART_CONTROL, "control": PART_CONTROL}
_FLAGS = {
    "несколько_источников": FLAG_MULTI, "multi_source": FLAG_MULTI,
    "рискованный": FLAG_RISKY, "risky": FLAG_RISKY,
    "один_документ": FLAG_SINGLE, "single_doc": FLAG_SINGLE,
}
_KINDS = {
    "число": KIND_NUMBER, "number": KIND_NUMBER, "дата": KIND_DATE, "date": KIND_DATE,
    "период": KIND_PERIOD, "period": KIND_PERIOD,
    "исключение": KIND_EXCEPTION, "exception": KIND_EXCEPTION,
    "условие": KIND_CONDITION, "condition": KIND_CONDITION,
}

# Машинные коды замечаний (``Problem.code``) и пояснение - реестр в одном месте (доки, тесты).
PROBLEM_CODES: dict[str, str] = {
    "case_not_mapping": "случай - не словарь",
    "case_unknown_key": "неизвестный ключ случая",
    "case_no_id": "у случая нет id",
    "case_duplicate_id": "дубль id случая",
    "case_no_question": "нет вопроса",
    "case_bad_part": "часть - только разработка | контроль",
    "case_bad_flag": "неизвестный признак",
    "flags_conflict": "один_документ несовместим с несколько_источников",
    "multi_source_needs_two": "несколько_источников: нужны ожидания из двух и более источников",
    "single_doc_many_sources": "один_документ допускает ожидания из одного источника",
    "risky_no_critical": "рискованный случай без критических условий",
    "case_no_scope": "нет разрешенной области корпуса",
    "scope_bad_path": "путь области: абсолютный, с .. или пустой",
    "scope_nda": "область под барьером _nda",
    "case_no_expectations": "нет ожидаемых утверждений",
    "expectation_not_mapping": "ожидание - не словарь",
    "expectation_unknown_key": "неизвестный ключ ожидания",
    "expectation_no_claim": "у ожидания нет утверждения",
    "expectation_no_source": "у ожидания нет источника (контрольный случай без источника)",
    "source_bad_path": "источник: абсолютный путь, .. или пусто",
    "source_nda": "источник под барьером _nda",
    "source_outside_scope": "источник вне разрешенной области случая",
    "critical_not_mapping": "критическое условие - не словарь",
    "critical_unknown_key": "неизвестный ключ критического условия",
    "critical_bad_kind": "тип условия: число | дата | период | исключение | условие",
    "critical_no_value": "у условия нет значения/текста",
    "critical_bad_number": "число условия не разбирается (нужно ровно одно число)",
    "critical_bad_date": "дата условия не разбирается (нужна ровно одна дата)",
    "critical_bad_period": "период: нужны даты с и по, с <= по",
    "case_bad_type": "поле случая неверного типа",
    "origin_bad": "происхождение: словарь с ключами кандидат, черновик_модели, правки_владельца, "
                  "хост, дата",
}
CODE_UNREADABLE = "control_unreadable"
CODE_BAD_YAML = "control_bad_yaml"
CODE_EMPTY = "control_empty"
CODE_SCHEMA_MISSING = "control_schema_missing"
CODE_SCHEMA_UNSUPPORTED = "control_schema_unsupported"
CODE_INVALID = "control_invalid"


@dataclass(frozen=True)
class Problem:
    code: str
    where: str
    message: str

    @classmethod
    def known(cls, code: str, where: str) -> Problem:
        """Замечание с типовым текстом из :data:`PROBLEM_CODES`."""
        return cls(code, where, PROBLEM_CODES[code])

    def __str__(self) -> str:
        return f"{self.where}: [{self.code}] {self.message}"


class SleepControlError(GoldenError):
    """Набор не прочитан/не валиден. ``code`` - верхний машинный код; ``problems`` - замечания."""

    def __init__(self, message: str, code: str = CODE_INVALID,
                 problems: list[Problem] | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.problems: list[Problem] = list(problems or [])


@dataclass(frozen=True)
class Expectation:
    claim: str
    source: str
    locator: str = ""


@dataclass(frozen=True)
class Critical:
    """Критическое условие. Детерминированные (число/дата/период) несут разобранное значение."""

    kind: str
    value: str = ""
    unit: str = ""
    text: str = ""
    markers: tuple[str, ...] = ()
    number: NumberMention | None = None
    date_iso: str = ""
    from_iso: str = ""
    to_iso: str = ""

    @property
    def deterministic(self) -> bool:
        return self.kind in DETERMINISTIC_KINDS

    def label(self) -> str:
        if self.kind == KIND_PERIOD:
            return f"{self.from_iso}..{self.to_iso}"
        if self.kind in SEMANTIC_KINDS:
            return self.text
        return " ".join(x for x in (self.value, self.unit) if x)


@dataclass(frozen=True)
class Case:
    id: str
    part: str
    question: str
    scope: tuple[str, ...]
    flags: frozenset[str]
    expectations: tuple[Expectation, ...]
    critical: tuple[Critical, ...] = ()
    note: str = ""
    #: SLEEP-PULT-1: происхождение случая (кандидат, был ли черновик модели, правил ли владелец);
    #: необязательное, в хэш вопросов и оценку не входит
    origin: dict[str, Any] = field(default_factory=dict, compare=False, hash=False)

    @property
    def multi_source(self) -> bool:
        return FLAG_MULTI in self.flags

    @property
    def risky(self) -> bool:
        return FLAG_RISKY in self.flags

    @property
    def single_doc(self) -> bool:
        return FLAG_SINGLE in self.flags

    @property
    def is_critical(self) -> bool:
        """Критический случай: есть критические условия или он размечен рискованным."""
        return bool(self.critical) or self.risky

    @property
    def sources(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(e.source for e in self.expectations))


@dataclass
class ControlSet:
    schema_version: int
    label: str
    cases: list[Case]
    file_sha256: str = ""
    warnings: list[Problem] = field(default_factory=list)

    def part(self, part: str) -> list[Case]:
        return [c for c in self.cases if c.part == part]

    def case(self, case_id: str) -> Case | None:
        return next((c for c in self.cases if c.id == case_id), None)


@dataclass(frozen=True)
class Coverage:
    """Покрытие пилота: сколько размечено против цели 30 / 10 / 10 (§11)."""

    total: int
    multi: int
    risky: int
    single_doc: int
    development: int
    control: int
    ready: bool
    shortfall: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "total": self.total, "multi_source": self.multi, "risky": self.risky,
            "single_doc": self.single_doc, "development": self.development,
            "control": self.control, "ready": self.ready, "shortfall": list(self.shortfall),
            "target": {"total": PILOT_TOTAL, "multi_source": PILOT_MULTI, "risky": PILOT_RISKY},
        }


# --------------------------------------------------------------------------- #
# Пути и область                                                                #
# --------------------------------------------------------------------------- #
def control_path(vault: Path | None = None) -> Path:
    if vault is None:
        from core.config import default_vault_path

        vault = default_vault_path()
    return Path(vault) / CONTROL_REL


def _nfc(text: str) -> str:
    return unicodedata.normalize("NFC", text)


def _clean_rel(raw: Any) -> str | None:
    """Путь vault: относительный posix, NFC, без ``..``; пусто/абсолютный/обход - ``None``."""
    if not isinstance(raw, str):
        return None
    text = _nfc(raw).strip().replace("\\", "/")
    while text.startswith("./"):
        text = text[2:]
    if not text or text.startswith("/") or (len(text) > 1 and text[1] == ":"):
        return None
    if ".." in text.split("/"):
        return None
    return text


def scope_match(rel_posix: str, patterns: tuple[str, ...] | list[str]) -> bool:
    """Путь vault входит в область: шаблоны якорятся к корню vault, ``dir/`` - вся папка."""
    for raw in patterns:
        pat = _nfc(raw).strip()
        if pat.endswith("/"):
            pat += "**"
        if not pat.startswith(("/", "*")):
            pat = "/" + pat
        if glob_match(rel_posix, pat):
            return True
    return False


def questions_hash(cases: list[Case]) -> str:
    """Хэш ВОПРОСОВ набора (id, часть, вопрос, область, признаки) - без ожиданий и ответов.

    Заморозка хранит его: вопросы поменялись после заморозки - выдача A к ним не относится.
    Ожидаемые утверждения и условия в хэш не входят (правка разметки К. заморозку не сбивает)."""
    payload = [
        {"id": c.id, "part": c.part, "question": " ".join(c.question.split()),
         "scope": sorted(c.scope), "flags": sorted(c.flags)}
        for c in sorted(cases, key=lambda c: c.id)
    ]
    blob = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


# --------------------------------------------------------------------------- #
# Разбор                                                                        #
# --------------------------------------------------------------------------- #
def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, str):
        value = [value]
    if isinstance(value, list) and value and all(isinstance(x, str) and x.strip() for x in value):
        return [x.strip() for x in value]
    return None


def _one_number(text: str) -> NumberMention | None:
    found = scan_numbers(text)
    return found[0] if len(found) == 1 else None


def _one_date(text: str) -> str:
    found = scan_dates(text)
    return found[0].iso if len(found) == 1 else ""


def _norm_critical(raw: Any, where: str, problems: list[Problem]) -> Critical | None:
    if not isinstance(raw, dict):
        problems.append(Problem.known("critical_not_mapping", where))
        return None
    item: dict[str, Any] = {}
    for key, value in raw.items():
        canon = _CRIT_KEYS.get(str(key).strip())
        if canon is None:
            problems.append(Problem("critical_unknown_key", where, f"ключ {key!r}"))
        else:
            item[canon] = value
    kind = _KINDS.get(str(item.get("kind") or "").strip().lower())
    if kind is None:
        problems.append(Problem("critical_bad_kind", where, f"тип {item.get('kind')!r}"))
        return None
    value = str(item["value"]).strip() if item.get("value") is not None else ""
    unit = str(item.get("unit") or "").strip()
    text = " ".join(str(item.get("text") or "").split())
    if kind == KIND_NUMBER:
        if not value:
            problems.append(Problem("critical_no_value", where, "число: нет значения"))
            return None
        number = _one_number(f"{value} {unit}".strip())
        if number is None:
            problems.append(Problem("critical_bad_number", where, f"значение {value!r}"))
            return None
        return Critical(kind, value=value, unit=unit, number=number)
    if kind == KIND_DATE:
        if not value:
            problems.append(Problem("critical_no_value", where, "дата: нет значения"))
            return None
        iso = _one_date(value)
        if not iso:
            problems.append(Problem("critical_bad_date", where, f"значение {value!r}"))
            return None
        return Critical(kind, value=value, date_iso=iso)
    if kind == KIND_PERIOD:
        a = _one_date(str(item.get("from") or ""))
        b = _one_date(str(item.get("to") or ""))
        if not a or not b or a > b:
            problems.append(Problem("critical_bad_period", where,
                                    f"с {item.get('from')!r} по {item.get('to')!r}"))
            return None
        return Critical(kind, from_iso=a, to_iso=b)
    if not text:
        problems.append(Problem("critical_no_value", where, f"{kind}: нет текста"))
        return None
    markers = item.get("markers")
    # Optional markers: an explicit empty array from UI/API equals omission.
    # Keep legacy scalar strings; reject non-string items and blank marker values.
    names = [] if markers is None or markers == [] else _str_list(markers)
    if names is None:
        problems.append(Problem("case_bad_type", where, "маркеры - список непустых строк"))
        names = []
    return Critical(kind, text=text, markers=tuple(names))


def _norm_expectation(raw: Any, where: str, problems: list[Problem],
                      warnings: list[Problem]) -> Expectation | None:
    if not isinstance(raw, dict):
        problems.append(Problem.known("expectation_not_mapping", where))
        return None
    item: dict[str, Any] = {}
    for key, value in raw.items():
        canon = _EXPECT_KEYS.get(str(key).strip())
        if canon is None:
            problems.append(Problem("expectation_unknown_key", where, f"ключ {key!r}"))
        else:
            item[canon] = value
    claim = " ".join(str(item.get("claim") or "").split())
    if not claim:
        problems.append(Problem.known("expectation_no_claim", where))
    source_raw = item.get("source")
    source: str | None = None
    if source_raw is None or not str(source_raw).strip():
        problems.append(Problem.known("expectation_no_source", where))
    else:
        source = _clean_rel(source_raw)
        if source is None:
            problems.append(Problem("source_bad_path", where, f"источник {source_raw!r}"))
        elif any_nda(source):
            problems.append(Problem.known("source_nda", where))
    locator = " ".join(str(item.get("locator") or "").split())
    if not locator:
        warnings.append(Problem("expectation_no_locator", where,
                                "нет локатора: сверка локатора для этого ожидания не выполняется"))
    if not claim or source is None:
        return None
    return Expectation(claim=claim, source=source, locator=locator)


def _norm_scope(raw: Any, where: str, problems: list[Problem]) -> tuple[str, ...]:
    names = _str_list(raw)
    if names is None:
        problems.append(Problem.known("case_no_scope", where))
        return ()
    out: list[str] = []
    for name in names:
        clean = _clean_rel(name)
        if clean is None:
            problems.append(Problem("scope_bad_path", where, f"область {name!r}"))
        elif any_nda(clean):
            problems.append(Problem("scope_nda", where, f"область {name!r}"))
        else:
            out.append(clean)
    return tuple(out)


def _norm_origin(raw: Any, where: str, problems: list[Problem]) -> dict[str, Any]:
    """Происхождение случая: известные ключи, булевы признаки - bool, остальное - строка."""
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        problems.append(Problem.known("origin_bad", where))
        return {}
    out: dict[str, Any] = {}
    for key, value in raw.items():
        canon = _ORIGIN_KEYS.get(str(key).strip())
        if canon is None or isinstance(value, (dict, list)):
            problems.append(Problem("origin_bad", where, f"ключ {key!r}"))
        elif canon in ("model_draft", "owner_edited"):
            if not isinstance(value, bool):
                problems.append(Problem("origin_bad", where, f"{key}: да/нет"))
            else:
                out[canon] = value
        else:
            out[canon] = str(value).strip()
    return out


def _norm_flags(raw: Any, where: str, problems: list[Problem]) -> frozenset[str]:
    if raw is None or raw == []:
        return frozenset()
    names = _str_list(raw)
    if names is None:
        problems.append(Problem("case_bad_type", where, "признаки - список строк"))
        return frozenset()
    flags: set[str] = set()
    for name in names:
        canon = _FLAGS.get(name.strip().lower())
        if canon is None:
            problems.append(Problem("case_bad_flag", where, f"признак {name!r}"))
        else:
            flags.add(canon)
    return frozenset(flags)


def _flag_rules(case: Case, where: str, problems: list[Problem]) -> None:
    distinct = len(case.sources)
    if case.single_doc and case.multi_source:
        problems.append(Problem.known("flags_conflict", where))
    if case.multi_source and distinct < 2:
        problems.append(Problem.known("multi_source_needs_two", where))
    if case.single_doc and distinct > 1:
        problems.append(Problem.known("single_doc_many_sources", where))
    if case.risky and not case.critical:
        problems.append(Problem.known("risky_no_critical", where))


def _norm_case(raw: Any, index: int, problems: list[Problem],
               warnings: list[Problem]) -> Case | None:
    if not isinstance(raw, dict):
        problems.append(Problem.known("case_not_mapping", f"случай #{index}"))
        return None
    item: dict[str, Any] = {}
    for key, value in raw.items():
        canon = _CASE_KEYS.get(str(key).strip())
        if canon is None:
            problems.append(Problem("case_unknown_key", f"случай #{index}", f"ключ {key!r}"))
        else:
            item[canon] = value
    cid = str(item.get("id") or "").strip()
    where = f"случай {cid or '#' + str(index)}"
    if not cid:
        problems.append(Problem.known("case_no_id", where))
    question = " ".join(str(item.get("question") or "").split())
    if not question:
        problems.append(Problem.known("case_no_question", where))
    part = _PARTS.get(str(item.get("part") or "").strip().lower())
    if part is None:
        problems.append(Problem("case_bad_part", where, f"часть {item.get('part')!r}"))
    scope = _norm_scope(item.get("scope"), where, problems)
    flags = _norm_flags(item.get("flags"), where, problems)
    expects: list[Expectation] = []
    raw_expect = item.get("expect")
    if not isinstance(raw_expect, list) or not raw_expect:
        problems.append(Problem.known("case_no_expectations", where))
    else:
        for i, e in enumerate(raw_expect, start=1):
            exp = _norm_expectation(e, f"{where}, ожидание {i}", problems, warnings)
            if exp is not None:
                expects.append(exp)
    crit: list[Critical] = []
    raw_crit = item.get("critical")
    if raw_crit is not None and not isinstance(raw_crit, list):
        problems.append(Problem("case_bad_type", where, "критические_условия - список"))
    for i, c in enumerate(raw_crit or [], start=1):
        parsed = _norm_critical(c, f"{where}, условие {i}", problems)
        if parsed is not None:
            crit.append(parsed)
    if scope:
        for exp in expects:
            if not scope_match(exp.source, scope):
                problems.append(Problem("source_outside_scope", where,
                                        f"источник {exp.source!r} не входит в область"))
    if not cid or part is None:
        return None
    case = Case(id=cid, part=part, question=question, scope=scope, flags=flags,
                expectations=tuple(expects), critical=tuple(crit),
                note=str(item.get("note") or "").strip(),
                origin=_norm_origin(item.get("origin"), where, problems))
    _flag_rules(case, where, problems)
    return case


def _parse_top(data: Any, target: Path) -> tuple[int, str, list[Any]]:
    if not isinstance(data, dict):
        raise SleepControlError(
            f"контрольный набор сна: ожидается словарь с версия_схемы и случаи: {target}",
            CODE_EMPTY)
    keyed: dict[str, Any] = {}
    unknown: list[Problem] = []
    for key, value in data.items():
        canon = _TOP_KEYS.get(str(key).strip())
        if canon is None:
            unknown.append(Problem("case_unknown_key", "файл", f"ключ верхнего уровня {key!r}"))
        else:
            keyed[canon] = value
    version = keyed.get("schema_version")
    if version is None:
        raise SleepControlError(
            f"контрольный набор сна: нет версия_схемы (сейчас {SCHEMA_VERSION}): {target}",
            CODE_SCHEMA_MISSING)
    if isinstance(version, bool) or not isinstance(version, int) or version < 1:
        raise SleepControlError(
            f"контрольный набор сна: версия_схемы {version!r} - нужно целое >= 1",
            CODE_SCHEMA_MISSING)
    if version > SCHEMA_VERSION:
        raise SleepControlError(
            f"контрольный набор сна: версия_схемы {version} новее поддерживаемой "
            f"({SCHEMA_VERSION}); обновите движок, поля новой схемы молча не теряем",
            CODE_SCHEMA_UNSUPPORTED)
    if unknown:
        raise SleepControlError(
            "контрольный набор сна: " + "; ".join(str(p) for p in unknown), CODE_INVALID, unknown)
    cases = keyed.get("cases")
    if not isinstance(cases, list) or not cases:
        raise SleepControlError(
            f"контрольный набор сна: пусто или нет списка случаи: {target}", CODE_EMPTY)
    return version, str(keyed.get("label") or "").strip(), cases


def load_control(path: Path | None = None) -> ControlSet:
    """Прочитать набор; все замечания - одним :class:`SleepControlError` (код + список проблем).

    Движок файл только читает (запись набора - :mod:`core.sleep_eval.label` по явному действию
    владельца). Из конвейера сна загрузчик недоступен (fence)."""
    assert_control_allowed()
    target = Path(path) if path is not None else control_path()
    try:
        raw_bytes = target.read_bytes()
    except OSError as exc:
        raise SleepControlError(
            f"контрольный набор сна не прочитан: {target}: {exc}", CODE_UNREADABLE) from exc
    return parse_control(raw_bytes, target)


def parse_control(raw_bytes: bytes, target: Path) -> ControlSet:
    """Разобрать и проверить содержимое набора (те же правила, что у загрузчика файла): запись
    набора проверяет НОВЫЙ текст этим же кодом до записи на диск."""
    assert_control_allowed()
    try:
        data = yaml.safe_load(raw_bytes.decode("utf-8"))
    except (yaml.YAMLError, UnicodeDecodeError) as exc:
        raise SleepControlError(
            f"контрольный набор сна: невалидный YAML ({target}): {exc}", CODE_BAD_YAML) from exc
    version, label, items = _parse_top(data, target)
    problems: list[Problem] = []
    warnings: list[Problem] = []
    cases: list[Case] = []
    for i, raw in enumerate(items, start=1):
        case = _norm_case(raw, i, problems, warnings)
        if case is not None:
            cases.append(case)
    ids = [str(r.get("id") or "").strip() for r in items if isinstance(r, dict)]
    ids = [i for i in ids if i]
    for dup in sorted({i for i in ids if ids.count(i) > 1}):
        problems.append(Problem.known("case_duplicate_id", f"случай {dup}"))
    if problems:
        raise SleepControlError(
            "контрольный набор сна: " + "; ".join(str(p) for p in problems), CODE_INVALID, problems)
    return ControlSet(
        schema_version=version, label=label, cases=cases,
        file_sha256=hashlib.sha256(raw_bytes).hexdigest(), warnings=warnings)


def coverage(control: ControlSet) -> Coverage:
    """Покрытие пилота: размечено / многоисточниковых / рискованных против 30 / 10 / 10."""
    cases = control.cases
    multi = sum(1 for c in cases if c.multi_source)
    risky = sum(1 for c in cases if c.risky)
    short: list[str] = []
    if len(cases) < PILOT_TOTAL:
        short.append(f"размечено {len(cases)} из {PILOT_TOTAL}")
    if multi < PILOT_MULTI:
        short.append(f"по нескольким источникам {multi} из {PILOT_MULTI}")
    if risky < PILOT_RISKY:
        short.append(f"рискованных {risky} из {PILOT_RISKY}")
    single = sum(1 for c in cases if c.single_doc)
    if single == 0:
        short.append("нет вопросов по одному документу (нужны: память может мешать, §11)")
    dev = len(control.part(PART_DEV))
    ctl = len(control.part(PART_CONTROL))
    if dev == 0 or ctl == 0:
        short.append("нужны обе части: разработка и контроль")
    return Coverage(total=len(cases), multi=multi, risky=risky, single_doc=single,
                    development=dev, control=ctl, ready=not short, shortfall=tuple(short))
