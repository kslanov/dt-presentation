"""SLEEP-EVAL-1 п.4 - кандидаты случаев для разметки К. (``dt sleep-eval draft``).

Читает vault ТОЛЬКО на чтение (без ``_nda`` и личного: барьер обхода и
:mod:`core.sleep_eval.privacy`) и предлагает, ИЗ ЧЕГО можно собрать контрольные вопросы пилота
(цель - не меньше 30 размеченных, из них 10 многоисточниковых и 10 рискованных). Результат -
``.derived/sleep/eval/candidates.json``; в контрольный набор ничего не пишется (файл набора - данные
К., движок его не меняет): К. выбирает кандидата, формулирует вопрос и ожидания сам.

Эвристики (все детерминированные, без модели; порядок и ``cand_id`` стабильны):

* **многоисточниковые** - хабы клиентов/проектов (``type: hub``) с >= 3 документами и >= 2
  «семействами» (папка + имя без версий/дат): документ принадлежит хабу по ``client``/``project``/
  ``product``/``links``; оценка растет с числом документов и разнообразием семейств;
* **рискованные**:

  - ``currency_mix`` - в документе суммы в разных валютах; ``scale_mix`` - одна валюта, но записи
    в разных масштабах (``480 тыс. руб.`` рядом с ``654 000 руб.``); ``vat_both`` - «с НДС» и
    «без НДС» в одном документе; ``labor_unit_mix`` - чел.-дн рядом с чел.-час;
  - ``version_family`` - несколько версий одного документа в папке (``v2``, ``финал``, ``ред.``,
    даты в имени);
  - ``fact_conflict`` - противоречие в сторе фактов (актуальные факты одного ключа из разных
    семейств версий, :func:`core.facts.versions.contradiction_groups`; только чтение; недоступный
    стор - предупреждение, не пустой результат);

* **по одному документу** - документы с несколькими проверяемыми числами/датами вне кандидатов
  выше (§11: отдельно проверить вопросы, где дополнительная память может мешать). Это расширение ТЗ.

Имя документа в ``question_draft`` - человеческое: имя исходного файла из ``source_path`` (без
расширения; не почтовый ``conv:``), иначе ``title``, а если это легаси-слаг (``otsenka-8dcc6a11``) -
H1 тела; у почтового треда (``source_path: conv:<id>``) при пустом ``title`` или ``title`` -
идентификаторе треда берется ``subject``. В вопросе ``version_family`` - имя новейшего участника
семейства (по дате) без меток версии, а не ключ группировки. Ключ семейства версий срезает хвост
хэша слага ``-xxxxxxxx`` и берется по имени исходного файла, если он есть: серия ``<слаг>-<hash>``
не рассыпается на кандидатов.

Хаб-кандидат с рискованными документами получает оба признака. ``already_labeled`` - случаи
существующего набора, область которых покрывает >= половины источников кандидата (чтобы К. не
размечал одно дважды). Верхний уровень ``07-outputs``/``06-templates``/``01-style``/``_*`` не
обходится. Бюджет времени - честный ``partial``.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
from collections import defaultdict
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import frontmatter  # type: ignore[import-untyped]

from core.facts.textnorm import NumberMention, scan_dates, scan_numbers
from core.privacy import is_nda
from core.sleep_eval.control import PILOT_MULTI, PILOT_RISKY, PILOT_TOTAL, ControlSet, scope_match
from core.sleep_eval.privacy import exclusion_reason

__all__ = [
    "CANDIDATES_FILE",
    "CANDIDATES_SCHEMA",
    "Doc",
    "draft_candidates",
    "family_key",
    "looks_like_slug",
    "money_signals",
    "write_candidates",
]

CANDIDATES_FILE = "candidates.json"
CANDIDATES_SCHEMA = 1
SKIP_TOP = frozenset({"07-outputs", "06-templates", "01-style"})
MIN_HUB_DOCS, MIN_HUB_FAMILIES = 3, 2
MAX_SOURCES = 12
MAX_BODY = 200_000
LIMITS = {"multi_source": 40, "risky": 40, "single_doc": 10}

_WIKILINK_RE = re.compile(r"\[\[([^\[\]|]+?)(?:\|[^\]]*)?\]\]")
_OWNER_FIELDS = ("client", "project", "product", "links")
_VAT_WITH = re.compile(r"\bс\s+НДС\b", re.IGNORECASE)
_VAT_WITHOUT = re.compile(r"\bбез\s+НДС\b", re.IGNORECASE)
_B, _E = r"(?<![^\W_])", r"(?![^\W_])"  # границы слова, где «_» - разделитель, а не часть слова
_DATE_NAME_RE = re.compile(
    _B + r"\d{1,2}[.\-_]\d{1,2}[.\-_]\d{2,4}" + _E + "|" + _B
    + r"\d{4}[.\-_]\d{2}[.\-_]\d{2}" + _E)
_VERSION_RE = re.compile(
    _B + r"v\s*\d+(?:\.\d+)*" + _E + "|" + _B + r"в\s*\d+" + _E + "|" + _B + r"ver\w*" + _E
    + "|" + _B + r"версия\s*\d*" + _E + "|" + _B + r"ред(?:акция)?\.?\s*\d*" + _E + "|"
    + _B + r"rev\w*" + _E + "|" + _B
    + r"(?:финал\w*|final|draft|черновик\w*|копия|copy|old|архив\w*|новый|new)" + _E,
    re.IGNORECASE)
_HAS_VERSION_RE = _VERSION_RE
#: хвост легаси-слага ``<слаг>-<8 hex хэша source_path>`` (core.legacy.render.note_relpath)
_HASH_TAIL_RE = re.compile(r"-[0-9a-f]{8}$")
#: слаг легаси-заметки: латиница/цифры/дефисы плюс хвост из 8 hex (узко и детерминированно)
_SLUG_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*-[0-9a-f]{8}$")
_DATE8_RE = re.compile(r"^(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])$")
#: почтовый источник: ``conv:``/``msg:`` или виртуальный ``correspondence/conv:<id>`` (repoint)
_MAIL_SOURCE_RE = re.compile(r"^(?:correspondence/)?(?:conv|msg):|^correspondence/", re.IGNORECASE)
#: «имя»-заглушка почтового треда: сам идентификатор (``conv:210613``, ``msg-42``)
_CONV_ID_RE = re.compile(r"^(?:conv|msg)[:\-_ ]*[\w.\-]+$", re.IGNORECASE)
_FILE_EXT_RE = re.compile(r"\.(?=[0-9]*[A-Za-z])[A-Za-z0-9]{1,5}$")
_CURRENCY_LEN = 3
_LABOR_DAY, _LABOR_HOUR = "чел.-дн", "чел.-ч"


@dataclass
class Doc:
    rel: str
    title: str
    note_type: str
    note_id: str
    date: str
    owners: list[str]
    family: str
    body: str = ""
    source_path: str = ""
    key: str = ""  # ключ семейства версий (без папки)
    name_src: str = ""  # имя файла, от которого взят ключ (исходный файл либо файл заметки)
    fm: dict[str, Any] = field(default_factory=dict)
    signals: list[dict[str, Any]] = field(default_factory=list)
    checkable: int = 0


# --------------------------------------------------------------------------- #
# Чтение vault                                                                   #
# --------------------------------------------------------------------------- #
def _strip_hash(stem: str) -> str:
    """Срезать хвост хэша легаси-слага ``-xxxxxxxx`` (8 hex) в конце имени без расширения."""
    return _HASH_TAIL_RE.sub("", stem.casefold())


def looks_like_slug(text: str) -> bool:
    """Легаси-слаг: латиница/цифры/дефисы плюс хвост из 8 hex (``otsenka-8dcc6a11``).

    Хвост из 8 цифр, похожий на дату (``plan-20260101``), хэшем не считается."""
    text = text.strip()
    if not _SLUG_RE.match(text):
        return False
    return not _DATE8_RE.match(text[-8:])


def family_key(name: str) -> str:
    """Имя без хвоста хэша, версий, дат, пометок «финал/копия» и знаков - ключ семейства версий."""
    stem = name.replace("\\", "/").rsplit("/", 1)[-1].rsplit(".", 1)[0].replace("ё", "е")
    stem = _strip_hash(stem.casefold())
    stem = _DATE_NAME_RE.sub(" ", stem)
    stem = _VERSION_RE.sub(" ", stem)
    stem = re.sub(r"[\d_\-.()\[\]]+", " ", stem)
    return " ".join(stem.split())


def _source_file_name(source_path: str) -> str:
    """Имя исходного файла из ``source_path`` (с расширением) либо ``""`` (нет пути, почтовый
    ``conv:``/``msg:``)."""
    sp = source_path.strip()
    if not sp or _MAIL_SOURCE_RE.match(sp):
        return ""
    return sp.replace("\\", "/").rstrip("/").rsplit("/", 1)[-1].strip()


def _file_stem(name: str) -> str:
    return _FILE_EXT_RE.sub("", name).strip()


def _owner_ids(fm: dict[str, Any]) -> list[str]:
    out: list[str] = []
    for key in _OWNER_FIELDS:
        raw = fm.get(key)
        for item in raw if isinstance(raw, list) else [raw]:
            if not item:
                continue
            m = _WIKILINK_RE.search(str(item))
            out.append((m.group(1) if m else str(item)).strip())
    return list(dict.fromkeys(o for o in out if o))


def _first_h1(body: str) -> str:
    for line in body.splitlines():
        if line.strip().startswith("# "):
            return line.strip()[2:].strip()
    return ""


def _display_title(fm: dict[str, Any], body: str, stem: str, src_name: str) -> str:
    """Человеческое имя документа: имя исходного файла из ``source_path`` (без расширения), иначе
    ``title``/``subject``, но если это слаг - H1 тела (если он не слаг), иначе что есть."""
    from_file = _file_stem(src_name)
    if from_file:
        return from_file
    title = str(fm.get("title") or "").strip()
    subject = str(fm.get("subject") or "").strip()
    mail = bool(_MAIL_SOURCE_RE.match(str(fm.get("source_path") or "").strip()))
    if not title or (mail and subject and (_CONV_ID_RE.match(title)
                                           or title == str(fm.get("source_path") or "").strip())):
        title = subject or title
    if title and not looks_like_slug(title):
        return title
    h1 = _first_h1(body)
    if h1 and not looks_like_slug(h1):
        return h1
    return title or h1 or stem


def _read_doc(path: Path, rel: str) -> tuple[Doc | None, str | None]:
    try:
        raw = path.read_text(encoding="utf-8")[:MAX_BODY]
        post = frontmatter.loads(raw)
    except (OSError, ValueError, UnicodeDecodeError, TypeError):
        return None, None
    fm = dict(post.metadata)
    reason = exclusion_reason(rel, fm, source_path=str(fm.get("source_path") or ""))
    if reason:
        return None, reason
    body = post.content
    src_name = _source_file_name(str(fm.get("source_path") or ""))
    title = _display_title(fm, body, path.stem, src_name)
    date = ""
    for key in ("modified", "last_date", "created", "first_date"):
        if fm.get(key):
            date = str(fm[key])
            break
    parent = rel.rsplit("/", 1)[0] if "/" in rel else ""
    name_src = src_name or path.name
    key = family_key(name_src) or _strip_hash(path.stem) or path.stem.casefold()
    return Doc(
        rel=rel, title=title, note_type=str(fm.get("type") or ""),
        note_id=str(fm.get("id") or ""), date=date, owners=_owner_ids(fm),
        family=f"{parent}|{key}", body=body, source_path=str(fm.get("source_path") or ""),
        key=key, name_src=name_src, fm=fm,
    ), None


def _walk(vault: Path, clock: Callable[[], float], deadline: float) -> tuple[
        list[Doc], dict[str, int], bool]:
    from core.vault import iter_vault_paths

    docs: list[Doc] = []
    excluded: dict[str, int] = defaultdict(int)
    for path in iter_vault_paths(Path(vault)):
        if clock() > deadline:
            return docs, dict(excluded), True
        rel = path.relative_to(vault).as_posix()
        if rel.split("/", 1)[0] in SKIP_TOP or is_nda(rel):
            continue
        doc, reason = _read_doc(path, rel)
        if reason:
            excluded[reason] += 1
        elif doc is not None:
            docs.append(doc)
    return docs, dict(excluded), False


# --------------------------------------------------------------------------- #
# Сигналы риска                                                                  #
# --------------------------------------------------------------------------- #
def _is_currency(unit: str | None) -> bool:
    return bool(unit) and len(str(unit)) == _CURRENCY_LEN and str(unit).isalpha() \
        and str(unit).isupper()


def _snippet(text: str, start: int, end: int) -> str:
    return " ".join(text[max(0, start - 30): end + 30].split())[:90]


def money_signals(body: str) -> list[dict[str, Any]]:
    """Риски документа по тексту: смесь валют/масштабов, НДС и без, чел.-дн рядом с чел.-час."""
    numbers: list[NumberMention] = scan_numbers(body)
    money = [n for n in numbers if _is_currency(n.unit)]
    out: list[dict[str, Any]] = []
    currencies = sorted({str(n.unit) for n in money})
    if len(currencies) >= 2:
        first = {c: next(n for n in money if n.unit == c) for c in currencies}
        out.append({"code": "currency_mix", "detail": ", ".join(currencies), "examples": [
            _snippet(body, n.start, n.end) for n in first.values()][:3]})
    for cur in currencies:
        scales = {n.scale for n in money if n.unit == cur}
        if len(scales) >= 2:
            ex = [next(n for n in money if n.unit == cur and n.scale == s) for s in sorted(
                scales, key=lambda x: x or 0)]
            out.append({"code": "scale_mix", "detail": cur,
                        "examples": [_snippet(body, n.start, n.end) for n in ex][:3]})
    if numbers and _VAT_WITH.search(body) and _VAT_WITHOUT.search(body):
        m = _VAT_WITH.search(body)
        out.append({"code": "vat_both", "detail": "с НДС и без НДС",
                    "examples": [_snippet(body, m.start(), m.end())] if m else []})
    units = {n.unit for n in numbers}
    if _LABOR_DAY in units and _LABOR_HOUR in units:
        out.append({"code": "labor_unit_mix", "detail": "чел.-дн и чел.-ч", "examples": []})
    return out


def _checkable(body: str) -> int:
    dates = scan_dates(body)
    blank = body
    for d in sorted(dates, key=lambda d: -d.start):
        blank = blank[: d.start] + " " * (d.end - d.start) + blank[d.end:]
    nums = [n for n in scan_numbers(blank) if n.unit or n.scale or len(n.raw) >= 4]
    return len(nums) + len(dates)


def _version_groups(docs: list[Doc]) -> list[list[Doc]]:
    by_family: dict[str, list[Doc]] = defaultdict(list)
    for d in docs:
        if len(d.key) >= 4:
            by_family[d.family].append(d)
    out = []
    for members in by_family.values():
        if len(members) < 2:
            continue
        names = [_strip_hash(m.name_src.rsplit(".", 1)[0]) for m in members]
        marked = any(_HAS_VERSION_RE.search(n) or _DATE_NAME_RE.search(n) for n in names)
        versioned = len({str(m.fm.get("version") or m.fm.get("modified") or "")
                         for m in members}) > 1
        if marked or versioned:
            out.append(sorted(members, key=lambda m: m.rel))
    return sorted(out, key=lambda g: g[0].rel)


# --------------------------------------------------------------------------- #
# Кандидаты                                                                      #
# --------------------------------------------------------------------------- #
def _cid(kind: str, paths: Iterable[str], extra: str = "") -> str:
    blob = kind + "|" + "|".join(sorted(paths)) + "|" + extra
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:12]


def _src(d: Doc) -> dict[str, str]:
    return {"path": d.rel, "title": d.title, "date": d.date, "type": d.note_type}


def _hub_name(hub: Doc) -> str:
    aliases = hub.fm.get("aliases")
    alias = aliases[0] if isinstance(aliases, list) and aliases else ""
    options = [str(x).strip() for x in (alias, _first_h1(hub.body), hub.title, hub.note_id) if x]
    return next((o for o in options if o and not looks_like_slug(o)), options[0] if options else "")


def _pick_sources(members: list[Doc]) -> list[Doc]:
    """До MAX_SOURCES документов: по одному на семейство (свежие первыми), затем остальные."""
    ordered = sorted(members, key=lambda d: (d.date or "", d.rel), reverse=True)
    seen: set[str] = set()
    first: list[Doc] = []
    rest: list[Doc] = []
    for d in ordered:
        if d.family in seen:
            rest.append(d)
        else:
            seen.add(d.family)
            first.append(d)
    return sorted((first + rest)[:MAX_SOURCES], key=lambda d: d.rel)


def _hub_candidates(docs: list[Doc]) -> list[dict[str, Any]]:
    hubs = [d for d in docs if d.note_type == "hub" and d.note_id]
    by_owner: dict[str, list[Doc]] = defaultdict(list)
    for d in docs:
        if d.note_type == "hub":
            continue
        for owner in d.owners:
            by_owner[owner].append(d)
    out: list[dict[str, Any]] = []
    for hub in sorted(hubs, key=lambda h: h.rel):
        members = sorted({m.rel: m for m in by_owner.get(hub.note_id, [])}.values(),
                         key=lambda m: m.rel)
        families = {m.family for m in members}
        if len(members) < MIN_HUB_DOCS or len(families) < MIN_HUB_FAMILIES:
            continue
        picked = _pick_sources(members)
        signals = [{**s, "path": m.rel} for m in members for s in m.signals][:12]
        flags = ["multi_source"] + (["risky"] if signals else [])
        name = _hub_name(hub)
        out.append({
            "cand_id": _cid("hub", [hub.rel] + [m.rel for m in picked]), "kind": "multi_source",
            "flags": flags, "hub": {"id": hub.note_id, "path": hub.rel, "name": name},
            "question_draft": (f"Что известно по «{name}»: ключевые условия, суммы, сроки и "
                               "исключения по документам?"),
            "sources": [_src(hub)] + [_src(m) for m in picked],
            "signals": signals,
            "stats": {"documents": len(members), "families": len(families)},
            "score": round(min(len(members), 10) / 10 * 0.6 + min(len(families), 6) / 6 * 0.4
                           + (0.2 if signals else 0.0), 4),
        })
    return out


def _risky_doc_candidates(docs: list[Doc]) -> list[dict[str, Any]]:
    out = []
    for d in sorted(docs, key=lambda d: d.rel):
        if not d.signals:
            continue
        codes = sorted({s["code"] for s in d.signals})
        out.append({
            "cand_id": _cid("risky", [d.rel], ",".join(codes)), "kind": "risky",
            "flags": ["risky"], "question_draft": (
                f"Какие суммы и на каком основании (единицы, масштаб, налоги) указаны в "
                f"документе «{d.title}»?"),
            "sources": [_src(d)], "signals": [{**s, "path": d.rel} for s in d.signals],
            "score": round(min(len(d.signals), 4) / 4 * 0.7 + min(d.checkable, 10) / 10 * 0.3, 4)})
    return out


_TITLE_EDGE = " \t_-.,;:()[]"


def _strip_version_marks(title: str) -> str:
    """Название без меток версии и дат (``Смета v2 финал`` -> ``Смета``), регистр сохраняется."""
    text = _VERSION_RE.sub(" ", _DATE_NAME_RE.sub(" ", title))
    text = re.sub(r"\(\s*\)|\[\s*\]", " ", text)
    return " ".join(text.split()).strip(_TITLE_EDGE)


def _family_name(members: list[Doc]) -> str:
    """Человеческое имя семейства версий: display-title новейшего участника (по дате, при равных -
    по пути) без меток версии; нет ничего - title как есть, затем ключ группировки."""
    newest = max(members, key=lambda m: (m.date or "", m.rel))
    return _strip_version_marks(newest.title) or newest.title or newest.key


def _version_candidates(groups: list[list[Doc]]) -> list[dict[str, Any]]:
    out = []
    for members in groups:
        name = _family_name(members)
        flags = ["risky", "multi_source"]
        out.append({
            "cand_id": _cid("versions", [m.rel for m in members]), "kind": "risky", "flags": flags,
            "question_draft": (f"Какая версия документа «{name}» действующая и что в ней "
                               "изменилось?"),
            "sources": [_src(m) for m in members[:MAX_SOURCES]],
            "signals": [{"code": "version_family", "detail": f"{len(members)} версий",
                         "path": members[0].rel, "examples": [m.rel for m in members[:3]]}],
            "score": round(min(len(members), 5) / 5 * 0.8 + 0.2, 4)})
    return out


def _conflict_candidates(groups: list[list[dict[str, Any]]], docs: list[Doc],
                         ) -> list[dict[str, Any]]:
    by_source: dict[str, Doc] = {}
    for d in docs:
        by_source[d.source_path] = d
        by_source[d.rel] = d
    out = []
    for group in groups:
        found: dict[str, Doc] = {}
        for fact in group:
            src = str(fact.get("source_path") or "")
            if is_nda(src):
                continue
            doc = by_source.get(src) or next(
                (d for d in docs if d.source_path and src and d.source_path.endswith(
                    src.rsplit("/", 1)[-1])), None)
            if doc is not None:
                found[doc.rel] = doc
        if len(found) < 1:
            continue
        values = sorted({str(f.get("value_raw") or "") for f in group if f.get("value_raw")})
        label = str(group[0].get("label") or group[0].get("fact_key") or "значение")[:60]
        out.append({
            "cand_id": _cid("conflict", list(found), str(group[0].get("fact_key") or label)),
            "kind": "risky", "flags": ["risky"] + (["multi_source"] if len(found) > 1 else []),
            "question_draft": f"Какое значение «{label}» действует: {' или '.join(values[:3])}?",
            "sources": [_src(d) for d in sorted(found.values(), key=lambda d: d.rel)],
            "signals": [{"code": "fact_conflict", "detail": label, "path": p,
                         "examples": values[:3]} for p in sorted(found)][:6],
            "score": round(0.7 + min(len(group), 4) / 4 * 0.3, 4)})
    return out


def _single_candidates(docs: list[Doc], used: set[str]) -> list[dict[str, Any]]:
    out = []
    for d in sorted(docs, key=lambda d: d.rel):
        if d.note_type == "hub" or d.rel in used or d.checkable < 3:
            continue
        out.append({
            "cand_id": _cid("single", [d.rel]), "kind": "single_doc", "flags": ["single_doc"],
            "question_draft": f"Какие ключевые числа и даты указаны в документе «{d.title}»?",
            "sources": [_src(d)], "signals": [],
            "score": round(min(d.checkable, 12) / 12, 4)})
    return out


def _with_overlap(cands: list[dict[str, Any]], control: ControlSet | None) -> None:
    for c in cands:
        hits: list[str] = []
        if control is not None:
            paths = [s["path"] for s in c["sources"]]
            for case in control.cases:
                inside = sum(1 for p in paths if scope_match(p, case.scope))
                if paths and inside * 2 >= len(paths):
                    hits.append(case.id)
        c["already_labeled"] = sorted(hits)


def _trim(cands: list[dict[str, Any]]) -> list[dict[str, Any]]:
    cands.sort(key=lambda c: (-c["score"], c["cand_id"]))
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    taken = defaultdict(int)
    for c in cands:
        group = "multi_source" if c["kind"] == "multi_source" else c["kind"]
        if c["cand_id"] in seen or taken[group] >= LIMITS[group]:
            continue
        seen.add(c["cand_id"])
        taken[group] += 1
        out.append(c)
    return out


def _default_contradictions() -> tuple[list[list[dict[str, Any]]], str]:
    import sqlite3

    from core.facts.versions import contradiction_groups

    try:
        groups = contradiction_groups()
    except (OSError, sqlite3.Error) as exc:
        return [], f"стор фактов недоступен: {type(exc).__name__}"
    if groups is None:
        return [], "стор фактов старой схемы: противоречия не считаются"
    return groups, ""


def draft_candidates(
    vault: Path, *, control: ControlSet | None = None,
    contradictions: Callable[[], tuple[list[list[dict[str, Any]]], str]] | None = None,
    budget_s: float = 120.0, clock: Callable[[], float] = time.monotonic,
    now: datetime | None = None, skip_ids: Iterable[str] = (),
) -> dict[str, Any]:
    """Кандидаты случаев из vault (только чтение). Результат - словарь для ``candidates.json``.

    ``contradictions`` - поставщик противоречий фактов ``() -> (группы, предупреждение)``; по
    умолчанию читает стор фактов (read-only). ``skip_ids`` - ``cand_id``, которые владелец уже
    отклонил или отложил в пульте (SLEEP-PULT-1): повторный draft их не возвращает."""
    deadline = clock() + budget_s
    docs, excluded, partial = _walk(Path(vault), clock, deadline)
    for d in docs:
        d.signals = money_signals(d.body)
        d.checkable = _checkable(d.body)
    warnings: list[str] = []
    groups, warn = (contradictions or _default_contradictions)()
    if warn:
        warnings.append(warn)
    hubs = _hub_candidates(docs)
    versions = _version_candidates(_version_groups(docs))
    cands = [*hubs, *_risky_doc_candidates(docs), *versions, *_conflict_candidates(groups, docs)]
    used = {s["path"] for c in cands for s in c["sources"]}
    cands += _single_candidates(docs, used)
    cands = _trim(cands)
    skip = set(skip_ids)
    owner_skipped = sum(1 for c in cands if c["cand_id"] in skip)
    cands = [c for c in cands if c["cand_id"] not in skip]
    _with_overlap(cands, control)
    multi = sum(1 for c in cands if "multi_source" in c["flags"])
    risky = sum(1 for c in cands if "risky" in c["flags"])
    return {
        "schema_version": CANDIDATES_SCHEMA,
        "generated_at": (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "purpose": "кандидаты для разметки К.; в контрольный набор не входят",
        "partial": partial, "warnings": warnings, "owner_skipped": owner_skipped,
        "scanned": {"documents": len(docs), "excluded": excluded},
        "counts": {"total": len(cands), "multi_source": multi, "risky": risky,
                   "single_doc": sum(1 for c in cands if "single_doc" in c["flags"])},
        "pilot_target": {"total": PILOT_TOTAL, "multi_source": PILOT_MULTI, "risky": PILOT_RISKY},
        "candidates": cands,
    }


def write_candidates(data: dict[str, Any], root: Path | None = None) -> Path:
    """Записать ``candidates.json`` (атомарно); корень по умолчанию - ``sleep_eval_dir()``."""
    if root is None:
        from core.config import sleep_eval_dir

        root = sleep_eval_dir()
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    target = root / CANDIDATES_FILE
    tmp = target.with_name(CANDIDATES_FILE + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=1) + "\n",
                   encoding="utf-8")
    os.replace(tmp, target)
    return target
