"""Compatibility facade for the shared runtime boundary."""

from core.sleep.fence import (
    CODE_FORBIDDEN_IN_PIPELINE,
    ControlAccessError,
    assert_control_allowed,
    in_pipeline,
    pipeline_scope,
)

__all__ = [
    "CODE_FORBIDDEN_IN_PIPELINE",
    "ControlAccessError",
    "assert_control_allowed",
    "in_pipeline",
    "pipeline_scope",
]
