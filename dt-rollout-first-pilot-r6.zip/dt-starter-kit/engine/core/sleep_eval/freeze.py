"""SLEEP-EVAL-1 п.2 - заморозка разрешенного корпуса и исходной выдачи варианта A (sleep-1.md §11).

«До синтеза зафиксировать разрешенный корпус, вопросы и исходную выдачу». ``dt sleep-eval freeze``
пишет в ``.derived/sleep/eval/<метка>/``:

* ``manifest.json`` - ДЕТЕРМИНИРОВАННЫЙ манифест разрешенного корпуса: объединение областей всех
  случаев, по файлу - путь, sha256, размер, ``id``/``corpus``/``version``/``modified`` из
  frontmatter; отдельно исключенное (``_nda``, личное, карантин) с причиной; хэш вопросов и
  параметры выдачи. Повтор на неизменном корпусе дает ТОТ ЖЕ байт-в-байт манифест; изменился файл -
  другой ``manifest_hash``. Времени и абсолютных путей в нем нет;
* ``baseline-A.json`` - исходная выдача варианта A (текущий RAG) по КАЖДОМУ вопросу с
  фиксированными параметрами: ``find_notes`` (топ ``find_limit`` внутри области) + текст верхних
  ``read_top`` заметок (``read_note``, ``read_chars`` знаков) и, если задан сценарий, ``retrieve``.
  Раннер A берет контекст отсюда, а не из живого индекса: A, B, C, D отвечают на одном и том же;
* ``freeze.json`` - мета (когда, версия движка, хэши, счетчики); пишется последней, это маркер
  завершенности.

Контрольные ОТВЕТЫ (ожидаемые утверждения, источники, критические условия) в заморозку не попадают:
сюда идут только вопросы и области (:func:`core.sleep_eval.control.questions_hash`). Ожидаемые
источники сверяются с корпусом отдельно (:func:`missing_expected_sources`) и НЕ сохраняются.

Повторная заморозка той же метки: тот же манифест и та же выдача - ``unchanged`` (ничего не
пишется); иначе отказ ``freeze_exists_differs`` / ``freeze_baseline_drift`` с перечнем отличий;
``force`` откладывает прежнюю заморозку как ``<метка>.superseded-N`` (ничего не удаляется).
Запись атомарна (временный каталог, ``rename``): у оборванной заморозки нет маркера завершения.

Инструменты приходят параметром (``find_notes``, ``read_note``, опционально ``retrieve``) - модуль
``mcp-server/server.py`` либо подделка: ``core`` ⊥ cli/mcp. Модель не вызывается.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import frontmatter  # type: ignore[import-untyped]

from core.privacy import any_nda
from core.sleep_eval.control import Case, ControlSet, questions_hash, scope_match
from core.sleep_eval.privacy import exclusion_reason

__all__ = [
    "FREEZE_SCHEMA",
    "BASELINE_FILE",
    "MANIFEST_FILE",
    "META_FILE",
    "Drift",
    "FreezeError",
    "FreezeParams",
    "FreezeResult",
    "Frozen",
    "build_manifest",
    "freeze_corpus",
    "load_frozen",
    "missing_expected_sources",
    "safe_label",
    "verify_corpus",
]

FREEZE_SCHEMA = 1
MANIFEST_FILE, BASELINE_FILE, META_FILE = "manifest.json", "baseline-A.json", "freeze.json"

CODE_EXISTS_DIFFERS = "freeze_exists_differs"
CODE_BASELINE_DRIFT = "freeze_baseline_drift"
CODE_NOT_FOUND = "freeze_not_found"
CODE_INCOMPLETE = "freeze_incomplete"
CODE_BAD_LABEL = "freeze_bad_label"
CODE_NO_TOOLS = "freeze_no_tools"
CODE_MISSING_EXPECTED = "freeze_missing_expected"
CODE_SCHEMA = "freeze_schema_unsupported"
_MAX_FIND_LIMIT = 50


class FreezeError(RuntimeError):
    """Заморозка не выполнена/не прочитана. ``code`` - машинный; ``drift`` - отличия."""

    def __init__(self, message: str, code: str, drift: Drift | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.drift = drift


@dataclass(frozen=True)
class FreezeParams:
    """Фиксированные параметры исходной выдачи A: одни и те же для всех вопросов и повторов."""

    find_limit: int = 8
    read_top: int = 5
    read_chars: int = 2000
    corpus: str | None = None
    retrieve_use_case: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"find_limit": self.find_limit, "read_top": self.read_top,
                "read_chars": self.read_chars, "corpus": self.corpus,
                "retrieve_use_case": self.retrieve_use_case}

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> FreezeParams:
        return cls(find_limit=int(raw.get("find_limit", 8)), read_top=int(raw.get("read_top", 5)),
                   read_chars=int(raw.get("read_chars", 2000)), corpus=raw.get("corpus"),
                   retrieve_use_case=raw.get("retrieve_use_case"))


@dataclass
class Drift:
    """Отличие корпуса от заморозки: добавлено / удалено / изменено (пути vault)."""

    added: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)
    changed: list[str] = field(default_factory=list)

    def __bool__(self) -> bool:
        return bool(self.added or self.removed or self.changed)

    def summary(self, limit: int = 5) -> str:
        parts = []
        for name, items in (("добавлено", self.added), ("удалено", self.removed),
                            ("изменено", self.changed)):
            if items:
                shown = ", ".join(items[:limit]) + (f" ... (+{len(items) - limit})"
                                                    if len(items) > limit else "")
                parts.append(f"{name} {len(items)}: {shown}")
        return "; ".join(parts) or "отличий нет"


@dataclass
class Frozen:
    """Прочитанная заморозка."""

    directory: Path
    manifest: dict[str, Any]
    baseline: dict[str, Any]
    meta: dict[str, Any]

    @property
    def label(self) -> str:
        return str(self.manifest.get("label") or "")

    @property
    def params(self) -> FreezeParams:
        return FreezeParams.from_dict(self.manifest.get("params") or {})


@dataclass
class FreezeResult:
    status: str  # created | unchanged | replaced
    directory: Path
    manifest_hash: str
    baseline_hash: str
    files: int
    excluded: int
    questions: int
    missing_expected: list[tuple[str, str]] = field(default_factory=list)
    superseded: Path | None = None


# --------------------------------------------------------------------------- #
# Хэши и JSON                                                                    #
# --------------------------------------------------------------------------- #
def _canonical(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _hash(data: Any) -> str:
    return hashlib.sha256(_canonical(data).encode("utf-8")).hexdigest()


def _dump(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, indent=1) + "\n"


def safe_label(label: str) -> str:
    text = (label or "").strip()
    ok = bool(text) and len(text) <= 64 and all(
        ch.isalnum() or ch in "-_." for ch in text) and not text.startswith(".")
    if not ok:
        raise FreezeError(
            f"метка заморозки {label!r}: нужны буквы/цифры/-_. без пробелов и разделителей путей",
            CODE_BAD_LABEL)
    return text


# --------------------------------------------------------------------------- #
# Манифест корпуса                                                               #
# --------------------------------------------------------------------------- #
def _scope_union(cases: list[Case]) -> list[str]:
    return sorted({p for c in cases for p in c.scope})


def _entry(path: Path, rel: str) -> tuple[dict[str, Any] | None, dict[str, str] | None]:
    """Запись манифеста о файле либо ``(None, {path, reason})`` для исключенного."""
    raw = path.read_bytes()
    try:
        post = frontmatter.loads(raw.decode("utf-8"))
        fm = dict(post.metadata)
        parse_error = False
    except (ValueError, UnicodeDecodeError, TypeError):
        fm, parse_error = {}, True
    reason = exclusion_reason(rel, fm, source_path=str(fm.get("source_path") or ""))
    if reason:
        return None, {"path": rel, "reason": reason}
    entry: dict[str, Any] = {
        "path": rel, "sha256": hashlib.sha256(raw).hexdigest(), "size": len(raw),
        "note_id": str(fm.get("id") or ""), "corpus": str(fm.get("corpus") or "vault"),
        "version": str(fm.get("version") or ""), "modified": str(fm.get("modified") or ""),
    }
    if parse_error:
        entry["frontmatter_error"] = True
    return entry, None


def build_manifest(vault: Path, scope: list[str], *, label: str, qhash: str,
                   params: FreezeParams) -> dict[str, Any]:
    """Манифест разрешенного корпуса по объединению областей (детерминированный)."""
    from core.vault import iter_vault_paths

    vault = Path(vault)
    entries: list[dict[str, Any]] = []
    excluded: list[dict[str, str]] = []
    seen: set[str] = set()
    for path in iter_vault_paths(vault):
        rel = path.relative_to(vault).as_posix()
        if rel in seen or not scope_match(rel, scope) or any_nda(rel):
            continue
        seen.add(rel)
        entry, skipped = _entry(path, rel)
        if entry is not None:
            entries.append(entry)
        elif skipped is not None:
            excluded.append(skipped)
    entries.sort(key=lambda e: e["path"])
    excluded.sort(key=lambda e: e["path"])
    body = {
        "schema_version": FREEZE_SCHEMA, "label": label, "questions_hash": qhash,
        "scope": sorted(scope), "params": params.to_dict(),
        "files": entries, "excluded": excluded,
    }
    return {**body, "manifest_hash": _hash(body)}


def _manifest_body(manifest: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in manifest.items() if k != "manifest_hash"}


def _drift(old: dict[str, Any], new: dict[str, Any]) -> Drift:
    a = {e["path"]: e["sha256"] for e in old.get("files", [])}
    b = {e["path"]: e["sha256"] for e in new.get("files", [])}
    return Drift(
        added=sorted(set(b) - set(a)), removed=sorted(set(a) - set(b)),
        changed=sorted(p for p in set(a) & set(b) if a[p] != b[p]))


def verify_corpus(vault: Path, frozen: Frozen) -> Drift:
    """Сравнить корпус сейчас с заморозкой (область и параметры - из нее); пусто - не менялся."""
    m = frozen.manifest
    now = build_manifest(vault, list(m.get("scope") or []), label=frozen.label,
                         qhash=str(m.get("questions_hash") or ""), params=frozen.params)
    drift = _drift(m, now)
    if not drift and now["excluded"] != m.get("excluded"):
        drift.changed.append("(состав исключенных изменился)")
    return drift


def missing_expected_sources(
    control: ControlSet, manifest: dict[str, Any]) -> list[tuple[str, str]]:
    """Ожидаемые источники, которых нет в замороженном корпусе: ``(id случая, путь)``.

    Проверка разметки К. (опечатка, файл под ``_nda``/личным, источник вне vault). Результат
    НЕ сохраняется в заморозку: ожидаемые источники - часть контрольных ответов."""
    have = {e["path"] for e in manifest.get("files", [])}
    return [(c.id, e.source) for c in control.cases for e in c.expectations
            if e.source not in have]


# --------------------------------------------------------------------------- #
# Исходная выдача A                                                              #
# --------------------------------------------------------------------------- #
def _hit_in_scope(hit: dict[str, Any], scope: tuple[str, ...]) -> bool:
    return any(scope_match(str(hit.get(k) or ""), scope) for k in ("path", "source_path")
               if hit.get(k))


def _find_hits(
    tools: Any, case: Case, params: FreezeParams,
) -> tuple[list[dict[str, Any]], int, int, str]:
    """Топ ``find_limit`` внутри области: ``(хиты, вне области, nda, ошибка)``."""
    ask = min(max(params.find_limit * 3, params.find_limit), _MAX_FIND_LIMIT)
    kwargs: dict[str, Any] = {"query": case.question, "limit": ask}
    if params.corpus:
        kwargs["corpus"] = params.corpus
    try:
        out = tools.find_notes(**kwargs)
    except Exception as exc:  # noqa: BLE001 - сбой поиска виден в выдаче, заморозку не рвет
        return [], 0, 0, f"{type(exc).__name__}: {str(exc)[:120]}"
    notes = [n for n in (out.get("notes") if isinstance(out, dict) else None) or []
             if isinstance(n, dict)]
    hits: list[dict[str, Any]] = []
    outside = nda = 0
    for note in notes:
        if any_nda(note.get("path"), note.get("source_path")):
            nda += 1
        elif not _hit_in_scope(note, case.scope):
            outside += 1
        elif len(hits) < params.find_limit:
            hits.append({
                "rank": len(hits) + 1, "note_id": str(note.get("note_id") or ""),
                "path": str(note.get("path") or ""), "title": str(note.get("title") or ""),
                "score": round(float(note.get("score") or 0.0), 4),
                "matched_by": str(note.get("matched_by") or ""),
                "corpus": str(note.get("corpus") or ""), "date": str(note.get("date") or ""),
            })
    return hits, outside, nda, ""


def _attach_text(tools: Any, hits: list[dict[str, Any]], params: FreezeParams) -> None:
    for hit in hits[: params.read_top]:
        try:
            got = tools.read_note(path=hit["path"], max_chars=params.read_chars)
        except Exception as exc:  # noqa: BLE001 - нечитаемая заметка помечается, не валит заморозку
            hit["read_error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
            continue
        body = got.get("body") if isinstance(got, dict) else None
        hit["text"] = str(body or "")[: params.read_chars]
        hit["truncated"] = bool(isinstance(got, dict) and got.get("truncated"))


def _retrieve_hits(
    tools: Any, case: Case, params: FreezeParams,
) -> tuple[list[dict[str, Any]], str]:
    if not params.retrieve_use_case:
        return [], ""
    try:
        out = tools.retrieve(use_case_id=params.retrieve_use_case, query=case.question,
                             corpus=params.corpus or "both")
    except Exception as exc:  # noqa: BLE001
        return [], f"{type(exc).__name__}: {str(exc)[:120]}"
    rows: list[dict[str, Any]] = []
    for name in sorted((out.get("slices") or {}) if isinstance(out, dict) else {}):
        for hit in out["slices"][name] or []:
            if not isinstance(hit, dict) or any_nda(hit.get("source_path")):
                continue
            if not _hit_in_scope({"path": hit.get("source_path")}, case.scope):
                continue
            rows.append({"slice": name, "note_id": str(hit.get("note_id") or ""),
                         "source_path": str(hit.get("source_path") or ""),
                         "score": round(float(hit.get("score") or 0.0), 4),
                         "text": str(hit.get("preview") or "")})
    return rows, ""


def _baseline(tools: Any, control: ControlSet, params: FreezeParams, manifest: dict[str, Any],
              ) -> dict[str, Any]:
    cases: dict[str, Any] = {}
    for case in sorted(control.cases, key=lambda c: c.id):
        hits, outside, nda, error = _find_hits(tools, case, params)
        _attach_text(tools, hits, params)
        retrieved, rerror = _retrieve_hits(tools, case, params)
        cases[case.id] = {
            "question": case.question, "part": case.part, "scope": list(case.scope),
            "hits": hits, "retrieve": retrieved, "dropped_out_of_scope": outside,
            "dropped_nda": nda, **({"error": error} if error else {}),
            **({"retrieve_error": rerror} if rerror else {}),
        }
    body = {"schema_version": FREEZE_SCHEMA, "variant": "A", "label": manifest["label"],
            "questions_hash": manifest["questions_hash"],
            "manifest_hash": manifest["manifest_hash"],
            "params": params.to_dict(), "cases": cases}
    return {**body, "baseline_hash": _hash(body)}


# --------------------------------------------------------------------------- #
# Запись и чтение                                                                #
# --------------------------------------------------------------------------- #
def _read_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("ожидался JSON-объект")
    return data


def load_frozen(label_dir: Path) -> Frozen:
    """Прочитать заморозку; нет каталога/маркера/файла - :class:`FreezeError` с кодом."""
    label_dir = Path(label_dir)
    if not label_dir.is_dir():
        raise FreezeError(f"заморозки нет: {label_dir}", CODE_NOT_FOUND)
    if not (label_dir / META_FILE).is_file():
        raise FreezeError(f"заморозка не завершена (нет {META_FILE}): {label_dir}", CODE_INCOMPLETE)
    try:
        manifest = _read_json(label_dir / MANIFEST_FILE)
        baseline = _read_json(label_dir / BASELINE_FILE)
        meta = _read_json(label_dir / META_FILE)
    except (OSError, ValueError) as exc:
        raise FreezeError(f"заморозка не читается: {label_dir}: {exc}", CODE_INCOMPLETE) from exc
    if int(manifest.get("schema_version", 0)) > FREEZE_SCHEMA:
        raise FreezeError(
            f"заморозка новее поддерживаемой схемы ({manifest.get('schema_version')})", CODE_SCHEMA)
    return Frozen(label_dir, manifest, baseline, meta)


def _write_dir(target: Path, manifest: dict[str, Any], baseline: dict[str, Any],
               meta: dict[str, Any]) -> None:
    """Атомарно: временный каталог рядом, затем ``rename``; ``freeze.json`` - последним."""
    tmp = target.with_name(target.name + ".tmp")
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    try:
        (tmp / MANIFEST_FILE).write_text(_dump(manifest), encoding="utf-8")
        (tmp / BASELINE_FILE).write_text(_dump(baseline), encoding="utf-8")
        (tmp / META_FILE).write_text(_dump(meta), encoding="utf-8")
        os.replace(tmp, target)
    except BaseException:
        shutil.rmtree(tmp, ignore_errors=True)
        raise


def _supersede(target: Path) -> Path:
    n = 1
    while target.with_name(f"{target.name}.superseded-{n}").exists():
        n += 1
    dest = target.with_name(f"{target.name}.superseded-{n}")
    os.replace(target, dest)
    return dest


def freeze_corpus(
    control: ControlSet, vault: Path, tools: Any, *, label: str | None = None,
    root: Path | None = None, params: FreezeParams | None = None, force: bool = False,
    now: datetime | None = None, engine_version: str = "", allow_missing: bool = False,
) -> FreezeResult:
    """Заморозить корпус и исходную выдачу A. Повтор без изменений - ``unchanged``.

    ``root`` - корень заморозок (по умолчанию ``sleep_eval_dir()``); ``tools`` - объект с
    ``find_notes``/``read_note`` (и ``retrieve``, если задан сценарий). Ожидаемый источник вне
    корпуса (опечатка, ``_nda``, личное) - отказ ``freeze_missing_expected`` до записи, если не
    ``allow_missing``: замораживать набор с битой разметкой нельзя."""
    for name in ("find_notes", "read_note"):
        if not callable(getattr(tools, name, None)):
            raise FreezeError(f"нет инструмента {name} для исходной выдачи A", CODE_NO_TOOLS)
    params = params or FreezeParams()
    if params.retrieve_use_case and not callable(getattr(tools, "retrieve", None)):
        raise FreezeError("задан сценарий retrieve, но инструмента retrieve нет", CODE_NO_TOOLS)
    if root is None:
        from core.config import sleep_eval_dir

        root = sleep_eval_dir()
    name = safe_label(label or control.label or "")
    target = Path(root) / name
    manifest = build_manifest(Path(vault), _scope_union(control.cases), label=name,
                              qhash=questions_hash(control.cases), params=params)
    missing = missing_expected_sources(control, manifest)
    if missing and not allow_missing:
        shown = ", ".join(f"{cid}: {path}" for cid, path in missing[:5])
        raise FreezeError(
            f"ожидаемых источников вне разрешенного корпуса: {len(missing)} ({shown}"
            f"{' ...' if len(missing) > 5 else ''}); поправьте разметку или область",
            CODE_MISSING_EXPECTED)
    baseline = _baseline(tools, control, params, manifest)
    result = FreezeResult(
        status="created", directory=target, manifest_hash=manifest["manifest_hash"],
        baseline_hash=baseline["baseline_hash"], files=len(manifest["files"]),
        excluded=len(manifest["excluded"]), questions=len(control.cases), missing_expected=missing)

    superseded: Path | None = None
    if (target / META_FILE).is_file():
        old = load_frozen(target)
        same_manifest = old.manifest.get("manifest_hash") == manifest["manifest_hash"]
        same_baseline = old.baseline.get("baseline_hash") == baseline["baseline_hash"]
        if same_manifest and same_baseline:
            result.status = "unchanged"
            return result
        if not force:
            if not same_manifest:
                drift = _drift(old.manifest, manifest)
                raise FreezeError(
                    f"заморозка {name} уже есть и отличается ({drift.summary()}); "
                    "новая метка либо --force (прежняя уйдет в .superseded-N)",
                    CODE_EXISTS_DIFFERS, drift)
            raise FreezeError(
                f"корпус тот же, но исходная выдача A отличается (индекс/ранжирование изменились) "
                f"у заморозки {name}; новая метка либо --force", CODE_BASELINE_DRIFT)
        superseded = _supersede(target)
        result.status, result.superseded = "replaced", superseded
    elif target.exists():  # оборванная заморозка без маркера
        _supersede(target)
    meta = {
        "schema_version": FREEZE_SCHEMA, "label": name,
        "frozen_at": (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "engine_version": engine_version, "manifest_hash": manifest["manifest_hash"],
        "baseline_hash": baseline["baseline_hash"], "questions_hash": manifest["questions_hash"],
        "files": len(manifest["files"]), "excluded": len(manifest["excluded"]),
        "questions": len(control.cases),
    }
    Path(root).mkdir(parents=True, exist_ok=True)
    _write_dir(target, manifest, baseline, meta)
    return result
