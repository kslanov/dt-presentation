"""Readiness metadata passed by an interface before entering the synthesis boundary.

Answers stay in this package. Model packages cannot assert readiness.
"""

from __future__ import annotations

from pathlib import Path

from core.sleep_eval.label import status


def synthesis_readiness(vault=None, root=None):
    s = status(vault, root)
    control = s.get("control") or {}
    coverage = control.get("coverage") or {}
    ready = bool(control.get("valid") and coverage.get("ready") and s.get("frozen"))
    matching = False
    if ready:
        from core.config import default_vault_path, sleep_eval_dir
        from core.sleep_eval.control import control_path, load_control, questions_hash
        from core.sleep_eval.freeze import FreezeError, load_frozen, safe_label

        try:
            cs = load_control(control_path(vault or default_vault_path()))
            frozen = load_frozen(Path(root or sleep_eval_dir()) / safe_label(cs.label))
            matching = frozen.manifest["questions_hash"] == questions_hash(cs.cases)
        except (ValueError, OSError, FreezeError):
            matching = False
    return {
        "ok": True,
        "ready": ready and matching,
        "cases": control.get("cases", 0),
        "multi_source": coverage.get("multi_source", 0),
        "risky": coverage.get("risky", 0),
        "sha": control.get("sha", ""),
        "frozen": bool(s.get("frozen")),
        "hint": "Нужны 30 случаев, 10 многоисточниковых, 10 рискованных, обе части и заморозка",
    }
