"""SLEEP-PULT-1 п.6 - разметка контрольного набора из пульта: кандидаты, черновики ответов, запись.

Решение К. 15.11: набор размечается в пульте, а запись файла набора - по явному действию владельца.
Этот модуль - ЕДИНСТВЕННОЕ место записи ``vault/_system/eval/sleep-control.yaml`` (внутри пакета
``core.sleep_eval``; ограда SLEEP-EVAL-1 сохраняется: конвейер сна набор не читает, гард-тест видит
этот каталог как «свой»). Модель здесь не вызывается: черновик ответа кладет хост-сессия
(``suggest``), пульт модели не зовет.

Файлы (все под ``.derived/sleep/eval/``, пересобираемые, вне бэкапа vault):

* ``candidates.json`` - кандидаты (``dt sleep-eval draft``), читается здесь, не пишется;
* ``suggestions.json`` - черновики ответов хоста по ``cand_id`` (``{schema_version, suggestions}``);
* ``labels.json`` - отклоненные и отложенные кандидаты (``{schema_version, labels}``): повторный
  ``draft`` их не возвращает (``dt sleep-eval draft`` берет :func:`reviewed_ids`);
* ``control-history/`` - копия прежней версии набора перед каждой записью.

Запись набора (``decision=add``): случай собирается из правок владельца, ПРОВЕРЯЕТСЯ загрузчиком
набора (:func:`core.sleep_eval.control.parse_control`) вместе со всем файлом до записи, и пишется
штатным писателем (:mod:`core.note_writer`: атомарно, CAS по sha). Ожидаемый хэш файла - обязателен:
ручная правка между показом и записью дает ``conflict`` (ничего не записано). Замороженный набор -
``control_frozen`` (вопросы поменялись бы после заморозки). Случай несет ``происхождение``
(схема v1, необязательное поле): кандидат, был ли черновик модели, правил ли владелец. Его
считает движок, а не клиент: без черновика модели содержание целиком от владельца
(``правки_владельца: да``), с черновиком - ``да`` только если итог отличается от черновика.

Файл правят и вручную (Obsidian): экран перечитывает его на каждый показ. Комментарии и порядок
ключей сохраняются, когда ``случаи`` - последний ключ файла (допись в конец); иначе файл
пересобирается целиком (``rewritten: true``), прежняя версия остается в ``control-history/``.

Права: ``candidates``/``status`` - чтение; ``suggest`` пишет ``suggestions.json``; ``label`` пишет
``labels.json`` и/или набор. Токен записи требует фасад MCP для ``suggest`` и ``label``.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from core.file_lock import file_lock
from core.note_writer import NoteWriteError, read_sha, write_note_atomic
from core.privacy_scope import exclusion_reason
from core.sleep_eval import control as ctl
from core.sleep_eval.draft import CANDIDATES_FILE
from core.sleep_eval.fence import ControlAccessError, assert_control_allowed

__all__ = [
    "DECISIONS",
    "LABELS_FILE",
    "SUGGESTIONS_FILE",
    "candidates",
    "label",
    "reviewed_ids",
    "status",
    "suggest",
]

SUGGESTIONS_FILE = "suggestions.json"
LABELS_FILE = "labels.json"
HISTORY_DIR = "control-history"
SCHEMA = 1
DECISIONS = ("add", "reject", "defer", "restore")
DEFAULT_LABEL = "pilot-1"
_PREFIX = "_system/eval/"
_REL = ctl.CONTROL_REL.as_posix()
_MAX_CLAIMS, _MAX_CRITICAL = 8, 8
_MAX_TEXT, _MAX_QUESTION, _MAX_LOCATOR = 600, 500, 120
_SUGGEST_KEYS = {"question", "claims", "critical", "part", "scope", "note"}
_CASE_KEYS = {"id", "question", "part", "scope", "flags", "claims", "critical", "note",
              "prepared_revision", "source_hashes"}
_RU_PART = {ctl.PART_DEV: "разработка", ctl.PART_CONTROL: "контроль"}
_RU_FLAG = {ctl.FLAG_MULTI: "несколько_источников", ctl.FLAG_RISKY: "рискованный",
            ctl.FLAG_SINGLE: "один_документ"}
_RU_KIND = {ctl.KIND_NUMBER: "число", ctl.KIND_DATE: "дата", ctl.KIND_PERIOD: "период",
            ctl.KIND_EXCEPTION: "исключение", ctl.KIND_CONDITION: "условие"}
_RU_CRIT_KEY = {"value": "значение", "unit": "единица", "from": "с", "to": "по", "text": "текст",
                "markers": "маркеры"}
_CASE_ID_RE = re.compile(r"^c(\d+)$")
_CAND_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,80}$")


class LabelError(ValueError):
    """Отказ операции: ``code`` машинный; ``extra`` - то, чем продолжают работу."""

    def __init__(self, code: str, message: str, **extra: Any) -> None:
        super().__init__(message)
        self.code = code
        self.extra = extra

    def envelope(self) -> dict[str, Any]:
        return {"ok": False, "refused": True, "code": self.code,
                "error": f"{self.code}: {self}", **self.extra}


def _now(now: str = "") -> str:
    return now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _root(root: Path | None) -> Path:
    if root is not None:
        return Path(root)
    from core.config import sleep_eval_dir

    return sleep_eval_dir()


def _vault(vault: Path | None) -> Path:
    if vault is not None:
        return Path(vault)
    from core.config import default_vault_path

    return default_vault_path()


def _read_json(path: Path, key: str) -> dict[str, Any]:
    """Файл ``.derived``: нет/битый - пустой словарь по ключу (производные пересобираются)."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data.get(key, {}) if isinstance(data, dict) and isinstance(data.get(key), dict) else {}


def _write_json(path: Path, key: str, value: dict[str, Any], now: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    tmp = Path(name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(json.dumps({"schema_version": SCHEMA, "updated_at": now, key: value},
                                ensure_ascii=False, sort_keys=True, indent=1) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def reviewed_ids(root: Path | None = None) -> set[str]:
    """``cand_id`` отклоненных и отложенных владельцем: повторный ``draft`` их не возвращает."""
    return set(_read_json(_root(root) / LABELS_FILE, "labels"))


# --------------------------------------------------------------------------- #
# Чтение: набор, кандидаты                                                       #
# --------------------------------------------------------------------------- #
def _load_set(vault: Path) -> tuple[ctl.ControlSet | None, dict[str, Any]]:
    """Набор из файла и его описание для экрана: ``present``/``valid``/``sha``/коды отказа."""
    path = ctl.control_path(vault)
    info: dict[str, Any] = {"path": _REL, "present": path.is_file(), "valid": False, "sha": "",
                            "label": "", "cases": 0, "coverage": None, "warnings": []}
    if not info["present"]:
        info["valid"] = True  # файла нет - это начало разметки, не ошибка
        return None, info
    info["sha"] = read_sha(path) or ""
    try:
        cs = ctl.load_control(path)
    except ctl.SleepControlError as exc:
        info.update(code=exc.code, error=str(exc)[:400],
                    problems=[{"code": p.code, "where": p.where, "message": p.message}
                              for p in exc.problems][:20])
        return None, info
    info.update(valid=True, label=cs.label, cases=len(cs.cases),
                coverage=ctl.coverage(cs).to_dict(),
                warnings=[{"code": w.code, "where": w.where} for w in cs.warnings][:10])
    return cs, info


def _frozen(root: Path, label_name: str) -> dict[str, Any] | None:
    """Заморозка метки (``<root>/<метка>/freeze.json``) или ``None``."""
    from core.sleep_eval.freeze import FreezeError, load_frozen, safe_label

    try:
        frozen = load_frozen(root / safe_label(label_name))
    except FreezeError:
        return None
    meta = frozen.meta if isinstance(getattr(frozen, "meta", None), dict) else {}
    return {"label": label_name, "at": str(meta.get("frozen_at") or meta.get("created_at") or "")}


def _case_view(c: ctl.Case) -> dict[str, Any]:
    return {"case_id": c.id, "part": c.part, "question": c.question,
            "flags": sorted(c.flags), "sources": list(c.sources), "scope": list(c.scope),
            "claims": [{"claim": e.claim, "source": e.source, "locator": e.locator}
                       for e in c.expectations],
            "critical": [{"kind": x.kind, "label": x.label()} for x in c.critical],
            "origin": dict(c.origin), "note": c.note}


def _clean_candidates(raw: dict[str, Any]) -> tuple[list[dict[str, Any]], int]:
    """Кандидаты без ``_nda``/личного/карантина (по путям источников и сигналов) и их число."""
    out: list[dict[str, Any]] = []
    hidden = 0
    for cand in raw.get("candidates") or []:
        if not isinstance(cand, dict) or not _CAND_ID_RE.match(str(cand.get("cand_id") or "")):
            continue
        paths = [str(s.get("path") or "") for s in cand.get("sources") or [] if isinstance(s, dict)]
        paths += [str(s.get("path") or "") for s in cand.get("signals") or []
                  if isinstance(s, dict) and s.get("path")]
        if not paths or any(exclusion_reason(p) for p in paths):
            hidden += 1
            continue
        out.append(cand)
    return out, hidden


def _read_candidates(root: Path) -> dict[str, Any] | None:
    try:
        data = json.loads((root / CANDIDATES_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _public_candidate(cand: dict[str, Any], suggestion: dict[str, Any] | None) -> dict[str, Any]:
    out = {k: cand.get(k) for k in ("cand_id", "kind", "flags", "question_draft", "sources",
                                     "signals", "score", "already_labeled", "stats")
           if cand.get(k) is not None}
    if suggestion:
        out["suggestion"] = suggestion
    return out


def status(vault: Path | None = None, root: Path | None = None) -> dict[str, Any]:
    """Сводка разметки: файл набора (хэш, покрытие, заморозка), кандидаты, решения. Чтение."""
    assert_control_allowed()
    vault, root = _vault(vault), _root(root)
    cs, info = _load_set(vault)
    frozen = _frozen(root, info["label"] or DEFAULT_LABEL)
    raw = _read_candidates(root)
    labels = _read_json(root / LABELS_FILE, "labels")
    suggestions = _read_json(root / SUGGESTIONS_FILE, "suggestions")
    out: dict[str, Any] = {"ok": True, "control": info, "frozen": frozen,
                           "labels": {"rejected": sum(1 for v in labels.values()
                                                      if v.get("decision") == "reject"),
                                      "deferred": sum(1 for v in labels.values()
                                                      if v.get("decision") == "defer")},
                           "suggestions": len(suggestions),
                           "candidates": {"present": raw is not None}}
    if raw is not None:
        cands, hidden = _clean_candidates(raw)
        in_set = {str(c.origin.get("candidate") or "") for c in (cs.cases if cs else [])}
        pending = [c for c in cands if c["cand_id"] not in labels and c["cand_id"] not in in_set]
        out["candidates"].update(
            generated_at=raw.get("generated_at", ""), partial=bool(raw.get("partial")),
            counts=raw.get("counts") or {}, total=len(cands), pending=len(pending),
            hidden_private=hidden, warnings=list(raw.get("warnings") or [])[:5])
    return out


def candidates(vault: Path | None = None, root: Path | None = None, *,
               limit: int = 100) -> dict[str, Any]:
    """Очередь разметки: кандидаты без решения (с черновиком модели, если он есть), рассмотренные
    (отклоненные/отложенные) и случаи самого набора. Личное и ``_nda`` не показываются."""
    base = status(vault, root)
    vault, root = _vault(vault), _root(root)
    cs, _info = _load_set(vault)
    raw = _read_candidates(root)
    labels = _read_json(root / LABELS_FILE, "labels")
    suggestions = _read_json(root / SUGGESTIONS_FILE, "suggestions")
    in_set = {str(c.origin.get("candidate") or "") for c in (cs.cases if cs else [])}
    pending: list[dict[str, Any]] = []
    if raw is not None:
        cands, _hidden = _clean_candidates(raw)
        pending = [_public_candidate(c, suggestions.get(c["cand_id"])) for c in cands
                   if c["cand_id"] not in labels and c["cand_id"] not in in_set]
    reviewed = [{"cand_id": cid, **{k: v.get(k) for k in ("decision", "at", "reason", "host")},
                 "candidate": v.get("candidate") or {}}
                for cid, v in sorted(labels.items(), key=lambda kv: str(kv[1].get("at")),
                                     reverse=True)]
    from core.sleep_eval.prepared import check_sources, records
    from core.sleep_eval.revision import replacements, review_state

    materials = pending
    pending = []
    unavailable = 0
    superseded = replacements(root)
    for cid, cand in sorted(records(root).items(),
                            key=lambda kv: (kv[1]["prepared"]["batch_id"],
                                            kv[1]["prepared"].get("order", 0))):
        if cid in labels or cid in in_set or cid in superseded:
            continue
        try:
            sources = check_sources(cand, vault)
        except LabelError:
            # Private/unavailable content must not leak via a stale prepared snapshot.
            unavailable += 1
            continue
        pending.append({**cand, "sources": sources})
    n = max(1, int(limit))
    return {**base, "prepared_mode": True, "ready": pending[:n], "ready_total": len(pending),
            "review_state": review_state(vault, root),
            "ready_unavailable": unavailable,
            "materials": materials[:n],
            "materials_total": len(materials),
            "pending": materials[:n], "pending_total": len(materials), "reviewed": reviewed,
            "set_cases": [_case_view(c) for c in (cs.cases if cs else [])]}


# --------------------------------------------------------------------------- #
# Черновик ответа хоста                                                          #
# --------------------------------------------------------------------------- #
def _text(value: Any, where: str, limit: int, *, required: bool = False) -> str:
    text = " ".join(str(value or "").split())
    if required and not text:
        raise LabelError("suggestion_invalid", f"{where}: пусто")
    if len(text) > limit:
        raise LabelError("suggestion_invalid", f"{where}: длиннее {limit} знаков")
    return text


def _norm_claims(raw: Any, allowed: set[str] | None) -> list[dict[str, str]]:
    if raw is None:
        return []
    if not isinstance(raw, list) or len(raw) > _MAX_CLAIMS:
        raise LabelError("suggestion_invalid", f"claims: список до {_MAX_CLAIMS}")
    out = []
    for i, item in enumerate(raw, start=1):
        if not isinstance(item, dict) or set(item) - {"claim", "source", "locator"}:
            raise LabelError("suggestion_invalid", f"claims[{i}]: ключи claim, source, locator")
        source = ctl._clean_rel(item.get("source"))
        if source is None or exclusion_reason(source):
            raise LabelError("suggestion_invalid", f"claims[{i}].source: путь vault, не личное "
                             "и не _nda")
        if allowed is not None and source not in allowed:
            raise LabelError("source_not_in_candidate", f"claims[{i}].source {source!r}: нет среди "
                             "источников кандидата")
        out.append({"claim": _text(item.get("claim"), f"claims[{i}].claim", _MAX_TEXT,
                                   required=True),
                    "source": source,
                    "locator": _text(item.get("locator"), f"claims[{i}].locator", _MAX_LOCATOR)})
    return out


def _canon_critical(item: Any, where: str) -> dict[str, Any]:
    """Критическое условие в канонических ключах после проверки загрузчиком набора."""
    if not isinstance(item, dict):
        raise LabelError("suggestion_invalid", f"{where}: объект")
    canon: dict[str, Any] = {}
    for key, value in item.items():
        name = ctl._CRIT_KEYS.get(str(key).strip())
        if name is None:
            raise LabelError("suggestion_invalid", f"{where}: ключ {key!r}")
        canon[name] = value
    problems: list[ctl.Problem] = []
    parsed = ctl._norm_critical(item, where, problems)
    if parsed is None or problems:
        raise LabelError("suggestion_invalid", f"{where}: " + "; ".join(str(p) for p in problems),
                         problems=[{"code": p.code, "where": p.where, "message": p.message}
                                   for p in problems])
    out: dict[str, Any] = {"kind": parsed.kind}
    if parsed.kind in (ctl.KIND_NUMBER, ctl.KIND_DATE):
        out["value"] = parsed.value
        if parsed.unit:
            out["unit"] = parsed.unit
    elif parsed.kind == ctl.KIND_PERIOD:
        out["from"], out["to"] = str(canon.get("from") or ""), str(canon.get("to") or "")
    else:
        out["text"] = parsed.text
        if parsed.markers:
            out["markers"] = list(parsed.markers)
    return out


def _norm_critical_list(raw: Any) -> list[dict[str, Any]]:
    if raw is None:
        return []
    if not isinstance(raw, list) or len(raw) > _MAX_CRITICAL:
        raise LabelError("suggestion_invalid", f"critical: список до {_MAX_CRITICAL}")
    return [_canon_critical(x, f"critical[{i}]") for i, x in enumerate(raw, start=1)]


def _candidate(root: Path, cand_id: str) -> dict[str, Any]:
    from core.sleep_eval.prepared import records

    prepared = records(root).get(cand_id)
    if prepared is not None:
        return prepared
    raw = _read_candidates(root)
    cands, _hidden = _clean_candidates(raw) if raw is not None else ([], 0)
    cand = next((c for c in cands if c["cand_id"] == cand_id), None)
    if cand is None:
        raise LabelError("cand_not_found", f"кандидат {cand_id!r} не найден среди доступных: "
                         "повторите dt sleep-eval draft или проверьте идентификатор")
    return cand


def suggest(cand_id: str, suggestion: Any, *, host: str = "", root: Path | None = None,
            now: str = "") -> dict[str, Any]:
    """Положить черновик ответа хоста по кандидату (``suggestions.json``). Модель не вызывается.

    ``suggestion``: ``question``, ``claims`` [{claim, source, locator}] (источник - из источников
    кандидата), ``critical`` (условия как в наборе, ключи рус./англ.), необязательно ``part`` и
    ``scope``/``note``. Черновик показывается владельцу с пометкой «черновик модели»; в набор он
    попадает только действием владельца."""
    try:
        assert_control_allowed()
        root = _root(root)
        if not _CAND_ID_RE.match(str(cand_id or "")):
            raise LabelError("suggestion_invalid", "cand_id: идентификатор кандидата")
        if not isinstance(suggestion, dict) or set(suggestion) - _SUGGEST_KEYS:
            raise LabelError("suggestion_invalid", "suggestion: объект с ключами "
                             + ", ".join(sorted(_SUGGEST_KEYS)))
        cand = _candidate(root, str(cand_id))
        if cand.get("prepared"):
            raise LabelError("prepared_immutable",
                             "Подготовленный пакет неизменяем: создайте новую версию")
        sources = {str(s.get("path")) for s in cand.get("sources") or [] if isinstance(s, dict)}
        out: dict[str, Any] = {
            "question": _text(suggestion.get("question"), "question", _MAX_QUESTION),
            "claims": _norm_claims(suggestion.get("claims"), sources),
            "critical": _norm_critical_list(suggestion.get("critical")),
        }
        if suggestion.get("part") not in (None, ""):
            part = ctl._PARTS.get(str(suggestion["part"]).strip().lower())
            if part is None:
                raise LabelError("suggestion_invalid", "part: разработка | контроль")
            out["part"] = part
        if suggestion.get("scope") not in (None, ""):
            out["scope"] = _norm_scope(suggestion["scope"])
        if suggestion.get("note"):
            out["note"] = _text(suggestion["note"], "note", _MAX_TEXT)
        if not (out["question"] or out["claims"] or out["critical"]):
            raise LabelError("suggestion_invalid", "пустой черновик: нужен вопрос, утверждения "
                             "или условия")
        stamp = _now(now)
        out.update(at=stamp, host=str(host or "")[:40])
        with file_lock(root / SUGGESTIONS_FILE):
            store = _read_json(root / SUGGESTIONS_FILE, "suggestions")
            replaced = str(cand_id) in store
            store[str(cand_id)] = out
            _write_json(root / SUGGESTIONS_FILE, "suggestions", store, stamp)
        return {"ok": True, "cand_id": str(cand_id), "stored": True, "replaced": replaced,
                "claims": len(out["claims"]), "critical": len(out["critical"]),
                "note": "черновик модели: в набор попадет только после решения владельца"}
    except LabelError as exc:
        return exc.envelope()
    except ControlAccessError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc)}
    except OSError as exc:
        return {"ok": False, "refused": True, "code": "store_unavailable",
                "error": f"store_unavailable: черновик не записан ({type(exc).__name__})"}


def _norm_scope(raw: Any) -> list[str]:
    names = ctl._str_list(raw)
    if names is None:
        raise LabelError("case_invalid", "scope: список путей vault")
    out = []
    for name in names:
        clean = ctl._clean_rel(name)
        if clean is None or exclusion_reason(clean.rstrip("*/") or clean):
            raise LabelError("case_invalid", f"scope {name!r}: путь vault без .., не личное и "
                             "не _nda")
        out.append(clean)
    return out


# --------------------------------------------------------------------------- #
# Решение владельца: в набор / отклонить / отложить / вернуть                    #
# --------------------------------------------------------------------------- #
def _next_case_id(cs: ctl.ControlSet | None) -> str:
    nums = [int(m.group(1)) for c in (cs.cases if cs else [])
            if (m := _CASE_ID_RE.match(c.id))]
    return f"c{(max(nums) + 1) if nums else 1:03d}"


def _ru_critical(item: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {"тип": _RU_KIND[item["kind"]]}
    for key in ("value", "unit", "from", "to", "text", "markers"):
        if item.get(key) not in (None, "", []):
            out[_RU_CRIT_KEY[key]] = item[key]
    return out


def _build_case(payload: dict[str, Any], cand: dict[str, Any], cs: ctl.ControlSet | None,
                suggestion: dict[str, Any] | None, host: str, now: str) -> dict[str, Any]:
    unknown = sorted(set(payload) - _CASE_KEYS)
    if unknown:
        raise LabelError("case_invalid", f"case: неизвестные ключи {', '.join(unknown)}")
    question = _text(payload.get("question"), "question", _MAX_QUESTION, required=True)
    part = ctl._PARTS.get(str(payload.get("part") or "").strip().lower())
    if part is None:
        raise LabelError("case_invalid", "part: разработка | контроль (выбирает владелец)")
    sources = [str(s.get("path")) for s in cand.get("sources") or [] if isinstance(s, dict)]
    scope = _norm_scope(payload["scope"]) if payload.get("scope") else sources
    flags_in = payload.get("flags") if payload.get("flags") is not None else cand.get("flags")
    flags: list[str] = []
    for name in flags_in or []:
        canon = ctl._FLAGS.get(str(name).strip().lower())
        if canon is None:
            raise LabelError("case_invalid", f"flags: неизвестный признак {name!r}")
        flags.append(_RU_FLAG[canon])
    claims = _norm_claims(payload.get("claims"), None)
    critical = _norm_critical_list(payload.get("critical"))
    case_id = str(payload.get("id") or "").strip() or _next_case_id(cs)
    if cs is not None and cs.case(case_id) is not None:
        raise LabelError("case_exists", f"случай {case_id} уже есть в наборе")
    case: dict[str, Any] = {
        "id": case_id, "часть": _RU_PART[part], "вопрос": question, "область": scope,
        "признаки": list(dict.fromkeys(flags)),
        "ожидания": [{"утверждение": c["claim"], "источник": c["source"],
                      **({"локатор": c["locator"]} if c["locator"] else {})} for c in claims],
        "критические_условия": [_ru_critical(c) for c in critical],
    }
    if not case["признаки"]:
        del case["признаки"]
    if not case["критические_условия"]:
        del case["критические_условия"]
    note = " ".join(str(payload.get("note") or "").split())
    if note:
        case["заметка"] = note
    case["происхождение"] = _origin(cand, suggestion, question, claims, critical, host, now)
    return case


def _same_draft(suggestion: dict[str, Any], question: str, claims: list[dict[str, str]],
                critical: list[dict[str, Any]]) -> bool:
    return (" ".join(str(suggestion.get("question") or "").split()) == question
            and [dict(c) for c in suggestion.get("claims") or []] == claims
            and suggestion.get("critical") == critical)


def _origin(cand: dict[str, Any], suggestion: dict[str, Any] | None, question: str,
            claims: list[dict[str, str]], critical: list[dict[str, Any]], host: str,
            now: str) -> dict[str, Any]:
    drafted = suggestion is not None
    edited = (not _same_draft(suggestion, question, claims, critical)) if drafted else True
    return {"кандидат": cand["cand_id"], "черновик_модели": drafted, "правки_владельца": edited,
            **({"хост": str(suggestion.get("host") or "")} if drafted and suggestion.get("host")
               else {}),
            "дата": now[:10]}


def _compose(raw: str | None, case: dict[str, Any], label_name: str) -> tuple[str, bool]:
    """Новый текст файла набора и признак «пересобран целиком». Допись в конец сохраняет комментарии
    и порядок, пока ``случаи`` - последний ключ блочного файла."""
    block = yaml.safe_dump([case], allow_unicode=True, sort_keys=False,
                           default_flow_style=False, width=100)
    if raw is None:
        head = ("# Контрольный набор сна (SLEEP-EVAL-1). Размечается в пульте (Двойник / Сон / "
                "Контроль)\n# и вручную; движок пишет сюда только по действию владельца.\n")
        body = yaml.safe_dump({"версия_схемы": ctl.SCHEMA_VERSION, "метка": label_name},
                              allow_unicode=True, sort_keys=False)
        return head + body + "случаи:\n" + "".join(f"  {x}\n" for x in block.splitlines()), False
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError:
        data = None
    keys = [str(k) for k in data] if isinstance(data, dict) else []
    cases_key = next((k for k in keys if k in ("случаи", "cases")), "")
    lines = raw.splitlines()
    head_re = re.compile(rf"^{re.escape(cases_key)}:\s*(#.*)?$") if cases_key else None
    head_idx = next((i for i, ln in enumerate(lines) if head_re and head_re.match(ln)), -1)
    first_item = next((ln for ln in lines[head_idx + 1:] if ln.strip() and not ln.lstrip()
                       .startswith("#")), "") if head_idx >= 0 else ""
    m = re.match(r"^(\s*)-\s", first_item)
    if keys and keys[-1] == cases_key and head_idx >= 0 and m:
        pad = m.group(1)
        add = "".join(f"{pad}{x}\n" for x in block.splitlines())
        return (raw if raw.endswith("\n") else raw + "\n") + add, False
    dumped = dict(data) if isinstance(data, dict) else {}
    dumped.setdefault("версия_схемы", ctl.SCHEMA_VERSION)
    key = cases_key or "случаи"
    dumped[key] = [*(dumped.get(key) or []), case]
    return yaml.safe_dump(dumped, allow_unicode=True, sort_keys=False, width=100), True


def _problems(exc: ctl.SleepControlError) -> list[dict[str, str]]:
    return [{"code": p.code, "where": p.where, "message": p.message} for p in exc.problems][:30]


def _backup(root: Path, vault: Path, sha: str, stamp: str) -> str:
    src = ctl.control_path(vault)
    dest = root / HISTORY_DIR / f"{stamp.replace(':', '')}-{sha[:12]}.yaml"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(src.read_bytes())
    return dest.name


def _add(vault: Path, root: Path, cand: dict[str, Any], case_payload: Any,
         expected_hash: str | None, host: str, stamp: str) -> dict[str, Any]:
    if expected_hash is None:
        raise LabelError("expected_hash_required", "expected_hash обязателен: sha файла набора, "
                         "который вы видели (пустая строка - файла не было)")
    if not isinstance(case_payload, dict):
        raise LabelError("case_invalid", "case: нужен объект (вопрос, часть, область, утверждения)")
    target = ctl.control_path(vault)
    with file_lock(target):
        from core.sleep_eval.revision import ancestors, replacements

        if cand["cand_id"] in replacements(root):
            raise LabelError("prepared_superseded",
                             "Есть обновленная версия кейса; перечитайте экран")
        if cand.get("prepared"):
            from core.sleep_eval.prepared import check_sources

            if case_payload.get("prepared_revision") != cand["prepared_revision"]:
                raise LabelError("prepared_conflict",
                                 "Версия кейса не совпадает: перечитайте экран")
            check_sources(cand, vault)
        # Owner-added evidence is outside the initial model draft. Validate it too.
        from core.sleep_eval.prepared import _source

        original = {s["path"] for s in cand["sources"]}
        refs = case_payload.get("source_hashes") or {}
        if not isinstance(refs, dict):
            raise LabelError("case_invalid", "source_hashes: объект проверенных источников")
        added = []
        try:
            claims = _norm_claims(case_payload.get("claims"), None)
        except LabelError as exc:
            raise LabelError("case_invalid", str(exc), **exc.extra) from exc
        for claim in claims:
            path = claim["source"]
            if path in original:
                continue
            _data, sha = _source(vault, path)
            if refs.get(path) != sha:
                raise LabelError("sources_changed",
                                 "Проверьте добавленный источник перед принятием")
            added.append(path)
        case_payload = dict(case_payload)
        scope = _norm_scope(case_payload.get("scope") or list(original))
        case_payload["scope"] = list(dict.fromkeys([*scope, *added]))
        if added and len({c["source"] for c in claims}) > 1:
            flags = case_payload.get("flags", cand.get("flags", []))
            case_payload["flags"] = [f for f in flags
                                     if ctl._FLAGS.get(str(f)) != ctl.FLAG_SINGLE]
            if not any(ctl._FLAGS.get(str(f)) == ctl.FLAG_MULTI
                       for f in case_payload["flags"]):
                case_payload["flags"].append(ctl.FLAG_MULTI)
        current = read_sha(target) or ""
        if str(expected_hash) != current:
            raise LabelError("conflict", "файл набора изменен после показа (правка вне пульта): "
                             "перечитайте и повторите; ничего не записано", current_sha=current)
        cs: ctl.ControlSet | None = None
        raw_text: str | None = None
        if target.is_file():
            try:
                cs = ctl.load_control(target)
            except ctl.SleepControlError as exc:
                raise LabelError("control_invalid", "файл набора сейчас не проходит проверку: "
                                 "исправьте его (Obsidian) и повторите", problems=_problems(exc),
                                 control_code=exc.code) from exc
            raw_text = target.read_text(encoding="utf-8")
        label_name = (cs.label if cs and cs.label else DEFAULT_LABEL)
        frozen = _frozen(root, label_name)
        if frozen is not None:
            raise LabelError("control_frozen", f"набор заморожен ({label_name}): новые вопросы "
                             "сбили бы исходную выдачу A; новая заморозка - "
                             "dt sleep-eval freeze --force", frozen=frozen)
        suggestion = (cand.get("suggestion") or
                      _read_json(root / SUGGESTIONS_FILE, "suggestions").get(cand["cand_id"]))
        previous_id = cand.get("prepared", {}).get("replaces")
        previous_ids = ancestors(root, previous_id) if previous_id else set()
        previous = (next((c for c in (cs.cases if cs else [])
                          if c.origin.get("candidate") in previous_ids), None)
                    if previous_id else None)
        build_set = cs
        if previous is not None:
            from dataclasses import replace
            build_set = replace(cs, cases=[c for c in cs.cases if c.id != previous.id])
            case_payload = {**case_payload, "id": previous.id}
        try:
            case = _build_case(case_payload, cand, build_set, suggestion, host, stamp)
        except LabelError as exc:
            if exc.code != "suggestion_invalid":
                raise
            raise LabelError("case_invalid", str(exc), **exc.extra) from exc
        if previous is not None:
            data = yaml.safe_load(raw_text)
            key = next(k for k in data if k in ("cases", "случаи"))
            data[key] = [case if str(item.get("id")) == previous.id else item
                         for item in data[key]]
            text = yaml.safe_dump(data, allow_unicode=True, sort_keys=False, width=100)
            rewritten = True
        else:
            text, rewritten = _compose(raw_text, case, label_name)
        try:
            parsed = ctl.parse_control(text.encode("utf-8"), target)
        except ctl.SleepControlError as exc:
            raise LabelError("case_invalid", "случай не проходит проверку набора: "
                             + "; ".join(str(p) for p in exc.problems)[:600],
                             problems=_problems(exc)) from exc
        saved_case = parsed.case(case["id"])
        if saved_case is None:  # страховка: проверка прошла, а случая в наборе нет - не пишем
            raise LabelError("case_invalid", "случай не найден в проверенном наборе")
        backup = _backup(root, vault, current, stamp) if current else ""
        try:
            receipt = write_note_atomic(vault, _REL, text, expect_sha=current or None, now=stamp,
                                        allowed_prefix=_PREFIX)
        except NoteWriteError as exc:
            code = "conflict" if exc.code == "cas_mismatch" else f"control_{exc.code}"
            raise LabelError(code, str(exc), current_sha=exc.current_sha or "") from exc
        labels = _read_json(root / LABELS_FILE, "labels")
        if labels.pop(cand["cand_id"], None) is not None:  # отложенный кандидат ушел в набор
            _write_json(root / LABELS_FILE, "labels", labels, stamp)
        return {"ok": True, "decision": "add", "saved": True, "case_id": case["id"],
                "sha": receipt["sha_after"], "previous_sha": receipt["sha_before"] or "",
                "created": bool(receipt["created"]), "rewritten": rewritten, "backup": backup,
                "origin": dict(saved_case.origin), "path": _REL,
                "coverage": ctl.coverage(parsed).to_dict(), "cases": len(parsed.cases),
                "warnings": [{"code": w.code, "where": w.where} for w in parsed.warnings][:10]}


def label(cand_id: str, decision: str, *, case: Any = None, expected_hash: str | None = None,
          reason: str = "", host: str = "", vault: Path | None = None, root: Path | None = None,
          now: str = "") -> dict[str, Any]:
    """Решение владельца по кандидату: ``add`` (в набор, с правками), ``reject``, ``defer``,
    ``restore`` (вернуть рассмотренного в очередь). Запись набора - см. модуль."""
    try:
        assert_control_allowed()
        vault, root = _vault(vault), _root(root)
        if decision not in DECISIONS:
            raise LabelError("bad_decision", f"decision: допустимо {', '.join(DECISIONS)}")
        stamp = _now(now)
        with file_lock(root / LABELS_FILE):
            labels = _read_json(root / LABELS_FILE, "labels")
            if decision == "restore":
                if labels.pop(str(cand_id), None) is None:
                    raise LabelError("cand_not_found", f"среди рассмотренных {cand_id!r} нет")
                _write_json(root / LABELS_FILE, "labels", labels, stamp)
                return {"ok": True, "decision": "restore", "cand_id": str(cand_id),
                        "restored": True}
            cand = _candidate(root, str(cand_id))
            if decision == "add":
                return _add(vault, root, cand, case, expected_hash, host, stamp)
            labels[cand["cand_id"]] = {
                "decision": decision, "at": stamp, "host": str(host or "")[:40],
                "reason": _text(reason, "reason", 300),
                "candidate": {k: cand.get(k) for k in ("kind", "flags", "question_draft", "sources",
                                                        "score") if cand.get(k) is not None}}
            _write_json(root / LABELS_FILE, "labels", labels, stamp)
            return {"ok": True, "decision": decision, "cand_id": cand["cand_id"], "saved": True,
                    "note": "в набор не записано; повторный draft этого кандидата не вернет"}
    except LabelError as exc:
        return exc.envelope()
    except ControlAccessError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc)}
    except OSError as exc:
        return {"ok": False, "refused": True, "code": "store_unavailable",
                "error": f"store_unavailable: запись не выполнена ({type(exc).__name__})"}
