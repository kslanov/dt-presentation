"""Small, evidence-backed review batches. No model calls and no control-set writes.

The host selects real tasks and reads their sources, then submits drafts here.
The owner alone accepts them through label.add. Raw draft_candidates are materials,
not an owner assignment queue. Business content stays in the instance, outside Git.
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from core.file_lock import file_lock
from core.privacy_scope import exclusion_reason
from core.retrieval.find import read_full_note
from core.sleep.validate import contains_secret
from core.sleep_eval.fence import ControlAccessError, assert_control_allowed

FILE = "prepared.json"


def source_preview(reference: str, *, vault: Path | None = None) -> dict:
    """Resolve a source independently of the initial candidate; never write a case."""
    from core.sleep_eval import label as lb
    from core.vault import resolve_note_path

    try:
        assert_control_allowed()
        vault = lb._vault(vault).resolve()
        path = resolve_note_path(reference, vault_path=vault)
        if path is None or not path.resolve().is_relative_to(vault):
            raise lb.LabelError("source_unavailable", "Источник не найден в DT")
        relative = path.resolve().relative_to(vault).as_posix()
        data, sha = _source(vault, relative)
        excerpt = data["body"][-5000:]
        if contains_secret(excerpt):
            excerpt = "Фрагмент скрыт: обнаружены секреты."
        return {"ok": True, "path": relative, "title": _title(data, relative),
                "sha256": sha, "excerpt": excerpt}
    except lb.LabelError as exc:
        return exc.envelope()
    except ControlAccessError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}
    except (OSError, ValueError):
        return {"ok": False, "code": "source_unavailable", "error": "Источник недоступен"}


def _digest(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True).encode()
    ).hexdigest()


def _source(vault: Path, path: str) -> tuple[dict, str]:
    from core.sleep_eval.label import LabelError

    assert_control_allowed()
    target = (vault / path).resolve()
    if (
        not path.endswith(".md")
        or Path(path).is_absolute()
        or ".." in Path(path).parts
        or exclusion_reason(path)
        or not target.is_relative_to(vault.resolve())
    ):
        raise LabelError("source_unavailable", "Источник недоступен для подготовки")
    try:
        before = hashlib.sha256(target.read_bytes()).hexdigest()
        data = read_full_note(path, vault_path=vault, max_chars=1_000_000, messages="all")
        sha = hashlib.sha256(target.read_bytes()).hexdigest()
    except (OSError, ValueError) as exc:
        raise LabelError("source_unavailable", "Источник не прочитан или исключен") from exc
    fm = data.get("frontmatter") or {}
    if exclusion_reason(path, fm, source_path=str(fm.get("source_path") or "")):
        raise LabelError("source_unavailable", "Источник исключен правилами приватности")
    if sha != before:
        raise LabelError("sources_changed", "Источник изменился во время чтения")
    if contains_secret(str(fm.get("title") or "")):
        raise LabelError("source_unavailable", "Название источника содержит секреты")
    return data, sha


def records(root: Path) -> dict[str, Any]:
    from core.sleep_eval.label import LabelError

    assert_control_allowed()
    path = root / FILE
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        cases = data["cases"]
        if not isinstance(cases, dict) or any(not isinstance(v, dict) for v in cases.values()):
            raise ValueError("cases")
        return cases
    except (ValueError, KeyError, TypeError) as exc:
        raise LabelError(
            "prepared_invalid_store", "Хранилище кейсов повреждено; запись отменена"
        ) from exc


def _title(data: dict, path: str) -> str:
    title = data.get("frontmatter", {}).get("title")
    if not title:
        match = re.search(r"(?m)^Тред:\s*(.+)$|^#\s+(.+)$", data.get("body") or "")
        title = next((x for x in match.groups() if x), "") if match else path
    return path if contains_secret(str(title)) else str(title)[:500]


def _batch_content(cases: dict) -> dict:
    # Display titles can improve without changing an immutable draft or its revision.
    return {cid: {**{k: v for k, v in c.items()
                    if k not in {"prepared_revision", "sources"}},
                  "sources": [{k: v for k, v in s.items() if k != "title"}
                              for s in c["sources"]]}
            for cid, c in cases.items()}


def check_sources(cand: dict, vault: Path) -> list[dict]:
    from core.sleep_eval.label import LabelError

    result = []
    for source in cand["sources"]:
        data, sha = _source(vault, source["path"])
        if sha != source["sha256"]:
            raise LabelError("sources_changed", "Источник изменился: кейс нужно подготовить заново")
        result.append({**source, "title": _title(data, source["path"])})
    return result


def prepare(
    package: Any,
    *,
    vault: Path | None = None,
    root: Path | None = None,
    host: str = "",
    now: str = "",
) -> dict[str, Any]:
    from core.sleep_eval import label as lb

    try:
        assert_control_allowed()
        vault, root = lb._vault(vault), lb._root(root)
        if not isinstance(package, dict) or set(package) != {"batch_id", "model", "cases"}:
            raise lb.LabelError("prepared_invalid", "Нужны batch_id, model, cases")
        batch = lb._text(package["batch_id"], "batch_id", 80, required=True)
        model = lb._text(package["model"], "model", 80, required=True)
        items = package["cases"]
        if not isinstance(items, list) or not 1 <= len(items) <= 5:
            raise lb.LabelError("prepared_invalid", "Пакет: от одного до пяти кейсов")
        if contains_secret(json.dumps(package, ensure_ascii=False)):
            raise lb.LabelError("prepared_invalid", "В пакете обнаружены секреты")
        previous_risk = {
            c["question_draft"]: "risky" in c["flags"]
            for c in records(root).values()
            if c["prepared"]["batch_id"] == batch
        }
        staged: dict[str, dict] = {}
        cache: dict[str, tuple[dict, str]] = {}
        stamp = lb._now(now)
        for index, item in enumerate(items):
            keys = {"question", "task", "why", "as_of", "claims", "critical", "note"}
            if (not isinstance(item, dict) or not keys <= set(item)
                    or set(item) - keys - {"risky"}):
                raise lb.LabelError(
                    "prepared_invalid", "Кейс: question, task, why, as_of, claims, critical, note"
                )
            # New drafts are ordinary unless declared risky. Existing immutable
            # batches retain their original classification on a legacy replay.
            risky = item.get("risky", previous_risk.get(str(item["question"]), False))
            if not isinstance(risky, bool):
                raise lb.LabelError("prepared_invalid", "risky: логическое значение")
            text = {
                k: lb._text(item[k], k, 600, required=True)
                for k in ("task", "why", "as_of", "note")
            }
            question = lb._text(item["question"], "question", 500, required=True)
            raw = item["claims"]
            if not isinstance(raw, list) or not 1 <= len(raw) <= 8:
                raise lb.LabelError("prepared_invalid", "Нужны 1–8 утверждений с цитатами")
            claims, evidence, sources = [], [], {}
            for claim in raw:
                if not isinstance(claim, dict) or set(claim) != {
                    "claim",
                    "source",
                    "locator",
                    "quote",
                }:
                    raise lb.LabelError(
                        "prepared_invalid", "Утверждение: claim, source, locator, quote"
                    )
                normal = lb._norm_claims(
                    [{k: claim[k] for k in ("claim", "source", "locator")}], None
                )[0]
                path = normal["source"]
                if path not in cache:
                    cache[path] = _source(vault, path)
                data, sha = cache[path]
                quote = lb._text(claim["quote"], "quote", 1200, required=True)
                if len(quote) < 20 or quote not in " ".join(data["body"].split()):
                    raise lb.LabelError(
                        "quote_not_found", "Цитата не найдена в прочитанном источнике"
                    )
                claims.append(normal)
                evidence.append({**normal, "quote": quote})
                sources[path] = {
                    "path": path,
                    "sha256": sha,
                    "title": _title(data, path),
                    "date": str(
                        data.get("frontmatter", {}).get("modified")
                        or data.get("frontmatter", {}).get("created")
                        or ""
                    )[:10],
                }
            critical = lb._norm_critical_list(item["critical"])
            if not critical:
                raise lb.LabelError("prepared_invalid", "Укажите важные условия и ограничения")
            cid = "prepared-" + _digest([batch, question])[:24]
            if cid in staged:
                raise lb.LabelError("prepared_invalid", "Повтор вопроса в пакете")
            suggestion = {
                "question": question,
                "claims": claims,
                "critical": critical,
                "part": "development",
                "scope": list(sources),
                "note": text["note"],
                "host": host[:40],
                "model": model,
            }
            cand = {
                "cand_id": cid,
                "kind": "prepared",
                "question_draft": question,
                "flags": (["multi_source" if len(sources) > 1 else "single_doc"]
                          + (["risky"] if risky else [])),
                "sources": list(sources.values()),
                "suggestion": suggestion,
                "prepared": {
                    **text,
                    "evidence": evidence,
                    "batch_id": batch,
                    "order": index,
                    "model": model,
                    "host": host[:40],
                },
            }
            cand["prepared_revision"] = _digest(cand)
            staged[cid] = cand
        with file_lock(root / FILE):
            current = records(root)
            old_batch = {
                k: v for k, v in current.items() if v.get("prepared", {}).get("batch_id") == batch
            }
            if old_batch and _batch_content(old_batch) != _batch_content(staged):
                raise lb.LabelError(
                    "batch_conflict", "Пакет уже существует; используйте новую метку пакета"
                )
            # All-or-nothing: no partial batch when any source/quote is invalid.
            if not old_batch:
                lb._write_json(root / FILE, "cases", {**current, **staged}, stamp)
        return {
            "ok": True,
            "prepared": len(staged),
            "ids": list(staged),
            "replayed": bool(old_batch),
            "control_written": False,
        }
    except lb.LabelError as exc:
        return exc.envelope()
    except ControlAccessError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}
    except (OSError, ValueError) as exc:
        return {"ok": False, "code": "prepared_unavailable", "error": type(exc).__name__}
