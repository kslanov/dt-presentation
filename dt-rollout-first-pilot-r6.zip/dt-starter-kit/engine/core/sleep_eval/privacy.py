"""SLEEP-EVAL-1 - что не попадает ни в заморозку корпуса, ни в кандидаты для разметки.

Предикат один на всех потребителей рабочего сна и живет в нейтральном :mod:`core.privacy_scope`
(реестр входов SLEEP-INPUT-1 берет его оттуда, не из пакета оценки: конвейер сна не импортирует
контрольные ответы). Здесь - прежние имена для заморозки и кандидатов оценки.
"""

from __future__ import annotations

from core.privacy_scope import (
    REASON_NDA,
    REASON_PERSONAL,
    REASON_QUARANTINE,
    exclusion_reason,
)

__all__ = ["REASON_NDA", "REASON_PERSONAL", "REASON_QUARANTINE", "exclusion_reason"]
