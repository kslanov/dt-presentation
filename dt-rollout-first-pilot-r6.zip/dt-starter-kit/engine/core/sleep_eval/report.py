"""SLEEP-EVAL-1 п.3 - отчет по воротам §11 по прогонам A/B/C/D (таблица, отрицательные результаты).

Сравнение выполняется при приемке слоев (B - SYNTH, C - WIKI, D - CONTEXT); сводный отчет A/B/C/D
обязателен до включения расписания. Здесь - детерминированная сборка отчета из сохраненных прогонов
(:mod:`core.sleep_eval.runner`), без модели:

* прогоны сопоставимы только при одинаковых метке, вопросах, корпусе, модели, шаблоне промпта,
  бюджете, части и числе повторов - иначе строки варианта ``incomparable`` с перечнем отличий;
* строки ворот - ровно таблица §11: утечка/запись без решения/гонка, неподтвержденное как
  проверенное, повторы/восстановление, качество ответа, польза представлений (+ вопросы по одному
  документу), экономика, карточки. Что раннер измерить не может (приемочные сценарии, четыре недели
  очереди), показано как ``not_measured`` с указанием, где это измеряется - не как «пройдено»;
* ``fail`` и «не окупается» сохраняются в отрицательных результатах; неизвестная стоимость -
  «неизвестна», не ноль; один повтор - «предварительно».

``blockers`` - что мешает включить расписание: любая строка варианта B/C/D не в статусе ``pass``/
``reported``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from core.sleep_eval.runner import RunResult, summarize

__all__ = ["GateRow", "GateReport", "VariantReport", "build_report", "format_report",
           "report_json"]

PASS, FAIL = "pass", "fail"
NOT_MEASURED, NOT_APPLICABLE = "not_measured", "not_applicable"
UNAVAILABLE, BASELINE, PENDING = "unavailable", "baseline", "pending"
REPORTED, INCOMPARABLE = "reported", "incomparable"
_OK_FOR_SCHEDULE = {PASS, REPORTED, NOT_APPLICABLE, BASELINE}
_LABELS = {
    PASS: "пройдено", FAIL: "ПРОВАЛ", NOT_MEASURED: "не измерено", NOT_APPLICABLE: "не применимо",
    UNAVAILABLE: "недоступно", BASELINE: "базовая линия", PENDING: "ждет решения человека",
    REPORTED: "посчитано", INCOMPARABLE: "несопоставимо",
}
G_LEAK = "Утечка, запись без решения, потеря при гонке"
G_UNVERIFIED = "Неподтвержденное выдано проверенным"
G_RECOVERY = "Повторы/восстановление"
G_QUALITY = "Качество ответа"
G_USEFUL = "Польза представлений"
G_SINGLE = "Вопросы по одному документу"
G_ECON = "Экономика"
G_CARDS = "Карточки"
USEFUL_TOKEN_SAVING = 0.15  # §11: минимум 15% меньше медианных токенов при том же качестве


@dataclass
class GateRow:
    gate: str
    status: str
    detail: str = ""

    @property
    def negative(self) -> bool:
        return self.status == FAIL or "НЕ ОКУПАЕТСЯ" in self.detail


@dataclass
class VariantReport:
    variant: str
    run_id: str
    status: str
    rows: list[GateRow] = field(default_factory=list)
    incomparable: list[str] = field(default_factory=list)
    summary: dict[str, Any] | None = None
    reason: str = ""


@dataclass
class GateReport:
    label: str
    part: str
    variants: list[VariantReport]
    blockers: list[str]
    notes: list[str]
    questions_per_month: float | None = None


# --------------------------------------------------------------------------- #
# Сопоставимость                                                                #
# --------------------------------------------------------------------------- #
_SAME = (("label", "метка заморозки"), ("part", "часть"), ("repeats", "число повторов"),
         ("model", "модель"), ("prompt_hash", "шаблон промпта"), ("budget", "бюджет"),
         ("questions_hash", "вопросы"), ("manifest_hash", "корпус"))


def _incomparable(base: RunResult, other: RunResult) -> list[str]:
    return [f"{title}: {getattr(base, key)!r} против {getattr(other, key)!r}"
            for key, title in _SAME if getattr(base, key) != getattr(other, key)]


# --------------------------------------------------------------------------- #
# Строки                                                                         #
# --------------------------------------------------------------------------- #
def _f(value: Any, unit: str = "") -> str:
    return "неизвестно" if value is None else f"{value:g}{unit}"


def _prelim(s: dict[str, Any]) -> str:
    return " (предварительно: 1 повтор, вариативность не оценена)" if s["preliminary"] else ""


def _measured_rows(s: dict[str, Any]) -> list[GateRow]:
    leaks = s["out_of_scope_citations"]
    row = GateRow(G_LEAK, FAIL if leaks else PASS,
                  (f"ссылок вне области/под _nda: {leaks}" if leaks
                   else "ссылок вне области и под _nda в ответах нет") +
                  "; запись без решения и потери при гонке - приемочные сценарии SLEEP-STORE/"
                  "SYNTH (12-14), раннером не измеряются")
    return [row]


def _baseline_quality(s: dict[str, Any]) -> GateRow:
    return GateRow(
        G_QUALITY, BASELINE,
        f"критических случаев {s['critical_cases']}, провалено {s['critical_fail']}, ждут решения "
        f"{s['critical_pending']}, потеряно условий {s['lost_conditions']}; полный успех "
        f"{s['quality_pass']}/{s['cases']}; источники {_f(s['source_recall'])}, локаторы "
        f"{_f(s['locator_recall'])}; нестабильных случаев {s['flaky_cases']}{_prelim(s)}")


def _quality_row(a: dict[str, Any], x: dict[str, Any]) -> GateRow:
    a_ok = {r["case_id"] for r in a["per_case"] if not r["critical_fail"]}
    regress = sorted(r["case_id"] for r in x["per_case"]
                     if r["critical_fail"] and r["case_id"] in a_ok)
    fail = x["lost_conditions"] > 0 or x["critical_fail"] > 0 or bool(regress)
    detail = (f"потеряно условий {x['lost_conditions']} (у A {a['lost_conditions']}), критических "
              f"провалов {x['critical_fail']} (у A {a['critical_fail']})"
              + (f"; регрессии относительно A: {', '.join(regress)}" if regress else ""))
    if fail:
        return GateRow(G_QUALITY, FAIL, detail + _prelim(x))
    if x["critical_pending"]:
        return GateRow(G_QUALITY, PENDING,
                       f"{x['critical_pending']} случаев ждут решения человека по смысловым "
                       f"условиям (human.json); детерминированных потерь нет{_prelim(x)}")
    return GateRow(G_QUALITY, PASS, detail + _prelim(x))


def _useful_rows(a: dict[str, Any], x: dict[str, Any], quality: GateRow) -> list[GateRow]:
    better = (x["multi_completeness"] is not None and a["multi_completeness"] is not None
              and x["multi_completeness"] > a["multi_completeness"])
    t_a, t_x = a["tokens_median"], x["tokens_median"]
    saving = (None if t_a is None or t_x is None or t_a == 0 else round(1 - t_x / t_a, 4))
    cheaper = saving is not None and saving >= USEFUL_TOKEN_SAVING
    text = (f"полнота по нескольким источникам: {_f(x['multi_completeness'])} против "
            f"{_f(a['multi_completeness'])} у A ({x['multi_cases']} случаев); медианные токены: "
            f"{_f(t_x)} против {_f(t_a)}"
            + (f" (экономия {saving:.0%}, порог {USEFUL_TOKEN_SAVING:.0%})"
               if saving is not None else " (токены неизвестны - экономию не оценить)"))
    ok = (better or cheaper) and quality.status != FAIL
    rows = [GateRow(G_USEFUL, PASS if ok else FAIL,
                    text + ("" if ok else "; ни полноты, ни 15% экономии при том же качестве")
                    + _prelim(x))]
    if x["single_doc_cases"] == 0 or a["single_doc_cases"] == 0:
        rows.append(GateRow(G_SINGLE, NOT_MEASURED,
                            "нет вопросов по одному документу в выбранной части (§11: проверить "
                            "отдельно, дополнительная память может мешать)"))
    else:
        r_x = x["single_doc_pass"] / x["single_doc_cases"]
        r_a = a["single_doc_pass"] / a["single_doc_cases"]
        rows.append(GateRow(
            G_SINGLE, PASS if r_x >= r_a else FAIL,
            f"полный успех {x['single_doc_pass']}/{x['single_doc_cases']} против "
            f"{a['single_doc_pass']}/{a['single_doc_cases']} у A{_prelim(x)}"))
    return rows


def _answer_cost(s: dict[str, Any]) -> tuple[float | None, str]:
    n = max(s["cases"] * s["repeats"], 1)
    if s["cost_total"] is not None:
        return s["cost_total"] / n, f"стоимость{(' ' + s['currency']) if s['currency'] else ''}"
    if s["tokens_total"] is not None:
        return s["tokens_total"] / n, "токены"
    return None, ""


def _econ_baseline(s: dict[str, Any]) -> GateRow:
    cost = ("неизвестна" if s["cost_total"] is None
            else f"{s['cost_total']:g}{(' ' + s['currency']) if s['currency'] else ''}")
    return GateRow(G_ECON, BASELINE,
                   f"токены всего {_f(s['tokens_total'])}, медиана на случай "
                   f"{_f(s['tokens_median'])}; время {_f(s['seconds_total'], ' с')}; "
                   f"стоимость {cost} (ответов без стоимости {s['cost_unknown_answers']}); "
                   f"издержек создания памяти нет{_prelim(s)}")


def _memory_total(run: RunResult, basis: str) -> float | None:
    if run.memory_cost is None:
        return None
    parts = [run.memory_cost.creation]
    if basis.startswith("токены"):
        values = [p.tokens for p in parts]
    else:
        values = [p.cost for p in parts]
    return None if any(v is None for v in values) else float(sum(values))  # type: ignore[arg-type]


def _econ_row(a: dict[str, Any], x: dict[str, Any], run: RunResult,
              per_month: float | None) -> GateRow:
    ca, basis_a = _answer_cost(a)
    cx, basis_x = _answer_cost(x)
    cost = "неизвестна" if x["cost_total"] is None else f"{x['cost_total']:g}"
    head = (f"токены всего {_f(x['tokens_total'])}, время {_f(x['seconds_total'], ' с')}, "
            f"стоимость {cost}")
    if ca is None or cx is None or basis_a != basis_x:
        return GateRow(G_ECON, REPORTED,
                       head + "; стоимость/токены неизвестны у A или варианта - точка окупаемости "
                       "не посчитана (неизвестно, не «не окупается»)")
    creation = _memory_total(run, basis_x)
    if creation is None:
        return GateRow(G_ECON, REPORTED,
                       head + f"; издержки создания памяти ({basis_x}) неизвестны - окупаемость "
                       "не посчитана")
    saving = ca - cx
    if saving <= 0:
        return GateRow(G_ECON, REPORTED,
                       head + f"; выгода на ответ {saving:g} ({basis_x}): НЕ ОКУПАЕТСЯ")
    points = creation / saving
    tail = (f"; окупаемость {points:.1f} вопросов ({basis_x}: создание {creation:g}, выгода "
            f"{saving:g} на ответ)")
    if per_month:
        tail += f", при {per_month:g} вопросов в месяц - {points / per_month:.1f} мес."
    else:
        tail += "; частота вопросов не задана - срок не посчитан"
    return GateRow(G_ECON, REPORTED, head + tail)


def _static_rows(variant: str) -> list[GateRow]:
    base = variant == "A"
    return [
        GateRow(G_UNVERIFIED, NOT_APPLICABLE if base else NOT_MEASURED,
                "у A нет слоя принятого" if base else
                "0 на размеченном пилоте, гипотезы отделены: проверяется при приемке слоя"),
        GateRow(G_RECOVERY, NOT_MEASURED,
                "сценарии 9-14 приемки: без дубля, потери и скрытого частичного принятия"),
        GateRow(G_CARDS, NOT_MEASURED,
                "четыре недели: принятые/отклоненные, дубли, нерешенные, запас - SLEEP-LOOP-1"),
    ]


def _order(rows: list[GateRow]) -> list[GateRow]:
    order = [G_LEAK, G_UNVERIFIED, G_RECOVERY, G_QUALITY, G_USEFUL, G_SINGLE, G_ECON, G_CARDS]
    return sorted(rows, key=lambda r: order.index(r.gate))


def _variant_report(run: RunResult, base_run: RunResult | None, per_month: float | None,
                    ) -> VariantReport:
    rep = VariantReport(run.variant, run.run_id, run.status, reason=run.reason)
    if run.status != "done":
        rep.rows = [GateRow(g, UNAVAILABLE, run.reason) for g in (
            G_LEAK, G_UNVERIFIED, G_RECOVERY, G_QUALITY, G_USEFUL, G_SINGLE, G_ECON, G_CARDS)]
        return rep
    s = summarize(run)
    rep.summary = s
    rows = _static_rows(run.variant) + _measured_rows(s)
    if run.variant == "A":
        rows += [_baseline_quality(s), GateRow(G_USEFUL, NOT_APPLICABLE, "эталон сравнения"),
                 _econ_baseline(s)]
        rep.rows = _order(rows)
        return rep
    if base_run is None or base_run.status != "done":
        rep.incomparable = ["нет выполненного прогона A: сравнивать не с чем"]
    else:
        rep.incomparable = _incomparable(base_run, run)
    if rep.incomparable:
        rep.rows = [GateRow(g, INCOMPARABLE, "; ".join(rep.incomparable)) for g in (
            G_LEAK, G_UNVERIFIED, G_RECOVERY, G_QUALITY, G_USEFUL, G_SINGLE, G_ECON, G_CARDS)]
        return rep
    assert base_run is not None  # noqa: S101
    a = summarize(base_run)
    quality = _quality_row(a, s)
    rows += [quality, *_useful_rows(a, s, quality), _econ_row(a, s, run, per_month)]
    rep.rows = _order(rows)
    return rep


def build_report(runs: dict[str, RunResult], *, questions_per_month: float | None = None,
                 ) -> GateReport:
    """Отчет по воротам из прогонов ``{вариант: прогон}`` (A - база сравнения)."""
    if not runs:
        return GateReport("", "", [], ["нет прогонов"], [], questions_per_month)
    base = runs.get("A")
    first = base or next(iter(runs.values()))
    variants = [_variant_report(runs[v], base, questions_per_month)
                for v in ("A", "B", "C", "D") if v in runs]
    missing = [v for v in ("A", "B", "C", "D") if v not in runs]
    blockers: list[str] = [f"вариант {v}: прогона нет" for v in missing]
    for vr in variants:
        if vr.variant == "A":
            continue
        blockers += [f"{vr.variant} - {r.gate}: {_LABELS[r.status]}" for r in vr.rows
                     if r.status not in _OK_FOR_SCHEDULE]
    notes: list[str] = []
    for run in runs.values():
        notes += [f"{run.run_id}: {n}" for n in run.notes]
        if run.status == "done" and summarize(run)["preliminary"]:
            notes.append(f"{run.run_id}: 1 повтор - правило трех повторов не выполнено, "
                         "вердикты предварительные")
    return GateReport(first.label, first.part, variants, blockers, notes, questions_per_month)


# --------------------------------------------------------------------------- #
# Вывод                                                                          #
# --------------------------------------------------------------------------- #
def _cell(text: str) -> str:
    return text.replace("|", "/").replace("\n", " ")


def format_report(report: GateReport) -> str:
    """Таблица ворот §11 по вариантам + отрицательные результаты + блокеры расписания."""
    lines = [f"# Отчет по воротам SLEEP-EVAL-1 - метка {report.label or '-'}, часть "
             f"{report.part or '-'}", ""]
    for vr in report.variants:
        head = f"## Вариант {vr.variant} (прогон {vr.run_id}) - "
        head += "недоступно" if vr.status != "done" else "выполнен"
        lines += [head, ""]
        if vr.reason:
            lines += [vr.reason, ""]
        lines += ["| Критерий | Статус | Данные |", "|---|---|---|"]
        lines += [f"| {r.gate} | {_LABELS[r.status]} | {_cell(r.detail)} |" for r in vr.rows]
        lines.append("")
    negatives = [(vr.variant, r) for vr in report.variants for r in vr.rows if r.negative]
    lines += ["## Отрицательные результаты", ""]
    lines += ([f"- {v} - {r.gate}: {_cell(r.detail)}" for v, r in negatives]
              or ["- отрицательных результатов нет (не означает прохождения: см. «не измерено»)"])
    lines += ["", "## Блокирует включение расписания", ""]
    lines += [f"- {b}" for b in report.blockers] or ["- блокеров нет"]
    if report.notes:
        lines += ["", "## Заметки", ""] + [f"- {n}" for n in report.notes]
    return "\n".join(lines) + "\n"


def report_json(report: GateReport) -> dict[str, Any]:
    return {
        "label": report.label, "part": report.part,
        "questions_per_month": report.questions_per_month,
        "variants": [{
            "variant": v.variant, "run_id": v.run_id, "status": v.status, "reason": v.reason,
            "incomparable": v.incomparable,
            "rows": [{"gate": r.gate, "status": r.status, "detail": r.detail,
                      "negative": r.negative} for r in v.rows],
            "summary": ({k: val for k, val in v.summary.items() if k != "per_case"}
                        if v.summary else None)} for v in report.variants],
        "blockers": report.blockers, "notes": report.notes,
        "schedule_blocked": bool(report.blockers),
    }
