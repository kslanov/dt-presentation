"""Version prepared drafts without changing owner decisions or the accepted set."""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

from core.file_lock import file_lock
from core.note_writer import read_sha
from core.sleep_eval import label as lb
from core.sleep_eval import prepared as prep
from core.sleep_eval.fence import ControlAccessError, assert_control_allowed


def review_state(vault: Path, root: Path) -> str:
    assert_control_allowed()
    return prep._digest(
        [
            read_sha(p) or ""
            for p in (
                lb.ctl.control_path(vault),
                root / prep.FILE,
                root / lb.LABELS_FILE,
                root / lb.SUGGESTIONS_FILE,
            )
        ]
    )


def replacements(root: Path) -> dict[str, str]:
    return {
        str(c["prepared"]["replaces"]): cid
        for cid, c in prep.records(root).items()
        if c.get("prepared", {}).get("replaces")
    }


def ancestors(root: Path, cid: str) -> set[str]:
    records, seen = prep.records(root), set()
    while cid and cid not in seen:
        seen.add(cid)
        cid = records.get(cid, {}).get("prepared", {}).get("replaces", "")
    return seen


def refresh(
    package: Any,
    *,
    vault: Path | None = None,
    root: Path | None = None,
    host: str = "",
    now: str = "",
) -> dict:
    """Validate a whole replacement batch, CAS the review state, preserve all labels.

    replaces follows cases order. Previous drafts remain immutable; their replacement
    must be reviewed explicitly. Accepted cases are replaced only by label/add later.
    """
    try:
        assert_control_allowed()
        vault, root = lb._vault(vault), lb._root(root)
        keys = {"batch_id", "model", "cases", "replaces", "expected_state"}
        if not isinstance(package, dict) or set(package) != keys:
            raise lb.LabelError(
                "refresh_invalid", "Нужны batch_id, model, cases, replaces, expected_state"
            )
        old_ids = package["replaces"]
        if (
            not isinstance(old_ids, list)
            or not isinstance(package["cases"], list)
            or len(old_ids) != len(package["cases"])
            or any(not isinstance(x, str) for x in old_ids)
            or len(set(old_ids)) != len(old_ids)
        ):
            raise lb.LabelError("refresh_invalid", "replaces: разные id для каждого кейса")
        request_hash = prep._digest({k: v for k, v in package.items() if k != "expected_state"})
        with tempfile.TemporaryDirectory(prefix="dt-case-refresh-") as box:
            result = prep.prepare(
                {k: package[k] for k in ("batch_id", "model", "cases")},
                vault=vault,
                root=Path(box),
                host=host,
                now=now,
            )
            if not result.get("ok"):
                return result
            fresh = prep.records(Path(box))
        # Same order as label/add: decisions, accepted file, prepared registry.
        with (
            file_lock(root / lb.LABELS_FILE),
            file_lock(lb.ctl.control_path(vault)),
            file_lock(root / prep.FILE),
        ):
            current = prep.records(root)
            existing = {
                cid: c
                for cid, c in current.items()
                if c["prepared"].get("batch_id") == package["batch_id"]
            }
            if existing:
                if len(existing) == len(fresh) and all(
                    c["prepared"].get("refresh_request") == request_hash for c in existing.values()
                ):
                    return {
                        "ok": True,
                        "replayed": True,
                        "ids": list(existing),
                        "control_written": False,
                    }
                raise lb.LabelError("batch_conflict", "Метка пакета уже занята")
            if not package["expected_state"] or package["expected_state"] != review_state(
                vault, root
            ):
                raise lb.LabelError(
                    "review_conflict", "Разметка изменилась; перечитайте ее перед обновлением"
                )
            superseded = replacements(root)
            cs, info = lb._load_set(vault)
            if not info["valid"]:
                raise lb.LabelError("control_invalid", "Принятый набор требует проверки")
            if lb._frozen(root, info["label"] or lb.DEFAULT_LABEL):
                raise lb.LabelError("control_frozen", "Замороженный набор не обновляется")
            labels = lb._read_json(root / lb.LABELS_FILE, "labels")
            mapping = {}
            for cid, previous in zip(result["ids"], old_ids, strict=True):
                if previous not in current or previous in superseded:
                    raise lb.LabelError(
                        "refresh_invalid", "Прежний кейс отсутствует или уже обновлен"
                    )
                previous_ids = ancestors(root, previous)
                accepted = next(
                    (
                        c
                        for c in (cs.cases if cs else [])
                        if c.origin.get("candidate") in previous_ids
                    ),
                    None,
                )
                decision = {"decision": labels.get(previous, {}).get("decision", "pending")}
                if accepted:
                    decision = {
                        "decision": "accepted",
                        "case_id": accepted.id,
                        "owner_edited": bool(accepted.origin.get("owner_edited")),
                    }
                    fresh[cid]["suggestion"]["part"] = accepted.part
                fresh[cid]["prepared"].update(
                    replaces=previous, previous_review=decision, refresh_request=request_hash
                )
                fresh[cid]["prepared_revision"] = prep._digest(
                    {k: v for k, v in fresh[cid].items() if k != "prepared_revision"}
                )
                mapping[previous] = cid
            lb._write_json(root / prep.FILE, "cases", {**current, **fresh}, lb._now(now))
        return {
            "ok": True,
            "replayed": False,
            "ids": result["ids"],
            "replaced": mapping,
            "control_written": False,
            "decisions_preserved": True,
        }
    except lb.LabelError as exc:
        return exc.envelope()
    except ControlAccessError as exc:
        return {"ok": False, "code": exc.code, "error": str(exc)}
    except OSError:
        return {"ok": False, "code": "store_unavailable", "error": "Обновление не записано"}
