"""SLEEP-EVAL-1 п.3 - раннер A/B/C/D: одинаковые корпус, модель, формулировка, инструменты, бюджет.

``run_variant`` прогоняет вариант на ЗАМОРОЖЕННОЙ выдаче (:mod:`core.sleep_eval.freeze`): вариант A
берет контекст из ``baseline-A.json``, а не из живого индекса; общий шаблон промпта и бюджет
(:class:`Budget`) одинаковы для всех вариантов, отличается только материал. Модель не вызывается:
ответчик (:data:`Answerer`) приходит параметром - в тестах подделка, в боевом прогоне функция
``--answerer модуль:функция`` либо записанные ответы (:class:`RecordedAnswerer`).

* **Варианты.** A - текущий RAG (замороженная выдача). B (RAG + принятое), C (RAG + вики), D (C +
  компактный контекст) - слои SYNTH/WIKI/CONTEXT: пока не реализованы, провайдер возвращает честное
  ``недоступно: слой не реализован``; прогон сохраняется со статусом ``unavailable`` (отрицательный
  результат не теряется). Слой при приемке регистрирует провайдера (:func:`register_provider`).
* **Повторы.** ``repeats`` 1 или 3 (правило трех повторов): вариативность оценивается только при 3;
  вердикт по случаю - пессимистичный (все повторы), расхождение повторов - ``flaky``.
* **Разработка/контроль.** Метод правят на части ``разработка``; ``контроль`` открывается только с
  ``final=True`` и каждое вскрытие учитывается (повторное - заметка о подгонке).
* **Учет.** Токены, время, стоимость (известна/неизвестна: ``None`` не равен нулю) по каждому
  ответу; издержки создания памяти слоя (:class:`MemoryCost`) отдельно от издержек ответа.
* **Человек.** Смысловые условия (исключения/условия) ждут решения в ``human.json`` прогона
  (:func:`set_verdict`); без решения они ``pending``, а не ``ok``.

Модуль чистый по отношению к модели и сети; пишет только в каталог заморозки (``runs/``,
``runs.jsonl``).
"""

from __future__ import annotations

import hashlib
import importlib
import json
import statistics
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.sleep_eval.control import PART_CONTROL, PART_DEV, Case, ControlSet, questions_hash
from core.sleep_eval.freeze import Frozen, verify_corpus
from core.sleep_eval.score import (
    ST_HUMAN,
    ST_LOST,
    ST_OK,
    Answer,
    CaseScore,
    Citation,
    CriticalResult,
    ExpectationResult,
    score_answer,
)

__all__ = [
    "PROMPT_TEMPLATE",
    "RUN_SCHEMA",
    "VARIANTS",
    "Answerer",
    "AnswerRequest",
    "BaselineProvider",
    "Budget",
    "CaseRun",
    "MaterialItem",
    "MemoryCost",
    "Provider",
    "RecordedAnswerer",
    "RepeatResult",
    "RunError",
    "RunResult",
    "UnavailableProvider",
    "Usage",
    "build_prompt",
    "get_provider",
    "import_answerer",
    "list_runs",
    "load_run",
    "register_provider",
    "run_variant",
    "set_verdict",
    "summarize",
]

RUN_SCHEMA = 1
VARIANTS = ("A", "B", "C", "D")

PROMPT_TEMPLATE = """\
Ответь на вопрос только по приведенным материалам, не используя знания вне них.
Сохрани числа, единицы, периоды, налоговое основание (с НДС или без) и исключения как в источнике.
Если в материалах нет ответа - скажи об этом прямо; предположение не выдавай за факт.
После ответа перечисли использованные источники отдельными строками в формате:
Источник: <путь из заголовка материала> | <локатор: страница, пункт, лист или ячейка>

Вопрос: {question}

Материалы:
{materials}
"""
PROMPT_HASH = hashlib.sha256(PROMPT_TEMPLATE.encode("utf-8")).hexdigest()[:12]

CODE_BAD_VARIANT = "run_bad_variant"
CODE_BAD_REPEATS = "run_bad_repeats"
CODE_BAD_PART = "run_bad_part"
CODE_CONTROL_CLOSED = "run_control_part_closed"
CODE_STALE_QUESTIONS = "run_freeze_stale_questions"
CODE_CORPUS_CHANGED = "run_corpus_changed"
CODE_NO_CASES = "run_no_cases"
CODE_NOT_FOUND = "run_not_found"


class RunError(RuntimeError):
    """Прогон не начат/не прочитан. ``code`` - машинный."""

    def __init__(self, message: str, code: str) -> None:
        super().__init__(message)
        self.code = code


# --------------------------------------------------------------------------- #
# Данные                                                                        #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Budget:
    """Бюджет задачи - ОДИН на все варианты: объем материала и потолок ответа."""

    max_context_chars: int = 12000
    max_answer_tokens: int = 1024

    def to_dict(self) -> dict[str, int]:
        return {"max_context_chars": self.max_context_chars,
                "max_answer_tokens": self.max_answer_tokens}


@dataclass(frozen=True)
class MaterialItem:
    path: str
    text: str
    note_id: str = ""
    title: str = ""
    truncated: bool = False


@dataclass(frozen=True)
class AnswerRequest:
    """Что видит ответчик: вопрос, промпт, материал, бюджет. Ожиданий и разметки тут нет."""

    variant: str
    case_id: str
    question: str
    prompt: str
    material: tuple[MaterialItem, ...]
    repeat: int
    budget: Budget


Answerer = Callable[[AnswerRequest], Answer]


@dataclass(frozen=True)
class Usage:
    """Учет одного ответа/слоя. ``None`` - неизвестно (не ноль)."""

    tokens_in: int | None = None
    tokens_out: int | None = None
    seconds: float | None = None
    cost: float | None = None
    currency: str = ""

    @property
    def tokens(self) -> int | None:
        if self.tokens_in is None or self.tokens_out is None:
            return None
        return self.tokens_in + self.tokens_out

    def to_dict(self) -> dict[str, Any]:
        return {"tokens_in": self.tokens_in, "tokens_out": self.tokens_out,
                "seconds": self.seconds, "cost": self.cost, "currency": self.currency}

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> Usage:
        return cls(raw.get("tokens_in"), raw.get("tokens_out"), raw.get("seconds"),
                   raw.get("cost"), str(raw.get("currency") or ""))


@dataclass(frozen=True)
class MemoryCost:
    """Издержки создания и обслуживания памяти слоя - отдельно от издержек ответа."""

    creation: Usage = field(default_factory=lambda: Usage(0, 0, 0.0, 0.0))
    maintenance: Usage = field(default_factory=lambda: Usage(0, 0, 0.0, 0.0))

    def to_dict(self) -> dict[str, Any]:
        return {"creation": self.creation.to_dict(), "maintenance": self.maintenance.to_dict()}

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> MemoryCost:
        return cls(Usage.from_dict(raw.get("creation") or {}),
                   Usage.from_dict(raw.get("maintenance") or {}))


@dataclass
class RepeatResult:
    repeat: int
    status: str  # answered | error
    usage: Usage = field(default_factory=Usage)
    score: CaseScore | None = None
    error: str = ""
    material_paths: list[str] = field(default_factory=list)
    material_truncated: int = 0
    answer_chars: int = 0


@dataclass
class CaseRun:
    case_id: str
    part: str
    flags: list[str]
    critical: bool
    repeats: list[RepeatResult] = field(default_factory=list)


@dataclass
class RunResult:
    run_id: str
    variant: str
    status: str  # done | unavailable
    part: str
    final: bool
    repeats: int
    label: str
    ts: str
    model: str = ""
    reason: str = ""
    prompt_hash: str = PROMPT_HASH
    budget: Budget = field(default_factory=Budget)
    questions_hash: str = ""
    manifest_hash: str = ""
    baseline_hash: str = ""
    cases: list[CaseRun] = field(default_factory=list)
    memory_cost: MemoryCost | None = None
    control_opens: int = 0
    notes: list[str] = field(default_factory=list)
    directory: Path | None = None


# --------------------------------------------------------------------------- #
# Промпт                                                                         #
# --------------------------------------------------------------------------- #
def build_prompt(question: str, items: Iterable[MaterialItem], budget: Budget,
                 ) -> tuple[str, tuple[MaterialItem, ...], int]:
    """Общий для всех вариантов промпт: ``(текст, материал в пределах бюджета, обрезано)``."""
    used = 0
    kept: list[MaterialItem] = []
    cut = 0
    blocks: list[str] = []
    for n, item in enumerate(items, start=1):
        room = budget.max_context_chars - used
        if room <= 0:
            cut += 1
            continue
        text = item.text
        truncated = item.truncated
        if len(text) > room:
            text, truncated = text[:room], True
            cut += 1
        used += len(text)
        kept.append(replace(item, text=text, truncated=truncated))
        mark = " [обрезано]" if truncated else ""
        blocks.append(f"### Материал {n}: {item.path}{mark}\n{text}")
    prompt = PROMPT_TEMPLATE.format(question=question, materials="\n\n".join(blocks) or "(нет)")
    return prompt, tuple(kept), cut


# --------------------------------------------------------------------------- #
# Провайдеры вариантов                                                           #
# --------------------------------------------------------------------------- #
class Provider:
    """Вариант A/B/C/D: что он дает ответчику и сколько стоит его память."""

    name = ""

    def availability(self) -> tuple[bool, str]:
        return True, ""

    def material(self, case_id: str, frozen: Frozen) -> tuple[list[MaterialItem], dict[str, str]]:
        raise NotImplementedError

    def memory_cost(self) -> MemoryCost | None:
        return None


class UnavailableProvider(Provider):
    """Слой не реализован: честное «недоступно», а не пустой или выдуманный результат."""

    def __init__(self, name: str, package: str, what: str) -> None:
        self.name, self.package, self.what = name, package, what

    def availability(self) -> tuple[bool, str]:
        return False, f"недоступно: слой не реализован ({self.package}: {self.what})"


class BaselineProvider(Provider):
    """Вариант A: замороженная выдача текущего RAG; своей памяти нет (издержки известны: 0)."""

    name = "A"

    def material(self, case_id: str, frozen: Frozen) -> tuple[list[MaterialItem], dict[str, str]]:
        entry = (frozen.baseline.get("cases") or {}).get(case_id) or {}
        items: list[MaterialItem] = []
        aliases: dict[str, str] = {}
        seen: set[str] = set()
        for hit in entry.get("hits") or []:
            if hit.get("note_id"):
                aliases[str(hit["note_id"])] = str(hit["path"])
            if hit.get("text") and hit["path"] not in seen:
                seen.add(hit["path"])
                items.append(MaterialItem(
                    path=hit["path"], text=hit["text"], note_id=str(hit.get("note_id") or ""),
                    title=str(hit.get("title") or ""), truncated=bool(hit.get("truncated"))))
        for row in entry.get("retrieve") or []:
            path = str(row.get("source_path") or "")
            if path and row.get("text") and path not in seen:
                seen.add(path)
                items.append(MaterialItem(path=path, text=row["text"],
                                          note_id=str(row.get("note_id") or ""), truncated=True))
                if row.get("note_id"):
                    aliases[str(row["note_id"])] = path
        return items, aliases

    def memory_cost(self) -> MemoryCost:
        return MemoryCost()


PROVIDERS: dict[str, Provider] = {
    "A": BaselineProvider(),
    "B": UnavailableProvider("B", "SLEEP-SYNTH-1", "RAG + принятое"),
    "C": UnavailableProvider("C", "SLEEP-WIKI-1", "RAG + вики"),
    "D": UnavailableProvider("D", "SLEEP-CONTEXT-1", "C + компактный контекст"),
}


def register_provider(provider: Provider) -> None:
    """Слой при приемке подключает свой вариант (B/C/D) вместо заглушки."""
    if provider.name not in VARIANTS:
        raise RunError(f"неизвестный вариант {provider.name!r}", CODE_BAD_VARIANT)
    PROVIDERS[provider.name] = provider


def get_provider(variant: str) -> Provider:
    if variant not in PROVIDERS:
        raise RunError(
            f"вариант {variant!r}: нужен один из {', '.join(VARIANTS)}", CODE_BAD_VARIANT)
    return PROVIDERS[variant]


# --------------------------------------------------------------------------- #
# Ответчики                                                                      #
# --------------------------------------------------------------------------- #
class RecordedAnswerer:
    """Готовые ответы из JSON: ``{"model": ..., "answers": {id случая: [ответ на повтор 1, ...]}}``.

    Ответ - ``{text, citations: [{source, locator}], tokens_in, tokens_out, seconds, cost}``;
    ответов на повтор нет - ошибка этого повтора (не молчаливая подстановка)."""

    def __init__(self, path: Path) -> None:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        self.model = str(data.get("model") or "")
        self._answers: dict[str, list[dict[str, Any]]] = data.get("answers") or {}

    def __call__(self, req: AnswerRequest) -> Answer:
        rows = self._answers.get(req.case_id) or []
        if req.repeat > len(rows):
            raise LookupError(f"нет записанного ответа: случай {req.case_id}, повтор {req.repeat}")
        row = rows[req.repeat - 1]
        return Answer(
            text=str(row.get("text") or ""),
            citations=tuple(Citation(str(c.get("source") or ""), str(c.get("locator") or ""))
                            for c in row.get("citations") or []),
            tokens_in=row.get("tokens_in"), tokens_out=row.get("tokens_out"),
            seconds=row.get("seconds"), cost=row.get("cost"),
            currency=str(row.get("currency") or ""))


def import_answerer(spec: str) -> Answerer:
    """Ответчик из ``модуль:функция`` (боевой хост подключается так; в движок не вшит)."""
    module_name, _, attr = spec.partition(":")
    if not module_name or not attr:
        raise RunError(f"ответчик {spec!r}: нужен вид модуль:функция", CODE_BAD_VARIANT)
    func = getattr(importlib.import_module(module_name), attr)
    if not callable(func):
        raise RunError(f"ответчик {spec!r}: не вызываемый", CODE_BAD_VARIANT)
    return func  # type: ignore[no-any-return]


# --------------------------------------------------------------------------- #
# Хранилище прогонов                                                             #
# --------------------------------------------------------------------------- #
def _runs_dir(frozen: Frozen) -> Path:
    return frozen.directory / "runs"


def _ledger(frozen: Frozen) -> Path:
    return frozen.directory / "runs.jsonl"


def _ledger_rows(frozen: Frozen) -> list[dict[str, Any]]:
    path = _ledger(frozen)
    if not path.is_file():
        return []
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def list_runs(frozen: Frozen) -> list[str]:
    return sorted(p.name for p in _runs_dir(frozen).glob("*") if (p / "run.json").is_file()) \
        if _runs_dir(frozen).is_dir() else []


def _next_run_id(frozen: Frozen, variant: str, part: str) -> str:
    n = sum(1 for r in list_runs(frozen) if r.startswith(f"{variant}-{part}-")) + 1
    return f"{variant}-{part}-{n:03d}"


def _case_to_dict(c: CaseRun) -> dict[str, Any]:
    return {
        "case_id": c.case_id, "part": c.part, "flags": c.flags, "critical": c.critical,
        "repeats": [{
            "repeat": r.repeat, "status": r.status, "error": r.error, "usage": r.usage.to_dict(),
            "material_paths": r.material_paths, "material_truncated": r.material_truncated,
            "answer_chars": r.answer_chars,
            "score": r.score.to_dict() if r.score else None} for r in c.repeats]}


def _score_from_dict(raw: dict[str, Any]) -> CaseScore:
    score = CaseScore(str(raw["case_id"]))
    score.criticals = [CriticalResult(c["kind"], c["label"], c["status"], c.get("detail", ""),
                                      bool(c.get("deterministic", True)))
                       for c in raw.get("criticals") or []]
    score.expectations = [ExpectationResult(e["source"], e["locator"], e["source_status"],
                                            e["locator_status"])
                          for e in raw.get("expectations") or []]
    score.unseen = list(raw.get("unseen") or [])
    score.out_of_scope = list(raw.get("out_of_scope") or [])
    return score


def _run_to_dict(run: RunResult) -> dict[str, Any]:
    return {
        "schema_version": RUN_SCHEMA, "run_id": run.run_id, "variant": run.variant,
        "status": run.status, "reason": run.reason, "part": run.part, "final": run.final,
        "repeats": run.repeats, "label": run.label, "ts": run.ts, "model": run.model,
        "prompt_hash": run.prompt_hash, "budget": run.budget.to_dict(),
        "questions_hash": run.questions_hash, "manifest_hash": run.manifest_hash,
        "baseline_hash": run.baseline_hash, "control_opens": run.control_opens,
        "notes": run.notes,
        "memory_cost": run.memory_cost.to_dict() if run.memory_cost else None,
        "cases": [_case_to_dict(c) for c in run.cases]}


def load_run(frozen: Frozen, run_id: str) -> RunResult:
    path = _runs_dir(frozen) / run_id / "run.json"
    if not path.is_file():
        raise RunError(f"прогон {run_id} не найден в {frozen.directory}", CODE_NOT_FOUND)
    raw = json.loads(path.read_text(encoding="utf-8"))
    cases = []
    for c in raw.get("cases") or []:
        reps = [RepeatResult(
            repeat=r["repeat"], status=r["status"], usage=Usage.from_dict(r.get("usage") or {}),
            score=_score_from_dict(r["score"]) if r.get("score") else None,
            error=r.get("error", ""), material_paths=list(r.get("material_paths") or []),
            material_truncated=int(r.get("material_truncated") or 0),
            answer_chars=int(r.get("answer_chars") or 0)) for r in c["repeats"]]
        cases.append(CaseRun(c["case_id"], c["part"], list(c["flags"]), bool(c["critical"]), reps))
    mem = raw.get("memory_cost")
    return RunResult(
        run_id=raw["run_id"], variant=raw["variant"], status=raw["status"], part=raw["part"],
        final=bool(raw["final"]), repeats=int(raw["repeats"]), label=raw["label"], ts=raw["ts"],
        model=raw.get("model", ""), reason=raw.get("reason", ""),
        prompt_hash=raw.get("prompt_hash", ""), budget=Budget(**raw["budget"]),
        questions_hash=raw.get("questions_hash", ""), manifest_hash=raw.get("manifest_hash", ""),
        baseline_hash=raw.get("baseline_hash", ""), cases=cases,
        memory_cost=MemoryCost.from_dict(mem) if mem else None,
        control_opens=int(raw.get("control_opens") or 0), notes=list(raw.get("notes") or []),
        directory=path.parent)


def _human_path(run: RunResult) -> Path:
    assert run.directory is not None  # noqa: S101
    return run.directory / "human.json"


def _human_skeleton(run: RunResult) -> list[dict[str, Any]]:
    items = []
    for c in run.cases:
        for r in c.repeats:
            if r.score is None:
                continue
            for index, cr in r.score.human_items():
                items.append({"case_id": c.case_id, "repeat": r.repeat, "index": index,
                              "kind": cr.kind, "text": cr.label, "hint": cr.detail,
                              "verdict": None, "note": ""})
    return items


def _load_human(run: RunResult) -> dict[tuple[str, int, int], str]:
    path = _human_path(run)
    if not path.is_file():
        return {}
    data = json.loads(path.read_text(encoding="utf-8"))
    return {(i["case_id"], int(i["repeat"]), int(i["index"])): i["verdict"]
            for i in data.get("items") or [] if i.get("verdict") in ("ok", "lost")}


def set_verdict(run: RunResult, case_id: str, repeat: int, index: int, verdict: str,
                note: str = "") -> None:
    """Решение человека по смысловому условию: ``ok`` (условие сохранено) | ``lost``."""
    if verdict not in ("ok", "lost"):
        raise RunError(f"решение {verdict!r}: нужно ok | lost", CODE_BAD_PART)
    path = _human_path(run)
    data = json.loads(path.read_text(encoding="utf-8"))
    for item in data["items"]:
        if (item["case_id"], int(item["repeat"]), int(item["index"])) == (case_id, repeat, index):
            item["verdict"], item["note"] = verdict, note
            path.write_text(json.dumps(data, ensure_ascii=False, indent=1) + "\n",
                            encoding="utf-8")
            return
    raise RunError(f"нет смыслового условия: {case_id} повтор {repeat} условие {index}",
                   CODE_NOT_FOUND)


def _with_human(score: CaseScore, case_id: str, repeat: int,
                human: dict[tuple[str, int, int], str]) -> CaseScore:
    crit = []
    for i, c in enumerate(score.criticals):
        verdict = human.get((case_id, repeat, i)) if c.status == ST_HUMAN else None
        crit.append(replace(c, status=ST_OK if verdict == "ok" else ST_LOST) if verdict else c)
    out = CaseScore(score.case_id)
    out.criticals, out.expectations = crit, score.expectations
    out.unseen, out.out_of_scope = score.unseen, score.out_of_scope
    return out


# --------------------------------------------------------------------------- #
# Прогон                                                                         #
# --------------------------------------------------------------------------- #
def _select(control: ControlSet, part: str) -> list[Case]:
    if part == "all":
        return sorted(control.cases, key=lambda c: c.id)
    return sorted(control.part(part), key=lambda c: c.id)


def _usage(answer: Answer, wall: float) -> Usage:
    return Usage(answer.tokens_in, answer.tokens_out,
                 answer.seconds if answer.seconds is not None else round(wall, 3),
                 answer.cost, answer.currency)


def _check_inputs(control: ControlSet, frozen: Frozen, variant: str, repeats: int, part: str,
                  final: bool) -> list[Case]:
    get_provider(variant)
    if repeats not in (1, 3):
        raise RunError("повторов должно быть 1 или 3 (правило трех повторов)", CODE_BAD_REPEATS)
    if part not in (PART_DEV, PART_CONTROL, "all"):
        raise RunError(f"часть {part!r}: development | control | all", CODE_BAD_PART)
    if part != PART_DEV and not final:
        raise RunError(
            "контрольная часть открывается только с final=True (--final): метод разрабатывают на "
            "части разработка, подгонка по закрытой контрольной запрещена", CODE_CONTROL_CLOSED)
    if questions_hash(control.cases) != frozen.manifest.get("questions_hash"):
        raise RunError("вопросы набора изменились после заморозки: выдача A к ним не относится; "
                       "заморозьте заново (новая метка)", CODE_STALE_QUESTIONS)
    cases = _select(control, part)
    if not cases:
        raise RunError(f"в части {part} нет случаев", CODE_NO_CASES)
    return cases


def run_variant(
    variant: str, control: ControlSet, frozen: Frozen, answerer: Answerer | None, *,
    repeats: int = 1, part: str = PART_DEV, final: bool = False, vault: Path | None = None,
    allow_drift: bool = False, budget: Budget | None = None, model: str = "",
    now: datetime | None = None, clock: Callable[[], float] = time.perf_counter,
    persist: bool = True,
) -> RunResult:
    """Прогнать вариант на замороженной выдаче; результат сохраняется в ``<заморозка>/runs/``.

    ``vault`` - если задан, корпус сверяется с заморозкой (изменился - ``run_corpus_changed``, если
    не ``allow_drift``). Недоступный вариант (B/C/D) сохраняется как ``unavailable``."""
    cases = _check_inputs(control, frozen, variant, repeats, part, final)
    if vault is not None and not allow_drift:
        drift = verify_corpus(vault, frozen)
        if drift:
            raise RunError(f"корпус изменился после заморозки ({drift.summary()}); сравнение "
                           "A/B/C/D требует одного корпуса", CODE_CORPUS_CHANGED)
    provider = get_provider(variant)
    budget = budget or Budget()
    prior_opens = sum(
        1 for r in _ledger_rows(frozen)
        if r.get("variant") == variant and r.get("final") and r.get("status") == "done"
        and r.get("part") != PART_DEV)
    run = RunResult(
        run_id=_next_run_id(frozen, variant, part), variant=variant, status="done", part=part,
        final=final, repeats=repeats, label=frozen.label, model=model, budget=budget,
        ts=(now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        questions_hash=str(frozen.manifest.get("questions_hash") or ""),
        manifest_hash=str(frozen.manifest.get("manifest_hash") or ""),
        baseline_hash=str(frozen.baseline.get("baseline_hash") or ""))
    if part != PART_DEV:
        run.control_opens = prior_opens + 1
        if prior_opens:
            run.notes.append(
                f"контрольная часть вскрыта повторно ({prior_opens + 1}-й раз для варианта "
                f"{variant}): метод нельзя подгонять по закрытой части")
    ok, reason = provider.availability()
    if not ok:
        run.status, run.reason = "unavailable", reason
    elif answerer is None:
        raise RunError("нет ответчика: --answerer модуль:функция либо --answers файл.json",
                       CODE_BAD_VARIANT)
    else:
        run.memory_cost = provider.memory_cost()
        for case in cases:
            run.cases.append(_run_case(provider, case, frozen, answerer, variant, repeats,
                                       budget, clock))
    if persist:
        _persist(frozen, run)
    return run


def _run_case(provider: Provider, case: Case, frozen: Frozen, answerer: Answerer, variant: str,
              repeats: int, budget: Budget, clock: Callable[[], float]) -> CaseRun:
    items, aliases = provider.material(case.id, frozen)
    prompt, kept, cut = build_prompt(case.question, items, budget)
    out = CaseRun(case.id, case.part, sorted(case.flags), case.is_critical)
    for n in range(1, repeats + 1):
        req = AnswerRequest(variant, case.id, case.question, prompt, kept, n, budget)
        started = clock()
        try:
            answer = answerer(req)
        except Exception as exc:  # noqa: BLE001 - сбой ответчика = провал повтора, не прогона
            out.repeats.append(RepeatResult(
                n, "error", error=f"{type(exc).__name__}: {str(exc)[:160]}",
                material_paths=[m.path for m in kept], material_truncated=cut))
            continue
        paths = [m.path for m in kept]
        out.repeats.append(RepeatResult(
            n, "answered", usage=_usage(answer, clock() - started),
            score=score_answer(case, answer, provided=paths, aliases=aliases),
            material_paths=paths, material_truncated=cut, answer_chars=len(answer.text)))
    return out


def _persist(frozen: Frozen, run: RunResult) -> None:
    directory = _runs_dir(frozen) / run.run_id
    directory.mkdir(parents=True, exist_ok=False)
    run.directory = directory
    (directory / "run.json").write_text(
        json.dumps(_run_to_dict(run), ensure_ascii=False, sort_keys=True, indent=1) + "\n",
        encoding="utf-8")
    (directory / "human.json").write_text(
        json.dumps({"schema_version": RUN_SCHEMA, "run_id": run.run_id,
                    "items": _human_skeleton(run)}, ensure_ascii=False, indent=1) + "\n",
        encoding="utf-8")
    with _ledger(frozen).open("a", encoding="utf-8") as fh:
        fh.write(json.dumps({
            "run_id": run.run_id, "variant": run.variant, "part": run.part, "final": run.final,
            "status": run.status, "repeats": run.repeats, "ts": run.ts},
            ensure_ascii=False, sort_keys=True) + "\n")


# --------------------------------------------------------------------------- #
# Сводка                                                                         #
# --------------------------------------------------------------------------- #
def _mean(values: list[float]) -> float | None:
    return round(sum(values) / len(values), 4) if values else None


def _median(values: list[float]) -> float | None:
    return round(float(statistics.median(values)), 2) if values else None


def _case_summary(c: CaseRun, human: dict[tuple[str, int, int], str]) -> dict[str, Any]:
    scores = [(r.repeat, _with_human(r.score, c.case_id, r.repeat, human))
              for r in c.repeats if r.score is not None]
    errors = sum(1 for r in c.repeats if r.status == "error")
    crit_fail = errors > 0 or any(not s.critical_ok for _, s in scores)
    pending = any(s.pending for _, s in scores)
    q = [s.quality_ok for _, s in scores]
    usage = [r.usage for r in c.repeats if r.status == "answered"]
    tokens = [u.tokens for u in usage]
    return {
        "case_id": c.case_id, "flags": c.flags, "critical": c.critical, "errors": errors,
        "critical_fail": bool(c.critical and crit_fail),
        "critical_pending": bool(c.critical and not crit_fail and pending),
        "lost": sorted({cr.label for _, s in scores for cr in s.criticals
                        if cr.status not in (ST_OK, ST_HUMAN)}),
        "quality_pass": bool(scores) and errors == 0 and all(q),
        "flaky": len(set(q)) > 1,
        "source_recall": _mean([s.source_recall for _, s in scores if s.source_recall is not None]),
        "locator_recall": _mean([s.locator_recall for _, s in scores
                                 if s.locator_recall is not None]),
        "out_of_scope": sum(len(s.out_of_scope) for _, s in scores),
        "unseen": sum(len(s.unseen) for _, s in scores),
        "tokens": (_median([float(t) for t in tokens if t is not None])
                   if usage and all(t is not None for t in tokens) else None),
        "seconds": (_median([float(u.seconds) for u in usage if u.seconds is not None])
                    if usage and all(u.seconds is not None for u in usage) else None),
        "cost": (sum(float(u.cost) for u in usage if u.cost is not None) / len(usage)
                 if usage and all(u.cost is not None for u in usage) else None),
        "answers": len(usage),
    }


def summarize(run: RunResult) -> dict[str, Any]:
    """Сводка прогона с учетом решений человека (``human.json``); ничего не пишет."""
    human = _load_human(run) if run.directory else {}
    rows = [_case_summary(c, human) for c in run.cases]
    crit = [r for r in rows if r["critical"]]
    multi = [r for r in rows if "multi_source" in r["flags"] and r["source_recall"] is not None]
    single = [r for r in rows if "single_doc" in r["flags"]]
    answers = [rep for c in run.cases for rep in c.repeats if rep.status == "answered"]
    tokens_known = [r["tokens"] for r in rows if r["tokens"] is not None]
    unknown_cost = sum(1 for a in answers if a.usage.cost is None)
    currencies = sorted({a.usage.currency for a in answers if a.usage.currency})
    return {
        "run_id": run.run_id, "variant": run.variant, "status": run.status, "part": run.part,
        "repeats": run.repeats, "preliminary": run.repeats < 3,
        "cases": len(rows), "errors": sum(r["errors"] for r in rows),
        "critical_cases": len(crit), "critical_fail": sum(1 for r in crit if r["critical_fail"]),
        "critical_pending": sum(1 for r in crit if r["critical_pending"]),
        "lost_conditions": sum(len(r["lost"]) for r in rows),
        "quality_pass": sum(1 for r in rows if r["quality_pass"]),
        "flaky_cases": sum(1 for r in rows if r["flaky"]),
        "source_recall": _mean([r["source_recall"] for r in rows
                                if r["source_recall"] is not None]),
        "locator_recall": _mean([r["locator_recall"] for r in rows
                                 if r["locator_recall"] is not None]),
        "multi_cases": len(multi),
        "multi_completeness": _mean([r["source_recall"] for r in multi]),
        "single_doc_cases": len(single),
        "single_doc_pass": sum(1 for r in single if r["quality_pass"]),
        "out_of_scope_citations": sum(r["out_of_scope"] for r in rows),
        "unseen_citations": sum(r["unseen"] for r in rows),
        "tokens_median": _median([float(t) for t in tokens_known])
        if len(tokens_known) == len(rows) and rows else None,
        "tokens_total": (sum(a.usage.tokens or 0 for a in answers)
                         if answers and all(a.usage.tokens is not None for a in answers) else None),
        "seconds_total": (round(sum(a.usage.seconds or 0.0 for a in answers), 3)
                          if answers and all(a.usage.seconds is not None for a in answers)
                          else None),
        "cost_total": (round(sum(a.usage.cost or 0.0 for a in answers), 6)
                       if answers and unknown_cost == 0 else None),
        "cost_unknown_answers": unknown_cost, "currency": ",".join(currencies),
        "per_case": rows,
    }
