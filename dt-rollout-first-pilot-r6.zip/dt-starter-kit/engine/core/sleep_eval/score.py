"""SLEEP-EVAL-1 п.3 - детерминированная оценка ответа по случаю контрольного набора (без модели).

Числа, даты, единицы и локаторы проверяются КОДОМ против ожидаемых (sleep-1.md §11); смысл -
по разметке и решению человека. Нового LLM-as-judge нет.

* **Критические условия.** ``число`` (с единицей/валютой/масштабом), ``дата``, ``период`` (обе даты)
  ищутся в тексте ответа ТОЙ ЖЕ нормализацией, что у сверки цитат и чисел
  (:class:`core.cited.Corpus`, :mod:`core.facts.textnorm`): ``480`` и ``0,48 млн`` - разные числа,
  ``1 200 000 тенге`` и ``1,2 млн ₸`` - одно и то же значение. Статусы: ``ok`` | ``missing`` (нет) |
  ``unit_mismatch`` (то же значение в другой единице/валюте) | ``scale_mismatch`` (те же цифры,
  другая степень десяти). Смысловые (``исключение``/``условие``) - всегда ``needs_human``: код
  только сообщает, нашлись ли маркеры; итог ставит человек (``ok``/``lost``) через ``human.json``.
* **Источники и локаторы.** Ожидание = (источник, локатор). Ссылка ответа (``Источник: путь |
  локатор``) приводится к пути (путь, суффикс пути, ``note_id`` по алиасам выдачи); локатор
  сравнивается нормализованно (регистр, написание буквы «е», тире, пробелы), ожидаемый должен
  ВХОДИТЬ в указанный целым токеном (``п.4.1`` не входит в ``п.4.10``). Статусы источника:
  ``cited`` | ``absent``; локатора: ``ok`` | ``mismatch`` | ``absent`` | ``not_checked``
  (ожидание без локатора).
* **Учет ссылок.** ``unseen`` - ссылка на источник, которого не было в выданном материале (ссылка в
  никуда); ``out_of_scope`` - ссылка на источник вне разрешенной области случая либо под ``_nda``
  (кандидат в утечки).

Чистые функции: ни сети, ни модели, ни записи.
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from typing import Any

from core.cited import Corpus, Material
from core.facts.textnorm import scan_dates
from core.privacy import is_nda
from core.sleep_eval.control import (
    KIND_CONDITION,
    KIND_DATE,
    KIND_EXCEPTION,
    KIND_NUMBER,
    KIND_PERIOD,
    Case,
    Critical,
    scope_match,
)

__all__ = [
    "Answer",
    "Citation",
    "CriticalResult",
    "ExpectationResult",
    "CaseScore",
    "ST_OK", "ST_MISSING", "ST_UNIT", "ST_SCALE", "ST_HUMAN", "ST_LOST",
    "norm_loc",
    "parse_citations",
    "resolve_source",
    "score_answer",
]

ST_OK, ST_MISSING, ST_UNIT, ST_SCALE = "ok", "missing", "unit_mismatch", "scale_mismatch"
ST_HUMAN, ST_LOST = "needs_human", "lost"

_CITE_LINE_RE = re.compile(r"^\s*(?:[-*]\s*)?(?:источник|source)\s*:\s*(.+?)\s*$",
                           re.IGNORECASE | re.MULTILINE)
_DASHES = str.maketrans({c: "-" for c in "‐‑‒–—―−"})
_LOC_STRIP_RE = re.compile(r"[\s №#]+")


@dataclass(frozen=True)
class Citation:
    source: str
    locator: str = ""


@dataclass(frozen=True)
class Answer:
    """Ответ варианта: текст, ссылки и учет. ``None`` в учете - неизвестно, а не ноль."""

    text: str
    citations: tuple[Citation, ...] = ()
    tokens_in: int | None = None
    tokens_out: int | None = None
    seconds: float | None = None
    cost: float | None = None
    currency: str = ""


@dataclass(frozen=True)
class CriticalResult:
    kind: str
    label: str
    status: str
    detail: str = ""
    deterministic: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "label": self.label, "status": self.status,
                "detail": self.detail, "deterministic": self.deterministic}


@dataclass(frozen=True)
class ExpectationResult:
    source: str
    locator: str
    source_status: str   # cited | absent
    locator_status: str  # ok | mismatch | absent | not_checked

    def to_dict(self) -> dict[str, Any]:
        return {"source": self.source, "locator": self.locator,
                "source_status": self.source_status, "locator_status": self.locator_status}


@dataclass
class CaseScore:
    case_id: str
    criticals: list[CriticalResult] = field(default_factory=list)
    expectations: list[ExpectationResult] = field(default_factory=list)
    unseen: list[str] = field(default_factory=list)
    out_of_scope: list[str] = field(default_factory=list)

    @property
    def det_total(self) -> int:
        return sum(1 for c in self.criticals if c.deterministic)

    @property
    def det_ok(self) -> int:
        return sum(1 for c in self.criticals if c.deterministic and c.status == ST_OK)

    @property
    def lost(self) -> int:
        """Потеряно условий: детерминированных (нет/другая единица) и признанных человеком."""
        return sum(1 for c in self.criticals if c.status not in (ST_OK, ST_HUMAN))

    @property
    def pending(self) -> int:
        """Смысловых условий, по которым человек еще не решил."""
        return sum(1 for c in self.criticals if c.status == ST_HUMAN)

    @property
    def critical_ok(self) -> bool:
        """Ни одно критическое условие не потеряно (ожидающие решения человека не в счет)."""
        return self.lost == 0

    @property
    def source_recall(self) -> float | None:
        if not self.expectations:
            return None
        return sum(1 for e in self.expectations if e.source_status == "cited") / len(
            self.expectations)

    @property
    def locator_recall(self) -> float | None:
        checked = [e for e in self.expectations if e.locator_status != "not_checked"]
        if not checked:
            return None
        return sum(1 for e in checked if e.locator_status == "ok") / len(checked)

    @property
    def quality_ok(self) -> bool:
        """Критические условия целы, все источники названы, локаторы (где заданы) верны."""
        return (self.critical_ok and self.pending == 0 and self.source_recall == 1.0
                and self.locator_recall in (None, 1.0))

    def human_items(self) -> list[tuple[int, CriticalResult]]:
        return [(i, c) for i, c in enumerate(self.criticals) if c.status == ST_HUMAN]

    def to_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id, "criticals": [c.to_dict() for c in self.criticals],
            "expectations": [e.to_dict() for e in self.expectations],
            "unseen": list(self.unseen), "out_of_scope": list(self.out_of_scope),
            "critical_ok": self.critical_ok, "pending": self.pending,
            "source_recall": self.source_recall,
            "locator_recall": self.locator_recall, "quality_ok": self.quality_ok,
        }


# --------------------------------------------------------------------------- #
# Нормализация                                                                  #
# --------------------------------------------------------------------------- #
def _fold(text: str) -> str:
    return " ".join(unicodedata.normalize("NFC", text or "").casefold().replace("ё", "е").split())


def norm_loc(locator: str) -> str:
    """Локатор без регистра, вариантов буквы «е», видов тире, пробелов и знака номера."""
    low = unicodedata.normalize("NFC", locator or "").casefold().replace("ё", "е")
    return _LOC_STRIP_RE.sub("", low.translate(_DASHES))


def _loc_in(expected: str, given: str) -> bool:
    """Ожидаемый локатор входит в указанный целым токеном (``п.4.1`` не в ``п.4.10``)."""
    exp, got = norm_loc(expected), norm_loc(given)
    if not exp:
        return True
    return re.search(r"(?<![0-9a-zа-я])" + re.escape(exp) + r"(?![0-9a-zа-я])", got) is not None


def _loc_in_text(expected: str, text: str) -> bool:
    """Ожидаемый локатор есть в тексте ответа целым токеном (пробелы между знаками любые)."""
    chars = [re.escape(ch) for ch in norm_loc(expected)]
    if not chars:
        return True
    body = unicodedata.normalize("NFC", text or "").casefold().replace("ё", "е").translate(_DASHES)
    pattern = r"(?<![0-9a-zа-я])" + r"[\s№#]*".join(chars) + r"(?![0-9a-zа-я])"
    return re.search(pattern, body) is not None


def parse_citations(text: str) -> tuple[Citation, ...]:
    """Ссылки из строк ``Источник: <путь> | <локатор>`` текста ответа (формат из общего промпта)."""
    out: list[Citation] = []
    for m in _CITE_LINE_RE.finditer(text or ""):
        source, _, locator = m.group(1).partition("|")
        if source.strip():
            out.append(Citation(source.strip().strip("`«»\"'"), locator.strip()))
    return tuple(out)


def _norm_path(ref: str) -> str:
    text = unicodedata.normalize("NFC", ref or "").strip().replace("\\", "/")
    while text.startswith("./"):
        text = text[2:]
    return text.casefold()


def resolve_source(ref: str, paths: Iterable[str], aliases: Mapping[str, str] | None = None
                   ) -> str | None:
    """Ссылка ответа -> путь vault из ``paths``: путь целиком, суффикс пути либо алиас
    (``note_id``) выдачи. Нет однозначного совпадения - ``None``."""
    target = _norm_path(ref)
    if not target:
        return None
    by_norm = {_norm_path(p): p for p in paths}
    if target in by_norm:
        return by_norm[target]
    suffix = [p for n, p in by_norm.items() if n.endswith("/" + target)]
    if len(suffix) == 1:
        return suffix[0]
    alias = {_norm_path(k): v for k, v in (aliases or {}).items()}
    hit = alias.get(target)
    if hit is not None and _norm_path(hit) in by_norm:
        return by_norm[_norm_path(hit)]
    return None


# --------------------------------------------------------------------------- #
# Критические условия                                                           #
# --------------------------------------------------------------------------- #
def _key(base: float) -> str:
    return f"{abs(base):.9g}"


def _number_result(c: Critical, corpus: Corpus) -> CriticalResult:
    assert c.number is not None  # noqa: S101 - гарантия загрузчика
    status, hit = corpus.number_status(c.number)
    if status == "found":
        return CriticalResult(KIND_NUMBER, c.label(), ST_OK)
    if status == "mismatch" and hit is not None:
        same = _key(hit.base) == _key(c.number.base)
        return CriticalResult(
            KIND_NUMBER, c.label(), ST_UNIT if same else ST_SCALE,
            f"в ответе {hit.raw} {hit.unit or ''}".strip())
    return CriticalResult(KIND_NUMBER, c.label(), ST_MISSING, "числа нет в ответе")


def _date_result(iso: str, label: str, kind: str, corpus: Corpus) -> CriticalResult:
    mentions = scan_dates(iso)
    found = bool(mentions) and corpus.date_status(mentions[0])[0]
    return CriticalResult(kind, label, ST_OK if found else ST_MISSING,
                          "" if found else f"даты {iso} нет в ответе")


def _critical_result(c: Critical, corpus: Corpus, answer_text: str) -> CriticalResult:
    if c.kind == KIND_NUMBER:
        return _number_result(c, corpus)
    if c.kind == KIND_DATE:
        return _date_result(c.date_iso, c.label(), KIND_DATE, corpus)
    if c.kind == KIND_PERIOD:
        first = _date_result(c.from_iso, c.label(), KIND_PERIOD, corpus)
        second = _date_result(c.to_iso, c.label(), KIND_PERIOD, corpus)
        if first.status == ST_OK and second.status == ST_OK:
            return first
        return CriticalResult(KIND_PERIOD, c.label(), ST_MISSING,
                              "; ".join(x.detail for x in (first, second) if x.detail))
    folded = _fold(answer_text)
    found = [m for m in c.markers if _fold(m) in folded]
    detail = (f"маркеры найдены {len(found)}/{len(c.markers)}" if c.markers
              else "маркеров нет - только решение человека")
    return CriticalResult(c.kind if c.kind in (KIND_EXCEPTION, KIND_CONDITION) else KIND_CONDITION,
                          c.label(), ST_HUMAN, detail, deterministic=False)


# --------------------------------------------------------------------------- #
# Оценка случая                                                                 #
# --------------------------------------------------------------------------- #
def _expectation_results(case: Case, cites: list[tuple[str | None, Citation]],
                         text: str) -> list[ExpectationResult]:
    out: list[ExpectationResult] = []
    for exp in case.expectations:
        mine = [c for resolved, c in cites if resolved == exp.source]
        inline = not mine and (_norm_path(exp.source) in _norm_path(text)
                               or exp.source.rsplit("/", 1)[-1].casefold() in text.casefold())
        if not mine and not inline:
            out.append(ExpectationResult(exp.source, exp.locator, "absent",
                                         "absent" if exp.locator else "not_checked"))
            continue
        if not exp.locator:
            status = "not_checked"
        elif any(_loc_in(exp.locator, c.locator) for c in mine) or (
                inline and _loc_in_text(exp.locator, text)):
            status = "ok"
        else:
            status = "mismatch"
        out.append(ExpectationResult(exp.source, exp.locator, "cited", status))
    return out


def score_answer(case: Case, answer: Answer, *, provided: Iterable[str] = (),
                 aliases: Mapping[str, str] | None = None) -> CaseScore:
    """Оценить ответ по случаю: условия, источники/локаторы, ссылки в никуда и вне области.

    ``provided`` - пути материала, который получил ответчик; ``aliases`` - ``note_id -> путь``
    из исходной выдачи."""
    provided_set = set(provided)
    universe = sorted(provided_set | set(case.sources))
    corpus = Corpus([Material(label="answer", text=answer.text)])
    score = CaseScore(case.id)
    score.criticals = [_critical_result(c, corpus, answer.text) for c in case.critical]
    citations = answer.citations or parse_citations(answer.text)
    cites: list[tuple[str | None, Citation]] = [
        (resolve_source(c.source, universe, aliases), c) for c in citations]
    score.expectations = _expectation_results(case, cites, answer.text)
    for resolved, c in cites:
        path = resolved or _norm_path(c.source)
        pathlike = resolved is not None or "/" in path or path.endswith(".md")
        if is_nda(c.source) or is_nda(path) or (pathlike and not scope_match(path, case.scope)):
            score.out_of_scope.append(c.source)
        elif resolved is None or resolved not in provided_set:
            score.unseen.append(c.source)
    score.unseen = sorted(set(score.unseen))
    score.out_of_scope = sorted(set(score.out_of_scope))
    return score
