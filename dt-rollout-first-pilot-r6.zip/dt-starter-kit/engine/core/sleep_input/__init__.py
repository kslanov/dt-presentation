"""SLEEP-INPUT-1 - реестр ревизий входов Сна, план прогона, досье порции, прием явного опыта.

Контракт знания - :mod:`core.sleep` (SLEEP-CONTRACT-1), ledger - :mod:`core.sleep_store`
(SLEEP-STORE-1), квитанции чтения - :mod:`core.receipts` (PROV-CITED-1): здесь они ИСПОЛЬЗУЮТСЯ,
не дублируются. Модель не вызывается, сеть не обходится, в знания и facts ничего не пишется.

* :mod:`core.sleep_input.schema` - DDL реестра (миграция v6 общего менеджера :mod:`core.db`);
* :mod:`core.sleep_input.store` - доступ к реестру (запись / строго чтение);
* :mod:`core.sleep_input.identity` - правило ``source_id``/``family_id`` (переименование, копии);
* :mod:`core.sleep_input.privacy` - что НЕ входит в реестр (личное, ``_nda``, секрет, symlink,
  выход пути за vault) и что блокировано (неизвестная приватность);
* :mod:`core.sleep_input.discover` - кандидаты реестра из того, что DT уже знает (frontmatter-срезы
  vault, почтовые треды, facts), инкрементально, без обхода сетевых шар;
* :mod:`core.sleep_input.registry` - применение обхода к реестру;
* :mod:`core.sleep_input.plan` - ``plan_sleep``: манифест, оценка, пропуски, worklist и хвост;
* :mod:`core.sleep_input.dossier` - ``sleep_context``: досье порции с покрытием и квитанцией;
* :mod:`core.sleep_input.experience` / :mod:`core.sleep_input.redact` - прием явного опыта сессий;
* :mod:`core.sleep_input.ops` - общие операции для CLI и MCP (одинаковые проверки и результаты).

Инварианты: до решения владельца ничего не пишется в знания и facts; ``plan`` без ``--apply``
ничего не пишет; содержимое входов - данные, не полномочия; личное/``_nda``/секрет/symlink -
отказ до досье и реестра; копии - не независимые подтверждения; хвост worklist не теряется;
ошибка не равна «пусто». ``core`` ⊥ cli/mcp.
"""
