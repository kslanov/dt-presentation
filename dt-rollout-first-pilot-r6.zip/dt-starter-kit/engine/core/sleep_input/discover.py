"""SLEEP-INPUT-1 - кандидаты реестра входов из того, что DT уже знает (sleep-1.md §4.1).

Обхода сетевых шар и массового импорта здесь нет: источники - заметки vault и слоя ``_legacy``
(``corpus: current|legacy``, ``source_path`` и ``source_content_hash`` из их frontmatter),
почтовые треды (``conv:<id>`` - тоже заметки vault) и сами заметки vault. Оригиналы по
``source_path`` НЕ открываются и не хешируются (они могут лежать на шаре или в dataless-iCloud):
тождество файла - ``source_content_hash``, записанный при входе. Факты (``facts``) входами не
становятся: они производные от файлов-источников и входят в план сигналом, в досье - ссылками.

**Инкрементально.** Обход делает ``stat`` каждой заметки и сравнивает ``(mtime_ns, size)`` с
записью реестра: совпало - файл не читается (``reuse``), хеш и метаданные берутся из реестра;
читаются и разбираются только новые и изменившиеся. По пути (дешево) заново проверяется
приватность даже у неизменных: маркер ``_nda`` могли добавить позже.

**Чтение read-only:** ни реестр, ни ``.derived`` не пишутся; кэш frontmatter не трогается (его
запись - побочный эффект, плану без ``--apply`` недопустимый).

Отказы по приватности (:mod:`core.sleep_input.privacy`) считаются по причинам, без путей; пути
остаются только у ``symlink``/``path_traversal`` (они помогают найти ошибку, секрета не несут).
Нечитаемая заметка - в ``errors``, а не «пусто»; обход, прерванный по времени, - ``complete=False``
(исчезновение входов по неполному обходу не объявляется).
"""

from __future__ import annotations

import hashlib
import re
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.sleep_input.identity import Observation
from core.sleep_input.privacy import classify_note, classify_path_only

__all__ = ["Discovery", "KINDS", "content_hash_of", "discover_vault", "instance_label", "kind_of"]

KINDS = ("note", "file", "mail_thread")
_NOT_INPUT_TYPES = frozenset({"hub", "output", "output-sources", "moc"})
_MAIL_RE = re.compile(r"(?:conv|msg):[^\s/]+")
_DATE_KEYS = ("source_date", "modified", "last_date", "created", "first_date")
_OCR_NO_TEXT = frozenset({"pending", "refused", "refused_text", "empty"})
_SAMPLE_PATHS = 20


def instance_label() -> str:
    from core.instance import instance_name, instance_role

    return instance_name() or instance_role()


@dataclass
class Discovery:
    observations: list[Observation] = field(default_factory=list)
    refused: dict[str, int] = field(default_factory=dict)
    refused_paths: dict[str, list[str]] = field(default_factory=dict)
    to_block: list[tuple[str, str]] = field(default_factory=list)   # (source_id, причина)
    errors: list[dict[str, str]] = field(default_factory=list)
    complete: bool = True
    scanned: int = 0
    reused: int = 0

    def refuse(self, reason: str, rel: str = "") -> None:
        self.refused[reason] = self.refused.get(reason, 0) + 1
        if reason in ("symlink", "path_traversal") and rel:
            sample = self.refused_paths.setdefault(reason, [])
            if len(sample) < _SAMPLE_PATHS:
                sample.append(rel)


def _date(fm: Mapping[str, Any]) -> str:
    for key in _DATE_KEYS:
        value = fm.get(key)
        if value:
            return str(value)[:10]
    return ""


def _kind_and_locator(fm: Mapping[str, Any], note_id: str) -> tuple[str, str]:
    source_path = str(fm.get("source_path") or "").strip()
    if str(fm.get("source_type") or "") == "email-thread" or source_path.startswith(
            "correspondence/") or "conv:" in source_path or "msg:" in source_path:
        hit = _MAIL_RE.search(source_path) or _MAIL_RE.search(str(fm.get("conversation_id") or ""))
        return "mail_thread", (hit.group(0) if hit else note_id)
    if str(fm.get("type") or "") == "legacy-source" and source_path:
        return "file", source_path
    return "note", note_id


def _coverage(fm: Mapping[str, Any]) -> tuple[str, str]:
    ocr = str(fm.get("ocr") or "").strip().lower()
    if ocr in _OCR_NO_TEXT:
        return "unknown", f"ocr:{ocr}"
    sheets = [str(s) for s in (fm.get("truncated_sheets") or []) if str(s).strip()]
    if sheets:
        return "partial", "truncated_sheets:" + ",".join(sheets[:20])
    if ocr == "low":
        return "full", "ocr_low_confidence"
    return "full", ""


def content_hash_of(kind: str, fm: Mapping[str, Any], raw: bytes) -> str:
    """Хеш входа: у файла-источника - ``source_content_hash`` (хеш оригинала, записанный при входе;
    нет - хеш заметки), у заметки и треда - хеш файла заметки. Один путь для обхода и досье."""
    file_hash = hashlib.sha256(raw).hexdigest()
    if kind == "file":
        return str(fm.get("source_content_hash") or "") or file_hash
    return file_hash


def kind_of(fm: Mapping[str, Any], note_id: str) -> tuple[str, str]:
    """``(тип, локатор)`` входа по frontmatter заметки (см. :func:`_kind_and_locator`)."""
    return _kind_and_locator(fm, note_id)


def _observe(rel: str, fm: Mapping[str, Any], text: str, raw: bytes, stat_sig: str,
             privacy: str, instance: str) -> Observation:
    note_id = str(fm.get("id") or Path(rel).stem)
    kind, locator = _kind_and_locator(fm, note_id)
    content_hash = content_hash_of(kind, fm, raw)
    coverage, scope = _coverage(fm)
    method = str(fm.get("source_type") or fm.get("type") or "note")
    version = str(fm.get("ocr_engine") or "") or "1"
    return Observation(
        kind=kind, locator=locator, content_hash=content_hash, note_rel=rel, note_id=note_id,
        stat_sig=stat_sig, valid_date=_date(fm), privacy=privacy, extract_method=method,
        extract_version=version, coverage=coverage, coverage_scope=scope, size=len(raw),
        instance=instance)


def discover_vault(
    vault: Path, known: list[dict[str, Any]], *, instance: str | None = None,
    clock: Callable[[], float] = time.monotonic, deadline: float | None = None,
) -> Discovery:
    """Обход заметок vault: наблюдения для реестра + что отказано и почему. Ничего не пишет.

    ``known`` - записи реестра типов :data:`KINDS` (для инкрементальности); ``deadline`` - момент
    ``clock()``, после которого обход останавливается (``complete=False``)."""
    import frontmatter  # type: ignore[import-untyped]

    from core.vault import iter_vault_paths

    vault = Path(vault)
    inst = instance if instance is not None else instance_label()
    by_rel = {r["note_rel"]: r for r in known if r.get("note_rel")}
    disc = Discovery()
    for path in iter_vault_paths(vault, apply_nda=False):
        if deadline is not None and clock() > deadline:
            disc.complete = False
            break
        rel = path.relative_to(vault).as_posix()
        disc.scanned += 1
        row = by_rel.get(rel)

        def refuse(reason: str, rel: str = rel, row: dict[str, Any] | None = row) -> None:
            disc.refuse(reason, rel)
            if row is not None:  # уже был в реестре, а теперь нельзя: путь стирается, вход blocked
                disc.to_block.append((row["source_id"], reason))

        try:
            st = path.lstat()
        except OSError as exc:
            disc.errors.append({"rel": rel, "error": type(exc).__name__})
            continue
        sig = f"{st.st_mtime_ns}:{st.st_size}"
        if row is not None and row["stat_sig"] == sig and not path.is_symlink():
            verdict = classify_path_only(
                rel, row["locator"] if row["kind"] == "file" else "")
            if verdict.refused:
                refuse(verdict.reason)
                continue
            disc.reused += 1
            disc.observations.append(Observation(
                kind=row["kind"], locator=row["locator"], content_hash=row["content_hash"],
                note_rel=rel, note_id=row["note_id"], stat_sig=sig, valid_date=row["valid_date"],
                privacy=row["privacy"], extract_method=row["extract_method"],
                extract_version=row["extract_version"], coverage=row["coverage"],
                coverage_scope=row["coverage_scope"], size=int(row["size"]), instance=inst,
                reuse=True, existing_id=row["source_id"]))
            continue
        early = classify_path_only(rel)
        if early.refused:  # путь решает до чтения: ни файл, ни его содержимое не открываются
            refuse(early.reason)
            continue
        if path.is_symlink():
            refuse("symlink")
            continue
        try:
            raw = path.read_bytes()
            text = raw.decode("utf-8", errors="replace")
            post = frontmatter.loads(text)
        except Exception as exc:  # noqa: BLE001 - битая заметка не роняет обход: ошибка, не «пусто»
            disc.errors.append({"rel": rel, "error": type(exc).__name__})
            continue
        fm = dict(post.metadata)
        if str(fm.get("type") or "") in _NOT_INPUT_TYPES:
            refuse("derived")
            continue
        verdict = classify_note(rel, fm, text, vault=vault)
        if verdict.refused:
            refuse(verdict.reason)
            continue
        disc.observations.append(_observe(
            rel, fm, text, raw, sig, "unknown" if verdict.blocked else "work", inst))
    return disc
