"""SLEEP-INPUT-1 п.4 - прием явного опыта сессий (sleep-1.md §4.2).

Принимается ТОЛЬКО явно сданный пакет (CLI ``dt sleep experience add`` / MCP ``sleep(op=
"experience")``): хостовых экспортеров и скрытого чтения баз клиентов здесь нет. Журнал DT тела
разговоров не хранит и стенограммой не является - пакет не выдается за нее.

**Формат пакета** (JSON, ``schema`` = 1)::

    host, session_id            кто и какая сессия (обязательны; машинные имена)
    revision                    метка последнего сообщения (позднее сообщение - другая метка)
    privacy                     "work" - обязательно; "personal"/"nda" - отказ без следа;
                                не задано/иное - вход блокирован (содержимое не сохраняется)
    task, result                задача и результат сессии (строки)
    owner_notes[]               замечания владельца: {text, correction?, locator?}
    decisions[]                 решения: {text, by: "owner"|"agent", locator?}
    probes[]                    пробы: {action, observed, tool?, call_locator?, ok?, locator?}
    claims[]                    заявления агента: {text, locator?}
    hypotheses[]                нерешенные гипотезы: {text, locator?}
    locators[]                  локаторы исходных сообщений/вызовов (id, не пути)
    sources[]                   на какие входы ссылается замечание (локатор/id входа)
    messages                    {total, items[{idx, speaker, text?|fingerprint?, locator?}]} -
                                ТОЛЬКО роли/отпечатки/локаторы: тексты сообщений не сохраняются

**Роль говорящего и вид свидетельства раздельны.** ``speaker`` (owner | agent | tool | system) -
кто сказал; ``evidence`` (owner_statement | agent_claim | tool_result | observation | hypothesis)
- чем это подтверждено. Заявление агента НЕ равно результату инструмента: проба становится
``tool_result`` только если названы инструмент, локатор вызова и наблюдаемый результат; иначе она
понижается до ``agent_claim`` с пометкой ``unverified_probe`` (наблюдением не становится).
Гипотеза остается гипотезой.

**Покрытие.** Нет сообщений - ``summary_only`` (не стенограмма и не проверенный факт). Есть
сообщения и их число не меньше ``total`` - ``full``; меньше - ``partial`` с областью. Заявленное
``coverage`` выше проверяемого понижается (предупреждение).

**Секреты** отсекаются ДО долговечной записи (:mod:`core.sleep_input.redact`): в SQL, хеше,
ответе и логах остается число замен, не значения. Скрытые рассуждения не сохраняются (поля для них
нет; неизвестные поля отбрасываются с предупреждением).

**Ревизии.** Вход - ``exp:<host>/<session_id>`` (``source_id`` ``exp-…``); то же содержимое -
``unchanged`` (идемпотентно), другое (позднее сообщение, переоткрытая сессия) - ревизия +1 того же
входа. Семейство - сама сессия. Приватность определяет поле envelope, заданное адаптером хоста, не
текст.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any

from core.contract import warning
from core.sleep.contract import fragment_fingerprint
from core.sleep_input.identity import family_id_of
from core.sleep_input.redact import redact_obj
from core.sleep_input.store import InputStore
from core.sleep_store.ctx import Ctx

__all__ = [
    "EVIDENCE",
    "MAX_PACKAGE_BYTES",
    "MAX_STATEMENTS",
    "SCHEMA_VERSION",
    "SPEAKERS",
    "add_experience",
    "normalize",
]

SCHEMA_VERSION = 1
SPEAKERS = ("owner", "agent", "tool", "system")
EVIDENCE = ("owner_statement", "agent_claim", "tool_result", "observation", "hypothesis")
MAX_PACKAGE_BYTES = 1_000_000
MAX_STATEMENTS = 200
MAX_TEXT = 4000
_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:\-]{0,79}$")
_LOCATOR_RE = re.compile(r"^[A-Za-z0-9_.:#@\-\[\]/ ]{1,200}$")
_KNOWN_KEYS = frozenset({
    "schema", "host", "session_id", "revision", "privacy", "task", "result", "owner_notes",
    "decisions", "probes", "claims", "hypotheses", "locators", "sources", "messages", "coverage"})
_ALLOWED_COVERAGE = ("full", "partial", "summary_only")


def _refuse(code: str, error: str, **extra: Any) -> dict[str, Any]:
    return {"ok": False, "refused": True, "code": code, "error": f"{code}: {error}", **extra}


def _loc(value: Any, dropped: list[str]) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if ".." in text.split("/") or text.startswith("/") or not _LOCATOR_RE.match(text):
        dropped.append("locator")
        return ""
    return text


def _text(value: Any, flags: dict[str, Any]) -> str:
    text = " ".join(str(value or "").split())
    if len(text) > MAX_TEXT:
        flags["truncated"] = flags.get("truncated", 0) + 1
        text = text[:MAX_TEXT]
    return text


def normalize(raw: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    """Нормализованный пакет (секреты еще НЕ отсечены - отсекает :func:`add_experience`) и
    сведения о приеме: ``{"downgraded", "dropped", "truncated", "unknown_keys"}``."""
    info: dict[str, Any] = {"downgraded": 0, "dropped": [], "truncated": 0,
                            "unknown_keys": sorted(set(raw) - _KNOWN_KEYS)}
    flags: dict[str, Any] = {}
    dropped: list[str] = info["dropped"]
    statements: list[dict[str, Any]] = []

    def add(section: str, speaker: str, evidence: str, text: Any, locator: Any,
            **extra: Any) -> None:
        text = _text(text, flags)
        if not text:
            return
        statements.append({"id": f"s{len(statements) + 1}", "section": section,
                           "speaker": speaker, "evidence": evidence, "text": text,
                           "locator": _loc(locator, dropped), **extra})

    add("task", "owner", "owner_statement", raw.get("task"), None)
    add("result", "agent", "agent_claim", raw.get("result"), None)
    for item in raw.get("owner_notes") or []:
        d = item if isinstance(item, dict) else {"text": item}
        add("owner_note", "owner", "owner_statement", d.get("text"), d.get("locator"),
            correction=bool(d.get("correction")))
    for item in raw.get("decisions") or []:
        d = item if isinstance(item, dict) else {"text": item}
        by = "owner" if str(d.get("by") or "").lower() == "owner" else "agent"
        add("decision", by, "owner_statement" if by == "owner" else "agent_claim",
            d.get("text"), d.get("locator"))
    for item in raw.get("probes") or []:
        d = item if isinstance(item, dict) else {"action": item}
        action, observed = str(d.get("action") or ""), str(d.get("observed") or "")
        tool, call = str(d.get("tool") or "").strip(), _loc(d.get("call_locator"), dropped)
        text = action + (f" -> {observed}" if observed else "")
        if tool and call and observed:       # результат инструмента: кто, какой вызов, что вернул
            add("probe", "tool", "tool_result", text, d.get("locator") or call, tool=tool,
                call_locator=call, ok=d.get("ok") if isinstance(d.get("ok"), bool) else None)
        else:                                # заявление агента без результата инструмента
            info["downgraded"] += 1
            add("probe", "agent", "agent_claim", text, d.get("locator"), unverified_probe=True,
                ok=d.get("ok") if isinstance(d.get("ok"), bool) else None)
    for item in raw.get("claims") or []:
        d = item if isinstance(item, dict) else {"text": item}
        add("claim", "agent", "agent_claim", d.get("text"), d.get("locator"))
    for item in raw.get("hypotheses") or []:
        d = item if isinstance(item, dict) else {"text": item}
        add("hypothesis", "agent", "hypothesis", d.get("text"), d.get("locator"))
    info["truncated"] = flags.get("truncated", 0)

    msgs: dict[str, Any] = raw["messages"] if isinstance(raw.get("messages"), dict) else {}
    given = [m for m in (msgs.get("items") or []) if isinstance(m, dict)]
    items = []
    for i, m in enumerate(given, 1):
        speaker = str(m.get("speaker") or "")
        text = str(m.get("text") or "")
        items.append({
            "idx": int(m.get("idx") or i),
            "speaker": speaker if speaker in SPEAKERS else "system",
            "locator": _loc(m.get("locator"), dropped),
            "fingerprint": str(m.get("fingerprint") or "") or (
                fragment_fingerprint(text) if text else "")})
    total = msgs.get("total")
    total = int(total) if isinstance(total, int) and not isinstance(total, bool) else None
    package = {
        "schema": SCHEMA_VERSION, "host": str(raw.get("host") or ""),
        "session_id": str(raw.get("session_id") or ""),
        "revision_marker": " ".join(str(raw.get("revision") or "").split())[:200],
        "privacy": str(raw.get("privacy") or "").strip().lower(),
        "statements": statements,
        "locators": [x for x in (_loc(v, dropped) for v in raw.get("locators") or []) if x],
        "sources": [x for x in (_loc(v, dropped) for v in raw.get("sources") or []) if x],
        "messages": {"total": total, "given": len(items), "items": items},
    }
    return package, info


def _coverage(package: dict[str, Any], declared: Any) -> tuple[str, str, str | None]:
    """``(покрытие, область, предупреждение)``: проверяемое, не заявленное."""
    msgs = package["messages"]
    given, total = int(msgs["given"]), msgs["total"]
    if not given:
        verified, scope = "summary_only", "оригинал сообщений не сдан"
    elif total is not None and given >= total:
        verified, scope = "full", f"сообщения 1-{given} из {total}"
    else:
        verified = "partial"
        scope = f"сообщения {given} из {total if total is not None else 'неизвестно'}"
    note = None
    if declared in _ALLOWED_COVERAGE and declared != verified and (
            _ALLOWED_COVERAGE.index(declared) < _ALLOWED_COVERAGE.index(verified)):
        note = f"заявлено coverage={declared}, проверяемо {verified}"
    return verified, scope, note


def _digest(package: dict[str, Any]) -> str:
    blob = json.dumps(package, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def add_experience(ctx: Ctx, raw: Any, *, dry_run: bool = False) -> dict[str, Any]:
    """Принять пакет опыта: проверить, отсечь секреты, зарегистрировать вход и ревизию.

    Отказ данными (``ok: false``, ``refused``, ``code``); недоступная БД - ``sqlite3.Error``
    наверх (поверхность отвечает ``store_unavailable``). ``dry_run`` - только проверки: ничего не
    пишется (в ответе те же статистика и ``action``, что была бы)."""
    if not isinstance(raw, dict):
        return _refuse("schema_invalid", "пакет опыта должен быть объектом JSON")
    if len(json.dumps(raw, ensure_ascii=False, default=str)) > MAX_PACKAGE_BYTES:
        return _refuse("package_too_large", f"пакет больше {MAX_PACKAGE_BYTES} байт")
    if int(raw.get("schema") or SCHEMA_VERSION) != SCHEMA_VERSION:
        return _refuse("schema_unsupported", f"поддерживается schema={SCHEMA_VERSION}")
    host, session = str(raw.get("host") or ""), str(raw.get("session_id") or "")
    if not _NAME_RE.match(host) or not _NAME_RE.match(session):
        return _refuse("bad_session", "host и session_id: латиница, цифры и ._:- (до 80 знаков)")
    privacy = str(raw.get("privacy") or "").strip().lower()
    if privacy in ("personal", "nda"):  # без следа: ни записи, ни хеша, ни идентификатора
        return _refuse("privacy_refused", "личное и NDA не входят в рабочий сон", reason=privacy)
    clean, redacted = redact_obj(raw)
    package, info = normalize(clean)
    if len(package["statements"]) > MAX_STATEMENTS:
        return _refuse("package_too_large", f"утверждений больше {MAX_STATEMENTS}")
    coverage, scope, cov_note = _coverage(package, clean.get("coverage"))
    package["coverage"], package["coverage_scope"] = coverage, scope
    stm = package["statements"]
    package["signals"] = {
        "owner_remark": any(s["section"] == "owner_note" for s in stm),
        "repeat_error": any(s.get("correction") for s in stm),
        "procedure": any(s["evidence"] == "tool_result" and s.get("ok") is True for s in stm),
        "refs": list(dict.fromkeys([*package["sources"]])),
    }
    package["redacted"] = int(redacted)
    unknown = privacy != "work"
    source_id = "exp-" + hashlib.sha256(f"{host}\0{session}".encode()).hexdigest()[:16]
    locator = f"exp:{host}/{session}"
    content_hash = _digest({k: v for k, v in package.items() if k != "redacted"})
    warnings: list[dict[str, Any]] = []
    if info["unknown_keys"]:
        warnings.append(warning("unknown_keys", "неизвестные поля пакета отброшены (скрытые "
                                "рассуждения и посторонние данные не сохраняются)",
                                keys=info["unknown_keys"][:10]))
    if info["dropped"]:
        warnings.append(warning("partial", "часть локаторов отброшена (не id, а путь/мусор)",
                                count=len(info["dropped"])))
    if info["truncated"]:
        warnings.append(warning("truncated", f"тексты длиннее {MAX_TEXT} знаков обрезаны",
                                count=info["truncated"]))
    if cov_note:
        warnings.append(warning("coverage_downgraded", cov_note))
    if coverage == "summary_only":
        warnings.append(warning("summary_only", "оригинала нет: резюме - не стенограмма и не "
                                "проверенный факт"))
    if unknown:
        warnings.append(warning("privacy_unknown", "приватность не объявлена (privacy: work): вход "
                                "заблокирован, содержимое не сохранено"))
    counts: dict[str, int] = {}
    for s in stm:
        counts[s["evidence"]] = counts.get(s["evidence"], 0) + 1
    result: dict[str, Any] = {
        "ok": True, "source_id": source_id, "locator": locator, "coverage": coverage,
        "coverage_scope": scope, "redacted": int(redacted), "statements": counts,
        "downgraded": info["downgraded"], "blocked": unknown, "dry_run": bool(dry_run),
        "signals": package["signals"], "content_hash": content_hash,
    }
    if warnings:
        result["warning"] = warnings
    store = InputStore.open_readonly(ctx.db_path) if dry_run else InputStore.open(ctx.db_path)
    try:
        prev = store.input_row(source_id) if store is not None else None
        if prev is None:
            action, revision = "new", 1
        elif prev["content_hash"] == content_hash and bool(prev["privacy"] != "work") == unknown:
            action, revision = "unchanged", int(prev["revision"])
        else:
            action, revision = "revision", int(prev["revision"]) + 1
        result.update(action=action, revision=revision)
        if dry_run or store is None or action == "unchanged":
            return result
        now = ctx.stamp()
        cols = {
            "content_hash": content_hash, "stat_sig": "", "note_rel": "", "note_id": "",
            "valid_date": now[:10], "extract_method": "experience-package",
            "extract_version": str(SCHEMA_VERSION), "coverage": coverage,
            "coverage_scope": scope, "size": len(json.dumps(package, ensure_ascii=False)),
            "instance": _instance(), "privacy": "unknown" if unknown else "work",
            "availability": "blocked" if unknown else "available",
            "unavailable_reason": "privacy_unknown" if unknown else "",
        }
        with store.tx(immediate=True):
            if action == "new":
                store.insert_input({
                    **cols, "source_id": source_id, "family_id": family_id_of(source_id),
                    "origin_id": source_id, "is_copy": False, "kind": "experience",
                    "locator": locator, "revision": 1, "discovered_at": now, "updated_at": now,
                    "last_seen_at": now})
            else:
                store.new_revision(source_id, now, **cols)
            if not unknown:  # неизвестная приватность: содержимое не сохраняется
                store.conn.execute(
                    "INSERT INTO sleep_experience(source_id, revision, host, session_id, "
                    "content_hash, coverage, redacted, package_json, recorded_at) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    (source_id, revision, host, session, content_hash, coverage, int(redacted),
                     json.dumps(package, ensure_ascii=False, sort_keys=True), now))
    finally:
        if store is not None:
            store.close()
    return result


def _instance() -> str:
    from core.sleep_input.discover import instance_label

    return instance_label()

