"""SLEEP-INPUT-1 - правило идентичности входов: ``source_id`` / ``family_id`` (sleep-1.md §4.1).

Чистая логика (без SQL и диска): на входе наблюдение (:class:`Observation`) и то, что реестр уже
знает о нем (``by_locator``, ``same_hash``, ``present``), на выходе :class:`Decision`.

**Правило.**

* ``source_id`` - ``src-`` + sha256 от ``(тип, хеш, локатор)`` ПЕРВОГО наблюдения: он не зависит от
  того, как вход называется сейчас. Локатор - ``source_path`` (файл), ``conv:<id>`` (почтовый тред),
  id заметки (заметка vault), ``exp:<хост>/<сессия>`` (опыт).
* Тот же локатор, тот же хеш - ничего не изменилось (``unchanged``). Тот же локатор, другой хеш -
  ТА ЖЕ запись, ревизия +1 (``revision``): правка документа, новое сообщение треда, переоткрытая
  сессия.
* Новый локатор + хеш, который уже есть в реестре у входа, чей локатор ПРОПАЛ из текущего обхода
  - это переименование/перенос (``rename``): тот же ``source_id``, прежний локатор остается
  алиасом, новой ревизии нет.
* Новый локатор + хеш, который есть у входа, чей локатор ВСЁ ЕЩЁ виден, - копия (``copy``): новый
  ``source_id``, но тот же ``family_id`` и ``origin_id`` (первоисточник) и ``is_copy=1``.
  Копии одного семейства - НЕ независимые подтверждения (сценарий 1): :func:`independence` считает
  семейства, а не файлы. Переименование И правка одновременно по хешу не опознаются: это новый вход
  (честное ограничение: нечем доказать происхождение).
* Иначе - новый вход (``new``): свое семейство, он же первоисточник.

Копии в пределах одного обхода: первый (по дате действия, затем локатору) - первоисточник, прочие
- его копии; решение не зависит от порядка выдачи обхода.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

__all__ = [
    "Decision",
    "Observation",
    "decide",
    "family_id_of",
    "independence",
    "new_source_id",
    "sort_key",
]


@dataclass(frozen=True)
class Observation:
    """Что обход увидел про один вход (без текста: хеш, локатор, метаданные)."""

    kind: str
    locator: str
    content_hash: str = ""
    note_rel: str = ""
    note_id: str = ""
    stat_sig: str = ""
    valid_date: str = ""
    privacy: str = "work"            # work | unknown
    extract_method: str = ""
    extract_version: str = ""
    coverage: str = "unknown"
    coverage_scope: str = ""
    size: int = 0
    instance: str = ""
    reuse: bool = False              # хеш/метаданные взяты из реестра: файл не перечитывался
    existing_id: str = ""            # при ``reuse`` - source_id записи реестра


@dataclass(frozen=True)
class Decision:
    """Решение по наблюдению: ``action`` ∈ new | revision | unchanged | rename | copy."""

    action: str
    source_id: str
    family_id: str
    origin_id: str
    is_copy: bool = False
    revision: int = 1
    prev_revision: int = 0
    prev_hash: str = ""
    copy_of: str = ""


def new_source_id(kind: str, content_hash: str, locator: str) -> str:
    blob = f"{kind}\0{content_hash}\0{locator}".encode()
    return "src-" + hashlib.sha256(blob).hexdigest()[:16]


def family_id_of(origin_id: str) -> str:
    """Семейство названо по первоисточнику (``src-…`` -> ``fam-…``)."""
    return "fam-" + origin_id.removeprefix("src-").removeprefix("exp-")


def sort_key(obs: Observation) -> tuple[str, str]:
    """Порядок обработки новых входов: старший (по дате действия) первым, затем локатор."""
    return (obs.valid_date or "9999", obs.locator)


def decide(
    obs: Observation, *, by_locator: Mapping[str, Any] | None,
    same_hash: Iterable[Mapping[str, Any]], present: frozenset[str] | set[str],
) -> Decision:
    """Решение по наблюдению. ``by_locator`` - запись реестра с этим текущим локатором;
    ``same_hash`` - записи с тем же хешем (старшие первыми); ``present`` - локаторы, видимые в
    ЭТОМ обходе (по ним отличают переименование от копии)."""
    if by_locator is not None:
        prev_hash = str(by_locator["content_hash"])
        if obs.content_hash and prev_hash and obs.content_hash != prev_hash:
            return Decision(
                "revision", by_locator["source_id"], by_locator["family_id"],
                by_locator["origin_id"], bool(by_locator["is_copy"]),
                int(by_locator["revision"]) + 1, int(by_locator["revision"]), prev_hash)
        return Decision(
            "unchanged", by_locator["source_id"], by_locator["family_id"],
            by_locator["origin_id"], bool(by_locator["is_copy"]), int(by_locator["revision"]),
            int(by_locator["revision"]), prev_hash)
    holders = [dict(r) for r in same_hash if obs.content_hash]
    vanished = [r for r in holders if r["locator"] not in present]
    if vanished:
        r = vanished[0]
        return Decision("rename", r["source_id"], r["family_id"], r["origin_id"],
                        bool(r["is_copy"]), int(r["revision"]), int(r["revision"]),
                        str(r["content_hash"]))
    if holders:
        r = holders[0]
        sid = new_source_id(obs.kind, obs.content_hash, obs.locator)
        return Decision("copy", sid, r["family_id"], r["origin_id"], True, 1, 0, "",
                        copy_of=r["source_id"])
    sid = new_source_id(obs.kind, obs.content_hash, obs.locator)
    return Decision("new", sid, family_id_of(sid), sid, False, 1, 0, "")


def independence(rows: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Сколько НЕЗАВИСИМЫХ подтверждений дает набор входов: считаются семейства, не файлы.

    ``{"inputs": n, "families": k, "independent": k >= 2, "groups": {family_id: [source_id…]}}``.
    Копии и переименования одного первоисточника - одна группа."""
    groups: dict[str, list[str]] = {}
    for row in rows:
        groups.setdefault(str(row["family_id"]), []).append(str(row["source_id"]))
    return {"inputs": sum(len(v) for v in groups.values()), "families": len(groups),
            "independent": len(groups) >= 2,
            "groups": {k: sorted(v) for k, v in sorted(groups.items())}}
