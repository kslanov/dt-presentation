"""SLEEP-INPUT-1 - общие пределы порции досье и плана (одни числа для оценки и для чтения)."""

from __future__ import annotations

__all__ = ["MESSAGES_PER_PORTION", "PORTION_CHARS"]

#: размер порции досье, символов тела заметки: оценка плана и ``sleep_context`` считают одним числом
PORTION_CHARS = 12_000
#: сообщений почтового треда в порции (порция треда - по сообщениям, не по символам)
MESSAGES_PER_PORTION = 10
