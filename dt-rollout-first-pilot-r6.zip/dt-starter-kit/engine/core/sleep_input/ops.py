"""SLEEP-INPUT-1 п.5 - общие операции ядра для CLI и MCP: plan / context / experience / inputs.

Сценарий 20 (sleep-1.md §12): ``dt sleep`` и фасад ``sleep`` MCP дают ОДИНАКОВЫЕ результаты, потому
что поверхности лишь собирают :class:`core.sleep_store.ctx.Ctx` и зовут эти функции (своей логики
у них нет). Конверты отказа - ядра (:mod:`core.contract`): ``ok: false``, ``refused``, ``code``.

Права: ``plan`` без ``apply``, ``context``, ``inputs`` - чтение (``context`` оставляет лишь
квитанцию чтения); ``plan`` с ``apply`` и ``experience`` - запись (реестр/прогон/пакет опыта),
знания и facts не меняются. Недоступная БД - ``store_unavailable``, не пустой план и не «ничего
нового».
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from core.contract import CODE_STORE_UNAVAILABLE
from core.sleep_input.store import InputStore
from core.sleep_store.ctx import Ctx

__all__ = [
    "OPS",
    "context",
    "experience",
    "experience_from_file",
    "inputs",
    "plan",
    "profile",
    "summary",
]

OPS = ("plan", "context", "experience")   # новые op фасада ``sleep`` (inputs - только CLI)
#: SLEEP-PULT-1: op фасада ``sleep`` для экранов пульта (данные из тех же таблиц, без второй логики)
SCREEN_OPS = ("profile", "summary", "runs")
MAX_FILE_BYTES = 1_000_000


def _unavailable(exc: BaseException) -> dict[str, Any]:
    return {"ok": False, "refused": True, "code": CODE_STORE_UNAVAILABLE,
            "error": f"{CODE_STORE_UNAVAILABLE}: реестр входов Сна недоступен "
                     f"({type(exc).__name__}): это не «пусто», а ошибка"}


def plan(ctx: Ctx, *, scope: str | None = None, mode: str | None = None,
         budgets: dict[str, Any] | None = None, apply: bool = False,
         signals: Any = None) -> dict[str, Any]:
    """``plan_sleep``: манифест, оценка, пропуски; без ``apply`` ничего не пишет."""
    from core.sleep_input.plan import PlanError, plan_sleep

    try:
        return plan_sleep(ctx, scope=scope, mode=mode or "incremental", budgets=budgets,
                          apply=apply, signals=signals)
    except PlanError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": f"{exc.code}: {exc}"}
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)


def profile(ctx: Ctx, settings: dict[str, Any] | None = None,
            expected_version: str | None = None) -> dict[str, Any]:
    """SLEEP-PULT-1 п.5: профиль Сна. Без ``settings`` - чтение (версия, значения, пределы, то, что
    не выключается); с ``settings`` - запись по действию владельца (ожидаемая версия обязательна,
    чужая правка - ``profile_conflict``). Знания и реестр входов не меняются."""
    from core.sleep_input import profile as prof

    if settings is None:
        return prof.read_profile(ctx.vault)
    try:
        return prof.save_profile(ctx.vault, settings, expected_version, now=ctx.stamp())
    except prof.ProfileError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": f"{exc.code}: {exc}",
                **exc.extra}
    except OSError as exc:
        return {"ok": False, "refused": True, "code": "profile_unreadable",
                "error": f"profile_unreadable: профиль Сна не записан ({type(exc).__name__})"}


def context(ctx: Ctx, run_id: str | None, item: str | None, cursor: str | None = None, *,
            record: bool = True) -> dict[str, Any]:
    """``sleep_context``: досье порции позиции ``item`` прогона ``run_id``."""
    from core.sleep_input.dossier import sleep_context

    if not run_id or not item:
        return {"ok": False, "refused": True, "code": "schema_invalid",
                "error": "schema_invalid: нужны run_id и item (work_item из манифеста плана)"}
    try:
        return sleep_context(ctx, str(run_id), str(item), cursor or None, record=record)
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)


def experience(ctx: Ctx, package: Any, *, dry_run: bool = False) -> dict[str, Any]:
    """Прием явно сданного пакета опыта (секреты отсекаются до записи)."""
    from core.sleep_input.experience import add_experience

    try:
        return add_experience(ctx, package, dry_run=dry_run)
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)


def experience_from_file(ctx: Ctx, path: Path, *, dry_run: bool = False) -> dict[str, Any]:
    """То же из файла CLI: обычный файл (не symlink, не каталог) не больше ``MAX_FILE_BYTES``."""
    import json

    path = Path(path)
    if path.is_symlink() or not path.is_file():
        return {"ok": False, "refused": True, "code": "bad_file",
                "error": "bad_file: нужен обычный файл (symlink и каталоги не принимаются)"}
    try:
        if path.stat().st_size > MAX_FILE_BYTES:
            return {"ok": False, "refused": True, "code": "package_too_large",
                    "error": f"package_too_large: файл больше {MAX_FILE_BYTES} байт"}
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return {"ok": False, "refused": True, "code": "bad_file",
                "error": f"bad_file: файл не прочитан как JSON ({type(exc).__name__})"}
    return experience(ctx, data, dry_run=dry_run)


def summary(store: InputStore | None) -> dict[str, Any]:
    """Сводка реестра, worklist и чтения для статуса и доктора (только чтение). ``None`` или БД
    без реестра (миграция v6 не применена) - пустая сводка: «не заводили», не ошибка."""
    if store is None or not store.registry:
        counts = {"inputs": 0, "available": 0, "unavailable": 0, "blocked": 0, "unknown": 0,
                  "copies": 0, "experience": 0}
        return {"registry": counts, "worklist": {"open": 0, "by_status": {}},
                "runs": {}, "reads": {"portions": 0, "truncated": 0, "with_blockers": 0},
                "lease": {"active": 0, "expired": 0}}
    counts = store.counts()
    by_status = {r[0]: r[1] for r in store.conn.execute(
        "SELECT status, COUNT(*) FROM sleep_worklist GROUP BY status")}
    runs = {r[0]: r[1] for r in store.conn.execute(
        "SELECT state, COUNT(*) FROM sleep_runs GROUP BY state")}
    reads = store.conn.execute(
        "SELECT COUNT(*), COALESCE(SUM(truncated), 0), "
        "COALESCE(SUM(CASE WHEN blockers_json <> '[]' THEN 1 ELSE 0 END), 0) "
        "FROM sleep_reads").fetchone()
    from core.sleep_store.store import now_iso

    now = now_iso()
    active = expired = 0
    for r in store.conn.execute(
            "SELECT lease_holder, lease_until FROM sleep_runs WHERE lease_holder IS NOT NULL "
            "AND lease_holder <> ''"):
        if str(r["lease_until"] or "") > now:
            active += 1
        else:
            expired += 1
    return {
        "registry": counts,
        "worklist": {"open": int(by_status.get("queued", 0) + by_status.get("tail", 0)
                                 + by_status.get("failed", 0)),
                     "by_status": by_status},
        "runs": runs,
        "reads": {"portions": int(reads[0]), "truncated": int(reads[1]),
                  "with_blockers": int(reads[2])},
        "lease": {"active": active, "expired": expired},
    }


def inputs(ctx: Ctx, *, stale: bool = False, blocked: bool = False,
           limit: int = 50) -> dict[str, Any]:
    """Список реестра входов (``--stale``: недоступные и с изменившимся источником под принятым
    знанием; ``--blocked``: заблокированные приватностью)."""
    try:
        store = InputStore.open_readonly(ctx.db_path)
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
    if store is None or not store.registry:
        return {"ok": True, "present": False, "rows": [], "total": 0, "counts": {},
                "hint": "реестр входов еще не заводили: dt sleep plan --apply"}
    try:
        state = {r["source_id"]: r for r in store.inputs()}
        from core.sleep_input.plan import dependent_claims

        flagged: set[str] = set()
        if stale:
            deps = dependent_claims(store, state)
            flagged = set(deps) | {sid for sid, r in state.items()
                                   if r["availability"] == "unavailable"}
        rows = []
        for r in state.values():
            if blocked and r["availability"] != "blocked":
                continue
            if stale and r["source_id"] not in flagged:
                continue
            rows.append({k: r[k] for k in (
                "source_id", "family_id", "kind", "locator", "revision", "availability",
                "privacy", "unavailable_reason", "valid_date", "updated_at", "is_copy")})
        rows.sort(key=lambda r: (r["updated_at"], r["source_id"]), reverse=True)
        return {"ok": True, "present": True, "rows": rows[: max(1, int(limit))],
                "total": len(rows), "counts": store.counts(),
                "filter": "stale" if stale else ("blocked" if blocked else "all")}
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
    finally:
        store.close()
