"""SLEEP-INPUT-1 п.2 - ``plan_sleep(scope, mode, budgets)`` -> run_id, manifest, estimate, skipped.

План - ОТБОР входов прогона и ничего больше: модель не вызывается, знания и facts не меняются.
Без ``apply`` не пишется ничего (ни ``dt.db``, ни ``.derived``, ни кэш frontmatter): реестр и ledger
открываются строго на чтение, решения по входам считаются в памяти. С ``apply`` - реестр входов,
прогон (``sleep_runs``, состояние ``planned``) и worklist (``sleep_worklist``) пишутся одной
транзакцией; манифест копией лежит в одноразовом пакете ``.derived/sleep/<run_id>/``.

**Отбор** (sleep-1.md §4.1): кандидат - ревизия входа, которой нет в worklist ни как обработанной,
ни как стоящей в очереди; плюс знания ledger, чей источник изменился или исчез
(``dependent_knowledge``), плюс замечания владельца из явно сданного опыта сессий. Копии входов,
чей первоисточник доступен, в манифест не идут (не независимые подтверждения; их число - сигнал
первоисточника).

**Приоритет** (тот же каркас и те же сигналы, что у USE-LOOP-1: :mod:`core.decisions.proximity`,
сопоставление сделка/встреча -> хаб не новое)::

    priority = NEAR_BONUS * доля_близости + Σ вес(причина) + свежесть(0..30 ступенями)

* ``близость`` = 1, если вход принадлежит хабу АКТИВНОЙ сделки К. либо встречи в ближайшие
  ``MEETING_DAYS`` дней (``Signals.deals`` / ``Signals.meetings``); сбой сигнала не роняет план и
  не врет (``signals`` в ответе: ``ok|off|unavailable``).
* веса причин - таблица :data:`WEIGHTS` (данные, не код): исправление повторяющейся ошибки >
  замечание владельца > существенное изменение проекта (ревизия входа хаба) > зависимое знание >
  связь нескольких источников > проверенный прием > новый вход хаба; ниже всех - «пересказ»
  (новый вход без связи с хабом/сделкой/замечанием) и устаревший вход с высоким риском.
* ``свежесть`` - возраст документа ступенями (:data:`AGE_STEPS`, 0..30, новее - выше). Дата: дата
  действия входа, иначе дата из имени файла (``20250525``, ``10032022``, ``2021-03-04``, год), иначе
  mtime заметки; чем взята - ``signals.age.basis``. Вход старше :data:`STALE_AFTER_DAYS` получает
  причину ``stale_input`` (отрицательный вес), если за ним нет сильной причины (замечание,
  зависимое знание, прием, проверка старой памяти). Явный признак копии в имени («- копия»,
  ``copy``, ``(1)``) - причина ``copy_mark`` (отрицательный вес): копия с тем же хешем и так уходит
  из манифеста (identity), копия с правкой - ниже оригинала.
* **Исторический импорт чатов** (``history_import``): заметка, созданная импортом разговора Claude
  (``source_type: claude-conversation``, тег ``claude-import``, каталог
  ``02-knowledge/conversations/`` либо id ``claude-conversation-<uuid>[-part-N]``), - пересказ, а
  не первоисточник (sleep-1.md §4.2). Вес ниже ``new_input``; доля близости :data:`NEAR_SHARE` = 0
  (близость к сделке не поднимает пересказ над первоисточниками хаба); части одного разговора -
  одно семейство: в манифест идет одна позиция, остальные не берутся этим планом
  (``skipped.copies``, у позиции ``signals.history_import.siblings_skipped``) и приходят
  следующими планами по одной.

У каждой позиции - ``intended_use`` (предполагаемая задача использования) и ``difference``
(отличие от имеющегося): значение ``неизвестно``, когда по сигналам их не определить.

**Хвост worklist.** Что не влезло в бюджет (``items``, ``per_hub``) либо осталось от отмененного/
недоделанного прогона, хранится позициями ``tail``/``queued`` и берется следующим планом ПЕРВЫМ
(строка переносится в новый прогон, а не копируется: хвост не множится). Ревизия, обогнавшая
позицию хвоста (позднее сообщение, правка), обновляет ее. Хранится не больше ``tail`` позиций;
остаток не теряется - он вычисляется заново как «ревизии без позиции» (``tail_unstored``).

**Идемпотентность:** ``run_id = plan-<отпечаток>`` от (режим, область, бюджеты, ключи манифеста и
хвоста); повтор ``--apply`` с теми же входами возвращает тот же прогон (``replayed``), строк не
добавляет. Прогон с активным lease не трогается (хвост из него не забирается, ``run_active``).
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, date, datetime
from pathlib import Path, PurePosixPath
from typing import Any

from core.contract import CODE_PARTIAL, warning
from core.sleep_input import registry
from core.sleep_input.discover import KINDS, instance_label
from core.sleep_input.limits import PORTION_CHARS
from core.sleep_input.store import InputStore
from core.sleep_store.ctx import Ctx

__all__ = [
    "AGE_STEPS",
    "BUDGET_KEYS",
    "MODES",
    "NEAR_SHARE",
    "STALE_AFTER_DAYS",
    "WEIGHTS",
    "PlanError",
    "dependent_claims",
    "item_key",
    "plan_sleep",
]

MODES = ("incremental", "recheck")
BUDGET_KEYS = ("items", "per_hub", "seconds", "tail")
DEFAULT_BUDGETS = {"items": 20, "per_hub": 10, "seconds": 120, "tail": 1000}
NEAR_BONUS = 1000.0
#: вес причины (чем больше - тем раньше). Данные, не код: порядок задан sleep-1.md §4.1
WEIGHTS: dict[str, int] = {
    "repeat_error": 100,        # исправление повторяющейся ошибки (замечание-поправка владельца)
    "owner_remark": 85,         # замечание владельца
    "project_change": 70,       # существенное изменение проекта: ревизия входа хаба
    "dependent_knowledge": 65,  # принятое знание опирается на изменившийся/исчезнувший источник
    "multi_source": 60,         # связь нескольких независимых источников одного хаба
    "procedure": 50,            # проверенный повторно используемый прием
    "revised": 45,              # ревизия входа без связи с хабом
    "stale_check": 40,          # проверка старой памяти по риску устаревания
    "new_input": 30,            # новый вход хаба
    "retell": 10,               # пересказ: новый вход без связи с хабом, сделкой, замечанием
    "history_import": 5,        # импортированный исторический разговор: пересказ, не первоисточник
    "copy_mark": -20,           # «копия» в имени файла (если identity не поймала по хешу)
    "stale_input": -20,         # вход старше STALE_AFTER_DAYS без сильной причины
}
#: доля NEAR_BONUS по причине (нет в таблице - 1.0); берется минимум по причинам позиции
NEAR_SHARE: dict[str, float] = {"history_import": 0.0}
#: причины, которые снимают приглушение близости и штраф за возраст
STRONG_REASONS = frozenset({"repeat_error", "owner_remark", "procedure", "dependent_knowledge"})
#: причины, заменяемые на ``history_import`` у импортированного разговора
HISTORY_REPLACES = frozenset({"new_input", "revised", "project_change", "multi_source", "retell"})
#: свежесть: (возраст в днях не больше, баллы); старше последней ступени - 0
AGE_STEPS: tuple[tuple[int, int], ...] = ((7, 30), (30, 24), (90, 18), (180, 12), (365, 6))
STALE_AFTER_DAYS = 730
#: признаки исторического импорта чата (данные заметки, не одно имя файла)
HISTORY_SOURCE_TYPES = frozenset({"claude-conversation"})
HISTORY_TAGS = frozenset({"claude-import"})
HISTORY_PATH_PREFIXES = ("02-knowledge/conversations/",)
_CONV_ID_RE = re.compile(
    r"^claude-conversation-(?P<uuid>[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"
    r"(?:-part-(?P<part>\d+))?$", re.IGNORECASE)
_PART_FILE_RE = re.compile(r"(?:^|[-_ ])part[-_ ]?(?P<part>\d+)$", re.IGNORECASE)
_COPY_MARK_RE = re.compile(
    r"(?<![\w])(?:копия|copy)(?![\w])|\(\d{1,2}\)\s*$", re.IGNORECASE)
_DATE_NAME_RES = (
    re.compile(r"(?<!\d)((?:19|20)\d{2})[-._]?(0[1-9]|1[0-2])[-._]?(0[1-9]|[12]\d|3[01])(?!\d)"),
    re.compile(r"(?<!\d)(0[1-9]|[12]\d|3[01])[-._]?(0[1-9]|1[0-2])[-._]?((?:19|20)\d{2})(?!\d)"),
)
_YEAR_NAME_RE = re.compile(r"(?<!\d)((?:19|20)\d{2})(?!\d)")
_SAMPLE = 20


class PlanError(ValueError):
    """Отказ плана: ``code`` машиночитаем (``bad_mode`` | ``bad_scope`` | ``bad_budget`` |
    ``vault_unavailable``)."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def item_key(source_id: str, revision: int) -> str:
    return f"{source_id}@{revision}"


# --------------------------------------------------------------------------- #
# Параметры                                                                     #
# --------------------------------------------------------------------------- #
def _budgets(raw: dict[str, Any] | None) -> dict[str, int]:
    out = dict(DEFAULT_BUDGETS)
    for key, value in (raw or {}).items():
        if key not in BUDGET_KEYS:
            raise PlanError("bad_budget", f"budgets: неизвестный ключ {key!r}; "
                                          f"допустимо {', '.join(BUDGET_KEYS)}")
        try:
            number = int(value)
        except (TypeError, ValueError):
            number = 0
        if number < 1:
            raise PlanError("bad_budget", f"budgets.{key}: нужно целое >= 1, получено {value!r}")
        out[key] = number
    return out


def _scope(raw: str | None) -> tuple[str, tuple[str, str] | None]:
    text = (raw or "all").strip() or "all"
    if text == "all":
        return "all", None
    head, _, tail = text.partition(":")
    if head == "hub" and tail.strip():
        return f"hub:{tail.strip()}", ("hub", tail.strip())
    if head == "kind" and tail.strip() in (*KINDS, "experience"):
        return f"kind:{tail.strip()}", ("kind", tail.strip())
    raise PlanError("bad_scope", f"scope {text!r}: допустимо all | hub:<id хаба> | "
                                 f"kind:{'|'.join((*KINDS, 'experience'))}")


# --------------------------------------------------------------------------- #
# Состояние реестра (с учетом решений этого обхода, без записи)                  #
# --------------------------------------------------------------------------- #
def _state(store: InputStore | None, rplan: registry.RefreshPlan,
           apply: bool) -> dict[str, dict[str, Any]]:
    """``source_id -> строка реестра``. При ``apply`` реестр уже записан и читается из БД; без
    ``apply`` решения обхода накладываются на записанное в памяти - итог тот же."""
    rows: dict[str, dict[str, Any]] = {}
    if store is not None and store.registry:
        rows = {r["source_id"]: r for r in store.inputs()}
    if apply:
        return rows
    for r in rplan.resolved:
        obs, dec = r.obs, r.decision
        base = dict(rows.get(dec.source_id) or {
            "source_id": dec.source_id, "discovered_at": "", "kind": obs.kind})
        base.update(
            family_id=dec.family_id, origin_id=dec.origin_id, is_copy=int(dec.is_copy),
            revision=dec.revision, locator=obs.locator, note_rel=obs.note_rel,
            note_id=obs.note_id, content_hash=obs.content_hash, valid_date=obs.valid_date,
            privacy=obs.privacy, availability=r.availability, size=obs.size, kind=obs.kind,
            coverage=obs.coverage, coverage_scope=obs.coverage_scope,
            extract_method=obs.extract_method, instance=obs.instance, stat_sig=obs.stat_sig)
        rows[dec.source_id] = base
    for row in rplan.missing:
        rows[row["source_id"]] = {**rows[row["source_id"]], "availability": "unavailable"}
    for source_id, reason in rplan.to_block:
        if source_id in rows:
            rows[source_id] = {**rows[source_id], "availability": "blocked",
                               "unavailable_reason": reason}
    return rows


# --------------------------------------------------------------------------- #
# Сигналы                                                                       #
# --------------------------------------------------------------------------- #
def _read_metas(vault: Path) -> tuple[list[Any], list[Any]]:
    """Срезы frontmatter БЕЗ записи кэша: снимок как есть, иначе обход диска (кэша нет).

    Нечитаемая заметка пропускается (ее ошибка уже названа обходом реестра)."""
    from core.retrieval.fm_cache import peek_metas
    from core.retrieval.notemeta import meta_from_note
    from core.vault import iter_vault_paths, read_note

    metas = peek_metas(vault)
    if metas:
        return metas, []
    out: list[Any] = []
    for path in iter_vault_paths(vault):
        try:
            out.append(meta_from_note(read_note(path, vault), vault))
        except Exception:  # noqa: BLE001, S112 - битая заметка не роняет сопоставление с хабами
            continue
    return out, []


def _load_signals(ctx: Ctx, now_dt: datetime, warnings: list[dict[str, Any]]) -> Any:
    try:
        from core.decisions import QueueEnv
        from core.decisions.proximity import load_signals

        env = QueueEnv(vault=ctx.vault, now=now_dt)
        return load_signals(env, now_dt, load_metas=_read_metas)
    except Exception as exc:  # noqa: BLE001 - без сигналов план жив, но говорит об этом
        warnings.append(warning(
            "signals_unavailable", "сигналы сделок и встреч не прочитаны: в приоритете они не "
            "учтены", error=type(exc).__name__))
        return None


def _project_title_owner(vault: Path, hub_id: str):
    """Resolve one real project and use only its explicit aliases for title matching."""
    from core.ingest import EntityRef
    from core.privacy import any_nda
    from core.vault import read_note, resolve_note_path

    if not hub_id.startswith("project-"):
        return None
    path = resolve_note_path(hub_id, vault_path=vault)
    if path is None or any_nda(path):
        return None
    note = read_note(path, vault)
    if note.type != "hub" or note.id != hub_id or note.frontmatter.get("entity") != "project":
        return None
    raw = note.frontmatter.get("aliases") or []
    aliases = [raw] if isinstance(raw, str) else raw
    aliases = [name for name in aliases if isinstance(name, str) and len(name.strip()) >= 4]
    return EntityRef("project", hub_id, aliases, aliases) if aliases else None


def _note_index(vault: Path, rels: set[str], *, fresh: bool = False, scoped_hub: str = ""
                ) -> dict[str, tuple[tuple[str, ...], frozenset[str]]]:
    """``note_rel -> (id хабов-владельцев, теги)``: хабы - client/project/product/links, теги - из
    срезов frontmatter (один проход)."""
    from core.privacy import any_nda
    from core.retrieval.notemeta import meta_from_note, owner_ids
    from core.vault import read_note

    if not fresh:
        metas, _w = _read_metas(vault)
        return {
            m.path: (tuple(sorted(owner_ids(m))),
                     frozenset(t.strip().lower() for t in m.fields.get("tags", ())))
            for m in metas if m.path in rels
        }
    # Scope is a data boundary. An index snapshot can miss a new or reassigned note
    # between fast ingestion and reindex. Read only the scoped candidate paths.
    from core.linking.deterministic import deterministic_links
    from core.linking.signals import NoteSignals, signals_for_note

    root = vault.resolve()
    project = _project_title_owner(root, scoped_hub)
    out: dict[str, tuple[tuple[str, ...], frozenset[str]]] = {}
    for rel in rels:
        path = root / rel
        try:
            target = path.resolve()
            if target != path or not target.is_relative_to(root) or any_nda(path, target):
                continue
            note = read_note(path, root)
            meta = meta_from_note(note, root)
        except Exception:  # noqa: BLE001, S112 - discovery reports unreadable notes separately
            continue
        tags = frozenset(t.strip().lower() for t in meta.fields.get("tags", ()))
        owners = owner_ids(meta)
        if (project and note.frontmatter.get("source_type") == "email-thread"
                and not any(owner.startswith("project-") for owner in owners)):
            title = signals_for_note(note).title
            if deterministic_links(NoteSignals(meta.id, title=title), [project]):
                owners.add(project.id)
        out[rel] = (tuple(sorted(owners)), tags)
    return out


def _experience_signals(store: InputStore | None) -> dict[str, dict[str, Any]]:
    """Сигналы явно сданного опыта: ``source_id -> {owner_remark, repeat_error, procedure, refs}``
    по последней ревизии пакета каждой сессии."""
    if store is None or not store.registry:
        return {}
    out: dict[str, dict[str, Any]] = {}
    for row in store.conn.execute(
            "SELECT e.source_id, e.package_json FROM sleep_experience e WHERE e.revision = "
            "(SELECT MAX(revision) FROM sleep_experience WHERE source_id = e.source_id)"):
        try:
            pkg = json.loads(row["package_json"])
        except ValueError:
            continue
        sig = pkg.get("signals")
        out[row["source_id"]] = sig if isinstance(sig, dict) else {}
    return out


def dependent_claims(store: InputStore | None,
                state: dict[str, dict[str, Any]]) -> dict[str, list[str]]:
    """Принятые утверждения ledger, чей источник изменился или исчез (``source_id -> claims``)."""
    if store is None or not store.registry or not store.has_table("sleep_evidence"):
        return {}
    out: dict[str, set[str]] = {}
    for e in store.conn.execute(
            "SELECT e.source_id, e.source_revision, e.content_hash, e.claim_id FROM sleep_evidence"
            " e JOIN sleep_claims c ON c.row_id = e.claim_row WHERE c.layer = 'accepted'"):
        row = state.get(e["source_id"])
        if row is None:
            continue
        gone = row["availability"] == "unavailable"
        moved = (int(e["source_revision"] or 0) > 0
                 and int(row["revision"]) > int(e["source_revision"])) or bool(
            e["content_hash"] and row["content_hash"] and e["content_hash"] != row["content_hash"])
        if gone or moved:
            out.setdefault(e["source_id"], set()).add(e["claim_id"])
    return {k: sorted(v) for k, v in out.items()}


def _stale_risk(store: InputStore | None, state: dict[str, dict[str, Any]],
                today: str) -> dict[str, tuple[int, list[str]]]:
    """Режим ``recheck``: источники принятых утверждений по риску устаревания (чем выше балл,
    тем раньше): ``needs_check`` 3, срок ``valid_to`` вышел 2, ``stale_risk`` high 2 / medium 1 /
    unknown 1, принято давно (> 180 дн) 1."""
    if store is None or not store.registry or not store.has_table("sleep_evidence"):
        return {}
    out: dict[str, tuple[int, list[str]]] = {}
    for c in store.conn.execute(
            "SELECT claim_id, row_id, needs_check, valid_to, recorded_at, body_json "
            "FROM sleep_claims WHERE layer = 'accepted'"):
        try:
            risk_name = str(json.loads(c["body_json"]).get("stale_risk") or "unknown")
        except ValueError:
            risk_name = "unknown"
        score = 3 * int(c["needs_check"] or 0)
        score += 2 if c["valid_to"] and str(c["valid_to"])[:10] < today else 0
        score += {"high": 2, "medium": 1, "unknown": 1}.get(risk_name, 0)
        score += 1 if str(c["recorded_at"] or "")[:10] and str(c["recorded_at"])[:10] < (
            f"{int(today[:4]) - 1}{today[4:]}") else 0
        if not score:
            continue
        for e in store.conn.execute(
                "SELECT DISTINCT source_id FROM sleep_evidence WHERE claim_row=?",
                (c["row_id"],)):
            if e["source_id"] in state:
                prev = out.get(e["source_id"], (0, []))
                out[e["source_id"]] = (max(prev[0], score), [*prev[1], c["claim_id"]])
    return out


# --------------------------------------------------------------------------- #
# Отбор                                                                         #
# --------------------------------------------------------------------------- #
@dataclass
class _Cand:
    row: dict[str, Any]
    reasons: list[str]
    carried_from: str = ""
    carried_item: str = ""
    carried_status: str = ""
    seq_hint: int = 0
    priority: float = 0.0
    signals: dict[str, Any] | None = None
    intended_use: str = ""
    difference: str = ""
    hub: str = ""
    history: dict[str, Any] | None = None

    @property
    def key(self) -> str:
        return item_key(self.row["source_id"], int(self.row["revision"]))


def _history_import(row: dict[str, Any], tags: frozenset[str]) -> dict[str, Any] | None:
    """Исторический импорт чата по данным входа: ``source_type`` (``extract_method`` реестра), тег,
    каталог импорта или id вида ``claude-conversation-<uuid>[-part-N]``. ``None`` - не импорт.

    ``{"family": ключ разговора, "part": номер части (индекс разговора - после всех частей)}``."""
    rel = str(row.get("note_rel") or "")
    note_id = str(row.get("note_id") or "")
    id_hit = _CONV_ID_RE.match(note_id)
    by_path = any(rel.startswith(p) for p in HISTORY_PATH_PREFIXES)
    if not (str(row.get("extract_method") or "") in HISTORY_SOURCE_TYPES
            or tags & HISTORY_TAGS or by_path or id_hit):
        return None
    parent = rel.rpartition("/")[0]
    family = id_hit.group("uuid").lower() if id_hit else (parent or note_id or rel)
    part_text = id_hit.group("part") if id_hit and id_hit.group("part") else ""
    if not part_text:
        file_hit = _PART_FILE_RE.search(rel.rpartition("/")[2].removesuffix(".md"))
        part_text = file_hit.group("part") if file_hit else ""
    return {"family": f"history:{family}", "part": int(part_text) if part_text else 10**6}


def _name_date(text: str) -> str:
    """Дата из имени файла: ``20250525``/``2025-05-25``, ``10032022``/``10.03.2022``; нет - только
    год (середина года). Пусто - даты в имени нет."""
    for rx, order in zip(_DATE_NAME_RES, ("ymd", "dmy"), strict=True):
        for m in rx.finditer(text):
            parts = {k: int(v) for k, v in zip(order, m.groups(), strict=True)}
            try:
                return date(parts["y"], parts["m"], parts["d"]).isoformat()
            except ValueError:
                continue
    years = [int(y) for y in _YEAR_NAME_RE.findall(text)]
    return f"{max(years)}-07-01" if years else ""


def _name_texts(row: dict[str, Any]) -> list[str]:
    """Имена, по которым судят о дате и копии: файл-источник (его имя), затем заметка."""
    texts: list[str] = []
    if row.get("kind") == "file" and row.get("locator"):
        texts.append(PurePosixPath(str(row["locator"]).replace("\\", "/")).stem)
    if row.get("note_rel"):
        texts.append(PurePosixPath(str(row["note_rel"])).stem)
    return texts


def _doc_age(row: dict[str, Any], today: str) -> dict[str, Any]:
    """Возраст документа: дата действия, иначе дата из имени, иначе mtime заметки (``stat_sig``).
    ``{"date", "basis": valid_date|name|mtime|none, "days"}``; даты нет - ``days=None``."""
    candidates: list[tuple[str, str]] = [("valid_date", str(row.get("valid_date") or "")[:10])]
    candidates += [("name", _name_date(t)) for t in _name_texts(row)]
    try:
        mtime_ns = int(str(row.get("stat_sig") or "").partition(":")[0])
        candidates.append(("mtime", datetime.fromtimestamp(mtime_ns / 1e9, UTC).date().isoformat()))
    except (ValueError, OverflowError, OSError):
        pass
    for basis, day in candidates:
        if not day:
            continue
        try:
            days = (date.fromisoformat(today) - date.fromisoformat(day)).days
        except ValueError:
            continue
        return {"date": day, "basis": basis, "days": max(days, 0)}
    return {"date": "", "basis": "none", "days": None}


def _age_bonus(days: int | None) -> float:
    """Свежесть ступенями :data:`AGE_STEPS`: 0..30; даты нет или старше последней ступени - 0."""
    if days is None:
        return 0.0
    for limit, points in AGE_STEPS:
        if days <= limit:
            return float(points)
    return 0.0


def _copy_marked(row: dict[str, Any]) -> bool:
    if row.get("kind") not in ("file", "note"):
        return False
    return any(_COPY_MARK_RE.search(t) for t in _name_texts(row))


def _ru_day(day: str) -> str:
    return f"{day[8:10]}.{day[5:7]}"


def plan_sleep(
    ctx: Ctx, *, scope: str | None = None, mode: str = "incremental",
    budgets: dict[str, Any] | None = None, apply: bool = False, signals: Any = None,
    clock: Callable[[], float] = time.monotonic,
) -> dict[str, Any]:
    """План прогона. Отказ параметров - :class:`PlanError`; недоступная БД - ``sqlite3.Error``
    наверх (поверхность отвечает ``store_unavailable``, не пустым планом)."""
    if mode not in MODES:
        raise PlanError("bad_mode", f"mode {mode!r}: допустимо {', '.join(MODES)}")
    vault = Path(ctx.vault)
    # SLEEP-PULT-1 п.5: умолчания области и пределов - из профиля Сна; явные параметры сильнее
    from core.sleep_input import profile as _profile

    p_scope, p_budgets, p_status = _profile.resolve_plan_defaults(vault)
    if p_status is not None:
        p_status["used"] = sorted(
            ([] if scope is not None or p_scope is None else ["scope"])
            + [k for k in p_budgets if k not in (budgets or {})]) if p_status["applied"] else []
    scope_text, scope_filter = _scope(scope if scope is not None else p_scope)
    limits = _budgets({**p_budgets, **(budgets or {})})
    if not vault.is_dir():
        raise PlanError("vault_unavailable", "vault недоступен: это ошибка, а не «входов нет»")
    now = ctx.stamp()
    now_dt = datetime.fromisoformat(now.replace("Z", "+00:00")).astimezone(UTC)
    today = now_dt.date().isoformat()
    warnings: list[dict[str, Any]] = []
    deadline = clock() + limits["seconds"]

    store = InputStore.open(ctx.db_path) if apply else InputStore.open_readonly(ctx.db_path)
    try:
        disc, rplan, written = registry.refresh(
            vault, db_path=ctx.db_path, now=now, apply=apply, instance=instance_label(),
            clock=clock, deadline=deadline)
        if apply and store is not None:  # реестр записан отдельным соединением: перечитать
            store.registry = store.has_table("sleep_inputs")
        state = _state(store, rplan, apply)
        out = _plan(ctx, store, state, rplan, disc, written, scope_text, scope_filter, mode,
                    limits, apply, signals, now, now_dt, today, warnings)
    finally:
        if store is not None:
            store.close()
    if p_status is not None:
        out["profile"] = p_status
        if not p_status["valid"]:
            out["warning"] = [*out.get("warning", []), warning(
                "profile_invalid", "профиль Сна не разобран: план идет на умолчаниях кода",
                problems=p_status.get("problems"))]
    return out


def _plan(ctx: Ctx, store: InputStore | None, state: dict[str, dict[str, Any]],
          rplan: registry.RefreshPlan, disc: Any, written: dict[str, Any] | None,
          scope_text: str, scope_filter: tuple[str, str] | None, mode: str,
          limits: dict[str, int], apply: bool, signals: Any, now: str, now_dt: datetime,
          today: str, warnings: list[dict[str, Any]]) -> dict[str, Any]:
    vault = Path(ctx.vault)
    skipped: dict[str, Any] = {
        "refused": dict(disc.refused), "refused_paths": dict(disc.refused_paths),
        "blocked": [], "unavailable": [], "copies": 0, "handled": 0, "carried_dropped": [],
        "errors": list(disc.errors[:_SAMPLE]), "per_hub_limit": 0}
    if disc.errors:
        warnings.append(warning(
            CODE_PARTIAL, "часть заметок не прочитана: это ошибка чтения, а не «пусто»",
            count=len(disc.errors)))
    if not disc.complete:
        warnings.append(warning(
            "scan_incomplete", "обход vault прерван по времени (budgets.seconds): исчезновение "
            "входов не объявлялось"))
    sig = signals if signals is not None else _load_signals(ctx, now_dt, warnings)
    sig_status = dict(getattr(sig, "status", {}) or {}) if sig is not None else {
        "deals": "unavailable", "meetings": "unavailable"}

    have = store is not None and store.registry
    handled_all = store.handled_keys() if have and store else set()
    done_keys = store.handled_keys(("done", "skipped")) if have and store else set()
    queued_keys = store.handled_keys(("queued", "tail")) if have and store else set()
    rechecked = store.reason_keys("stale_check") if have and store else set()
    vanished = store.reason_keys("source_unavailable") if have and store else set()
    for row in state.values():
        if row["availability"] == "blocked":
            skipped["blocked"].append({"source_id": row["source_id"],
                                       "reason": row.get("unavailable_reason") or "blocked"})
        elif row["availability"] == "unavailable":
            skipped["unavailable"].append({"source_id": row["source_id"],
                                           "locator": row["locator"]})

    # --- кандидаты: ревизии без позиции worklist -------------------------------------------- #
    cands: dict[str, _Cand] = {}
    exp_signals = _experience_signals(store)
    dependents = dependent_claims(store, state)
    stale = _stale_risk(store, state, today) if mode == "recheck" else {}
    for row in sorted(state.values(), key=lambda r: r["source_id"]):
        if row["availability"] != "available" or row["privacy"] != "work":
            continue
        pair = (row["source_id"], int(row["revision"]))
        key = item_key(*pair)
        if row["is_copy"] and state.get(row["origin_id"], {}).get("availability") == "available":
            skipped["copies"] += 1
            continue
        reasons: list[str] = []
        if mode == "incremental" and pair not in handled_all:
            reasons.append("new_input" if pair[1] == 1 else "revised")
        if row["source_id"] in dependents and pair not in handled_all:
            reasons.append("dependent_knowledge")
        if row["source_id"] in stale and pair not in queued_keys and pair not in rechecked:
            reasons.append("stale_check")
        if reasons:
            cands[key] = _Cand(row, reasons)
        elif pair in handled_all:
            skipped["handled"] += 1
    for sid, claims in dependents.items():  # источник исчез: проверка знания без нового чтения
        row = state[sid]
        key = item_key(sid, int(row["revision"]))
        if (row["availability"] == "unavailable" and key not in cands
                and (sid, int(row["revision"])) not in vanished):
            cands[key] = _Cand(row, ["dependent_knowledge", "source_unavailable"])
        if key in cands:
            cands[key].signals = {**(cands[key].signals or {}), "dependent_claims": claims}

    # --- хвост прежних прогонов: первым ------------------------------------------------------ #
    carried, blockers = _carry(store, state, cands, done_keys, skipped, scope_filter, now)
    for b in blockers:
        warnings.append(b)

    pool = [*carried, *sorted(cands.values(), key=lambda c: c.key)]
    pool = [c for c in pool if _in_scope(c, scope_filter, state)]
    scoped_hub = scope_filter[1] if scope_filter and scope_filter[0] == "hub" else ""
    hubs = _note_index(vault, {c.row["note_rel"] for c in pool if c.row["note_rel"]},
                       fresh=bool(scoped_hub), scoped_hub=scoped_hub)
    _enrich(pool, state, sig, hubs, exp_signals, dependents, stale, store, today)
    if scope_filter is not None and scope_filter[0] == "hub":
        pool = [c for c in pool if scope_filter[1] in (c.signals or {}).get("hubs", [])]
    pool = _collapse_history(pool, skipped)

    order = sorted(pool, key=_order_key)
    manifest, tail = _cut(order, limits, skipped)
    unstored = max(0, len(tail) - limits["tail"])
    tail = tail[: limits["tail"]]
    _detail([*manifest, *tail], store)
    estimate = _estimate(manifest, tail, unstored)
    digest = _digest(mode, scope_text, limits, manifest, tail)
    result: dict[str, Any] = {
        "ok": True, "applied": False, "replayed": False, "run_id": None, "mode": mode,
        "scope": scope_text, "budgets": limits, "signals": sig_status,
        "manifest": [_public(c, "queued", i) for i, c in enumerate(manifest, 1)],
        "tail": [_public(c, "tail", len(manifest) + i) for i, c in enumerate(tail, 1)],
        "estimate": estimate, "skipped": _skipped_public(skipped),
        "carried": {"items": sum(1 for c in order if c.carried_from),
                    "runs": sorted({c.carried_from for c in order if c.carried_from})},
        "registry": rplan.counts(), "scan": {"scanned": disc.scanned, "reused": disc.reused,
                                             "complete": disc.complete},
        "plan_digest": digest,
    }
    if warnings:
        result["warning"] = warnings
    if not manifest and not tail:
        result["note"] = "нового для сна нет (ошибки и пропуски - в skipped и warning)"
        return result
    if not apply or store is None:
        return result
    return _apply(ctx, store, result, manifest, tail, order, scope_text, mode, limits, digest,
                  estimate, skipped, now)


def _order_key(c: _Cand) -> tuple[int, float, str]:
    """Хвост прежних прогонов первым (в прежнем порядке), затем новые по убыванию приоритета."""
    if c.carried_from:
        return (0, float(c.seq_hint), c.row["source_id"])
    return (1, -c.priority, c.row["source_id"])


def _in_scope(c: _Cand, scope_filter: tuple[str, str] | None,
              state: dict[str, dict[str, Any]]) -> bool:
    if scope_filter is None or scope_filter[0] != "kind":
        return True
    return str(c.row["kind"]) == scope_filter[1]


def _carry(store: InputStore | None, state: dict[str, dict[str, Any]], cands: dict[str, _Cand],
           done_keys: set[tuple[str, int]], skipped: dict[str, Any],
           scope_filter: tuple[str, str] | None,
           now: str) -> tuple[list[_Cand], list[dict[str, Any]]]:
    """Позиции хвоста прежних прогонов, актуализированные по текущему реестру."""
    if store is None or not store.registry:
        return [], []
    out: list[_Cand] = []
    blockers: list[dict[str, Any]] = []
    seen: set[str] = set()
    active: set[str] = set()
    for it in store.open_items():
        if store.lease_active(it, now):
            active.add(it["run_id"])
            continue
        row = state.get(it["source_id"])
        why = ""
        if row is None:
            why = "source_gone"
        elif (row["availability"] != "available" or row["privacy"] != "work") and (
                "source_unavailable" not in json.loads(it["reasons_json"] or "[]")):
            why = "source_unavailable"
        elif (row["source_id"], int(row["revision"])) in done_keys:
            why = "already_handled"
        if why or row is None:
            skipped["carried_dropped"].append({"item_id": it["item_id"], "reason": why,
                                               "run_id": it["run_id"]})
            continue
        key = item_key(row["source_id"], int(row["revision"]))
        if key in seen:
            continue
        seen.add(key)
        reasons = [r for r in json.loads(it["reasons_json"] or "[]")]
        if int(row["revision"]) != int(it["revision"]):
            reasons = ["revised_since_plan", *[r for r in reasons if r != "revised_since_plan"]]
        cand = cands.pop(key, None)
        if cand is not None:
            reasons += [r for r in cand.reasons if r not in reasons]
        out.append(_Cand(row, reasons, carried_from=it["run_id"], carried_item=it["item_id"],
                         carried_status=it["status"], seq_hint=len(out)))
    for run_id in sorted(active):
        blockers.append(warning(
            "run_active", "у прогона действующий lease: его хвост не забирается",
            run_id=run_id))
    return out, blockers


def _enrich(pool: list[_Cand], state: dict[str, dict[str, Any]], sig: Any,
            hubs: dict[str, tuple[tuple[str, ...], frozenset[str]]], exp: dict[str, dict[str, Any]],
            dependents: dict[str, list[str]], stale: dict[str, tuple[int, list[str]]],
            store: InputStore | None, today: str) -> None:
    titles: dict[str, str] = dict(getattr(sig, "titles", {}) or {}) if sig is not None else {}
    deals = getattr(sig, "deals", {}) if sig is not None else {}
    meetings = getattr(sig, "meetings", {}) if sig is not None else {}
    refs: dict[str, dict[str, Any]] = {}
    for sid, s in exp.items():  # на что ссылается замечание владельца: локатор/id заметки/source_id
        for ref in s.get("refs") or []:
            refs.setdefault(str(ref), {}).update({k: v for k, v in s.items() if k != "refs"},
                                                 source=sid)
    by_hub: dict[str, set[str]] = {}
    for c in pool:
        owners, tags = hubs.get(c.row["note_rel"], ((), frozenset()))
        c_hubs = [h for h in owners if (not titles or h in titles)]
        c.hub = c_hubs[0] if c_hubs else ""
        c.signals = {**(c.signals or {}), "hubs": c_hubs}
        c.history = _history_import(c.row, tags)
        for h in c_hubs:
            if c.history is None:  # пересказ разговора - не независимый первоисточник хаба
                by_hub.setdefault(h, set()).add(c.row["family_id"])
    for c in pool:
        row = c.row
        sg = c.signals or {}
        flags = dict(refs.get(row["locator"]) or refs.get(row["note_id"])
                     or refs.get(row["source_id"]) or {})
        if row["kind"] == "experience":
            flags = {**flags, **exp.get(row["source_id"], {})}
        if flags.get("repeat_error"):
            c.reasons.append("repeat_error")
        if flags.get("owner_remark"):
            c.reasons.append("owner_remark")
        if flags.get("procedure"):
            c.reasons.append("procedure")
        if c.history is not None:
            c.reasons = [r for r in c.reasons if r not in HISTORY_REPLACES]
            c.reasons.append("history_import")
            part = c.history["part"]
            sg["history_import"] = {"family": c.history["family"],
                                    "part": None if part >= 10**6 else part}
        if c.hub and "revised" in c.reasons:
            c.reasons = ["project_change" if r == "revised" else r for r in c.reasons]
        if c.hub and len(by_hub.get(c.hub, ())) >= 2 and "new_input" in c.reasons:
            c.reasons.append("multi_source")
            sg["independent_families"] = len(by_hub[c.hub])
        if "new_input" in c.reasons and not c.hub and not any(
                r in c.reasons for r in ("repeat_error", "owner_remark", "procedure",
                                         "dependent_knowledge")):
            c.reasons = ["retell" if r == "new_input" else r for r in c.reasons]
        age = _doc_age(row, today)
        sg["age"] = age
        strong = bool(STRONG_REASONS & set(c.reasons))
        if _copy_marked(row):
            c.reasons.append("copy_mark")
        if (age["days"] is not None and age["days"] > STALE_AFTER_DAYS and not strong
                and "stale_check" not in c.reasons):
            c.reasons.append("stale_input")
        c.reasons = list(dict.fromkeys(c.reasons))
        near: dict[str, Any] | None = None
        for h in sg.get("hubs", []):
            if deals.get(h):
                near = {"kind": "deal", "hub_id": h, "label": titles.get(h) or h}
                break
        if near is None:
            best: tuple[int, str, str] | None = None
            for h in sg.get("hubs", []):
                for m in meetings.get(h, ()):
                    k = (int(m["days"]), str(m["day"]), h)
                    if best is None or k < best:
                        best = k
            if best is not None:
                near = {"kind": "meeting", "hub_id": best[2], "day": best[1], "days": best[0],
                        "label": titles.get(best[2]) or best[2]}
        if near:
            sg["near"] = near
        if row["source_id"] in dependents:
            sg["dependent_claims"] = dependents[row["source_id"]]
        share = 1.0 if strong else min(
            (NEAR_SHARE.get(r, 1.0) for r in c.reasons), default=1.0)
        c.priority = round(
            (NEAR_BONUS * share if near else 0.0) + sum(WEIGHTS.get(r, 0) for r in c.reasons)
            + (stale[row["source_id"]][0] if row["source_id"] in stale else 0)
            + _age_bonus(age["days"]), 2)
        c.intended_use = _intended_use(c, sg, near)
        c.signals = sg


def _collapse_history(pool: list[_Cand], skipped: dict[str, Any]) -> list[_Cand]:
    """Части одного импортированного разговора - одно семейство: в план идет одна позиция
    (хвост прежних прогонов первым, затем по приоритету, затем меньшая часть), остальные не берутся
    этим планом (``skipped.copies``) и приходят следующими, по одной."""
    groups: dict[str, list[_Cand]] = {}
    for c in pool:
        if c.history is not None:
            groups.setdefault(c.history["family"], []).append(c)
    drop: set[int] = set()
    for members in groups.values():
        if len(members) < 2:
            continue
        members.sort(key=lambda c: (0 if c.carried_from else 1, -c.priority, c.history["part"]
                                    if c.history else 0, c.row["source_id"]))
        rest = members[1:]
        hist = dict((members[0].signals or {}).get("history_import") or {})
        hist["siblings_skipped"] = len(rest)
        members[0].signals = {**(members[0].signals or {}), "history_import": hist}
        skipped["copies"] += len(rest)
        drop.update(id(c) for c in rest)
    return [c for c in pool if id(c) not in drop]


def _detail(cands: list[_Cand], store: InputStore | None) -> None:
    """Подробности только тем, кто попал в манифест или хвост (запросы к БД - не на каждого из
    тысяч кандидатов): копии первоисточника и отличие от имеющегося."""
    for c in cands:
        sg = c.signals or {}
        if store is not None and store.registry:
            copies = [r for r in store.family_rows(c.row["family_id"])
                      if r["is_copy"] and r["source_id"] != c.row["source_id"]]
            if copies:
                sg["copies"] = len(copies)
        c.difference = _difference(c, sg, store)
        c.signals = sg


def _intended_use(c: _Cand, sg: dict[str, Any], near: dict[str, Any] | None) -> str:
    label = near["label"] if near else ""
    if "repeat_error" in c.reasons:
        return "не повторить исправленную ошибку (замечание владельца)"
    if "history_import" in c.reasons and not STRONG_REASONS & set(c.reasons):
        hubs = sg.get("hubs") or []
        tail = f"; сверить с первоисточниками хаба {hubs[0]}" if hubs else ""
        return f"исторический пересказ разговора, не первоисточник{tail}"
    if near and near["kind"] == "deal":
        return f"работа по сделке в работе: {label}"
    if near:
        return f"подготовка к встрече {_ru_day(near['day'])}: {label}"
    if "procedure" in c.reasons:
        return "повтор проверенного приема"
    if "dependent_knowledge" in c.reasons:
        return "проверка принятого знания, опирающегося на этот источник"
    if "owner_remark" in c.reasons:
        return "учесть замечание владельца в следующей работе"
    hubs = sg.get("hubs") or []
    if hubs:
        return f"состояние и решения по хабу {hubs[0]}"
    return "неизвестно"


def _difference(c: _Cand, sg: dict[str, Any], store: InputStore | None) -> str:
    if store is None or not store.registry:
        return "неизвестно (реестр не читался)"
    rev = int(c.row["revision"])
    parts: list[str] = []
    if rev >= 2:
        parts.append(f"ревизия {rev} (была {rev - 1}): содержимое изменено")
    elif c.row["kind"] != "experience":
        parts.append("новый вход")
    claims = sg.get("dependent_claims") or []
    if claims:
        parts.append(f"затрагивает принятых утверждений: {len(claims)}")
    elif store.has_table("sleep_evidence"):
        n = store.conn.execute(
            "SELECT COUNT(DISTINCT e.claim_id) FROM sleep_evidence e JOIN sleep_claims c ON "
            "c.row_id = e.claim_row WHERE c.layer='accepted' AND e.source_id IN "
            "(SELECT source_id FROM sleep_inputs WHERE family_id=?)",
            (c.row["family_id"],)).fetchone()[0]
        parts.append(f"принятых утверждений по семейству: {n}")
    if c.row["kind"] == "experience":
        parts.append("явно сданный опыт сессии")
    return "; ".join(parts) or "неизвестно"


# --------------------------------------------------------------------------- #
# Бюджет, оценка, отпечаток, запись                                             #
# --------------------------------------------------------------------------- #
def _cut(order: list[_Cand], limits: dict[str, int],
         skipped: dict[str, Any]) -> tuple[list[_Cand], list[_Cand]]:
    manifest: list[_Cand] = []
    tail: list[_Cand] = []
    per_hub: dict[str, int] = {}
    for c in order:
        over_items = len(manifest) >= limits["items"]
        over_hub = bool(c.hub) and per_hub.get(c.hub, 0) >= limits["per_hub"]
        if over_items or over_hub:
            if over_hub and not over_items:
                skipped["per_hub_limit"] += 1
            tail.append(c)
            continue
        manifest.append(c)
        if c.hub:
            per_hub[c.hub] = per_hub.get(c.hub, 0) + 1
    return manifest, tail


def _estimate(manifest: list[_Cand], tail: list[_Cand], unstored: int) -> dict[str, Any]:
    size = sum(int(c.row["size"] or 0) for c in manifest)
    return {
        "items": len(manifest), "bytes": size,
        "portions": sum(max(1, math.ceil(int(c.row["size"] or 0) / PORTION_CHARS))
                        for c in manifest),
        "tail_items": len(tail), "tail_unstored": unstored,
        "unit": "объем входов (байты заметок и порции досье), не деньги",
    }


def _digest(mode: str, scope: str, limits: dict[str, int], manifest: list[_Cand],
            tail: list[_Cand]) -> str:
    blob = json.dumps({"mode": mode, "scope": scope, "limits": limits,
                       "manifest": [c.key for c in manifest], "tail": [c.key for c in tail]},
                      sort_keys=True)
    return hashlib.sha256(blob.encode()).hexdigest()


def _public(c: _Cand, status: str, seq: int) -> dict[str, Any]:
    return {
        "item_id": c.key, "seq": seq, "source_id": c.row["source_id"],
        "revision": int(c.row["revision"]), "family_id": c.row["family_id"],
        "kind": c.row["kind"], "locator": c.row["locator"], "priority": c.priority,
        "reasons": c.reasons, "intended_use": c.intended_use, "difference": c.difference,
        "signals": c.signals or {}, "status": status, "carried_from": c.carried_from or None,
    }


def _skipped_public(skipped: dict[str, Any]) -> dict[str, Any]:
    out = dict(skipped)
    out["unavailable_count"] = len(skipped["unavailable"])
    out["blocked_count"] = len(skipped["blocked"])
    out["unavailable"] = skipped["unavailable"][:_SAMPLE]
    out["blocked"] = skipped["blocked"][:_SAMPLE]
    return out


def _apply(ctx: Ctx, store: InputStore, result: dict[str, Any], manifest: list[_Cand],
           tail: list[_Cand], order: list[_Cand], scope: str, mode: str, limits: dict[str, int],
           digest: str, estimate: dict[str, Any], skipped: dict[str, Any],
           now: str) -> dict[str, Any]:
    from core.sleep_store.packages import package_dir

    existing = next((r for r in store.runs(("planned",)) if r["plan_digest"] == digest), None)
    if existing is not None:  # тот же план: тот же прогон, строк не добавляем
        result.update(applied=True, replayed=True, run_id=existing["run_id"])
        for entry in (*result["manifest"], *result["tail"]):
            if entry["carried_from"] == existing["run_id"]:  # свои же позиции, не чужой хвост
                entry["carried_from"] = None
            entry["run_id"] = existing["run_id"]
        result["carried"] = {"items": sum(1 for c in order if c.carried_from not in (
            "", existing["run_id"])), "runs": sorted({c.carried_from for c in order
                                                       if c.carried_from not in (
                                                           "", existing["run_id"])})}
        return result
    run_id = f"plan-{digest[:12]}"
    n = 1
    while store.run_row(run_id) is not None:
        n += 1
        run_id = f"plan-{digest[:12]}-{n}"
    items = [(c, "queued") for c in manifest] + [(c, "tail") for c in tail]
    with store.tx(immediate=True):
        store.create_run(run_id, now, scope=scope, mode=mode,
                         budgets_json=json.dumps(limits, sort_keys=True),
                         plan_digest=digest, estimate_json=json.dumps(estimate, sort_keys=True),
                         skipped_json=json.dumps(result["skipped"], ensure_ascii=False,
                                                 sort_keys=True))
        touched: set[str] = set()
        for seq, (c, status) in enumerate(items, 1):
            payload = {
                "item_id": c.key, "seq": seq, "source_id": c.row["source_id"],
                "revision": int(c.row["revision"]), "family_id": c.row["family_id"],
                "item_kind": c.row["kind"], "priority": c.priority,
                "reasons_json": json.dumps(c.reasons), "intended_use": c.intended_use,
                "difference": c.difference, "status": status, "carried_from": c.carried_from,
                "signals_json": json.dumps(c.signals or {}, ensure_ascii=False, sort_keys=True),
            }
            if c.carried_from:
                touched.add(c.carried_from)
                store.move_item(c.carried_from, c.carried_item, run_id, now, **{
                    k: payload[k] for k in ("item_id", "seq", "revision", "priority",
                                            "reasons_json", "signals_json", "intended_use",
                                            "difference", "status")})
            else:
                store.put_item(run_id, payload, now)
        for old in touched:  # хвост перенесен: нетронутый прогон снят как замененный
            left = store.worklist(old, ("queued", "tail", "failed"))
            prev = store.run_row(old)
            if not left and prev is not None and prev["state"] == "planned":
                store.set_run_state(old, "cancelled", now, f"superseded_by:{run_id}")
        for d in skipped["carried_dropped"]:  # потерянные источником позиции видны, не пропадают
            store.set_item_status(d["run_id"], d["item_id"], "skipped", now, d["reason"])
    pkg = package_dir(run_id, create=True)
    (pkg / "manifest.json").write_text(
        json.dumps({k: result[k] for k in ("run_id", "mode", "scope", "budgets", "manifest",
                                            "tail", "estimate")}
                   | {"run_id": run_id}, ensure_ascii=False, indent=1), encoding="utf-8")
    result.update(applied=True, run_id=run_id)
    for entry in (*result["manifest"], *result["tail"]):
        entry["run_id"] = run_id
    return result
