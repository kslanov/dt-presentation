"""SLEEP-INPUT-1 - что НЕ входит в реестр входов Сна и что блокировано (sleep-1.md §2 п.7, §4.2).

Решение принимается ДО чтения содержимого в досье и ДО записи в реестр, по политике источника
(путь, frontmatter, тип), а не по тексту: инструкция внутри документа политику не меняет.

Отказ (вход не регистрируется, пути в реестр/ответ не попадают - только причина и счетчик):

* ``nda`` / ``personal`` / ``quarantine`` - общий предикат рабочего сна
  (:func:`core.privacy_scope.exclusion_reason`: структура пути, frontmatter, правила личного);
* ``secret`` - в заметке похоже на секрет (тот же детектор, что у блокирующего валидатора Сна);
* ``symlink`` - заметка - символическая ссылка, либо ее реальный путь вне vault;
* ``path_traversal`` - локатор источника с ``..`` (выход из своей области);
* ``derived`` - не вход: выходы, шаблоны, стиль и заметки самого Сна (``02-knowledge/memory``):
  построенное представление - не независимое подтверждение оригинала (sleep-1.md §2 п.5).

Блок (вход ЕСТЬ в реестре, но ``blocked``): ``privacy_unknown`` - приватность явно задана значением,
которое политика не знает (§4.2: неизвестная приватность блокирует включение в рабочий сон).
Нет ключа приватности и нет маркеров - рабочий корпус vault (``work``).
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.privacy_scope import exclusion_reason
from core.sleep.validate import contains_secret

__all__ = [
    "REASON_DERIVED",
    "REASON_SECRET",
    "REASON_SYMLINK",
    "REASON_TRAVERSAL",
    "REASON_UNKNOWN",
    "Verdict",
    "classify_note",
    "classify_path_only",
    "has_traversal",
]

REASON_SECRET, REASON_SYMLINK, REASON_TRAVERSAL = "secret", "symlink", "path_traversal"
REASON_DERIVED, REASON_UNKNOWN = "derived", "privacy_unknown"

#: каталоги верхнего уровня vault, которые не входы: выходы, шаблоны, стиль
_SKIP_TOP = frozenset({"07-outputs", "06-templates", "01-style"})
_MEMORY_DIR = "02-knowledge/memory"  # заметки Сна (core.sleep_store.notes.MEMORY_DIR)
_FM_KEYS = ("privacy", "приватность", "access", "visibility")
_WORK_WORDS = frozenset({"work", "public", "internal", "рабочее", "рабочий", "рабочая",
                         "открытое", "открытый", "публичное", "общее"})
_SPLIT_RE = re.compile(r"[\s_\-./,;]+")
_SEG_RE = re.compile(r"[\\/]")


@dataclass(frozen=True)
class Verdict:
    """``ok`` - можно в реестр; ``refuse`` - нельзя (``reason``); ``blocked`` - в реестр, но не в
    работу (``reason``)."""

    kind: str
    reason: str = ""

    @property
    def ok(self) -> bool:
        return self.kind == "ok"

    @property
    def refused(self) -> bool:
        return self.kind == "refuse"

    @property
    def blocked(self) -> bool:
        return self.kind == "blocked"


OK = Verdict("ok")


def has_traversal(locator: str) -> bool:
    """В локаторе-пути есть сегмент ``..`` (в любом из разделителей): выход из своей области."""
    return any(seg == ".." for seg in _SEG_RE.split(str(locator or "")))


def _tokens(value: Any) -> set[str]:
    if isinstance(value, (list, tuple, set)):
        out: set[str] = set()
        for item in value:
            out |= _tokens(item)
        return out
    return {t for t in _SPLIT_RE.split(str(value or "").casefold().replace("ё", "е")) if t}


def _unknown_privacy(fm: Mapping[str, Any]) -> bool:
    """Приватность задана явно, но значение политике неизвестно (ни рабочее, ни личное/NDA)."""
    for key in _FM_KEYS:
        raw = fm.get(key)
        if raw is None or raw == "" or raw == []:
            continue
        if isinstance(raw, bool):
            continue
        toks = _tokens(raw)
        if toks and not toks <= _WORK_WORDS:
            return True
    return False


def classify_path_only(rel: str, source_path: str = "") -> Verdict:
    """Дешевая проверка по пути (без чтения файла): для уже зарегистрированных, неизменных входов
    - вдруг маркер ``_nda`` добавили позже."""
    top = rel.split("/", 1)[0]
    if top in _SKIP_TOP or rel.startswith(_MEMORY_DIR + "/"):
        return Verdict("refuse", REASON_DERIVED)
    reason = exclusion_reason(rel, None, source_path=source_path)
    if reason:
        return Verdict("refuse", reason)
    if has_traversal(rel) or has_traversal(source_path):
        return Verdict("refuse", REASON_TRAVERSAL)
    return OK


def classify_note(rel: str, frontmatter: Mapping[str, Any] | None, text: str, *,
                  vault: Path | None = None, source_path: str = "") -> Verdict:
    """Полная проверка заметки vault: путь, frontmatter, symlink/containment, секрет, приватность.

    ``text`` - содержимое заметки целиком (frontmatter + тело): ищем секрет. ``vault`` - корень
    для проверки symlink и выхода реального пути за vault (``None`` - проверка пропущена)."""
    fm = frontmatter or {}
    head = classify_path_only(rel, source_path or str(fm.get("source_path") or ""))
    if head.refused:
        return head
    reason = exclusion_reason(rel, fm, source_path=source_path or str(fm.get("source_path") or ""))
    if reason:
        return Verdict("refuse", reason)
    if vault is not None:
        path = Path(vault) / rel
        if path.is_symlink():
            return Verdict("refuse", REASON_SYMLINK)
        try:
            path.resolve().relative_to(Path(vault).resolve())
        except (OSError, ValueError):
            return Verdict("refuse", REASON_SYMLINK)
    if contains_secret(text):
        return Verdict("refuse", REASON_SECRET)
    if _unknown_privacy(fm):
        return Verdict("blocked", REASON_UNKNOWN)
    return OK
