"""SLEEP-PULT-1 п.5 - профиль Сна: область и пределы плана (``_system/sleep-profile.yaml``).

Профиль - данные владельца в vault (правятся в пульте или как заметка); движок пишет его штатным
писателем :mod:`core.note_writer` (атомарно, CAS по sha, NDA-гард) и ТОЛЬКО по действию владельца
(фасад ``sleep(op="profile", settings=...)`` с write-токеном). Читает его
:func:`resolve_plan_defaults`: ``plan_sleep`` берет отсюда умолчания области и пределов; явные
параметры вызова сильнее; без профиля (или с битым) действуют умолчания кода
(:data:`core.sleep_input.plan.DEFAULT_BUDGETS`).

Формат (``schema_version: 1``)::

    schema_version: 1
    scope: all                # all | hub:<id> | kind:<тип>
    budgets: {items: 20, per_hub: 10, seconds: 120}
    schedule: manual          # единственное допустимое значение: расписания нет (SLEEP-LOOP-1)
    human_review: true        # обязательное принятие человеком - не выключается

**Версия** профиля - sha256 файла (``version``): сохранение передает ожидаемую версию; ручная правка
файла между показом и записью дает ``profile_conflict`` (запись не выполняется), а не перезапись.
Нет файла - версия пустая (``""``): записать можно, только если файла по-прежнему нет.

Серверная валидация: ``items`` 1..200, ``per_hub`` 1..``items``, ``seconds`` 10..900, область по
:func:`core.sleep_input.plan._scope`; ``schedule`` не ``manual`` - ``schedule_unavailable``;
``human_review`` не ``true`` - ``human_review_required``. Хвост плана (``tail``) в профиль не
входит.

``core`` ⊥ cli/mcp; модель и сеть не вызываются.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from core.file_lock import file_lock
from core.note_writer import NoteWriteError, read_sha, write_note_atomic
from core.sleep_input.plan import DEFAULT_BUDGETS, PlanError, _scope

__all__ = [
    "LIMITS",
    "LOCKED",
    "PROFILE_REL",
    "SCHEMA_VERSION",
    "SETTING_KEYS",
    "ProfileError",
    "read_profile",
    "resolve_plan_defaults",
    "save_profile",
]

PROFILE_REL = "_system/sleep-profile.yaml"
SCHEMA_VERSION = 1
#: пределы пилота (минимум, максимум); данные, не код ветвлений
LIMITS: dict[str, tuple[int, int]] = {"items": (1, 200), "per_hub": (1, 50), "seconds": (10, 900)}
SETTING_KEYS = ("scope", "items", "per_hub", "seconds", "schedule", "human_review")
#: то, что профиль не выключает: ручной режим и принятие человеком
LOCKED: dict[str, Any] = {
    "schedule": "manual", "human_review": True,
    "schedule_unavailable": "расписания нет: нет исполнителя и бюджета (SLEEP-LOOP-1)",
    "human_review_note": "обязательное принятие человеком: в знания пишет только решение владельца",
}
_HEADER = (
    "# SLEEP-PULT-1: профиль Сна (область и пределы плана по умолчанию).\n"
    "# Правится в пульте (Настройки / Сон) или вручную; версия = sha файла: правка между показом\n"
    "# и сохранением в пульте даст конфликт, а не перезапись. schedule/human_review не меняются.\n")
_KEYS = {"schema_version", "scope", "budgets", "schedule", "human_review"}


class ProfileError(ValueError):
    """Отказ профиля: ``code`` машинный (``profile_invalid`` | ``profile_conflict`` |
    ``schedule_unavailable`` | ``human_review_required`` | ``bad_scope`` | ``bad_budget``)."""

    def __init__(self, code: str, message: str, **extra: Any) -> None:
        super().__init__(message)
        self.code = code
        self.extra = extra


def _path(vault: Path) -> Path:
    return Path(vault) / PROFILE_REL


def _defaults() -> dict[str, Any]:
    return {"scope": "all", **{k: DEFAULT_BUDGETS[k] for k in LIMITS},
            "schedule": "manual", "human_review": True}


def _validate(values: dict[str, Any]) -> dict[str, Any]:
    """Нормализованные значения профиля или :class:`ProfileError` (все числа - целые в пределах)."""
    out = _defaults()
    unknown = sorted(set(values) - set(SETTING_KEYS))
    if unknown:
        raise ProfileError("profile_invalid", f"неизвестные настройки: {', '.join(unknown)}",
                           field=unknown[0])
    if "schedule" in values and str(values["schedule"]).strip().lower() != "manual":
        raise ProfileError("schedule_unavailable", LOCKED["schedule_unavailable"],
                           field="schedule")
    if "human_review" in values and values["human_review"] is not True:
        raise ProfileError("human_review_required", LOCKED["human_review_note"],
                           field="human_review")
    if "scope" in values:
        try:
            scope, _ = _scope(str(values["scope"]) if values["scope"] is not None else None)
        except PlanError as exc:
            raise ProfileError("bad_scope", str(exc), field="scope") from exc
        out["scope"] = scope
    for key, (lo, hi) in LIMITS.items():
        if key not in values:
            continue
        raw = values[key]
        if isinstance(raw, bool) or not isinstance(raw, (int, str, float)):
            raise ProfileError("bad_budget", f"{key}: нужно целое число {lo}..{hi}", field=key)
        try:
            number = int(str(raw).strip()) if not isinstance(raw, float) else int(raw)
            if isinstance(raw, float) and raw != number:
                raise ValueError
        except ValueError as exc:
            raise ProfileError("bad_budget", f"{key}: нужно целое число {lo}..{hi}, получено "
                               f"{raw!r}", field=key) from exc
        if not lo <= number <= hi:
            raise ProfileError("bad_budget", f"{key}: допустимо {lo}..{hi}, получено {number}",
                               field=key, min=lo, max=hi)
        out[key] = number
    if out["per_hub"] > out["items"]:
        raise ProfileError("bad_budget", f"per_hub ({out['per_hub']}) не больше items "
                           f"({out['items']})", field="per_hub")
    return out


def _parse(text: str) -> dict[str, Any]:
    """Файл -> нормализованные значения; битый/чужой - :class:`ProfileError` ``profile_invalid``."""
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ProfileError("profile_invalid", f"профиль Сна: невалидный YAML ({exc})") from exc
    if not isinstance(data, dict):
        raise ProfileError("profile_invalid", "профиль Сна: ожидается словарь")
    extra = sorted(set(map(str, data)) - _KEYS)
    if extra:
        raise ProfileError("profile_invalid", f"профиль Сна: неизвестные ключи {', '.join(extra)}")
    version = data.get("schema_version")
    if version != SCHEMA_VERSION:
        raise ProfileError("profile_invalid", f"профиль Сна: schema_version {version!r}, "
                           f"поддерживается {SCHEMA_VERSION}")
    budgets = data.get("budgets") or {}
    if not isinstance(budgets, dict):
        raise ProfileError("profile_invalid", "профиль Сна: budgets - словарь")
    flat: dict[str, Any] = {k: v for k, v in budgets.items()}
    for key in ("scope", "schedule", "human_review"):
        if key in data:
            flat[key] = data[key]
    return _validate(flat)


def _meta() -> dict[str, Any]:
    from core.sleep_input.discover import KINDS

    return {"defaults": _defaults(), "scope_kinds": [*KINDS, "experience"],
            "limits": {k: {"min": lo, "max": hi} for k, (lo, hi) in LIMITS.items()},
            "locked": dict(LOCKED), "path": PROFILE_REL}


def read_profile(vault: Path) -> dict[str, Any]:
    """Профиль для пульта: ``{ok, present, valid, version, profile, defaults, limits, locked}``.

    Нет файла - ``present: false`` и умолчания кода (это не ошибка); битый файл - ``valid: false``
    + ``problems`` (умолчания кода действуют, ошибка не прячется); нечитаемый -
    ``profile_unreadable``."""
    target = _path(Path(vault))
    meta = _meta()
    try:
        raw = target.read_bytes()
    except FileNotFoundError:
        return {"ok": True, "present": False, "valid": True, "version": "",
                "profile": _defaults(), **meta}
    except OSError as exc:
        return {"ok": False, "refused": True, "code": "profile_unreadable",
                "error": f"profile_unreadable: профиль Сна не прочитан ({type(exc).__name__})",
                **meta}
    version = read_sha(target) or ""
    try:
        profile = _parse(raw.decode("utf-8"))
    except (ProfileError, UnicodeDecodeError) as exc:
        return {"ok": True, "present": True, "valid": False, "version": version,
                "profile": _defaults(), "problems": [str(exc)], **meta}
    return {"ok": True, "present": True, "valid": True, "version": version, "profile": profile,
            **meta}


def resolve_plan_defaults(vault: Path) -> tuple[str | None, dict[str, int], dict[str, Any] | None]:
    """Умолчания плана из профиля: ``(scope | None, budgets, статус)``. Нет профиля - ``(None, {},
    None)`` (действуют умолчания кода, ответ плана не меняется); битый - ``(None, {}, {valid:
    false, ...})`` (план идет на умолчаниях кода, причина - в ответе)."""
    state = read_profile(vault)
    if not state.get("present"):
        return None, {}, None
    version = str(state.get("version") or "")[:12]
    if not state.get("ok") or not state.get("valid"):
        return None, {}, {"applied": False, "valid": False, "version": version,
                          "problems": state.get("problems") or [state.get("error", "")]}
    p = state["profile"]
    return str(p["scope"]), {k: int(p[k]) for k in LIMITS}, {
        "applied": True, "valid": True, "version": version}


def save_profile(vault: Path, settings: dict[str, Any], expected_version: str | None,
                 *, now: str = "") -> dict[str, Any]:
    """Записать профиль по действию владельца: валидация, CAS по ожидаемой версии, штатный писатель.

    ``expected_version`` - ``version`` из :func:`read_profile` на момент показа (``""`` - файла не
    было); отличие от текущей - ``profile_conflict`` (ничего не записано, в ответе - текущий
    профиль). Незаданные ключи берутся из ТЕКУЩЕГО профиля (или умолчаний кода): сохраняется
    показанное целиком."""
    if not isinstance(settings, dict):
        raise ProfileError("profile_invalid", "settings: нужен объект")
    if expected_version is None:
        raise ProfileError("profile_invalid", "expected_version обязателен: версия профиля, "
                           "которую вы видели (пустая строка - файла не было)")
    target = _path(Path(vault))
    with file_lock(target):
        cur_version = read_sha(target) or ""
        if str(expected_version) != cur_version:
            raise ProfileError("profile_conflict", "профиль изменен после показа: "
                               "перечитайте и повторите", current=read_profile(vault))
        current = read_profile(vault)
        base = dict(current["profile"]) if current.get("valid") else _defaults()
        merged = _validate({**base, **settings})
        body = {
            "schema_version": SCHEMA_VERSION, "scope": merged["scope"],
            "budgets": {k: merged[k] for k in LIMITS},
            "schedule": "manual", "human_review": True,
        }
        text = _HEADER + yaml.safe_dump(body, allow_unicode=True, sort_keys=False,
                                        default_flow_style=False)
        try:
            receipt = write_note_atomic(Path(vault), PROFILE_REL, text,
                                        expect_sha=cur_version or None, now=now,
                                        allowed_prefix="_system/")
        except NoteWriteError as exc:
            code = "profile_conflict" if exc.code == "cas_mismatch" else f"profile_{exc.code}"
            raise ProfileError(code, str(exc)) from exc
        return {"ok": True, "saved": True, "version": receipt["sha_after"],
                "previous_version": receipt["sha_before"] or "", "profile": merged,
                "created": bool(receipt["created"]), "path": PROFILE_REL}
