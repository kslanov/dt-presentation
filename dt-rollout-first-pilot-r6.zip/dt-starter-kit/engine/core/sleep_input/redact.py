"""SLEEP-INPUT-1 - редактор секретов: секрет отсекается ДО долговечной записи (sleep-1.md §4.2).

Не второй детектор: набор шаблонов - тот же, что у блокирующего валидатора Сна
(:data:`core.sleep.validate.SECRET_PATTERNS`: ключи API, токены, приватные ключи, пароли), плюс
значения секретов окружения/Keychain, которые знает скраб логгера (:func:`core.logging_setup.
scrub_secrets`). Найденное заменяется меткой ``[REDACTED]`` (значение не сохраняется нигде и не
попадает в ответ - только число замен). Если после замены строка все еще похожа на секрет, она
заменяется целиком (``[REDACTED:whole]``): лучше потерять фразу, чем сохранить секрет.

Применяется к строкам любой вложенности (:func:`redact_obj`) до хеширования, до записи в SQL и до
ответа поверхности, поэтому секрет не доживает ни до БД, ни до логов, ни до журнала аудита.
"""

from __future__ import annotations

from typing import Any

from core.sleep.validate import SECRET_PATTERNS, contains_secret

__all__ = ["MARK", "MARK_WHOLE", "redact", "redact_obj"]

MARK = "[REDACTED]"
MARK_WHOLE = "[REDACTED:whole]"


def redact(text: str) -> tuple[str, int]:
    """``(очищенный текст, число замен)``."""
    if not text:
        return text, 0
    count = 0
    for pattern in SECRET_PATTERNS:
        text, n = pattern.subn(MARK, text)
        count += n
    from core.logging_setup import scrub_secrets

    scrubbed = scrub_secrets(text)
    if scrubbed != text:
        count += 1
        text = scrubbed.replace("***", MARK)
    if contains_secret(text):
        return MARK_WHOLE, count + 1
    return text, count


def redact_obj(value: Any) -> tuple[Any, int]:
    """Рекурсивно: строки очищаются, структура сохраняется; ``(объект, число замен)``."""
    if isinstance(value, str):
        return redact(value)
    if isinstance(value, list):
        out, total = [], 0
        for item in value:
            clean, n = redact_obj(item)
            out.append(clean)
            total += n
        return out, total
    if isinstance(value, dict):
        out_d: dict[str, Any] = {}
        total = 0
        for key, item in value.items():
            clean_key, nk = redact(str(key))
            clean, n = redact_obj(item)
            out_d[clean_key] = clean
            total += n + nk
        return out_d, total
    return value, 0
