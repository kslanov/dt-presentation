"""SLEEP-INPUT-1 - применение обхода к реестру входов: решить (чтение) и записать (транзакция).

Два шага, потому что ``plan`` без ``--apply`` обязан показать результат и НИЧЕГО не записать:

* :func:`resolve` - по результату обхода и СОСТОЯНИЮ реестра (только чтение) решает судьбу каждого
  наблюдения (:class:`core.sleep_input.identity.Decision`: новый / ревизия / без изменений /
  переименование / копия) и что исчезло. Копии и переименования внутри одного обхода учитываются
  оверлеем (без записи): решение не зависит от порядка выдачи.
* :func:`commit` - те же решения в одной транзакции ``dt.db``. Исчезнувший вход помечается
  ``unavailable`` (только если обход был полным), а зависимые принятые утверждения ledger
  отправляются на проверку штатным :meth:`core.sleep_store.store.SleepStore.mark_source_unavailable`
  (историю не стираем, принятое не откатываем).

Неизвестная приватность: вход регистрируется, но ``availability=blocked`` (в манифест не попадает).
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.sleep_input.discover import KINDS, Discovery, discover_vault
from core.sleep_input.identity import Decision, Observation, decide, sort_key
from core.sleep_input.store import InputStore

__all__ = ["RefreshPlan", "Resolved", "commit", "refresh", "resolve"]


@dataclass(frozen=True)
class Resolved:
    obs: Observation
    decision: Decision

    @property
    def availability(self) -> str:
        return "blocked" if self.obs.privacy == "unknown" else "available"


@dataclass
class RefreshPlan:
    resolved: list[Resolved] = field(default_factory=list)
    missing: list[dict[str, Any]] = field(default_factory=list)     # исчезнувшие входы
    to_block: list[tuple[str, str]] = field(default_factory=list)
    complete: bool = True

    def counts(self) -> dict[str, int]:
        out = {"new": 0, "revision": 0, "unchanged": 0, "rename": 0, "copy": 0,
               "unavailable": len(self.missing), "blocked": len(self.to_block)}
        for r in self.resolved:
            out[r.decision.action] += 1
        return out


class _View:
    """Реестр + оверлей решений этого обхода (чтобы копии/переименования видели друг друга)."""

    def __init__(self, store: InputStore | None) -> None:
        self.store = store if store is not None and store.registry else None
        self.by_locator: dict[str, dict[str, Any]] = {}
        self.by_id: dict[str, dict[str, Any]] = {}
        self.moved: dict[str, dict[str, Any]] = {}

    def locator(self, locator: str) -> dict[str, Any] | None:
        hit = self.by_locator.get(locator)
        if hit is not None:
            return hit
        if self.store is None:
            return None
        row = self.store.row_by_locator(locator)
        return self.moved.get(row["source_id"], row) if row else None

    def holders(self, content_hash: str, kind: str) -> list[dict[str, Any]]:
        rows = self.store.rows_by_hash(content_hash, (kind,)) if self.store else []
        rows = [self.moved.get(r["source_id"], r) for r in rows]
        have = {r["source_id"] for r in rows}
        rows += [r for r in self.by_id.values()
                 if r["content_hash"] == content_hash and r["kind"] == kind
                 and r["source_id"] not in have]
        return rows

    def remember(self, obs: Observation, dec: Decision) -> None:
        row = {"source_id": dec.source_id, "family_id": dec.family_id, "origin_id": dec.origin_id,
               "is_copy": int(dec.is_copy), "revision": dec.revision, "kind": obs.kind,
               "locator": obs.locator, "content_hash": obs.content_hash}
        self.by_locator[obs.locator] = row
        self.by_id[dec.source_id] = row
        if dec.action == "rename":
            self.moved[dec.source_id] = row


def resolve(store: InputStore | None, disc: Discovery) -> RefreshPlan:
    """Решить судьбу каждого наблюдения и найти исчезнувшие входы (только чтение)."""
    view = _View(store)
    present = frozenset(o.locator for o in disc.observations)
    plan = RefreshPlan(to_block=list(disc.to_block), complete=disc.complete)
    seen: set[str] = set()

    def known(o: Observation) -> bool:
        return o.reuse or view.locator(o.locator) is not None

    for obs in sorted(disc.observations, key=lambda o: (not known(o), *sort_key(o))):
        if obs.reuse:
            row = view.locator(obs.locator) or (
                view.store.input_row(obs.existing_id) if view.store else None)
            if row is None:  # запись исчезла между обходом и решением - как новое
                obs = Observation(**{**obs.__dict__, "reuse": False, "existing_id": ""})
                dec = decide(obs, by_locator=None, same_hash=view.holders(
                    obs.content_hash, obs.kind), present=present)
            else:
                dec = decide(obs, by_locator=row, same_hash=(), present=present)
        else:
            dec = decide(obs, by_locator=view.locator(obs.locator),
                         same_hash=view.holders(obs.content_hash, obs.kind), present=present)
        view.remember(obs, dec)
        seen.add(dec.source_id)
        plan.resolved.append(Resolved(obs, dec))
    if disc.complete and view.store is not None:
        blocked = {sid for sid, _ in disc.to_block}
        for row in view.store.known_by_kind(KINDS):
            if (row["source_id"] not in seen and row["source_id"] not in blocked
                    and row["availability"] != "blocked"):
                if row["availability"] == "available":
                    plan.missing.append(row)
    return plan


def _cols(obs: Observation, dec: Decision, availability: str) -> dict[str, Any]:
    return {
        "content_hash": obs.content_hash, "stat_sig": obs.stat_sig, "note_rel": obs.note_rel,
        "note_id": obs.note_id, "valid_date": obs.valid_date, "extract_method": obs.extract_method,
        "extract_version": obs.extract_version, "coverage": obs.coverage,
        "coverage_scope": obs.coverage_scope, "size": obs.size, "instance": obs.instance,
        "privacy": obs.privacy, "availability": availability,
        "unavailable_reason": "privacy_unknown" if availability == "blocked" else "",
    }


def commit(store: InputStore, plan: RefreshPlan, now: str) -> dict[str, Any]:
    """Записать решения ``resolve`` в реестр одной транзакцией; вернуть счетчики и число
    утверждений ledger, отправленных на проверку из-за исчезнувших источников."""
    counts = plan.counts()
    with store.tx(immediate=True):
        for r in plan.resolved:
            obs, dec = r.obs, r.decision
            cols = _cols(obs, dec, r.availability)
            if dec.action in ("new", "copy"):
                store.insert_input({
                    **cols, "source_id": dec.source_id, "family_id": dec.family_id,
                    "origin_id": dec.origin_id, "is_copy": dec.is_copy, "kind": obs.kind,
                    "locator": obs.locator, "revision": 1, "discovered_at": now,
                    "updated_at": now, "last_seen_at": now})
            elif dec.action == "revision":
                store.new_revision(dec.source_id, now, **cols)
            elif dec.action == "rename":
                store.move_locator(dec.source_id, now, locator=obs.locator,
                                   note_rel=obs.note_rel, note_id=obs.note_id)
                store.touch(dec.source_id, now, **{
                    k: cols[k] for k in ("stat_sig", "privacy", "availability",
                                         "unavailable_reason")})
            else:
                keep = {k: cols[k] for k in ("stat_sig", "note_rel", "privacy", "availability",
                                             "unavailable_reason")}
                store.touch(dec.source_id, now, **keep)
        for source_id, reason in plan.to_block:
            store.block(source_id, reason, now)
        for row in plan.missing:
            store.set_availability(row["source_id"], "unavailable", "source_missing", now)
    flagged = 0
    if plan.missing:
        from core.sleep_store.store import SleepStore

        ledger = SleepStore(store.conn)
        for row in plan.missing:
            flagged += ledger.mark_source_unavailable(row["source_id"], now)["claims"]
    counts["claims_needing_check"] = flagged
    return counts


def refresh(
    vault: Path, *, db_path: Path | None, now: str, apply: bool, instance: str | None = None,
    clock: Callable[[], float] = time.monotonic, deadline: float | None = None,
) -> tuple[Discovery, RefreshPlan, dict[str, Any] | None]:
    """Обход vault -> решения -> (при ``apply``) запись в реестр. Без ``apply`` реестр открывается
    строго на чтение (файла БД нет - реестр считается пустым) и ничего не пишется.

    Возврат: обход, решения и счетчики записи (``None`` без ``apply``)."""
    store = InputStore.open(db_path) if apply else InputStore.open_readonly(db_path)
    try:
        known = store.known_by_kind(KINDS) if store is not None else []
        disc = discover_vault(vault, known, instance=instance, clock=clock, deadline=deadline)
        plan = resolve(store, disc)
        written = commit(store, plan, now) if apply and store is not None else None
        return disc, plan, written
    finally:
        if store is not None:
            store.close()
