"""SLEEP-INPUT-1 - физическая модель реестра входов Сна в общей ``dt.db`` (sleep-1.md §4.1).

Миграция v6 общего менеджера (:mod:`core.db.migrations`): своей БД и своего менеджера миграций нет.
Этот модуль - только DDL (импортов ``core.db`` нет: миграция зовет его лениво).

**Что где лежит**

========================  =================================================================
``sleep_inputs``          вход: текущая запись (source_id, family_id, ревизия, хеш, локатор,
                          тип, экземпляр, обнаружен/обновлен, дата действия, доступность,
                          приватность, метод извлечения и его версия)
``sleep_input_revisions`` история ревизий входа (одна строка на ревизию; хеш и метод)
``sleep_input_aliases``   локаторы входа: переименование - тот же ``source_id``, новый локатор
``sleep_experience``      явно сданные пакеты опыта сессий (секреты отсечены ДО записи)
``sleep_worklist``        worklist прогона: позиции, приоритет, хвост при лимите/отмене
``sleep_reads``           квитанции чтения досье (прочитано/обрезано/блокеры), для доктора
========================  =================================================================

Таблица прогонов ``sleep_runs`` - SLEEP-STORE-1 (v5); здесь она ДОПОЛНЯЕТСЯ колонками плана и
lease (:data:`RUN_COLUMNS`), второй таблицы прогонов нет.

**Тексты оригиналов в SQL не копируются.** Реестр хранит локатор, хеш, ревизию и метаданные;
пакет опыта - структурированное резюме, сданное владельцем (не копия оригинала: тексты сообщений
хоста сюда не попадают, только роли/отпечатки/локаторы), секреты в нем отсечены до записи.
Личное, ``_nda``, секреты, symlink и выход пути за vault в реестр не попадают вовсе
(:mod:`core.sleep_input.privacy`); неизвестная приватность - вход есть, но ``blocked``.
"""

from __future__ import annotations

import sqlite3

__all__ = ["RUN_COLUMNS", "TABLES", "create_schema"]

TABLES = (
    "sleep_inputs", "sleep_input_revisions", "sleep_input_aliases", "sleep_experience",
    "sleep_worklist", "sleep_reads",
)

#: колонки, которые v6 добавляет к ``sleep_runs`` (v5): параметры плана и lease с heartbeat
RUN_COLUMNS: tuple[tuple[str, str], ...] = (
    ("mode", "TEXT"), ("budgets_json", "TEXT"), ("plan_digest", "TEXT"), ("estimate_json", "TEXT"),
    ("skipped_json", "TEXT"), ("lease_holder", "TEXT"), ("lease_until", "TEXT"),
    ("heartbeat_at", "TEXT"), ("note", "TEXT"),
)

_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS sleep_inputs (
        source_id TEXT PRIMARY KEY,
        family_id TEXT NOT NULL,
        origin_id TEXT NOT NULL,
        is_copy INTEGER NOT NULL DEFAULT 0,
        kind TEXT NOT NULL,
        instance TEXT NOT NULL DEFAULT '',
        locator TEXT NOT NULL,
        note_rel TEXT NOT NULL DEFAULT '',
        note_id TEXT NOT NULL DEFAULT '',
        revision INTEGER NOT NULL,
        content_hash TEXT NOT NULL DEFAULT '',
        stat_sig TEXT NOT NULL DEFAULT '',
        discovered_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        last_seen_at TEXT NOT NULL,
        valid_date TEXT NOT NULL DEFAULT '',
        availability TEXT NOT NULL DEFAULT 'available'
            CHECK (availability IN ('available', 'unavailable', 'blocked')),
        unavailable_reason TEXT NOT NULL DEFAULT '',
        privacy TEXT NOT NULL CHECK (privacy IN ('work', 'unknown')),
        extract_method TEXT NOT NULL DEFAULT '',
        extract_version TEXT NOT NULL DEFAULT '',
        coverage TEXT NOT NULL DEFAULT 'unknown',
        coverage_scope TEXT NOT NULL DEFAULT '',
        size INTEGER NOT NULL DEFAULT 0
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_inputs_hash ON sleep_inputs(content_hash)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_inputs_family ON sleep_inputs(family_id)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_inputs_locator ON sleep_inputs(locator)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_inputs_state ON sleep_inputs(availability, privacy)",
    """
    CREATE TABLE IF NOT EXISTS sleep_input_revisions (
        source_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        content_hash TEXT NOT NULL DEFAULT '',
        locator TEXT NOT NULL DEFAULT '',
        observed_at TEXT NOT NULL,
        valid_date TEXT NOT NULL DEFAULT '',
        extract_method TEXT NOT NULL DEFAULT '',
        extract_version TEXT NOT NULL DEFAULT '',
        coverage TEXT NOT NULL DEFAULT 'unknown',
        coverage_scope TEXT NOT NULL DEFAULT '',
        size INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (source_id, revision)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sleep_input_aliases (
        locator TEXT NOT NULL,
        source_id TEXT NOT NULL,
        first_seen TEXT NOT NULL,
        last_seen TEXT NOT NULL,
        current INTEGER NOT NULL DEFAULT 1,
        PRIMARY KEY (locator, source_id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_alias_src ON sleep_input_aliases(source_id)",
    """
    CREATE TABLE IF NOT EXISTS sleep_experience (
        source_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        host TEXT NOT NULL,
        session_id TEXT NOT NULL,
        content_hash TEXT NOT NULL,
        coverage TEXT NOT NULL,
        redacted INTEGER NOT NULL DEFAULT 0,
        package_json TEXT NOT NULL,
        recorded_at TEXT NOT NULL,
        PRIMARY KEY (source_id, revision)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sleep_worklist (
        run_id TEXT NOT NULL,
        item_id TEXT NOT NULL,
        seq INTEGER NOT NULL,
        source_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        family_id TEXT NOT NULL DEFAULT '',
        item_kind TEXT NOT NULL,
        reasons_json TEXT NOT NULL DEFAULT '[]',
        signals_json TEXT NOT NULL DEFAULT '{}',
        priority REAL NOT NULL DEFAULT 0,
        intended_use TEXT NOT NULL DEFAULT '',
        difference TEXT NOT NULL DEFAULT '',
        status TEXT NOT NULL CHECK (status IN
            ('queued', 'tail', 'done', 'skipped', 'failed', 'carried')),
        carried_from TEXT NOT NULL DEFAULT '',
        note TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        PRIMARY KEY (run_id, item_id)
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_wl_status ON sleep_worklist(status, run_id)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_wl_source ON sleep_worklist(source_id)",
    """
    CREATE TABLE IF NOT EXISTS sleep_reads (
        read_id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id TEXT NOT NULL,
        item_id TEXT NOT NULL,
        source_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        requested_hash TEXT NOT NULL DEFAULT '',
        actual_hash TEXT NOT NULL DEFAULT '',
        cursor TEXT NOT NULL DEFAULT '',
        next_cursor TEXT NOT NULL DEFAULT '',
        unit TEXT NOT NULL DEFAULT '',
        units_returned INTEGER NOT NULL DEFAULT 0,
        units_total INTEGER,
        chars INTEGER NOT NULL DEFAULT 0,
        total_chars INTEGER,
        truncated INTEGER NOT NULL DEFAULT 0,
        blockers_json TEXT NOT NULL DEFAULT '[]',
        errors_json TEXT NOT NULL DEFAULT '[]',
        at TEXT NOT NULL
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_reads_run ON sleep_reads(run_id, item_id)",
)


def create_schema(conn: sqlite3.Connection) -> None:
    """Таблицы/индексы реестра и недостающие колонки ``sleep_runs`` (идемпотентно, в транзакции
    вызывающего). ``sleep_runs`` создает v5; если ее нет (миграция вызвана отдельно) - создаем ее
    тем же DDL, что у ledger."""
    from core.sleep_store.schema import create_schema as create_ledger

    create_ledger(conn)  # IF NOT EXISTS: sleep_runs гарантированно есть
    for statement in _DDL:
        conn.execute(statement)
    have = {row[1] for row in conn.execute("PRAGMA table_info(sleep_runs)")}
    for col, ddl in RUN_COLUMNS:
        if col not in have:
            conn.execute(f"ALTER TABLE sleep_runs ADD COLUMN {col} {ddl}")
