"""SLEEP-INPUT-1 - доступ к реестру входов Сна в общей ``dt.db`` (sleep-1.md §4.1).

Тонкий слой над SQLite: строки таблиц :mod:`core.sleep_input.schema`. Решений здесь нет: кто чей
``source_id`` - :mod:`core.sleep_input.identity`, что пускать в реестр - :mod:`core.sleep_input.
privacy`, что брать в прогон - :mod:`core.sleep_input.plan`. Тексты оригиналов не хранятся.

Два способа открыть:

* :meth:`InputStore.open` - запись (создает/мигрирует ``dt.db`` общим менеджером :mod:`core.db`);
* :meth:`InputStore.open_readonly` - ТОЛЬКО чтение (``mode=ro``, миграций нет, файл не создается):
  так ходят ``plan`` без ``--apply``, ``context`` и ``inputs``. Файла БД нет - ``None``; БД старой
  схемы (без таблиц реестра) читается как пустой реестр с ``registry=False`` (это не ошибка:
  реестр еще не заводили), битая БД - исключение (``sqlite3.Error``), «недоступно» не прячется за
  «пусто».

Методы записи НЕ коммитят сами - вызывающий оборачивает их в :meth:`InputStore.tx`.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from core.sleep_store.store import now_iso

__all__ = ["InputStore", "now_iso"]

_INPUT_COLUMNS = (
    "source_id", "family_id", "origin_id", "is_copy", "kind", "instance", "locator", "note_rel",
    "note_id", "revision", "content_hash", "stat_sig", "discovered_at", "updated_at",
    "last_seen_at", "valid_date", "availability", "unavailable_reason", "privacy",
    "extract_method", "extract_version", "coverage", "coverage_scope", "size",
)
_REVISION_COLUMNS = (
    "source_id", "revision", "content_hash", "locator", "observed_at", "valid_date",
    "extract_method", "extract_version", "coverage", "coverage_scope", "size",
)


def _dicts(rows: Any) -> list[dict[str, Any]]:
    return [dict(r) for r in rows]


class InputStore:
    """Реестр входов в ``dt.db``. ``registry`` - есть ли в БД таблицы реестра (миграция v6)."""

    def __init__(self, conn: sqlite3.Connection, *, readonly: bool = False) -> None:
        self.conn = conn
        self.readonly = readonly
        self.registry = self.has_table("sleep_inputs")

    # --- соединение ------------------------------------------------------------------------ #
    @classmethod
    def open(cls, db_path: Path | None = None) -> InputStore:
        from core.db import connect

        return cls(connect(db_path))

    @classmethod
    def open_readonly(cls, db_path: Path | None = None) -> InputStore | None:
        """``None`` - файла БД нет. Иначе соединение ``mode=ro`` (не создает и не мигрирует)."""
        from core.config import dt_db_path

        path = Path(db_path) if db_path is not None else dt_db_path()
        if not path.is_file():
            return None
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("SELECT 1 FROM sqlite_master LIMIT 1").fetchone()  # битый файл - здесь
        except sqlite3.Error:
            conn.close()
            raise
        return cls(conn, readonly=True)

    def close(self) -> None:
        self.conn.close()

    def has_table(self, name: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
        return row is not None

    @contextmanager
    def tx(self, *, immediate: bool = False) -> Iterator[sqlite3.Connection]:
        """Транзакция: ``COMMIT`` при выходе, ``ROLLBACK`` при любом исключении."""
        if self.readonly:
            raise RuntimeError("InputStore открыт только для чтения")
        conn = self.conn
        prev = conn.isolation_level
        conn.isolation_level = None
        try:
            conn.execute("BEGIN IMMEDIATE" if immediate else "BEGIN")
            try:
                yield conn
            except BaseException:
                conn.execute("ROLLBACK")
                raise
            conn.execute("COMMIT")
        finally:
            conn.isolation_level = prev

    # --- чтение реестра -------------------------------------------------------------------- #
    def input_row(self, source_id: str) -> dict[str, Any] | None:
        if not self.registry:
            return None
        row = self.conn.execute(
            "SELECT * FROM sleep_inputs WHERE source_id=?", (source_id,)).fetchone()
        return dict(row) if row else None

    def inputs(self, *, availability: str | None = None, privacy: str | None = None,
               kind: str | None = None, limit: int | None = None) -> list[dict[str, Any]]:
        if not self.registry:
            return []
        sql = "SELECT * FROM sleep_inputs WHERE 1=1"
        args: list[Any] = []
        for col, val in (("availability", availability), ("privacy", privacy), ("kind", kind)):
            if val:
                sql += f" AND {col}=?"
                args.append(val)
        sql += " ORDER BY updated_at DESC, source_id"
        if limit:
            sql += " LIMIT ?"
            args.append(int(limit))
        return _dicts(self.conn.execute(sql, args))

    def row_by_locator(self, locator: str) -> dict[str, Any] | None:
        """Вход, чей ТЕКУЩИЙ локатор равен ``locator`` (по таблице алиасов: переименование
        переносит флаг ``current`` на новый локатор того же ``source_id``)."""
        if not self.registry or not locator:
            return None
        row = self.conn.execute(
            "SELECT i.* FROM sleep_inputs i JOIN sleep_input_aliases a "
            "ON a.source_id = i.source_id AND a.current = 1 WHERE a.locator=? "
            "ORDER BY i.discovered_at, i.source_id LIMIT 1", (locator,)).fetchone()
        return dict(row) if row else None

    def rows_by_hash(self, content_hash: str, kinds: tuple[str, ...]) -> list[dict[str, Any]]:
        """Входы с тем же содержимым (копии и переименования), старшие первыми."""
        if not self.registry or not content_hash or not kinds:
            return []
        marks = ",".join("?" for _ in kinds)
        return _dicts(self.conn.execute(
            f"SELECT * FROM sleep_inputs WHERE content_hash=? AND kind IN ({marks}) "  # noqa: S608
            "ORDER BY discovered_at, source_id", (content_hash, *kinds)))

    def family_rows(self, family_id: str) -> list[dict[str, Any]]:
        if not self.registry:
            return []
        return _dicts(self.conn.execute(
            "SELECT * FROM sleep_inputs WHERE family_id=? ORDER BY discovered_at, source_id",
            (family_id,)))

    def revision_rows(self, source_id: str) -> list[dict[str, Any]]:
        if not self.registry:
            return []
        return _dicts(self.conn.execute(
            "SELECT * FROM sleep_input_revisions WHERE source_id=? ORDER BY revision",
            (source_id,)))

    def revision_row(self, source_id: str, revision: int) -> dict[str, Any] | None:
        if not self.registry:
            return None
        row = self.conn.execute(
            "SELECT * FROM sleep_input_revisions WHERE source_id=? AND revision=?",
            (source_id, revision)).fetchone()
        return dict(row) if row else None

    def alias_rows(self, source_id: str) -> list[dict[str, Any]]:
        if not self.registry:
            return []
        return _dicts(self.conn.execute(
            "SELECT * FROM sleep_input_aliases WHERE source_id=? ORDER BY first_seen, locator",
            (source_id,)))

    def known_by_kind(self, kinds: tuple[str, ...]) -> list[dict[str, Any]]:
        """Все входы перечисленных типов (для инкрементального сравнения обхода с реестром)."""
        if not self.registry or not kinds:
            return []
        marks = ",".join("?" for _ in kinds)
        return _dicts(self.conn.execute(
            f"SELECT * FROM sleep_inputs WHERE kind IN ({marks})", kinds))  # noqa: S608

    def counts(self) -> dict[str, int]:
        """Счетчики реестра для статуса/доктора."""
        if not self.registry:
            return {"inputs": 0, "available": 0, "unavailable": 0, "blocked": 0, "unknown": 0,
                    "copies": 0, "experience": 0}
        one = lambda sql: int(self.conn.execute(sql).fetchone()[0])  # noqa: E731
        return {
            "inputs": one("SELECT COUNT(*) FROM sleep_inputs"),
            "available": one("SELECT COUNT(*) FROM sleep_inputs WHERE availability='available'"),
            "unavailable": one(
                "SELECT COUNT(*) FROM sleep_inputs WHERE availability='unavailable'"),
            "blocked": one("SELECT COUNT(*) FROM sleep_inputs WHERE availability='blocked'"),
            "unknown": one("SELECT COUNT(*) FROM sleep_inputs WHERE privacy='unknown'"),
            "copies": one("SELECT COUNT(*) FROM sleep_inputs WHERE is_copy=1"),
            "experience": one("SELECT COUNT(*) FROM sleep_inputs WHERE kind='experience'"),
        }

    # --- запись реестра (в транзакции вызывающего) ----------------------------------------- #
    def insert_input(self, row: dict[str, Any]) -> None:
        """Новый вход: строка ``sleep_inputs`` + ревизия 1 + текущий алиас-локатор."""
        data = {c: row.get(c, "") for c in _INPUT_COLUMNS}
        data["is_copy"] = int(bool(row.get("is_copy")))
        data["revision"] = int(row.get("revision") or 1)
        data["size"] = int(row.get("size") or 0)
        self.conn.execute(
            f"INSERT INTO sleep_inputs({', '.join(_INPUT_COLUMNS)}) "  # noqa: S608
            f"VALUES ({', '.join('?' for _ in _INPUT_COLUMNS)})",
            [data[c] for c in _INPUT_COLUMNS])
        self._insert_revision(data, data["updated_at"])
        self._set_alias(data["source_id"], data["locator"], data["updated_at"])

    def _insert_revision(self, data: dict[str, Any], now: str) -> None:
        rev = {c: data.get(c, "") for c in _REVISION_COLUMNS}
        rev["observed_at"] = now
        rev["size"] = int(data.get("size") or 0)
        self.conn.execute(
            f"INSERT OR REPLACE INTO sleep_input_revisions({', '.join(_REVISION_COLUMNS)}) "  # noqa: S608
            f"VALUES ({', '.join('?' for _ in _REVISION_COLUMNS)})",
            [rev[c] for c in _REVISION_COLUMNS])

    def _set_alias(self, source_id: str, locator: str, now: str) -> None:
        """Сделать ``locator`` текущим у ``source_id``; прежние его локаторы - не текущие."""
        if not locator:
            return
        self.conn.execute(
            "UPDATE sleep_input_aliases SET current=0 WHERE source_id=? AND locator<>?",
            (source_id, locator))
        self.conn.execute(
            "INSERT INTO sleep_input_aliases(locator, source_id, first_seen, last_seen, current) "
            "VALUES (?,?,?,?,1) ON CONFLICT(locator, source_id) DO UPDATE SET "
            "last_seen=excluded.last_seen, current=1", (locator, source_id, now, now))

    def new_revision(self, source_id: str, now: str, **cols: Any) -> int:
        """Содержимое входа изменилось: ревизия +1 (хеш/метод/покрытие - в ``cols``)."""
        row = self.input_row(source_id)
        if row is None:
            raise KeyError(source_id)
        revision = int(row["revision"]) + 1
        merged = {**row, "revision": revision, "updated_at": now, "last_seen_at": now,
                  "availability": "available", "unavailable_reason": "", **cols}
        sets = ", ".join(f"{c}=?" for c in _INPUT_COLUMNS if c != "source_id")
        self.conn.execute(
            f"UPDATE sleep_inputs SET {sets} WHERE source_id=?",  # noqa: S608
            [merged[c] for c in _INPUT_COLUMNS if c != "source_id"] + [source_id])
        self._insert_revision(merged, now)
        self._set_alias(source_id, str(merged["locator"]), now)
        return revision

    def touch(self, source_id: str, now: str, **cols: Any) -> None:
        """Вход виден и не менялся: ``last_seen_at`` (и сопутствующие колонки без новой ревизии).
        Вернувшийся вход снова доступен."""
        cols = {**cols, "last_seen_at": now}
        row = self.input_row(source_id)
        if row and row["availability"] == "unavailable" and "availability" not in cols:
            cols.update(availability="available", unavailable_reason="", updated_at=now)
        sets = ", ".join(f"{c}=?" for c in cols)
        self.conn.execute(f"UPDATE sleep_inputs SET {sets} WHERE source_id=?",  # noqa: S608
                          [*cols.values(), source_id])

    def move_locator(self, source_id: str, now: str, *, locator: str, note_rel: str = "",
                     note_id: str = "") -> None:
        """Переименование/перенос: тот же ``source_id``, новый локатор (старый остается алиасом)."""
        self.conn.execute(
            "UPDATE sleep_inputs SET locator=?, note_rel=?, note_id=?, last_seen_at=?, "
            "updated_at=?, availability='available', unavailable_reason='' WHERE source_id=?",
            (locator, note_rel, note_id, now, now, source_id))
        self._set_alias(source_id, locator, now)

    def set_availability(self, source_id: str, availability: str, reason: str, now: str) -> None:
        self.conn.execute(
            "UPDATE sleep_inputs SET availability=?, unavailable_reason=?, updated_at=? "
            "WHERE source_id=?", (availability, reason, now, source_id))

    def block(self, source_id: str, reason: str, now: str) -> None:
        """Вход стал личным/``_nda``/секретным уже ПОСЛЕ регистрации: путь стирается из реестра,
        вход заблокирован (``blocked``), прежняя история ревизий остается без локатора."""
        self.conn.execute(
            "UPDATE sleep_inputs SET availability='blocked', unavailable_reason=?, locator=?, "
            "note_rel='', note_id='', updated_at=? WHERE source_id=?",
            (reason, f"redacted:{source_id}", now, source_id))
        self.conn.execute("DELETE FROM sleep_input_aliases WHERE source_id=?", (source_id,))
        self.conn.execute("UPDATE sleep_input_revisions SET locator='' WHERE source_id=?",
                          (source_id,))

    # --- прогоны и worklist ------------------------------------------------------------------- #
    def run_row(self, run_id: str) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM sleep_runs WHERE run_id=?", (run_id,)).fetchone()
        return dict(row) if row else None

    def runs(self, states: tuple[str, ...] | None = None) -> list[dict[str, Any]]:
        sql, args = "SELECT * FROM sleep_runs", []
        if states:
            sql += f" WHERE state IN ({','.join('?' for _ in states)})"
            args = list(states)
        return _dicts(self.conn.execute(sql + " ORDER BY created_at, run_id", args))

    def create_run(self, run_id: str, now: str, *, scope: str, mode: str, budgets_json: str,
                   plan_digest: str, estimate_json: str, skipped_json: str) -> None:
        self.conn.execute(
            "INSERT INTO sleep_runs(run_id, state, scope, package_ref, created_at, updated_at, "
            "mode, budgets_json, plan_digest, estimate_json, skipped_json) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (run_id, "planned", scope, f"sleep/{run_id}", now, now, mode, budgets_json,
             plan_digest, estimate_json, skipped_json))

    def set_run_state(self, run_id: str, state: str, now: str, note: str = "") -> None:
        self.conn.execute(
            "UPDATE sleep_runs SET state=?, updated_at=?, note=CASE WHEN ?<>'' THEN ? "
            "ELSE note END WHERE run_id=?", (state, now, note, note, run_id))

    def worklist(self, run_id: str,
                 statuses: tuple[str, ...] | None = None) -> list[dict[str, Any]]:
        sql, args = "SELECT * FROM sleep_worklist WHERE run_id=?", [run_id]
        if statuses:
            sql += f" AND status IN ({','.join('?' for _ in statuses)})"
            args += list(statuses)
        return _dicts(self.conn.execute(sql + " ORDER BY seq, item_id", args))

    def work_item(self, run_id: str, item_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM sleep_worklist WHERE run_id=? AND item_id=?",
            (run_id, item_id)).fetchone()
        return dict(row) if row else None

    def open_items(self) -> list[dict[str, Any]]:
        """Невыполненные позиции прогонов: ``queued``/``tail``/``failed`` (хвост worklist). Из них
        следующий план берет первыми; ``done``/``skipped``/``carried`` - обработано."""
        return _dicts(self.conn.execute(
            "SELECT w.*, r.state AS run_state, r.lease_holder, r.lease_until FROM sleep_worklist w "
            "JOIN sleep_runs r ON r.run_id = w.run_id "
            "WHERE w.status IN ('queued','tail','failed') ORDER BY r.created_at, w.run_id, w.seq"))

    def handled_keys(
        self, statuses: tuple[str, ...] = ("queued", "tail", "done", "skipped"),
    ) -> set[tuple[str, int]]:
        """``(source_id, revision)``, уже разобранные или в очереди (не кандидаты заново)."""
        marks = ",".join("?" for _ in statuses)
        return {(r[0], int(r[1])) for r in self.conn.execute(
            f"SELECT source_id, revision FROM sleep_worklist WHERE status IN ({marks})",  # noqa: S608
            statuses)}

    def reason_keys(self, reason: str) -> set[tuple[str, int]]:
        """``(source_id, revision)`` позиций с этой причиной (кроме упавших)."""
        return {(r[0], int(r[1])) for r in self.conn.execute(
            "SELECT source_id, revision FROM sleep_worklist WHERE status <> 'failed' AND "
            "reasons_json LIKE ?", (f'%"{reason}"%',))}

    def put_item(self, run_id: str, item: dict[str, Any], now: str) -> None:
        self.conn.execute(
            "INSERT INTO sleep_worklist(run_id, item_id, seq, source_id, revision, family_id, "
            "item_kind, reasons_json, signals_json, priority, intended_use, difference, status, "
            "carried_from, note, created_at, updated_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (run_id, item["item_id"], item["seq"], item["source_id"], item["revision"],
             item.get("family_id", ""), item.get("item_kind", "input"),
             item["reasons_json"], item["signals_json"], float(item.get("priority") or 0),
             item.get("intended_use", ""), item.get("difference", ""), item["status"],
             item.get("carried_from", ""), item.get("note", ""), now, now))

    def set_item_status(self, run_id: str, item_id: str, status: str, now: str,
                        note: str = "") -> None:
        self.conn.execute(
            "UPDATE sleep_worklist SET status=?, updated_at=?, note=CASE WHEN ?<>'' THEN ? "
            "ELSE note END WHERE run_id=? AND item_id=?",
            (status, now, note, note, run_id, item_id))

    def move_item(self, old_run: str, old_item: str, new_run: str, now: str, **cols: Any) -> None:
        """Перенести позицию хвоста в новый прогон (одна строка на позицию - хвост не множится)."""
        cols = {**cols, "run_id": new_run, "carried_from": old_run, "updated_at": now}
        sets = ", ".join(f"{c}=?" for c in cols)
        self.conn.execute(
            f"UPDATE sleep_worklist SET {sets} WHERE run_id=? AND item_id=?",  # noqa: S608
            [*cols.values(), old_run, old_item])

    def lease_active(self, row: dict[str, Any], now: str) -> bool:
        return bool(row.get("lease_holder")) and str(row.get("lease_until") or "") > now

    # --- опыт сессий и квитанции чтения ------------------------------------------------------- #
    def experience_row(self, source_id: str, revision: int | None = None) -> dict[str, Any] | None:
        """Пакет опыта: ревизия ``revision`` либо последняя."""
        if not self.registry:
            return None
        sql = "SELECT * FROM sleep_experience WHERE source_id=?"
        args: list[Any] = [source_id]
        if revision is not None:
            sql += " AND revision=?"
            args.append(int(revision))
        row = self.conn.execute(sql + " ORDER BY revision DESC LIMIT 1", args).fetchone()
        return dict(row) if row else None

    def add_read(self, now: str, **cols: Any) -> None:
        """Квитанция чтения порции досье (журнал наблюдений; знания и реестр не меняет)."""
        cols = {"at": now, **cols}
        names = ", ".join(cols)
        self.conn.execute(
            f"INSERT INTO sleep_reads({names}) VALUES ({','.join('?' for _ in cols)})",  # noqa: S608
            list(cols.values()))

    def reads(self, run_id: str | None = None, item_id: str | None = None) -> list[dict[str, Any]]:
        if not self.registry:
            return []
        sql, args = "SELECT * FROM sleep_reads WHERE 1=1", []
        for col, val in (("run_id", run_id), ("item_id", item_id)):
            if val:
                sql += f" AND {col}=?"
                args.append(val)
        return _dicts(self.conn.execute(sql + " ORDER BY read_id", args))

    def facts_of_source(self, content_hash: str,
                        limit: int = 15) -> tuple[int, list[dict[str, Any]]]:
        """Факты стора по хешу источника (``facts.source_content_hash``): ``(всего, первые N)``.
        Только чтение; нет таблицы/ошибка - ``sqlite3.Error`` вызывающему."""
        if not content_hash or not self.has_table("facts"):
            return 0, []
        total = int(self.conn.execute(
            "SELECT COUNT(*) FROM facts WHERE source_content_hash=? AND (valid_to IS NULL "
            "OR valid_to='')", (content_hash,)).fetchone()[0])
        rows = self.conn.execute(
            "SELECT fact_id, kind, label, value_raw, unit, currency, locator FROM facts WHERE "
            "source_content_hash=? AND (valid_to IS NULL OR valid_to='') ORDER BY locator LIMIT ?",
            (content_hash, limit))
        return total, _dicts(rows)
