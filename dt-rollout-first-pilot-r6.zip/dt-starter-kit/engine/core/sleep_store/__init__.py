"""SLEEP-STORE-1 - ledger утверждений Сна в общей ``dt.db``, запись кандидатов, единый применитель.

Контракт знания и предложения - :mod:`core.sleep` (SLEEP-CONTRACT-1: схемы, блокирующий
валидатор, сравнение, ``issue_key``); здесь он ИСПОЛЬЗУЕТСЯ, не дублируется. ``core.sleep``
остается чистым (без SQLite и записи на диск): все, что хранит и пишет, живет в этом пакете.

* :mod:`core.sleep_store.schema` - DDL ledger (миграция v5 общего менеджера :mod:`core.db`);
* :mod:`core.sleep_store.store` - доступ к ledger, кандидаты отдельно от принятого, снимок для
  валидатора;
* :mod:`core.sleep_store.propose` - ``propose_memory``: запись кандидатов только через валидатор,
  идемпотентность по ``(run_id, idempotency_key)``;
* :mod:`core.sleep_store.locks` - короткая блокировка целевого набора (lease с TTL);
* :mod:`core.sleep_store.notes` - детерминированная заметка vault по принятым утверждениям;
* :mod:`core.sleep_store.applier` - решение владельца, CAS, prepared -> applying -> applied |
  conflict | failed | recovering, восстановитель;
* :mod:`core.sleep_store.cards` - карточка вида ``memory`` и ее объяснение (§9);
* :mod:`core.sleep_store.ops` - общие операции для CLI и MCP (одни проверки и эффекты).

Инварианты: до решения владельца в знания и facts ничего не пишется; запись заметки - только через
:func:`core.note_writer.write_note_atomic` и только из применителя; кандидаты вне обычной выдачи
(читатели принятого берут VIEW ``sleep_accepted_claims``); multi-file запрещен
(``multi_note_atomic_forbidden``). ``core`` ⊥ cli/mcp; ни сети, ни модели.
"""
