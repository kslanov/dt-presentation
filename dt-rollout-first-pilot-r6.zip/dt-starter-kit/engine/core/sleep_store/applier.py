"""SLEEP-STORE-1 п.4 - единый применитель: решение владельца -> CAS -> заметка -> ревизия -> индекс.

Единственное место, где принятое меняет знания (sleep-1.md §6.2-§6.3). Зовется только из
:func:`core.sleep_store.decide.decide_proposal` (то есть после решения владельца через общий реестр
карточек) и из восстановителя (:func:`recover`), который лишь ДОВОДИТ уже принятое.

**Путь** ``propose -> decide -> apply -> recover``::

    pending --approve--> [валидатор на свежем ledger] --stale--> stale (согласие не переносится)
        блокировка целевого набора (LockBusy -> conflict, ничего не записано)
        CAS цели: заметка на диске == то, что записал ledger (иначе stale с новым diff)
        prepared   одна транзакция: решение владельца + принятие + намерение (ожидаемые sha, текст)
        applying   файл: атомарная замена, квитанция (sha до/после)         [хук: before_file]
                   SQL: кандидаты -> принятое, ревизии, зависимости, effects [хук: before_sql]
        applied    ревизия опубликована; индексация (сброс среза frontmatter) [хук: before_index]
        conflict   третья сторона изменила цель между шагами - не перезаписываем
        failed     сбой шага; файл не опубликован либо возвращен, если он еще наш
        recovering восстановитель взял блокировку и доводит шаги по квитанциям

**CAS** - три уровня: ожидаемые ревизии утверждений (валидатор против свежего ledger под
блокировкой и повторно в транзакции публикации), sha заметки-цели (``sleep_notes``), актуальные хеши
источников (``Ledger.sources``, если хост дал резолвер). **Блокировка** - lease целевого набора
(:mod:`core.sleep_store.locks`): ``claim:<id>`` и ``note:<путь>``.

**Восстановитель** (:func:`recover`) работает под блокировкой и решает по sha файла: лежит наш
``new_sha`` - шаг файла сделан, идем дальше; лежит прежний ``prev_sha`` - дописываем файл; лежит
иное - ``conflict`` (посторонняя правка сохранена). Повтор approve/recovery возвращает прежние
``effects`` без новых ревизий. Откат опубликованного - не восстановление папки, а компенсирующее
предложение с CAS; автоматически возвращается только неопубликованное (файл, который мы же записали,
если публикация в SQL не состоялась).

Запись заметки - только :func:`core.note_writer.write_note_atomic`; модель сюда не допускается.
"""

from __future__ import annotations

import json
from dataclasses import replace
from typing import Any

from core.note_writer import (
    NoteWriteError,
    read_sha,
    remove_note_atomic,
    write_note_atomic,
)
from core.sleep.contract import (
    Actor,
    ApplyState,
    Claim,
    Decision,
    DecisionRecord,
    Operation,
    Pin,
    Proposal,
    ReviewState,
    Snapshot,
    claim_fingerprint,
    claim_from_dict,
)
from core.sleep.validate import Policy, validate_proposal
from core.sleep_store import locks, notes
from core.sleep_store.ctx import Ctx
from core.sleep_store.decide import STALE_CODES, outcome
from core.sleep_store.propose import SUPPORTED_OPERATIONS, default_entity_exists
from core.sleep_store.store import LedgerError, SleepStore, strip_claim

__all__ = ["approve", "recover", "lock_refs"]

_UNFINISHED = ("prepared", "applying", "recovering", "failed")
# Расхождение цели, которое владелец может принять НОВОЙ ревизией предложения после показа diff:
# ручная правка / чужая заметка по пути цели (наблюдаемый sha запомнен в stale_json).
_ADOPTABLE = ("target_changed", "target_untracked")
_MAX_DIFF = 1200


class _Conflict(Exception):
    """Третья сторона изменила цель между шагами."""


class _CasFailure(Exception):
    """Ожидаемая ревизия изменилась к моменту публикации."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def lock_refs(p: Proposal, note_rel: str = "") -> list[str]:
    """Целевой набор предложения: утверждения, связи и заметка."""
    refs = {f"claim:{c.claim_id}" for c in p.after.claims}
    refs |= {t.ref if t.ref.startswith("claim:") else f"{t.kind}:{t.ref}" for t in p.targets
             if t.kind == "claim"}
    refs |= {f"link:{x.link_id}" for x in p.after.links}
    if note_rel:
        refs.add(f"note:{note_rel}")
    return sorted(refs)


# --------------------------------------------------------------------------- #
# Вход: approve                                                                 #
# --------------------------------------------------------------------------- #
def approve(ctx: Ctx, store: SleepStore, row: dict[str, Any], params: dict[str, Any]
            ) -> dict[str, Any]:
    pid = row["proposal_id"]
    state, apply = row["review_state"], row["apply_state"]
    if state == "accepted":
        if apply == "applied":
            return _replay(ctx, store, pid)
        if apply in ("prepared", "applying", "recovering", "failed"):
            rep = _recover_one(ctx, store, pid)
            return _outcome_of_recovery(store, pid, rep)
        if apply == "conflict":
            return outcome("refused", "применение остановлено конфликтом: цель изменена третьей "
                           "стороной; нужен новый diff и новое решение", code="apply_conflict")
        return outcome("refused", "принято, но применения нет: состояние не согласовано",
                       code="apply_state_inconsistent")
    if state in ("rejected", "superseded", "stale"):
        return outcome("stale", f"предложение уже решено ({state})", code="already_decided")
    if state not in ("pending", "snoozed"):
        return outcome("refused", f"предложение в состоянии {state}: владельцу оно еще не "
                       "передано", code="not_ready")
    p = store.get_proposal(pid)
    if p is None:
        raise ValueError(f"предложение {pid!r} не найдено")
    if p.operation not in SUPPORTED_OPERATIONS:
        return outcome("refused", f"операцию {p.operation.value} этот пакет применить не умеет",
                       code="operation_not_supported")
    return _apply_new(ctx, store, row, p)


def _replay(ctx: Ctx, store: SleepStore, pid: str) -> dict[str, Any]:
    """Повтор approve по уже примененному: прежние effects, без новых ревизий; недоделанную
    индексацию (после сбоя) дожимает тем же идемпотентным шагом."""
    a = store.apply_row(pid)
    effects = json.loads((a or {}).get("effects_json") or "[]")
    if a and a["index_state"] != "done":
        _finish_index(ctx, store, pid, a)
    return outcome("applied", "Уже применено: повтор ничего не меняет", effects)


def _lock_set(store: SleepStore, ctx: Ctx, p: Proposal) -> tuple[list[str], str]:
    rel = ""
    if p.operation in (Operation.ADD, Operation.AMEND, Operation.SUPERSEDE):
        rel, _nid = notes.note_key(p, store)
    return lock_refs(p, rel), rel


def _apply_new(ctx: Ctx, store: SleepStore, row: dict[str, Any], p: Proposal) -> dict[str, Any]:
    pid = p.proposal_id
    now = ctx.stamp()
    try:
        refs, _rel = _lock_set(store, ctx, p)
    except notes.PlanError as exc:
        return outcome("refused", str(exc), code=exc.code)
    holder = locks.new_holder()
    try:
        try:
            locks.acquire(store, refs, holder, ttl_s=ctx.lock_ttl_s, now=now, proposal_id=pid)
        except locks.LockBusy as busy:
            with store.tx():
                store.log_apply(pid, "conflict", "conflict",
                                "цель занята: " + ", ".join(sorted(busy.refs)), now)
            return outcome("refused", "цель уже применяется другим решением (блокировка): ничего "
                           "не записано, повторите после завершения", code="apply_conflict",
                           apply_state=ApplyState.CONFLICT.value)
        released = False
        try:
            result = _apply_locked(ctx, store, row, p, holder, now)
        except Exception as exc:  # noqa: BLE001 - сбой шага: failed + отказ данными
            _mark_failed(store, pid, ctx.stamp(), f"{type(exc).__name__}: {str(exc)[:200]}")
            locks.release(store, holder)
            released = True
            return outcome("refused", f"применение не удалось ({type(exc).__name__}): остановлено, "
                           "восстановитель доведет", code="apply_failed",
                           apply_state=ApplyState.FAILED.value)
        if not released:
            locks.release(store, holder)
        return result
    finally:
        locks.forget(holder)   # при имитации падения (BaseException) БД-блокировка остается


# --------------------------------------------------------------------------- #
# Проверка + подготовка                                                          #
# --------------------------------------------------------------------------- #
def _stale(store: SleepStore, pid: str, now: str, codes: list[str], reasons: list[str],
           diff: str = "", **extra: Any) -> dict[str, Any]:
    revision = int((store.proposal_row(pid) or {}).get("revision") or 0)
    payload = {"codes": codes, "reasons": reasons, "diff": diff, "at": now,
               "revision": revision, **extra}
    with store.tx(immediate=True):
        store.set_proposal(pid, now, review_state=ReviewState.STALE.value,
                           stale_json=json.dumps(payload, ensure_ascii=False))
        store.log_apply(pid, "stale", "stale", "; ".join(codes), now)
    detail = ("цель или основание изменились: согласие не переносится, нужен новый diff и новое "
              "решение (" + ", ".join(codes) + ")")
    if reasons:
        detail += ": " + "; ".join(reasons)
    effects = []
    if diff:
        effects = ["новый diff:", *diff.splitlines()[:40]]
        if len(diff) > _MAX_DIFF:
            detail += f"\n{diff[:_MAX_DIFF]}…"
        else:
            detail += f"\n{diff}"
    return outcome("stale", detail, effects, code=codes[0], diff=diff)


def _accepted_claims(p: Proposal, receipt: DecisionRecord) -> list[Claim]:
    return [replace(c, review_state=ReviewState.ACCEPTED,
                    decisions=(*c.decisions, receipt)) for c in p.after.claims]


def _apply_locked(ctx: Ctx, store: SleepStore, row: dict[str, Any], p: Proposal, holder: str,
                  now: str) -> dict[str, Any]:
    pid = p.proposal_id
    cur = store.proposal_row(pid)
    if cur is None or cur["review_state"] not in ("pending", "snoozed") \
            or int(cur["revision"]) != int(row["revision"]):
        return outcome("stale", "предложение изменилось или решено другим путем: решение не "
                       "применено", code="already_decided")
    pending = replace(p, review_state=ReviewState.PENDING,
                      after=replace(p.after, claims=tuple(
                          replace(c, review_state=ReviewState.PENDING) for c in p.after.claims)))
    from core.sleep_synth.store import SynthError
    from core.sleep_synth.verify import check_application

    try:
        check_application(ctx, store, pending)
    except SynthError as exc:
        if exc.code=="synth_unverified":
            return outcome("refused", str(exc), code=exc.code)
        return _stale(store,pid,now,[exc.code],[str(exc)])
    ledger = store.ledger_snapshot(
        pending, now=now, source_hash=ctx.source_hash,
        entity_exists=ctx.entity_exists or default_entity_exists(ctx.vault))
    verdict = validate_proposal(pending, ledger, Policy())
    if verdict.violations:
        stale = [v for v in verdict.violations if v.code in STALE_CODES]
        if stale:
            return _stale(store, pid, now, list(dict.fromkeys(v.code for v in stale)),
                          [v.reason for v in stale])
        first = verdict.violations[0]
        return outcome("refused", f"{first.code}: {first.reason}", code=first.code,
                       violations=[v.to_dict() for v in verdict.violations])

    receipt = DecisionRecord(
        decision=Decision.ACCEPT, actor=Actor.OWNER, at=now, proposal_id=pid,
        proposal_revision=p.revision,
        pins=tuple(Pin(c.claim_id, claim_fingerprint(c)) for c in p.after.claims),
        evidence_digest=p.evidence_digest)
    accepted = _accepted_claims(p, receipt)
    olds = [t.ref.removeprefix("claim:") for t in p.targets
            if t.kind == "claim" and p.operation is Operation.SUPERSEDE]
    plan: notes.NotePlan | None = None
    adopted = False
    if p.operation is not Operation.RELATE:
        try:
            plan = notes.build_plan(store, ctx.vault, p, accepted, decided_at=now,
                                    superseded_ids=olds)
        except notes.PlanError as exc:
            if exc.code == "multi_note_atomic_forbidden":
                return outcome("refused", str(exc), code=exc.code)
            shadow: notes.NotePlan | None = None
            try:
                shadow = notes.build_plan(store, ctx.vault, p, accepted, decided_at=now,
                                          superseded_ids=olds, ignore_cas=True)
            except notes.PlanError:
                pass
            observed = shadow.prev_sha if shadow else None
            prior = json.loads(cur.get("stale_json") or "null") or {}
            adopt = (shadow is not None and exc.code in _ADOPTABLE and "observed_sha" in prior
                     and prior.get("observed_sha") == observed
                     and prior.get("target") == shadow.rel
                     and int(prior.get("revision") or 0) < p.revision)
            if not adopt:
                diff = notes.diff_text(shadow.prev_text, shadow.new_text) if shadow else ""
                return _stale(store, pid, now, [exc.code], [str(exc)], diff,
                              observed_sha=observed, target=shadow.rel if shadow else "")
            plan, adopted = shadow, True
    accepted_proposal = replace(
        p, review_state=ReviewState.ACCEPTED, apply_state=ApplyState.PREPARED,
        decision_receipt=receipt, after=Snapshot(claims=tuple(accepted), links=p.after.links,
                                                 note=p.after.note))
    final = validate_proposal(accepted_proposal, ledger, Policy())
    if final.violations:
        first = final.violations[0]
        return outcome("refused", f"{first.code}: {first.reason}", code=first.code,
                       violations=[v.to_dict() for v in final.violations])

    plan_json = json.dumps({
        "claims": [strip_claim(c).to_dict() for c in accepted], "superseded": olds,
        "note_id": plan.note_id if plan else "", "claim_ids": plan.claim_ids if plan else [],
        "created": plan.created if plan else False,
        "expected": [e.to_dict() for e in p.expected_revisions],
        "operation": p.operation.value, "links": len(p.after.links), "adopted": adopted,
    }, ensure_ascii=False, sort_keys=True)
    with store.tx(immediate=True):
        cur = store.proposal_row(pid)
        if cur is None or cur["review_state"] not in ("pending", "snoozed") \
                or int(cur["revision"]) != int(row["revision"]):
            return outcome("stale", "предложение решено другим путем", code="already_decided")
        store.add_decision(
            proposal_id=pid, revision=p.revision, decision=Decision.ACCEPT, actor=Actor.OWNER,
            host=ctx.host, at=now, evidence_digest=p.evidence_digest, pins=receipt.pins)
        store.set_proposal(pid, now, review_state=ReviewState.ACCEPTED.value,
                           apply_state=ApplyState.PREPARED.value)
        store.put_apply(
            pid, p.revision, now, state="prepared", stage="prepared", index_state="none",
            note_rel=plan.rel if plan else None, prev_sha=plan.prev_sha if plan else None,
            new_sha=plan.new_sha if plan else None, prev_text=plan.prev_text if plan else None,
            new_text=plan.new_text if plan else None, plan_json=plan_json, holder=holder,
            effects_json="[]", attempts=1)
        store.log_apply(pid, "prepared", "prepared", plan.rel if plan else "ledger-only", now)
    ctx.hook("after_prepare")
    return _execute(ctx, store, pid, holder)


# --------------------------------------------------------------------------- #
# Шаги: файл -> SQL -> индекс (общие для первого прохода и восстановления)       #
# --------------------------------------------------------------------------- #
def _mark_failed(store: SleepStore, pid: str, now: str, error: str) -> None:
    with store.tx(immediate=True):
        a = store.apply_row(pid)
        if a is not None and a["state"] != "applied":
            store.set_apply(pid, now, state="failed", error=error)
            store.set_proposal(pid, now, apply_state=ApplyState.FAILED.value)
            store.log_apply(pid, "failed", "failed", error, now)


def _execute(ctx: Ctx, store: SleepStore, pid: str, holder: str) -> dict[str, Any]:
    a = store.apply_row(pid)
    if a is None:
        raise LedgerError("apply_missing", f"нет намерения применения {pid}")
    now = ctx.stamp()
    with store.tx(immediate=True):
        store.set_apply(pid, now, state="applying", holder=holder)
        store.set_proposal(pid, now, apply_state=ApplyState.APPLYING.value)
        store.log_apply(pid, "applying", "applying", "", now)
    ctx.hook("before_file")
    rel = a["note_rel"]
    if rel:
        try:
            _file_step(ctx, store, pid, a)
        except _Conflict as exc:
            return _conflict(store, pid, ctx.stamp(), str(exc))
    ctx.hook("after_file")
    ctx.hook("before_sql")
    try:
        effects = _sql_step(ctx, store, pid, a)
    except _CasFailure as exc:
        _rollback_file(ctx, store, pid, a)
        return _stale_after_prepare(store, pid, ctx.stamp(), exc)
    ctx.hook("before_index")
    index_note = ""
    if rel:
        index_note = _finish_index(ctx, store, pid, a)
    return outcome("applied", "Принято и применено" + (f" ({index_note})" if index_note else ""),
                   effects)


def _file_step(ctx: Ctx, store: SleepStore, pid: str, a: dict[str, Any]) -> None:
    rel = a["note_rel"]
    path = ctx.vault / rel
    cur = read_sha(path)
    now = ctx.stamp()
    if cur == a["new_sha"]:
        receipt = {"path": rel, "sha_after": cur, "recovered": True, "at": now}
    elif cur == a["prev_sha"]:
        try:
            receipt = write_note_atomic(ctx.vault, rel, a["new_text"], expect_sha=a["prev_sha"],
                                        now=now, allowed_prefix=notes.MEMORY_DIR + "/")
        except NoteWriteError as exc:
            if exc.code == "cas_mismatch":
                raise _Conflict(str(exc)) from exc
            raise
    else:
        raise _Conflict(f"{rel}: на диске не прежняя и не наша версия (третья сторона)")
    with store.tx(immediate=True):
        store.set_apply(pid, now, stage="file",
                        receipt_json=json.dumps(receipt, ensure_ascii=False))
        store.log_apply(pid, "file_written", "applying",
                        f"{rel} {str(receipt.get('sha_after'))[:12]}", now)


def _conflict(store: SleepStore, pid: str, now: str, reason: str) -> dict[str, Any]:
    with store.tx(immediate=True):
        store.set_apply(pid, now, state="conflict", error=reason[:300])
        store.set_proposal(pid, now, apply_state=ApplyState.CONFLICT.value)
        store.log_apply(pid, "conflict", "conflict", reason, now)
    locks_row = store.apply_row(pid) or {}
    holder = locks_row.get("holder")
    if holder:
        locks.release(store, str(holder))
    return outcome("refused", f"конфликт: {reason}. Чужая правка сохранена, перезаписи нет; "
                   "нужен новый diff и новое решение", code="apply_conflict",
                   apply_state=ApplyState.CONFLICT.value)


def _stale_after_prepare(store: SleepStore, pid: str, now: str, exc: _CasFailure
                         ) -> dict[str, Any]:
    payload = {"codes": [exc.code], "reasons": [str(exc)], "diff": "", "at": now}
    with store.tx(immediate=True):
        store.set_apply(pid, now, state="failed", error=str(exc)[:300])
        store.set_proposal(pid, now, review_state=ReviewState.STALE.value,
                           apply_state=ApplyState.FAILED.value,
                           stale_json=json.dumps(payload, ensure_ascii=False))
        store.log_apply(pid, "stale", "failed", f"{exc.code}: {exc}", now)
    holder = (store.apply_row(pid) or {}).get("holder")
    if holder:
        locks.release(store, str(holder))
    return outcome("stale", f"ревизия цели изменилась до публикации ({exc.code}): применение "
                   "отменено, прежняя заметка возвращена; согласие не переносится",
                   code=exc.code)


def _rollback_file(ctx: Ctx, store: SleepStore, pid: str, a: dict[str, Any]) -> None:
    """Вернуть прежний файл, ЕСЛИ на диске еще наша версия (публикация в SQL не состоялась)."""
    rel = a["note_rel"]
    if not rel:
        return
    now = ctx.stamp()
    try:
        if a["prev_text"] is None:
            remove_note_atomic(ctx.vault, rel, expect_sha=a["new_sha"], now=now,
                               allowed_prefix=notes.MEMORY_DIR + "/")
        else:
            write_note_atomic(ctx.vault, rel, a["prev_text"], expect_sha=a["new_sha"], now=now,
                              allowed_prefix=notes.MEMORY_DIR + "/")
    except NoteWriteError:
        return  # файл уже не наш (третья сторона): посторонние изменения сохраняем
    with store.tx():
        store.log_apply(pid, "file_restored", "failed", rel, now)


def _sql_step(ctx: Ctx, store: SleepStore, pid: str, a: dict[str, Any]) -> list[str]:
    plan = json.loads(a["plan_json"])
    accepted = [claim_from_dict(c) for c in plan["claims"]]
    superseded = list(plan["superseded"])
    now = ctx.stamp()
    with store.tx(immediate=True):
        prop = store.proposal_row(pid)
        cur_apply = store.apply_row(pid)
        if prop is None or cur_apply is None:
            raise _CasFailure("apply_missing", "предложение или намерение исчезли")
        if cur_apply["state"] == "applied":   # повтор шага: уже опубликовано
            return list(json.loads(cur_apply["effects_json"] or "[]"))
        if prop["review_state"] != "accepted":
            raise _CasFailure("consent_not_transferable",
                              f"предложение уже в состоянии {prop['review_state']}")
        for e in plan["expected"]:
            ref = str(e["ref"])
            if not ref.startswith("claim:") or int(e["revision"]) <= 0:
                continue
            cid = ref.removeprefix("claim:")
            have = store.accepted_claims({cid}).get(cid)
            if have is None or have.revision != int(e["revision"]):
                raise _CasFailure("expected_revision_stale",
                                  f"{ref}: ожидалась ревизия {e['revision']}, в ledger "
                                  f"{have.revision if have else 'нет'}")
        for c in accepted:
            if plan["operation"] == Operation.ADD.value:
                taken = store.accepted_claims({c.claim_id})
                if taken and taken[c.claim_id].revision >= c.revision:
                    raise _CasFailure("expected_revision_stale",
                                      f"claim:{c.claim_id} уже принят")
        store.publish_claims(pid, accepted, superseded, now)
        if a["note_rel"]:
            store.put_note(a["note_rel"], plan["note_id"], a["new_sha"], list(plan["claim_ids"]),
                           now)
        effects = _effects(a, plan, accepted)
        store.set_proposal(pid, now, apply_state=ApplyState.APPLIED.value,
                           effects_json=json.dumps(effects, ensure_ascii=False))
        store.set_apply(pid, now, state="applied", stage="sql",
                        index_state="pending" if a["note_rel"] else "done",
                        effects_json=json.dumps(effects, ensure_ascii=False), error=None,
                        finished_at=now)
        store.log_apply(pid, "applied", "applied", f"claims={len(accepted)}", now)
    return effects


def _effects(a: dict[str, Any], plan: dict[str, Any], accepted: list[Claim]) -> list[str]:
    out: list[str] = []
    if a["note_rel"]:
        verb = "создана" if plan.get("created") else "обновлена"
        out.append(f"заметка {a['note_rel']} {verb} (sha {str(a['new_sha'])[:12]})")
        if plan.get("adopted"):
            out.append("ручная правка заметки принята как основа по вашему решению; остальной "
                       "текст заметки сохранен")
    for c in accepted:
        out.append(f"утверждение {c.claim_id} принято (ревизия {c.revision}, "
                   f"{c.type.value})")
    if plan["superseded"]:
        out.append("заменены (история остается): " + ", ".join(plan["superseded"]))
    if plan.get("links") and not a["note_rel"]:
        out.append(f"связей записано в ledger: {plan['links']}")
    if a["note_rel"]:
        out.append("индекс: срез frontmatter сброшен; векторы и FTS подхватит инкрементальный "
                   "reindex")
    return out


def _finish_index(ctx: Ctx, store: SleepStore, pid: str, a: dict[str, Any]) -> str:
    """Индексация записанной заметки (идемпотентный шаг; сбой не откатывает опубликованное)."""
    now = ctx.stamp()
    rel = a["note_rel"]
    if not rel:
        with store.tx():
            store.set_apply(pid, now, index_state="done")
        return ""
    try:
        ctx.index(rel)
    except Exception as exc:  # noqa: BLE001 - индекс производный: пересоберется, не откат знаний
        with store.tx():
            store.set_apply(pid, now, index_state="failed", error=f"index: {type(exc).__name__}")
            store.log_apply(pid, "index_failed", "applied", type(exc).__name__, now)
        return "индексация не завершена, восстановитель повторит"
    with store.tx():
        store.set_apply(pid, now, index_state="done")
        store.log_apply(pid, "index_done", "applied", rel, now)
    return ""


# --------------------------------------------------------------------------- #
# Восстановитель                                                                 #
# --------------------------------------------------------------------------- #
def _outcome_of_recovery(store: SleepStore, pid: str, rep: dict[str, Any]) -> dict[str, Any]:
    a = store.apply_row(pid) or {}
    if rep["result"] in ("recovered", "nothing") and a.get("state") == "applied":
        return outcome("applied", "Применение доведено восстановителем",
                       json.loads(a.get("effects_json") or "[]"))
    if rep["result"] == "locked":
        return outcome("refused", "цель занята другим применением: повторите позже",
                       code="apply_conflict")
    if rep["result"] == "conflict":
        return outcome("refused", rep.get("detail", "конфликт"), code="apply_conflict")
    if rep["result"] == "stale":
        return outcome("stale", rep.get("detail", "ревизия цели изменилась"),
                       code=rep.get("code", "expected_revision_stale"))
    return outcome("refused", rep.get("detail", "применение не доведено"), code="apply_failed")


def _recover_one(ctx: Ctx, store: SleepStore, pid: str) -> dict[str, Any]:
    a = store.apply_row(pid)
    if a is None:
        return {"proposal_id": pid, "result": "nothing", "detail": "нет намерения применения"}
    if a["state"] == "applied":
        if a["index_state"] != "done":
            _finish_index(ctx, store, pid, a)
            return {"proposal_id": pid, "result": "index_completed"}
        return {"proposal_id": pid, "result": "nothing", "detail": "уже применено"}
    if a["state"] == "conflict":
        return {"proposal_id": pid, "result": "conflict", "detail": a.get("error") or "конфликт"}
    prop = store.get_proposal(pid)
    if prop is None or prop.review_state is not ReviewState.ACCEPTED:
        return {"proposal_id": pid, "result": "nothing",
                "detail": "предложение не в состоянии accepted: доводить нечего"}
    plan = json.loads(a["plan_json"])
    refs = lock_refs(prop, a["note_rel"] or "")
    holder = locks.new_holder()
    now = ctx.stamp()
    try:
        try:
            locks.acquire(store, refs, holder, ttl_s=ctx.lock_ttl_s, now=now, proposal_id=pid)
        except locks.LockBusy:
            return {"proposal_id": pid, "result": "locked",
                    "detail": "блокировку держит живое применение"}
        with store.tx(immediate=True):
            store.set_apply(pid, now, state="recovering", holder=holder,
                            attempts=int(a["attempts"] or 0) + 1)
            store.set_proposal(pid, now, apply_state=ApplyState.RECOVERING.value)
            store.log_apply(pid, "recovering", "recovering", f"было {a['state']}/{a['stage']}", now)
        try:
            res = _execute(ctx, store, pid, holder)
        except Exception as exc:  # noqa: BLE001 - шаг снова не удался: failed, повтор возможен
            _mark_failed(store, pid, ctx.stamp(), f"{type(exc).__name__}: {str(exc)[:200]}")
            return {"proposal_id": pid, "result": "failed",
                    "detail": f"{type(exc).__name__}: {str(exc)[:160]}"}
        finally:
            locks.release(store, holder)
        kind = {"applied": "recovered", "stale": "stale"}.get(res["outcome"], "conflict"
                if res.get("code") == "apply_conflict" else "failed")
        return {"proposal_id": pid, "result": kind, "detail": res.get("detail", ""),
                "code": res.get("code", ""), "effects": res.get("effects", []),
                "was": f"{a['state']}/{a['stage']}", "claims": len(plan["claims"])}
    finally:
        locks.forget(holder)


def recover(ctx: Ctx, *, proposal_id: str | None = None) -> dict[str, Any]:
    """Довести незавершенные применения (prepared / applying / recovering / failed и недоделанную
    индексацию). Идемпотентно: повтор не создает новых ревизий и возвращает то же состояние.

    ``{ok, items: [{proposal_id, result: recovered|index_completed|nothing|conflict|locked|stale|
    failed, ...}], summary}``; ``conflict`` требует решения владельца, ``locked`` - повторить."""
    store = SleepStore.open_existing(ctx.db_path)
    if store is None:
        return {"ok": True, "items": [], "summary": {}}
    try:
        if proposal_id:
            pids = [proposal_id]
        else:
            rows = store.apply_rows((*_UNFINISHED, "conflict"))   # конфликт - на виду, не молча
            pids = [r["proposal_id"] for r in rows]
            pids += [r["proposal_id"] for r in store.conn.execute(
                "SELECT proposal_id FROM sleep_apply "
                "WHERE state='applied' AND index_state<>'done'")]
        items = [_recover_one(ctx, store, pid) for pid in dict.fromkeys(pids)]
    finally:
        store.close()
    summary: dict[str, int] = {}
    for it in items:
        summary[it["result"]] = summary.get(it["result"], 0) + 1
    ok = not any(it["result"] in ("failed", "conflict", "locked", "stale") for it in items)
    return {"ok": ok, "items": items, "summary": summary}
