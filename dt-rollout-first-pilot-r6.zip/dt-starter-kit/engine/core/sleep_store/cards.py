"""SLEEP-STORE-1 п.3 - карточка вида ``memory`` и ее объяснение (sleep-1.md §9).

Только чтение и форма: список ждущих предложений -> карточки единой формы реестра; объяснение -
тип изменения, что и почему сейчас, было/стало, проверено/неизвестно, ОБА основания конфликта,
условия, эффект. Решает и применяет не этот модуль (``decide`` вида ->
:mod:`core.sleep_store.decide` и :mod:`core.sleep_store.applier`).

Правка владельцем - новая ревизия предложения (``meta.proposal_revision`` меняется, значит
меняется и ``rev`` карточки реестра): старое согласие на измененный текст не переносится.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from core.sleep.contract import Claim, EvidenceRole, Operation, Proposal
from core.sleep_store import notes
from core.sleep_store.store import SleepStore

__all__ = ["CHANGE_LABELS", "OPERATION_LABELS", "card_fields", "change_kind", "explain",
           "effect_lines", "claim_view"]

OPERATION_LABELS = {
    Operation.ADD.value: "Новое утверждение",
    Operation.AMEND.value: "Уточнение утверждения",
    Operation.SUPERSEDE.value: "Замена утверждения",
    Operation.RELATE.value: "Связь между утверждениями",
    Operation.MERGE_REPRESENTATION.value: "Слияние представлений",
    Operation.REPAIR_REFERENCE.value: "Исправление ссылки",
    Operation.PROMOTE_CONTEXT.value: "Повышение в контекст",
    Operation.DEMOTE_CONTEXT.value: "Снятие с контекста",
}
#: SLEEP-PULT-1: тип изменения для карточки пульта (§17.3): подписи зависят от типа
CHANGE_LABELS = {"new": "Новое", "refinement": "Уточнение", "conflict": "Конфликт",
                 "link": "Связь", "hypothesis": "Гипотеза", "other": "Изменение"}
_CUT = 400


def change_kind(p: Proposal, compare: list[str] | None = None) -> str:
    """Тип изменения: ``hypothesis`` (в «стало» есть гипотеза - она остается гипотезой) >
    ``conflict`` (сравнение с принятым дало противоречие: показываются оба основания) > ``link`` >
    ``refinement`` (уточнение/замена/временное обновление) > ``new`` > ``other``."""
    results = set(compare or [])
    if any(c.type.value == "hypothesis" for c in p.after.claims):
        return "hypothesis"
    if "contradiction" in results:
        return "conflict"
    if p.operation is Operation.RELATE:
        return "link"
    if p.operation in (Operation.AMEND, Operation.SUPERSEDE) or results & {
            "refinement", "temporal_update"}:
        return "refinement"
    if p.operation is Operation.ADD:
        return "new"
    return "other"


def _cut(text: Any, n: int = _CUT) -> str:
    s = " ".join(str(text or "").split())
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"


def claim_view(c: Claim) -> dict[str, Any]:
    """Утверждение для показа: суть, условия, период, проверки, неизвестное (без тела основания)."""
    return {
        "claim_id": c.claim_id, "revision": c.revision, "type": c.type.value,
        "subject": c.subject, "predicate": c.predicate, "statement": _cut(c.statement),
        "object": c.object, "unit": c.unit, "area": c.area,
        "conditions": list(c.conditions), "exceptions": list(c.exceptions),
        "valid_from": c.valid_from, "valid_to": c.valid_to,
        "checks": [r.check.value for r in c.checks], "unknown": list(c.unknown),
        "fact_refs": [f.fact_id for f in c.fact_refs],
    }


def _evidence_rows(c: Claim) -> list[dict[str, Any]]:
    return [{"claim_id": c.claim_id, "role": e.role.value, "source_id": e.source_id,
             "revision": e.revision, "locator": e.locator, "coverage": e.coverage.value,
             "coverage_scope": e.coverage_scope, "source_kind": e.source_kind.value,
             "origin": e.origin} for e in c.evidence]


def _link_views(store: SleepStore, vault: Path, p: Proposal) -> tuple[list[dict], list[dict]]:
    if not p.after.links:
        return [], []
    from core.sleep_input.store import InputStore
    from core.sleep_store.evidence_view import preview
    from core.sleep_synth.verify import table_exists

    refs = {ref.removeprefix("claim:") for x in p.after.links for ref in (x.source, x.target)
            if ref.startswith("claim:")}
    names = {f"claim:{k}": _cut(c.statement, 180) for k, c in store.accepted_claims(refs).items()}
    inputs = InputStore(store.conn) if table_exists(store.conn, "sleep_inputs") else None
    links, bases = [], []
    for link in p.after.links:
        links.append({"type": link.type.value, "source": link.source, "target": link.target,
                      "source_label": names.get(link.source, ""),
                      "target_label": names.get(link.target, "")})
        for item in link.evidence:
            basis = {"link_id": link.link_id, "role": item.role.value, "source_id": item.source_id,
                     "revision": item.revision, "locator": item.locator,
                     "coverage": item.coverage.value, "coverage_scope": item.coverage_scope,
                     "source_kind": item.source_kind.value, "origin": item.origin}
            view = preview(vault, inputs, item) if inputs else {"preview_status": "unavailable"}
            if view["preview_status"] == "ready":
                basis.update(title=view["title"], path=view["path"], date=view["date"],
                             excerpt=view["excerpt"][:600])
            bases.append({**basis, "preview_status": view["preview_status"]})
    return links, bases


def effect_lines(store: SleepStore, vault: Path, p: Proposal) -> list[str]:
    """Что изменится при принятии (человеческие строки). До решения не менялось ничего."""
    out: list[str] = []
    op = p.operation
    if op is Operation.RELATE:
        for link in p.after.links:
            out.append(f"Связь {link.type.value}: {link.source} -> {link.target} записывается в "
                       "ledger; заметки vault не меняются")
    elif op in (Operation.ADD, Operation.AMEND, Operation.SUPERSEDE):
        try:
            rel, _nid = notes.note_key(p, store)
            exists = (vault / rel).is_file()
            out.append(f"{'Обновляется' if exists else 'Создается'} заметка {rel}")
        except notes.PlanError as exc:
            out.append(f"Применение невозможно: {exc}")
        for c in p.after.claims:
            if op is Operation.AMEND:
                prev = next((x for x in p.before.claims if x.claim_id == c.claim_id), None)
                out.append(f"Утверждение {c.claim_id}: ревизия {prev.revision if prev else '?'} "
                           f"-> {c.revision}; прежняя остается в истории ledger")
            else:
                out.append(f"Утверждение {c.claim_id} (ревизия {c.revision}) становится принятым"
                           f" знанием как «{c.type.value}»")
        if op is Operation.SUPERSEDE:
            olds = [t.ref.removeprefix("claim:") for t in p.targets if t.kind == "claim"]
            out.append("Заменяемые утверждения помечаются замененными (история остается): "
                       + ", ".join(olds))
    out.append("До вашего решения знания и facts не менялись; точные значения остаются в facts")
    return out


def _compare_view(store: SleepStore, row: dict[str, Any], p: Proposal) -> dict[str, Any] | None:
    """Сопоставление с принятым: результат, затронутые утверждения и ОБЕ версии с основаниями."""
    raw = json.loads(row.get("compare_json") or "null")
    if not raw:
        return None
    rows = [r for r in raw.get("results", []) if r.get("result")]
    matched = {m for r in rows for m in r.get("matched", [])}
    existing = store.accepted_claims(matched) if matched else {}
    versions: list[dict[str, Any]] = []
    for c in existing.values():
        versions.append({"side": "existing", **claim_view(c), "bases": _evidence_rows(c)})
    for c in p.after.claims:
        versions.append({"side": "candidate", **claim_view(c), "bases": _evidence_rows(c)})
    results = sorted({r["result"] for r in rows})
    return {"results": results, "details": rows,
            "show_both": any(r.get("show_both") for r in rows), "versions": versions}


def card_fields(store: SleepStore, vault: Path, row: dict[str, Any], p: Proposal) -> dict[str, Any]:
    """``title``/``reason``/``since``/``meta`` карточки реестра по предложению."""
    label = OPERATION_LABELS.get(p.operation.value, p.operation.value)
    first = p.after.claims[0] if p.after.claims else None
    links, link_bases = _link_views(store, vault, p)
    relation = links[0] if links else {}
    subject = f"{first.subject}: {first.predicate}" if first else (
        relation.get("source_label") or relation.get("source") or p.proposal_id
    )
    cmp = _compare_view(store, row, p)
    bases = [b for c in p.after.claims for b in _evidence_rows(c)] + link_bases
    meta: dict[str, Any] = {
        "proposal_id": p.proposal_id, "proposal_revision": int(row["revision"]),
        "operation": p.operation.value, "operation_label": label,
        "issue_key": row.get("issue_key") or "", "risk": p.risk.value,
        "run_id": p.run_id, "why_now": _cut(p.why_now, 300),
        "intended_use": _cut(p.intended_use, 300),
        "before": [claim_view(c) for c in p.before.claims],
        "after": [claim_view(c) for c in p.after.claims],
        "links": links,
        "checks": [{"step": c.step.value, "ok": c.ok} for c in p.checks],
        "blockers": [b.to_dict() for b in p.blockers],
        "bases": bases,
        "compare": cmp["results"] if cmp else [],
        "change_kind": (kind := change_kind(p, cmp["results"] if cmp else [])),
        "change_label": CHANGE_LABELS[kind],
        "conflict_versions": cmp["versions"] if cmp and cmp["show_both"] else [],
        "evidence_digest": p.evidence_digest[:16],
    }
    return {
        "title": f"Память: {label} - {_cut(subject, 70)}",
        "reason": _cut(p.why_now, 200),
        "since": row.get("created_at"),
        "meta": meta,
        "effect": effect_lines(store, vault, p),
    }


def explain(store: SleepStore, vault: Path, row: dict[str, Any], p: Proposal) -> dict[str, Any]:
    """«Почему» по §9: тип изменения, что и почему сейчас, было/стало, проверено/неизвестно,
    оба основания конфликта, условия, эффект."""
    cmp = _compare_view(store, row, p)
    gaps = [{"claim_id": c.claim_id, "source_id": e.source_id, "coverage": e.coverage.value,
             "coverage_scope": e.coverage_scope}
            for c in p.after.claims for e in c.evidence
            if e.coverage.value != "full" and e.role is not EvidenceRole.CONTEXT]
    diff = ""
    target_state = "ok"
    if p.operation in (Operation.ADD, Operation.AMEND, Operation.SUPERSEDE):
        try:
            rel = notes.note_key(p, store)[0]
            try:
                notes.check_target(store, vault, rel)
            except notes.PlanError as exc:
                target_state = exc.code
            cur_text = notes.read_current(vault, rel)[0]
            olds = [t.ref.removeprefix("claim:") for t in p.targets
                    if t.kind == "claim" and p.operation is Operation.SUPERSEDE]
            plan = notes.build_plan(store, vault, p, list(p.after.claims),
                                    decided_at=row.get("created_at") or "", superseded_ids=olds,
                                    ignore_cas=True)
            diff = notes.diff_text(cur_text, plan.new_text)
        except notes.PlanError as exc:
            diff = f"[{exc.code}] {exc}"
            target_state = exc.code
    stale = json.loads(row.get("stale_json") or "null")
    links, link_bases = _link_views(store, vault, p)
    return {
        "proposal_id": p.proposal_id, "revision": int(row["revision"]),
        "operation": p.operation.value,
        "change_kind": (kind := change_kind(p, cmp["results"] if cmp else [])),
        "change_label": CHANGE_LABELS[kind],
        "change_type": OPERATION_LABELS.get(p.operation.value, p.operation.value),
        "state": {"review_state": row["review_state"], "apply_state": row["apply_state"]},
        "what": [claim_view(c) for c in p.after.claims],
        "why_now": p.why_now, "intended_use": p.intended_use, "risk": p.risk.value,
        "before": [claim_view(c) for c in p.before.claims],
        "after": [claim_view(c) for c in p.after.claims],
        "checked": {
            "pipeline": [{"step": c.step.value, "ok": c.ok, "by": c.by} for c in p.checks],
            "claims": [{"claim_id": c.claim_id, "checks": [r.check.value for r in c.checks],
                        "reviewed_by": [r.by for r in c.checks if r.by]} for c in p.after.claims],
        },
        "unknown": [{"claim_id": c.claim_id, "unknown": list(c.unknown),
                     "stale_risk": c.stale_risk.value, "next_check_on": c.next_check_on}
                    for c in p.after.claims],
        "blockers": [b.to_dict() for b in p.blockers],
        "coverage_gaps": gaps,
        "bases": [b for c in p.after.claims for b in _evidence_rows(c)] + link_bases,
        "links": links,
        "conflict": cmp,
        "conditions": [{"claim_id": c.claim_id, "conditions": list(c.conditions),
                        "exceptions": list(c.exceptions), "valid_from": c.valid_from,
                        "valid_to": c.valid_to, "unit": c.unit, "area": c.area}
                       for c in p.after.claims],
        "effect": effect_lines(store, vault, p),
        "note_diff": diff, "target_state": target_state,
        "issue_key": row.get("issue_key") or "",
        "stale": stale,
        "effects_done": json.loads(row.get("effects_json") or "[]"),
    }
