"""SLEEP-STORE-1 - контекст операций ledger: пути, время, инъекции (источники, сущности, сбои).

Один объект на все поверхности (реестр карточек, CLI, MCP): так одинаковые проверки и effects
(сценарий 20) получаются тем, что код один, а различаются только способы собрать ``Ctx``.
``hooks`` - точки имитации сбоя/паузы в тестах (``after_prepare``, ``before_file``, ``after_file``,
``before_sql``, ``before_index``): боевой код хуков не задает.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.sleep_store.store import now_iso

__all__ = ["Ctx", "Hooks", "default_index"]

Hooks = dict[str, Callable[[], None]]


def default_index(vault: Path, rel: str) -> None:
    """Индексация записанной заметки: сбрасывает срез frontmatter (поиск по заголовкам видит ее
    сразу); векторы и FTS подхватит штатный инкрементальный ``reindex`` по хешу файла - полный
    пересчет в момент применения не запускается (дорого, делает шаг ночной цепочки)."""
    from core.retrieval import fm_cache

    fm_cache.forget(vault, [rel])


@dataclass
class Ctx:
    vault: Path
    db_path: Path | None = None
    now: str = ""
    host: str = "cli"
    source_hash: Callable[[str], str | None] | None = None
    entity_exists: Callable[[str], bool] | None = None
    hooks: Hooks = field(default_factory=dict)
    indexer: Callable[[Path, str], None] | None = None
    lock_ttl_s: float = 120.0
    extra: dict[str, Any] = field(default_factory=dict)

    def stamp(self) -> str:
        return now_iso(self.now or None)

    def hook(self, name: str) -> None:
        fn = self.hooks.get(name)
        if fn is not None:
            fn()

    def index(self, rel: str) -> None:
        (self.indexer or default_index)(self.vault, rel)
