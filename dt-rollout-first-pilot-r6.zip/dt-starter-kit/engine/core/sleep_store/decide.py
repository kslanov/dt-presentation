"""SLEEP-STORE-1 п.3/п.4 - решение владельца по предложению: принять / отклонить / отложить.

Единственная точка, где появляется решение. Ее зовет вид ``memory`` реестра карточек
(:class:`core.decisions.kinds.MemoryKind`) - значит, только путь list/decide/explain общей
очереди (второй очереди нет) - и никто больше. Отказ и откладывание - запись в журнал решений и
смена состояния (знания не меняются); принятие - :mod:`core.sleep_store.applier` (CAS,
блокировка, заметка).

Форма исхода - как у ядер видов реестра: ``{outcome: applied|rejected|snoozed|stale|refused,
code?, detail, effects}``. Соответствие кодов валидатора исходам - матрица SLEEP-CONTRACT-1 §2.6:
изменилось основание/цель/редакция - ``stale`` (согласие не переносится), повтор подавлен -
``refused``.
"""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any

from core.sleep.contract import Actor, Decision
from core.sleep_store.ctx import Ctx
from core.sleep_store.store import SleepStore

__all__ = ["ACTIONS", "STALE_CODES", "decide_proposal", "outcome"]

ACTIONS = ("approve", "reject", "snooze")
# Коды валидатора, при которых согласие не переносится: исход ``stale`` (матрица §2.6).
STALE_CODES = frozenset({"expected_revision_stale", "source_changed", "consent_not_transferable",
                         "operation_target_missing"})
SNOOZE_DAYS = (1, 90)


def outcome(kind: str, detail: str = "", effects: list[str] | None = None, *,
            code: str | None = None, **extra: Any) -> dict[str, Any]:
    out: dict[str, Any] = {"outcome": kind, "detail": detail, "effects": list(effects or [])}
    if code:
        out["code"] = code
    out.update(extra)
    return out


def _parse_now(stamp: str) -> datetime:
    return datetime.strptime(stamp, "%Y-%m-%dT%H:%M:%SZ")


def _expected_revision(params: dict[str, Any]) -> int | None:
    raw = params.get("expected_revision")
    if raw in (None, ""):
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        raise ValueError("expected_revision: ожидается целое число (ревизия предложения)") from None


def decide_proposal(ctx: Ctx, proposal_id: str, action: str, params: dict[str, Any] | None = None
                    ) -> dict[str, Any]:
    """Решение владельца. ``ValueError`` - неизвестное действие/предложение/параметр (диспетчер
    реестра превращает в ``refused``); хранилище недоступно - исключение ``sqlite3.Error`` /
    ``OSError`` (вид превращает его в ``store_unavailable``)."""
    params = dict(params or {})
    if action not in ACTIONS:
        raise ValueError(f"неизвестное действие {action!r}")
    expected = _expected_revision(params)
    store = SleepStore.open_existing(ctx.db_path)
    if store is None or (row := store.proposal_row(proposal_id)) is None:
        if store is not None:
            store.close()
        raise ValueError(f"предложение {proposal_id!r} не найдено")
    try:
        if expected is not None and expected != int(row["revision"]):
            return outcome(
                "stale", f"предложение изменилось: вы видели ревизию {expected}, сейчас "
                f"{row['revision']}; согласие на другую редакцию не переносится",
                code="consent_not_transferable", revision=int(row["revision"]))
        state = row["review_state"]
        if action == "approve":
            from core.sleep_store import applier

            return applier.approve(ctx, store, row, params)
        if state in ("accepted", "rejected", "superseded", "stale"):
            return outcome("stale", f"предложение уже решено ({state})", code="already_decided")
        if state not in ("pending", "snoozed"):
            return outcome("refused", f"предложение в состоянии {state}: владельцу оно еще не "
                           "передано", code="not_ready")
        return _reject(ctx, store, row, params) if action == "reject" \
            else _snooze(ctx, store, row, params)
    finally:
        store.close()


def _reject(ctx: Ctx, store: SleepStore, row: dict[str, Any], params: dict[str, Any]
            ) -> dict[str, Any]:
    reason = str(params.get("reason") or "").strip()[:500]
    now = ctx.stamp()
    with store.tx(immediate=True):
        cur = store.proposal_row(row["proposal_id"])
        if cur is None or cur["review_state"] not in ("pending", "snoozed"):
            return outcome("stale", "предложение уже решено другим путем", code="already_decided")
        store.add_decision(
            proposal_id=row["proposal_id"], revision=int(cur["revision"]), decision=Decision.REJECT,
            actor=Actor.OWNER, host=ctx.host, at=now, evidence_digest=cur["evidence_digest"] or "",
            reason=reason)
        store.set_proposal(row["proposal_id"], now, review_state="rejected")
        store.mark_claims(row["proposal_id"], "rejected", "rejected", now)
    return outcome(
        "rejected", reason or "отклонено",
        [f"предложение {row['proposal_id']} отклонено; повтор с тем же основанием "
         f"(evidence_digest {str(row['evidence_digest'])[:12]}) не воскреснет, новое основание "
         "потребует связанной ревизии с объяснением"])


def _snooze(ctx: Ctx, store: SleepStore, row: dict[str, Any], params: dict[str, Any]
            ) -> dict[str, Any]:
    try:
        days = int(float(params.get("days") or 7))
    except (TypeError, ValueError):
        raise ValueError("days: ожидается число дней") from None
    lo, hi = SNOOZE_DAYS
    if not lo <= days <= hi:
        raise ValueError(f"days: от {lo} до {hi}")
    now = ctx.stamp()
    until = (_parse_now(now) + timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")
    with store.tx(immediate=True):
        cur = store.proposal_row(row["proposal_id"])
        if cur is None or cur["review_state"] not in ("pending", "snoozed"):
            return outcome("stale", "предложение уже решено другим путем", code="already_decided")
        store.add_decision(
            proposal_id=row["proposal_id"], revision=int(cur["revision"]), decision=Decision.SNOOZE,
            actor=Actor.OWNER, host=ctx.host, at=now, evidence_digest=cur["evidence_digest"] or "",
            snooze_until=until)
        store.set_proposal(row["proposal_id"], now, review_state="snoozed", snooze_until=until)
    return outcome("snoozed", f"Вернется {until}",
                   [f"карточка отложена на {days} дн.; то же основание до срока не вернется"])
