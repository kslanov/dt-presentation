"""Resolve a pinned basis for human review without trusting the stored excerpt."""

import re
from pathlib import Path

import yaml  # type: ignore[import-untyped]

from core.retrieval.mail_read import parse_thread
from core.sleep.contract import Evidence, fragment_fingerprint
from core.sleep.validate import contains_secret
from core.sleep_input.discover import content_hash_of, kind_of
from core.sleep_input.dossier import MAX_READ_BYTES, _safe_note, _split_frontmatter
from core.sleep_input.privacy import classify_note, classify_path_only
from core.sleep_input.store import InputStore


def preview(vault: Path, inputs: InputStore, evidence: Evidence) -> dict:
    row = inputs.input_row(evidence.source_id)
    if not row or row["availability"] != "available" or row["privacy"] != "work":
        return {"preview_status": "unavailable"}
    rel = str(row["note_rel"] or "")
    if not rel or not classify_path_only(rel, evidence.source_path).ok:
        return {"preview_status": "unavailable"}
    if row["revision"] != evidence.revision or not evidence.content_hash:
        return {"preview_status": "changed"}
    raw, refusal = _safe_note(vault, rel)
    if refusal or raw is None or len(raw) > MAX_READ_BYTES:
        return {"preview_status": "unavailable"}
    text = raw.decode("utf-8", errors="replace")
    try:
        metadata, body = _split_frontmatter(text)
    except (ValueError, TypeError, yaml.YAMLError):
        return {"preview_status": "unavailable"}
    if not classify_note(rel, metadata, text, vault=vault).ok:
        return {"preview_status": "unavailable"}
    kind, _ = kind_of(metadata, str(metadata.get("id") or Path(rel).stem))
    if content_hash_of(kind, metadata, raw) != evidence.content_hash:
        return {"preview_status": "changed"}
    prefix = f"{evidence.source_id}@{evidence.revision}#"
    if not evidence.locator.startswith(prefix):
        return {"preview_status": "unavailable"}
    suffix = evidence.locator[len(prefix):]
    title_match = re.search(r"(?m)^Тред:\s*(.+)$|^#\s+(.+)$", body)
    title = str(metadata.get("title") or metadata.get("subject") or (
        next((part for part in title_match.groups() if part), "") if title_match else ""
    ) or Path(rel).stem)[:240]
    date = str(row["valid_date"] or "")[:16]
    sender = ""
    if re.fullmatch(r"m[1-9][0-9]{0,7}", suffix):
        thread = parse_thread(body)
        message = next((msg for msg in thread.messages if msg.idx == int(suffix[1:])), None) \
            if thread else None
        if message is None:
            return {"preview_status": "unavailable"}
        fragment = message.header + ("\n" + message.text if message.text else "")
        excerpt = message.text
        date, sender = message.date, message.sender.split("<", 1)[0].strip()[:120]
    elif match := re.fullmatch(r"c([0-9]{1,8})-([0-9]{1,8})", suffix):
        start, stop = map(int, match.groups())
        if not 0 <= start < stop <= len(body):
            return {"preview_status": "unavailable"}
        fragment = excerpt = body[start:stop]
    else:
        return {"preview_status": "unavailable"}
    if fragment_fingerprint(fragment) != evidence.fragment_fingerprint or contains_secret(excerpt):
        return {"preview_status": "changed"}
    excerpt = excerpt.strip()
    return {"preview_status": "ready", "path": rel, "title": title, "date": date, "sender": sender,
            "excerpt": excerpt[:12000], "excerpt_truncated": len(excerpt) > 12000}
