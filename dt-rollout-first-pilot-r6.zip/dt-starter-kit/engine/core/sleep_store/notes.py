"""SLEEP-STORE-1 п.4/п.5 - принятое как штатная заметка vault: тип, каталог, детерминированный вид.

**Принятое - заметка vault** (sleep-1.md §3): ``type: note`` по живой схеме, каталог
``02-knowledge/memory/`` (подкаталог существующего ``02-knowledge``, нового верхнего каталога нет),
``id: memory-<ключ>``. Один атомарный пакет предложения - ОДНА заметка (MVP, §6.3): утверждения
группы лежат в одной заметке, каждое в своем блоке между маркерами
``<!-- sleep:claim id=… rev=… fp=… -->`` … ``<!-- /sleep:claim -->``; точные значения остаются в
facts, блок ссылается на ``fact_id`` (``fact:<id>``), а не копирует число как истину.

``sha256`` всей заметки хранится в ``sleep_notes`` и служит CAS: ручная правка цели между
предложением и принятием - ``stale`` с новым diff (согласие не переносится). Меняются только блоки
ledger, остальной текст заметки (ручные дополнения, чужие ключи frontmatter) сохраняется байт-в-
байт: потерянных строк нет. Отрисовка детерминирована: тот же вход - те же байты, поэтому повтор
применения не создает новой ревизии. Модуль только строит текст и план; пишет заметку применитель
через :func:`core.note_writer.write_note_atomic`.
"""

from __future__ import annotations

import difflib
import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml  # type: ignore[import-untyped]

from core.sleep.contract import Claim, ClaimType, EvidenceRole, Proposal
from core.sleep_store.store import SleepStore

__all__ = [
    "BLOCK_RE",
    "MEMORY_DIR",
    "NotePlan",
    "PlanError",
    "build_plan",
    "diff_text",
    "note_key",
    "parse_blocks",
    "render_block",
    "sha_text",
    "slug",
]

MEMORY_DIR = "02-knowledge/memory"
BLOCK_RE = re.compile(
    r"<!-- sleep:claim id=(?P<id>\S+) rev=(?P<rev>\d+) fp=(?P<fp>\w+) -->\n"
    r"(?P<body>.*?)<!-- /sleep:claim -->\n?", re.DOTALL)
_TYPE_RU = {
    ClaimType.SOURCE_ASSERTION: "утверждение источника",
    ClaimType.INFERENCE: "вывод",
    ClaimType.HYPOTHESIS: "гипотеза (не факт)",
    ClaimType.OWNER_DECISION: "решение владельца",
    ClaimType.PROCEDURE: "прием",
}


class PlanError(RuntimeError):
    """План заметки невозможен: ``code`` (``multi_note_atomic_forbidden`` | ``target_changed`` |
    ``target_untracked`` | ``target_missing``) и объяснение."""

    def __init__(self, code: str, message: str, *, diff: str = "") -> None:
        super().__init__(message)
        self.code = code
        self.diff = diff


def slug(text: str) -> str:
    """Безопасное имя файла: ``[A-Za-z0-9._-]``; если пришлось менять, добавляется хеш (разные
    исходные имена не склеиваются)."""
    clean = re.sub(r"[^A-Za-z0-9._-]+", "-", text).strip("-.")[:60] or "note"
    if clean != text:
        clean = f"{clean}-{hashlib.sha1(text.encode('utf-8')).hexdigest()[:8]}"  # noqa: S324
    return clean


def sha_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def note_key(p: Proposal, store: SleepStore) -> tuple[str, str]:
    """``(note_rel, note_id)`` заметки предложения. Утверждения, уже живущие в заметке ledger, идут
    в ту же заметку; в двух разных заметках сразу - ``multi_note_atomic_forbidden``; новое - по
    атомарной единице группы, иначе по ``claim_id`` первого утверждения."""
    ids = [c.claim_id for c in p.after.claims]
    ids += [t.ref.removeprefix("claim:") for t in p.targets if t.kind == "claim"]
    homes = {rel for cid in dict.fromkeys(ids) if (rel := store.note_of_claim(cid))}
    if len(homes) > 1:
        raise PlanError("multi_note_atomic_forbidden",
                        "MVP: одна заметка на атомарное предложение; утверждения живут в "
                        f"{len(homes)} заметках - объединять их в одном применении запрещено")
    if homes:
        rel = next(iter(homes))
        row = store.note_row(rel)
        return rel, str((row or {}).get("note_id") or f"memory-{Path(rel).stem}")
    base = slug(p.group.atomic_unit) if p.group and p.group.atomic_unit else slug(ids[0])
    return f"{MEMORY_DIR}/{base}.md", f"memory-{base}"


def _fmt_period(c: Claim) -> str:
    if c.valid_from and c.valid_to:
        return f"с {c.valid_from} по {c.valid_to} (не включая)"
    if c.valid_from:
        return f"с {c.valid_from}, пока не заменено"
    if c.valid_to:
        return f"до {c.valid_to} (не включая)"
    return "не указан"


def render_block(c: Claim, *, proposal_id: str, decided_at: str, status_note: str = "") -> str:
    """Блок одного утверждения (между маркерами). Детерминирован: порядок строк фиксирован."""
    from core.sleep.contract import claim_fingerprint

    value = f"{c.object} {c.unit}".strip()
    fp = claim_fingerprint(c)[:16]
    lines = [f"<!-- sleep:claim id={c.claim_id} rev={c.revision} fp={fp} -->",
             f"## {c.subject} - {c.predicate}", "",
             f"- Тип: {_TYPE_RU.get(c.type, c.type.value)}",
             f"- Утверждение: {c.statement}", f"- Значение: {value}"]
    if c.area:
        lines.append(f"- Область: {c.area}")
    if c.conditions:
        lines.append("- Условия: " + "; ".join(c.conditions))
    if c.exceptions:
        lines.append("- Исключения: " + "; ".join(c.exceptions))
    lines.append(f"- Период: {_fmt_period(c)}")
    if c.negative:
        lines.append(f"- Отрицательное утверждение, область проверки: {c.search_scope}")
    if c.type is ClaimType.PROCEDURE and c.procedure is not None:
        pr = c.procedure
        lines += [f"- Прием, условия: {'; '.join(pr.conditions)}",
                  f"- Прием, действие: {pr.action}",
                  f"- Прием, результат: {pr.observable_result}",
                  f"- Прием, среда: {pr.environment_version}",
                  f"- Прием, отмена: {pr.undo}"]
    if c.type is ClaimType.INFERENCE:
        lines.append("- Посылки: " + ", ".join(c.premises))
        lines.append(f"- Объяснение: {c.explanation}")
    for e in c.evidence:
        if e.role is EvidenceRole.CONTEXT:
            continue
        mark = "против" if e.role is EvidenceRole.CONTRADICT else "за"
        cov = e.coverage.value + (f": {e.coverage_scope}" if e.coverage_scope else "")
        lines.append(f"- Основание ({mark}): {e.source_id} r{e.revision}, {e.locator}, "
                     f"покрытие {cov}")
    for f in c.fact_refs:
        lines.append(f"- Точное значение: fact:{f.fact_id}" + (f" ({f.fact_key})" if f.fact_key
                                                                else ""))
    done = ", ".join(r.check.value for r in c.checks) or "нет"
    lines.append(f"- Проверено: {done}")
    if c.unknown:
        lines.append("- Неизвестно: " + "; ".join(c.unknown))
    lines.append(f"- Принято владельцем: решение {proposal_id}, {decided_at[:10]}")
    if status_note:
        lines.append(f"- Статус: {status_note}")
    lines.append("<!-- /sleep:claim -->")
    return "\n".join(lines) + "\n"


def parse_blocks(text: str) -> list[tuple[str, int, str]]:
    """``[(claim_id, revision, полный текст блока)]`` в порядке следования."""
    return [(m["id"], int(m["rev"]), m.group(0)) for m in BLOCK_RE.finditer(text)]


_FM_RE = re.compile(r"\A---\n(.*?)\n---\n", re.DOTALL)


def _split(text: str | None) -> tuple[dict[str, object], str]:
    """``(frontmatter, тело)`` заметки; нет или битый frontmatter - ``({}, весь текст)``."""
    if not text:
        return {}, "\n"
    m = _FM_RE.match(text)
    if not m:
        return {}, text
    try:
        fm = yaml.safe_load(m.group(1)) or {}
    except yaml.YAMLError:
        return {}, text
    return (fm if isinstance(fm, dict) else {}), text[m.end():]


def _put_block(body: str, cid: str, text: str) -> str:
    """Заменить блок ``cid`` на месте (прочий, в т.ч. ручной, текст байт-в-байт) либо дописать."""
    pat = re.compile(r"<!-- sleep:claim id=" + re.escape(cid)
                     + r" rev=\d+ fp=\w+ -->\n.*?<!-- /sleep:claim -->\n?", re.DOTALL)
    if pat.search(body):
        return pat.sub(lambda _m: text, body, count=1)
    base = body.rstrip("\n")
    return (base + "\n\n" if base.strip() else "\n") + text


def _front(old: dict[str, object], note_id: str, title: str, created: str, modified: str,
           claims: list[Claim], ids: list[str]) -> str:
    """Frontmatter: управляемые ledger ключи обновляются, чужие (теги и т.п.) сохраняются."""
    facts: list[str] = []
    for c in claims:
        facts += [f.fact_id for f in c.fact_refs if f.fact_id not in facts]
    fm: dict[str, object] = dict(old)
    fm.setdefault("id", note_id)
    fm.setdefault("type", "note")
    fm.setdefault("title", title)
    fm.setdefault("status", "active")
    fm.setdefault("created", created)
    fm["modified"] = modified
    fm["claim_ids"] = ids
    types = sorted({c.type.value for c in claims})
    if types:
        fm["claim_types"] = types
    if facts:
        fm["fact_ids"] = facts
    else:
        fm.pop("fact_ids", None)
    fm["managed_by"] = "dt-sleep-ledger"
    return "---\n" + yaml.safe_dump(fm, allow_unicode=True, sort_keys=False, width=1000) + "---\n"


@dataclass
class NotePlan:
    """Что будет записано: цель, ожидаемое прежнее состояние и итоговый текст."""

    rel: str
    note_id: str
    created: bool
    prev_text: str | None
    prev_sha: str | None
    new_text: str
    new_sha: str
    claim_ids: list[str] = field(default_factory=list)
    superseded: list[str] = field(default_factory=list)

    @property
    def changed(self) -> bool:
        return self.new_sha != self.prev_sha


def diff_text(old: str | None, new: str, *, limit: int = 60) -> str:
    lines = list(difflib.unified_diff((old or "").splitlines(), new.splitlines(),
                                      "было", "стало", lineterm="", n=1))
    if len(lines) > limit:
        lines = [*lines[:limit], f"… еще {len(lines) - limit} строк"]
    return "\n".join(lines)


def _title(claims: list[Claim], p: Proposal) -> str:
    if p.group and p.group.atomic_unit:
        return f"Память: {p.group.atomic_unit}"
    c = claims[0]
    return f"{c.subject}: {c.predicate}"


def read_current(vault: Path, rel: str) -> tuple[str | None, str | None]:
    path = vault / rel
    if not path.is_file():
        return None, None
    data = path.read_bytes()
    return data.decode("utf-8"), hashlib.sha256(data).hexdigest()


def check_target(store: SleepStore, vault: Path, rel: str) -> tuple[str | None, str | None]:
    """Сверка цели с тем, что записал ledger (CAS). Возвращает текущие ``(text, sha)`` или
    ``PlanError``: ручная правка (``target_changed``), удаленная вручную (``target_missing``),
    чужая заметка на месте цели (``target_untracked``)."""
    cur_text, cur_sha = read_current(vault, rel)
    row = store.note_row(rel)
    if row is None:
        if cur_sha is not None:
            raise PlanError("target_untracked",
                            f"по пути {rel} уже лежит заметка, которую ledger не вел: поверх нее "
                            "не пишем")
        return None, None
    if cur_sha is None:
        raise PlanError("target_missing", f"заметка {rel} удалена вручную: нужен новый diff")
    if cur_sha != row["note_sha"]:
        raise PlanError("target_changed",
                        f"заметка {rel} изменена вручную после последнего применения: нужен новый "
                        "diff и новое решение")
    return cur_text, cur_sha


def build_plan(
    store: SleepStore, vault: Path, p: Proposal, accepted: list[Claim], *, decided_at: str,
    superseded_ids: list[str] | None = None, ignore_cas: bool = False,
) -> NotePlan:
    """План заметки предложения: утверждения ``accepted`` (с решением владельца) встают в блоки,
    заменяемые утверждения помечаются. Исключения - :class:`PlanError`; ``ignore_cas`` - построить
    текст поверх того, что лежит на диске сейчас (для diff устаревшего предложения)."""
    rel, note_id = note_key(p, store)
    if ignore_cas:
        cur_text, cur_sha = read_current(vault, rel)
    else:
        cur_text, cur_sha = check_target(store, vault, rel)
    fm_old, body = _split(cur_text)
    existing = parse_blocks(body)
    order = [cid for cid, _rev, _text in existing]
    old_claims = store.accepted_claims(set(superseded_ids or []))
    for cid in superseded_ids or []:
        old = old_claims.get(cid)
        if old is not None and cid in order:
            new_ids = ", ".join(c.claim_id for c in accepted)
            body = _put_block(body, cid, render_block(
                old, proposal_id=p.proposal_id, decided_at=decided_at,
                status_note=f"заменено утверждением {new_ids} (предложение {p.proposal_id})"))
    for c in accepted:
        body = _put_block(body, c.claim_id,
                          render_block(c, proposal_id=p.proposal_id, decided_at=decided_at))
    order = [cid for cid, _rev, _text in parse_blocks(body)]
    created = cur_text is None
    all_claims = list(accepted)
    seen = {c.claim_id for c in accepted}
    stored = store.accepted_claims({cid for cid in order if cid not in seen})
    all_claims += [stored[cid] for cid in order if cid in stored]
    created_day = str(fm_old.get("created") or decided_at[:10])
    new_text = _front(fm_old, note_id, _title(accepted or all_claims, p), created_day,
                      decided_at[:10], all_claims, order) + body
    return NotePlan(rel=rel, note_id=note_id, created=created, prev_text=cur_text, prev_sha=cur_sha,
                    new_text=new_text, new_sha=sha_text(new_text), claim_ids=order,
                    superseded=list(superseded_ids or []))
