"""SLEEP-STORE-1 п.7 - общие операции ядра для CLI и MCP: status / propose / apply_recover.

Сценарий 20 (sleep-1.md §12): CLI, MCP и пульт дают ОДИНАКОВЫЕ проверки, решения, effects и
ограничения прав - потому что поверхности только собирают :class:`core.sleep_store.ctx.Ctx` и зовут
эти функции; своей логики у ``cli/dt_sleep.py`` и фасада ``sleep`` в ``mcp-server`` нет.

Права: ``propose`` пишет КАНДИДАТОВ (знания не меняются), ``apply_recover`` лишь доводит уже
принятое владельцем (решения не принимает), ``status`` читает. Решить карточку может только
владелец через общий реестр (``pult_card_decide``) - этой поверхности для решений здесь нет.
Недоступное хранилище - отказ ``store_unavailable``, не пустой успех.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from core.contract import CODE_STORE_UNAVAILABLE
from core.sleep_store.ctx import Ctx
from core.sleep_store.store import SleepStore, now_iso

__all__ = ["OPS", "apply_recover", "make_ctx", "propose", "screen_runs", "screen_summary",
           "status"]

OPS = ("status", "propose", "apply_recover", "plan", "context", "experience", "profile",
       "summary", "runs", "synth_start", "synth_read", "synth_submit", "synth_review",
       "synth_publish", "synth_cancel", "synth_resume", "synth_report", "synth_gate")
# SLEEP-INPUT-1: plan/context/experience - core.sleep_input.ops (те же Ctx и конверты); запись -
# propose, apply_recover, experience и plan с apply (фасад MCP требует write-токен только для них)


def make_ctx(*, vault: Path | None = None, db_path: Path | None = None,
             now: str | None = None) -> Ctx:
    """Контекст боевых путей (``DT_VAULT_PATH``/``DT_DERIVED_ROOT``) и хоста процесса."""
    from core.config import default_vault_path
    from core.host import current_host

    return Ctx(vault=Path(vault) if vault else default_vault_path(), db_path=db_path,
               now=now_iso(now) if now else "", host=str(current_host().get("name") or "cli"))


def _unavailable(exc: BaseException) -> dict[str, Any]:
    return {"ok": False, "refused": True, "code": CODE_STORE_UNAVAILABLE,
            "error": f"{CODE_STORE_UNAVAILABLE}: ledger Сна недоступен ({type(exc).__name__}): "
                     "это не «пусто», а ошибка"}


def status(ctx: Ctx, run_id: str | None = None) -> dict[str, Any]:
    """Сводка ledger: счетчики, очередь вида ``memory`` (бюджет, запас), что требует внимания
    (конфликт применения, недоведенное, индексация, источники для проверки); ``run_id`` - прогон."""
    try:
        store = SleepStore.open_existing(ctx.db_path)
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
    from core.decisions import flow

    budget = flow.budgets().get("memory")
    reserve = flow.reserve_counts().get("memory", 0)
    from core.sleep_input import ops as input_ops
    from core.sleep_input.store import InputStore

    if store is None:
        return {"ok": True, "present": False, "summary": {}, "attention": {},
                "queue": {"pending": 0, "budget": budget, "in_reserve": reserve},
                "inputs": input_ops.summary(None),
                "hint": "ledger Сна еще не заводили: кандидатов нет"}
    try:
        summary = store.summary()
        pending = len(store.pending_rows(ctx.stamp()))
        unfinished = [r["proposal_id"] for r in store.apply_rows(
            ("prepared", "applying", "recovering", "failed"))]
        conflicts = [r["proposal_id"] for r in store.apply_rows(("conflict",))]
        out: dict[str, Any] = {
            "ok": True, "present": True, "summary": summary,
            "queue": {"pending": pending, "budget": budget, "in_reserve": reserve},
            "attention": {"conflict": conflicts, "unfinished": unfinished,
                          "index_pending": summary["index_pending"],
                          "needs_check": summary["needs_check"]},
            "inputs": input_ops.summary(InputStore(store.conn, readonly=True)),
        }
        if run_id:
            run = store.run_row(run_id)
            if run is None:
                out.update(run=None, run_hint=f"прогон {run_id!r} не найден")
            else:
                counts = store.conn.execute(
                    "SELECT review_state, COUNT(*) FROM sleep_proposals WHERE run_id=? "
                    "GROUP BY review_state", (run_id,)).fetchall()
                items = store.conn.execute(  # БД открыта общим менеджером: таблицы v6 есть
                    "SELECT status, COUNT(*) FROM sleep_worklist WHERE run_id=? GROUP BY status",
                    (run_id,)).fetchall()
                out["run"] = {**run, "proposals": {r[0]: r[1] for r in counts},
                              "worklist": {r[0]: r[1] for r in items}}
        return out
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
    finally:
        store.close()


def screen_summary(ctx: Ctx, limit: int | None = None) -> dict[str, Any]:
    """SLEEP-PULT-1: сводка для «Результатов» и «Предложений» (чтение, ``mode=ro``)."""
    from core.sleep_store import screens

    return screens.summary(ctx, reviewed_limit=int(limit or 30))


def screen_runs(ctx: Ctx, run_id: str | None = None, limit: int | None = None) -> dict[str, Any]:
    """SLEEP-PULT-1: журнал прогонов или один прогон с worklist и квитанциями чтения (чтение)."""
    from core.sleep_store import screens

    return screens.runs(ctx, run_id or None, limit=int(limit or 20))


def propose(ctx: Ctx, payload: dict[str, Any] | list[Any], *, dry_run: bool = False,
            run_id: str | None = None, idempotency_key: str | None = None) -> dict[str, Any]:
    """``propose_memory`` по содержимому файла/запроса: ``{run_id, idempotency_key, candidates}``
    либо просто список кандидатов (тогда ``run_id`` и ключ - из параметров)."""
    from core.sleep_store.propose import propose_memory

    if isinstance(payload, list):
        candidates, rid, key = payload, run_id, idempotency_key
    elif isinstance(payload, dict):
        candidates = payload.get("candidates") or []
        rid = run_id or payload.get("run_id")
        key = idempotency_key or payload.get("idempotency_key")
    else:
        return {"ok": False, "refused": True, "code": "schema_invalid",
                "error": "schema_invalid: ожидается объект {run_id, idempotency_key, candidates}"}
    return propose_memory(
        str(rid or ""), candidates, str(key or ""), db_path=ctx.db_path, vault_path=ctx.vault,
        now=ctx.now or None, dry_run=dry_run, source_hash=ctx.source_hash,
        entity_exists=ctx.entity_exists)


def apply_recover(ctx: Ctx, proposal_id: str | None = None) -> dict[str, Any]:
    """Довести незавершенные применения (prepared / applying / recovering / failed, недоделанная
    индексация). Идемпотентно; решения не принимает. ``conflict`` остается на владельце."""
    from core.sleep_store import applier

    try:
        return applier.recover(ctx, proposal_id=proposal_id)
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
