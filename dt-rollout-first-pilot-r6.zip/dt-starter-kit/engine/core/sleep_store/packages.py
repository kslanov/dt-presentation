"""SLEEP-STORE-1 - временные пакеты прогона ``.derived/sleep/<run_id>/`` (sleep-1.md §6.1).

Пакет - одноразовое рабочее место прогона (досье порции, промежуточные кандидаты, квитанции):
выбрасывается, в недельный бэкап НЕ входит, ссылка на него лежит в ``sleep_runs.package_ref``.
**Очистка не трогает историю**: удаляются только каталоги пакетов, строки ``dt.db`` (прогоны,
утверждения, решения, журнал применения) остаются, а ссылка из БД переживает отсутствие пакета.
Путь строится только от проверенного ``run_id`` (``../`` и разделители невозможны).
"""

from __future__ import annotations

import shutil
import time
from pathlib import Path

from core.sleep_store.store import RUN_ID_RE, LedgerError

__all__ = ["package_dir", "package_exists", "purge_packages"]


def _root() -> Path:
    from core.config import sleep_dir_path

    return sleep_dir_path()


def package_dir(run_id: str, *, create: bool = False) -> Path:
    """Каталог пакета прогона; ``create`` создает его. Плохой ``run_id`` - ``LedgerError``."""
    if not RUN_ID_RE.match(run_id or ""):
        raise LedgerError("bad_run_id", f"run_id {str(run_id)[:40]!r} не годится для пути")
    path = _root() / run_id
    if create:
        path.mkdir(parents=True, exist_ok=True)
    return path


def package_exists(run_id: str) -> bool:
    return package_dir(run_id).is_dir()


def purge_packages(*, older_than_days: float, keep: set[str] | None = None,
                   dry_run: bool = False) -> list[str]:
    """Удалить каталоги пакетов старше ``older_than_days`` (кроме ``keep``); вернуть их ``run_id``.
    Только каталоги непосредственно под ``.derived/sleep/``; симлинки и файлы не трогаются."""
    root = _root()
    if not root.is_dir():
        return []
    cutoff = time.time() - older_than_days * 86400.0
    gone: list[str] = []
    for child in sorted(root.iterdir()):
        if child.is_symlink() or not child.is_dir() or (keep and child.name in keep):
            continue
        if not RUN_ID_RE.match(child.name) or child.stat().st_mtime > cutoff:
            continue
        gone.append(child.name)
        if not dry_run:
            shutil.rmtree(child, ignore_errors=True)
    return gone
