"""SLEEP-STORE-1 п.2 - ``propose_memory``: запись кандидатов только через валидатор (sleep-1.md §9).

``propose_memory(run_id, candidates, idempotency_key)`` -> проверки, ``proposal_ids``, ``blockers``.
Кандидат - предложение §5.3 (:class:`core.sleep.contract.Proposal` или его словарь). Каждый проходит
БЛОКИРУЮЩИЙ валидатор SLEEP-CONTRACT-1 против снимка ledger; отказавший не записывается (машинные
коды в ответе), прошедший ложится в ledger КАНДИДАТОМ (``layer='candidate'``) - в знания, facts и
обычную выдачу он не попадает до решения владельца.

**Идемпотентность.** Результат вызова хранится по ``(run_id, idempotency_key)``: повтор с тем же
содержимым возвращает ТОТ ЖЕ результат (``replayed: true``), тот же ключ с другим содержимым -
отказ ``idempotency_conflict``. На уровне предложения: тот же ``proposal_id`` и то же содержимое -
``duplicate`` (ничего не пишется); ``revision + 1`` - новая ревизия (старое согласие не
переносится); иное - отказ. Отказ владельца не воскресает: повтор с тем же ``evidence_digest`` -
``rejected_repeat`` (валидатор), новое основание без связанной ревизии - ``new_basis_unexplained``.

**Что не принимается от сна:** состояния решения (принято/отклонено/отложено) и квитанции - только
владелец (``decision_by_non_owner``); применение (``apply_without_acceptance``); операции, которые
этот пакет применить не умеет (``operation_not_supported``: вики/контекст/слияние - другие пакеты).
``dry_run`` - те же проверки без единой записи (ни прогона, ни кандидата, ни батча).

``core`` ⊥ cli/mcp; ни сети, ни модели.
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from collections.abc import Callable, Iterable
from dataclasses import replace
from pathlib import Path
from typing import Any

from core.contract import CODE_STORE_UNAVAILABLE
from core.sleep.compare import CompareResult, classify
from core.sleep.contract import (
    Actor,
    ApplyState,
    ContractError,
    Operation,
    Proposal,
    ReviewState,
    proposal_from_dict,
)
from core.sleep.issue_key import issue_key_of_proposal
from core.sleep.validate import (
    CODE_APPLY_WITHOUT_ACCEPTANCE,
    CODE_DECISION_BY_NON_OWNER,
    CODE_IDEMPOTENCY_CONFLICT,
    CODE_TRANSITION_FORBIDDEN,
    Ledger,
    Policy,
    Violation,
    check_transition,
    validate_proposal,
)
from core.sleep_store.store import (
    RUN_ID_RE,
    LedgerError,
    SleepStore,
    content_digest,
    now_iso,
)

__all__ = [
    "CODE_OPERATION_NOT_SUPPORTED",
    "SUPPORTED_OPERATIONS",
    "default_entity_exists",
    "propose_memory",
    "request_digest",
]

CODE_OPERATION_NOT_SUPPORTED = "operation_not_supported"
CODE_RUN_ID_INVALID = "run_id_invalid"
CODE_SCHEMA_INVALID = "schema_invalid"
# Что умеет применить SLEEP-STORE-1 (одна заметка на атомарное предложение, либо запись связи в
# ledger). Вики/контекст/слияние представлений - SLEEP-WIKI-1/CONTEXT-1: их кандидат не принимается,
# а не повисает карточкой, которую нельзя применить.
SUPPORTED_OPERATIONS = (Operation.ADD, Operation.AMEND, Operation.SUPERSEDE, Operation.RELATE)
_SUBMITTABLE = (ReviewState.DRAFT, ReviewState.READY, ReviewState.PENDING)
_REVISABLE = ("draft", "ready", "pending", "snoozed", "stale")


def default_entity_exists(vault_path: Path | None) -> Callable[[str], bool]:
    """``entity:<id>`` существует, если id резолвится в заметку vault (хаб)."""
    def exists(ref: str) -> bool:
        if vault_path is None:
            return False
        from core.vault import resolve_note_path

        try:
            return resolve_note_path(ref.removeprefix("entity:"), vault_path=vault_path) is not None
        except Exception:  # noqa: BLE001 - не смогли проверить: сущности нет
            return False

    return exists


def request_digest(candidates: Iterable[Proposal]) -> str:
    """Отпечаток запроса (идемпотентность батча): содержимое кандидатов, не порядок их ключей."""
    parts = sorted(content_digest(p) + "|" + p.proposal_id + "|" + str(p.revision)
                   for p in candidates)
    return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()


def _refusal(code: str, error: str, **extra: Any) -> dict[str, Any]:
    return {"ok": False, "refused": True, "code": code, "error": f"{code}: {error}", **extra}


def _parse(raw: Any, index: int) -> tuple[Proposal | None, dict[str, Any] | None]:
    if isinstance(raw, Proposal):
        return raw, None
    try:
        return proposal_from_dict(raw), None
    except ContractError as exc:
        v = Violation(exc.code, f"candidates[{index}]" + (f".{exc.path}" if exc.path else ""),
                      exc.reason)
        return None, {"index": index, "proposal_id": "", "status": "refused", "ok": False,
                      "violations": [v.to_dict()], "warnings": [], "blockers": [
                          {"code": v.code, "detail": v.reason}]}


def _owner_only_violations(p: Proposal) -> list[Violation]:
    """Сон предлагает, но не решает и не применяет: состояния и квитанции - только владелец."""
    out: list[Violation] = []
    if p.review_state not in _SUBMITTABLE:
        verdict = check_transition(ReviewState.PENDING, p.review_state, actor=Actor.SLEEP)
        for v in verdict.violations:
            out.append(Violation(v.code, "review_state", v.reason, v.detail))
        if not out:
            out.append(Violation(CODE_TRANSITION_FORBIDDEN, "review_state",
                                 f"кандидат приходит в состоянии draft/ready/pending, не "
                                 f"{p.review_state.value}"))
    if p.decision_receipt is not None:
        out.append(Violation(CODE_DECISION_BY_NON_OWNER, "decision_receipt",
                             "квитанцию решения выдает владелец: кандидат приходит без нее"))
    if p.apply_state is not ApplyState.NONE or p.effects:
        out.append(Violation(CODE_APPLY_WITHOUT_ACCEPTANCE, "apply_state",
                             "применение и effects появляются только после решения владельца"))
    for c in p.after.claims:   # «было» вправе быть принятым; «стало» принимает только владелец
        if c.review_state in (ReviewState.ACCEPTED, ReviewState.REJECTED, ReviewState.SNOOZED):
            out.append(Violation(CODE_DECISION_BY_NON_OWNER, f"after.{c.claim_id}.review_state",
                                 f"утверждение {c.claim_id} уже в состоянии "
                                 f"{c.review_state.value}: так его помечает только владелец"))
            break
    return out


def _normalize(p: Proposal, run_id: str, now: str) -> Proposal:
    """Единое состояние при записи: ``pending`` (карточка) либо ``draft`` (не идет владельцу);
    утверждения «стало» получают то же состояние рассмотрения."""
    state = ReviewState.DRAFT if p.review_state is ReviewState.DRAFT else ReviewState.PENDING
    after = replace(p.after, claims=tuple(replace(c, review_state=state) for c in p.after.claims))
    return replace(p, run_id=p.run_id or run_id, review_state=state, after=after,
                   created_at=p.created_at or now)


def _compare(p: Proposal, ledger: Ledger) -> tuple[dict[str, Any] | None, str]:
    """Классификация §5.4 каждого утверждения «стало» против принятого + ключ проблемы."""
    rows: list[dict[str, Any]] = []
    conflict_with = None
    pool = list(ledger.claims.values())
    for c in p.after.claims:
        cmp = classify(c, pool)
        rows.append(cmp.to_dict())
        if cmp.result is CompareResult.CONTRADICTION and conflict_with is None and cmp.matched:
            conflict_with = ledger.claims.get(cmp.matched[0])
    try:
        key = issue_key_of_proposal(p, conflict_with=conflict_with)
    except ValueError:
        key = ""
    return ({"results": rows} if rows else None), key


def _candidate_result(
    index: int, p: Proposal, status: str, *, violations: Iterable[Violation] = (),
    warnings: Iterable[dict[str, Any]] = (), issue_key: str = "",
    compare: dict[str, Any] | None = None, existing: str = "",
) -> dict[str, Any]:
    viol = [v.to_dict() for v in violations]
    blockers = [b.to_dict() for b in p.blockers]
    if status == "refused":
        blockers += [{"code": v["code"], "detail": v.get("reason", "")} for v in viol]
    out: dict[str, Any] = {
        "index": index, "proposal_id": existing or p.proposal_id, "status": status,
        "ok": status != "refused", "review_state": p.review_state.value, "revision": p.revision,
        "operation": p.operation.value, "violations": viol, "warnings": list(warnings),
        "blockers": blockers,
    }
    if issue_key:
        out["issue_key"] = issue_key
    if compare:
        out["compare"] = compare
    return out


def _one(
    store: SleepStore | None, index: int, raw: Proposal, run_id: str, *, now: str, dry_run: bool,
    policy: Policy, source_hash: Callable[[str], str | None] | None,
    entity_exists: Callable[[str], bool] | None,
) -> dict[str, Any]:
    p0 = raw
    if p0.run_id and p0.run_id != run_id:
        v = Violation(CODE_SCHEMA_INVALID, "run_id",
                      f"run_id предложения ({p0.run_id}) не совпадает с прогоном ({run_id})")
        return _candidate_result(index, p0, "refused", violations=[v])
    pre = _owner_only_violations(p0)
    if p0.operation not in SUPPORTED_OPERATIONS:
        pre.append(Violation(
            CODE_OPERATION_NOT_SUPPORTED, "operation",
            f"операцию {p0.operation.value} пока применять нечем: слияние представлений, "
            "исправление ссылок и контекст - пакеты SLEEP-WIKI-1/SLEEP-CONTEXT-1"))
    if pre:
        return _candidate_result(index, p0, "refused", violations=pre)
    p = _normalize(p0, run_id, now)
    from core.sleep_synth.verify import binding_error

    bound_error = binding_error(store.conn, p) if store is not None else ""
    if bound_error:
        return _candidate_result(index, p, "refused", violations=[
            Violation(bound_error, "run_id", "Нет проверенного пакета сквозного синтеза")])
    digest = content_digest(p)

    existing = store.proposal_row(p.proposal_id) if store else None
    revising = False
    if existing is not None:
        same = int(existing["revision"]) == p.revision and existing["content_digest"] == digest
        if same:
            return _candidate_result(index, p, "duplicate", existing=existing["proposal_id"],
                                     issue_key=existing["issue_key"] or "")
        revising = (p.revision == int(existing["revision"]) + 1
                    and existing["review_state"] in _REVISABLE)
        if not revising:
            v = Violation(CODE_IDEMPOTENCY_CONFLICT, "proposal_id",
                          "proposal_id уже занят другим содержимым или состоянием: правка - "
                          "ревизия +1 до решения, новая попытка после отказа - новое предложение "
                          "со связью reopens")
            return _candidate_result(index, p, "refused", violations=[v])
    elif store is not None:
        twin = store.find_by_key(run_id, p.idempotency_key)
        if twin is not None:
            if twin["content_digest"] == digest and int(twin["revision"]) == p.revision:
                return _candidate_result(index, p, "duplicate", existing=twin["proposal_id"],
                                         issue_key=twin["issue_key"] or "")
            v = Violation(CODE_IDEMPOTENCY_CONFLICT, "idempotency_key",
                          "тот же idempotency_key с другим содержимым")
            return _candidate_result(index, p, "refused", violations=[v])

    ledger = (store.ledger_snapshot(p, now=now, source_hash=source_hash,
                                    entity_exists=entity_exists)
              if store else Ledger(now=now))
    verdict = validate_proposal(p, ledger, policy)
    warns = list(verdict.warnings)
    if verdict.violations:
        return _candidate_result(index, p, "refused", violations=verdict.violations,
                                 warnings=warns)
    if any(w.get("code") == "idempotent_noop" for w in warns):
        return _candidate_result(index, p, "noop", warnings=warns)
    compare, issue_key = _compare(p, ledger)
    status = "revised" if revising else "created"
    if not dry_run and store is not None:
        with store.tx(immediate=True):
            store.ensure_run(run_id, now)
            if revising:
                store.revise_proposal(p, digest=digest, issue_key=issue_key, compare=compare,
                                      review_state=p.review_state, now=now)
            else:
                store.insert_proposal(p, digest=digest, issue_key=issue_key, compare=compare,
                                      review_state=p.review_state, now=now)
    return _candidate_result(index, p, status, warnings=warns, issue_key=issue_key,
                             compare=compare)


def propose_memory(
    run_id: str,
    candidates: list[Any],
    idempotency_key: str,
    *,
    db_path: Path | None = None,
    vault_path: Path | None = None,
    now: str | None = None,
    dry_run: bool = False,
    policy: Policy | None = None,
    source_hash: Callable[[str], str | None] | None = None,
    entity_exists: Callable[[str], bool] | None = None,
) -> dict[str, Any]:
    """Записать кандидатов в ledger через валидатор; вернуть проверки, ``proposal_ids``, блокеры.

    ``{ok, run_id, idempotency_key, dry_run, replayed, results: [{index, proposal_id, status:
    created|revised|duplicate|noop|refused, ok, review_state, violations, warnings, blockers,
    issue_key?, compare?}], proposal_ids, blockers, warnings, summary}``. ``ok=false`` - хотя бы
    один кандидат отказан (форма отказа ядра: ``refused``/``code``/``error`` первого нарушения);
    остальные кандидаты при этом записаны. Недоступное хранилище - ``store_unavailable`` (не
    пустой успех). В знания, facts и обычную выдачу кандидат не попадает."""
    stamp = now_iso(now)
    if not RUN_ID_RE.match(str(run_id or "")):
        return _refusal(CODE_RUN_ID_INVALID, "run_id: буквы, цифры и ._- (до 64 знаков)",
                        run_id=str(run_id)[:64])
    if not str(idempotency_key or "").strip():
        return _refusal(CODE_SCHEMA_INVALID, "idempotency_key пуст", run_id=run_id)
    if not isinstance(candidates, list) or not candidates:
        return _refusal(CODE_SCHEMA_INVALID, "candidates: непустой список предложений",
                        run_id=run_id)
    parsed: list[tuple[int, Proposal | None, dict[str, Any] | None]] = []
    for i, raw in enumerate(candidates):
        p, bad = _parse(raw, i)
        parsed.append((i, p, bad))
    good = [p for _, p, _ in parsed if p is not None]
    digest = request_digest(good)
    entity_exists = entity_exists or default_entity_exists(vault_path)
    policy = policy or Policy()

    store: SleepStore | None
    try:
        store = SleepStore.open_existing(db_path) if dry_run else SleepStore.open(db_path)
    except (sqlite3.Error, OSError) as exc:
        return _refusal(CODE_STORE_UNAVAILABLE, f"ledger не открылся ({type(exc).__name__})",
                        run_id=run_id, idempotency_key=idempotency_key)
    try:
        if store is not None and not dry_run:
            prior = store.batch(run_id, idempotency_key)
            if prior is not None:
                if prior["request_digest"] != digest:
                    return _refusal(CODE_IDEMPOTENCY_CONFLICT,
                                    "тот же idempotency_key с другим содержимым",
                                    run_id=run_id, idempotency_key=idempotency_key)
                replay = json.loads(prior["result_json"])
                replay["replayed"] = True
                return replay
        results: list[dict[str, Any]] = []
        for i, p, bad in parsed:
            if bad is not None or p is None:
                results.append(bad or {})
                continue
            try:
                results.append(_one(store, i, p, run_id, now=stamp, dry_run=dry_run,
                                    policy=policy, source_hash=source_hash,
                                    entity_exists=entity_exists))
            except (sqlite3.Error, OSError, LedgerError) as exc:
                return _refusal(CODE_STORE_UNAVAILABLE,
                                f"ledger недоступен при записи ({type(exc).__name__})",
                                run_id=run_id, idempotency_key=idempotency_key,
                                results=results)
        out = _envelope(run_id, idempotency_key, dry_run, results)
        if store is not None and not dry_run:
            with store.tx(immediate=True):
                store.save_batch(run_id, idempotency_key, digest, out, stamp)
        return out
    finally:
        if store is not None:
            store.close()


def _envelope(run_id: str, key: str, dry_run: bool, results: list[dict[str, Any]]
              ) -> dict[str, Any]:
    summary: dict[str, int] = {}
    for r in results:
        summary[r["status"]] = summary.get(r["status"], 0) + 1
    refused = [r for r in results if r["status"] == "refused"]
    out: dict[str, Any] = {
        "ok": not refused, "run_id": run_id, "idempotency_key": key, "dry_run": dry_run,
        "replayed": False, "results": results,
        "proposal_ids": [r["proposal_id"] for r in results
                         if r["status"] in ("created", "revised", "duplicate")],
        "blockers": [dict(b, proposal_id=r["proposal_id"]) for r in results
                     for b in r["blockers"]],
        "warnings": [w for r in results for w in r["warnings"]],
        "summary": summary,
    }
    if refused:
        first = refused[0]["violations"][0]
        out.update(refused=first["code"], code=first["code"],
                   error=f"{first['code']}: {first.get('reason', '')}".rstrip(": "))
    return out
