"""Select accepted Sleep knowledge for a separate, read-only search field."""

import re
import sqlite3
from dataclasses import dataclass
from datetime import date
from functools import cache
from pathlib import Path

import yaml

from core.retrieval.notemeta import is_sleep_pilot_output
from core.sleep.contract import Claim, Evidence, EvidenceRole, LinkType, ReviewState
from core.sleep.validate import contains_secret
from core.sleep_input.dossier import MAX_READ_BYTES, _safe_note, _split_frontmatter
from core.sleep_input.privacy import classify_note, classify_path_only
from core.sleep_input.store import InputStore
from core.sleep_store.evidence_view import preview
from core.sleep_store.store import SleepStore
from core.text.stem import fold_stem

_LIMIT = 3
_LINK_LABELS = {
    LinkType.SUPERSEDES: "заменяет",
    LinkType.DEPENDS_ON: "зависит от",
    LinkType.CONTRADICTS: "противоречит",
    LinkType.DUPLICATE_OF: "дублирует",
    LinkType.DERIVED_FROM: "выведено из",
    LinkType.PART_OF: "входит в состав",
    LinkType.BELONGS_TO: "относится к",
    LinkType.CAUSES: "вызывает",
    LinkType.ALIAS_OF: "имеет другое название",
}


def _words(text: str) -> list[str]:
    return re.findall(r"[^\W_]+", fold_stem(text))


def _topic_matches(query: list[str], topic: str) -> bool:
    words = _words(topic)
    width = len(words)
    return width >= 2 and any(query[index:index + width] == words
                              for index in range(len(query) - width + 1))


def _known(claim: Claim) -> str:
    return max([claim.recorded_at, *(d.at for d in claim.decisions)])


@dataclass(frozen=True)
class _Hit:
    rank: tuple[int, int, str, str]
    row: dict
    evidence: tuple[Evidence, ...]
    endpoints: tuple[str, ...] = ()


def _entity(ref: str, vault: Path) -> dict | None:
    from core.vault import resolve_note_path

    entity_id = ref.removeprefix("entity:")
    if not classify_path_only(entity_id).ok:
        return None
    path = resolve_note_path(entity_id, vault_path=vault)
    if path is None or not path.is_relative_to(vault.resolve()):
        return None
    rel = path.relative_to(vault.resolve()).as_posix()
    if not classify_path_only(rel).ok:
        return None
    raw, refusal = _safe_note(vault, rel)
    if refusal or raw is None or len(raw) > MAX_READ_BYTES:
        return None
    text = raw.decode("utf-8", errors="replace")
    try:
        metadata, _ = _split_frontmatter(text)
    except (ValueError, TypeError, yaml.YAMLError):
        return None
    title = str(metadata.get("title") or entity_id)[:240]
    if is_sleep_pilot_output(rel, title) or not classify_note(rel, metadata, text, vault=vault).ok:
        return None
    return {"ref": ref, "title": title, "type": "entity", "path": rel}


def _select(store: SleepStore, inputs: InputStore, terms: list[str], vault: Path,
            as_of: date | None) -> list[dict]:
    today = (as_of or date.today()).isoformat()
    claims = {
        key: c for key, c in store.memory_claims(today if as_of else "").items()
        if c.review_state is ReviewState.ACCEPTED and _known(c)[:10] <= today
        and (not c.valid_from or c.valid_from[:10] <= today)
        and (not c.valid_to or c.valid_to[:10] > today)
    }

    @cache
    def source(item: Evidence) -> dict | None:
        view = preview(vault, inputs, item)
        if (view["preview_status"] != "ready"
                or is_sleep_pilot_output(view["path"], view["title"])):
            return None
        return {key: view[key] for key in ("path", "title", "date")} | {"locator": item.locator}

    def sources(evidence: tuple[Evidence, ...]) -> list[dict]:
        result = []
        for item in evidence:
            if item.role is EvidenceRole.SUPPORT:
                view = source(item)
                if view is None:
                    return []
                result.append(view)
        return result

    @cache
    def endpoint(ref: str) -> dict | None:
        if not ref.startswith("claim:"):
            return _entity(ref, vault) if ref.startswith("entity:") else None
        claim = claims.get(ref.removeprefix("claim:"))
        if claim is None:
            return None
        return {"ref": ref, "title": f"{claim.subject}: {claim.predicate}",
                "type": claim.type.value, "revision": claim.revision}

    query_words = set(terms)
    hits: list[_Hit] = []
    for claim in claims.values():
        if not any(_topic_matches(terms, t) for t in (claim.area, claim.subject)):
            continue
        overlap = len((query_words - set(_words(claim.area))) & set(_words(
            f"{claim.subject} {claim.predicate} {claim.statement}"
        )))
        row = {"title": f"{claim.subject}: {claim.predicate}", "statement": claim.statement,
               "conditions": list(claim.conditions), "unknown": list(claim.unknown),
               "claim_id": claim.claim_id, "type": claim.type.value,
               "origin": "sleep",
               "revision": claim.revision, "as_of": today, "valid_from": claim.valid_from,
               "valid_to": claim.valid_to,
               "use": "гипотеза для проверки, не доказательство" if claim.type.value == "hypothesis"
               else "сверить с первоисточниками"}
        if not contains_secret(str(row)):
            hits.append(_Hit((1, overlap, claim.recorded_at, claim.claim_id), row, claim.evidence))

    for proposal, receipt in store.accepted_link_proposals():
        decided_at = receipt.at
        if not decided_at or decided_at[:10] > today:
            continue
        expected = {item.ref: item.revision for item in proposal.expected_revisions}
        for link in proposal.after.links:
            if link.type not in _LINK_LABELS:
                continue
            ends = (link.source, link.target)
            matched = 0
            topics = []
            for ref in ends:
                if ref.startswith("claim:"):
                    claim = claims.get(ref.removeprefix("claim:"))
                    if claim is None or _known(claim) > decided_at or (
                        ref in expected and claim.revision != expected[ref]
                    ):
                        break
                    labels = (claim.area, claim.subject)
                else:
                    entity = endpoint(ref)
                    if entity is None:
                        break
                    labels = (entity["title"],)
                topics.extend(labels)
                matched += any(_topic_matches(terms, t) for t in labels)
            else:
                if not matched:
                    continue
                left, right = (endpoint(ref) for ref in ends)
                if left is None or right is None:
                    continue
                title = f'{left["title"]} {_LINK_LABELS[link.type]} {right["title"]}'
                hypotheses = "hypothesis" in (left["type"], right["type"])
                row = {"title": title, "statement": title, "type": "relation",
                       "link_id": link.link_id, "relation_type": link.type.value,
                       "source": left, "target": right, "origin": "sleep",
                       "revision": proposal.revision, "as_of": today, "accepted_at": decided_at,
                       "use": "связь с гипотезой, требует проверки"
                       if hypotheses else "сверить с первоисточниками"}
                if not contains_secret(str(row)):
                    overlap = len(query_words & set(_words(" ".join([title, *topics]))))
                    claim_ids = tuple(ref.removeprefix("claim:") for ref in ends
                                      if ref.startswith("claim:"))
                    hits.append(_Hit((matched, overlap, decided_at, link.link_id),
                                     row, link.evidence, claim_ids))

    selected = []
    seen = set()
    for hit in sorted(hits, key=lambda item: item.rank, reverse=True):
        row = hit.row
        key = ((row["relation_type"], row["source"]["ref"], row["target"]["ref"])
               if "link_id" in row else row["claim_id"])
        if key in seen:
            continue
        origin = sources(hit.evidence)
        if not origin or any(not sources(claims[cid].evidence) for cid in hit.endpoints):
            continue
        row["sources"] = origin
        if "claim_id" in row:
            row["path"] = store.note_of_claim(row["claim_id"])
        selected.append(row)
        seen.add(key)
        if len(selected) == _LIMIT:
            break
    return selected


def select(
    query: str, vault: Path, *, db_path: Path | None = None, as_of: date | None = None,
) -> list[dict]:
    terms = _words(query[:2000])
    if len(terms) < 2:
        return []
    inputs = InputStore.open_readonly(db_path)
    if inputs is None:
        return []
    try:
        store = SleepStore(inputs.conn)
        if not inputs.has_table("sleep_claims"):
            return []
        with store.tx():
            return _select(store, inputs, terms, vault, as_of)
    finally:
        inputs.close()


def attach(
    output: dict, query: str, *, vault: Path | None = None, as_of: date | None = None,
) -> None:
    from core.config import default_vault_path
    from core.contract import add_warning

    try:
        output["accepted_memory"] = select(query, vault or default_vault_path(), as_of=as_of)
    except (OSError, sqlite3.Error, ValueError) as exc:
        output["accepted_memory"] = []
        add_warning(output, "store_unavailable", "Принятая память недоступна",
                    component="accepted_memory", detail=type(exc).__name__)
