"""SLEEP-STORE-1 - физическая модель ledger Сна в общей ``dt.db`` (sleep-1.md §6.1).

Миграция v5 общего менеджера (:mod:`core.db.migrations`): своей БД и своего менеджера миграций нет.
Этот модуль - только DDL (никаких импортов ``core.db``: миграция зовет его лениво).

**Что где лежит**

=========================  ==============================================================
``sleep_runs``             прогоны (состояние, ссылка на пакет ``.derived/sleep/<run_id>/``)
``sleep_claims``           утверждения и ревизии; поле ``layer`` отделяет КАНДИДАТОВ от принятого
``sleep_accepted_claims``  VIEW ``layer='accepted'`` - единственная точка чтения принятого
``sleep_evidence``         основания (источник, ревизия, хеш, locator, отпечаток; БЕЗ текста)
``sleep_proposals``        предложения (текущая ревизия), ``sleep_proposal_revisions`` - история
``sleep_batches``          результат ``propose_memory`` по ``(run_id, idempotency_key)``
``sleep_decisions``        журнал решений владельца (квитанции)
``sleep_deps``             зависимости: supersedes / depends_on / contradicts / ... и связи
``sleep_notes``            какие заметки vault ведет ledger (sha для CAS), ``sleep_note_claims``
``sleep_apply``            применение: намерение, ожидаемые версии, состояние, квитанция файла
``sleep_apply_log``        журнал шагов применения (append-only)
``sleep_locks``            короткая блокировка целевого набора (lease с TTL)
=========================  ==============================================================

**Кандидаты отделены от принятого** в SQL: ``layer`` ``candidate | accepted | superseded |
rejected``; потребитель принятого читает VIEW ``sleep_accepted_claims``, а не таблицу. Частичный
уникальный индекс гарантирует: у ``(claim_id, revision)`` не больше одной принятой строки.

**Тексты оригиналов в SQL не копируются.** Фрагмент основания (``Evidence.fragment``) в хранилище не
попадает - только ``fragment_fingerprint``; ``body_json`` хранит утверждения/предложения БЕЗ
``fragment``. Принятое - долговременные знания: таблицы не пересобираются из вики и не считаются
кэшем.
"""

from __future__ import annotations

import sqlite3

__all__ = ["TABLES", "VIEWS", "create_schema"]

TABLES = (
    "sleep_runs", "sleep_claims", "sleep_evidence", "sleep_proposals", "sleep_proposal_revisions",
    "sleep_batches", "sleep_decisions", "sleep_deps", "sleep_notes", "sleep_note_claims",
    "sleep_apply", "sleep_apply_log", "sleep_locks",
)
VIEWS = ("sleep_accepted_claims",)

_DDL: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS sleep_runs (
        run_id TEXT PRIMARY KEY,
        state TEXT NOT NULL,
        scope TEXT,
        package_ref TEXT,
        created_at TEXT,
        updated_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sleep_claims (
        row_id INTEGER PRIMARY KEY AUTOINCREMENT,
        claim_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        layer TEXT NOT NULL CHECK (layer IN ('candidate', 'accepted', 'superseded', 'rejected')),
        claim_type TEXT NOT NULL,
        review_state TEXT NOT NULL,
        fingerprint TEXT NOT NULL,
        topic_key TEXT,
        subject TEXT,
        predicate TEXT,
        area TEXT,
        valid_from TEXT,
        valid_to TEXT,
        run_id TEXT,
        proposal_id TEXT,
        needs_check INTEGER NOT NULL DEFAULT 0,
        needs_check_reason TEXT,
        body_json TEXT NOT NULL,
        recorded_at TEXT,
        updated_at TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_claims_id ON sleep_claims(claim_id, revision)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_claims_layer ON sleep_claims(layer, topic_key)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_claims_proposal ON sleep_claims(proposal_id)",
    "CREATE UNIQUE INDEX IF NOT EXISTS uq_sleep_claims_accepted "
    "ON sleep_claims(claim_id, revision) WHERE layer = 'accepted'",
    "CREATE VIEW IF NOT EXISTS sleep_accepted_claims AS "
    "SELECT * FROM sleep_claims WHERE layer = 'accepted'",
    """
    CREATE TABLE IF NOT EXISTS sleep_evidence (
        evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,
        claim_row INTEGER NOT NULL,
        claim_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        proposal_id TEXT,
        source_id TEXT NOT NULL,
        source_revision INTEGER,
        content_hash TEXT,
        locator TEXT,
        fragment_fingerprint TEXT,
        role TEXT,
        source_kind TEXT,
        origin_id TEXT,
        coverage TEXT,
        coverage_scope TEXT,
        privacy TEXT,
        source_path TEXT,
        available INTEGER NOT NULL DEFAULT 1,
        unavailable_at TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_evidence_source ON sleep_evidence(source_id)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_evidence_claim ON sleep_evidence(claim_row)",
    """
    CREATE TABLE IF NOT EXISTS sleep_proposals (
        proposal_id TEXT PRIMARY KEY,
        revision INTEGER NOT NULL,
        idempotency_key TEXT NOT NULL,
        content_digest TEXT NOT NULL,
        run_id TEXT NOT NULL,
        operation TEXT NOT NULL,
        targets_key TEXT NOT NULL,
        review_state TEXT NOT NULL,
        apply_state TEXT NOT NULL DEFAULT 'none',
        evidence_digest TEXT,
        issue_key TEXT,
        risk TEXT,
        snooze_until TEXT,
        compare_json TEXT,
        stale_json TEXT,
        body_json TEXT NOT NULL,
        effects_json TEXT NOT NULL DEFAULT '[]',
        created_at TEXT,
        updated_at TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_prop_state ON sleep_proposals(review_state, created_at)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_prop_key ON sleep_proposals(idempotency_key)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_prop_scope ON sleep_proposals(operation, targets_key)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_prop_run ON sleep_proposals(run_id)",
    """
    CREATE TABLE IF NOT EXISTS sleep_proposal_revisions (
        proposal_id TEXT NOT NULL,
        revision INTEGER NOT NULL,
        content_digest TEXT NOT NULL,
        evidence_digest TEXT,
        body_json TEXT NOT NULL,
        created_at TEXT,
        PRIMARY KEY (proposal_id, revision)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sleep_batches (
        run_id TEXT NOT NULL,
        idempotency_key TEXT NOT NULL,
        request_digest TEXT NOT NULL,
        result_json TEXT NOT NULL,
        created_at TEXT,
        PRIMARY KEY (run_id, idempotency_key)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sleep_decisions (
        decision_id INTEGER PRIMARY KEY AUTOINCREMENT,
        proposal_id TEXT NOT NULL,
        proposal_revision INTEGER NOT NULL,
        decision TEXT NOT NULL,
        actor TEXT NOT NULL,
        host TEXT,
        at TEXT,
        evidence_digest TEXT,
        reason TEXT,
        snooze_until TEXT,
        pins_json TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_dec_prop ON sleep_decisions(proposal_id, decision_id)",
    """
    CREATE TABLE IF NOT EXISTS sleep_deps (
        dep_id INTEGER PRIMARY KEY AUTOINCREMENT,
        owner_ref TEXT NOT NULL,
        rel TEXT NOT NULL,
        target_ref TEXT NOT NULL,
        layer TEXT NOT NULL,
        proposal_id TEXT,
        link_id TEXT,
        evidence_json TEXT,
        created_at TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_deps_owner ON sleep_deps(owner_ref)",
    "CREATE INDEX IF NOT EXISTS idx_sleep_deps_target ON sleep_deps(target_ref)",
    """
    CREATE TABLE IF NOT EXISTS sleep_notes (
        note_rel TEXT PRIMARY KEY,
        note_id TEXT,
        note_sha TEXT,
        seq INTEGER NOT NULL DEFAULT 0,
        updated_at TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sleep_note_claims (
        claim_id TEXT PRIMARY KEY,
        note_rel TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS sleep_apply (
        proposal_id TEXT PRIMARY KEY,
        proposal_revision INTEGER,
        state TEXT NOT NULL,
        stage TEXT,
        index_state TEXT NOT NULL DEFAULT 'none',
        note_rel TEXT,
        prev_sha TEXT,
        new_sha TEXT,
        prev_text TEXT,
        new_text TEXT,
        plan_json TEXT,
        holder TEXT,
        receipt_json TEXT,
        effects_json TEXT NOT NULL DEFAULT '[]',
        error TEXT,
        attempts INTEGER NOT NULL DEFAULT 0,
        started_at TEXT,
        updated_at TEXT,
        finished_at TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_apply_state ON sleep_apply(state)",
    """
    CREATE TABLE IF NOT EXISTS sleep_apply_log (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        proposal_id TEXT NOT NULL,
        at TEXT,
        event TEXT NOT NULL,
        state TEXT,
        detail TEXT
    )
    """,
    "CREATE INDEX IF NOT EXISTS idx_sleep_apply_log ON sleep_apply_log(proposal_id, log_id)",
    """
    CREATE TABLE IF NOT EXISTS sleep_locks (
        ref TEXT PRIMARY KEY,
        holder TEXT NOT NULL,
        pid INTEGER,
        proposal_id TEXT,
        acquired_at TEXT,
        expires_at TEXT
    )
    """,
)


def create_schema(conn: sqlite3.Connection) -> None:
    """Создать таблицы/индексы/VIEW ledger (идемпотентно, в транзакции вызывающего)."""
    for statement in _DDL:
        conn.execute(statement)
