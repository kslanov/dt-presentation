"""SLEEP-PULT-1 п.2, п.4 - данные экранов Сна: сводка («Результаты», счетчики «Предложений») и
журнал прогонов («Прогоны»). Только чтение: БД открывается ``mode=ro``, ничего не создается и
не мигрирует.

Те же таблицы и те же функции, что у ``sleep(op="status")`` и очереди ``pult_cards`` (вид
``memory``): второй очереди и второго бюджета здесь нет - счетчики очереди берутся из общего реестра
(:mod:`core.decisions.flow`), состав - из ledger.

**Неизвестное - не нуль.** Хост, модель, токены, стоимость и полезность прогона движок не измеряет
(модель не вызывается; синтез - SLEEP-SYNTH-1): в ответе они ``null`` и перечислены в
``unknown``. Пока нет ни прогонов, ни предложений - ``state: empty_checked`` с перечнем того, что
проверено; нет ledger
или миграции - ``not_configured``. Гипотезы и конфликты в «новые проверенные» не входят.

Форма ответа ``summary``: ``{ok, state, ledger, last_run, reading, counters, queue, conflicts,
sources_with_gaps, reviewed, synthesis, unknown, checked}``; ``runs`` без ``run_id`` - журнал,
с ним - один прогон с worklist, квитанциями чтения, пропусками. Отказ БД - ``store_unavailable``,
не «пусто».
"""

from __future__ import annotations

import json
import sqlite3
from typing import Any

from core.contract import CODE_STORE_UNAVAILABLE
from core.sleep_input.store import InputStore
from core.sleep_store import cards
from core.sleep_store.ctx import Ctx
from core.sleep_store.store import SleepStore

__all__ = ["runs", "summary"]

UNKNOWN = ("host", "model", "tokens", "cost", "usefulness")
_REVIEWED_STATES = ("accepted", "rejected", "snoozed", "superseded", "stale")
_OPEN_ITEMS = ("queued", "tail", "failed")
_RUN_LIMIT_MAX = 100
_ITEM_LIMIT = 200
_PREVIEW = 3
_SYNTH_NOTE = ("синтеза пока нет: модель в Сне не вызывается. Экран наполнят предложения прогонов "
               "синтеза (SLEEP-SYNTH-1); сейчас показано то, что уже лежит в ledger и реестре")


def _unavailable(exc: BaseException) -> dict[str, Any]:
    return {"ok": False, "refused": True, "code": CODE_STORE_UNAVAILABLE,
            "error": f"{CODE_STORE_UNAVAILABLE}: данные Сна недоступны ({type(exc).__name__}): "
                     "это не «пусто», а ошибка"}


def _open(ctx: Ctx) -> InputStore | None:
    return InputStore.open_readonly(ctx.db_path)


def _json(raw: Any, default: Any) -> Any:
    try:
        value = json.loads(raw) if raw else default
    except (TypeError, ValueError):
        return default
    return value if isinstance(value, type(default)) else default


def _count(conn: sqlite3.Connection, sql: str, *args: Any) -> int:
    return int(conn.execute(sql, args).fetchone()[0])


def _lease(row: dict[str, Any], now: str) -> dict[str, Any]:
    holder = str(row.get("lease_holder") or "")
    until = str(row.get("lease_until") or "")
    return {"holder": holder, "until": until, "active": bool(holder and until > now),
            "heartbeat_at": str(row.get("heartbeat_at") or "")}


def _run_view(row: dict[str, Any], now: str) -> dict[str, Any]:
    skipped = _json(row.get("skipped_json"), {})
    state = str(row.get("state") or "")
    lease = _lease(row, now)
    return {
        "run_id": row["run_id"], "state": state, "running": bool(lease["active"]),
        "mode": str(row.get("mode") or ""), "scope": str(row.get("scope") or ""),
        "created_at": str(row.get("created_at") or ""),
        "updated_at": str(row.get("updated_at") or ""),
        "budgets": _json(row.get("budgets_json"), {}),
        "estimate": _json(row.get("estimate_json"), {}),
        "skipped": {"blocked": int(skipped.get("blocked_count")
                                   or len(skipped.get("blocked") or [])),
                    "unavailable": int(skipped.get("unavailable_count")
                                       or len(skipped.get("unavailable") or [])),
                    "copies": int(skipped.get("copies") or 0),
                    "handled": int(skipped.get("handled") or 0),
                    "refused": dict(skipped.get("refused") or {}),
                    "errors": len(skipped.get("errors") or [])},
        "lease": lease, "note": str(row.get("note") or ""),
        "host": None, "model": None, "tokens": None, "cost": None, "usefulness": None,
    }


def _reading(conn: sqlite3.Connection, run_id: str) -> dict[str, Any]:
    """Объем чтения прогона: план / прочитано / отложено / ошибка (+ готово, пропущено)."""
    by = {r[0]: r[1] for r in conn.execute(
        "SELECT status, COUNT(*) FROM sleep_worklist WHERE run_id=? GROUP BY status", (run_id,))}
    read = _count(conn, "SELECT COUNT(DISTINCT item_id) FROM sleep_reads WHERE run_id=?", run_id)
    trunc = _count(conn, "SELECT COUNT(DISTINCT item_id) FROM sleep_reads WHERE run_id=? AND "
                         "truncated=1", run_id)
    return {"plan": int(sum(by.values())), "read": read, "deferred": int(by.get("tail", 0)
                                                                         + by.get("carried", 0)),
            "failed": int(by.get("failed", 0)), "done": int(by.get("done", 0)),
            "skipped": int(by.get("skipped", 0)), "queued": int(by.get("queued", 0)),
            "truncated": trunc, "by_status": by,
            "unit": "позиции worklist; «прочитано» - позиции с квитанцией чтения досье"}


def _title(store: SleepStore, ctx: Ctx, row: dict[str, Any]) -> dict[str, Any]:
    p = store.get_proposal(row["proposal_id"])
    out: dict[str, Any] = {"proposal_id": row["proposal_id"], "revision": int(row["revision"]),
                           "title": row["proposal_id"], "change_kind": "other",
                           "change_label": cards.CHANGE_LABELS["other"]}
    if p is None:
        return out
    cmp = _json(row.get("compare_json"), {})
    results = sorted({r["result"] for r in cmp.get("results", []) if r.get("result")})
    kind = cards.change_kind(p, results)
    fields = cards.card_fields(store, ctx.vault, row, p)
    out.update(title=fields["title"], change_kind=kind, change_label=cards.CHANGE_LABELS[kind],
               why_now=fields["meta"]["why_now"], run_id=row["run_id"],
               intended_use=fields["meta"]["intended_use"], operation=row["operation"],
               since=row.get("created_at") or "")
    return out


def _reviewed(store: SleepStore, ctx: Ctx, limit: int) -> tuple[list[dict[str, Any]], int]:
    marks = ",".join("?" for _ in _REVIEWED_STATES)
    total = _count(store.conn, f"SELECT COUNT(*) FROM sleep_proposals WHERE review_state IN "  # noqa: S608
                               f"({marks})", *_REVIEWED_STATES)
    rows = store.conn.execute(
        f"SELECT * FROM sleep_proposals WHERE review_state IN ({marks}) "  # noqa: S608
        "ORDER BY updated_at DESC, proposal_id LIMIT ?", (*_REVIEWED_STATES, limit)).fetchall()
    out = []
    for row in rows:
        row = dict(row)
        item = _title(store, ctx, row)
        dec = store.conn.execute(
            "SELECT decision, actor, host, at, reason, snooze_until FROM sleep_decisions WHERE "
            "proposal_id=? ORDER BY decision_id DESC LIMIT 1", (row["proposal_id"],)).fetchone()
        item.update(state=row["review_state"], apply_state=row["apply_state"],
                    decided_at=(dec["at"] if dec else row["updated_at"]) or "",
                    reason=(dec["reason"] if dec else "") or "",
                    snooze_until=row.get("snooze_until") or "")
        out.append(item)
    return out, total


def _open_conflicts(store: SleepStore, ctx: Ctx, now: str, limit: int = 10) -> dict[str, Any]:
    rows = [dict(r) for r in store.pending_rows(now)]
    items = []
    for row in rows:
        cmp = _json(row.get("compare_json"), {})
        if any(r.get("result") == "contradiction" for r in cmp.get("results", [])):
            items.append(row)
    shown = []
    for row in items[:limit]:
        v = _title(store, ctx, row)
        shown.append({k: v.get(k) for k in ("proposal_id", "title", "run_id", "why_now")}
                     | {"since": row.get("created_at") or ""})
    apply_conflicts = [r[0] for r in store.conn.execute(
        "SELECT proposal_id FROM sleep_apply WHERE state='conflict' ORDER BY proposal_id")]
    return {"open": len(items), "items": shown, "apply_conflicts": apply_conflicts}


def _gaps(conn: sqlite3.Connection, input_ok: bool, limit: int = 10) -> list[dict[str, Any]]:
    """Источники с пропусками: порции с обрезкой/блокером/ошибкой и недоступные входы."""
    if not input_ok:
        return []
    out: list[dict[str, Any]] = []
    rows = conn.execute(
        "SELECT r.run_id, r.item_id, r.source_id, r.truncated, r.blockers_json, r.errors_json, "
        "r.units_total, r.units_returned, r.unit, i.locator FROM sleep_reads r LEFT JOIN "
        "sleep_inputs i ON i.source_id = r.source_id WHERE r.truncated=1 OR "
        "r.blockers_json <> '[]' OR r.errors_json <> '[]' ORDER BY r.read_id DESC LIMIT ?",
        (limit,))
    for r in rows:
        blockers = _json(r["blockers_json"], [])
        errors = _json(r["errors_json"], [])
        reason = ("blocker:" + str(blockers[0].get("code", "")) if blockers else
                  "error" if errors else "truncated")
        out.append({"source_id": r["source_id"], "locator": r["locator"] or "", "reason": reason,
                    "run_id": r["run_id"], "item_id": r["item_id"], "unit": r["unit"] or "",
                    "returned": r["units_returned"], "total": r["units_total"]})
    rest = limit - len(out)
    if rest > 0:
        for r in conn.execute(
                "SELECT source_id, locator, availability, unavailable_reason FROM sleep_inputs "
                "WHERE availability <> 'available' ORDER BY updated_at DESC, source_id LIMIT ?",
                (rest,)):
            out.append({"source_id": r["source_id"], "locator": r["locator"],
                        "reason": (r["availability"] + (":" + r["unavailable_reason"]
                                                        if r["unavailable_reason"] else "")),
                        "run_id": "", "item_id": ""})
    return out


def _duplicates(conn: sqlite3.Connection, run_id: str) -> int:
    n = 0
    for (raw,) in conn.execute("SELECT result_json FROM sleep_batches WHERE run_id=?", (run_id,)):
        for res in _json(raw, {}).get("results", []):
            if isinstance(res, dict) and res.get("status") in ("duplicate", "noop"):
                n += 1
    return n


def summary(ctx: Ctx, *, reviewed_limit: int = 30) -> dict[str, Any]:
    """Сводка для «Результатов» и счетчиков «Предложений». Только чтение."""
    from core.decisions import flow
    from core.sleep_store.store import now_iso

    try:
        inp = _open(ctx)
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
    budget = flow.budgets().get("memory")
    queue = {"pending": 0, "budget": budget, "in_reserve": flow.reserve_counts().get("memory", 0)}
    unknown = {k: None for k in UNKNOWN}
    if inp is None or not inp.has_table("sleep_proposals"):
        if inp is not None:
            inp.close()
        return {"ok": True, "present": False, "state": "not_configured", "queue": queue,
                "unknown": unknown, "synthesis": {"available": False, "note": _SYNTH_NOTE},
                "hint": "ledger Сна еще не заводили (нет dt.db или миграции v5): предложений и "
                        "прогонов нет, это не «проверено, пусто»"}
    try:
        conn = inp.conn
        store = SleepStore(conn)
        now = now_iso(ctx.now or None)
        stats = store.summary()
        queue["pending"] = len(store.pending_rows(now))
        input_ok = inp.registry
        last_row = conn.execute(
            "SELECT * FROM sleep_runs ORDER BY created_at DESC, run_id DESC LIMIT 1").fetchone()
        last = _run_view(dict(last_row), now) if last_row else None
        reading = _reading(conn, last["run_id"]) if last and input_ok else None
        counters: dict[str, Any] = {
            "pending_all_runs": queue["pending"], "snoozed": _count(
                conn, "SELECT COUNT(*) FROM sleep_proposals WHERE review_state='snoozed'"),
            "new_in_run": None, "new_verified": None, "duplicates": None,
            "open_conflicts": None, "unit": "карточки вида «Память»"}
        conflicts = _open_conflicts(store, ctx, now)
        counters["open_conflicts"] = conflicts["open"]
        if last is not None:
            rows = [dict(r) for r in conn.execute(
                "SELECT * FROM sleep_proposals WHERE run_id=?", (last["run_id"],))]
            kinds: dict[str, int] = {}
            for row in rows:
                kind = _title(store, ctx, row)["change_kind"]
                kinds[kind] = kinds.get(kind, 0) + 1
            counters.update(
                new_in_run={"total": len(rows), "by_kind": kinds},
                # гипотезы и конфликты не считаются новыми проверенными фактами (§17.3)
                new_verified=sum(v for k, v in kinds.items()
                                 if k not in ("hypothesis", "conflict")),
                duplicates=_duplicates(conn, last["run_id"]))
        reviewed, reviewed_total = _reviewed(store, ctx, max(1, int(reviewed_limit)))
        preview = [_title(store, ctx, dict(r)) for r in store.pending_rows(now)[:_PREVIEW]]
        checked = ["ledger Сна (предложения, решения, применение)", "прогоны и worklist",
                   "очередь вида «Память» (общий бюджет)"]
        if input_ok:
            checked.append("реестр входов и квитанции чтения")
        state = "ready"
        if stats["proposals"] == 0 and last is None:
            state = "empty_checked"
        elif last is not None and last["running"]:
            state = "running"
        out: dict[str, Any] = {
            "ok": True, "present": True, "state": state, "ledger": stats, "last_run": last,
            "reading": reading, "counters": counters, "queue": queue, "queue_preview": preview,
            "conflicts": conflicts,
            "sources_with_gaps": _gaps(conn, input_ok), "reviewed": reviewed,
            "reviewed_total": reviewed_total,
            "synthesis": {"available": False, "note": _SYNTH_NOTE}, "unknown": unknown,
            "checked": checked, "runs_total": stats["runs"],
        }
        if not input_ok:
            out["warning"] = [{"code": "unavailable",
                               "reason": "реестр входов не заведен (миграция v6): объем чтения "
                                         "и пропуски источников неизвестны"}]
            out["state"] = "partial" if state == "ready" else state
        return out
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
    finally:
        inp.close()


def _proposal_counts(conn: sqlite3.Connection, run_id: str) -> dict[str, int]:
    return {r[0]: r[1] for r in conn.execute(
        "SELECT review_state, COUNT(*) FROM sleep_proposals WHERE run_id=? GROUP BY review_state",
        (run_id,))}


def runs(ctx: Ctx, run_id: str | None = None, *, limit: int = 20) -> dict[str, Any]:
    """Журнал прогонов (без ``run_id``) либо один прогон: worklist, квитанции чтения, пропуски."""
    from core.sleep_store.store import now_iso

    try:
        inp = _open(ctx)
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
    if inp is None or not inp.has_table("sleep_runs"):
        if inp is not None:
            inp.close()
        return {"ok": True, "present": False, "state": "not_configured", "runs": [],
                "unknown": {k: None for k in UNKNOWN},
                "hint": "прогонов еще не заводили: dt sleep plan --apply создаст первый"}
    try:
        conn = inp.conn
        now = now_iso(ctx.now or None)
        registry = inp.registry
        if run_id:
            row = conn.execute("SELECT * FROM sleep_runs WHERE run_id=?", (run_id,)).fetchone()
            if row is None:
                return {"ok": False, "refused": True, "code": "run_not_found",
                        "error": f"run_not_found: прогон {run_id!r} не найден"}
            view = _run_view(dict(row), now)
            items = []
            if registry:
                for it in inp.worklist(run_id)[:_ITEM_LIMIT]:
                    src = inp.input_row(it["source_id"]) or {}
                    reads = inp.reads(run_id, it["item_id"])
                    items.append({
                        "item_id": it["item_id"], "seq": it["seq"], "source_id": it["source_id"],
                        "locator": src.get("locator", ""), "kind": it["item_kind"],
                        "revision": it["revision"], "status": it["status"],
                        "priority": it["priority"], "reasons": _json(it["reasons_json"], []),
                        "intended_use": it["intended_use"], "difference": it["difference"],
                        "carried_from": it["carried_from"], "note": it["note"],
                        "availability": src.get("availability", ""),
                        "reads": [{"at": r["at"], "unit": r["unit"],
                                   "returned": r["units_returned"], "total": r["units_total"],
                                   "truncated": bool(r["truncated"]),
                                   "next_cursor": bool(r["next_cursor"]),
                                   "blockers": _json(r["blockers_json"], []),
                                   "errors": _json(r["errors_json"], [])} for r in reads]})
            return {"ok": True, "present": True, "run": view,
                    "skipped": _json(dict(row).get("skipped_json"), {}),
                    "reading": _reading(conn, run_id) if registry else None, "items": items,
                    "items_total": (_count(conn, "SELECT COUNT(*) FROM sleep_worklist WHERE "
                                                 "run_id=?", run_id) if registry else 0),
                    "proposals": _proposal_counts(conn, run_id) if inp.has_table(
                        "sleep_proposals") else {},
                    "unknown": {k: None for k in UNKNOWN}}
        n = max(1, min(int(limit), _RUN_LIMIT_MAX))
        total = _count(conn, "SELECT COUNT(*) FROM sleep_runs")
        out_runs = []
        for row in conn.execute(
                "SELECT * FROM sleep_runs ORDER BY created_at DESC, run_id DESC LIMIT ?", (n,)):
            view = _run_view(dict(row), now)
            view["reading"] = _reading(conn, view["run_id"]) if registry else None
            view["proposals"] = _proposal_counts(conn, view["run_id"]) if inp.has_table(
                "sleep_proposals") else {}
            out_runs.append(view)
        tail = {"items": 0, "runs": 0}
        if registry:
            tail["items"] = _count(conn, "SELECT COUNT(*) FROM sleep_worklist WHERE status IN "
                                         "('queued','tail','failed')")
            tail["runs"] = _count(conn, "SELECT COUNT(DISTINCT run_id) FROM sleep_worklist WHERE "
                                        "status IN ('queued','tail','failed')")
        res: dict[str, Any] = {"ok": True, "present": True, "runs": out_runs, "runs_total": total,
                               "tail": tail, "unknown": {k: None for k in UNKNOWN},
                               "state": "ready" if out_runs else "empty_checked"}
        if not registry:
            res["warning"] = [{"code": "unavailable", "reason":
                               "реестр входов не заведен (миграция v6): worklist и квитанции "
                               "чтения неизвестны"}]
            res["state"] = "partial"
        return res
    except (sqlite3.Error, OSError) as exc:
        return _unavailable(exc)
    finally:
        inp.close()
