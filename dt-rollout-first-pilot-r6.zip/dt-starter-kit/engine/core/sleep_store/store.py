"""SLEEP-STORE-1 - доступ к ledger Сна в общей ``dt.db`` (sleep-1.md §6.1).

Тонкий слой над SQLite: строки таблиц :mod:`core.sleep_store.schema` <-> объекты контракта
:mod:`core.sleep.contract`. Решений здесь нет: проверки - валидатор SLEEP-CONTRACT-1, запись
заметок - применитель. Модуль не пишет в vault и facts.

**Кандидаты отделены от принятого.** Поле ``sleep_claims.layer`` (``candidate | accepted |
superseded | rejected``); читатель принятого пользуется :meth:`SleepStore.accepted_claims` / VIEW
``sleep_accepted_claims``. Кандидат становится принятым только в :meth:`SleepStore.publish_claims`
(его зовет применитель после решения владельца и записи заметки).

**Тексты оригиналов в SQL не копируются:** ``Evidence.fragment`` перед записью обнуляется
(:func:`strip_proposal`), хранится ``fragment_fingerprint``.

**Транзакции:** методы записи НЕ коммитят сами - вызывающий оборачивает их в :meth:`SleepStore.tx`
(``BEGIN`` / ``BEGIN IMMEDIATE``). Вложенных транзакций нет.
"""

from __future__ import annotations

import hashlib
import json
import re
import sqlite3
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.sleep.contract import (
    Actor,
    ApplyState,
    Claim,
    Decision,
    DecisionRecord,
    Evidence,
    Link,
    Pin,
    Proposal,
    ReviewState,
    Snapshot,
    claim_fingerprint,
    claim_from_dict,
    proposal_from_dict,
)
from core.sleep.slot import topic_key
from core.sleep.validate import Ledger

__all__ = [
    "LedgerError",
    "RUN_ID_RE",
    "SleepStore",
    "content_digest",
    "now_iso",
    "strip_claim",
    "strip_proposal",
    "targets_key",
]

RUN_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
_CLOSURE_CAP = 400  # потолок догрузки утверждений по графу посылок/зависимостей


class LedgerError(RuntimeError):
    """Нарушение целостности ledger (машинный ``code`` + текст)."""

    def __init__(self, code: str, message: str = "") -> None:
        super().__init__(message or code)
        self.code = code


def now_iso(now: datetime | str | None = None) -> str:
    """Метка времени ``ГГГГ-ММ-ДДTЧЧ:ММ:ССZ`` (UTC); строка принимается как есть (тесты)."""
    if isinstance(now, str) and now:
        return now
    moment = now if isinstance(now, datetime) else datetime.now(UTC)
    if moment.tzinfo is not None:
        moment = moment.astimezone(UTC)
    return moment.strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------------- #
# Сериализация: без текстов оригиналов                                          #
# --------------------------------------------------------------------------- #
def _strip_evidence(e: Evidence) -> Evidence:
    return replace(e, fragment="") if e.fragment else e


def strip_claim(c: Claim) -> Claim:
    """Утверждение без ``Evidence.fragment``: в SQL остаются отпечатки, не тексты оригиналов."""
    return replace(c, evidence=tuple(_strip_evidence(e) for e in c.evidence))


def _strip_link(link: Link) -> Link:
    return replace(link, evidence=tuple(_strip_evidence(e) for e in link.evidence))


def _strip_snapshot(s: Snapshot) -> Snapshot:
    return replace(s, claims=tuple(strip_claim(c) for c in s.claims),
                   links=tuple(_strip_link(x) for x in s.links))


def strip_proposal(p: Proposal) -> Proposal:
    return replace(p, before=_strip_snapshot(p.before), after=_strip_snapshot(p.after))


def targets_key(p: Proposal) -> str:
    return "|".join(sorted(t.ref for t in p.targets))


def content_digest(p: Proposal) -> str:
    """Отпечаток СОДЕРЖАНИЯ предложения (не состояния): повтор того же - идемпотентен, другое
    содержимое под тем же ключом - ``idempotency_conflict``. Состояние рассмотрения/применения,
    квитанция и время в отпечаток не входят."""
    material = {
        "op": p.operation.value,
        "targets": sorted(f"{t.kind}:{t.ref}" for t in p.targets),
        "expected": sorted([e.ref, e.revision, e.content_hash] for e in p.expected_revisions),
        "before": sorted([c.claim_id, claim_fingerprint(c)] for c in p.before.claims),
        "after": sorted([c.claim_id, c.revision, claim_fingerprint(c)] for c in p.after.claims),
        "links": sorted([x.link_id, x.type.value, x.source, x.target] for x in p.after.links),
        "notes": [p.before.note, p.after.note],
        "evidence_digest": p.evidence_digest,
        "claim_ids": sorted(p.claim_ids),
        "reopens": p.reopens, "new_basis": p.new_basis, "context_mode": p.context_mode,
        "group": p.group.to_dict() if p.group else None,
        "promotion": p.promotion.to_dict() if p.promotion else None,
        "redirects": sorted([r.from_ref, r.to_ref] for r in p.redirects),
    }
    blob = json.dumps(material, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def _dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True)


def _claim_refs(c: Claim) -> set[str]:
    out = set(c.premises) | set(c.depends_on) | set(c.supersedes) | set(c.contradicts)
    if c.duplicate_of:
        out.add(c.duplicate_of)
    for e in c.evidence:
        out.update(e.derived_from)
    return out


def _proposal_refs(p: Proposal) -> set[str]:
    ids = set(p.claim_ids) | {c.claim_id for c in p.after.claims}
    ids |= {t.ref.removeprefix("claim:") for t in p.targets if t.kind == "claim"}
    ids |= {e.ref.removeprefix("claim:") for e in p.expected_revisions
            if e.ref.startswith("claim:")}
    for c in (*p.after.claims, *p.before.claims):
        ids |= _claim_refs(c)
    for link in p.after.links:
        for end in (link.source, link.target):
            if end.startswith("claim:"):
                ids.add(end.removeprefix("claim:"))
    return {i for i in ids if i}


def _entity_refs(p: Proposal) -> set[str]:
    refs = {t.ref for t in p.targets if t.ref.startswith("entity:")}
    for link in p.after.links:
        refs |= {end for end in (link.source, link.target) if end.startswith("entity:")}
    return refs


class SleepStore:
    """Ledger Сна в ``dt.db``. Создается :meth:`open` (создает/мигрирует БД) или
    :meth:`open_existing` (файла нет - ``None``: пусто, а не ошибка)."""

    def __init__(self, conn: sqlite3.Connection) -> None:
        self.conn = conn

    # --- соединение ------------------------------------------------------------------------ #
    @classmethod
    def open(cls, db_path: Path | None = None) -> SleepStore:
        from core.db import connect

        return cls(connect(db_path))

    @classmethod
    def open_existing(cls, db_path: Path | None = None) -> SleepStore | None:
        """``None`` - файла БД нет вовсе (ledger не заводили: пусто). Битая/недоступная БД -
        исключение (``sqlite3.Error``/``OSError``): «недоступно» не прячется за «пусто»."""
        from core.config import dt_db_path

        path = Path(db_path) if db_path is not None else dt_db_path()
        if not path.is_file():
            return None
        return cls.open(path)

    def close(self) -> None:
        self.conn.close()

    @contextmanager
    def tx(self, *, immediate: bool = False) -> Iterator[sqlite3.Connection]:
        """Транзакция: ``COMMIT`` при выходе, ``ROLLBACK`` при любом исключении (в т.ч. имитации
        сбоя ``BaseException`` в тестах)."""
        conn = self.conn
        prev = conn.isolation_level
        conn.isolation_level = None
        try:
            conn.execute("BEGIN IMMEDIATE" if immediate else "BEGIN")
            try:
                yield conn
            except BaseException:
                conn.execute("ROLLBACK")
                raise
            conn.execute("COMMIT")
        finally:
            conn.isolation_level = prev

    # --- прогоны --------------------------------------------------------------------------- #
    def ensure_run(self, run_id: str, now: str, *, scope: str = "", state: str = "running") -> None:
        if not RUN_ID_RE.match(run_id or ""):
            raise LedgerError("bad_run_id", f"run_id {str(run_id)[:40]!r}: нужны буквы, цифры, ._-")
        self.conn.execute(
            "INSERT OR IGNORE INTO sleep_runs(run_id, state, scope, package_ref, created_at, "
            "updated_at) VALUES (?,?,?,?,?,?)",
            (run_id, state, scope, f"sleep/{run_id}", now, now))

    def run_row(self, run_id: str) -> dict[str, Any] | None:
        row = self.conn.execute("SELECT * FROM sleep_runs WHERE run_id=?", (run_id,)).fetchone()
        return dict(row) if row else None

    # --- чтение утверждений ---------------------------------------------------------------- #
    @staticmethod
    def _claim(row: sqlite3.Row) -> Claim:
        return claim_from_dict(json.loads(row["body_json"]))

    def accepted_claims(self, ids: set[str] | None = None) -> dict[str, Claim]:
        """Принятое: действующая ревизия каждого ``claim_id`` (ЕДИНСТВЕННЫЙ читатель принятого
        для потребителей; кандидаты сюда не попадают по построению VIEW)."""
        if ids is not None and not ids:
            return {}
        sql = "SELECT * FROM sleep_accepted_claims"
        args: list[Any] = []
        if ids is not None:
            marks = ",".join("?" for _ in ids)
            sql += f" WHERE claim_id IN ({marks})"
            args = sorted(ids)
        out: dict[str, Claim] = {}
        for row in self.conn.execute(sql + " ORDER BY claim_id, revision", args):
            out[row["claim_id"]] = self._claim(row)  # последняя ревизия перекрывает прежние
        return out

    def memory_claims(self, as_of: str = "") -> dict[str, Claim]:
        """Accepted and still eligible for retrieval at the requested date."""
        if not as_of:
            rows = self.conn.execute(
                "SELECT * FROM sleep_accepted_claims WHERE needs_check=0 "
                "ORDER BY claim_id, revision")
        else:
            # The transition to 'superseded' stamps updated_at. Its stored body
            # and decision still describe the old accepted revision.
            rows = self.conn.execute(
                "SELECT * FROM sleep_claims WHERE needs_check=0 AND "
                "(layer='accepted' OR (layer='superseded' AND substr(updated_at,1,10)>?)) "
                "ORDER BY claim_id, revision", (as_of,))
        out: dict[str, Claim] = {}
        for row in rows:
            claim = self._claim(row)
            known = max([claim.recorded_at, *(d.at for d in claim.decisions)])
            if not as_of or known[:10] <= as_of:
                out[claim.claim_id] = claim
        return out

    def accepted_link_proposals(self) -> Iterator[tuple[Proposal, DecisionRecord]]:
        """Explicit links after the owner decision and successful application."""
        rows = self.conn.execute(
            "SELECT DISTINCT p.* FROM sleep_deps d "
            "JOIN sleep_proposals p ON p.proposal_id=d.proposal_id "
            "WHERE d.layer='accepted' AND d.link_id != '' AND p.review_state='accepted' "
            "AND p.apply_state='applied'")
        for row in rows:
            proposal = self._proposal_of(dict(row))
            receipt = proposal.decision_receipt
            if receipt and receipt.actor is Actor.OWNER:
                yield proposal, receipt

    def accepted_by_topic(self, topics: set[str]) -> dict[str, Claim]:
        if not topics:
            return {}
        marks = ",".join("?" for _ in topics)
        rows = self.conn.execute(
            f"SELECT * FROM sleep_accepted_claims WHERE topic_key IN ({marks}) "  # noqa: S608
            "ORDER BY claim_id, revision", sorted(topics))
        return {r["claim_id"]: self._claim(r) for r in rows}

    def claims_of_proposal(self, proposal_id: str, layer: str | None = None) -> list[Claim]:
        sql = "SELECT * FROM sleep_claims WHERE proposal_id=?"
        args: list[Any] = [proposal_id]
        if layer:
            sql += " AND layer=?"
            args.append(layer)
        return [self._claim(r) for r in self.conn.execute(sql + " ORDER BY row_id", args)]

    def claim_rows(self, claim_id: str) -> list[dict[str, Any]]:
        """История ревизий утверждения (все слои) - для проверки и тестов."""
        return [dict(r) for r in self.conn.execute(
            "SELECT row_id, claim_id, revision, layer, review_state, proposal_id, needs_check, "
            "needs_check_reason FROM sleep_claims WHERE claim_id=? ORDER BY revision, row_id",
            (claim_id,))]

    # --- запись кандидатов ----------------------------------------------------------------- #
    def _insert_claim(self, c: Claim, layer: str, proposal_id: str, run_id: str, now: str) -> int:
        c = strip_claim(c)
        cur = self.conn.execute(
            "INSERT INTO sleep_claims(claim_id, revision, layer, claim_type, review_state, "
            "fingerprint, topic_key, subject, predicate, area, valid_from, valid_to, run_id, "
            "proposal_id, body_json, recorded_at, updated_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (c.claim_id, c.revision, layer, c.type.value, c.review_state.value,
             claim_fingerprint(c), topic_key(c), c.subject, c.predicate, c.area, c.valid_from,
             c.valid_to, run_id, proposal_id, _dumps(c.to_dict()), c.recorded_at, now))
        row_id = int(cur.lastrowid or 0)
        for e in c.evidence:
            self.conn.execute(
                "INSERT INTO sleep_evidence(claim_row, claim_id, revision, proposal_id, source_id, "
                "source_revision, content_hash, locator, fragment_fingerprint, role, source_kind, "
                "origin_id, coverage, coverage_scope, privacy, source_path) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (row_id, c.claim_id, c.revision, proposal_id, e.source_id, e.revision,
                 e.content_hash, e.locator, e.fragment_fingerprint, e.role.value,
                 e.source_kind.value, e.origin_id, e.coverage.value, e.coverage_scope,
                 e.privacy.value, e.source_path))
        return row_id

    def _insert_deps(self, p: Proposal, layer: str, now: str) -> None:
        def put(owner: str, rel: str, target: str, link_id: str = "", ev: str = "") -> None:
            self.conn.execute(
                "INSERT INTO sleep_deps(owner_ref, rel, target_ref, layer, proposal_id, link_id, "
                "evidence_json, created_at) VALUES (?,?,?,?,?,?,?,?)",
                (owner, rel, target, layer, p.proposal_id, link_id, ev, now))

        for c in p.after.claims:
            owner = f"claim:{c.claim_id}"
            for rel, refs in (("supersedes", c.supersedes), ("depends_on", c.depends_on),
                              ("contradicts", c.contradicts), ("premise", c.premises)):
                for ref in refs:
                    put(owner, rel, f"claim:{ref}")
            if c.duplicate_of:
                put(owner, "duplicate_of", f"claim:{c.duplicate_of}")
            for e in c.evidence:
                for ref in e.derived_from:
                    put(owner, "derived_from", f"claim:{ref}")
        for link in p.after.links:
            put(link.source, link.type.value, link.target, link.link_id,
                _dumps([_strip_evidence(e).to_dict() for e in link.evidence]))

    def insert_proposal(
        self, p: Proposal, *, digest: str, issue_key: str, compare: dict[str, Any] | None,
        review_state: ReviewState, now: str,
    ) -> None:
        """Новое предложение + его кандидаты-утверждения (layer ``candidate``)."""
        p = strip_proposal(p)
        body = _dumps(p.to_dict())
        self.conn.execute(
            "INSERT INTO sleep_proposals(proposal_id, revision, idempotency_key, content_digest, "
            "run_id, operation, targets_key, review_state, apply_state, evidence_digest, "
            "issue_key, risk, compare_json, body_json, effects_json, created_at, updated_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (p.proposal_id, p.revision, p.idempotency_key, digest, p.run_id, p.operation.value,
             targets_key(p), review_state.value, ApplyState.NONE.value, p.evidence_digest,
             issue_key, p.risk.value, _dumps(compare) if compare else None, body, "[]",
             p.created_at or now, now))
        self.conn.execute(
            "INSERT INTO sleep_proposal_revisions(proposal_id, revision, content_digest, "
            "evidence_digest, body_json, created_at) VALUES (?,?,?,?,?,?)",
            (p.proposal_id, p.revision, digest, p.evidence_digest, body, now))
        for c in p.after.claims:
            self._insert_claim(c, "candidate", p.proposal_id, p.run_id, now)
        self._insert_deps(p, "candidate", now)

    def revise_proposal(
        self, p: Proposal, *, digest: str, issue_key: str, compare: dict[str, Any] | None,
        review_state: ReviewState, now: str,
    ) -> None:
        """Новая ревизия предложения (правка владельцем/пересборка после ``stale``): прежние
        кандидаты этого предложения уходят в ``rejected`` (история остается), решения прежних
        ревизий в журнале не переносятся."""
        p = strip_proposal(p)
        body = _dumps(p.to_dict())
        self.conn.execute(
            "UPDATE sleep_claims SET layer='rejected', review_state='superseded', updated_at=? "
            "WHERE proposal_id=? AND layer='candidate'", (now, p.proposal_id))
        self.conn.execute(
            "UPDATE sleep_deps SET layer='rejected' WHERE proposal_id=? AND layer='candidate'",
            (p.proposal_id,))
        self.conn.execute(
            "UPDATE sleep_proposals SET revision=?, idempotency_key=?, content_digest=?, "
            "review_state=?, apply_state='none', evidence_digest=?, issue_key=?, risk=?, "
            "compare_json=?, snooze_until=NULL, body_json=?, effects_json='[]', "
            "updated_at=? WHERE proposal_id=?",
            (p.revision, p.idempotency_key, digest, review_state.value, p.evidence_digest,
             issue_key, p.risk.value, _dumps(compare) if compare else None, body, now,
             p.proposal_id))
        self.conn.execute(
            "INSERT INTO sleep_proposal_revisions(proposal_id, revision, content_digest, "
            "evidence_digest, body_json, created_at) VALUES (?,?,?,?,?,?)",
            (p.proposal_id, p.revision, digest, p.evidence_digest, body, now))
        for c in p.after.claims:
            self._insert_claim(c, "candidate", p.proposal_id, p.run_id, now)
        self._insert_deps(p, "candidate", now)

    # --- предложения: чтение --------------------------------------------------------------- #
    def proposal_row(self, proposal_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM sleep_proposals WHERE proposal_id=?", (proposal_id,)).fetchone()
        return dict(row) if row else None

    def decision_rows(self, proposal_id: str) -> list[dict[str, Any]]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM sleep_decisions WHERE proposal_id=? ORDER BY decision_id",
            (proposal_id,))]

    @staticmethod
    def _receipt(row: dict[str, Any]) -> DecisionRecord:
        pins = tuple(Pin(str(x["claim_id"]), str(x["fingerprint"]))
                     for x in json.loads(row.get("pins_json") or "[]"))
        return DecisionRecord(
            decision=Decision(row["decision"]), actor=Actor(row["actor"]), at=row["at"] or "",
            proposal_id=row["proposal_id"], proposal_revision=int(row["proposal_revision"]),
            pins=pins, evidence_digest=row["evidence_digest"] or "", reason=row["reason"] or "",
            snooze_until=row["snooze_until"] or "")

    def _proposal_of(self, row: dict[str, Any]) -> Proposal:
        p = proposal_from_dict(json.loads(row["body_json"]))
        receipt = None
        want = {"accepted": Decision.ACCEPT.value, "rejected": Decision.REJECT.value,
                "snoozed": Decision.SNOOZE.value}.get(row["review_state"])
        if want:
            for d in reversed(self.decision_rows(row["proposal_id"])):
                if d["decision"] == want and int(d["proposal_revision"]) == int(row["revision"]):
                    receipt = self._receipt(d)
                    break
        return replace(
            p, revision=int(row["revision"]), review_state=ReviewState(row["review_state"]),
            apply_state=ApplyState(row["apply_state"]), decision_receipt=receipt,
            effects=tuple(json.loads(row["effects_json"] or "[]")))

    def get_proposal(self, proposal_id: str) -> Proposal | None:
        row = self.proposal_row(proposal_id)
        return self._proposal_of(row) if row else None

    def related_proposals(self, p: Proposal) -> tuple[Proposal, ...]:
        """Предложения того же ключа идемпотентности или той же области (операция + цели): вход
        ``Ledger.decided`` (повтор отказа, snooze, конфликт ключа). Само предложение исключено."""
        rows = self.conn.execute(
            "SELECT * FROM sleep_proposals WHERE (idempotency_key=? OR (operation=? AND "
            "targets_key=?)) AND proposal_id<>? ORDER BY created_at, proposal_id",
            (p.idempotency_key, p.operation.value, targets_key(p), p.proposal_id))
        return tuple(self._proposal_of(dict(r)) for r in rows)

    def find_by_key(self, run_id: str, idempotency_key: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM sleep_proposals WHERE idempotency_key=? ORDER BY created_at LIMIT 1",
            (idempotency_key,)).fetchone()
        return dict(row) if row else None

    def pending_rows(self, now: str) -> list[dict[str, Any]]:
        """Карточки, ждущие решения: ``pending`` и ``snoozed`` с истекшим сроком."""
        rows = self.conn.execute(
            "SELECT * FROM sleep_proposals WHERE review_state='pending' OR "
            "(review_state='snoozed' AND snooze_until IS NOT NULL AND snooze_until<=?) "
            "ORDER BY created_at, proposal_id", (now,))
        return [dict(r) for r in rows]

    # --- батчи (идемпотентность propose_memory) -------------------------------------------- #
    def batch(self, run_id: str, key: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM sleep_batches WHERE run_id=? AND idempotency_key=?",
            (run_id, key)).fetchone()
        return dict(row) if row else None

    def save_batch(self, run_id: str, key: str, digest: str, result: dict[str, Any],
                   now: str) -> None:
        self.conn.execute(
            "INSERT OR IGNORE INTO sleep_batches(run_id, idempotency_key, request_digest, "
            "result_json, created_at) VALUES (?,?,?,?,?)",
            (run_id, key, digest, _dumps(result), now))

    # --- состояние предложения и решения --------------------------------------------------- #
    def set_proposal(self, proposal_id: str, now: str, **cols: Any) -> None:
        allowed = {"review_state", "apply_state", "snooze_until", "stale_json", "effects_json"}
        bad = set(cols) - allowed
        if bad:
            raise LedgerError("bad_column", f"нельзя менять {sorted(bad)}")
        sets = ", ".join(f"{k}=?" for k in cols)
        self.conn.execute(
            f"UPDATE sleep_proposals SET {sets}, updated_at=? WHERE proposal_id=?",  # noqa: S608
            (*cols.values(), now, proposal_id))

    def add_decision(
        self, *, proposal_id: str, revision: int, decision: Decision, actor: Actor, host: str,
        at: str, evidence_digest: str, reason: str = "", snooze_until: str = "",
        pins: tuple[Pin, ...] = (),
    ) -> int:
        cur = self.conn.execute(
            "INSERT INTO sleep_decisions(proposal_id, proposal_revision, decision, actor, host, "
            "at, evidence_digest, reason, snooze_until, pins_json) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (proposal_id, revision, decision.value, actor.value, host, at, evidence_digest,
             reason, snooze_until, _dumps([p.to_dict() for p in pins])))
        return int(cur.lastrowid or 0)

    def mark_claims(self, proposal_id: str, layer: str, review_state: str, now: str) -> None:
        """Кандидаты предложения -> ``rejected`` (отказ); принятое - только через publish."""
        if layer not in ("rejected",):
            raise LedgerError("bad_layer", "кандидат становится принятым только publish_claims")
        self.conn.execute(
            "UPDATE sleep_claims SET layer=?, review_state=?, updated_at=? "
            "WHERE proposal_id=? AND layer='candidate'", (layer, review_state, now, proposal_id))
        self.conn.execute(
            "UPDATE sleep_deps SET layer=? WHERE proposal_id=? AND layer='candidate'",
            (layer, proposal_id))

    def publish_claims(
        self, proposal_id: str, accepted: list[Claim], superseded_ids: list[str], now: str,
    ) -> None:
        """Кандидаты -> принятое (единственный путь): каждое утверждение обязано быть кандидатом
        этого предложения; прежние принятые ревизии того же ``claim_id`` и заменяемые
        утверждения уходят в ``superseded`` (история остается)."""
        for c in accepted:
            c = strip_claim(c)
            cur = self.conn.execute(
                "UPDATE sleep_claims SET layer='accepted', review_state='accepted', body_json=?, "
                "fingerprint=?, updated_at=? WHERE proposal_id=? AND claim_id=? AND revision=? "
                "AND layer='candidate'",
                (_dumps(c.to_dict()), claim_fingerprint(c), now, proposal_id, c.claim_id,
                 c.revision))
            if cur.rowcount != 1:
                raise LedgerError("candidate_missing",
                                  f"кандидат {c.claim_id} r{c.revision} предложения "
                                  f"{proposal_id} не найден")
            self.conn.execute(
                "UPDATE sleep_claims SET layer='superseded', review_state='superseded', "
                "updated_at=? WHERE claim_id=? AND revision<? AND layer='accepted'",
                (now, c.claim_id, c.revision))
        for cid in superseded_ids:
            self.conn.execute(
                "UPDATE sleep_claims SET layer='superseded', review_state='superseded', "
                "updated_at=? WHERE claim_id=? AND layer='accepted'", (now, cid))
        self.conn.execute(
            "UPDATE sleep_deps SET layer='accepted' WHERE proposal_id=? AND layer='candidate'",
            (proposal_id,))

    # --- применение: намерение, состояние, журнал ------------------------------------------ #
    def apply_row(self, proposal_id: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM sleep_apply WHERE proposal_id=?", (proposal_id,)).fetchone()
        return dict(row) if row else None

    def apply_rows(self, states: tuple[str, ...]) -> list[dict[str, Any]]:
        marks = ",".join("?" for _ in states)
        rows = self.conn.execute(
            f"SELECT * FROM sleep_apply WHERE state IN ({marks}) ORDER BY started_at, proposal_id",  # noqa: S608
            states)
        return [dict(r) for r in rows]

    def put_apply(self, proposal_id: str, revision: int, now: str, **cols: Any) -> None:
        """Намерение применения (INSERT OR REPLACE одной строкой на предложение)."""
        names = ["proposal_id", "proposal_revision", "started_at", "updated_at", *cols]
        marks = ",".join("?" for _ in names)
        self.conn.execute(
            f"INSERT OR REPLACE INTO sleep_apply({','.join(names)}) VALUES ({marks})",  # noqa: S608
            (proposal_id, revision, now, now, *cols.values()))

    def set_apply(self, proposal_id: str, now: str, **cols: Any) -> None:
        allowed = {"state", "stage", "index_state", "receipt_json", "effects_json", "error",
                   "holder", "attempts", "finished_at"}
        bad = set(cols) - allowed
        if bad:
            raise LedgerError("bad_column", f"нельзя менять {sorted(bad)}")
        sets = ", ".join(f"{k}=?" for k in cols)
        self.conn.execute(
            f"UPDATE sleep_apply SET {sets}, updated_at=? WHERE proposal_id=?",  # noqa: S608
            (*cols.values(), now, proposal_id))

    def log_apply(self, proposal_id: str, event: str, state: str, detail: str, now: str) -> None:
        self.conn.execute(
            "INSERT INTO sleep_apply_log(proposal_id, at, event, state, detail) VALUES (?,?,?,?,?)",
            (proposal_id, now, event, state, detail[:500]))

    def apply_log(self, proposal_id: str) -> list[dict[str, Any]]:
        return [dict(r) for r in self.conn.execute(
            "SELECT at, event, state, detail FROM sleep_apply_log WHERE proposal_id=? "
            "ORDER BY log_id", (proposal_id,))]

    # --- заметки ledger -------------------------------------------------------------------- #
    def note_row(self, note_rel: str) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT * FROM sleep_notes WHERE note_rel=?", (note_rel,)).fetchone()
        return dict(row) if row else None

    def note_of_claim(self, claim_id: str) -> str | None:
        row = self.conn.execute(
            "SELECT note_rel FROM sleep_note_claims WHERE claim_id=?", (claim_id,)).fetchone()
        return str(row["note_rel"]) if row else None

    def put_note(self, note_rel: str, note_id: str, sha: str, claim_ids: list[str],
                 now: str) -> None:
        self.conn.execute(
            "INSERT INTO sleep_notes(note_rel, note_id, note_sha, seq, updated_at) "
            "VALUES (?,?,?,1,?) ON CONFLICT(note_rel) DO UPDATE SET note_id=excluded.note_id, "
            "note_sha=excluded.note_sha, seq=sleep_notes.seq+1, updated_at=excluded.updated_at",
            (note_rel, note_id, sha, now))
        for cid in claim_ids:
            self.conn.execute(
                "INSERT OR REPLACE INTO sleep_note_claims(claim_id, note_rel) VALUES (?,?)",
                (cid, note_rel))

    # --- снимок для валидатора ------------------------------------------------------------- #
    def ledger_snapshot(
        self, p: Proposal | None, *, now: str,
        source_hash: Callable[[str], str | None] | None = None,
        entity_exists: Callable[[str], bool] | None = None,
    ) -> Ledger:
        """Снимок реестра для ``validate_proposal``: действующие принятые ревизии (только то, что
        относится к предложению и его теме - не весь ledger), существующие сущности, актуальные
        хеши источников, связанные предложения (повторы отказов, snooze, конфликт ключа)."""
        if p is None:
            return Ledger(claims=self.accepted_claims(), now=now)
        wanted = _proposal_refs(p)
        claims = self.accepted_claims(wanted)
        for _ in range(_CLOSURE_CAP):  # замыкание по посылкам/зависимостям/основаниям
            more = {r for c in claims.values() for r in _claim_refs(c)} - set(claims)
            more = {r for r in more if r}
            if not more:
                break
            loaded = self.accepted_claims(more)
            if not loaded:
                break
            claims.update(loaded)
        topics = {topic_key(c) for c in p.after.claims}
        for cid, c in self.accepted_by_topic(topics).items():
            claims.setdefault(cid, c)
        entities = frozenset(
            ref for ref in _entity_refs(p) if entity_exists is not None and entity_exists(ref))
        sources: dict[str, str] = {}
        if source_hash is not None:
            ev = [e for c in p.after.claims for e in c.evidence]
            ev += [e for link in p.after.links for e in link.evidence]
            for e in ev:
                cur = source_hash(e.source_id)
                if cur:
                    sources[e.source_id] = cur
        return Ledger(claims=claims, entities=entities, sources=sources,
                      decided=self.related_proposals(p), now=now)

    # --- сводки (доктор, статус) ----------------------------------------------------------- #
    def summary(self) -> dict[str, Any]:
        c = self.conn
        one = lambda sql, *a: int(c.execute(sql, a).fetchone()[0])  # noqa: E731
        last = c.execute("SELECT MAX(finished_at) FROM sleep_apply WHERE state='applied'"
                         ).fetchone()[0]
        return {
            "candidates": one("SELECT COUNT(*) FROM sleep_proposals WHERE review_state IN "
                              "('draft','ready','pending','snoozed')"),
            "pending": one("SELECT COUNT(*) FROM sleep_proposals WHERE review_state='pending'"),
            "accepted_claims": one("SELECT COUNT(*) FROM sleep_accepted_claims"),
            "proposals": one("SELECT COUNT(*) FROM sleep_proposals"),
            "decisions": one("SELECT COUNT(*) FROM sleep_decisions"),
            "conflict": one("SELECT COUNT(*) FROM sleep_apply WHERE state='conflict'"),
            "recovering": one("SELECT COUNT(*) FROM sleep_apply WHERE state IN "
                              "('prepared','applying','recovering','failed')"),
            "index_pending": one("SELECT COUNT(*) FROM sleep_apply WHERE state='applied' AND "
                                 "index_state<>'done'"),
            "needs_check": one("SELECT COUNT(*) FROM sleep_accepted_claims WHERE needs_check=1"),
            "last_applied": last or "",
            "runs": one("SELECT COUNT(*) FROM sleep_runs"),
        }

    # --- исчезнувший источник -------------------------------------------------------------- #
    def mark_source_unavailable(self, source_id: str, now: str) -> dict[str, int]:
        """Источник исчез: основание помечается недоступным, зависимые принятые утверждения - для
        проверки. Историю НЕ стираем и принятое не откатываем (sleep-1.md §6.3)."""
        c = self.conn
        with self.tx(immediate=True):
            ev = c.execute(
                "UPDATE sleep_evidence SET available=0, unavailable_at=? WHERE source_id=? "
                "AND available=1", (now, source_id)).rowcount
            rows = c.execute(
                "SELECT DISTINCT claim_row, claim_id FROM sleep_evidence WHERE source_id=?",
                (source_id,)).fetchall()
            marked: set[str] = set()
            for r in rows:
                n = c.execute(
                    "UPDATE sleep_claims SET needs_check=1, needs_check_reason=?, updated_at=? "
                    "WHERE row_id=? AND layer='accepted'",
                    (f"source_unavailable:{source_id}", now, r["claim_row"])).rowcount
                if n:
                    marked.add(r["claim_id"])
            frontier = set(marked)
            while frontier:  # зависимые по посылкам/зависимостям/основаниям-ссылкам
                nxt: set[str] = set()
                for cid in frontier:
                    deps = c.execute(
                        "SELECT owner_ref FROM sleep_deps WHERE target_ref=? AND rel IN "
                        "('depends_on','premise','derived_from') AND layer='accepted'",
                        (f"claim:{cid}",)).fetchall()
                    for d in deps:
                        owner = str(d["owner_ref"]).removeprefix("claim:")
                        if owner in marked:
                            continue
                        n = c.execute(
                            "UPDATE sleep_claims SET needs_check=1, needs_check_reason=?, "
                            "updated_at=? WHERE claim_id=? AND layer='accepted'",
                            (f"dependency_needs_check:{cid}", now, owner)).rowcount
                        if n:
                            marked.add(owner)
                            nxt.add(owner)
                frontier = nxt
        return {"evidence": int(ev), "claims": len(marked)}
