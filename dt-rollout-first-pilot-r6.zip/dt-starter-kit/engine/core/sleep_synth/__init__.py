"""SLEEP-SYNTH-1: bounded host-driven synthesis; only the owner accepts memory."""
