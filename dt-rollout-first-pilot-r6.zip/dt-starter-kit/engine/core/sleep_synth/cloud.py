"""Cloud authorization and conservative daily reservations for scheduled Sleep."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from urllib.parse import urlsplit

from core.file_lock import file_lock
from core.note_writer import NoteWriteError, sha256_bytes, write_note_atomic
from core.operational import ai_gateway as gateway
from core.sleep_synth.store import SynthError, digest

_MICRO = 1_000_000
_MAX_MONEY = 2**53 - 1
_BILLING_FILE = "sleep-cloud-budget.json"
_FIELDS = frozenset({"recipient", "daily_usd_micros", "input_per_million_usd_micros",
                     "output_per_million_usd_micros"})


@dataclass(frozen=True)
class Grant:
    recipient: str
    daily_usd_micros: int
    input_per_million_usd_micros: int
    output_per_million_usd_micros: int

    @classmethod
    def parse(cls, raw: dict) -> Grant:
        if (not isinstance(raw, dict) or raw.keys() != _FIELDS
                or not isinstance(raw["recipient"], str)
                or not re.fullmatch(r"[0-9a-f]{64}", raw["recipient"])
                or any(type(raw[k]) is not int or not 0 < raw[k] <= _MAX_MONEY
                       for k in _FIELDS - {"recipient"})):
            raise SynthError(
                "sleep_cloud_settings", "Нужны получатель, дневной лимит и оба тарифа в USD",
            )
        return cls(**raw)


def recipient(route: gateway.Resolved, scope: str) -> dict | None:
    """Bind confirmation to the resolved recipient and to one hub."""
    if not route.profile or not route.model or route.provider not in ("openai", "anthropic"):
        return None
    base = gateway.validate_url(route.url, route.provider)
    url = base or gateway.ANTHROPIC_HOST_URL
    if gateway.url_is_local(url) or urlsplit(url).scheme != "https":
        return None
    if "\\" in url:
        return None
    _ = urlsplit(url).port  # Reject invalid port syntax before recording a recipient.
    from core.operational.ai_layer import messages_endpoint

    endpoint = messages_endpoint(route.provider, base)
    fields = {"provider": route.provider, "model": route.model, "profile": route.profile,
              "endpoint": endpoint, "scope": scope}
    # Consent for the former dossier-only protocol must be requested again.
    fields["data_scope"] = "dossier_and_verified_hub_claims"
    return {**fields, "id": digest([fields, route.key_file])}


def _path(ctx) -> Path:
    path = Path(ctx.vault).resolve() / "_system" / _BILLING_FILE
    if path.resolve() != path:
        raise SynthError("sleep_cloud_budget_state", "Журнал резерва расходов недоступен")
    return path


def _ledger(path: Path, day: date) -> tuple[int, str | None]:
    try:
        if path.is_symlink():
            raise ValueError
        with path.open("rb") as stream:
            raw = stream.read(2049)
        if len(raw) > 2048:
            raise ValueError
        data = json.loads(raw)
        if not isinstance(data, dict) or set(data) != {"day", "reserved_usd_micros"}:
            raise ValueError
        saved_day = date.fromisoformat(data["day"])
        used = data["reserved_usd_micros"]
        if type(used) is not int or used < 0 or saved_day > day:
            raise ValueError
    except FileNotFoundError:
        return 0, None
    except (OSError, TypeError, KeyError, ValueError) as exc:
        raise SynthError("sleep_cloud_budget_state", "Журнал резерва расходов недоступен") from exc
    return (used if saved_day == day else 0), sha256_bytes(raw)


def reserved(ctx) -> int:
    return _ledger(_path(ctx), date.fromisoformat(ctx.stamp()[:10]))[0]


def reserve(ctx, grant: Grant, body: dict, output_tokens: int) -> None:
    """Reserve before send, including failed calls. Use the serialized bytes plus framing margin."""
    units = (len(json.dumps(body).encode("ascii")) + 1024) * grant.input_per_million_usd_micros
    units += output_tokens * grant.output_per_million_usd_micros
    cost = (units + _MICRO - 1) // _MICRO
    path = _path(ctx)
    day = date.fromisoformat(ctx.stamp()[:10])
    with file_lock(path):
        used, before = _ledger(path, day)
        total = used + cost
        if total > grant.daily_usd_micros:
            raise SynthError("sleep_cloud_budget", "Дневной резерв расходов Сна исчерпан")
        try:
            write_note_atomic(
                Path(ctx.vault), "_system/" + path.name,
                json.dumps({"day": day.isoformat(), "reserved_usd_micros": total}),
                expect_sha=before, allowed_prefix="_system/",
            )
        except (OSError, NoteWriteError) as exc:
            raise SynthError(
                "sleep_cloud_budget_state", "Не удалось записать резерв расходов",
            ) from exc
