"""One bounded scheduled Sleep tick. Workflows publish candidates, never accept them."""

from __future__ import annotations

import json
import os
import sqlite3
import tempfile
import time
from dataclasses import asdict, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Protocol
from zoneinfo import ZoneInfo

from core.config import dt_db_path
from core.file_lock import file_lock
from core.sleep.fence import pipeline_scope
from core.sleep_input import ops as input_ops
from core.sleep_input.store import InputStore
from core.sleep_synth import schedule
from core.sleep_synth.ops import dispatch
from core.sleep_synth.store import MAX_SCHEDULED_FINDINGS, Store, SynthError, digest
from core.sleep_synth.verify import SCHEDULED_HOST, table_exists, validate_pins

_HOST = SCHEDULED_HOST
_MAX_ATTEMPTS = 2
_WORK_SECONDS = 15 * 60


class Executor(Protocol):
    model: str

    def extract(self, dossiers: list[dict], templates: list[dict]) -> dict: ...

    def review(self, dossiers: list[dict], drafts: list[dict], comparisons: list[dict]) -> dict: ...


def _failure(code: str, reason: str) -> dict:
    return {"ok": False, "code": code, "error": reason}


def _step(ctx, action, run, **params):
    item = params.pop("item", None)
    result = dispatch(ctx, action, run, params, item=item)
    if not result["ok"]:
        raise SynthError(result["code"], result["error"])
    return result


def _date(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _state_path(ctx) -> Path:
    return Path(ctx.db_path or dt_db_path()).resolve().with_name(schedule.STATE_FILENAME)


def _read_state(path: Path) -> dict:
    if path.is_symlink():
        raise SynthError("sleep_schedule_state", "История расписания недоступна")
    try:
        with path.open("rb") as stream:
            data = json.loads(stream.read(8193))
    except FileNotFoundError:
        return {}
    if not isinstance(data, dict):
        raise SynthError("sleep_schedule_state", "История расписания повреждена")
    return data


def _write_state(path: Path, state: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    stream = tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False)
    temp = Path(stream.name)
    try:
        with stream:
            json.dump(state, stream, ensure_ascii=False)
            stream.flush()
            os.fsync(stream.fileno())
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def status(ctx, *, readiness=None) -> dict:
    from core.sleep_synth import cloud
    from core.sleep_synth.executor import cloud_destination

    try:
        cfg, version = schedule.load(ctx.vault)
        dest = None if cfg.cursor else cloud_destination(ctx.vault, cfg.scope)
        reserved, budget_error = 0, None
        if dest or cfg.cloud:
            try:
                reserved = cloud.reserved(ctx)
            except SynthError as exc:
                reserved, budget_error = None, exc.code
        return {
            "ok": True,
            "profile": asdict(cfg),
            "version": version,
            "last": _read_state(_state_path(ctx)),
            "cloud_destination": dest,
            "cloud_authorized": bool(
                cfg.mode == "scheduled" and dest and cfg.cloud
                and cfg.cloud["recipient"] == dest["id"]
            ),
            "cloud_reserved_usd_micros": reserved,
            "cloud_budget_error": budget_error,
            "cursor_model": _cursor_model(cfg),
            **({"schedule_setup": _setup(ctx, readiness)} if readiness else {}),
        }
    except (SynthError, ValueError, OSError, sqlite3.Error) as exc:
        return _failure(getattr(exc, "code", "sleep_schedule_unavailable"), str(exc))


def _cursor_model(cfg):
    from core.sleep_synth.cursor_runner import MODEL

    return MODEL if cfg.cursor else None


def configure(ctx, settings: dict, expected_version: str, *, readiness=None) -> dict:
    try:
        if isinstance(settings, dict) and "activate" in settings:
            if settings.keys() != {"activate"}:
                raise SynthError("sleep_schedule_invalid", "Укажите параметры расписания отдельно")
            settings = _activation(ctx, settings["activate"], readiness)
        return schedule.save(ctx.vault, settings, expected_version)
    except (SynthError, ValueError, OSError, sqlite3.Error) as exc:
        return _failure(getattr(exc, "code", "sleep_schedule_unavailable"), str(exc))


def _legacy_pilot_matches(ctx, conn, run_id: str, scope: str) -> bool:
    """A curated notes pilot may seed a hub only when its accepted claims name that hub."""
    from core.privacy import any_nda
    from core.vault import read_note, resolve_note_path

    if not scope.startswith("hub:"):
        return False
    hub_id = scope.removeprefix("hub:")
    if not schedule.is_hub_scope(scope):
        return False
    path = resolve_note_path(hub_id, vault_path=ctx.vault)
    if path is None or any_nda(path):
        return False
    hub = read_note(path, ctx.vault)
    if hub.type != "hub" or hub.id != hub_id:
        return False
    aliases = hub.frontmatter.get("aliases") or []
    if isinstance(aliases, str):
        aliases = [aliases]
    names = {name.strip().casefold() for name in [hub.id, *aliases] if isinstance(name, str)}
    rows = conn.execute(
        """SELECT p.body_json FROM sleep_proposals p WHERE p.run_id=?
           AND p.review_state='accepted' AND p.apply_state='applied'""", (run_id,),
    )
    found = False
    for (body,) in rows:
        claims = json.loads(body).get("after", {}).get("claims", [])
        if not claims or any(str(c.get("area") or "").strip().casefold() not in names
                             for c in claims):
            return False
        found = True
    return found


def _approved_pilots(
    ctx, gate: dict, run_id: str | None = None, bind_scope: str = "",
) -> list[dict]:
    if not gate.get("ready") or not gate.get("sha"):
        return []
    store = InputStore.open_readonly(ctx.db_path)
    if store is None:
        return []
    try:
        if not table_exists(store.conn, "sleep_synth_sessions"):
            return []
        rows = store.conn.execute(
            """SELECT s.run_id,s.updated_at,r.scope FROM sleep_synth_sessions s
                   JOIN sleep_runs r ON s.run_id=r.run_id
                   WHERE s.state='completed' AND s.host<>?
                   AND (r.scope GLOB 'hub:*' OR (? AND r.scope GLOB 'notes:*'))
                   AND json_extract(s.data_json, '$.evaluation_gate.sha')=?
                   AND (? IS NULL OR s.run_id=?)
                   AND EXISTS (
                     SELECT 1 FROM sleep_proposals p WHERE p.run_id=s.run_id
                     AND p.review_state='accepted' AND p.apply_state='applied'
                   ) ORDER BY s.updated_at DESC,s.run_id DESC LIMIT 50""",
            (_HOST, bool(run_id and bind_scope), gate["sha"], run_id, run_id),
        )
        pilots = []
        for row in rows:
            pilot = dict(row)
            if pilot["scope"].startswith("notes:"):
                if not _legacy_pilot_matches(ctx, store.conn, pilot["run_id"], bind_scope):
                    continue
                pilot["scope"] = bind_scope
            if not bind_scope or pilot["scope"] == bind_scope:
                pilots.append(pilot)
        return pilots
    finally:
        store.close()

def _setup(ctx, readiness) -> dict:
    gate = readiness(ctx.vault)
    return {
        "ready": bool(gate.get("ready")),
        "pilots": _approved_pilots(ctx, gate),
    }


def _activation(ctx, values: dict, readiness) -> dict:
    fields = {"pilot_run_id", "timezone", "start_hour", "end_hour", "resources_confirmed"}
    if (not isinstance(values, dict) or not fields <= values.keys() <= fields | {"scope"}
            or not isinstance(values.get("scope", ""), str)
            or not isinstance(values["pilot_run_id"], str) or not values["pilot_run_id"]):
        raise SynthError("sleep_schedule_invalid", "Выберите пилот, окно и проверьте ресурсы")
    gate = readiness(ctx.vault) if readiness else {}
    pilots = _approved_pilots(ctx, gate, values["pilot_run_id"], values.get("scope", ""))
    if not pilots:
        raise SynthError(
            "sleep_schedule_gate", "Нужен принятый пилот на текущем контрольном наборе",
        )
    return {
        **values, "scope": pilots[0]["scope"], "assessment_sha": gate["sha"],
        "mode": "scheduled", "paused": True, "cloud": None, "cursor": None,
    }


def _approval(ctx, cfg: schedule.Schedule, gate: dict) -> None:
    if not gate.get("ready") or gate.get("sha") != cfg.assessment_sha:
        raise SynthError(
            "sleep_schedule_gate", "Версия замороженного набора изменена или не готова"
        )
    pilots = _approved_pilots(ctx, gate, cfg.pilot_run_id, cfg.scope)
    if not pilots or pilots[0]["scope"] != cfg.scope:
        raise SynthError("sleep_schedule_gate", "Пилот ждет принятого результата в этой области")


def _queue(ctx, *, proposal_ids: list[str] | None = None) -> None:
    from core.decisions.flow import budgets

    limit = budgets().get("memory")
    if not limit:
        raise SynthError("sleep_queue_budget", "Нужен конечный ненулевой бюджет очереди")
    now = _date(ctx.stamp())
    monday = now.date().toordinal() - now.weekday()
    week = now.date().fromordinal(monday).isoformat()
    store = InputStore.open_readonly(ctx.db_path)
    if store is None:
        return
    try:
        if not table_exists(store.conn, "sleep_proposals"):
            return
        queued = {
            row[0] for row in store.conn.execute(
                """SELECT proposal_id FROM sleep_proposals
                   WHERE created_at>=? OR review_state IN ('pending','snoozed')""",
                (week,),
            )
        }
        # A publication retried after writing some cards must not count those cards twice.
        count = len(queued) + 1 if proposal_ids is None else len(queued.union(proposal_ids))
        if count > limit:
            raise SynthError("sleep_queue_budget", "Очередь предложений Сна достигла бюджета")
    finally:
        store.close()


def _guard(ctx, version: str, deadline: float, *, publishing: list[str] | None = None) -> None:
    cfg, actual = schedule.load(ctx.vault)
    if actual != version or cfg.paused or cfg.mode != "scheduled":
        raise SynthError("sleep_schedule_paused", "Настройка изменена или расписание на паузе")
    now = _date(ctx.stamp()).astimezone(ZoneInfo(cfg.timezone))
    if not cfg.start_hour <= now.hour < cfg.end_hour:
        raise SynthError("sleep_schedule_window", "Допустимое окно закончилось, хвост сохранен")
    if time.monotonic() > deadline:
        raise SynthError("sleep_schedule_budget", "Достигнут лимит времени, хвост сохранен")
    if publishing is not None:
        _queue(ctx, proposal_ids=publishing)


def _unfinished(ctx, run: str):
    store = Store.readonly(ctx.db_path or dt_db_path())
    try:
        row = store.session(run)
        if not row:
            return None
        return next(
            (
                (bid, batch)
                for bid, batch in row["data"]["batches"].items()
                if batch["stage"] not in ("published", "rejected")
            ),
            None,
        )
    finally:
        store.close()


def _first_portions(ctx, run, token, limit):
    store = InputStore.open_readonly(ctx.db_path)
    try:
        work = store.worklist(run, ("queued",))[:limit]
    finally:
        store.close()
    return [_step(ctx, "read", run, session=token, item=w["item_id"]) for w in work]


def _one_batch(ctx, cfg, version, deadline, run, token, executor):
    existing = _unfinished(ctx, run)
    if existing:
        bid, batch = existing
        phase = batch["stage"]
        dossiers = validate_pins(ctx, batch["pins"]) if phase == "submitted" else []
        drafts, comparisons = batch["drafts"], batch["comparisons"]
        publish_ids = [p["proposal_id"] for p in batch.get("proposals") or []]
    else:
        packets = _first_portions(ctx, run, token, cfg.items)
        if not packets:
            raise SynthError(
                "sleep_schedule_empty_worklist", "Нет доступных позиций для продолжения"
            )
        dossiers = [p["dossier"] for p in packets]
        receipts = [p["receipt_id"] for p in packets]
        _guard(ctx, version, deadline)
        extracted = executor.extract(dossiers, [p["draft_template"] for p in packets])
        _guard(ctx, version, deadline)
        candidates = extracted.get("candidates") if isinstance(extracted, dict) else None
        if not isinstance(candidates, list) or any(
            not isinstance(p, dict)
            or p.get("operation") not in ("add", "amend", "relate", "supersede")
            or not isinstance(p.get("after"), dict)
            for p in candidates
        ):
            raise SynthError("sleep_provider_format", "Нужны самостоятельные предложения Сна")
        step = _step(
            ctx,
            "submit",
            run,
            session=token,
            receipts=receipts,
            key=digest(receipts),
            candidates=candidates,
            reason=extracted.get("reason", ""),
            model=executor.model,
        )
        bid, phase = step["batch_id"], step["stage"]
        batch = step
        drafts, comparisons = step["drafts"], step["comparisons"]
    if phase == "submitted":
        _guard(ctx, version, deadline)
        reviewed = (
            executor.review(dossiers, drafts, comparisons)
            if drafts
            else {
                "reviews": [],
                "reason": ("Находки отклонены на проверке оснований"
                           if batch.get("precheck_rejections")
                           else "Извлечение не предложило изменений"),
            }
        )
        if not isinstance(reviewed, dict):
            raise SynthError("sleep_provider_format", "Ожидается рецензия JSON")
        _guard(ctx, version, deadline)
        review = _step(
            ctx,
            "review",
            run,
            session=token,
            batch_id=bid,
            reviews=reviewed.get("reviews"),
            link_reviews=reviewed.get("link_reviews", []),
            reason=reviewed.get("reason", ""),
            reviewer=executor.model,
        )
        phase = review["stage"]
        publish_ids = review["publish_ids"]
    if phase != "rejected":
        with file_lock(ctx.vault / schedule.PROFILE):
            _guard(ctx, version, deadline, publishing=publish_ids)
            _step(ctx, "publish", run, session=token, batch_id=bid)
    return _step(ctx, "report", run)


def tick(ctx, *, executor: Executor | None = None, signals=None, readiness=None) -> dict:
    """Run with readiness metadata supplied by the caller, outside the model pipeline."""
    try:
        cfg, version = schedule.load(ctx.vault)
        if cfg.mode != "scheduled" or cfg.paused:
            return {"ok": True, "state": "paused" if cfg.paused else cfg.mode}
        now = _date(ctx.stamp()).astimezone(ZoneInfo(cfg.timezone))
        if not cfg.start_hour <= now.hour < cfg.end_hour:
            return {"ok": True, "state": "outside_window"}
        path = _state_path(ctx)
        with file_lock(path):
            return _tick_locked(
                ctx, cfg, version, now.date().isoformat(), path, executor, signals, readiness
            )
    except (SynthError, ValueError, OSError, sqlite3.Error, TypeError, KeyError) as exc:
        return _failure(getattr(exc, "code", "sleep_schedule_unavailable"), str(exc))


def _tick_locked(ctx, cfg, version, slot, path, executor, signals, readiness):
    deadline = time.monotonic() + _WORK_SECONDS
    _guard(ctx, version, deadline)
    state = _read_state(path)
    if state.get("day") == slot:
        if state.get("state") in ("finished", "nothing_new"):
            return {"ok": True, "state": "already_ran", "run_id": state.get("run_id")}
        if state.get("attempts", 0) >= _MAX_ATTEMPTS:
            raise SynthError(
                "sleep_schedule_attempts", "Лимит попыток окна исчерпан, хвост сохранен"
            )
    gate = readiness(ctx.vault) if readiness else {}
    _approval(ctx, cfg, gate)
    ctx = replace(ctx, host=_HOST, extra={"synthesis_gate": gate, "schedule_scope": cfg.scope})
    # The confirmed settings can be paused/resumed without committing a second pipeline.
    payload = asdict(cfg)
    payload.pop("paused")
    payload.pop("cloud")
    payload.pop("cursor")
    cfg_digest = digest(payload)
    run = state.get("run_id") if state.get("state") != "nothing_new" else None
    if run:
        report = _step(ctx, "report", run)
        if report.get("state") == "completed" or (
            report.get("state") == "partial" and not report.get("worklist", {}).get("queued")
        ):
            run = None
        elif state.get("config_digest") != cfg_digest:
            raise SynthError(
                "sleep_schedule_changed", "Настройка изменилась, прежний хвост сохранен"
            )
        elif report.get("lease_active"):
            return {"ok": True, "state": "leased", "run_id": run}
    prior = _unfinished(ctx, run) if run and report.get("present") else None
    retrying_publish = prior and prior[1]["stage"] == "publishing"
    if not retrying_publish:
        _queue(ctx)
    if executor is None:
        from core.sleep_synth.executor import ScheduledExecutor

        executor = ScheduledExecutor(ctx, cfg)

    attempts = state.get("attempts", 0) + 1 if state.get("day") == slot else 1
    state = {
        "day": slot,
        "attempts": attempts,
        "state": "running",
        "run_id": run,
        "config_digest": cfg_digest,
        "at": ctx.stamp(),
    }
    _write_state(path, state)
    token = None
    try:
        if run is None:
            with pipeline_scope():
                plan = input_ops.plan(
                    ctx,
                    scope=cfg.scope,
                    apply=True,
                    signals=signals,
                    budgets={"items": cfg.items, "per_hub": cfg.items, "seconds": 120},
                )
            if not plan["ok"]:
                raise SynthError(plan["code"], plan["error"])
            run = plan.get("run_id")
            if not plan["manifest"]:
                if plan["tail"] or not plan["scan"]["complete"]:
                    raise SynthError("sleep_schedule_tail", "План пока не завершен")
                state.update(state="nothing_new")
                _write_state(path, state)
                return {"ok": True, "state": "nothing_new"}
            state["run_id"] = run
            _write_state(path, state)
        report = _step(ctx, "report", run)
        if report.get("state") == "completed":
            state.update(state="finished")
            _write_state(path, state)
            return {"ok": True, "state": "finished", "run_id": run, "report": report}
        if report.get("present"):
            token = _step(ctx, "resume", run)["session"]
        else:
            token = _step(
                ctx, "start", run, max_candidates=MAX_SCHEDULED_FINDINGS,
                max_chars=cfg.max_chars,
            )["session"]
        with pipeline_scope():
            report = _one_batch(ctx, cfg, version, deadline, run, token, executor)
        if report.get("state") == "running":
            _step(ctx, "cancel", run, session=token)
        state.update(state="finished", run_id=run)
        _write_state(path, state)
        return {"ok": True, "state": "finished", "run_id": run, "report": report}
    except (SynthError, ValueError, OSError, sqlite3.Error, TypeError, KeyError) as exc:
        if token:
            dispatch(ctx, "cancel", run, {"session": token})
        if getattr(exc, "code", "") == "synth_budget":
            # The planner carries remaining source revisions into a fresh run tomorrow.
            state.update(run_id=None, tail_run_id=run)
        state.update(state="failed", code=getattr(exc, "code", "sleep_schedule_unavailable"))
        _write_state(path, state)
        raise
