"""Normalize model drafts against actual packets; no model-supplied check marks survive."""

from __future__ import annotations

import re
from dataclasses import replace
from datetime import date

from core.sleep.compare import CompareResult, classify, same_value
from core.sleep.contract import (
    Check,
    CheckRecord,
    ClaimType,
    Coverage,
    Evidence,
    EvidenceRole,
    LinkType,
    Operation,
    PipelineCheck,
    PipelineStep,
    Privacy,
    ReviewState,
    Snapshot,
    SourceKind,
    Target,
    claim_fingerprint,
    evidence_digest,
    proposal_from_dict,
)
from core.sleep.validate import CODE_NUMBER_NOT_IN_FRAGMENT, Policy, validate_proposal
from core.sleep_store.propose import default_entity_exists
from core.sleep_synth.store import SynthError, digest
from core.sleep_synth.verify import verify_scheduled_targets

NUMBERS = re.compile(r"(?<![\w])\d+(?:[.,]\d+)?")


def prepare(ctx, store, raw: dict, dossiers: list[dict], rid: str, key: str, index: int):
    p = proposal_from_dict(raw)
    if (
        p.decision_receipt
        or p.apply_state.value != "none"
        or p.effects
        or p.checks
        or p.review_state not in (ReviewState.DRAFT, ReviewState.READY)
    ):
        raise SynthError("synth_self_approval", "Модель передает черновик без решений и проверок")
    segments = {}
    facts = set()
    for d in dossiers:
        for f in (d.get("facts") or {}).get("items", []):
            facts.add(str(f["fact_id"]))
        for s in d["segments"]:
            segments[(d["source"]["source_id"], s["locator"])] = (d, s)

    def evidence(e):
        pair = segments.get((e.source_id, e.locator))
        if not pair:
            raise SynthError("synth_unread_evidence", "Основание вне прочитанных порций")
        d, s = pair
        if (e.fragment and e.fragment != s["text"]) or (
            e.fragment_fingerprint and e.fragment_fingerprint != s["fingerprint"]
        ):
            raise SynthError("synth_fragment", "Цитата не совпадает с прочитанным фрагментом")
        if s.get("suspect_instruction"):
            raise SynthError(
                "synth_instruction", "Фрагмент с инструкцией требует отдельного разбора"
            )
        if e.revision not in (0, d["source"]["revision"]) or (
            e.content_hash and e.content_hash != d["versions"]["actual_hash"]
        ):
            raise SynthError("source_changed", "Основание относится к другой версии")
        # Experience does not become original evidence just because a model says so.
        kind = (
            SourceKind.MODEL_OUTPUT if d["source"]["kind"] == "experience" else SourceKind.ORIGINAL
        )
        return Evidence(
            source_id=e.source_id,
            role=e.role,
            revision=d["source"]["revision"],
            content_hash=d["versions"]["actual_hash"],
            locator=e.locator,
            fragment_fingerprint=s["fingerprint"],
            fragment=s["text"],
            source_kind=kind,
            origin_id=d["source"]["origin_id"] or d["source"]["family_id"],
            privacy=Privacy.WORK,
            source_path=d["source"]["locator"],
            coverage=Coverage(d["coverage"]["state"]),
            coverage_scope=d["negative_scope"]["area"],
            ocr_ambiguous=bool(d["coverage"].get("ocr_ambiguous")),
            derived_from=e.derived_from,
        )

    claims = []
    for c in p.after.claims:
        if (
            c.checks
            or c.decisions
            or c.history
            or c.review_state not in (ReviewState.DRAFT, ReviewState.READY)
            or c.type is ClaimType.OWNER_DECISION
        ):
            raise SynthError(
                "synth_self_approval", "Модель не подтверждает факт и не решает за владельца"
            )
        ev = tuple(evidence(e) for e in c.evidence)
        if c.negative:
            scopes = {e.coverage_scope for e in ev}
            if c.search_scope not in scopes:
                raise SynthError(
                    "synth_negative_scope", "Отрицание ограничивается прочитанной областью"
                )
        # Every number in the assertion (not just its object) must be present in support.
        support = " ".join(e.fragment for e in ev if e.role is EvidenceRole.SUPPORT)
        wanted = set(NUMBERS.findall(c.statement + " " + c.object))
        have = set(NUMBERS.findall(support))
        if {n.replace(",", ".") for n in wanted} - {n.replace(",", ".") for n in have}:
            raise SynthError(
                CODE_NUMBER_NOT_IN_FRAGMENT,
                "В указанном фрагменте источника нет числа из утверждения",
            )
        for effective in (c.valid_from, c.valid_to):
            dates = {d["source"].get("valid_date", "")[:10] for d in dossiers}
            human = ".".join(reversed(effective.split("-"))) if effective else ""
            if (effective and effective not in dates and effective not in support
                    and human not in support):
                raise SynthError("synth_date", "Дата действия не найдена в основании")
        if c.unit and c.unit.casefold() not in support.casefold():
            raise SynthError("synth_unit", "Единица утверждения отсутствует в основании")
        if any(f.fact_id not in facts or f.fact_key for f in c.fact_refs):
            raise SynthError("synth_fact", "Ссылка на точное значение не показана в досье")
        c = replace(
            c,
            evidence=ev,
            review_state=ReviewState.DRAFT,
            run_id=rid,
            recorded_at=ctx.stamp(),
            fingerprint="",
        )
        fp = claim_fingerprint(c)
        checks = tuple(
            CheckRecord(
                k,
                fp,
                ctx.stamp(),
                "engine:" + VERSION_LABEL,
                ("Сверены прочитанные порции и точные локаторы",),
            )
            for k in (Check.LOCATED, Check.MECHANICALLY_CHECKED)
        )
        claims.append(replace(c, fingerprint=fp, checks=checks))
    links = tuple(
        replace(link, evidence=tuple(evidence(e) for e in link.evidence), run_id=rid)
        for link in p.after.links
    )
    if ctx.extra.get("schedule_scope"):
        p, links = _scheduled_shapes(ctx, store, p, claims, links)
    before = []
    known = store.accepted_claims()
    for c in p.before.claims:
        actual = known.get(c.claim_id)
        if (
            not actual
            or c.revision != actual.revision
            or claim_fingerprint(c) != claim_fingerprint(actual)
        ):
            raise SynthError(
                "expected_revision_stale", "Состояние было не совпадает с принятой памятью"
            )
        before.append(actual)
    evs = [e for c in claims for e in c.evidence] + [e for link in links for e in link.evidence]
    if not evs:
        raise SynthError("synth_unread_evidence", "Нет проверяемого основания")
    p = replace(
        p,
        proposal_id="ss-" + digest([rid, key, index])[:32],
        idempotency_key=digest([rid, key, index]),
        run_id=rid,
        review_state=ReviewState.DRAFT,
        before=replace(p.before, claims=tuple(before)),
        after=Snapshot(tuple(claims), links, p.after.note),
        created_at=ctx.stamp(),
        evidence_digest=evidence_digest(evs),
    )
    ledger = store.ledger_snapshot(
        p, now=ctx.stamp(), entity_exists=ctx.entity_exists or default_entity_exists(ctx.vault)
    )
    verdict = validate_proposal(p, ledger, Policy())
    if verdict.violations:
        first = verdict.violations[0]
        raise SynthError(first.code, first.reason)
    comparisons = [classify(c, known.values()).to_dict() for c in claims]
    # Give the host both statements/conditions, not merely opaque IDs. Accepted evidence
    # is historical metadata, not a receipt that the original source was reread in this run.
    for comparison in comparisons:
        ids = set(comparison["matched"])
        if comparison.get("idempotent_of"):
            ids.add(comparison["idempotent_of"])
        if len(ids) > 20:
            raise SynthError("synth_budget", "Слишком много связанных утверждений: сузьте область")
        comparison["existing"] = [known[i].to_dict() for i in sorted(ids) if i in known]
        comparison["existing_sources_reread"] = False
    duplicates = [bool(c.get("idempotent_of")) for c in comparisons]
    if any(duplicates):
        if not all(duplicates):
            raise SynthError("synth_duplicate_group", "Разделите уже известное и новое изменение")
        # Known content is a checked no-op, not a new card.
        return None, comparisons
    for c in claims:
        # A pending copy is also a duplicate; refusal/snooze is checked by the common ledger.
        for row in store.pending_rows(ctx.stamp()):
            old = store.get_proposal(row["proposal_id"])
            if any(claim_fingerprint(c) == claim_fingerprint(x) for x in old.after.claims):
                raise SynthError("synth_pending_duplicate", "Такое утверждение уже ожидает решения")
    return p, comparisons


def _scheduled_shapes(ctx, store, p, claims, links):
    if p.operation is Operation.ADD and len(claims) == 1 and not links:
        return p, links
    expected = {item.ref: item.revision for item in p.expected_revisions}
    if len(expected) != len(p.expected_revisions) or any(r < 1 for r in expected.values()):
        raise SynthError("sleep_provider_format", "Нужны ревизии принятых утверждений")
    if p.before != Snapshot() or p.after.note:
        raise SynthError("sleep_provider_format", "Состояние принятого знания подставляет движок")
    if p.operation is Operation.AMEND and len(claims) == 1 and not links:
        claim = claims[0]
        ref = "claim:" + claim.claim_id
        if set(expected) == {ref} and claim.revision == expected[ref] + 1:
            old = verify_scheduled_targets(ctx, store, p)[claim.claim_id]
            if (claim.type is not old.type or claim.negative != old.negative
                    or not same_value(claim.object, old.object)):
                raise SynthError(
                    "sleep_revision_value", "Уточнение сохраняет тип, смысл и значение утверждения",
                )
            return replace(p, before=Snapshot(claims=(old,)),
                           targets=(Target("claim", claim.claim_id),)), links
    if p.operation is Operation.SUPERSEDE and len(claims) == 1 and not links and len(expected) == 1:
        claim = claims[0]
        ref, = expected
        if ref.startswith("claim:"):
            prior_id = ref.removeprefix("claim:")
            prior = verify_scheduled_targets(ctx, store, p)[prior_id]
            if (claim.claim_id != prior_id and claim.revision == 1
                    and claim.supersedes == (prior_id,) and not store.claim_rows(claim.claim_id)):
                _verify_later_value(ctx, prior, claim)
                return replace(
                    p, before=Snapshot(claims=(prior,)), claim_ids=(prior_id, claim.claim_id),
                    targets=(Target("claim", prior_id),),
                ), links
    if p.operation is Operation.RELATE and len(links) == 1 and not claims and not p.claim_ids:
        link = links[0]
        refs = {link.source, link.target}
        if (len(refs) == 2 and set(expected) == refs and all(r.startswith("claim:") for r in refs)
                and link.type not in (LinkType.ALIAS_OF, LinkType.SUPERSEDES)
                and not link.acceptance_ref):
            verify_scheduled_targets(ctx, store, p)
            if link.type is LinkType.CONTRADICTS and len({e.origin_id for e in link.evidence}) < 2:
                raise SynthError("sleep_relation_basis", "Противоречию нужны два основания")
            if link.type is not LinkType.CO_MENTION and not any(
                e.role is EvidenceRole.SUPPORT for e in link.evidence
            ):
                raise SynthError("sleep_relation_basis", "Нужно основание связи")
            pair = sorted(refs) if link.type in (
                LinkType.CONTRADICTS, LinkType.CO_MENTION, LinkType.DUPLICATE_OF,
            ) else [link.source, link.target]
            link = replace(link, link_id="link-" + digest([link.type.value, pair])[:24])
            return replace(p, targets=(Target("link", link.link_id),)), (link,)
    raise SynthError(
        "sleep_provider_format", "Нужно одно добавление, уточнение, замена или связь",
    )


def _verify_later_value(ctx, prior, claim):
    if (prior.type is not ClaimType.SOURCE_ASSERTION or claim.type is not prior.type
            or claim.negative or prior.negative or not claim.valid_from or not prior.valid_from):
        raise SynthError(
            "sleep_replacement_date", "Для замены нужны два положительных датированных утверждения",
        )
    try:
        start = date.fromisoformat(claim.valid_from)
        previous = date.fromisoformat(prior.valid_from)
        today = date.fromisoformat(ctx.stamp()[:10])
        end = date.fromisoformat(claim.valid_to) if claim.valid_to else None
    except ValueError:
        raise SynthError("sleep_replacement_date", "Некорректная дата действия") from None
    if not previous < start <= today or (end is not None and end <= today):
        raise SynthError("sleep_replacement_date", "Нужна более поздняя дата действия на сегодня")
    parts = (start.isoformat(), start.strftime("%d.%m.%Y"))
    explicit_date = rf"(?<!\d)(?:{'|'.join(map(re.escape, parts))})(?!\d)"
    if not any(
        e.role is EvidenceRole.SUPPORT and re.search(explicit_date, e.fragment)
        for e in claim.evidence
    ):
        raise SynthError("sleep_replacement_date", "Дата действия должна быть в цитате основания")
    cmp = classify(claim, (prior,))
    if cmp.result is not CompareResult.TEMPORAL_UPDATE or cmp.newer != "candidate":
        raise SynthError(
            "sleep_replacement_conflict", "Источник не подтверждает временное обновление значения",
        )


VERSION_LABEL = "sleep-synth-1.0"


def reviewed(p, rows: list, author: str, stamp: str, reason: str = ""):
    expected = {c.claim_id: c for c in p.after.claims}
    if len(rows) != len(expected) or {r.get("claim_id") for r in rows} != set(expected):
        raise SynthError("synth_review", "Рецензия должна охватить каждое утверждение")
    claims = []
    for row in rows:
        if set(row) != {"claim_id", "fingerprint", "decision", "reason"}:
            raise SynthError("synth_review", "Некорректная строка рецензии")
        c = expected[row["claim_id"]]
        if row["fingerprint"] != claim_fingerprint(c):
            raise SynthError("synth_review_stale", "Рецензия относится к другому тексту")
        if not isinstance(row["reason"], str) or not 1 <= len(row["reason"].strip()) <= 2000:
            raise SynthError("synth_review", "Нужна причина смысловой рецензии")
        if row["decision"] == "reject":
            return None
        if row["decision"] != "supported":
            raise SynthError(
                "synth_review", "Неуверенный вывод исправляют новой гипотезой, не меткой"
            )
        rec = CheckRecord(
            Check.SEMANTICALLY_REVIEWED, claim_fingerprint(c), stamp, author, (row["reason"],)
        )
        claims.append(replace(c, checks=(*c.checks, rec), review_state=ReviewState.PENDING))
    # Relations need a semantic rationale as well; the caller supplies a separate link review.
    steps = tuple(
        PipelineCheck(
            s,
            True,
            author if s is PipelineStep.SEMANTIC_REVIEW else "engine:" + VERSION_LABEL,
            (reason or "; ".join(r["reason"] for r in rows))
            if s is PipelineStep.SEMANTIC_REVIEW
            else "Проверка выполнена",
        )
        for s in PipelineStep
    )
    return replace(
        p,
        after=replace(p.after, claims=tuple(claims)),
        checks=steps,
        review_state=ReviewState.PENDING,
    )


def draft_template(dossier, receipt_id):
    """Only an empty contract skeleton; does not invent a subject, predicate or assertion."""
    from core.sleep.contract import Claim, ExpectedRevision, Operation, Proposal, Target

    d = dossier
    s = d["segments"][0] if d["segments"] else None
    cid = "claim-" + receipt_id[:24]
    evidence = (
        ()
        if not s
        else (
            Evidence(
                d["source"]["source_id"],
                EvidenceRole.SUPPORT,
                revision=d["source"]["revision"],
                content_hash=d["versions"]["actual_hash"],
                locator=s["locator"],
                fragment_fingerprint=s["fingerprint"],
            ),
        )
    )
    c = Claim(cid, 1, ClaimType.SOURCE_ASSERTION, "", "", "", "", evidence=evidence)
    return Proposal(
        "host-draft",
        "host-key",
        Operation.ADD,
        targets=(Target("claim", cid),),
        expected_revisions=(ExpectedRevision("claim:" + cid, 0),),
        after=Snapshot(claims=(c,)),
        claim_ids=(cid,),
    ).to_dict()
