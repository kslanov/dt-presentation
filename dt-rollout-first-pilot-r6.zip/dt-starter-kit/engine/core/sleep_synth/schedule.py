"""Explicit per-vault opt-in for the bounded Sleep scheduler."""

from __future__ import annotations

import json
import re
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core.file_lock import file_lock
from core.note_writer import NoteWriteError, read_sha, write_note_atomic
from core.privacy import any_nda
from core.sleep_synth.cloud import Grant
from core.sleep_synth.store import SynthError

PROFILE = "_system/sleep-schedule.json"
STATE_FILENAME = "sleep-schedule-state.json"
_HUB = re.compile(r"hub:[\w-]{1,96}", re.UNICODE)
_PLAN = re.compile(r"plan-[\da-f]{12}(?:-\d+)?")
_SHA = re.compile(r"[\da-f]{64}")


def is_hub_scope(value: str) -> bool:
    return _HUB.fullmatch(value) is not None


@dataclass(frozen=True)
class Schedule:
    mode: str = "off"
    paused: bool = False
    scope: str = ""
    timezone: str = "UTC"
    start_hour: int = 1
    end_hour: int = 5
    items: int = 3
    max_chars: int = 20_000
    max_output_tokens: int = 2000
    pilot_run_id: str = ""
    assessment_sha: str = ""
    resources_confirmed: bool = False
    cloud: dict | None = None
    cursor: dict | None = None

    @classmethod
    def parse(cls, data: dict) -> Schedule:
        if not isinstance(data, dict) or set(data) - set(asdict(cls())):
            raise SynthError("sleep_schedule_invalid", "Неизвестная настройка расписания")
        cfg = cls(**data)
        if cfg.mode not in ("off", "manual", "scheduled"):
            raise SynthError("sleep_schedule_invalid", "Режим: off, manual или scheduled")
        if type(cfg.paused) is not bool or type(cfg.resources_confirmed) is not bool:
            raise SynthError("sleep_schedule_invalid", "Нужны логические отметки")
        limits = {
            "start_hour": (0, 23),
            "end_hour": (1, 24),
            "items": (1, 5),
            "max_chars": (1000, 60_000),
            "max_output_tokens": (256, 4096),
        }
        for key, (lo, hi) in limits.items():
            val = getattr(cfg, key)
            if type(val) is not int or not lo <= val <= hi:
                raise SynthError("sleep_schedule_invalid", f"{key}: предел {lo}..{hi}")
        if cfg.start_hour >= cfg.end_hour:
            raise SynthError("sleep_schedule_invalid", "Окно должно лежать внутри суток")
        try:
            ZoneInfo(cfg.timezone)
        except (ValueError, TypeError, ZoneInfoNotFoundError) as exc:
            raise SynthError("sleep_schedule_invalid", "Нужен часовой пояс IANA") from exc
        for key, pattern in (
            ("scope", _HUB),
            ("pilot_run_id", _PLAN),
            ("assessment_sha", _SHA),
        ):
            val = getattr(cfg, key)
            if not isinstance(val, str) or (val and not pattern.fullmatch(val)):
                raise SynthError("sleep_schedule_invalid", f"Некорректное значение: {key}")
        if cfg.mode == "scheduled" and not (
            cfg.scope and cfg.pilot_run_id and cfg.assessment_sha and cfg.resources_confirmed
        ):
            raise SynthError(
                "sleep_schedule_gate",
                "Нужны один хаб, ручной пилот, версия оценки и подтверждение замера ресурсов",
            )
        if cfg.cursor is not None:
            from core.sleep_synth.cursor_runner import validate_grant

            validate_grant(cfg.cursor)
            if cfg.mode != "scheduled" or cfg.cloud is not None:
                raise SynthError("sleep_cursor_consent", "Выберите одного исполнителя Сна")
        if cfg.cloud is not None:
            Grant.parse(cfg.cloud)
        return cfg


def _profile_path(vault: Path) -> Path:
    vault = vault.resolve()
    path = vault / PROFILE
    if path.resolve() != path or any_nda(path):
        raise SynthError("sleep_schedule_invalid", "Профиль расписания недоступен")
    return path


def load(vault: Path) -> tuple[Schedule, str]:
    path = _profile_path(vault)
    try:
        with path.open("rb") as stream:
            raw = stream.read(8193)
    except FileNotFoundError:
        return Schedule(), ""
    if len(raw) > 8192:
        raise SynthError("sleep_schedule_invalid", "Профиль расписания слишком велик")
    try:
        payload = json.loads(raw)
        if not isinstance(payload, dict) or payload.pop("schema_version", None) != 1:
            raise ValueError
        payload.pop("revision", None)
    except ValueError as exc:
        raise SynthError("sleep_schedule_invalid", "Профиль расписания не прочитан") from exc
    import hashlib

    return Schedule.parse(payload), hashlib.sha256(raw).hexdigest()


def save(vault: Path, settings: dict, expected_version: str) -> dict:
    target = _profile_path(vault)
    if not isinstance(expected_version, str):
        raise SynthError("sleep_schedule_conflict", "Нужна текущая версия расписания")
    if not isinstance(settings, dict):
        raise SynthError("sleep_schedule_invalid", "Настройки расписания должны быть объектом")
    with file_lock(target):
        current, version = load(vault)
        if version != expected_version or (read_sha(target) or "") != version:
            raise SynthError("sleep_schedule_conflict", "Профиль изменен после просмотра")
        merged = {**asdict(current), **settings}
        if "cloud" not in settings and (
            merged["mode"] != "scheduled" or merged["scope"] != current.scope
        ):
            merged["cloud"] = None
        if "cursor" not in settings and (
            merged["mode"] != "scheduled" or merged["scope"] != current.scope
        ):
            merged["cursor"] = None
        proposed = Schedule.parse(merged)
        if settings.get("cursor") is not None:
            from core.sleep_synth.cursor_runner import account

            if not proposed.paused or proposed.cursor["account"] != account():
                raise SynthError("sleep_cursor_consent", "На паузе подтвердите аккаунт Cursor")
        if settings.get("cloud") is not None:
            from core.sleep_synth.executor import cloud_destination

            dest = cloud_destination(vault, proposed.scope)
            if (proposed.mode != "scheduled" or not dest
                    or dest["id"] != proposed.cloud["recipient"]):
                raise SynthError(
                    "sleep_cloud_consent", "Подтвердите передачу текущему облачному исполнителю",
                )
        text = json.dumps(
            {"schema_version": 1, "revision": uuid.uuid4().hex, **asdict(proposed)},
            ensure_ascii=False,
            indent=2,
        )
        try:
            result = write_note_atomic(
                vault,
                PROFILE,
                text + "\n",
                expect_sha=version or None,
                allowed_prefix="_system/",
            )
        except NoteWriteError as exc:
            raise SynthError("sleep_schedule_conflict", "Профиль не записан") from exc
    return {"ok": True, "profile": asdict(proposed), "version": result["sha_after"]}
