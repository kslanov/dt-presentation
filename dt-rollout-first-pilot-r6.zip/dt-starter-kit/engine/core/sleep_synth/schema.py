"""Additive v7 checkpoints and publication bindings in the shared database."""

import sqlite3

TABLES = ("sleep_synth_sessions", "sleep_synth_publications")


def create_schema(conn: sqlite3.Connection) -> None:
    conn.execute("""CREATE TABLE IF NOT EXISTS sleep_synth_sessions (
        run_id TEXT PRIMARY KEY, pipeline_version TEXT NOT NULL,
        state TEXT NOT NULL, host TEXT NOT NULL, token_hash TEXT NOT NULL,
        lease_until TEXT NOT NULL, generation INTEGER NOT NULL,
        data_json TEXT NOT NULL, updated_at TEXT NOT NULL)""")
    conn.execute("""CREATE TABLE IF NOT EXISTS sleep_synth_publications (
        proposal_id TEXT NOT NULL, revision INTEGER NOT NULL, run_id TEXT NOT NULL,
        digest TEXT NOT NULL, state TEXT NOT NULL, pins_json TEXT NOT NULL,
        PRIMARY KEY(proposal_id,revision))""")
