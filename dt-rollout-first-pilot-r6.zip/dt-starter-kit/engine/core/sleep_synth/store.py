"""Per-vault serialization and bounded, atomic checkpoints; original texts are not cached."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime, timedelta

from core.sleep_store.store import SleepStore

VERSION = "sleep-synth-1.0"
LEASE_SECONDS = 900
MAX_BYTES = 1_000_000
MAX_SCHEDULED_FINDINGS = 3


class SynthError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(value) -> str:
    return hashlib.sha256(dumps(value).encode()).hexdigest()


def until(stamp: str) -> str:
    return (
        datetime.fromisoformat(stamp.replace("Z", "+00:00")).astimezone(UTC)
        + timedelta(seconds=LEASE_SECONDS)
    ).strftime("%Y-%m-%dT%H:%M:%SZ")


class Store(SleepStore):
    @classmethod
    def readonly(cls, path):
        import sqlite3

        conn = sqlite3.connect("file:" + str(path) + "?mode=ro", uri=True, timeout=30)
        conn.row_factory = sqlite3.Row
        return cls(conn)

    def session(self, rid: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM sleep_synth_sessions WHERE run_id=?", (rid,)
        ).fetchone()
        if not row:
            return None
        result = dict(row)
        result["data"] = json.loads(result.pop("data_json"))
        if result["pipeline_version"] != VERSION:
            raise SynthError("synth_version", "Для прежней версии конвейера нужен отдельный прогон")
        return result

    def save(self, row: dict, stamp: str) -> None:
        raw = dumps(row["data"])
        if len(raw.encode()) > MAX_BYTES:
            raise SynthError("synth_budget", "Достигнут размер журнала; завершите этот прогон")
        self.conn.execute(
            """INSERT INTO sleep_synth_sessions
            (run_id,pipeline_version,state,host,token_hash,lease_until,generation,data_json,updated_at)
            VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(run_id) DO UPDATE SET
            state=excluded.state,host=excluded.host,token_hash=excluded.token_hash,
            lease_until=excluded.lease_until,generation=excluded.generation,
            data_json=excluded.data_json,updated_at=excluded.updated_at""",
            (
                row["run_id"],
                VERSION,
                row["state"],
                row["host"],
                row["token_hash"],
                row["lease_until"],
                row["generation"],
                raw,
                stamp,
            ),
        )
        self.conn.execute(
            """UPDATE sleep_runs SET state=?,lease_holder=?,lease_until=?,
            heartbeat_at=?,updated_at=? WHERE run_id=?""",
            (
                row["state"],
                "synth:" + str(row["generation"])
                if row["token_hash"] and row["lease_until"]
                else "",
                row["lease_until"],
                stamp,
                stamp,
                row["run_id"],
            ),
        )
