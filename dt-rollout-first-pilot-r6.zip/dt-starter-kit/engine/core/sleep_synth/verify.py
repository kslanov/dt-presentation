"""Trusted packet reads and revalidation before publication and owner application."""

from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from pathlib import Path

from core.domain.store import DomainStore
from core.sleep_input.dossier import MAX_READ_BYTES, sleep_context
from core.sleep_input.store import InputStore
from core.sleep_synth.store import SynthError, digest

SCHEDULED_HOST = "sleep-schedule"


def link_fingerprint(link):
    return digest(link.to_dict())


def read_bound(ctx, run_id: str, item: str, cursor=None, *, record=False) -> tuple[dict, dict]:
    store = InputStore.open_readonly(ctx.db_path)
    if store is None:
        raise SynthError("run_not_found", "План не найден")
    try:
        work = store.work_item(run_id, item)
        source = store.input_row(work["source_id"]) if work else None
        if not source:
            raise SynthError("item_not_found", "Позиция не входит в план")
        rel = source["note_rel"] if source["kind"] != "experience" else ""
        from core.sleep_input.privacy import classify_path_only

        if not classify_path_only(rel, source["locator"]).ok:
            raise SynthError("privacy_refused", "Источник закрыт политикой пути")
    finally:
        store.close()

    def note_hash():
        if not rel:
            return ""
        if Path(rel).parts[0].startswith(".") and not rel.startswith("_legacy/"):
            raise SynthError("privacy_refused", "Служебный путь не является входом")
        if Path(rel).parts[0].startswith("_") and not rel.startswith("_legacy/"):
            raise SynthError("privacy_refused", "Служебный путь не является входом")
        try:
            path = DomainStore(ctx.vault).path(rel)
        except ValueError as exc:
            raise SynthError("privacy_refused", "Путь источника больше не разрешен") from exc
        try:
            with path.open("rb") as stream:
                raw = stream.read(MAX_READ_BYTES + 1)
        except OSError as exc:
            raise SynthError("source_unavailable", "Источник больше не доступен") from exc
        if len(raw) > MAX_READ_BYTES:
            raise SynthError("synth_budget", "Источник превышает бюджет чтения")
        return hashlib.sha256(raw).hexdigest()

    before = note_hash()
    scope = ctx.extra.get("schedule_scope")
    if scope:
        from core.sleep_input.plan import _note_index

        hub_id = scope.removeprefix("hub:")
        index = _note_index(ctx.vault, {rel}, fresh=True, scoped_hub=hub_id)
        owners, _tags = index.get(rel, ((), ()))
        if hub_id not in owners:
            raise SynthError("source_blocked", "Источник больше не относится к выбранному хабу")
    dossier = sleep_context(ctx, run_id, item, cursor, record=record)
    if not dossier.get("ok"):
        raise SynthError(dossier.get("code", "source_unavailable"), "Источник не прочитан")
    if before != note_hash():
        raise SynthError("source_changed", "Источник менялся при чтении")
    if dossier.get("blockers"):
        raise SynthError("source_blocked", "Чтение содержит блокеры; позиция требует проверки")
    material = {
        k: dossier.get(k)
        for k in (
            "source",
            "versions",
            "segments",
            "coverage",
            "facts",
            "negative_scope",
            "portion",
            "independence",
        )
    }
    pin = {
        "run_id": run_id,
        "item": item,
        "cursor": cursor,
        "note_hash": before,
        "digest": digest(material),
        "source_id": source["source_id"],
    }
    return dossier, pin


def validate_pins(ctx, pins: list[dict]) -> list[dict]:
    out = []
    for pin in pins:
        try:
            dossier, actual = read_bound(ctx, pin["run_id"], pin["item"], pin["cursor"])
        except SynthError as exc:
            exc.item = pin["item"]
            raise
        if actual != pin:
            exc = SynthError("source_changed", "Прочитанное основание изменилось")
            exc.item = pin["item"]
            raise exc
        out.append(dossier)
    return out


def table_exists(conn, name):
    return conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)
    ).fetchone()


def binding_digest(proposal) -> str:
    from core.sleep_store.store import strip_proposal

    return digest(strip_proposal(proposal).to_dict())


def binding_error(conn, proposal, *, published=False) -> str:
    """Legacy runs are unchanged; a managed run cannot bypass its verifier through propose."""
    if not table_exists(conn, "sleep_synth_sessions"):
        return ""
    managed = conn.execute(
        "SELECT 1 FROM sleep_synth_sessions WHERE run_id=?", (proposal.run_id,)
    ).fetchone()
    if not managed:
        return ""
    row = conn.execute(
        "SELECT * FROM sleep_synth_publications WHERE proposal_id=? AND revision=?",
        (proposal.proposal_id, proposal.revision),
    ).fetchone()
    if (
        not row
        or row["run_id"] != proposal.run_id
        or row["digest"] != binding_digest(proposal)
        or (published and row["state"] != "published")
    ):
        return "synth_unverified"
    return ""


def check_application(ctx, store, proposal) -> None:
    error = binding_error(store.conn, proposal, published=True)
    if error:
        raise SynthError(error, "Предложение не прошло конвейер проверки")
    if not table_exists(store.conn, "sleep_synth_publications"):
        return
    row = store.conn.execute(
        """SELECT p.pins_json, s.host, r.scope FROM sleep_synth_publications p
        JOIN sleep_synth_sessions s ON s.run_id=p.run_id
        JOIN sleep_runs r ON r.run_id=p.run_id
        WHERE p.proposal_id=? AND p.revision=?""",
        (proposal.proposal_id, proposal.revision),
    ).fetchone()
    if row:
        if row["host"] == SCHEDULED_HOST:
            ctx = replace(ctx, extra={**ctx.extra, "schedule_scope": row["scope"]})
        validate_pins(ctx, json.loads(row["pins_json"]))
        verify_scheduled_targets(ctx, store, proposal)


def scoped_memory(ctx, store, *, ids=None, limit=None):
    """Return accepted assertions backed entirely by current, readable sources in this hub."""
    from core.sleep.contract import ClaimType, EvidenceRole
    from core.sleep.validate import contains_secret
    from core.sleep_input.plan import _note_index
    from core.sleep_store.evidence_view import preview

    scope = ctx.extra.get("schedule_scope")
    if not scope or ids == set():
        return {}
    now = ctx.stamp()
    day = now[:10]
    hub = scope.removeprefix("hub:")
    inputs = InputStore(store.conn)
    accepted = store.accepted_claims(ids)
    rows = store.conn.execute("SELECT claim_id FROM sleep_accepted_claims WHERE needs_check=1")
    needs_check = {r[0] for r in rows}
    found = {}
    for claim in sorted(accepted.values(), key=lambda c: (c.recorded_at, c.claim_id), reverse=True):
        if (
            claim.type is ClaimType.OWNER_DECISION or claim.claim_id in needs_check
            or claim.recorded_at[:10] > day
            or (claim.valid_from and claim.valid_from[:10] > day)
            or (claim.valid_to and claim.valid_to[:10] <= day)
            or contains_secret(claim.statement)
        ):
            continue
        if not any(e.role is EvidenceRole.SUPPORT for e in claim.evidence):
            continue
        paths = set()
        for evidence in claim.evidence:
            view = preview(ctx.vault, inputs, evidence)
            if view["preview_status"] != "ready":
                break
            paths.add(view["path"])
        else:
            owners = _note_index(ctx.vault, paths, fresh=True)
            if all(hub in owners.get(p, ((), ()))[0] for p in paths):
                found[claim.claim_id] = claim
                if limit is not None and len(found) >= limit:
                    break
    return found


def verify_scheduled_targets(ctx, store, proposal):
    """Recheck endpoint revisions and scope before a finding can be reviewed or applied."""
    from core.sleep.contract import Operation

    if not ctx.extra.get("schedule_scope") or proposal.operation not in (
        Operation.RELATE, Operation.AMEND, Operation.SUPERSEDE,
    ):
        return {}
    expected = {e.ref: e.revision for e in proposal.expected_revisions}
    ids = {ref.removeprefix("claim:") for ref in expected}
    accepted = scoped_memory(ctx, store, ids=ids)
    if not all(
        cid in accepted and accepted[cid].revision == expected[f"claim:{cid}"] for cid in ids
    ):
        raise SynthError(
            "sleep_schedule_target_stale", "Ревизия или доступность принятого знания изменилась",
        )
    if proposal.operation is Operation.RELATE and proposal.after.links:
        _verify_relation(store, proposal)
    if proposal.operation is Operation.SUPERSEDE and proposal.after.claims:
        replacement = proposal.after.claims[0]
        today = ctx.stamp()[:10]
        if replacement.valid_to and replacement.valid_to[:10] <= today:
            raise SynthError("sleep_replacement_date", "Срок действия нового значения истек")
        if store.accepted_claims({replacement.claim_id}):
            raise SynthError("sleep_replacement_conflict", "Новое утверждение уже заняло этот ID")
    return accepted


def _verify_relation(store, proposal):
    from core.sleep.contract import LinkType

    link = proposal.after.links[0]
    directions = [(link.source, link.target)]
    if link.type in (LinkType.CONTRADICTS, LinkType.CO_MENTION, LinkType.DUPLICATE_OF):
        directions.append((link.target, link.source))
    for source, target in directions:
        row = store.conn.execute(
            """SELECT 1 FROM sleep_deps d WHERE owner_ref=? AND target_ref=? AND rel=?
            AND COALESCE(proposal_id,'')<>? AND link_id<>''
            AND (layer='accepted' OR (layer='candidate' AND EXISTS (
                SELECT 1 FROM sleep_proposals p WHERE p.proposal_id=d.proposal_id
                AND p.review_state IN ('draft','ready','pending','snoozed')
            ))) LIMIT 1""",
            (source, target, link.type.value, proposal.proposal_id),
        ).fetchone()
        if row:
            raise SynthError("sleep_relation_duplicate", "Такая связь уже принята или предложена")
    if link.type is LinkType.DEPENDS_ON:
        found = store.conn.execute(
            """WITH RECURSIVE path(ref) AS (
                SELECT ?
                UNION
                SELECT CASE WHEN instr(d.target_ref, ':') > 0 THEN d.target_ref
                    ELSE 'claim:' || d.target_ref END
                FROM sleep_deps d JOIN path p ON p.ref=d.owner_ref
                WHERE d.rel='depends_on' AND d.layer='accepted'
            )
            SELECT 1 FROM path WHERE ref=? LIMIT 1""",
            (link.target, link.source),
        ).fetchone()
        if found:
            raise SynthError("sleep_relation_cycle", "Связь замыкает принятые зависимости")
