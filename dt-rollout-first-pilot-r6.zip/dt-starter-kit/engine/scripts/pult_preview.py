#!/usr/bin/env python3
# ruff: noqa: E501
"""PULT-UX-1 п.8: предпросмотр пульта без токена, без сети и без движка.

Собирает из ``webpult/pult.html`` ОДНУ самодостаточную страницу: вызовы движка
(``window.cowork.callMcpTool``) подменены ответами из фикстуры (обезличенной,
``tests/fixtures/pult/fixture.json``) или из JSON-снимка, переданного аргументом; CDN-скрипт chart.js
заменен локальной заглушкой. Токены, демон (8787), vault и ``.derived`` не нужны и не читаются.

Формат данных: ``{"manifest_role": "work", "tools": {"<имя инструмента без префикса>": <ответ>},
"errors": {"<имя>": "<текст ошибки>"}, "write_tools": [...], "read_ops": {"sleep": [...]}}`` (``read_ops`` - операции
фасадов с правами по операции, которые в режиме «только чтение» не блокируются). Ответ - то, что инструмент вернул бы
в ``structuredContent``. Инструмент без записи в ``tools`` отвечает ошибкой «нет данных предпросмотра»:
страница обязана пережить это (ошибка одного источника не скрывает остальные секции).

Запуск::

    python scripts/pult_preview.py                       # фикстура -> pult-preview.html (в tmp)
    python scripts/pult_preview.py --snapshot snap.json  # свой JSON-снимок ответов
    python scripts/pult_preview.py --mode read --open    # режим «только чтение», открыть в браузере
    python scripts/pult_preview.py --list-overlays       # состояния ТЗ-UX §18.7 поверх фикстуры
    python scripts/pult_preview.py --overlay empty-day,refresh-error --open

Запись из предпросмотра никуда не уходит: write-инструменты отвечают заглушкой ``{ok: true}`` (или
своей записью из фикстуры) и ничего не пишут.

Ответ инструмента может зависеть от аргументов: ``{"$when": [{"args": {...}, "result": ...}], "$default": ...}``;
ключ ``args`` - путь через точку (``"payload.stage"``), значения сравниваются точно. Результат ``{"$error": "текст"}``
завершает вызов ошибкой (сбой сети). Наложение может ДОПИСАТЬ правила к существующему ``$when``:
``{"tools": {"pult_ai": {"$prepend": [{"args": ..., "result": ...}]}}}`` - тогда остальные ответы инструмента остаются.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
import webbrowser
from pathlib import Path
from typing import Any

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_HTML = ENGINE_ROOT / "webpult" / "pult.html"
DEFAULT_FIXTURE = ENGINE_ROOT / "tests" / "fixtures" / "pult" / "fixture.json"
OVERLAYS_DIR = ENGINE_ROOT / "tests" / "fixtures" / "pult" / "overlays"

# CDN chart.js в боевой странице; в предпросмотре сети нет - рисуем столбики сами (только для вида).
_CHART_TAG = re.compile(r'<script src="https://cdn\.jsdelivr\.net/npm/chart\.js[^>]*></script>')
_CHART_STUB = """<script>
/* предпросмотр: локальная замена chart.js (столбики по datasets, без интерактива) */
window.Chart = class {
  constructor(ctx, cfg) { this.ctx = ctx; this.cfg = cfg; this.draw(); }
  draw() {
    const c = this.ctx && this.ctx.canvas; if (!c || !c.getContext) return;
    const g = this.ctx, d = this.cfg.data, w = c.width = c.clientWidth || 320, h = c.height = c.clientHeight || 160;
    if (!g.clearRect) return;
    g.clearRect(0, 0, w, h);
    const n = d.labels.length || 1, bw = Math.max(4, Math.min(22, (w - 20) / n - 6));
    const tot = d.labels.map((_, i) => d.datasets.reduce((a, s) => a + (s.data[i] || 0), 0));
    const max = Math.max(1, ...tot);
    d.labels.forEach((_, i) => {
      let y = h - 16; const x = 10 + i * ((w - 20) / n) + 3;
      d.datasets.forEach(s => { const v = (s.data[i] || 0) / max * (h - 30); y -= v; g.fillStyle = s.backgroundColor; g.fillRect(x, y, bw, v); });
    });
  }
  destroy() {} update() { this.draw(); }
};
</script>"""


def load_data(path: Path) -> dict[str, Any]:
    """Прочитать фикстуру/снимок. Допустимы обе формы: ``{"tools": {...}}`` и просто ``{tool: ответ}``."""
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError(f"{path}: ожидался JSON-объект")
    if isinstance(raw.get("tools"), dict):
        return raw
    return {"tools": raw}


def list_overlays(directory: Path = OVERLAYS_DIR) -> dict[str, str]:
    """Наложения предпросмотра: ``{имя: описание}`` (``tests/fixtures/pult/overlays/*.json``)."""
    out: dict[str, str] = {}
    for path in sorted(Path(directory).glob("*.json")):
        try:
            out[path.stem] = str(json.loads(path.read_text(encoding="utf-8")).get("title") or "")
        except (OSError, ValueError):
            out[path.stem] = "(не читается)"
    return out


def apply_overlays(data: dict[str, Any], names: list[str], directory: Path = OVERLAYS_DIR) -> dict[str, Any]:
    """Наложить состояния поверх фикстуры: ``tools`` и ``errors`` наложения заменяют одноименные записи (по порядку имен).

    Наложение ``errors`` снимает одноименный ответ ``tools`` и наоборот: инструмент отвечает либо данными, либо ошибкой.
    Неизвестное имя - ``ValueError`` со списком доступных (молча не игнорируется)."""
    out = json.loads(json.dumps(data))  # копия: исходная фикстура не меняется
    out.setdefault("tools", {})
    out.setdefault("errors", {})
    known = list_overlays(directory)
    for name in names:
        if name not in known:
            raise ValueError(f"нет наложения {name!r}; доступно: {', '.join(known) or 'ни одного'}")
        body = json.loads((Path(directory) / f"{name}.json").read_text(encoding="utf-8"))
        for tool, value in (body.get("tools") or {}).items():
            if isinstance(value, dict) and "$prepend" in value:  # дописать правила в начало существующего $when
                base = out["tools"].get(tool)
                base = base if isinstance(base, dict) and "$when" in base else {"$when": [], "$default": base}
                out["tools"][tool] = {**base, "$when": [*value["$prepend"], *base["$when"]]}
            else:
                out["tools"][tool] = value
            out["errors"].pop(tool, None)
        for tool, message in (body.get("errors") or {}).items():
            out["errors"][tool] = message
    return out


def _js_json(value: Any) -> str:
    # внутри <script> закрывающий тег недопустим: экранируем «</» и разделители строк JS
    return (json.dumps(value, ensure_ascii=False)
            .replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


def _shim(data: dict[str, Any], *, mode: str, instance: str) -> str:
    cfg = {
        "tools": data.get("tools") or {},
        "errors": data.get("errors") or {},
        "write_tools": data.get("write_tools") or [],
        "read_ops": data.get("read_ops") or {},
        "latency_ms": int(data.get("latency_ms") or 0),
    }
    inst = f"window.__DT_INSTANCE={_js_json(instance)};" if instance and instance != "work" else ""
    return (_SHIM_JS.replace("%%CFG%%", _js_json(cfg)).replace("%%MODE%%", _js_json(mode))
            .replace("%%INST%%", inst))


# JS-шим как обычная строка (не f-строка): фигурные скобки кода не экранируем
_SHIM_JS = r"""<script>
window.__DT_PREVIEW = %%CFG%%;
window.__DT_WEB_MODE = %%MODE%%;
window.__DT_WEB_WRITE_TOOLS = window.__DT_PREVIEW.write_tools;
window.__DT_WEB_READ_OPS = window.__DT_PREVIEW.read_ops;
%%INST%%
window.__DT_PREVIEW_CALLS = [];
/* маркеры относительных дат "@now", "@now-3h", "@now+2d" -> ISO на момент вызова */
window.__dtPreviewDates = function (v) {
  if (typeof v === "string") {
    const m = /^@now(?:([+-])(\d+)([mhd]))?$/.exec(v);
    if (!m) return v;
    const k = { m: 60000, h: 3600000, d: 86400000 }[m[3] || "m"] || 0;
    return new Date(Date.now() + (m[1] === "-" ? -1 : 1) * (+m[2] || 0) * k).toISOString();
  }
  if (Array.isArray(v)) return v.map(window.__dtPreviewDates);
  if (v && typeof v === "object") { const o = {}; for (const k in v) o[k] = window.__dtPreviewDates(v[k]); return o; }
  return v;
};
/* значение инструмента: обычный ответ либо {"$when": [{"args": {...}, "result": ...}], "$default": ...} по аргументам вызова;
   ключ args может быть путем через точку ("payload.stage"): так различаются вызовы одного инструмента с разной полезной нагрузкой */
window.__dtPreviewArg = function (args, path) {
  return String(path).split(".").reduce((o, k) => (o && typeof o === "object") ? o[k] : undefined, args || {});
};
window.__dtPreviewPick = function (entry, args) {
  if (entry && typeof entry === "object" && !Array.isArray(entry) && ("$when" in entry || "$default" in entry)) {
    for (const w of (entry.$when || [])) {
      if (Object.keys(w.args || {}).every(k => JSON.stringify(window.__dtPreviewArg(args, k)) === JSON.stringify(w.args[k]))) return w.result;
    }
    return entry.$default;
  }
  return entry;
};
window.cowork = {
  callMcpTool: async (tool, args) => {
    const name = String(tool).replace(/^mcp__digital-twin(-personal)?__/, "");
    const P = window.__DT_PREVIEW;
    window.__DT_PREVIEW_CALLS.push({ name, args: args || {} });
    if (P.latency_ms) await new Promise(r => setTimeout(r, P.latency_ms));
    if (name in P.errors) return { isError: true, content: [{ type: "text", text: String(P.errors[name]) }] };
    if (name in P.tools) {
      const picked = window.__dtPreviewPick(P.tools[name], args);
      /* {"$error": "текст"} - вызов завершается ошибкой (сбой сети/сервера) именно на этих аргументах */
      if (picked && typeof picked === "object" && "$error" in picked) return { isError: true, content: [{ type: "text", text: String(picked.$error) }] };
      return { structuredContent: window.__dtPreviewDates(JSON.parse(JSON.stringify(picked))) };
    }
    return { isError: true, content: [{ type: "text", text: "предпросмотр: нет данных для " + name }] };
  },
};
</script>"""


_BANNER = (
    '<div id="dt-preview-banner" role="note" style="position:fixed;right:10px;bottom:10px;z-index:90;'
    'font:12px system-ui;background:#343434;color:#ededed;border:1px solid #414141;border-radius:8px;'
    'padding:6px 10px;opacity:.92">Предпросмотр: данные фикстуры, движок не вызывается, запись не '
    'выполняется</div>'
)


def _clock_shim(now_ms: int) -> str:
    """Часы страницы закреплены на ``now_ms``: «сегодня», окна встреч и маркеры ``@now`` не зависят от
    времени запуска (фикстура с ``@now+6h`` иначе вечером уходит в завтра и снимок «сегодня» плавает)."""
    return ("<script>(function(){const T=" + str(now_ms) + ",D=Date;"
            "function F(...a){return a.length?new D(...a):new D(T);}"
            "F.now=()=>T;F.UTC=D.UTC;F.parse=D.parse;F.prototype=D.prototype;window.Date=F;})();</script>")


def build_preview(html: str, data: dict[str, Any], *, mode: str = "write", instance: str = "work",
                  now_ms: int | None = None) -> str:
    """Самодостаточная страница предпросмотра из исходного HTML пульта.

    ``now_ms`` - закрепить часы страницы (мс эпохи) для воспроизводимых проверок; ``None`` - живые часы."""
    if mode not in {"read", "write"}:
        raise ValueError("mode: read | write")
    if "</head>" not in html or "<body>" not in html:
        raise ValueError("в странице нет </head> или <body>")
    html, n = _CHART_TAG.subn(lambda _m: _CHART_STUB, html, count=1)
    if n != 1:
        raise ValueError("в странице не найден CDN-скрипт chart.js")
    shim = _shim(data, mode=mode, instance=instance)
    if now_ms is not None:
        html = html.replace("<head>", "<head>" + _clock_shim(int(now_ms)), 1)
    html = html.replace("</head>", shim + "</head>", 1)
    return html.replace("<body>", "<body>" + _BANNER, 1)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--html", type=Path, default=DEFAULT_HTML, help="исходный HTML (по умолчанию webpult/pult.html)")
    ap.add_argument("--fixture", type=Path, default=DEFAULT_FIXTURE, help="фикстура (обезличенная)")
    ap.add_argument("--snapshot", type=Path, help="JSON-снимок ответов вместо фикстуры")
    ap.add_argument("--mode", choices=("read", "write"), default="write", help="режим доступа веб-пульта")
    ap.add_argument("--instance", choices=("work", "personal"), default="work")
    ap.add_argument("--overlay", default="", help="состояния §18.7 поверх данных через запятую (см. --list-overlays)")
    ap.add_argument("--list-overlays", action="store_true", help="показать доступные наложения и выйти")
    ap.add_argument("--out", type=Path, help="куда писать страницу (по умолчанию tmp/pult-preview.html)")
    ap.add_argument("--open", action="store_true", help="открыть результат в браузере по умолчанию")
    args = ap.parse_args(argv)

    if args.list_overlays:
        for name, title in list_overlays().items():
            print(f"{name:20} {title}")
        return 0
    data = load_data(args.snapshot or args.fixture)
    if args.overlay.strip():
        data = apply_overlays(data, [n.strip() for n in args.overlay.split(",") if n.strip()])
    page = build_preview(args.html.read_text(encoding="utf-8"), data, mode=args.mode, instance=args.instance)
    out = args.out or Path(tempfile.gettempdir()) / "pult-preview.html"
    out.write_text(page, encoding="utf-8")
    print(f"предпросмотр: {out} ({len(page) // 1024} КБ; данные: {args.snapshot or args.fixture})")
    if args.open:
        webbrowser.open(out.resolve().as_uri())
    return 0


if __name__ == "__main__":
    sys.exit(main())
