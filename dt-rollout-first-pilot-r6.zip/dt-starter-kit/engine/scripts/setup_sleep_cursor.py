"""Install and select the optional Cursor SDK executor on this DT instance."""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ENGINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE))

from cli._env import load_env  # noqa: E402
from core.config import dt_db_path  # noqa: E402
from core.instance import secrets_path  # noqa: E402
from core.sleep_eval.gate import synthesis_readiness  # noqa: E402
from core.sleep_store.ops import make_ctx  # noqa: E402
from core.sleep_synth import cursor_runner, loop  # noqa: E402


def install(destination: Path) -> None:
    if destination.is_dir() and (destination / "node").is_file():
        print("Cursor SDK уже установлен для этого экземпляра.")
        return
    node, npm = shutil.which("node"), shutil.which("npm")
    if not node or not npm:
        raise ValueError("Для установки Cursor SDK нужны Node.js 22.13 или новее и npm.")
    subprocess.run(
        [node, "-e", "const [a,b]=process.versions.node.split('.').map(Number);"
         "if(a<22||(a===22&&b<13)) process.exit(1)"], check=True, timeout=15,
    )
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".cursor-install-", dir=destination.parent) as tmp:
        temp = Path(tmp) / "cursor-sleep"
        shutil.copytree(ENGINE / "scripts/cursor-sleep", temp)
        subprocess.run(
            [npm, "ci", "--ignore-scripts", "--no-fund", "--no-audit"], cwd=temp,
            check=True, timeout=180,
        )
        shutil.copy2(node, temp / "node")
        temp.chmod(0o700)
        temp.rename(destination)
    print("Cursor SDK установлен. Теперь выполните login.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["install", "login", "status", "select"])
    parser.add_argument("--included-only", action="store_true",
                        help="Доплаты в аккаунте выключены. Разрешаю досье выбранного хаба.")
    args = parser.parse_args()
    load_env()
    folder = dt_db_path().resolve().parent / "cursor-sleep"
    try:
        if args.action == "install":
            install(folder)
        elif args.action in ("login", "status"):
            cred = secrets_path() / "sleep-cursor-account.json"
            if cred.is_symlink():
                raise ValueError("Файл авторизации Cursor не может быть ссылкой.")
            subprocess.run(
                [str(folder / "node"), str(folder / "sleep-cursor.mjs"), str(cred),
                 f"--{args.action}"], check=True, timeout=370,
            )
        else:
            account = cursor_runner.account()
            if not args.included_only or not account or not (folder / "node").is_file():
                raise ValueError("Нужны установленный SDK, вход и подтверждение режима без доплат.")
            ctx = make_ctx()
            current = loop.status(ctx, readiness=synthesis_readiness)
            if not current.get("ok") or not current["profile"]["paused"]:
                raise ValueError("Сначала сохраните расписание по принятому пилоту на паузе.")
            result = loop.configure(ctx, {
                "cloud": None,
                "cursor": {"account": account, "billing": "included_only"},
                "max_chars": max(current["profile"]["max_chars"], 40_000),
            }, current["version"], readiness=synthesis_readiness)
            if not result.get("ok"):
                raise ValueError(result["error"])
            print("Cursor включен для выбранного хаба. Возобновите расписание в Пульте.")
    except (OSError, ValueError, subprocess.SubprocessError) as exc:
        print(f"Cursor для Сна: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
