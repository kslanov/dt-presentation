# Changelog

Формат - [Keep a Changelog](https://keepachangelog.com/ru/1.1.0/); версии - `pyproject.toml`
(принцип 17: версии и миграции при появлении второго пользователя). Тег волны и `git describe`
(`dt version`) - рядом, не вместо. Дальше запись пополняет постановщик при приемках.

## [0.3.1] - 2026-11-02

Кит без имен клиентов владельца (KIT-PRIVACY-1); снимает Known из 0.3.0. Наставник вместо
инсталлера (KIT-MENTOR-1).

### Added
- Наставник (`installer/`): `INSTALL.md` - самодостаточный промпт (72 строки): калибровка уровня
  `novice | confident | expert`, проверка возможностей хоста (читает файлы / выполняет команды),
  ветка «Рельсы с нуля» для веб-чата без файлов; `brain/00-welcome … 07-first-run` в одной форме
  «Картина (новичок/эксперт) → Вопросы → Делаем (сам / даю команду) → Проверка → Если не вышло →
  Переход», фаза `01-prereqs` ставит с человеком Terminal, git, `uv`, Obsidian, Claude Desktop и кит;
  `glossary.md`; `state/` с уровнем, хостом и тем, что уже стояло. `INSTALL.md` лежит и в корне кита,
  README кита «три шага» без предусловий. Тесты рельсов (`tests/test_installer_brain.py`, 27).
- Один сборщик приватных терминов `core/owner/privacy.py`: владелец (`owner.yaml`) + клиенты и другие
  хабы с `aliases` (title, aliases, части slug) - на боевом vault 242 термина; границы слова,
  регистронезависимо, минимум 4 символа. Файл исключений `scripts/privacy-ignore.txt` (термин +
  причина, только по решению владельца); термин из игнор-списка, которого нет в vault, - отказ.
- Гард поставляемого кода `test_no_private_terms_in_shipped_code` по тому же списку; область - корни
  кита `SHIPPED_DIRS` из `scripts/build_starter_kit.py` (один список для теста и сборки).
- `build_starter_kit` - отказ при любом совпадении (файл:термин); `verify_starter_kit` - независимый
  проход по тем же терминам; `--privacy-ignore PATH`.

### Changed
- Нейтрализованы примеры и комментарии в 47 поставляемых файлах (`core`, `cli`, `mcp-server`,
  `webpult`, `scripts`, `skills`, `ops`, `docs`): имена клиентов → `Acme`/«Клиент А», пути примеров →
  `Region/ClientA/…`; поведение кода не менялось (полный pytest 6151/0).
- `cli/_oneoff/` и скрипты по живым данным в кит не кладутся.

## [0.3.0] - 2026-11-01

Установка для второго человека (DEV-3-KIT, фаза B инсталлера).

### Added
- `dt install` - оркестратор установки с состоянием и возобновлением (`.derived/install/state.json`):
  шаги platform → deps → config (мастер) → vault → owner → models → launchd → host → index → doctor,
  каждый идемпотентен; `--check`, `--step`, `--from`, `--yes`, `--dry-run`, `--json`. Шаги зовут
  существующие команды движка (слой CLI: `cli/dt_install_steps.py`).
- `dt install --step models`: загрузка `bge-m3` и `bge-reranker-v2-m3` с прогрессом и докачкой,
  `--models-from` (офлайн-копия кэша), `scripts/build_models_bundle.py` → `dt-models.tar`; доктор «Модели».
- launchd по манифесту роли и коннекторов (`core/install/launchd.py`): `server`, `sync.fast`,
  `sync.index`, `backup` всегда, `meetings` при Outlook, `smoke`/`run.watchdog` - `--ops-full`;
  `ops/install_launchd.sh` - обертка. `dt uninstall [--purge]` (vault не трогает).
- Мозг инсталлера `installer/`: `INSTALL.md` (промпт для Claude), `brain/00-05` (профиль, сетап,
  методология, стиль, интеграции, первый прогон), шаблоны `state/`.
- Стартовый кит: `scripts/build_starter_kit.py` (гард утечек: приватные термины владельца, маски
  токенов, абсолютные пути, запрещенные файлы; `KIT-MANIFEST.json`) и `scripts/verify_starter_kit.py`.
- `dt owner init --name/--email/--company/--domain/--internal-domain`.

### Known
- В коде и скиллах остаются имена клиентов владельца в комментариях и примерах (не данные владельца,
  гардом не ловятся) - KIT-PRIVACY-1 до раздачи кита.

## [0.2.0] - 2026-11-01

Движок для второго человека (DEV-3-CORE, фаза A инсталлера).

### Added
- Коннекторы как выключаемая ось манифеста роли: `core/connectors.py` (`timetta`, `ticktick`,
  `outlook`), `DT_CONNECTORS` = `auto` (дефолт, поведение прежнее) | список | `none` («базовый DT»).
  Выключенный коннектор: секции пульта не объявлены, шаги `dt_sync`/ops заданий/виды карточек/проверки
  доктора пропущены (одна строка «коннектор выключен»), инструменты отвечают конвертом
  `connector_disabled`; `pult_manifest.connectors`, строка «Коннекторы» в «Настройках».
- `engine/vault-template/` - каркас vault, который генерирует `scripts/build_vault_template.py`
  (README папок, политики поиска, шаблоны гайдов стиля, пустые `ingest-roots`/`host-access`, образец
  `mail-filter`, шаблоны профиля); `dt vault init --kind work` и `dt instance add --role work` его
  раскладывают, существующее не трогают.
- `dt version` (версия, `git describe`, версии схем `dt.db`/facts/jobs/чанкер/индекс),
  `version.engine` в `/health`, версия в строке доктора «Демон DT».
- `owner.yaml`: `company: {name, domains, internal_domains}`; `dt owner init` мигрирует старую строку
  `company` (с бэкапом) и дозаполняет пустой шаблон профиля.
- `dt config check`: явно включенный коннектор без секрета, опечатки в `DT_CONNECTORS`, пустые домены
  владельца при включенной почте.

### Changed
- Данные владельца и компании ушли из кода в профиль: почтовые домены владельца - домены `emails` +
  `company.domains` + `DT_MAIL_OWNER_DOMAINS`, служебные - `company.internal_domains` +
  `DT_MAIL_INTERNAL_DOMAINS` (дефолта в коде нет). Запасной образец `mail-filter` нейтрален.
- Справка и подписи пульта без названия компании (кольцо с названием компании → «Подразделение»).
- `ops/SETUP.md` переписан под порядок установки нового человека.
- README папок каркаса помечены маркером `<!-- dt-template: readme` и в индекс/линковку не идут.

### Migration
- Рабочий `.env` без `DT_CONNECTORS` ведет себя как раньше (auto: коннектор включен, если есть его
  секрет/`DT_OUTLOOK_FOLDERS`). Домены владельца: добавить в `owner.yaml` `company.internal_domains`
  (раньше служебные домены были зашиты в коде) - `DT_MAIL_INTERNAL_DOMAINS=… dt owner init` перенесет.

## [0.1.0] - 2026-06

Первая рабочая версия: индекс и поиск, генерация в стиле автора, операционный контур.
