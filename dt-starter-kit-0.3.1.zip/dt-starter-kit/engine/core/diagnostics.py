"""UX-1 / CODE-7 — диагностика окружения DT (env, токены, пути, индекс, модель).

Один источник правды для `dt doctor` (CLI), MCP-инструмента ``doctor`` и fail-fast
проверки на старте (:func:`validate_environment`). Каждая проверка —
:class:`Check` со статусом ``ok`` / ``warn`` / ``fail``, человекочитаемой деталью и
подсказкой. Значения секретов НИКОГДА не выводятся — только факт наличия.

Статусы: ``fail`` — без этого ключевые функции не работают (нет токена/vault);
``warn`` — деградация (нет зеркала/индекса/модели → синк/ретривал ограничены, но
не падают); ``ok`` — в порядке. :func:`validate_environment` возвращает только
``fail`` — для баннера/выхода на старте, чтобы ошибки были видны сразу, а не при
первом вызове.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import shutil
import time
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import doctor_snapshot_path

__all__ = [
    "SNAPSHOT_MAX_AGE_H",
    "Check",
    "last_snapshot",
    "run_diagnostics",
    "snapshot_state",
    "validate_environment",
    "write_snapshot",
]

# VAULT-1: инбокс захватов не должен копиться молча (лежали захваты с 22.06,
# нашёл аудит, не система). Порог по числу файлов (env-override) ИЛИ по возрасту
# старейшего. Оба — warning, не fail.
INBOX_WARN_COUNT = 5
INBOX_WARN_DAYS = 7

# FAIL-TELEMETRY-1: окно и порог показа отказов инструментов. Жёлтым светим, когда
# ОДНА пара tool:code повторилась ≥ порога за окно — единичный отказ это норма работы
# (ссылка с опечаткой, пустой фильтр), а десяток одинаковых за неделю — дефект, до
# которого пользователь дойдёт болью. Порог — env ``DT_DEGRADATION_WARN_N``.
DEGRADATION_WINDOW_DAYS = 7
DEGRADATION_WARN_N = 10
DEGRADATION_TOP_N = 5


@dataclass
class Check:
    name: str
    status: str  # ok | warn | fail
    detail: str
    hint: str = ""


# EVAL-3 п.2 — снимок последнего прогона доктора (единый источник «здоровья» для индикатора в
# шапке пульта; первый срез аудита A6 «Мониторинг одной карточкой»). Путь —
# ``core.config.doctordoctor_snapshot_path()`` (TEST-SANDBOX-1: функция, а не константа модуля —
# подпроцесс видит подмену корня через ``DT_DERIVED_ROOT``).
SNAPSHOT_MAX_AGE_H = 24.0


def write_snapshot(
    checks: Iterable[Check], *, path: Path | None = None, now: datetime | None = None
) -> Path:
    """Записать снимок прогона: ``{ts, oks, warns, fails, worst, items}``.

    ``items`` — ТОЛЬКО warn/fail (``name``, ``status``, ``detail``): ok-строки идут счётчиком
    (снимок читают часто и целиком — шапка пульта, подсказка по наведению). Запись атомарна
    (tmp + replace): читатель не увидит половину файла. Подсказки (``hint``) в снимок не идут —
    они в «Здоровье DT» по живому ``doctor``. Сбой записи — наружу (вызывающий решает; из
    :func:`run_diagnostics` он глотается: снимок не имеет права ронять диагностику).
    """
    target = Path(path) if path is not None else doctor_snapshot_path()
    rows = list(checks)
    fails = sum(1 for c in rows if c.status == "fail")
    warns = sum(1 for c in rows if c.status == "warn")
    stamp = (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ")
    snap = {
        "ts": stamp, "oks": len(rows) - fails - warns, "warns": warns, "fails": fails,
        "worst": "fail" if fails else ("warn" if warns else "ok"),
        "items": [
            {"name": c.name, "status": c.status, "detail": c.detail}
            for c in rows if c.status in ("warn", "fail")
        ],
    }
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(snap, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    tmp.replace(target)
    return target


def snapshot_state(
    *, path: Path | None = None, now: datetime | None = None
) -> tuple[dict[str, Any] | None, str | None]:
    """``(снимок | None, ошибка)``: нет файла → ``(None, None)``; битый → ``(None, причина)``.

    Снимок дополняется ``age_min`` и ``stale`` (старше :data:`SNAPSHOT_MAX_AGE_H` часов): индикатор
    «серый» не от того, что всё плохо, а от того, что мы давно не знаем (принцип «ошибка ≠ пусто»).
    """
    target = Path(path) if path is not None else doctor_snapshot_path()
    if not target.is_file():
        return None, None
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
        ts = datetime.strptime(str(data["ts"]), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
        items = [
            {"name": str(i["name"]), "status": str(i["status"]), "detail": str(i.get("detail", ""))}
            for i in data["items"]
        ]
        snap = {
            "ts": data["ts"], "oks": int(data["oks"]), "warns": int(data["warns"]),
            "fails": int(data["fails"]), "worst": str(data["worst"]), "items": items,
        }
    except (OSError, ValueError, KeyError, TypeError) as exc:
        return None, f"снимок доктора нечитаем ({type(exc).__name__}): {target}"
    age_min = max(0.0, ((now or datetime.now(UTC)) - ts).total_seconds() / 60.0)
    snap["age_min"] = round(age_min, 1)
    snap["stale"] = age_min > SNAPSHOT_MAX_AGE_H * 60.0
    return snap, None


def last_snapshot(
    *, path: Path | None = None, now: datetime | None = None
) -> dict[str, Any] | None:
    """Снимок последнего доктора с ``age_min``/``stale`` или ``None`` (нет файла / битый)."""
    return snapshot_state(path=path, now=now)[0]


def doctor_payload(checks: Iterable[Check]) -> dict[str, Any]:
    """Ответ инструмента ``doctor`` из прогона: ``{ok, oks, fails, warns, checks[]}``.

    Единая сборка для MCP-инструмента и CLI ``dt-doctor``: снимок ``status/cache/doctor.json``
    (PULT-SURFACE-2 п.1) пишут оба, поэтому форма одна."""
    rows = list(checks)
    fails = sum(1 for c in rows if c.status == "fail")
    warns = sum(1 for c in rows if c.status == "warn")
    return {
        "ok": fails == 0,
        "oks": len(rows) - fails - warns,
        "fails": fails,
        "warns": warns,
        "checks": [
            {"name": c.name, "status": c.status, "detail": c.detail, "hint": c.hint}
            for c in rows
        ],
    }


def write_doctor_cache(checks: Iterable[Check], *, elapsed_ms: int = 0) -> bool:
    """Снимок полного ответа доктора (``status/cache/doctor.json``) — из CLI и ночного шага.

    Тот же файл, что читает ``doctor()`` из пульта: ночью шаг ``doctor`` обновляет его вместе с
    ``doctor_last.json`` (один прогон — два снимка: короткий для индикатора, полный для карточки).
    """
    from core.operational.snapshot import write_cache

    return write_cache("doctor", doctor_payload(checks), elapsed_ms=elapsed_ms)


def _env_set(var: str) -> bool:
    return bool((os.environ.get(var) or "").strip())


def _plural_ru(n: int, one: str, few: str, many: str) -> str:
    """«1 заметка / 2 заметки / 5 заметок» — строки доктора читают глазами."""
    tail = n % 100
    if 11 <= tail <= 14:
        return f"{n} {many}"
    last = n % 10
    if last == 1:
        return f"{n} {one}"
    return f"{n} {few}" if 2 <= last <= 4 else f"{n} {many}"


def _env_int(name: str, default: int) -> int:
    """Положительный порог из окружения, иначе ``default`` (мусор — тоже ``default``)."""
    raw = (os.environ.get(name) or "").strip()
    return int(raw) if raw.isdigit() and int(raw) > 0 else default


def _path_check(name: str, path: Path, *, missing: str, hint: str) -> Check:
    exists = path.exists()
    return Check(
        name,
        "ok" if exists else missing,
        str(path) if exists else f"нет: {path}",
        "" if exists else hint,
    )


def _index_check() -> Check:
    """Открыть таблицу индекса и посчитать строки (без загрузки модели)."""
    try:
        from core.config import lancedb_path
    except Exception as exc:  # noqa: BLE001
        return Check("Индекс (LanceDB)", "fail", f"config: {exc}", "проверь установку")
    db_path = lancedb_path()
    if not db_path.exists():
        return Check("Индекс (LanceDB)", "warn", f"нет: {db_path}",
                     "запусти reindex (или full-sync) — иначе ретривал пуст")
    try:
        import lancedb

        from core.retrieval.search import TABLE_NAME

        db = lancedb.connect(str(db_path))
        rows = db.open_table(TABLE_NAME).count_rows()
        return Check("Индекс (LanceDB)", "ok", f"{rows} чанков")
    except Exception as exc:  # noqa: BLE001
        return Check("Индекс (LanceDB)", "warn", f"не открыть: {exc}",
                     "запусти reindex — таблица отсутствует/повреждена")


def _text_hash_check() -> Check:
    """VEC-REUSE-1 п.1: доля строк индекса с заполненным ``text_hash`` (ключ реюза векторов).

    < 100% (или колонки нет — индекс собран до VEC-REUSE-1) → warn: реюз по содержимому
    работает только на заполненных строках, а без колонки выключен целиком."""
    name = "Индекс: text_hash"
    hint = "разово: uv run python cli/dt_index.py --backfill-text-hash (без переэмбеддинга)"
    try:
        from core.retrieval.index import open_chunks_table, text_hash_coverage

        table = open_chunks_table()
        if table is None:
            return Check(name, "ok", "индекса нет (колонка появится при первой сборке)")
        cov = text_hash_coverage(table)
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"не проверен: {exc}", "проверь .derived/lancedb")
    rows, filled = cov["rows"], cov["filled"]
    if not cov["column"]:
        return Check(name, "warn", f"колонки text_hash нет ({rows} строк) — реюз по "
                     "содержимому выключен", hint)
    share = filled / rows if rows else 1.0
    detail = f"{filled}/{rows} ({share:.1%})"
    if filled < rows:
        return Check(name, "warn", f"{detail}: часть строк без хэша", hint)
    return Check(name, "ok", detail)


def _lance_health_check() -> Check:
    """WAVE0-HYGIENE п.1: версий / фрагментов / ГБ каталога LanceDB с порогами.

    Замер идёт по каталогу (scandir), таблицу не открывает. Warn: версий >
    ``DT_LANCE_WARN_VERSIONS`` (500) или ``_versions`` > ``DT_LANCE_WARN_VERSIONS_GB``
    (5 ГБ) — значит, optimize после reindex не отрабатывает (аудит B1: 252 ГБ).
    """
    name = "LanceDB: версии/фрагменты/ГБ"
    try:
        from core.retrieval.lance_health import lance_health, lance_health_verdict

        status, detail = lance_health_verdict(lance_health())
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"замер не удался: {exc}", "проверь .derived/lancedb")
    hint = ""
    if status == "warn":
        hint = ("запусти reindex (optimize идёт после каждого прогона) или разово: "
                "uv run python cli/dt_index.py; DT_LANCE_KEEP_H — сколько часов версий держать")
    return Check(name, status, detail, hint)


def _fts_language_check() -> Check:
    """RETR-RANK-1 п.3: язык FTS-индекса против кода (меткa — ``index_fts.json``).

    Индекс, собранный до RETR-RANK-1, держит английский стеммер на русском корпусе
    («лицензия»/«лицензии» — разные термы): warn с командой пересборки. Метка пишется при
    каждой сборке FTS; нет таблицы — проверять нечего (ok «индекса нет» уже светит
    «Индекс (LanceDB)»).
    """
    name = "FTS: язык индекса"
    try:
        from core.config import lancedb_path
        from core.retrieval.fts_index import fts_meta_verdict, read_fts_meta

        if not lancedb_path().exists():
            return Check(name, "ok", "индекса нет — проверять нечего")
        status, detail = fts_meta_verdict(read_fts_meta())
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"не проверен: {exc}", "проверь core.retrieval.fts_index")
    hint = ""
    if status == "warn":
        hint = ("пересобери полнотекстовый индекс без переэмбеддинга: "
                "uv run python cli/dt_index.py --rebuild-fts")
    return Check(name, status, detail, hint)


def _note_id_collisions_check() -> Check:
    """WAVE0-HYGIENE п.2: коллизии ``note_id`` (0 → ok).

    Два источника: свежий скан vault без ``_legacy`` (сотни файлов, frontmatter-only) и
    отчёт последнего reindex (он видит и легаси). Повторный id → индексатор пропускает
    второй файл, а не затирает первый — но заметка при этом НЕ ищется, поэтому warn.
    """
    name = "Коллизии note_id"
    try:
        from core.config import default_vault_path
        from core.note_ids import scan_collisions
        from core.retrieval.index_report import read_report

        found = scan_collisions(default_vault_path())
        report = read_report() or {}
        for nid, paths in (report.get("id_collisions") or {}).items():
            found.setdefault(nid, list(paths))
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"скан не удался: {exc}", "проверь vault и index_report")
    if not found:
        return Check(name, "ok", "0 (id уникальны)")
    sample = "; ".join(f"{nid} ← {', '.join(paths[:2])}" for nid, paths in list(found.items())[:3])
    return Check(
        name, "warn", f"{len(found)} повторных id: {sample}",
        "задай уникальный frontmatter id второй заметке; выходы 07-outputs без id — "
        "uv run python cli/_oneoff/dt_backfill_note_ids.py (dry-run → --apply --limit 3 → --apply)",
    )


def _capped_notes_check() -> Check:
    """WAVE0-HYGIENE п.5: «капнутые заметки: N» — деталь, не тревога.

    Кап ``DT_INDEX_MAX_CHUNKS_PER_NOTE`` режет монстров (xlsx-дампы — хвост, почтовые
    треды — голову: новейшие письма остаются). Число и топ — из отчёта последнего reindex,
    чтобы потеря покрытия была ВИДНА, а не обнаруживалась промахом поиска.
    """
    name = "Капнутые заметки"
    try:
        from core.retrieval.index_report import read_report

        report = read_report()
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"отчёт не прочитан: {exc}",
                     "проверь .derived/index_report.json")
    if report is None:
        return Check(name, "ok", "нет отчёта (reindex ещё не прогонялся этой версией)")
    capped = report.get("capped") or {}
    count = int(capped.get("count") or 0)
    if not count:
        return Check(name, "ok", "0 (все заметки проиндексированы целиком)")
    by_policy = capped.get("by_policy") or {}
    def _policy(t: dict[str, Any]) -> str:
        return "хвост" if t.get("policy") == "tail" else "голова"

    top = "; ".join(
        f"{t['note_id']} {t['kept']}/{t['total']}"
        f"{' сообщ.' if t.get('unit') == 'messages' else ''} ({_policy(t)})"
        for t in (capped.get("top") or [])[:3]
    )
    return Check(
        name, "ok",
        f"{count} (тредов с хвостом: {by_policy.get('tail', 0)}, остальных с головой: "
        f"{by_policy.get('head', 0)}); топ: {top}",
        "DT_INDEX_MAX_CHUNKS_PER_NOTE повышает кап; бэкфилл флага: dt_index.py --replan-capped",
    )


def _backup_check() -> Check:
    """WAVE0-HYGIENE п.6: последний недельный бэкап ``.derived`` не старше 8 дней.

    Бэкапы были ручными (последний 16.08) — потеря ``dt.db``/манифеста почты/сайдкаров
    тредов невосстановима. Warn: бэкапов нет или самый свежий старше
    ``DT_BACKUP_WARN_DAYS`` (8); плюс отсутствующие источники последнего бэкапа в детали.
    """
    name = "Бэкап .derived"
    try:
        from core.backup import backups_dir, last_backup, stale_after_days

        info = last_backup()
        limit = stale_after_days()
        where = backups_dir()
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"не проверен: {exc}", "проверь core.backup / DT_BACKUPS_PATH")
    hint = ("запусти: uv run python cli/dt_backup.py; по расписанию — com.dt.backup "
            "(ops/install_launchd.sh, воскресенье 11:00)")
    if info is None:
        return Check(name, "warn", f"бэкапов нет в {where}", hint)
    detail = (f"{info['name']}, {info['age_days']:.1f} дн назад, "
              f"{info['size_bytes'] / 1e6:.0f} МБ, архивов {info['count']}")
    if info["missing"]:
        detail += f"; без источников: {', '.join(info['missing'][:3])}"
    if info["age_days"] > limit:
        return Check(name, "warn", f"последний бэкап старше {limit:g} дн: {detail}", hint)
    return Check(name, "ok", detail)


def _embed_share_detail(report: dict[str, Any]) -> str:
    """WAVE1-MEASURE п.5: «; MPS 100% из 1234 чанков, 18.5 чанк/с, OOM-повторов 2» или ``""``."""
    embed = report.get("embed") or {}
    total = int(embed.get("chunks") or 0)
    if not total:
        return ""
    parts = [f"MPS {float(embed.get('mps_share') or 0.0):.0%} из {total} чанков"]
    if embed.get("chunks_per_s"):
        parts.append(f"{embed['chunks_per_s']} чанк/с")
    if int(embed.get("oom_retries") or 0):
        parts.append(
            f"OOM-повторов на MPS {embed['oom_retries']} (батч → {embed.get('batch_size')})"
        )
    return "; " + ", ".join(parts)


def _embed_reuse_detail(report: dict[str, Any]) -> str:
    """VEC-REUSE-1 п.4: «; реюз 87% (same 120, cross 30, in_run 5, embed 25)» или ``""``.

    Доля — reused/(reused+embedded) за ПОСЛЕДНИЙ прогон. Режим не ``on`` (полная пересборка,
    нет колонки, чужая модель) показывается явно: 0% там — не «плохой реюз», а выключенный."""
    reuse = report.get("reuse") or {}
    if not reuse:
        return ""
    mode = str(reuse.get("mode") or "on")
    if mode != "on":
        why = {"full": "полная пересборка", "no_column": "нет колонки text_hash",
               "model_mismatch": "модель индекса ≠ текущей"}.get(mode, mode)
        return f"; реюз выключен ({why})"
    share = reuse.get("share")
    if share is None:
        return "; реюз: нечего было эмбеддить"
    return (
        f"; реюз {float(share):.0%} (same {reuse.get('reused_same_note', 0)}, "
        f"cross {reuse.get('reused_cross_note', 0)}, in_run {reuse.get('reused_in_run', 0)}, "
        f"embed {reuse.get('embedded', 0)})"
    )


def _index_model_check() -> Check:
    """VEC-REUSE-1 п.5: модель индекса (метка ``index_meta.json``) = текущая модель эмбеддера.

    Вектор по ``text_hash`` валиден только при той же модели; при расхождении реюз
    выключен, а старые векторы в индексе остаются чужими — лечится ``--full``."""
    name = "Индекс: модель эмбеддингов"
    try:
        from core.retrieval.index import embedder_model_id, index_model_mismatch, read_index_meta

        mismatch = index_model_mismatch()
        stored = str(read_index_meta().get("embed_model") or "")
        current = embedder_model_id()
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"не проверена: {exc}", "проверь .derived/index_meta.json")
    if mismatch:
        return Check(name, "warn", f"индекс от другой модели ({mismatch}); реюз векторов "
                     "выключен", "полная пересборка: uv run python cli/dt_index.py --full")
    if not stored:
        return Check(name, "ok", f"метки ещё нет (появится при следующем reindex); сейчас "
                     f"{current}")
    return Check(name, "ok", stored)


def _chunker_version_check() -> Check:
    """RETR-CHUNK-1 п.9: версия чанкера индекса (``index_meta.json``) = версии кода.

    Расхождение — индекс построен старой нарезкой: плановый инкремент (``reindex_inc``) ПРОПУСКАЕТСЯ
    (иначе индекс станет смешанным), поиск работает по старым чанкам. Лечится ``--full``."""
    name = "Индекс: версия чанкера"
    try:
        from core.chunking import LEGACY_CHUNKER_VERSION, chunker_version
        from core.retrieval.index import index_chunker_mismatch, read_index_meta

        mismatch = index_chunker_mismatch()
        stored = str(read_index_meta().get("chunker_version") or LEGACY_CHUNKER_VERSION)
        current = chunker_version()
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"не проверена: {exc}", "проверь .derived/index_meta.json")
    if mismatch:
        return Check(
            name, "warn",
            f"индекс {stored} ≠ код {current}: ночной инкремент (reindex_inc) пропускается, "
            "поиск идёт по чанкам прежней нарезки",
            "полная пересборка: uv run python cli/dt_index.py --full (под caffeinate -i)",
        )
    return Check(name, "ok", stored)


def _embed_device_check() -> Check:
    """WAVE0-HYGIENE п.7: последний reindex шёл на CPU? (no-silent-fallback эмбеддера).

    Фолбэк MPS→CPU раньше проглатывался без единой строки (15 из 78 итогов — ``device=cpu``,
    причина неизвестна). Теперь причина в отчёте reindex. Warn: прогон на CPU без явного
    ``DT_EMBED_DEVICE=cpu`` — с причиной фолбэка, если она известна.
    """
    name = "Эмбеддер: устройство"
    try:
        from core.retrieval.index_report import read_report

        report = read_report()
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"отчёт не прочитан: {exc}",
                     "проверь .derived/index_report.json")
    if report is None:
        return Check(name, "ok", "нет отчёта (reindex ещё не прогонялся этой версией)")
    device = str(report.get("device") or "unknown")
    reason = str(report.get("device_fallback") or "")
    forced_cpu = (os.environ.get("DT_EMBED_DEVICE") or "").strip().lower() == "cpu"
    if device == "cpu" and not forced_cpu:
        why = f" — {reason}" if reason else " (MPS не использован, причина не записана)"
        return Check(
            name, "warn",
            f"последний reindex шёл на CPU{why}{_embed_share_detail(report)}"
            f"{_embed_reuse_detail(report)}",
            "CPU в 2–3 раза медленнее; причину ищи в dt-sync.log (WARNING «ФОЛБЭК MPS→CPU»); "
            "DT_EMBED_DEVICE=cpu делает выбор явным и гасит это предупреждение",
        )
    note = f" (фолбэк: {reason})" if reason else ""
    return Check(
        name, "ok",
        f"{device}{note}{_embed_share_detail(report)}{_embed_reuse_detail(report)}",
    )


def _night_chain_check(chain: Any = None) -> Check:
    """NIGHT-CHAIN-1: «Ночная цепочка» - сколько шел последний ``index``-прогон и на что ушло время.

    Общее время, три самых долгих шага (с длительностью). ``warn``: общее время больше
    ``DT_NIGHT_CHAIN_MAX_H`` (дефолт 3 ч), шаг ``ocr`` дольше бюджета × 1.5 (бюджет теперь обрывает
    и внутри документа) либо ``reindex_inc`` шел на CPU без явного ``DT_EMBED_DEVICE=cpu``. Нет
    данных (маяк без ``steps`` - прогон прежней версией) - ``ok``: честное «ещё не измерено».
    ``chain`` - инъекция для тестов; по умолчанию - :func:`core.nightchain.read_chain` (та же
    функция чтения, что у мониторинга пульта)."""
    name = "Ночная цепочка"
    try:
        from core import nightchain as nc

        chain = chain if chain is not None else nc.read_chain("index")
        if chain is None:
            return Check(name, "ok", "нет данных: ночной index ещё не прогонялся этой версией",
                         "время по шагам появится после ближайшего прогона dt_sync index")
        from core.ocr.settings import budget_s

        forced_cpu = (os.environ.get("DT_EMBED_DEVICE") or "").strip().lower() == "cpu"
        status, reasons = nc.verdict(chain, ocr_budget_s=budget_s(), forced_cpu=forced_cpu)
        top = ", ".join(f"{s.name} {nc.format_duration(s.elapsed_s)}" for s in chain.top(3))
        state = "идёт" if not chain.finished else "последний прогон"
        part = " (частичный: --steps)" if chain.partial else ""
        detail = f"{state}{part} с {chain.started[:16].replace('T', ' ')} UTC: " \
                 f"всего {nc.format_duration(chain.total_s)}; топ-3: {top}"
        if chain.failed:
            detail += f"; с ошибками: {', '.join(chain.failed)}"
        if reasons:
            detail += " — " + "; ".join(reasons)
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"сводка не собрана: {exc}", "проверь core/nightchain.py")
    if status == "ok":
        return Check(name, "ok", detail)
    return Check(
        name, "warn", detail,
        "время по шагам - .derived/status/dt-sync-index.json и строки «step X: ok за N с» в "
        "dt-sync.log; ocr обрывается по бюджету DT_OCR_BUDGET_S, reindex на CPU - см. «Эмбеддер: "
        "устройство»",
    )


def _models_check() -> Check:
    """DEV-3-KIT п.2: «Модели» - обе модели поиска в кэше целиком: размер и откуда (хаб/набор).

    Личный экземпляр без своей модели (``DT_EMBED_OWNER=0``: вектора у соседа) - ok с пометкой.
    Нет/недокачано - warn с командой докачки (``dt install --step models``, офлайн -
    ``--models-from``). Только чтение: модели не грузятся, сети нет."""
    name = "Модели"
    try:
        from core.config import models_path
        from core.install.models import models_status
        from core.instance import embed_owner

        states = models_status(models_path())
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"статус не прочитан: {exc}", "проверь core/install/models.py")
    if not embed_owner():
        return Check(name, "ok", "эмбеддинг у соседнего демона (DT_EMBED_OWNER=0): модель не нужна")
    if all(s.complete for s in states):
        origin = sorted({s.source for s in states if s.source}) or ["поставлены не установщиком"]
        shown = ", ".join(s.reason for s in states)
        return Check(name, "ok", f"{shown}; откуда: {'; '.join(origin)}")
    broken = "; ".join(s.reason for s in states if not s.complete)
    return Check(name, "warn", f"не готово: {broken}",
                 "dt install --step models (докачает); офлайн: --models-from dt-models.tar")


def _rerank_check() -> Check:
    """RETR-RERANK-1 п.5: «Реранкер» — модель в ``models/``, устройство, прогрев.

    ok: модель на месте (устройство и время загрузки, если прогрета) либо реранкер выключен
    (``DT_RERANK`` не 1) и модели нет — тогда это осознанно. warn: реранкер включён, а модели нет
    («поиск без реранкера», конверт ``rerank_unavailable`` в каждой выдаче) или он работает на
    CPU без явного ``DT_RERANK_DEVICE=cpu``/``DT_EMBED_DEVICE=cpu`` (с причиной фолбэка).
    Модель НЕ грузится — только наличие снимка и состояние живого экземпляра.
    """
    name = "Реранкер"
    try:
        from core.retrieval import rerank as rr

        st = rr.model_status()
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"статус не прочитан: {exc}", "проверь core/retrieval/rerank.py")
    enabled = bool(st.get("enabled"))
    state = "вкл" if enabled else "выкл (DT_RERANK=0)"
    if not st.get("present"):
        if not enabled:
            return Check(name, "ok", f"{state}; модель {rr.RERANK_MODEL} не скачана")
        return Check(
            name, "warn", f"модель {rr.RERANK_MODEL} не скачана — поиск без реранкера",
            "разовая докачка (~2 ГБ в models/): DT_MODEL_DOWNLOAD=1 и первый поиск с реранкером; "
            "пока модели нет, find_notes отдаёт конверт rerank_unavailable",
        )
    device = str(st.get("device") or "unknown")
    warm = (f"прогрета ({st['load_seconds']} с)" if st.get("loaded")
            else "не прогрета (грузится при первом запросе)")
    forced_cpu = any(
        (os.environ.get(v) or "").strip().lower() == "cpu"
        for v in ("DT_RERANK_DEVICE", "DT_EMBED_DEVICE")
    )
    reason = str(st.get("fallback") or "")
    if device == "cpu" and not forced_cpu:
        why = f" — {reason}" if reason else " (MPS не использован)"
        return Check(
            name, "warn", f"{state}; модель на месте, устройство CPU{why}; {warm}",
            "CPU заметно медленнее MPS; причину ищи в логе (WARNING «ФОЛБЭК MPS→CPU»); "
            "DT_RERANK_DEVICE=cpu делает выбор явным и гасит это предупреждение",
        )
    note = f" (фолбэк: {reason})" if reason else ""
    return Check(name, "ok", f"{state}; модель на месте, устройство {device}{note}; {warm}")


def _critical_checks() -> list[Check]:
    """Дешёвые критичные проверки (секреты + vault) — без коннекта к индексу.
    Используются :func:`validate_environment` для fail-fast на старте."""
    from core import connectors
    from core.secrets import secret_location

    checks: list[Check] = []
    for var, label, connector in (
        ("TICKTICK_ACCESS_TOKEN", "TickTick токен", "ticktick"),
        ("TIMETTA_API_TOKEN", "Timetta токен", "timetta"),
    ):
        if not connectors.enabled(connector):  # DEV-3-CORE: выключенному коннектору токен не нужен
            continue
        # SEC-5: секрет может жить в ``.env`` (env) ИЛИ в Keychain — считаем его
        # заданным в обоих случаях (иначе после ``dt_secrets --prune`` doctor
        # ошибочно кричал бы «не задан»). Значение НИКОГДА не выводится — только
        # где живёт.
        loc = secret_location(var)
        ok = loc != "absent"
        hint = "" if ok else f"добавь {var} в .env или Keychain (dt_secrets --migrate)"
        checks.append(Check(label, "ok" if ok else "fail",
                            f"задан ({loc})" if ok else "не задан", hint))
    try:
        from core.config import default_vault_path

        checks.append(_path_check("Vault", default_vault_path(), missing="fail",
                                  hint="DT_VAULT_PATH — без vault ничего не работает"))
    except Exception as exc:  # noqa: BLE001
        checks.append(Check("Vault (config)", "fail", str(exc), "проверь core/config и .env"))
    return checks


def _role_checks(checks: list[Check]) -> list[Check]:
    """PERSONAL-3: убрать проверки из ``doctor_excluded`` роли (манифест поверхности)."""
    from core.surface import manifest

    skip = manifest.doctor_excluded()
    kept = [c for c in checks if c.name not in skip] if skip else checks
    # DEV-3-CORE: выключенный коннектор - одна строка ok вместо его проверок (без warn/fail)
    for _key, label, reason in manifest.connector_notes():
        kept.append(Check(f"Коннектор {label}", "ok", f"коннектор {label} выключен ({reason})",
                          "включить: DT_CONNECTORS (ops/README.md, «Коннекторы»)"))
    return kept


def run_diagnostics(*, known_tools: Iterable[str] | None = None) -> list[Check]:
    """Полный набор проверок окружения (порядок — от критичных к деградациям).

    ``known_tools`` — реестр инструментов MCP-слоя (``TOOL_NAMES``): core его не знает,
    его передаёт вызывающий (инструмент ``doctor``); без него строка «Инструменты без
    вызовов» считает только то, что уже вызывалось, и честно об этом говорит.
    """
    from core.daemon import server_mode

    if server_mode() == "client":  # CONFIG-1 п.6: у клиента нет vault/индекса - короткий набор
        from core.client import client_diagnostics

        return client_diagnostics()
    checks: list[Check] = []
    critical = _critical_checks()
    vault_check = next(c for c in critical if c.name.startswith("Vault"))
    checks.extend(c for c in critical if c is not vault_check)

    ident = _env_set("DT_TIMETTA_USER_ID") or _env_set("DT_TIMETTA_USER_EMAIL")
    checks.append(Check("Timetta identity", "ok" if ident else "warn",
                        "задан" if ident else "не задан",
                        "" if ident else "DT_TIMETTA_USER_ID или DT_TIMETTA_USER_EMAIL в .env"))

    # --- пути ---
    try:
        from core.config import (
            outlook_ingest_manifest_path,
            style_guides_path,
            timetta_mirror_path,
        )

        checks.append(vault_check)
        checks.append(_index_check())
        checks.append(_text_hash_check())
        checks.append(_index_model_check())
        checks.append(_chunker_version_check())
        checks.append(_lance_health_check())
        checks.append(_fts_language_check())
        checks.append(_note_id_collisions_check())
        checks.append(_capped_notes_check())
        checks.append(_embed_device_check())
        checks.append(_rerank_check())
        checks.append(_models_check())
        checks.append(_path_check("Зеркало Timetta", timetta_mirror_path(), missing="warn",
                                  hint="запусти full-sync — иначе «Работа»/статусы пусты"))
        checks.append(_path_check("Манифест почты", outlook_ingest_manifest_path(),
                                  missing="warn", hint="mail_ingest не прогонялся"))
        checks.append(_path_check("Style guides", style_guides_path(), missing="warn",
                                  hint="генерация без стиля будет слабее"))
    except Exception as exc:  # noqa: BLE001
        checks.append(Check("Пути (config)", "fail", str(exc), "проверь core/config и .env"))

    # --- Outlook-мост (macOS) ---
    has_osa = shutil.which("osascript") is not None
    checks.append(Check("Outlook-мост (osascript)", "ok" if has_osa else "warn",
                        "доступен" if has_osa else "нет osascript",
                        "" if has_osa else "не macOS — почта/календарь Outlook недоступны"))

    # --- parsers extra (оперативный контур: lift_source/SRC-1) ---
    import importlib.util

    has_parsers = importlib.util.find_spec("openpyxl") is not None
    checks.append(Check("Парсеры источников (extra parsers)",
                        "ok" if has_parsers else "warn",
                        "установлен" if has_parsers else "не установлен",
                        "" if has_parsers else
                        "uv sync --extra parsers — иначе lift_source по xlsx вернёт unavailable"))

    # --- NDA-барьер (NDA-1): показать, что включён и по каким маркерам ---
    try:
        from core.config import nda_markers

        markers = nda_markers()
        checks.append(Check("NDA-барьер", "ok", f"маркеры = {markers}",
                            "путь с _nda (сегмент/суффикс) не идёт в индекс/lift/промпт"))
    except Exception as exc:  # noqa: BLE001
        checks.append(Check("NDA-барьер", "warn", f"config: {exc}",
                            "проверь DT_NDA_MARKERS / core.config.nda_markers"))

    # --- Ingest-корни (INGEST-1): сколько, какие маршруты, живы ли пути ---
    checks.append(_ingest_check())

    # --- Источники: не локальны (SRC-ICLOUD-1 + OneDrive, PERSONAL-2): файлы корней не скачаны ---
    checks.append(_icloud_sources_check())

    # --- Byte-hash покрытие легаси-манифеста (INGEST-DEDUP): нужен ли backfill ---
    checks.append(_ingest_dedup_check())

    # --- OCR сканов (OCR-1): очередь, сделано, приватность, движок ---
    checks.append(_ocr_check())

    # --- Источники заметок (SRC-PATH-1): source_path разрешается в живой файл ---
    checks.extend(_source_paths_checks())

    # --- Факты (FACT-2): версия экстрактора строк стора ---
    checks.append(_facts_version_check())
    checks.append(_facts_time_check())

    # --- Целостность почтовых тредов (MAIL-THREAD-1): дубли msg_id, склейки ---
    checks.append(_mail_threads_check())

    # --- Вход: источники (INGRESS-1): последний прогон, диспозиции, отказы — по реестру ---
    checks.append(_ingress_sources_check())

    # --- Качество выдачи (EVAL-1): recall@5 золотого набора и его динамика ---
    from core.surface import manifest as _surface

    skip = _surface.doctor_excluded()  # PERSONAL-3: не считаем то, чего у роли нет
    if "Качество выдачи" not in skip:
        checks.append(_eval_check())
    if "Золотой набор" not in skip:
        checks.append(_golden_check())  # EVAL-2: здоровье самого набора (канон/stale/очередь)

    # --- Орбита Timetta (ORBIT-2): юрлица, удалённые, кольца ---
    if "Зеркало Timetta" not in skip:  # орбита - производная зеркала Timetta
        checks.extend(_orbit_checks())

    # --- Единая БД (DB-1): версия схемы + счётчики таблиц ---
    checks.append(_db_check())

    # --- Журнал стадий (PULT-EVENTLOG): сколько событий по стадиям ---
    checks.append(_eventlog_check())

    # --- Отказы инструментов (FAIL-TELEMETRY-1): где агенты спотыкаются ---
    checks.append(_degradation_check())

    # --- Употребление поверхности (WAVE1-MEASURE п.2): что из инструментов/вкладок молчит ---
    checks.append(_usage_check(known_tools))

    # --- Хосты и пульт (VENDOR-HYGIENE-1): доступ хостов к папкам, копии пульта ---
    checks.extend(_host_access_checks())
    checks.append(_host_outputs_check())  # MODEL-1: выходы по хостам, host в мете
    checks.append(_output_runs_check())  # EVAL-HYGIENE-1: прогоны eval/selftest - в карантине
    checks.append(_output_provenance_check())  # PROV-SESSION-1: сессионный провенанс выходов
    checks.append(_kimi_plugin_check())  # MODEL-1: плагин Kimi - когда собран, свежий ли
    checks.append(_pult_copies_check())
    checks.append(_web_tokens_check())  # WEBPULT-ACCESS-1: read/rw токены веб-пульта
    checks.append(_config_check())  # CONFIG-1: неизвестные/устаревшие ключи, права, режим
    checks.append(_owner_check())  # PROFILE-1: профиль владельца - один источник личности
    checks.extend(_instance_checks())  # PERSONAL-1: «Экземпляр»/«Мост» - только у экземпляра
    checks.append(_pult_surfaces_check())  # PULT-STANDALONE-1: артефакт vs веб-пульт
    checks.append(_pult_ai_check())  # PULT-STANDALONE-1: слой ИИ-синтезов пульта
    checks.append(_queue_decisions_check())  # QUEUE-SERVER-1: очередь решений - ждут/решено/шум

    # --- Смоук-прогон (LIVE-SMOKE-1): свежий ли и зелёный ли ---
    checks.append(_smoke_check())

    # --- Протечка мимо NDA-барьера (NDA-2): заметки под NDA-путями ---
    checks.append(_nda_leak_check())

    # --- Локи прогонов (SYNC-OFFLINE-1): не завис ли dt-sync/index ---
    checks.append(_lock_check())

    # --- Хабы без track (TRACK-3): беспризорные project/deal-хабы ---
    checks.append(_orphan_track_check())

    # --- Имена хабов (HUB-ALIAS-1): единый каталог — без aliases / без H1 / дубли ---
    checks.append(_hub_names_check())
    checks.append(_hub_candidates_check())
    checks.append(_hub_synth_check())  # HUB-SYNTH-1: карточки «Состояние хаба?» и устаревшие хабы
    checks.append(_lint_check())  # KNOWLEDGE-LINT-1: находки линта, давно ждущие решения
    checks.append(_bak_check())
    checks.append(_vault_git_check())

    # --- Инбокс захватов (VAULT-1): не копится ли _staging/inbox ---
    checks.append(_inbox_backlog_check())

    # --- Висящие chunk-сессии (ФТ-5): недособранные бинари в .derived ---
    checks.append(_chunk_sessions_check())

    # --- Незакрытый контур (DOD-1): файлы в хранилище без output-заметки ---
    checks.append(_dod_registration_check())

    # --- Недооформленный выход (DOD-2): папка выхода начата и не закрыта ---
    checks.append(_output_draft_check())

    # --- Выход без источников (SRC-TRACE-2): ad-hoc-выход без sources.md ---
    checks.append(_output_sources_check())

    # --- Бэкап .derived (WAVE0-HYGIENE п.6): свежий ли недельный архив ---
    checks.append(_backup_check())

    # --- Захват знаниевых файлов (WAVE1-MEASURE п.4): последний ЗАВЕРШЁННЫЙ скан ---
    checks.append(_files_freshness_check())

    # --- Плановые джобы (MEET-FIX-1): plist в репо ≠ загружен и работает ---
    checks.append(_launchd_jobs_check())
    checks.append(_night_chain_check())  # NIGHT-CHAIN-1: время ночной цепочки по шагам

    # --- Демон движка (DAEMON-1): жив, код = HEAD, uptime, сессии по хостам, footprint ---
    checks.append(_daemon_check())

    # --- Хосты: подключение (HOSTS-ATTACH-1): конфиги хостов на демоне, stdio-процессов нет ---
    checks.append(_hosts_connect_check())

    # PERSONAL-3: проверки, которых у роли нет по манифесту (Timetta, почта, золотой набор...)
    checks = _role_checks(checks)

    # EVAL-3 п.2: снимок прогона (warn/fail) — источник индикатора здоровья в шапке пульта.
    try:
        write_snapshot(checks)
    except Exception as exc:  # noqa: BLE001 — снимок не имеет права ронять диагностику
        logging.getLogger(__name__).warning("снимок доктора не записан: %s", exc)

    return checks


def _lock_held(path: Path) -> bool:
    """True, если flock ``path`` сейчас удерживается процессом (POSIX).

    Неблокирующая проба (образец :func:`core.operational.pult._sync_running`):
    берём и сразу отпускаем LOCK_EX|LOCK_NB; ``EWOULDBLOCK`` ⇒ держит кто-то.
    Открываем в режиме append (не усекаем содержимое лок-файла).
    """
    import fcntl

    try:
        fh = open(path, "a")
    except OSError:
        return False
    try:
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return True
        with contextlib.suppress(Exception):
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        return False
    finally:
        fh.close()


def _lock_check() -> Check:
    """Локи прогонов без ПРОГРЕССА (ADAPTER-HONEST-1 п.5, инцидент 2026-10-13).

    Прежняя проверка смотрела на mtime lock-файла, который двигался ЛЮБЫМ ``open("w")`` —
    в том числе каждые 30 минут пропущенным fast-синком («another run holds the lock»), —
    поэтому зависший ночной index выглядел «свежим» и доктор молчал 10 часов. Теперь
    mtime — это heartbeat, который двигает только держатель (шаг, бикон-тик, завершённый
    вызов моста; :mod:`core.runlock`). Warn — когда lock УДЕРЖИВАЕТСЯ flock'ом и heartbeat
    старше ``DT_RUN_STALL_MIN`` (дефолт 60 мин). Отпущенный lock-файл (никто не держит) —
    безобидный остаток, не шумим. Сторож ``com.dt.run.watchdog`` снимает такие прогоны сам;
    warn говорит, что он не отработал/не установлен (или прогон завис только что).
    """
    if os.name != "posix":
        return Check("Локи прогонов", "ok", "проверка локов только на POSIX")
    try:
        from core import runlock
        from core.operational.runwatch import scan

        states = scan()
        limit = runlock.stall_minutes()
    except Exception as exc:  # noqa: BLE001
        return Check("Локи прогонов", "warn", f"config: {exc}", "проверь core.config")
    stalled = [st for st in states if st.stalled]
    if stalled:
        parts = [
            f"{st.label} (pid {st.pid or '?'}, {st.mode or '?'}/{st.step or '?'}, "
            f"без прогресса {st.age_min:.0f} мин)"
            for st in stalled
        ]
        return Check(
            "Локи прогонов", "warn",
            f"прогон без прогресса >{limit:.0f} мин (DT_RUN_STALL_MIN): {', '.join(parts)}",
            "прогон завис: сторож com.dt.run.watchdog снимет его сам "
            "(launchctl list | grep run.watchdog); вручную: "
            "uv run python cli/dt_run_watchdog.py или kill <pid>; лок освободится сам",
        )
    slept = [st for st in states if st.held and st.slept]
    if slept:
        parts = [
            f"{st.label} (pid {st.pid or '?'}, heartbeat {st.age_raw_min or 0:.0f} мин назад, "
            f"из них сон; простой после пробуждения {st.age_min or 0:.0f} мин)"
            for st in slept
        ]
        return Check("Локи прогонов", "ok",
                     "зависших локов нет; пережили сон: " + ", ".join(parts))
    return Check("Локи прогонов", "ok", "зависших локов нет (heartbeat идёт или lock свободен)")


def _bak_check(roots: list[Path] | None = None) -> Check:
    """SURFACE-HYGIENE-1 п.7: «Бэкапы .bak» - сколько ``*.bak-*`` копится рядом с ``.env``, в
    ``.derived`` и у копии артефакта. ``warn``: в корне больше ``DT_BAK_WARN_COUNT`` (10) -
    подсказка называет ``dt backup prune-bak --dry-run``. Только чтение."""
    name = "Бэкапы .bak"
    try:
        from core.bakprune import bak_roots, bak_warn_count, count_bak

        found = roots if roots is not None else bak_roots()
        counts = [(root, count_bak(root)) for root in found]
        limit = bak_warn_count()
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"корни не прочитаны: {exc}", "проверь DT_BAK_ROOTS")
    total = sum(n for _r, n in counts)
    detail = f"{total} файлов в {len(counts)} корнях: " + ", ".join(
        f"{root.name or root}: {n}" for root, n in counts)
    over = [(root, n) for root, n in counts if n > limit]
    if over:
        names = ", ".join(f"{root.name or root} ({n})" for root, n in over)
        return Check(name, "warn", f"{detail}; больше {limit} в: {names}",
                     "посмотри, что уйдет: uv run python cli/dt.py backup prune-bak --dry-run; "
                     "затем без --dry-run (останутся 5 свежих на файл)")
    return Check(name, "ok", detail)


def _git(vault: Path, *args: str, timeout: float = 20.0) -> str | None:
    """Вывод ``git -C <vault> <args>`` (чтение) или ``None`` - git нет/не репозиторий/таймаут."""
    import subprocess

    try:
        out = subprocess.run(  # noqa: S603 — фиксированный argv, vault - наш каталог
            ["git", "-C", str(vault), *args],  # noqa: S607 — git из PATH, как у dt_save
            capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    return out.stdout if out.returncode == 0 else None


def _vault_git_check(vault_path: Path | None = None, *, now: datetime | None = None) -> Check:
    """SURFACE-HYGIENE-1 п.7: «Vault: git» - vault коммитится руками, 31.10 нашлось 629
    незакоммиченных путей с 24.10. ``warn``: незакоммиченных путей больше ``DT_VAULT_DIRTY_MAX``
    (200) или последний коммит старше ``DT_VAULT_COMMIT_MAX_DAYS`` (7). Читает
    ``git status --porcelain`` и ``git log -1``, ничего не пишет. Vault не под git (или git
    недоступен) - ``ok`` со справкой."""
    name = "Vault: git"
    try:
        from core.config import default_vault_path

        vault = Path(vault_path) if vault_path else default_vault_path()
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"vault не определен: {exc}", "проверь DT_VAULT_PATH")
    status = _git(vault, "status", "--porcelain")
    if status is None:
        return Check(name, "ok",
                     "справка: vault не под git (или git недоступен) - проверка пропущена")
    dirty = len([ln for ln in status.splitlines() if ln.strip()])
    stamp = (_git(vault, "log", "-1", "--format=%ct") or "").strip()
    max_dirty = _env_int("DT_VAULT_DIRTY_MAX", 200)
    try:
        max_days = float((os.environ.get("DT_VAULT_COMMIT_MAX_DAYS") or "").strip() or 7.0)
    except ValueError:
        max_days = 7.0
    ref = now or datetime.now(UTC)
    age_days: float | None = None
    if stamp.isdigit():
        age_days = max(0.0, (ref - datetime.fromtimestamp(int(stamp), UTC)).total_seconds() / 86400)
    last = f"{age_days:.0f} дн. назад" if age_days is not None else "коммитов нет"
    detail = f"незакоммичено {dirty}, последний коммит: {last}"
    problems = []
    if dirty > max_dirty:
        problems.append(f"незакоммиченных путей больше {max_dirty}")
    if age_days is None or age_days > max_days:
        problems.append(f"коммит старше {max_days:g} дн.")
    if problems:
        return Check(name, "warn", f"{detail}; " + ", ".join(problems),
                     f"закоммить vault: cd {vault} && git add -A && git commit -m \"checkpoint\" "
                     "(движок в git vault не пишет)")
    return Check(name, "ok", detail)


_HUB_NAMES_ID_LIMIT = 12
HUB_CAND_STALE_DAYS = 30  # pending без решения дольше - предупреждение (R4)


def _hub_candidates_check(
    *, path: Path | None = None, now: datetime | None = None
) -> Check:
    """SURFACE-HYGIENE-1 (R4): «Хабы: кандидаты» - очередь не должна вечно висеть нерешенной.

    ``warn``: есть pending старше :data:`HUB_CAND_STALE_DAYS` дней без решения (очередь, которую
    никто не разбирает, - шум: решения К. по журналу 17 approve / 172 reject). Ok-строка: сколько
    pending и сколько снято сверкой (в т.ч. ``ring_unit`` - чужие сделки без упоминаний).
    Только чтение."""
    name = "Хабы: кандидаты"
    try:
        from core.config import hub_candidates_path
        from core.linking.hub_candidates import REASON_RING_UNIT, HubCandidateQueue

        queue = HubCandidateQueue.load(path or hub_candidates_path())
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"очередь не прочитана: {exc}",
                     "проверь .derived/hub_candidates.jsonl")
    pending = queue.pending()
    resolved = [c for c in queue.by_id.values() if c.status == "resolved"]
    ring_unit = sum(1 for c in resolved if c.reason == REASON_RING_UNIT)
    summary = (f"pending {len(pending)}, снято сверкой {len(resolved)} "
               f"(из них чужие сделки без упоминаний: {ring_unit})")
    ref = now or datetime.now(UTC)
    old: list[Any] = []
    for c in pending:
        try:
            made = datetime.strptime(str(c.created), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
        except ValueError:
            continue
        if (ref - made).days >= HUB_CAND_STALE_DAYS:
            old.append(c)
    if old:
        return Check(
            name, "warn",
            f"{summary}; {len(old)} без решения дольше {HUB_CAND_STALE_DAYS} дн.",
            "разбери «Предлагаю хаб» в пульте (Двойник → Требуют решения) или отклони лишнее; "
            "чужие сделки без упоминаний снимает dt_hub_scan сам",
        )
    return Check(name, "ok", summary)


HUB_SYNTH_WARN_HUBS = 3  # столько хабов «просят сводку» - warn (зерно KNOWLEDGE-LINT-1)


def _hub_synth_check(
    *, stats: dict[str, Any] | None = None, stale_days: int | None = None
) -> Check:
    """HUB-SYNTH-1: «Синтез хабов» - ждущие карточки ``synth``, последний синтез, устаревшие хабы.

    ``warn`` при >= :data:`HUB_SYNTH_WARN_HUBS` хабов-клиентов, у которых секция «Состояние» /
    ``synth_at`` старше ``DT_SYNTH_STALE_DAYS`` (60) дней И набралось >= 3 новых элементов дельты
    («N хабов просят сводку: …»); меньше - ``ok`` с перечнем. Хабы без синтеза не считаются
    (устаревать нечему). Только чтение; ``pult_monitor.health`` видит строку из снимка доктора.
    ``stats`` - инъекция тестов.
    """
    name = "Синтез хабов"
    try:
        from core.operational import hub_synth

        data = stats if stats is not None else hub_synth.stats()
        days = stale_days if stale_days is not None else hub_synth.stale_days()
        last = (data.get("last_applied") or "")[:10] or "нет"
        stale = list(data.get("stale") or [])
        detail = (f"ждут решения {data.get('pending', 0)}; последний синтез {last}; "
                  f"хабов с состоянием {data.get('hubs_with_state', 0)}")
        listed = ", ".join(f"{s['hub_id']} (+{s['delta']})" for s in stale[:8])
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        return Check(name, "warn", f"синтез хабов не прочитан: {exc!r}",
                     "проверь core.operational.hub_synth")
    if not stale:
        return Check(name, "ok", detail)
    more = f" … (+{len(stale) - 8})" if len(stale) > 8 else ""
    text = (f"{len(stale)} хабов просят сводку (состояние старше {days} дн., есть новое): "
            f"{listed}{more}")
    if len(stale) >= HUB_SYNTH_WARN_HUBS:
        return Check(name, "warn", f"{detail}; {text}",
                     "собери состояние скиллом hub-synth («собери состояние хаба X») и реши "
                     "карточку «Состояние хаба?» в пульте")
    return Check(name, "ok", f"{detail}; {text}")


def _lint_check(now: datetime | None = None) -> Check:
    """KNOWLEDGE-LINT-1: «Линт знаний» - находки по правилам, давние без решения, последний прогон.

    Только чтение стора находок и сводки последнего прогона (``dt lint`` / ночной шаг ``lint``).
    ``warn``: есть находка ``pending`` старше :data:`core.lint.settings.PENDING_WARN_DAYS` (30) дней
    без решения. Нет прогона/стора - ``ok`` с подсказкой запустить ``dt lint --dry-run``;
    ``partial`` последнего прогона (бюджет) в деталях честно называется."""
    name = "Линт знаний"
    try:
        from core.lint import settings
        from core.lint.run import pending_by_rule
        from core.lint.store import LintStore, read_last_run, stamp

        store = LintStore.load()
        last = read_last_run()
        cur = now or datetime.now(UTC)
        pending = store.pending()
        counts = pending_by_rule(store)
        limit = stamp(cur - timedelta(days=settings.PENDING_WARN_DAYS))
        old = [r for r in pending if str(r.get("created") or "") < limit]
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"стор находок не прочитан: {exc}", "проверь .derived/lint_*")
    if last is None:
        run_text = "прогонов еще не было"
    else:
        rules = last.get("rules") or {}
        part = sorted(n for n, e in rules.items() if e.get("partial"))
        skipped = sorted(n for n, e in rules.items() if e.get("skipped"))
        run_text = f"последний прогон {str(last.get('ts') or '?')[:16].replace('T', ' ')}"
        if part:
            run_text += f", partial: {', '.join(part)}"
        if skipped:
            run_text += f", пропущено: {', '.join(skipped)}"
    shown = ", ".join(f"{k} {v}" for k, v in sorted(counts.items())) or "нет"
    detail = f"ждут решения {len(pending)} ({shown}); {run_text}"
    if old:
        oldest = min(str(r.get("created") or "")[:10] for r in old)
        return Check(name, "warn",
                     f"{detail}; старше {settings.PENDING_WARN_DAYS} дн. без решения: {len(old)} "
                     f"(с {oldest})",
                     "реши карточки вида «Линт» в «Требуют решения» (или «Не проблема» - стоп на "
                     f"{settings.snooze_days()} дн.)")
    return Check(name, "ok", detail,
                 "прогон: dt lint [--dry-run]; ночью - шаг lint после hub_scan"
                 if last is None else "карточки вида «Линт» - в «Требуют решения»")


def _hub_names_check(vault_path: Path | None = None) -> Check:
    """HUB-ALIAS-1 п.2: «Хабы: имена» - здоров ли единый каталог имен хабов.

    ``warn`` (никогда не ``fail``): хабы без ``aliases`` (клиентские первыми - по ним решает
    карточка «Алиасы хаба?»), хабы без H1 (имени нет нигде, кроме слага id) и явный алиас хаба,
    совпавший (``casefold``) с алиасом или id ДРУГОГО хаба - источник ложных ссылок линковки и
    нормализации клиента. Ok: ``79 хабов, имен в каталоге N, без aliases 0``. Дешево: срезы
    frontmatter из общего снимка (:func:`core.retrieval.hubcat.hub_catalog`).
    """
    name = "Хабы: имена"
    try:
        from core.config import default_vault_path
        from core.retrieval.hubcat import hub_catalog

        vault = vault_path or default_vault_path()
        catalog = hub_catalog(vault, None)
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"каталог имен не прочитан: {exc}",
                     "проверь vault и core.retrieval")
    if not catalog:
        return Check(name, "ok", "хабов нет")

    def _ids(items: list[str]) -> str:
        shown = ", ".join(items[:_HUB_NAMES_ID_LIMIT])
        more = len(items) - _HUB_NAMES_ID_LIMIT
        return shown + (f" … (+{more})" if more > 0 else "")

    # клиентские первыми: по ним К. решает карточкой
    ordered = sorted(catalog, key=lambda e: (e.entity != "client", e.entity, e.note_id))
    no_alias = [e for e in ordered if not any(n.source == "alias" for n in e.names)]
    no_h1 = [e.note_id for e in ordered if not e.h1.strip()]
    owners: dict[str, set[str]] = {}
    for e in catalog:
        keys = {n.text.casefold().strip() for n in e.names if n.source == "alias"}
        keys.add(e.note_id.casefold())
        for key in keys:
            owners.setdefault(key, set()).add(e.note_id)
    dupes = sorted(
        {f"{key!r}: {' / '.join(sorted(ids))}" for key, ids in owners.items() if len(ids) > 1}
    )
    names_total = sum(len(e.names) for e in catalog)
    summary = f"{len(catalog)} хабов, имен в каталоге {names_total}, без aliases {len(no_alias)}"
    problems: list[str] = []
    if no_alias:
        clients = [e.note_id for e in no_alias if e.entity == "client"]
        problems.append(
            f"без aliases: {len(no_alias)} (клиентских {len(clients)}): "
            + _ids([e.note_id for e in no_alias])
        )
    if no_h1:
        problems.append(f"без H1 (имени нет нигде, кроме слага): {len(no_h1)}: {_ids(no_h1)}")
    if dupes:
        problems.append(f"алиас-дубль другого хаба: {len(dupes)}: {_ids(dupes)}")
    if not problems:
        return Check(name, "ok", summary)
    return Check(
        name, "warn", f"{summary}; " + "; ".join(problems),
        "алиасы: карточка «Алиасы хаба?» в «Требуют решения» (шаг hub_scan предлагает имена из H1, "
        "зеркала Timetta и доменов) или aliases: [..] в frontmatter хаба; дубль - убрать у одного",
    )


def _orphan_track_check() -> Check:
    """TRACK-3: project/deal-хабы в ``03-projects`` без валидного ``track``.

    Канон (02-architecture §9 принцип 18): ``entity: project`` = workspace-хаб,
    ``track ∈`` :data:`core.operational.tracks.TRACKS` обязателен. ``scaffold_hub``
    пишет его сам (TRACK-1), но старые/ручные хабы остаются беспризорными →
    детектор «дозревших» падает на эвристику и красит лиды «внутр. проектами».
    Warning (НЕ fail): список id + подсказка. Дёшево (только frontmatter).
    """
    try:
        from core.config import default_vault_path
        from core.operational.ripe_leads import LEAD_DIR, LEAD_ENTITIES
        from core.operational.tracks import TRACKS
        from core.vault import read_note
    except Exception as exc:  # noqa: BLE001
        return Check("Хабы без track", "warn", f"config: {exc}", "проверь core.operational.tracks")

    root = default_vault_path() / LEAD_DIR
    orphans: list[str] = []
    if root.is_dir():
        for path in sorted(root.rglob("*.md")):
            try:
                note = read_note(path)
            except (OSError, ValueError):
                continue
            fm = note.frontmatter
            if fm.get("type") != "hub":
                continue
            if str(fm.get("entity") or "") not in LEAD_ENTITIES:
                continue
            if str(fm.get("track") or "").strip().lower() not in TRACKS:
                orphans.append(note.id)
    if orphans:
        return Check(
            "Хабы без track", "warn",
            f"{len(orphans)} project/deal-хабов без track: {', '.join(orphans)}",
            "поставь трек кликом в «Дозрели» или полем track: "
            "presale|project|internal во frontmatter",
        )
    return Check("Хабы без track", "ok", "все project/deal-хабы размечены")


# MEET-FIX-1 — каталог plist-шаблонов наших плановых джобов и подстановки, которые
# ОБЯЗАН сделать ops/install_launchd.sh (не подставили → джоб не может запуститься).
_LAUNCHD_DIR = Path(__file__).resolve().parents[1] / "ops" / "launchd"
_LAUNCHD_AGENTS = Path("~/Library/LaunchAgents").expanduser()
_PLIST_PLACEHOLDERS = ("__ENGINE_DIR__", "__UV_BIN_DIR__")


def _launchctl_state() -> dict[str, tuple[str, str]] | None:
    """``launchctl list`` → ``{label: (pid, last_exit_status)}``; ``None`` — не прочитать.

    Один дешёвый вызов, read-only. Нет launchctl (не macOS/CI) → ``None``, и проверка
    честно говорит «не проверить», а не выдумывает вердикт.
    """
    import subprocess

    try:
        proc = subprocess.run(
            ["launchctl", "list"],  # noqa: S607 — launchctl из PATH (системная утилита)
            capture_output=True, text=True, timeout=10, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if proc.returncode != 0:
        return None
    out: dict[str, tuple[str, str]] = {}
    for line in (proc.stdout or "").splitlines()[1:]:
        parts = line.split("\t")
        if len(parts) >= 3:
            out[parts[2].strip()] = (parts[0].strip(), parts[1].strip())
    return out


def _plist_label(path: Path) -> str:
    """Label из plist-шаблона (строка сразу после ``<key>Label</key>``)."""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return path.stem
    for i, line in enumerate(lines):
        if "<key>Label</key>" in line and i + 1 < len(lines):
            value = lines[i + 1].strip()
            if value.startswith("<string>") and value.endswith("</string>"):
                return value[len("<string>"):-len("</string>")].strip()
    return path.stem


# DOCTOR-HONEST-1: сигнальные коды выхода. launchd отдаёт либо номер сигнала (15 —
# SIGTERM от ``kickstart -k``), либо 128+сигнал (шелл-конвенция) — и то и другое
# означает «процесс завершили», а не «упал сам».
_SIGTERM_EXIT = 15
_SIGNAL_EXIT_BASE = 128


def _pid_alive_row(pid: str) -> bool:
    """Есть ли у джоба живой PID в строке ``launchctl list`` (``-`` = не запущен)."""
    value = (pid or "").strip()
    return value.isdigit() and int(value) > 0


def _is_signal_exit(status: str) -> bool:
    """Похож ли код выхода на завершение сигналом (штатный рестарт выглядит так же)."""
    value = (status or "").strip().lstrip("-")
    if not value.isdigit():
        return False
    code = int(value)
    return code == _SIGTERM_EXIT or code > _SIGNAL_EXIT_BASE


def _launchd_jobs_check() -> Check:
    """MEET-FIX-1: наши плановые джобы — plist в репо ЕСТЬ, а в launchctl?

    Класс дефекта (пойман на PERF-3): ``com.dt.meetings.plist`` лежал в репо, приёмка
    записала «планово каждые 3 часа», а в ``~/Library/LaunchAgents`` его не было —
    и кэш встреч не обновлялся две недели, пока это не заметили глазами. Гард
    закрывает весь класс, а не один джоб:

    * plist есть в репо, в ``launchctl`` метки нет → **не загружен** (нужен
      ``ops/install_launchd.sh``);
    * загружен, но в установленном plist остались ``__ENGINE_DIR__``/``__UV_BIN_DIR__``
      → «загружен, но запуститься не может» (шаблон скопировали как есть);
    * загружен, последний выход ≠ 0 → **падает** (виден статус).

    **DOCTOR-HONEST-1.** Живой процесс важнее истории: если у джоба в ``launchctl list``
    есть PID, он работает СЕЙЧАС, и последний код выхода — прошлое, а не проблема
    (кейс: ``com.dt.webpult`` показывал «последний выход 143», хотя 143 — это SIGTERM
    от собственной кнопки перезапуска ``pult_web_restart``, и сервис был жив). Для
    остальных код выхода различается: сигнальный (15/SIGTERM или >128) — так выглядит
    штатный рестарт, и тревожен он только если повторяется без рестартов; прочие коды —
    смотреть лог прогона. Доктор, который жёлтый всегда, перестают читать.

    Read-only, один вызов ``launchctl list``; на не-macOS — «не проверить» (warn).
    """
    if not _LAUNCHD_DIR.is_dir():
        return Check("Плановые джобы (launchd)", "warn", f"нет каталога {_LAUNCHD_DIR}",
                     "ops/launchd/*.plist — шаблоны наших джобов")
    plists = sorted(_LAUNCHD_DIR.glob("*.plist"))
    if not plists:
        return Check("Плановые джобы (launchd)", "warn", "в ops/launchd нет plist",
                     "шаблоны джобов пропали из репо?")
    # DEV-3-KIT п.3: состав - из манифеста. Не ждем задание выключенного коннектора (meetings без
    # outlook) и ярус владельца (смоук, сторож), которого человеку не ставили (``dt install``
    # без ``--ops-full``): отсутствие такого плиста - не поломка.
    from core.surface import manifest as _manifest

    wanted = set(_manifest.launchd_jobs(ops_full=True))
    owner_tier = {k for k, tier in _manifest.LAUNCHD_JOBS if tier == "ops"}
    plists = [
        p for p in plists
        if (key := _plist_label(p).removeprefix("com.dt.")) in wanted
        and not (key in owner_tier and not (_LAUNCHD_AGENTS / f"{_plist_label(p)}.plist").exists())
    ] or plists
    state = _launchctl_state()
    if state is None:
        return Check(
            "Плановые джобы (launchd)", "warn",
            f"launchctl не прочитан (джобов в репо: {len(plists)})",
            "на macOS проверь `launchctl list`; на другой ОС проверка неприменима",
        )

    problems: list[str] = []
    ok_labels: list[str] = []
    running_notes: list[str] = []
    signalled = False
    for plist in plists:
        label = _plist_label(plist)
        row = state.get(label)
        if row is None:
            problems.append(f"{label}: не загружен")
            continue
        installed = _LAUNCHD_AGENTS / f"{label}.plist"
        raw = ""
        with contextlib.suppress(OSError):
            raw = installed.read_text(encoding="utf-8")
        if any(ph in raw for ph in _PLIST_PLACEHOLDERS):
            problems.append(f"{label}: загружен с НЕподставленными __ПЛЕЙСХОЛДЕРАМИ__")
            continue
        pid, status = row[0], row[1]
        if _pid_alive_row(pid):
            # Работает СЕЙЧАС: код выхода — история прошлого запуска, не проблема.
            ok_labels.append(label)
            if status not in {"0", ""}:
                running_notes.append(f"{label}: работает (в истории выход {status})")
            continue
        if status not in {"0", ""}:
            problems.append(f"{label}: последний выход {status}")
            if _is_signal_exit(status):
                signalled = True
            continue
        ok_labels.append(label)

    if not problems:
        detail = f"загружены и без ошибок: {', '.join(ok_labels)}"
        if running_notes:
            detail += " · " + "; ".join(running_notes)
        return Check("Плановые джобы (launchd)", "ok", detail)
    hint = (
        "переустановить: ops/install_launchd.sh (подставляет пути в шаблоны и "
        "перезагружает); логи прогонов — .derived/logs/launchd.<label>.log"
    )
    if signalled:
        hint = (
            "выход сигнальный (SIGTERM/…): так же выглядит ШТАТНЫЙ рестарт — тревожно "
            "только если повторяется без рестартов; иначе смотри "
            ".derived/logs/launchd.<label>.log"
        )
    return Check(
        "Плановые джобы (launchd)", "warn",
        f"проблемные джобы: {len(problems)} — " + "; ".join(problems),
        hint,
    )


def _human_uptime(seconds: int) -> str:
    days, rest = divmod(max(0, int(seconds)), 86400)
    hours, rest = divmod(rest, 3600)
    minutes = rest // 60
    if days:
        return f"{days} д {hours} ч"
    return f"{hours} ч {minutes} мин" if hours else f"{minutes} мин"


def _daemon_check(
    *,
    fetch: Callable[[], dict[str, Any] | None] | None = None,
    head: str | None = None,
    footprint: Callable[[int], int | None] | None = None,
    sessions_24h: Callable[[], dict[str, int] | None] | None = None,
    tailscale_clients: Callable[[], int | None] | None = None,
) -> Check:
    """DAEMON-1: «Демон DT» - ``com.dt.server`` на 8787 (пульт + MCP).

    CONFIG-1: в режиме ``server`` (``/health`` отдает ``mode: server`` и ``tailscale``) строка
    начинается с «режим server · <dns> · клиентов по Tailscale за 24 ч N» (разные peer из
    ``tool_call``); в ``local`` - как прежде.

    * **ok** - ``/health`` отвечает, версия кода демона = ``HEAD`` репо; в detail - uptime, сессии
      сейчас (``/health``) и за 24 ч (телеметрия ``tool_call`` с ``sid``), footprint процесса
      (``footprint -p``; нет утилиты - «н/д»);
    * **warn «отстает»** - демон жив, но стартовал на другом коммите: код обновили, а демон не
      перезапускали (``launchctl kickstart -k gui/<uid>/com.dt.server``) - хосты по ``url`` видят
      старый код;
    * **warn «не жив»** - ``/health`` не отвечает (не установлен либо упал).

    Зависимости инжектируются (тесты не ходят в сеть/launchctl/git); по умолчанию - живые."""
    name = "Демон DT"
    from core import daemon as dmn

    port = int(os.environ.get("DT_WEB_PORT") or 8787)
    kick = f"launchctl kickstart -k gui/{os.getuid()}/com.dt.server"
    health = (fetch or (lambda: dmn.fetch_health(port)))()
    if health is None:
        return Check(
            name, "warn", f"не отвечает на 127.0.0.1:{port}/health (демон не установлен или упал)",
            "поставить: `bash ops/install_launchd.sh` (com.dt.server); если стоит - "
            f"`{kick}` и лог .derived/logs/launchd.server.err.log",
        )
    version = health.get("version") or {}
    code = str(version.get("code") or "unknown")
    repo = head if head is not None else dmn.code_version()
    uptime = _human_uptime(int(version.get("uptime_s") or 0))
    parts = [f"жив на :{port}", f"код {code}", f"uptime {uptime}"]
    if version.get("engine"):  # DEV-3-CORE: версия релиза рядом с кодом демона
        parts.insert(1, f"версия {version['engine']}")
    if health.get("mode") == "server":
        dns = str((health.get("tailscale") or {}).get("dns") or "?")
        clients = (tailscale_clients or (lambda: dmn.tailscale_clients(24.0)))()
        parts.insert(0, f"режим server · {dns} · клиентов по Tailscale за 24 ч "
                        + (str(clients) if clients is not None else "н/д"))
    sessions = health.get("sessions") or {}
    now_hosts = ", ".join(f"{h} {n}" for h, n in sorted((sessions.get("by_host") or {}).items()))
    parts.append(
        f"сессий сейчас {sessions.get('total', 0)}" + (f" ({now_hosts})" if now_hosts else "")
    )
    day = (sessions_24h or (lambda: dmn.sessions_by_host(24.0)))()
    if day is None:
        parts.append("за 24 ч: журнал не прочитан")
    else:
        listed = ", ".join(f"{h} {n}" for h, n in sorted(day.items()))
        parts.append("за 24 ч: " + (listed or "сессий не было"))
    pid = health.get("pid")
    mb = (footprint or dmn.footprint_mb)(int(pid)) if isinstance(pid, int) else None
    parts.append("footprint " + (f"{mb / 1024:.1f} ГБ" if mb is not None else "н/д"))
    detail = " · ".join(parts)
    if code != "unknown" and repo != "unknown" and code != repo:
        return Check(
            name, "warn", f"демон отстает от кода: работает {code}, HEAD репо {repo} · " + detail,
            f"перезапусти демон: `{kick}` (хосты по url подхватят код без перезапуска; сессии "
            "MCP-хостов при этом рвутся - прямой клиент переподключается, мост Desktop - с "
            "--reconnect)",
        )
    if code == "unknown" or repo == "unknown":
        detail += " · версию кода сверить нельзя (нет git)"
    return Check(name, "ok", detail)


def _replaced_deliveries_info(window_h: float) -> str:
    """DELIVER-2 п.4: справка (не предупреждение) «доставленный файл заменен снаружи» - выход
    доставил файл, а потом его затерли ``place_download``/``store_file`` другого хоста: в папке
    клиента лежит уже не документ движка. Пусто - нет замен в окне; сбой чтения - пусто (справка не
    имеет права ломать строку доктора)."""
    try:
        from core.output import replaced_deliveries

        rows = replaced_deliveries(window_h=window_h)
    except Exception:  # noqa: BLE001 — справка best-effort
        return ""
    if not rows:
        return ""
    shown = "; ".join(f"{r['ref']} ({r['replaced_by'].split('/')[0]})" for r in rows[:3])
    more = f" и ещё {len(rows) - 3}" if len(rows) > 3 else ""
    return f" · справка: доставленный файл заменен снаружи: {len(rows)} ({shown}{more})"


def _hosts_connect_check(
    *,
    verify: Callable[[str], dict[str, Any]] | None = None,
    procs: Callable[[], list[dict[str, Any]] | None] | None = None,
    sessions: Callable[[], tuple[dict[str, int] | None, dict[str, int] | None]] | None = None,
    instance_verdicts: Callable[[], list[dict[str, Any]]] | None = None,
) -> Check:
    """HOSTS-ATTACH-1 п.5: «Хосты: подключение» - все ли хосты на демоне (рядом с «Демон DT»).

    По каждому известному конфигу (``claude_desktop_config.json``, ``~/.cursor/mcp.json``,
    ``mcp.json`` агента Kimi - ТОЛЬКО чтение, ``core.host_config.verify_host``) вердикт: ``daemon``
    (мост/url на наш порт, токен есть) | ``stdio-legacy`` (старая команда ``server.py`` - дрейф) |
    ``missing`` | ``foreign``. Плюс живые stdio-процессы ``server.py`` без ``--transport http``
    (счет и хост-владелец по родителю) и телеметрия за 24 ч: хосты с ``sid`` (по url/мосту) и без
    (stdio).

    * **warn** - есть ``stdio-legacy`` или живые stdio-процессы (хост держит СВОЙ движок: лишняя
      память, код отстает от демона до перезапуска хоста);
    * **ok** - «все на демоне: …; stdio-процессов 0» (``missing``/``foreign`` - в detail, не дрейф).

    PERSONAL-3 п.D3: для каждого экземпляра из ``instances/`` ожидается запись
    ``digital-twin-<имя>`` в конфиге Claude Desktop; ``missing``/``foreign`` - warn «запись
    экземпляра пропала: Desktop перезаписывает конфиг при выходе», поставить ``… --relaunch``.

    Зависимости инжектируются (тесты не ходят в ``ps``/файлы хостов/журнал)."""
    name = "Хосты: подключение"
    from core import daemon as dmn
    from core.host_config import instance_entry_verdicts, verify_host

    check = verify or (lambda host: verify_host(host))
    verdicts: dict[str, dict[str, Any]] = {}
    for host in ("claude", "cursor", "kimi"):
        try:
            verdicts[host] = check(host)
        except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
            verdicts[host] = {"verdict": "missing", "reason": f"не прочитан: {exc}", "form": ""}
    running = (procs or dmn.stdio_server_processes)()
    http_hosts, stdio_hosts = (sessions or (lambda: (
        dmn.sessions_by_host(24.0), dmn.stdio_calls_by_host(24.0))))()

    def label(host: str, v: dict[str, Any]) -> str:
        form = {"shim": "мост", "url": "url", "stdio": "stdio"}.get(str(v.get("form") or ""), "")
        profile = f", {v['profile']}" if v.get("profile") else ""
        what = v["verdict"] + (f" ({form}{profile})" if form else "")
        if v["verdict"] == "missing" and str(v.get("reason") or "").startswith("не прочитан"):
            what += f" ({v['reason']})"  # конфиг не прочитался - это сказано, а не «нет записи»
        return f"{host}: {what}"

    parts = [label(h, v) for h, v in verdicts.items()]
    legacy = [h for h, v in verdicts.items() if v["verdict"] == "stdio-legacy"]
    if running is None:
        parts.append("stdio-процессов: ps не выполнился")
    elif running:
        owners: dict[str, int] = {}
        for p in running:
            owners[p["owner"]] = owners.get(p["owner"], 0) + 1
        parts.append("stdio-процессов " + str(len(running)) + " ("
                     + ", ".join(f"{o} {n}" for o, n in sorted(owners.items())) + ")")
    else:
        parts.append("stdio-процессов 0")
    if http_hosts is None:
        parts.append("за 24 ч: журнал не прочитан")
    else:
        by_url = ", ".join(f"{h} {n}" for h, n in sorted(http_hosts.items())) or "нет"
        by_stdio = ", ".join(f"{h} {n}" for h, n in sorted((stdio_hosts or {}).items())) or "нет"
        parts.append(f"за 24 ч: по url/мосту (сессий) {by_url}; по stdio (вызовов) {by_stdio}")
    try:  # PERSONAL-3: записи экземпляров (digital-twin-<имя>) на месте?
        entries: list[dict[str, Any]] = list((instance_verdicts or instance_entry_verdicts)())
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        entries = []
        parts.append(f"записи экземпляров: не прочитаны ({exc})")
    for v in entries:
        parts.append(f"экземпляр {v['name']}: " + ("запись на месте" if v["verdict"] == "daemon"
                                                    else v["verdict"]))
    detail = " · ".join(parts)
    lost = [v["name"] for v in entries if v["verdict"] != "daemon"]
    if lost and not (legacy or running):
        cures = [f"dt host-config claude --instance {n} --install --relaunch" for n in lost]
        lost_why = "; ".join(f"запись экземпляра {n} пропала - Desktop перезаписывает конфиг при "
                             "выходе" for n in lost)
        return Check(name, "warn", lost_why + " · " + detail, "поставить: " + "; ".join(cures))
    if legacy or running:
        fixes = []
        for host in legacy:
            fixes.append("dt plugin kimi --out plugins/kimi-work --install" if host == "kimi"
                         else f"dt host-config {host} --install")
        if running:
            fixes.append("перезапусти хост-владелец (процесс живет до перезапуска хоста)")
        why = []
        if legacy:
            why.append("в конфиге старая stdio-команда server.py: " + ", ".join(legacy))
        if running:
            why.append(f"живых stdio-процессов движка: {len(running)}")
        return Check(name, "warn", "; ".join(why) + " · " + detail,
                     "перевести на демон: " + "; ".join(fixes))
    if all(v["verdict"] == "missing" for v in verdicts.values()):
        return Check(name, "ok", "хосты не настроены (конфигов с digital-twin нет) · " + detail)
    daemon_hosts = [h for h, v in verdicts.items() if v["verdict"] == "daemon"]
    via = {"claude": "Desktop/Cowork через мост", "cursor": "Cursor по url", "kimi": "Kimi по url"}
    head = "все на демоне: " + ", ".join(via[h] for h in daemon_hosts) if daemon_hosts else ""
    return Check(name, "ok", (head + "; " if head else "") + detail)


def _dod_registration_check() -> Check:
    """DOD-1: файлы, доставленные в хранилище, но не зарегистрированные в output-заметке.

    Третий слой кейса 2026-08-04: нарушение контракта «результат возвращается в DT»
    было НЕВИДИМО — файлы легли, заметки-output нет, и без напоминания К. этого никто
    бы не заметил. Здесь оно видно: доставки за окно (env ``DT_DOD_WINDOW_H``, дефолт
    48 ч) из аудит-лога сверяются с секцией «## Файлы» заметок ``07-outputs``.

    **Это warning-nudge, а не fail**: файл, положенный в папку без генерации, —
    легитимный случай, ложные срабатывания здесь дешевле пропусков. Read-only.
    """
    try:
        from core.operational.dod import unregistered_deliveries, window_hours
    except Exception as exc:  # noqa: BLE001
        return Check("Незакрытый контур (DOD-1)", "warn", f"config: {exc}",
                     "проверь core.operational.dod")
    try:
        hours = window_hours()
        rows = unregistered_deliveries()
    except Exception as exc:  # noqa: BLE001
        return Check("Незакрытый контур (DOD-1)", "warn", f"не прочитался аудит: {exc}",
                     "проверь .derived/logs/pult-actions.log")
    info = _replaced_deliveries_info(hours)
    if not rows:
        return Check("Незакрытый контур (DOD-1)", "ok",
                     f"файлов без output-регистрации нет (окно {hours:g} ч)" + info)
    shown = ", ".join(d.label for d in rows[:5])
    more = f" и ещё {len(rows) - 5}" if len(rows) > 5 else ""
    return Check(
        "Незакрытый контур (DOD-1)", "warn",
        f"файлы в хранилище без output-регистрации: {len(rows)} ({shown}{more})" + info,
        "закрой контур: save_output(text=…, title=…, file_refs=[…]) — путь файла "
        "должен попасть в заметку-output; файл без генерации — ложное срабатывание, ок",
    )


def _output_draft_check() -> Check:
    """DOD-2: папки выхода, начатые и не закрытые дольше суток.

    Фейлкейс 2026-08-11: контур собирался ПОСЛЕ работы, таймаут моста пришёлся на
    середину — в vault осталась полу-папка без ``prompt.md``/``output.md``. Теперь
    каркас создаётся до работы (``output_begin``), и цена этого — новый класс мусора:
    заявка, которую никто не дооформил. Её и показываем: нет ``output.md`` или мета
    ``status: draft`` дольше ``DT_OUTPUT_DRAFT_WARN_H`` (24 ч).

    **Warning, не fail** (как и DOD-1): папка в работе — легитимное состояние, а
    ложное срабатывание здесь дешевле пропуска. Read-only.
    """
    try:
        from core.operational.dod import draft_outputs, draft_warn_hours
    except Exception as exc:  # noqa: BLE001
        return Check("Недооформленный выход (DOD-2)", "warn", f"config: {exc}",
                     "проверь core.operational.dod")
    try:
        hours = draft_warn_hours()
        rows = draft_outputs()
    except Exception as exc:  # noqa: BLE001
        return Check("Недооформленный выход (DOD-2)", "warn",
                     f"не прочитались папки выхода: {exc}", "проверь 07-outputs")
    if not rows:
        return Check("Недооформленный выход (DOD-2)", "ok",
                     f"незакрытых папок выхода нет (порог {hours:g} ч)")
    # имена папок выхода длинные (дата + слаг заголовка) — показываем три старейших,
    # остальное счётчиком, чтобы строка доктора осталась читаемой
    shown = "; ".join(d.label for d in rows[:3])
    more = f" и ещё {len(rows) - 3}" if len(rows) > 3 else ""
    return Check(
        "Недооформленный выход (DOD-2)", "warn",
        f"папок выхода без закрытия: {len(rows)} ({shown}{more})",
        "дооформи: save_output(output_dir=…, text=…) — переведёт meta в final; "
        "работа не состоялась — удали папку, чтобы не выглядела оформленной",
    )


def _output_sources_check() -> Check:
    """SRC-TRACE-2: закрытые ad-hoc-выходы без ``sources.md`` (провенанс не собрался).

    Дефект 2 фейлкейса 2026-08-11: выход с 16 первоисточниками получил ноль
    машиночитаемого провенанса, и увидеть это было НЕГДЕ — папка выглядела
    оформленной. Теперь sources.md собирается телеметрией подъёмов сам; эта строка
    ловит остаток: выход закрыт, движок подбора не участвовал, а источников нет ни
    из телеметрии, ни руками (сессия работала мимо ``lift_source`` и не объявила
    ничего параметром ``sources``).

    Warning, не fail; порог тот же, что у draft-гарда (``DT_OUTPUT_DRAFT_WARN_H``).
    """
    try:
        from core.operational.dod import draft_warn_hours, outputs_without_sources
    except Exception as exc:  # noqa: BLE001
        return Check("Выход без источников (SRC-TRACE-2)", "warn", f"config: {exc}",
                     "проверь core.operational.dod")
    try:
        hours = draft_warn_hours()
        rows = outputs_without_sources()
    except Exception as exc:  # noqa: BLE001
        return Check("Выход без источников (SRC-TRACE-2)", "warn",
                     f"не прочитались папки выхода: {exc}", "проверь 07-outputs")
    if not rows:
        return Check("Выход без источников (SRC-TRACE-2)", "ok",
                     f"ad-hoc-выходы с провенансом (порог {hours:g} ч)")
    shown = "; ".join(d.rel_path for d in rows[:3])
    more = f" и ещё {len(rows) - 3}" if len(rows) > 3 else ""
    return Check(
        "Выход без источников (SRC-TRACE-2)", "warn",
        f"ad-hoc-выходов без sources.md: {len(rows)} ({shown}{more})",
        "источники собираются сами из подъёмов (lift_source) в окне begin→save; "
        "работали мимо движка — допиши save_output(sources=[{path, what_taken}])",
    )


def _chunk_sessions_check() -> Check:
    """ФТ-5: незавершённые сессии порционной записи (``.derived/chunked/``).

    Warning, если такие есть: сессия висит — значит доставка бинаря оборвалась, а её
    части занимают место (и ждут либо ``store_file_commit``, либо ``store_file_abort``).
    Чтение только состояний (цель+смещения), содержимого частей не касаемся; истёкшие
    по TTL снимаются тем же вызовом (ленивая чистка).
    """
    try:
        from core.operational.store_chunked import list_sessions
    except Exception as exc:  # noqa: BLE001
        return Check("Chunk-сессии (ФТ-5)", "warn", f"config: {exc}",
                     "проверь core.operational.store_chunked")
    try:
        sessions = list_sessions()
    except Exception as exc:  # noqa: BLE001
        return Check("Chunk-сессии (ФТ-5)", "warn", f"не прочитались: {exc}",
                     "проверь .derived/chunked (DT_CHUNK_SESSIONS_DIR)")
    if not sessions:
        return Check("Chunk-сессии (ФТ-5)", "ok", "висящих нет")
    top = sessions[0]
    return Check(
        "Chunk-сессии (ФТ-5)", "warn",
        f"незавершённых: {len(sessions)} (свежая — {top['path']}: "
        f"{top['bytes_done']}/{top['total_size']} байт)",
        "доставить остаток (store_file_append/commit) или снять store_file_abort; "
        "сами снимутся по TTL DT_CHUNK_SESSION_TTL_H",
    )


def _inbox_backlog_check() -> Check:
    """VAULT-1: не копится ли ``_staging/inbox`` (захваты не разобраны).

    Warning (НЕ fail), если файлов ``≥ INBOX_WARN_COUNT`` (env
    ``DT_INBOX_WARN_COUNT``) ИЛИ старейший старше ``INBOX_WARN_DAYS`` дней (env
    ``DT_INBOX_WARN_DAYS``). Read-only, содержимое не читаем — только листинг+mtime.
    """
    try:
        from core.config import staging_inbox_path
        from core.ingest import _INBOX_SUFFIXES
    except Exception as exc:  # noqa: BLE001
        return Check("Инбокс захватов", "warn", f"config: {exc}",
                     "проверь core.config / core.ingest")

    count_thr = _env_int("DT_INBOX_WARN_COUNT", INBOX_WARN_COUNT)
    days_thr = _env_int("DT_INBOX_WARN_DAYS", INBOX_WARN_DAYS)

    inbox = staging_inbox_path()
    if not inbox.is_dir():
        return Check("Инбокс захватов", "ok", "пуст")
    files = [
        p for p in inbox.iterdir()
        if p.is_file() and not p.name.startswith(".") and p.suffix.lower() in _INBOX_SUFFIXES
    ]
    if not files:
        return Check("Инбокс захватов", "ok", "пуст")

    now = time.time()
    oldest_days = int(max((now - p.stat().st_mtime) for p in files) // 86400)
    if len(files) >= count_thr or oldest_days > days_thr:
        return Check(
            "Инбокс захватов", "warn",
            f"{len(files)} захватов, старейший {oldest_days} дн",
            "разбери: скилл inbox-triage или refine_inbox",
        )
    return Check("Инбокс захватов", "ok", f"{len(files)} захватов (старейший {oldest_days} дн)")


def _db_check() -> Check:
    """Unified ``dt.db`` (DB-1): schema version + facts/sources/jobs row counts."""
    try:
        from core.config import dt_db_path
        from core.db import schema_version, table_counts

        path = dt_db_path()
    except Exception as exc:  # noqa: BLE001
        return Check("БД (dt.db)", "warn", f"config: {exc}", "проверь core/db / dt_db_path")
    if not path.is_file():
        return Check("БД (dt.db)", "warn", f"не создана: {path}",
                     "создастся при первом get_facts / lift_source / submit_job")
    try:
        ver = schema_version(path)
        counts = table_counts(path)
    except Exception as exc:  # noqa: BLE001
        return Check("БД (dt.db)", "warn", f"open: {exc}",
                     "снести dt.db → пересоберётся (facts/sources/jobs derivable)")
    detail = (
        f"dt.db schema v{ver} | facts {counts['facts']} / "
        f"sources {counts['sources']} / jobs {counts['jobs']}"
    )
    return Check("БД (dt.db)", "ok", detail,
                 "единая SQLite facts/sources/jobs с миграциями (DB-1)")


def _degradation_check() -> Check:
    """FAIL-TELEMETRY-1: где агенты спотыкались за окно (топ ``tool:code``).

    Дефекты движка находили реактивно — через боль пользователя («почему пропустили»),
    хотя отказ инструмента УЖЕ машиночитаем (CONTRACT-2) и его видел агент в своём
    сеансе. Здесь эти спотыкания сложены: повторяющаяся пара ``инструмент:код`` — это
    фейлкейс, который нашёл себя сам, до справки.

    Порог warn — ``DT_DEGRADATION_WARN_N`` (дефолт :data:`DEGRADATION_WARN_N`) на ОДНУ
    пару; ноль отказов → ok. Журнал не прочитался → warn ``store_unavailable``: молчать
    об этом значило бы показать «агенты не спотыкались» вместо «не знаю» (канон §9
    п.22 — на самой телеметрии).
    """
    name = f"Отказы инструментов ({DEGRADATION_WINDOW_DAYS} дн)"
    try:
        from core.contract import CODE_STORE_UNAVAILABLE, has_warning
        from core.metrics import degradation_summary

        summary = degradation_summary(days=DEGRADATION_WINDOW_DAYS)
    except Exception as exc:  # noqa: BLE001 — телеметрия не критична
        return Check(name, "warn", f"метрики: {exc}",
                     "проверь core.metrics / .derived/metrics/events.jsonl")

    if has_warning(summary, CODE_STORE_UNAVAILABLE):
        return Check(name, "warn", f"store_unavailable: {summary.get('journal')}",
                     "журнал метрик не прочитался — счётчиков нет; проверь доступ к "
                     ".derived/metrics/events.jsonl (ноль здесь означал бы «отказов нет»)")

    counters = summary.get("counters") or []
    if not counters:
        return Check(name, "ok", "агенты не спотыкались (0 отказов)",
                     "счётчик копится сам: каждый отказ инструмента оставляет "
                     "tool:code в журнале метрик")

    threshold = _env_int("DT_DEGRADATION_WARN_N", DEGRADATION_WARN_N)
    top = ", ".join(
        f"{c['tool']}:{c['code']} {c['count']}" for c in counters[:DEGRADATION_TOP_N]
    )
    more = len(counters) - DEGRADATION_TOP_N
    detail = (f"{_plural_ru(int(summary.get('total') or 0), 'отказ', 'отказа', 'отказов')}"
              f" — {top}")
    if more > 0:
        detail += f" (+{more} пар)"
    worst = counters[0]
    if int(worst.get("count") or 0) >= threshold:
        return Check(
            name, "warn", detail,
            f"{worst['tool']}:{worst['code']} — {worst['count']} раз за "
            f"{DEGRADATION_WINDOW_DAYS} дн (порог {threshold}, env "
            "DT_DEGRADATION_WARN_N): повторяющийся отказ — это фейлкейс, посмотри "
            "ветку этого кода",
        )
    return Check(name, "ok", detail,
                 f"единичные отказы — норма; жёлтым от {threshold} повторов одной пары")


def _files_freshness_check() -> Check:
    """WAVE1-MEASURE п.4 (аудит C10): свежесть захвата знаниевых файлов — «files:knowledge».

    Полный скан знаниевого корня не завершался с 15.10, а ни доктор, ни ``pult_freshness`` об
    этом не знали: шаг dt-sync отчитывается ``ok`` и после снятия сторожем. Берём ПОСЛЕДНИЙ
    ЗАВЕРШЁННЫЙ скан (``outcome=ok``): старше 48 ч (``STALE_AFTER_H``) или ни одного → warn.
    В детали — ``pending_download`` (dataless iCloud) и снятия сторожем за 7 дн.
    """
    name = "Свежесть files:knowledge"
    try:
        from core.operational.freshness import files_knowledge_row

        row = files_knowledge_row()
    except Exception as exc:  # noqa: BLE001 — монитор не критичен
        return Check(name, "warn", f"не проверена: {exc}", "проверь core.operational.freshness")
    extras = []
    if row.get("pending_download") is not None:
        extras.append(f"pending_download {row['pending_download']}")
    kills = int(row.get("watchdog_kills") or 0)
    extras.append(f"снято сторожем за 7 дн: {kills}"
                  + (f" (последнее {str(row['last_watchdog_kill'])[:16]})" if kills else ""))
    tail = "; ".join(extras)
    hint = ("шаг file_ingest_knowledge не доходит до конца: смотри dt-sync.log и run-watchdog "
            "(iCloud dataless — dt_ingest --route knowledge --apply вручную после прогрева)")
    if row["data_as_of"] is None:
        return Check(name, "warn", f"завершённого полного скана не видно; {tail}", hint)
    lag = float(row["lag_h"])
    when = f"последний полный скан {str(row['data_as_of'])[:16]}Z ({lag:.0f} ч назад)"
    if row["stale"]:
        return Check(name, "warn", f"{when}, порог {row['stale_after_h']:.0f} ч; {tail}", hint)
    return Check(name, "ok", f"{when}; {tail}",
                 "скан знаниевого корня идёт ночной цепочкой index")


USAGE_WINDOW_DAYS = 30


def _usage_check(known_tools: Iterable[str] | None) -> Check:
    """WAVE1-MEASURE п.2: «Инструменты без вызовов (30 дн): N из M» — деталь, не тревога.

    Решения о том, что убирать/сворачивать (волна 3), были догадками: у read-инструментов и
    вкладок пульта счётчика не было. Здесь — числа; полные списки по запросу
    (``pult_kpi(unused=true)`` / ``dt-kpi``). Статус ``ok`` всегда: молчащий инструмент — повод
    подумать, не поломка. ``warn`` — только если журнал не прочитался (ноль ≠ «не вызывали»).
    Пока телеметрия копится меньше окна — сказано прямо, число предварительное.
    """
    name = f"Инструменты без вызовов ({USAGE_WINDOW_DAYS} дн)"
    try:
        from core.contract import CODE_STORE_UNAVAILABLE, has_warning
        from core.metrics import usage_summary

        summary = usage_summary(USAGE_WINDOW_DAYS, known_tools=known_tools)
    except Exception as exc:  # noqa: BLE001 — телеметрия не критична
        return Check(name, "warn", f"метрики: {exc}", "проверь core.metrics")
    if has_warning(summary, CODE_STORE_UNAVAILABLE):
        return Check(name, "warn", f"store_unavailable: {summary.get('journal')}",
                     "журнал метрик не прочитался — употребление не посчитано")
    if not summary.get("observed_since"):
        return Check(name, "ok", "телеметрия вызовов ещё не накоплена (включится после "
                     "рестарта MCP-сервера: guarded_tool)",
                     "tool_call пишет граница MCP; после рестарта Desktop счётчик пойдёт")
    parts: list[str] = []
    if "unused_tools" in summary:
        parts.append(f"инструментов без вызовов: {len(summary['unused_tools'])} "
                     f"из {summary.get('tools_total', '?')}")
    else:
        parts.append(f"вызывалось инструментов: {len(summary['tools'])}")
    parts.append(f"вкладок/секций пульта без открытий: {len(summary['unused_ui'])} "
                 f"из {summary.get('ui_total', '?')}")
    cov = float(summary.get("coverage_days") or 0.0)
    since = str(summary["observed_since"])[:10]
    tail = (f"телеметрия копится с {since} ({cov:.0f} из {USAGE_WINDOW_DAYS} дн — "
            "число предварительное)") if cov < USAGE_WINDOW_DAYS else f"данные с {since}"
    by_surface = summary.get("tools_by_surface") or {}
    if by_surface:  # PULT-STANDALONE-1: разрез по поверхности (mcp = артефакт и MCP-хосты)
        parts.append("вызванных инструментов по поверхностям: "
                     + ", ".join(f"{k} {len(v)}" for k, v in by_surface.items()))
    return Check(name, "ok", "; ".join(parts) + "; " + tail,
                 "полные списки: pult_kpi(unused=true) — это материал для решений волны 3, "
                 "не поломка")


def _pult_surfaces_check(*, path: Path | None = None, now: datetime | None = None) -> Check:
    """PULT-STANDALONE-1 п.6: «Пульт: поверхности» - кто реально пользуется пультом (30 дн).

    Артефакт Cowork - поверхность ``mcp`` (открытия вкладок ``ui:*`` приходят только из страницы
    пульта), веб-пульт - ``webpult``; события до разметки - ``unknown``. Числа: открытия вкладок/
    секций и вызовы ``pult_*``/``work_*`` по поверхности, последнее открытие веб-пульта. Статус
    ``ok`` всегда (факт для решения «что первично», не поломка); ``warn`` - журнал не прочитался.
    """
    name = "Пульт: поверхности"
    try:
        from core.contract import CODE_STORE_UNAVAILABLE, has_warning
        from core.metrics import usage_summary

        summary = usage_summary(30, now=now, path=path)
    except Exception as exc:  # noqa: BLE001 - телеметрия не критична
        return Check(name, "warn", f"метрики: {exc}", "проверь core.metrics")
    if has_warning(summary, CODE_STORE_UNAVAILABLE):
        return Check(name, "warn", f"store_unavailable: {summary.get('journal')}",
                     "журнал метрик не прочитался - употребление по поверхностям не посчитано")
    rows = {str(r["surface"]): r for r in summary.get("surfaces", [])}
    art, web, unk = (rows.get(k, {}) for k in ("mcp", "webpult", "unknown"))
    last_web = str(web.get("last_ui_ts") or "")[:16].replace("T", " ") or "нет"
    detail = (
        f"за 30 дн: артефакт {art.get('ui_opens', 0)} открытий / {art.get('pult_calls', 0)} "
        f"вызовов, веб-пульт {web.get('ui_opens', 0)} / {web.get('pult_calls', 0)}"
        f"{', без метки ' + str(unk['pult_calls']) + ' вызовов' if unk.get('pult_calls') else ''}"
        f"; последнее открытие веб-пульта: {last_web}"
    )
    return Check(name, "ok", detail,
                 "решение «что первично» - по этим числам (dt pult open; замер surface=webpult)")


def _pult_ai_check(*, events: list[dict[str, Any]] | None = None) -> Check:
    """GATEWAY-1 п.6: «ИИ-шлюз» - по каждому классу задач маршрут и состояние профиля.

    Строка: ``triage -> cheap (openai/kimi-k2, ключ ...abcd, внешний, данные уходят)``; маршрут
    ``none`` - «база движка», ``host`` - «хост (askClaude)». Профили без маршрута - info (в строке).
    ``warn``: маршрут на профиль без ключа (``openai|anthropic``) или без модели, на несуществующий
    профиль, права файла ключа шире 600, у профиля отказов больше половины вызовов за 7 дн. Плоский
    конфиг (PULT-STANDALONE-1) - ``ok`` с подсказкой ``dt ai migrate``. Данные провайдеру уходят по
    явному выбору пользователя (внешний url) - строка это говорит.
    """
    name = "ИИ-шлюз"
    try:
        from core.operational import ai_gateway, ai_layer

        cfg = ai_layer.get_settings()
        view = ai_layer.settings_view(cfg)
        use = ai_layer.usage(7, events=events)
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        return Check(name, "warn", f"настройки ИИ-слоя не прочитаны: {exc}", "проверь pult.yaml")
    problems: list[str] = []
    parts: list[str] = []
    groups: dict[str, list[str]] = {}  # классы с одним маршрутом - одной частью строки
    for cls in ai_gateway.CLASSES:
        groups.setdefault(view["routes"][cls], []).append(cls)
    for target, classes in groups.items():
        label = ", ".join(classes)
        first = classes[0]
        err = view["route_errors"].get(first)
        if err:
            parts.append(f"{label} -> {target}: {err}")
            problems.append(f"{label}: профиля {target!r} нет (dt ai set route {first} <профиль>)")
            continue
        side = view["sides"][first]
        if side == "none":
            parts.append(f"{label} -> {target}: база движка")
            continue
        if side == "host":
            parts.append(f"{label} -> {target}: хост (askClaude)")
            continue
        prof = view["profiles"][target]
        key = prof["key"]
        tail = f"ключ ...{key['tail']}" if key["configured"] else "ключа нет"
        where = ("локальный url, данные остаются" if not view["sends_data_out"][first]
                 else "данные уходят провайдеру (явный выбор)")
        parts.append(f"{label} -> {target} ({prof['provider']}/{prof['model'] or '?'}, {tail}, "
                     f"{where})")
        if not key["configured"]:
            problems.append(f"профиль {target}: ключа нет, dt ai set-key --profile {target} "
                            f"(файл .secrets/{key['file']})")
        elif not key["mode_ok"]:
            problems.append(f"профиль {target}: права файла ключа шире 600: chmod 600")
        if not prof["model"]:
            problems.append(f"профиль {target}: модель не задана: dt ai set profile {target} "
                            "model=...")
    unrouted = sorted(set(view["profiles"]) - set(view["routes"].values()))
    # профиль default плоской формы без маршрута не бывает; пустой default новой формы - тоже не шум
    unrouted = [n for n in unrouted if view["profiles"][n]["provider"] != "none"]
    detail = "; ".join(parts)
    if unrouted:
        detail += f"; профили без маршрута: {', '.join(unrouted)}"
    daemon = any(v == "daemon" for v in view["sides"].values())
    if daemon:
        detail += (f"; за 7 дн вызовов {use['calls']}, отказов {use['errors']}, "
                   f"кэш-попаданий {use['cache_hits']}")
    for prof_name, row in sorted(use["by_profile"].items()):
        if row["calls"] and row["errors"] / row["calls"] > 0.5:
            problems.append(f"профиль {prof_name}: отказов больше половины: dt ai test, "
                            "провайдер/ключ/url")
    hint = ""
    if view["legacy_flat"]:
        hint = "плоский конфиг ai (профиль default): dt ai migrate перепишет в профили и маршруты"
    if all(v == "none" for v in view["sides"].values()) and not view["legacy_flat"]:
        hint = hint or ("включить: dt ai set profile <имя> provider=..., "
                        "dt ai set route <класс> <имя>")
    if problems:
        return Check(name, "warn", detail, "; ".join(problems))
    return Check(name, "ok", detail, hint)


def _queue_decisions_check(
    *,
    events: list[dict[str, Any]] | None = None,
    totals: dict[str, int] | None = None,
    errors: dict[str, str] | None = None,
    now: datetime | None = None,
) -> Check:
    """QUEUE-SERVER-1 п.3: «Очередь решений» - сколько ждет по видам и как решается за 30 дн.

    ``ждут`` - pending по видам реестра (``core.decisions``; eval-кандидаты читаются из кэша, без
    пересчета); ``принято/отклонено`` - события решений за 30 дн с долей принятых
    (:mod:`core.decisions.stats`). ``warn``: у вида больше 100 ждущих; доля принятых < 20% при >= 30
    решениях («детектор шумит: <вид>» - ЗАМЕР, правка детектора отдельным ТЗ); вид не прочитался.
    ``events``/``totals`` инжектируются (тесты), иначе читаются боевые журнал и сторы (read-only).
    """
    name = "Очередь решений"
    try:
        from core.decisions import pending_totals
        from core.decisions import stats as qstats
        from core.metrics import read_events

        now_dt = now or datetime.now(UTC)
        if events is None:
            events = read_events(since=now_dt - timedelta(days=qstats.WINDOW_DAYS))
        if totals is None:
            totals, errors = pending_totals()
        stats = qstats.decision_stats(events)
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        return Check(name, "warn", f"очередь не прочитана: {exc}", "проверь core.decisions")
    errors = errors or {}
    waiting = ", ".join(f"{k} {n}" for k, n in sorted(totals.items(), key=lambda t: -t[1]) if n)
    decided = ", ".join(
        f"{k} {row['approved']}/{row['rejected']}"
        + (f" ({round(100 * (qstats.share(row) or 0))}%)" if qstats.share(row) is not None else "")
        for k, row in sorted(stats.items())
    )
    detail = (f"ждут: {waiting or 'ничего'}; за {qstats.WINDOW_DAYS} дн принято/отклонено: "
              f"{decided or 'решений нет'}")
    problems: list[str] = []
    for kind in qstats.noisy_kinds(stats):
        row = stats[kind]
        total = row["approved"] + row["rejected"]
        problems.append(f"детектор шумит: {kind} (принято {row['approved']} из {total}) - "
                        "замер, правка детектора отдельным ТЗ")
    for kind, n in sorted(totals.items()):
        if n > qstats.PENDING_WARN:
            problems.append(f"вид {kind}: {n} ждущих (> {qstats.PENDING_WARN}) - очередь копится")
    for kind, code in sorted(errors.items()):
        problems.append(f"вид {kind} не прочитан ({code})")
    if problems:
        return Check(name, "warn", detail, "; ".join(problems))
    return Check(name, "ok", detail)


def _host_access_checks() -> list[Check]:
    """VENDOR-HYGIENE-1 п.6: доступ хостов к папкам (``vault/_system/host-access.yaml``).

    Две строки. «Доступ хостов: папки с _nda не выданы» — правило «``_nda`` никому» по самому
    yaml (``warn`` с перечнем хост→папка; нет файла → ``warn``; нечитаемый → ``fail``).
    «Хосты без записи в host-access» — хост из телеметрии за 30 дн (MCP-поверхность), которого
    нет в yaml, → ``warn`` с его именем (так же добавляется и новый хост: он сам себя
    называет в handshake). Журнал метрик не прочитался → строка ``warn`` «сверка не сделана»
    (ноль «неизвестных» без данных был бы ложью).
    """
    name_nda = "Доступ хостов: папки с _nda не выданы"
    name_seen = "Хосты без записи в host-access"
    try:
        from core.host_access import (
            anonymous_hosts,
            host_access_path,
            load_host_access,
            nda_folders,
            seen_mcp_hosts,
            unregistered_hosts,
        )

        path = host_access_path()
        entries, error = load_host_access(path)
        seen = seen_mcp_hosts()
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return [Check(name_nda, "warn", f"host-access не прочитан: {exc}",
                      "проверь core.host_access")]
    hint_create = (f"создай {path}: «имя хоста из handshake → {{folders, granted, note}}» "
                   "(доступ хостов к папкам, один набор правил для всех)")
    if error:
        missing = error.startswith("нет файла")
        return [Check(name_nda, "warn" if missing else "fail", error,
                      hint_create if missing else f"поправь {path} (ошибка названа выше)"),
                Check(name_seen, "warn", "сверка не сделана: реестр хостов недоступен",
                      hint_create)]
    leaks = nda_folders(entries)
    folders_n = sum(len(e.folders) for e in entries.values())
    if leaks:
        first = "; ".join(f"{h}: {f}" for h, f in leaks[:3])
        nda = Check(name_nda, "warn", f"выдано под NDA: {first}",
                    f"убери эти папки из {path}: папки _nda не выдаются никому")
    else:
        nda = Check(name_nda, "ok", f"хостов {len(entries)}, папок {folders_n} — под NDA ничего")
    if seen is None:
        return [nda, Check(name_seen, "warn", "сверка не сделана: журнал метрик не прочитался",
                           "ноль неизвестных без данных был бы ложью")]
    unknown = unregistered_hosts(entries, seen)
    anon = anonymous_hosts(seen)
    anon_note = ""
    if anon:  # KIMI-INSTALL-2: отдельно, без предложения вписать в реестр
        anon_note = ("; анонимный клиент (имя SDK по умолчанию) - хост поднял сервер сам: "
                     + ", ".join(f"{r['host']} ({r['calls']} вызовов)" for r in anon))
    if unknown:
        return [nda, Check(name_seen, "warn", ", ".join(unknown) + anon_note,
                           f"хост ходит в DT, но не записан в {path}: добавь запись "
                           "(folders: [] — если папки не выданы)")]
    named = len(seen) - len(anon)
    return [nda, Check(name_seen, "ok", f"в телеметрии за {USAGE_WINDOW_DAYS} дн: "
                       f"{named} хост(ов), все записаны{anon_note}")]


def _host_outputs_check() -> Check:
    """MODEL-1 п.A3: «Хосты: выходы» - хост из телеметрии, но без выходов; выход без ``host``.

    * ``warn`` - в окне 30 дн есть выходы БЕЗ ``host`` в мете, созданные после того, как движок
      начал штамповать хост (дефект гигиены: контур выхода пишет мету мимо ``provenance_fields``);
      старые папки без поля - не дефект (не бэкфиллятся);
    * ``ok`` со справкой - MCP-хост ходит в DT, но выходов от него нет (читает, но не возвращает
      результат в vault, либо ему еще не давали задач);
    * журнал метрик не прочитался - сверка по телеметрии пропущена, выходы проверены.
    """
    name = "Хосты: выходы"
    try:
        from core.eval_generation import host_outputs_health
        from core.host_access import seen_mcp_hosts

        seen = seen_mcp_hosts()
        health = host_outputs_health([r["host"] for r in seen] if seen is not None else None)
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"выходы по хостам не прочитаны: {exc}",
                     "проверь core.eval_generation")
    days = health["days"]
    if health["missing"]:
        first = ", ".join(health["missing"][:3])
        return Check(name, "warn",
                     f"выходов без host за {days} дн: {len(health['missing'])} ({first}) - "
                     f"хосты штампуются с {str(health['adopted_since'])[:10]}",
                     "output_begin/save_output обязаны писать host (core.output."
                     "provenance_fields): найди путь, что пишет мету мимо него")
    note = ""
    if health["silent"]:
        note = ("; справка: хост в телеметрии, но без выходов - "
                + ", ".join(health["silent"]))
    if seen is None:
        note += "; сверка с телеметрией не сделана (журнал не прочитался)"
    return Check(name, "ok",
                 f"выходов за {days} дн: {health['total']}, хостов с выходами "
                 f"{len(health['hosts'])}{note}")


def _output_runs_check() -> Check:
    """EVAL-HYGIENE-1 п.5: «Выходы: прогоны» - сколько выходов ``eval``/``selftest`` и чисто ли.

    * ``warn`` - прогон с доставкой ВНЕ ``_eval`` (файл прогона лежит в папке клиента), selftest-
      папка в ``07-outputs`` (мусор самопроверки) либо выход, который определяется как прогон,
      но еще не помечен (``dt outputs mark``): синтез/линт/поиск по клиенту иначе увидят его как
      работу;
    * ``ok`` - прогоны помечены, их доставки только в ``_eval``. Read-only."""
    name = "Выходы: прогоны"
    try:
        from core.outputs_mark import runs_status

        st = runs_status()
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        return Check(name, "warn", f"прогоны не прочитаны: {exc}", "проверь core.outputs_mark")
    head = f"прогонов: eval {st['eval']}, selftest {st['selftest']}"
    problems: list[str] = []
    if st["offside"]:
        problems.append(f"доставка вне _eval: {len(st['offside'])} ({st['offside'][0]})")
    if st["selftest_folders"]:
        problems.append(f"selftest-папок в 07-outputs: {len(st['selftest_folders'])} "
                        f"({st['selftest_folders'][0]})")
    unmarked_only = [u for u in st["unmarked"]
                     if u not in st["offside"] and u not in st["selftest_folders"]]
    if unmarked_only:
        problems.append(f"не помечено: {len(unmarked_only)} ({unmarked_only[0]})")
    if problems:
        return Check(name, "warn", f"{head}; " + "; ".join(problems),
                     "uv run python cli/dt.py outputs mark --dry-run - список; без флага - "
                     "пометить, перенести файлы в _eval, удалить selftest-папки")
    return Check(name, "ok", f"{head}; доставки прогонов - только в _eval")


def _output_provenance_check() -> Check:
    """PROV-SESSION-1 п.6: «Выходы: провенанс» - сессионный провенанс ad-hoc-выходов за 30 дн.

    Всего / с телеметрией сессии (``read``/``lift``/``facts``/поиск) / только руками
    (``sources=``) / без провенанса. ``warn``: без провенанса есть выход за 7 дн ИЛИ журнал
    запросов выключен (``DT_EVAL_QUERY_LOG=0`` гасит и провенанс сессии, не только кандидатов
    золотого набора).
    Движковые (``generate``) выходы - отдельным счетом: их провенанс пишет сам движок. Read-only."""
    name = "Выходы: провенанс"
    try:
        from core.outputs_sources import provenance_status

        st = provenance_status()
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        return Check(name, "warn", f"провенанс не прочитан: {exc}", "проверь core.outputs_sources")
    total = st["total"]
    share = f" ({round(100 * st['telemetry'] / total)}%)" if total else ""
    head = (f"за 30 дн ad-hoc-выходов {total}: с телеметрией сессии {st['telemetry']}{share}, "
            f"только руками {st['manual']}, без провенанса {st['none']}"
            + (f"; движковых {st['engine']}" if st["engine"] else ""))
    problems: list[str] = []
    if not st["journal_on"]:
        problems.append("провенанс выключен: DT_EVAL_QUERY_LOG=0 гасит журнал запросов, из "
                        "которого собираются чтения/поиски сессии")
    if st["recent_none"]:
        problems.append(f"без провенанса за 7 дн: {len(st['recent_none'])} "
                        f"({st['recent_none'][0]})")
    if problems:
        return Check(name, "warn", f"{head}; " + "; ".join(problems),
                     "DT_EVAL_QUERY_LOG=1 (или убери 0); прошлым выходам - uv run python cli/dt.py "
                     "outputs sources --dry-run; работали мимо DT - save_output(sources=[…])")
    return Check(name, "ok", head)


def _kimi_plugin_check() -> Check:
    """MODEL-1 п.D + KIMI-INSTALL-1: «Плагин Kimi: собран <дата>, скиллов N, профиль lean ·
    установлен в Kimi <дата>, манифест = сборка».

    Источник сборки - ``.derived/status/kimi-plugin.json`` (пишет ``dt plugin kimi``), установки -
    каталог Kimi (``core.kimi_install``, только чтение). ``warn``: статус битый; самопроверка
    сервера при сборке не прошла; каталог плагина исчез; реестр скиллов изменился после сборки
    (пересобрать); в Kimi устаревший плагин (сервер не существует / манифест и скиллы разошлись
    со сборкой / запись отключена). Плагин не собирали или в Kimi не поставлен - ``ok`` со
    справкой (второй хост не обязателен); отсутствие каталога Kimi - тоже справка, не warn."""
    name = "Плагин Kimi"
    try:
        from core.kimi_plugin import plugin_skills, read_status, skills_digest
        from core.skills import load_skills

        record, error = read_status()
        skills_now = load_skills()
        # MODEL-1-FIT: в плагине - только скиллы профиля; пересчитываем по инструментам профиля
        # на момент сборки (старый статус без них - весь реестр, как было). PULT-SURFACE-2 п.5: в
        # составе и скилл ``dt-owner`` с версией профиля владельца - ту же функцию зовет сборка.
        tools_then = (record or {}).get("profile_tools")
        owner_now = ""
        if isinstance(tools_then, list) and tools_then:
            skills_now, _skip, owner_now, _note = plugin_skills(
                skills_now, lint_tools=tools_then, profile_tools=tools_then)
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"статус плагина не прочитан: {exc}", "проверь core.kimi_plugin")
    rebuild = "uv run python cli/dt.py plugin kimi --out plugins/kimi-work --install"
    if error:
        return Check(name, "warn", f"статус сборки не читается: {error[:200]}",
                     f"пересобери: {rebuild}")
    kimi = _kimi_install_state(record)
    if record is None:
        if kimi["stale"]:
            return Check(name, "warn", f"в Kimi устаревший плагин: {kimi['reason']}",
                         f"собери и поставь: {rebuild}")
        return Check(name, "ok", "справка: плагин не собирался (второй хост подключается через "
                     f"`{rebuild}`)")
    date = str(record.get("built_at") or "")[:10] or "?"
    skipped_n = len(record.get("skipped") or {})
    detail = (f"собран {date}, скиллов {len(record.get('skills') or [])}, "
              f"профиль {record.get('profile')}"
              + (f" (вне профиля: {skipped_n})" if skipped_n else ""))
    if record.get("selftest_ok") is False:
        return Check(name, "warn", f"{detail}; самопроверка сервера НЕ прошла: "
                     f"{record.get('selftest') or '?'}", f"пересобери и посмотри вывод: {rebuild}")
    out = record.get("out")
    if out and not Path(str(out)).is_dir():
        return Check(name, "warn", f"{detail}; каталога плагина нет: {out}",
                     f"пересобери: {rebuild}")
    if record.get("skills_digest") != skills_digest(skills_now, owner_now):
        built_owner = record.get("owner_version")
        if "owner_version" not in record and owner_now:
            why = "в плагине нет скилла dt-owner (сборка до PULT-SURFACE-2)"
        elif (built_owner or "") != owner_now:
            why = (f"профиль владельца изменился после сборки ({built_owner or 'не было'} → "
                   f"{owner_now or 'нет'}): dt-owner в плагине устарел")
        else:
            why = "реестр скиллов изменился после сборки - плагин устарел"
        return Check(name, "warn", f"{detail}; {why}",
                     f"пересобери плагин: {rebuild}")
    if not kimi["found"]:
        return Check(name, "ok", f"{detail} · справка: Kimi не найден, плагин не установлен")
    if kimi["stale"]:
        return Check(name, "warn", f"{detail} · в Kimi устаревший плагин: {kimi['reason']}",
                     f"поставь заново: {rebuild}")
    if not kimi["installed"]:
        return Check(name, "ok", f"{detail} · справка: в Kimi не установлен (`{rebuild}`)")
    base = f"{detail} · установлен в Kimi {kimi['date']}, манифест = сборка"
    if kimi["mcp"] == "registered":
        from core.host_config import daemon_port

        return Check(name, "ok", f"{base} · MCP агента: url → :{daemon_port()}/lean")
    if kimi["mcp"] == "stdio_legacy":
        return Check(name, "warn",
                     f"{base} · MCP агента: старая stdio-запись (свой процесс движка на сессию, "
                     "код отстает от демона)",
                     f"{rebuild}: запись заменится url демона; затем перезапусти Kimi Work")
    why = ("MCP агента расходится с ожидаемой url-записью" if kimi["mcp"] == "differs"
           else "MCP агента не зарегистрирован")
    extra = f" ({kimi['mcp_reason']})" if kimi["mcp"] in ("differs", "invalid") else ""
    return Check(name, "warn",
                 f"{base} · {why}{extra} - инструменты DT хосту не видны, модель будет писать "
                 "свой клиент",
                 f"{rebuild}, затем перезапусти Kimi Work (скиллы и MCP агента подхватятся "
                 "в новой сессии)")


def _kimi_install_state(record: dict[str, Any] | None) -> dict[str, Any]:
    """Что стоит в Kimi против сборки (только чтение; сбой чтения - как «не найден»).

    ``{found, installed, stale, reason, date, mcp, mcp_reason}``: ``installed`` - запись плагина
    есть; ``stale``/``reason`` - расхождения ПЛАГИНА (скиллы, манифест, устаревший спайк); ``mcp`` -
    ``registered|missing|differs|invalid`` (``mcp.json`` агента, KIMI-INSTALL-2) отдельно: плагин
    без MCP - свой warn («инструменты DT хосту не видны»)."""
    empty = {"found": False, "installed": False, "stale": [], "reason": "", "date": "",
             "mcp": "", "mcp_reason": ""}
    try:
        from core.host_config import PLUGIN_DIR
        from core.kimi_install import verify_install

        build = Path(str((record or {}).get("out") or PLUGIN_DIR))
        verdict = verify_install(build)
    except Exception:  # noqa: BLE001
        return empty
    plugin_codes = [c for c in verdict["stale"] if not c.startswith("mcp_")]
    if record is None:
        plugin_codes = [c for c in plugin_codes if c != "no_build"]
    # не поставлен вовсе (нет записи) - справка, а не устаревший плагин; warn - если что-то стоит
    # неправильно (старый плагин спайка, расхождение со сборкой, отключен)
    installed = bool(verdict["installed"])
    if plugin_codes == ["no_entry"]:
        plugin_codes = []
    date = str(verdict.get("updated_at") or verdict.get("installed_at") or "")[:10] or "?"
    reason = str(verdict.get("plugin_reason") or verdict["reason"]) if plugin_codes else ""
    return {"found": bool(verdict.get("kimi_found")), "installed": installed,
            "stale": plugin_codes, "reason": reason, "date": date,
            "mcp": str(verdict.get("mcp") or ""),
            "mcp_reason": str(verdict.get("mcp_reason") or "")}


def _pult_copies_check() -> Check:
    """VENDOR-HYGIENE-1 п.5: «Пульт: копии» — тело артефакта пульта = тело репо.

    Источник HTML — ``webpult/pult.html`` (репо); артефакт Cowork — зеркало для Desktop, его
    allowlist (шапка до ``<html lang="ru">``) свой. Сравнивается тело. Расхождение → ``warn`` с
    подсказкой (пересинхронизировать тело, шапку не трогать); артефакта нет → ``ok``.
    """
    name = "Пульт: копии"
    marker = '<html lang="ru">'
    try:
        from core.config import ENGINE_ROOT

        repo = ENGINE_ROOT / "webpult" / "pult.html"
        artifact = Path.home() / "Claude" / "Artifacts" / "dt-pult" / "index.html"
        if not repo.is_file():
            return Check(name, "warn", f"нет {repo}", "источник пульта — webpult/pult.html")
        if not artifact.is_file():
            return Check(name, "ok", "артефакт-копия не установлена — пульт отдается из репо")
        repo_text = repo.read_text(encoding="utf-8")
        art_text = artifact.read_text(encoding="utf-8")
        if marker not in repo_text or marker not in art_text:
            return Check(name, "warn", "не найден разделитель шапки/тела (<html lang=\"ru\">)",
                         "сравнить тела не удалось — проверь оба файла")
        same = repo_text[repo_text.index(marker):] == art_text[art_text.index(marker):]
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"сравнение не удалось: {exc}", "проверь пути пульта")
    if same:
        return Check(name, "ok", "тело артефакта = тело webpult/pult.html")
    return Check(name, "warn", "тело артефакта ≠ webpult/pult.html",
                 "источник — репо: пересинхронизируй ТЕЛО артефакта (allowlist-шапку не меняй)")


def _ingress_sources_check(
    *, log_path: Path | None = None, now: datetime | None = None
) -> Check:
    """INGRESS-1 п.1: «Вход: источники» — ОДИН чек по реестру адаптеров входа.

    По каждому адаптеру: последний прогон (из dt-sync-лога по имени шага и из ``last_runs.json``) и
    итог диспозиций; плюс отказы за 7 дн (``refusals_summary``). ``warn``: адаптер с порогом
    ``stale_after_h`` без прогона дольше порога (или ни разу); журнал отказов нечитаем
    (``store_unavailable``). Специальные чеки (дедуп/треды/инбокс) остаются отдельными строками.
    """
    name = "Вход: источники"
    try:
        from core.config import sync_log_path
        from core.contract import CODE_STORE_UNAVAILABLE, has_warning
        from core.ingress import registry
        from core.ingress.refusals import refusals_summary
        from core.ingress.run import read_last_runs
        from core.operational.synclog import iter_step_lines

        now_dt = (now or datetime.now(UTC)).astimezone(UTC)
        try:
            log_lines = (log_path or sync_log_path()).read_text(
                encoding="utf-8", errors="replace").splitlines()
        except OSError:
            log_lines = []
        step_ts: dict[str, datetime] = {}
        for ts, step, ok in iter_step_lines(log_lines):
            if ok:
                try:
                    step_ts[step] = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").astimezone(UTC)
                except ValueError:
                    continue
        last = read_last_runs()
        summary = refusals_summary(7)
        from core.instance import instance_role

        role = instance_role()  # PERSONAL-3: у личной нет почты/Timetta/легаси - их строк нет
        adapters = registry.adapters(role=role)
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"реестр входа не прочитан: {exc}", "проверь core.ingress")

    parts: list[str] = []
    stale: list[str] = []
    for a in adapters:
        moments: list[datetime] = []
        if a.step and a.step in step_ts:
            moments.append(step_ts[a.step])
        rec = (last.get(a.key) or {}).get("last_apply") or {}
        try:
            moments.append(datetime.strptime(rec["ts"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC))
        except (KeyError, ValueError, TypeError):
            pass
        newest = max(moments) if moments else None
        age_h = (now_dt - newest).total_seconds() / 3600 if newest else None
        tail = ""
        if rec:
            tail = (f" (new {rec.get('new', 0)}, changed {rec.get('changed', 0)}, "
                    f"отказов {rec.get('refused', 0)})")
        if age_h is None:
            parts.append(f"{a.key}: прогонов нет")
        else:
            parts.append(f"{a.key}: {age_h:.0f} ч назад{tail}")
        if a.stale_after_h is not None and a.step and (age_h is None or age_h > a.stale_after_h):
            stale.append(a.key)
    refused = summary.get("total", 0)
    detail = "; ".join(parts) + f"; отказов за 7 дн: {refused}"
    if role == "work":
        detail += "; " + _mail_gap_text()
    # MAIL-PRIVACY-2: снятое по приватности - отдельной цифрой (почта пишет privacy_probe с
    # классом правила; тем/участников в журнале нет)
    private = sum(r.get("privacy_probe", 0) for r in summary.get("by_adapter", {}).values())
    detail += f"; снято по приватности за 7 дн: {private}"
    if has_warning(summary, CODE_STORE_UNAVAILABLE):
        return Check(name, "warn", detail + "; журнал отказов НЕ прочитался",
                     "проверь .derived/ingress/refusals.jsonl (store_unavailable): ноль отказов "
                     "без чтения журнала ничего не доказывает")
    if stale:
        return Check(name, "warn", detail + f"; без прогона дольше порога: {', '.join(stale)}",
                     "проверь launchd (dt-sync fast/index) и лог dt-sync.log; руками: "
                     "dt_sync fast | index")
    return Check(name, "ok", detail)


def _mail_gap_text() -> str:
    """MAIL-GAP-1 п.2: результат последнего смоука С-13 одной фразой. Сам замер в доктор не кладем
    (листинг папки - минуты): только то, что смоук записал в свой лог."""
    try:
        from core.config import mail_gap_max
        from core.legacy.mail_gap import last_gap
        from core.smoke import smoke_log_path

        lines = smoke_log_path().read_text(encoding="utf-8").splitlines()
        gap = last_gap(lines)
    except Exception:  # noqa: BLE001 — лог смоука не критичен для доктора
        gap = None
    if gap is None:
        return "дыра курсора: не замерялась (смоук С-13)"
    when = f", смоук {gap['ts'][:10]}" if gap.get("ts") else ""
    over = f" (> порога {mail_gap_max()})" if not gap["ok"] else ""
    return f"дыра курсора за {gap['days']} дн: {gap['added']}{over}{when}"


def _web_tokens_check(
    directory: Path | None = None, env: dict[str, str] | None = None
) -> Check:
    """WEBPULT-ACCESS-1 п.3: «Веб-пульт: токены» — read и rw заданы, права файлов 0600, возраст rw.

    ``warn``: rw-токена нет (создастся при старте сервиса; до тех пор решения с веба
    недоступны), права файла шире 0600, read = rw (разделение прав пустое), rw старше
    :data:`core.web_tokens.RW_WARN_DAYS` дней (подсказка перевыпустить), read-токена нет.
    Только чтение (токены не генерируются и не печатаются).
    """
    name = "Веб-пульт: токены"
    try:
        from core.web_tokens import RW_WARN_DAYS, WebTokens, inspect_tokens

        info = inspect_tokens(directory, env)
        tokens = WebTokens(directory, env)
        same = bool(tokens.read()) and tokens.read() == tokens.rw()
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"токены не прочитаны: {exc}", "проверь core.web_tokens")
    read, rw = info["read"], info["rw"]
    problems: list[str] = []
    hints: list[str] = []
    if not read.configured:
        problems.append("read-токена нет")
        hints.append("создастся при старте веб-сервиса (или dt web-token rotate read)")
    if not rw.configured:
        problems.append("rw-токена нет")
        hints.append("создастся при старте веб-сервиса (или dt web-token rotate rw); пока решения "
                     "с веб-пульта недоступны")
    for t in (read, rw):
        if t.configured and t.source == "file" and not t.mode_ok:
            problems.append(f"права {t.name}-файла {t.mode} (нужно 600)")
            hints.append("chmod 600 .secrets/web_token*")
    if same:
        problems.append("read и rw совпадают")
        hints.append("dt web-token rotate rw — иначе разделение прав пустое")
    if rw.age_days is not None and rw.age_days > RW_WARN_DAYS:
        problems.append(f"rw-токену {rw.age_days:.0f} дн (> {RW_WARN_DAYS})")
        hints.append("перевыпусти: dt web-token rotate rw (старая rw-ссылка и cookie перестанут "
                     "работать сразу)")
    if problems:
        return Check(name, "warn", "; ".join(problems), "; ".join(hints))
    age = f", rw выдан {rw.age_days:.0f} дн назад" if rw.age_days is not None else ""
    return Check(name, "ok", f"read: {read.source}, rw: {rw.source}{age}")


def _config_check(
    *,
    run: Callable[[], Any] | None = None,
) -> Check:
    """CONFIG-1 п.4: «Конфиг» - результат ``dt config check`` одной строкой + режим local|server.

    ``ok`` - замечаний нет; ``warn`` - неизвестные/устаревшие/пустые обязательные ключи, права
    ``.env``/``.secrets``, несовместимости. В тексте только ИМЕНА ключей, значений нет. ``run`` -
    инъекция результата (``core.config.report.CheckResult``) для тестов."""
    name = "Конфиг"
    try:
        if run is None:
            from core.config import engine_env_path
            from core.config.report import check as _check_env
            from core.web_tokens import secrets_dir

            result = _check_env(engine_env_path(), secrets_dir=secrets_dir())
        else:
            result = run()
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"проверка конфига не выполнилась: {type(exc).__name__}",
                     "uv run python cli/dt.py config check")
    if result.status == "ok":
        return Check(name, "ok", result.summary())
    return Check(name, "warn", result.summary(),
                 "uv run python cli/dt.py config check - подробности; ключ правится "
                 "`dt config set KEY VALUE`, неизвестный (опечатка?) - убрать из .env")


def _owner_check(
    *, profile: Any | None = None, environ: Mapping[str, str] | None = None,
) -> Check:
    """PROFILE-1 п.5: «Профиль владельца» - ``owner.yaml`` + ``about.md`` + дубли с ``.env``.

    ``ok`` - ``owner.yaml`` валиден, есть ``name`` + >= 1 вариант + >= 1 почта, ``about.md``
    непустой, дублей с ``.env`` нет. ``warn`` - профиля нет (подсказка ``dt owner init``), схема
    битая, личность неполна, ``about.md`` пуст, дубль с ``.env``, в силе ``the user``. В строке
    имена полей и счетчики, секретов нет. Та же функция (:func:`core.owner.check.evaluate`)
    кормит ``dt owner check`` и ``pult_settings_get.owner``. ``profile``/``environ`` - инъекция
    состояния для тестов."""
    name = "Профиль владельца"
    try:
        from core.owner import load_profile
        from core.owner.check import evaluate

        res = evaluate(load_profile() if profile is None else profile,
                       os.environ if environ is None else environ)  # mail - по коннектору Outlook
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        return Check(name, "warn", f"профиль не прочитан: {type(exc).__name__}",
                     "uv run python cli/dt.py owner check")
    return Check(name, res.status, res.summary, res.hint)


def _instance_checks(
    *, client: Any | None = None, health: Callable[[str], dict[str, Any] | None] | None = None,
    now: datetime | None = None,
) -> list[Check]:
    """PERSONAL-1 п.7: строки «Экземпляр» и «Мост» - ТОЛЬКО у именованного экземпляра.

    Рабочий экземпляр (без ``DT_INSTANCE`` и с ролью ``work``) о личном не знает: пустой список,
    ни одной строки. У личного:

    * «Экземпляр» - имя, роль, vault, порт, эмбеддер (владеет/сосед и жив ли сосед), права
      каталога секретов и мост в рабочий: ``/health`` рабочего, токен принят (пустой ``find_notes``:
      читающий вызов без следа в рабочем журнале), уровень ``read`` - по построению (токен чтения
      рабочего из ``DT_WORK_TOKEN_FILE``, клиент зовет только читающие инструменты; живая проба
      уровня - ``dt bridge --probe-level``);
    * «Мост» - сколько карточек ``bridge`` ждут решения, итог последнего скана (``partial``,
      ``work_unavailable``, пропуски).

    ``client``/``health`` - инъекции для тестов. Только чтение; секреты не выводятся."""
    from core.instance import (
        embed_owner,
        embed_url,
        instance_name,
        instance_role,
        is_personal,
        secrets_path,
    )

    name = instance_name()
    if name is None and not is_personal():
        return []
    out: list[Check] = []
    try:
        role = instance_role()
        from core.config import default_vault_path
        from core.daemon import fetch_health_url

        def probe_default(url: str) -> dict[str, Any] | None:
            return fetch_health_url(url, timeout=2.0)

        probe = health or probe_default
        port = (os.environ.get("DT_WEB_PORT") or "").strip() or "8787"
        parts = [f"{name or '(без имени)'}", f"роль {role}", f"vault {default_vault_path()}",
                 f"порт {port}"]
        problems: list[str] = []
        if embed_owner():
            parts.append("эмбеддер: своя модель")
        else:
            neighbour = embed_url()
            alive = probe(neighbour) if neighbour else None
            parts.append(f"эмбеддер: сосед {neighbour or '(DT_EMBED_URL не задан)'}"
                         + (" (жив)" if alive else " (не отвечает - откат на локальную модель)"))
            if not alive:
                problems.append("эмбеддер-сосед не отвечает")
        import stat

        sec = secrets_path()
        try:
            loose = [p.name for p in [sec, *sorted(sec.iterdir())] if p.exists()
                     and stat.S_IMODE(p.stat().st_mode) & 0o077]
        except OSError:
            loose = []
        if loose:
            problems.append("права шире 600/700: " + ", ".join(loose))
        if role == "personal":
            parts.append(_bridge_link_text(client, problems))
        hint = ("разбери: " + "; ".join(problems)) if problems else ""
        out.append(Check("Экземпляр", "warn" if problems else "ok", " · ".join(parts), hint))
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        out.append(Check("Экземпляр", "warn", f"не прочитан: {type(exc).__name__}: {exc}",
                         "dt instance status"))
    if is_personal():
        out.append(_bridge_check(now))
        out.append(_capture_source_check())
    return out


def _capture_source_check() -> Check:
    """PERSONAL-3 п.C2: «Захват» личного - из какого списка TickTick и куда идут задачи без тега.

    ``warn``: ``untagged_lane`` не ``skip`` при списке, совпадающем с рабочим (задачи без тега
    ушли бы в оба vault). Только чтение оверлея и ``engine/.env``."""
    name = "Захват"
    try:
        from core.personal.capture_source import HINT, describe

        cap = describe()
    except Exception as exc:  # noqa: BLE001 - диагностика не должна падать
        return Check(name, "warn", f"источник захвата не прочитан: {exc}", "dt instance status")
    project = cap["project"] or "список рабочего"
    detail = f"список: {project}; задачи без тега → {cap['lane']}"
    if cap["lane"] != "skip" and cap["same_project"]:
        return Check(name, "warn", detail + "; список общий с рабочим: задача без тега ушла бы в "
                                            "оба vault", HINT)
    if cap["lane"] == "skip" and not cap["own"]:
        return Check(name, "ok", detail + " (развод по тегам)",
                     "свой список: dt instance set <имя> DT_TICKTICK_CAPTURE_PROJECT_NAME <список>")
    return Check(name, "ok", detail)


def _bridge_link_text(client: Any | None, problems: list[str]) -> str:
    """Кусок строки «Экземпляр»: мост в рабочий (``/health``, токен, уровень) либо причина."""
    from core.bridge.work_client import WorkClient

    cli = client if client is not None else WorkClient.from_env()
    if cli is None:
        problems.append("моста нет: нужны DT_WORK_URL и токен чтения (DT_WORK_TOKEN_FILE)")
        return "мост в рабочий: не настроен"
    info = cli.health()
    if info is None:
        problems.append("рабочий демон не отвечает на /health")
        return f"мост в рабочий: {cli.url} не отвечает"
    got = cli.find_notes("", limit=1)
    if not got.get("ok"):
        reason = got.get("reason")
        problems.append(f"токен чтения не принят ({reason})" if reason == "token_rejected"
                        else f"рабочий демон отказал: {reason}")
        return f"мост в рабочий: /health ok, но {reason}"
    return (f"мост в рабочий: /health ok, токен принят, уровень read "
            f"(код рабочего {((info.get('version') or {}).get('code') or '?')})")


def _bridge_excluded_text() -> str:
    """«; вне моста по исключениям N (шаблоны)»: сколько заметок снимка не уходит рабочему."""
    try:
        from core.config import default_vault_path
        from core.instance import bridge_exclude, excluded
        from core.retrieval.fm_cache import peek_metas

        patterns = bridge_exclude()
        if not patterns:
            return "; исключений моста нет (весь vault может уйти в запросы)"
        n = sum(1 for m in peek_metas(default_vault_path()) if excluded(m.path, patterns))
        return f"; вне моста по исключениям {n} ({', '.join(patterns)})"
    except Exception:  # noqa: BLE001 - диагностика не должна падать
        return ""


def _bridge_check(now: datetime | None = None) -> Check:
    """PERSONAL-1 п.7: «Мост» - карточки ``bridge`` ждут решения, последний скан, пропуски."""
    name = "Мост"
    try:
        from core.bridge import store

        cur = now or datetime.now(UTC)
        cards = store.BridgeStore.load()
        pending = cards.pending(cur)
        last = store.load_last()
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"стор моста не прочитан: {exc}", "проверь .derived/bridge*")
    detail = f"карточек bridge ждут решения {len(pending)}"
    detail += _bridge_excluded_text()
    if cards.skipped:
        detail += f" (битых строк стора: {cards.skipped})"
    if last is None:
        return Check(name, "ok", detail + "; сканов еще не было",
                     "dt bridge --dry-run --limit 5; ночью - шаг bridge после reindex_inc")
    when = str(last.get("at") or "?")[:16].replace("T", " ")
    skips = (f"без изменений {last.get('unchanged', 0)}, "
             f"ниже порога {last.get('below_threshold', 0)}, "
             f"заглушек {last.get('stubs', 0)}, "
             f"ошибок срезов хабов {last.get('retrieve_errors', 0)}")
    detail += (f"; последний скан {when}: опрошено {last.get('scanned', 0)}, новых "
               f"{last.get('new', 0)}, обновлено {last.get('updated', 0)} ({skips})")
    bad = []
    if last.get("work_unavailable"):
        bad.append(f"рабочий демон не отвечал ({last['work_unavailable']}), скан прерван")
    if last.get("partial"):
        bad.append(f"бюджет вышел, не доскан {last.get('pending_left', '?')}")
    if bad:
        return Check(name, "warn", detail + "; " + "; ".join(bad),
                     "демон рабочего жив? ночной шаг bridge допросит остаток")
    return Check(name, "ok", detail, "карточки вида «Мост» - в «Требуют решения» личного пульта")


def _nda_leak_check() -> Check:
    """NDA-2: заметки vault, лежащие под NDA-путями (класс «протечка мимо барьера»).

    Инцидент 16.08: несимметрия предиката (суффикс работал на файле, но не на
    каталоге) пропустила ``x_nda/БПЛА/…`` — две заметки в vault, и нашёл их ЧЕЛОВЕК
    глазами в трассе, а не движок. Гард закрывает класс, а не конкретную дырку:
    любая будущая несимметрия проявится здесь тем же способом — заметкой, которая
    лежит под маркером и всё-таки существует.

    Смотрим ОБА пути заметки (:func:`core.privacy.any_nda`): путь файла и
    ``source_path`` из frontmatter — легаси-слуг маркер теряет
    (``About_EC_НМ_NDA.pptx`` → ``about-ec-nm-nda-….md``), и без второго пути такая
    заметка выглядит чистой. Обход — с ``apply_nda=False`` (иначе фильтр спрячет
    ровно то, что мы ищем). Warning, не fail: заметку удаляет/карантинит человек.
    """
    name = "Заметки под NDA-путями"
    try:
        from core.config import default_vault_path
        from core.privacy import any_nda
        from core.vault import iter_vault

        root = default_vault_path()
        leaks: list[str] = []
        for note in iter_vault(root, apply_nda=False):
            source = note.frontmatter.get("source_path")
            if isinstance(source, list):
                source = source[0] if source else ""
            if any_nda(note.path, source):
                leaks.append(str(note.path.relative_to(root)))
    except Exception as exc:  # noqa: BLE001
        return Check(name, "warn", f"обход vault: {exc}",
                     "проверь core.vault / DT_VAULT_PATH")

    if not leaks:
        return Check(name, "ok", "протечек нет",
                     "заметка под маркером *_nda не должна существовать в vault "
                     "(барьер — core.privacy.is_nda)")
    shown = ", ".join(leaks[:3]) + (f" (+{len(leaks) - 3})" if len(leaks) > 3 else "")
    counted = _plural_ru(len(leaks), "заметка", "заметки", "заметок")
    return Check(
        name, "warn", f"{counted} под NDA-путями: {shown}",
        "перенеси в карантин вне vault и сними производные следы: "
        "uv run python cli/dt_purge_nda.py --purge",
    )


def _smoke_check() -> Check:
    """LIVE-SMOKE-1: свежесть и цвет последнего сценарного прогона.

    Смоук ловит конфиг-зависимые поломки живой машины — и сам подвержен ровно тому
    же способу умереть: джоб не загрузился / упал / его сняли, и полгода «всё
    зелено», потому что никто не гонял. Поэтому у прогона есть срок годности:
    старше :data:`core.smoke.MAX_AGE_DAYS` или красный → warn.
    """
    try:
        from core.smoke import MAX_AGE_DAYS, last_run, smoke_log_path

        run = last_run()
        log = smoke_log_path()
    except Exception as exc:  # noqa: BLE001 — смоук-лог не критичен
        return Check("Смоук-прогон", "warn", f"лог: {exc}", "проверь core.smoke")

    hint = "прогон: make smoke (или launchctl start com.dt.smoke)"
    if run is None:
        return Check("Смоук-прогон", "warn", f"прогонов нет ({log})",
                     f"{hint} — сценарии на боевом vault ещё ни разу не гонялись")
    when = f"{run['ts']} ({run['age_days']:.0f} дн назад)"
    if not run["ok"]:
        # WAVE1-MEASURE п.3: КАКИЕ сценарии красные — прямо в строке (а не «1 из 9»).
        which = f" ({'; '.join(run['red'])})" if run.get("red") else ""
        return Check(
            "Смоук-прогон", "warn",
            f"последний прогон КРАСНЫЙ: {run['failed']} из {run['total']}{which} — {when}",
            f"смотри {log} (блок последнего прогона: сценарий + причина), затем {hint}",
        )
    if run["age_days"] > MAX_AGE_DAYS:
        return Check(
            "Смоук-прогон", "warn", f"прогон устарел: {when}",
            f"порог {MAX_AGE_DAYS:.0f} дн; джоб com.dt.smoke загружен? {hint}",
        )
    return Check("Смоук-прогон", "ok",
                 f"{run['passed']}/{run['total']} зелёных, {when}, {run['duration_s']:.0f}с",
                 "сценарии «как ходит агент» на боевом vault (weekly com.dt.smoke)")


def _eval_check() -> Check:
    """EVAL-1/2: «Качество выдачи: recall@5 X (Δ к прошлому)» — по истории золотого набора.

    Читает ``.derived/eval/history.jsonl`` (его пишет С-10 смоука и ``dt_eval``): последний
    прогон и его отличие от предыдущего — ВСЕГО и по группам (рабочая | контрольная; пустая
    контрольная — «нет данных», не 0). ``warn`` — регрессия recall@5/hub@3 больше 0.1 в любой
    группе (то же правило, что красит С-10) или прогон старше :data:`core.eval.MAX_AGE_DAYS`.
    Прогонов нет — ``ok`` с подсказкой: линейка без базовой линии ещё не измерена, а не сломана.
    """
    name = "Качество выдачи"
    try:
        from core.eval import GATING, GROUP_LABELS, GROUPS, MAX_AGE_DAYS, last_runs, red_text

        runs = last_runs(2)
    except Exception as exc:  # noqa: BLE001 — линейка не критична
        return Check(name, "warn", f"история не прочитана: {exc}", "проверь core.eval")
    hint = ("прогон: make smoke (С-10) или uv run python cli/dt_eval.py; "
            "набор — vault/_system/eval/golden-queries.yaml")
    if not runs:
        return Check(name, "ok", "прогонов нет — базовой линии ещё нет", hint)
    cur = runs[-1]
    same_set = len(runs) > 1 and runs[-2].get("golden_hash") == cur.get("golden_hash")
    prev = runs[-2] if same_set else None
    labels = {"recall5": "recall@5", "mrr": "MRR", "hub3": "hub@3"}
    parts = []
    for metric in ("recall5", "hub3", "mrr"):
        value = (cur.get("metrics") or {}).get(metric)
        if value is None:
            continue
        old = ((prev or {}).get("metrics") or {}).get(metric)
        delta = f" (Δ {value - old:+.2f} к прошлому)" if old is not None else ""
        parts.append(f"{labels[metric]} {value:.2f}{delta}")
    ts = str(cur.get("ts") or "")[:10]
    tail = (f"прогон {ts}, {cur.get('verified', '?')} в метрике"
            f" + {cur.get('hypotheses', 0)} гипотез вне её"
            + (", базовая линия" if cur.get("baseline") else ""))
    detail = ", ".join(parts) + "; " + tail
    # EVAL-2 п.5: обе группы рядом (записи истории до EVAL-2 групп не несут — строка прежняя)
    cur_groups = cur.get("groups") or {}
    if cur_groups:
        prev_groups = (runs[-2].get("groups") or {}) if len(runs) > 1 else {}
        gparts = []
        for group in GROUPS:
            rec = cur_groups.get(group) or {}
            value = (rec.get("metrics") or {}).get("recall5")
            if not rec.get("verified") or value is None:
                gparts.append(f"{GROUP_LABELS[group]}: нет данных")
                continue
            old_rec = prev_groups.get(group) or {}
            old = (old_rec.get("metrics") or {}).get("recall5")
            comparable = old is not None and old_rec.get("hash") == rec.get("hash")
            delta = f" (Δ {value - old:+.2f})" if comparable else ""
            gparts.append(f"{GROUP_LABELS[group]} recall@5 {value:.2f}{delta} на {rec['verified']}")
        detail += "; " + " · ".join(gparts)
    red = [r for r in (cur.get("red") or []) if r.rpartition(":")[2] in GATING]
    if red:
        return Check(name, "warn", f"РЕГРЕССИЯ > 0.1 ({red_text(red)}): {detail}", hint)
    age = cur.get("age_days")
    if age is not None and age > MAX_AGE_DAYS:
        return Check(name, "warn", f"прогон устарел ({age:.0f} дн): {detail}", hint)
    return Check(name, "ok", detail, hint)


# EVAL-2 п.6: пороги строки «Золотой набор».
GOLDEN_PENDING_WARN = 5      # столько кандидатов в очереди = пора разобрать
GOLDEN_AGE_WARN_DAYS = 60    # канон не правили дольше — набор, вероятно, протух


def _golden_check() -> Check:
    """EVAL-2 п.6: «Золотой набор» — здоровье самого набора (не метрик: они в «Качество выдачи»).

    ``{проверено / гипотез / контрольных, stale N, кандидатов pending N, правка канона N дн}``.
    Канон валиден — проверяется ЗДЕСЬ же (``load_golden``): невалидный YAML → ``fail`` с текстом
    ошибки (раньше это ловил тест равенства фикстуры, теперь тесты канон не копируют). ``warn``:
    есть stale-ожидания (id не резолвятся — набор врёт промахом), кандидатов в очереди ≥ 5, канон
    не правили дольше 60 дней. Нет файла канона — ``warn``. Только чтение: поиск не запускается,
    очередь кандидатов берётся как есть (пересчёт — при чтении из пульта).
    """
    name = "Золотой набор"
    try:
        from core.eval import GROUP_CONTROL, GoldenError, golden_path, load_golden, stale_refs
        from core.eval_candidates import GoldenCandidateQueue

        path = golden_path()
        if not path.is_file():
            return Check(name, "warn", f"канон не найден: {path}",
                         "создай vault/_system/eval/golden-queries.yaml "
                         "(образец формата — engine/tests/fixtures/golden-queries.yaml)")
        try:
            queries = load_golden(path)
        except GoldenError as exc:
            return Check(name, "fail", f"канон невалиден: {str(exc)[:400]}",
                         "поправь vault/_system/eval/golden-queries.yaml (ошибка названа выше)")
        verified = sum(1 for q in queries if q.verified)
        control = sum(1 for q in queries if q.group == GROUP_CONTROL)
        stale = [q.id for q in queries if stale_refs(q)]
        pending = len(GoldenCandidateQueue.load().pending())
        age_days = (datetime.now(UTC).timestamp() - path.stat().st_mtime) / 86400.0
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"набор не прочитан: {exc}", "проверь core.eval")
    detail = (f"{verified} проверено / {len(queries) - verified} гипотез / {control} контрольных; "
              f"stale {len(stale)}{' (' + ', '.join(stale[:6]) + ')' if stale else ''}; "
              f"кандидатов pending {pending}; канон правили {age_days:.0f} дн назад")
    todo = []
    if stale:
        todo.append("stale: заметку перегенерировали или удалили — поправь id в "
                    "golden-queries.yaml (метрики эти запросы не считают)")
    if pending >= GOLDEN_PENDING_WARN:
        todo.append("кандидаты: разбери карточки «В золотой набор?» в «Требуют решения»")
    if age_days > GOLDEN_AGE_WARN_DAYS:
        todo.append(f"канон не правили > {GOLDEN_AGE_WARN_DAYS} дн: набор мог протухнуть — "
                    "просмотри ожидания, добавь запрос на каждый свежий фейлкейс поиска")
    if todo:
        return Check(name, "warn", detail, "; ".join(todo))
    return Check(name, "ok", detail,
                 "запрос на каждый фейлкейс поиска/ТЗ по retrieval — DoD, "
                 "docs/02-architecture §9 п.23")


def _source_paths_checks(vault_path: Path | None = None) -> list[Check]:
    """SRC-PATH-1: файловые заметки, чей ``source_path`` не разрешается (по ``frontmatter.json``).

    Две строки: «разрешимость» - warn, пока есть заметки, которые чинит ``--repoint-sources``
    (ключ манифеста жив); «исчезнувшие файлы» - info (ни записи, ни живого ключа: файла больше
    нет, выполнимого действия нет). Бюджет 5 с - при превышении проверка по выборке (помечено).
    """
    name = "Источники заметок: разрешимость"
    gone_name = "Источники заметок: исчезнувшие файлы"
    try:
        from core.config import default_vault_path
        from core.legacy.repoint import unresolved_file_notes

        r = unresolved_file_notes(vault_path or default_vault_path())
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return [Check(name, "warn", f"снимок frontmatter: {exc}", "dt_index обновит снимок")]
    if not r["total"]:
        return [
            Check(name, "ok", "нет файловых заметок в снимке (0)", "снимок ещё не построен"),
            Check(gone_name, "ok", "0", "снимок ещё не построен"),
        ]
    sample = f" (выборка {r['checked']} из {r['total']})" if r["partial"] else ""
    detail = f"{r['total']} файловых заметок, не разрешаются {r['recoverable']}{sample}"
    if r["recoverable"]:
        top = "; ".join(f"{f} ({n})" for f, n in r["folders"][:5])
        out = [Check(name, "warn", f"{detail}; папки: {top}",
                     "dt_ingest --repoint-sources (dry-run) → --apply --limit 5 → --apply")]
    else:
        out = [Check(name, "ok", detail, "source_path каждой заметки ведет к живому файлу")]
    gone = r["no_entry"] + r["dead_key"]
    out.append(Check(
        gone_name, "ok",
        f"{gone} (без записи в манифесте {r['no_entry']}, ключ тоже мертв {r['dead_key']})",
        "файл исчез с диска - чинить нечем; заметка остается как память",
    ))
    return out


def _facts_version_check() -> Check:
    """FACT-2 п.7: сколько строк фактов извлечено НЕ текущей версией экстрактора.

    Читает стор только на чтение (``mode=ro``). Старая версия - warn: единицы/масштаб/типы
    таких фактов могут быть неверны (``unit``/``scale`` не заполнены, ``A6``-«этап» - деньги), а
    ``get_facts`` по ``note_id`` их переизвлечет сам; пакетно - ``dt_facts --reextract``.
    """
    name = "Факты: версия экстрактора"
    try:
        from core.facts.materialize import needs_reextract
        from core.facts.schema import EXTRACTOR_VERSION
        from core.facts.store import last_read_error, source_versions

        sources = source_versions()
        broken = last_read_error()
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"стор фактов: {exc}", "проверь .derived/dt.db")
    if broken:
        return Check(name, "warn", f"стор фактов не прочитан: {broken}", "проверь .derived/dt.db")
    if not sources:
        return Check(name, "ok", "фактов в сторе нет (0)", f"текущая версия {EXTRACTOR_VERSION}")
    old = [s for s in sources if needs_reextract(str(s["version"]))]
    total = sum(int(s["n"]) for s in sources)  # type: ignore[call-overload]
    if not old:
        return Check(name, "ok", f"{total} фактов, {len(sources)} источников - версия "
                     f"{EXTRACTOR_VERSION}", "стор соответствует текущему экстрактору")
    n_old = sum(int(s["n"]) for s in old)  # type: ignore[call-overload]
    versions = ", ".join(sorted({str(s["version"]) for s in old}))
    return Check(name, "warn",
                 f"{n_old} из {total} фактов ({len(old)} из {len(sources)} источников) версии "
                 f"{versions}, текущая {EXTRACTOR_VERSION}",
                 "dt_facts --reextract --dry-run → --limit 1 → --reextract (либо get_facts по "
                 "note_id переизвлечет источник сам)")


_FACTS_UNDATED_WARN = 0.10  # доля фактов без valid_from, выше которой - warn


def _facts_time_check() -> Check:
    """FACTS-BITEMPORAL-1 п.6: «Факты: время» - оси времени и цепочка версий.

    Читает стор только на чтение. ``warn``: схема до v4, фактов без ``valid_from`` (не удалось
    датировать) больше 10 %, либо цепочка порвана - у семейства есть более новая версия, а факты
    старой не вытеснены (подъем не пересобрал связи: ``dt facts backfill``). Противоречия (два
    актуальных факта с одним ``fact_key`` из РАЗНЫХ семейств с разными значениями) только считаются:
    карточки - зона KNOWLEDGE-LINT-1.
    """
    name = "Факты: время"
    try:
        from core.facts.store import last_read_error
        from core.facts.versions import time_stats

        st = time_stats()
        broken = last_read_error()
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"стор фактов: {exc}", "проверь .derived/dt.db")
    if broken:
        return Check(name, "warn", f"стор фактов не прочитан: {broken}", "проверь .derived/dt.db")
    if st.unmigrated:
        return Check(name, "warn", "схема стора старше v4 (нет осей времени)",
                     "откройте БД (любой get_facts / dt doctor применит миграцию), затем "
                     "dt facts backfill --dry-run")
    if st.total == 0:
        return Check(name, "ok", "фактов в сторе нет (0)",
                     "оси времени появятся при первом подъеме")
    detail = (f"{st.current} актуальных / {st.superseded} вытеснено / "
              f"{st.provisional} provisional; "
              f"источников в цепочке {st.sources_in_chain} из {st.sources}, семейств с >1 версией "
              f"{st.families_multi}; противоречий {st.contradictions}")
    hint = ("оси: valid_from/valid_to (когда верно) и known_at (когда узнали); цепочка версий - "
            "core.facts.temporal; dt facts versions <источник>")
    problems: list[str] = []
    if st.undated_share > _FACTS_UNDATED_WARN:
        problems.append(f"без valid_from {st.undated} из {st.total} ({st.undated_share:.0%})")
    if st.broken_families:
        problems.append(f"цепочка порвана: {st.broken_families} сем., {st.broken_facts} фактов не "
                        "вытеснены новой версией")
    if problems:
        return Check(name, "warn", "; ".join(problems) + " - " + detail,
                     "dt facts backfill --dry-run → dt facts backfill (пересоберет связи и даты); "
                     + hint)
    return Check(name, "ok", detail, hint)


def _mail_threads_check() -> Check:
    """Целостность почтовых тредов (MAIL-THREAD-1): индекс манифеста, без сайдкаров.

    * ``msg_id`` в >1 треде — след сдвига массивов моста (инжест такого уже не
      допускает; накопленное чинит ``dt_mail_repair``);
    * треды с подозрением на склейку (смена темы + смена круга доменов) — только
      сигнал, автоматического разделения нет.
    """
    try:
        from core.config import outlook_ingest_manifest_path
        from core.legacy.mail import _load_manifest
        from core.legacy.mail_integrity import find_multi_thread

        path = outlook_ingest_manifest_path()
        if not path.is_file():
            return Check("Почтовые треды", "ok", "манифест почты ещё не создан (0 тредов)",
                         "mail_ingest не прогонялся")
        index = {k: v for k, v in _load_manifest(path).items() if "msg_ids" in v}
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check("Почтовые треды", "warn", f"manifest: {exc}",
                     "проверь outlook_ingest_manifest.json")
    multi = find_multi_thread(index)
    spliced = sorted(k for k, v in index.items() if v.get("splice_suspects"))
    detail = f"{len(index)} тредов"
    # MAIL-LOCK-1 п.6: индекс и сайдкары обязаны быть взаимно однозначны (гонка писателей без
    # общего лока оставляла записи без сайдкара - 45 штук 29.10).
    try:
        from core.legacy.mail_reconcile import find_orphans

        orphans = find_orphans(path)
        no_sidecar = len(orphans.entries_without_sidecar)
        no_entry = len(orphans.sidecars_without_entry)
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        no_sidecar = no_entry = 0
        detail += f"; сверка сайдкаров не удалась: {exc}"
    orphan_text = f"записей без сайдкара: {no_sidecar}; сайдкаров без записи: {no_entry}"
    if not multi and not no_sidecar and not no_entry:
        # Подозрение на склейку без дублей msg_id — это деталь, не предупреждение: сигнал
        # эвристический (смена темы + круга доменов), легитимные треды его дают постоянно.
        if spliced:
            return Check("Почтовые треды", "ok",
                         detail + f"; дублей msg_id нет; {orphan_text}; подозрение на склейку: "
                         f"{len(spliced)} (напр. {spliced[0]})",
                         "склейка — только сигнал; сверь тред глазами, авто-разделения нет")
        return Check("Почтовые треды", "ok",
                     detail + f"; дублей msg_id и склеек нет; {orphan_text}",
                     "инвариант: msg_id принадлежит ровно одному треду; индекс = сайдкарам")
    parts: list[str] = []
    hint: list[str] = []
    if multi:
        threads = len({t for ts in multi.values() for t in ts})
        parts.append(f"{len(multi)} msg_id в >1 треде ({threads} тредов затронуто)")
        hint.append("dt_mail_repair.py (dry-run → --apply --limit 3 → --apply) разберёт дубли")
    if no_sidecar or no_entry:
        parts.append(orphan_text)
        hint.append("dt_mail_repair.py --reconcile (dry-run → --apply) снимет сироты, "
                    "чьи письма все в «отказано»")
    if spliced:
        parts.append(f"подозрение на склейку: {len(spliced)} (напр. {spliced[0]})")
    return Check("Почтовые треды", "warn", detail + "; " + "; ".join(parts), "; ".join(hint))


def _orbit_mirror() -> tuple[list[dict], list[dict], list[dict]] | None:
    """Сделки/issue/проекты зеркала для doctor-строк орбиты; None — зеркала нет/не читается."""
    try:
        from core.config import timetta_mirror_path
        from core.operational import orbit
        from core.operational.timetta.mirror import MirrorStore

        root = timetta_mirror_path()
        if not root.is_dir():
            return None
        store = MirrorStore(root)
        # диагностике нужны ВСЕ кольца и удалённые (счётчики) — сырая карта через хелпер орбиты
        return list(orbit.lookup(store).values()), store.all("issues"), store.all("projects")
    except Exception:  # noqa: BLE001 — диагностика не должна падать
        return None


def _orbit_checks() -> list[Check]:
    """ORBIT-2 п.6: юрлица сделок, сверка удалений, кольца (числа без имён и сумм)."""
    data = _orbit_mirror()
    if data is None:
        return []
    from core.operational import orbit

    deals, issues, projects = data
    live = [d for d in deals if not orbit.is_deleted(d)]
    no_le = sum(1 for d in live if not d.get("legal_entity_id"))
    out = [
        Check("Сделки без юрлица", "warn" if no_le else "ok", f"{no_le} из {len(live)}",
              "" if not no_le else
              "подразделение этих сделок берётся по юрлицу ведущего — проверь в Timetta")
    ]
    gone = sum(1 for rec in (*deals, *issues, *projects) if orbit.is_deleted(rec))
    stale_issues = sum(1 for i in issues if not orbit.is_deleted(i) and i.get("is_active") is False)
    out.append(Check("Зеркало: удалённые", "ok",
                     f"удалённых {gone}, устаревших issue {stale_issues}",
                     "метка deleted_at ставится сверкой (dt_reconcile); записи не удаляются"))
    counts = orbit.ring_counts(live)
    out.append(Check("Кольца орбиты", "ok",
                     f"1/2/3 = {counts.get('mine', 0)}/{counts.get('unit', 0)}/"
                     f"{counts.get('group', 0)}",
                     "1 — мои, 2 — подразделение, 3 — группа; видимость: DT_ORBIT_RINGS "
                     "(записи в Timetta нет — кольца только для чтения)"))
    return out


def _eventlog_check() -> Check:
    """Сквозной лог стадий (PULT-EVENTLOG): счётчики событий по стадиям."""
    try:
        from core.eventlog import stage_counts

        counts = stage_counts()
    except Exception as exc:  # noqa: BLE001 — лог не критичен
        return Check("Журнал стадий", "warn", f"open: {exc}",
                     "core.eventlog / таблица events (миграция v2)")
    detail = (
        f"{counts.get('total', 0)} событий (ingest {counts.get('ingest', 0)} / "
        f"hub {counts.get('hub', 0)} / index {counts.get('index', 0)} / "
        f"link {counts.get('link', 0)})"
    )
    return Check("Журнал стадий", "ok", detail,
                 "лента стадий артефактов ingest→hub→index→link (PULT-EVENTLOG)")


def _ingest_dedup_check() -> Check:
    """Share of legacy-manifest entries carrying a byte-hash (INGEST-DEDUP).

    A low ratio means a folder move/rename would look like re-imports — run
    ``dt_legacy_ingest --backfill-hashes`` to content-address the existing corpus.
    """
    try:
        from core.legacy.ingest import manifest_hash_coverage

        with_hash, total, missing = manifest_hash_coverage()
    except Exception as exc:  # noqa: BLE001
        return Check("Byte-hash легаси", "warn", f"manifest: {exc}",
                     "проверь legacy_ingest_manifest.json")
    # DOCTOR-HONEST-1: исчезнувшие с диска исходники — не недо-backfill, а факт;
    # называем их вслух, но жёлтым за них не светим (выполнимого действия нет).
    gone = f" ({missing} исходников исчезли с диска)" if missing else ""
    if total == 0:
        return Check("Byte-hash легаси", "ok", f"нет живых легаси-заметок (0){gone}",
                     "нечего backfill'ить — корпус ещё не импортирован")
    detail = f"{with_hash}/{total} живых записей с source_content_hash{gone}"
    if with_hash < total:
        return Check("Byte-hash легаси", "warn", detail,
                     "прогони dt_legacy_ingest.py --backfill-hashes — иначе перенос "
                     "папки выглядит как переимпорт")
    return Check("Byte-hash легаси", "ok", detail,
                 "перенос/переименование корпуса распознаётся по контенту")


def _ocr_last_run_detail(last: Any) -> str:
    """NIGHT-CHAIN-1: «последний прогон: бюджет исчерпан на документе X, страниц Y/Z» (если так)."""
    if not isinstance(last, dict):
        return ""
    elapsed = float(last.get("elapsed_s") or 0)
    budget = float(last.get("budget_s") or 0)
    base = f"; последний прогон {elapsed / 60:.0f} мин из {budget / 60:.0f}"
    part = last.get("partial")
    if last.get("budget_hit") and isinstance(part, dict):
        return (f"{base}: бюджет исчерпан на документе {part.get('doc')}, страниц "
                f"{part.get('pages_done')}/{part.get('pages_total')} (продолжит следующий прогон)")
    if last.get("budget_hit"):
        return f"{base}: бюджет исчерпан между документами"
    return base


def _ocr_check() -> Check:
    """OCR-1 п.5: «OCR» - очередь сканов, сделано за 7 дн, низкая уверенность, приватность, движок.

    ``warn``: в очереди есть сканы, а движка нет (tesseract/gs не найдены - заглушки остаются, шаг
    ``ocr`` честно ``unavailable``) либо манифест нечитаем. Остальное ``ok``: очередь - не поломка,
    а работа по бюджету. Ничего не распознает и не читает pdf (снимок очереди + манифесты +
    журнал OCR)."""
    name = "OCR"
    try:
        from core.ocr.state import summary

        sm = summary()
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"сводка не собрана: {exc}", "проверь core/ocr/state.py")
    queue = sm.get("queue") or {}
    notes = sm.get("notes")
    week = sm.get("week") or {}
    refused = sm.get("refused") or {}
    n_ref = (refused.get("path") or 0) + (refused.get("text") or 0)
    low = (notes or {}).get("low", 0)
    engine = (f"{sm.get('engine')} {sm.get('engine_version')} {sm.get('langs')}"
              if sm.get("available") else f"недоступен ({sm.get('code')})")
    src = "снимок" if queue.get("source") == "snapshot" else "по манифесту"
    detail = (
        f"очередь {queue.get('docs', 0)} документов / {queue.get('pages', 0)} страниц ({src}); "
        f"сделано за 7 дн {week.get('docs', 0)}; низкая уверенность {low}; "
        f"отказано по приватности {n_ref}; {engine}"
    )
    detail += _ocr_last_run_detail(sm.get("last_run"))
    if notes is None:
        return Check(name, "warn", detail + "; манифест ingest не прочитался",
                     "проверь legacy/current_ingest_manifest.json (store_unavailable)")
    if not sm.get("available") and queue.get("docs", 0) > 0:
        return Check(name, "warn", detail,
                     "brew install tesseract tesseract-lang ghostscript - до установки сканы "
                     "остаются заглушками (OCR-1)")
    return Check(name, "ok", detail,
                 "очередь разбирает шаг ocr по бюджету DT_OCR_BUDGET_S; вручную: cli/dt_ocr.py")


def _icloud_sources_check() -> Check:
    """SRC-ICLOUD-1: «Источники: не локальны» - сколько файлов ingest-корней не локальны.

    По ``st_flags`` (SF_DATALESS), без чтения и скачивания. Не ``fail``: не скачанный файл -
    штатная очередь (подъем из демона даст ``source_not_local``, из Finder/CLI файл скачается).
    ``warn`` - есть не локальные: подсказка, как прогреть. Вне macOS - ``ok``, «не применимо».

    PERSONAL-2: общая строка для iCloud и OneDrive (провайдер - по пути корня,
    ``…/CloudStorage/OneDrive…``); у личного экземпляра vault считается корнем (заметки лежат в
    OneDrive); у OneDrive подсказка - Files On-Demand, а не ``brctl``."""
    name = "Источники: не локальны"
    try:
        from types import SimpleNamespace

        from core.config import default_vault_path
        from core.file_ingest import load_ingest_roots
        from core.instance import is_personal
        from core.sources.icloud import count_not_local

        roots: list[Any] = list(load_ingest_roots())
        if is_personal():
            roots.append(SimpleNamespace(name="vault", path=default_vault_path()))
        st = count_not_local(roots)
    except Exception as exc:  # noqa: BLE001 — диагностика не должна падать
        return Check(name, "warn", f"счет не выполнен: {exc}", "проверь _system/ingest-roots.yaml")
    if not st["applicable"]:
        return Check(name, "ok", "не применимо (нет iCloud/st_flags): файлы считаются локальными",
                     "")
    tail = " (обход неполный - бюджет)" if st["partial"] else ""
    detail = f"не локальны {st['not_local']} из {st['scanned']} файлов {len(roots)} корней{tail}"
    if st["not_local"]:
        from core.fsguard import ONEDRIVE_HINT

        per = ", ".join(f"{k}: {v}" for k, v in st["roots"].items() if v)
        prov = st.get("providers") or {}
        hints = []
        if prov.get("onedrive"):
            hints.append(ONEDRIVE_HINT)
        if prov.get("icloud") or not prov:
            hints.append("iCloud: подъем из демона вернет source_not_local; прогреть - открыть в "
                         "Finder или brctl download <путь> (массовое скачивание - только вручную)")
        return Check(name, "warn", f"{detail} ({per})", "; ".join(hints))
    return Check(name, "ok", detail, "все файлы корней локальны")


def _ingest_check() -> Check:
    """Summarise the configured file-ingest roots (INGEST-1): count + routes + live."""
    try:
        from core.file_ingest import load_ingest_roots

        roots = load_ingest_roots()
    except Exception as exc:  # noqa: BLE001
        return Check("Ingest-корни", "warn", f"config: {exc}",
                     "проверь _system/ingest-roots.yaml")
    if not roots:
        return Check("Ingest-корни", "warn", "нет (0)",
                     "заполни _system/ingest-roots.yaml — иначе файловый ingest не работает")
    knowledge = sum(1 for r in roots if r.route == "knowledge")
    operational = len(roots) - knowledge
    missing = [r.name for r in roots if not r.path.is_dir()]
    detail = f"{len(roots)} (knowledge {knowledge} / operational {operational})"
    if missing:
        return Check("Ingest-корни", "warn", f"{detail}; путь недоступен: {missing}",
                     "проверь path / DT_INGEST_ROOT_<NAME> для этих корней")
    return Check("Ingest-корни", "ok", detail,
                 "dt_ingest --apply проведёт new/changed файлы по маршрутам")


def validate_environment() -> list[Check]:
    """Только критичные ``fail`` (секреты/vault) — для баннера/выхода на старте.
    Лёгкая: без коннекта к индексу (полный набор — :func:`run_diagnostics`)."""
    return [c for c in _critical_checks() if c.status == "fail"]
