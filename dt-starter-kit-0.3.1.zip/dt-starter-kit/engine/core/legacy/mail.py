"""Outlook correspondence → per-thread layer-B notes (ТЗ phase5; принцип 11).

Archival, read-only intake of Classic Outlook mail into the vault as ONE note
per conversation (``conversationId``) — not one per message — so quoted history
isn't duplicated and a discussion isn't fragmented across notes. A thread note
lives at ``_legacy/correspondence/<subject-slug>-<hash>.md`` and accumulates
messages from BOTH Inbox and Sent, across folders and incremental runs; its body
lists each message chronologically with only its NEW text (the quoted reply/
forward tail is stripped).

Incrementality is governed by a dedicated thread manifest
(``outlook_ingest_manifest.json``), keyed by conversationId, recording each
included message (id → date/from/is-me/stripped-text/bucket/hash). Resume skips
messages already recorded; a new message appends and re-renders the whole thread
from the manifest (no re-fetch of old messages); the per-folder ``since`` cursor
is the newest manifested message date for that bucket MINUS ``DT_MAIL_CURSOR_OVERLAP_DAYS``
(MAIL-GAP-1: mail reaching the local Outlook later than newer mail is backdated).
Per-message filters: third-party privacy (:mod:`core.legacy.discover`) and noise — decided by the
DATA rules of ``_system/mail-filter.yaml`` (:mod:`core.legacy.mail_filter`, MAIL-FILTER-1:
Inbox full set, Sent only auto-reply prefixes); a thread that is entirely noise is skipped, a
mixed thread keeps only its non-noise messages. Deterministic, no LLM; run ``dt_index``
afterwards to embed.
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Protocol

from core import runlock
from core.adapters import StoreUnavailableError, load_json_store
from core.config import (
    legacy_privacy_salary_terms,
    mail_a2_context_extra,
    mail_batch_size,
    mail_cursor_overlap_days,
    mail_owner_domains,
    outlook_folders,
    outlook_ingest_manifest_path,
    outlook_pull_window,
    outlook_self_tokens,
)
from core.ingress.provenance import stamp_fields
from core.ingress.refusals import refuse, subject_domain_hint
from core.legacy.discover import first_term_hit, nfc, privacy_reason
from core.legacy.mail_filter import (
    Decision,
    RefusedMemory,
    Rules,
    decide,
    decide_meta,
    load_rules,
)
from core.legacy.mail_integrity import detect_splices
from core.legacy.render import legacy_note_id, slugify
from core.operational.outlook_bridge import _filter_since as filter_since
from core.progress import ProgressBeacon
from core.vault import Note, write_note

logger = logging.getLogger(__name__)

__all__ = ["MailIngestStats", "MailBridge", "ingest_mail", "CORRESPONDENCE_SECTION"]

# Vault section (folder) all correspondence lands under: _legacy/correspondence/.
CORRESPONDENCE_SECTION = "correspondence"

# Sort fallback for messages whose date failed to parse (they sink to the end).
_EPOCH = datetime(1970, 1, 1, tzinfo=UTC)


class MailBridge(Protocol):
    """The read-only surface :func:`ingest_mail` needs from an Outlook bridge.

    Satisfied by :class:`core.operational.outlook_bridge.OutlookBridge`; tests
    pass a fake exposing ``list_folder_meta`` (cheap metadata for the whole
    folder) and ``fetch_by_ids`` (heavy full objects for an EXACT id batch — a
    direct hash lookup, replacing the old date-range fetch that dragged in months
    of bodies on sparse resumes).
    """

    def list_folder_meta(
        self, folder: str, since: str | None = ...
    ) -> list[dict[str, Any]]: ...

    def fetch_by_ids(
        self, folder: str, ids: list[str]
    ) -> list[dict[str, Any]]: ...


@dataclass
class MailIngestStats:
    """Disposition of one mail-ingest run."""

    new: int = 0  # threads newly created this run
    changed: int = 0  # existing threads that gained message(s) → re-rendered
    unchanged: int = 0
    resumed: int = 0  # message already in the manifest thread → skipped (resume)
    msgs_added: int = 0  # messages appended to threads this run
    skipped_privacy: int = 0
    skipped_noise: int = 0  # Inbox-only sender/subject noise → skipped before bodies
    skipped_empty: int = 0
    duplicate: int = 0  # message collapsed by content hash within its thread
    notes_total: int = 0  # thread notes written/updated
    elapsed_s: float = 0.0
    dry_run: bool = False
    scope: str = "incremental"
    manifest_path: str = ""
    folders: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)
    noise_examples: list[str] = field(default_factory=list)
    # MAIL-THREAD-1: сообщения, которые инжест отказался положить во ВТОРОЙ тред
    # (инвариант «msg_id в ровно одном треде»); примеры — без тем/адресов.
    rejected_multi_thread: int = 0
    reject_examples: list[str] = field(default_factory=list)
    # Конверты ``bridge_misaligned`` моста за прогон (страницы, перечитанные мельче).
    bridge_misaligned: int = 0
    # Треды с подозрением на склейку (смена темы + смена круга доменов).
    splice_suspects: int = 0
    # ADAPTER-HONEST-1: треды, чей сайдкар нечитаем — пропущены (не затёрты), сообщения
    # остаются на повтор после починки файла.
    thread_store_errors: int = 0
    # MAIL-FILTER-1: шум по правилам yaml (имя правила → сообщений), сообщения, пропущенные по
    # памяти «отказано» (снятые прежде), и диагностика приватности (только при --explain-privacy).
    noise_by_rule: dict[str, int] = field(default_factory=dict)
    refused_resumed: int = 0
    privacy_before: dict[str, int] = field(default_factory=dict)  # «правило/папка» → сообщений
    privacy_after: dict[str, int] = field(default_factory=dict)
    filter_source: str = ""  # file | defaults (откуда правила фильтра)
    # MAIL-GAP-1: «отказ ≠ пропуск». ``skipped_since`` - сообщения, отрезанные границей ``since``
    # (курсор с перекрытием / окно выгрузки / явный --since); ``resumed`` - уже в манифесте.
    # Единицы - СООБЩЕНИЯ. ``since_effective`` - граница по папкам (``all`` = вся папка).
    skipped_since: int = 0
    skipped_since_by_folder: dict[str, int] = field(default_factory=dict)
    since_effective: dict[str, str] = field(default_factory=dict)
    since_notes: dict[str, str] = field(default_factory=dict)  # папка → строка для лога/CLI
    # Кандидаты на добавление по папкам и их даты (дни) - для смоука С-13 «дыра курсора».
    added_by_folder: dict[str, int] = field(default_factory=dict)
    added_dates: dict[str, list[str]] = field(default_factory=dict)


# --------------------------------------------------------------------------- #
# Manifest                                                                    #
# --------------------------------------------------------------------------- #


def _load_manifest(path: Path) -> dict[str, dict[str, Any]]:
    """Индекс манифеста почты. Нет файла → ``{}`` (первый запуск); файл есть, но битый →
    :class:`~core.adapters.StoreUnavailableError` (ADAPTER-HONEST-1): прежнее «битый ⇒ пусто»
    заставляло инжест считать, что истории нет, переимпортировать всё и затереть индекс."""
    data = load_json_store(path, adapter="mail_manifest", expect=dict)
    if data is None:
        return {}
    return {str(k): v for k, v in data.items() if isinstance(v, dict)}


def _save_manifest(path: Path, manifest: dict[str, dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    tmp.replace(path)


# --------------------------------------------------------------------------- #
# Thread state store: a LIGHTWEIGHT index (manifest_path) + one sidecar file   #
# per thread holding the bodies. This keeps per-batch writes proportional to   #
# the batch, not the whole corpus — the single-file manifest with every body   #
# grew to 127 MB and got fully rewritten each batch (O(n²) → it stalled).      #
# --------------------------------------------------------------------------- #


def _state_dir(manifest_path: Path) -> Path:
    """Directory holding per-thread sidecar files (beside the index manifest)."""
    return manifest_path.parent / "mail_threads"


def _thread_file(state_dir: Path, thread_key: str) -> Path:
    """Sidecar path for a thread — hashed so ``conv:…`` keys are filesystem-safe."""
    return state_dir / (hashlib.sha1(thread_key.encode("utf-8")).hexdigest() + ".json")  # noqa: S324 — content hash (identity/dedup), not security


def _load_thread_rec(state_dir: Path, thread_key: str) -> dict[str, Any]:
    """Load a thread's full record (with ``messages``) from its sidecar, or a
    fresh empty record when none exists yet.

    Сайдкар ЕСТЬ, но нечитаем → :class:`~core.adapters.StoreUnavailableError`: свежая
    пустая запись поверх битой молча потеряла бы все накопленные сообщения треда при
    следующей записи (ADAPTER-HONEST-1)."""
    p = _thread_file(state_dir, thread_key)
    data = load_json_store(p, adapter="mail_thread", expect=dict)
    if data is None:
        return {"messages": {}}
    if not isinstance(data.get("messages"), dict):
        raise StoreUnavailableError(
            f"{p.name}: в сайдкаре треда нет словаря messages", adapter="mail_thread", path=str(p)
        )
    return data


def _save_thread_rec(state_dir: Path, thread_key: str, rec: dict[str, Any]) -> None:
    """Write one thread's sidecar atomically (only the touched thread each batch)."""
    state_dir.mkdir(parents=True, exist_ok=True)
    p = _thread_file(state_dir, thread_key)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(rec, ensure_ascii=False), encoding="utf-8")
    tmp.replace(p)


def _index_entry(rec: dict[str, Any]) -> dict[str, Any]:
    """Lightweight index row for a thread — everything resume + the incremental
    cursor need, WITHOUT the bodies (which live in the sidecar)."""
    msgs = rec.get("messages") or {}
    bucket_dates: dict[str, str] = {}
    for mm in msgs.values():
        b = str(mm.get("bucket") or "")
        d = str(mm.get("date") or "")
        if b and d and d > bucket_dates.get(b, ""):  # ISO strings sort chronologically
            bucket_dates[b] = d
    return {
        "conversationId": rec.get("conversationId", ""),
        "subject": rec.get("subject", ""),
        "note_path": rec.get("note_path", ""),
        "content_hash": rec.get("content_hash", ""),
        "count": len(msgs),
        "first_date": rec.get("first_date", ""),
        "last_date": rec.get("last_date", ""),
        "buckets": rec.get("buckets", []),
        "bucket_dates": bucket_dates,
        "msg_ids": sorted(msgs.keys()),
        # MAIL-THREAD-1: сколько подозрений на склейку нашёл рендер (doctor читает
        # индекс, а не тела сайдкаров).
        "splice_suspects": len(rec.get("splice_suspects") or []),
    }


def _migrate_manifest_if_needed(manifest_path: Path, state_dir: Path) -> bool:
    """One-time: split a legacy single-file manifest (thread records WITH bodies)
    into per-thread sidecars + a lightweight index at ``manifest_path``. Returns
    True if a migration ran. No-op when already in index format or absent."""
    data = _load_manifest(manifest_path)
    if not data:
        return False
    sample = next(iter(data.values()), {})
    if not isinstance(sample, dict) or "msg_ids" in sample:
        return False  # already the lightweight index format
    index: dict[str, dict[str, Any]] = {}
    for tkey, rec in data.items():
        if not isinstance(rec, dict) or "messages" not in rec:
            continue
        _save_thread_rec(state_dir, tkey, rec)
        index[tkey] = _index_entry(rec)
    _save_manifest(manifest_path, index)  # replaces the giant file with the index
    return True


# --------------------------------------------------------------------------- #
# Message → LegacyFile / cursor helpers                                       #
# --------------------------------------------------------------------------- #


def _parse_dt(value: Any) -> datetime | None:
    """Parse an ISO 8601 date(-time) string into an aware datetime, else ``None``."""
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=UTC)


def _window_since() -> str:
    """Default look-back cursor: ``today − outlook_pull_window`` as ``YYYY-MM-DD``."""
    cutoff = datetime.now(UTC) - timedelta(days=outlook_pull_window())
    return cutoff.date().isoformat()


@dataclass(frozen=True)
class SinceCursor:
    """Граница ``since`` одной папки и откуда она взялась (для лога и ``last_runs.json``)."""

    since: str | None  # YYYY-MM-DD; ``None`` - вся папка
    mode: str  # all | explicit | full | cursor | window
    cursor: str | None = None  # дата новейшего проиндексированного письма (режим cursor)
    overlap_days: int = 0

    def note(self, *, pull_window: int | None = None) -> str:
        """«since 2026-10-16 (курсор 2026-10-30 − 14 дн)» - человекочитаемо, без тем/адресов."""
        if self.mode == "all":
            return "вся папка (--all)"
        if self.mode == "explicit":
            return f"since {self.since} (явный --since)"
        if self.mode == "full":
            return f"since {self.since} (scope=full: окно выгрузки {pull_window} дн)"
        if self.mode == "cursor":
            return f"since {self.since} (курсор {self.cursor} − {self.overlap_days} дн)"
        return f"since {self.since} (истории нет: окно выгрузки {pull_window} дн)"


def _cursor_for(
    index: dict[str, dict[str, Any]], bucket: str, scope: str,
    *, since: str | None = None, all_history: bool = False,
) -> SinceCursor:
    """Граница папки: ``--all`` > явный ``--since`` > ``scope=full`` (окно) > курсор с
    перекрытием > окно выгрузки (нет истории). Курсор = дата новейшего письма папки в манифесте
    МИНУС ``DT_MAIL_CURSOR_OVERLAP_DAYS`` (MAIL-GAP-1), но не раньше окна выгрузки."""
    if all_history:
        return SinceCursor(None, "all")
    if since:
        return SinceCursor(since, "explicit")
    window = _window_since()
    if scope == "full":
        return SinceCursor(window, "full")
    best = ""
    for entry in index.values():
        d = str((entry.get("bucket_dates") or {}).get(bucket, ""))
        if d > best:
            best = d
    dt = _parse_dt(best) if best else None
    if dt is None:
        return SinceCursor(window, "window")
    newest = dt.date()
    overlap = mail_cursor_overlap_days()
    since_eff = max((newest - timedelta(days=overlap)).isoformat(), window)
    return SinceCursor(since_eff, "cursor", cursor=newest.isoformat(), overlap_days=overlap)


def _incremental_since(
    index: dict[str, dict[str, Any]], bucket: str, scope: str
) -> str:
    """Per-folder ``since`` cursor: newest indexed message date for ``bucket`` (из ``bucket_dates``
    манифеста, тела не нужны) МИНУС перекрытие ``DT_MAIL_CURSOR_OVERLAP_DAYS`` (MAIL-GAP-1: письма,
    пришедшие в локальный Outlook позже более свежих, иначе отрезались бы навсегда), но не раньше
    окна выгрузки. Нет истории (или всегда при ``scope="full"``) - окно выгрузки."""
    cur = _cursor_for(index, bucket, scope)
    assert cur.since is not None  # noqa: S101 - без all_history граница всегда задана
    return cur.since


# --------------------------------------------------------------------------- #
# Thread helpers                                                              #
# --------------------------------------------------------------------------- #

# We DELIBERATELY keep each message's FULL body (per-thread grouping already
# removes fragmentation; aggressive quote-stripping produced near-empty cards).
# The only reduction is collapsing EXACT duplicate blocks WITHIN a thread at
# render time — no unique text is ever lost (a dropped block is byte-identical
# to one already shown earlier in the same card).
_BLOCK_SPLIT_RE = re.compile(r"\n\s*\n")
_MIN_COLLAPSE_LEN = 40  # only collapse substantial blocks; keep short lines


def _block_key(block: str) -> str:
    """Normalise a block for exact-duplicate detection: strip ``>`` quote markers
    and collapse whitespace, so a quoted copy matches its original."""
    lines = [re.sub(r"^\s*>+\s?", "", ln).rstrip() for ln in block.splitlines()]
    return re.sub(r"\s+", " ", " ".join(lines)).strip()


def _collapse_seen(text: str, seen: set[str]) -> str:
    """Drop blocks whose normalised form was already emitted earlier in the thread
    (exact quoted history); keep everything else verbatim. ``seen`` accumulates
    across the thread's messages in chronological order."""
    kept: list[str] = []
    for block in _BLOCK_SPLIT_RE.split(text):
        key = _block_key(block)
        if len(key) >= _MIN_COLLAPSE_LEN:
            if key in seen:
                continue
            seen.add(key)
        kept.append(block)
    return "\n\n".join(b for b in kept if b.strip()).strip()


def _split_addrs(value: str) -> list[str]:
    """Split a joined recipient string (``"Name <a>, Name2 <b>"``) into parts."""
    return [p.strip() for p in str(value or "").split(",") if p.strip()]


def _addr_domain(value: str) -> str:
    """Lower-cased e-mail domain from a ``"Name <x@dom>"`` / ``"x@dom"`` string."""
    m = re.search(r"@([A-Za-z0-9.-]+)", value or "")
    return m.group(1).lower().rstrip(".") if m else ""


def _is_owner_addr(value: str, owner_domains: list[str], self_tokens: list[str]) -> bool:
    """True when a participant is us: an owner e-mail domain or a self-token."""
    dom = _addr_domain(value)
    if dom and any(dom == od or dom.endswith("." + od) for od in owner_domains):
        return True
    hay = nfc(str(value or "")).lower()
    return any(nfc(t).lower() in hay for t in self_tokens if t.strip())


def _sender_is_me(from_str: str, self_tokens: list[str]) -> bool:
    """True when the sender matches an owner self-token (case-insensitive, NFC)."""
    hay = nfc(str(from_str or "")).lower()
    return any(nfc(t).lower() in hay for t in self_tokens if t.strip())


def _thread_key(conversation_id: Any, entry_id: str) -> str:
    """Manifest/thread key: the conversationId when present, else a per-message
    singleton (``msg:<entryID>``) so lone messages still get a note."""
    conv = str(conversation_id or "").strip()
    return f"conv:{conv}" if conv else f"msg:{entry_id}"


def _thread_source_path(thread_key: str) -> str:
    """Stable provenance/id anchor for a thread note (drives ``legacy-<hash>``)."""
    return f"{CORRESPONDENCE_SECTION}/{thread_key}"


def _sorted_messages(rec: dict[str, Any]) -> list[dict[str, Any]]:
    """Thread messages in chronological order (undated sink to the end)."""
    msgs = list(rec.get("messages", {}).values())
    return sorted(msgs, key=lambda m: (_parse_dt(m.get("date")) or _EPOCH))


def _update_thread_meta(
    rec: dict[str, Any], owner_domains: list[str], self_tokens: list[str]
) -> None:
    """Recompute participants (senders + to/cc), counterparties (external, non-owner),
    first/last date, count, and pick a subject (first non-empty chronologically)."""
    msgs = _sorted_messages(rec)
    parts: list[str] = []
    for m in msgs:
        for value in (m.get("from"), m.get("to"), m.get("cc")):
            for addr in _split_addrs(str(value or "")) or ([str(value).strip()] if value else []):
                addr = addr.strip()
                if addr and addr not in parts:
                    parts.append(addr)
    counterparties = [
        p for p in parts if not _is_owner_addr(p, owner_domains, self_tokens)
    ]
    cp_domains: list[str] = []
    for p in counterparties:
        dom = _addr_domain(p)
        if dom and dom not in cp_domains:
            cp_domains.append(dom)
    dated = [d for d in (_parse_dt(m.get("date")) for m in msgs) if d]
    rec["participants"] = parts
    rec["counterparties"] = counterparties
    rec["counterparty_domains"] = cp_domains
    rec["first_date"] = min(dated).isoformat() if dated else ""
    rec["last_date"] = max(dated).isoformat() if dated else ""
    rec["count"] = len(msgs)
    # MAIL-THREAD-1: кто написал ПОСЛЕДНЕЕ сообщение (find_notes/превью показывают
    # «чем кончился тред» из frontmatter, не читая тело).
    last = msgs[-1] if msgs else None
    rec["last_from"] = str(last.get("from") or "").strip() if last else ""
    rec["last_from_me"] = bool(last.get("is_me")) if last else False
    rec["buckets"] = sorted({str(m.get("bucket") or "") for m in msgs if m.get("bucket")})
    if not rec.get("subject"):
        rec["subject"] = next(
            (str(m.get("subject") or "").strip() for m in msgs if m.get("subject")), ""
        )


def _thread_body(rec: dict[str, Any], source_path: str) -> str:
    """Provenance preamble + each message chronologically. Full text is kept;
    only EXACT duplicate blocks already shown earlier in the thread are collapsed.
    Message header: ``## <date> — <sender> → <to[, cc]>``. Data only — no
    ``[[links]]``: связывание — отдельный проход linking-engine (Phase 9)."""
    lines = [f"Источник: {source_path}"]
    subj = rec.get("subject") or rec.get("conversationId") or "(без темы)"
    lines.append(f"Тред: {subj}")
    parts = rec.get("participants") or []
    if parts:
        lines.append("Участники: " + ", ".join(parts))
    cps = rec.get("counterparties") or []
    if cps:
        lines.append("Контрагенты: " + ", ".join(cps))
    span = " … ".join(x[:10] for x in (rec.get("first_date", ""), rec.get("last_date", "")) if x)
    lines.append(f"Сообщений: {rec.get('count', 0)}" + (f" · {span}" if span else ""))
    seen: set[str] = set()
    for m in _sorted_messages(rec):
        when = str(m.get("date") or "")[:16].replace("T", " ")
        who = "Я" if m.get("is_me") else (str(m.get("from") or "").strip() or "(?)")
        recips = _split_addrs(str(m.get("to") or "")) + _split_addrs(str(m.get("cc") or ""))
        arrow = f" → {', '.join(recips)}" if recips else ""
        lines.append("")
        lines.append(f"## {when} — {who}{arrow}")
        text = _collapse_seen(str(m.get("text") or ""), seen)
        if text:
            lines.append(text)
    return "\n".join(lines).strip() + "\n"


def _render_thread(
    thread_key: str,
    rec: dict[str, Any],
    vault_path: Path,
    *,
    owner_domains: list[str],
    self_tokens: list[str],
    dry_run: bool,
) -> tuple[str, str]:
    """Render one thread → a single note (frontmatter + chronological body). Returns
    ``(note_relpath, content_hash)``. One note per conversation, spanning folders.

    Data only (Phase 9, этап 3): counterparties / domains / subject идут во
    frontmatter как СИГНАЛЫ; ``[[hub]]``-ссылки рендер не проставляет никогда —
    их добавляет отдельный проход ``core/linking`` (deterministic-резолвер кроет
    домен→client-хаб) без переимпорта."""
    _update_thread_meta(rec, owner_domains, self_tokens)
    # MAIL-THREAD-1 (гард 2-го уровня): подозрение на склейку — только сигнал в лог.
    suspects = detect_splices(_sorted_messages(rec), owner_domains)
    rec["splice_suspects"] = suspects
    if suspects:
        logger.warning(
            "[mail] подозрение на склейку: %s — %d границ(ы) (смена темы + смена круга "
            "доменов), напр. между сообщениями %s",
            thread_key, len(suspects), suspects[0]["between"],
        )
    source_path = _thread_source_path(thread_key)
    base = slugify(rec.get("subject") or "") or "thread"
    suffix = hashlib.sha1(source_path.encode("utf-8")).hexdigest()[:8]  # noqa: S324 — content hash (identity/dedup), not security
    rel = f"_legacy/{CORRESPONDENCE_SECTION}/{base}-{suffix}.md"
    body = _thread_body(rec, source_path)
    content_hash = hashlib.sha1(body.encode("utf-8")).hexdigest()  # noqa: S324 — content hash (identity/dedup), not security

    created = (rec.get("first_date") or "")[:10]
    fm: dict[str, Any] = {
        "id": legacy_note_id(source_path),
        "type": "legacy-source",
        "corpus": "legacy",
        "curated": False,
        "status": "raw",
        "source_type": "email-thread",
        "source_path": source_path,
        "section": CORRESPONDENCE_SECTION,
        "conversation_id": rec.get("conversationId", ""),
        "subject": rec.get("subject", ""),
        "participants": rec.get("participants", []),
        "counterparties": rec.get("counterparties", []),
        "counterparty_domains": rec.get("counterparty_domains", []),
        "first_date": rec.get("first_date", ""),
        "last_date": rec.get("last_date", ""),
        "last_from": rec.get("last_from", ""),
        "last_from_me": rec.get("last_from_me", False),
        "message_count": rec.get("count", 0),
        "created": created,
        "tags": ["legacy", CORRESPONDENCE_SECTION],
        # INGRESS-1 п.3: единый провенанс входа; ``source_id`` треда — conversation_id.
        **stamp_fields("mail", str(rec.get("conversationId") or source_path)),
    }
    fm = {k: v for k, v in fm.items() if v not in ("", []) or k in ("curated",)}

    if not dry_run:
        note = Note(
            id=fm["id"],
            type="legacy-source",
            path=vault_path / rel,
            frontmatter=fm,
            body=body,
        )
        note.path.parent.mkdir(parents=True, exist_ok=True)
        write_note(note)
    return rel, content_hash


def _privacy_probe(message: dict[str, Any]) -> str:
    """Text the privacy rules check for a message: participants + subject.

    Third-party surnames in the senders/recipients/subject trip the same
    name-token rule that excludes personal-data files in discovery. The owner's
    own identity (:func:`config.outlook_self_tokens`) is stripped first — they
    are a participant in every message, so their surname must not filter their
    own correspondence (it is on the privacy list to keep *their files* out).
    """
    parts = [str(message.get(k) or "") for k in ("subject", "from", "to", "cc")]
    # NFC-normalize both the probe text and the self-tokens so stripping (and the
    # downstream privacy match) works for Cyrillic regardless of normal form. Join
    # with spaces and drop "/" so privacy_reason sees one segment (an email has no
    # folder path): rules A1/A2 apply, the folder rule A3 is naturally inert.
    text = nfc(" ".join(p for p in parts if p.strip())).replace("/", " ")
    for token in outlook_self_tokens():
        token = nfc(token)
        if token:
            text = re.sub(re.escape(token), " ", text, flags=re.IGNORECASE)
    return text


_MAIL_SALARY_CONTEXT = ("зарплат", "оклад", "штатн", "премии")
# A1-термины, которые в теме письма значат что-то только при зарплатном контексте: «Личный
# кабинет», «вилка цен». Остальные A1-термины (зарплат/оклад) - сами контекст.
_A1_NEEDS_CONTEXT = ("личн", "вилк")
# MAIL-PRIVACY-2: контекст A2 («фамилия + контекст») для почты - БЕЗ голого «договор»: коммерческая
# переписка («договор ИТС», «ДС к договору субподряда») не персональные данные, а владелец ведет
# коммерцию. Персональное остается: ГПХ/оклад/зарплата/штат/кадры в строке. Расширение - env
# ``DT_MAIL_A2_CONTEXT`` (только добавляет). Файловый A2 (legacy discovery) этим не затронут.
_MAIL_A2_CONTEXT = ("гпх", "оклад", "зарплат", "штат", "кадр")


def _is_inbox(bucket: str) -> bool:
    return str(bucket or "").strip().lower() in ("inbox", "входящие")


def _privacy_check(message: dict[str, Any], *, sent: bool) -> str | None:
    """Приватность письма (MAIL-FILTER-1 п.3): участники + тема через файловые правила A1/A2.

    * A1 для ``личн``/``вилк`` - только при зарплатном контексте в ТЕМЕ (``зарплат|оклад|штатн|
      премии``): «Личный кабинет», «вилка цен» проходят;
    * A2 («фамилия + ГПХ/оклад/зарплата/штат/кадры») не применяется к Sent: свое письмо клиенту -
      не персональные данные третьих лиц; голое «договор» контекстом A2 для почты не является
      (MAIL-PRIVACY-2): «договор ИТС» коммерция, «Договор ГПХ <фамилия>» по-прежнему снимается.
    """
    terms = list(legacy_privacy_salary_terms())
    if first_term_hit(nfc(str(message.get("subject") or "")), _MAIL_SALARY_CONTEXT) is None:
        terms = [t for t in terms if t not in _A1_NEEDS_CONTEXT]
    context = list(dict.fromkeys([*_MAIL_A2_CONTEXT, *mail_a2_context_extra()]))
    return privacy_reason(
        _privacy_probe(message), salary_terms=terms, surname_rule=not sent, context_terms=context
    )


def _privacy_class(reason: str | None) -> str:
    """``privacy-term:зарплат`` → ``A1``, ``privacy-term:кадр`` → ``A1b``, ``privacy-name:`` →
    ``A2``, ``privacy-contract:`` → ``A3`` (счетчики диагностики)."""
    text = str(reason or "")
    kind, _, term = text.partition(":")
    if kind == "privacy-term":
        return "A1" if term in legacy_privacy_salary_terms() else "A1b"
    return {"privacy-name": "A2", "privacy-contract": "A3"}.get(kind, kind or "-")


def _record_noise(
    stats: MailIngestStats, memory: RefusedMemory, d: Decision, *, eid: str,
    subject: str, sender: str, dry_run: bool,
) -> None:
    """Шум: счетчик + пример + журнал отказов (с именем правила) + память «отказано»."""
    stats.skipped_noise += 1
    rule = d.rule or "?"
    stats.noise_by_rule[rule] = stats.noise_by_rule.get(rule, 0) + 1
    if len(stats.noise_examples) < 5:
        stats.noise_examples.append(f"{rule} · {subject[:60]}")
    refuse("mail", str(d.reason), source_id=eid, rule=d.rule,
           hint=subject_domain_hint(subject, sender))
    if not dry_run:
        memory.add(eid, d.reason, d.rule, datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"))


def _emit_refusals(refusals: list[dict[str, str]]) -> None:
    """Журнал стадий: отказы класть msg_id во второй тред (best-effort, одной пачкой)."""
    try:
        from core.eventlog import emit_batch, new_run_id

        run_id = new_run_id()
        emit_batch(
            [
                {
                    "stage": "ingest",
                    "status": "msg_multi_thread_refused",
                    "detail": r,
                    "run_id": run_id,
                }
                for r in refusals[:200]
            ]
        )
    except Exception:  # noqa: BLE001 — журнал не критичный путь
        logger.debug("eventlog emit(msg_multi_thread_refused) failed", exc_info=True)


def _fmt_eta(seconds: float) -> str:
    """Human ETA: ``42s`` / ``7m`` / ``2h``."""
    if seconds < 90:
        return f"{int(seconds)}s"
    if seconds < 5400:
        return f"{int(seconds / 60)}m"
    return f"{seconds / 3600:.1f}h"


# --------------------------------------------------------------------------- #
# Ingest                                                                      #
# --------------------------------------------------------------------------- #


def _flush_threads(
    batch_recs: dict[str, dict[str, Any]],
    *,
    index: dict[str, dict[str, Any]],
    included: dict[str, set[str]],
    prev_keys: set[str],
    rendered: set[str],
    owner_domains: list[str],
    self_tokens: list[str],
    stats: MailIngestStats,
    vault_path: Path,
    state_dir: Path,
    manifest_path: Path,
    run_id: str | None = None,
) -> None:
    """Re-render each thread touched this batch, write ONLY its sidecar (bodies),
    then flush the lightweight index once. Render BEFORE persisting so the index
    only records messages whose note + sidecar are on disk (resume-safe).

    INGRESS-1 п.5: по каждому отрисованному треду — ``ingest``-событие (``note_id``, ``path``,
    ``run_id``, ``detail {route: mail, msgs, disposition}``), пачкой на вызов."""
    events: list[dict[str, Any]] = []
    for tkey, rec in batch_recs.items():
        runlock.beat()  # MAIL-LOCK-1: писатель держит dt-sync.lock - сторож видит прогресс
        rel, chash = _render_thread(
            tkey, rec, vault_path,
            owner_domains=owner_domains, self_tokens=self_tokens, dry_run=False,
        )
        rec["note_path"] = rel
        rec["content_hash"] = chash
        if rec.get("splice_suspects"):
            stats.splice_suspects += 1
        _save_thread_rec(state_dir, tkey, rec)  # per-thread bodies (small write)
        index[tkey] = _index_entry(rec)
        included[tkey] = set(index[tkey]["msg_ids"])
        events.append({
            "stage": "ingest", "status": "done",
            "note_id": legacy_note_id(_thread_source_path(tkey)),
            "source_hash": chash, "path": rel,
            "detail": {"route": "mail", "msgs": len(rec.get("messages") or {}),
                       "disposition": "changed" if tkey in prev_keys else "new"},
        })
        if tkey not in rendered:
            rendered.add(tkey)
            if tkey in prev_keys:
                stats.changed += 1
            else:
                stats.new += 1
            if len(stats.examples) < 5:
                stats.examples.append(rel)
    _save_manifest(manifest_path, index)  # lightweight index only
    _emit_thread_events(events, run_id)


def _emit_thread_events(events: list[dict[str, Any]], run_id: str | None) -> None:
    """Лента событий: отрисованные треды (INGRESS-1 п.5). Best-effort — не ломает ingest."""
    if not events:
        return
    try:
        from core.eventlog import emit_batch, new_run_id
        from core.ingress.run import current_run

        run = current_run()
        rid = run_id or (run.run_id if run is not None else new_run_id())
        emit_batch([{**e, "run_id": rid} for e in events])
    except Exception:  # noqa: BLE001 — лента событий не критичный путь
        logger.debug("eventlog emit(mail thread) failed", exc_info=True)


def _explain_privacy_batch(
    bridge: MailBridge, batch: list[tuple[str, str, dict[str, Any]]],
    stats: MailIngestStats, out: Callable[[str], None],
) -> None:
    """Диагностика приватности пачки (dry-run, ``--explain-privacy``): читает тела (read-only),
    печатает ``правило · дата · тема[:60]`` каждого отказа ТОЛЬКО в ``out`` (консоль), считает
    «до» (прежнее правило) и «после» (суженное) по классу правила и папке. Журнал/файл не
    трогает."""
    for fname in sorted({b[0] for b in batch}):
        fbatch = [(bk, m) for (fn, bk, m) in batch if fn == fname]
        ids = [str(m.get("entryID") or "") for _bk, m in fbatch]
        by_id = {str(f.get("entryID") or ""): f for f in bridge.fetch_by_ids(fname, ids)}
        for bk, m in fbatch:
            msg = by_id.get(str(m.get("entryID") or ""))
            if msg is None:
                continue
            side = "inbox" if _is_inbox(bk) else "sent"
            before = privacy_reason(_privacy_probe(msg))
            after = _privacy_check(msg, sent=side == "sent")
            if before is not None:
                key = f"{_privacy_class(before)}/{side}"
                stats.privacy_before[key] = stats.privacy_before.get(key, 0) + 1
            if after is not None:
                key = f"{_privacy_class(after)}/{side}"
                stats.privacy_after[key] = stats.privacy_after.get(key, 0) + 1
                when = str(msg.get("date") or m.get("date") or "")[:10]
                subj = " ".join(str(msg.get("subject") or m.get("subject") or "").split())[:60]
                out(f"[privacy] {side} · {after} · {when} · {subj}")


def _explain_privacy_summary(stats: MailIngestStats, out: Callable[[str], None]) -> None:
    keys = sorted(set(stats.privacy_before) | set(stats.privacy_after))
    if not keys:
        out("[privacy] отказов приватности в окне нет (ни по прежнему, ни по новому правилу)")
        return
    out("[privacy] до → после (класс правила/папка):")
    for k in keys:
        out(f"[privacy]   {k}: {stats.privacy_before.get(k, 0)} → {stats.privacy_after.get(k, 0)}")


def ingest_mail(
    vault_path: Path,
    bridge: MailBridge,
    *,
    folders: list[dict[str, str]] | None = None,
    since: str | None = None,
    scope: str = "incremental",
    dry_run: bool = False,
    all_history: bool = False,
    batch_size: int | None = None,
    limit: int | None = None,
    should_stop: Callable[[], bool] | None = None,
    on_progress: Callable[[str], None] | None = None,
    explain_privacy: Callable[[str], None] | None = None,
) -> MailIngestStats:
    """PER-THREAD pull of Outlook folders → ``_legacy/correspondence/`` notes
    (принцип 11: optimised, transparent, interruptible, resumable).

    ONE note per conversation (``conversationId``), NOT one per message — a thread
    may span Inbox AND Sent, and the note accumulates across folders and runs
    (dedup + fragmentation gone). Two phases:

      1. CHEAP — ``list_folder_meta`` returns metadata (id/subject/from/date/
         conversationId) for every message in the window; per-message filters
         apply BEFORE any body: resume (message already in its thread's manifest
         record), then — Inbox only — noise (automated senders / bulk subjects).
         Survivors are grouped by conversationId.
      2. HEAVY — survivors are fetched in date-descending batches of ``batch_size``
         (``DT_MAIL_BATCH``, default 300) via ``fetch_by_ids``; privacy is
         re-checked with recipients, sender-noise (Inbox) is applied, and each
         message's FULL body (no quote-stripping) is appended to its thread record
         (content-hash dedup within the thread). Threads touched by a batch are
         re-rendered from their full (accumulated) record — messages sorted
         chronologically, exact duplicate blocks collapsed at render — and the
         manifest is flushed. Resume-safe: the manifest stores each included
         message's full text, so a later message (or the second folder) re-renders
         the whole thread without re-fetching the old ones. Meeting/calendar
         auto-responses are noise in both folders; frontmatter carries
         participants (senders + to/cc) and counterparties (external, non-owner)
         with their domains — as DATA (signals). No ``[[links]]`` are written
         here: связывание — отдельный проход ``core/linking`` (Phase 9).

    ``since`` windows the scan; ``all_history=True`` reads the whole folder (all
    years). ``dry_run`` counts threads/messages without fetching bodies or writing.
    ``should_stop`` is polled after each batch (graceful SIGTERM — the in-flight
    batch is flushed first); ``on_progress`` gets one ``[mail] …`` line per batch.
    Sent is never noise-filtered (only auto-reply prefixes). Noise is decided by
    :func:`core.legacy.mail_filter.decide` over ``_system/mail-filter.yaml``; a removed message is
    remembered (:class:`RefusedMemory`) so an incremental run never brings it back.
    ``explain_privacy`` (только с ``dry_run``; MAIL-FILTER-1 п.3) печатает в переданный
    callback - НЕ в журнал и не в файл - правило/дату/тему[:60] каждого privacy-отказа окна и
    счетчики «до/после» (читает тела писем, ничего не пишет). State is a LIGHTWEIGHT index
    manifest plus one
    sidecar file per thread (bodies) — each batch writes only its touched sidecars
    + the small index, so per-batch I/O is bounded (not O(corpus)). Memory holds
    the index + one batch, never all bodies. No LLM.

    Raises :class:`~core.operational.outlook_bridge.OutlookUnavailableError`
    (propagated from the bridge) when Outlook cannot be read.
    """
    start = time.perf_counter()
    vault_path = Path(vault_path)
    manifest_path = outlook_ingest_manifest_path()
    state_dir = _state_dir(manifest_path)
    # One-time: split a legacy 127 MB single-file manifest into sidecars + index.
    _migrate_manifest_if_needed(manifest_path, state_dir)
    # The index is lightweight (no bodies) — safe to hold fully in memory.
    index = {
        k: v
        for k, v in _load_manifest(manifest_path).items()
        if isinstance(v, dict) and "msg_ids" in v
    }
    prev_keys = set(index.keys())
    included = {k: set(v.get("msg_ids") or []) for k, v in index.items()}
    # MAIL-THREAD-1 инвариант: msg_id принадлежит РОВНО одному треду. Карта владельцев
    # строится из индекса; для уже задвоенных (до ремонта) владельцем считается первый
    # тред — их разбирает mail_repair, а не инжест.
    owner: dict[str, str] = {}
    for tk, ent in index.items():
        for mid in ent.get("msg_ids") or []:
            owner.setdefault(str(mid), tk)
    # INGRESS-1: ``run_id`` прогона — общий с итогом (контекст ``ingress_run``), иначе свой.
    from core.ingress.run import current_run

    _run = current_run()
    run_id = _run.run_id if _run is not None else None
    stats = MailIngestStats(
        dry_run=dry_run, scope=scope, manifest_path=str(manifest_path)
    )

    folder_specs = folders if folders is not None else outlook_folders()
    stats.folders = [spec["bucket"] for spec in folder_specs]
    batch_n = batch_size if (batch_size and batch_size > 0) else mail_batch_size()
    rules: Rules = load_rules(vault_path)
    stats.filter_source = rules.source
    memory = RefusedMemory()
    owner_domains = mail_owner_domains()
    # ACT-1 / хвост PERF-1: прогресс виден живьём и под пайпом launchd (flush).
    emit = on_progress if on_progress is not None else (lambda msg: print(msg, flush=True))
    stop = should_stop if should_stop is not None else (lambda: False)
    self_tokens = outlook_self_tokens()

    # ---- Phase 1: META across all folders → per-message filters → survivors. ---
    survivors: list[tuple[str, str, dict[str, Any]]] = []  # (folder, bucket, meta)
    refusals: list[dict[str, str]] = []
    eid_thread: dict[str, str] = {}
    thread_keys: set[str] = set()
    for spec in folder_specs:
        bucket, name = spec["bucket"], spec["name"]
        is_inbox = bucket.strip().lower() in ("inbox", "входящие")
        cur = _cursor_for(index, bucket, scope, since=since, all_history=all_history)
        # Мост листает папку целиком, ``since`` у него - постфильтр в Python; берем полный листинг и
        # режем здесь той же функцией, чтобы СЧИТАТЬ отрезанное (skipped_since), а не терять молча.
        full_meta = bridge.list_folder_meta(name, None)
        meta = filter_since(full_meta, cur.since)
        cut = len(full_meta) - len(meta)
        stats.skipped_since += cut
        stats.skipped_since_by_folder[bucket] = cut
        stats.since_effective[bucket] = cur.since or "all"
        stats.since_notes[bucket] = f"{bucket}: {cur.note(pull_window=outlook_pull_window())}"
        emit(f"[mail] {stats.since_notes[bucket]}, отрезано границей {cut}")
        meta.sort(key=lambda m: (_parse_dt(m.get("date")) or _EPOCH), reverse=True)
        for m in meta:
            eid = str(m.get("entryID") or "")
            if not eid:
                continue
            tkey = _thread_key(m.get("conversationId"), eid)
            # resume: this message is already recorded in its thread → skip.
            if scope != "full" and eid in included.get(tkey, ()):
                stats.resumed += 1
                continue
            # MAIL-FILTER-1: снятое фильтром прежде не возвращаем (``scope=full`` - решает yaml).
            if scope != "full" and eid in memory:
                stats.refused_resumed += 1
                continue
            # Темовые правила ДО чтения тела (в метаданных отправителя нет): Sent - только
            # авто-префиксы; Inbox - при пустом allow, иначе решит чтение письма (allow бьет все).
            nd = decide_meta(m.get("subject"), inbox=is_inbox, rules=rules)
            if nd is not None:
                _record_noise(stats, memory, nd, eid=eid, subject=str(m.get("subject") or ""),
                              sender=str(m.get("from") or ""), dry_run=dry_run)
                continue
            prior = owner.get(eid)
            if prior is not None and prior != tkey:
                # Второй тред для того же msg_id — отказ с журналом, не тихий дубль.
                stats.rejected_multi_thread += 1
                refuse("mail", "multi_thread", source_id=eid)
                refusals.append(
                    {"msg_id": eid, "have": prior, "want": tkey, "folder": name}
                )
                if len(stats.reject_examples) < 5:
                    stats.reject_examples.append(f"{eid}: {prior} ≠ {tkey}")
                logger.warning(
                    "[mail] msg_id %s уже в треде %s — отказ класть во второй (%s)",
                    eid, prior, tkey,
                )
                continue
            owner[eid] = tkey
            eid_thread[eid] = tkey
            thread_keys.add(tkey)
            survivors.append((name, bucket, m))
            stats.added_by_folder[bucket] = stats.added_by_folder.get(bucket, 0) + 1
            day = str(m.get("date") or "")[:10]
            days = stats.added_dates.setdefault(bucket, [])
            if day and day not in days:
                days.append(day)

    stats.bridge_misaligned = len(getattr(bridge, "misaligned", []) or [])
    memory.save()
    if refusals:
        _emit_refusals(refusals)
    total_msgs = len(survivors)
    total_threads = len(thread_keys)
    rendered: set[str] = set()

    if total_msgs == 0:
        emit("[mail] 0/0 threads | msgs 0 | done")
        stats.elapsed_s = time.perf_counter() - start
        return stats

    # ACT-1: маяк для pult_activity — счётчики тредов/сообщений, без тем/адресов.
    beacon = ProgressBeacon("mail", total_threads, emit=emit)

    # ---- Phase 2: fetch bodies per batch (by EXACT id), accumulate + render. ---
    consumed = 0
    stopped = False
    broken_threads: set[str] = set()
    i = 0
    while i < total_msgs:
        batch = survivors[i:i + batch_n]
        i += batch_n
        consumed += len(batch)

        if not dry_run:
            # Threads touched this batch — their bodies live in batch_recs (loaded
            # from the sidecar on first touch), so memory holds one batch, not all.
            batch_recs: dict[str, dict[str, Any]] = {}
            for fname in {b[0] for b in batch}:
                fbatch = [(bk, m) for (fn, bk, m) in batch if fn == fname]
                ids = [str(m.get("entryID") or "") for _bk, m in fbatch]
                # Direct id lookups — only these messages, no date-span over-fetch.
                by_id = {
                    str(f.get("entryID") or ""): f
                    for f in bridge.fetch_by_ids(fname, ids)
                }
                for bk, m in fbatch:
                    eid = str(m.get("entryID") or "")
                    msg = by_id.get(eid)
                    if msg is None:
                        continue
                    sent_msg = not _is_inbox(bk)
                    p_reason = _privacy_check(msg, sent=sent_msg)
                    if p_reason is not None:
                        stats.skipped_privacy += 1
                        # MAIL-PRIVACY-2: строка журнала - id письма, КЛАСС правила и папка·дата;
                        # ни темы, ни участников, ни фамилии (значение правила отрезано)
                        when = str(msg.get("date") or m.get("date") or "")[:10]
                        side = "sent" if sent_msg else "inbox"
                        refuse("mail", "privacy_probe", source_id=eid,
                               rule=p_reason.partition(":")[0],
                               hint=f"{side} · {when}" if when else side)
                        continue
                    frm = str(msg.get("from") or m.get("from") or "")
                    # Шум по полному правилу (отправитель известен только теперь): Inbox -
                    # весь набор yaml, Sent - только авто-префиксы.
                    subj_now = str(msg.get("subject") or m.get("subject") or "")
                    nd = decide({"subject": subj_now, "from": frm}, inbox=not sent_msg, rules=rules)
                    if nd.noise:
                        _record_noise(stats, memory, nd, eid=eid, subject=subj_now, sender=frm,
                                      dry_run=False)
                        continue
                    tkey = eid_thread[eid]
                    if tkey in broken_threads:
                        continue
                    if tkey not in batch_recs:
                        # Load the thread's existing bodies (prior runs/folders)
                        # from its sidecar so re-render has the whole conversation.
                        try:
                            rec = _load_thread_rec(state_dir, tkey)
                        except StoreUnavailableError as exc:
                            # Битый сайдкар: НЕ подменяем пустой записью (потеряли бы
                            # накопленные сообщения) и не валим остальные треды —
                            # изолируем тред, считаем, оставляем сообщение на повтор.
                            broken_threads.add(tkey)
                            stats.thread_store_errors += 1
                            refuse("mail", "error", source_id=str(tkey))
                            if len(stats.reject_examples) < 5:
                                stats.reject_examples.append(f"{tkey}: {exc.reason[:80]}")
                            logger.error("[mail] сайдкар треда %s нечитаем: %s", tkey, exc)
                            continue
                        rec.setdefault("conversationId", str(m.get("conversationId") or "").strip())
                        rec.setdefault("subject", "")
                        batch_recs[tkey] = rec
                    rec = batch_recs[tkey]
                    date = str(msg.get("date") or m.get("date") or "")
                    # FULL body — no quote-stripping (per-thread already removes
                    # fragmentation; exact dup blocks are collapsed only at render).
                    text = str(msg.get("body") or "").strip()
                    to_str = str(msg.get("to") or "")
                    cc_str = str(msg.get("cc") or "")
                    chash = hashlib.sha1(f"{date}|{frm}|{text}".encode()).hexdigest()  # noqa: S324 — content hash (identity/dedup), not security
                    if any(mm.get("hash") == chash for mm in rec["messages"].values()):
                        stats.duplicate += 1
                        continue
                    rec["messages"][eid] = {
                        "date": date, "from": frm, "to": to_str, "cc": cc_str,
                        "is_me": _sender_is_me(frm, self_tokens),
                        "text": text, "bucket": bk, "hash": chash,
                        # MAIL-THREAD-1: тема САМОГО сообщения — по ней определяется
                        # родной тред при ремонте и считается детект склейки.
                        "subject": str(msg.get("subject") or m.get("subject") or "").strip(),
                    }
                    if not rec.get("subject"):
                        rec["subject"] = str(msg.get("subject") or m.get("subject") or "").strip()
                    stats.msgs_added += 1
            _flush_threads(
                batch_recs, index=index, included=included, prev_keys=prev_keys,
                rendered=rendered, owner_domains=owner_domains,
                self_tokens=self_tokens, stats=stats, vault_path=vault_path,
                state_dir=state_dir, manifest_path=manifest_path, run_id=run_id,
            )
            memory.save()
        else:
            if explain_privacy is not None:
                _explain_privacy_batch(bridge, batch, stats, explain_privacy)
            # Preview: count messages + threads, no fetch, no write.
            for _fn, _bk, m in batch:
                tkey = eid_thread[str(m.get("entryID") or "")]
                stats.msgs_added += 1
                if tkey not in rendered:
                    rendered.add(tkey)
                    if tkey in prev_keys:
                        stats.changed += 1
                    else:
                        stats.new += 1

        elapsed = time.perf_counter() - start
        eta = _fmt_eta(elapsed / consumed * (total_msgs - consumed)) if consumed else "?"
        beacon.update(
            len(rendered),
            {"msgs": stats.msgs_added},
            line=f"[mail] {len(rendered)}/{total_threads} threads | "
            f"msgs {stats.msgs_added} | ~{eta}",
        )
        if stop():
            stopped = True
            break

    stats.notes_total = len(rendered)
    if explain_privacy is not None and dry_run:
        _explain_privacy_summary(stats, explain_privacy)
    beacon.update(
        len(rendered),
        {"msgs": stats.msgs_added},
        line=f"[mail] {len(rendered)}/{total_threads} threads | msgs {stats.msgs_added} | "
        f"{'stopped' if stopped else 'done'}",
    )
    # Остановка сигналом оставляет маяк незавершённым → interrupted в activity
    # (прогресс уже слит батчами, повторный запуск продолжит с курсора).
    if not stopped:
        beacon.done(f"{len(rendered)} threads, {stats.msgs_added} msgs")
    stats.elapsed_s = time.perf_counter() - start
    return stats
