# digital-twin engine

Code for the digital-twin system (architecture: [`docs/02-architecture.md`](docs/02-architecture.md)).
This repo is the `engine/` half of the workspace; the markdown source of truth
lives in a separate `vault/` repo.

## Layout

```
core/            # pure shared library (no MCP/CLI deps — see invariant below)
  vault.py       #   read markdown notes + frontmatter, walk the vault
  chunking.py    #   markdown-aware chunking
  embeddings.py  #   local BGE-M3 embedder (interface + singleton)
  config.py      #   path config (.derived/lancedb, models/)
  retrieval/     #   LanceDB index (index.py) + hybrid RRF search (search.py)
cli/             # argparse scripts (interface layer), e.g. dt_index.py
mcp-server/      # MCP entry point + tool registrations (interface layer)
scripts/         # demos + smoke (smoke_retrieval.py)
tests/           # pytest units + fixtures
docs/            # concept, architecture, implementation plan, playbook, roadmap (05-roadmap-2026-07.md — рабочий бэклог)
```

**Invariant:** `core/` does not import from `mcp-server/` or `cli/`, nor from
external services. It is a standalone library so new interfaces can be added
without rewriting logic (enforced by `tests/test_invariant.py`).

## Setup

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/).

```bash
uv sync            # create .venv and install runtime + dev deps
uv run pytest      # run tests
uv run ruff check .   # lint
```

The retrieval stack (BGE-M3 embeddings + LanceDB) is a runtime dependency. The
first run downloads BGE-M3 (~2GB) into `engine/models/` (gitignored). Remaining
future dependencies stay optional:

```bash
uv sync --extra parsers      # python-pptx / pymupdf / python-docx
uv sync --extra connectors   # msal
uv sync --extra precise      # tiktoken (precise chunk token counts)
uv sync --extra server       # mcp SDK — run the MCP server (mcp-server/README.md)
```

`uv run pytest` runs the fast unit tests. The heavy end-to-end smoke (loads
BGE-M3) is opt-in:

```bash
uv run pytest -m slow                  # smoke as a test
uv run python scripts/smoke_retrieval.py   # smoke as a script
```

## Retrieval

Indexes are **derived and per-machine** (not versioned): the LanceDB store lives
in `<workspace_root>/.derived/lancedb/`, the model cache in `engine/models/` —
both covered by `.gitignore`.

```bash
uv run python cli/dt_index.py --vault PATH   # build/rebuild the LanceDB index
```

Search is hybrid: vector (BGE-M3) + BM25/FTS fused with **Reciprocal Rank
Fusion (RRF)**, done natively by LanceDB. The cross-encoder reranker
(BGE-reranker) is intentionally **off** at start (architecture §5/§10) — "RRF on,
cross-encoder off". The embedding backend sits behind an `Embedder` interface;
only local BGE-M3 is implemented. If the model fails to load it raises an
explicit error with diagnostics — no silent fallback to a remote API.

## Demo

Read a sample note and print its chunks:

```bash
uv run python scripts/demo_chunking.py tests/fixtures/report_large.md
```

## Token sizing in chunking

`core.chunking` sizes chunks with a `words × 1.3` heuristic by default — no
extra dependency, fully offline and deterministic. If `tiktoken` is installed
(`uv sync --extra precise`) it is used instead as a closer approximation. Exact
agreement with the BGE-M3 tokenizer is intentionally out of scope here (a later
deliverable).
