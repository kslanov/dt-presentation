"""Shared ``.env`` loading for the CLIs (interface layer).

``core/`` reads ``os.environ`` directly — loading ``engine/.env`` is a CLI concern
(architecture §0/§8), so every CLI calls :func:`load_env` once at the start of
``main`` *before* reading any config (e.g. ``legacy_roots()``, tokens). The path is
anchored to ``engine/.env`` (this file is ``engine/cli/_env.py``), so it resolves
regardless of the current working directory. Values land in ``os.environ`` and are
never logged.
"""

from __future__ import annotations

import contextlib
import logging
import os
import stat
import sys
from pathlib import Path

from core.config.env_file import load_env_layers

# engine/cli/_env.py → parents[1] = engine/ → engine/.env
_ENGINE_ENV = Path(__file__).resolve().parents[1] / ".env"


def _line_buffer_stdout() -> None:
    """Force line-buffered stdout so progress lines appear promptly.

    Хвост-1 (фикс класса): под ``nohup``/pipe Python block-buffers stdout (it is
    not a tty), so a long CLI's progress prints arrive in rare bursts. Every CLI
    calls :func:`load_env` first thing in ``main`` → doing it here makes the fix
    apply to **all** long CLIs at once (dt_index / dt_sync / dt_corpus_retag /
    dt_ingest_current / dt_legacy_ingest …), not one at a time. No-op for a tty
    (already line-buffered) and for a stream without ``reconfigure`` (e.g. a
    captured buffer under a test); best-effort — never fails a run.
    """
    reconfigure = getattr(sys.stdout, "reconfigure", None)
    if reconfigure is not None:
        with contextlib.suppress(Exception):
            reconfigure(line_buffering=True)


def _warn_env_permissions() -> None:
    """SEC-5 гигиена: предупредить, если ``engine/.env`` доступен группе/остальным.

    ``.env`` — plaintext-секреты; корректный режим ``600`` (только владелец). Если
    выставлены любые group/other-биты (``mode & 0o077``), логируем warning — но
    **не чиним молча** (изменение прав — решение владельца; ТЗ). Best-effort:
    отсутствие файла / не-POSIX (Windows, где режим не значим) / любой сбой stat —
    тихо пропускаем, CLI не роняем.
    """
    if os.name != "posix":
        return
    with contextlib.suppress(Exception):
        if not _ENGINE_ENV.is_file():
            return
        mode = stat.S_IMODE(_ENGINE_ENV.stat().st_mode)
        if mode & 0o077:
            logging.getLogger("cli._env").warning(
                ".env доступен не только владельцу (режим %o) — секреты в plaintext. "
                "Ограничь: chmod 600 %s (или мигрируй в Keychain: dt_secrets --migrate).",
                mode,
                _ENGINE_ENV,
            )


def load_env() -> None:
    """Shared CLI init: load ``engine/.env`` + line-buffer stdout + unified logger.

    Loads ``engine/.env`` into ``os.environ`` (tokens + ``DT_*`` knobs). Does not
    override variables already set in the environment (python-dotenv default), so
    an explicit ``export`` still wins over the file. PERSONAL-1: with ``DT_INSTANCE``
    set, ``engine/instances/<name>.env`` is layered on top of ``.env`` (overlay wins,
    environment wins over both); without it the load is the same single ``.env``.
    Also line-buffers stdout (see
    :func:`_line_buffer_stdout`) — this is the one place every CLI runs first, so
    progress stays live under ``nohup``/pipe across all of them.

    CODE-5-1: configures the unified logger (RotatingFile ``dt-sync.log`` + stderr,
    human-readable format with ``[corr-id]`` + token scrub) and mints a fresh
    correlation-id per CLI process — so every CLI logs uniformly and one run's lines
    (and its eventlog/metrics events) are traceable by a shared ``corr_id``. Tokens
    are loaded first so the scrub filter sees them.
    """
    load_env_layers(_ENGINE_ENV)  # PERSONAL-1: оверлей экземпляра (DT_INSTANCE) поверх .env
    _line_buffer_stdout()

    from core.logging_setup import new_corr_id, setup_logging

    setup_logging()
    new_corr_id()
    _warn_env_permissions()
