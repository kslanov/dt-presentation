"""dt — единая точка входа CLI: ``dt skills …``, ``dt host-config …`` (TOOLS-PROFILES-1),
``dt web-token …`` (WEBPULT-ACCESS-1), ``dt mail-filter explain|lint`` (MAIL-FILTER-1),
``dt plugin kimi`` (MODEL-1), ``dt ai show|set|set-key|test`` и ``dt pult open|status|url``
(PULT-STANDALONE-1), ``dt config show|check|set|init`` и ``dt client join`` (CONFIG-1),
``dt owner init|show|check|export`` (PROFILE-1), ``dt backup prune-bak`` (SURFACE-HYGIENE-1), ``dt
facts versions|backfill`` (FACTS-BITEMPORAL-1), ``dt lint [--dry-run]`` (KNOWLEDGE-LINT-1),
``dt outputs mark [--dry-run]`` (EVAL-HYGIENE-1), ``dt instance add|list|status|remove``
``dt vault init --kind work|personal`` и ``dt bridge`` (PERSONAL-1), ``dt version`` (DEV-3-CORE),
``dt install`` / ``dt uninstall`` / ``dt doctor`` (DEV-3-KIT: ``dt doctor`` - псевдоним
``cli/dt_doctor.py``).

Остальные CLI живут отдельными скриптами (``cli/dt_*.py``); здесь — только новые команды,
у которых нет своего скрипта-предшественника.
``uv run python cli/dt.py host-config kimi --profile lean``.
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

COMMANDS = {
    "skills": "dt_skills",
    "host-config": "dt_host_config",
    "web-token": "dt_web_token",
    "mail-filter": "dt_mail_filter",
    "plugin": "dt_plugin",
    "ai": "dt_ai",
    "pult": "dt_pult",
    "config": "dt_config",
    "client": "dt_client",
    "owner": "dt_owner",
    "backup": "dt_backup",
    "facts": "dt_facts",
    "lint": "dt_lint",
    "outputs": "dt_outputs",
    "instance": "dt_instance",
    "vault": "dt_vault",
    "bridge": "dt_bridge",
    "version": "dt_version",
    "doctor": "dt_doctor",
    "install": "dt_install",
    "uninstall": "dt_uninstall",
}


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] not in COMMANDS:
        print("usage: dt <" + "|".join(COMMANDS) + "> [args…]", file=sys.stderr)
        return 2
    import importlib

    module = importlib.import_module(COMMANDS[args[0]])
    return int(module.main(args[1:]))


if __name__ == "__main__":
    raise SystemExit(main())
