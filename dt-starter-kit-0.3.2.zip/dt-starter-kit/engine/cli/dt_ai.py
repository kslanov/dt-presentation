"""dt ai - шлюз моделей слоя ИИ-синтезов пульта (PULT-STANDALONE-1, GATEWAY-1).

Настройка живет в ``vault/_system/pult.yaml`` (раздел ``ai``): **профили** моделей (``cheap``,
``strong``, ``local`` - имена свободные) и **маршруты** «класс задачи -> профиль | host | none».
Классы: ``triage`` (бриф, лейн захвата), ``synth`` (состояние хаба, проверка хаба), ``draft``
(черновик). Ключ профиля - ТОЛЬКО файл ``.secrets/pult_ai_key[-<профиль>]`` (права 600): ``show``
отдает последние 4 символа, ``set-key`` читает ключ из stdin или скрытого запроса и в stdout его не
пишет.

* ``show`` - профили (без ключей), маршруты, классы, последний вызов (из аудита);
* ``set route <класс> <профиль|host|none>`` - куда идет класс;
* ``set profile <имя> поле=значение ...`` - создать/править профиль (``provider``, ``url``,
  ``model``, ``key_file``, ``timeout_s``, ``max_chars``, ``max_calls_per_hour``);
* ``rm profile <имя>`` - удалить профиль (нельзя, пока на него есть маршрут);
* ``set-key [--profile P] [--key-file F]`` - положить ключ (``echo $KEY | dt ai set-key``);
* ``test [--class C]`` - один вызов ``brief`` по маршруту класса мимо кэша (``host``/``none`` -
  сообщение, не вызов);
* ``migrate`` - плоский ``ai:`` -> профили и маршруты (бэкап ``pult.yaml.bak-*`` рядом);
* ``set --provider P [--url U] [--model M] ...`` - прежняя форма: правит профиль ``default``.

Usage:
    uv run python cli/dt.py ai show
    uv run python cli/dt.py ai set profile cheap provider=openai model=kimi-k2 \
        url=https://api.moonshot.ai/v1
    uv run python cli/dt.py ai set route triage cheap
    uv run python cli/dt.py ai set-key --profile cheap
    uv run python cli/dt.py ai test --class triage
"""

from __future__ import annotations

import argparse
import getpass
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.operational import ai_gateway, ai_layer
from core.operational.brief import build_brief

# Фиксированный фид для ``dt ai test``: не боевые данные, провайдеру уходят вымышленные числа.
_TEST_FEED = {
    "now": "2026-01-15T09:00:00Z",
    "counts": {"deals_active": 12, "presales": 3, "tasks_overdue": 2, "tasks_due_week": 4,
               "unanswered_mail": 1},
    "attention": [
        {"type": "checklist_overdue", "id": "checklist:T-1:x", "title": "Согласовать КП",
         "deal": {"code": "T-1", "name": "Тестовая сделка"}, "days_overdue": 3},
        {"type": "mail_unanswered", "id": "mail:x", "title": "Вопрос по смете", "silent_days": 4},
    ],
    "deltas": [{"type": "deal", "title": "Тестовая сделка"}],
    "colleagues": {"changed_deals": 2, "mine": 1, "entries": 3, "days": 14},
}
_INT_FIELDS = ("timeout_s", "max_chars", "max_calls_per_hour")
_SIDE_TEXT = {"none": "нет (база движка)", "host": "хост (askClaude)", "daemon": "демон"}


def _fail(exc: ai_gateway.SettingsError) -> int:
    print(f"отказ [{exc.code}]: {exc}", file=sys.stderr)
    return 2


def _show() -> int:
    cfg = ai_layer.get_settings()
    view = ai_layer.settings_view(cfg)
    if view["legacy_flat"]:
        print("конфиг в плоской форме (профиль default, все маршруты на него): "
              "`dt ai migrate` перепишет в профили и маршруты (бэкап рядом)")
    print("профили:")
    for name, p in view["profiles"].items():
        key = p["key"]
        key_line = (f"ключ ...{key['tail']}" if key["configured"] else "ключ не задан")
        key_line += f" (.secrets/{key['file']})"
        key_line += "" if key["mode_ok"] else " ПРАВА ШИРЕ 600: chmod 600"
        print(f"  {name}: {p['provider']}"
              + (" (синтеза нет)" if p["provider"] == "none" else "")
              + f"  url {p['url'] or '-'}  model {p['model'] or '-'}")
        print(f"      {key_line}; timeout_s {p['timeout_s']}, max_chars {p['max_chars']}, "
              f"вызовов/ч {p['max_calls_per_hour']}")
    print("маршруты:")
    for cls, target in view["routes"].items():
        kinds = ", ".join(view["classes"][cls])
        if view["route_errors"].get(cls):
            side = f"ОШИБКА {view['route_errors'][cls]}: профиля {target!r} нет"
        else:
            side = _SIDE_TEXT[view["sides"][cls]]
        leaves = "; данные уходят наружу (явный выбор)" if view["sends_data_out"][cls] else ""
        print(f"  {cls:<7} -> {target:<10} [{kinds}] {side}{leaves}")
    last = ai_layer.last_call()
    if last:
        tail = "ok" if last["ok"] else f"ошибка {last.get('code', '?')}"
        print(f"последний вызов: {last['at']} {last['kind']} {last['profile']} "
              f"{last['provider']}/{last['model']} {last['ms']} мс - {tail}")
    else:
        print("последний вызов: нет")
    return 0


def _apply(values: dict[str, object], *, hint: str = "") -> int:
    try:
        ai_layer.save_settings(values, allow_key_file=True)
    except ai_gateway.SettingsError as exc:
        return _fail(exc)
    if hint:
        print(hint, file=sys.stderr)
    return _show()


def _parse_pairs(pairs: list[str]) -> dict[str, object]:
    out: dict[str, object] = {}
    for pair in pairs:
        field, sep, raw = pair.partition("=")
        if not sep or not field:
            raise ai_gateway.SettingsError(
                "bad_values", f"ожидается поле=значение, получено {pair!r}")
        if field in _INT_FIELDS:
            if raw in ("", "null") and field == "max_calls_per_hour":
                out[field] = None
                continue
            try:
                out[field] = int(raw)
            except ValueError:
                raise ai_gateway.SettingsError(f"bad_{field}", f"{field}: целое число") from None
        else:
            out[field] = raw
    return out


def _set_route(args: argparse.Namespace) -> int:
    return _apply({f"routes.{args.cls}": args.target})


def _set_profile(args: argparse.Namespace) -> int:
    try:
        fields = _parse_pairs(args.pairs)
    except ai_gateway.SettingsError as exc:
        return _fail(exc)
    if not fields:
        print("нечего менять: поле=значение (provider/url/model/key_file/timeout_s/max_chars/"
              "max_calls_per_hour)", file=sys.stderr)
        return 2
    return _apply({f"profiles.{args.name}.{f}": v for f, v in fields.items()})


def _set_legacy(args: argparse.Namespace) -> int:
    values: dict[str, object] = {}
    for field, value in (("provider", args.provider), ("url", args.url), ("model", args.model),
                         ("key_file", args.key_file), ("timeout_s", args.timeout_s),
                         ("max_chars", args.max_chars)):
        if value is not None:
            values[field] = value
    if not values:
        print("нечего менять: set route <класс> <профиль|host|none> | set profile <имя> "
              "поле=значение | (прежнее) --provider/--url/--model/--key-file/--timeout-s/"
              "--max-chars", file=sys.stderr)
        return 2
    return _apply(values, hint="подсказка: плоские поля правят профиль default; теперь есть "
                  "`dt ai set profile <имя> ...` и `dt ai set route <класс> <профиль>`")


def _rm_profile(args: argparse.Namespace) -> int:
    return _apply({f"profiles.{args.name}": None})


def _set_key(args: argparse.Namespace) -> int:
    try:  # нет такого профиля - отказ ДО запроса ключа
        ai_layer.key_status(args.profile)
    except ai_gateway.SettingsError as exc:
        return _fail(exc)
    if sys.stdin.isatty():
        value = getpass.getpass("ключ провайдера (ввод скрыт): ")
    else:
        value = sys.stdin.readline()
    try:
        status = ai_layer.set_key(value, profile=args.profile, key_file=args.key_file)
    except ai_gateway.SettingsError as exc:
        return _fail(exc)
    print(f"ключ профиля {args.profile} записан в .secrets/{status['file']} (права 600), "
          f"хвост ...{status['tail']}")
    return 0


def _migrate() -> int:
    res = ai_layer.migrate()
    if not res["migrated"]:
        print("мигрировать нечего: раздела ai в плоской форме нет")
        return 0
    print(f"перенесено в профили и маршруты; бэкап: {res['backup']}")
    return _show()


def _test(args: argparse.Namespace) -> int:
    try:
        res = ai_gateway.resolve_class(args.cls, ai_layer.get_settings())
    except ai_gateway.SettingsError as exc:
        return _fail(exc)
    if res.side != "daemon":
        what = ("синтез делает хост (askClaude)" if res.side == "host"
                else "синтеза нет (база движка)")
        print(f"класс {args.cls} -> {res.route}: {what}; вызова провайдеру нет (для проверки: "
              f"dt ai set route {args.cls} <профиль openai|anthropic>)", file=sys.stderr)
        return 2
    label = f"{res.profile}:{res.provider}/{res.model}"
    brief = build_brief(_TEST_FEED)
    payload = {"brief": brief, "summary": {"counts": _TEST_FEED["counts"]}}
    # brief - вид класса triage; для synth/draft берем их вид с тем же фиксированным текстом
    kind = {"triage": "brief", "synth": "hub_synth", "draft": "draft"}[args.cls]
    if kind != "brief":
        payload = {"prompt": "Ответь одним коротким предложением: связь с провайдером работает."}
    out = ai_layer.synthesize(kind, payload, use_cache=False)
    if not out["ok"]:
        print(f"ОШИБКА {label}: {out['code']} ({out['ms']} мс)", file=sys.stderr)
        return 1
    snippet = " ".join(out["text"].split())[:80]
    print(f"ok {label} {out['ms']} мс")
    print(snippet)
    return 0


def main(argv: list[str] | None = None) -> int:
    load_env()
    parser = argparse.ArgumentParser(prog="dt ai", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    sub.add_parser("show")
    p_set = sub.add_parser("set", help="route | profile | (прежнее) плоские поля default")
    set_sub = p_set.add_subparsers(dest="what")
    p_route = set_sub.add_parser("route")
    p_route.add_argument("cls", metavar="класс", choices=ai_gateway.CLASSES)
    p_route.add_argument("target", metavar="профиль|host|none")
    p_prof = set_sub.add_parser("profile")
    p_prof.add_argument("name", metavar="имя")
    p_prof.add_argument("pairs", nargs="*", metavar="поле=значение")
    p_set.add_argument("--provider", choices=ai_layer.PROVIDERS)
    p_set.add_argument("--url")
    p_set.add_argument("--model")
    p_set.add_argument("--key-file", dest="key_file")
    p_set.add_argument("--timeout-s", dest="timeout_s", type=int)
    p_set.add_argument("--max-chars", dest="max_chars", type=int)
    p_rm = sub.add_parser("rm")
    rm_sub = p_rm.add_subparsers(dest="what", required=True)
    rm_sub.add_parser("profile").add_argument("name", metavar="имя")
    p_key = sub.add_parser("set-key")
    p_key.add_argument("--profile", default=ai_gateway.DEFAULT_PROFILE)
    p_key.add_argument("--key-file", dest="key_file")
    p_test = sub.add_parser("test")
    p_test.add_argument("--class", dest="cls", choices=ai_gateway.CLASSES, default="triage")
    sub.add_parser("migrate")
    args = parser.parse_args(argv)
    if args.cmd == "show":
        return _show()
    if args.cmd == "set":
        if args.what == "route":
            return _set_route(args)
        if args.what == "profile":
            return _set_profile(args)
        return _set_legacy(args)
    if args.cmd == "rm":
        return _rm_profile(args)
    if args.cmd == "set-key":
        return _set_key(args)
    if args.cmd == "migrate":
        return _migrate()
    return _test(args)


if __name__ == "__main__":
    raise SystemExit(main())
