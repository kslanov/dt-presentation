"""dt-backup — еженедельный бэкап невосстановимого .derived (WAVE0-HYGIENE п.6).

Состав: dt.db (SQLite .backup API), манифест почты + сайдкары тредов, манифесты инжеста,
леджеры ссылок, operational/*.json, events.jsonl, ticktick-состояние. LanceDB в бэкап НЕ
входит (восстановим пересборкой). Архив ``derived-weekly-<ts>.tar.gz`` в ``<workspace>/.backups``
(``DT_BACKUPS_PATH``), ротация — 4 последних. Плановый запуск: launchd ``com.dt.backup``
(воскресенье). Ручной: ``uv run python cli/dt_backup.py [--dry-run]``.

Restore: ``tar xzf <архив> -C <workspace>/.derived`` (раскладка относительна .derived).

SURFACE-HYGIENE-1 п.7: ``dt backup prune-bak [--keep 5] [--dry-run]`` (или
``cli/dt_backup.py prune-bak``) - ротация ``*.bak-*`` рядом с ``.env``, в ``.derived`` и у копии
артефакта пульта (корни - ``DT_BAK_ROOTS``); ``--dry-run`` только показывает, что уйдет и что
останется. Журнал ``pult-actions.log`` эта команда не трогает.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.backup import run_backup

logger = logging.getLogger(__name__)


def prune_bak_main(argv: list[str]) -> int:
    from core.bakprune import KEEP_DEFAULT, bak_roots, prune_bak

    parser = argparse.ArgumentParser(prog="dt backup prune-bak", description=prune_bak_main.__doc__)
    parser.add_argument("--keep", type=int, default=KEEP_DEFAULT,
                        help=f"сколько свежих .bak-* оставить на файл (default {KEEP_DEFAULT})")
    parser.add_argument("--dry-run", action="store_true", help="показать, ничего не удалять")
    args = parser.parse_args(argv)
    roots = bak_roots()
    report = prune_bak(roots, keep=args.keep, dry_run=args.dry_run)
    mode = "DRY-RUN" if report.dry_run else "PRUNE"
    print(f"[{mode}] keep={report.keep}, корней {len(roots)}")
    failed = 0
    for item in report.roots:
        print(f"{item['root']}: оставлено {len(item['kept'])}, "
              f"{'удалилось бы' if report.dry_run else 'удалено'} {len(item['removed'])}")
        for name in item["removed"]:
            print(f"  - {name}")
        for name in item["failed"]:
            failed += 1
            print(f"  ! не удалился: {name}", file=sys.stderr)
    total = len(report.removed)
    verb = "удалилось бы" if report.dry_run else "удалено"
    print(f"итого: {verb} {total}, оставлено {len(report.kept)}")
    return 1 if failed else 0


def main(argv: list[str] | None = None) -> int:
    args_in = list(sys.argv[1:] if argv is None else argv)
    if args_in and args_in[0] == "prune-bak":
        load_env()
        return prune_bak_main(args_in[1:])
    load_env()
    parser = argparse.ArgumentParser(prog="dt-backup", description=__doc__)
    parser.add_argument("--dry-run", action="store_true", help="показать состав, ничего не писать")
    args = parser.parse_args(args_in)

    result = run_backup(dry_run=args.dry_run)
    mode = "DRY-RUN" if args.dry_run else "BACKUP"
    total = sum(m["size"] for m in result.members)
    print(f"[{mode}] элементов {len(result.members)}, {total / 1e6:.1f} МБ → {result.archive}")
    for m in result.members:
        print(f"  {m['group']:11} {m['name']}  ({m['size'] / 1e6:.2f} МБ)")
    for name in result.missing:
        print(f"  (нет источника) {name}")
    if result.rotated:
        print(f"ротация: снято {', '.join(result.rotated)}")
    if result.error:
        logger.error("бэкап не удался: %s", result.error)
        print(f"ОШИБКА: {result.error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
