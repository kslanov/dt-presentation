"""dt bridge - ``bridge_scan`` личного экземпляра: связи личных заметок с рабочим знанием
(PERSONAL-1).

Только у экземпляра роли ``personal`` с ``DT_WORK_URL`` и токеном чтения рабочего демона
(``DT_WORK_TOKEN_FILE``); у рабочего экземпляра команда отказывает (нет клиента - нет моста).

Что делает: берет личные заметки, новые/измененные с прошлого скана, ищет перекликающееся в
рабочем знании (``find_notes`` + хабы) и кладет кандидатов карточками ``bridge`` в очередь решений
личного пульта. Принятие карточки записывает ``work_refs`` в ЛИЧНУЮ заметку; рабочий vault и его
``.derived`` не затрагиваются.

* ``--dry-run`` - только показать кандидатов (стор и дельта не пишутся);
* ``--limit N`` - не больше N заметок за прогон;
* ``--step`` - режим шага ночной цепочки: код выхода 0 всегда, итог одной строкой;
* ``--probe-level`` - проверить, что рабочий демон считает наш токен токеном чтения (оставляет в
  рабочем журнале действий одну строку отказа ``write_token_required``: проба зовет запись с
  заведомо неверным телом).

Usage:
    DT_INSTANCE=personal uv run python cli/dt.py bridge --dry-run --limit 5
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

logger = logging.getLogger(__name__)


def main(argv: list[str] | None = None) -> int:
    load_env()
    parser = argparse.ArgumentParser(prog="dt bridge", description=__doc__.split("\n")[0])
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--step", action="store_true")
    parser.add_argument("--probe-level", action="store_true")
    parser.add_argument(
        "--rescan", action="store_true",
        help="пересчитать связи по текущим правилам: ждущие карточки, переставшие проходить, "
             "снимаются (withdrawn); заметки берутся независимо от дельты (канарейка - --limit)")
    args = parser.parse_args(argv)

    from core.bridge.scan import scan
    from core.bridge.work_client import WorkClient
    from core.config import default_vault_path

    client = WorkClient.from_env()
    if client is None:
        msg = ("нет моста: нужны DT_INSTANCE_ROLE=personal, DT_WORK_URL и токен чтения "
               "(DT_WORK_TOKEN_FILE) - это личный экземпляр, см. dt instance add")
        if args.step:
            logger.info("bridge: пропущен (%s)", msg)
            print("bridge: пропущен - не личный экземпляр")
            return 0
        print(f"отказ: {msg}", file=sys.stderr)
        return 2
    if args.probe_level:
        level = client.token_level()
        print(f"токен моста: {level}")
        return 0 if level == "read" else 1
    result = scan(Path(default_vault_path()), client, dry_run=args.dry_run, max_notes=args.limit,
                  rescan=args.rescan)
    s = result.summary()
    print(f"bridge{' (dry-run)' if args.dry_run else ''}{' (rescan)' if args.rescan else ''}: "
          f"опрошено {s['scanned']}, без изменений "
          f"{s['unchanged']}, кандидатов {s['candidates']} (новых {s['new']}, обновлено "
          f"{s['updated']}, оставлено {s['kept']}), ниже порога {s['below_threshold']}"
          f", заглушек {s['stubs']}, страниц {s['pages']}, слабых {s['weak']}, "
          f"коротких {s['short']}, без терминов {s['no_terms']}"
          + (f", снято {s['withdrawn']}" if args.rescan else "")
          + (", ЧАСТИЧНО (бюджет)" if s["partial"] else "")
          + (f", РАБОЧИЙ ДЕМОН НЕДОСТУПЕН ({s['work_unavailable']})" if s["work_unavailable"]
             else ""))
    if args.dry_run:
        for item in result.items:
            terms = ", ".join(item.get("terms") or []) or "без общих терминов"
            print(f"  {item['score']:.2f}  «{item['personal_title']}» ↔ «{item['work_title']}» "
                  f"[{item['matched_by']}] · термины: {terms}")
    if s["work_unavailable"]:
        logger.warning("bridge: рабочий демон недоступен (%s): скан прерван, заметки остались в "
                       "дельте", s["work_unavailable"])
    return 0 if args.step or not s["work_unavailable"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
