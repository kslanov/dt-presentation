"""dt client — машина без vault ходит на демон-сервер по Tailscale (CONFIG-1 п.6): ``join``.

``join --server <dns|ip|url>`` - разовый обмен ключом: на сервере ``dt web-token show rw`` печатает
токен, здесь он читается из stdin (``printf %s "$KEY" | dt client join --server …``) или скрытого
запроса и ложится в ``.secrets/web_token_rw`` (права 600); значение не печатается, только хвост 4
символа. Перед записью проверяется ``/health`` сервера и принятие токена на ``/mcp``; затем в
``.env`` клиента через ``env_file`` пишутся ``DT_MODE=client`` и ``DT_SERVER_URL``. Дальше -
``dt host-config <host> --server … --install`` и ``dt host-config --verify``.

Usage:
    uv run python cli/dt.py client join --server konstantins-macbook-pro.tail1faf5a.ts.net
    printf %s "$KEY" | uv run python cli/dt.py client join --server 100.99.184.42 --token rw
"""

from __future__ import annotations

import argparse
import getpass
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.client import JoinError, join


def _read_key(args: argparse.Namespace) -> str:
    if args.key_file:
        return Path(args.key_file).expanduser().read_text(encoding="utf-8").strip()
    if sys.stdin.isatty():
        return getpass.getpass("ключ с сервера (`dt web-token show rw`; ввод скрыт): ").strip()
    return sys.stdin.readline().strip()


def _join(args: argparse.Namespace) -> int:
    try:
        key = _read_key(args)
        result = join(
            args.server, key, which=args.token,
            env_path=Path(args.env_file) if args.env_file else None,
            directory=Path(args.secrets_dir) if args.secrets_dir else None,
        )
    except JoinError as exc:
        print(f"join отклонён: {exc.reason}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"ключ не прочитан: {type(exc).__name__}", file=sys.stderr)
        return 2
    print(f"сервер {result.base}: отвечает · режим {result.mode} · код {result.code}")
    print(f"токен {args.token}: …{result.token_tail} → {result.token_path} (права 600)")
    changed = ", ".join(result.env_changed) or "без изменений"
    print(f".env: DT_MODE=client, DT_SERVER_URL={result.base} ({changed})")
    print("дальше: dt host-config <claude|cursor|kimi> --server "
          f"{result.base} --install; проверка: dt host-config <host> --verify, dt doctor")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt client", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    j = sub.add_parser("join", help="завести токен-файл и режим client на этой машине")
    j.add_argument("--server", required=True, help="dns-имя, IP или url сервера (порт 8787)")
    j.add_argument("--token", choices=("rw", "read"), default="rw",
                   help="какой токен выдан (дефолт rw: профили пишут выходы)")
    j.add_argument("--key-file", default=None, help="прочитать ключ из файла вместо stdin/запроса")
    j.add_argument("--env-file", default=None, help="другой .env клиента (пробы)")
    j.add_argument("--secrets-dir", default=None, help="другой каталог .secrets (пробы)")
    j.set_defaults(func=_join)
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
