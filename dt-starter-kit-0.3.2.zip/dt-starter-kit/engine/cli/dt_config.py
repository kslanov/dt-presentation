"""dt config — один конфиг движка (CONFIG-1): ``show | check | set | init``.

``show`` - действующие значения по реестру настроек (секреты - хвост 4 символа; источник:
``.env`` | env процесса | дефолт; сначала заданные). ``check`` - неизвестные ключи ``.env`` (с
подсказкой ближайшего имени), устаревшие, пустые обязательные, несовместимости (``DT_MODE=server``
без Tailscale), права ``.env``/``.secrets``, ``.env`` вне git; код выхода 1 при замечаниях.
``set KEY VALUE`` - правка ОДНОГО ключа через ``core.config.env_file`` (бэкап ``.env.bak-<ts>``,
права 600, повтор - без записи). ``init`` - создать ``.env`` из ``ops/env.template`` (вторая
машина, сервер).

``--env-file PATH`` работает на другом файле (копия боевого ``.env`` для проб); без него -
``engine/.env``. Демон читает ``.env`` при старте: после ``set`` - ``launchctl kickstart -k``.

Usage:
    uv run python cli/dt.py config show [--all] [--set-only]
    uv run python cli/dt.py config check
    uv run python cli/dt.py config set DT_RERANK_POOL 20
    printf %s "$KEY" | uv run python cli/dt.py config set TIMETTA_API_TOKEN --stdin
    uv run python cli/dt.py config init [--force]
"""

from __future__ import annotations

import argparse
import difflib
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config import ENGINE_ROOT, engine_env_path
from core.config import env_file as ef
from core.config.env_template import TEMPLATE_REL, render
from core.config.knobs import KNOBS, by_name, mask
from core.config.report import _bad_value, check, show_rows
from core.web_tokens import secrets_dir

_RESTART_NOTE = ("демон читает .env при старте: `launchctl kickstart -k "
                 "gui/$(id -u)/com.dt.server` (другие процессы - при следующем запуске)")


def _env_path(args: argparse.Namespace) -> Path:
    return Path(args.env_file) if args.env_file else engine_env_path()


def _show(args: argparse.Namespace) -> int:
    path = _env_path(args)
    rows = show_rows(path, include_all=args.all)
    if args.set_only:
        rows = [r for r in rows if r.source != "дефолт"]
    width = max((len(r.name) for r in rows), default=10)
    print(f"# {path} · {len(rows)} из {len(KNOBS)} записей реестра"
          + ("" if args.all else " (без test/deprecated; --all - все)"))
    for r in rows:
        mark = "; legacy: источник - профиль владельца" if r.legacy else ""
        print(f"{r.name:<{width}} = {r.value}  [{r.source}; {r.scope}; {r.type}{mark}]")
    return 0


def _check(args: argparse.Namespace) -> int:
    path = _env_path(args)
    res = check(path, secrets_dir=secrets_dir())
    print("\n".join(res.render()))
    return 0 if res.status == "ok" else 1


def _set(args: argparse.Namespace) -> int:
    key = args.key
    knob = by_name(key)
    if knob is None and not args.force:
        near = difflib.get_close_matches(key, [k.name for k in KNOBS], n=1, cutoff=0.8)
        hint = f" Возможно {near[0]}." if near else ""
        print(f"неизвестный ключ {key}.{hint} Не в реестре (core/config/knobs.py); "
              "если это осознанно - --force", file=sys.stderr)
        return 2
    if knob is not None and knob.scope in ("deprecated", "test") and not args.force:
        print(f"{key}: {knob.scope} - {knob.doc}. Если это осознанно - --force", file=sys.stderr)
        return 2
    if knob is not None and knob.is_secret:
        if not args.stdin:
            print(f"{key} - секрет: значение в argv остаётся в истории shell. "
                  f"Передай через stdin: printf %s \"$VALUE\" | dt config set {key} --stdin",
                  file=sys.stderr)
            return 2
        value = sys.stdin.read().rstrip("\n")
    elif args.stdin:
        value = sys.stdin.read().rstrip("\n")
    elif args.value is None:
        print("нужно значение: dt config set KEY VALUE (или --stdin)", file=sys.stderr)
        return 2
    else:
        value = args.value
    if knob is not None and not knob.is_secret and _bad_value(knob, value) and not args.force:
        print(f"{key}: значение не подходит типу {knob.type}. Если это осознанно - --force",
              file=sys.stderr)
        return 2
    path = _env_path(args)
    try:
        edit = ef.set_key(path, key, value)
    except ef.EnvFileError as exc:
        print(f"{key}: {exc}", file=sys.stderr)
        return 2
    shown = mask(value) if (knob is not None and knob.is_secret) else value
    if not edit.changed:
        print(f"{key} = {shown}: без изменений ({path})")
        return 0
    bak = f" · бэкап {edit.backup.name}" if edit.backup else ""
    print(f"{key} = {shown}: {edit.action} в {path}{bak}")
    print(_RESTART_NOTE)
    return 0


def _init(args: argparse.Namespace) -> int:
    path = _env_path(args)
    template = ENGINE_ROOT / TEMPLATE_REL
    text = template.read_text(encoding="utf-8") if template.is_file() else render()
    try:
        edit = ef.write_new(path, text, overwrite=args.force)
    except ef.EnvFileError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    bak = f" · бэкап прежнего {edit.backup.name}" if edit.backup else ""
    print(f"{path}: {edit.action} из {TEMPLATE_REL} (права 600){bak}")
    print("дальше: заполнить обязательные ключи (`dt config set KEY VALUE`), `dt config check`")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt config", description=__doc__.split("\n")[0])
    parser.add_argument("--env-file", default=None, help="другой .env (по умолчанию engine/.env)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sh = sub.add_parser("show", help="действующие значения по реестру")
    sh.add_argument("--all", action="store_true", help="включая test/deprecated")
    sh.add_argument("--set-only", action="store_true", help="только заданные явно (не дефолты)")
    sh.set_defaults(func=_show)

    ck = sub.add_parser("check", help="проверка .env по реестру (код 1 при замечаниях)")
    ck.set_defaults(func=_check)

    st = sub.add_parser("set", help="выставить один ключ (бэкап, права 600)")
    st.add_argument("key")
    st.add_argument("value", nargs="?", default=None)
    st.add_argument("--stdin", action="store_true",
                    help="значение из stdin (обязательно для секретов)")
    st.add_argument("--force", action="store_true", help="неизвестный/устаревший ключ, чужой тип")
    st.set_defaults(func=_set)

    it = sub.add_parser("init", help="создать .env из ops/env.template")
    it.add_argument("--force", action="store_true", help="перезаписать существующий (с бэкапом)")
    it.set_defaults(func=_init)

    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
