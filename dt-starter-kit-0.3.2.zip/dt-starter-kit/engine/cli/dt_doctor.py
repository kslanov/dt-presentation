"""dt-doctor — диагностика окружения DT (UX-1, interface layer).

Один прогон проверок из :mod:`core.diagnostics`: секреты (наличие, не значение),
пути, индекс, зеркало, модель, Outlook-мост — с человекочитаемыми подсказками.
Не лечит и не чинит: только показывает, что не так и куда смотреть.

CLI depends on core, never the reverse (architecture §8).

Usage:
    uv run python cli/dt_doctor.py
    uv run python cli/dt_doctor.py --quiet   # только проблемы (warn/fail)
Exit code: 1, если есть хотя бы один ``fail`` (для скриптов/CI), иначе 0.

EVAL-3: ``--step`` — режим ночного шага ``doctor`` цепочки ``dt_sync index`` (после ``eval``):
один прогон проверок, который (как любой прогон) пишет снимок ``.derived/doctor_last.json``
(warn/fail + счётчики), вывод — сводка и имена warn/fail, код ВСЕГДА 0 (диагностика не роняет
цепочку); warn/fail ночью — WARNING в логе dt-sync. К утру снимок свежий — от него горит
индикатор здоровья в шапке пульта.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.diagnostics import run_diagnostics, write_doctor_cache

_MARK = {"ok": "[ ok ]", "warn": "[warn]", "fail": "[FAIL]"}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Диагностика окружения Digital Twin.")
    parser.add_argument("--quiet", action="store_true", help="показать только warn/fail")
    parser.add_argument("--step", action="store_true",
                        help="ночной шаг dt_sync index: сводка, код всегда 0, снимок пишется")
    args = parser.parse_args(argv)

    load_env()
    started = time.perf_counter()
    checks = run_diagnostics()
    # PULT-SURFACE-2 п.1: тот же прогон кладёт полный снимок ``status/cache/doctor.json`` —
    # его читает ``doctor()`` из пульта, не пересчитывая. Живой расчёт и вывод — как прежде.
    write_doctor_cache(checks, elapsed_ms=int((time.perf_counter() - started) * 1000))
    if args.step:
        return _step_summary(checks)
    fails = sum(1 for c in checks if c.status == "fail")
    warns = sum(1 for c in checks if c.status == "warn")

    print("DT doctor — окружение\n")
    for c in checks:
        if args.quiet and c.status == "ok":
            continue
        line = f"{_MARK.get(c.status, '[????]')} {c.name}: {c.detail}"
        print(line)
        if c.hint and c.status != "ok":
            print(f"        → {c.hint}")

    print()
    if fails:
        print(f"Итог: {fails} критичных, {warns} предупреждений. "
              "Почини FAIL — без этого ключевые функции не работают.")
    elif warns:
        print(f"Итог: критичных нет, {warns} предупреждений (деградации; см. подсказки).")
    else:
        print("Итог: всё в порядке.")
    return 1 if fails else 0


def _step_summary(checks: list) -> int:
    """Итог ночного шага: счётчики + имена warn/fail; код 0 (снимок уже записан прогоном)."""
    log = logging.getLogger("dt_sync.doctor")
    fails = [c for c in checks if c.status == "fail"]
    warns = [c for c in checks if c.status == "warn"]
    oks = len(checks) - len(fails) - len(warns)
    print(f"doctor: ✓ {oks} · ⚠ {len(warns)} · ✗ {len(fails)}; снимок doctor_last.json записан")
    for c in fails + warns:
        line = f"doctor: [{c.status}] {c.name}: {c.detail}"
        print(line[:300])
    if fails:
        log.warning("doctor: FAIL — %s", "; ".join(c.name for c in fails))
    if warns:
        log.warning("doctor: warn — %s", "; ".join(c.name for c in warns[:8]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
