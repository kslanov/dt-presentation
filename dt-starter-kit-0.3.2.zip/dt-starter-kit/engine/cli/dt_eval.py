"""dt-eval — прогон золотого набора запросов к выдаче DT с таблицей (EVAL-1, WAVE1-MEASURE).

Берёт канон ``vault/_system/eval/golden-queries.yaml``, прогоняет запросы на боевом vault и
индексе и печатает таблицу «запрос → ожидание → факт» + метрики (recall@5, MRR, hub@3, конверт,
хвост, корпус, факты, чтение). Результат дописывается в ``.derived/eval/history.jsonl``
(первый прогон — БАЗОВАЯ ЛИНИЯ; красный — только падение recall@5/hub@3 больше 0.1 к прошлому).
Запросы с ``источник: гипотеза`` прогоняются и видны, но в метрику не входят.

Read-only к vault/индексу: БД фактов, журнал аудита и журнал метрик уводятся в tmp на время
прогона (``get_facts`` апсертит поднятый источник, ``retrieve`` пишет событие) — боевые сторы
линейка не трогает; пишется только история прогонов.

Usage:
    uv run --extra parsers --extra operational python cli/dt_eval.py
    uv run ... python cli/dt_eval.py --no-record      # без записи в историю
    uv run ... python cli/dt_eval.py --only q01,q04   # подмножество (в историю не пишется)
    uv run ... python cli/dt_eval.py --json
RETR-RERANK-1 п.6 (абляция выдачи; ни один из этих прогонов в историю не пишется и с прошлым
не сравнивается — другая конфигурация выдачи несравнима с линией):
    uv run ... python cli/dt_eval.py --rerank on --semantic-always off     # вариант (б)
    uv run ... python cli/dt_eval.py --rerank on                           # (в): семантика
                                                                           # следует за реранкером
    uv run ... python cli/dt_eval.py --rerank off --semantic-always on     # вариант (г)
    uv run ... python cli/dt_eval.py --ablation   # четыре варианта (а/б/в/г) подряд: таблица
MODEL-1 (закрытие): золотые задачи генерации по хостам - таблица «задача × хост» по 07-outputs:
    uv run ... python cli/dt_eval.py --generation [--host kimi] [--since 2026-10-29] [--json]
Exit code: 1 — красный прогон (регрессия) или набор не прочитан; иначе 0.

EVAL-3: ``--step`` — режим ночного шага ``eval`` цепочки ``dt_sync index`` (после ``reindex_inc``,
под тем же index-локом): прогон + запись в историю как обычно, вывод — сводка и красные группы в
несколько строк, а код ВСЕГДА 0 — качество выдачи не имеет права ронять цепочку index; красный,
сбой набора/прогона и «упали все запросы» уходят в WARNING лога dt-sync. Недействительный прогон
(упали все запросы — инфраструктура, не качество) в историю не пишется: иначе завтрашний
сравнительный прогон принял бы его за базу и показал «рост» на пустом месте.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import logging
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

if TYPE_CHECKING:
    from core.eval import EvalReport

_ENGINE_DIR = Path(__file__).resolve().parents[1]


def _load_tools() -> object:
    """Боевые инструменты — тот же ``mcp-server/server.py``, что видит агент."""
    spec = importlib.util.spec_from_file_location(
        "dt_eval_server", _ENGINE_DIR / "mcp-server" / "server.py"
    )
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load mcp-server/server.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-eval", description="Золотой набор запросов: таблица и метрики качества выдачи."
    )
    parser.add_argument("--golden", help="Путь к golden-queries.yaml (по умолчанию — из vault).")
    parser.add_argument(
        "--only", help="id запросов через запятую (подмножество; без записи в историю)."
    )
    parser.add_argument(
        "--no-record", action="store_true",
        help="Не писать прогон в историю (и без флага пишется только с ветки main "
        "или при DT_EVAL_RECORD=1).",
    )
    parser.add_argument(
        "--rerank", choices=("on", "off"),
        help="Реранкер (cross-encoder) вкл/выкл на время прогона (env DT_RERANK). Прогон с "
        "флагом — абляция: не пишется в историю и не сравнивается с прошлым.",
    )
    parser.add_argument(
        "--semantic-always", choices=("on", "off"), dest="semantic_always",
        help="Семантическая ступень всегда (on) или лестница по порогу (off; env "
        "DT_FIND_SEMANTIC_ALWAYS). Без флага — следует за реранкером.",
    )
    parser.add_argument(
        "--ablation", action="store_true",
        help="Четыре варианта подряд: (а) база, (б) реранкер, (в) реранкер + семантика всегда, "
        "(г) только семантика всегда — сводная таблица recall@5/MRR/hub@3/латентность и ранг цели.",
    )
    parser.add_argument(
        "--generation", action="store_true",
        help="MODEL-1: золотые задачи ГЕНЕРАЦИИ по хостам (vault/_system/eval/golden-generation."
        "yaml): таблица «задача × хост» по выходам 07-outputs, без LLM и сети; точка на хост — в "
        ".derived/eval/generation.jsonl (--no-record отключает).",
    )
    parser.add_argument("--host", help="С --generation: подстрока имени хоста (kimi, claude…).")
    parser.add_argument("--since", help="С --generation: только выходы с даты YYYY-MM-DD.")
    parser.add_argument("--json", action="store_true", help="Машинный итог вместо таблицы.")
    parser.add_argument(
        "--step", action="store_true",
        help="Режим ночного шага dt_sync index: сводка вместо таблицы, код всегда 0, "
        "красное/сбой — WARNING в логе (качество не роняет цепочку).",
    )
    args = parser.parse_args(argv)

    load_env()
    if args.generation:
        # Без песочницы метрик: оценщик read-only, а журнал метрик ему нужен боевой (след задач
        # «журнал»); пишется только история generation.jsonl.
        return _run_generation(args)
    if args.host or args.since:
        parser.error("--host/--since - только вместе с --generation")
    sandbox = lambda box: {  # noqa: E731
        # Песочница ДО загрузки инструментов: пишущие побочки (facts-БД, аудит, метрики) — в tmp.
        # DT_EVAL_QUERY_LOG=0 (EVAL-2): прогон линейки — не употребление, в журнал запросов нельзя.
        # DT_EVENTS_PATH (TEST-SANDBOX-1): журнал метрик — через env, а не подменой атрибута
        # модуля (так переопределение видно и подпроцессам, и всем читателям пути).
        "DT_DB_PATH": str(Path(box) / "dt.db"), "DT_LOGS_PATH": str(Path(box) / "logs"),
        "DT_EVENTS_PATH": str(Path(box) / "events.jsonl"), "DT_EVAL_QUERY_LOG": "0",
        **_variant_env(args),
    }
    with tempfile.TemporaryDirectory(prefix="dt-eval-") as box, mock.patch.dict(
        os.environ, sandbox(box)
    ):
        if args.ablation:
            return _run_ablation(args)
        return _run_step(args, Path(box)) if args.step else _run(args, Path(box))


def _run_generation(args: argparse.Namespace) -> int:
    """MODEL-1 п.A: таблица «задача × хост» по выходам; код 1 - канон не прочитан."""
    from core.eval_generation import (
        GenerationGoldenError,
        append_generation_history,
        evaluate_generation,
        format_generation_table,
        generation_json,
    )

    if args.since and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", args.since):
        print(f"ОШИБКА: --since {args.since!r} - нужно YYYY-MM-DD", file=sys.stderr)
        return 1
    try:
        report = evaluate_generation(
            golden=Path(args.golden) if args.golden else None, host=args.host, since=args.since
        )
    except GenerationGoldenError as exc:
        print(f"ОШИБКА [{exc.code}]: {exc}", file=sys.stderr)
        return 1
    recorded: tuple[Path, int] | None = None
    if not args.no_record:
        try:
            recorded = append_generation_history(report)
        except OSError as exc:
            print(f"ОШИБКА: история не записана: {exc}", file=sys.stderr)
    if args.json:
        data = generation_json(report)
        data["recorded"] = {"path": str(recorded[0]), "points": recorded[1]} if recorded else None
        print(json.dumps(data, ensure_ascii=False, indent=1))
    else:
        print(format_generation_table(report))
        if recorded and recorded[1]:
            print(f"\nИстория: {recorded[0]} (+{recorded[1]})")
        elif args.no_record:
            print("\n(--no-record — в историю не записано)")
    return 0


def _variant_env(args: argparse.Namespace) -> dict[str, str]:
    """Флаги абляции → env конфигурации выдачи (читается ``core.retrieval.rerank``)."""
    env: dict[str, str] = {}
    if args.rerank:
        env["DT_RERANK"] = "1" if args.rerank == "on" else "0"
    if args.semantic_always:
        env["DT_FIND_SEMANTIC_ALWAYS"] = "1" if args.semantic_always == "on" else "0"
    return env


def _warm_reranker() -> tuple[float | None, str, str]:
    """Загрузить реранкер ДО замера (первая загрузка ~7 с не должна лечь в p95 варианта).

    ``(секунд загрузки | None, устройство, причина недоступности)``."""
    from core.retrieval import rerank as rr

    try:
        rr.rerank("прогрев", [rr.RerankCand("w", "прогрев")])
        inst = rr.get_reranker()
        return inst.load_seconds, inst.device, ""
    except Exception as exc:  # noqa: BLE001 — недоступность видна в таблице как ошибка варианта
        return None, "", f"{type(exc).__name__}: {str(exc)[:160]}"


def _run_ablation(args: argparse.Namespace) -> int:
    """Четыре варианта выдачи подряд на одном наборе (без истории и сравнения с прошлым)."""
    from core.eval import (
        VARIANTS,
        GoldenError,
        ablation_table,
        golden_path,
        load_golden,
        run_eval,
    )

    try:
        queries = load_golden(Path(args.golden) if args.golden else golden_path())
    except GoldenError as exc:
        print(f"ОШИБКА: {exc}", file=sys.stderr)
        return 1
    if args.only:
        wanted = {x.strip() for x in args.only.split(",") if x.strip()}
        queries = [q for q in queries if q.id in wanted]
    tools = _load_tools()
    _warm_frontmatter_cache()
    load_s, device, why = _warm_reranker()
    print("реранкер: " + (f"загружен за {load_s} с на {device}" if not why
                          else f"НЕДОСТУПЕН — {why}"))
    runs = []
    for label, name, rerank_on, sem_always in VARIANTS:
        env = {"DT_RERANK": "1" if rerank_on else "0",
               "DT_FIND_SEMANTIC_ALWAYS": "1" if sem_always else "0"}
        with mock.patch.dict(os.environ, env):
            print(f"вариант ({label}) {name} …", flush=True)
            report = run_eval(
                queries, tools, previous=None,
                progress=None if args.json else lambda line: print(f"  … {line}", flush=True),
            )
        runs.append((label, name, report))
    if args.json:
        from core.eval import history_record

        print(json.dumps({lab: history_record(rep) for lab, _, rep in runs},
                         ensure_ascii=False, indent=1))
    else:
        print("\n" + ablation_table(runs))
    return 0


def _warm_frontmatter_cache() -> None:
    """Прогреть кэш frontmatter ДО прогона (EVAL-3 п.1).

    Первая сборка кэша (нет файла / другой vault / версия) возвращает в ответ поиска конверт
    ``store_unavailable`` — и метрика «конверт» красила бы q01 «ложной тревогой» (так было
    24.10). Обход один раз здесь: сами запросы набора идут уже по готовому кэшу.
    Best-effort: сбой прогрева — не повод пропустить прогон."""
    try:
        from core.config import default_vault_path
        from core.retrieval.fm_cache import refresh

        refresh(default_vault_path())
    except Exception:  # noqa: BLE001, S110 — прогрев опционален
        pass


def _run_step(args: argparse.Namespace, box: Path) -> int:
    """Ночной шаг ``eval``: всегда 0; красное/сбой — WARNING, запись в историю — как у dt_eval."""
    from core.eval import (
        append_history,
        golden_path,
        last_runs,
        load_golden,
        record_policy,
        red_text,
        run_eval,
        summary_line,
    )

    log = logging.getLogger("dt_sync.eval")
    try:
        queries = load_golden(golden_path())
        _warm_frontmatter_cache()
        previous = (last_runs(1) or [None])[-1]
        tools = _load_tools()
        report = run_eval(queries, tools, previous=previous)
    except Exception as exc:  # noqa: BLE001 — шаг не роняет цепочку: причина — в лог и вывод
        msg = f"eval: прогон не состоялся — {type(exc).__name__}: {str(exc)[:200]}"
        log.warning(msg)
        print(msg)
        return 0
    if report.all_failed:
        msg = ("eval: прогон недействителен — упали ВСЕ запросы (индекс/модель недоступны: "
               f"{report.results[0].errors[:1]}); в историю не записан")
        log.warning(msg)
        print(msg)
        return 0
    record, why = record_policy()
    if not record:
        print(f"eval: {why}")
        log.info("eval: %s", why)
    try:
        recorded = append_history(report) if record else None
    except OSError as exc:
        msg = f"eval: история не записана — {exc}"
        log.warning(msg)
        print(msg)
        return 0
    print(f"eval: {len(report.results)} запросов, {report.duration_s:.0f} с; "
          + (f"история {recorded.name}" if recorded else "история не записана"))
    _refresh_gold_candidates(tools, log)
    print("eval: всего: " + summary_line(report))
    for group_line in _group_lines(report):
        print("eval: " + group_line)
    if report.errors:
        log.warning("eval: %d запрос(ов) упали с ошибкой вызова", report.errors)
    if report.stale_ids:
        log.warning("eval: stale %s — ожидаемая заметка перегенерирована или удалена; "
                    "поправь id в golden-queries.yaml", ", ".join(report.stale_ids))
    if report.red:
        msg = "eval: КРАСНЫЙ — падение > 0.1 к прошлому прогону: " + red_text(report.red)
        log.warning(msg)
        print(msg)
    return 0


def _refresh_gold_candidates(tools: object, log: logging.Logger) -> None:
    """PULT-SURFACE-2 п.1: ночью пересчитать очередь кандидатов в золотой набор (вид ``gold``).

    ``pult_cards`` на чтении gold не считает (реранкер - секунды внутри read-вызова): расчет живет
    здесь, где индекс и модель уже тёплые. Best-effort: сбой - WARNING, цепочка идет дальше."""
    try:
        from core.eval_candidates import ensure_fresh

        probe = getattr(tools, "_golden_probe", None)
        _queue, error = ensure_fresh(probe=probe, force=True)
        if error:
            log.warning("eval: кандидаты в золотой набор не пересчитаны - %s", error)
        else:
            print("eval: кандидаты в золотой набор пересчитаны")
    except Exception as exc:  # noqa: BLE001 - расчет кандидатов не роняет ночной шаг
        log.warning("eval: кандидаты в золотой набор не пересчитаны - %s: %s",
                    type(exc).__name__, str(exc)[:200])


def _group_lines(report: EvalReport) -> list[str]:
    from core.eval import GROUPS, group_line

    return [group_line(report, g) for g in GROUPS]


def _run(args: argparse.Namespace, box: Path) -> int:
    from core.eval import (
        GoldenError,
        append_history,
        format_table,
        golden_path,
        history_record,
        last_runs,
        load_golden,
        record_policy,
        run_eval,
    )

    try:
        queries = load_golden(Path(args.golden) if args.golden else golden_path())
    except GoldenError as exc:
        print(f"ОШИБКА: {exc}", file=sys.stderr)
        return 1
    ablation_flags = bool(args.rerank or args.semantic_always)  # другая конфигурация — не линия
    subset = bool(args.only) or ablation_flags
    if args.only:
        wanted = {x.strip() for x in args.only.split(",") if x.strip()}
        queries = [q for q in queries if q.id in wanted]
        if not queries:
            print(f"нет запросов с id {sorted(wanted)}", file=sys.stderr)
            return 1

    previous = (last_runs(1) or [None])[-1]
    _warm_frontmatter_cache()  # EVAL-3: первая сборка кэша не должна красить q01 конвертом
    report = run_eval(
        queries, _load_tools(), previous=None if subset else previous,
        progress=None if args.json else lambda line: print(f"  … {line}", flush=True),
    )

    recorded = None
    not_recorded = ""
    if not (args.no_record or subset):
        record, why = record_policy()
        if record:
            recorded = append_history(report)
        else:
            not_recorded = why
    if args.json:
        print(json.dumps(history_record(report), ensure_ascii=False, indent=1))
    else:
        print("\n" + format_table(report))
        if recorded:
            print(f"\nИстория: {recorded}")
        elif subset:
            why_not = "конфигурация выдачи изменена флагами" if ablation_flags else "подмножество"
            print(f"\n({why_not} — в историю не записано)")
        elif not_recorded:
            print(f"\n({not_recorded})")
    return 1 if report.red or report.all_failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
