"""dt-facts — extract / query typed facts from source files (FACT-1, PART-4).

The CLI twin of the MCP ``get_facts`` tool (for smoke tests / cron). With
``--note`` or a ``path`` it lifts the source (SRC-1), extracts facts
deterministically, upserts them, and prints them; with only filters it reads the
stored facts. Human summary by default, full JSON with ``--json``. No LLM, no
network.

Usage::

    uv run python cli/dt_facts.py --note deal-acme-2026 --kind money
    uv run python cli/dt_facts.py /abs/path/to/Расчёт.xlsx --json
    uv run python cli/dt_facts.py --entity client-acme --min-confidence 0.6
    uv run python cli/dt_facts.py --reextract --dry-run       # какие источники устарели (FACT-2)
    uv run python cli/dt_facts.py --reextract --limit 1       # канарейка
    uv run python cli/dt_facts.py --reextract                 # переизвлечь все устаревшие

Временная плоскость (FACTS-BITEMPORAL-1)::

    uv run python cli/dt.py facts versions /abs/path/Прайс_10.2026.xlsx      # цепочка версий и
    вытеснений
    uv run python cli/dt.py facts backfill --dry-run   # сухой отчет: атрибуция к хабу, черновики,
    цепочки
    uv run python cli/dt.py facts backfill             # применить (идемпотентно)

``versions`` читает стор только на чтение: версии семейства по датам документа, чем датированы,
что вытеснено и «было → стало» по ярлыкам. ``backfill`` сначала строит ПЛАН целиком в памяти
(``--dry-run`` на этом останавливается и ничего не пишет), потом применяет его одной транзакцией;
повторный прогон ничего не меняет. Перед первым прогоном на боевом сторе - ``dt backup``.

``--reextract`` (FACT-2 п.7): по каждому источнику стора, чьи факты извлечены прежней версией
экстрактора, находит файл (по пути, реестру content-hash или хвосту пути под ingest-корнем),
поднимает его, извлекает заново и ЗАМЕНЯЕТ факты источника (``source_path`` - живой путь).
``--dry-run`` ничего не пишет: ни стор, ни кеш подъема (только отчет: сколько фактов было/будет,
распределение confidence). Источник не найден или его байты изменились с прошлой экстракции -
пропуск с причиной, чужие факты не подменяются.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.facts import ensure_facts, get_facts
from core.sources import lift_from


def main(argv: list[str] | None = None) -> int:
    raw = list(sys.argv[1:] if argv is None else argv)
    if raw and raw[0] == "versions":
        return _versions(raw[1:])
    if raw and raw[0] == "backfill":
        return _backfill(raw[1:])
    parser = argparse.ArgumentParser(
        prog="dt-facts", description="Extract/query typed facts (FACT-1)."
    )
    parser.add_argument(
        "path", nargs="?", default=None, help="Source file (absolute or vault-relative)."
    )
    parser.add_argument("--note", help="Resolve source from a note id (source_path).")
    parser.add_argument("--entity", help="Filter by entity_ref (client/deal hub).")
    parser.add_argument("--kind", help="Filter by kind (money|quantity|date|…).")
    parser.add_argument("--min-confidence", type=float, default=0.0)
    parser.add_argument("--json", action="store_true", help="Print full JSON.")
    parser.add_argument("--reextract", action="store_true",
                        help="Переизвлечь факты источников стора со старой версией экстрактора.")
    parser.add_argument("--dry-run", action="store_true",
                        help="С --reextract: только отчет, ничего не писать.")
    parser.add_argument("--limit", type=int, default=None,
                        help="С --reextract: не больше N источников (канарейка).")
    args = parser.parse_args(raw)

    load_env()

    if args.reextract:
        return _reextract(args)

    content_hash: str | None = None
    if args.note or args.path:
        lifted = lift_from(note_id=args.note, path=args.path)
        if lifted.status != "ok":
            print(f"source unavailable: {lifted.reason}")
            return 1
        content_hash = lifted.content_hash
        ensure_facts(lifted, entity_ref=args.entity or args.note)  # + гейт версии (FACT-2)

    facts = get_facts(
        entity_ref=args.entity,
        kind=args.kind,
        source_content_hash=content_hash,
        min_confidence=args.min_confidence,
    )

    if args.json:
        print(json.dumps([f.to_dict() for f in facts], ensure_ascii=False, indent=2))
        return 0

    if not facts:
        print("(no facts)")
        return 0
    for f in facts:
        cur = f" {f.currency}" if f.currency else ""
        vat = f" НДС:{f.vat_flag}" if f.vat_flag else ""
        stale = " ⚠stale" if f.stale_hint else ""
        when = f" с {f.valid_from}" if f.valid_from else ""
        prov = " ⚠черновик" if f.provisional else ""
        print(
            f"[{f.kind}] {f.label or '(без ярлыка)'} = {f.value_raw}{cur}{vat} "
            f"@ {f.locator} conf={f.confidence:.2f}{stale}{when}{prov}"
        )
    return 0


def _resolve_source(arg: str) -> str:
    """Путь источника: файл как есть; иначе заметка (``source_path`` карточки) → путь файла."""
    from pathlib import Path

    if Path(arg).is_file() or "/" in arg or Path(arg).suffix:
        return arg
    lifted = lift_from(note_id=arg, persist=False)
    return lifted.path if lifted.status == "ok" else arg


def _versions(argv: list[str]) -> int:
    """``versions <источник> [--json]``: цепочка версий семейства по сохраненным фактам (чтение)."""
    from core.facts.versions import version_chain

    parser = argparse.ArgumentParser(prog="dt facts versions")
    parser.add_argument("source", help="Файл-источник (путь) или id заметки.")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--changes", type=int, default=8,
                        help="Сколько строк «было → стало» показать (по умолчанию 8).")
    args = parser.parse_args(argv)
    load_env()
    chain = version_chain(_resolve_source(args.source))
    if args.json:
        print(json.dumps(chain, ensure_ascii=False, indent=2))
        return 0 if chain["status"] == "ok" else 1
    if chain["status"] == "unmigrated":
        print("схема стора старше v4: откройте БД (любой get_facts / dt doctor) и повторите")
        return 1
    if chain["status"] == "empty":
        print("(фактов этого семейства в сторе нет - сначала get_facts по источнику)")
        return 1
    print(f"семейство вокруг {chain['source']}: версий в сторе {len(chain['versions'])}")
    for v in chain["versions"]:
        marks = [m for m, on in (("черновик", v["provisional"]), ("архив", v["archived"])) if on]
        span = f"{v['valid_from'] or '?'} → {v['valid_to'] or 'действует'}"
        basis = {"name": "по имени", "mtime": "по mtime", "": "без даты"}.get(
            v["date_basis"] or "", "")
        print(f"  · {span}  [{basis}]  узнали {str(v['known_at'] or '?')[:10]}  "
              f"фактов {v['facts']}, вытеснено {v['superseded']}"
              f"{'  ⚠' + '/'.join(marks) if marks else ''}  {v['path'].rsplit('/', 1)[-1]}")
    changed = [c for c in chain["changes"] if c["changed"]]
    print(f"вытеснений {len(chain['changes'])}, из них со сменой значения {len(changed)}")
    for c in changed[: max(0, args.changes)]:
        print(f"  {c['label']}: {c['was']} ({c['valid_from']}) → {c['now']} ({c['valid_to']})")
    return 0


def _backfill(argv: list[str]) -> int:
    """``backfill [--dry-run]``: атрибуция к хабу, черновики, fact_key, цепочки версий по стору."""
    from core.facts.backfill import apply_backfill, plan_backfill

    parser = argparse.ArgumentParser(prog="dt facts backfill")
    parser.add_argument("--dry-run", action="store_true", help="Только отчет, ничего не писать.")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    load_env()
    plan = plan_backfill()
    if plan.unmigrated:
        print("схема стора старше v4: откройте БД (любой get_facts / dt doctor) и повторите")
        return 1
    mode = "DRY-RUN" if args.dry_run else "APPLY"
    if args.json:
        print(json.dumps({"mode": mode, **plan.to_dict(), "sources": [
            {"path": s.path, "facts": s.n, "entity_old": s.entity_old, "entity_new": s.entity_new,
             "why": s.entity_reason, "draft": s.draft, "family_members": s.members}
            for s in plan.sources]}, ensure_ascii=False, indent=2))
    else:
        print(f"[backfill {mode}] фактов {plan.total}, источников {len(plan.sources)}")
        dating = ", ".join(f"{({'name': 'по имени', 'mtime': 'по mtime', '': 'без даты'}[k])} {v}"
                           for k, v in sorted(plan.dating.items()))
        print(f"  датировано: {dating}")
        for s in plan.sources:
            ent = (f"{s.entity_old} → {s.entity_new}" if s.entity_new
                   else f"{s.entity_old} (прежнее)")
            name = s.path.rsplit("/", 1)[-1]
            print(f"  · {name}: {s.n} фактов; entity_ref {ent} [{s.entity_reason}]"
                  f"; в семействе {s.members}{'; ЧЕРНОВИК' if s.draft else ''}")
        print(f"  entity_ref сменится у {len(plan.entity_changes)} фактов; "
              f"provisional {plan.provisional_facts}; "
              f"вытеснено {plan.superseded} (семейств с цепочкой {plan.families}); "
              f"уйдет из дефолтной выдачи {plan.hidden_from_default} "
              f"({plan.visible_before} → {plan.visible_after})")
    if args.dry_run:
        return 0
    done = apply_backfill(plan)
    print(f"[backfill APPLY] записано: entity_ref {done['entity']}, fact_key {done['keys']}, "
          f"provisional {done['provisional']}, связей цепочки {done['links']}")
    return 0


def _locate(source_path: str, content_hash: str) -> tuple[str | None, str]:
    """Живой файл источника: путь как есть → реестр content-hash → хвост пути под ingest-корнем.

    ``(путь | None, причина)``. Найденный файл обязан совпасть по байтам (content-hash) с тем,
    что извлекалось: иначе это уже другая версия документа - факты старой не подменяем.
    """
    from pathlib import Path

    from core.sources import cache
    from core.sources.resolver import resolve_source_path

    candidates: list[str] = []
    if Path(source_path).is_file():
        candidates.append(source_path)
    entry = cache.load_index().get(content_hash)
    if isinstance(entry, dict):
        candidates += [p for p in entry.get("paths", []) if isinstance(p, str)]
    live = resolve_source_path(source_path.lstrip("/"))
    if live is not None:
        candidates.append(str(live))
    seen: set[str] = set()
    changed = False
    for cand in candidates:
        if cand in seen or not Path(cand).is_file():
            continue
        seen.add(cand)
        if cache.file_content_hash(Path(cand)) == content_hash:
            return cand, ""
        changed = True
    return None, ("файл найден, но его байты изменились с прошлой экстракции" if changed
                  else "файл не найден (ни путь, ни реестр, ни ingest-корень)")


def _confidence_histogram(facts) -> dict[str, int]:
    out: dict[str, int] = {}
    for f in facts:
        key = f"{f.confidence:.2f}"
        out[key] = out.get(key, 0) + 1
    return dict(sorted(out.items()))


def _reextract(args) -> int:
    """``--reextract``: источники стора со старой версией → переизвлечение (или сухой отчет)."""
    from core.facts import extract_facts
    from core.facts.materialize import needs_reextract, write_source_facts
    from core.facts.schema import EXTRACTOR_VERSION
    from core.facts.store import source_versions
    from core.sources import resolve_ref
    from core.sources.resolver import lift

    todo = [s for s in source_versions() if needs_reextract(str(s["version"]))]
    total_sources = len(source_versions())
    if args.limit is not None:
        todo = todo[: max(0, args.limit)]
    mode = "DRY-RUN" if args.dry_run else "APPLY"
    print(f"[reextract {mode}] версия экстрактора {EXTRACTOR_VERSION}: источников со старой "
          f"версией {len(todo)} из {total_sources}")
    done = skipped = 0
    before_total = after_total = 0
    after_conf: dict[str, int] = {}
    for src in todo:
        path_s, why = _locate(str(src["source_path"]), str(src["source_content_hash"]))
        name = str(src["source_path"]).rsplit("/", 1)[-1]
        if path_s is None:
            skipped += 1
            print(f"  ! пропуск {name}: {why}")
            continue
        lifted = lift(resolve_ref(path=path_s), persist=not args.dry_run)
        if lifted.status != "ok":
            skipped += 1
            print(f"  ! пропуск {name}: источник не поднялся ({lifted.reason or lifted.status})")
            continue
        facts = extract_facts(lifted)
        for f in facts:  # entity_ref прежних строк сохраняем: привязка к хабу не теряется
            f.entity_ref = src["entity_ref"] or None  # type: ignore[assignment]
        before_total += int(src["n"])
        after_total += len(facts)
        for k, v in _confidence_histogram(facts).items():
            after_conf[k] = after_conf.get(k, 0) + v
        by_kind: dict[str, int] = {}
        for f in facts:
            by_kind[f.kind] = by_kind.get(f.kind, 0) + 1
        print(f"  · {name}: было {src['n']} → станет {len(facts)}  {by_kind}"
              f"  путь: {path_s}")
        if not args.dry_run:
            write_source_facts(lifted, facts, replace=True)
        done += 1
    verb = "к переизвлечению" if args.dry_run else "переизвлечено"
    print(f"[reextract {mode}] источников {verb} {done}, пропущено {skipped}; "
          f"фактов было {before_total} → {after_total}")
    print(f"  confidence после: {after_conf}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
