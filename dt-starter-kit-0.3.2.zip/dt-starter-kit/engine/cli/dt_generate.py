"""dt-generate — assemble a generation prompt + provenance (interface layer).

Path B: this prints the assembled prompt (which Cowork uses to generate the
artifact) and writes the provenance folder under ``07-outputs/``. It never calls
an LLM. After Cowork produces the text, ``--save-to`` writes it back to the same
folder as ``output.md``.

CLI depends on core, never the reverse (architecture §8 invariant).

Usage:
    # Parse a natural-language task, assemble + write provenance, print prompt:
    uv run python cli/dt_generate.py "Письмо клиенту Инитех: ..."

    # Or pass the use case + entity params explicitly (no parsing):
    uv run python cli/dt_generate.py --use-case client_correspondence \\
        --client client-initech --industry industry-oil-gas

    # Save Cowork-generated text into an existing output folder:
    uv run python cli/dt_generate.py --save-to <dir> --file letter.md
    cat letter.md | uv run python cli/dt_generate.py --save-to <dir>
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from core.generation import assemble_prompt
from core.output import create_output_dir, save_artifact, write_provenance
from core.parse_task import parse_task


def _build_params(args: argparse.Namespace) -> dict[str, str]:
    params: dict[str, str] = {}
    if args.client:
        params["client_id"] = args.client
    if args.industry:
        params["industry_id"] = args.industry
    if args.project:
        params["project_id"] = args.project
    if args.audience:
        params["audience"] = args.audience
    return params


def _save(args: argparse.Namespace) -> int:
    text = Path(args.file).read_text(encoding="utf-8") if args.file else sys.stdin.read()
    if not text.strip():
        print("error: no artifact text provided (use --file or pipe via stdin)", file=sys.stderr)
        return 2
    path = save_artifact(args.save_to, text)
    print(f"Saved artifact → {path}")
    return 0


def _generate(args: argparse.Namespace) -> int:
    explicit = _build_params(args)

    if args.use_case:
        # Explicit mode: skip NL parsing, use the given use case + params.
        use_case_id = args.use_case
        params = explicit
        interpretation = ", ".join(
            f"{k}={v}" for k, v in [("use_case", use_case_id), *params.items()]
        )
    else:
        if not args.task:
            print("error: provide a task text, or --use-case with params", file=sys.stderr)
            return 2
        parsed = parse_task(args.task, params=explicit or None)
        use_case_id = parsed.use_case_id
        params = parsed.params
        interpretation = parsed.interpretation

    task_text = args.task or f"({use_case_id} task)"

    print(f"Interpretation: {interpretation}")
    print("(confirm the entities above before using the generated text)\n")

    corpus = {"both": None, "vault": "vault", "legacy": "legacy"}[args.corpus]
    assembled = assemble_prompt(use_case_id, task_text, params, corpus=corpus)

    short_desc = args.short or (args.task or use_case_id)
    out_dir = create_output_dir(use_case_id, short_desc)
    write_provenance(out_dir, assembled)

    print("=" * 72)
    print("ASSEMBLED PROMPT (give this to Cowork to generate the artifact)")
    print("=" * 72)
    print(assembled.prompt)
    print("=" * 72)
    print(f"\nProvenance written to: {out_dir}")
    print("  prompt.md  sources.md  policy.yaml  meta.yaml")
    print(
        f"\nAfter generating in Cowork, save the text with:\n"
        f'  uv run python cli/dt_generate.py --save-to "{out_dir}" --file <text-file>'
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-generate",
        description="Assemble a generation prompt + provenance (Path B; no LLM call).",
    )
    parser.add_argument("task", nargs="?", help="Natural-language task text.")
    parser.add_argument("--use-case", help="Use case id (explicit mode; skips parsing).")
    parser.add_argument("--client", help="client_id override.")
    parser.add_argument("--industry", help="industry_id override.")
    parser.add_argument("--project", help="project_id override.")
    parser.add_argument("--audience", help="audience filter for exemplars (internal/external).")
    parser.add_argument("--short", help="Short slug for the output folder name.")
    parser.add_argument(
        "--corpus",
        choices=("both", "vault", "legacy"),
        default="both",
        help="Retrieval layer: both (default; legacy marked as raw source), "
        "vault (clean generation, curated only), or legacy.",
    )
    parser.add_argument(
        "--save-to", type=Path,
        help="Save mode: write artifact text (--file or stdin) as output.md in this folder.",
    )
    parser.add_argument("--file", help="In save mode, read artifact text from this file.")

    args = parser.parse_args(argv)

    if args.save_to:
        return _save(args)
    return _generate(args)


if __name__ == "__main__":
    raise SystemExit(main())
