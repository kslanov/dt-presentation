"""dt host-config - запись ``mcpServers.digital-twin`` для MCP-хоста из одного шаблона.

HOSTS-ATTACH-1: движок - сервис (демон ``com.dt.server`` на 8787), хост - клиент. Формы записи:

* ``claude`` (Desktop/Cowork) - мост ``cli/dt_shim.py`` (хост умеет только команду; full, rw);
* ``cursor`` / ``kimi`` - url ``/mcp/lean`` + ``Authorization: Bearer`` (rw: lean пишет выходы);
* ``cherry`` - то же + ``"type": "streamableHttp"`` (форма Settings → MCP → Import from JSON);
* ``url`` - голая запись ``{url, headers}`` для любого клиента.

``--server <dns|ip|url>`` (CONFIG-1) - то же, но на демон-сервер по Tailscale:
``http://<server>:8787/mcp/<профиль>`` (мост ``cli/dt_shim.py --url`` - для claude); токен - файл
``.secrets/web_token_rw`` клиента (``dt client join``). ``--verify`` на клиенте (``DT_MODE=client``
или ``--server``) сверяет url сервера, токен-файл и ``/health`` сервера.

``--instance <имя>`` (PERSONAL-1) - запись ЛИЧНОГО экземпляра: ключ ``digital-twin-<имя>`` на порт и
токены его оверлея (``dt instance add``), мост ``dt_shim`` с меткой ``com.dt.server-<имя>``;
печать для всех хостов, ``--install`` для claude/cursor, ``--verify`` для claude/cursor/kimi.
Запись рабочего (``digital-twin``) не затрагивается: ``personal_recall`` есть только у личной.

``--legacy-stdio`` - прежняя stdio-форма (тесты, fallback; ``--sandbox``/``--desc-chars`` - с ней).
``--install`` (claude, cursor) пишет СВОЙ член ``digital-twin`` в конфиг хоста байт-точным
редактором (остальные байты файла целы) с бэкапом ``<файл>.bak-<время>`` рядом; повтор -
«без изменений», битый JSON - отказ без записи. ``--verify`` (claude, cursor, kimi, cherry) -
только чтение: daemon |
stdio-legacy | missing | foreign (cherry - по сессиям в телеметрии). ``--out`` - только в наш файл.

PERSONAL-3: Claude Desktop перезаписывает ``claude_desktop_config.json`` при выходе из своей памяти
(запись, сделанная при работающем Desktop, пропадает). ``--install`` при запущенном Desktop - отказ
``desktop_running``; ``--relaunch`` делает штатно: выход → ожидание (до 60 с, без kill) → запись →
запуск; шаги печатаются и идут в аудит.

Токен в печати - настоящий (секрет пользователя в его терминале): не вставлять в чат;
``--token-placeholder`` печатает ``<web_token_rw>``. В вердиктах и логах токена нет (хвост 4).

Usage:
    uv run python cli/dt.py host-config claude --verify
    uv run python cli/dt.py host-config claude --install
    uv run python cli/dt.py host-config claude --instance personal --install --relaunch
    uv run python cli/dt.py host-config cherry --token-placeholder
    uv run python cli/dt.py host-config cursor --legacy-stdio --profile lean
    uv run python cli/dt.py host-config claude --server konstantins-macbook-pro.tail1faf5a.ts.net
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.host_config import (
    DAEMON_HOSTS,
    HOSTS,
    PROFILES,
    HostConfigError,
    default_profile,
    host_config,
    install_entry,
    install_target,
    kimi_plugin_manifest,
    refuse_foreign_config,
    render,
    server_name,
    verify_host,
)

PASTE_HINT = {
    "claude": "запись в конфиг: `dt host-config claude --install` (бэкап рядом), затем полностью "
              "перезапусти Claude Desktop (Cmd+Q); мост: cli/dt_shim.py",
    "cursor": "запись в конфиг: `dt host-config cursor --install` (~/.cursor/mcp.json), "
              "перезапусти Cursor",
    "kimi": "собери и поставь плагин: dt plugin kimi --out plugins/kimi-work --install (скиллы + "
            "url в mcp.json агента), затем перезапусти Kimi Work",
    "cherry": "Cherry Studio: Settings → MCP → «Import from JSON» - вставь этот JSON (чужую базу "
              "приложения генератор не пишет); скиллы: dt skills export cherry",
    "url": "голая запись {url, headers} для любого клиента MCP по Streamable HTTP",
}


def _verdict_line(v: dict) -> str:
    extra = f" · профиль {v['profile']}" if v.get("profile") else ""
    form = f" ({v['form']})" if v.get("form") else ""
    tok = f" · токен …{v['token_tail']}" if v.get("token_tail") else ""
    why = f" - {v['reason']}" if v.get("reason") else ""
    where = f" [{v['path']}]" if v.get("path") else ""
    return f"{v['host']}: {v['verdict']}{form}{extra}{tok}{why}{where}"


def _server_base(arg: str | None) -> str | None:
    """Адрес сервера: ``--server`` либо ``DT_SERVER_URL`` при ``DT_MODE=client``; нет - ``None``."""
    from core.client import JoinError, configured_server, is_client, server_base

    try:
        if arg:
            return server_base(arg)
        return server_base(configured_server() or "") if is_client() else None
    except JoinError:
        return None


def _cmd_verify(host: str, as_json: bool, server: str | None = None,
                instance: str | None = None) -> int:
    if host not in (*DAEMON_HOSTS, "cherry"):
        print(f"--verify: {', '.join((*DAEMON_HOSTS, 'cherry'))}", file=sys.stderr)
        return 2
    if instance and host == "cherry":
        print("--verify --instance: claude, cursor, kimi (cherry - свой стор в UI)",
              file=sys.stderr)
        return 2
    base = None if instance else _server_base(server)
    try:
        verdict = verify_host(host, server=base, instance=instance)
    except ValueError as exc:
        print(f"отказ: {exc}", file=sys.stderr)
        return 2
    health_ok = True
    if base is not None and host != "cherry":
        from core.client import probe_health

        info = probe_health(base)
        health_ok = info is not None
        code = ((info or {}).get("version") or {}).get("code", "unknown")
        verdict["server"] = {"url": base, "health": health_ok, "code": code if info else None}
    if as_json:
        print(json.dumps(verdict, ensure_ascii=False))
    else:
        print(_verdict_line(verdict))
        if "server" in verdict:
            sv = verdict["server"]
            print(f"сервер {sv['url']}: " + (f"отвечает · код {sv['code']}" if sv["health"]
                                             else "НЕ отвечает на /health"))
    if verdict["verdict"] == "stdio-legacy":
        print(f"# дрейф: хост держит свой процесс движка; перейти: `dt host-config {host} "
              "--install`", file=sys.stderr)
    return 0 if verdict["verdict"] == "daemon" and health_ok else 1


def _cmd_install(host: str, args: argparse.Namespace) -> int:
    if args.legacy_stdio or args.sandbox is not None or args.desc_chars is not None:
        print("установка отклонена: --install ставит только форму демона (url/мост); "
              "--legacy-stdio/--sandbox/--desc-chars - только печать, вставь запись руками",
              file=sys.stderr)
        return 2
    try:
        target = install_target(host)  # до сборки записи: cherry/url/kimi файла не имеют
        entry = host_config(host, args.profile, placeholder=False, access=args.token,
                            port=args.port, server=args.server,
                            instance=args.instance)["mcpServers"][server_name(args.instance)]
        done = install_entry(host, entry, path=target, name=server_name(args.instance),
                             relaunch=args.relaunch)
    except (HostConfigError, ValueError) as exc:
        print(f"установка отклонена: {exc}", file=sys.stderr)
        return 2
    key = server_name(args.instance)  # PERSONAL-3: сообщение называет реальную запись
    words = {"created": f"создан файл с ключом {key}", "added": f"ключ {key} добавлен",
             "updated": f"ключ {key} обновлен", "unchanged": "без изменений (запись уже такая)"}
    print(f"{host}: {done['path']} - {words[done['outcome']]}")
    for step in done.get("steps", []):
        print(f"  · {step}")
    if done["backup"]:
        print(f"бэкап: {done['backup']}")
    relaunched = any("запущен снова" in step for step in done.get("steps", []))
    if done["outcome"] != "unchanged" and not relaunched:
        print(f"# {PASTE_HINT[host].split('), ')[-1] if host == 'claude' else 'перезапусти хост'}",
              file=sys.stderr)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt host-config", description=__doc__.split("\n")[0])
    parser.add_argument("host", choices=HOSTS)
    parser.add_argument("--profile", choices=PROFILES, default=None,
                        help="профиль (дефолт: claude - full, остальные - lean)")
    parser.add_argument("--token", choices=("read", "rw"), default="rw",
                        help="какой токен в записи (дефолт rw: профили пишут выходы)")
    parser.add_argument("--port", type=int, default=None,
                        help="порт демона (дефолт DT_WEB_PORT/8787)")
    parser.add_argument("--server", default=None, metavar="DNS|IP|URL",
                        help="демон-сервер по Tailscale (CONFIG-1): http://<server>:8787/mcp/<профиль>")
    parser.add_argument("--instance", default=None, metavar="ИМЯ",
                        help="личный экземпляр (PERSONAL-1): запись digital-twin-<имя> на его порт "
                             "и токены (dt instance add)")
    parser.add_argument("--token-placeholder", action="store_true",
                        help="печатать <web_token_rw> вместо настоящего токена")
    parser.add_argument("--install", action="store_true",
                        help="записать свой член digital-twin в конфиг хоста (claude, cursor)")
    parser.add_argument("--relaunch", action="store_true",
                        help="с --install (claude): Desktop запущен - выйти, дождаться (до 60 с), "
                             "записать, запустить (без этого флага запись при запущенном Desktop "
                             "отклоняется: он перезаписывает конфиг при выходе)")
    parser.add_argument("--verify", action="store_true",
                        help="только чтение: что стоит в конфиге хоста (daemon|stdio-legacy|...)")
    parser.add_argument("--json", action="store_true", help="с --verify: вердикт JSON-ом")
    parser.add_argument("--legacy-stdio", action="store_true",
                        help="прежняя stdio-форма (command/args/env) - тесты и fallback")
    parser.add_argument("--sandbox", type=Path, default=None,
                        help="только с --legacy-stdio: DT_DERIVED_ROOT песочницы")
    parser.add_argument("--desc-chars", type=int, default=None,
                        help="только с --legacy-stdio: DT_TOOL_DESC_CHARS")
    parser.add_argument("--plugin-manifest", action="store_true",
                        help="kimi: напечатать манифест плагина (скиллы, без MCP) вместо записи")
    parser.add_argument("--out", type=Path, default=None,
                        help="записать JSON в файл (не в конфиг хоста)")
    args = parser.parse_args(argv)

    if args.instance and (args.server or args.legacy_stdio or args.port):
        print("отказ: --instance - локальный экземпляр: порт и токены берутся из его оверлея "
              "(без --server/--port/--legacy-stdio)", file=sys.stderr)
        return 2
    if args.verify:
        return _cmd_verify(args.host, args.json, args.server, args.instance)
    if (args.sandbox or args.desc_chars) and not args.legacy_stdio:
        print("отказ: --sandbox/--desc-chars - только с --legacy-stdio (демон берет настройки из "
              "своего .env)", file=sys.stderr)
        return 2
    if args.relaunch and not args.install:
        print("отказ: --relaunch - только с --install", file=sys.stderr)
        return 2
    if args.install:
        return _cmd_install(args.host, args)

    try:
        if args.host == "kimi" and args.plugin_manifest:
            from dt_skills import profile_tools

            from core.skills import fit_profile, load_skills

            profile = args.profile or default_profile("kimi")
            fit, _ = fit_profile(load_skills(), profile_tools(profile))
            config = kimi_plugin_manifest(profile, skills=[s.name for s in fit])
        else:
            config = host_config(
                args.host, args.profile, legacy_stdio=args.legacy_stdio, sandbox=args.sandbox,
                desc_chars=args.desc_chars, access=args.token, port=args.port,
                placeholder=args.token_placeholder, server=args.server, instance=args.instance)
    except ValueError as exc:
        print(f"отказ: {exc}", file=sys.stderr)
        return 2
    text = render(config)
    if args.out is not None:
        reason = refuse_foreign_config(args.out)
        if reason:
            print(f"отказ: {reason}", file=sys.stderr)
            return 2
        args.out.expanduser().write_text(text + "\n", encoding="utf-8")
        print(f"записано: {args.out}", file=sys.stderr)
    else:
        print(text)
    if not args.legacy_stdio and not args.token_placeholder and args.host != "claude":
        print("# в выводе настоящий токен демона - секрет: не вставляй вывод в чат "
              "(--token-placeholder печатает <web_token_rw>)", file=sys.stderr)
    print(f"# {PASTE_HINT[args.host]}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
