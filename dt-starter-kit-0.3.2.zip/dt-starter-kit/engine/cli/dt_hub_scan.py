"""dt-hub-scan — детектор кандидатов в хабы (HUB-1, interface layer).

Прогоняет :func:`core.linking.hub_candidates.scan_hub_candidates` над свежими
заметками vault + сделками Timetta-зеркала и обновляет очередь кандидатов
``.derived/hub_candidates.jsonl``. Лёгкий и без сети (зеркало — локальный json);
шаг ``hub_scan`` в ``dt-sync full`` зовёт именно этот CLI. Решения по
кандидатам — кнопками пульта (``pult_cards`` вид ``hub`` / ``pult_card_decide``);
хаб НИКОГДА не создаётся автоматически.

HUB-ALIAS-1: тем же шагом ``alias_scan`` пополняет очередь алиасов хабов
``.derived/hub_alias_candidates.jsonl`` (H1, организации зеркала, домены, папки легаси);
решения — ``pult_cards`` вид ``alias`` / ``pult_card_decide``, запись в хаб только
по решению с пульта.

Usage:
    uv run python cli/dt_hub_scan.py
    uv run python cli/dt_hub_scan.py --days 30
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import (
    default_vault_path,
    hub_alias_candidates_path,
    hub_candidates_path,
    timetta_mirror_path,
)
from core.linking.hub_aliases import AliasQueue, AliasScanResult, scan_alias_candidates
from core.linking.hub_candidates import (
    FRESH_DAYS,
    HubCandidateQueue,
    HubScanResult,
    scan_hub_candidates,
)


def render(result: HubScanResult, pending: int) -> str:
    """Анонимная сводка — только счётчики (ни имён, ни текстов)."""
    return "\n".join([
        "СКАН КАНДИДАТОВ В ХАБЫ (HUB-1) — только очередь, хабы не создаются",
        f"  свежих заметок:        {result.fresh_notes}",
        f"  имён извлечено:        {result.raw_names}",
        f"  уже в каталоге:        {result.skipped_catalog}",
        f"  стоп-лист/шум:         {result.skipped_stopped}",
        f"  отклонённых ранее:     {result.skipped_rejected}",
        f"  персон (→ в домен):    {result.skipped_person}",
        f"  фри-почта:             {result.skipped_free_mail}",
        f"  ниже порога:           {result.below_threshold}",
        f"  сделок без хаба:       {result.deals_without_hub}"
        f" (strong: {result.deals_strong}, чужие unit - обычный порог: {result.deals_ring_unit})",
        f"  снято ring_unit:       {result.ring_unit_resolved}",
        f"  кандидатов добавлено:  {result.added}",
        f"  кандидатов обновлено:  {result.updated}",
        f"  снято сверкой:         {result.reconciled}",
        f"  вернулось из снятых:   {result.revived}",
        f"  ждут решения (всего):  {pending}",
        "  (решение — кнопками пульта: pult_cards(hub) / pult_card_decide)",
    ])


def render_aliases(result: AliasScanResult, pending: int) -> str:
    """Анонимная сводка детектора алиасов — только счётчики."""
    sources = ", ".join(f"{k} {v}" for k, v in sorted(result.by_source.items())) or "—"
    return "\n".join([
        "СКАН АЛИАСОВ ХАБОВ (HUB-ALIAS-1) — только очередь, aliases не пишутся",
        f"  хабов:                 {result.hubs}",
        f"  без aliases:           {result.hubs_without_aliases}",
        f"  с предложениями:       {result.with_suggestions} (по источникам: {sources})",
        f"  конфликтов имен:       {result.conflicts}",
        f"  строк добавлено:       {result.added}",
        f"  строк обновлено:       {result.updated}",
        f"  вернулось в очередь:   {result.revived}",
        f"  снято сверкой:         {result.resolved}",
        f"  отклонённых ранее:     {result.skipped_rejected}",
        f"  ждут решения (всего):  {pending}",
        "  (решение — кнопками пульта: pult_cards(alias) / pult_card_decide)",
    ])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-hub-scan",
        description="Собрать кандидатов в хабы из свежих заметок и сделок зеркала.",
    )
    parser.add_argument("--vault", type=Path, default=None)
    parser.add_argument(
        "--days", type=int, default=FRESH_DAYS,
        help=f"Окно свежести заметок в днях (default {FRESH_DAYS}).",
    )
    args = parser.parse_args(argv)
    load_env()

    vault = args.vault or default_vault_path()
    queue = HubCandidateQueue.load(hub_candidates_path())

    deals: list[dict] = []
    orgs: list[dict] = []
    mirror_ok = False
    try:
        from core.operational import orbit
        from core.operational.timetta.mirror import MirrorStore

        # ORBIT-2 (решение К. 4): «Дозрели» — как свои по ВСЕМ видимым кольцам.
        store = MirrorStore(timetta_mirror_path())
        deals = orbit.visible(store.all("deals"), orbit.enabled_rings())
        orgs = store.all("organizations")
        mirror_ok = True
    except Exception:  # noqa: BLE001 — нет зеркала → сканим только заметки
        deals = []

    result = scan_hub_candidates(
        vault, queue=queue, deals=deals, days=max(1, args.days)
    )
    print(render(result, pending=len(queue.pending())))

    # HUB-ALIAS-1: алиасы хабов - тот же шаг, отдельная очередь. Сбой детектора алиасов не
    # роняет скан кандидатов в хабы (он уже сохранен) - код выхода 0, причина в лог.
    try:
        alias_queue = AliasQueue.load(hub_alias_candidates_path())
        alias_result = scan_alias_candidates(
            vault, queue=alias_queue, deals=deals if mirror_ok else None, organizations=orgs
        )
        print(render_aliases(alias_result, pending=len(alias_queue.pending())))
    except Exception as exc:  # noqa: BLE001 — второй детектор не ломает первый
        import logging

        logging.getLogger(__name__).warning("alias_scan не отработал: %s", exc)
        print(f"alias_scan: не отработал ({type(exc).__name__}) — очередь алиасов не обновлена")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
