"""dt-index — rebuild the LanceDB index from the vault (interface layer).

Thin wrapper over core.retrieval.index.reindex. CLI depends on core, never the
reverse (architecture §8 invariant).

Incremental by default (only new/changed notes are re-embedded); ``--full``
forces a drop + recreate rebuild.

Usage:
    uv run python cli/dt_index.py [--vault PATH] [--full]
"""

from __future__ import annotations

import argparse
import logging
import os
import signal
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import default_vault_path
from core.retrieval.index import (
    IndexBusyError,
    backfill_text_hash,
    rebuild_fts,
    reindex,
    reuse_line,
)

logger = logging.getLogger(__name__)


def _install_sigterm_handler() -> None:
    """Map SIGTERM to KeyboardInterrupt so ``kill <pid>`` stops as gracefully as
    Ctrl-C — the reindex flushes its current checkpoint and re-raises, so a
    killed long run stays resumable rather than corrupt."""

    def _handler(signum: int, frame: object) -> None:
        raise KeyboardInterrupt

    try:
        signal.signal(signal.SIGTERM, _handler)
    except (ValueError, OSError):
        # Not in the main thread (e.g. under a test runner) — skip silently.
        pass


def _rebuild_fts_main() -> int:
    """``--rebuild-fts``: один шаг, под index-lock'ом; 0 — собран или мягкий пропуск."""
    logger.info("rebuilding FTS index only (no re-embedding)")
    try:
        out = rebuild_fts()
    except IndexBusyError as e:
        logger.warning("FTS rebuild skipped — %s", e)
        return 0
    except FileNotFoundError as e:
        logger.error("FTS rebuild impossible — %s", e)
        return 1
    print(
        f"FTS rebuilt [language={out['language']}]: {out['rows']} rows in {out['elapsed_s']}s"
    )
    return 0


def _backfill_text_hash_main() -> int:
    """``--backfill-text-hash``: один шаг, под index-lock'ом; 0 — готово или мягкий пропуск."""
    logger.info("backfilling text_hash column (no re-embedding)")
    try:
        out = backfill_text_hash()
    except IndexBusyError as e:
        logger.warning("text_hash backfill skipped — %s", e)
        return 0
    except FileNotFoundError as e:
        logger.error("text_hash backfill impossible — %s", e)
        return 1
    action = "колонка добавлена" if out["column_added"] else "дозаполнено"
    print(
        f"text_hash backfilled [{action}]: {out['filled']}/{out['rows']} rows "
        f"(было заполнено {out['filled_before']}, осталось пустых {out['remaining']}) "
        f"in {out['elapsed_s']}s"
    )
    return 0 if out["remaining"] == 0 else 1


def main(argv: list[str] | None = None) -> int:
    load_env()  # CODE-5-2: engine/.env + unified logger (handler + corr-id) as other CLIs
    parser = argparse.ArgumentParser(prog="dt-index", description="Rebuild the LanceDB index.")
    parser.add_argument(
        "--vault",
        type=Path,
        default=default_vault_path(),
        help="Path to the vault (default: sibling vault/ or $DT_VAULT_PATH).",
    )
    parser.add_argument(
        "--full",
        action="store_true",
        default=False,
        help="Full rebuild (drop + recreate, re-embed everything). "
        "Default is incremental — re-embed only new/changed notes.",
    )
    parser.add_argument(
        "--replan-capped",
        action="store_true",
        default=False,
        help="WAVE0-HYGIENE п.5: перепланировать капнутые заметки (у почтовых тредов "
        "кап теперь с хвоста; у остальных только проставится флаг). Канарейка: "
        "--replan-limit 1, затем без лимита.",
    )
    parser.add_argument(
        "--rechunk",
        action="store_true",
        default=False,
        help="RETR-CHUNK-1 п.12: перечанковать ВСЕ заметки старой версии чанкера НА МЕСТЕ — индекс"
        "остаётся живым (поиск не пропадает), векторы чанков с тем же текстом переиспользуются; "
        "версия чанкера проставляется в конце. Возобновляем: повтор берёт только недоделанные.",
    )
    parser.add_argument(
        "--replan-limit", type=int, default=None, help="сколько капнутых заметок взять"
    )
    parser.add_argument(
        "--rebuild-fts",
        action="store_true",
        default=False,
        help="RETR-RANK-1 п.3: пересобрать ТОЛЬКО полнотекстовый индекс (язык Russian), без "
        "переэмбеддинга; под index-lock'ом, прогресс в маяк. После смены настроек FTS.",
    )
    parser.add_argument(
        "--backfill-text-hash",
        action="store_true",
        default=False,
        help="VEC-REUSE-1 п.1: заполнить колонку text_hash (sha256 текста чанка) в "
        "существующей таблице БЕЗ переэмбеддинга; идемпотентно, под index-lock'ом, "
        "прогресс в маяк. Разово после обновления; без неё реюз по содержимому выключен.",
    )
    args = parser.parse_args(argv)
    _install_sigterm_handler()

    if args.backfill_text_hash:
        return _backfill_text_hash_main()

    if args.rebuild_fts:
        return _rebuild_fts_main()

    mode = "full rebuild" if args.full else "incremental"
    # Lifecycle start of a background step → logger (journal); the RESULT report
    # below stays stdout (UX). The [index] progress lines come from core's default
    # emitter (injection contract) — untouched.
    logger.info("indexing vault (%s): %s", mode, args.vault)
    try:
        stats = reindex(
            args.vault, full=args.full,
            replan_capped=args.replan_capped, replan_limit=args.replan_limit,
            rechunk=args.rechunk,
        )
    except IndexBusyError as e:
        # Soft skip (Phase 9 этап 4): an in-flight (re)index must never be
        # broken by a scheduled incremental pass — it catches up next run.
        logger.warning("reindex skipped — %s", e)
        return 0
    except KeyboardInterrupt:
        # Progress is checkpointed to the manifest; a re-run resumes the rest.
        logger.warning(
            "reindex interrupted — progress checkpointed to the manifest; "
            "re-run `dt-index` to resume from where it stopped."
        )
        return 130
    print(
        f"Done [{stats.mode}, device={stats.device}"
        f"{' via daemon' if getattr(stats, 'via', '') == 'daemon' else ''}]: "
        f"new={stats.new} changed={stats.changed} deleted={stats.deleted} "
        f"unchanged={stats.unchanged}; {stats.embedded_chunks} chunks (re)embedded "
        f"in {stats.checkpoints} checkpoints; "
        f"{stats.notes} notes, {stats.chunks} rows in {stats.elapsed_s:.1f}s "
        f"→ {stats.db_path}"
    )
    if hasattr(stats, "reuse_summary"):  # VEC-REUSE-1 п.4; дублёры статистики без неё — молча
        print(reuse_line(stats).removeprefix("[index] "))
    lance = getattr(stats, "lance", None) or {}
    if lance:
        before, after = lance.get("before", {}), lance.get("after", {})
        print(
            f"LanceDB optimize [{'ok' if lance.get('ok') else 'FAILED'}]: "
            f"версий {before.get('versions')}→{after.get('versions')}, "
            f"_versions {before.get('versions_gb')}→{after.get('versions_gb')} ГБ, "
            f"фрагментов {after.get('fragments')}, {lance.get('elapsed_s')}с"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
