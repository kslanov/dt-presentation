"""dt-ingest — scan watched folders and route files (INGEST-1 PART-5).

The main path for the file ingest (cron / by hand). Walks the roots from
``_system/ingest-roots.yaml``, filters (include/exclude + NDA-1), handles iCloud
dataless placeholders, and routes new/changed files: operational → SRC-1 registry,
knowledge → legacy note pipeline + reindex.

**Dry-run by default** — reports the disposition and writes nothing (and never
downloads an iCloud file). Pass ``--apply`` to actually route. ``--root <name>``
limits the pass to one configured root.

Usage::

    uv run python cli/dt_ingest.py                 # dry-run preview of all roots
    uv run python cli/dt_ingest.py --apply         # route new/changed files
    uv run python cli/dt_ingest.py --root acme-ops --apply
    uv run python cli/dt_ingest.py --repoint-sources           # SRC-PATH-1: dry-run бэкфилла
    uv run python cli/dt_ingest.py --repoint-sources --apply --corpus current --limit 5

``--repoint-sources`` (SRC-PATH-1) чинит заметки, чей frontmatter ``source_path`` отстал после
переезда папки: переписывает его по ключу манифеста инжеста (тело и прочий frontmatter -
байт-в-байт). Dry-run по умолчанию; корни инжеста не нужны.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import default_vault_path
from core.file_ingest import load_ingest_roots, scan


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-ingest", description="Scan + route watched folders (INGEST-1)."
    )
    parser.add_argument("--apply", action="store_true",
                        help="Actually route (default: dry-run, writes nothing).")
    parser.add_argument("--root", help="Limit to one configured root by name.")
    parser.add_argument("--route", choices=["operational", "knowledge"],
                        help="Limit to roots of this route (operational: cheap registry; "
                             "knowledge: notes+reindex). Used by the scheduled dt-sync steps.")
    parser.add_argument("--no-reindex", action="store_true",
                        help="Knowledge route: render notes but skip the inner incremental "
                             "reindex (the nightly dt-sync index chain runs reindex_inc next).")
    parser.add_argument("--repoint-sources", action="store_true",
                        help="SRC-PATH-1: переписать отставший source_path заметок по манифесту "
                             "(dry-run без --apply).")
    parser.add_argument("--corpus", choices=["current", "legacy", "both"], default="both",
                        help="--repoint-sources: слой заметок (по умолчанию both).")
    parser.add_argument("--limit", type=int, default=None,
                        help="--repoint-sources: канарейка - переписать не больше N заметок.")
    parser.add_argument("--json", action="store_true", help="Print the full stats JSON.")
    parser.add_argument("--quiet", action="store_true", help="Suppress per-file progress.")
    args = parser.parse_args(argv)

    load_env()
    vault = default_vault_path()

    if args.repoint_sources:
        return _repoint_sources(vault, args)

    roots = load_ingest_roots(vault)
    if not roots:
        print("no ingest roots configured (_system/ingest-roots.yaml absent/empty)")
        return 0
    if args.root and not any(r.name == args.root for r in roots):
        print(f"no root named {args.root!r}; configured: {[r.name for r in roots]}")
        return 1
    # A scheduled --route pass over a corpus with no roots of that route is a clean
    # no-op (the operational fast step must not error when only knowledge roots exist).
    if args.route and not any(r.route == args.route for r in roots):
        print(f"no {args.route} ingest roots configured — nothing to scan.")
        return 0

    def _log(msg: str) -> None:
        # --json emits pure JSON on stdout; route progress to stderr so it can be
        # piped. --quiet suppresses progress entirely.
        if args.quiet:
            return
        print(msg, file=sys.stderr if args.json else sys.stdout)

    from core.ingress.run import ingress_run

    # INGRESS-1: run_id + общий итог прогона (last_runs.json) — по маршруту; полный проход без
    # --route покрывает оба адаптера сразу, его итог в last_runs не пишем (единицы смешаны).
    adapter_key = f"files:{args.route}" if args.route else None
    with ingress_run(adapter_key or "files", dry_run=not args.apply) as run:
        stats = scan(
            vault_path=vault, root_name=args.root, route=args.route,
            dry_run=not args.apply, log=_log, reindex=not args.no_reindex,
        )
        if adapter_key:
            run.finish(stats)

    if args.json:
        print(json.dumps(stats.to_dict(), ensure_ascii=False, indent=2))
        return 0

    mode = "APPLY" if args.apply else "DRY-RUN"
    scope = f" route={args.route}" if args.route else ""
    print(
        f"\n[ingest {mode}{scope}] roots={stats.roots} seen={stats.total_seen} "
        f"new={stats.new} changed={stats.changed} unchanged={stats.unchanged} "
        f"nda_skipped={stats.nda_skipped} excluded={stats.excluded} "
        f"pending_download={stats.pending_download} errors={stats.errors}"
    )
    print(
        f"  operational_registered={stats.operational_registered} "
        f"knowledge_roots_ingested={stats.knowledge_roots_ingested} "
        f"reindex={'yes' if stats.reindex_triggered else 'no'} "
        f"elapsed={stats.elapsed_s:.1f}s"
        + ("  [interrupted]" if stats.interrupted else "")
    )
    # PART-2 transparency: per-root new/changed/unchanged/nda/dataless — so the
    # dt-sync captured log / digest shows what each root did (like a manual run).
    for line in _per_root_lines(stats):
        print(line)
    if not args.apply and (stats.new or stats.changed):
        print("  (dry-run) rerun with --apply to route these files.")
    return 0


def _repoint_sources(vault, args) -> int:
    from core.legacy.repoint import repoint_sources

    report = repoint_sources(
        vault, corpus=args.corpus, apply=args.apply, limit=args.limit
    )
    if args.json:
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
        return 0
    mode = "APPLY" if args.apply else "DRY-RUN"
    verb = "переписано" if args.apply else "переписать"
    print(f"[repoint-sources {mode}]")
    for layer, c in report.corpora.items():
        print(
            f"  {layer}: заметок с файловым source_path {c['notes']}, живых {c['resolvable']} | "
            f"{verb} {c['rewritten']}, без записи в манифесте {c['no_entry']}, "
            f"ключ тоже мертв {c['dead_key']}"
            + (f", уже живые (снимок отстал) {c['already']}" if c.get("already") else "")
            + (f", за лимитом {c['skipped_limit']}" if c["skipped_limit"] else "")
            + (f", ошибок {c['errors']}" if c["errors"] else "")
        )
        for bucket, items in c["examples"].items():
            for item in items:
                detail = " → ".join(str(v) for v in item.values())
                print(f"      [{bucket}] {detail}")
    if not args.apply:
        print("  (dry-run) --apply перепишет заметки; затем dt_index подхватит их штатно.")
    return 0


def _per_root_lines(stats) -> list[str]:
    """Per-root counters derived from the scan's per-file actions (INGEST-SCHEDULE PART-2)."""
    from core.file_ingest.scan import (
        STATUS_CHANGED,
        STATUS_NDA,
        STATUS_NEW,
        STATUS_PENDING,
        STATUS_UNCHANGED,
    )

    agg: dict[str, dict[str, int]] = {}
    for a in stats.actions:
        c = agg.setdefault(
            a.root or "?",
            {"new": 0, "changed": 0, "unchanged": 0, "nda": 0, "dataless": 0},
        )
        if a.status == STATUS_NEW:
            c["new"] += 1
        elif a.status == STATUS_CHANGED:
            c["changed"] += 1
        elif a.status == STATUS_UNCHANGED:
            c["unchanged"] += 1
        elif a.status == STATUS_NDA:
            c["nda"] += 1
        elif a.status == STATUS_PENDING:
            c["dataless"] += 1
    return [
        f"  · {name}: new={c['new']} changed={c['changed']} unchanged={c['unchanged']} "
        f"nda={c['nda']} dataless={c['dataless']}"
        for name, c in sorted(agg.items())
    ]


if __name__ == "__main__":
    raise SystemExit(main())
