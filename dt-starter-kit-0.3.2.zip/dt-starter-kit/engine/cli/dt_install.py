"""dt install - фаза 1 инсталлера одной командой (DEV-3-KIT): шаги, состояние, возобновление.

Порядок: ``platform → deps → config → vault → owner → [models → launchd →] host → index → doctor``.
Каждый шаг - существующая команда движка + ``check()``; повтор продолжает с первого незавершенного.
Состояние - ``<корень>/.derived/install/state.json`` (чем кончился шаг, проценты скачивания, ответы
мастера; секретов нет). ``--check`` и ``--dry-run`` ничего не пишут. ``sudo`` нигде не нужен.

Usage:
    uv run python cli/dt.py install                    # продолжить с первого незавершенного
    uv run python cli/dt.py install --check            # таблица «шаг - сделано/нет - почему»
    uv run python cli/dt.py install --dry-run          # что было бы сделано
    uv run python cli/dt.py install --yes --name "Имя Фамилия" --email a@example.com
    uv run python cli/dt.py install --step models --models-from ~/Downloads/dt-models.tar
    uv run python cli/dt.py install --step host --host claude --relaunch
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def add_target_args(parser: argparse.ArgumentParser) -> None:
    """Куда ставим (общие флаги ``dt install`` и ``dt uninstall``)."""
    parser.add_argument("--root", default=None, metavar="PATH",
                        help="корень рабочей папки (vault и .derived внутри); по умолчанию - "
                             "родитель engine/")
    parser.add_argument("--home", default=None, metavar="PATH",
                        help="домашний каталог (LaunchAgents, конфиги хостов); по умолчанию HOME")
    parser.add_argument("--engine-dir", default=None, metavar="PATH",
                        help="каталог движка (по умолчанию - где лежит этот код)")
    parser.add_argument("--env-file", default=None, metavar="PATH",
                        help=".env цели (по умолчанию <engine>/.env)")
    parser.add_argument("--vault", default=None, metavar="PATH", help="папка vault")
    parser.add_argument("--json", action="store_true", help="машиночитаемый вывод")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt install", description=__doc__.split("\n")[0])
    add_target_args(parser)
    parser.add_argument("--check", action="store_true",
                        help="только таблица «что сделано» (ничего не пишет; код 1, если не все)")
    parser.add_argument("--dry-run", action="store_true", help="показать план, ничего не менять")
    parser.add_argument("--yes", action="store_true",
                        help="без вопросов: значения из флагов/состояния/умолчаний")
    parser.add_argument("--step", default=None, metavar="ИМЯ", help="выполнить один шаг")
    parser.add_argument("--from", dest="start", default=None, metavar="ИМЯ",
                        help="начать с этого шага (готовые пропускаются)")
    parser.add_argument("--name", default=None, help="имя владельца")
    parser.add_argument("--email", action="append", default=[], metavar="АДРЕС",
                        help="ваш адрес (повторяемый)")
    parser.add_argument("--company", default=None, help="компания")
    parser.add_argument("--domain", action="append", default=[], metavar="ДОМЕН",
                        help="почтовый домен компании (повторяемый)")
    parser.add_argument("--internal-domain", action="append", default=[], metavar="ДОМЕН",
                        help="служебный домен группы (повторяемый)")
    parser.add_argument("--people", nargs="*", default=[], metavar="ФАМИЛИЯ",
                        help="чьи личные документы не индексировать (privacy.people)")
    hosts = ("claude", "cursor", "kimi", "cherry", "none")
    parser.add_argument("--host", default=None, choices=hosts,
                        help="какой ассистент подключаем (none - пропустить)")
    parser.add_argument("--connectors", default=None, metavar="none|auto|СПИСОК",
                        help="DT_CONNECTORS (по умолчанию none: база без CRM/почты)")
    parser.add_argument("--relaunch", action="store_true",
                        help="шаг host: Claude Desktop запущен - выйти, записать, запустить")
    parser.add_argument("--ops-full", action="store_true",
                        help="шаг launchd: полный состав (смоук и сторож прогонов - для владельца)")
    parser.add_argument("--models-from", default=None, metavar="ПАПКА|АРХИВ",
                        help="шаг models: офлайн-копия кэша моделей (dt-models.tar или папка)")
    args = parser.parse_args(argv)

    from dt_install_steps import STEPS

    from core.install.context import Answers, InstallContext
    from core.install.runner import run_install

    answers = Answers(
        name=args.name or "", emails=list(args.email), company=args.company or "",
        domains=list(args.domain), internal_domains=list(args.internal_domain),
        people=list(args.people), host=args.host or "", connectors=args.connectors or "",
        vault=args.vault or "")
    ctx = InstallContext.build(
        engine_dir=Path(args.engine_dir) if args.engine_dir else None,
        root=Path(args.root) if args.root else None,
        home=Path(args.home) if args.home else None,
        env_path=Path(args.env_file) if args.env_file else None,
        vault=Path(args.vault) if args.vault else None, answers=answers,
        yes=args.yes, dry_run=args.dry_run, relaunch=args.relaunch, ops_full=args.ops_full,
        models_from=Path(args.models_from).expanduser() if args.models_from else None)
    return run_install(ctx, STEPS, only=args.step, start=args.start, check_only=args.check,
                       as_json=args.json)


if __name__ == "__main__":
    raise SystemExit(main())
