"""dt instance - экземпляры движка (PERSONAL-1 п.1): ``add | list | status | remove``.

Экземпляр - тот же движок со своим оверлеем env, vault, derived, секретами, портом и
launchd-метками.
Личный контур = экземпляр роли ``personal`` (захват ``#дневник``/``#контент``/``#личное``, мост к
рабочему демону по токену ЧТЕНИЯ). Рабочий экземпляр - без оверлея и этой команды не требует.

* ``add <имя> --vault ПУТЬ --port N [--work-url URL] [--role personal|work]`` - оверлей
  ``engine/instances/<имя>.env``, каталог секретов с новыми токенами (+ токен чтения рабочего демона
  и узкий токен эмбеддера у роли personal), derived, каркас vault, три plist-а
  ``com.dt.server-<имя>`` / ``com.dt.sync.fast-<имя>`` / ``com.dt.sync.index-<имя>``; загружает их
  (``--no-load`` - только записать). ``--launchd-dir``/``--instances-dir``/``--work-secrets-dir`` -
  для проверки на песочнице;
  PERSONAL-2: ``--journal-dir``/``--ideas-dir``/``--content-dirs`` - папки УЖЕ существующего личного
  vault (пути от корня): каркас создает только ``_system/``, инбокс и эти папки дневника/идей;
* ``set <имя> <ключ> <значение>`` - правка ручки оверлея (папки ``DT_PERSONAL_*``, исключения
  ``DT_BRIDGE_EXCLUDE``/``DT_INDEX_EXCLUDE``, ``DT_BRIDGE_*``): значение проверяется, писатель -
  ``env_file`` (бэкап, права 600); пустое значение снимает ручку;
* ``list`` - имена оверлеев;
* ``status [<имя>]`` - оверлей, пути, plist-ы, загружены ли метки, ``/health`` экземпляра;
* ``remove <имя>`` - снять plist-ы и оверлей; vault, derived и секреты не трогаются.

Usage:
    uv run python cli/dt.py instance add personal --port 8788 \\
        --vault ~/Claude/Projects/"Digital twin"/vault-personal
    uv run python cli/dt.py instance status
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env


def _add(args: argparse.Namespace) -> int:
    from core.instance_admin import InstanceExists, add_instance

    try:
        res = add_instance(
            args.name, vault=Path(args.vault), port=args.port, role=args.role,
            work_url=args.work_url,
            instances_dir=Path(args.instances_dir) if args.instances_dir else None,
            launchd_dir=Path(args.launchd_dir) if args.launchd_dir else None,
            work_secrets_dir=Path(args.work_secrets_dir) if args.work_secrets_dir else None,
            work_vault=Path(args.work_vault) if args.work_vault else None,
            load=not args.no_load, journal_dir=args.journal_dir, ideas_dir=args.ideas_dir,
            capture_project=args.capture_project, untagged_lane=args.untagged_lane,
            bridge_exclude=args.bridge_exclude,
            content_dirs=[d for d in (args.content_dirs or "").split(",") if d.strip()] or None,
        )
    except InstanceExists as exc:
        print(f"отказ: {exc}", file=sys.stderr)
        return 2
    except ValueError as exc:
        print(f"отказ: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(res.as_dict(), ensure_ascii=False, indent=2))
        return 0
    print(f"экземпляр {res.name} (роль {res.role}), порт {res.port}")
    print(f"  оверлей:  {res.overlay}")
    print(f"  vault:    {res.vault}")
    print(f"  derived:  {res.derived}")
    print(f"  секреты:  {res.secrets} (токены: {', '.join(sorted(res.tokens))})")
    print(f"  каркас vault: {len(res.skeleton)} позиций")
    for kind, path in res.plists.items():
        print(f"  plist {kind}: {path}")
    if res.loaded:
        print("  загружены: " + ", ".join(res.loaded))
    for note in res.notes:
        print(f"  внимание: {note}")
    if res.role == "personal":  # PERSONAL-3: Desktop перезаписывает конфиг при выходе
        print(f"  запись в Desktop: dt host-config claude --instance {res.name} --install "
              "--relaunch")
    return 0


def _set(args: argparse.Namespace) -> int:
    from core.instance_settings import SettingsError, set_key

    try:
        edit = set_key(args.key, args.value, name=args.name,
                       instances_dir=Path(args.instances_dir) if args.instances_dir else None,
                       apply_env=False)
    except SettingsError as exc:
        print(f"отказ ({exc.code}): {exc.detail}", file=sys.stderr)
        return 2
    print(f"{args.name}: {args.key} - {edit.action}"
          + (f" (бэкап {edit.backup.name})" if edit.backup else ""))
    print("# демон подхватит значение при перезапуске (kickstart) либо через "
          "pult_settings_set; джобы launchd - при следующем запуске", file=sys.stderr)
    return 0


def _list(_args: argparse.Namespace) -> int:
    from core.instance_admin import list_instances

    for name in list_instances():
        print(name)
    return 0


def _desktop_line(name: str, inst_dir: Path | None) -> str:
    """PERSONAL-3 п.D3: запись ``digital-twin-<имя>`` в конфиге Claude Desktop (только чтение)."""
    from core.host_config import instance_entry_verdicts

    (verdict,) = instance_entry_verdicts("claude", instances=[name], instances_dir=inst_dir)
    if verdict["verdict"] == "daemon":
        return "запись в Desktop: на месте"
    return (f"запись в Desktop: {verdict['verdict']} - Desktop перезаписывает конфиг при выходе; "
            f"поставить: dt host-config claude --instance {name} --install --relaunch")


def _status(args: argparse.Namespace) -> int:
    from core.instance_admin import instance_status, list_instances

    inst_dir = Path(args.instances_dir) if args.instances_dir else None
    la_dir = Path(args.launchd_dir) if args.launchd_dir else None
    names = [args.name] if args.name else list_instances(inst_dir)
    if not args.name:  # рабочий экземпляр: без оверлея, порт процесса; о личном он не знает
        from core.instance_admin import work_status

        w = work_status()
        print(f"work: порт {w['port']}, демон " + ("жив" if w["health"] else "не отвечает"))
    if not names:
        print("личных экземпляров нет (dt instance add …)")
        return 0
    bad = 0
    for name in names:
        st = instance_status(name, instances_dir=inst_dir, launchd_dir=la_dir)
        if not st.get("exists"):
            print(f"{name}: нет оверлея")
            bad = 1
            continue
        h = st["health"]
        alive = ("жив" + (f", instance={h['instance']['name']}" if h.get("instance") else "")
                 if h else "не отвечает")
        print(f"{name}: роль {st['role']}, порт {st['port']}, демон {alive}")
        print(f"  vault {st['vault']}; derived {st['derived']}")
        def yn(d: dict) -> str:
            return ", ".join(f"{k}={'да' if v else 'нет'}" for k, v in d.items())

        print(f"  plist: {yn(st['plists'])}; загружены: {yn(st['loaded'])}")
        print("  " + _desktop_line(name, inst_dir))
    return bad


def _remove(args: argparse.Namespace) -> int:
    from core.instance_admin import remove_instance

    rep = remove_instance(
        args.name, instances_dir=Path(args.instances_dir) if args.instances_dir else None,
        launchd_dir=Path(args.launchd_dir) if args.launchd_dir else None)
    print(f"{args.name}: снято plist-ов {len(rep['plists_removed'])}"
          f", оверлей {'снят' if rep['overlay_removed'] else 'не найден'}")
    for kept in rep["kept"]:
        print(f"  не тронуто: {kept}")
    return 0


def main(argv: list[str] | None = None) -> int:
    load_env()
    parser = argparse.ArgumentParser(prog="dt instance", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    add = sub.add_parser("add", help="создать экземпляр")
    add.add_argument("name")
    add.add_argument("--vault", required=True)
    add.add_argument("--port", type=int, required=True)
    add.add_argument("--role", choices=("personal", "work"), default="personal")
    add.add_argument("--work-url", default=None,
                     help="адрес рабочего демона (по умолчанию http://127.0.0.1:8787)")
    add.add_argument("--no-load", action="store_true", help="plist-ы записать, launchctl не звать")
    add.add_argument("--json", action="store_true")
    for p in (add, sub.add_parser("remove", help="снять plist-ы и оверлей")):
        p.add_argument("--instances-dir", default=None)
        p.add_argument("--launchd-dir", default=None)
    add.add_argument("--work-secrets-dir", default=None)
    add.add_argument("--journal-dir", default=None, help="папка дневника от корня vault")
    add.add_argument("--ideas-dir", default=None,
                     help="папка идей (#личное → заметка идеи) от корня vault")
    add.add_argument("--content-dirs", default=None,
                     help="папки контента для подсказки размещения, через запятую")
    add.add_argument("--capture-project", default=None,
                     help="свой список TickTick для захвата личного (имя или id; без него - "
                          "список рабочего)")
    add.add_argument("--untagged-lane", default=None,
                     choices=("skip", "personal", "journal", "content"),
                     help="полоса для задач без тега (не skip - только с --capture-project)")
    add.add_argument("--bridge-exclude", default=None,
                     help="заметки вне моста (glob от корня vault, через запятую; пусто - без "
                          "исключений; без флага - Templates/**): задать до первого индекса")
    add.add_argument("--work-vault", default=None,
                     help="рабочий vault: откуда копируются профиль и канон ИИ-маркеров")
    sub.choices["remove"].add_argument("name")
    setp = sub.add_parser("set", help="правка ручки оверлея экземпляра")
    setp.add_argument("name")
    setp.add_argument("key")
    setp.add_argument("value")
    setp.add_argument("--instances-dir", default=None)
    sub.add_parser("list", help="имена экземпляров")
    st = sub.add_parser("status", help="состояние экземпляров")
    st.add_argument("name", nargs="?")
    st.add_argument("--instances-dir", default=None)
    st.add_argument("--launchd-dir", default=None)
    args = parser.parse_args(argv)
    return {"add": _add, "set": _set, "list": _list, "status": _status,
            "remove": _remove}[args.cmd](args)


if __name__ == "__main__":
    raise SystemExit(main())
