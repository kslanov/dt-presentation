"""dt-job — submit / inspect async jobs from the shell (JOB-1, interface layer).

The CLI twin of the MCP ``submit_job`` / ``job_status`` tools, for smoke tests and
cron. ``submit`` records a job and spawns the detached worker (returns a ``job_id``
immediately); ``status`` / ``list`` read the durable ``jobs.db``; ``cancel``
requests a graceful stop. Human summary by default, full JSON with ``--json``.

Path B: no LLM. The heavy work runs in the detached worker (``dt_job_worker.py``);
this shim only talks to ``core.orchestration.jobs``.

Usage::

    uv run --extra operational --extra server python cli/dt_job.py submit reindex --arg scope=full
    uv run python cli/dt_job.py status <job_id>
    uv run python cli/dt_job.py list --state running
    uv run python cli/dt_job.py cancel <job_id>
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

logger = logging.getLogger(__name__)

from core.orchestration.jobs import (  # noqa: E402
    SUBMITTABLE_OPS,
    JobError,
    cancel,
    list_jobs,
    status,
    submit,
)


def _parse_args_kv(pairs: list[str]) -> dict[str, object]:
    """``--arg k=v`` pairs → dict; numeric/bool values are coerced for convenience."""
    out: dict[str, object] = {}
    for pair in pairs:
        if "=" not in pair:
            raise SystemExit(f"bad --arg {pair!r}; expected key=value")
        key, _, raw = pair.partition("=")
        value: object = raw
        if raw.lower() in ("true", "false"):
            value = raw.lower() == "true"
        elif raw.lstrip("-").isdigit():
            value = int(raw)
        out[key.strip()] = value
    return out


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-job", description="Submit / inspect async jobs (JOB-1)."
    )
    parser.add_argument("--json", action="store_true", help="Print full JSON.")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_submit = sub.add_parser("submit", help="Submit a job and spawn its worker.")
    p_submit.add_argument(
        "op", help=f"Submittable op: {', '.join(sorted(SUBMITTABLE_OPS))}."
    )
    p_submit.add_argument(
        "--arg", action="append", default=[], metavar="K=V",
        help="Job argument (repeatable), e.g. --arg scope=full --arg mode=meetings.",
    )

    p_status = sub.add_parser("status", help="Show a job's state / progress / result.")
    p_status.add_argument("job_id")

    p_list = sub.add_parser("list", help="List recent jobs (newest first).")
    p_list.add_argument("--state", default=None, help="Filter by state.")
    p_list.add_argument("--limit", type=int, default=20)

    p_cancel = sub.add_parser("cancel", help="Request a graceful cancel.")
    p_cancel.add_argument("job_id")

    args = parser.parse_args(argv)
    load_env()

    if args.cmd == "submit":
        try:
            job_id = submit(args.op, _parse_args_kv(args.arg))
        except JobError as exc:
            logger.error("submit failed — %s", exc)
            return 2
        out = {"job_id": job_id, "op": args.op, "state": "queued"}
        print(json.dumps(out, ensure_ascii=False) if args.json else f"submitted {job_id}")
        return 0

    if args.cmd == "status":
        st = status(args.job_id)
        if args.json:
            print(json.dumps(st, ensure_ascii=False, indent=2))
        else:
            line = f"{args.job_id}  {st.get('state')}"
            if st.get("phase"):
                line += f"  phase={st['phase']}"
            if st.get("current") is not None:
                line += f"  {st.get('current')}/{st.get('total')}"
            if st.get("error"):
                line += f"  error={st['error']}"
            print(line)
        return 0

    if args.cmd == "list":
        rows = list_jobs(state=args.state, limit=args.limit)
        if args.json:
            print(json.dumps(rows, ensure_ascii=False, indent=2))
        else:
            for r in rows:
                print(f"{r['job_id']}  {r['op']:<14}  {r['state']:<9}  {r['created_at']}")
            if not rows:
                print("(no jobs)")
        return 0

    if args.cmd == "cancel":
        st = cancel(args.job_id)
        if args.json:
            print(json.dumps(st, ensure_ascii=False))
        else:
            print(f"{args.job_id}  {st.get('state')}")
        return 0

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
