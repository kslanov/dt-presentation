"""dt-job-worker — detached entry that runs ONE async job (JOB-1, interface layer).

Spawned (never called directly by a user) by ``core.orchestration.jobs.submit``
as a detached process — ``Popen`` + ``start_new_session``, stdio → devnull — so it
outlives the MCP server and the result is durable. It loads ``.env`` (the server
launches it without the shell environment), then hands off to
:func:`core.orchestration.jobs.run_job`, which marks the job ``running``, dispatches
to the op handler, writes progress durably + to the beacon, and settles the job
(``done`` / ``failed`` / ``cancelled``). All state lives in ``jobs.db``; this
process holds nothing the poller needs.

Path B: the worker runs only the operation itself (bridge read / reindex / lift) —
no LLM. The heavy lifting is in ``core``; this is a thin CLI shim (architecture §8
invariant: ``core/`` ⊥ cli).

Usage (normally spawned, shown for smoke tests)::

    uv run --extra operational --extra parsers python cli/dt_job_worker.py --job <id>
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.orchestration.jobs import JobError, run_job

logger = logging.getLogger(__name__)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-job-worker", description="Run one async job to completion (JOB-1)."
    )
    parser.add_argument("--job", required=True, help="job_id to run (from submit).")
    args = parser.parse_args(argv)

    load_env()

    try:
        row = run_job(args.job)
    except JobError as exc:
        logger.error("job worker error — %s", exc)
        return 2
    state = row.get("state")
    print(f"job {args.job}: {state}")
    # Exit non-zero on a hard failure so a supervising smoke run notices; a
    # cancelled/done job is a clean exit.
    return 1 if state == "failed" else 0


if __name__ == "__main__":
    raise SystemExit(main())
