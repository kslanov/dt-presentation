"""dt-kpi — сводка метрик когнитивной нагрузки (KPI-1, interface layer).

Reads the append-only event journal (``.derived/metrics/events.jsonl``, written
best-effort by the instrumented engine points) and prints a plain-text summary
of metrics 1–3 over the last N days. No network; nothing is written.

Все цифры считает ``core.metrics.summarize`` (ADMIN-1 v2A) — тот же источник,
что у MCP-инструмента ``pult_kpi``; этот CLI только рендерит dict в текст,
никакой собственной агрегации (сводка не дублируется).

Метрики (v1 — честные счётчики, интерпретация и пороги позже):

1. Inbox-разметка применена (Understanding) — v1-приближение: правка после
   apply пока не детектируется, считаем факт применения.
2. Retrieval-прогоны (Memory) — v1-приближение: «ответил с первого раза» пока
   не детектируется, считаем прогоны и их наполненность (hits > 0).
3. Решения через очередь (кривая доверия, данные AUTON-1) — approved / auto /
   rejected + доля без reject.

Метрика 4 (читаемость дайджеста) в v1 не измеряется — зафиксировано как
«позже» (нет сигнала).

Usage:
    uv run python cli/dt_kpi.py --days 7
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.metrics import summarize


def _pct(part: int, total: int) -> str:
    return f"{100 * part / total:.0f}%" if total else "—"


def render_summary(summary: dict[str, Any]) -> str:
    days = summary["days"]
    retrieval = summary["retrieval"]
    queue = summary["queue"]

    lines = [
        f"KPI-СВОДКА за {days} дн. (журнал: {summary['journal']})",
        f"  событий в окне: {summary['events']}",
        "",
        "1. Inbox-разметка (Understanding)",
        f"   применено разметок: {summary['inbox']['applied']}",
        "   (v1-приближение: правка после apply не детектируется — считаем факт "
        "применения)",
        "",
        "2. Память (Memory)",
        f"   retrieval-прогонов: {retrieval['runs']}, с находками (hits>0): "
        f"{retrieval['with_hits']} ({_pct(retrieval['with_hits'], retrieval['runs'])})",
        "   (v1-приближение: «с первого раза» не детектируется — считаем прогоны "
        "и наполненность)",
    ]

    ok = queue["approved"] + queue["auto"]
    lines += [
        "",
        "3. Очередь подтверждений (кривая доверия, AUTON-1)",
        f"   решений: {queue['decisions']} — approved: {queue['approved']}, "
        f"auto: {queue['auto']}, "
        f"rejected: {queue['rejected']}",
        f"   без reject: {ok} ({_pct(ok, queue['decisions'])})",
    ]

    by_resolver = summary["links"]["applied_by_resolver"]
    if by_resolver:
        parts = ", ".join(f"{r}: {n}" for r, n in sorted(by_resolver.items()))
        lines += ["", f"Дополнительно: применено ссылок — {parts}"]

    lines += [
        "",
        "4. Читаемость дайджеста — в v1 не измеряется (нет сигнала; позже).",
    ]
    return "\n".join(lines)


def render_usage(usage: dict[str, Any], *, full: bool = False) -> str:
    """WAVE1-MEASURE п.2: употребление поверхности (``core.metrics.usage_summary``) текстом."""
    cov = usage.get("coverage_days") or 0
    since = usage.get("observed_since")
    started = f"с {str(since)[:10]} ({cov:.0f} дн)" if since else "не начата"
    lines = [
        "",
        f"5. Употребление за {usage['days']} дн (телеметрия копится {started})",
        f"   вызовов инструментов: {usage['calls']}, открытий вкладок/секций пульта: "
        f"{usage['ui_opens']}",
    ]
    if usage.get("hosts"):
        lines.append("   вызовы по хостам: " + ", ".join(
            f"{r['host']}[{r['surface']}] {r['calls']}" for r in usage["hosts"]))
    if "unused_tools" in usage:
        lines.append(f"   инструментов без вызовов: {len(usage['unused_tools'])} "
                     f"из {usage.get('tools_total', '?')}")
    lines.append(f"   вкладок/секций без открытий: {len(usage['unused_ui'])} "
                 f"из {usage.get('ui_total', '?')}")
    if full:
        for row in usage["tools"][:25]:
            lines.append(f"     {row['tool']}: {row['calls']} (ошибок {row['errors']}, "
                         f"p50 {row['p50_ms']} мс, max {row['max_ms']} мс)")
        if usage.get("unused_tools"):
            lines.append("   без вызовов: " + ", ".join(usage["unused_tools"]))
        if usage["unused_ui"]:
            lines.append("   без открытий: " + ", ".join(usage["unused_ui"]))
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-kpi",
        description="Сводка метрик когнитивной нагрузки из журнала событий.",
    )
    parser.add_argument(
        "--days", type=int, default=7, help="Окно сводки в днях (default 7)."
    )
    parser.add_argument(
        "--usage", action="store_true",
        help="Добавить употребление за 30 дн: молчащие инструменты и секции (полные списки).",
    )
    args = parser.parse_args(argv)
    load_env()

    text = render_summary(summarize(max(1, args.days)))
    if args.usage:
        text += "\n" + render_usage(_usage(), full=True)
    print(text)
    return 0


def _usage() -> dict[str, Any]:
    """Употребление с реестром инструментов (``TOOL_NAMES`` MCP-слоя — core его не знает)."""
    import importlib.util
    from pathlib import Path

    from core.metrics import usage_summary

    known = None
    path = Path(__file__).resolve().parents[1] / "mcp-server" / "server.py"
    spec = importlib.util.spec_from_file_location("dt_kpi_server", path)
    if spec and spec.loader:
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        known = mod.TOOL_NAMES
    return usage_summary(30, known_tools=known)


if __name__ == "__main__":
    raise SystemExit(main())
