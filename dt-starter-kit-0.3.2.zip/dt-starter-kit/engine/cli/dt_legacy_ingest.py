"""dt-legacy-ingest — render legacy files into vault/_legacy/ notes (interface layer).

Thin wrapper over core.legacy.ingest.ingest_corpus: discovers the legacy corpus,
extracts/normalizes (cached), dedups, and writes/updates/drops ``_legacy/*.md``
notes incrementally. It does NOT embed — run ``dt_index`` afterwards to index the
new/changed notes. CLI depends on core, never the reverse (architecture §8).

Usage:
    uv run python cli/dt_legacy_ingest.py [--roots P1:P2] [--scope incremental|full]
                                          [--dry-run] [--no-link] [--vault PATH]
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# cli/ is not an importable package; put our own dir on sys.path so the shared
# _env helper imports cleanly whether run as `python cli/dt_legacy_ingest.py`
# (cli/ already on path[0]) or loaded by path from a test (matches dt_sync.py).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import (
    default_vault_path,
    legacy_dryrun_report_path,
    legacy_roots,
)
from core.legacy.ingest import backfill_hashes, ingest_corpus


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-legacy-ingest",
        description="Render legacy files into vault/_legacy/ markdown notes.",
    )
    parser.add_argument(
        "--vault",
        type=Path,
        default=default_vault_path(),
        help="Path to the vault (default: sibling vault/ or $DT_VAULT_PATH).",
    )
    parser.add_argument(
        "--roots",
        default=None,
        help="Override legacy roots (':'-separated abs paths; default $DT_LEGACY_ROOTS).",
    )
    parser.add_argument(
        "--scope",
        choices=("incremental", "full"),
        default="incremental",
        help="incremental (default): only new/changed sources; full: re-render all.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Show the disposition without writing notes, cache, or manifest.",
    )
    parser.add_argument(
        "--no-link",
        action="store_true",
        default=False,
        help="Reserved: skip hub auto-linking (linking lands in stage 5).",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=None,
        help="Write a per-bucket diagnostic report (path lists per disposition) "
        "here. Defaults on for --dry-run (.derived/legacy_dryrun_report.txt).",
    )
    parser.add_argument(
        "--backfill-hashes",
        action="store_true",
        default=False,
        help="One-off: stamp source_content_hash (byte-hash) onto existing manifest "
        "entries by reading bytes (no extraction), then exit. Makes a later folder "
        "move/rename recognised by content instead of re-imported (INGEST-DEDUP).",
    )
    args = parser.parse_args(argv)
    load_env()  # engine/.env → os.environ (DT_LEGACY_* knobs) before config reads

    roots = (
        [Path(p) for p in args.roots.split(":") if p.strip()]
        if args.roots
        else legacy_roots()
    )
    if not roots:
        print(
            "No legacy roots configured. Set DT_LEGACY_ROOTS in .env or pass --roots.",
        )
        return 2

    if args.backfill_hashes:
        print(f"Backfilling source_content_hash{' (DRY-RUN)' if args.dry_run else ''} …")
        counts = backfill_hashes(roots, dry_run=args.dry_run, log=print)
        print(
            "Backfill: "
            f"total={counts['total']} filled={counts['filled']} "
            f"already={counts['already']} skipped(missing)={counts['skipped_missing']}"
        )
        return 0

    mode = f"{args.scope}{' DRY-RUN' if args.dry_run else ''}"
    print(f"Legacy ingest ({mode}) → {args.vault}/_legacy")
    print(f"Roots: {', '.join(str(r) for r in roots)}")

    # Default the diagnostic report on for dry runs (eyeball before a big ingest).
    report_path = args.report
    if report_path is None and args.dry_run:
        report_path = legacy_dryrun_report_path()

    from core.ingress.run import ingress_run

    with ingress_run("legacy", dry_run=args.dry_run) as run:  # INGRESS-1: run_id + итог прогона
        stats = ingest_corpus(
            args.vault,
            roots,
            scope=args.scope,
            dry_run=args.dry_run,
            link=not args.no_link,
            report_path=report_path,
        )
        run.finish(stats)

    print(
        "Disposition: "
        f"new={stats.new} changed={stats.changed} relocated={stats.relocated} "
        f"unchanged={stats.unchanged} "
        f"deleted={stats.deleted} | duplicate={stats.duplicate} "
        f"needs_ocr={stats.needs_ocr} needs_conversion={stats.needs_conversion} "
        f"unsupported={stats.skipped_unsupported} "
        f"errors={stats.errors} | skipped(exclude)={stats.skipped_exclude} "
        f"skipped(privacy)={stats.skipped_privacy}"
    )
    print(f"Notes (representatives): {stats.notes_total} in {stats.elapsed_s:.1f}s")
    if not args.no_link and not args.dry_run:
        print(
            f"Navigation post-pass: mocs={stats.mocs} "
            f"hub-candidates={stats.hub_candidates} curated-backlinks={stats.backlinks} "
            "(per-note [[hub]]-ссылки — отдельным проходом dt_link.py, Phase 9)"
        )
        if stats.backlinked:
            print("  back-linked curated notes: " + ", ".join(stats.backlinked))
    if stats.examples:
        print("Examples:")
        for rel in stats.examples:
            print(f"  - {rel}")
    if stats.report_path:
        print(f"Diagnostic report: {stats.report_path}")
    if not args.dry_run:
        print("Next: run `uv run python cli/dt_index.py` to index the new/changed notes.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
