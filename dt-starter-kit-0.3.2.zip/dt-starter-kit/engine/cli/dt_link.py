"""dt-link — unified linking pass over the vault (Phase 9, stage 2).

One entry point for both resolver layers on top of the shared review queue
(``.derived/link_proposals.jsonl``) and the Phase-6 apply step:

* ``--resolver deterministic`` (default) — exact catalog matches
  (ids / aliases / counterparty domains → existing hubs) enqueued at score 1.0;
  no index required. With ``--auto`` the deterministic rows are approved and
  written into the notes in the same run (``## Связано`` + journal) — the
  auto-apply decision is this CLI flag, never a config knob. Without ``--auto``
  they stay ``pending`` for a threshold approve.
* ``--resolver semantic`` — Phase-6 embedding candidates over the same scope
  (``spine`` targets by default; client hubs excluded exactly as before);
  always human-in-the-loop: rows land ``pending``.
* ``--approve-above SCORE`` — bulk-approve pending rows with score ≥ SCORE
  (deterministic rows are 1.0 by construction, so ``--approve-above 1.0``
  is the "queue with a high threshold" alternative to ``--auto``; it also
  triages the semantic backlog).

``--scope`` selects the notes directly (re-runnable, idempotent):
``all`` / ``legacy`` / ``correspondence`` / ``curated`` / ``<note-id>`` /
``<folder>``. ``--dry-run`` (default) computes and prints everything but
persists nothing; ``--apply`` saves the queue, writes approved links and
appends the journal. CLI depends on core, never the reverse (architecture §8).

Schedulable (Phase 9 этап 4, принцип 11): layer/folder scopes go through a
stat-scan against ``.derived/link_scan.json`` — unchanged notes are not even
re-read (steady-state пробег дёшев), прогресс ``[link] X/TOTAL | proposed P |
applied A | ~eta``, манифест чекпойнтится, SIGINT/SIGTERM останавливают
gracefully (exit 130) и повторный запуск ПРОДОЛЖАЕТ, а не начинает заново.
``--rescan`` игнорирует отпечатки (полный перескан). Манифест двигается только
на ``--apply`` — dry-run строит план, ничего не фиксируя.

Usage:
    uv run python cli/dt_link.py --scope correspondence                # план
    uv run python cli/dt_link.py --scope legacy --auto --apply         # det → в заметки
    uv run python cli/dt_link.py --resolver both --scope 02-knowledge --apply
    uv run python cli/dt_link.py --approve-above 0.75 --apply          # разбор очереди
    uv run python cli/dt_link.py --scope all --auto --apply --rescan   # форс-перескан
"""

from __future__ import annotations

import argparse
import os
import signal
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import (
    default_vault_path,
    link_proposals_path,
    link_scan_manifest_path,
)
from core.linking.apply import apply_approved
from core.linking.engine import (
    RESOLVER_DETERMINISTIC,
    RESOLVER_SEMANTIC,
    approve_pending,
    propose_deterministic,
    scan_deterministic,
    select_scope,
)
from core.linking.propose import LinkProposalQueue, propose_for_notes

# Layer scopes go through the schedulable scan (manifest-checkpointed); an
# explicit note id falls back to the direct in-memory path.
_LAYER_SCOPES = ("all", "legacy", "correspondence", "curated")

# Graceful SIGINT/SIGTERM (принцип 11): the handlers flip a flag the scan polls
# per note, so the current checkpoint is flushed and the run stays resumable.
_STOP = {"flag": False}


def _install_signal_handlers() -> None:
    def _handler(signum: int, frame: object) -> None:
        _STOP["flag"] = True

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, _handler)
        except (ValueError, OSError):
            pass  # not the main thread (test runner) — skip silently


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-link",
        description="Unified linking pass: deterministic/semantic propose + apply.",
    )
    parser.add_argument(
        "--resolver",
        default=RESOLVER_DETERMINISTIC,
        choices=(RESOLVER_DETERMINISTIC, RESOLVER_SEMANTIC, "both"),
        help="Resolver layer(s) to run (default: deterministic — no index needed).",
    )
    parser.add_argument(
        "--scope",
        default="all",
        help="all | legacy | correspondence | curated | <note-id> | <folder>.",
    )
    parser.add_argument(
        "--auto",
        action="store_true",
        default=False,
        help="Auto-approve deterministic exact matches (they are applied on --apply; "
        "without this flag they stay pending in the queue).",
    )
    parser.add_argument(
        "--approve-above",
        type=float,
        default=None,
        metavar="SCORE",
        help="Bulk-approve pending proposals (any resolver) with score ≥ SCORE.",
    )
    parser.add_argument(
        "--min-score", type=float, default=None,
        help="Semantic cosine floor (propose).",
    )
    parser.add_argument(
        "--topn", type=int, default=None, help="Semantic: max targets per source.",
    )
    parser.add_argument(
        "--target-filter",
        default="spine",
        choices=("spine", "curated", "hub", "all"),
        help="Semantic eligible targets (default: spine — client hubs excluded).",
    )
    parser.add_argument(
        "--no-rationale", action="store_true", default=False,
        help="Write bare links without the rationale tail.",
    )
    parser.add_argument(
        "--rescan", action="store_true", default=False,
        help="Ignore the scan-manifest fingerprints (full rescan; fingerprints "
        "are refreshed on --apply).",
    )
    parser.add_argument(
        "--progress-every", type=int, default=50,
        help="Progress line every N notes/sources (default 50).",
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--dry-run", dest="dry_run", action="store_true", default=True,
        help="Compute and print the plan; persist nothing (default).",
    )
    group.add_argument(
        "--apply", dest="dry_run", action="store_false",
        help="Save the queue, write approved links, append the journal.",
    )
    args = parser.parse_args(argv)
    load_env()
    _STOP["flag"] = False  # fresh run — an earlier in-process interrupt is history
    _install_signal_handlers()

    vault = default_vault_path()
    scope = (args.scope or "all").strip().strip("/")
    use_scan = scope in _LAYER_SCOPES or (vault / scope).is_dir()

    queue = LinkProposalQueue.load(link_proposals_path())

    det = None
    notes_label = "—"
    if args.resolver in (RESOLVER_DETERMINISTIC, "both"):
        if use_scan:
            # Schedulable путь (принцип 11): stat-скан по манифесту, чекпойнты,
            # resume, graceful stop. Dry-run читает манифест, но не двигает его.
            det = scan_deterministic(
                vault,
                queue=queue,
                scope=scope,
                manifest_path=link_scan_manifest_path(),
                save_manifest=not args.dry_run,
                rescan=args.rescan,
                append_path=None if args.dry_run else link_proposals_path(),
                log=print,
                progress_every=args.progress_every,
                should_stop=lambda: _STOP["flag"],
            )
            notes_label = f"{det.sources + det.skipped_unchanged} (скан)"
            if det.stopped:
                if not args.dry_run:
                    queue.save()
                print(
                    "[link] прервано (SIGINT/SIGTERM) — чекпойнт и очередь "
                    "сохранены; повторный запуск продолжит с места остановки."
                )
                return 130
        else:  # явный note-id — прямой путь без манифеста
            notes = select_scope(vault, scope)
            if not notes:
                print(f"нет заметок по scope {args.scope!r}.")
                return 0
            notes_label = str(len(notes))
            det = propose_deterministic(notes, vault_path=vault, queue=queue)

    sem = None
    if args.resolver in (RESOLVER_SEMANTIC, "both"):
        notes = select_scope(vault, scope)
        if not notes and det is None:
            print(f"нет заметок по scope {args.scope!r}.")
            return 0
        notes_label = str(len(notes))
        # Incremental append on --apply (crash-durable, like dt-link-propose);
        # the final queue.save() below rewrites the file deduplicated.
        sem = propose_for_notes(
            notes,
            queue=queue,
            min_score=args.min_score,
            topn=args.topn,
            target_filter=args.target_filter,
            resume=True,
            append_path=None if args.dry_run else link_proposals_path(),
            log=print,
            progress_every=args.progress_every,
            total=len(notes),
        )

    approved: list[str] = []
    if args.auto:
        approved += approve_pending(queue, resolver=RESOLVER_DETERMINISTIC)
    if args.approve_above is not None:
        approved += approve_pending(queue, min_score=args.approve_above)

    if not args.dry_run:
        queue.save()

    applied = None
    if approved:
        applied = apply_approved(
            queue,
            vault,
            dry_run=args.dry_run,
            include_rationale=not args.no_rationale,
        )

    head = "ПРИМЕНЕНО" if not args.dry_run else "ПЛАН (dry-run — ничего не сохранено)"
    print(f"{head}\n  scope: {args.scope} | resolver: {args.resolver} | заметок: {notes_label}")
    if det is not None:
        print(
            f"  deterministic: источников {det.sources} (мета пропущено "
            f"{det.skipped_sources}, без изменений {det.skipped_unchanged}) | "
            f"матчей {det.matched} | новых {det.added} | "
            f"апгрейд semantic→det {det.upgraded} | уже в очереди {det.duplicates} | "
            f"уже слинковано {det.already_linked} | цель вне правил {det.skipped_targets}"
        )
        print(
            f"[link] итог: proposed {det.added + det.upgraded} | "
            f"applied {applied.applied if applied is not None else 0}"
        )
        for p in det.proposals[:20]:
            print(f"    1.000 {p.source_note} → [[{p.target_note}]]  ({p.evidence_snippet})")
        if len(det.proposals) > 20:
            print(f"    … ещё {len(det.proposals) - 20}")
    if sem is not None:
        print(
            f"  semantic: источников {sem.sources} | кандидатов {sem.candidates} | "
            f"новых {sem.added} | дубли {sem.duplicates}"
        )
    if approved:
        print(f"  одобрено: {len(approved)}")
    if applied is not None:
        print(
            f"  вставлено ссылок: {applied.applied} | уже на месте: "
            f"{applied.already_present} | источник не найден: {applied.missing_source} | "
            f"затронуто заметок: {len(set(applied.touched_notes))}"
        )
    print(f"  очередь: {link_proposals_path()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
