"""dt lint - линт знаний: детекторы -> находки (KNOWLEDGE-LINT-1, interface layer).

Тонкая обертка над :func:`core.lint.run.run_lint`: четыре детерминированных правила
(``fact_conflict``, ``hub_stale``, ``orphan``, ``duplicate``; без LLM) читают vault, стор фактов,
манифест индекса и ``link_proposals`` и кладут находки в ``.derived/lint_findings.jsonl``; решения
- карточками вида ``lint`` в очереди пульта (``pult_cards``/``pult_card_decide``), запись в vault
только по решению человека. Бюджет ``DT_LINT_BUDGET_S`` (120 с) - не уложились: честный ``partial``.

Usage:
    uv run python cli/dt.py lint --dry-run            # что нашли бы; НИЧЕГО не пишет
    uv run python cli/dt.py lint --rule orphan        # одно правило, с записью находок
    uv run python cli/dt.py lint --step               # шаг ночной цепочки: счетчики, код 0
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.lint.registry import detector_rule_names
from core.lint.run import run_lint

_SHOW = 15  # строк находок на правило в обычном выводе (--all - все)


def render(summary: dict[str, Any], *, details: bool, show_all: bool = False) -> str:
    """Сводка прогона: счетчики по правилам (всегда) и строки находок (``details``)."""
    mode = "DRY-RUN (ничего не записано)" if summary["dry_run"] else "прогон"
    lines = [f"ЛИНТ ЗНАНИЙ ({mode}) - {summary['elapsed_s']:.1f} с"
             + (", ЧАСТИЧНО: бюджет вышел" if summary["partial"] else "")]
    by_rule: dict[str, list[dict[str, Any]]] = {}
    for f in summary.get("findings", []):
        by_rule.setdefault(f["rule"], []).append(f)
    for name, e in summary["rules"].items():
        flags = []
        if e["partial"]:
            flags.append("partial")
        if e["skipped"]:
            flags.append("пропущено")
        tail = f" [{', '.join(flags)}]" if flags else ""
        lines.append(
            f"  {name:14} найдено {e['found']:>4} (новых {e['new']}, известных {e['updated']}, "
            f"под стопом {e['stopped']}, решенных {e['kept']}), снято {e['resolved']}, "
            f"просмотрено {e['scanned']}, {e['elapsed_s']:.1f} с{tail}"
            + (f" - {e['note']}" if e["note"] else ""))
        if details:
            rows = by_rule.get(name, [])
            for f in rows if show_all else rows[:_SHOW]:
                lines.append(f"      - {f['title']} - {f['reason']}")
            if not show_all and len(rows) > _SHOW:
                lines.append(f"      … и еще {len(rows) - _SHOW} (--all)")
    pend = summary.get("pending") or {}
    lines.append("  ждут решения: " + (", ".join(f"{k} {v}" for k, v in sorted(pend.items()))
                                       or "нет"))
    if summary.get("unknown_rules"):
        lines.append(f"  неизвестные правила пропущены: {', '.join(summary['unknown_rules'])}")
    if not summary["dry_run"]:
        lines.append("  (решение - карточки вида lint: pult_cards / pult_card_decide)")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt lint", description="Линт знаний: противоречия, устаревшие хабы, сироты, дубли.")
    parser.add_argument("--rule", action="append", choices=list(detector_rule_names()),
                        help="Только это правило (можно несколько раз); по умолчанию все.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Показать находки, ничего не записывая (ни стор, ни сводку).")
    parser.add_argument("--vault", type=Path, default=None)
    parser.add_argument("--budget", type=float, default=None,
                        help="Бюджет прогона, с (по умолчанию DT_LINT_BUDGET_S = 120; 0 - без).")
    parser.add_argument("--json", action="store_true", help="Сводка JSON (с находками).")
    parser.add_argument("--all", action="store_true",
                        help="Все находки, а не первые 15 на правило.")
    parser.add_argument("--step", action="store_true",
                        help="Шаг цепочки dt-sync: только счетчики (без названий), код всегда 0.")
    args = parser.parse_args(argv)
    load_env()

    from core.lint.env import LintEnv

    env = LintEnv(vault=args.vault, budget_s=args.budget)
    try:
        summary = run_lint(env, rules=args.rule, dry_run=args.dry_run)
    except Exception as exc:  # noqa: BLE001 - линт не роняет цепочку: причина в лог, код 0
        import logging

        logging.getLogger(__name__).warning("lint не отработал: %s", exc)
        print(f"lint: не отработал ({type(exc).__name__}) - находки не обновлены")
        return 0 if args.step else 1
    if args.json:
        print(json.dumps(summary, ensure_ascii=False, indent=1))
    else:
        print(render(summary, details=not args.step, show_all=args.all))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
