"""dt mail-filter — правила фильтра почты (MAIL-FILTER-1): ``explain`` и ``lint``. Без сети.

``explain --from X --subject Y [--folder inbox|sent]`` печатает решение и сработавшее правило
(``noise_sender (rule: senders/b2b_invoice@acme.kz)`` / ``pass``) - тем же ``decide``, что и
инжест. ``lint`` проверяет ``_system/mail-filter.yaml``: yaml валиден, правила не пустые, ``allow``
не пересекается с ``senders``; код выхода 1 при ошибках (замечания - 0).

Usage:
    uv run python cli/dt.py mail-filter explain --from b2b_invoice@acme.kz --subject "Счет"
    uv run python cli/dt.py mail-filter lint [--file PATH]
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config import default_vault_path, mail_filter_path
from core.legacy.mail_filter import decide, lint_file, load_rules


def _explain(args: argparse.Namespace) -> int:
    rules = load_rules(args.vault)
    for w in rules.warnings:
        print(f"! {w.get('code')}: {w.get('reason')}", file=sys.stderr)
    verdict = decide(
        {"from": args.sender, "subject": args.subject}, inbox=args.folder == "inbox", rules=rules
    )
    print(verdict.render())
    return 0


def _lint(args: argparse.Namespace) -> int:
    target = Path(args.file) if args.file else mail_filter_path(args.vault)
    if not target.is_file():
        print(f"файла правил нет: {target} - работает запасной набор из кода "
              "(core/legacy/mail_filter.py)")
        return 0
    errors, notes = lint_file(target)
    for e in errors:
        print(f"ОШИБКА  {e}")
    for n in notes:
        print(f"замечание  {n}")
    if errors:
        print(f"{target}: {len(errors)} ошибок")
        return 1
    rules = load_rules(path=target)
    print(f"{target}: ok - правил {rules.total()} (allow {len(rules.allow)}, senders "
          f"{len(rules.senders)}, subject_prefix {len(rules.subject_prefix)}, subject_regex "
          f"{len(rules.subject_regex)}, senders_weak {len(rules.senders_weak)}, subject_word "
          f"{len(rules.subject_word)})")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt mail-filter", description=__doc__.split("\n")[0])
    parser.add_argument("--vault", type=Path, default=None,
                        help="путь к vault (по умолчанию - боевой)")
    sub = parser.add_subparsers(dest="cmd", required=True)
    ex = sub.add_parser("explain", help="решение по письму и сработавшее правило")
    ex.add_argument("--from", dest="sender", default="",
                    help="отправитель (адрес или «Имя <адрес>»)")
    ex.add_argument("--subject", default="", help="тема письма")
    ex.add_argument("--folder", choices=("inbox", "sent"), default="inbox")
    ex.set_defaults(func=_explain)
    li = sub.add_parser("lint", help="проверить mail-filter.yaml")
    li.add_argument("--file", default=None, help="другой файл правил (по умолчанию vault/_system)")
    li.set_defaults(func=_lint)
    args = parser.parse_args(argv)
    if args.vault is None:
        args.vault = default_vault_path()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
