"""dt-mail-repair — ремонт корпуса почты и пересчёт потребителей (MAIL-THREAD-1, P0).

Сдвиг массивов моста положил ~200 писем во ВТОРОЙ тред и испортил поля страницы
(conv/subject/date). Мост и инвариант инжеста исправлены — теперь разбираем накопленное.
Порядок работы (контракт §9 п.11г):

    1. uv run python cli/dt_mail_repair.py                    # dry-run (по умолчанию) → отчёт
    2. uv run python cli/dt_mail_repair.py --apply --limit 3  # канарейка
    3. uv run python cli/dt_mail_repair.py --apply            # полный + пересчёт потребителей

MAIL-LOCK-1: ``--apply`` (и ``--reconcile --apply``) берет ``dt-sync.lock`` - занят: ждет ``--wait``
секунд (дефолт 600), ``--no-wait`` - отказ ``sync_busy`` с именем держателя (exit 4). Dry-run лок не
берет. ``--reconcile [--apply]`` сверяет индекс манифеста и сайдкары: снимает сироты индекса, чьи
msg_id все в памяти «отказано» (след гонки писателей 29.10), остальные - в отчет, не трогает.

Источник правды — ИСПРАВЛЕННОЕ чтение метаданных Outlook (настоящий conversationId
каждого письма) и per-message ``fetch_by_ids`` для даты/темы/адресов. ``--offline`` —
запасное правило по теме (неоднозначные уходят в отчёт, не трогаются). После ``--apply``
команда пересчитывает потребителей замусоренных метаданных: пере-линковка с отзывом
неверных связей, ``hub_scan`` (applied-хабы от затронутых тредов — в отчёт, не трогаются),
список выходов, чьи ``sources.md`` ссылаются на затронутые треды. Переиндекс затронутых
заметок — ``--reindex`` (или ``dt_index``). Живая проверка «Требует внимания» — после.
CLI зависит от core, не наоборот. Без LLM.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import default_vault_path, outlook_ingest_manifest_path, timetta_mirror_path
from core.legacy.mail_repair import AssignError, bridge_fetch, bridge_truth, repair_corpus
from core.legacy.mail_repair_post import outputs_referencing, relink_threads, rescan_hubs
from core.operational.outlook_bridge import OutlookBridge, OutlookUnavailableError


def _deals() -> list[dict]:
    try:
        from core.operational import orbit
        from core.operational.timetta.mirror import MirrorStore

        return orbit.visible(
            MirrorStore(timetta_mirror_path()).all("deals"), orbit.enabled_rings()
        )
    except Exception:  # noqa: BLE001 — нет зеркала → скан только по заметкам
        return []


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-mail-repair",
        description="Вернуть сообщения почты в свои треды и пересчитать потребителей.",
    )
    parser.add_argument("--vault", type=Path, default=default_vault_path())
    parser.add_argument("--apply", action="store_true", default=False,
                        help="Записать изменения (по умолчанию dry-run: только отчёт).")
    parser.add_argument("--limit", type=int, default=None,
                        help="Канарейка: взять в работу первые N сообщений.")
    parser.add_argument("--offline", action="store_true", default=False,
                        help="Без Outlook: запасное правило по теме (неоднозначные — в отчёт).")
    parser.add_argument("--drop-emptied", action="store_true", default=False,
                        help="Удалять треды, целиком состоявшие из переехавших сообщений.")
    parser.add_argument(
        "--assign", action="append", default=[], metavar="MSG_ID=CONV",
        help="Явное решение человека: письмо остаётся ТОЛЬКО в этом треде (conv:ID или ID), "
        "из остальных удаляется; для писем, которых мост не подтверждает. Повторяемый. "
        "Пишется штатным рендером + строка аудита (mail_repair_audit.jsonl).",
    )
    parser.add_argument("--no-post", action="store_true", default=False,
                        help="Не пересчитывать потребителей (линковка/hub_scan) после apply.")
    parser.add_argument("--reindex", action="store_true", default=False,
                        help="После apply — инкрементальный переиндекс (иначе: dt_index).")
    parser.add_argument("--report", type=Path, default=None,
                        help="JSON-отчёт (по умолчанию .derived/mail_repair_reports/).")
    parser.add_argument("--reconcile", action="store_true", default=False,
                        help="Сверить индекс манифеста и сайдкары: снять сироты, чьи msg_id все в "
                             "памяти «отказано»; остальные - в отчет (dry-run без --apply).")
    parser.add_argument("--wait", type=float, default=None, metavar="SECONDS",
                        help="--apply ждет занятый dt-sync.lock столько секунд (дефолт 600 или "
                             "$DT_MAIL_LOCK_WAIT_S).")
    parser.add_argument("--no-wait", action="store_true", default=False,
                        help="Не ждать лок: занят - отказ sync_busy и имя держателя (exit 4).")
    args = parser.parse_args(argv)
    load_env()

    if not args.apply:
        return _dispatch(args)  # dry-run ничего не пишет в манифест/заметки - лок не нужен
    from core.legacy.mail_lock import mail_writer_lock, resolve_wait_s
    from core.runlock import RunLockBusy

    try:
        with mail_writer_lock(
            "reconcile" if args.reconcile else "repair",
            wait_s=resolve_wait_s(args.wait, no_wait=args.no_wait),
        ):
            return _dispatch(args)
    except RunLockBusy as exc:
        print(str(exc))
        return 4


def _run_reconcile(args: argparse.Namespace) -> int:
    from core.adapters import StoreUnavailableError
    from core.legacy.mail_reconcile import reconcile_corpus

    try:
        rep = reconcile_corpus(dry_run=not args.apply)
    except StoreUnavailableError as exc:
        print(f"store_unavailable: {exc}")
        return 3
    mode = "APPLY" if args.apply else "DRY-RUN"
    print(f"Mail reconcile ({mode}): тредов в индексе {rep.threads}")
    print(f"Записей без сайдкара: {rep.entries_without_sidecar} - все msg_id в «отказано»: "
          f"{rep.dropped} ({'сняты' if args.apply else 'снять'}), остальные: {rep.left} "
          "(в отчет, не тронуты)")
    for key in rep.dropped_examples:
        print(f"  · снять {key}")
    for row in rep.left_examples:
        print(f"  ? оставлен {row['thread']}: сообщений {row['msgs']}, не отказано "
              f"{row['not_refused']}")
    print(f"Сайдкаров без записи: {rep.sidecars_without_entry} (в отчет, не тронуты)")
    for name in rep.sidecar_examples:
        print(f"  ? {name}")
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(
            json.dumps(rep.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"Отчёт: {args.report}")
    if not args.apply:
        print("Это dry-run. Дальше: --reconcile --apply.")
    return 0


def _dispatch(args: argparse.Namespace) -> int:
    """Тело CLI после разбора аргументов - под локом, когда команда пишет."""
    if args.reconcile:
        return _run_reconcile(args)

    assign: dict[str, str] = {}
    for item in args.assign:
        mid, sep, conv = item.partition("=")
        if not sep or not mid.strip() or not conv.strip():
            print(f"--assign: ожидалось MSG_ID=CONV, получено {item!r}")
            return 2
        assign[mid.strip()] = conv.strip()

    truth = fetch = None
    if not args.offline and not assign:
        bridge = OutlookBridge(require_preflight=True)
        truth, fetch = bridge_truth(bridge), bridge_fetch(bridge)
    mode = "APPLY" if args.apply else "DRY-RUN"
    lim = f" limit={args.limit}" if args.limit is not None else ""
    print(f"Mail repair ({mode}{lim}) → {args.vault}/_legacy/correspondence", flush=True)
    try:
        rep = repair_corpus(
            args.vault, dry_run=not args.apply, limit=args.limit,
            truth=truth, fetch=fetch, drop_emptied=args.drop_emptied, assign=assign or None,
        )
    except AssignError as exc:
        print(f"--assign отклонён: {exc}")
        return 2
    except OutlookUnavailableError as exc:
        print(f"Outlook unavailable — nothing changed: {exc}\n(повторите с --offline)")
        return 3

    data = rep.to_dict()
    data["outputs_to_review"] = outputs_referencing(args.vault, rep.affected)
    if args.apply and rep.affected and not args.no_post:
        paths = {a["note_path"] for a in rep.affected}
        data["relink"] = relink_threads(args.vault, rep.affected, dry_run=False)
        data["hub_scan"] = rescan_hubs(args.vault, paths, dry_run=False, deals=_deals())
    elif rep.affected:
        data["hub_scan"] = rescan_hubs(
            args.vault, {a["note_path"] for a in rep.affected}, dry_run=True
        )
    if args.apply and args.reindex and rep.affected:
        from core.retrieval.index import reindex

        stats = reindex(args.vault, full=False)
        data["reindex"] = {"changed": stats.changed, "new": stats.new, "deleted": stats.deleted}

    out = args.report or (
        outlook_ingest_manifest_path().parent / "mail_repair_reports"
        / f"{'apply' if args.apply else 'dryrun'}-{time.strftime('%Y%m%d-%H%M%S')}.json"
    )
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"Источник правды: {rep.truth_source}. msg_id в >1 треде: {rep.dup_messages} "
          f"({rep.dup_threads} тредов); не в своём треде по мосту: {rep.misplaced_total}; "
          f"нет в чтении моста: {rep.unverifiable}")
    print(f"Взято в работу: {rep.processed} | перенос/удаление: {len(rep.resolved)} | "
          f"неоднозначных: {len(rep.ambiguous)} | опустошили бы тред: {len(rep.would_empty)}")
    r = rep.refresh
    if r:
        print(f"Метаданные из per-message чтения ({r.get('source')}): сообщений "
              f"{r.get('messages')}, подтверждено {r.get('verified')}, не найдено "
              f"{r.get('unverified')}, исправлено полей {r.get('changed')}")
    for a in rep.assigned:
        print(f"  assign {a['msg_id']} → {a['target']}: {a['status']}")
    verb = "Переписано" if args.apply else "Было бы переписано"
    print(f"{verb} тредов: {len(rep.rewritten)}; переименовано файлов: {len(rep.renamed)}; "
          f"удалено пустых: {len(rep.dropped)}")
    for row in rep.rewritten[:5]:
        print(f"  - {row['thread']}: -{len(row['removed'])} +{len(row['added'])}, "
              f"осталось {row['count_after']}")
    if "relink" in data:
        rl = data["relink"]
        print(f"Линковка: отозвано {len(rl['revoked'])} "
              f"(семантических {len(rl['semantic_revoked'])}), "
              f"возвращено {rl['kept_reapplied']}, предложено новых {rl['newly_proposed']}, "
              f"записано в заметки {rl['applied']}")
    hubs = data.get("hub_scan", {})
    if hubs.get("applied_hubs_only_from_affected") or hubs.get("applied_hubs_partly_from_affected"):
        print(f"⚠ applied-хабов от затронутых тредов: только от них "
              f"{len(hubs['applied_hubs_only_from_affected'])}, частично "
              f"{len(hubs['applied_hubs_partly_from_affected'])} — на решение К. (не тронуты)")
    if data["outputs_to_review"]:
        n_out = len(data["outputs_to_review"])
        print(f"⚠ выходы со ссылкой на затронутые треды ({n_out}) — на ревизию К.:")
        for o in data["outputs_to_review"]:
            print(f"  · {o['output']}  ← {', '.join(o['threads'])}")
    print(f"Отчёт: {out}")
    if args.apply and not args.reindex:
        print("Дальше: `uv run python cli/dt_index.py` (переиндекс), затем живая проверка "
              "«Требует внимания».")
    elif not args.apply:
        print("Это dry-run. Дальше: --apply --limit 3 (канарейка), затем --apply.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
