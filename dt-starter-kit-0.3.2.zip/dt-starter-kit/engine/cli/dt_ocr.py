"""dt-ocr — распознавание сканов (pdf без текстового слоя), OCR-1 (interface layer).

Тонкая обертка над :func:`core.ocr.run.run_ocr`: очередь (записи L1-кэша ``needs_ocr``; приватные по
пути/имени исключены ДО распознавания) -> движок (tesseract по умолчанию; ``DT_OCR_ENGINE=vision`` -
если установлен ``pyobjc-framework-Vision``) -> текстовый гард -> кэш ``.derived/ocr`` -> L1 и
манифест (заметка перерисуется следующим ingest: ``dt_ingest --route knowledge``).

Бюджет ``DT_OCR_BUDGET_S`` (дефолт 1800 с; ``--budget``) обрывает прогон между документами и между
страницами; SIGTERM/Ctrl-C останавливает на границе страницы. Распознанные страницы недоделанного
документа остаются в чекпойнте (``.derived/ocr/partial``), повторный запуск продолжает с первой
нераспознанной. Нет tesseract/gs -> строка ``unavailable`` с кодом, код выхода 0 (заглушки
остаются, доктор покажет причину). Источники только читаются; индекс не трогается.

Usage:
    uv run python cli/dt_ocr.py --dry-run             # очередь и оценка, OCR не запускается
    uv run python cli/dt_ocr.py --limit 20            # канарейка: 20 документов
    uv run python cli/dt_ocr.py --budget 600 --path-scope "2018-2023/00. Presale"
"""

from __future__ import annotations

import argparse
import os
import signal
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core import runlock
from core.config import sync_lock_path
from core.ocr.run import OcrStats, run_ocr
from core.ocr.settings import budget_s


def render(stats: OcrStats) -> str:
    """Анонимная сводка: только счетчики и имена правил (ни путей, ни текстов)."""
    mode = "DRY-RUN (OCR не запускался)" if stats.dry_run else "прогон"
    lines = [
        f"OCR ({mode}) — движок: {stats.engine or '—'} {stats.engine_version} "
        f"языки: {stats.lang or '—'}",
        f"  очередь:           {stats.queue_docs} документов / {stats.queue_pages} страниц",
        f"  отказано по пути:  {stats.refused_path} (приватность до OCR, не распознаются)",
    ]
    if stats.refused_reasons:
        lines.append("    правила: " + "; ".join(
            f"{k} {v}" for k, v in sorted(stats.refused_reasons.items(), key=lambda kv: -kv[1])))
    if stats.missing:
        lines.append(f"  нет на устройстве: {stats.missing} (iCloud dataless/файл исчез)")
    if stats.unavailable:
        lines.append(f"  unavailable ({stats.unavailable}): {stats.unavailable_reason}")
        lines.append("  заглушки остаются; после установки движка шаг подхватит очередь")
        return "\n".join(lines)
    if stats.dry_run:
        lines.append(f"  оценка:            ~{stats.est_s / 60:.0f} мин на всю очередь "
                     f"(бюджет прогона {stats.budget_s:.0f} с)")
        return "\n".join(lines)
    lines += [
        f"  распознано:        {stats.processed} док. / {stats.pages_done} стр. "
        f"(готово {stats.done}, низкая уверенность {stats.low}, "
        f"приватный текст не сохранен {stats.refused_text}, пусто {stats.empty})",
        f"  из кэша:           {stats.resumed} док.; из чекпойнта страниц: {stats.pages_resumed}",
        f"  сбоев:             {stats.failed}",
        f"  заметок на перерисовку: {stats.refreshed}  (дальше: dt_ingest --route knowledge)",
        f"  время:             {stats.elapsed_s:.1f} с (бюджет {stats.budget_s:.0f} с)",
    ]
    if stats.budget_hit:
        where = (f" на документе {stats.partial_doc}, страниц {stats.partial_pages_done}/"
                 f"{stats.partial_pages_total}" if stats.partial_doc else " между документами")
        lines.append(f"  ⏱ бюджет исчерпан{where}; повторный запуск продолжит")
    if stats.interrupted:
        lines.append("  ⏹ стоп по сигналу: сделанные страницы в чекпойнте; повтор доделает")
    if stats.docs_partial:
        lines.append(f"  частично распознано: {stats.docs_partial} док. (чекпойнт страниц)")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-ocr", description="Распознать сканы (pdf без текстового слоя) с бюджетом."
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="только очередь и оценка (OCR не запускается, ничего не пишется)")
    parser.add_argument("--limit", type=int, default=None,
                        help="не больше N документов (канарейка)")
    parser.add_argument("--budget", type=float, default=None,
                        help=f"бюджет прогона, секунд (DT_OCR_BUDGET_S, сейчас {budget_s():.0f})",
                        )
    parser.add_argument("--path-scope", default=None,
                        help="только source_path под этой папкой (относительно корня)")
    parser.add_argument("--quiet", action="store_true", help="без построчного прогресса")
    args = parser.parse_args(argv)
    load_env()

    stopping = {"v": False}

    def _request_stop(signum: int, _frame: object) -> None:
        stopping["v"] = True
        print(f"\n[ocr] сигнал {signum} — останавливаюсь на границе страницы…", flush=True)

    def _go() -> int:
        stats = run_ocr(
            dry_run=args.dry_run, limit=args.limit, budget=args.budget,
            should_stop=lambda: stopping["v"],
            on_progress=None if args.quiet else (lambda m: print(m, flush=True)),
            path_scope=args.path_scope,
        )
        print(render(stats), flush=True)
        return 0

    if args.dry_run:
        return _go()
    # Пишущий прогон: общий lock index-режима (того же, что держит ``dt_sync index``; внутри шага
    # ``ocr`` он уже наш - reentrant), чтобы два OCR/ingest не писали манифест одновременно.
    prev = (signal.getsignal(signal.SIGTERM), signal.getsignal(signal.SIGINT))
    try:
        with runlock.hold(runlock.index_sync_lock(sync_lock_path()), mode="ocr", step="ocr"):
            signal.signal(signal.SIGTERM, _request_stop)
            signal.signal(signal.SIGINT, _request_stop)
            return _go()
    except runlock.RunLockBusy as exc:
        print(f"OCR не запущен: {exc} (дождитесь конца прогона или повторите позже)")
        return 3
    finally:
        signal.signal(signal.SIGTERM, prev[0])
        signal.signal(signal.SIGINT, prev[1])


if __name__ == "__main__":
    raise SystemExit(main())
