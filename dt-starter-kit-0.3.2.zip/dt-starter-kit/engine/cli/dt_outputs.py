"""dt outputs - операции над папками выходов ``07-outputs`` (EVAL-HYGIENE-1, interface layer).

``dt outputs mark [--dry-run] [--force] [--json]`` - ретро-пометка прошлых прогонов:
выходы, постановка которых совпала с фразой золотой задачи
(``vault/_system/eval/golden-generation.yaml``) или
которые сделал тестовый хост, получают ``purpose: eval|selftest``; доставленные ими файлы
переезжают из папок клиентов в ``<корень>/_eval/<ГГГГ-ММ>/<папка выхода>/`` (с отчетом «откуда →
куда»), selftest-папки удаляются. Eval-выходы НЕ удаляются (история eval). Нет флага - применить;
``--dry-run`` - показать план, ничего не трогая; ``--force`` - переносить и файлы, правленные после
доставки (sha не наш; решение владельца). Идемпотентно. Логика - :mod:`core.outputs_mark`.

``dt outputs sources [--since ГГГГ-ММ-ДД] [--dry-run] [--json]`` - ретро сессионного провенанса
(PROV-SESSION-1): рабочим выходам, окно которых покрыто журналом запросов (с 24.10), дописываются
автосекции «## Прочитано в сессии»/«## Поиск в сессии» (у ad-hoc-выхода без ``sources.md`` - файл
целиком); сегмент старых записей - по хосту и времени, границы - по аудиту ``save_output``.
Идемпотентно; ``--dry-run`` - только список. Логика - :mod:`core.outputs_sources`.

Usage:
    uv run python cli/dt.py outputs mark --dry-run
    uv run python cli/dt.py outputs mark
    uv run python cli/dt.py outputs sources --dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt outputs", description="Операции над выходами 07-outputs.")
    sub = parser.add_subparsers(dest="cmd", required=True)
    mark = sub.add_parser("mark", help="Ретро-пометка прогонов eval/selftest и перенос файлов.")
    mark.add_argument("--dry-run", action="store_true",
                      help="Показать план (пометить/перенести/удалить), ничего не меняя.")
    mark.add_argument("--force", action="store_true",
                      help="Переносить и файлы прогонов, правленные после доставки (sha не наш).")
    mark.add_argument("--vault", type=Path, default=None)
    mark.add_argument("--json", action="store_true", help="Отчет JSON.")
    src = sub.add_parser(
        "sources", help="Ретро сессионного провенанса: дописать автосекции в sources.md.")
    src.add_argument("--since", default=None, metavar="ГГГГ-ММ-ДД",
                     help="Только выходы, сохраненные не раньше этой даты.")
    src.add_argument("--dry-run", action="store_true",
                     help="Показать план (кому что дописать), ничего не меняя.")
    src.add_argument("--vault", type=Path, default=None)
    src.add_argument("--json", action="store_true", help="Отчет JSON.")
    args = parser.parse_args(argv)
    load_env()

    if args.cmd == "sources":
        from core.outputs_sources import format_report as fmt_sources
        from core.outputs_sources import run as run_sources

        sreport = run_sources(args.vault, since=args.since, dry_run=args.dry_run)
        if args.json:
            print(json.dumps(sreport.to_dict(), ensure_ascii=False, indent=1))
        else:
            print(fmt_sources(sreport))
        return 1 if sreport.problems else 0

    from core.outputs_mark import format_report, run

    report = run(args.vault, dry_run=args.dry_run, force=args.force)
    if args.json:
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=1))
    else:
        print(format_report(report))
    return 1 if report.problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
