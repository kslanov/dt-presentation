"""dt owner - профиль владельца в vault (PROFILE-1): ``init | show | check | export``.

Профиль - три файла в ``vault/_system/profile/``: ``owner.yaml`` (личность), ``about.md`` (идет в
промпт generate секцией ``[Owner]``), ``rules.md`` (правила хостам). Правит владелец руками
(Obsidian); движок профиль только читает.

* ``init [--force] [--people ФАМИЛИЯ ...] [--name ИМЯ] [--email АДРЕС ...] [--company НАЗВАНИЕ]
  [--domain ДОМЕН ...] [--internal-domain ДОМЕН ...] [--vault PATH]`` - создать три файла из
  текущих источников
  (``DT_USER_NAME``, ``DT_OUTLOOK_SELF_TOKENS``, ``DT_TIMETTA_USER_EMAIL``,
  ``DT_LEGACY_PRIVACY_NAMES``, ``DT_MAIL_OWNER_DOMAINS``/``DT_MAIL_INTERNAL_DOMAINS`` - в
  ``company.domains``/``company.internal_domains``); существующий ``owner.yaml`` со строкой
  ``company: <название>`` мигрируется в объект (с бэкапом);
  ``--people`` - фамилии для ``privacy.people`` (в коде движка их больше нет); DEV-3-KIT:
  ``--name``/``--email``/``--company``/``--domain``/``--internal-domain`` (повторяемые) задают
  личность без переменных рабочего контура - так ставит ``dt install`` (явные значения
  перекрывают env, списки дополняют). Существующий файл без ``--force`` не трогается;
  с ``--force`` - перезапись с бэкапом;
* ``show`` - что движок видит в профиле (поля ``owner.yaml``, размеры блоков, версия, замечания);
  секретов в профиле нет по построению;
* ``check`` - схема + полнота личности + ``about.md`` + дубли с ``.env`` (то же, что строка доктора
  «Профиль владельца»); код выхода 1 при замечаниях;
* ``export [--format markdown] [--out FILE]`` - правила и ядро ``about.md`` одним markdown для
  вставки в память любого клиента (тот же текст, что в скилле ``dt-owner`` экспорта скиллов).

Usage:
    uv run python cli/dt.py owner init --people Фамилия1 Фамилия2
    uv run python cli/dt.py owner show
    uv run python cli/dt.py owner check
    uv run python cli/dt.py owner export > owner-rules.md
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env


def _vault(args: argparse.Namespace) -> Path | None:
    return Path(args.vault).expanduser() if args.vault else None


def _init(args: argparse.Namespace) -> int:
    from core.owner.init import init_profile

    res = init_profile(
        _vault(args), force=args.force, people=list(args.people or []), name=args.name,
        emails=list(args.email or []), company=args.company, domains=list(args.domain or []),
        internal_domains=list(args.internal_domain or []))
    print(f"профиль: {res.directory}")
    for name in res.created:
        if name not in res.refilled:
            print(f"  создан {name}")
    for name in res.skipped:
        print(f"  уже есть {name} (без --force не трогаю)")
    for name in res.refilled:
        print(f"  дозаполнен {name} (был пустой шаблон vault)")
    for name in res.migrated:
        print(f"  мигрирован {name}: company строкой -> объект {{name, domains, internal_domains}}")
    for name in res.backups:
        print(f"  бэкап прежнего: {name}.bak-*")
    found = ", ".join(f"{k}: {n}" for k, n in res.sources.items())
    print(f"из текущих источников: {found}")
    if not res.sources.get("privacy"):
        print("privacy.people пуст: фамилии коллег в код движка не возвращаются - передай их "
              "`--people ...` (или впиши в owner.yaml руками), иначе их личные документы "
              "не отфильтруются")
    if res.created:
        print("дальше: заполнить about.md/rules.md в Obsidian; `dt owner check`")
    return 0


def _show(args: argparse.Namespace) -> int:
    from core.owner import load_profile

    prof = load_profile(_vault(args))
    print(f"# {prof.path}")
    if not prof.exists:
        print("профиля нет: dt owner init")
        return 1
    d = prof.data
    print(f"name:          {d.name or '(не задано)'}")
    print(f"name_variants: {', '.join(d.name_variants) or '-'}")
    print(f"emails:        {', '.join(d.emails) or '-'}")
    print(f"company:       {d.company or '-'}; domains: {', '.join(d.company_domains) or '-'}; "
          f"internal: {', '.join(d.company_internal_domains) or '-'}")
    print(f"role:          {d.role or '-'}")
    print(f"locale:        {d.locale or '-'}")
    print(f"privacy.people: {len(d.privacy_people)} ({', '.join(d.privacy_people) or '-'})")
    print(f"updated:       {d.updated or '-'}   версия: {prof.version}")
    print(f"about.md: {len(prof.about)} симв.   rules.md: {len(prof.rules)} симв.   "
          f"missing: {', '.join(prof.missing) or '-'}")
    for issue in prof.issues:
        print(f"замечание {issue}")
    return 0


def _check(args: argparse.Namespace) -> int:
    from core.owner import load_profile
    from core.owner.check import evaluate

    prof = load_profile(_vault(args))
    res = evaluate(prof, os.environ)
    print(f"Профиль владельца: {res.status} - {res.summary}")
    for issue in prof.issues:
        print(f"  замечание {issue}")
    if res.hint:
        print(f"  что делать: {res.hint}")
    return 0 if res.status == "ok" else 1


def _export(args: argparse.Namespace) -> int:
    from core.owner import load_profile
    from core.owner.export import export_markdown

    text, reason = export_markdown(load_profile(_vault(args)))
    if text is None:
        print(f"экспортировать нечего: {reason}", file=sys.stderr)
        return 1
    if args.out:
        Path(args.out).expanduser().write_text(text, encoding="utf-8")
        print(f"{len(text)} симв. -> {args.out}")
    else:
        sys.stdout.write(text)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt owner", description=__doc__.split("\n")[0])
    parser.add_argument("--vault", default=None, help="другой vault (по умолчанию DT_VAULT_PATH)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    it = sub.add_parser("init", help="создать профиль из текущих источников")
    it.add_argument("--force", action="store_true", help="перезаписать существующее (с бэкапом)")
    it.add_argument("--people", nargs="*", default=[], metavar="ФАМИЛИЯ",
                    help="privacy.people: чьи личные документы не индексируем")
    it.add_argument("--name", default=None, help="имя владельца (перекрывает DT_USER_NAME)")
    it.add_argument("--email", action="append", default=[], metavar="АДРЕС",
                    help="свой адрес (повторяемый)")
    it.add_argument("--company", default=None, help="название компании (company.name)")
    it.add_argument("--domain", action="append", default=[], metavar="ДОМЕН",
                    help="почтовый домен компании (повторяемый; company.domains)")
    it.add_argument("--internal-domain", action="append", default=[], metavar="ДОМЕН",
                    help="служебный домен группы (повторяемый; company.internal_domains)")
    it.set_defaults(func=_init)

    sh = sub.add_parser("show", help="что движок видит в профиле")
    sh.set_defaults(func=_show)

    ck = sub.add_parser("check", help="схема, полнота, дубли с .env (код 1 при замечаниях)")
    ck.set_defaults(func=_check)

    ex = sub.add_parser("export", help="правила владельца одним markdown для памяти клиента")
    ex.add_argument("--format", choices=("markdown",), default="markdown")
    ex.add_argument("--out", default=None, help="файл вместо stdout")
    ex.set_defaults(func=_export)

    args = parser.parse_args(argv)
    load_env()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
