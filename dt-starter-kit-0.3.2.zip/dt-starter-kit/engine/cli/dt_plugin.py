"""dt plugin - плагин хоста как артефакт (MODEL-1 п.D): ``dt plugin kimi``.

``dt plugin kimi --out DIR`` собирает каталог плагина Kimi Work: обертка над
``dt skills export kimi`` (скиллы + манифест, линтер переносимости - без него сборка не идет) и
``dt host-config kimi --plugin-manifest`` (манифест: скиллы, БЕЗ MCP), плюс версия из ``pyproject``,
README с шагами подключения и **самопроверка** (``server.py --profile lean --selftest``:
``tools/list`` = профиль, prompts = реестр скиллов, плюс - при живом демоне -
``--selftest --transport http``: ``tools/list`` по url). Результат (когда, сколько скиллов, ok ли
самопроверка) пишется в
``.derived/status/kimi-plugin.json`` - из него строка доктора «Плагин Kimi».

``dt plugin kimi --selftest`` - только самопроверка, без сборки. Cursor - ``dt host-config cursor``
(url демона; ``--install`` пишет в ``~/.cursor/mcp.json``).

KIMI-INSTALL-1: ``--install`` (после сборки) кладет каталог в Kimi (``managed/digital-twin`` +
запись в ``installed.json``, снимает ``digital-twin-lean``) и сверяет; ``--verify-install`` - только
чтение: что стоит в Kimi против сборки (``core/kimi_install.py``). Корень Kimi -
``DT_KIMI_PLUGINS_DIR`` либо путь машины.

KIMI-INSTALL-2: **плагин = скиллы, MCP = ``mcp.json`` агента** (Kimi Work 3.2.22 не поддерживает
локальные MCP-плагины). ``--install`` дополнительно пишет ``mcpServers.digital-twin`` в
``<home агента>/mcp.json`` (остальное в файле не меняется), ``--verify-install`` сверяет и его
(``stale: mcp_missing|mcp_stdio_legacy|mcp_differs``; итог ok - только при обоих). Каталог агента -
``DT_KIMI_AGENT_HOME`` либо путь машины. Снять ключ - вручную из ``mcp.json``.

HOSTS-ATTACH-1: запись в ``mcp.json`` - url демона (``http://127.0.0.1:<порт>/mcp/lean`` +
``Authorization: Bearer <rw>``), а не stdio-команда: хост подключается к работающему движку.

Usage:
    uv run python cli/dt.py plugin kimi --out /tmp/dt-kimi-plugin
    uv run python cli/dt.py plugin kimi --out plugins/kimi-work --install
    uv run python cli/dt.py plugin kimi --verify-install
    uv run python cli/dt.py plugin kimi --selftest
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config import ENGINE_ROOT
from core.host_config import PLUGIN_DIR, PROFILES, kimi_plugin_manifest, render
from core.kimi_install import KimiInstallError, install, kimi_plugins_dir, verify_install
from core.kimi_plugin import (
    engine_version,
    new_status,
    plugin_skills,
    render_readme,
    write_status,
)
from core.skills import export_kimi_skills, format_skipped, lint_skills, load_skills

SELFTEST_TIMEOUT_S = 120


def _run_server(args: list[str]) -> tuple[bool, str]:
    server = ENGINE_ROOT / "mcp-server" / "server.py"
    python = ENGINE_ROOT / ".venv" / "bin" / "python"
    env = {**os.environ, "PYTHONPATH": str(ENGINE_ROOT)}
    try:
        proc = subprocess.run(  # noqa: S603 - свои пути и аргументы, без пользовательского ввода
            [str(python if python.is_file() else sys.executable), str(server), *args],
            capture_output=True, text=True, timeout=SELFTEST_TIMEOUT_S, env=env,
            cwd=str(ENGINE_ROOT), check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, f"FAIL самопроверка не запустилась: {type(exc).__name__}: {exc}"
    return proc.returncode == 0, proc.stdout.strip() or proc.stderr.strip()[-400:]


def run_selftest(profile: str = "lean") -> tuple[bool, str]:
    """Самопроверка плагина -> (ок, вывод): реестр (``server.py --profile <p> --selftest`` - в
    памяти, stdio-сервер из манифеста не поднимается) и, при живом демоне, ``tools/list`` по url
    (``--selftest --transport http``). Демон не запущен - справка, не отказ (последняя строка -
    ``SELFTEST ok|FAIL …`` по реестру и, если демон жив, по url)."""
    from core.daemon import fetch_health
    from core.host_config import daemon_port

    ok, text = _run_server(["--profile", profile, "--selftest"])
    lines = text.splitlines()
    summary = lines.pop() if lines and lines[-1].startswith("SELFTEST") else ""
    port = daemon_port()
    if fetch_health(port) is None:
        lines.append(f"справка: демон не отвечает на 127.0.0.1:{port} - tools/list по url не "
                     "проверен (`bash ops/install_launchd.sh`)")
    else:
        http_ok, http_text = _run_server(
            ["--selftest", "--transport", "http", "--profile", profile, "--port", str(port)])
        http_lines = http_text.splitlines()
        lines.extend(f"url: {ln}" for ln in http_lines[-1:] if ln)
        if not http_ok:
            lines.extend(f"url: {ln}" for ln in http_lines[:-1] if ln.startswith("FAIL"))
        ok = ok and http_ok
    if summary and not ok and summary.startswith("SELFTEST ok"):
        summary = summary.replace("SELFTEST ok", "SELFTEST FAIL", 1)
    return ok, "\n".join([*lines, *([summary] if summary else [])])


def _tool_names() -> tuple[str, ...]:
    from dt_skills import tool_names

    return tool_names()


def _profile_tools(profile: str) -> tuple[str, ...]:
    from dt_skills import profile_tools

    return profile_tools(profile)


def _verify_source(out: Path | None) -> Path:
    """Сборка для сверки: ``--out``, иначе та, что записал статус сборки, иначе каталог репо."""
    if out is not None:
        return out.expanduser()
    from core.kimi_plugin import read_status

    record, _ = read_status()
    recorded = (record or {}).get("out")
    return Path(str(recorded)) if recorded else PLUGIN_DIR


MCP_OUTCOME = {"created": "создан mcp.json с ключом digital-twin",
               "added": "ключ digital-twin добавлен", "updated": "ключ digital-twin обновлен",
               "unchanged": "ключ digital-twin уже совпадает со сборкой"}
MCP_WORDS = {"registered": "зарегистрирован", "missing": "нет", "differs": "расходится",
             "invalid": "mcp.json не читается",
             "stdio_legacy": "старая stdio-запись (`dt plugin kimi --install` -> url демона)"}


def _mcp_port() -> int:
    from core.host_config import daemon_port

    return daemon_port()


def print_verdict(verdict: dict) -> None:
    state = "ok" if verdict["ok"] else "STALE" if verdict["installed"] else "не установлен"
    print(f"Kimi ({kimi_plugins_dir()}): {state}")
    if verdict["stale"]:
        print("  stale: " + ", ".join(verdict["stale"]))
    print(f"  {verdict['reason']}")
    if "mcp" in verdict:  # KIMI-INSTALL-2: MCP агента - отдельная строка
        word = MCP_WORDS.get(verdict["mcp"], verdict["mcp"])
        if verdict["mcp"] == "registered":
            word = f"url → :{_mcp_port()}/lean"
        print(f"  MCP агента: {word} ({verdict['mcp_path']})")


def cmd_verify(out: Path | None) -> int:
    verdict = verify_install(_verify_source(out))
    print_verdict(verdict)
    return 0 if verdict["ok"] else 1


def cmd_install(out: Path) -> int:
    try:
        done = install(out)
    except KimiInstallError as exc:
        print(f"установка в Kimi отклонена [{exc.code}]: {exc.reason}", file=sys.stderr)
        return 1
    removed = f"; снят устаревший: {', '.join(done['removed'])}" if done["removed"] else ""
    print(f"установлено в Kimi: {done['target']} (installedAt {done['installed_at']}, "
          f"updatedAt {done['updated_at']}){removed}")
    print(f"MCP агента ({done['mcp_path']}): {MCP_OUTCOME.get(done['mcp'], done['mcp'])}")
    verdict = verify_install(out)
    print_verdict(verdict)
    if verdict["ok"]:
        print("Перезапусти Kimi Work и начни новую сессию: скиллы плагина `Digital Twin` и MCP "
              "агента подхватятся; в `tools_added` будут инструменты `digital-twin` (deferred, "
              "через `select_tools`).")
    return 0 if verdict["ok"] else 1


def cmd_kimi(args: argparse.Namespace) -> int:
    if args.verify_install and not args.install:
        return cmd_verify(args.out)
    if args.selftest and args.out is None:
        ok, text = run_selftest(args.profile)
        print(text)
        return 0 if ok else 1
    if args.out is None:
        print("нужен --out DIR (или --selftest / --verify-install)", file=sys.stderr)
        return 2
    skills = load_skills()
    issues = lint_skills(skills, _tool_names())
    if issues:
        for issue in issues:
            print(issue, file=sys.stderr)
        print("сборка остановлена: сначала почини линтер (dt skills lint)", file=sys.stderr)
        return 1
    out = args.out.expanduser()
    version = engine_version()
    # MODEL-1-FIT: плагин несет только скиллы, выполнимые инструментами профиля
    tools = _profile_tools(args.profile)
    # PULT-SURFACE-2 п.5 (хвост PROFILE-1): плагин несет и ``dt-owner``, как ``dt skills export``
    skills, skipped, owner_version, owner_note = plugin_skills(
        skills, lint_tools=_tool_names(), profile_tools=tools)
    if owner_note:
        print(f"dt-owner: не в плагине - {owner_note}")
    names = [s.name for s in skills]
    files = export_kimi_skills(out, skills, skipped=skipped)
    manifest = kimi_plugin_manifest(args.profile, skills=names, version=version)
    (out / "kimi.plugin.json").write_text(render(manifest) + "\n", encoding="utf-8")
    built = datetime.now(UTC).strftime("%Y-%m-%d")
    readme = out / "README.md"
    if out.resolve() == PLUGIN_DIR.resolve():
        readme_note = "README.md каталога репо - не перезаписан (описание команды лежит в git)"
    else:
        readme.write_text(
            render_readme(version=version, profile=args.profile, skills=names, built=built,
                          skipped=skipped, tools_n=len(tools)),
            encoding="utf-8",
        )
        readme_note = f"README.md: {readme}"
    print(f"плагин Kimi v{version}: {len(files)} скиллов + kimi.plugin.json -> {out}")
    print(readme_note)
    if skipped:
        print(format_skipped(skipped, args.profile))
    passed: bool | None = None
    line = ""
    if not args.no_selftest:
        passed, line = run_selftest(args.profile)
        print(line)
    try:
        record = new_status(out=out.resolve(), version=version, profile=args.profile,
                            skills=skills, skipped=skipped, profile_tools=tools,
                            owner_version=owner_version, selftest_ok=passed,
                            selftest_line=line.splitlines()[-1] if line else "")
        write_status(record)
    except OSError as exc:
        print(f"статус сборки не записан (доктор не увидит): {exc}", file=sys.stderr)
    print(f"Плагин Kimi: собран {built}, скиллов {len(names)}, профиль {args.profile}")
    if passed is False:
        if args.install:
            print("в Kimi не ставлю: самопроверка сервера не прошла", file=sys.stderr)
        return 1
    return cmd_install(out) if args.install else 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt plugin", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="host", required=True)
    kimi = sub.add_parser("kimi", help="плагин Kimi Work: скиллы + манифест + самопроверка")
    kimi.add_argument("--out", type=Path, default=None, help="каталог плагина")
    kimi.add_argument("--profile", choices=PROFILES, default="lean")
    kimi.add_argument("--selftest", action="store_true",
                      help="только самопроверка сервера (без --out - без сборки)")
    kimi.add_argument("--no-selftest", action="store_true", help="собрать без самопроверки")
    kimi.add_argument("--install", action="store_true",
                      help="после сборки поставить в Kimi (managed/digital-twin + installed.json)")
    kimi.add_argument("--verify-install", action="store_true",
                      help="только чтение: что стоит в Kimi против сборки (--out или последняя)")
    args = parser.parse_args(argv)
    return cmd_kimi(args)


if __name__ == "__main__":
    raise SystemExit(main())
