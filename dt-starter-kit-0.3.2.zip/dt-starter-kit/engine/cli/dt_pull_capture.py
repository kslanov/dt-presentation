"""dt-pull-capture — TickTick capture project → vault inbox (interface layer).

Reads a dedicated TickTick capture list and routes its tasks into
``_staging/inbox/`` by tag (``знание``→knowledge, ``тиметта``→operational),
deduped by a local state file, so the existing ``dt-refine-inbox`` (D6) can
place them. **Read-only to TickTick.** ``#личное``/``#дневник``/``#контент`` are dropped
before any save (PERSONAL-1; в экземпляре личного контура они, наоборот, маршрутизируются).

The summary is **anonymized**: only per-lane counts and skip counters — никогда
заголовки или текст задач (особенно для личного — оно не сохраняется нигде).

CLI depends on core, never the reverse (architecture §8 invariant). The token is
loaded from ``.env`` via python-dotenv and is never printed.

Usage:
    uv run --extra operational python cli/dt_pull_capture.py
    uv run --extra operational python cli/dt_pull_capture.py --dry-run
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

from core.operational.ticktick.capture import (
    LANE_ASSIGNMENT,
    LANE_KNOWLEDGE,
    PERSONAL_LANES,
    CaptureResult,
)
from core.operational.ticktick.client import TickTickAuthError, TickTickError
from core.operational.ticktick.connector import TickTickConnector

# cli/ is not an importable package; put our own dir on sys.path so the shared
# _env helper imports cleanly in both script and load-by-path (test) contexts.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

logger = logging.getLogger(__name__)


def render(result: CaptureResult) -> str:
    """Anonymized summary — counts only, no task titles/text/ids."""
    mode = " (dry-run — файлы не записаны)" if result.dry_run else ""
    lines: list[str] = []
    lines.append(f"ЗАХВАЧЕНО{mode}: {result.total_pulled}")
    lines.append(f"  knowledge (#знание):    {result.pulled.get(LANE_KNOWLEDGE, 0)}")
    lines.append(f"  поручения (#поручение): {result.pulled.get(LANE_ASSIGNMENT, 0)}")
    for lane in PERSONAL_LANES:  # PERSONAL-1: личный контур; в рабочем счетчиков нет - строк тоже
        if result.pulled.get(lane):
            lines.append(f"  {lane} (личный контур): {result.pulled[lane]}")
    lines.append("ПРОПУЩЕНО:")
    lines.append(f"  личное (не сохранено):  {result.skipped_personal}")
    lines.append(f"  оператив:               {result.skipped_operative}")
    lines.append(f"  без рабочего тега:      {result.skipped_untagged}")
    if result.skipped_work_tag:
        lines.append(f"  рабочие теги (берет рабочий контур): {result.skipped_work_tag}")
    lines.append(f"  дубликаты (без изменений): {result.skipped_dedup}")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    load_env()  # engine/.env → os.environ (token + DT_TICKTICK_* knobs)

    parser = argparse.ArgumentParser(
        prog="dt-pull-capture",
        description="Capture a TickTick project into the vault inbox by tag (read-only).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be pulled (per lane) without writing files or state.",
    )
    args = parser.parse_args(argv)

    try:
        connector = TickTickConnector.from_env()
    except RuntimeError as e:
        logger.error("capture aborted — %s", e)
        return 2

    from core.ingress.run import ingress_run

    try:
        with ingress_run("capture", dry_run=args.dry_run) as run:  # INGRESS-1: run_id + итог
            result = connector.pull_capture(dry_run=args.dry_run)
            run.finish(result)
    except TickTickAuthError as e:
        logger.error("capture aborted — %s", e)
        return 2
    except TickTickError as e:
        logger.error("TickTick capture failed — %s", e)
        return 1

    print(render(result))  # anonymized summary → stdout (UX result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
