"""dt pult - пульт без Desktop (PULT-STANDALONE-1): ``open | status | url``.

Веб-пульт отдает тот же демон ``com.dt.server`` (порт ``DT_WEB_PORT``, по умолчанию 8787), поэтому
для работы без Claude Desktop нужен только браузер:

* ``open [--rw] [--public]`` - браузер по умолчанию на ``http://127.0.0.1:8787/?t=<read-токен>``;
  ``--rw`` - токен записи (решения, настройки; cookie на 7 дней), ``--public`` - публичный адрес
  Tailscale funnel (``public_url``), например с телефона. Демон не отвечает - строка с
  ``launchctl kickstart -k gui/<uid>/com.dt.server`` и выход 1. Токен в stdout не печатается;
* ``status`` - ``pult_web_status`` текстом (порт, демон, funnel, launchd, токены без значений);
* ``url [--rw] [--public]`` - печать ссылки С токеном (локально, в терминале).

Usage:
    uv run python cli/dt.py pult open
    uv run python cli/dt.py pult url --public
    uv run python cli/dt.py pult status
"""

from __future__ import annotations

import argparse
import importlib.util
import os
import socket
import sys
import webbrowser
from collections.abc import Callable
from pathlib import Path
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.web_tokens import WebTokens

_SERVER_LABEL = "com.dt.server"
_SERVER_PY = Path(__file__).resolve().parents[1] / "mcp-server" / "server.py"


def _port() -> int:
    return int(os.environ.get("DT_WEB_PORT") or 8787)


def _daemon_up(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            return True
    except OSError:
        return False


def _web_status() -> dict[str, Any]:
    """``pult_web_status`` из модуля инструментов (сокет, tailscale funnel status, launchctl)."""
    spec = importlib.util.spec_from_file_location("dt_mcp_server_pult_cli", _SERVER_PY)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"не загрузить {_SERVER_PY}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.pult_web_status()  # type: ignore[no-any-return]


def _kickstart_hint() -> str:
    return (f"демон не отвечает на 127.0.0.1:{_port()}; запусти: "
            f"launchctl kickstart -k gui/{os.getuid()}/{_SERVER_LABEL}")


def _link(
    rw: bool, public: bool, status_fn: Callable[[], dict[str, Any]]
) -> tuple[str | None, str]:
    """``(ссылка с токеном | None, пояснение отказа)``."""
    tokens = WebTokens()
    token = tokens.rw() if rw else tokens.read()
    which = "rw" if rw else "read"
    if not token:
        return None, (f"{which}-токена нет: он создастся при старте демона "
                      f"или `dt web-token rotate {which}`")
    if public:
        url = status_fn().get("public_url")
        if not url:
            return None, "публичного адреса нет: Tailscale funnel выключен (public_url пуст)"
        return f"{str(url).rstrip('/')}/?t={token}", ""
    return f"http://127.0.0.1:{_port()}/?t={token}", ""


def _status_text(st: dict[str, Any]) -> str:
    def mark(value: Any) -> str:
        return "неизвестно" if value is None else ("да" if value else "нет")

    lines = [
        f"демон слушает порт {st.get('port')}: {mark(st.get('server_running'))}",
        f"launchd {_SERVER_LABEL} загружен: {mark(st.get('launchd_loaded'))}",
        f"Tailscale funnel включен: {mark(st.get('funnel_on'))}",
        f"публичный адрес: {st.get('public_url') or '-'}",
    ]
    access = st.get("access")
    if isinstance(access, dict):
        lines.append(
            f"токены: read ...{access.get('read_tail') or '-'}, "
            f"rw ...{access.get('rw_tail') or '-'} "
            f"(rw настроен: {mark(access.get('rw_configured'))}); "
            "значения: dt web-token show read|rw"
        )
    for warning in st.get("warning") or []:
        if isinstance(warning, dict):
            lines.append(f"! {warning.get('code')}: {warning.get('reason')}")
    if not st.get("server_running"):
        lines.append(_kickstart_hint())
    return "\n".join(lines)


def main(
    argv: list[str] | None = None,
    *,
    browser: Any = webbrowser,
    daemon_up: Callable[[int], bool] = _daemon_up,
    status_fn: Callable[[], dict[str, Any]] = _web_status,
) -> int:
    load_env()
    parser = argparse.ArgumentParser(prog="dt pult", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    for name in ("open", "url"):
        p = sub.add_parser(name)
        p.add_argument("--rw", action="store_true", help="токен записи вместо read")
        p.add_argument("--public", action="store_true", help="публичный адрес Tailscale funnel")
    sub.add_parser("status")
    args = parser.parse_args(argv)

    if args.cmd == "status":
        try:
            st = status_fn()
        except Exception as exc:  # noqa: BLE001 - статус не должен падать трассой
            print(f"статус не получен: {exc}", file=sys.stderr)
            return 1
        print(_status_text(st))
        return 0

    if args.cmd == "open" and not daemon_up(_port()):
        print(_kickstart_hint(), file=sys.stderr)
        return 1
    url, why = _link(args.rw, args.public, status_fn)
    if url is None:
        print(why, file=sys.stderr)
        return 1
    if args.cmd == "url":
        print(url)
        return 0
    if not browser.open(url):
        print("браузер не открылся; ссылку покажет `dt pult url`", file=sys.stderr)
        return 1
    where = "публичный адрес" if args.public else f"127.0.0.1:{_port()}"
    print(f"открыл пульт ({where}, токен {'rw' if args.rw else 'read'} в ссылке, здесь не печатаю)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
