"""dt-purge-nda — скан и снятие следов NDA во всех производных сторах (NDA-1/NDA-2).

Документ под барьером оставляет след не в одном месте: манифест инжеста, манифест
индекса и чанки LanceDB, реестр источников и L2-кэш лифта, факты, журнал стадий.
Пока след лежит хоть где-то, документ находится поиском и поднимается lift'ом —
поэтому обход общий и по одному предикату :func:`core.privacy.is_nda`.

**Dry-run по умолчанию** (печатает отчёт «что нашли», ничего не меняя). ``--purge``
снимает найденное; ``--limit N`` — канарейка (по N записей на каждой поверхности:
посмотреть результат на одной-двух, потом добить остальное, §9 п.11г). События
журнала ПОМЕЧАЮТСЯ (``detail.nda``), а не переписываются; заметки vault не трогаются
никогда — карантин остаётся решением человека (их показывает ``dt doctor``).

Usage::

    uv run python cli/dt_purge_nda.py                  # отчёт (ничего не меняет)
    uv run python cli/dt_purge_nda.py --purge --limit 1  # канарейка
    uv run python cli/dt_purge_nda.py --purge            # снять всё найденное
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.nda_purge import purge_nda_traces, scan_nda_traces

_PREVIEW = 20  # сколько строк каждой поверхности печатать целиком


def _head(items: list, n: int = _PREVIEW) -> tuple[list, int]:
    return items[:n], max(0, len(items) - n)


def render_scan(scan: dict) -> str:
    """Отчёт скана по поверхностям — то, что уходит в приёмку."""
    lines = [f"NDA-следы в производных сторах: {scan['total']} записей", ""]

    lines.append(f"Реестр источников + L2-кэш: {scan['source_count']}")
    shown, rest = _head(scan["sources"])
    for content_hash, paths in shown:
        lines.append(f"  {content_hash[:12]}  {paths}")
    if rest:
        lines.append(f"  … ещё {rest}")

    lines.append(f"Факты (source_path): {scan['facts_count']}")
    shown, rest = _head(scan["facts"])
    lines += [f"  {p}" for p in shown]
    if rest:
        lines.append(f"  … ещё {rest}")

    lines.append(f"Манифесты инжеста: {scan['manifest_count']}")
    shown, rest = _head(scan["manifests"])
    for hit in shown:
        lines.append(f"  [{hit['layer']}] {hit['source_path']} → {hit['note_path'] or '—'}")
    if rest:
        lines.append(f"  … ещё {rest}")

    lines.append(f"Индекс (манифест + чанки): {scan['index_count']}")
    shown, rest = _head(scan["index"])
    for hit in shown:
        lines.append(
            f"  {hit['note_id']}  чанков {hit['chunks']}  {hit['path']}"
            + (f"  ← {hit['source_path']}" if hit["source_path"] else "")
        )
    if rest:
        lines.append(f"  … ещё {rest}")

    lines.append(f"События журнала (пометить, не удалять): {scan['event_count']}")
    shown, rest = _head(scan["events"])
    for hit in shown:
        lines.append(f"  #{hit['event_id']} {hit['stage']}/{hit['status']} {hit['path']}")
    if rest:
        lines.append(f"  … ещё {rest}")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-purge-nda",
        description="Скан/снятие следов NDA во всех производных сторах (NDA-1/NDA-2).",
    )
    parser.add_argument("--purge", action="store_true",
                        help="снять найденное (по умолчанию — только отчёт)")
    parser.add_argument("--limit", type=int, default=None,
                        help="канарейка: не больше N записей на каждой поверхности")
    args = parser.parse_args(argv)

    load_env()

    scan = scan_nda_traces()
    print(render_scan(scan))

    if not args.purge:
        print(
            "\n(dry-run) следов не найдено." if not scan["total"]
            else "\n(dry-run) повтори с --purge (можно с --limit 1 — канарейкой)."
        )
        return 0

    removed = purge_nda_traces(limit=args.limit)
    print(
        f"\nСНЯТО: {removed['cache_records']} записей кэша, "
        f"{removed['registry_entries']} строк реестра, "
        f"{removed['facts_rows']} строк фактов, "
        f"{removed['manifest_entries']} записей манифестов инжеста, "
        f"{removed['index_entries']} записей индекса ({removed['index_chunks']} чанков); "
        f"помечено событий: {removed['events_marked']}."
    )
    if args.limit is not None:
        print("Это была канарейка (--limit) — проверь результат и повтори без лимита.")
    print("Заметки vault не тронуты: карантин — решение человека (см. dt doctor).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
