"""dt-reconcile — свести производные persist-очереди с источником (RECONCILE-1).

Тонкий интерфейсный слой над общим контуром
:func:`core.operational.reconcile.reconcile_all`: строит адаптеры и запускает
сверку. **Read-only ко внешним системам** — TickTick читается (``get_project_data``),
vault обходится; ничего нигде не мутируется, кроме локальных persist-очередей
(статусы ``resolved_external`` / ``stale`` + архив inbox-заметки, НЕ hard-delete).

Адаптеры:

* **captures** — untriaged-захваты и карточки поручений, завершённые/удалённые в TickTick,
  снимаются из «Требуют решения». Требует ``TICKTICK_ACCESS_TOKEN``; без токена шаг мягко
  пропускается (сверка ссылок всё равно идёт).
* **link_proposals** — pending-предложения с удалённой source/target-заметкой →
  ``stale`` (лента перерисуется).
* **timetta_mirror** (ORBIT-2) — сделки/проекты/issue, исчезнувшие в Timetta (id-списки),
  получают мягкую метку ``deleted_at`` в зеркале + каскад в crosswalk
  (``resolved_external``). Требует ``TIMETTA_API_TOKEN``; без токена шаг
  пропускается. Только чтение id-списков, в Timetta ничего не пишется.
* **reattr_proposals** (REATTR-1) — предложения переатрибуции, которые vault больше
  не оправдывает (заметка исчезла, атрибуцию поставили руками, файл уехал дальше) →
  ``resolved``.

Общий гард (пустое/ошибочное чтение источника → пропуск, очередь не обнуляется)
живёт в движке. Сводка анонимна — только счётчики снятого.

CLI зависит от core, не наоборот (инвариант §8). Токен из ``.env``, не логируется.

Usage:
    uv run --extra operational python cli/dt_reconcile.py
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

from core.config import (
    crosswalk_path,
    default_vault_path,
    link_proposals_path,
    reattr_proposals_path,
    staging_inbox_path,
    ticktick_capture_project,
    ticktick_state_path,
    timetta_mirror_path,
    watchlist_path,
)
from core.linking.reconcile_links import LinkProposalsReconcilable
from core.linking.reconcile_reattr import ReattrProposalsReconcilable
from core.operational.reconcile import Reconcilable, reconcile_all
from core.operational.ticktick.capture import CapturesReconcilable
from core.operational.ticktick.client import TickTickClient, TickTickError
from core.operational.timetta.client import TimettaClient, TimettaError
from core.operational.timetta.mirror import MirrorStore
from core.operational.timetta.reconcile import MirrorReconcilable
from core.secrets import get_secret

# cli/ is not an importable package; put our own dir on sys.path so the shared
# _env helper imports cleanly in both script and load-by-path (test) contexts.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

logger = logging.getLogger(__name__)


def _build_captures() -> tuple[CapturesReconcilable | None, TickTickClient | None]:
    """Build the captures adapter from env, or ``(None, None)`` if unconfigured.

    Returns the live client too so the caller can close it after the run. A
    missing token / unresolvable capture project is a soft skip (link reconcile
    still runs), not an error — reconcile is opportunistic maintenance.
    """
    token = get_secret("TICKTICK_ACCESS_TOKEN")
    if not token:
        return None, None
    try:
        client = TickTickClient(token)
        project_id = ticktick_capture_project(client)
    except (RuntimeError, TickTickError) as exc:
        logger.warning("captures: пропуск — %s", exc)
        return None, None
    adapter = CapturesReconcilable(
        client=client,
        project_id=project_id,
        state_path=ticktick_state_path() / "capture_state.json",
        inbox_dir=staging_inbox_path(),
    )
    return adapter, client


def _build_timetta() -> tuple[MirrorReconcilable | None, TimettaClient | None]:
    """Адаптер сверки удалений зеркала Timetta или ``(None, None)`` без токена (мягкий пропуск)."""
    token = get_secret("TIMETTA_API_TOKEN")
    if not token:
        return None, None
    try:
        client = TimettaClient(token)
    except TimettaError as exc:
        logger.warning("timetta_mirror: пропуск — %s", exc)
        return None, None
    adapter = MirrorReconcilable(
        client=client,
        store=MirrorStore(timetta_mirror_path()),
        crosswalk_path=crosswalk_path(),
        watchlist_path=watchlist_path(),
    )
    return adapter, client


def main(argv: list[str] | None = None) -> int:
    load_env()  # engine/.env → os.environ (token + DT_* knobs); never logged

    argparse.ArgumentParser(
        prog="dt-reconcile",
        description=(
            "Свести persist-очереди (захваты, link-предложения, переатрибуция) "
            "с источником."
        ),
    ).parse_args(argv)

    reconcilables: list[Reconcilable] = []
    captures, client = _build_captures()
    if captures is not None:
        reconcilables.append(captures)
    timetta, timetta_client = _build_timetta()
    if timetta is not None:
        reconcilables.append(timetta)
    reconcilables.append(
        LinkProposalsReconcilable(default_vault_path(), link_proposals_path())
    )
    reconcilables.append(
        ReattrProposalsReconcilable(default_vault_path(), reattr_proposals_path())
    )

    try:
        counts = reconcile_all(reconcilables)
    finally:
        if client is not None:
            client.close()
        if timetta_client is not None:
            timetta_client.close()

    captures_n = counts.get("captures", 0)
    links_n = counts.get("link_proposals", 0)
    reattr_n = counts.get("reattr_proposals", 0)
    timetta_n = counts.get("timetta_mirror", 0)
    skipped = "" if captures is not None else " (захваты пропущены — нет токена)"
    print(
        f"СНЯТО: захваты {captures_n}, ссылки {links_n}, "
        f"переатрибуция {reattr_n}, исчезло в Timetta {timetta_n}{skipped}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
