"""dt-refine-inbox — AI-assisted ingestion of inbox items (interface layer).

Path B: this prints the structured *refinement request* (which Cowork turns
into a placement proposal) and, on ``--apply``, writes a confirmed proposal into
the vault and clears the item from the inbox. It never calls an LLM.

CLI depends on core, never the reverse (architecture §8 invariant).

Usage:
    # List the inbox and print a refinement request per item (for Cowork):
    uv run python cli/dt_refine_inbox.py

    # Apply a confirmed proposal (YAML from a file or stdin) to one item:
    uv run python cli/dt_refine_inbox.py --apply <inbox_file> --proposal proposal.yaml
    cat proposal.yaml | uv run python cli/dt_refine_inbox.py --apply <inbox_file> --proposal -
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

from core.ingest import (
    InboxItem,
    apply_refinement,
    build_refinement_request,
    list_inbox,
)


def _list(args: argparse.Namespace) -> int:
    items = list_inbox()
    if not items:
        print("Inbox is empty (_staging/inbox/).")
        return 0

    print(f"{len(items)} item(s) in inbox:\n")
    for item in items:
        request = build_refinement_request(item)
        print("=" * 72)
        print(request.render())
    print("=" * 72)
    print(
        "\nGive a request above to Cowork to get a YAML proposal, then apply it:\n"
        "  uv run python cli/dt_refine_inbox.py --apply <inbox_file> --proposal <file|->"
    )
    return 0


def _apply(args: argparse.Namespace) -> int:
    inbox_file = Path(args.apply)
    if not inbox_file.is_file():
        print(f"error: inbox file not found: {inbox_file}", file=sys.stderr)
        return 2

    if args.proposal == "-":
        raw = sys.stdin.read()
    else:
        raw = Path(args.proposal).read_text(encoding="utf-8")
    proposal = yaml.safe_load(raw)
    if not isinstance(proposal, dict):
        print("error: proposal must be a YAML mapping", file=sys.stderr)
        return 2

    item = InboxItem(path=inbox_file, text=inbox_file.read_text(encoding="utf-8"))
    written = apply_refinement(item, proposal)
    print(f"Placed note → {written}")
    print(f"Cleared from inbox → {inbox_file}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-refine-inbox",
        description="AI-assisted ingestion of inbox items (Path B; no LLM call).",
    )
    parser.add_argument(
        "--apply", metavar="INBOX_FILE",
        help="Apply mode: the inbox file to place into the vault.",
    )
    parser.add_argument(
        "--proposal", metavar="PATH",
        help="In apply mode, read the YAML proposal from this file ('-' for stdin).",
    )

    args = parser.parse_args(argv)

    if args.apply:
        if not args.proposal:
            print("error: --apply requires --proposal <file|->", file=sys.stderr)
            return 2
        return _apply(args)
    return _list(args)


if __name__ == "__main__":
    raise SystemExit(main())
