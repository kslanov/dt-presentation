"""dt-retrieve — inspect what a use case's retrieval policy pulls (interface layer).

Runs a retrieval policy and prints the per-slice hits (note_id / corpus / score +
preview). For inspection only — no generation, no LLM. Supports the layer scope
(vault-only / legacy / both) and ad-hoc legacy filters.

Usage:
    uv run python cli/dt_retrieve.py client_correspondence "письмо Инитеху" \\
        --client client-initech
    uv run python cli/dt_retrieve.py client_correspondence "…" --corpus vault
    uv run python cli/dt_retrieve.py deep_client_reference "методика РАМПУР" \\
        --corpus legacy --section Presale --era 2018-2023
"""

from __future__ import annotations

import argparse
import os
import sys

# cli/ is not an importable package; put our own dir on sys.path so the shared
# _env helper imports cleanly in both script and load-by-path (test) contexts.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.retrieval.policies import run_policy

_CORPUS = {"both": None, "vault": "vault", "legacy": "legacy"}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-retrieve", description="Inspect a retrieval policy's slices."
    )
    parser.add_argument("use_case")
    parser.add_argument("query")
    parser.add_argument(
        "--corpus",
        choices=("both", "vault", "legacy"),
        default="both",
        help="Layer scope: both (default), vault (vault-only flag), or legacy.",
    )
    parser.add_argument("--client")
    parser.add_argument("--section")
    parser.add_argument("--era")
    parser.add_argument("--k", type=int, default=None, help="Override per-slice k.")
    parser.add_argument(
        "--no-boost",
        action="store_true",
        default=False,
        help="Disable the curated boost (rank purely by relevance).",
    )
    args = parser.parse_args(argv)
    load_env()  # engine/.env → os.environ before any config/retrieval read

    params: dict[str, str] = {}
    if args.client:
        params["client_id"] = args.client
        params["client"] = args.client
    if args.section:
        params["section"] = args.section
    if args.era:
        params["era"] = args.era

    result = run_policy(
        args.use_case,
        args.query,
        params,
        corpus=_CORPUS[args.corpus],
        boost_curated=not args.no_boost,
    )

    print(f"use_case={result.use_case} corpus={args.corpus}")
    for name, hits in result.slices.items():
        print(f"\n## slice: {name} ({len(hits)} hits)")
        for r in hits:
            corpus = r.metadata.get("corpus", "?")
            preview = r.text.replace("\n", " ")[:80]
            print(f"  [{corpus}] {r.note_id} score={r.score:.4f} — {preview}")
    print(f"\nContext: {len(result.context)} de-duplicated chunks.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
