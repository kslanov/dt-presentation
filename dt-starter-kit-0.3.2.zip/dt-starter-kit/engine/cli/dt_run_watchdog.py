"""dt-run-watchdog — сторож прогонов без прогресса (ADAPTER-HONEST-1 п.5).

Тонкая обёртка над :func:`core.operational.runwatch.run_watchdog`. Плановый запуск —
launchd ``com.dt.run.watchdog`` (каждые 10 минут). Прогон, чей lock удерживается, а
heartbeat старше ``DT_RUN_STALL_MIN`` (дефолт 60) минут, снимается: SIGTERM → SIGKILL,
lock удаляется, событие — в лог/метрики/журнал стадий. Живой, но медленный прогон
(heartbeat свежий) не трогается.

Usage:
    uv run python cli/dt_run_watchdog.py              # снять зависшие
    uv run python cli/dt_run_watchdog.py --dry-run    # только показать
    uv run python cli/dt_run_watchdog.py --status     # состояние всех lock'ов
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import sync_log_path
from core.logging_setup import setup_logging
from core.operational.runwatch import run_watchdog, scan


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-run-watchdog",
        description="Снять прогоны (dt-sync/index) без прогресса дольше DT_RUN_STALL_MIN минут.",
    )
    parser.add_argument("--dry-run", action="store_true", default=False,
                        help="Только показать, что было бы снято.")
    parser.add_argument("--status", action="store_true", default=False,
                        help="Показать состояние всех lock'ов и выйти.")
    args = parser.parse_args(argv)
    load_env()
    setup_logging(log_path=sync_log_path().with_name("run-watchdog.log"))
    logging.getLogger("core.operational.runwatch").setLevel(logging.INFO)

    if args.status:
        for st in scan():
            print(st.to_dict())
        return 0
    results = run_watchdog(dry_run=args.dry_run)
    if not results:
        print("dt-run-watchdog: зависших прогонов нет")
        return 0
    for r in results:
        verdict = "СНЯТ" if r["killed"] else f"не снят ({r['reason']})"
        print(f"dt-run-watchdog: {r['label']} pid={r['pid']} mode={r['mode']} "
              f"step={r['step']} без прогресса {r['age_min']} мин — {verdict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
