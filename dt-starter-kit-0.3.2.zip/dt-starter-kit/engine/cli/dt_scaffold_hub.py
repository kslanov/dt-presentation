"""dt-scaffold-hub — create a minimal stub entity hub (interface layer).

Human-in-the-loop only: hubs are NEVER auto-created during ingest. This writes a
minimal ``type: hub`` stub into the curated area (e.g. ``04-clients/``) so the
next ``dt_legacy_ingest`` resolves layer-B links to it and drops the client from
``_legacy/_candidates-for-hub.md``.

Usage:
    uv run python cli/dt_scaffold_hub.py --client "Хули"
    uv run python cli/dt_scaffold_hub.py --from-candidates client-hooli,client-kct
    uv run python cli/dt_scaffold_hub.py --from-candidates client-hooli --yes
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# cli/ is not an importable package; put our own dir on sys.path so the shared
# _env helper imports cleanly in both script and load-by-path (test) contexts.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import default_vault_path
from core.legacy.linking import CANDIDATES_NOTE, scaffold_hub


def _candidate_names(vault_path: Path) -> dict[str, str]:
    """Parse ``_candidates-for-hub.md`` → {suggested_id: client name}."""
    path = vault_path / "_legacy" / CANDIDATES_NOTE
    out: dict[str, str] = {}
    if not path.is_file():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.startswith("| ") or "| ---" in line or line.startswith("| клиент"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) >= 4 and cells[3].startswith("client-"):
            out[cells[3]] = cells[0]
    return out


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-scaffold-hub",
        description="Create a minimal stub entity hub (human-in-the-loop).",
    )
    parser.add_argument("--vault", type=Path, default=default_vault_path())
    parser.add_argument("--client", help="Client name to scaffold a hub for.")
    parser.add_argument(
        "--type", dest="entity", default="client", help="Entity type (default: client)."
    )
    parser.add_argument(
        "--from-candidates",
        help="Comma-separated suggested ids from _candidates-for-hub.md.",
    )
    parser.add_argument(
        "--yes", action="store_true", default=False, help="Skip the confirmation prompt."
    )
    args = parser.parse_args(argv)
    load_env()  # engine/.env → os.environ (DT_VAULT_PATH etc.) before config reads

    targets: list[tuple[str, str]] = []  # (name, entity)
    if args.client:
        targets.append((args.client, args.entity))
    if args.from_candidates:
        names = _candidate_names(args.vault)
        for cid in (c.strip() for c in args.from_candidates.split(",") if c.strip()):
            name = names.get(cid)
            if not name:
                print(f"warning: {cid} not found in {CANDIDATES_NOTE}; skipping.")
                continue
            targets.append((name, "client"))

    if not targets:
        print("Nothing to do: pass --client \"<name>\" or --from-candidates <ids>.")
        return 2

    if not args.yes:
        print("About to scaffold stub hubs:")
        for name, entity in targets:
            print(f"  - {entity}: {name}")
        reply = input("Proceed? [y/N] ").strip().lower()
        if reply not in ("y", "yes"):
            print("Aborted.")
            return 1

    for name, entity in targets:
        path, created = scaffold_hub(args.vault, name, entity=entity)
        status = "created" if created else "exists (unchanged)"
        print(f"{status}: {path}")
    print("Next: run `uv run python cli/dt_legacy_ingest.py` to resolve links.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
