"""dt-secrets — статус/миграция секретов из ``.env`` в macOS Keychain (SEC-5).

Секреты контура (``TICKTICK_ACCESS_TOKEN``, ``TICKTICK_CLIENT_ID``,
``TICKTICK_CLIENT_SECRET``, ``TIMETTA_API_TOKEN``) исторически лежат в ``engine/.env``
(plaintext). Этот CLI помогает переехать в Keychain, оставаясь обратно
совместимым: :func:`core.secrets.get_secret` читает env раньше Keychain, поэтому до
миграции всё работает как прежде.

Три действия (взаимоисключающие):

* ``--status`` — где живёт каждый секрет: ``env`` (в ``os.environ`` / ``.env``) |
  ``keychain`` (учётка ``dt:<NAME>``) | ``absent`` (нигде). **Значения не печатаются.**
* ``--migrate`` — для каждого секрета, доступного сейчас в env, завести/обновить
  учётку Keychain (``security add-generic-password -U -s dt:<NAME> -a dt -w <value>``).
  Значение попадает в ``argv`` дочернего ``security`` — приемлемо для локальной
  разовой миграции (отмечено в ``SECURITY.md``); в лог/stdout не выводится.
* ``--prune`` — заменить в ``.env`` строки тех секретов, что **реально уже в
  Keychain**, на маркер БЕЗ значения (``# NAME → Keychain (dt_secrets --status)``;
  сначала бэкап ``.env.bak`` с оригиналами). Значение из plain-text ``.env`` уходит
  (цель SEC-5). Только по явному флагу; не трогает уже вырезанные строки и секреты,
  не переехавшие в Keychain; идемпотентно (маркеры не дублируются).

CLI зависит от core, не наоборот (инвариант §8). Значение секрета не логируется.

Usage::

    uv run python cli/dt_secrets.py --status
    uv run python cli/dt_secrets.py --migrate
    uv run python cli/dt_secrets.py --migrate --prune
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

# cli/ is not an importable package; put our own dir on sys.path so the shared
# _env helper imports cleanly in both script and load-by-path (test) contexts.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import _ENGINE_ENV, load_env

from core.config import env_file
from core.secrets import (
    KEYCHAIN_ACCOUNT,
    KEYCHAIN_PREFIX,
    SECRET_NAMES,
    Runner,
    in_keychain,
    keychain_available,
    secret_location,
)

# Инъектируем subprocess-раннер (образец core.secrets) — тесты подставляют фейк,
# не касаясь живого Keychain.
_KEYCHAIN_TIMEOUT = 5.0


def _default_runner(cmd: list[str], timeout: float) -> tuple[int, str, str]:
    proc = subprocess.run(  # noqa: S603 — cmd — фиксированная security-инвокация
        cmd, capture_output=True, text=True, timeout=timeout
    )
    return proc.returncode, proc.stdout, proc.stderr


def _cmd_status(*, runner: Runner | None = None) -> int:
    """``--status``: где живёт каждый секрет — БЕЗ значений."""
    print("Секреты (SEC-5) — расположение (значения не выводятся):")
    for name in SECRET_NAMES:
        loc = secret_location(name, runner=runner)
        label = {"env": "env/.env", "keychain": "keychain", "absent": "нигде"}[loc]
        print(f"  {name:<24} {label}")
    if not keychain_available(runner=runner):
        print("  (Keychain недоступен здесь — не macOS или нет `security`)")
    return 0


def _cmd_migrate(*, runner: Runner | None = None) -> int:
    """``--migrate``: env → Keychain для каждого доступного в env секрета."""
    if not keychain_available(runner=runner):
        print(
            "error: Keychain недоступен (не macOS / нет `security`) — миграция невозможна",
            file=sys.stderr,
        )
        return 2
    run = runner or _default_runner
    migrated = 0
    for name in SECRET_NAMES:
        value = os.environ.get(name)
        if not value:
            print(f"  {name:<24} пропуск (нет в env — нечего мигрировать)")
            continue
        # -U: обновить, если учётка уже есть. Значение секрета в лог не пишем.
        cmd = [
            "security", "add-generic-password", "-U",
            "-s", f"{KEYCHAIN_PREFIX}{name}",
            "-a", KEYCHAIN_ACCOUNT,
            "-w", value,
        ]
        try:
            code, _out, _err = run(cmd, _KEYCHAIN_TIMEOUT)
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as exc:
            print(f"  {name:<24} ОШИБКА: {type(exc).__name__}", file=sys.stderr)
            continue
        if code == 0:
            print(f"  {name:<24} → Keychain (dt:{name})")
            migrated += 1
        else:
            # stderr от security может содержать имя учётки, но НЕ значение (-w в argv)
            print(f"  {name:<24} ОШИБКА security (код {code})", file=sys.stderr)
    print(f"Мигрировано: {migrated}/{len(SECRET_NAMES)}.")
    if migrated:
        print("Проверь `--status`; затем при желании `--prune` уберёт их из .env.")
    return 0


def _cmd_prune(*, env_path: Path | None = None, runner: Runner | None = None) -> int:
    """``--prune``: заменить в ``.env`` секреты (уже в Keychain) на маркер без значения."""
    path = env_path or _ENGINE_ENV
    if not path.is_file():
        print(f"error: .env не найден: {path}", file=sys.stderr)
        return 2

    # Резать только реально переехавшие в Keychain (env-fallback игнорируем).
    to_prune = {n for n in SECRET_NAMES if in_keychain(n, runner=runner)}
    if not to_prune:
        print("Нет секретов в Keychain — нечего вырезать (сначала `--migrate`).")
        return 0

    changed: list[str] = []

    def _marker(key: str, line: bytes) -> bytes | None:
        # ^<NAME>= (допускаем ведущие пробелы и export), НЕ трогаем закомментированные.
        if key not in to_prune:
            return None
        # Заменяем строку на маркер БЕЗ значения (иначе plain-text секрет так и остался бы лежать
        # в .env — цель SEC-5 не достигнута). Значение живёт только в бэкапе .env.bak-<ts>. Маркер
        # не начинается с ``<NAME>=`` → повторный prune его не матчит (идемпотентно).
        changed.append(key)
        nl = "\n" if line.endswith(b"\n") else ""
        return f"# {key} → Keychain (dt_secrets --status){nl}".encode()

    # CONFIG-1: единственный писатель .env - core.config.env_file (один бэкап, права 600)
    edit = env_file.replace_lines(path, _marker)
    if not changed:
        print("Строки секретов в .env не найдены (уже вырезаны?) — .env не изменён.")
        return 0

    backup = edit.backup
    print(f"Бэкап (с оригиналами): {backup}")
    print(f"Вырезано из .env (значение убрано, маркер оставлен): {', '.join(sorted(set(changed)))}")
    print("Секреты теперь читаются из Keychain (get_secret: env→keychain).")
    return 0


def main(argv: list[str] | None = None) -> int:
    load_env()  # engine/.env → os.environ (значения не логируются)
    parser = argparse.ArgumentParser(
        prog="dt-secrets",
        description="Статус/миграция секретов .env → macOS Keychain (SEC-5).",
    )
    # --status исключает изменяющие действия; --migrate и --prune комбинируются.
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--status", action="store_true",
                       help="показать, где живёт каждый секрет (без значений)")
    group.add_argument("--migrate", action="store_true",
                       help="перенести доступные в env секреты в Keychain (idempotent, -U)")
    parser.add_argument("--prune", action="store_true",
                        help="закомментировать в .env секреты, уже осевшие в Keychain "
                             "(бэкап .env.bak). Можно вместе с --migrate или отдельно.")
    args = parser.parse_args(argv)

    if not (args.status or args.migrate or args.prune):
        parser.error("укажи действие: --status, --migrate и/или --prune")

    if args.status:
        return _cmd_status()

    rc = 0
    if args.migrate:
        rc = _cmd_migrate()
    if args.prune:
        rc = _cmd_prune() or rc
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
