"""dt-shim - stdio-мост хоста (Claude Desktop/Cowork) к демону: stdio -> ``/mcp/<профиль>``.

Desktop запускает только КОМАНДУ (локальный http-адрес для него недостижим), поэтому мост - тонкий
процесс между ним и демоном ``com.dt.server``. Протокол мост НЕ разбирает: каждая строка stdin
(JSON-RPC) уходит POST-ом в демон как есть, ответ (JSON или SSE-поток) возвращается строками в
stdout. Поэтому ``initialize`` с ``clientInfo`` хоста (идентичность хоста в телеметрии - его имя),
``instructions``, ``tools/*``, ``prompts/*`` и будущие методы проходят сквозь. Только httpx +
stdlib.

* адрес: ``--url http://127.0.0.1:8787/mcp/full`` ЛИБО ``--profile lean|pult|full`` [``--port``]
  (дефолт ``DT_WEB_PORT`` или 8787, loopback);
* токен: ТОЛЬКО из файла ``--token-file`` (в аргументах процесса виден путь, не токен); в
  stdout/stderr не печатается;
* ``initialize`` хоста запоминается: демон перезапущен (сессии MCP рвутся, старый id -> 404) - мост
  на 404 сам повторяет сохраненный ``initialize`` и запрос (``--no-reconnect`` - для тестов);
* демон не отвечает - хосту уходит ошибка JSON-RPC с командой ``launchctl kickstart``; мост жив и
  подключится, когда демон вернется. Нет ``httpx`` - строка в stderr и выход 2.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

try:
    import httpx
except ImportError:  # мост запускается .venv/bin/python напрямую, без uv run
    print("dt-shim: нет httpx (uv sync в каталоге engine)", file=sys.stderr)
    raise SystemExit(2) from None

ACCEPT = "application/json, text/event-stream"
PROFILES = ("lean", "pult", "full")


def _log(text: str) -> None:
    print(f"[dt-shim] {text}", file=sys.stderr, flush=True)


class Shim:
    def __init__(self, url: str, token: str, reconnect: bool = True,
                 label: str = "com.dt.server") -> None:
        self.url, self.reconnect = url, reconnect
        self.label = label  # метка launchd демона (у экземпляра - com.dt.server-<имя>)
        self.session_id: str | None = None
        self.protocol: str | None = None
        self._init_line: str | None = None  # initialize хоста - для повторного подключения
        self._out_lock = asyncio.Lock()
        self._reconnect_lock = asyncio.Lock()
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(None, connect=10.0), headers={"Authorization": f"Bearer {token}"})

    def _down_text(self) -> str:
        u = urlparse(self.url)
        port = u.port or 8787
        if u.hostname not in (None, "127.0.0.1", "localhost", "::1"):  # CONFIG-1: по Tailscale
            return (f"сервер {u.hostname}:{port} не отвечает: Tailscale подключен? демон на "
                    "сервере жив (на сервере `dt doctor`)?")
        return (f"демон не отвечает на 127.0.0.1:{port}: "
                f"`launchctl kickstart -k gui/{os.getuid()}/{self.label}`")

    async def emit(self, payload: str) -> None:
        async with self._out_lock:
            sys.stdout.buffer.write(payload.encode("utf-8") + b"\n")
            sys.stdout.buffer.flush()

    async def _error(self, msg: dict[str, Any], text: str) -> None:
        if "id" in msg:  # на уведомление (без id) отвечать нечем
            await self.emit(json.dumps({"jsonrpc": "2.0", "id": msg["id"],
                                        "error": {"code": -32000, "message": text}}))

    def _headers(self) -> dict[str, str]:
        headers = {"Accept": ACCEPT, "Content-Type": "application/json"}
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
        if self.protocol:
            headers["MCP-Protocol-Version"] = self.protocol
        return headers

    async def handle(self, line: str, *, retried: bool = False) -> None:
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            _log("не JSON на stdin - пропущено")
            return
        is_init = isinstance(msg, dict) and msg.get("method") == "initialize"
        if is_init:
            self._init_line = line
        sid_used = self.session_id
        try:
            async with self._client.stream(
                "POST", self.url, content=line.encode("utf-8"), headers=self._headers()
            ) as resp:
                if is_init:
                    self.session_id = resp.headers.get("mcp-session-id")
                if resp.status_code == 404 and self.reconnect and not is_init and not retried:
                    await resp.aread()
                    if await self._reinitialize(sid_used):
                        await self.handle(line, retried=True)
                        return
                if resp.status_code >= 400:
                    await resp.aread()
                    lost = resp.status_code == 404
                    await self._error(msg, (
                        "сессия потеряна (демон перезапущен), мост запущен с --no-reconnect: "
                        f"перезапусти хост; демон: `launchctl kickstart -k gui/{os.getuid()}/"
                        f"{self.label}`" if lost else f"демон ответил HTTP {resp.status_code}"))
                    return
                ctype = resp.headers.get("content-type", "")
                if "text/event-stream" in ctype:
                    await self._pump_sse(resp, is_init)
                elif "json" in ctype:
                    await self._forward((await resp.aread()).decode("utf-8"), is_init)
                # 202 Accepted (уведомления): тела нет
        except httpx.HTTPError:
            await self._error(msg, self._down_text())

    async def _reinitialize(self, stale_sid: str | None) -> bool:
        """Сессия потеряна (демон перезапущен): тот же ``initialize`` хоста + ``initialized``.

        Один раз на потерю: параллельные запросы ждут замок и видят уже новый id сессии. Ответ на
        повторный initialize хосту НЕ пересылается (он уже получил свой)."""
        async with self._reconnect_lock:
            if self.session_id != stale_sid:
                return True  # другой запрос уже переподключил
            if not self._init_line:
                return False
            self.session_id = None
            try:
                async with self._client.stream("POST", self.url, content=self._init_line.encode(),
                                               headers=self._headers()) as resp:
                    if resp.status_code >= 400:
                        await resp.aread()
                        return False
                    self.session_id = resp.headers.get("mcp-session-id")
                    await resp.aread()
                note = '{"jsonrpc":"2.0","method":"notifications/initialized"}'
                async with self._client.stream("POST", self.url, content=note.encode(),
                                               headers=self._headers()) as resp:
                    await resp.aread()
            except httpx.HTTPError:
                return False
            _log("сессия потеряна (404) - переподключился")
            return self.session_id is not None

    async def _pump_sse(self, resp: httpx.Response, is_init: bool) -> None:
        data: list[str] = []
        async for raw in resp.aiter_lines():
            if raw == "":
                if data:
                    await self._forward("\n".join(data), is_init)
                    data = []
            elif raw.startswith("data:"):
                data.append(raw[5:].lstrip(" "))
        if data:
            await self._forward("\n".join(data), is_init)

    async def _forward(self, body: str, is_init: bool) -> None:
        if not body.strip():  # SSE-событие без data (затравка потока возобновления) - не сообщение
            return
        if is_init:  # согласованная версия протокола нужна заголовком следующих запросов
            try:
                self.protocol = json.loads(body)["result"]["protocolVersion"]
            except (KeyError, TypeError, ValueError):
                pass
        await self.emit(body)

    async def close(self) -> None:
        if self.session_id:
            try:
                await self._client.delete(self.url, headers=self._headers())
            except httpx.HTTPError:
                pass
        await self._client.aclose()


async def run(url: str, token: str, reconnect: bool = True, label: str = "com.dt.server") -> None:
    shim = Shim(url, token, reconnect, label)
    loop = asyncio.get_running_loop()
    tasks: set[asyncio.Task[None]] = set()
    try:
        while True:
            line = await loop.run_in_executor(None, sys.stdin.buffer.readline)
            if not line:
                break  # хост закрыл stdin
            text = line.decode("utf-8").strip()
            if not text:
                continue
            try:
                notification = "id" not in json.loads(text)
            except json.JSONDecodeError:
                notification = True
            if notification:  # initialized/cancelled: завершаем до следующих запросов (порядок)
                await shim.handle(text)
                continue
            task = asyncio.create_task(shim.handle(text))  # медленный вызов не держит остальные
            tasks.add(task)
            task.add_done_callback(tasks.discard)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    finally:
        await shim.close()


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="dt-shim: stdio -> streamable-http мост к демону DT")
    p.add_argument("--url", help="http://127.0.0.1:<порт>/mcp/<профиль> (или --profile)")
    p.add_argument("--profile", choices=PROFILES, help="профиль инструментов (вместо --url)")
    p.add_argument("--port", type=int, default=int(os.environ.get("DT_WEB_PORT") or 8787),
                   help="порт демона для --profile (дефолт DT_WEB_PORT или 8787)")
    p.add_argument("--token-file", required=True, help="файл с Bearer-токеном (read или rw)")
    p.add_argument("--label", default="com.dt.server",
                   help="метка launchd демона для подсказок (экземпляр: com.dt.server-<имя>)")
    p.add_argument("--no-reconnect", action="store_true",
                   help="не переподключаться на потерю сессии (404) - для тестов")
    args = p.parse_args(argv)
    if bool(args.url) == bool(args.profile):
        p.error("нужен ровно один из --url / --profile")
    url = args.url or f"http://127.0.0.1:{args.port}/mcp/{args.profile}"
    try:
        token = Path(args.token_file).expanduser().read_text(encoding="utf-8").strip()
    except OSError as exc:
        print(f"dt-shim: токен-файл не прочитан: {type(exc).__name__}", file=sys.stderr)
        return 2
    if not token:
        print("dt-shim: токен-файл пуст", file=sys.stderr)
        return 2
    asyncio.run(run(url, token, not args.no_reconnect, args.label))
    return 0


if __name__ == "__main__":
    sys.exit(main())
