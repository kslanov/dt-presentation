"""dt skills — скиллы DT из git (``engine/skills``): список, линтер переносимости, экспорт.

TOOLS-PROFILES-1 п.2. Источник — ``engine/skills/<name>/SKILL.md``; отсюда генерируются

* ``export cowork --out DIR`` — библиотека Cowork (те же файлы; сам файл в библиотеке аккаунта
  обновляет человек через ``save_skill`` — генератор в нее не пишет);
* ``export kimi --out DIR [--profile lean]`` — плагин Kimi Work: ``skills/`` + ``kimi.plugin.json``;
  скиллы подбираются под профиль (``fit_profile``: вызовы скилла ⊆ инструменты профиля), отброшенные
  называются в выводе и в ``skipped`` манифеста ``.dt-skills.json``;
* ``export cherry --out DIR [--profile lean]`` (то же: ``export --host cherry``) - скиллы для Cherry
  Studio: ``<DIR>/<имя>/SKILL.md`` с frontmatter ``name``/``description``/``version`` (как у
  встроенных скиллов Cherry), тот же состав, что в плагине Kimi (``fit_profile`` под профиль);
  установка из каталога - в UI Cherry (Settings → Skills), свой стор Cherry генератор не пишет;
* ``export prompts --out DIR`` — тела скиллов (без YAML-шапки) + ``prompts.json``: для хоста без
  MCP-``prompts``; сам сервер отдает их по протоколу в любом профиле;
* ``dt-owner`` (PROFILE-1) - скилл правил владельца, ГЕНЕРИРУЕТСЯ из профиля при экспорте
  cowork/kimi/cherry (``rules.md`` + строки ``about.md``, шапка «источник, версия»); нет профиля
  или ``rules.md`` пуст - не создается, причина в выводе и в ``skipped`` манифеста;
* ``lint`` — линтер переносимости (нет Claude/Cowork/песочницы, инструменты только из реестра,
  шапка валидна); код возврата 1 при нарушениях.

Usage:
    uv run python cli/dt_skills.py list
    uv run python cli/dt_skills.py lint
    uv run python cli/dt_skills.py export cowork --out /tmp/cowork-skills
    uv run python cli/dt_skills.py export kimi --out plugins/kimi-work
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.skills import (
    SKILLS_DIR,
    Skill,
    export_cowork,
    export_kimi_skills,
    fit_profile,
    format_skipped,
    lint_skills,
    load_skills,
)

TARGETS = ("cowork", "kimi", "prompts", "cherry")


def _server() -> Any:
    """MCP-слой (core его не знает) — как делает ``dt_kpi``."""
    path = Path(__file__).resolve().parents[1] / "mcp-server" / "server.py"
    spec = importlib.util.spec_from_file_location("dt_skills_server", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def tool_names(personal: bool = False) -> tuple[str, ...]:
    """Реестр инструментов MCP-слоя (``TOOL_NAMES``); ``personal`` - плюс личные (PERSONAL-1)."""
    srv = _server()
    return (*srv.TOOL_NAMES, *srv.PERSONAL_TOOLS) if personal else tuple(srv.TOOL_NAMES)


def profile_tools(profile: str, personal: bool = False) -> tuple[str, ...]:
    """Инструменты профиля хоста (``PROFILES[profile]``); ``personal`` - плюс личные."""
    srv = _server()
    base = tuple(srv.PROFILES[profile])
    return (*base, *srv.PERSONAL_TOOLS) if personal else base


def cmd_list(personal: bool = False) -> int:
    for sk in load_skills(personal=personal):
        print(f"{sk.name}\t{sk.description[:100]}")
    return 0


def cmd_lint(personal: bool = False) -> int:
    skills = load_skills(personal=personal)
    issues = lint_skills(skills, tool_names(personal))
    for issue in issues:
        print(issue)
    print(f"скиллов: {len(skills)}, нарушений: {len(issues)}")
    return 1 if issues else 0


def _with_owner_skill(skills: list[Skill], target: str) -> tuple[list[Skill], dict[str, list[str]]]:
    """PROFILE-1: к скиллам из git добавить сгенерированный ``dt-owner`` (cowork|kimi|cherry).

    ``(скиллы, extra_skipped)``: нет профиля / ``rules.md`` пуст / линтер ругается на текст
    профиля - скилл не создается, причина идет в ``skipped`` манифеста и в вывод."""
    if target not in ("cowork", "kimi", "cherry"):
        return skills, {}
    from core.owner import load_profile
    from core.owner.export import SKILL_NAME, owner_skill

    skill, reason = owner_skill(load_profile(), tool_names())
    if skill is None:
        print(f"{SKILL_NAME}: не сформирован - {reason}")
        return skills, {SKILL_NAME: [reason]}
    return [*skills, skill], {}


def cmd_export(target: str, out: Path, profile: str = "lean", personal: bool = False) -> int:
    """``personal`` (PERSONAL-1): состав личной записи хоста - скиллы реестра + ``skills-personal/``
    и профиль с ``personal_recall``; генерируемый ``dt-owner`` не добавляется (он из рабочего
    vault)."""
    skills = load_skills(personal=personal)
    issues = lint_skills(skills, tool_names(personal))
    if issues:
        for issue in issues:
            print(issue, file=sys.stderr)
        print("экспорт остановлен: сначала почини линтер (dt skills lint)", file=sys.stderr)
        return 1
    out = out.expanduser()
    skills, owner_skipped = ((skills, {}) if personal else _with_owner_skill(skills, target))
    if target == "cowork":
        files = export_cowork(out, skills, skipped=owner_skipped)  # Cowork = full: весь реестр
        print(f"{len(files)} скиллов → {out}\nПереопубликуй в библиотеку Cowork через save_skill "
              "(генератор в библиотеку аккаунта не пишет).")
    elif target == "cherry":
        from core.kimi_plugin import engine_version
        from core.skills import export_cherry_skills

        fit, skipped = fit_profile(skills, profile_tools(profile, personal))
        files = export_cherry_skills(out, fit, version=engine_version(),
                                     skipped={**skipped, **owner_skipped})
        print(f"{len(files)} скиллов (профиль {profile}) → {out}\nУстановка: Cherry Studio → "
              "Settings → Skills → «Установить из каталога», по одной папке на навык "
              "(skills/<имя>, где лежит SKILL.md; стор Cherry генератор не пишет).")
        if skipped:
            print(format_skipped(skipped, profile))
    elif target == "kimi":
        from core.host_config import kimi_plugin_manifest, render

        # MODEL-1-FIT: на хосте только то, что выполнимо профилем (скилл ⊆ инструменты профиля)
        fit, skipped = fit_profile(skills, profile_tools(profile, personal))
        files = export_kimi_skills(out, fit, skipped={**skipped, **owner_skipped})
        manifest = kimi_plugin_manifest(profile, skills=[s.name for s in fit])
        (out / "kimi.plugin.json").write_text(render(manifest) + "\n", encoding="utf-8")
        print(f"{len(files)} скиллов + kimi.plugin.json → {out}")
        if skipped:
            print(format_skipped(skipped, profile))
    else:
        out.mkdir(parents=True, exist_ok=True)
        index = []
        for sk in skills:
            (out / f"{sk.name}.md").write_text(sk.body, encoding="utf-8")
            index.append({"name": sk.name, "description": sk.description, "file": f"{sk.name}.md"})
        (out / "prompts.json").write_text(
            json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"{len(skills)} prompts → {out}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt skills", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    lst = sub.add_parser("list", help=f"скиллы из {SKILLS_DIR}")
    lnt = sub.add_parser("lint", help="линтер переносимости")
    for p_ in (lst, lnt):
        p_.add_argument("--personal", action="store_true",
                        help="плюс скиллы личной записи хоста (skills-personal/, PERSONAL-1)")
    exp = sub.add_parser("export", help="экспорт скиллов")
    exp.add_argument("target", nargs="?", choices=TARGETS)
    exp.add_argument("--host", choices=TARGETS, default=None,
                     help="то же, что позиционный target (dt skills export --host cherry)")
    exp.add_argument("--out", type=Path, required=True, help="каталог назначения")
    exp.add_argument("--profile", choices=("lean", "pult", "full"), default="lean",
                     help="kimi/cherry: профиль хоста, под него подбираются скиллы")
    exp.add_argument("--personal", action="store_true",
                     help="личная запись хоста: + skills-personal/, профиль с personal_recall")
    args = parser.parse_args(argv)
    if args.cmd == "list":
        return cmd_list(args.personal)
    if args.cmd == "lint":
        return cmd_lint(args.personal)
    target = args.host or args.target
    if not target:
        parser.error("export: нужен target (cowork|kimi|prompts|cherry) или --host")
    return cmd_export(target, args.out, args.profile, args.personal)


if __name__ == "__main__":
    raise SystemExit(main())
