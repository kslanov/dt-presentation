"""dt-smoke — сценарный прогон на боевом окружении (LIVE-SMOKE-1, interface layer).

Гоняет ``tests/test_live_smoke.py`` (маркер ``live_smoke``, из обычного ``pytest``
исключён) и печатает человекочитаемый итог: строка на сценарий — ok/fail, деталь
«что именно увидел», длительность. Тот же итог дописывается в
``.derived/logs/smoke.log``, последней строкой блока — машинный ``RESULT``
(:mod:`core.smoke`), который читает doctor-гард «прогон старше 8 дней или красный».

Почему pytest внутри CLI, а не свой раннер: сценарии обязаны идти через тот же
conftest, что и все тесты, — его autouse-фикстуры уводят записи (facts/jobs-БД,
журнал метрик, DT_LOGS_PATH) в tmp. Свой раннер означал бы смоук, который пишет в
боевые сторы.

Usage:
    uv run python cli/dt_smoke.py            # прогон + итог + дозапись лога
    uv run python cli/dt_smoke.py --no-log   # только на экран
Exit code: 1, если хотя бы один сценарий красный (для launchd/скриптов), иначе 0.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.smoke import format_result, smoke_log_path

_ENGINE_DIR = Path(__file__).resolve().parents[1]
_SCENARIOS_PATH = _ENGINE_DIR / "tests" / "test_live_smoke.py"

_MARK = {"ok": "[ ok ]", "fail": "[FAIL]"}
# Сколько строк упавшего сценария показывать: причина — это assert и его сообщение,
# а не весь трейс (полный — в выводе pytest, который CLI не глотает).
_REASON_LINES = 6


@dataclass
class Scenario:
    """Результат одного сценария для рендера и лога."""

    title: str
    ok: bool
    detail: str = ""
    reason: str = ""
    duration_s: float = 0.0


@dataclass
class _Collector:
    """pytest-плагин: собирает названия сценариев, вердикты и детали.

    Название берётся из аргумента маркера (``@pytest.mark.live_smoke("С-1 …")``),
    деталь — из ``record_property("detail", …)`` самого сценария. Оба живут рядом
    с проверкой, а не в таблице на стороне CLI: иначе они разъедутся.
    """

    scenarios: list[Scenario] = field(default_factory=list)
    _titles: dict[str, str] = field(default_factory=dict)

    def pytest_collection_modifyitems(self, items: list) -> None:
        for item in items:
            mark = item.get_closest_marker("live_smoke")
            title = str(mark.args[0]) if mark and mark.args else item.name
            self._titles[item.nodeid] = title

    def pytest_runtest_logreport(self, report) -> None:
        if report.when == "setup" and report.failed:
            # Сорванная фикстура — тоже красный сценарий (иначе прогон «зелёный»,
            # потому что ни один сценарий не запустился).
            self._add(report, ok=False)
        elif report.when == "teardown" and report.failed:
            # Сессионный гард боевого .derived (tests/_derived_allowlist.py) падает в teardown
            # последнего теста: «смоук тронул боевой стор» не должен проходить зелёным RESULT.
            # Тест уже записан сценарием — краснеем его, а не заводим одиннадцатый.
            title = self._titles.get(report.nodeid, report.nodeid)
            for sc in self.scenarios:
                if sc.title == title:
                    sc.ok = False
                    sc.reason = "teardown: " + _short_reason(report)
                    return
            self._add(report, ok=False)
        elif report.when == "call":
            self._add(report, ok=report.passed)

    def _add(self, report, ok: bool) -> None:
        detail = next(
            (str(v) for k, v in getattr(report, "user_properties", []) if k == "detail"),
            "",
        )
        self.scenarios.append(
            Scenario(
                title=self._titles.get(report.nodeid, report.nodeid),
                ok=ok,
                detail=detail,
                reason="" if ok else _short_reason(report),
                duration_s=float(getattr(report, "duration", 0.0) or 0.0),
            )
        )


def _short_reason(report) -> str:
    """Причина падения в несколько строк: сообщение assert'а, без полного трейса."""
    text = str(getattr(report, "longreprtext", "") or getattr(report, "longrepr", ""))
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    meaningful = [ln for ln in lines if ln.startswith(("E ", "assert"))] or lines
    return " / ".join(meaningful[:_REASON_LINES])


def run_scenarios(*, path: Path | None = None) -> list[Scenario]:
    """Прогнать сценарии и вернуть их результаты (pytest как раннер)."""
    import pytest

    collector = _Collector()
    pytest.main(
        [
            str(path or _SCENARIOS_PATH),
            "-m", "live_smoke",   # перекрывает addopts (обычный прогон их не берёт)
            "-p", "no:cacheprovider",
            "-q", "--no-header", "--tb=no",
        ],
        plugins=[collector],
    )
    return collector.scenarios


def render(scenarios: list[Scenario], duration_s: float, *, ts: str) -> str:
    """Человекочитаемый итог прогона (он же — блок лога)."""
    failed = [s for s in scenarios if not s.ok]
    head = f"=== {ts} смоук на боевом окружении: {len(scenarios)} сценариев ==="
    lines = [head]
    for s in scenarios:
        mark = _MARK["ok" if s.ok else "fail"]
        tail = s.detail if s.ok else s.reason
        lines.append(f"{mark} {s.title} ({s.duration_s:.1f}с)" + (f": {tail}" if tail else ""))
    if not scenarios:
        lines.append("[FAIL] ни один сценарий не собрался — смотри вывод pytest выше")
        lines.append("Итог: прогон не состоялся (это тоже красный).")
    elif failed:
        lines.append(f"Итог: красных {len(failed)} из {len(scenarios)}.")
    else:
        lines.append(f"Итог: всё зелено ({len(scenarios)} сценариев, {duration_s:.0f}с).")
    lines.append(
        format_result(
            ts=ts,
            ok=bool(scenarios) and not failed,
            total=len(scenarios),
            passed=len(scenarios) - len(failed),
            failed=len(failed),
            duration_s=duration_s,
            red=[s.title for s in failed],
        )
    )
    return "\n".join(lines)


def append_log(text: str, *, path: Path | None = None) -> Path:
    """Дописать блок прогона в ``.derived/logs/smoke.log`` (создаст каталог)."""
    target = path or smoke_log_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as fh:
        fh.write(text + "\n\n")
    return target


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Сценарный смоук Digital Twin на боевом vault/конфиге/сторах."
    )
    parser.add_argument("--no-log", action="store_true",
                        help="не дописывать .derived/logs/smoke.log")
    args = parser.parse_args(argv)

    load_env()
    # Путь лога берём ДО прогона: сценарии идут под conftest, который на время
    # теста уводит DT_LOGS_PATH в tmp (и правильно делает — записи сценариев туда
    # и должны идти). Итог прогона обязан лечь в боевой лог, а не в tmp.
    log_target = smoke_log_path()

    started = time.monotonic()
    scenarios = run_scenarios()
    elapsed = time.monotonic() - started
    ts = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    text = render(scenarios, elapsed, ts=ts)
    print("\n" + text)
    if not args.no_log:
        print(f"\nЛог: {append_log(text, path=log_target)}")
    return 0 if scenarios and all(s.ok for s in scenarios) else 1


if __name__ == "__main__":
    raise SystemExit(main())
