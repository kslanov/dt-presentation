"""dt-status — operational snapshot from the Timetta mirror (interface layer).

By default prints the author's operational slice **from the local mirror**
(no network): active deals, my open issues, projects — grouped, with
``--client`` / ``--project`` / ``--deal`` narrowing. ``--refresh`` first runs a
delta-pull (network) to update the mirror and prints what changed.

CLI depends on core, never the reverse (architecture §8 invariant). The token
is loaded from ``.env`` via python-dotenv and is never printed.

Usage:
    uv run --extra operational python cli/dt_status.py
    uv run --extra operational python cli/dt_status.py --refresh
    uv run --extra operational python cli/dt_status.py --client "Инитех"
    uv run --extra operational python cli/dt_status.py --deal DEAL-29
"""

from __future__ import annotations

import argparse
import sys

import httpx
from dotenv import load_dotenv

from core.config import timetta_user_email, timetta_user_id
from core.operational.connector import OperationalState, StateFilter
from core.operational.timetta.client import TimettaAuthError, TimettaError
from core.operational.timetta.connector import TimettaConnector, discover_user_id


def _fmt_amount(amount: float | None) -> str:
    if amount is None:
        return "—"
    return f"{amount:,.0f}".replace(",", " ")


def render(state: OperationalState) -> str:
    lines: list[str] = []

    lines.append(f"АКТИВНЫЕ СДЕЛКИ ({len(state.deals)})")
    if not state.deals:
        lines.append("  (нет)")
    for d in state.deals:
        client = d.organization_name or "—"
        status = d.state_name or "—"
        prob = f", p={d.probability:.0%}" if d.probability is not None else ""
        code = f"[{d.code}] " if d.code else ""
        lines.append(f"  {code}{d.name or '—'} — {status} — {_fmt_amount(d.amount)}{prob}")
        lines.append(f"      клиент: {client}")

    lines.append("")
    lines.append(f"МОИ ОТКРЫТЫЕ ЗАДАЧИ ({len(state.issues)})")
    if not state.issues:
        lines.append("  (нет)")
    for i in state.issues:
        due = f"срок {i.due_date}" if i.due_date else "без срока"
        status = i.state_name or "—"
        code = f"[{i.code}] " if i.code else ""
        link = i.deal_id or i.project_id or "—"
        lines.append(f"  {code}{i.name or '—'} — {status} — {due}")
        lines.append(f"      связано: {link}")

    lines.append("")
    lines.append(f"ПРОЕКТЫ ({len(state.projects)})")
    if not state.projects:
        lines.append("  (нет)")
    for p in state.projects:
        status = p.state_name or "—"
        client = p.organization_name or "—"
        code = f"[{p.code}] " if p.code else ""
        lines.append(f"  {code}{p.name or '—'} — {status} — клиент: {client}")

    return "\n".join(lines)


def _render_changes(changeset) -> str:
    parts = []
    for entity in ("Deals", "Projects", "Issues"):
        c = changeset.created.get(entity, 0)
        u = changeset.updated.get(entity, 0)
        if c or u:
            parts.append(f"{entity}: +{c} новых, {u} обновлено")
    # ORBIT-3: лента изменений коллег — только счётчики (без имён/полей); бюджет вызовов виден
    h = getattr(changeset, "history", None) or {}
    if h.get("calls") or h.get("added") or h.get("errors"):
        parts.append(
            f"Лента коллег: сделок опрошено {h.get('deals_checked', 0)}, "
            f"вызовов {h.get('calls', 0)}, новых записей {h.get('added', 0)}"
            + (f", сбоев {h['errors']}" if h.get("errors") else "")
        )
    if not parts:
        return "Дельта: изменений нет (зеркало и курсор стабильны)."
    return "Дельта:\n  " + "\n  ".join(parts)


def _ensure_user_id(connector: TimettaConnector) -> int:
    """If the user id is unset, try discovery by email and print the Guid."""
    if timetta_user_id():
        return 0
    email = timetta_user_email()
    if not email:
        print(
            "error: orbit is not scoped — set DT_TIMETTA_USER_ID in .env, or set\n"
            "       DT_TIMETTA_USER_EMAIL to let dt-status discover and print it.",
            file=sys.stderr,
        )
        return 2
    if connector.client is None:
        print("error: TIMETTA_API_TOKEN not set — cannot discover user id.", file=sys.stderr)
        return 2
    guid = discover_user_id(connector.client, email)
    if not guid:
        print(f"error: no Timetta user found for email {email!r}.", file=sys.stderr)
        return 2
    print(
        f"Discovered Timetta user id for {email}:\n\n    DT_TIMETTA_USER_ID={guid}\n\n"
        "Paste the line above into engine/.env, then re-run with --refresh."
    )
    return 3  # discovery-only run; nothing pulled.


def main(argv: list[str] | None = None) -> int:
    load_dotenv()  # engine/.env → os.environ (token + DT_TIMETTA_* knobs)

    parser = argparse.ArgumentParser(
        prog="dt-status",
        description="Operational snapshot from the Timetta mirror (no network unless --refresh).",
    )
    parser.add_argument("--refresh", action="store_true", help="Delta-pull before printing.")
    parser.add_argument("--client", metavar="NAME", help="Filter by client/organization.")
    parser.add_argument("--project", metavar="NAME", help="Filter by project.")
    parser.add_argument("--deal", metavar="NAME", help="Filter by deal.")
    args = parser.parse_args(argv)

    connector = TimettaConnector.from_env()

    if args.refresh:
        code = _ensure_user_id(connector)
        if code != 0:
            return 0 if code == 3 else code
        try:
            changeset = connector.pull_changes()
        except TimettaAuthError as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        except TimettaError as e:
            print(f"error: Timetta pull failed: {e}", file=sys.stderr)
            return 1
        except (httpx.HTTPError, OSError) as e:
            # Offline / DNS / timeout — a clean message instead of a traceback
            # (UX-2). Still prints the last mirror snapshot from disk, but exits
            # non-zero so dt-sync treats the step as failed and retries (RETRY-1).
            print(
                f"error: Timetta unreachable ({type(e).__name__}: {e}) — "
                "showing the last mirror snapshot without refresh.",
                file=sys.stderr,
            )
            state_filter = StateFilter(client=args.client, project=args.project, deal=args.deal)
            print(render(connector.get_state(state_filter)))
            return 1
        print(_render_changes(changeset))
        print()

    state_filter = StateFilter(client=args.client, project=args.project, deal=args.deal)
    print(render(connector.get_state(state_filter)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
