"""dt-sync — launchd-orchestrated operational loop (interface layer, Polish-1).

One orchestrator, three modes, calling the **existing** CLI operations (it never
re-implements their logic — architecture §8 invariant: ``core/`` ⊥ mcp/cli). The
split is by *cost*: turnover of incoming flows is light and runs often; knowledge
maintenance is heavy (loads the BGE model) and runs at night or on demand.

* **fast** — turnover of incoming flows, no linking, no index (loads no model):
  ``refresh`` → ``pull_capture`` → ``reconcile`` → ``file_ingest`` → ``mail_ingest``.
  Frequent (≈every 30 min): pull Timetta (READ-ONLY mirror), pull TickTick
  captures, reconcile the derived persist queues against their sources (RECONCILE-1:
  drop captures finished in TickTick, link proposals whose note vanished), scan the
  **operational** ingest roots for new/changed files into the SRC-1 registry
  (INGEST-SCHEDULE: cheap — register only, no reindex; steady-state fast-path costs
  one stat/file), then the incremental mail delta (deliberately LAST — a
  mail/Outlook problem never delays the Timetta/TickTick steps).
* **index** — knowledge maintenance, signals → links → index:
  ``ocr`` (OCR-1: сканы, бюджет) → ``file_ingest_knowledge`` → ``link_auto`` → ``hub_scan`` →
  ``lint`` (KNOWLEDGE-LINT-1: находки, бюджет, код 0) → ``reindex_inc`` → ``eval`` →
  ``doctor`` (EVAL-3: ночной прогон золотого набора и снимок доктора для пульта;
  оба шага всегда возвращают 0 — качество/диагностика цепочку не роняют). Heavy
  (reindex loads the model), so it runs at NIGHT (03:00) or on demand, decoupled
  from turnover — it ingests knowledge roots (notes) and links/indexes whatever the
  frequent fast passes already wrote to disk. ``reindex_inc`` soft-skips when
  another (re)index holds the index lock and is deliberately NOT retried in-run
  (heavy; the next scheduled pass catches up).
* **full** — ``fast`` + ``index``: the complete pass in one go. Manual «сделать
  всё сейчас»; not on a schedule (frequent fast + nightly index already cover
  it round-the-clock).

Each mode loads ``.env``, takes a **single-instance lock** (``flock`` on
``.derived/operational/dt-sync.lock`` for fast, ``dt-sync-index.lock`` for index — the
two modes run in parallel; a second run of the SAME mode logs «busy» and exits
cleanly), and runs its steps **in sequence with error
isolation**: one step failing (401 / offline / a single write refusal) is logged
and does **not** abort the rest; the process exit code reflects whether any step
failed. **Offline-safe**: a network error is caught, logged, and the run exits
without crashing (the connectors already back off) — ``run()`` never raises.

Logging goes to ``.derived/logs/dt-sync.log`` (rotating by size): a timestamp,
the mode, and per-step **anonymized** counters + errors — never tokens, client
names, or amounts (the underlying CLI summaries are already anonymized; on top of
that every token value from ``.env`` is scrubbed from captured output as a
belt-and-braces guard). A short summary is also printed to stdout for manual
runs.

RETIRE-WRITE-1 (решение К. 2026-10-19): в Timetta движок НЕ пишет — шагов reflect/writeback/
digest/apply_queue больше нет (код — в ветке ``archive/timetta-write``).

Usage:
    uv run --extra operational python cli/dt_sync.py fast
    uv run --extra operational python cli/dt_sync.py index
    uv run --extra operational python cli/dt_sync.py full
"""

from __future__ import annotations

import argparse
import contextlib
import io
import logging
import os
import shutil
import subprocess
import sys
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

# dt_sync.py lives in cli/, which is not an importable package. Put our own
# directory on sys.path so the sibling operation modules import cleanly whether
# we are launched as `python cli/dt_sync.py` (cli/ already on path[0]) or loaded
# by path from a test.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import dt_bridge
import dt_doctor
import dt_eval
import dt_hub_scan
import dt_index
import dt_ingest
import dt_link
import dt_lint
import dt_mail_ingest
import dt_ocr
import dt_pull_capture
import dt_reconcile
import dt_status
from _env import load_env

from core.config import sync_lock_path, sync_log_path
from core.logging_setup import (
    new_corr_id,
    scrub_secrets,
    setup_logging,
)
from core.progress import ProgressBeacon

# A step is (name, thunk). The thunk calls an existing CLI main() with a fixed
# argv and returns its exit code (0 = ok). We reference the operation modules by
# attribute so a single call site stays the source of truth — no duplicated
# logic — and tests can monkeypatch the underlying main().


def _pull_capture() -> int:
    return dt_pull_capture.main([])


def _reconcile() -> int:
    # RECONCILE-1: сверить производные persist-очереди (захваты, link-предложения)
    # с источником — снять разрешённое/исчезшее. Read-only ко внешним системам;
    # общий гард (пустое/ошибочное чтение → пропуск) внутри reconcile_all. Сразу
    # ПОСЛЕ pull_capture: живой фид захвата уже прогрет, гап закрывается в тот же
    # проход. Дёшево (без модели) → в fast.
    return dt_reconcile.main([])


def _refresh() -> int:
    return dt_status.main(["--refresh"])


def _mail_ingest() -> int:
    # Incremental delta by the per-folder cursor (thread manifest dedups).
    # Deliberately AFTER the CRM chain: a mail problem (Outlook not running,
    # JXA hiccup) must never delay the Timetta/TickTick steps.
    return dt_mail_ingest.main([])


def _file_ingest() -> int:
    # INGEST-SCHEDULE PART-1: incremental scan of the OPERATIONAL ingest roots →
    # SRC-1 registry (register_source; no note, no reindex → cheap). The scan's
    # fast-path (path+mtime+size, PART-3а) makes a steady-state pass one stat/file,
    # so it belongs in the frequent fast loop; NDA/dataless are skipped inside the
    # scan (never crash). Knowledge roots (reindex — heavy) are excluded here and
    # handled in the index mode. A long first pass checkpoints/resumes (принцип 11).
    return dt_ingest.main(["--apply", "--route", "operational", "--quiet"])


def _ocr() -> int:
    # OCR-1 п.5: распознавание сканов ПЕРЕД file_ingest_knowledge - свежий текст из .derived/ocr
    # ложится в L1 и перерисовывается в заметки тем же ночным ingest'ом. Бюджет DT_OCR_BUDGET_S
    # (дефолт 30 мин) обрывает и между страницами (чекпойнт страниц документа, продолжит следующая
    # ночь); нет tesseract - строка unavailable, код 0.
    return dt_ocr.main(["--quiet"])


def _file_ingest_knowledge() -> int:
    # INGEST-SCHEDULE PART-1: knowledge ingest roots → legacy note pipeline +
    # incremental reindex (loads the model → heavy), so it runs in the nightly
    # index mode next to the other reindex work, not in the frequent fast loop.
    # WAVE0-HYGIENE п.3: БЕЗ вложенного reindex — следующим шагом идёт reindex_inc
    # (две загрузки модели и два обхода vault за ночь были чистым расходом).
    return dt_ingest.main(["--apply", "--route", "knowledge", "--quiet", "--no-reindex"])


def _link_auto() -> int:
    # Phase 9 этап 4: deterministic auto-linking over the whole vault. The
    # scan-manifest (link_scan.json) skips unchanged notes, so on steady state
    # this only touches the notes the mail delta just wrote (signals → links).
    return dt_link.main(
        ["--resolver", "deterministic", "--scope", "all", "--auto", "--apply"]
    )


def _hub_scan() -> int:
    # HUB-1: лёгкий детектор кандидатов в хабы — ПОСЛЕ link_auto (нерезолвящееся
    # после свежей линковки и есть сигнал). Только очередь; хабы не создаются.
    return dt_hub_scan.main([])


def _lint() -> int:
    # KNOWLEDGE-LINT-1: линт знаний ПОСЛЕ hub_scan (свежие ссылки и кандидаты в хабы), до reindex:
    # четыре детерминированных детектора -> находки -> карточки lint. Бюджет DT_LINT_BUDGET_S с
    # честным partial; ``--step`` -> счетчики без названий, код ВСЕГДА 0 (линт цепочку не роняет).
    return dt_lint.main(["--step"])


def _reindex_inc() -> int:
    # Incremental reindex (links → index). dt_index soft-skips (exit 0) when
    # another (re)index holds the index lock — never breaks an in-flight run.
    # NOT in RETRY_ATTEMPTS on purpose: heavy; the next scheduled pass catches up.
    return dt_index.main([])


def _bridge() -> int:
    # PERSONAL-1 п.5: связи личных заметок с рабочим знанием - ПОСЛЕ reindex_inc (личный индекс
    # свежий), только у личного экземпляра (build_steps). ``--step`` -> код ВСЕГДА 0: рабочий демон
    # молчит в 03:30 - не повод красить ночную цепочку; бюджет DT_BRIDGE_BUDGET_S, честный partial.
    return dt_bridge.main(["--step"])


def _eval() -> int:
    # EVAL-3 п.1: ночной прогон золотого набора ПОСЛЕ reindex_inc (индекс только что
    # обновлён — регрессия поиска видна утром, а не в понедельник). Пишет точку в историю
    # (как dt_eval), под index-локом; ``--step`` → код ВСЕГДА 0: красный/сбой — WARNING в логе,
    # качество не роняет цепочку.
    return dt_eval.main(["--step"])


def _doctor() -> int:
    # EVAL-3 п.2: снимок доктора (.derived/doctor_last.json) ПОСЛЕ eval — к утру он свежий, от
    # него горит индикатор здоровья в шапке пульта. ``--step`` → код всегда 0.
    return dt_doctor.main(["--step"])


# INGRESS-1 п.1: шаги ВХОДА (refresh / pull_capture / file_ingest / mail_ingest /
# file_ingest_knowledge) производятся из реестра адаптеров ``core.ingress.registry`` по ``mode`` и
# ``order``; имена шагов прежние — на них завязаны launchd-логи, свежесть, пульт и test_sync_steps.
# Не-входные шаги (reconcile, link_auto, hub_scan, reindex_inc, eval, doctor) остаются здесь, в
# ``_STATIC_STEPS`` с явным местом (mode, order) — их порядок относительно входов прежний.
#
# fast: refresh(10) → pull_capture(20) → reconcile(25) → file_ingest(30) → mail_ingest(40):
# turnover of incoming flows, no linking, no index; почта ПОСЛЕДНЕЙ — проблема Outlook не
# задерживает Timetta/TickTick. index: ocr(5) → file_ingest_knowledge(10) → link_auto → hub_scan →
# lint → reindex_inc → eval → doctor: heavy (loads the BGE model), ночью или по требованию.
_STEP_THUNKS: dict[str, Callable[[], int]] = {
    "refresh": _refresh,
    "pull_capture": _pull_capture,
    "file_ingest": _file_ingest,
    "mail_ingest": _mail_ingest,
    "file_ingest_knowledge": _file_ingest_knowledge,
}

# PERSONAL-3: имена, места (mode, order) и роли не-входных шагов - в ``core.surface.manifest.
# STATIC_STEPS`` (единый реестр «что есть у роли»); здесь - только исполнители шагов по имени.
# OCR-1: ocr(5) идет перед file_ingest_knowledge (order 10 у адаптера) - тот же ночной проход
# ingest'а перерисует заметки со свежим текстом сканов. EVAL-3: eval/doctor - ночью, последними,
# оба возвращают 0 при любых находках (warn в логе) и не могут уронить цепочку. PERSONAL-1: bridge -
# после reindex_inc, только у личной роли.
_STATIC_THUNKS: dict[str, Callable[[], int]] = {
    "reconcile": _reconcile,
    "ocr": _ocr,
    "link_auto": _link_auto,
    "hub_scan": _hub_scan,
    "lint": _lint,
    "reindex_inc": _reindex_inc,
    "bridge": _bridge,
    "eval": _eval,
    "doctor": _doctor,
}


def _adapter_thunk(adapter) -> Callable[[], int]:
    """Шаг адаптера без собственного CLI-thunk (новый вход): прогон ``run`` из реестра, код 0/1."""

    def thunk() -> int:
        if adapter.run is None:
            return 0
        stats = adapter.run(dry_run=False)
        return 1 if stats.errors else 0

    return thunk


def build_steps(mode: str) -> list[tuple[str, Callable[[], int]]]:
    """Шаги режима ``fast|index`` ДЛЯ РОЛИ процесса: входы из реестра (по ``roles``) + статические
    шаги манифеста роли, по ``order``."""
    from core.ingress import registry
    from core.instance import instance_role
    from core.surface import manifest

    role = instance_role()
    rows: list[tuple[int, str, Callable[[], int]]] = []
    for adapter in registry.adapters(mode, role=role):
        if adapter.step:
            rows.append((adapter.order, adapter.step,
                         _STEP_THUNKS.get(adapter.step) or _adapter_thunk(adapter)))
    rows += [(order, name, _STATIC_THUNKS[name])
             for order, name in manifest.static_steps(mode, role)]
    rows.sort(key=lambda r: r[0])
    return [(name, thunk) for _order, name, thunk in rows]


_FAST_STEPS: list[tuple[str, Callable[[], int]]] = []
_INDEX_STEPS: list[tuple[str, Callable[[], int]]] = []
MODES: dict[str, list[tuple[str, Callable[[], int]]]] = {}


def _rebuild_modes() -> None:
    """Пересобрать режимы ИЗ РЕЕСТРА (на месте: ссылки ``_FAST_STEPS``/``MODES`` остаются живыми).
    Реестр меняется (подложенный адаптер в тесте) → подписка вызывает это снова."""
    _FAST_STEPS[:] = build_steps("fast")
    _INDEX_STEPS[:] = build_steps("index")
    MODES["fast"] = _FAST_STEPS
    MODES["index"] = _INDEX_STEPS
    # full = fast + index: the complete pass, in one go (manual «сделать всё»).
    MODES["full"] = _FAST_STEPS + _INDEX_STEPS


from core.ingress import registry as _ingress_registry  # noqa: E402

_ingress_registry.subscribe(_rebuild_modes)
_rebuild_modes()

# In-run retries for *idempotent read-only* steps hit by transient network
# failures (RETRY-1: two ReadTimeout on refresh during the launchd shakedown
# week; 2026-07 — pull_capture тоже регулярно ловил DNS/SSL-блипы к TickTick и
# ронял fast-sync, хотя это read-only чтение захватов и безопасно повторяется).
# Write steps stay at a single attempt — their own guards decide.
RETRY_ATTEMPTS: dict[str, int] = {"refresh": 3, "pull_capture": 3}
RETRY_BACKOFF_S = 5.0  # 5s, then 10s between attempts (exponential)

# Injectable for tests (so retry tests don't actually sleep).
_sleep = time.sleep


# SYNC-OFFLINE-1 PART-3 — power-assertion на время тяжёлого прогона. Модель спит,
# когда хочет (Power Nap dark-wake); сон ПОСРЕДИ сетевого read = вечное зависание
# (инцидент 36ч). Берём idle-sleep assertion на время index/full-прогона, чтобы
# машина не уснула в середине; окно короткое (прогон завершается — отпускаем).
_CAFFEINATE_MODES = frozenset({"index", "full"})

# Инъектируемо для тестов (чтобы не звать реальный caffeinate).
_popen = subprocess.Popen


def _power_assertion_cmd() -> list[str] | None:
    """``caffeinate -i -w <pid>`` (idle-sleep assertion, привязанная к нашему pid),
    или ``None`` если недоступно (не macOS / нет ``caffeinate``)."""
    if sys.platform != "darwin" or shutil.which("caffeinate") is None:
        return None
    return ["caffeinate", "-i", "-w", str(os.getpid())]


@contextlib.contextmanager
def _power_assertion(mode: str):
    """Держать idle-sleep assertion на время прогона; гарантированно отпустить.

    ``caffeinate -i -w <pid>`` сам завершается, когда наш процесс выходит (страховка
    от вечного caffeinate даже при крахе); вдобавок **явно убиваем в finally** —
    лик-гард (не оставить висящий caffeinate) и путь с исключением. No-op для
    лёгких режимов / не-darwin / нет caffeinate.
    """
    proc = None
    cmd = _power_assertion_cmd() if mode in _CAFFEINATE_MODES else None
    if cmd is not None:
        try:
            proc = _popen(cmd)
        except Exception:  # noqa: BLE001 — assertion не должна ронять прогон
            proc = None
    try:
        yield proc
    finally:
        if proc is not None:
            with contextlib.suppress(Exception):
                proc.terminate()
            try:
                proc.wait(timeout=5)
            except Exception:  # noqa: BLE001 — не отреагировал на TERM → добить
                with contextlib.suppress(Exception):
                    proc.kill()


@contextlib.contextmanager
def _single_instance(lock_path: Path, mode: str = ""):
    """Yield True if we got the lock, False if another run holds it (non-blocking).

    MAIL-LOCK-1: взятие - единый :func:`core.runlock.hold` (раньше здесь был inline flock):
    ADAPTER-HONEST-1 п.5 сохранен - взятый lock **регистрируется** (pid/mode/step в самом файле)
    и несет heartbeat (:mod:`core.runlock`), попытка второго прогона не стирает содержимое lock'а
    живого держателя. Занятость - не исключение для вызывающего: ``False`` (прогон пропускается).
    """
    from core import runlock

    stack = contextlib.ExitStack()
    with stack:
        try:
            stack.enter_context(runlock.hold(lock_path, mode=mode, reentrant=False))
        except runlock.RunLockBusy:
            yield False
            return
        yield True


def lock_paths_for(mode: str, lock_path: Path) -> list[Path]:
    """Lock'и, которые берёт режим (WAVE0-HYGIENE п.4, аудит B5).

    ``fast`` держит ``dt-sync.lock``, ``index`` — свой ``dt-sync-index.lock``; идут
    параллельно: ночной index, растянутый до утра, больше не останавливает почту и
    Timetta (31 пропуск fast в рабочие часы за 53 дня). ``full`` = fast + index → оба.
    Конфликт по vault между mail_ingest (fast) и link_auto/hub_scan (index) решается на
    уровне шага (:mod:`core.linking.quiet`), а не общим lock'ом.
    """
    from core import runlock

    index_lock = runlock.index_sync_lock(lock_path)
    return {"fast": [lock_path], "index": [index_lock], "full": [lock_path, index_lock]}.get(
        mode, [lock_path]
    )


@contextlib.contextmanager
def _locks_for_mode(mode: str, lock_path: Path):
    """Взять все lock'и режима (``full`` — оба); ``False``, если хоть один занят."""
    with contextlib.ExitStack() as stack:
        for path in lock_paths_for(mode, lock_path):
            if not stack.enter_context(_single_instance(path, mode)):
                yield False
                return
        yield True


def _run_step_once(
    name: str,
    thunk: Callable[[], int],
    logger: logging.Logger,
    *,
    final: bool = True,
) -> tuple[bool, str]:
    """Run one step attempt, isolating any failure. Returns (ok, captured text).

    The operation's stdout/stderr is captured (the CLI summaries are already
    anonymized — counts only), token-scrubbed (shared ``scrub_secrets``), logged,
    and returned so the caller can echo it for manual runs. A non-zero exit OR any
    raised exception (e.g. an uncaught network error when offline) marks the step
    failed but never aborts the run or propagates. A failure on a non-``final``
    attempt is logged as a WARNING (a retry follows), only the last attempt logs
    ERROR. (The logger's formatter also scrubs — defense-in-depth; the explicit
    scrub here keeps the returned/echoed-to-stdout text clean too.)
    """
    fail_log = logger.error if final else logger.warning
    fail_tag = "FAILED" if final else "failed (will retry)"
    buf = io.StringIO()
    t0 = time.monotonic()  # NIGHT-CHAIN-1: длительность попытки - в строку лога
    try:
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            code = thunk()
        captured = scrub_secrets(buf.getvalue().strip())
        took = f"{time.monotonic() - t0:.1f} с"
        if code == 0:
            logger.info("step %s: ok за %s\n%s", name, took, captured)
            return True, captured
        fail_log("step %s: %s (exit %s) за %s\n%s", name, fail_tag, code, took, captured)
        return False, captured
    except Exception as e:  # noqa: BLE001 — offline / unexpected; isolate, log, keep going
        captured = scrub_secrets(buf.getvalue().strip())
        msg = scrub_secrets(f"{type(e).__name__}: {e}")
        fail_log("step %s: %s (exception) %s [за %.1f с]\n%s", name, fail_tag, msg,
                 time.monotonic() - t0, captured)
        return False, f"{captured}\n[exception] {msg}".strip()


def _run_step(
    name: str, thunk: Callable[[], int], logger: logging.Logger
) -> tuple[bool, str]:
    """Run one step with in-run retries for steps listed in ``RETRY_ATTEMPTS``.

    Transient network hiccups (e.g. a Timetta ReadTimeout on ``refresh``) get
    ``RETRY_ATTEMPTS[name]`` attempts with exponential backoff (RETRY-1) instead
    of waiting for the next scheduled run. Non-listed steps run exactly once —
    unchanged behavior.
    """
    attempts = max(1, RETRY_ATTEMPTS.get(name, 1))
    for attempt in range(1, attempts + 1):
        final = attempt == attempts
        ok, captured = _run_step_once(name, thunk, logger, final=final)
        if ok or final:
            return ok, captured
        delay = RETRY_BACKOFF_S * (2 ** (attempt - 1))
        logger.warning(
            "step %s: attempt %d/%d failed — retrying in %.0fs",
            name, attempt, attempts, delay,
        )
        _sleep(delay)
    return ok, captured  # unreachable, keeps type-checkers happy


def _utc_iso(ts: float | None = None) -> str:
    return datetime.fromtimestamp(time.time() if ts is None else ts, UTC).strftime(
        "%Y-%m-%dT%H:%M:%SZ")


def _reindex_extra(started_ts: float) -> dict[str, str]:
    """Устройство и причина фолбэка ``reindex_inc`` из отчета ПРОГОНА (``index_report.json``).

    Берется только отчет, записанный после старта шага: прежний отчет не выдается за этот прогон
    (шаг мог мягко пропуститься под чужим локом). Нет отчета/сбой чтения - пусто."""
    try:
        from core.retrieval.index_report import read_report

        report = read_report() or {}
        at = datetime.fromisoformat(str(report.get("ts")))
    except Exception:  # noqa: BLE001 — наблюдение не роняет шаг
        return {}
    if at.timestamp() < started_ts - 1:
        return {}
    out = {"device": str(report.get("device") or "")}
    if report.get("device_fallback"):
        out["fallback"] = str(report["device_fallback"])[:200]
    return out


# Что шаг докладывает о себе в запись ``steps`` маяка (имя шага -> f(время старта шага)).
_STEP_EXTRA: dict[str, Callable[[float], dict[str, str]]] = {"reindex_inc": _reindex_extra}


def _record_step(
    beacon: ProgressBeacon, name: str, started_ts: float, ok: bool, logger: logging.Logger
) -> None:
    """NIGHT-CHAIN-1: итог шага -> ``steps`` маяка (``started/finished/elapsed_s/exit``)."""
    try:
        now = time.time()
        extra: dict[str, str] = {}
        enrich = _STEP_EXTRA.get(name)
        if enrich is not None:
            extra = enrich(started_ts)
        beacon.set_step(name, {
            "started": _utc_iso(started_ts), "finished": _utc_iso(now),
            "elapsed_s": round(now - started_ts, 1), "exit": 0 if ok else 1, **extra,
        })
    except Exception as exc:  # noqa: BLE001 — учет времени не роняет цепочку
        logger.debug("step %s: тайминг не записан (%s)", name, type(exc).__name__)


def _beacon_extra(mode: str, failed: list[str], steps: list[str] | None) -> dict[str, object]:
    """``extra`` маяка оркестратора; ``partial`` (``--steps``) - только когда он есть, прежняя форма
    ``{mode, failed}`` у полного прогона не меняется."""
    extra: dict[str, object] = {"mode": mode, "failed": len(failed)}
    if steps:
        extra["partial"] = True
    return extra


def run(
    mode: str,
    *,
    steps: list[str] | None = None,
    log_path: Path | None = None,
    lock_path: Path | None = None,
) -> int:
    """Run one orchestration mode. Never raises; returns 0 on success, 1 on any
    step failure, 2 on a usage/lock-contention condition that did no work.

    ``steps`` (RETIRE-WRITE-1 п.7) — подмножество шагов режима по именам, в порядке режима
    (точечное «обновить почту» с пульта вместо всего fast). Имя не из режима → 2 без работы,
    с перечнем допустимых. Лок — того же режима, что и у полного прогона."""
    log_path = log_path or sync_log_path()
    lock_path = lock_path or sync_lock_path()
    # CODE-5-1: unified logger to this run's log file + fresh corr-id per run
    # (self-contained: run() is also called directly from tests, not only via main).
    setup_logging(log_path=log_path)
    new_corr_id()
    logger = logging.getLogger("dt_sync")

    if mode not in MODES:
        logger.error("unknown mode %r (expected: %s)", mode, ", ".join(MODES))
        return 2

    plan = MODES[mode]
    # DEV-3-CORE: шаги выключенных коннекторов в плане нет - говорим об этом в лог, не молчим
    from core.surface import manifest as _surface

    skipped = [s for m in (("fast", "index") if mode == "full" else (mode,))
               for s in _surface.skipped_steps(m)]
    for step_name, keys in skipped:
        logger.info("шаг %s пропущен: коннектор %s выключен", step_name, ", ".join(keys))
    if steps:
        known = [name for name, _ in plan]
        unknown = [x for x in steps if x not in known]
        off = [x for x in unknown if x in {n for n, _ in skipped}]
        if off:
            print(f"dt-sync {mode}: шаги {', '.join(off)} пропущены - коннектор выключен "
                  "(DT_CONNECTORS)")
            return 2
        if unknown:
            logger.error("mode %s: unknown step(s) %s (expected: %s)", mode,
                         ", ".join(unknown), ", ".join(known))
            print(f"dt-sync {mode}: неизвестные шаги {', '.join(unknown)} — допустимо: "
                  f"{', '.join(known)}")
            return 2
        plan = [(name, thunk) for name, thunk in plan if name in set(steps)]

    with _locks_for_mode(mode, lock_path) as acquired:
        if not acquired:
            logger.info("mode %s: skipped — another dt-sync run holds the lock", mode)
            print(f"dt-sync {mode}: пропущено — уже выполняется другой прогон.")
            return 0

        # SYNC-OFFLINE-1: держим power-assertion на время тяжёлого прогона
        # (index/full), чтобы машина не уснула ПОСРЕДИ него. Отпускается по выходу
        # (в т.ч. на любом return/исключении ниже — CM finally). No-op для fast.
        with _power_assertion(mode):
            # CODE-7 fail-fast: критичные проблемы окружения — в лог СРАЗУ, а не при
            # первом сетевом вызове (иначе в ночном прогоне видна лишь глухая ошибка).
            try:
                from core.diagnostics import validate_environment

                for c in validate_environment():
                    logger.warning("окружение: %s — %s (%s)", c.name, c.detail, c.hint)
            except Exception:  # noqa: BLE001, S110 — диагностика не должна ронять синк
                pass

            selected = f" [{', '.join(n for n, _ in plan)}]" if steps else ""
            logger.info("=== dt-sync %s: start (%d steps)%s ===", mode, len(plan), selected)
            print(f"dt-sync {mode}: старт ({len(plan)} шагов){selected}")

            # ACT-1: маяк оркестратора — фаза = текущий шаг, current = шагов пройдено.
            # Заводится ТОЛЬКО под локом (второй прогон не затирает маяк первого);
            # вложенные операции ведут свои маяки (index/link/mail) сами.
            # п.4: fast и index идут параллельно — у каждого свой маяк, иначе они затирали бы
            # счётчики друг друга.
            beacon = ProgressBeacon(
                "dt-sync-index" if mode == "index" else "dt-sync", len(plan)
            )

            failed: list[str] = []
            for done_steps, (name, thunk) in enumerate(plan):
                beacon.update(done_steps, _beacon_extra(mode, failed, steps))
                beacon.phase(name)
                step_ts = time.time()
                beacon.set_step(name, {"started": _utc_iso(step_ts)})  # идет сейчас: exit нет
                ok, captured = _run_step(name, thunk, logger)
                _record_step(beacon, name, step_ts, ok, logger)
                status = "ok" if ok else "FAILED"
                print(f"  · {name}: {status}")
                if captured:
                    for line in captured.splitlines():
                        print(f"      {line}")
                if not ok:
                    failed.append(name)

            beacon.update(len(plan), _beacon_extra(mode, failed, steps))
            if failed:
                logger.warning(
                    "=== dt-sync %s: done WITH ERRORS (steps: %s) ===", mode, ", ".join(failed)
                )
                print(f"dt-sync {mode}: завершено С ОШИБКАМИ — {', '.join(failed)} (детали в логе)")
                beacon.done(f"{mode}: done with errors ({', '.join(failed)})")
                return 1

            logger.info("=== dt-sync %s: done ok ===", mode)
            print(f"dt-sync {mode}: завершено без ошибок")
            beacon.done(f"{mode}: done ok")
            return 0


def main(argv: list[str] | None = None) -> int:
    load_env()  # engine/.env → os.environ (tokens + DT_* knobs); never logged
    _rebuild_modes()  # PERSONAL-1: роль экземпляра известна только после слоев env (шаг bridge)

    parser = argparse.ArgumentParser(
        prog="dt-sync",
        description="Orchestrate the operational loop (fast / full) via the existing CLI ops.",
    )
    parser.add_argument(
        "mode",
        choices=sorted(MODES),
        help="fast: оборот входящих потоков без индекса (часто). "
        "index: линковка+индекс, signals→links→index (ночью/по кнопке). "
        "full: fast+index — полный проход (вручную).",
    )
    parser.add_argument(
        "--steps",
        help="только эти шаги режима, через запятую (например mail_ingest или "
        "refresh,reconcile); порядок — режима; неизвестное имя → код 2 без работы.",
    )
    args = parser.parse_args(argv)
    chosen = [x.strip() for x in (args.steps or "").split(",") if x.strip()]
    return run(args.mode, steps=chosen or None)


if __name__ == "__main__":
    raise SystemExit(main())
