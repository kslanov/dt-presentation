"""dt uninstall - снять установку (DEV-3-KIT): задания launchd, записи хостов, экземпляры.

Данные человека остаются: vault, ``.env``, модели, секреты, ``.derived``. ``--purge`` убирает
производные, секреты и модели (с подтверждением; ``--yes`` - без вопроса); vault не удаляется
никогда. ``--dry-run`` - только план. Claude Desktop запущен - запись снимается с ``--relaunch``.

Usage:
    uv run python cli/dt.py uninstall --dry-run
    uv run python cli/dt.py uninstall --relaunch
    uv run python cli/dt.py uninstall --purge          # спросит подтверждение
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dt_install import add_target_args


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt uninstall", description=__doc__.split("\n")[0])
    add_target_args(parser)
    parser.add_argument("--dry-run", action="store_true", help="показать план, ничего не менять")
    parser.add_argument("--purge", action="store_true",
                        help="удалить еще .derived, секреты и модели (vault - никогда)")
    parser.add_argument("--yes", action="store_true", help="подтверждение --purge без вопроса")
    parser.add_argument("--relaunch", action="store_true",
                        help="Claude Desktop запущен: выйти, снять запись, запустить снова")
    args = parser.parse_args(argv)

    from core.install.context import InstallContext
    from core.install.uninstall import uninstall

    ctx = InstallContext.build(
        engine_dir=Path(args.engine_dir) if args.engine_dir else None,
        root=Path(args.root) if args.root else None,
        home=Path(args.home) if args.home else None,
        env_path=Path(args.env_file) if args.env_file else None,
        vault=Path(args.vault) if args.vault else None,
        yes=args.yes, dry_run=args.dry_run, relaunch=args.relaunch)
    return uninstall(ctx, purge=args.purge)


if __name__ == "__main__":
    raise SystemExit(main())
