"""dt vault - каркас vault из шаблона (PERSONAL-1 п.2): ``init --kind work|personal``.

``init`` создаёт папки и стартовые файлы пресета (:mod:`core.vault_template`); существующее не
трогает, повтор ничего не меняет. Для ``personal`` копирует профиль владельца и канон ИИ-маркеров
из рабочего vault (``--work-vault``, по умолчанию ``DT_VAULT_PATH`` процесса).

Usage:
    uv run python cli/dt.py vault init --kind personal \\
        --vault ~/Claude/Projects/"Digital twin"/vault-personal
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env


def main(argv: list[str] | None = None) -> int:
    load_env()
    parser = argparse.ArgumentParser(prog="dt vault", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    init = sub.add_parser("init", help="создать каркас vault")
    init.add_argument("--kind", choices=("work", "personal"), default="personal")
    init.add_argument("--vault", required=True)
    init.add_argument("--work-vault", default=None)
    args = parser.parse_args(argv)

    from core.config import default_vault_path
    from core.vault_template import build_vault

    source = Path(args.work_vault).expanduser() if args.work_vault else default_vault_path()
    target = Path(args.vault).expanduser()
    if target.resolve() == default_vault_path().resolve() and args.kind == "personal":
        print("отказ: личный каркас в рабочем vault не создаем", file=sys.stderr)
        return 2
    created = build_vault(target, args.kind, work_vault=source)
    print(f"{target}: создано {len(created)}" + ("" if created else " (каркас уже на месте)"))
    for rel in created:
        print(f"  {rel}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
