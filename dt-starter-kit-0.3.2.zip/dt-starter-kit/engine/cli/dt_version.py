"""dt version - версия движка и версии схем (DEV-3-CORE п.4, принцип 17).

Печатает версию релиза (``pyproject.toml``), ``git describe`` и версии схем из существующих
реестров:
``dt.db`` (миграции), факты, задания, чанкер и метка индекса (какой моделью/чанкером построен).
Только чтение: ни индекса, ни сети, ни записи.

Usage:
    uv run python cli/dt.py version [--json]
"""

from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env


def main(argv: list[str] | None = None) -> int:
    load_env()
    parser = argparse.ArgumentParser(prog="dt version", description=__doc__.split("\n")[0])
    parser.add_argument("--json", action="store_true", help="машиночитаемо")
    args = parser.parse_args(argv)

    from core.version import version_info

    info = version_info()
    if args.json:
        print(json.dumps(info, ensure_ascii=False, indent=2))
        return 0
    sch = info["schemas"]
    idx = sch["index"]
    print(f"Digital Twin engine {info['version']}")
    print(f"git: {info['git'] or 'нет (не репозиторий или нет git)'}")
    print("схемы:")
    print(f"  dt.db:   v{sch['dt.db']}")
    print(f"  facts:   v{sch['facts']}")
    print(f"  jobs:    v{sch['jobs']}")
    print(f"  chunker: {sch['chunker']}")
    print(f"  индекс:  модель {idx['embed_model'] or 'нет метки'}; "
          f"чанкер {idx['chunker'] or 'нет метки'}"
          + ("" if not idx["chunker"] or idx["chunker"] == sch["chunker"]
             else "  (отличается от кода: нужен rechunk)"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
