"""dt web-token — токены веб-пульта: ротация и показ ссылок (WEBPULT-ACCESS-1 п.5).

``rotate read|rw`` выпускает новый токен в ``.secrets/web_token`` | ``web_token_rw`` (0600): старый
токен, cookie и закладка перестают работать СРАЗУ (сервер перечитывает токены на каждый запрос,
рестарт сервиса не нужен). Токен из env/.env (``DT_WEB_TOKEN``/``DT_WEB_TOKEN_RW``) файлом не
перекрыть - ротация откажет с пояснением. ``show read|rw`` печатает ссылку с токеном (локально, в
терминале): rw - с пометкой «cookie на 7 дней»; ссылки с токенами в ответы MCP-инструментов не
попадают (они уходят в контекст чата хоста).

Usage:
    uv run python cli/dt.py web-token rotate rw
    uv run python cli/dt.py web-token show read
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.web_tokens import RW_COOKIE_DAYS, WebTokens, rotate


def _env_with_dotenv() -> dict[str, str]:
    """Окружение + ``engine/.env`` (сервер грузит его при старте: токен мог быть задан там)."""
    from dotenv import dotenv_values

    from core.config import engine_env_path

    merged = {k: v for k, v in dotenv_values(engine_env_path()).items() if v is not None}
    merged.update(os.environ)
    return merged


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="dt web-token", description=__doc__.split("\n")[0])
    sub = parser.add_subparsers(dest="cmd", required=True)
    for name in ("rotate", "show"):
        p = sub.add_parser(name)
        p.add_argument("which", nargs="?", choices=("read", "rw"), default="rw")
    parser.add_argument("--port", type=int, default=int(os.environ.get("DT_WEB_PORT") or 8787))
    parser.add_argument("--dir", type=Path, default=None,
                        help="каталог секретов (по умолчанию <workspace>/.secrets)")
    args = parser.parse_args(argv)
    # --dir (песочница каталога секретов) - значит, .env боевого движка не читаем
    env = dict(os.environ) if args.dir is not None else _env_with_dotenv()

    if args.cmd == "rotate":
        try:
            token = rotate(args.which, args.dir, env=env)
        except ValueError as exc:
            print(f"отказ: {exc}", file=sys.stderr)
            return 2
        print(f"новый {args.which}-токен выпущен (.secrets/, 0600); старые токен, cookie и ссылки "
              "перестали работать сразу, рестарт сервиса не нужен.")
        print(f"ссылка: http://localhost:{args.port}/?t={token}")
        if args.which == "rw":
            print(f"(запись: cookie на {RW_COOKIE_DAYS} дней; обнови закладку rw на ноуте)")
        else:
            print("(обнови закладку на телефоне)")
        return 0

    tokens = WebTokens(args.dir, env=env)
    token = tokens.read() if args.which == "read" else tokens.rw()
    if not token:
        print(f"{args.which}-токена нет: он создастся при старте веб-сервиса "
              f"или `dt web-token rotate {args.which}`", file=sys.stderr)
        return 1
    note = f"  # запись, cookie на {RW_COOKIE_DAYS} дней" if args.which == "rw" else "  # чтение"
    print(f"http://localhost:{args.port}/?t={token}{note}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
