"""Digital-twin engine — core library.

Pure business logic. By architectural invariant (docs/02-architecture.md §8),
`core` must not import from the interface layers (`mcp-server/`, `cli/`) nor from
external services. It is a standalone library so new interfaces can be added
without rewriting logic.
"""

from core.chunking import Chunk, chunk_note
from core.vault import Note, iter_vault, read_note, write_note

__all__ = [
    "Note",
    "read_note",
    "iter_vault",
    "write_note",
    "Chunk",
    "chunk_note",
]
