"""ADAPTER-HONEST-1 — единый мини-контракт отказа внутренних адаптеров.

Канон §9 п.22 («деградация всегда с сигналом») писался про границу MCP. Фейлкейс 01.10
показал, что он обязан действовать и на **внутренние** границы с внешним миром — мосты
Outlook/календаря, HTTP-клиенты TickTick/Timetta, парсеры, манифесты: ``_meta_page``
молча подставлял пустое вместо сбойного свойства и 200 писем легли в чужие треды.

Решение одно на все адаптеры — **исключения семейства** :class:`AdapterError`
(не россыпь результатов с ``error``-полями): сбой адаптера нельзя перепутать с
«пустым результатом», его нельзя «не заметить» возвратом ``[]``. Вызывающий слой
(инжест, work, пульт, MCP-обёртка) переводит исключение в конверт п.22
(:meth:`AdapterError.envelope` / :meth:`AdapterError.add_to`) с кодом из
:mod:`core.contract`; конверты на границе MCP считает телеметрия отказов
(FAIL-TELEMETRY-1, ``degradation_codes``) — новых точек учёта не заводим.

Коды (машинная причина):

* ``unavailable`` — внешняя зависимость недоступна (Outlook не запущен, HTTP-сбой);
* ``store_unavailable`` — локальное хранилище (манифест, кэш) нечитаемо: НЕ «пусто»;
* ``bridge_misaligned`` — массивы моста разошлись, зипать нельзя;
* ``adapter_interrupted`` — вызов прерван: таймаут уровня вызова или сон машины.

«Честное пусто» — тоже решение: файла/ответа нет **легитимно** (первый запуск, окно без
событий) — это не ошибка, а обычный результат; отказом считается только то, что есть,
но не прочиталось/не разобралось.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from core.contract import (
    CODE_ADAPTER_INTERRUPTED,
    CODE_BRIDGE_MISALIGNED,
    CODE_STORE_UNAVAILABLE,
    CODE_UNAVAILABLE,
    add_warning,
)

__all__ = [
    "AdapterError",
    "AdapterUnavailable",
    "AdapterInterrupted",
    "AdapterMisaligned",
    "StoreUnavailableError",
    "load_json_store",
    "expect_shape",
]


class AdapterError(RuntimeError):
    """Сбой внутреннего адаптера. Никогда не маскируется пустым результатом.

    ``reason`` — человеку, по существу; ``adapter`` — какой адаптер (``outlook``,
    ``ticktick``, ``timetta``, ``manifest``, …); ``context`` — то, чем продолжают
    работу (номер страницы, путь, длины массивов); пустые значения отбрасываются.
    ``str(exc)`` — ``reason``: существующие обработчики, печатающие исключение, не
    меняются.
    """

    code: str = CODE_UNAVAILABLE
    default_adapter: str = ""

    def __init__(self, reason: str = "", *, adapter: str | None = None, **context: Any) -> None:
        super().__init__(reason)
        self.reason = str(reason)
        self.adapter = adapter if adapter is not None else self.default_adapter
        self.context = {
            k: v for k, v in context.items() if v is not None and v != "" and v != []
        }

    def envelope(self) -> dict[str, Any]:
        """Машиночитаемый отказ: ``{ok:false, code, adapter, reason, …контекст}``."""
        env: dict[str, Any] = {"ok": False, "code": self.code, "reason": self.reason}
        if self.adapter:
            env["adapter"] = self.adapter
        env.update(self.context)
        return env

    def add_to(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Положить отказ в ответ как конверт ``warning`` (тот же, что у остальных
        деградаций; его считает телеметрия на границе MCP)."""
        ctx = dict(self.context)
        if self.adapter:
            ctx["adapter"] = self.adapter
        return add_warning(payload, self.code, self.reason, **ctx)


class AdapterUnavailable(AdapterError):
    """Внешняя зависимость недоступна (Outlook не запущен, сеть, HTTP-ошибка)."""

    code = CODE_UNAVAILABLE


class AdapterInterrupted(AdapterError):
    """Вызов адаптера прерван: таймаут на уровне вызова либо сон машины посреди него.

    Незавершённый после пробуждения вызов — ОТКАЗ, а не «подождём ещё»: ожидание ответа,
    который уже не придёт, держало ночной прогон 10 часов (инцидент 2026-10-13).
    """

    code = CODE_ADAPTER_INTERRUPTED


class AdapterMisaligned(AdapterError):
    """Параллельные структуры разошлись по длине — зипать/индексировать нельзя."""

    code = CODE_BRIDGE_MISALIGNED


class StoreUnavailableError(AdapterError, ValueError):
    """Локальное хранилище (манифест/кэш/зеркало) существует, но не прочиталось.

    Подкласс ``ValueError`` намеренно: прежний код, ловивший ``ValueError``/``JSONDecodeError``
    от чтения хранилищ, продолжает его ловить.

    Отличие от «нет файла» принципиально: пустой манифест — «первый запуск», битый
    манифест — «не знаю, что там было»; подставить пустое значит переимпортировать
    всё или затереть накопленное.
    """

    code = CODE_STORE_UNAVAILABLE
    default_adapter = "store"


def load_json_store(
    path: Path,
    *,
    adapter: str = "store",
    expect: type | tuple[type, ...] = dict,
) -> Any | None:
    """Прочитать JSON-хранилище: ``None`` — файла НЕТ (легитимно пусто);
    битый/нечитаемый/не того типа → :class:`StoreUnavailableError` (с путём и причиной).
    """
    p = Path(path)
    if not p.is_file():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:  # JSON/Unicode-ошибки — подклассы ValueError
        raise StoreUnavailableError(
            f"{p.name} не прочитался ({type(exc).__name__}: {str(exc)[:160]}) — "
            "это НЕ «данных нет»; проверь/восстанови файл (рядом может лежать .bak)",
            adapter=adapter, path=str(p),
        ) from exc
    if not isinstance(data, expect):
        want = expect.__name__ if isinstance(expect, type) else "/".join(t.__name__ for t in expect)
        raise StoreUnavailableError(
            f"{p.name}: ожидался {want}, а лежит {type(data).__name__}",
            adapter=adapter, path=str(p),
        )
    return data


def expect_shape(
    data: Any,
    kind: type | tuple[type, ...],
    *,
    adapter: str,
    op: str,
    exc: type[AdapterError] | None = None,
) -> Any:
    """Ответ внешней системы обязан иметь форму ``kind`` — иначе отказ, не ``[]``.

    Замена идиомы ``data if isinstance(data, list) else []``: неожиданная форма ответа
    (``{}``, строка, ``null`` вместо списка) — это сбой адаптера, а не «0 элементов».
    """
    if isinstance(data, kind):
        return data
    want = kind.__name__ if isinstance(kind, type) else "/".join(t.__name__ for t in kind)
    raise (exc or AdapterUnavailable)(
        f"{adapter}/{op}: ответ неожиданной формы ({type(data).__name__}, ожидался {want}) — "
        "это отказ адаптера, не пустой результат",
        adapter=adapter, op=op,
    )
