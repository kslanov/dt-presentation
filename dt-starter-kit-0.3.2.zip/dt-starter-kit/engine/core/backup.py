"""WAVE0-HYGIENE п.6 — еженедельный бэкап невосстановимого ``.derived`` (аудит B9).

Бэкапы были ручными (``make backup-derived``, последний 16.08) и неполными: без ``dt.db``
(факты/реестр подъёмов/джобы), манифеста почты, сайдкаров тредов (тела писем, которых уже
может не быть в Outlook), леджеров ссылок и событий. Здесь — состав из аудита §4 «не
пересобирается»; LanceDB и ``index_manifest`` в бэкап НЕ входят (восстановимы пересборкой).

* ``dt.db`` копируется через SQLite ``.backup`` API (согласованный снимок при живом WAL),
  не ``cp``;
* архив ``derived-weekly-<ts>.tar.gz`` + рядом ``…json`` (состав/размеры — doctor читает
  его, не вскрывая гигабайты); запись атомарна (tmp → rename), ротация — только после
  успешной записи нового (4 последних);
* restore = ``tar xzf … -C <derived>`` (раскладка внутри архива относительна ``.derived``).

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import sqlite3
import tarfile
import tempfile
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "ARCHIVE_PREFIX",
    "KEEP_DEFAULT",
    "BackupResult",
    "backups_dir",
    "collect_members",
    "last_backup",
    "run_backup",
    "stale_after_days",
]

ARCHIVE_PREFIX = "derived-weekly-"
KEEP_DEFAULT = 4
STALE_DAYS_DEFAULT = 8.0


def backups_dir() -> Path:
    """Куда складывать архивы: ``DT_BACKUPS_PATH`` либо ``<workspace>/.backups`` (вне git).

    Единое место — :func:`core.config.backups_path` (TEST-SANDBOX-1: ручка живёт в config)."""
    from core.config import backups_path

    return backups_path()


def stale_after_days() -> float:
    """Порог doctor «последний бэкап старше N дней» (``DT_BACKUP_WARN_DAYS``, дефолт 8)."""
    try:
        value = float((os.environ.get("DT_BACKUP_WARN_DAYS") or "").strip())
    except ValueError:
        return STALE_DAYS_DEFAULT
    return value if value > 0 else STALE_DAYS_DEFAULT


def keep_count() -> int:
    """Сколько недельных архивов хранить (``DT_BACKUP_KEEP``, дефолт 4)."""
    raw = (os.environ.get("DT_BACKUP_KEEP") or "").strip()
    return int(raw) if raw.isdigit() and int(raw) > 0 else KEEP_DEFAULT


@dataclass
class Member:
    """Один элемент состава: ``source`` на диске → ``arcname`` внутри архива."""

    source: Path
    arcname: str
    kind: str  # file | dir | sqlite
    group: str


@dataclass
class BackupResult:
    ok: bool = False
    dry_run: bool = False
    archive: str = ""
    members: list[dict[str, Any]] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    size_bytes: int = 0
    rotated: list[str] = field(default_factory=list)
    elapsed_s: float = 0.0
    error: str = ""


def _derived_root() -> Path:
    from core.config import outlook_ingest_manifest_path

    return outlook_ingest_manifest_path().parent


def _arcname(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return f"external/{path.name}"


def collect_members() -> tuple[list[Member], list[str]]:
    """Состав бэкапа (аудит B §4 «не пересобирается») и список отсутствующих источников.

    Отсутствие источника — не ошибка (свежая машина): оно попадает в ``missing`` и в отчёт.
    """
    from core.config import (
        current_ingest_manifest_path,
        dt_db_path,
        events_path,
        file_ingest_manifest_path,
        hub_alias_candidates_path,
        hub_candidates_path,
        legacy_ingest_manifest_path,
        link_applied_path,
        link_proposals_path,
        link_scan_manifest_path,
        operational_derived_path,
        outlook_ingest_manifest_path,
        reattr_proposals_path,
        ticktick_state_path,
    )

    root = _derived_root()
    wanted: list[tuple[str, Path, str]] = [
        ("db", dt_db_path(), "sqlite"),
        ("mail", outlook_ingest_manifest_path(), "file"),
        ("mail", outlook_ingest_manifest_path().parent / "mail_threads", "dir"),
        ("ingest", legacy_ingest_manifest_path(), "file"),
        ("ingest", current_ingest_manifest_path(), "file"),
        ("ingest", file_ingest_manifest_path(), "file"),
        ("ledgers", link_proposals_path(), "file"),
        ("ledgers", link_applied_path(), "file"),
        ("ledgers", link_applied_path().parent / "link_revoked.jsonl", "file"),
        ("ledgers", reattr_proposals_path(), "file"),
        ("ledgers", hub_candidates_path(), "file"),
        ("ledgers", hub_alias_candidates_path(), "file"),
        ("ledgers", link_scan_manifest_path(), "file"),
        ("events", events_path(), "file"),
        ("ticktick", ticktick_state_path(), "file"),
    ]
    members: list[Member] = []
    missing: list[str] = []
    for group, path, kind in wanted:
        if path.exists():
            members.append(Member(path, _arcname(path, root), kind, group))
        else:
            missing.append(_arcname(path, root))
    # operational/*.json — очередь подтверждений, crosswalk, снузы, дедупы, вотчлист
    op_dir = operational_derived_path()
    if op_dir.is_dir():
        for path in sorted(op_dir.glob("*.json")):
            members.append(Member(path, _arcname(path, root), "file", "operational"))
    else:
        missing.append(_arcname(op_dir, root) + "/*.json")
    # дубль путей (разные конфиги → один файл) не кладём дважды
    seen: set[str] = set()
    unique = []
    for member in members:
        if member.arcname not in seen:
            seen.add(member.arcname)
            unique.append(member)
    return unique, missing


def _sqlite_snapshot(source: Path, dest: Path) -> None:
    """Согласованный снимок БД через ``.backup`` API (живой WAL не ломает копию)."""
    src = sqlite3.connect(f"file:{source}?mode=ro", uri=True, timeout=30)
    try:
        dst = sqlite3.connect(str(dest))
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()


def _dir_size(path: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            with contextlib.suppress(OSError):
                total += os.stat(os.path.join(root, name)).st_size
    return total


def run_backup(*, dry_run: bool = False, out_dir: Path | None = None) -> BackupResult:
    """Собрать архив, записать атомарно, провести ротацию. Не бросает: итог в результате."""
    start = time.perf_counter()
    result = BackupResult(dry_run=dry_run)
    members, missing = collect_members()
    result.missing = missing
    out = Path(out_dir) if out_dir is not None else backups_dir()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    final = out / f"{ARCHIVE_PREFIX}{stamp}.tar.gz"
    for m in members:
        size = _dir_size(m.source) if m.kind == "dir" else m.source.stat().st_size
        result.members.append({"name": m.arcname, "group": m.group, "kind": m.kind,
                               "size": size})
    result.archive = str(final)
    if dry_run:
        result.ok = True
        result.elapsed_s = round(time.perf_counter() - start, 2)
        return result

    out.mkdir(parents=True, exist_ok=True)
    tmp = out / f".{final.name}.tmp"
    try:
        with tempfile.TemporaryDirectory(prefix="dt-backup-") as scratch:
            with tarfile.open(tmp, "w:gz") as tar:
                for m in members:
                    source = m.source
                    if m.kind == "sqlite":
                        snap = Path(scratch) / "dt.db"
                        _sqlite_snapshot(m.source, snap)
                        source = snap
                    tar.add(source, arcname=m.arcname)
                manifest = {
                    "created": datetime.now().isoformat(timespec="seconds"),
                    "members": result.members,
                    "missing": missing,
                    "note": "LanceDB и index_manifest не входят (восстановимы пересборкой)",
                }
                data = json.dumps(manifest, ensure_ascii=False, indent=1).encode("utf-8")
                info = tarfile.TarInfo("BACKUP-MANIFEST.json")
                info.size = len(data)
                info.mtime = int(time.time())
                import io

                tar.addfile(info, io.BytesIO(data))
        os.replace(tmp, final)
        sidecar = final.with_suffix("").with_suffix(".json")  # derived-weekly-<ts>.json
        sidecar.write_text(json.dumps(
            {"created": datetime.now().isoformat(timespec="seconds"),
             "archive": final.name, "size_bytes": final.stat().st_size,
             "members": result.members, "missing": missing},
            ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception as exc:  # noqa: BLE001 — бэкап не бросает: ошибка в отчёте, старые целы
        with contextlib.suppress(OSError):
            tmp.unlink()
        result.error = f"{type(exc).__name__}: {exc}"[:300]
        result.elapsed_s = round(time.perf_counter() - start, 2)
        logger.error("[backup] не удался: %s", result.error)
        return result

    result.size_bytes = final.stat().st_size
    result.rotated = _rotate(out, keep_count())
    result.ok = True
    result.elapsed_s = round(time.perf_counter() - start, 2)
    logger.info("[backup] %s: %d элементов, %.1f МБ, ротация -%d",
                final.name, len(members), result.size_bytes / 1e6, len(result.rotated))
    return result


def _archives(out: Path) -> list[Path]:
    """Недельные архивы по возрастанию имени (имя = метка времени)."""
    return sorted(out.glob(f"{ARCHIVE_PREFIX}*.tar.gz"))


def _rotate(out: Path, keep: int) -> list[str]:
    """Оставить ``keep`` новейших недельных архивов (+ их json); ручные ``derived-*`` не трогаем."""
    old = _archives(out)[:-keep] if keep > 0 else []
    removed: list[str] = []
    for archive in old:
        with contextlib.suppress(OSError):
            archive.unlink()
            removed.append(archive.name)
        sidecar = archive.with_suffix("").with_suffix(".json")
        with contextlib.suppress(OSError):
            sidecar.unlink()
    return removed


def last_backup(out_dir: Path | None = None) -> dict[str, Any] | None:
    """Новейший недельный архив: ``{name, age_days, size_bytes, members, missing}`` | ``None``."""
    out = Path(out_dir) if out_dir is not None else backups_dir()
    archives = _archives(out) if out.is_dir() else []
    if not archives:
        return None
    newest = archives[-1]
    try:
        st = newest.stat()
    except OSError:
        return None
    info: dict[str, Any] = {
        "name": newest.name,
        "age_days": max(0.0, (time.time() - st.st_mtime) / 86400.0),
        "size_bytes": st.st_size,
        "count": len(archives),
        "members": None,
        "missing": [],
    }
    sidecar = newest.with_suffix("").with_suffix(".json")
    with contextlib.suppress(OSError, ValueError):
        meta = json.loads(sidecar.read_text(encoding="utf-8"))
        info["members"] = len(meta.get("members") or [])
        info["missing"] = list(meta.get("missing") or [])
    return info
