"""Ротация ``*.bak-*`` (SURFACE-HYGIENE-1 п.7): ``dt backup prune-bak [--keep N] [--dry-run]``.

Правки ``.env``, копии артефакта пульта и производных файлов оставляют рядом ``<имя>.bak-<метка>``;
за месяцы их копилось десятками (``engine/.env.bak-*`` 5, у копии артефакта 20). Здесь - ТОЛЬКО эти
файлы и только в перечисленных корнях:

* корни - из конфига (:func:`bak_roots`): каталог ``engine/`` (там ``.env``), корень ``.derived`` и
  ``DT_BAK_ROOTS`` (список каталогов; дефолт реестра - каталог копии артефакта пульта);
* шаблон строгий: имя ``<база>.bak-<метка>`` (``.bak-`` в середине), без захода в подкаталоги, без
  симлинков; файлы ``*.bak`` без метки (``current_ingest_manifest.json.bak``) НЕ трогаются;
* на каждую ``<базу>`` остаются ``keep`` самых свежих (по mtime, при равенстве - по имени);
* ``dry_run`` ничего не удаляет и возвращает тот же отчет «удалено/оставлено».

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "BAK_RE",
    "KEEP_DEFAULT",
    "PruneReport",
    "bak_roots",
    "bak_warn_count",
    "count_bak",
    "prune_bak",
]

KEEP_DEFAULT = 5
WARN_DEFAULT = 10
BAK_RE = re.compile(r"^(?P<base>.+)\.bak-(?P<tag>.+)$")


# Корень ``engine/`` для ротации; ``None`` - боевой ``core.config.ENGINE_ROOT``. Тесты (conftest
# ``_bak_roots_isolated``) подменяют на tmp: sandbox-гард защищает только ``.derived``, а
# ``ENGINE_ROOT`` под pytest - живой ``engine/`` (31.10 тест без корней снес все ``.env.bak-*``).
ENGINE_BAK_ROOT: Path | None = None


def bak_roots() -> list[Path]:
    """Корни ротации: ``engine/`` (``.env``), корень ``.derived``, ``DT_BAK_ROOTS`` (через запятую).

    Несуществующий каталог в списке пропускается (на другой машине копии артефакта нет)."""
    from core.config import ENGINE_ROOT, derived_root

    engine = ENGINE_BAK_ROOT if ENGINE_BAK_ROOT is not None else Path(ENGINE_ROOT)
    roots: list[Path] = [Path(engine), Path(derived_root())]
    raw = os.environ.get("DT_BAK_ROOTS")
    if raw is None:
        from core.config.knobs import KNOBS

        raw = next((k.default for k in KNOBS if k.name == "DT_BAK_ROOTS"), "") or ""
    for part in str(raw).split(","):
        part = part.strip()
        if part:
            roots.append(Path(part).expanduser())
    seen: set[Path] = set()
    out: list[Path] = []
    for root in roots:
        key = root.resolve() if root.exists() else root
        if root.is_dir() and key not in seen:
            seen.add(key)
            out.append(root)
    return out


def bak_warn_count() -> int:
    """Порог доктора «Бэкапы .bak»: больше файлов на корень - warn (``DT_BAK_WARN_COUNT``, 10)."""
    raw = (os.environ.get("DT_BAK_WARN_COUNT") or "").strip()
    return int(raw) if raw.isdigit() and int(raw) > 0 else WARN_DEFAULT


def _baks(root: Path) -> dict[str, list[Path]]:
    """``{база: [файлы .bak-*]}`` верхнего уровня корня (свежие первыми); симлинки/каталоги мимо."""
    groups: dict[str, list[Path]] = {}
    try:
        entries = list(root.iterdir())
    except OSError:
        return {}
    for path in entries:
        m = BAK_RE.match(path.name)
        if not m or path.is_symlink() or not path.is_file():
            continue
        groups.setdefault(m.group("base"), []).append(path)

    def newest_first(p: Path) -> tuple[float, str]:
        try:
            return (-p.stat().st_mtime, p.name)
        except OSError:
            return (0.0, p.name)

    for files in groups.values():
        files.sort(key=newest_first)
    return groups


def count_bak(root: Path) -> int:
    """Сколько ``*.bak-*`` лежит в корне (для доктора)."""
    return sum(len(v) for v in _baks(root).values())


@dataclass
class PruneReport:
    keep: int
    dry_run: bool
    roots: list[dict[str, Any]] = field(default_factory=list)  # {root, kept[], removed[], failed[]}

    @property
    def removed(self) -> list[str]:
        return [name for r in self.roots for name in r["removed"]]

    @property
    def kept(self) -> list[str]:
        return [name for r in self.roots for name in r["kept"]]


def prune_bak(
    roots: list[Path] | None = None, *, keep: int = KEEP_DEFAULT, dry_run: bool = False
) -> PruneReport:
    """Оставить ``keep`` свежих ``.bak-*`` на базу в каждом корне, остальные удалить.

    ``dry_run`` - только отчет. Удаление одного файла, не удавшееся (занят/права), попадает в
    ``failed`` корня и не останавливает остальные. ``keep < 1`` приводится к 1: ротация никогда не
    снимает ПОСЛЕДНЮЮ копию (инцидент приемки 31.10: тест звал ``prune_bak(keep=0)`` с корнями по
    умолчанию, а ``ENGINE_ROOT`` в тестах - боевой ``engine/`` → все ``.env.bak-*`` удалены)."""
    keep = max(1, int(keep))
    report = PruneReport(keep=keep, dry_run=dry_run)
    for root in roots if roots is not None else bak_roots():
        kept: list[str] = []
        removed: list[str] = []
        failed: list[str] = []
        for _base, files in sorted(_baks(root).items()):
            kept += [p.name for p in files[:keep]]
            for victim in files[keep:]:
                if not dry_run:
                    try:
                        victim.unlink()
                    except OSError:
                        failed.append(victim.name)
                        continue
                removed.append(victim.name)
        report.roots.append({"root": str(root), "kept": kept, "removed": removed, "failed": failed})
    return report
