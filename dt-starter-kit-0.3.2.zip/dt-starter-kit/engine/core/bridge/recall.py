"""PERSONAL-1 п.6 - ``personal_recall``: «что я читал/думал по теме X» с оверлеем рабочего
контекста.

Инструмент ТОЛЬКО личного экземпляра (регистрируется при ``DT_INSTANCE_ROLE=personal``; в реестре
профилей рабочего его нет). Ответ собирается из трех частей, НИЧЕГО не пишет и в рабочий vault не
ходит иначе, чем читающим вызовом:

* ``personal`` - попадания ``find_notes`` по ЛИЧНОМУ индексу; к каждому приложены его ``work_refs``
  (связи с рабочим знанием, принятые карточками ``bridge``);
* ``work`` - живой оверлей: ``WorkClient.find_notes(query)`` к рабочему демону по токену чтения,
  каждая запись помечена ``source: "work"``; рабочий демон недоступен - ``available: false`` и
  конверт ``work_unavailable``, личная часть отдается как есть;
* ``linked_work`` - рабочие заметки, на которые личные хиты ссылаются через ``work_refs`` (без
  повторного похода в сеть).
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

from core.bridge.refs import read_work_refs
from core.bridge.work_client import WorkClient

__all__ = ["recall"]

MAX_K = 20


def _ref_view(item: Any) -> dict[str, Any]:
    if isinstance(item, dict):
        return {k: item.get(k) for k in ("id", "title", "path", "at") if item.get(k) is not None}
    return {"id": str(item)}


def recall(
    query: str,
    k: int,
    *,
    personal_search: Callable[[str, int], dict[str, Any]],
    vault: Path,
    client: WorkClient | None = None,
) -> dict[str, Any]:
    """Сводка по теме: личные хиты + их ``work_refs`` + оверлей рабочего контекста.

    ``personal_search(query, limit)`` - поиск по личному индексу (``find_notes`` сервера);
    ``client`` - клиент рабочего демона (``None`` - моста нет: оверлей пуст с причиной)."""
    text = " ".join(str(query or "").split())
    limit = max(1, min(int(k), MAX_K))
    out: dict[str, Any] = {"query": text, "k": limit, "personal": [], "linked_work": [],
                           "work": {"source": "work", "available": False, "notes": []}}
    if not text:
        return out
    found = personal_search(text, limit)
    if isinstance(found.get("warning"), list) and found["warning"]:
        out["warning"] = found["warning"]
    linked: dict[str, dict[str, Any]] = {}
    for hit in (found.get("notes") or [])[:limit]:
        path = str(hit.get("path") or "")
        refs = [_ref_view(r) for r in read_work_refs(Path(vault) / path, Path(vault))] if path \
            else []
        out["personal"].append({
            "note_id": hit.get("note_id"), "title": hit.get("title"), "path": path,
            "score": hit.get("score"), "matched_by": hit.get("matched_by"),
            "date": hit.get("date"), "work_refs": refs})
        for ref in refs:
            linked.setdefault(str(ref.get("id")), {**ref, "source": "work_ref"})
    out["linked_work"] = list(linked.values())
    work = out["work"]
    if client is None:
        work["reason"] = "not_configured"
        work["error"] = "мост к рабочему демону не настроен (DT_WORK_URL / токен чтения)"
        return out
    got = client.find_notes(text, limit=limit)
    if not got.get("ok"):
        work.update(code=got.get("code"), reason=got.get("reason"), error=got.get("error"))
        return out
    work["available"] = True
    work["notes"] = [
        {"note_id": n.get("note_id"), "title": n.get("title"), "path": n.get("path"),
         "score": n.get("score"), "matched_by": n.get("matched_by"), "corpus": n.get("corpus"),
         "date": n.get("date"), "source": "work"}
        for n in (got["result"].get("notes") or [])[:limit] if isinstance(n, dict)]
    return out
