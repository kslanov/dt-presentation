"""PERSONAL-1 п.5 - ``work_refs`` в frontmatter ЛИЧНОЙ заметки (принятая связь с рабочим знанием).

Формат поля: ``work_refs: [{id, title, path, at}, …]`` - одна строка flow-YAML (валидный JSON): так
хирургический писатель :func:`core.vault.set_frontmatter_fields` меняет ровно строку поля, остальной
frontmatter и тело остаются байт в байт. Есть запись с тем же ``id`` - обновляется, а не
дублируется;
чужие (написанные руками) записи сохраняются как есть. Заметка без frontmatter получает блок с одним
полем ``work_refs`` в начале файла (тело не меняется).

Пишется ТОЛЬКО личная заметка. Рабочий vault и его индекс эта функция не знает и не трогает.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from core.vault import RawYaml, read_note, set_frontmatter_fields

__all__ = ["add_work_ref", "read_work_refs"]

FIELD = "work_refs"


def read_work_refs(path: Path, vault_root: Path | None = None) -> list[Any]:
    """Текущие ``work_refs`` заметки (пусто - нет поля или заметка не читается)."""
    try:
        raw = read_note(Path(path), vault_root).frontmatter.get(FIELD)
    except Exception:  # noqa: BLE001 - нечитаемая заметка = нет связей
        return []
    if raw is None:
        return []
    return list(raw) if isinstance(raw, list) else [raw]


def _ref_id(item: Any) -> str:
    return str(item.get("id") if isinstance(item, dict) else item or "")


def add_work_ref(
    path: Path, ref: dict[str, str], vault_root: Path | None = None
) -> tuple[bool, list[Any]]:
    """Дописать/обновить ``ref`` (``{id, title, path, at}``) в ``work_refs`` заметки ``path``.

    Возвращает ``(изменился ли файл, итоговый список)``. Повтор того же ``ref`` - без записи."""
    target = Path(path)
    current = read_work_refs(target, vault_root)
    merged: list[Any] = []
    replaced = False
    for item in current:
        if _ref_id(item) == ref["id"]:
            merged.append(ref)
            replaced = True
        else:
            merged.append(item)
    if not replaced:
        merged.append(ref)
    value = RawYaml(json.dumps(merged, ensure_ascii=False))
    text = target.read_text(encoding="utf-8")
    if not text.startswith("---"):
        # нет frontmatter: блок с одним полем в начало, тело - как было
        target.write_text(f"---\n{FIELD}: {value.text}\n---\n{text}", encoding="utf-8")
        return True, merged
    _prev, changed = set_frontmatter_fields(target, {FIELD: value})
    return changed, merged
