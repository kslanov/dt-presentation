"""PERSONAL-1 п.5 - ``bridge_scan``: личные заметки → кандидаты связей в рабочем знании → карточки.

Шаг ``bridge`` ночной index-цепочки ЛИЧНОГО экземпляра (после ``reindex_inc``) и ``dt bridge``.

Что делает:

1. дельта: личные заметки, новые/изменившиеся с прошлого скана (``(mtime_ns, size)`` против
   ``.derived/bridge_state.json``; список заметок - снимок frontmatter ``fm_cache``);
   ``07-outputs/``
   и корневой ``README.md`` не сканируются;
2. по каждой заметке запрос в рабочий демон (:class:`core.bridge.work_client.WorkClient`, токен
   чтения): ``find_notes`` (заголовок + первые 400 символов, ``limit`` ``DT_BRIDGE_LIMIT``) и срез
   по
   хабам: ``parse_task`` называет хабы в тексте, ``retrieve`` отдает слайсы ``client_hub``/
   ``practices``;
3. кандидаты с оценкой ``>= DT_BRIDGE_MIN_SCORE`` → upsert карточек ``bridge`` в
   ``.derived/bridge.jsonl`` по паре ``(personal_note_id, work_note_id)`` с цитатами обеих сторон.

Бюджет ``DT_BRIDGE_BUDGET_S`` (дефолт 120): сверх него скан останавливается честным ``partial``, а
нетронутые заметки остаются в дельте до следующего прогона. Рабочий демон не отвечает -
скан прекращается (``work_unavailable``), заметки НЕ отмечаются просмотренными.

Рабочий vault, индекс и ``.derived`` скан не пишет: единственный исходящий вызов - чтение по токену
чтения (с ``X-DT-No-Journal``: личный текст не оседает в рабочем журнале запросов).
"""

from __future__ import annotations

import os
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.bridge import store as _store
from core.bridge.work_client import WorkClient

__all__ = [
    "GENERIC_HEADINGS",
    "HUB_SLICES",
    "RETRIEVE_USE_CASE",
    "ScanResult",
    "budget_s",
    "candidate_limit",
    "min_body_chars",
    "min_quote_chars",
    "min_score",
    "min_score_fts",
    "min_score_legacy",
    "note_title",
    "personal_quote",
    "query_for",
    "scan",
    "work_corpus",
]

HUB_SLICES = ("client_hub", "practices")
RETRIEVE_USE_CASE = "client_correspondence"  # дефолтный кейс parse_task: слайсы client_hub/…
SKIP_DIRS = ("07-outputs",)
SKIP_FILES = ("README.md",)
QUERY_BODY_CHARS = 400
QUOTE_CHARS = 240
_FOOTER_KEYS = ("источник:", "lane:", "taskid:", "captured:", "modified:", "type:", "url:",
                "source:")
_FM_RE = re.compile(r"\A---\r?\n.*?\r?\n---\r?\n?", re.DOTALL)
# PERSONAL-3 п.B1: служебные строки шаблонов Templater/Obsidian в ТЕЛЕ заметки (ключи шаблонов К.:
# подкаст, статья, книга, идея) не должны уходить в запрос рабочему поиску.
TEMPLATE_KEYS = frozenset({
    "title", "date", "time", "podcast", "episode_number", "host", "guest", "link", "source",
    "author", "tags", "status", "rating", "type", "url", "created", "linked_notes",
    "publication_date", "date_read", "genre"})
GENERIC_HEADINGS = frozenset({
    "overview", "summary", "notes", "intro", "links", "key takeaways", "related", "references"})
_KEY_LINE_RE = re.compile(r"^\s*[-*]?\s*([A-Za-z_][\w ]*?)\s*:(?:\s|$)")
_PLACEHOLDER_RE = re.compile(r"\{\{.*?\}\}|<%.*?%>")
_ONLY_REFS_RE = re.compile(
    r"^[\s\-*>,;]*(?:(?:\[\[[^\]]*\]\]|#[\w/-]+|https?://\S+)[\s\-*>,;]*)+$")
NO_TERMS_SCORE = 0.85  # без общих терминов проходит только близость не ниже этой оценки


def _env_num(name: str, default: float, cast: Callable[[str], float]) -> float:
    try:
        value = cast((os.environ.get(name) or "").strip() or str(default))
    except ValueError:
        return default
    return value if value > 0 else default


def min_score() -> float:
    """``DT_BRIDGE_MIN_SCORE`` (дефолт 0.55): порог оценки кандидата на шкале ``find_notes``
    0..1."""
    return float(_env_num("DT_BRIDGE_MIN_SCORE", 0.55, float))


def min_score_fts() -> float:
    """``DT_BRIDGE_MIN_SCORE_FTS`` (дефолт 0.75): порог для хита БЕЗ семантики (чистый fts /
    fts+rerank); ``DT_BRIDGE_MIN_SCORE`` остается нижней планкой для всех."""
    return float(_env_num("DT_BRIDGE_MIN_SCORE_FTS", 0.75, float))


def min_score_legacy() -> float:
    """``DT_BRIDGE_MIN_SCORE_LEGACY`` (дефолт 0.8): порог для хитов легаси (при корпусе both)."""
    return float(_env_num("DT_BRIDGE_MIN_SCORE_LEGACY", 0.8, float))


def work_corpus() -> str:
    """``DT_BRIDGE_WORK_CORPUS``: ``vault`` (дефолт) | ``both`` (vault + легаси рабочего)."""
    raw = (os.environ.get("DT_BRIDGE_WORK_CORPUS") or "").strip().lower()
    return raw if raw in ("vault", "both") else "vault"


def min_body_chars() -> int:
    """``DT_BRIDGE_MIN_BODY_CHARS`` (дефолт 120): тело короче - заметка-заглушка."""
    return int(_env_num("DT_BRIDGE_MIN_BODY_CHARS", 120, lambda s: float(int(s))))


def min_quote_chars() -> int:
    """``DT_BRIDGE_MIN_QUOTE_CHARS`` (дефолт 200): рабочая цитата короче - кусок/страница."""
    return int(_env_num("DT_BRIDGE_MIN_QUOTE_CHARS", 200, lambda s: float(int(s))))


def candidate_limit() -> int:
    """``DT_BRIDGE_LIMIT`` (дефолт 5): сколько хитов ``find_notes`` берется на заметку."""
    return int(_env_num("DT_BRIDGE_LIMIT", 5, lambda s: float(int(s))))


def budget_s() -> float:
    """``DT_BRIDGE_BUDGET_S`` (дефолт 120): бюджет шага ``bridge``, секунд."""
    return float(_env_num("DT_BRIDGE_BUDGET_S", 120.0, float))


def _clean(body: str, drop: str = "") -> str:
    """Тело заметки для запроса/цитаты: без frontmatter, служебного футера и разметки заголовков.

    ``drop`` - строка-заголовок, уже вошедшая в запрос отдельно (повтор не нужен)."""
    text = _FM_RE.sub("", body, count=1)
    lines = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line == "---" or line.lower().startswith(_FOOTER_KEYS):
            continue
        if _service_line(line):
            continue
        line = line.lstrip("#").strip() if line.startswith("#") else line
        if drop and line == drop:
            continue
        if line.rstrip(":").strip().casefold() in GENERIC_HEADINGS:
            continue
        lines.append(line)
    return " ".join(" ".join(lines).split())


def _service_line(line: str) -> bool:
    """Служебная строка шаблона в теле: плейсхолдер ``{{…}}``/``<%…%>``, ``ключ: значение`` с ключом
    шаблона, строка из одних ``[[ссылок]]``/``#тегов``/адресов."""
    if _PLACEHOLDER_RE.search(line):
        return True
    m = _KEY_LINE_RE.match(line)
    if m and m.group(1).strip().casefold().replace(" ", "_") in TEMPLATE_KEYS:
        return True
    return bool(_ONLY_REFS_RE.match(line))


def note_title(note: Any, meta: Any) -> str:
    """Заголовок личной заметки: ``title`` frontmatter, иначе первый ``# `` тела, иначе имя файла.

    (``NoteMeta.title`` у заметки без frontmatter - имя файла, а настоящий заголовок - в H1.)"""
    explicit = str((note.frontmatter or {}).get("title") or "").strip()
    if explicit:
        return " ".join(explicit.split())
    for raw in _FM_RE.sub("", note.body, count=1).splitlines():
        if raw.startswith("# ") and raw[2:].strip():
            return " ".join(raw[2:].split())
    return str(meta.h1 or meta.title or Path(meta.path).stem)


def query_for(title: str, body: str) -> str:
    """Запрос в рабочий ``find_notes``: заголовок + первые 400 символов очищенного тела."""
    head = " ".join(str(title or "").split())
    rest = _clean(body, drop=head)[:QUERY_BODY_CHARS]
    return f"{head}. {rest}".strip(" .") if head and rest else (head or rest)


def personal_quote(body: str) -> str:
    """Цитата личной стороны для карточки: начало очищенного тела (до 240 символов)."""
    text = _clean(body)
    return text if len(text) <= QUOTE_CHARS else text[: QUOTE_CHARS - 1].rstrip() + "…"


@dataclass
class ScanResult:
    scanned: int = 0  # заметок опрошено в этом прогоне
    unchanged: int = 0  # пропущено по дельте
    candidates: int = 0  # кандидатов выше порога (до upsert)
    new: int = 0
    updated: int = 0
    kept: int = 0  # решенные/остановленные пары (новой карточки нет)
    below_threshold: int = 0
    excluded: int = 0  # PERSONAL-2: вне моста по DT_BRIDGE_EXCLUDE (текст рабочему не шлется)
    dropped: int = 0  # ждущие карточки заметок, попавших под исключение позже
    stubs: int = 0  # PERSONAL-3: заметки-заглушки (тело шаблона без содержания): не опрошены
    pages: int = 0  # хиты рабочей стороны - служебные страницы/куски документов: пропущены
    weak: int = 0  # лексика без семантики/легаси ниже своего порога
    short: int = 0  # чистая семантика на короткой рабочей цитате
    no_terms: int = 0  # нет общих терминов и оценка ниже NO_TERMS_SCORE
    withdrawn: int = 0  # --rescan: ждущие карточки, переставшие проходить правила
    partial: bool = False  # бюджет вышел раньше конца дельты
    work_unavailable: str = ""  # причина, если рабочий демон не ответил (скан прерван)
    retrieve_errors: int = 0
    pending_left: int = 0  # заметок дельты, до которых не дошли
    elapsed_s: float = 0.0
    dry_run: bool = False
    items: list[dict[str, Any]] = field(default_factory=list)  # dry-run: что нашлось

    def summary(self) -> dict[str, Any]:
        return {
            "scanned": self.scanned, "unchanged": self.unchanged, "candidates": self.candidates,
            "new": self.new, "updated": self.updated, "kept": self.kept,
            "below_threshold": self.below_threshold, "excluded": self.excluded,
            "dropped": self.dropped, "stubs": self.stubs, "pages": self.pages, "weak": self.weak,
            "short": self.short, "no_terms": self.no_terms, "withdrawn": self.withdrawn,
            "partial": self.partial,
            "work_unavailable": self.work_unavailable, "retrieve_errors": self.retrieve_errors,
            "pending_left": self.pending_left, "elapsed_s": round(self.elapsed_s, 1),
            "dry_run": self.dry_run,
        }


def _eligible(rel: str) -> bool:
    parts = Path(rel).parts
    return not (parts and parts[0] in SKIP_DIRS) and rel not in SKIP_FILES


def _hits(env: dict[str, Any]) -> list[dict[str, Any]]:
    notes = (env.get("result") or {}).get("notes")
    return [n for n in notes if isinstance(n, dict) and n.get("note_id")] if isinstance(
        notes, list) else []


def _hub_hits(client: WorkClient, query: str) -> tuple[list[dict[str, Any]], bool]:
    """Хиты слайсов ``client_hub``/``practices`` + признак ошибки (best-effort, скан не рвет)."""
    parsed = client.parse_task(query)
    if not parsed.get("ok"):
        return [], True
    res = parsed["result"]
    params = res.get("params") if isinstance(res.get("params"), dict) else {}
    if not any(str(k).endswith("_id") for k in params):
        return [], False  # хабы в тексте не названы: слайсам нечего резолвить
    got = client.retrieve(str(res.get("use_case_id") or RETRIEVE_USE_CASE), query, params=params)
    if not got.get("ok"):
        return [], True
    slices = got["result"].get("slices")
    out: list[dict[str, Any]] = []
    if isinstance(slices, dict):
        for name in HUB_SLICES:
            for hit in slices.get(name) or []:
                if isinstance(hit, dict) and hit.get("note_id"):
                    out.append({**hit, "matched_by": f"retrieve:{name}"})
    return out, False


def scan(
    vault: Path,
    client: WorkClient,
    *,
    store: _store.BridgeStore | None = None,
    state: dict[str, Any] | None = None,
    threshold: float | None = None,
    limit: int | None = None,
    budget: float | None = None,
    dry_run: bool = False,
    max_notes: int | None = None,
    now: datetime | None = None,
    clock: Callable[[], float] = time.monotonic,
    metas_loader: Callable[[Path], Any] | None = None,
    exclude: list[str] | None = None,
    rescan: bool = False,
) -> ScanResult:
    """Один прогон ``bridge_scan`` по личному vault. Никогда не пишет в рабочий контур.

    ``dry_run`` - только считает кандидатов (``items``), не пишет ни стор, ни дельту.
    ``max_notes`` - потолок заметок за прогон (``dt bridge --limit``); ``metas_loader`` - откуда
    брать срезы заметок (по умолчанию снимок frontmatter ``fm_cache``; инъекция для тестов).

    ``exclude`` (по умолчанию ``DT_BRIDGE_EXCLUDE``, дефолт ``Templates/**``) - glob-ы от корня
    vault: такие заметки не опрашиваются и их текст рабочему демону не уходит НИКОГДА (замок стоит
    до сборки запроса); ждущие карточки по заметкам, попавшим под исключение позже, снимаются.

    PERSONAL-3: заметка-заглушка (тело шаблона без содержания) не опрашивается; рабочий поиск
    идет по корпусу ``DT_BRIDGE_WORK_CORPUS``; хит без семантики проходит порог
    ``DT_BRIDGE_MIN_SCORE_FTS``, легаси - ``DT_BRIDGE_MIN_SCORE_LEGACY``; служебные страницы и
    короткие куски пропускаются; кандидат хранит общие термины (``terms``). ``rescan`` - пересчет
    по новым правилам: дельта не смотрит на подписи, ждущие карточки, переставшие проходить,
    помечаются ``withdrawn``."""
    from core.retrieval.fm_cache import load_metas_cached

    vault = Path(vault)
    threshold = min_score() if threshold is None else threshold
    limit = candidate_limit() if limit is None else limit
    budget = budget_s() if budget is None else budget
    moment = now or datetime.now(UTC)
    result = ScanResult(dry_run=dry_run)
    started = clock()
    own_store = store if store is not None else _store.BridgeStore.load()
    own_state = state if state is not None else _store.load_state()
    seen: dict[str, Any] = own_state.setdefault("notes", {})

    metas = metas_loader(vault) if metas_loader is not None else load_metas_cached(vault)[0]
    from core.instance import bridge_exclude, excluded

    patterns = bridge_exclude() if exclude is None else list(exclude)
    delta: list[tuple[int, Any, tuple[int, int]]] = []
    for meta in metas:
        if not _eligible(meta.path):
            continue
        if patterns and excluded(meta.path, patterns):
            result.excluded += 1
            continue
        try:
            st = (vault / meta.path).stat()
        except OSError:
            continue
        sig = (st.st_mtime_ns, st.st_size)
        if not rescan and seen.get(meta.path, {}).get("sig") == list(sig):
            result.unchanged += 1
            continue
        delta.append((st.st_mtime_ns, meta, sig))
    delta.sort(key=lambda row: row[0], reverse=True)  # свежие правки - первыми
    if max_notes is not None:
        delta = delta[:max_notes]

    for index, (_mtime, meta, sig) in enumerate(delta):
        if clock() - started >= budget:
            result.partial = True
            result.pending_left = len(delta) - index
            break
        from core.vault import read_note

        try:
            note = read_note(vault / meta.path, vault)
        except Exception:  # noqa: BLE001, S112 - нечитаемая заметка пропускается, скан идет дальше
            continue
        title = note_title(note, meta)
        stamp = {"sig": list(sig), "at": moment.isoformat(timespec="seconds")}
        if len(_clean(note.body, drop=" ".join(title.split()))) < min_body_chars():
            # заглушка шаблона: тела нет - запрос из одного заголовка дает случайные связки
            result.stubs += 1
            if not dry_run:
                seen[meta.path] = {**stamp, "reason": "stub"}
                if rescan:
                    result.withdrawn += _withdraw_note(own_store, meta.path, set(), "stub", moment)
            continue
        query = query_for(title, note.body)
        found = client.find_notes(query, limit=limit, **(
            {} if work_corpus() == "both" else {"corpus": "vault"}))
        if not found.get("ok"):
            result.work_unavailable = str(found.get("reason") or "unavailable")
            result.pending_left = len(delta) - index
            break
        hits = _hits(found)
        hub, hub_error = _hub_hits(client, query)
        result.retrieve_errors += int(hub_error)
        best: dict[str, dict[str, Any]] = {}
        for hit in [*hits, *hub]:
            wid = str(hit["note_id"])
            if wid not in best or float(hit.get("score") or 0) > float(best[wid].get("score") or 0):
                best[wid] = hit
        result.scanned += 1
        quote = personal_quote(note.body)
        passing: set[str] = set()
        for wid, hit in sorted(best.items(), key=lambda kv: -float(kv[1].get("score") or 0)):
            score = float(hit.get("score") or 0)
            if score < threshold:
                result.below_threshold += 1
                continue
            matched = str(hit.get("matched_by") or hit.get("slice") or "")
            if (_lexical_only(matched) and score < min_score_fts()) or (
                    str(hit.get("corpus") or "") == "legacy" and score < min_score_legacy()):
                result.weak += 1
                continue
            cand = {
                "personal_note_id": note.id, "personal_path": meta.path,
                "personal_title": title, "work_note_id": wid,
                "work_title": str(hit.get("title") or wid), "work_path": str(hit.get("path") or ""),
                "work_corpus": str(hit.get("corpus") or ""), "score": round(score, 4),
                "matched_by": matched,
                "quote_personal": quote, "quote_work": str(hit.get("preview") or ""),
            }
            if not cand["quote_work"] or cand["work_title"] == wid:
                _fill_work_side(client, cand)  # только чтение рабочего; цитата нужна и для фильтров
            verdict_skip = _judge(cand, hit, query, result)
            if verdict_skip:
                continue
            result.candidates += 1
            passing.add(_store.card_key(note.id, wid))
            if dry_run:
                result.items.append(cand)
                continue
            verdict = own_store.upsert(cand, now=moment)
            setattr(result, verdict, getattr(result, verdict) + 1)
        if not dry_run:
            seen[meta.path] = stamp
            if rescan:
                result.withdrawn += _withdraw_note(own_store, meta.path, passing, "rules", moment)

    result.elapsed_s = clock() - started
    if not dry_run:
        if patterns:
            result.dropped = own_store.drop_pending_where(
                lambda row: excluded(str(row.get("personal_path") or ""), patterns))
        own_store.save()
        # заметки, которых больше нет в vault, из дельты уходят (стор карточек не трогаем)
        known = {m.path for m in metas}
        for gone in [p for p in seen if p not in known]:
            seen.pop(gone, None)
        _store.save_state(own_state)
        _store.save_last({**result.summary(), "at": moment.isoformat(timespec="seconds")})
    return result


def _lexical_only(matched_by: str) -> bool:
    """Хит держится только на лексике: ``fts`` / ``fts+rerank`` без семантики и хаба."""
    parts = {p for p in str(matched_by).replace("+", " ").split() if p}
    return bool(parts) and parts <= {"fts", "rerank"}


def _judge(cand: dict[str, Any], hit: dict[str, Any], query: str, result: ScanResult) -> bool:
    """Правила качества над кандидатом; ``True`` - пропустить (счетчик в ``result``). Дописывает
    ``terms``/``rationale`` и родительский документ вместо заголовка страницы."""
    from core.bridge.terms import shared_terms

    kind = str(hit.get("kind") or "")
    quote_len = len(cand["quote_work"])
    short = quote_len < min_quote_chars()
    if kind and short:  # слайд/страница/лист/«Содержимое» и текста почти нет - служебный кусок
        result.pages += 1
        return True
    if kind and hit.get("doc_title"):
        cand["work_title"] = str(hit["doc_title"])
    matched = cand["matched_by"]
    if "semantic" in matched and "fts" not in matched and short:
        result.short += 1  # чистая семантика на короткой цитате: «похоже» без содержания
        return True
    terms = shared_terms(query, f"{cand['work_title']} {cand['quote_work']}")
    if not terms and float(cand["score"]) < NO_TERMS_SCORE:
        result.no_terms += 1
        return True
    cand["terms"] = terms
    if not terms:
        cand["rationale"] = "семантическая близость без общих терминов"
    return False


def _withdraw_note(
    store: _store.BridgeStore, path: str, keep: set[str], reason: str, moment: datetime
) -> int:
    """Снять ждущие карточки заметки ``path``, которых нет среди ``keep`` (пересчет)."""
    gone = [k for k, r in store.rows.items() if r.get("personal_path") == path
            and r.get("status") == _store.STATUS_PENDING and k not in keep]
    return sum(store.withdraw(k, reason, now=moment) for k in gone)


def _fill_work_side(client: WorkClient, cand: dict[str, Any]) -> None:
    """Цитата и заголовок рабочей стороны: ``work_note_preview`` (read-only); нет - как пришло."""
    got = client.note_preview(cand["work_note_id"])
    if got.get("ok") and (got["result"] or {}).get("found"):
        res = got["result"]
        cand["quote_work"] = str(res.get("preview") or cand["quote_work"])
        if cand["work_title"] == cand["work_note_id"] and res.get("title"):
            cand["work_title"] = str(res["title"])
