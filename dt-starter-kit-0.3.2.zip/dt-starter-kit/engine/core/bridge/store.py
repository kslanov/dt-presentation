"""PERSONAL-1 п.5 - стор карточек ``bridge`` (``.derived/bridge.jsonl``) и состояние скана.

Одна строка стора - одно предложение связи ЛИЧНОЙ заметки с РАБОЧЕЙ: ``(personal_note_id,
work_note_id)`` - ключ upsert (``id`` = sha1-хвост пары). Стор лежит в ``.derived`` ЛИЧНОГО
экземпляра
(``DT_DERIVED_ROOT`` его оверлея); у рабочего экземпляра этого файла нет и быть не может (его пишет
только ``bridge_scan`` личной роли). Производное, пересобираемое: решенная строка - заодно журнал
остановки (``rejected``/``snoozed`` не предлагаются заново до ``snooze_until``).

``bridge_state.json`` - дельта скана: путь личной заметки → ``(mtime_ns, size)`` на момент
последнего скана; ``bridge_last.json`` - итог последнего прогона для доктора.

Запись атомарная (temp + rename); чтение терпит битые строки (пропуск + счетчик).
"""

from __future__ import annotations

import hashlib
import json
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import derived_root

__all__ = [
    "BridgeStore",
    "STATUS_APPLIED",
    "STATUS_PENDING",
    "STATUS_REJECTED",
    "STATUS_WITHDRAWN",
    "card_key",
    "last_path",
    "load_last",
    "load_state",
    "save_last",
    "save_state",
    "snooze_days",
    "state_path",
    "store_path",
]

STATUS_PENDING = "pending"
STATUS_APPLIED = "applied"
STATUS_REJECTED = "rejected"
STATUS_WITHDRAWN = "withdrawn"  # PERSONAL-3: больше не проходит правила (dt bridge --rescan)
ENV_SNOOZE_DAYS = "DT_BRIDGE_SNOOZE_DAYS"
DEFAULT_SNOOZE_DAYS = 30


def store_path() -> Path:
    """``.derived/bridge.jsonl`` (под ``DT_DERIVED_ROOT``; своего переопределения нет)."""
    return derived_root() / "bridge.jsonl"


def state_path() -> Path:
    """``.derived/bridge_state.json`` - дельта скана личных заметок."""
    return derived_root() / "bridge_state.json"


def last_path() -> Path:
    """``.derived/bridge_last.json`` - итог последнего скана (доктор «Мост»)."""
    return derived_root() / "bridge_last.json"


def snooze_days() -> int:
    """``DT_BRIDGE_SNOOZE_DAYS`` (дефолт 30): стоп новой карточки по паре после отказа."""
    try:
        value = int((os.environ.get(ENV_SNOOZE_DAYS) or "").strip() or DEFAULT_SNOOZE_DAYS)
    except ValueError:
        return DEFAULT_SNOOZE_DAYS
    return value if value > 0 else DEFAULT_SNOOZE_DAYS


def card_key(personal_note_id: str, work_note_id: str) -> str:
    """Стабильный id пары (ключ upsert и родной id карточки)."""
    digest = hashlib.sha1(f"{personal_note_id}\x1f{work_note_id}".encode(), usedforsecurity=False)
    return digest.hexdigest()[:12]


def _iso(moment: datetime) -> str:
    return moment.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse(value: Any) -> datetime | None:
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


@dataclass
class BridgeStore:
    """Карточки моста. ``rows`` - ``{id: строка}``; ``skipped`` - сколько битых строк пропущено."""

    path: Path
    rows: dict[str, dict[str, Any]] = field(default_factory=dict)
    skipped: int = 0

    @classmethod
    def load(cls, path: Path | None = None) -> BridgeStore:
        target = Path(path) if path is not None else store_path()
        store = cls(target)
        try:
            lines = target.read_text(encoding="utf-8").splitlines()
        except OSError:
            return store
        for line in lines:
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                store.skipped += 1
                continue
            if isinstance(row, dict) and row.get("id"):
                store.rows[str(row["id"])] = row
            else:
                store.skipped += 1
        return store

    def save(self) -> None:
        text = "".join(json.dumps(r, ensure_ascii=False, sort_keys=True) + "\n"
                       for r in self.rows.values())
        _atomic_write(self.path, text)

    # -- выборки -----------------------------------------------------------
    def pending(self, now: datetime | None = None) -> list[dict[str, Any]]:
        """Карточки, ждущие решения (``snoozed`` скрыты до срока), лучшие по оценке первыми."""
        moment = now or datetime.now(UTC)
        rows = [r for r in self.rows.values() if r.get("status") == STATUS_PENDING
                and not self._snoozed(r, moment)]
        rows.sort(key=lambda r: (-float(r.get("score") or 0), str(r.get("personal_note_id"))))
        return rows

    @staticmethod
    def _snoozed(row: dict[str, Any], now: datetime) -> bool:
        until = _parse(row.get("snooze_until")) if row.get("snooze_until") else None
        return until is not None and until > now

    def get(self, native_id: str) -> dict[str, Any] | None:
        return self.rows.get(native_id)

    def drop_pending_where(self, predicate: Callable[[dict[str, Any]], bool]) -> int:
        """Убрать ждущие карточки, подпавшие под ``predicate`` (решенные не трогаем); сколько
        убрано."""
        gone = [k for k, r in self.rows.items() if r.get("status") == STATUS_PENDING
                and predicate(r)]
        for key in gone:
            del self.rows[key]
        return len(gone)

    # -- upsert ------------------------------------------------------------
    def upsert(self, cand: dict[str, Any], *, now: datetime | None = None) -> str:
        """Занести кандидата: ``new`` | ``updated`` | ``kept`` (решенное/остановленное не трогаем).

        * нет строки - ``pending``;
        * ``pending`` - освежаем оценку и цитаты (статус не меняем);
        * ``applied`` - связь уже принята, новой карточки нет (``kept``);
        * ``rejected`` - пока не истёк ``snooze_until``: ``kept``; после срока пара предлагается
          снова (``new``-подобно: статус ``pending``)."""
        moment = now or datetime.now(UTC)
        key = card_key(str(cand["personal_note_id"]), str(cand["work_note_id"]))
        fresh = {**cand, "id": key, "updated_at": _iso(moment)}
        prior = self.rows.get(key)
        if prior is None:
            self.rows[key] = {**fresh, "status": STATUS_PENDING, "created_at": _iso(moment)}
            return "new"
        status = prior.get("status")
        if status == STATUS_APPLIED:
            return "kept"
        if status == STATUS_REJECTED and self._snoozed(prior, moment):
            return "kept"
        if status == STATUS_WITHDRAWN:  # снятая пересчетом пара снова проходит правила
            self.rows[key] = {**prior, **fresh, "status": STATUS_PENDING, "withdrawn_at": None,
                              "withdrawn_reason": None, "reopened_at": _iso(moment)}
            return "new"
        if status == STATUS_REJECTED:  # срок стопа вышел: предлагаем снова
            self.rows[key] = {**prior, **fresh, "status": STATUS_PENDING, "snooze_until": None,
                              "reopened_at": _iso(moment)}
            return "new"
        # pending (в т.ч. отложенная): освежаем содержимое, отсрочку не снимаем
        self.rows[key] = {**prior, **{k: v for k, v in fresh.items() if k != "created_at"}}
        return "updated"

    def withdraw(self, native_id: str, reason: str, *, now: datetime | None = None) -> bool:
        """Снять ждущую карточку, которая больше не проходит правила: статус ``withdrawn`` с
        причиной и временем (след в сторе остается; из «Требуют решения» карточка уходит)."""
        row = self.rows.get(native_id)
        if row is None or row.get("status") != STATUS_PENDING:
            return False
        row.update(status=STATUS_WITHDRAWN, withdrawn_reason=reason,
                   withdrawn_at=_iso(now or datetime.now(UTC)), snooze_until=None)
        return True

    # -- решения -----------------------------------------------------------
    def mark_applied(self, native_id: str, *, now: datetime | None = None) -> None:
        row = self.rows[native_id]
        row.update(status=STATUS_APPLIED, decided_at=_iso(now or datetime.now(UTC)),
                   snooze_until=None)

    def mark_rejected(self, native_id: str, *, now: datetime | None = None,
                      days: int | None = None) -> str:
        moment = now or datetime.now(UTC)
        until = _iso(moment + timedelta(days=days or snooze_days()))
        self.rows[native_id].update(status=STATUS_REJECTED, decided_at=_iso(moment),
                                    snooze_until=until)
        return until

    def snooze(self, native_id: str, days: float, *, now: datetime | None = None) -> str:
        """Отложить карточку: остается ``pending``, но скрыта до ``snooze_until``."""
        moment = now or datetime.now(UTC)
        until = _iso(moment + timedelta(days=days))
        self.rows[native_id]["snooze_until"] = until
        self.rows[native_id]["updated_at"] = _iso(moment)
        return until


# --------------------------------------------------------------------------- #
# дельта скана и итог прогона                                                  #
# --------------------------------------------------------------------------- #
def load_state(path: Path | None = None) -> dict[str, Any]:
    target = Path(path) if path is not None else state_path()
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"notes": {}}
    if not isinstance(data, dict) or not isinstance(data.get("notes"), dict):
        return {"notes": {}}
    return data


def save_state(state: dict[str, Any], path: Path | None = None) -> None:
    _atomic_write(Path(path) if path is not None else state_path(),
                  json.dumps(state, ensure_ascii=False, sort_keys=True))


def load_last(path: Path | None = None) -> dict[str, Any] | None:
    target = Path(path) if path is not None else last_path()
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def save_last(summary: dict[str, Any], path: Path | None = None) -> None:
    _atomic_write(Path(path) if path is not None else last_path(),
                  json.dumps(summary, ensure_ascii=False, sort_keys=True))
