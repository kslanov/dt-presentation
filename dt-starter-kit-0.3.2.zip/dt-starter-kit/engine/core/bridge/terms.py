"""PERSONAL-3 п.B5 - общие термины личной заметки и рабочей цитаты («почему» моста).

Токены от 4 символов, без стоп-слов ru/en, сравнение по основе (первые 6 символов слова):
«партнерства» и «партнерств» - один термин. Результат - список слов запроса (как они стоят в личной
заметке), которые есть и в рабочем тексте: его хранит кандидат (``terms``), его показывает «почему»
вместо фиксированной фразы."""

from __future__ import annotations

import re

__all__ = ["MIN_TOKEN", "STEM_LEN", "STOPWORDS", "shared_terms", "stem", "tokens"]

MIN_TOKEN = 4
STEM_LEN = 6
_WORD_RE = re.compile(r"[a-zа-яё0-9]+", re.IGNORECASE)

STOPWORDS = frozenset("""
этот эта это эти того тому этом этих такой также если чтобы когда только очень можно
нужно будет были было была есть для при про над под без между после перед через около
вокруг среди кроме против вместо внутри более менее ещё еще уже или либо как так что кто
где там тут его ее её их нас вас них себя свой своя свои все всё всех весь вся сам сама
который которая которые которое которых которым которой своих чем тем тот той том тех
about above after again also because been before being below between both could does
doing down during each from further have having here into itself just more most myself
other over same should some such than that their theirs them then there these they this
those through under until very were what when where which while with would your yours
about overview summary notes intro links related references
""".split())


def stem(word: str) -> str:
    """Основа для сравнения: первые :data:`STEM_LEN` символов слова в нижнем регистре."""
    return word.lower()[:STEM_LEN]


def tokens(text: str) -> list[str]:
    """Значимые слова текста по порядку появления (``>= MIN_TOKEN`` символов, без стоп-слов)."""
    out: list[str] = []
    for raw in _WORD_RE.findall(text or ""):
        word = raw.lower()
        if len(word) >= MIN_TOKEN and word not in STOPWORDS and not word.isdigit():
            out.append(word)
    return out


def shared_terms(query: str, work_text: str, *, limit: int = 8) -> list[str]:
    """Слова ``query``, чья основа есть в ``work_text``; без повторов, не больше ``limit``."""
    have = {stem(w) for w in tokens(work_text)}
    seen: set[str] = set()
    out: list[str] = []
    for word in tokens(query):
        key = stem(word)
        if key in have and key not in seen:
            seen.add(key)
            out.append(word)
            if len(out) >= limit:
                break
    return out
