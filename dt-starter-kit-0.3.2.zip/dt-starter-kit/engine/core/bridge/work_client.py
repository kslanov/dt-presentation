"""PERSONAL-1 п.4 - ``WorkClient``: клиент рабочего демона из личного экземпляра.

``POST <DT_WORK_URL>/api/<tool>`` (JSON, Bearer) - тот же вход веб-пульта, без MCP-сессии. Токен -
ТОЛЬКО токен чтения рабочего демона (``DT_WORK_TOKEN_FILE``): запись по нему рабочий демон не
пускает
(403 ``write_token_required``), а сам клиент вдобавок отказывает локально всему, чего нет в
:data:`READ_TOOLS` (второй замок: даже подмена токена на rw не откроет клиенту инструменты записи).

Доступно ровно то, что рабочий демон отдает в профиле ``pult`` по ``/api``: ``find_notes``,
``retrieve``, ``parse_task`` (какие хабы названы в тексте) и ``work_note_preview`` (превью
заметки, read-only). ``read_note``/``find_latest`` в
профиль ``pult`` не входят - клиент их не предлагает.

Отказ рабочего демона (нет ответа, таймаут, 5xx, битый ответ, токен не принят, ошибка инструмента) -
КОНВЕРТ ``work_unavailable`` (``ok: false``, ``code``, ``reason``, ``error``, ``status``), не
исключение: мост и ``personal_recall`` деградируют, а не падают. Сетевой вызов инъектируется
(``transport``) - тесты гоняют клиент против фейкового сервера.

Тело запроса несет текст ЛИЧНОЙ заметки (как запрос поиска): клиент всегда шлет
``X-DT-No-Journal: 1`` - рабочий демон не пишет такой вызов в свой журнал запросов.
"""

from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from collections.abc import Callable
from typing import Any

from core import instance as _inst
from core.eval_journal import HEADER_NO_JOURNAL

__all__ = [
    "CODE_UNAVAILABLE",
    "LEVEL_PROBE_TOOL",
    "READ_TOOLS",
    "Transport",
    "WorkClient",
    "work_unavailable",
]

logger = logging.getLogger("dt.bridge")

CODE_UNAVAILABLE = "work_unavailable"
#: инструменты, которые клиент вообще согласен звать (читающие; в профиле pult рабочего демона)
READ_TOOLS = frozenset({"find_notes", "retrieve", "parse_task", "work_note_preview"})
#: запись по токену чтения рабочий демон отвергает ДО разбора тела; по неверному телу (не объект)
#: rw-токен дошел бы до 400, а read - 403: так проверяется уровень токена без побочных эффектов
LEVEL_PROBE_TOOL = "pult_card_decide"
DEFAULT_TIMEOUT_S = 20.0

#: ``transport(method, url, headers, body, timeout) -> (HTTP-статус, тело)``; сеть молчит - OSError
Transport = Callable[[str, str, dict[str, str], bytes | None, float], tuple[int, bytes]]


def _urllib_transport(
    method: str, url: str, headers: dict[str, str], body: bytes | None, timeout: float
) -> tuple[int, bytes]:
    req = urllib.request.Request(url, data=body, headers=headers, method=method)  # noqa: S310
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 - loopback http
            return int(resp.status), resp.read()
    except urllib.error.HTTPError as exc:
        return int(exc.code), exc.read() or b""


def work_unavailable(
    reason: str, error: str = "", status: int | None = None, tool: str = ""
) -> dict[str, Any]:
    """Конверт отказа рабочего демона (``reason``: ``connection`` | ``timeout`` | ``http_<код>`` |
    ``token_rejected`` | ``forbidden`` | ``bad_response`` | ``tool_error`` | ``not_configured``)."""
    return {"ok": False, "code": CODE_UNAVAILABLE, "refused": CODE_UNAVAILABLE, "reason": reason,
            "error": error or f"рабочий демон недоступен ({reason})", "status": status,
            "tool": tool}


class WorkClient:
    """Клиент рабочего демона: ``find_notes`` / ``retrieve`` / ``note_preview`` / ``health``."""

    def __init__(
        self, url: str, token: str, *, timeout: float = DEFAULT_TIMEOUT_S,
        transport: Transport | None = None,
    ) -> None:
        self.url = url.rstrip("/")
        self._token = token
        self.timeout = timeout
        self._transport = transport or _urllib_transport

    @classmethod
    def from_env(cls, *, transport: Transport | None = None) -> WorkClient | None:
        """Клиент из окружения экземпляра; ``None`` - нет клиента (клапан конструкцией).

        Нужны ВСЕ три условия: роль ``personal``, ``DT_WORK_URL`` и токен чтения в
        ``DT_WORK_TOKEN_FILE``. У рабочей роли адреса и токена нет по определению
        (:func:`core.instance.work_url`/:func:`core.instance.work_token` всегда пусты)."""
        url, token = _inst.work_url(), _inst.work_token()
        if not url or not token:
            return None
        return cls(url, token, transport=transport)

    # -- низкий уровень -----------------------------------------------------
    def _request(
        self, method: str, path: str, body: bytes | None = None, *, auth: bool = True
    ) -> tuple[int, bytes] | dict[str, Any]:
        headers = {"Content-Type": "application/json", HEADER_NO_JOURNAL: "1"}
        if auth:
            headers["Authorization"] = f"Bearer {self._token}"
        try:
            return self._transport(method, f"{self.url}{path}", headers, body, self.timeout)
        except TimeoutError:
            return work_unavailable("timeout", "рабочий демон не ответил за отведенное время")
        except (OSError, urllib.error.URLError) as exc:
            reason = "timeout" if "timed out" in str(exc).lower() else "connection"
            return work_unavailable(reason, f"рабочий демон не отвечает ({type(exc).__name__})")

    def call(self, tool: str, args: dict[str, Any] | None = None) -> dict[str, Any]:
        """``{"ok": True, "result": <структурный ответ>}`` либо конверт ``work_unavailable``."""
        if tool not in READ_TOOLS:
            return {"ok": False, "code": "tool_not_allowed", "refused": "tool_not_allowed",
                    "error": f"{tool}: мост зовет только читающие инструменты "
                             f"({', '.join(sorted(READ_TOOLS))})", "tool": tool}
        got = self._request("POST", f"/api/{tool}", json.dumps(args or {}).encode("utf-8"))
        if isinstance(got, dict):
            got["tool"] = tool
            return got
        status, raw = got
        if status == 401:
            return work_unavailable("token_rejected", "рабочий демон не принял токен чтения",
                                    status, tool)
        if status == 403:
            return work_unavailable("forbidden", "рабочий демон отказал токену чтения", status,
                                    tool)
        if status >= 400:
            return work_unavailable(f"http_{status}", f"рабочий демон ответил {status}", status,
                                    tool)
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return work_unavailable("bad_response", "ответ рабочего демона не JSON", status, tool)
        if not isinstance(data, dict):
            return work_unavailable("bad_response", "ответ рабочего демона не объект", status, tool)
        if data.get("isError"):
            text = ""
            content = data.get("content")
            if isinstance(content, list) and content and isinstance(content[0], dict):
                text = str(content[0].get("text") or "")[:200]
            return work_unavailable("tool_error", text or "инструмент вернул ошибку", status, tool)
        result = data.get("structuredContent")
        if not isinstance(result, dict):
            return work_unavailable("bad_response", "в ответе нет structuredContent", status, tool)
        return {"ok": True, "result": result, "tool": tool}

    # -- инструменты чтения -------------------------------------------------
    def find_notes(self, query: str, *, limit: int = 5, **kw: Any) -> dict[str, Any]:
        return self.call("find_notes", {"query": query, "limit": limit, **kw})

    def retrieve(
        self, use_case_id: str, query: str, *, corpus: str = "vault", **kw: Any
    ) -> dict[str, Any]:
        return self.call("retrieve", {"use_case_id": use_case_id, "query": query,
                                      "corpus": corpus, **kw})

    def parse_task(self, text: str) -> dict[str, Any]:
        return self.call("parse_task", {"text": text})

    def note_preview(self, name: str) -> dict[str, Any]:
        return self.call("work_note_preview", {"name": name})

    # -- состояние (для доктора) --------------------------------------------
    def health(self) -> dict[str, Any] | None:
        """``GET /health`` рабочего демона (без токена); ``None`` - не ответил / не наш."""
        got = self._request("GET", "/health", auth=False)
        if isinstance(got, dict):
            return None
        status, raw = got
        try:
            data = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            return None
        ok = status == 200 and isinstance(data, dict) and "version" in data
        return data if ok else None

    def token_level(self) -> str:
        """Что рабочий демон думает о нашем токене: ``read`` | ``write`` | ``rejected`` |
        ``unknown``.

        Проба без побочных эффектов: запись-инструмент с ТЕЛОМ-НЕ-ОБЪЕКТОМ (``[]``). Читающий токен
        получает 403 ``write_token_required`` ДО разбора тела; токен записи дошел бы до 400
        ``bad_request`` - и инструмент не выполнился бы в обоих случаях. ``write`` - тревога
        доктора: мосту положен только токен чтения."""
        got = self._request("POST", f"/api/{LEVEL_PROBE_TOOL}", b"[]")
        if isinstance(got, dict):
            return "unknown"
        status = got[0]
        if status == 401:
            return "rejected"
        if status == 403:
            return "read"
        if status == 400:
            return "write"
        return "unknown"
