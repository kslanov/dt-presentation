"""Markdown-aware chunking (architecture §5).

Splits a note's markdown body into semantic chunks recursively by document
structure (``#``, ``##``, ``###``) and, within sections, by paragraphs. Target
~500-800 tokens with ~100 token overlap; small files become a single chunk.
Frontmatter is never indexed as text — it travels in each chunk's ``metadata``.

Token sizing: by default a lightweight ``words × 1.3`` heuristic (no external
dependency, fully offline, deterministic). If the optional ``tiktoken`` package
is installed (``uv sync --extra precise``) it is used instead as a closer
approximation. Exact agreement with the BGE-M3 tokenizer is out of scope here —
real embedding tokenization is a later ТЗ.
"""

from __future__ import annotations

import hashlib
import math
import os
import re
from dataclasses import dataclass, field
from typing import Any

from core.vault import Note

__all__ = [
    "Chunk",
    "chunk_note",
    "context_prefix_enabled",
    "prefix_mode",
    "chunker_version",
    "CHUNKER_BASE_VERSION",
    "card_enabled",
    "is_email_thread",
    "split_context_prefix",
    "section_id",
    "PREFIX_OPEN",
    "PREFIX_CLOSE",
    "min_section_tokens",
    "MIN_SECTION_TOKENS",
    "TARGET_MIN_TOKENS",
    "TARGET_MAX_TOKENS",
    "OVERLAP_TOKENS",
]

TARGET_MIN_TOKENS = 500
TARGET_MAX_TOKENS = 800
OVERLAP_TOKENS = 100

# RETR-CHUNK-1 п.3: секция короче этого порога не становится чанком — приклеивается к
# соседней в пределах родителя (титульная страница docx, слайд из одной строки). Порог
# переопределяется ``DT_CHUNK_MIN_SECTION_TOKENS`` (0 = слияние выключено).
MIN_SECTION_TOKENS = 60
_MIN_SECTION_ENV = "DT_CHUNK_MIN_SECTION_TOKENS"
# RETR-CHUNK-1 п.1: контекстный префикс чанка — одна строка «{документ} › {путь заголовков} ·
# {клиент/проект} · {дата}» в ``«…»`` + пустая строка + тело. Он входит в ``text`` (значит, в FTS и
# в эмбеддинг), а при показе отделяется (:func:`split_context_prefix`; ``SearchResult.text`` —
# без префикса, сам префикс — ``metadata["context_prefix"]``). ``DT_CHUNK_CONTEXT_PREFIX=0``
# выключает (замер «до/после», откат).
PREFIX_OPEN = "«"
PREFIX_CLOSE = "»"
_PREFIX_ENV = "DT_CHUNK_CONTEXT_PREFIX"
_PREFIX_SEP = "\n\n"
_JOIN = "\n\n"  # разделитель единиц/сообщений внутри чанка
_PREFIX_TITLE_MAX = 120   # символов
_PREFIX_PATH_MAX = 160
_PREFIX_MAX = 360         # общий потолок строки префикса — он съедает бюджет чанка
# Машинный футер линковщика: стабильная граница, в содержательный чанк не вклеивается
# (правка списка связей не должна перевыпускать вектор соседнего текста).
_FOOTER_TITLES = frozenset({"связано"})

# Entity / classification fields carried from the note into chunk metadata (§5).
# genre/audience scope style-slice filtering; created/modified drive recency
# sorting (see core/retrieval/policies.py). corpus/curated/source_path/
# source_type/era/section are the layer-B (legacy corpus) discriminator and
# provenance fields (Phase 5) — carried so core/retrieval/index.py can store them.
_METADATA_FIELDS: tuple[str, ...] = (
    "id",
    "type",
    "client",
    "project",
    "deal",
    "industry",
    "direction",
    "product",
    "status",
    "genre",
    "audience",
    "created",
    "modified",
    "tags",
    "corpus",
    "curated",
    "source_path",
    "source_type",
    "era",
    "section",
    # OCR-1 п.4: уверенность распознавания (0..1) - в метаданные чанка, чтобы RETR-RERANK/eval
    # могли учесть позже. В колонки индекса не пишется (схема таблицы не меняется).
    "ocr_confidence",
)

_HEADING_RE = re.compile(r"^(#{1,3})\s+(.*)$")
_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
# RETR-CHUNK-1 п.2: строка таблицы — markdown-строка с «|» по краю либо ≥2 ячеек через табуляцию
# (так xlsx/docx/pptx становятся текстом в ``core/legacy/extract/_office.py``); сепаратор
# markdown-таблицы — строка из ``-``/``:``/``|``.
_MD_SEPARATOR_RE = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")


@dataclass
class Chunk:
    """A single retrievable chunk of a note.

    Attributes:
        text: Chunk body text (frontmatter excluded).
        chunk_index: Position of this chunk within the note (0-based).
        heading_path: Chain of headings (H1>H2>H3) leading to the chunk.
        metadata: Note-level metadata (id, type, entity links, status, tags).
        context_prefix: Contextual prefix line already included at the head of ``text``
            (RETR-CHUNK-1 п.1; ``""`` — нет префикса). ``body`` — текст без него.
        messages: For an ``email-thread`` chunk — 1-based ``(first, last)`` message numbers
            covered by it (RETR-CHUNK-1 п.4; the index tail-cap counts messages, not chunks).
    """

    text: str
    chunk_index: int
    heading_path: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    context_prefix: str = ""
    messages: tuple[int, int] | None = None

    @property
    def body(self) -> str:
        """Chunk text without the contextual prefix."""
        return split_context_prefix(self.text)[1]

    @property
    def embed_text(self) -> str:
        """Текст, по которому считается вектор и ключ реюза (``text_hash``): весь ``text``, а в
        режиме ``fts`` — тело без префикса (RETR-CHUNK-1 п.11, вариант «префикс только в FTS»)."""
        return self.body if (self.context_prefix and prefix_mode() == "fts") else self.text

    @property
    def section_id(self) -> str:
        """Key of the parent section (note id + heading path hash; RETR-CHUNK-1 п.5)."""
        return section_id(str(self.metadata.get("id", "")), " > ".join(self.heading_path))


# --- token counting ---------------------------------------------------------

_tiktoken_encoding: Any = None
_tiktoken_tried = False


def _get_tiktoken() -> Any:
    """Lazily load tiktoken's cl100k encoding if available, else None.

    Any failure (package missing, data download blocked) falls back to the
    heuristic — chunking must work offline and deterministically.
    """
    global _tiktoken_encoding, _tiktoken_tried
    if not _tiktoken_tried:
        _tiktoken_tried = True
        try:  # pragma: no cover - depends on optional install
            import tiktoken

            _tiktoken_encoding = tiktoken.get_encoding("cl100k_base")
        except Exception:  # noqa: BLE001 — best-effort; must not break the caller
            _tiktoken_encoding = None
    return _tiktoken_encoding


def count_tokens(text: str) -> int:
    """Estimate the token count of a piece of text.

    Uses tiktoken (cl100k) when available, otherwise the ``words × 1.3``
    heuristic. Both are approximations for chunk sizing only.
    """
    enc = _get_tiktoken()
    if enc is not None:  # pragma: no cover - depends on optional install
        return len(enc.encode(text))
    return math.ceil(len(text.split()) * 1.3)


# --- contextual prefix ---------------------------------------------------------


def prefix_mode() -> str:
    """Режим префикса (``DT_CHUNK_CONTEXT_PREFIX``): ``fts`` (дефолт, вердикт канарейки-2) — префикс
    в ``text`` (лексика), а вектор считается по ТЕЛУ (``embed_text``: ключ реюза VEC-REUSE-1 = хэш
    тела, старые векторы неизменённых чанков переиспользуются); ``1``/``full`` — префикс в ``text``
    и в эмбеддинге (переэмбеддинг всего корпуса); ``0`` — без префикса."""
    raw = os.environ.get(_PREFIX_ENV, "fts").strip().lower()
    if raw in ("0", "false", "no", "off"):
        return "off"
    return "full" if raw in ("1", "full", "true", "yes", "on") else "fts"


def context_prefix_enabled() -> bool:
    """Контекстный префикс включён (по умолчанию да, режим fts;
    ``DT_CHUNK_CONTEXT_PREFIX=0`` — нет)."""
    return prefix_mode() != "off"


# Версия чанкера (RETR-CHUNK-1 п.9): метка в ``index_meta.json``; расхождение с кодом = индекс
# смешанный → ночной инкремент пропускается, пока не пройдёт ``--full``. Базовое число повышают
# при любом изменении нарезки; настройки через env входят в строку (другой режим = другой индекс).
# Индекс без метки — «v0» (чанкер до RETR-CHUNK-1).
CHUNKER_BASE_VERSION = "rc1.2"
LEGACY_CHUNKER_VERSION = "v0"


def chunker_version() -> str:
    """Версия чанкера для метки индекса: база + префикс/карточка/порог слияния из окружения."""
    return (
        f"{CHUNKER_BASE_VERSION}:prefix={prefix_mode()}:card={int(card_enabled())}"
        f":min={min_section_tokens()}"
    )


def _squash(value: Any, limit: int) -> str:
    """Скаляр → одна строка без переводов/табов, обрезанная до ``limit`` символов."""
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ""
    text = " ".join(str(value).split()) if value is not None else ""
    if len(text) > limit:
        text = text[: limit - 1].rstrip() + "…"
    return text


def _note_title(note: Note) -> str:
    """Человеческое имя документа: ``title`` → ``subject`` → имя файла-источника (без папок и
    расширения, ``_`` → пробел: у легаси-файла «КП_Акме_ПГМ.pptx» это единственное имя)."""
    fm = note.frontmatter
    for key in ("title", "subject"):
        if fm.get(key):
            return _squash(fm[key], _PREFIX_TITLE_MAX)
    source = _squash(fm.get("source_path"), 400)
    if source and not source.startswith(("correspondence/", "conv:")):
        base = source.replace("\\", "/").rsplit("/", 1)[-1]
        stem = base.rsplit(".", 1)[0] if "." in base else base
        return _squash(stem.replace("_", " "), _PREFIX_TITLE_MAX)
    return ""


def _note_date(note: Note) -> str:
    """Дата ДОКУМЕНТА для префикса. У файлов легаси-корпуса (``current``/``legacy``, не почта)
    ``created`` — дата ингеста, а не документа: «2026» в префиксе каждого чанка заглушало бы
    лексику (замер канарейки q03) — такую дату не берём. Почтовый тред — ``first_date``."""
    fm = note.frontmatter
    thread = is_email_thread(note)
    if not thread and str(fm.get("corpus") or "vault") in ("current", "legacy"):
        return ""
    keys = ("first_date", "created", "date", "modified") if thread else (
        "created", "date", "first_date", "modified")
    for key in keys:
        if fm.get(key):
            return _squash(fm[key], 40)[:10]
    return ""


def _note_scope(note: Note) -> str:
    """``клиент/проект`` из frontmatter (что есть)."""
    fm = note.frontmatter
    parts = [_squash(fm.get(k), 60) for k in ("client", "project")]
    return "/".join(p for p in parts if p)


def _prefix_line(
    note: Note, heading_path: list[str], *, date: str | None = None, with_path: bool = True
) -> str:
    """Строка префикса для чанка секции ``heading_path`` (``""`` — контекста нет).

    ``{документ} › {путь} · {клиент/проект} · {дата}``: пустые части пропускаются; первый
    элемент пути, повторяющий имя документа (H1 = заголовок), не дублируется. Детерминирована:
    зависит только от frontmatter заметки и пути секции."""
    title = _note_title(note)
    trail = [h for h in (heading_path if with_path else []) if h]
    if trail and title and trail[0].strip().casefold() == title.casefold():
        trail = trail[1:]
    head = " › ".join(p for p in [title, *(_squash(h, _PREFIX_PATH_MAX) for h in trail)] if p)
    head = _squash(head, _PREFIX_PATH_MAX + _PREFIX_TITLE_MAX)
    parts = [head, _note_scope(note), date if date is not None else _note_date(note)]
    line = " · ".join(p for p in parts if p)
    if len(line) > _PREFIX_MAX:
        line = line[: _PREFIX_MAX - 1].rstrip() + "…"
    return f"{PREFIX_OPEN}{line}{PREFIX_CLOSE}" if line else ""


def split_context_prefix(text: str) -> tuple[str, str]:
    """``(prefix, body)`` — отделить контекстный префикс от тела чанка (``prefix == ""`` — его нет).

    Префикс — первая строка вида ``«…»`` (одна строка), за которой идёт пустая строка. Чанк без
    префикса (старый индекс, ``DT_CHUNK_CONTEXT_PREFIX=0``) возвращается как есть."""
    if text.startswith(PREFIX_OPEN):
        line, sep, rest = text.partition(_PREFIX_SEP)
        if sep and "\n" not in line and line.endswith(PREFIX_CLOSE):
            return line, rest
    return "", text


def section_id(note_id: str, heading_path: str) -> str:
    """Стабильный id секции (RETR-CHUNK-1 п.5): sha1 от ``note_id`` и пути заголовков, 12 hex.

    Путь — строка колонки ``heading_path`` (``" > "``-склейка), так что id вычисляется и в
    индексаторе, и по строке индекса без отдельной колонки."""
    raw = f"{note_id}\0{heading_path}".encode()
    return hashlib.sha1(raw, usedforsecurity=False).hexdigest()[:12]


def _with_prefix(prefix: str, body: str) -> str:
    return f"{prefix}{_PREFIX_SEP}{body}" if prefix else body


def _body_budget(prefix: str) -> int:
    """Бюджет токенов тела чанка при префиксе: общий максимум минус префикс и разделитель."""
    if not prefix or prefix_mode() == "fts":
        # режим fts: вектор по телу, префикс только в тексте для лексики — бюджет тела полный
        # (границы чанков = как без префикса, поэтому тексты неизменённых чанков совпадают со
        # старыми и их векторы переиспользуются)
        return TARGET_MAX_TOKENS
    return max(TARGET_MAX_TOKENS // 2, TARGET_MAX_TOKENS - count_tokens(prefix) - 2)


# --- blocks and units ---------------------------------------------------------


@dataclass
class _Block:
    """Неделимый кусок секции: абзац, таблица или блок кода (RETR-CHUNK-1 п.2).

    ``head``/``rows`` заполнены только у таблицы: ``head`` — шапка (1 строка либо
    «строка + сепаратор» markdown), ``rows`` — остальные строки; ``text`` — целиком.
    """

    text: str
    kind: str = "para"  # para | table | code
    head: str = ""
    rows: tuple[str, ...] = ()


@dataclass
class _Unit:
    """Единица упаковки: текст + оценка токенов + вид (``table-part`` — кусок длинной таблицы)."""

    text: str
    tokens: int
    kind: str = "para"  # para | table | table-part | code


def _is_table_row(line: str) -> str:
    """``"md"`` / ``"tsv"`` / ``""`` — вид табличной строки."""
    stripped = line.strip()
    if not stripped:
        return ""
    if "|" in stripped and (stripped.startswith("|") or stripped.endswith("|")):
        return "md"
    if "\t" in stripped and any(c.strip() for c in stripped.split("\t")[1:]):
        return "tsv"
    return ""


def _make_table(lines: list[str], kind: str) -> _Block:
    head_n = 2 if kind == "md" and len(lines) > 2 and _MD_SEPARATOR_RE.match(lines[1]) else 1
    return _Block(
        text="\n".join(lines),
        kind="table",
        head="\n".join(lines[:head_n]),
        rows=tuple(lines[head_n:]),
    )


def _classify(paragraph: str) -> list[_Block]:
    """Абзац (блок строк без пустых) → блоки: серии ≥2 табличных строк — таблица, прочее — текст.

    Битая таблица (нет сепаратора, рваные ячейки) — всё равно таблица, если строк ≥2: целостность
    важнее формальной валидности. Одиночная строка с «|» остаётся текстом."""
    lines = paragraph.split("\n")
    blocks: list[_Block] = []
    text_buf: list[str] = []
    i, n = 0, len(lines)

    def flush_text() -> None:
        if text_buf:
            blocks.append(_Block("\n".join(text_buf)))
            text_buf.clear()

    while i < n:
        kind = _is_table_row(lines[i])
        if kind:
            j = i
            while j < n and _is_table_row(lines[j]) == kind:
                j += 1
            if j - i >= 2:
                flush_text()
                blocks.append(_make_table(lines[i:j], kind))
                i = j
                continue
        text_buf.append(lines[i])
        i += 1
    flush_text()
    return blocks


# --- parsing ----------------------------------------------------------------


def _build_metadata(note: Note) -> dict[str, Any]:
    """Collect note-level metadata for chunks (entity links, status, tags)."""
    metadata: dict[str, Any] = {
        key: note.frontmatter[key] for key in _METADATA_FIELDS if key in note.frontmatter
    }
    # Ensure id/type are always present even if absent from frontmatter.
    metadata["id"] = note.id
    if note.type is not None:
        metadata["type"] = note.type
    return metadata


def _parse_sections(body: str) -> list[tuple[list[str], list[_Block]]]:
    """Parse a markdown body into ``(heading_path, blocks)`` sections.

    Blocks are blank-line separated paragraphs, split further into tables (markdown or
    tab-separated, RETR-CHUNK-1 п.2) and code fences. Headings update the active path;
    code fences (```) are one indivisible block — blank lines inside stay, and their
    ``#`` lines are not headings. An unclosed fence runs to the end of the body.
    """
    sections: list[tuple[list[str], list[_Block]]] = []
    stack: list[tuple[int, str]] = []  # (level, title)
    path: list[str] = []
    paras: list[_Block] = []
    buf: list[str] = []
    in_fence = False

    def flush_buf() -> None:
        if buf:
            paras.extend(_classify("\n".join(buf)))
            buf.clear()

    def flush_code() -> None:
        if buf:
            paras.append(_Block("\n".join(buf), kind="code"))
            buf.clear()

    def flush_section() -> None:
        flush_buf()
        if paras:
            sections.append((list(path), list(paras)))
            paras.clear()

    for line in body.splitlines():
        stripped = line.strip()

        if in_fence:
            buf.append(line)
            if stripped.startswith("```"):
                in_fence = False
                flush_code()
            continue

        if stripped.startswith("```") and not (len(stripped) > 3 and stripped.endswith("```")):
            flush_buf()
            in_fence = True
            buf.append(line)
            continue

        match = _HEADING_RE.match(line)
        if match:
            # Paragraphs gathered so far belong to the *previous* path.
            flush_section()
            level = len(match.group(1))
            title = match.group(2).strip()
            while stack and stack[-1][0] >= level:
                stack.pop()
            stack.append((level, title))
            path = [title for _, title in stack]
            continue

        if stripped == "":
            flush_buf()
        else:
            buf.append(line)

    if in_fence:
        flush_code()
    flush_section()
    return sections


def min_section_tokens() -> int:
    """Порог мелкой секции (:data:`MIN_SECTION_TOKENS`; env ``DT_CHUNK_MIN_SECTION_TOKENS``)."""
    raw = os.environ.get(_MIN_SECTION_ENV, "").strip()
    if raw.isdigit():
        return int(raw)
    return MIN_SECTION_TOKENS


def _is_footer(path: list[str]) -> bool:
    return bool(path) and path[-1].strip().casefold() in _FOOTER_TITLES


def _related(a: list[str], b: list[str]) -> bool:
    """Секции в пределах одного родителя: соседи (общий родитель) или предок-потомок.

    ``[]`` (преамбула/титульная часть до первого заголовка) — предок всех."""
    if a[:-1] == b[:-1]:
        return True
    shorter, longer = (a, b) if len(a) <= len(b) else (b, a)
    return longer[: len(shorter)] == shorter


def _heading_line(path: list[str], host: list[str]) -> list[_Block]:
    """Заголовок поглощённой секции как строка текста (иначе он пропал бы: в чанке
    заголовки живут в ``heading_path`` хозяина). Если он уже в пути хозяина — не нужен."""
    if not path or path[-1] in host:
        return []
    return [_Block(path[-1])]


def _merge_small_sections(
    sections: list[tuple[list[str], list[_Block]]], min_tokens: int
) -> list[tuple[list[str], list[_Block]]]:
    """Слить секции короче ``min_tokens`` с соседней в пределах родителя (п.3).

    Сначала вперёд (следующая секция — «хозяин»: титульная страница, вступление перед
    подразделом), затем назад (последняя мелкая секция родителя). Цепочки мелких секций
    сворачиваются слева направо. Секция без подходящего соседа (единственная в документе)
    остаётся как есть. Путь хозяина сохраняется; заголовок поглощённой секции
    добавляется строкой текста. Футер ``Связано`` не сливается ни в одну сторону.
    """
    if min_tokens <= 0 or len(sections) < 2:
        return sections
    todo = [(list(path), list(paras)) for path, paras in sections]
    out: list[tuple[list[str], list[_Block]]] = []
    for i in range(len(todo)):
        path, paras = todo[i]
        small = (
            not _is_footer(path)
            and sum(count_tokens(b.text) for b in paras) < min_tokens
        )
        if not small:
            out.append((path, paras))
            continue
        nxt = todo[i + 1] if i + 1 < len(todo) else None
        if nxt is not None and not _is_footer(nxt[0]) and _related(path, nxt[0]):
            todo[i + 1] = (nxt[0], _heading_line(path, nxt[0]) + paras + nxt[1])
            continue
        if out and not _is_footer(out[-1][0]) and _related(out[-1][0], path):
            host_path, host_paras = out[-1]
            out[-1] = (host_path, host_paras + _heading_line(path, host_path) + paras)
            continue
        out.append((path, paras))
    return out


def _split_words(words: list[str], budget: int) -> list[str]:
    """Слова → куски ≤ ``budget`` токенов. Шаг берётся по средней «токенности» слова строки
    (эвристика и tiktoken считают по-разному), а перебравший кусок делится пополам."""
    if not words:
        return []
    text = " ".join(words)
    if count_tokens(text) <= budget:
        return [text]
    if len(words) == 1:  # одно «слово» (base64, склейка без пробелов) — режем по символам
        half = max(1, len(text) // 2)
        if half == len(text):
            return [text]
        return _split_words([text[:half]], budget) + _split_words([text[half:]], budget)
    per_word = count_tokens(text) / len(words)
    step = max(1, min(len(words) - 1, int(budget / per_word * 0.9)))
    out: list[str] = []
    for k in range(0, len(words), step):
        out.extend(_split_words(words[k : k + step], budget))
    return out


def _hard_split(text: str, budget: int) -> list[str]:
    """Нарезать текст, у которого нет естественных границ (нет «.», пустых строк), по строкам,
    а строку длиннее бюджета — по словам. Каждый кусок ≤ ``budget`` (оценка токенов)."""
    pieces: list[str] = []
    cur: list[str] = []
    cur_tokens = 0
    for line in text.split("\n"):
        t = count_tokens(line)
        if t > budget:
            if cur:
                pieces.append("\n".join(cur))
                cur, cur_tokens = [], 0
            pieces.extend(_split_words(line.split(), budget))
            continue
        if cur and cur_tokens + t > budget:
            pieces.append("\n".join(cur))
            cur, cur_tokens = [], 0
        cur.append(line)
        cur_tokens += t
    if cur:
        pieces.append("\n".join(cur))
    return [q for p in pieces if p.strip() for q in _fit_lines(p, budget)]


def _fit_lines(piece: str, budget: int) -> list[str]:
    """Кусок из строк, склеенный по факту больше ``budget`` (сумма оценок строк аддитивна
    приближённо), делится пополам по строкам, пока каждая половина не влезет."""
    lines = piece.split("\n")
    if len(lines) < 2 or count_tokens(piece) <= budget:
        return [piece]
    mid = len(lines) // 2
    return _fit_lines("\n".join(lines[:mid]), budget) + _fit_lines("\n".join(lines[mid:]), budget)


def _table_units(block: _Block, budget: int) -> list[_Unit]:
    """Таблица → одна неделимая единица, а если не влезает в бюджет — куски по строкам,
    в каждом шапка (если она не съедает бюджет): строки без шапки теряют смысл колонок."""
    whole = count_tokens(block.text)
    if whole <= budget:
        return [_Unit(block.text, whole, "table")]
    head_tokens = count_tokens(block.head)
    repeat = head_tokens <= budget // 3
    head = block.head if repeat else ""
    room = budget - (head_tokens if repeat else 0)
    units: list[_Unit] = []

    def emit(rows: list[str]) -> None:
        """Кусок = шапка + строки. Оценка по строкам аддитивна лишь приближённо (переводы строк,
        склейка токенов), поэтому итог сверяется по факту и перебравший кусок делится пополам."""
        if not rows:
            return
        text = "\n".join(([head] if head else []) + rows)
        tokens = count_tokens(text)
        if tokens > budget and len(rows) > 1:
            mid = len(rows) // 2
            emit(rows[:mid])
            emit(rows[mid:])
            return
        units.append(_Unit(text, tokens, "table-part"))

    rows = list(block.rows) if block.rows else [block.head]
    if not block.rows:  # шапка без строк, но не влезла (гигантская строка) — режем её саму
        head, room = "", budget
    cur: list[str] = []
    cur_tokens = 0
    for row in rows:
        t = count_tokens(row) + 1  # +1: перевод строки
        if t > room:  # строка длиннее куска — режем по словам, шапку повторяем у каждой части
            emit(cur)
            cur, cur_tokens = [], 0
            for part in _hard_split(row, max(1, room - 1)):
                emit([part])
            continue
        if cur and cur_tokens + t > room:
            emit(cur)
            cur, cur_tokens = [], 0
        cur.append(row)
        cur_tokens += t
    emit(cur)
    return units


def _to_units(blocks: list[_Block], budget: int = TARGET_MAX_TOKENS) -> list[_Unit]:
    """Блоки секции → единицы упаковки.

    Абзац длиннее бюджета режется по предложениям, а то, что и после этого не влезло (нет
    пунктуации) — по строкам/словам (:func:`_hard_split`). Таблица — неделимая единица, длинная
    режется по строкам с шапкой (:func:`_table_units`). Блок кода неделим; слишком длинный
    режется по строкам."""
    units: list[_Unit] = []
    for block in blocks:
        tokens = count_tokens(block.text)
        if block.kind == "table":
            units.extend(_table_units(block, budget))
        elif tokens <= budget:
            units.append(_Unit(block.text, tokens, block.kind))
        elif block.kind == "code":
            units.extend(_Unit(p, count_tokens(p), "code") for p in _hard_split(block.text, budget))
        else:
            for sentence in _SENTENCE_SPLIT_RE.split(block.text):
                if not sentence.strip():
                    continue
                t = count_tokens(sentence)
                if t <= budget:
                    units.append(_Unit(sentence, t))
                else:
                    units.extend(_Unit(p, count_tokens(p)) for p in _hard_split(sentence, budget))
    return units


def _pack(units: list[_Unit], budget: int = TARGET_MAX_TOKENS) -> list[list[_Unit]]:
    """Pack units into chunks ≤ ``budget`` with ~OVERLAP trailing-unit overlap.

    Куски длинной таблицы (``table-part``) в перекрытие не берутся: шапка в каждом уже
    даёт контекст, а повтор строк только раздул бы чанк."""
    chunks: list[list[_Unit]] = []
    start = 0
    n = len(units)
    while start < n:
        end = start
        tokens = 0
        while end < n and (end == start or tokens + units[end].tokens + 1 <= budget):
            tokens += units[end].tokens + 1  # +1: разделитель «\n\n» между единицами
            end += 1
        # Оценка единиц аддитивна лишь приближённо (токенизатор склеивает/разделяет по границам):
        # сверяем с фактом и снимаем хвостовые единицы, пока склейка не влезла в бюджет.
        while end > start + 1 and (
            count_tokens(_JOIN.join(u.text for u in units[start:end])) > budget
        ):
            end -= 1
        chunks.append(units[start:end])
        if end >= n:
            break
        # Overlap: back up from `end` until ~OVERLAP_TOKENS of trailing units
        # are reincluded; never below start+1 so progress is guaranteed.
        overlap = 0
        next_start = end
        while next_start > start + 1 and overlap < OVERLAP_TOKENS:
            if units[next_start - 1].kind == "table-part":
                break
            next_start -= 1
            overlap += units[next_start].tokens
        start = next_start
    return chunks


def _block_kind(units: list[_Unit]) -> str:
    """``table`` / ``code`` / ``text`` — чем в основном (>50% токенов) является чанк."""
    total = sum(u.tokens for u in units) or 1
    table = sum(u.tokens for u in units if u.kind in ("table", "table-part"))
    code = sum(u.tokens for u in units if u.kind == "code")
    if table * 2 > total:
        return "table"
    if code * 2 > total:
        return "code"
    return "text"


# --- email-thread: the unit is a message (п.4) -----------------------------------

_EMAIL_THREAD = "email-thread"
_HEADER_MAX_TOKENS = 150  # шапка сообщения длиннее — в продолжениях только «дата — от»


def is_email_thread(note: Note) -> bool:
    """Заметка — почтовый тред (``source_type``/``type`` = ``email-thread``)."""
    fm = note.frontmatter
    return _EMAIL_THREAD in (str(fm.get("source_type") or ""), str(fm.get("type") or ""))


_PREAMBLE_LINE_MAX = 300  # символов в строке преамбулы (список участников бывает на сотни адресов)
_PREAMBLE_MAX_TOKENS = TARGET_MAX_TOKENS // 4


def _trim_preamble(preamble: str) -> str:
    """Преамбула треда (``Источник/Тред/Участники/Сообщений``) для первого чанка: длинные строки
    обрезаны, а целиком не влезающая в четверть бюджета — урезана с хвоста. Полный список
    участников остаётся в frontmatter заметки."""
    lines = []
    for line in preamble.strip().split("\n"):
        if len(line) > _PREAMBLE_LINE_MAX:
            line = line[: _PREAMBLE_LINE_MAX - 1].rstrip() + "…"
        lines.append(line)
    while len(lines) > 1 and count_tokens("\n".join(lines)) > _PREAMBLE_MAX_TOKENS:
        lines.pop()
    return "\n".join(lines).strip()


def _chunk_thread(note: Note, metadata: dict[str, Any], use_prefix: bool) -> list[Chunk] | None:
    """Чанки почтового треда: границы — сообщения (RETR-CHUNK-1 п.4).

    Единица нарезки — сообщение целиком (заголовок ``## дата — от → кому`` + тело). Подряд идущие
    сообщения упаковываются в чанк, пока влезают в бюджет; сообщение не режется, пока оно
    само не больше бюджета. Длинное сообщение режется внутри себя, а каждый кусок начинается с
    его заголовка. Префикс — тема треда и дата первого сообщения чанка (путь заголовков не нужен:
    отправитель/получатели — в тексте). Преамбула (``Источник/Тред/Участники``) идёт в первый
    чанк, футер ``## Связано`` — отдельным чанком (граница стабильна при правках линковщика).
    ``None`` — в теле нет заголовков сообщений (читатель падает на обычный путь).
    """
    # лениво: пакет core.retrieval сам импортирует chunking (цикл при импорте наверху)
    from core.retrieval.mail_read import parse_thread

    parsed = parse_thread(note.body.strip())
    if parsed is None or not parsed.messages:
        return None
    msgs = parsed.messages
    preamble = _trim_preamble(parsed.preamble)

    def prefix_for(i: int) -> str:
        if not use_prefix:
            return ""
        return _prefix_line(note, [], date=(msgs[i].date or "")[:10] or None, with_path=False)

    texts = []
    for m in msgs:
        texts.append(f"{m.header}\n{m.text}" if m.text else m.header)
    if preamble:
        texts[0] = f"{preamble}\n\n{texts[0]}"
    tokens = [count_tokens(t) for t in texts]
    meta = dict(metadata, block="text")
    chunks: list[Chunk] = []

    def add(text: str, i: int, last: int, prefix: str, kind: str = "text") -> None:
        chunks.append(
            Chunk(
                text=_with_prefix(prefix, text),
                chunk_index=len(chunks),
                heading_path=[msgs[i].header.lstrip("#").strip()],
                metadata=dict(meta, block=kind),
                context_prefix=prefix,
                messages=(i + 1, last + 1),
            )
        )

    i, n = 0, len(msgs)
    while i < n:
        prefix = prefix_for(i)
        budget = _body_budget(prefix)
        if tokens[i] > budget:
            # длинное сообщение: куски с заголовком сообщения в начале каждого
            head = msgs[i].header
            if count_tokens(head) > _HEADER_MAX_TOKENS:
                head = f"## {msgs[i].date} — {msgs[i].sender}".rstrip()
            lead = preamble if i == 0 else ""
            room = max(
                TARGET_MAX_TOKENS // 4,
                budget - count_tokens(head) - (count_tokens(lead) + 2 if lead else 0) - 2,
            )
            blocks = [b for para in re.split(r"\n\s*\n", msgs[i].text) if para.strip()
                      for b in _classify(para)]
            pieces = _pack(_to_units(blocks, room), room) or [[]]
            for k, piece in enumerate(pieces):
                body = "\n\n".join(u.text for u in piece)
                text = f"{head}\n{body}" if body else head
                if k == 0 and lead:
                    text = f"{lead}\n\n{text}"
                add(text, i, i, prefix, _block_kind(piece) if piece else "text")
            i += 1
            continue
        j, acc = i, tokens[i]
        while j + 1 < n and acc + tokens[j + 1] + 1 <= budget:
            j += 1
            acc += tokens[j] + 1
        while j > i and count_tokens(_JOIN.join(texts[i : j + 1])) > budget:
            j -= 1  # оценка аддитивна приближённо — сверяем с фактом
        add(_JOIN.join(texts[i : j + 1]), i, j, prefix)
        i = j + 1

    footer_body = parsed.footer.split("\n", 1)[1].strip() if "\n" in parsed.footer else ""
    if footer_body:
        prefix = ""  # как в обычных заметках: футер связей — без контекстного префикса
        chunks.append(
            Chunk(
                text=_with_prefix(prefix, footer_body),
                chunk_index=len(chunks),
                heading_path=["Связано"],
                metadata=dict(meta),
                context_prefix=prefix,
            )
        )
    return chunks


# --- document card (RETR-CHUNK-1 п.8) ---------------------------------------------

_CARD_ENV = "DT_CHUNK_CARD"
CARD_MAX_TOKENS = 80
CARD_HEADING = "Карточка документа"
_CARD_HEADINGS_MAX = 6


def card_enabled() -> bool:
    """Карточка документа включена (по умолчанию да; ``DT_CHUNK_CARD=0`` — нет)."""
    return os.environ.get(_CARD_ENV, "1").strip().lower() not in ("0", "false", "no", "off")


def _is_document(note: Note) -> bool:
    """Заметка-документ: файл легаси-корпуса (``current``/``legacy``, не почта) или выход."""
    fm = note.frontmatter
    if is_email_thread(note):
        return False
    return str(fm.get("corpus") or "vault") in ("current", "legacy") or (
        str(fm.get("type") or "") == "output"
    )


def _document_card(
    note: Note, metadata: dict[str, Any], sections: list[tuple[list[str], list[_Block]]]
) -> Chunk | None:
    """Карточка документа: ОДИН короткий чанк (≤ :data:`CARD_MAX_TOKENS`) — название, имя файла,
    клиент/проект, дата документа, разделы верхнего уровня. Это осознанная «титульная страница»
    (вместо случайного обрывка-преамбулы, который до п.3 выигрывал BM25 по имени файла): запрос
    по имени документа детерминированно находит её, а не длинный чанк с таблицей.

    Только у документов, нарезанных на ≥2 чанка (однокусочный документ несёт то же самое в
    префиксе). Без префикса — карточка сама и есть контекст. Детерминирована."""
    if not card_enabled() or not _is_document(note):
        return None
    fm = note.frontmatter
    lines: list[str] = []
    explicit = " ".join(str(fm.get("title") or fm.get("subject") or "").split())
    if explicit:
        lines.append(_squash(explicit, _PREFIX_TITLE_MAX))
    source = _squash(fm.get("source_path"), 400).replace("\\", "/")
    base = source.rsplit("/", 1)[-1] if source else ""
    if base and not source.startswith(("correspondence/", "conv:")):
        lines.append(f"Файл: {base}")
    elif not explicit:
        title = _note_title(note)
        if title:
            lines.append(title)
    scope = [
        f"{label}: {_squash(fm.get(key), 60)}"
        for key, label in (("client", "Клиент"), ("project", "Проект"))
        if fm.get(key)
    ]
    if scope:
        lines.append("; ".join(scope))
    date = _note_date(note)
    if date:
        lines.append(f"Дата: {date}")
    tops: list[str] = []
    for path, _ in sections:
        if path and path[0] not in tops:
            tops.append(path[0])
    if not lines and not tops:
        return None
    shown = [_squash(t, 50) for t in tops[:_CARD_HEADINGS_MAX]]
    while True:
        extra = f" … (всего {len(tops)})" if len(tops) > len(shown) else ""
        head = [f"Разделы: {'; '.join(shown)}{extra}"] if shown else []
        text = "\n".join([*lines, *head])
        if count_tokens(text) <= CARD_MAX_TOKENS or not shown:
            break
        shown.pop()
    if count_tokens(text) > CARD_MAX_TOKENS:  # шапка сама велика — режем по словам
        text = _split_words(text.split(), CARD_MAX_TOKENS)[0]
    return Chunk(
        text=text,
        chunk_index=0,
        heading_path=[CARD_HEADING],
        metadata=dict(metadata, block="card"),
    )


def chunk_note(note: Note) -> list[Chunk]:
    """Chunk a note into a list of :class:`Chunk` (architecture §5).

    Small notes (≤ TARGET_MAX tokens) yield a single chunk. Larger notes are
    chunked per heading-section (мелкие секции слиты с соседней, п.3), packed to the
    token target with overlap; таблицы — неделимые единицы (п.2). Каждый чанк несёт
    контекстный префикс (п.1), а бюджет токенов считается вместе с ним.
    """
    metadata = _build_metadata(note)
    body = note.body.strip()
    if not body:
        return []
    use_prefix = context_prefix_enabled()

    if is_email_thread(note):
        thread = _chunk_thread(note, metadata, use_prefix)
        if thread is not None:
            return thread

    sections = _parse_sections(body)
    top = _prefix_line(note, []) if use_prefix else ""
    if count_tokens(body if prefix_mode() == "fts" else _with_prefix(top, body)) <= (
        TARGET_MAX_TOKENS
    ):
        kind = _block_kind(
            [u for _, blocks in sections for u in _to_units(blocks, 10**9)]
        )
        return [
            Chunk(
                text=_with_prefix(top, body),
                chunk_index=0,
                heading_path=[],
                metadata=dict(metadata, block=kind),
                context_prefix=top,
            )
        ]

    chunks: list[Chunk] = []
    index = 0
    for path, blocks in _merge_small_sections(sections, min_section_tokens()):
        # футер «Связано» — машинный список связей, не содержание: без префикса (иначе короткий
        # чанк «имя документа + ссылки» выигрывал бы BM25 у содержательных, замер канарейки)
        prefix = _prefix_line(note, path) if use_prefix and not _is_footer(path) else ""
        budget = _body_budget(prefix)
        for piece in _pack(_to_units(blocks, budget), budget):
            chunks.append(
                Chunk(
                    text=_with_prefix(prefix, "\n\n".join(u.text for u in piece)),
                    chunk_index=index,
                    heading_path=path,
                    metadata=dict(metadata, block=_block_kind(piece)),
                    context_prefix=prefix,
                )
            )
            index += 1
    card = _document_card(note, metadata, sections)
    if card is not None:
        chunks.insert(0, card)
        for i, c in enumerate(chunks):
            c.chunk_index = i
    return chunks
