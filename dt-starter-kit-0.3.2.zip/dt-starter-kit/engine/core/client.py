"""Клиент без vault (CONFIG-1 п.6): машина ходит на демон-сервер по Tailscale, своего движка нет.

``DT_MODE=client`` + ``DT_SERVER_URL`` в ``.env`` клиента, токен выдан на сервере
(``dt web-token show rw``) и лежит в ``.secrets/web_token_rw`` рядом с клиентским engine. Здесь:

* :func:`server_base` - адрес сервера из ``dns | ip | host:порт | http://…`` (порт 8787);
* :func:`join` - ``dt client join``: проверить ``/health`` и принятие токена, положить токен-файл
  (600), записать ``DT_MODE``/``DT_SERVER_URL`` через ``env_file``; ничего не пишется, пока сервер
  не ответил и не принял токен;
* :func:`client_diagnostics` - короткий ``dt doctor`` клиента: сервер отвечает, версия кода сервера,
  токены, мост/конфиги хостов; без проверок vault/индекса.

Значение токена нигде не печатается (только хвост 4 символа). ``core`` не зависит от MCP/CLI;
сетевые вызовы инъектируются (тесты - фейковый сервер).
"""

from __future__ import annotations

import ipaddress
import json
import os
import urllib.error
import urllib.request
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

__all__ = [
    "DEFAULT_PORT",
    "JoinError",
    "JoinResult",
    "SERVER_URL_ENV",
    "client_diagnostics",
    "configured_server",
    "is_client",
    "join",
    "probe_health",
    "probe_token",
    "server_base",
]

SERVER_URL_ENV = "DT_SERVER_URL"
DEFAULT_PORT = 8787
_TIMEOUT = 5.0


class JoinError(Exception):
    """Отказ ``dt client join`` с машинным кодом (``bad_server``, ``no_health``, …)."""

    def __init__(self, code: str, reason: str) -> None:
        super().__init__(f"{code}: {reason}")
        self.code, self.reason = code, reason


def _bracket(host: str) -> str:
    return f"[{host}]" if ":" in host and not host.startswith("[") else host


def server_base(server: str, port: int | None = None) -> str:
    """``dns`` | ``ip`` | ``host:порт`` | ``http://host[:порт]`` → ``http://host:порт``, без пути.

    Порт по умолчанию - ``port`` либо 8787. Схема только http (трафик шифрует Tailscale; HTTPS/OAuth
    для ``/mcp`` вне объёма). Пустое/мусорное - :class:`JoinError` ``bad_server``."""
    raw = (server or "").strip()
    if not raw:
        raise JoinError("bad_server", "адрес сервера пуст (dns-имя или IP машины в Tailscale)")
    if "://" not in raw:
        try:  # голый IPv6 (fd7a:…) - в скобки, иначе двоеточия читаются как порт
            if isinstance(ipaddress.ip_address(raw), ipaddress.IPv6Address):
                raw = f"[{raw}]"
        except ValueError:
            pass
        raw = "http://" + raw
    u = urlparse(raw)
    if u.scheme != "http" or not u.hostname:
        raise JoinError("bad_server", f"адрес сервера: нужен http://<dns|ip>[:порт], не {server!r}")
    try:
        chosen = u.port or port or DEFAULT_PORT
    except ValueError as exc:
        raise JoinError("bad_server", "порт сервера не число") from exc
    return f"http://{_bracket(u.hostname)}:{chosen}"


def server_host(base: str) -> str:
    """Хост из ``server_base`` (без скобок IPv6)."""
    return urlparse(base).hostname or ""


def is_loopback_host(host: str) -> bool:
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def configured_server(env_path: Path | None = None) -> str | None:
    """``DT_SERVER_URL``: окружение процесса, затем ``.env`` (только чтение); нет - ``None``."""
    value = (os.environ.get(SERVER_URL_ENV) or "").strip()
    if value:
        return value
    from core.config import engine_env_path
    from core.config import env_file as ef

    value = (ef.read_value(env_path or engine_env_path(), SERVER_URL_ENV) or "").strip()
    return value or None


def is_client(env_path: Path | None = None) -> bool:
    """Машина в режиме ``client`` (``DT_MODE`` из окружения или ``.env``)."""
    raw = (os.environ.get("DT_MODE") or "").strip().lower()
    if not raw:
        from core.config import engine_env_path
        from core.config import env_file as ef

        raw = (ef.read_value(env_path or engine_env_path(), "DT_MODE") or "").strip().lower()
    return raw == "client"


# --------------------------------------------------------------------------- #
# сеть (инъектируется в тестах)                                                #
# --------------------------------------------------------------------------- #
def probe_health(base: str, *, timeout: float = _TIMEOUT) -> dict[str, Any] | None:
    """``GET <base>/health`` → тело (dict с ``version``) либо ``None`` (не ответил / не наш)."""
    try:
        with urllib.request.urlopen(f"{base}/health", timeout=timeout) as resp:  # noqa: S310
            data = json.loads(resp.read().decode("utf-8"))
    except (OSError, ValueError, urllib.error.URLError):
        return None
    return data if isinstance(data, dict) and "version" in data else None


def probe_token(base: str, token: str, *, profile: str = "lean",
                timeout: float = _TIMEOUT) -> int | None:
    """HTTP-статус ``GET <base>/mcp/<профиль>`` с Bearer-токеном: ``401`` - токен не принят,
    ``403`` - сервер не пускает этого клиента (не ``DT_MODE=server`` / не Tailscale-peer / прокси),
    прочее (400/405/406 и т.п.) - токен принят, протокол не проверяем. ``None`` - сеть молчит."""
    req = urllib.request.Request(  # noqa: S310
        f"{base}/mcp/{profile}", headers={"Authorization": f"Bearer {token}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
            return int(resp.status)
    except urllib.error.HTTPError as exc:
        return int(exc.code)
    except (OSError, urllib.error.URLError):
        return None


@dataclass(frozen=True)
class JoinResult:
    base: str
    token_path: Path
    token_tail: str
    code: str  # версия кода сервера
    mode: str  # режим сервера по /health (server | local | ?)
    env_changed: tuple[str, ...]  # какие ключи .env реально изменились


def join(
    server: str,
    token: str,
    *,
    which: str = "rw",
    env_path: Path | None = None,
    directory: Path | None = None,
    health: Callable[[str], dict[str, Any] | None] | None = None,
    token_status: Callable[[str, str], int | None] | None = None,
    port: int | None = None,
) -> JoinResult:
    """``dt client join``: проверить сервер, положить токен-файл, записать режим клиента в ``.env``.

    Порядок: адрес → ``/health`` отвечает → токен принят (не 401/403) → токен-файл (600) →
    ``DT_MODE=client`` и ``DT_SERVER_URL=<адрес>`` через ``env_file``. До успешной проверки
    ничего не пишется. ``health``/``token_status`` - инъекции (по умолчанию живая сеть)."""
    from core.config import engine_env_path
    from core.config import env_file as ef
    from core.web_tokens import store_token, tail

    value = (token or "").strip()
    if not value:
        raise JoinError("no_token", "ключ пуст: на сервере `dt web-token show rw`")
    base = server_base(server, port)
    info = (health or probe_health)(base)
    if info is None:
        raise JoinError(
            "no_health", f"сервер не отвечает на {base}/health: демон запущен? Tailscale "
            "подключен? (bind 0.0.0.0, /health пускает loopback и Tailscale)")
    status = (token_status or probe_token)(base, value)
    if status == 401:
        raise JoinError("token_rejected", "сервер не принял токен (401): выдан на сервере "
                                          f"`dt web-token show {which}`? не перевыпущен ли?")
    if status == 403:
        raise JoinError(
            "peer_forbidden", "сервер не пускает этот клиент на /mcp (403): на сервере нужен "
            "DT_MODE=server и Tailscale-адрес; через funnel/прокси /mcp закрыт всегда")
    if status is None:
        raise JoinError("no_health", f"сервер ответил на /health, но /mcp не отвечает ({base})")
    path = store_token(which, value, directory)
    target = Path(env_path) if env_path is not None else engine_env_path()
    changed = []
    for key, val in (("DT_MODE", "client"), ("DT_SERVER_URL", base)):
        if ef.set_key(target, key, val).changed:
            changed.append(key)
    version = info.get("version") or {}
    return JoinResult(
        base=base, token_path=path, token_tail=tail(value),
        code=str(version.get("code") or "unknown"), mode=str(info.get("mode") or "?"),
        env_changed=tuple(changed),
    )


# --------------------------------------------------------------------------- #
# dt doctor в режиме client                                                    #
# --------------------------------------------------------------------------- #
def client_diagnostics(
    *,
    health: Callable[[str], dict[str, Any] | None] | None = None,
    env_path: Path | None = None,
    directory: Path | None = None,
    hosts: Callable[[], list[dict[str, Any]]] | None = None,
) -> list[Any]:
    """Короткий набор доктора клиента: режим/адрес, сервер отвечает, версия кода сервера, токены,
    мост/конфиги хостов, конфиг. БЕЗ vault и индекса (их на клиенте нет)."""
    from core.diagnostics import Check, _config_check

    out: list[Any] = []
    server = configured_server(env_path)
    if not server:
        out.append(Check("Клиент: сервер", "warn", "режим client, но DT_SERVER_URL не задан",
                         "dt client join --server <dns|ip>"))
        base = None
    else:
        try:
            base = server_base(server)
        except JoinError as exc:
            out.append(Check("Клиент: сервер", "warn", f"DT_SERVER_URL не разобран: {exc.reason}",
                             "dt client join --server <dns|ip>"))
            base = None
    if base is not None:
        info = (health or probe_health)(base)
        if info is None:
            out.append(Check("Клиент: сервер", "warn", f"{base} не отвечает на /health",
                             "демон на сервере запущен? Tailscale подключен? "
                             "(на сервере: dt doctor, launchctl kickstart -k …/com.dt.server)"))
        else:
            v = info.get("version") or {}
            up = int(v.get("uptime_s") or 0)
            out.append(Check("Клиент: сервер", "ok",
                             f"{base} отвечает · режим {info.get('mode', '?')} · код "
                             f"{v.get('code', 'unknown')} · uptime "
                             f"{up // 3600} ч {up % 3600 // 60} мин"))
            if info.get("mode") != "server":
                out.append(Check(
                    "Клиент: режим сервера", "warn",
                    f"сервер сообщает режим {info.get('mode', '?')}, а не server",
                    "на сервере DT_MODE=server (dt config set DT_MODE server) и перезапуск демона"))
    # токены: клиенту нужен rw (или read) токен-файл с правами 600
    from core.web_tokens import inspect_tokens

    toks = inspect_tokens(directory)
    have = [t for t in toks.values() if t.configured]
    if not have:
        out.append(Check("Клиент: токены", "warn", "токен-файла нет",
                         "на сервере `dt web-token show rw`, затем dt client join --server …"))
    else:
        bad = [f"{t.name} ({t.mode})" for t in have if t.source == "file" and not t.mode_ok]
        out.append(Check("Клиент: токены", "warn" if bad else "ok",
                         ("права шире 600: " + ", ".join(bad)) if bad
                         else "токен-файл: " + ", ".join(f"{t.name} ({t.source})" for t in have),
                         "chmod 600 .secrets/web_token*" if bad else ""))
    # мост / конфиги хостов
    rows = (hosts or _verify_hosts)()
    daemon = [r for r in rows if r.get("verdict") == "daemon"]
    legacy = [r for r in rows if r.get("verdict") == "stdio-legacy"]
    if legacy:
        out.append(Check("Клиент: хосты", "warn",
                         "старая stdio-команда у: " + ", ".join(r["host"] for r in legacy),
                         "dt host-config <host> --server <dns|ip> --install"))
    elif daemon:
        out.append(Check("Клиент: хосты", "ok", "на сервере: " + ", ".join(
            f"{r['host']} ({r.get('form') or '?'})" for r in daemon)))
    else:
        out.append(Check("Клиент: хосты", "warn", "ни один хост не подключен к серверу",
                         "dt host-config claude --server <dns|ip> --install"))
    out.append(_config_check())
    return out


def _verify_hosts() -> list[dict[str, Any]]:
    from core.host_config import DAEMON_HOSTS, verify_host

    rows = []
    for host in DAEMON_HOSTS:
        try:
            rows.append(verify_host(host))
        except Exception:  # noqa: BLE001, S112 — диагностика best-effort
            continue
    return rows
