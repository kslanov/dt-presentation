"""Path configuration for the engine (architecture §0, §2).

Resolves the derived (per-machine, untracked) locations relative to the repo so
nothing is hardcoded. Overridable via environment variables for tests / CI.

Layout (architecture §0)::

    <workspace_root>/        # parent of engine/ and vault/
    ├── vault/               # markdown source of truth
    ├── engine/              # this repo
    └── .derived/            # rebuildable indexes/caches (untracked)
        └── lancedb/         # LanceDB store

CODE-1: this module is a **facade** over a domain-split package
(``_roots``/``_vault``/``_operational``/``_legacy``/``_outlook``). The public
surface is frozen — ``__all__`` is byte-identical (by set) to the pre-split
``core/config.py``, and every previously importable name (including the mail
helpers that were never in ``__all__``) remains importable from ``core.config``
unchanged. Behaviour is byte-equivalent: functions were moved verbatim, no
default/value/signature changed. Internal imports point only at ``_roots``
(leaf→root), so the package has no import cycles.
"""

from __future__ import annotations

from ._legacy import (
    current_ingest_manifest_path,
    legacy_dryrun_report_path,
    legacy_exclude_globs,
    legacy_extracted_path,
    legacy_ingest_manifest_path,
    legacy_privacy_contract_terms,
    legacy_privacy_globs,
    legacy_privacy_hr_folders,
    legacy_privacy_name_tokens,
    legacy_privacy_person_signal_terms,
    legacy_privacy_salary_terms,
    legacy_privacy_weak_hr_terms,
    legacy_roots,
    legacy_section_map,
    legacy_xlsx_cell_cap,
    nda_markers,
)
from ._operational import (
    crm_admin_email,
    crosswalk_path,
    folder_map_path,
    link_applied_path,
    link_proposals_path,
    load_learned_folder_map,
    logs_path,
    meetings_cache_path,
    operational_derived_path,
    pult_html_override,
    save_learned_folder_map,
    sync_lock_path,
    sync_log_path,
    ticktick_capture_project,
    ticktick_client_folder_map,
    ticktick_state_path,
    timetta_mirror_path,
    timetta_user_email,
    timetta_user_id,
)

# Public but historically absent from ``__all__`` — re-exported (redundant alias
# marks the intentional re-export) so ``from core.config import X`` keeps working,
# but deliberately kept OUT of ``__all__`` below (frozen surface). REATTR-1
# (``reattr_proposals_path``) заведён здесь же и по той же причине: surface пакета
# заморожен тестом ``tests/test_config_surface.py`` — звёздный импорт обязан отдавать
# ровно прежний набор, а явный ``from core.config import …`` работает как у соседей.
from ._operational import reattr_proposals_path as reattr_proposals_path
from ._operational import watchlist_path as watchlist_path
from ._outlook import (
    DEFAULT_OUTLOOK_TIMEOUT,
    outlook_folders,
    outlook_ingest_manifest_path,
    outlook_preflight_timeout,
    outlook_pull_window,
    outlook_read_limit,
    outlook_self_tokens,
    outlook_timeout,
)
from ._outlook import mail_a2_context_extra as mail_a2_context_extra
from ._outlook import mail_batch_size as mail_batch_size
from ._outlook import mail_cursor_overlap_days as mail_cursor_overlap_days
from ._outlook import mail_gap_max as mail_gap_max
from ._outlook import mail_internal_domains as mail_internal_domains
from ._outlook import mail_noise_meeting_subjects as mail_noise_meeting_subjects
from ._outlook import mail_noise_senders as mail_noise_senders
from ._outlook import mail_noise_subjects as mail_noise_subjects
from ._outlook import mail_owner_domains as mail_owner_domains
from ._outlook import mail_refused_path as mail_refused_path
from ._roots import (
    ENGINE_ROOT,
    WORKSPACE_ROOT,
    backups_path,
    chunk_sessions_dir,
    derived_root,
    doctor_snapshot_path,
    dt_db_path,
    engine_env_path,
    eval_candidates_path,
    eval_history_path,
    eval_journal_path,
    events_path,
    facts_db_path,
    hub_candidates_path,
    index_lock_path,
    index_manifest_path,
    index_report_path,
    ingress_dir,
    jobs_db_path,
    jobs_dir,
    lancedb_path,
    link_scan_manifest_path,
    models_path,
    status_dir,
    user_display_name,
    web_token,
)
from ._roots import hub_alias_candidates_path as hub_alias_candidates_path
from ._roots import hub_synth_path as hub_synth_path
from ._roots import lint_findings_path as lint_findings_path
from ._roots import lint_last_path as lint_last_path
from ._roots import outputs_mark_path as outputs_mark_path
from ._roots import outputs_sources_path as outputs_sources_path
from ._vault import (
    ai_markers_path,
    default_vault_path,
    file_ingest_manifest_path,
    folder_aliases_path,
    icloud_download_s,
    ingest_materialize_timeout,
    ingest_roots_path,
    outputs_path,
    retrieval_policies_path,
    sources_cache_path,
    sources_cell_cap,
    staging_inbox_path,
    style_guides_path,
    templates_path,
    vault_system_path,
)
from ._vault import freshness_markers_path as freshness_markers_path
from ._vault import mail_filter_path as mail_filter_path
from ._vault import pult_settings_path as pult_settings_path

# Frozen public surface — identical (by set) to the pre-split module's __all__.
# The mail-ingest helpers (mail_batch_size / mail_noise_* / mail_owner_domains)
# and timetta_issue_type_id are importable from core.config (re-exported above)
# but, as before the split, are intentionally NOT listed here — they were never
# in the old __all__ and must not become star-exported.
__all__ = [
    "ENGINE_ROOT",
    "WORKSPACE_ROOT",
    # TEST-SANDBOX-1: единый корень производных данных (DT_DERIVED_ROOT) и пути, что раньше
    # жили модульными константами в core.metrics/eval/eval_journal/eval_candidates/diagnostics/
    # progress; PATH_PROVIDERS — реестр всех путь-функций (гард полноты). Расширение осознанное.
    "derived_root",
    "events_path",
    "eval_history_path",
    "ingress_dir",  # INGRESS-1: журнал отказов входа + итоги прогонов
    "eval_journal_path",
    "eval_candidates_path",
    "doctor_snapshot_path",
    "status_dir",
    "backups_path",
    "PATH_PROVIDERS",
    "lancedb_path",
    "index_manifest_path",
    "index_lock_path",
    "index_report_path",
    "hub_candidates_path",
    "link_scan_manifest_path",
    "models_path",
    "default_vault_path",
    "vault_system_path",
    "retrieval_policies_path",
    "style_guides_path",
    # STYLE-GUARD-1: канон ИИ-маркеров — путь-хелпер рядом со style_guides_path;
    # расширение замороженной поверхности осознанное (как folder_aliases_path).
    "ai_markers_path",
    "templates_path",
    "outputs_path",
    "staging_inbox_path",
    "ingest_roots_path",
    "folder_aliases_path",
    "file_ingest_manifest_path",
    "icloud_download_s",
    "ingest_materialize_timeout",
    "user_display_name",
    "timetta_mirror_path",
    "meetings_cache_path",
    "timetta_user_id",
    "timetta_user_email",
    "crm_admin_email",
    "ticktick_state_path",
    "ticktick_capture_project",
    "operational_derived_path",
    "logs_path",
    "sync_log_path",
    "sync_lock_path",
    "crosswalk_path",
    "watchlist_path",
    "link_proposals_path",
    "link_applied_path",
    "folder_map_path",
    "pult_html_override",  # VENDOR-HYGIENE-1 п.5: явный файл HTML веб-пульта
    "ticktick_client_folder_map",
    "load_learned_folder_map",
    "save_learned_folder_map",
    "legacy_xlsx_cell_cap",
    "sources_cache_path",
    "sources_cell_cap",
    "dt_db_path",
    "facts_db_path",
    "jobs_db_path",
    "jobs_dir",
    "chunk_sessions_dir",
    "nda_markers",
    "legacy_roots",
    "engine_env_path",
    "web_token",
    "legacy_extracted_path",
    "legacy_ingest_manifest_path",
    "current_ingest_manifest_path",
    "legacy_dryrun_report_path",
    "legacy_exclude_globs",
    "legacy_privacy_globs",
    "legacy_privacy_name_tokens",
    "legacy_privacy_salary_terms",
    "legacy_privacy_weak_hr_terms",
    "legacy_privacy_person_signal_terms",
    "legacy_privacy_contract_terms",
    "legacy_privacy_hr_folders",
    "legacy_section_map",
    "outlook_folders",
    "outlook_pull_window",
    "outlook_read_limit",
    "outlook_self_tokens",
    "outlook_ingest_manifest_path",
    "outlook_timeout",
    "outlook_preflight_timeout",
    "DEFAULT_OUTLOOK_TIMEOUT",
]


# --------------------------------------------------------------------------- #
# TEST-SANDBOX-1 — реестр путь-функций (гард полноты в tests/test_sandbox_subprocess.py)  #
# --------------------------------------------------------------------------- #
# Имя функции → где живёт путь:
#   "derived" — строго под ``derived_root()`` (по умолчанию; поштучные ``DT_*_PATH`` — явное
#               переопределение поверх, в песочнице их нет);
#   "vault"   — внутри vault (``DT_VAULT_PATH``), не под производным корнем;
#   "engine"  — внутри дерева engine/ (``.env``, кэш моделей).
# Любая новая функция ``*_path`` / ``*_dir`` / ``*_root`` в ``core.config`` обязана попасть
# сюда: «новая ручка — осознанное решение», а не тихий новый путь мимо песочницы.
PATH_PROVIDERS: dict[str, str] = {
    "derived_root": "derived",
    "lancedb_path": "derived",
    "index_manifest_path": "derived",
    "index_lock_path": "derived",
    "index_report_path": "derived",
    "hub_candidates_path": "derived",
    "hub_alias_candidates_path": "derived",
    "hub_synth_path": "derived",
    "lint_findings_path": "derived",
    "lint_last_path": "derived",
    "outputs_mark_path": "derived",
    "outputs_sources_path": "derived",
    "link_scan_manifest_path": "derived",
    "dt_db_path": "derived",
    "facts_db_path": "derived",
    "jobs_db_path": "derived",
    "jobs_dir": "derived",
    "chunk_sessions_dir": "derived",
    "timetta_mirror_path": "derived",
    "meetings_cache_path": "derived",
    "ticktick_state_path": "derived",
    "operational_derived_path": "derived",
    "logs_path": "derived",
    "sync_log_path": "derived",
    "sync_lock_path": "derived",
    "crosswalk_path": "derived",
    "watchlist_path": "derived",
    "link_proposals_path": "derived",
    "reattr_proposals_path": "derived",
    "link_applied_path": "derived",
    "folder_map_path": "derived",
    "legacy_extracted_path": "derived",
    "legacy_ingest_manifest_path": "derived",
    "current_ingest_manifest_path": "derived",
    "legacy_dryrun_report_path": "derived",
    "file_ingest_manifest_path": "derived",
    "sources_cache_path": "derived",
    "outlook_ingest_manifest_path": "derived",
    "mail_refused_path": "derived",
    "events_path": "derived",
    "eval_history_path": "derived",
    "ingress_dir": "derived",
    "eval_journal_path": "derived",
    "eval_candidates_path": "derived",
    "doctor_snapshot_path": "derived",
    "status_dir": "derived",
    "backups_path": "derived",
    "default_vault_path": "vault",
    "vault_system_path": "vault",
    "retrieval_policies_path": "vault",
    "style_guides_path": "vault",
    "ai_markers_path": "vault",
    "templates_path": "vault",
    "outputs_path": "vault",
    "staging_inbox_path": "vault",
    "ingest_roots_path": "vault",
    "folder_aliases_path": "vault",
    "mail_filter_path": "vault",
    "pult_settings_path": "vault",
    "freshness_markers_path": "vault",
    "models_path": "engine",
    "engine_env_path": "engine",
}
