"""Layer-B legacy-corpus ingest config, privacy/NDA barriers (CODE-1).

Split verbatim out of the pre-split ``core/config.py``. Imports only the roots
and shared private helpers from :mod:`core.config._roots` (leaf→root, no
cycles); stdlib otherwise.
"""

from __future__ import annotations

import os
from pathlib import Path

from ._roots import _env_json_list, _union, derived_root

__all__ = [
    "nda_markers",
    "legacy_xlsx_cell_cap",
    "legacy_roots",
    "legacy_extracted_path",
    "legacy_ingest_manifest_path",
    "current_ingest_manifest_path",
    "legacy_dryrun_report_path",
    "legacy_exclude_globs",
    "legacy_privacy_globs",
    "legacy_privacy_name_tokens",
    "legacy_privacy_salary_terms",
    "legacy_privacy_weak_hr_terms",
    "legacy_privacy_person_signal_terms",
    "legacy_privacy_contract_terms",
    "legacy_privacy_hr_folders",
    "legacy_section_map",
]


def legacy_xlsx_cell_cap() -> int:
    """Max non-empty cells read per worksheet by the xlsx extractor (ТЗ phase5).

    Caps how much a single spreadsheet contributes so a huge model/report does
    not bloat the index; rows past the cap are dropped (the extractor flags the
    truncation). Override with ``DT_LEGACY_XLSX_CELL_CAP`` (default 2000); a
    non-positive or non-numeric value falls back to the default.
    """
    raw = os.environ.get("DT_LEGACY_XLSX_CELL_CAP")
    if raw and raw.strip().lstrip("-").isdigit():
        value = int(raw.strip())
        if value > 0:
            return value
    return 2000


# Default NDA path-marker: a directory segment `_nda/` or a filename `*_nda.*`
# never enters the index / lift / prompt (NDA-1). The barrier is a path marker,
# not a content scan (принцип 9), so it is inspectable and offline.
_DEFAULT_NDA_MARKERS = ("_nda",)


def nda_markers() -> list[str]:
    """NDA path markers (NDA-1). Read from ``DT_NDA_MARKERS`` (comma-separated).

    Several markers are allowed (e.g. ``_nda,_секретно``). An empty or malformed
    value falls back to the default ``_nda`` — the barrier is **never** disabled by
    config. Returns the raw markers; :func:`core.privacy.is_nda` NFC-normalizes and
    lowercases them before matching.
    """
    raw = os.environ.get("DT_NDA_MARKERS")
    if raw and raw.strip():
        markers = [m.strip() for m in raw.split(",") if m.strip()]
        if markers:
            return markers
    return list(_DEFAULT_NDA_MARKERS)


# --------------------------------------------------------------------------- #
# Layer-B legacy-corpus ingest config (ТЗ phase5)                              #
# --------------------------------------------------------------------------- #

# Noise/marketing to never ingest (ТЗ phase5 §Исключения). IBC and
# ПМГФ are deliberately NOT here — they are kept; "0.Архив/Разобрать" is included
# by default. Patterns are matched case-insensitively against a file's path
# relative to the Bitrix root (``**`` ≈ "any depth"; see core/legacy/discover.py).
_DEFAULT_EXCLUDE_GLOBS = (
    "**/шаблоны презентаций/**",
    "**/Сайт/**",
    "**/*баннер*",
    "**/e-баннер*",
)

# Privacy — NEVER index (ТЗ phase5, refined by decision К. in stage 8b). Matching
# is WORD-based (whole word / stem at a word boundary), never naive substring, so
# "Доклад" no longer trips "оклад". Three rules, all in core/legacy/discover.py:
#   • salary terms in the FILE NAME → privacy (rule A1);
#   • a surname token ONLY together with a salary/ГПХ/HR/contract context (A2) —
#     a surname alone never filters (e.g. "ТКП (Павел Морозов)" indexes);
#   • inside an HR/ГПХ folder, only contract/salary-named files (A3) — the whole
#     folder is no longer excluded (BP-descriptions, Опыт_HR, budgets index).
# Commercial terms / sums are NOT private.

# Explicit privacy globs are now an escape hatch only (env-extendable); the
# defaults moved to the word-term lists below so folders aren't wholesale excluded.
_DEFAULT_PRIVACY_GLOBS: tuple[str, ...] = ()

# A1 — STRONG salary/personal terms that mark privacy when matched (as a word)
# in a FILE NAME, regardless of folder. Stems (≥4 chars) match a word *prefix*
# (зарплат→зарплата/зарплаты); short tokens (≤3) match whole words only.
_DEFAULT_PRIVACY_SALARY_TERMS = (
    "зарплат",
    "оклад",
    "вилк",
    "личн",
)

# A1b — WEAK HR terms (decision К.): "кадр"/"штат" alone over-capture HR-system
# specs / ТЗ / methodology (solution knowledge to KEEP). They mark privacy ONLY
# with a personal signal (below) in the name/path, or inside an HR/ГПХ folder —
# never on their own. Matched as words/stems like the strong terms.
_DEFAULT_PRIVACY_WEAK_HR_TERMS = (
    "кадр",
    "штат",
)

# Personal-data signals that, alongside a WEAK HR term, confirm privacy
# (справка/выписка/расписание/удостоверение/табель/протокол/СЗ + the strong
# salary terms). Word/stem-matched.
_DEFAULT_PRIVACY_PERSON_SIGNAL_TERMS = (
    "справк",
    "сведени",
    "выписк",
    "расписани",
    "удостоверени",
    "протокол",
    "оклад",
    "зарплат",
    "сз",
    "вилк",
    "табел",
    "личн",
)

# A2/A3 — contract/HR context terms: activate a surname (A2) and, inside an
# HR/ГПХ folder, mark a file as a personal contract by NAME (A3).
_DEFAULT_PRIVACY_CONTRACT_TERMS = (
    "договор",
    "гпх",
    "оклад",
    "зарплат",
    "штат",
    "кадр",
    "сз",
    "вилк",
)

# Folder names that count as an HR folder (token match within a path segment).
# A salary-stem folder (зарплат*/оклад*) is detected separately in discover.py.
_DEFAULT_PRIVACY_HR_FOLDERS = (
    "hr",
    "кадры",
    "персонал",
)

# Surnames of individuals whose PERSONAL documents must never be indexed — but
# ONLY in a salary/ГПХ/HR/contract context (A2). Matched as a word/stem (so
# "Иванова" matches "Иванов"), case-insensitively. PROFILE-1: no names live in the
# engine code — the list is ``privacy.people`` of the vault profile (``owner.yaml``)
# plus ``DT_LEGACY_PRIVACY_NAMES``; ``dt config check`` warns when both are empty.
_DEFAULT_PRIVACY_NAME_TOKENS: tuple[str, ...] = ()

# Canonicalize a first-level folder (after stripping "NN. " numbering) to a
# section label. Lookup is case-insensitive on the stripped name; unknown names
# pass through unchanged. Extend/override via DT_LEGACY_SECTION_MAP (JSON object).
_DEFAULT_SECTION_MAP = {
    "presale": "Presale",
    "пресейл": "Presale",
    "pipeline": "Pipeline",
    "пайплайн": "Pipeline",
    "материалы": "Материалы",
    "презентации": "Презентации",
}


def legacy_roots() -> list[Path]:
    """Absolute roots of the legacy file corpus (ТЗ phase5 §Источники).

    Read from ``DT_LEGACY_ROOTS`` (``:``-separated absolute paths, e.g.
    ``<Bitrix>/2018-2023:<Bitrix>/2023-2026``). Empty list if unset — nothing is
    hardcoded; the Bitrix path lives only in ``.env``.
    """
    raw = os.environ.get("DT_LEGACY_ROOTS")
    if not raw or not raw.strip():
        return []
    return [Path(p) for p in raw.split(":") if p.strip()]


def legacy_extracted_path() -> Path:
    """Extraction-cache dir (``.derived/legacy_extracted/``, ТЗ phase5).

    Holds one ``<hash(source_path)>.json`` per ingested source (normalized text +
    metadata) so a pdf/xlsx is re-extracted only when its mtime/size changes.
    Per-machine, untracked, rebuildable. Override with ``DT_LEGACY_EXTRACTED_PATH``.
    """
    override = os.environ.get("DT_LEGACY_EXTRACTED_PATH")
    if override:
        return Path(override)
    return derived_root() / "legacy_extracted"


def legacy_ingest_manifest_path() -> Path:
    """File→note manifest (``.derived/legacy_ingest_manifest.json``, ТЗ phase5).

    Maps ``source_path → {mtime, size, content_hash, note_path, status}`` for the
    file→markdown step, so a note is regenerated only when its source changed and
    is dropped when the source vanishes / becomes excluded / privacy / duplicate.
    Distinct from the note→index manifest (Polish-2). Per-machine, untracked,
    rebuildable. Override with ``DT_LEGACY_INGEST_MANIFEST_PATH``.
    """
    override = os.environ.get("DT_LEGACY_INGEST_MANIFEST_PATH")
    if override:
        return Path(override)
    return derived_root() / "legacy_ingest_manifest.json"


def current_ingest_manifest_path() -> Path:
    """File→note manifest for the **current** corpus layer (CORPUS-MIGRATE-1).

    Same record shape as :func:`legacy_ingest_manifest_path`
    (``source_path → {mtime, size, content_hash, source_content_hash, note_path,
    status}``) — a single template shared with the future CORPUS-INGEST-CURRENT
    owner (phase 3). CORPUS-MIGRATE-1 transfers migrated legacy→current entries
    here so the narrowed legacy ingest no longer sees them (its drop-loop can't
    delete what it doesn't own) and the current-corpus owner recognises them as
    already-processed (by ``source_content_hash``/``note_path``) — no duplicates.
    Per-machine, untracked, rebuildable. Override with
    ``DT_CURRENT_INGEST_MANIFEST_PATH``.
    """
    override = os.environ.get("DT_CURRENT_INGEST_MANIFEST_PATH")
    if override:
        return Path(override)
    return derived_root() / "current_ingest_manifest.json"


def legacy_dryrun_report_path() -> Path:
    """Default path for the dry-run diagnostic report (``.derived/``, ТЗ phase5).

    Where ``dt_legacy_ingest --dry-run`` writes the per-bucket path lists when no
    explicit ``--report`` is given. Per-machine, untracked. Override with
    ``DT_LEGACY_DRYRUN_REPORT_PATH``.
    """
    override = os.environ.get("DT_LEGACY_DRYRUN_REPORT_PATH")
    if override:
        return Path(override)
    return derived_root() / "legacy_dryrun_report.txt"


def legacy_exclude_globs() -> list[str]:
    """Noise/marketing globs to skip (defaults + ``DT_LEGACY_EXCLUDE_GLOBS`` JSON)."""
    return _union(_DEFAULT_EXCLUDE_GLOBS, _env_json_list("DT_LEGACY_EXCLUDE_GLOBS"))


def legacy_privacy_globs() -> list[str]:
    """Privacy path globs to never index (defaults + ``DT_LEGACY_PRIVACY_GLOBS``)."""
    return _union(_DEFAULT_PRIVACY_GLOBS, _env_json_list("DT_LEGACY_PRIVACY_GLOBS"))


def legacy_privacy_name_tokens() -> list[str]:
    """Surname tokens marking personal docs (profile ``privacy.people`` + env supplement).

    A surname filters ONLY with a salary/ГПХ/HR/contract context (A2, see
    :func:`core.legacy.discover.privacy_reason`) — never on its own. PROFILE-1: the code
    default is empty; the list grows from the vault profile and the env (never shrinks
    by config), so an empty result means "nothing configured" — ``dt config check`` warns.
    """
    from core.owner import load_profile

    return _union(
        _DEFAULT_PRIVACY_NAME_TOKENS,
        [*load_profile().data.privacy_people, *_env_json_list("DT_LEGACY_PRIVACY_NAMES")],
    )


def legacy_privacy_salary_terms() -> list[str]:
    """STRONG salary/personal word-terms that filter a FILE NAME (defaults + env).

    Rule A1. Matched as whole words / stems (never substrings). Extend via
    ``DT_LEGACY_PRIVACY_SALARY_TERMS`` (JSON array); defaults can't be dropped.
    """
    return _union(
        _DEFAULT_PRIVACY_SALARY_TERMS,
        _env_json_list("DT_LEGACY_PRIVACY_SALARY_TERMS"),
    )


def legacy_privacy_weak_hr_terms() -> list[str]:
    """WEAK HR terms (кадр/штат) filtered only with context (defaults + env).

    Rule A1b: privacy ONLY when a personal signal
    (:func:`legacy_privacy_person_signal_terms`) is present in the name/path, or
    the file is in an HR/ГПХ folder — alone they index (HR-system ТЗ/methodology).
    Extend via ``DT_LEGACY_PRIVACY_WEAK_HR_TERMS`` (JSON array).
    """
    return _union(
        _DEFAULT_PRIVACY_WEAK_HR_TERMS,
        _env_json_list("DT_LEGACY_PRIVACY_WEAK_HR_TERMS"),
    )


def legacy_privacy_person_signal_terms() -> list[str]:
    """Personal-data signal terms gating the weak HR terms (defaults + env).

    Rule A1b. Word/stem-matched. Extend via ``DT_LEGACY_PRIVACY_PERSON_SIGNALS``.
    """
    return _union(
        _DEFAULT_PRIVACY_PERSON_SIGNAL_TERMS,
        _env_json_list("DT_LEGACY_PRIVACY_PERSON_SIGNALS"),
    )


def legacy_privacy_contract_terms() -> list[str]:
    """Contract/HR context terms (defaults + ``DT_LEGACY_PRIVACY_CONTRACT_TERMS``).

    Rules A2/A3: activate a surname and, inside an HR/ГПХ folder, flag a file as
    a personal contract by name. Word/stem-matched.
    """
    return _union(
        _DEFAULT_PRIVACY_CONTRACT_TERMS,
        _env_json_list("DT_LEGACY_PRIVACY_CONTRACT_TERMS"),
    )


def legacy_privacy_hr_folders() -> list[str]:
    """HR folder-name tokens (defaults + ``DT_LEGACY_PRIVACY_HR_FOLDERS``).

    A path segment whose word-tokens include one of these is an HR folder (rule
    A3); salary-stem folders (зарплат*/оклад*) are detected separately.
    """
    return [
        t.lower()
        for t in _union(
            _DEFAULT_PRIVACY_HR_FOLDERS,
            _env_json_list("DT_LEGACY_PRIVACY_HR_FOLDERS"),
        )
    ]


def legacy_section_map() -> dict[str, str]:
    """First-level-folder → section label map (defaults + ``DT_LEGACY_SECTION_MAP``).

    Keys are matched case-insensitively (lowercased here); env JSON object
    entries override/extend the defaults.
    """
    merged = {k.lower(): v for k, v in _DEFAULT_SECTION_MAP.items()}
    raw = os.environ.get("DT_LEGACY_SECTION_MAP")
    if raw and raw.strip():
        import json

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = {}
        if isinstance(data, dict):
            for k, v in data.items():
                if str(k).strip() and str(v).strip():
                    merged[str(k).strip().lower()] = str(v)
    return merged
