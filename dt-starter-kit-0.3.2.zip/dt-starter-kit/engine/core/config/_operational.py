"""Operational config — Timetta, TickTick, derived/logs, linking (CODE-1).

Split verbatim out of the pre-split ``core/config.py``. Imports only the roots
from :mod:`core.config._roots` (leaf→root, no cycles); stdlib otherwise.

``crosswalk_path`` lives here (not in ``_vault``): it is derived from
:func:`operational_derived_path`, so co-locating it keeps every internal import
pointed at ``_roots`` only — the package's hard no-cycle invariant.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from ._roots import derived_root

__all__ = [
    "timetta_mirror_path",
    "meetings_cache_path",
    "timetta_user_id",
    "timetta_user_email",
    "crm_admin_email",
    "pult_html_override",
    "ticktick_state_path",
    "ticktick_capture_project",
    "ticktick_client_folder_map",
    "folder_map_path",
    "load_learned_folder_map",
    "save_learned_folder_map",
    "operational_derived_path",
    "logs_path",
    "sync_log_path",
    "sync_lock_path",
    "crosswalk_path",
    "link_proposals_path",
    "link_applied_path",
]


def timetta_mirror_path() -> Path:
    """Derived Timetta mirror dir (``.derived/timetta/``, §7).

    Per-machine, untracked, rebuildable from Timetta. Override with
    ``DT_TIMETTA_MIRROR_PATH``.
    """
    override = os.environ.get("DT_TIMETTA_MIRROR_PATH")
    if override:
        return Path(override)
    return derived_root() / "timetta"


def meetings_cache_path() -> Path:
    """PERF-3 meetings cache snapshot (``.derived/meetings/cache.json``).

    A local mirror of the Outlook calendar read (``data_as_of`` + window +
    meetings), refreshed on a schedule / on demand — so the pult renders from it
    instantly instead of a ~31s live bridge read on every render. Per-machine,
    untracked, rebuildable. Override with ``DT_MEETINGS_CACHE_PATH``.
    """
    override = os.environ.get("DT_MEETINGS_CACHE_PATH")
    if override:
        return Path(override)
    return derived_root() / "meetings" / "cache.json"


def timetta_user_id() -> str | None:
    """The author's Timetta user Guid, scoping the orbit (§7).

    Read from ``DT_TIMETTA_USER_ID``. If unset, return ``None`` — callers can
    discover it once from ``DT_TIMETTA_USER_EMAIL`` (see
    ``core.operational.timetta.connector.discover_user_id``) and print the Guid
    for the user to paste into ``.env``; the orbit is never guessed without it.
    """
    return os.environ.get("DT_TIMETTA_USER_ID") or None


def crm_admin_email() -> str | None:
    """Адрес администратора CRM — адресат карточки поручения (RETIRE-WRITE-1).

    ``DT_CRM_ADMIN_EMAIL``. Нужен ТОЛЬКО для ``mailto:`` в карточке «Поручение администратору
    CRM»: движок письмо не отправляет, К. отправляет сам. Не задан → ``None`` (карточка
    работает, но без адресата в письме и с предупреждением).
    """
    value = (os.environ.get("DT_CRM_ADMIN_EMAIL") or "").strip()
    return value or None


def pult_html_override() -> str | None:
    """Явный файл HTML веб-пульта (VENDOR-HYGIENE-1 п.5): ``DT_PULT_HTML_PATH``.

    Источник HTML пульта — репо (``webpult/pult.html``); другой файл (например, артефакт
    ``~/Claude/Artifacts/dt-pult/index.html``) отдается ТОЛЬКО по этому явному указанию.
    Прежнее имя ``DT_PULT_HTML`` — синоним. Не задан → ``None``. Это указатель на входной
    файл, а не производный путь (в ``PATH_PROVIDERS`` не входит).
    """
    value = (os.environ.get("DT_PULT_HTML_PATH") or os.environ.get("DT_PULT_HTML") or "").strip()
    return value or None


def timetta_user_email() -> str | None:
    """The author's Timetta email, used only for one-off user-id discovery."""
    return os.environ.get("DT_TIMETTA_USER_EMAIL") or None


def ticktick_state_path() -> Path:
    """Derived TickTick state dir (``.derived/ticktick/``, §7, B2a).

    Holds the local capture dedup state (per-machine, untracked, rebuildable).
    Override with ``DT_TICKTICK_STATE_PATH``.
    """
    override = os.environ.get("DT_TICKTICK_STATE_PATH")
    if override:
        return Path(override)
    return derived_root() / "ticktick"


def ticktick_capture_project(client: Any | None = None) -> str:
    """Resolve the id of the TickTick capture project (§7, B2a).

    ``DT_TICKTICK_CAPTURE_PROJECT_ID`` wins outright. Otherwise the id is
    resolved from ``DT_TICKTICK_CAPTURE_PROJECT_NAME`` via ``client.list_projects()``
    (case-insensitive name match). Raises a clear error if neither is set, if the
    name cannot be resolved without a client, or if no project matches the name —
    with a hint to create the project and/or paste its id into ``.env``.
    """
    pid = os.environ.get("DT_TICKTICK_CAPTURE_PROJECT_ID")
    if pid:
        return pid

    name = os.environ.get("DT_TICKTICK_CAPTURE_PROJECT_NAME")
    if not name:
        raise RuntimeError(
            "TickTick capture project is not configured — set "
            "DT_TICKTICK_CAPTURE_PROJECT_ID (preferred) or "
            "DT_TICKTICK_CAPTURE_PROJECT_NAME in .env. Create a dedicated capture "
            "list in TickTick first (e.g. «📥 Захват»)."
        )
    if client is None:
        raise RuntimeError(
            "Cannot resolve DT_TICKTICK_CAPTURE_PROJECT_NAME without a TickTick "
            "client (token missing?) — set DT_TICKTICK_CAPTURE_PROJECT_ID instead."
        )

    needle = name.strip().lower()
    for project in client.list_projects():
        if str(project.get("name", "")).strip().lower() == needle:
            return str(project["id"])
    raise RuntimeError(
        f"No TickTick project named {name!r} was found. Create it in TickTick, or "
        "set DT_TICKTICK_CAPTURE_PROJECT_ID to its id in .env."
    )


def operational_derived_path() -> Path:
    """Derived operational dir (``.derived/operational/``, §7, B2b).

    Holds the three-way crosswalk. Per-machine, untracked, rebuildable (markers
    in TickTick tasks are the durable anchor). Override with
    ``DT_OPERATIONAL_PATH``.
    """
    override = os.environ.get("DT_OPERATIONAL_PATH")
    if override:
        return Path(override)
    return derived_root() / "operational"


def logs_path() -> Path:
    """Derived logs dir (``.derived/logs/``, §7, Polish-1).

    Holds the orchestrator log and launchd stdout/stderr. Per-machine, untracked
    (gitignored under ``.derived/``). Override with ``DT_LOGS_PATH``.
    """
    override = os.environ.get("DT_LOGS_PATH")
    if override:
        return Path(override)
    return derived_root() / "logs"


def sync_log_path() -> Path:
    """The orchestrator's rotating log file (``dt-sync.log``, §7, Polish-1)."""
    return logs_path() / "dt-sync.log"


def sync_lock_path() -> Path:
    """Single-instance lock file for the orchestrator (``dt-sync.lock``).

    A per-machine flock anchor under ``.derived/`` so a scheduled run never
    overlaps a still-running one. Lives in the operational derived dir.
    """
    return operational_derived_path() / "dt-sync.lock"


def crosswalk_path() -> Path:
    """The Timetta↔TickTick↔vault crosswalk file (``crosswalk.json``, §7, B2b)."""
    return operational_derived_path() / "crosswalk.json"


def watchlist_path() -> Path:
    """Список «слежу» (``watchlist.json``, ORBIT-3): сделки колец 2/3, которые К. поставил на
    внимание с пульта. Состояние ПОЛЬЗОВАТЕЛЯ (не пересобирается из Timetta) — рядом с
    crosswalk в ``DT_OPERATIONAL_PATH``."""
    return operational_derived_path() / "watchlist.json"


def link_proposals_path() -> Path:
    """Semantic-link proposal queue (``.derived/link_proposals.jsonl``, Phase 6).

    A derived (per-machine, untracked, gitignored under ``.derived/``) JSONL ledger
    of AI-semantic link suggestions: one row per ``source → target`` candidate
    (``{id, source, target, score, target_type, evidence, status}``). Drives
    human-in-the-loop review and idempotency — re-running ``propose`` never
    duplicates a row (key = ``source → target``). Distinct from the operational
    ``proposals.json`` (Timetta writes); this one only ever edits vault notes.
    Override with ``DT_LINK_PROPOSALS_PATH``.
    """
    override = os.environ.get("DT_LINK_PROPOSALS_PATH")
    if override:
        return Path(override)
    return derived_root() / "link_proposals.jsonl"


def reattr_proposals_path() -> Path:
    """Очередь предложений переатрибуции (``.derived/reattr_proposals.jsonl``, REATTR-1).

    Производный (per-machine, untracked) JSONL-реестр: строка на перенос файла между
    сущностными каталогами (``{id, note_id, old_path, new_path, from_hubs, to_hubs,
    detected_at, status}``). Рядом с ``link_proposals.jsonl`` и по тем же правилам:
    ключ даёт идемпотентность (повторный инжест не плодит дубли), решение принимает
    человек. Переопределяется ``DT_REATTR_PROPOSALS_PATH``.
    """
    override = os.environ.get("DT_REATTR_PROPOSALS_PATH")
    if override:
        return Path(override)
    return derived_root() / "reattr_proposals.jsonl"


def link_applied_path() -> Path:
    """Journal of applied semantic links (``.derived/link_applied.jsonl``, Phase 6).

    An append-only audit log: one row per ``[[target]]`` written into a source
    note's ``## Связано`` section (``{source, target, score, rationale}``). Derived,
    per-machine, untracked. The vault notes are the source of truth; this is the
    "what did the apply step change" record. Override with ``DT_LINK_APPLIED_PATH``.
    """
    override = os.environ.get("DT_LINK_APPLIED_PATH")
    if override:
        return Path(override)
    return derived_root() / "link_applied.jsonl"


def folder_map_path() -> Path:
    """The learned client-folder map (``folder_map.json``, §7, B2d).

    A derived cache (per-machine, untracked, gitignored under ``.derived/``)
    holding ``{ "<org_id>": "<groupId>", ... }`` learned by ``dt-reflect
    --learn-folders`` from the live ``groupId`` of the engine's own lists. Lives
    beside the crosswalk in ``.derived/operational/``.
    """
    return operational_derived_path() / "folder_map.json"


def load_learned_folder_map() -> dict[str, str]:
    """Read the learned ``org_id → groupId`` map (``folder_map.json``, §7, B2d).

    Returns ``{}`` if the file is missing or malformed (it is a rebuildable
    cache — re-run ``--learn-folders``). Distinct from
    :func:`ticktick_client_folder_map` (the env override keyed by client
    name/code): in ``reflect`` the env override wins, then this learned map.
    """
    path = folder_map_path()
    if not path.is_file():
        return {}
    import json

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k): str(v) for k, v in data.items() if k and v}


def save_learned_folder_map(mapping: dict[str, str]) -> Path:
    """Persist (merge into) the learned folder map; returns its path (§7, B2d).

    Merges ``mapping`` over any existing ``folder_map.json`` so each
    ``--learn-folders`` run augments rather than replaces what was learned
    before. Creates ``.derived/operational/`` if needed.
    """
    import json

    clean = {str(k): str(v) for k, v in mapping.items() if k and v}
    merged = {**load_learned_folder_map(), **clean}
    path = folder_map_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(merged, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return path


def ticktick_client_folder_map() -> dict[str, str]:
    """Client(name/code)→TickTick ``groupId`` map for placing lists in folders.

    V1 cannot list folders by name (only ``groupId`` surfaces on projects), so
    the user supplies the correspondence once via ``DT_TICKTICK_CLIENT_FOLDER_MAP``
    — a JSON object ``{"Client Name": "<groupId>", ...}``. Keys are matched
    case-insensitively against an organization's name or code. A client absent
    from the map (and whose list is not yet manually filed) is reflected at the
    top level with a "create a folder" warning; the next run self-heals once the
    list carries a ``groupId``. Returns ``{}`` if unset or malformed.
    """
    raw = os.environ.get("DT_TICKTICK_CLIENT_FOLDER_MAP")
    if not raw or not raw.strip():
        return {}
    import json

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    if not isinstance(data, dict):
        return {}
    return {str(k).strip().lower(): str(v) for k, v in data.items() if k and v}
