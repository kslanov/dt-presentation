"""Outlook correspondence ingest config (CODE-1).

Split verbatim out of the pre-split ``core/config.py`` (ТЗ phase5, stage 8).
Imports only the roots and shared private helpers from
:mod:`core.config._roots` (leaf→root, no cycles); stdlib otherwise.

``__all__`` lists every public name defined here so the facade's ``import *``
re-exports them, but the mail-ingest helpers (``mail_batch_size``,
``mail_noise_*``, ``mail_owner_domains``) were never in the pre-split module's
``__all__`` and stay out of the facade's frozen ``__all__`` — importable, not
star-exported, exactly as before.
"""

from __future__ import annotations

import os
from pathlib import Path

from ._roots import _env_json_list, _union, derived_root

__all__ = [
    "outlook_folders",
    "outlook_pull_window",
    "mail_cursor_overlap_days",
    "mail_gap_max",
    "outlook_read_limit",
    "outlook_self_tokens",
    "outlook_ingest_manifest_path",
    "outlook_timeout",
    "outlook_preflight_timeout",
    "DEFAULT_OUTLOOK_TIMEOUT",
    "mail_batch_size",
    "mail_refused_path",
    "mail_noise_senders",
    "mail_noise_subjects",
    "mail_noise_meeting_subjects",
    "mail_owner_domains",
    "mail_internal_domains",
    "mail_a2_context_extra",
]


# --------------------------------------------------------------------------- #
# Outlook correspondence ingest config (ТЗ phase5, stage 8)                    #
# --------------------------------------------------------------------------- #

# Folders pulled from Classic Outlook into _legacy/correspondence/<bucket>/, in
# order. ``bucket`` is the vault subfolder; ``name`` is the Outlook folder name
# the JXA bridge resolves (inbox/sent synonyms are handled in the bridge, so the
# default EN names work against a Russian Outlook too). Override the whole list
# via DT_OUTLOOK_FOLDERS — a JSON array of ``{"bucket": ..., "name": ...}``.
_DEFAULT_OUTLOOK_FOLDERS = (
    {"bucket": "inbox", "name": "Inbox"},
    {"bucket": "sent", "name": "Sent Items"},
)


def outlook_folders() -> list[dict[str, str]]:
    """Outlook folders to ingest as correspondence (defaults + ``DT_OUTLOOK_FOLDERS``).

    Returns an ordered list of ``{"bucket", "name"}`` dicts. ``bucket`` becomes the
    ``_legacy/correspondence/<bucket>/`` subfolder (e.g. ``inbox``/``sent``);
    ``name`` is the Outlook folder the JXA bridge reads. A malformed override
    falls back to the defaults so the ingest is never left without folders.
    """
    raw = os.environ.get("DT_OUTLOOK_FOLDERS")
    if raw and raw.strip():
        import json

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            data = None
        if isinstance(data, list):
            out: list[dict[str, str]] = []
            for entry in data:
                if not isinstance(entry, dict):
                    continue
                bucket = str(entry.get("bucket", "")).strip()
                name = str(entry.get("name", "")).strip()
                if bucket and name:
                    out.append({"bucket": bucket, "name": name})
            if out:
                return out
    return [dict(spec) for spec in _DEFAULT_OUTLOOK_FOLDERS]


def outlook_pull_window() -> int:
    """Default look-back window in days for the mail pull (ТЗ phase5, stage 8).

    Used when no ``--since`` is given and the manifest has no prior cursor for a
    folder: the first incremental run (and any ``--scope full`` run) reads only
    the last ``N`` days, so a huge mailbox is bounded. Override with
    ``DT_OUTLOOK_PULL_WINDOW`` (default 365); a non-positive/non-numeric value
    falls back to the default.
    """
    raw = os.environ.get("DT_OUTLOOK_PULL_WINDOW")
    if raw and raw.strip().lstrip("-").isdigit():
        value = int(raw.strip())
        if value > 0:
            return value
    return 365


def mail_cursor_overlap_days() -> int:
    """Перекрытие курсора почты, дни (MAIL-GAP-1): ``since`` папки = дата новейшего письма минус N.

    Outlook на ноутбуке досинхронизирует папку кусками (свежие первыми), переносит письма из
    подпапок, получает письма с задержкой сервера: у них ``time received`` СТАРШЕ курсора, и
    строгий ``since`` по новейшему письму отрезал бы их навсегда. Перекрытие дешево: повторно
    просмотренные письма уже в манифесте (``resumed``), тела не перечитываются.
    ``DT_MAIL_CURSOR_OVERLAP_DAYS`` (дефолт 14: отпуск с закрытым ноутбуком); ``0`` - прежнее
    поведение без перекрытия; нечисловое/отрицательное - дефолт.
    """
    raw = os.environ.get("DT_MAIL_CURSOR_OVERLAP_DAYS")
    if raw and raw.strip().isdigit():
        return int(raw.strip())
    return 14


def mail_gap_max() -> int:
    """Порог смоука «дыра курсора» (С-13, MAIL-GAP-1): писем за 90 дн вне манифеста допустимо.

    ``DT_MAIL_GAP_MAX`` (дефолт 5: письма, снятые приватностью, в манифест не попадают и в сухом
    проходе остаются «добавляемыми»); больше - письма теряются, смоук красный.
    Нечисловое/отрицательное - дефолт.
    """
    raw = os.environ.get("DT_MAIL_GAP_MAX")
    if raw and raw.strip().isdigit():
        return int(raw.strip())
    return 5


def outlook_read_limit() -> int:
    """Max messages the bridge reads per folder per run (ТЗ phase5, stage 8).

    A safety cap on a single JXA read so one run never tries to pull an entire
    mailbox at once. Override with ``DT_OUTLOOK_READ_LIMIT`` (default 500);
    non-positive/non-numeric falls back to the default.
    """
    raw = os.environ.get("DT_OUTLOOK_READ_LIMIT")
    if raw and raw.strip().lstrip("-").isdigit():
        value = int(raw.strip())
        if value > 0:
            return value
    return 500


# Realistic per-call Outlook ceiling (JOB-1, R5): a wedged/slow Outlook must not
# hang for minutes. Bounded meta/heavy reads fit under this; long reads go async
# (submit_job) instead of raising it. Kept in sync with the bridge's own default.
DEFAULT_OUTLOOK_TIMEOUT = 120.0


def outlook_timeout() -> float:
    """Per-call timeout (seconds) for the read-only Outlook bridge.

    Used for BOTH the ``osascript`` subprocess AND the AppleScript ``with timeout``
    inside the ops, so it must exceed the DEFAULT ~120s Apple Event cap (a big
    meta/heavy call otherwise dies with "AppleEvent timed out"). Override with
    ``DT_OUTLOOK_TIMEOUT`` (default **120**); non-positive/non-numeric falls back to
    the default. Meta/heavy work is index-paged and bounded to fit this ceiling;
    for genuinely long reads use the async path (``submit_job("outlook_read", …)``)
    rather than raising this and blocking the MCP client (JOB-1). Mirrors
    :func:`core.operational.outlook_bridge._default_timeout`.
    """
    raw = os.environ.get("DT_OUTLOOK_TIMEOUT")
    if raw and raw.strip():
        try:
            value = float(raw.strip())
        except ValueError:
            return DEFAULT_OUTLOOK_TIMEOUT
        if value > 0:
            return value
    return DEFAULT_OUTLOOK_TIMEOUT


def outlook_preflight_timeout() -> float:
    """Short ceiling (seconds) for the cheap Outlook preflight probe (JOB-1, R5).

    Preflight (Outlook running? Classic, not the non-scriptable New Outlook?) must
    fail *fast* — it must never inherit the heavy :func:`outlook_timeout` ceiling,
    or a wedged/New Outlook would stall the probe for minutes (the very bug R5
    fixes). Override with ``DT_OUTLOOK_PREFLIGHT_TIMEOUT`` (default 20);
    non-positive/non-numeric falls back to the default.
    """
    raw = os.environ.get("DT_OUTLOOK_PREFLIGHT_TIMEOUT")
    if raw and raw.strip():
        try:
            value = float(raw.strip())
        except ValueError:
            return 20.0
        if value > 0:
            return value
    return 20.0


def mail_batch_size() -> int:
    """Messages processed per durable batch in the paginated mail ingest.

    Heavy fields (body/recipients/attachments) are fetched and notes flushed one
    batch at a time, so a run is interruptible/resumable and memory holds only one
    batch. Override with ``DT_MAIL_BATCH`` (default 300); non-positive/non-numeric
    falls back to the default.
    """
    raw = os.environ.get("DT_MAIL_BATCH")
    if raw and raw.strip().lstrip("-").isdigit():
        value = int(raw.strip())
        if value > 0:
            return value
    return 300


def _env_list(var: str) -> list[str]:
    """Parse an env var as a JSON array OR a comma-separated list of strings."""
    raw = os.environ.get(var)
    if not raw or not raw.strip():
        return []
    items = _env_json_list(var)
    if items:
        return items
    return [part.strip() for part in raw.split(",") if part.strip()]


# MAIL-FILTER-1: правила шума почты живут В ДАННЫХ — ``vault/_system/mail-filter.yaml``
# (:mod:`core.legacy.mail_filter`; запасной набор — в коде того модуля, если файла нет). Env
# ``DT_MAIL_NOISE_*`` остается РАСШИРЕНИЕМ (никогда не сужает): JSON-массив или список через
# запятую. Подстрочных правил больше нет: ``DT_MAIL_NOISE_SENDERS`` пополняет ``senders_weak``
# (общие токены отправителя, подстрока), ``DT_MAIL_NOISE_SUBJECTS`` - ``subject_word`` (ЦЕЛОЕ
# слово, ``слов*`` - начало слова; только в паре со слабым отправителем), ``DT_MAIL_NOISE_MEETING``
# - ``subject_prefix`` авто-ответов на встречи (обе папки).


def mail_noise_senders() -> list[str]:
    """Env-расширение ``senders_weak`` (нижний регистр): общие токены отправителя."""
    return [t.lower() for t in _env_list("DT_MAIL_NOISE_SENDERS")]


def mail_noise_subjects() -> list[str]:
    """Env-расширение ``subject_word`` (нижний регистр): слова темы в паре со слабым адресом."""
    return [t.lower() for t in _env_list("DT_MAIL_NOISE_SUBJECTS")]


def mail_noise_meeting_subjects() -> list[str]:
    """Env-расширение префиксов ответов на встречи (``reason: meeting_response``, обе папки)."""
    return [t.lower() for t in _env_list("DT_MAIL_NOISE_MEETING")]


# Owner e-mail domains — participants on these are "us", everyone else is a
# counterparty (drives the counterparty/counterparty_domains frontmatter and
# client-hub linking). DEV-3-CORE: no default in code — the owner profile
# (``vault/_system/profile/owner.yaml``: domains of ``emails`` + ``company.domains``) plus the
# env add-on ``DT_MAIL_OWNER_DOMAINS``.
def _profile_domains(kind: str) -> list[str]:
    """Домены из профиля владельца (``owner``/``internal``); нет профиля/vault - пусто."""
    try:
        from core.owner import domains, load_profile

        profile = load_profile()
        if kind == "owner":
            return domains.owner_domains(profile)
        return domains.internal_domains(profile)
    except Exception:  # noqa: BLE001 - нет vault/профиля: доменов нет, почта станет внешней
        return []


def mail_owner_domains() -> list[str]:
    """Lower-cased owner e-mail domains: profile emails + ``company.domains`` + env add-on."""
    own = _union(tuple(_profile_domains("owner")), _env_list("DT_MAIL_OWNER_DOMAINS"))
    return [t.lower() for t in own]


def mail_internal_domains() -> list[str]:
    """Служебные домены группы/инфраструктуры (``company.internal_domains`` + env-добавка
    ``DT_MAIL_INTERNAL_DOMAINS``): контрагентом не считаются, «своими» для ingest не становятся."""
    internal = _union(tuple(_profile_domains("internal")), _env_list("DT_MAIL_INTERNAL_DOMAINS"))
    return [t.lower() for t in internal]


def mail_a2_context_extra() -> list[str]:
    """Env-расширение контекста A2 для почты (MAIL-PRIVACY-2): ``DT_MAIL_A2_CONTEXT`` (JSON-массив).

    Дефолт контекста (``гпх``/``оклад``/…, без голого «договор») - константа ``_MAIL_A2_CONTEXT``
    в ``core.legacy.mail``; env только ДОБАВЛЯЕТ слова (как все списки приватности: дефолт нельзя
    потерять конфигом). Вернуть «договор» в контекст: ``DT_MAIL_A2_CONTEXT='["договор"]'``.
    """
    return [t.lower() for t in _env_json_list("DT_MAIL_A2_CONTEXT")]


def outlook_self_tokens() -> list[str]:
    """Owner-identity tokens exempted from the email privacy probe (ТЗ phase5).

    The mailbox owner is a participant in **every** message, so their own name /
    email must not trip the third-party privacy filter — the same name-token
    rule that (correctly) excludes other flagged individuals' personal data also
    lists the owner's surname to keep *their files* out of the index. These
    tokens are stripped from the participant/subject probe before the rule runs.

    PROFILE-1: the vault profile (``owner.yaml``: ``name`` + ``name_variants`` +
    ``emails``) comes first; ``DT_OUTLOOK_SELF_TOKENS`` (JSON array of strings),
    ``DT_USER_NAME`` when set to a real name and the owner's
    ``DT_TIMETTA_USER_EMAIL`` are a supplement (legacy sources). **With none
    configured, the owner's own correspondence is filtered out** — fill the profile
    (``dt owner init``). De-duplicated, case-insensitively.
    """
    from core.owner import load_profile

    tokens = [*load_profile().identity_tokens, *_env_json_list("DT_OUTLOOK_SELF_TOKENS")]
    name = os.environ.get("DT_USER_NAME")
    if name and name.strip() and name.strip().lower() != "the user":
        tokens.append(name.strip())
    email = os.environ.get("DT_TIMETTA_USER_EMAIL")
    if email and email.strip():
        tokens.append(email.strip())
    seen: set[str] = set()
    out: list[str] = []
    for token in tokens:
        key = token.strip().lower()
        if key and key not in seen:
            seen.add(key)
            out.append(token.strip())
    return out


def outlook_ingest_manifest_path() -> Path:
    """Mail→note manifest (``.derived/outlook_ingest_manifest.json``, ТЗ phase5).

    Maps ``entryID → {date, content_hash, note_path, bucket, folder}`` for the
    correspondence ingest, so a note is regenerated only when its message content
    changed and the incremental ``since`` cursor can be derived per folder.
    Distinct from the legacy file→note manifest. Per-machine, untracked,
    rebuildable. Override with ``DT_OUTLOOK_INGEST_MANIFEST_PATH``.
    """
    override = os.environ.get("DT_OUTLOOK_INGEST_MANIFEST_PATH")
    if override:
        return Path(override)
    return derived_root() / "outlook_ingest_manifest.json"


def mail_refused_path() -> Path:
    """Память «отказано» почтового фильтра (``.derived/mail_refused.json``, MAIL-FILTER-1).

    ``{msg_id: {reason, rule, ts}}`` - сообщения, снятые фильтром (инжестом или ретро-проходом):
    следующий ИНКРЕМЕНТ их не возвращает, даже если тред из индекса ушел целиком (строки без
    ``msg_ids`` индекс почты не терпит). ``--scope full`` ее игнорирует - решает текущий yaml.
    Per-machine, untracked, rebuildable. Override: ``DT_MAIL_REFUSED_PATH``.
    """
    override = os.environ.get("DT_MAIL_REFUSED_PATH")
    if override:
        return Path(override)
    return derived_root() / "mail_refused.json"
