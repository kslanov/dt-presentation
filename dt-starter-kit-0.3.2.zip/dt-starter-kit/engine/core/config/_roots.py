"""Roots, shared env helpers and index/db paths — the package base (CODE-1).

The leaf of the config package's internal import graph: every other submodule
(`_vault`, `_operational`, `_legacy`, `_outlook`) imports the roots and shared
private helpers from here and nothing imports from them, so there are no cycles.
Depends only on the stdlib. Behaviour is byte-identical to the pre-split
``core/config.py`` (functions moved verbatim, defaults/values unchanged).
"""

from __future__ import annotations

import os
from pathlib import Path

__all__ = [
    "ENGINE_ROOT",
    "WORKSPACE_ROOT",
    "derived_root",
    "events_path",
    "ingress_dir",
    "eval_history_path",
    "eval_journal_path",
    "eval_candidates_path",
    "doctor_snapshot_path",
    "status_dir",
    "backups_path",
    "lancedb_path",
    "index_manifest_path",
    "index_lock_path",
    "index_report_path",
    "hub_candidates_path",
    "link_scan_manifest_path",
    "models_path",
    "dt_db_path",
    "facts_db_path",
    "jobs_db_path",
    "jobs_dir",
    "chunk_sessions_dir",
    "engine_env_path",
    "web_token",
    "user_display_name",
]

# engine/core/config/_roots.py → parents[2] = engine/, parents[3] = workspace root.
ENGINE_ROOT = Path(__file__).resolve().parents[2]
WORKSPACE_ROOT = ENGINE_ROOT.parent


def _env_json_list(var: str) -> list[str]:
    """Parse an env var as a JSON array of strings; ``[]`` if unset/malformed."""
    raw = os.environ.get(var)
    if not raw or not raw.strip():
        return []
    import json

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return []
    if not isinstance(data, list):
        return []
    return [str(x) for x in data if str(x).strip()]


def _union(defaults: tuple[str, ...], extra: list[str]) -> list[str]:
    """Defaults plus env extras, de-duplicated, order-preserving (defaults first).

    Lists only grow via env — a privacy/exclude default can never be lost by an
    override (ТЗ phase5: privacy patterns must not be droppable by config).
    """
    out: list[str] = list(defaults)
    for item in extra:
        if item not in out:
            out.append(item)
    return out


def derived_root(workspace: Path | None = None) -> Path:
    """Корень производных данных (``<workspace>/.derived``) — ЕДИНСТВЕННОЕ место литерала.

    TEST-SANDBOX-1: все производные пути строятся от него (функциями, не модульными
    константами), поэтому ОДНА переменная ``DT_DERIVED_ROOT`` уводит в песочницу весь
    стор — и в этом процессе, и в любом его подпроцессе (env наследуется, а
    ``monkeypatch`` атрибутов модуля подпроцесс не видит: так ``dt_sync index`` из теста
    записал точку в боевой ``eval/history.jsonl``, инцидент 24.10). Поштучные
    ``DT_*_PATH`` остаются переопределениями ПОВЕРХ корня. Без переменной — боевой
    ``.derived``, как раньше.

    DEV-3-KIT: ``workspace`` - явный корень рабочей папки (``dt install --root``): ``<workspace>/
    .derived`` без оглядки на окружение (установщик ставит НА цель, а не в ту, что в env процесса).
    """
    if workspace is not None:
        return Path(workspace) / ".derived"
    override = os.environ.get("DT_DERIVED_ROOT")
    if override and override.strip():
        return Path(override.strip())
    return WORKSPACE_ROOT / ".derived"


def events_path() -> Path:
    """Append-only журнал событий метрик (``.derived/metrics/events.jsonl``, KPI-1).

    Override with ``DT_EVENTS_PATH`` (нужно ``dt_eval``: его прогон пишет события в свою
    песочницу, а не в боевой журнал).
    """
    override = os.environ.get("DT_EVENTS_PATH")
    if override:
        return Path(override)
    return derived_root() / "metrics" / "events.jsonl"


def ingress_dir() -> Path:
    """INGRESS-1: ``.derived/ingress/`` — журнал отказов входа (``refusals.jsonl``) и итоги
    последних прогонов адаптеров (``last_runs.json``). Производные данные: пересобираются."""
    return derived_root() / "ingress"


def eval_history_path() -> Path:
    """История прогонов золотого набора (``.derived/eval/history.jsonl``, EVAL-1).

    Боевая линейка — от неё считается регрессия: случайная строка из теста искажает её.
    Override with ``DT_EVAL_HISTORY_PATH`` (смоук С-6 читает боевую при tmp-корне).
    """
    override = os.environ.get("DT_EVAL_HISTORY_PATH")
    if override:
        return Path(override)
    return derived_root() / "eval" / "history.jsonl"


def eval_journal_path() -> Path:
    """Журнал запросов поиска/открытий (``.derived/eval/queries.jsonl``, EVAL-2).

    Override with ``DT_EVAL_JOURNAL_PATH`` (SMOKE-SANDBOX-FIX: смоук читает боевой корень, но
    писать журнал запросов ему не положено — поштучная ручка уводит его в tmp).
    """
    override = os.environ.get("DT_EVAL_JOURNAL_PATH")
    if override:
        return Path(override)
    return derived_root() / "eval" / "queries.jsonl"


def eval_candidates_path() -> Path:
    """Очередь кандидатов в золотой набор (``.derived/eval/candidates.json``, EVAL-2).

    Override with ``DT_EVAL_CANDIDATES_PATH`` (смоук, см. :func:`eval_journal_path`).
    """
    override = os.environ.get("DT_EVAL_CANDIDATES_PATH")
    if override:
        return Path(override)
    return derived_root() / "eval" / "candidates.json"


def doctor_snapshot_path() -> Path:
    """Снимок последнего прогона доктора (``.derived/doctor_last.json``, EVAL-3)."""
    return derived_root() / "doctor_last.json"


def status_dir() -> Path:
    """Маяки прогресса долгих процессов (``.derived/status/``, ACT-1).

    Override with ``DT_STATUS_DIR`` (смоук: его маяки не должны смешиваться с боевыми).
    """
    override = os.environ.get("DT_STATUS_DIR")
    if override:
        return Path(override)
    return derived_root() / "status"


def backups_path() -> Path:
    """Куда складывать архивы бэкапа: ``DT_BACKUPS_PATH`` либо ``<корень>/.backups``.

    Дефолт — рядом с производным корнем (родитель ``derived_root()``): без
    ``DT_DERIVED_ROOT`` это прежний ``<workspace>/.backups`` (вне git), в песочнице —
    тоже внутри неё, а не в боевом workspace.
    """
    override = (os.environ.get("DT_BACKUPS_PATH") or "").strip()
    if override:
        return Path(override)
    return derived_root().parent / ".backups"


def lancedb_path() -> Path:
    """LanceDB store dir (derived, per-machine, NOT versioned).

    Override with ``DT_LANCEDB_PATH``.
    """
    override = os.environ.get("DT_LANCEDB_PATH")
    if override:
        return Path(override)
    return derived_root() / "lancedb"


def index_manifest_path() -> Path:
    """Incremental-index manifest file (``.derived/index_manifest.json``).

    Maps ``note_id → {hash, chunks, indexed_at, mtime, size, path}`` so an
    incremental reindex can tell new/changed/deleted/unchanged notes apart
    (note-level: mtime/size/hash) and re-embed only the changed chunks within a
    changed note (PERF-2: per-chunk ``chunks: [{text_hash, meta_hash}]``). Derived,
    per-machine, NOT versioned — sits beside ``lancedb/``.
    Override with ``DT_INDEX_MANIFEST_PATH``.
    """
    override = os.environ.get("DT_INDEX_MANIFEST_PATH")
    if override:
        return Path(override)
    return lancedb_path().parent / "index_manifest.json"


def index_lock_path() -> Path:
    """Single-writer flock anchor for the LanceDB reindex (``index.lock``).

    Guards against two concurrent (re)index runs (e.g. a scheduled incremental
    pass while a manual full rebuild is in flight) — the second run skips
    softly. Sits beside ``lancedb/`` so a ``DT_LANCEDB_PATH`` redirect (tests)
    isolates the lock too. Override with ``DT_INDEX_LOCK_PATH``.
    """
    override = os.environ.get("DT_INDEX_LOCK_PATH")
    if override:
        return Path(override)
    return lancedb_path().parent / "index.lock"


def index_report_path() -> Path:
    """Отчёт последнего reindex для doctor (``.derived/index_report.json``).

    WAVE0-HYGIENE: коллизии ``note_id`` (п.2), капнутые заметки (п.5), устройство
    эмбеддера и причина фолбэка (п.7) — то, что индексатор видит ВО ВРЕМЯ прогона и
    чего doctor иначе не узнает без повторного обхода 17 тыс. файлов. Перезаписывается
    каждым прогоном (атомарно). Sits beside ``lancedb/`` (тест-изоляция по
    ``DT_LANCEDB_PATH``). Override ``DT_INDEX_REPORT_PATH``.
    """
    override = os.environ.get("DT_INDEX_REPORT_PATH")
    if override:
        return Path(override)
    return lancedb_path().parent / "index_report.json"


def hub_candidates_path() -> Path:
    """HUB-1 candidate queue (``.derived/hub_candidates.jsonl``).

    The restartable hub-candidate detector's review queue: one JSON row per
    candidate (pending/applied/rejected; rejected doubles as the detector's
    stop-journal). Derived, per-machine. Override with ``DT_HUB_CANDIDATES_PATH``.
    """
    override = os.environ.get("DT_HUB_CANDIDATES_PATH")
    if override:
        return Path(override)
    return derived_root() / "hub_candidates.jsonl"


def hub_alias_candidates_path() -> Path:
    """HUB-ALIAS-1 alias queue (``.derived/hub_alias_candidates.jsonl``).

    One JSON row per HUB (id = hub id; pending/applied/rejected/snoozed/resolved): the detector's
    name suggestions for a hub (H1 fragments, Timetta-mirror organizations, e-mail domains, legacy
    folder names) awaiting K.'s decision on the pult. Derived, per-machine, rebuildable (a rejected
    row doubles as the stop-journal). Override with ``DT_HUB_ALIAS_CANDIDATES_PATH``.
    """
    override = os.environ.get("DT_HUB_ALIAS_CANDIDATES_PATH")
    if override:
        return Path(override)
    return derived_root() / "hub_alias_candidates.jsonl"


def hub_synth_path() -> Path:
    """HUB-SYNTH-1 synth-card store (``.derived/hub_synth.jsonl``).

    One JSON row per card (pending/applied/rejected/snoozed): the session's proposed hub-state
    section awaiting K.'s decision on the pult; a rejected row doubles as the per-hub stop period.
    Derived, per-machine, rebuildable. Under ``DT_DERIVED_ROOT`` (no own override).
    """
    return derived_root() / "hub_synth.jsonl"


def lint_findings_path() -> Path:
    """KNOWLEDGE-LINT-1 findings store (``.derived/lint_findings.jsonl``).

    One JSON row per finding (id stable per rule+key): pending/snoozed/dismissed/applied/resolved.
    Derived, per-machine, rebuildable by the detectors (a decided row is only the stop-journal).
    Under ``DT_DERIVED_ROOT`` (no own override).
    """
    return derived_root() / "lint_findings.jsonl"


def lint_last_path() -> Path:
    """KNOWLEDGE-LINT-1 last-run summary (``.derived/lint_last.json``): per-rule counters."""
    return derived_root() / "lint_last.json"


def outputs_mark_path() -> Path:
    """EVAL-HYGIENE-1 report of the last ``dt outputs mark`` run (``.derived/outputs_mark.json``).

    What was marked/moved/deleted (список до изменений + итог): backup of the retro-mark list.
    Derived, per-machine. Under ``DT_DERIVED_ROOT`` (no own override).
    """
    return derived_root() / "outputs_mark.json"


def outputs_sources_path() -> Path:
    """PROV-SESSION-1 report of the last ``dt outputs sources`` run (``outputs_sources.json``).

    Список выходов, которым ретро дописало (или собиралось дописать) автосекции сессии, - до
    изменений и итог. Derived, per-machine. Under ``DT_DERIVED_ROOT`` (no own override).
    """
    return derived_root() / "outputs_sources.json"


def link_scan_manifest_path() -> Path:
    """Deterministic link-scan checkpoint (``.derived/link_scan.json``, Phase 9).

    Maps ``vault-relative note path → {mtime, size}`` of the last deterministic
    linking scan, so a scheduled ``dt_link`` pass skips unchanged notes on
    steady-state and an interrupted run resumes instead of restarting. Derived,
    per-machine, rebuildable (a lost file just means one full rescan). Override
    with ``DT_LINK_SCAN_PATH``.
    """
    override = os.environ.get("DT_LINK_SCAN_PATH")
    if override:
        return Path(override)
    return derived_root() / "link_scan.json"


def models_path() -> Path:
    """Local model cache dir (NOT versioned; covered by .gitignore ``models/``).

    Override with ``DT_MODELS_PATH``.
    """
    override = os.environ.get("DT_MODELS_PATH")
    if override:
        return Path(override)
    return ENGINE_ROOT / "models"


def dt_db_path() -> Path:
    """The single unified SQLite DB (``.derived/dt.db``, DB-1).

    One file backing facts / sources-registry / jobs, with a shared connection,
    one schema version and one migration framework (:mod:`core.db`). The pre-DB-1
    stores (``facts.db``/``jobs.db``/``sources/index.json``) that sit beside it are
    imported once on first open and renamed ``.bak``. Per-machine, untracked
    (under ``.derived/``, gitignored incl. ``-wal``/``-shm``), rebuildable — снести
    ``dt.db`` и открыть заново (facts переизвлекаются, sources регистрируются при
    lift/ingest, jobs эфемерны). Override with ``DT_DB_PATH``.
    """
    override = os.environ.get("DT_DB_PATH")
    if override:
        return Path(override)
    return derived_root() / "dt.db"


def facts_db_path() -> Path:
    """SQLite location the facts store opens — the unified ``dt.db`` (DB-1).

    Defaults to :func:`dt_db_path` (facts now live in the shared DB), with the
    public ``get_facts``/``upsert_facts`` API unchanged. ``DT_FACTS_DB_PATH`` still
    overrides it (used for test isolation and any standalone facts DB); the DB it
    points at carries the full unified schema regardless. Before DB-1 this was
    ``.derived/facts.db`` — that file is migrated into ``dt.db`` on first open.
    """
    override = os.environ.get("DT_FACTS_DB_PATH")
    if override:
        return Path(override)
    return dt_db_path()


def jobs_db_path() -> Path:
    """SQLite location the jobs DAO opens — the unified ``dt.db`` (DB-1).

    Defaults to :func:`dt_db_path` (jobs now live in the shared DB), with the JOB-1
    DAO API unchanged. ``DT_JOBS_DB_PATH`` still overrides it (test isolation /
    standalone). Before DB-1 this was ``.derived/jobs.db`` — migrated (best-effort;
    jobs are ephemeral) into ``dt.db`` on first open.
    """
    override = os.environ.get("DT_JOBS_DB_PATH")
    if override:
        return Path(override)
    return dt_db_path()


def chunk_sessions_dir() -> Path:
    """Каталог сессий порционной записи файла (``.derived/chunked/``, ФТ-5 / FT-5).

    Здесь живёт сборка бинаря, приходящего частями: ``<session_id>.json`` — состояние
    (цель, принятые части, смещения; **контента нет**) и ``<session_id>.part`` — сами
    накопленные байты. Сборка идёт ЗДЕСЬ, а не в клиентской папке: недособранный файл
    там не должен быть виден ни на секунду (в цель уходит только проверенный по
    sha256 результат). Per-machine, untracked, пересобираемое; незавершённые сессии
    подчищаются по TTL. Override — ``DT_CHUNK_SESSIONS_DIR``.
    """
    override = os.environ.get("DT_CHUNK_SESSIONS_DIR")
    if override:
        return Path(override)
    return derived_root() / "chunked"


def jobs_dir() -> Path:
    """Durable per-job result dir (``.derived/jobs/``, JOB-1).

    Where a finished job's result payload is written as ``<job_id>.json`` so it
    survives an MCP-server restart (the result is never held only in memory). The
    ``jobs`` row's ``result_ref`` points here. Per-machine, untracked, rebuildable.
    Override with ``DT_JOBS_DIR``.
    """
    override = os.environ.get("DT_JOBS_DIR")
    if override:
        return Path(override)
    return derived_root() / "jobs"


def engine_env_path() -> Path:
    """``engine/.env`` — the single dotenv the CLIs load (never a secret store)."""
    return ENGINE_ROOT / ".env"


def web_token() -> str | None:
    """Read-only web-pult token — ``DT_WEB_TOKEN`` or ``.secrets/web_token``.

    Same sources ``webpult/server.py`` uses (but never generates one here — this is
    a *reader* for gating a privileged config write). ``None`` when neither is set:
    the caller treats "no token configured" as "refuse the gated write".
    """
    env = os.environ.get("DT_WEB_TOKEN")
    if env and env.strip():
        return env.strip()
    from core.instance import secrets_path  # PERSONAL-1: DT_SECRETS_DIR экземпляра

    token_file = secrets_path() / "web_token"
    try:
        existing = token_file.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    return existing or None


def user_display_name(vault_path: Path | None = None) -> str:
    """Name of the digital-twin owner, injected into the ``[System]`` line.

    PROFILE-1 priority: ``owner.yaml`` ``name`` in the vault profile
    (``_system/profile/``) > ``DT_USER_NAME`` (legacy supplement) > the neutral
    placeholder ``the user``, so the prompt is well-formed even when nothing is set.
    ``vault_path`` selects the vault whose profile is read (default: ``DT_VAULT_PATH``).
    """
    from core.owner import load_profile

    return (
        load_profile(vault_path).name
        or os.environ.get("DT_USER_NAME")
        or "the user"
    )
