"""Vault-relative paths and runtime source-resolver config (CODE-1).

Split verbatim out of the pre-split ``core/config.py``. Imports only the roots
from :mod:`core.config._roots` (leaf→root, no cycles); stdlib otherwise.
"""

from __future__ import annotations

import os
from pathlib import Path

from ._roots import WORKSPACE_ROOT, derived_root

__all__ = [
    "default_vault_path",
    "vault_system_path",
    "retrieval_policies_path",
    "style_guides_path",
    "ai_markers_path",
    "templates_path",
    "outputs_path",
    "staging_inbox_path",
    "ingest_roots_path",
    "folder_aliases_path",
    "file_ingest_manifest_path",
    "ingest_materialize_timeout",
    "icloud_download_s",
    "sources_cache_path",
    "sources_cell_cap",
]


def default_vault_path() -> Path:
    """Default vault location (sibling of engine/). Override with ``DT_VAULT_PATH``."""
    override = os.environ.get("DT_VAULT_PATH")
    if override:
        return Path(override)
    return WORKSPACE_ROOT / "vault"


def vault_system_path(vault_path: Path | None = None) -> Path:
    """The vault ``_system/`` dir (config the engine reads but does not index)."""
    return (vault_path or default_vault_path()) / "_system"


def retrieval_policies_path(vault_path: Path | None = None) -> Path:
    """Dir holding per-use-case retrieval policies (``_system/retrieval-policies/``)."""
    return vault_system_path(vault_path) / "retrieval-policies"


def style_guides_path(vault_path: Path | None = None) -> Path:
    """Dir holding per-genre style guides (``_system/style-guides/``)."""
    return vault_system_path(vault_path) / "style-guides"


def ai_markers_path(vault_path: Path | None = None) -> Path:
    """Канон ИИ-маркеров (``_system/style-guides/ai-markers.yaml``, STYLE-GUARD-1).

    Человекочитаемый + версионируемый, рядом с гайдами жанров: три уровня жёсткости
    (запрет / плотность / кальки) и флаги паттерн-детекторов. Пополняется как
    заметка — увидел новый маркер, добавил строку, — поэтому пороги и списки живут
    ЗДЕСЬ, а не в коде (см. :mod:`core.style_markers`). Отсутствует/бит → проверка
    не выполняется и говорит об этом конвертом ``store_unavailable``, а не молча.
    Переопределяется ``DT_AI_MARKERS_PATH`` (тесты / отдельный канон на машину).
    """
    override = os.environ.get("DT_AI_MARKERS_PATH")
    if override:
        return Path(override)
    return style_guides_path(vault_path) / "ai-markers.yaml"


def templates_path(vault_path: Path | None = None) -> Path:
    """Dir holding output templates (``06-templates/``)."""
    return (vault_path or default_vault_path()) / "06-templates"


def outputs_path(vault_path: Path | None = None) -> Path:
    """Dir where generated artifacts + provenance are written (``07-outputs/``)."""
    return (vault_path or default_vault_path()) / "07-outputs"


def staging_inbox_path(vault_path: Path | None = None) -> Path:
    """Inbox buffer for quick-capture notes (``_staging/inbox/``, §3, §4).

    PERSONAL-2: у личного экземпляра путь - ``DT_PERSONAL_INBOX`` (от корня vault); у рабочего и без
    ручки - прежний ``_staging/inbox``."""
    root = vault_path or default_vault_path()
    from core import instance

    if instance.is_personal():
        return root / instance.personal_inbox()
    return root / "_staging" / "inbox"


def mail_filter_path(vault_path: Path | None = None) -> Path:
    """Правила фильтра почты (``_system/mail-filter.yaml``, MAIL-FILTER-1).

    Данные, а не код: ``senders`` / ``subject_prefix`` / ``subject_regex`` / ``senders_weak`` +
    ``subject_word`` / ``allow`` (:mod:`core.legacy.mail_filter`). Нет файла - работает запасной
    набор из кода. Не в ``__all__`` (замороженная поверхность): импорт явный, как у ``mail_*``.
    """
    return vault_system_path(vault_path) / "mail-filter.yaml"


def pult_settings_path(vault_path: Path | None = None) -> Path:
    """Настройки пульта (``_system/pult.yaml``, PULT-STANDALONE-1): раздел ``ai`` (слой синтезов).

    Данные, а не код (:mod:`core.operational.ai_layer`): провайдер, url, модель, лимиты. Ключа
    здесь НЕТ (только файл в ``.secrets/``). Нет файла - дефолты (``provider: none``). Не в
    ``__all__`` (замороженная поверхность): импорт явный, как у ``mail_filter_path``.
    Переопределяется ``DT_PULT_SETTINGS_PATH`` (тесты / отдельный файл на машину).
    """
    override = os.environ.get("DT_PULT_SETTINGS_PATH")
    if override:
        return Path(override)
    return vault_system_path(vault_path) / "pult.yaml"


def freshness_markers_path(vault_path: Path | None = None) -> Path:
    """Маркеры черновика/архива в именах файлов и папок (``_system/freshness-markers.yaml``).

    FIND-LATEST-1: данные, а не код (:mod:`core.sources.markers`); нет файла - работает запасной
    набор из кода. Не в ``__all__`` (замороженная поверхность): импорт явный, как у
    ``mail_filter_path``.
    """
    return vault_system_path(vault_path) / "freshness-markers.yaml"


def ingest_roots_path(vault_path: Path | None = None) -> Path:
    """Declarative watched-roots config for the file ingest (``ingest-roots.yaml``).

    Human-readable + versioned, under ``_system/`` (INGEST-1). Lists the folders the
    ingest watches with their route (knowledge|operational), include/exclude globs
    and optional hints. Absolute paths are resolved per-device (see
    :func:`core.file_ingest.config.load_ingest_roots`). Absent/empty → the ingest is a
    no-op (never crashes).
    """
    return vault_system_path(vault_path) / "ingest-roots.yaml"


def folder_aliases_path(vault_path: Path | None = None) -> Path:
    """Реестр алиасов рабочих папок (``_system/folder-aliases.yaml``, ФТ-2 / FT-12).

    Человекочитаемый + версионируемый, рядом с ``ingest-roots.yaml``: алиас →
    ``{root_name, rel_path}``. Пути в хранилище разнородны по написанию
    (``Kazakhstan/Globex`` латиницей, ``Russia/Подводные технологии``
    кириллицей) — алиас сворачивает адресацию папки в один короткий токен
    («положи в ЦОД»). Отсутствует/пуст → реестр пуст (никогда не падает); см.
    :mod:`core.file_ingest.aliases`.
    """
    return vault_system_path(vault_path) / "folder-aliases.yaml"


def file_ingest_manifest_path() -> Path:
    """File-ingest manifest (``.derived/file_ingest_manifest.json``, INGEST-1).

    Keyed by **content_hash** (not path/mtime — cross-device iCloud) → processed
    file record, so a re-scan skips what is unchanged and resumes after an
    interruption. Same ``.derived/*_manifest.json`` convention as legacy/outlook/
    index. Per-machine, untracked, rebuildable. Override with
    ``DT_FILE_INGEST_MANIFEST_PATH``.
    """
    override = os.environ.get("DT_FILE_INGEST_MANIFEST_PATH")
    if override:
        return Path(override)
    return derived_root() / "file_ingest_manifest.json"


def ingest_materialize_timeout() -> float:
    """Seconds to wait for an iCloud dataless file to materialize (INGEST-1 PART-0).

    On a dataless hit the scan requests ``brctl download`` and polls until the file
    has real bytes; past this budget the file is marked ``pending_download`` and
    skipped (retried next pass) rather than read (which would block) or crash.
    Override with ``DT_INGEST_MATERIALIZE_TIMEOUT`` (default 20.0); non-positive /
    non-numeric falls back to the default.
    """
    raw = os.environ.get("DT_INGEST_MATERIALIZE_TIMEOUT")
    if raw and raw.strip():
        try:
            value = float(raw.strip())
        except ValueError:
            return 20.0
        if value > 0:
            return value
    return 20.0


def icloud_download_s() -> float:
    """Ожидание точечного ``brctl download`` при подъеме источника, с (SRC-ICLOUD-1).

    ``DT_ICLOUD_DOWNLOAD_S`` (по умолчанию 20); не число / неположительное - значение по умолчанию.
    Не скачалось за срок - ``status: not_local`` с конвертом ``source_not_local``.
    """
    raw = os.environ.get("DT_ICLOUD_DOWNLOAD_S")
    if raw and raw.strip():
        try:
            value = float(raw.strip())
        except ValueError:
            return 20.0
        if value > 0:
            return value
    return 20.0


# --------------------------------------------------------------------------- #
# Runtime source-resolver config (SRC-1, Facts Plane, architecture §10a)       #
# --------------------------------------------------------------------------- #


def sources_cache_path() -> Path:
    """Runtime source-lift cache dir (``.derived/sources/``, SRC-1).

    Holds one ``<content_hash>.json`` per lifted source (structural tables + text
    + metadata) keyed by the file's **content hash** — NOT its path or mtime (a
    path migrates, mtime lies after a linking wave), so a re-lift of unchanged
    bytes is a cache hit even after the file moved, and any content change is a
    fresh hash → automatic re-read. A ``index.json`` registry sits beside the
    records (path·hash·mtime·size·kind·last_lift·status·note_refs). Distinct from
    the offline legacy extraction cache (:func:`legacy_extracted_path`, keyed by
    ``sha256(source_path)`` + mtime/size). Per-machine, untracked, rebuildable.
    Override with ``DT_SOURCES_CACHE_PATH``.
    """
    override = os.environ.get("DT_SOURCES_CACHE_PATH")
    if override:
        return Path(override)
    return derived_root() / "sources"


def sources_cell_cap() -> int:
    """Max non-empty cells lifted per worksheet by the SRC-1 resolver (default 50000).

    The runtime structural lift keeps cell coordinates (``sheet!ref``) and so is
    far richer than the legacy flattening extractor — its cap is deliberately much
    higher than :func:`legacy_xlsx_cell_cap` (2000). Rows past the cap are dropped
    and the result is flagged ``truncated``. Override with ``DT_SOURCE_CELL_CAP``;
    a non-positive or non-numeric value falls back to the default.
    """
    raw = os.environ.get("DT_SOURCE_CELL_CAP")
    if raw and raw.strip().lstrip("-").isdigit():
        value = int(raw.strip())
        if value > 0:
            return value
    return 50000
