"""Единственный писатель ``engine/.env`` (CONFIG-1 п.2): байт-точная правка ОДНОГО ключа.

Что гарантируется (тесты ``tests/test_config_env_file.py`` на копии боевого ``.env`` с
комментариями и пустыми строками):

* меняется ровно одна строка ``KEY=…`` (последнее вхождение - его читает dotenv); префикс
  ``export``, пробелы вокруг ``=``, хвостовой комментарий и окончание строки (LF/CRLF) сохраняются,
  остальные байты файла не затрагиваются; нет ключа - строка дописывается в конец;
* изменение значения - бэкап ``<файл>.bak-<YYYYmmddTHHMMSS>`` рядом (права 600), затем атомарная
  замена; **повтор с тем же значением файл не трогает вовсе** (ни бэкапа, ни записи);
* права файла после записи - 600 (секреты в plaintext читает только владелец);
* значение НИГДЕ не печатается и не логируется: результат правки несёт имя ключа, действие и путь
  бэкапа, но не значения.

Модуль - только stdlib (лист пакета ``core.config``): им пользуются ``dt config set/init``,
``dt client join`` и запись путей из пульта (``core.operational.storage``).

PERSONAL-1 п.1: :func:`load_env_layers` - ЕДИНСТВЕННАЯ точка загрузки env процесса (демон, CLI,
``cli._env``). Слои: реальное окружение > ``engine/instances/<DT_INSTANCE>.env`` (оверлей
экземпляра) > ``engine/.env``. Без ``DT_INSTANCE`` загружается один ``.env``, как и раньше.
Писатель ``.env`` по-прежнему один (:func:`set_key`); оверлей экземпляра пишет только
``dt instance add`` (:mod:`core.instance_admin`) целиком через :func:`write_new`.
"""

from __future__ import annotations

import os
import re
import stat
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

__all__ = [
    "INSTANCE_ENV",
    "EnvEdit",
    "EnvFileError",
    "backup_file",
    "format_value",
    "instance_overlay_path",
    "load_env_layers",
    "valid_instance_name",
    "read_keys",
    "read_value",
    "replace_lines",
    "set_key",
    "unset_key",
    "write_new",
]

_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_PLAIN_RE = re.compile(r"^[A-Za-z0-9_./:@%+,=~-]*$")  # значение, которое можно писать без кавычек
_LINE_RE = re.compile(
    rb"^(?P<lead>[ \t]*(?:export[ \t]+)?)(?P<key>[A-Za-z_][A-Za-z0-9_]*)"
    rb"(?P<eq>[ \t]*=[ \t]*)(?P<rest>.*?)(?P<eol>\r?\n?)$",
    re.DOTALL,
)


INSTANCE_ENV = "DT_INSTANCE"
_INSTANCE_RE = re.compile(r"^[a-z][a-z0-9-]{0,31}$")
_ENGINE_DIR = Path(__file__).resolve().parents[2]  # engine/core/config/env_file.py → engine/


class EnvFileError(ValueError):
    """Недопустимый ключ/значение для правки ``.env``."""


@dataclass(frozen=True)
class EnvEdit:
    """Итог правки: без значений (их нельзя светить)."""

    key: str
    action: str  # replaced | added | unchanged | created | removed
    path: Path
    backup: Path | None = None

    @property
    def changed(self) -> bool:
        return self.action != "unchanged"


def format_value(value: str) -> str:
    """Значение в виде, пригодном для dotenv: простое - как есть, иначе в двойных кавычках."""
    if "\n" in value or "\r" in value or "\x00" in value:
        raise EnvFileError("значение не может содержать перевод строки или NUL")
    if _PLAIN_RE.fullmatch(value):
        return value
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _split_rest(rest: bytes) -> tuple[bytes, bytes]:
    """``rest`` строки после ``=`` → (значение, хвост). Хвост - комментарий вместе с пробелами."""
    stripped = rest.lstrip()
    if stripped[:1] in (b'"', b"'"):
        quote = stripped[:1]
        i = 1
        while i < len(stripped):
            if quote == b'"' and stripped[i : i + 1] == b"\\":
                i += 2
                continue
            if stripped[i : i + 1] == quote:
                return stripped[: i + 1], stripped[i + 1 :]
            i += 1
        return stripped, b""
    m = re.search(rb"[ \t]+#", stripped)
    if m:
        return stripped[: m.start()], stripped[m.start() :]
    return stripped.rstrip(), stripped[len(stripped.rstrip()) :]


def _lines(raw: bytes) -> list[bytes]:
    return raw.splitlines(keepends=True)


def _match_key(line: bytes, key: bytes) -> re.Match[bytes] | None:
    if line.lstrip().startswith(b"#"):
        return None
    m = _LINE_RE.match(line)
    return m if m is not None and m.group("key") == key else None


def read_keys(path: Path) -> list[str]:
    """Ключи ``.env`` по порядку (с повторами), без комментариев. Значения не читаются наружу."""
    try:
        raw = Path(path).read_bytes()
    except OSError:
        return []
    keys: list[str] = []
    for line in _lines(raw):
        if line.lstrip().startswith(b"#") or not line.strip():
            continue
        m = _LINE_RE.match(line)
        if m is not None:
            keys.append(m.group("key").decode("utf-8", "replace"))
    return keys


def read_value(path: Path, key: str) -> str | None:
    """Значение ключа из файла (последнее вхождение; кавычки сняты) или ``None``."""
    try:
        raw = Path(path).read_bytes()
    except OSError:
        return None
    found: str | None = None
    for line in _lines(raw):
        m = _match_key(line, key.encode())
        if m is None:
            continue
        value, _tail = _split_rest(m.group("rest"))
        text = value.decode("utf-8", "replace")
        if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
            body = text[1:-1]
            text = body.replace('\\"', '"').replace("\\\\", "\\") if text[0] == '"' else body
        found = text
    return found


def backup_file(path: Path, now: float | None = None) -> Path:
    """Копия ``<файл>.bak-<YYYYmmddTHHMMSS>`` рядом (права 600; при коллизии - ``-1``, ``-2``…)."""
    path = Path(path)
    stamp = time.strftime("%Y%m%dT%H%M%S", time.localtime(now if now is not None else time.time()))
    target = path.with_name(f"{path.name}.bak-{stamp}")
    n = 0
    while target.exists():
        n += 1
        target = path.with_name(f"{path.name}.bak-{stamp}-{n}")
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(path.read_bytes())
    os.chmod(target, 0o600)
    return target


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def set_key(path: Path, key: str, value: str, *, now: float | None = None) -> EnvEdit:
    """Выставить ``key=value`` в ``.env``: заменить последнее вхождение или дописать в конец."""
    path = Path(path)
    if not _KEY_RE.fullmatch(key):
        raise EnvFileError(f"недопустимое имя ключа: {key!r}")
    new_value = format_value(value).encode("utf-8")
    kb = key.encode()

    if not path.exists():
        _atomic_write(path, kb + b"=" + new_value + b"\n")
        return EnvEdit(key, "created", path)

    original = path.read_bytes()
    lines = _lines(original)
    idx = None
    for i, line in enumerate(lines):
        if _match_key(line, kb) is not None:
            idx = i  # последнее вхождение - его и читает dotenv
    if idx is None:
        out = original
        if out and not out.endswith(b"\n"):
            out += b"\n"
        out += kb + b"=" + new_value + b"\n"
        action = "added"
    else:
        m = _match_key(lines[idx], kb)
        if m is None:  # недостижимо: idx найден тем же _match_key
            raise AssertionError(key)
        _old, tail = _split_rest(m.group("rest"))
        rebuilt = m.group("lead") + kb + m.group("eq") + new_value + tail + m.group("eol")
        if rebuilt == lines[idx]:
            return EnvEdit(key, "unchanged", path)
        lines[idx] = rebuilt
        out = b"".join(lines)
        action = "replaced"

    bak = backup_file(path, now)
    _atomic_write(path, out)
    return EnvEdit(key, action, path, bak)


def unset_key(path: Path, key: str, *, now: float | None = None) -> EnvEdit:
    """Убрать ключ из файла (все вхождения): слой больше его не задает и значение приходит из слоя
    ниже (оверлей экземпляра -> ``.env``). Нет файла/ключа - ``unchanged``; иначе копия и атомарная
    запись, как у :func:`set_key`."""
    path = Path(path)
    if not _KEY_RE.fullmatch(key):
        raise EnvFileError(f"недопустимое имя ключа: {key!r}")
    if not path.exists():
        return EnvEdit(key, "unchanged", path)
    original = path.read_bytes()
    kb = key.encode()
    kept = [line for line in _lines(original) if _match_key(line, kb) is None]
    out = b"".join(kept)
    if out == original:
        return EnvEdit(key, "unchanged", path)
    bak = backup_file(path, now)
    _atomic_write(path, out)
    return EnvEdit(key, "removed", path, bak)


def replace_lines(
    path: Path, mapper: Callable[[str, bytes], bytes | None], *, now: float | None = None
) -> EnvEdit:
    """Заменить строки ``KEY=…`` (комментарии не трогаем) на ``mapper(key, line)``.

    ``mapper`` возвращает новую строку (с её окончанием) либо ``None`` - оставить как есть. Одна
    атомарная запись и один бэкап на весь проход; ничего не изменилось - файл не трогается. Для
    пакетных правок (``dt_secrets --prune`` вырезает значения секретов, оставляя маркер)."""
    path = Path(path)
    original = path.read_bytes()
    out: list[bytes] = []
    for line in _lines(original):
        new = None
        if not line.lstrip().startswith(b"#"):
            m = _LINE_RE.match(line)
            if m is not None:
                new = mapper(m.group("key").decode("utf-8", "replace"), line)
        out.append(line if new is None else new)
    data = b"".join(out)
    if data == original:
        return EnvEdit(path.name, "unchanged", path)
    bak = backup_file(path, now)
    _atomic_write(path, data)
    return EnvEdit(path.name, "replaced", path, bak)


def write_new(
    path: Path, text: str, *, overwrite: bool = False, now: float | None = None
) -> EnvEdit:
    """Создать ``.env`` целиком (``dt config init``); существующий - ``overwrite`` + бэкап."""
    path = Path(path)
    data = text.encode("utf-8")
    if path.exists():
        if not overwrite:
            raise EnvFileError(f"{path} уже есть (перезапись - только явно, с бэкапом)")
        if path.read_bytes() == data:
            return EnvEdit(path.name, "unchanged", path)
        bak = backup_file(path, now)
        _atomic_write(path, data)
        return EnvEdit(path.name, "replaced", path, bak)
    _atomic_write(path, data)
    return EnvEdit(path.name, "created", path)


def mode_of(path: Path) -> int | None:
    try:
        return stat.S_IMODE(Path(path).stat().st_mode)
    except OSError:
        return None


# --------------------------------------------------------------------------- #
# PERSONAL-1 п.1 - слои env: оверлей экземпляра поверх .env                     #
# --------------------------------------------------------------------------- #
def valid_instance_name(name: str) -> bool:
    """Имя экземпляра: строчные латиница/цифры/дефис, с буквы, до 32 символов (идет в метку launchd
    и в имя файла оверлея - никаких путей и пробелов)."""
    return bool(_INSTANCE_RE.fullmatch(name or ""))


def instance_overlay_path(name: str, instances_dir: Path | None = None) -> Path:
    """``engine/instances/<имя>.env`` (``instances_dir`` - для тестов и ``dt instance add``)."""
    if not valid_instance_name(name):
        raise EnvFileError(f"недопустимое имя экземпляра: {name!r} (a-z, 0-9, дефис; с буквы)")
    base = Path(instances_dir) if instances_dir is not None else _ENGINE_DIR / "instances"
    return base / f"{name}.env"


def load_env_layers(
    env_path: Path | None = None,
    *,
    instance: str | None = None,
    instances_dir: Path | None = None,
) -> list[Path]:
    """Загрузить env процесса слоями; вернуть реально прочитанные файлы (оверлей, затем ``.env``).

    Приоритет: реальное окружение > оверлей экземпляра > ``.env``. Ни один слой не перекрывает уже
    выставленное (``override=False`` у dotenv), поэтому оверлей грузится ПЕРВЫМ. ``instance`` по
    умолчанию - ``DT_INSTANCE`` окружения (его ставит plist; из ``.env`` оно НЕ читается).

    Названный экземпляр без оверлея - ошибка (:class:`EnvFileError`), а не тихий откат на ``.env``:
    личный джоб, запущенный без своего оверлея, работал бы на рабочем vault. Без экземпляра -
    ровно прежняя загрузка одного ``.env`` (байт в байт)."""
    from dotenv import load_dotenv

    chosen = (instance if instance is not None else os.environ.get(INSTANCE_ENV) or "").strip()
    loaded: list[Path] = []
    if chosen:
        overlay = instance_overlay_path(chosen, instances_dir)
        if not overlay.is_file():
            raise EnvFileError(
                f"экземпляр {chosen!r}: нет оверлея {overlay} (dt instance add {chosen} …)")
        load_dotenv(overlay)
        loaded.append(overlay)
    path = Path(env_path) if env_path is not None else _ENGINE_DIR / ".env"
    load_dotenv(path)
    if path.is_file():
        loaded.append(path)
    return loaded
