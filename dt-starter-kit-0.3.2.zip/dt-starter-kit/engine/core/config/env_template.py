"""Шаблон ``ops/env.template`` из реестра настроек (CONFIG-1 п.3): артефакт сборки, не рукопись.

``render()`` строит текст шаблона: обязательные ключи - пустой строкой (``KEY=``), остальные -
закомментированными с типом, дефолтом и ``doc`` из реестра. ``scripts/gen_env_template.py`` кладёт
его в ``ops/env.template``; гард ``tests/test_config_knobs.py`` требует, чтобы файл побайтно
совпадал с
``render()`` (новое имя в реестре без перегенерации шаблона - красный тест). ``dt config init``
создаёт ``.env`` из этого шаблона для второй машины (инсталлер DEV-3, сервер).
"""

from __future__ import annotations

import re

from .knobs import KNOBS, Knob

__all__ = ["TEMPLATE_REL", "render", "template_names"]

TEMPLATE_REL = "ops/env.template"

_HEADER = """\
# Конфиг движка DT на ЭТОЙ машине: пути, устройство эмбеддера, порт, режим, токены.
# Создан `dt config init` из реестра настроек (core/config/knobs.py); ops/env.template - артефакт
# сборки (`uv run python scripts/gen_env_template.py`), руками не правится.
#
# Правило «один конфиг»: здесь - настройки и секреты ЭТОЙ машины; настройки vault живут в
# vault/_system/*.yaml и едут вместе с vault; конфиги хостов производные (`dt host-config`);
# плисты launchd настроек не несут. Менять ключи - `dt config set KEY VALUE` (бэкап + права 600).
#
# Строка без «#» - задана; закомментированная показывает дефолт движка. Права файла - 600,
# в git не попадает (.gitignore). Проверка: `dt config check`; значения: `dt config show`.
"""

_NETWORK = ("DT_MODE", "DT_SERVER_URL", "DT_WEB_PORT", "DT_TAILSCALE_BIN")


def _line(k: Knob) -> list[str]:
    meta = k.type if k.default is None else f"{k.type}, по умолчанию {k.default}"
    if k.legacy:
        meta += "; legacy: источник - профиль владельца (dt owner init), ключ - добавка"
    out = [f"# {k.doc} [{meta}]"]
    if k.required:
        out.append(f"{k.name}=")
    elif k.is_secret:
        out.append(f"# {k.name}=")
    else:
        out.append(f"# {k.name}={k.default if k.default is not None else ''}")
    return out


def _section(title: str, items: list[Knob]) -> list[str]:
    if not items:
        return []
    out = ["", f"# --- {title} " + "-" * max(3, 70 - len(title))]
    for k in items:
        out.extend(_line(k))
    return out


def render() -> str:
    """Текст ``ops/env.template`` по реестру (scope engine/vault/host; test и deprecated - нет)."""
    live = [k for k in KNOBS if k.scope in ("engine", "vault", "host")]
    taken: set[str] = set()

    def pick(pred) -> list[Knob]:
        got = [k for k in live if k.name not in taken and pred(k)]
        taken.update(k.name for k in got)
        return sorted(got, key=lambda k: k.name)

    required = pick(lambda k: k.required)
    network = [k for n in _NETWORK for k in live if k.name == n and k.name not in taken]
    taken.update(k.name for k in network)
    secrets_ = pick(lambda k: k.is_secret)
    paths = pick(lambda k: k.type == "path" and k.scope != "host")
    host = pick(lambda k: k.scope == "host")
    rest = pick(lambda k: True)

    lines = _HEADER.rstrip("\n").split("\n")
    lines += _section("Обязательные (пусто = предупреждение dt config check)", required)
    lines += _section("Режим и сеть", network)
    lines += _section("Секреты (предпочтительно Keychain: dt_secrets --migrate)", secrets_)
    lines += _section("Пути (по умолчанию строятся от корня производных данных)", paths)
    lines += _section("Настройки движка", rest)
    lines += _section("Хосты (ставят dt host-config / dt plugin)", host)
    return "\n".join(lines) + "\n"


_NAME_LINE = re.compile(r"^#?\s*([A-Za-z_][A-Za-z0-9_]*)=")


def template_names(text: str) -> list[str]:
    """Имена ключей шаблона: строки ``KEY=…`` и ``# KEY=…`` (комментарии-пояснения пропускаются)."""
    names = []
    for line in text.splitlines():
        m = _NAME_LINE.match(line)
        if m and (m.group(1).isupper() or "_" in m.group(1)):
            names.append(m.group(1))
    return names
