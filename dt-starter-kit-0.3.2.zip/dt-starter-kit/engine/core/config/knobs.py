"""Реестр настроек движка (CONFIG-1 п.1): каждое имя ``DT_*``, которое читает код, объявлено здесь.

Реестр ОПИСЫВАЕТ существующие имена и их дефолты - он ничего не переименовывает и не меняет
поведение: чтение по-прежнему идёт из ``os.environ`` в момент вызова (``load_env`` кладёт туда
``engine/.env``). Гард ``tests/test_config_knobs.py`` сверяет реестр со сканом кода
(``scripts/knobs_scan.py``): новая настройка без записи = красный тест, как allowlist ``.derived``.

Поля записи:

* ``type`` - ``str | int | float | bool | path | list | secret``. ``secret`` - значение никогда не
  печатается (только хвост 4 символа), см. :func:`mask`.
* ``default`` - значение по умолчанию В ВИДЕ СТРОКИ как его написали бы в ``.env``; ``None`` -
  «не задано» либо вычисляется (пути от ``derived_root()``/vault - см. ``doc``).
* ``scope`` - ``engine`` (настройка ЭТОЙ машины, живёт в ``.env``), ``vault`` (указывает в vault,
  вместе с ним переезжает), ``host`` (производная конфигов хостов, ставит ``dt host-config``/
  ``dt plugin``), ``test`` (песочница/фикстуры тестов, в боевой ``.env`` не нужна),
  ``deprecated`` (код не читает либо читает как старый синоним - ``check`` предупреждает),
  ``instance`` (PERSONAL-1: настройка ЭКЗЕМПЛЯРА - ставит оверлей ``engine/instances/<имя>.env`` или
  plist; в рабочем ``engine/.env`` ей не место - ``check`` предупреждает, шаблон ``.env`` её не
  несёт).
* ``where`` - модуль, где значение читается.
* ``required`` - пустое значение = предупреждение ``dt config check`` (кроме режима ``client``).
* ``declared_only`` - имя не встречается строковой константой в коде (плейсхолдер в yaml, наследие
  из SETUP.md и т.п.): гард «реестр ⊆ скан» его не требует.
* ``legacy`` - PROFILE-1: ключ остаётся рабочей ДОБАВКОЙ, но источник правды теперь профиль
  владельца в vault (``_system/profile``): ``dt config show`` и шаблон ``.env`` помечают такой ключ,
  ``dt config check`` предупреждает о дубле с профилем. Не ``deprecated``: код его читает, удалять
  нельзя.

Расширение: добавь запись в :data:`KNOBS` в алфавитном порядке своей группы, затем
``uv run python scripts/gen_env_template.py`` (шаблон ``ops/env.template`` - артефакт сборки).
"""

from __future__ import annotations

from dataclasses import dataclass

__all__ = [
    "KNOBS",
    "Knob",
    "SCOPES",
    "TYPES",
    "by_name",
    "mask",
    "names",
]

TYPES = ("str", "int", "float", "bool", "path", "list", "secret")
SCOPES = ("engine", "vault", "host", "test", "deprecated", "instance")


@dataclass(frozen=True)
class Knob:
    name: str
    type: str
    default: str | None
    scope: str
    where: str
    doc: str
    required: bool = False
    declared_only: bool = False
    legacy: bool = False

    @property
    def is_secret(self) -> bool:
        return self.type == "secret"


def _k(
    name: str, type_: str, default: str | None, scope: str, where: str, doc: str,
    *, required: bool = False, declared_only: bool = False, legacy: bool = False,
) -> Knob:
    return Knob(name, type_, default, scope, where, doc, required, declared_only, legacy)


# Сокращения ``where`` (повторяющиеся модули).
_ROOTS = "core/config/_roots.py"
_VAULT = "core/config/_vault.py"
_OPER = "core/config/_operational.py"
_OUTL = "core/config/_outlook.py"
_LEG = "core/config/_legacy.py"
_FIND = "core/retrieval/find.py"
_RERANK = "core/retrieval/rerank.py"
_INDEX = "core/retrieval/index.py"
_BRIDGE = "core/operational/outlook_bridge.py"
_DIAG = "core/diagnostics.py"

# --- секреты без префикса DT_ (Keychain или .env; core/secrets.py::SECRET_NAMES) -------------
_SECRETS = (
    _k("TICKTICK_ACCESS_TOKEN", "secret", None, "engine", "core/secrets.py",
       "токен TickTick Open API (Keychain ``dt:…`` или .env; миграция: dt_secrets --migrate)"),
    _k("TICKTICK_CLIENT_ID", "secret", None, "engine", "core/secrets.py",
       "client id приложения TickTick (OAuth-обмен токена)"),
    _k("TICKTICK_CLIENT_SECRET", "secret", None, "engine", "core/secrets.py",
       "client secret приложения TickTick (OAuth-обмен токена)"),
    _k("TIMETTA_API_TOKEN", "secret", None, "engine", "core/secrets.py",
       "токен Timetta API (только чтение; Keychain или .env)"),
)

# --- внешние библиотеки: движок выставляет их сам (setdefault), но владелец может переопределить --
_EXTERNAL = (
    _k("HF_HUB_DOWNLOAD_TIMEOUT", "int", "30", "engine", "core/embeddings.py",
       "таймаут скачивания модели HuggingFace, с (внешняя; движок ставит setdefault)"),
    _k("HF_HUB_ETAG_TIMEOUT", "int", "10", "engine", "core/embeddings.py",
       "таймаут проверки ETag модели HuggingFace, с (внешняя; движок ставит setdefault)"),
    _k("PYTORCH_ENABLE_MPS_FALLBACK", "bool", "1", "engine", "core/embeddings.py",
       "откат операций MPS на CPU (внешняя PyTorch; движок ставит setdefault)"),
)

# --- DT_*: пути (``*_PATH``/``*_DIR``): по умолчанию строятся от derived_root()/vault ----------
_PATHS = (
    _k("DT_AI_MARKERS_PATH", "path", None, "vault", _VAULT,
       "канон ИИ-маркеров; по умолчанию vault/_system/style-guides/ai-markers.yaml"),
    _k("DT_BACKUPS_PATH", "path", None, "engine", _ROOTS,
       "каталог недельных бэкапов; по умолчанию <derived>/backups"),
    _k("DT_CHUNK_SESSIONS_DIR", "path", None, "engine", _ROOTS,
       "каталог сессий кусочной загрузки store_file; по умолчанию <derived>/chunk-sessions"),
    _k("DT_CURRENT_INGEST_MANIFEST_PATH", "path", None, "engine", _LEG,
       "манифест инжеста корня current; по умолчанию <derived>/…"),
    _k("DT_DB_PATH", "path", None, "engine", _ROOTS,
       "единая БД dt.db; по умолчанию <derived>/dt.db"),
    _k("DT_DERIVED_ROOT", "path", None, "engine", _ROOTS,
       "корень производных данных (индекс, БД, логи); по умолчанию <workspace>/.derived"),
    _k("DT_EVAL_CANDIDATES_PATH", "path", None, "engine", _ROOTS,
       "кандидаты золотого набора eval; по умолчанию <derived>/eval/…"),
    _k("DT_EVAL_HISTORY_PATH", "path", None, "engine", _ROOTS,
       "история прогонов eval; по умолчанию <derived>/eval/history.jsonl"),
    _k("DT_EVAL_JOURNAL_PATH", "path", None, "engine", _ROOTS,
       "журнал запросов к поиску (queries.jsonl); по умолчанию <derived>/eval/…"),
    _k("DT_EVENTS_PATH", "path", None, "engine", _ROOTS,
       "сквозной журнал событий конвейера (events v2); по умолчанию <derived>/…"),
    _k("DT_FACTS_DB_PATH", "path", None, "engine", _ROOTS,
       "БД фактов; по умолчанию <derived>/…"),
    _k("DT_FACTS_MAX", "int", "200", "engine", "mcp-server/server.py",
       "потолок выдачи get_facts без явного limit, фактов (0 - без потолка); больше - конверт "
       "truncated"),
    _k("DT_FILE_INGEST_MANIFEST_PATH", "path", None, "engine", _VAULT,
       "манифест файлового инжеста; по умолчанию <derived>/…"),
    _k("DT_FM_CACHE_PATH", "path", None, "engine", "core/retrieval/fm_cache.py",
       "кэш frontmatter; по умолчанию <derived>/index/frontmatter.json"),
    _k("DT_HUB_ALIAS_CANDIDATES_PATH", "path", None, "engine", _ROOTS,
       "очередь кандидатов алиасов хабов; по умолчанию <derived>/…"),
    _k("DT_HUB_CANDIDATES_PATH", "path", None, "engine", _ROOTS,
       "очередь кандидатов хабов; по умолчанию <derived>/…"),
    _k("DT_INDEX_LOCK_PATH", "path", None, "engine", _ROOTS,
       "lock-файл индексации; по умолчанию <derived>/…"),
    _k("DT_INDEX_MANIFEST_PATH", "path", None, "engine", _ROOTS,
       "манифест индекса; по умолчанию <derived>/index/manifest.json"),
    _k("DT_INDEX_REPORT_PATH", "path", None, "engine", _ROOTS,
       "отчёт последнего reindex (для доктора); по умолчанию <derived>/…"),
    _k("DT_JOBS_DB_PATH", "path", None, "engine", _ROOTS,
       "БД заданий JOB-1; по умолчанию <derived>/…"),
    _k("DT_JOBS_DIR", "path", None, "engine", _ROOTS,
       "каталог заданий JOB-1; по умолчанию <derived>/jobs"),
    _k("DT_LANCEDB_PATH", "path", None, "engine", _ROOTS,
       "хранилище LanceDB; по умолчанию <derived>/lancedb"),
    _k("DT_LEGACY_DRYRUN_REPORT_PATH", "path", None, "engine", _LEG,
       "отчёт dry-run инжеста legacy; по умолчанию <derived>/…"),
    _k("DT_LEGACY_EXTRACTED_PATH", "path", None, "engine", _LEG,
       "каталог извлечённых текстов legacy; по умолчанию <derived>/…"),
    _k("DT_LEGACY_INGEST_MANIFEST_PATH", "path", None, "engine", _LEG,
       "манифест инжеста legacy; по умолчанию <derived>/…"),
    _k("DT_LIFT_MAX_CHARS", "int", "40000", "engine", "core/sources/cap.py",
       "потолок text в ответе lift_source без явного max_chars, символов (0 - без потолка); "
       "больше - усечение по границе строки + truncated/chars_total"),
    _k("DT_LINK_APPLIED_PATH", "path", None, "engine", _OPER,
       "журнал применённых связей; по умолчанию <derived>/…"),
    _k("DT_LINK_PROPOSALS_PATH", "path", None, "engine", _OPER,
       "очередь предложенных связей; по умолчанию <derived>/…"),
    _k("DT_LINK_SCAN_PATH", "path", None, "engine", _ROOTS,
       "манифест скана связей; по умолчанию <derived>/…"),
    _k("DT_LOGS_PATH", "path", None, "engine", _OPER,
       "каталог логов (dt-sync.log и др.); по умолчанию <derived>/logs"),
    _k("DT_MAIL_REFUSED_PATH", "path", None, "engine", _OUTL,
       "память отказанных писем (mail-filter); по умолчанию <derived>/…"),
    _k("DT_MEETINGS_CACHE_PATH", "path", None, "engine", _OPER,
       "кэш встреч календаря; по умолчанию <derived>/meetings/cache.json"),
    _k("DT_MODELS_PATH", "path", None, "engine", _ROOTS,
       "каталог моделей эмбеддера/реранкера; по умолчанию engine/models"),
    _k("DT_OPERATIONAL_PATH", "path", None, "engine", _OPER,
       "каталог операционных производных; по умолчанию <derived>/operational"),
    _k("DT_OUTLOOK_INGEST_MANIFEST_PATH", "path", None, "engine", _OUTL,
       "манифест инжеста почты Outlook; по умолчанию <derived>/…"),
    _k("DT_PULT_CARDS_TTL_S", "int", "600", "engine", "core/decisions/registry.py",
       "снимок выдачи видов hub/alias/link очереди (pult_cards), с; раньше - при правке сторов или "
       "каталога хабов (mtime), решение по карточке сбрасывает снимок"),
    _k("DT_PULT_DEALS_TTL_S", "int", "300", "engine", "core/operational/hub_link.py",
       "снимок pult_deals (пикер сделок), с: дольше - пересчет; раньше - при обновлении зеркала "
       "Timetta или связи хаба со сделкой"),
    _k("DT_PULT_DOCTOR_TTL_S", "int", "1800", "engine", "mcp-server/server.py",
       "снимок doctor() для пульта, с; refresh=True и ночной шаг doctor обновляют его сразу"),
    _k("DT_PULT_HTML_PATH", "path", None, "engine", _OPER,
       "явный файл HTML веб-пульта (иначе встроенный webpult/pult.html)"),
    _k("DT_PULT_STORAGE_TTL_S", "int", "900", "engine", "mcp-server/server.py",
       "снимок pult_storage_status (скан NDA-следов, статистика LanceDB), с"),
    _k("DT_PULT_MONITOR_TTL_S", "int", "60", "engine", "core/operational/monitor.py",
       "снимок блоков services и freshness в pult_monitor, с (launchctl/манифесты - не на показ)"),
    _k("DT_PULT_SETTINGS_PATH", "path", None, "vault", _VAULT,
       "файл настроек пульта; по умолчанию vault/_system/pult.yaml"),
    _k("DT_REATTR_PROPOSALS_PATH", "path", None, "engine", _OPER,
       "очередь предложений перепривязки заметок; по умолчанию <derived>/…"),
    _k("DT_SOURCES_CACHE_PATH", "path", None, "engine", _VAULT,
       "кэш резолвера источников; по умолчанию <derived>/sources"),
    _k("DT_STATUS_DIR", "path", None, "engine", _ROOTS,
       "каталог статус-файлов (маяки шагов); по умолчанию <derived>/status"),
    _k("DT_TICKTICK_STATE_PATH", "path", None, "engine", _OPER,
       "состояние коннектора TickTick; по умолчанию <derived>/ticktick"),
    _k("DT_TIMETTA_MIRROR_PATH", "path", None, "engine", _OPER,
       "зеркало Timetta; по умолчанию <derived>/timetta"),
    _k("DT_VAULT_PATH", "path", None, "vault", _VAULT,
       "корень vault; по умолчанию <workspace>/vault (рядом с engine/)"),
)

# --- экземпляры движка (PERSONAL-1): ставит оверлей/plist, в рабочем .env их нет ---------------
_INSTANCE = (
    _k("DT_BRIDGE_BUDGET_S", "int", "120", "instance", "core/bridge/scan.py",
       "бюджет шага bridge (bridge_scan) личного экземпляра, секунд; сверх - честный partial"),
    _k("DT_BRIDGE_LIMIT", "int", "5", "instance", "core/bridge/scan.py",
       "хитов find_notes рабочего контура на одну личную заметку в bridge_scan"),
    _k("DT_BRIDGE_MIN_SCORE", "float", "0.55", "instance", "core/bridge/scan.py",
       "порог оценки кандидата моста (шкала find_notes 0..1): ниже - карточка не создается"),
    _k("DT_BRIDGE_MIN_SCORE_FTS", "float", "0.75", "instance", "core/bridge/scan.py",
       "порог оценки для хита без семантики (чистый fts / fts+rerank): лексика на слабой оценке - "
       "самый частый источник случайных связок; общий DT_BRIDGE_MIN_SCORE остается нижней планкой"),
    _k("DT_BRIDGE_MIN_SCORE_LEGACY", "float", "0.8", "instance", "core/bridge/scan.py",
       "порог оценки для хитов легаси-корпуса рабочего (при DT_BRIDGE_WORK_CORPUS=both)"),
    _k("DT_BRIDGE_WORK_CORPUS", "str", "vault", "instance", "core/bridge/scan.py",
       "корпус рабочего поиска моста: vault (дефолт) | both (vault + легаси)"),
    _k("DT_BRIDGE_MIN_BODY_CHARS", "int", "120", "instance", "core/bridge/scan.py",
       "заметка короче (после срезки служебных строк шаблонов) - заглушка: не опрашивается"),
    _k("DT_BRIDGE_MIN_QUOTE_CHARS", "int", "200", "instance", "core/bridge/scan.py",
       "рабочая цитата короче: страница/служебный кусок и чистая семантика на ней пропускаются"),
    _k("DT_BRIDGE_SNOOZE_DAYS", "int", "30", "instance", "core/bridge/store.py",
       "стоп новой карточки bridge по паре заметок после отказа, дней"),
    _k("DT_BRIDGE_EXCLUDE", "list", "Templates/**", "instance", "core/instance.py",
       "заметки вне моста (glob от корня vault, через запятую): текст не уходит рабочему демону; "
       "пусто - без исключений"),
    _k("DT_INDEX_EXCLUDE", "list", "Templates/**,.smart-*/**,.trash/**", "instance",
       "core/instance.py",
       "заметки вне индекса ЛИЧНОГО экземпляра (glob от корня vault, через запятую)"),
    _k("DT_PERSONAL_CONTENT_DIRS", "list", None, "instance", "core/instance.py",
       "папки контента личного vault для подсказки размещения (Podcasts,Articles,Books)"),
    _k("DT_PERSONAL_IDEAS_DIR", "path", None, "instance", "core/instance.py",
       "папка идей личного vault: #личное → заметка идеи (по шаблону Idea); нет - в инбокс"),
    _k("DT_PERSONAL_UNTAGGED_LANE", "str", "skip", "instance", "core/instance.py",
       "полоса личного захвата для задач БЕЗ тега: skip (дефолт) | personal | journal | content; "
       "не-skip - только при отдельном списке TickTick личного (иначе same_project)"),
    _k("DT_PERSONAL_INBOX", "path", "_staging/inbox", "instance", "core/instance.py",
       "инбокс личного vault (от корня vault)"),
    _k("DT_PERSONAL_JOURNAL_DIR", "path", "05-journal", "instance", "core/instance.py",
       "папка дневника личного vault (заметка дня ГГГГ-ММ-ДД.md)"),
    _k("DT_EMBED_OWNER", "bool", "1", "instance", "core/instance.py",
       "владеет ли демон моделью эмбеддинга; 0 - не грузит, считает через DT_EMBED_URL (личный)"),
    _k("DT_EMBED_TOKEN", "secret", None, "instance", "core/web_tokens.py",
       "узкий токен соседа-эмбеддера (только /internal/embed); по умолчанию файл embed_token"),
    _k("DT_EMBED_URL", "str", None, "instance", "core/instance.py",
       "чей /internal/embed использовать (http://127.0.0.1:<порт> соседа); по умолчанию свой порт"),
    _k("DT_INSTANCE", "str", None, "instance", "core/config/env_file.py",
       "имя экземпляра движка; ставит plist/окружение (из .env не читается); выбирает "
       "engine/instances/<имя>.env поверх .env"),
    _k("DT_INSTANCE_ROLE", "str", "work", "instance", "core/instance.py",
       "роль экземпляра: work (по умолчанию) | personal (личный контур, мост, personal_recall)"),
    _k("DT_SECRETS_DIR", "path", None, "instance", "core/instance.py",
       "каталог секретов экземпляра (токены демона); по умолчанию <workspace>/.secrets"),
    _k("DT_WORK_TOKEN_FILE", "path", None, "instance", "core/instance.py",
       "файл токена ЧТЕНИЯ рабочего демона для моста личного экземпляра (никогда rw)"),
    _k("DT_WORK_URL", "str", None, "instance", "core/instance.py",
       "адрес рабочего демона для моста (http://127.0.0.1:8787); только у роли personal"),
)

# --- DT_*: прочее движка ----------------------------------------------------------------------
_ENGINE = (
    _k("DT_ADHOC_SOURCES_H", "float", "8.0", "engine", "core/provenance.py",
       "потолок окна сбора sources.md, ч: сессия не уходит дальше; без нее - «последние N ч»"),
    _k("DT_AI_MAX_CALLS_PER_HOUR", "int", "120", "engine", "core/operational/ai_gateway.py",
       "дефолт потолка вызовов LLM-синтезов в час на ПРОФИЛЬ "
       "(свой - profiles.<имя>.max_calls_per_hour)"),
    _k("DT_BAK_ROOTS", "list", "~/Claude/Artifacts/dt-pult", "engine", "core/bakprune.py",
       "каталоги, где ``dt backup prune-bak`` чистит ``*.bak-*`` (сверх engine/ и корня .derived); "
       "дефолт - каталог копии артефакта пульта"),
    _k("DT_BAK_WARN_COUNT", "int", "10", "engine", "core/bakprune.py",
       "доктор «Бэкапы .bak»: больше стольких ``*.bak-*`` в одном корне - warn"),
    _k("DT_PROV_LATE_BEGIN_MIN", "float", "3", "engine", "core/provenance.py",
       "минут: output_begin позже этого порога при более ранних событиях сессии - не начало "
       "работы, окно sources.md берется сегментом сессии (PROV-SESSION-1)"),
    _k("DT_VAULT_COMMIT_MAX_DAYS", "float", "7.0", "engine", "core/diagnostics.py",
       "доктор «Vault: git»: последний коммит vault старше стольких дней - warn"),
    _k("DT_VAULT_DIRTY_MAX", "int", "200", "engine", "core/diagnostics.py",
       "доктор «Vault: git»: незакоммиченных путей больше - warn"),
    _k("DT_BACKUP_KEEP", "int", "4", "engine", "core/backup.py",
       "сколько недельных архивов хранить"),
    _k("DT_BACKUP_WARN_DAYS", "float", "8.0", "engine", "core/backup.py",
       "возраст последнего бэкапа, после которого доктор предупреждает, дни"),
    _k("DT_CHUNK_CARD", "bool", "1", "engine", "core/chunking.py",
       "карточка документа в чанках (0 - выключить)"),
    _k("DT_CHUNK_CONTEXT_PREFIX", "str", "fts", "engine", "core/chunking.py",
       "контекстный префикс чанка: fts | 1 (+эмбеддинг) | 0 (нет)"),
    _k("DT_CHUNK_LIMIT", "int", "16384", "engine", "core/operational/store_chunked.py",
       "размер части кусочной загрузки store_file, байт"),
    _k("DT_CHUNK_MIN_SECTION_TOKENS", "int", "60", "engine", "core/chunking.py",
       "порог слияния мелких секций, токены (0 - слияние выключено)"),
    _k("DT_CHUNK_SESSION_TTL_H", "float", "24.0", "engine", "core/operational/store_chunked.py",
       "TTL незавершённой сессии кусочной загрузки, ч"),
    _k("DT_CONNECTORS", "str", "auto", "engine", "core/connectors.py",
       "внешние коннекторы: auto (включен, если есть его секрет/ручка) | none (базовый DT: без "
       "Timetta/TickTick/Outlook) | список timetta,ticktick,outlook (включены ровно они)"),
    _k("DT_CRM_ADMIN_EMAIL", "str", None, "engine", _OPER,
       "адрес администратора CRM - адресат карточки поручения"),
    _k("DT_DATE_SPREAD_MONTHS", "int", "12", "engine", _FIND,
       "порог разброса дат в выдаче поиска, месяцы"),
    _k("DT_DEADLINE_MAX", "int", "5", "engine", "core/operational/detectors.py",
       "максимум строк детектора дедлайнов"),
    _k("DT_DEADLINE_WARN_DAYS", "float", "7.0", "engine", "core/operational/detectors.py",
       "окно детектора дедлайнов, дни"),
    _k("DT_DEGRADATION_WARN_N", "int", "10", "engine", _DIAG,
       "порог числа деградаций инструмента для предупреждения доктора"),
    _k("DT_DOD_WINDOW_H", "float", "48.0", "engine", "core/operational/dod.py",
       "окно проверки «выходы доставлены в vault», ч"),
    _k("DT_DOWNLOADS_DIRS", "list", "~/Downloads", "engine", "core/operational/place_download.py",
       "каталоги загрузок для place_download (через двоеточие)"),
    _k("DT_EMBED_ALLOW_DOWNLOAD", "bool", "0", "engine", "core/embeddings.py",
       "разрешить скачивание модели эмбеддера (1 - да; иначе только готовая модель)"),
    _k("DT_EMBED_BATCH_SIZE", "int", None, "engine", "core/embeddings.py",
       "батч кодирования; по умолчанию 64 на mps/cuda, 32 на cpu"),
    _k("DT_EMBED_DAEMON_TIMEOUT_S", "float", "300.0", "engine", "core/embed_daemon.py",
       "таймаут запроса /internal/embed к демону, с (дольше - откат на локальную модель)"),
    _k("DT_EMBED_DEVICE", "str", None, "engine", "core/embeddings.py",
       "устройство эмбеддера: mps | cuda | cpu; по умолчанию авто"),
    _k("DT_EMBED_OOM_RETRIES", "int", "4", "engine", "core/embeddings.py",
       "повторы эмбеддинга при OOM с делением батча"),
    _k("DT_EMBED_VIA_DAEMON", "bool", "1", "engine", "core/embed_daemon.py",
       "плановые джобы считают вектора через демон (POST /internal/embed); 0 - своя копия модели"),
    _k("DT_EVAL_SESSION_H", "float", "2", "engine", "core/eval_quarantine.py",
       "окно, часов: доставка без папки выхода (place_download/store_file*) идет в _eval, если "
       "ПОСЛЕДНИЙ выход этого хоста в окне помечен eval/selftest (EVAL-HYGIENE-1)"),
    _k("DT_EVAL_QUERY_LOG", "bool", "1", "engine", "core/eval_journal.py",
       "журнал запросов поиска для золотого набора (0 - выключить)"),
    _k("DT_EVAL_RECORD", "bool", "0", "engine", "core/eval.py",
       "писать прогон eval в историю (1 - да; правило записи - только с ветки main)"),
    _k("DT_FIND_CANON_EXPAND", "bool", "1", "engine", _FIND,
       "расширение запроса канонами имён клиента"),
    _k("DT_FIND_FTS_EXPAND", "bool", "0", "engine", _FIND,
       "стем-варианты слов запроса в FTS (по замеру - шум, выкл)"),
    _k("DT_FIND_PIN", "bool", "1", "engine", _FIND,
       "нормализация клиента в поиске: пин + буст + расширение (0 - выкл)"),
    _k("DT_FIND_SEMANTIC_ALWAYS", "bool", "0", "engine", _RERANK,
       "семантическая ступень поиска всегда (по абляции - выкл)"),
    _k("DT_FIND_SEMANTIC_FLOOR", "int", "3", "engine", _FIND,
       "семантика подключается, если лексических хитов меньше порога"),
    _k("DT_HISTORY_DAYS", "int", "14", "engine", "core/operational/timetta/history.py",
       "глубина ленты изменений Timetta, дни"),
    _k("DT_HISTORY_FEED", "bool", "1", "engine", "core/operational/timetta/history.py",
       "лента изменений Timetta (0 - не сравнивать снапшоты)"),
    _k("DT_INBOX_WARN_COUNT", "int", "5", "engine", _DIAG,
       "порог числа заметок инбокса для предупреждения доктора"),
    _k("DT_INBOX_WARN_DAYS", "int", "7", "engine", _DIAG,
       "порог возраста заметки инбокса для предупреждения доктора, дни"),
    _k("DT_INDEX_ALLOW_CHUNKER_MISMATCH", "bool", "0", "engine", _INDEX,
       "разрешить инкремент при другой версии чанкера (1 - да; обычно нужен --full)"),
    _k("DT_INDEX_BATCH_SIZE", "int", "16", "engine", _INDEX, "батч заметок при индексации"),
    _k("DT_INDEX_CHECKPOINT_EVERY", "int", "50", "engine", _INDEX,
       "чекпойнт индексации каждые N заметок"),
    _k("DT_INDEX_EMBED_WATCHDOG_SECONDS", "float", "180", "engine", _INDEX,
       "сторож зависшего эмбеддинга, с (0 - выкл)"),
    _k("DT_INDEX_MAX_CHUNKS_PER_NOTE", "int", "120", "engine", _INDEX,
       "потолок чанков одной заметки"),
    _k("DT_INDEX_WINDOW_TOKENS", "int", "50000", "engine", _INDEX,
       "бюджет токенов окна индексации"),
    _k("DT_ICLOUD_DOWNLOAD_S", "float", "20.0", "engine", _VAULT,
       "ожидание точечного brctl download при подъеме источника, с (SRC-ICLOUD-1)"),
    _k("DT_INGEST_MATERIALIZE_TIMEOUT", "float", "20.0", "engine", _VAULT,
       "ожидание материализации dataless-файла iCloud, с"),
    _k("DT_INGEST_MAX_INTERRUPTED", "int", "3", "engine", "core/legacy/ingest.py",
       "сколько прерванных чтений терпит инжест до остановки"),
    _k("DT_INGEST_READ_TIMEOUT_S", "float", "300.0", "engine", "core/fsguard.py",
       "таймаут чтения/экстракции одного файла, с"),
    _k("DT_INGEST_SLEEP_GAP_S", "float", "30.0", "engine", "core/fsguard.py",
       "расхождение часов, считающееся сном машины, с"),
    _k("DT_LANCE_KEEP_H", "float", "24.0", "engine", "core/retrieval/lance_health.py",
       "сколько часов хранить версии LanceDB при optimize"),
    _k("DT_LANCE_WARN_VERSIONS", "int", "500", "engine", "core/retrieval/lance_health.py",
       "число версий LanceDB, с которого доктор предупреждает"),
    _k("DT_LINT_BUDGET_S", "float", "120.0", "engine", "core/lint/settings.py",
       "бюджет шага lint (ночная цепочка), с; не уложились - честный partial, цепочку не роняет"),
    _k("DT_LINT_DUP_SCORE", "float", "0.97", "engine", "core/lint/settings.py",
       "порог semantic-близости заметок (link_proposals) для duplicate, + похожие заголовки"),
    _k("DT_LINT_HUB_STALE_DAYS", "int", "60", "engine", "core/lint/settings.py",
       "через сколько дней без правок хаб проверяется правилом hub_stale (дельта >= 3)"),
    _k("DT_LINT_ORPHAN_DAYS", "int", "14", "engine", "core/lint/settings.py",
       "возраст заметки знаний без хаба, с которого она сирота (правило orphan), дней"),
    _k("DT_LINT_SNOOZE_DAYS", "int", "30", "engine", "core/lint/settings.py",
       "стоп находки линта после dismiss, дней"),
    _k("DT_LANCE_WARN_VERSIONS_GB", "float", "5.0", "engine", "core/retrieval/lance_health.py",
       "размер версий LanceDB, с которого доктор предупреждает, ГБ"),
    _k("DT_LEGACY_EXCLUDE_GLOBS", "list", None, "engine", _LEG,
       "JSON-массив: добавка к шумовым globs legacy"),
    _k("DT_LEGACY_PRIVACY_CONTRACT_TERMS", "list", None, "engine", _LEG,
       "JSON-массив: добавка к словарю договорных терминов приватности"),
    _k("DT_LEGACY_PRIVACY_GLOBS", "list", None, "engine", _LEG,
       "JSON-массив: добавка к globs путей, которые не индексируем"),
    _k("DT_LEGACY_PRIVACY_HR_FOLDERS", "list", None, "engine", _LEG,
       "JSON-массив: добавка к HR-папкам приватности"),
    _k("DT_LEGACY_PRIVACY_NAMES", "list", None, "engine", _LEG,
       "JSON-массив: имена-токены для проверки приватности"),
    _k("DT_LEGACY_PRIVACY_PERSON_SIGNALS", "list", None, "engine", _LEG,
       "JSON-массив: добавка к признакам персональных данных"),
    _k("DT_LEGACY_PRIVACY_SALARY_TERMS", "list", None, "engine", _LEG,
       "JSON-массив: добавка к зарплатным терминам приватности"),
    _k("DT_LEGACY_PRIVACY_WEAK_HR_TERMS", "list", None, "engine", _LEG,
       "JSON-массив: добавка к слабым HR-терминам приватности"),
    _k("DT_LEGACY_ROOTS", "list", None, "engine", _LEG,
       "корни legacy-корпуса для инжеста (через двоеточие); правит пульт paths_set"),
    _k("DT_LEGACY_SECTION_MAP", "str", None, "engine", _LEG,
       "JSON: добавка к карте секций legacy→vault"),
    _k("DT_LEGACY_XLSX_CELL_CAP", "int", "2000", "engine", _LEG,
       "потолок ячеек листа xlsx при инжесте legacy"),
    _k("DT_LINK_MIN_SCORE", "float", "0.55", "engine", "core/linking/candidates.py",
       "минимальный скор кандидата связи"),
    _k("DT_LINK_PRIORITY_BONUS", "float", "0.05", "engine", "core/linking/candidates.py",
       "бонус приоритетных целей связи"),
    _k("DT_LINK_QUIET_S", "float", "60.0", "engine", "core/linking/quiet.py",
       "окно тишины перед применением связей, с (0 - выкл)"),
    _k("DT_LINK_TOPN", "int", "8", "engine", "core/linking/candidates.py",
       "сколько кандидатов связи на заметку"),
    _k("DT_MAIL_A2_CONTEXT", "list", None, "engine", _OUTL,
       "JSON-массив: добавка к контексту A2 приватности почты (дефолт: гпх/оклад/зарплат/штат/"
       "кадр, БЕЗ голого «договор»; env только добавляет)"),
    _k("DT_MAIL_BATCH", "int", "300", "engine", _OUTL, "размер батча инжеста почты"),
    _k("DT_MAIL_CURSOR_OVERLAP_DAYS", "int", "14", "engine", _OUTL,
       "перекрытие курсора почты, дни: since папки = дата новейшего письма минус N (письма, "
       "пришедшие в локальный Outlook задним числом; 0 - без перекрытия)"),
    _k("DT_MAIL_GAP_MAX", "int", "5", "engine", _OUTL,
       "порог смоука С-13 «дыра курсора»: писем за 90 дн вне манифеста, больше - красный"),
    _k("DT_MAIL_LOCK_WAIT_S", "float", "600.0", "engine", "core/legacy/mail_lock.py",
       "сколько ждать занятый лок почты, с"),
    _k("DT_MAIL_META_PAGE", "int", "10000", "engine", _BRIDGE,
       "страница индексов при мета-чтении большой папки Outlook"),
    _k("DT_MAIL_META_SINGLE_MAX", "int", "60000", "engine", _BRIDGE,
       "потолок мета-чтения папки одним проходом"),
    _k("DT_MAIL_NOISE_MEETING", "list", None, "engine", _OUTL,
       "добавка к темам-шуму встреч (через запятую)"),
    _k("DT_MAIL_NOISE_SENDERS", "list", None, "engine", _OUTL,
       "добавка к отправителям-шуму (через запятую); основное - vault/_system/mail-filter.yaml"),
    _k("DT_MAIL_NOISE_SUBJECTS", "list", None, "engine", _OUTL,
       "добавка к темам-шуму (через запятую)"),
    _k("DT_MAIL_OWNER_DOMAINS", "list", None, "engine", _OUTL,
       "добавка к почтовым доменам владельца (основное - owner.yaml: emails + company.domains)"),
    _k("DT_MAIL_INTERNAL_DOMAINS", "list", None, "engine", _OUTL,
       "добавка к служебным доменам группы (основное - owner.yaml: company.internal_domains)"),
    _k("DT_MAIL_UNANSWERED_MIN_DAYS", "float", "3.0", "engine", "core/operational/work.py",
       "с какого возраста письмо без ответа попадает в «Работу», дни"),
    _k("DT_MCP_PARAM_LIMIT", "int", "10485760", "engine", "mcp-server/server.py",
       "потолок суммарного размера строковых аргументов вызова, байт"),
    _k("DT_MCP_PARAM_WARN", "int", "32768", "engine", "mcp-server/server.py",
       "размер аргументов, с которого вызов логируется warning, байт"),
    _k("DT_MCP_SLOW_WARN_S", "float", "30.0", "engine", "mcp-server/server.py",
       "вызов медленнее порога логируется warning, с"),
    _k("DT_MODE", "str", "local", "engine", "core/daemon.py",
       "режим машины: local (демон слушает свою машину) | server (/mcp открыт и по Tailscale) | "
       "client (демона нет, ходим на сервер по DT_SERVER_URL)"),
    _k("DT_MODEL_DOWNLOAD", "bool", "0", "engine", _RERANK,
       "разрешить скачивание моделей (реранкера; 1 - да)"),
    _k("DT_NDA_MARKERS", "list", "_nda", "engine", _LEG,
       "маркеры NDA в путях (через запятую); пути с маркером исключены везде"),
    _k("DT_NEWER_SIBLING_DAYS", "float", "30.0", "engine", "core/sources/freshness.py",
       "окно «есть более свежая версия-соседка», дни"),
    _k("DT_NIGHT_CHAIN_MAX_H", "float", "3.0", "engine", "core/nightchain.py",
       "порог общего времени ночного index-прогона, ч: дольше - warn доктора «Ночная цепочка»"),
    _k("DT_OCR_BUDGET_S", "float", "1800.0", "engine", "core/ocr/settings.py",
       "бюджет одного прогона OCR, с"),
    _k("DT_OCR_ENGINE", "str", "tesseract", "engine", "core/ocr/engine.py",
       "движок OCR: tesseract | vision (Apple Vision)"),
    _k("DT_OCR_LANGS", "str", "rus+eng", "engine", "core/ocr/engine.py",
       "языки распознавания (``+kaz`` - по желанию)"),
    _k("DT_OCR_MIN_CONF", "float", "0.6", "engine", "core/ocr/settings.py",
       "порог средней уверенности OCR 0..1; ниже - ``ocr: low``"),
    _k("DT_ORBIT_RINGS", "list", "mine,unit", "engine", "core/operational/orbit.py",
       "видимые кольца орбиты Timetta: mine,unit,group"),
    _k("DT_ORBIT_UNIT_ENTITIES", "list", None, "engine", "core/operational/orbit.py",
       "явная добавка к «моим юрлицам» (id/имена через запятую)"),
    _k("DT_ORPHAN_DAYS", "float", "7.0", "engine", "core/operational/detectors.py",
       "окно детектора «сирот» (заметки без хаба), дни"),
    _k("DT_ORPHAN_MAX", "int", "5", "engine", "core/operational/detectors.py",
       "максимум строк детектора «сирот»"),
    _k("DT_OUTLOOK_CALENDAR_EXCLUDE", "list", None, "engine", _BRIDGE,
       "календари Outlook, которые гасим (имена через запятую)"),
    _k("DT_OUTLOOK_FOLDERS", "list", None, "engine", _OUTL,
       "JSON: папки Outlook для инжеста (по умолчанию Inbox и Sent Items)"),
    _k("DT_OUTLOOK_INCLUDE_LOCAL_CALENDARS", "bool", "0", "engine", _BRIDGE,
       "отдавать события локальных календарей Outlook (папки без аккаунта)"),
    _k("DT_OUTLOOK_PREFLIGHT_TIMEOUT", "float", "20.0", "engine", _OUTL,
       "таймаут предполётной проверки моста Outlook, с"),
    _k("DT_OUTLOOK_PULL_WINDOW", "int", "365", "engine", _OUTL, "окно загрузки почты, дни"),
    _k("DT_OUTLOOK_READ_LIMIT", "int", "500", "engine", _OUTL,
       "сколько писем читать за один вызов моста"),
    _k("DT_OUTLOOK_SELF_TOKENS", "list", None, "engine", _OUTL,
       "JSON: токены личности владельца (фамилия одним словом, email), вычитаемые из пробы "
       "приватности почты; обязателен при включённой почте: пусто или битый JSON - фамилия "
       "владельца (она в списке приватных имён) режет его же письма; dt config check "
       "предупреждает; PROFILE-1: основной источник - owner.yaml профиля владельца "
       "(name_variants/emails), ключ - добавка", required=True, legacy=True),
    _k("DT_OUTLOOK_SLEEP_GAP_S", "float", "30.0", "engine", _BRIDGE,
       "порог «машина спала посреди вызова», с"),
    _k("DT_OUTLOOK_TIMEOUT", "float", "120.0", "engine", _OUTL, "таймаут вызова моста Outlook, с"),
    _k("DT_OUTPUT_DRAFT_WARN_H", "float", "24.0", "engine", "core/operational/dod.py",
       "сколько часов папка выхода может быть черновиком до предупреждения"),
    _k("DT_PANDOC_TIMEOUT_S", "float", "60.0", "engine", "core/operational/deliver_output.py",
       "бюджет одного вызова pandoc, с"),
    _k("DT_RERANK", "bool", "0", "engine", _RERANK,
       "cross-encoder реранкер вторым этапом find_notes (1 - вкл; решение К. 29.10: вкл)"),
    _k("DT_RERANK_ALPHA", "float", "0.7", "engine", _RERANK, "вес скора реранкера в итоговом"),
    _k("DT_RERANK_BODY_CHARS", "int", "800", "engine", _RERANK,
       "обрезка головы тела у скан-хита для реранкера, символы"),
    _k("DT_RERANK_CHUNK_CHARS", "int", "1200", "engine", _RERANK,
       "обрезка текста чанка в паре для реранкера, символы"),
    _k("DT_RERANK_DEVICE", "str", None, "engine", _RERANK,
       "устройство реранкера: mps | cuda | cpu; по умолчанию как у эмбеддера"),
    _k("DT_RERANK_MAX_LENGTH", "int", "512", "engine", _RERANK, "токенов на пару реранкера"),
    _k("DT_RERANK_MIN_TOKENS", "int", "2", "engine", _RERANK,
       "минимум значимых слов запроса для реранкера"),
    _k("DT_RERANK_POOL", "int", "15", "engine", _RERANK,
       "сколько верхних кандидатов слияния переоценивает реранкер"),
    _k("DT_RESURFACE_DAYS", "float", "7.0", "engine", "core/operational/resurface.py",
       "окно «свежая заметка» для всплытия старого, дни"),
    _k("DT_RESURFACE_OLD_DAYS", "float", "30.0", "engine", "core/operational/resurface.py",
       "с какого возраста цель считается старой для всплытия, дни"),
    _k("DT_RUN_SLEEP_MIN_S", "float", "120.0", "engine", "core/operational/runwatch.py",
       "минимальный сон машины, объясняющий молчание прогона, с"),
    _k("DT_RUN_STALL_MAX_H", "float", "36.0", "engine", "core/operational/runwatch.py",
       "жёсткий потолок «прогон завис», ч"),
    _k("DT_RUN_STALL_MIN", "float", "60.0", "engine", "core/runlock.py",
       "прогон без прогресса дольше порога считается зависшим, мин"),
    _k("DT_SOFFICE_BIN", "path", None, "engine", "core/legacy/extract/_base.py",
       "путь к soffice/libreoffice; по умолчанию из PATH"),
    _k("DT_SOFFICE_TIMEOUT", "int", "120", "engine", "core/legacy/extract/_base.py",
       "таймаут конвертации soffice, с"),
    _k("DT_SOURCE_CELL_CAP", "int", "50000", "engine", _VAULT,
       "потолок непустых ячеек листа при подъёме источника"),
    _k("DT_SELFTEST", "bool", "0", "engine", "core/purpose.py",
       "процесс - самопроверка: выходы получают purpose=selftest, доставка - в _eval "
       "(EVAL-HYGIENE-1; тестовые хосты shim-test/dt-spike-*/idle-test - и без нее)"),
    _k("DT_SERVER_URL", "str", None, "engine", "core/client.py",
       "режим client: адрес демона-сервера (http://<dns|ip>:8787); ставит dt client join"),
    _k("DT_STORE_FILE_MAX_BYTES", "int", "26214400", "engine", "core/operational/store_file.py",
       "потолок размера файла store_file, байт"),
    _k("DT_SYNTH_CONTEXT_CHARS", "int", "40000", "engine", "core/operational/hub_synth.py",
       "бюджет строк дельты в досье синтеза хаба (hub_synth_context), символов; урезание в limits"),
    _k("DT_SYNTH_MAX_CHARS", "int", "6000", "engine", "core/operational/hub_synth.py",
       "предел длины текста секции «Состояние» в hub_synth_propose, символов (иначе too_long)"),
    _k("DT_SYNTH_SNOOZE_DAYS", "int", "14", "engine", "core/operational/hub_synth.py",
       "стоп нового предложения синтеза по хабу после отказа в карточке, дней"),
    _k("DT_SYNTH_STALE_DAYS", "int", "60", "engine", "core/operational/hub_synth.py",
       "через сколько дней состояние хаба «просит сводку» (доктор «Синтез хабов»; дельта >= 3)"),
    _k("DT_TAILSCALE_BIN", "path", None, "engine", "core/tailscale.py",
       "бинарь tailscale для режима server; по умолчанию из PATH или приложение Tailscale"),
    _k("DT_TICKTICK_CAPTURE_PROJECT_ID", "str", None, "engine", _OPER,
       "id проекта TickTick «Захват» (предпочтительнее имени)"),
    _k("DT_TICKTICK_CAPTURE_PROJECT_NAME", "str", None, "engine", _OPER,
       "имя проекта TickTick «Захват» (если не задан id)"),
    _k("DT_TICKTICK_CLIENT_FOLDER_MAP", "str", None, "engine", _OPER,
       "JSON: карта клиент→папка TickTick (в норме не нужна: авто-папки B2d)"),
    _k("DT_TIMETTA_USER_EMAIL", "str", None, "engine", _OPER,
       "email владельца в Timetta (разовое определение user-id; орбита)", required=True),
    _k("DT_TIMETTA_USER_ID", "str", None, "engine", _OPER,
       "Guid владельца в Timetta (орбита «мои сделки»)", required=True),
    _k("DT_USER_NAME", "str", "the user", "engine", _ROOTS,
       "имя владельца для [System] промпта generate и токенов личности почты; PROFILE-1: "
       "основной источник - owner.yaml профиля владельца, ключ - добавка", legacy=True),
    _k("DT_WEB_PORT", "int", "8787", "engine", "core/daemon.py",
       "порт демона (веб-пульт и /mcp)"),
    _k("DT_XLSX_MERGE_MAX_MB", "float", "8.0", "engine", "core/sources/parsers.py",
       "потолок размера xlsx для разбора объединённых ячеек, МБ"),
    _k("DT_DAEMON_HEAVY_PARALLEL", "int", "2", "engine", "core/daemon.py",
       "сколько тяжёлых вызовов (generate/retrieve) идут одновременно (минимум 1)"),
    _k("DT_DAEMON_SESSION_IDLE_H", "float", "24.0", "engine", "core/daemon.py",
       "простой MCP-сессии до закрытия, ч (0 - без закрытия)"),
)

# --- секреты с префиксом DT_ ------------------------------------------------------------------
_DT_SECRETS = (
    _k("DT_WEB_TOKEN", "secret", None, "engine", "core/web_tokens.py",
       "токен чтения веб-пульта и /mcp; по умолчанию файл .secrets/web_token"),
    _k("DT_WEB_TOKEN_RW", "secret", None, "engine", "core/web_tokens.py",
       "токен записи (rw) веб-пульта и /mcp; по умолчанию файл .secrets/web_token_rw"),
)

# --- хосты (производные: ставят dt host-config / dt plugin) -----------------------------------
_HOST = (
    _k("DT_KIMI_AGENT_HOME", "path", None, "host", "core/kimi_install.py",
       "домашний каталог агента kimi-code (mcp.json); по умолчанию внутри kimi-desktop"),
    _k("DT_KIMI_PLUGINS_DIR", "path", None, "host", "core/kimi_install.py",
       "каталог плагинов Kimi; по умолчанию внутри kimi-desktop"),
    _k("DT_TOOL_DESC_CHARS", "int", None, "host", "mcp-server/server.py",
       "усечение описаний инструментов, символы (ставит dt host-config в конфиг хоста)"),
    _k("DT_TOOL_PROFILE", "str", "full", "host", "mcp-server/server.py",
       "профиль инструментов: full | lean | pult (ставит dt host-config)"),
)

# --- тесты (фикстуры и песочница; в боевой .env не нужны) --------------------------------------
_TEST = (
    _k("DT_DERIVED_PATH", "path", None, "test", "tests/",
       "устаревшее имя корня производных в старых контрактных тестах (код не читает)"),
    _k("DT_INGEST_ROOT_ACME_OPS", "path", None, "test", "tests/test_file_ingest.py",
       "плейсхолдер корня ingest-roots в тесте подстановки переменных"),
    _k("DT_SANDBOX_SNAPSHOT", "bool", "1", "test", "tests/_derived_allowlist.py",
       "снимок боевого .derived за сессию тестов (0 - выкл, отладка)"),
    _k("DT_SMOKE_VAR", "str", None, "test", "tests/test_cli_env.py",
       "проверочная переменная теста load_env"),
    _k("DT_STATUS_PATH", "path", None, "test", "tests/",
       "устаревшее имя каталога статусов в старом контрактном тесте (код не читает)"),
    _k("DT_TEST", "str", None, "test", "tests/test_timetta_mirror.py",
       "имя тестовой сделки Timetta в фикстуре (данные, не настройка)"),
)

# --- устаревшее --------------------------------------------------------------------------------
_DEPRECATED = (
    # имя собрано на лету: гард tests/test_no_timetta_write.py не терпит литерала в core/
    _k("DT_ORBIT_" + "WRITE_RINGS", "list", None, "deprecated", "core/operational/orbit.py",
       "гейт записи по кольцам; снят в RETIRE-WRITE-1 (записи в Timetta нет), код не читает"),
    _k("DT_PULT_HTML", "path", None, "deprecated", _OPER,
       "прежнее имя DT_PULT_HTML_PATH (читается как синоним) - используй DT_PULT_HTML_PATH"),
    _k("DT_TICKTICK_APPROVAL_PROJECT_NAME", "str", None, "deprecated", "ops/SETUP.md",
       "список «На подтверждение» снят в RETIRE-WRITE-1; код не читает", declared_only=True),
    _k("DT_TICKTICK_CHANGES_PROJECT_NAME", "str", None, "deprecated", "ops/SETUP.md",
       "список «Изменения» снят в RETIRE-WRITE-1; код не читает", declared_only=True),
    _k("DT_TIMETTA_ISSUE_TYPE_ID", "str", None, "deprecated", "ops/SETUP.md",
       "тип Issue для записи в Timetta; запись снята (RETIRE-WRITE-1), код не читает",
       declared_only=True),
)

# --- плейсхолдеры в yaml, не читаются кодом как env -------------------------------------------
_PLACEHOLDER = (
    _k("DT_ICLOUD", "path", None, "host", "core/file_ingest/config.py",
       "плейсхолдер ``${DT_ICLOUD}`` в ingest-roots.yaml (раскрывается expandvars); корень "
       "iCloud на этой машине", declared_only=True),
)

KNOBS: tuple[Knob, ...] = (
    _PATHS + _ENGINE + _INSTANCE + _DT_SECRETS + _SECRETS + _EXTERNAL + _HOST + _TEST + _DEPRECATED
    + _PLACEHOLDER
)

_BY_NAME = {k.name: k for k in KNOBS}


def by_name(name: str) -> Knob | None:
    return _BY_NAME.get(name)


def names(*, scope: str | None = None) -> list[str]:
    """Имена реестра (опционально одного scope), в порядке записей."""
    return [k.name for k in KNOBS if scope is None or k.scope == scope]


def mask(value: str | None) -> str:
    """Секрет для вывода: только хвост 4 символа (``…abcd``); пусто - «не задан»."""
    value = (value or "").strip()
    if not value:
        return "(не задан)"
    return "…" + value[-4:]
