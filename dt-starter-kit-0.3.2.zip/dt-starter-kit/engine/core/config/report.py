"""``dt config show|check`` (CONFIG-1 п.3-4): действующие значения и проверка ``.env`` по реестру.

Чистые функции от пути к ``.env`` и словаря окружения (по умолчанию ``os.environ`` процесса, БЕЗ
подгрузки ``.env`` - иначе источник «.env | env процесса» не различить): тесты и ``dt config
--env-file`` работают на копии файла, боевой не трогают.

Инварианты: значение секрета нигде не печатается (``mask`` - хвост 4 символа); в замечаниях
``check`` только имена ключей, без значений; ничего не пишется.
"""

from __future__ import annotations

import contextlib
import difflib
import json
import os
import stat
import subprocess
from collections.abc import Callable, Iterator, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from . import env_file
from .knobs import KNOBS, Knob, by_name, mask

__all__ = [
    "CheckResult",
    "Finding",
    "Row",
    "check",
    "effective_mode",
    "env_values",
    "show_rows",
]

MODES_NOTE = "local | server | client"
_BOOL_OK = {"", "0", "1", "true", "false", "yes", "no", "on", "off"}


@dataclass(frozen=True)
class Finding:
    kind: str  # unknown | deprecated | test_key | required_empty | bad_value | duplicate | …
    text: str
    keys: tuple[str, ...] = ()


@dataclass
class CheckResult:
    mode: str
    env_path: Path
    findings: list[Finding] = field(default_factory=list)

    @property
    def status(self) -> str:
        return "ok" if not self.findings else "warn"

    def summary(self) -> str:
        """Одна строка для доктора: имена ключей без значений + режим."""
        if not self.findings:
            return f"чисто · режим: {self.mode}"
        return "; ".join(f.text for f in self.findings) + f" · режим: {self.mode}"

    def render(self) -> list[str]:
        head = f"dt config check · {self.env_path} · режим: {self.mode}"
        if not self.findings:
            return [head, "ok: замечаний нет"]
        return [head, *(f"warn  {f.text}" for f in self.findings),
                f"warn: замечаний {len(self.findings)}"]


@dataclass(frozen=True)
class Row:
    name: str
    value: str  # для секретов - хвост
    source: str  # .env | env | дефолт
    scope: str
    type: str
    legacy: bool = False


def env_values(env_path: Path) -> dict[str, str]:
    """Пары ``ключ → значение`` файла ``.env`` (последнее вхождение; кавычки сняты)."""
    out: dict[str, str] = {}
    for key in dict.fromkeys(env_file.read_keys(env_path)):
        value = env_file.read_value(env_path, key)
        if value is not None:
            out[key] = value
    return out


def effective_mode(file_values: Mapping[str, str], environ: Mapping[str, str]) -> str:
    raw = (environ.get("DT_MODE") or file_values.get("DT_MODE") or "").strip().lower()
    return raw or "local"


def _effective(
    name: str, file_values: Mapping[str, str], environ: Mapping[str, str]
) -> tuple[str | None, str]:
    if name in environ:
        return environ[name], "env"
    if name in file_values:
        return file_values[name], ".env"
    return None, "дефолт"


@contextlib.contextmanager
def _overlay(values: Mapping[str, str]) -> Iterator[None]:
    """Временно кладёт значения ``.env`` в ``os.environ`` (для расчёта путей по умолчанию)."""
    saved = {k: os.environ.get(k) for k in values}
    try:
        for k, v in values.items():
            os.environ.setdefault(k, v)
        yield
    finally:
        for k, old in saved.items():
            if old is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = old


_RESOLVER_OVERRIDES = {
    "DT_VAULT_PATH": "default_vault_path",
    "DT_DB_PATH": "dt_db_path",
    "DT_OPERATIONAL_PATH": "operational_derived_path",
}


def _default_text(k: Knob) -> str:
    """Значение по умолчанию для вывода: у путей - реально вычисленный путь."""
    if k.type == "path" and k.default is None:
        import core.config as cfg

        fn_name = _RESOLVER_OVERRIDES.get(k.name, k.name[3:].lower())
        fn = getattr(cfg, fn_name, None)
        if fn_name in cfg.PATH_PROVIDERS and callable(fn):
            try:
                return str(fn())
            except Exception:  # noqa: BLE001, S110 - показ best-effort
                pass
    return k.default if k.default is not None else "(не задан)"


def show_rows(
    env_path: Path, *, environ: Mapping[str, str] | None = None, include_all: bool = False
) -> list[Row]:
    """Строки ``dt config show``: сначала явно заданные, затем дефолты; секреты - хвостом."""
    environ = dict(os.environ if environ is None else environ)  # снимок ДО overlay
    file_values = env_values(env_path)
    rows: list[Row] = []
    with _overlay(file_values):
        for k in KNOBS:
            if not include_all and k.scope in ("test", "deprecated"):
                continue
            value, source = _effective(k.name, file_values, environ)
            if source == "дефолт":
                shown = "(не задан)" if k.is_secret else _default_text(k)
            else:
                shown = mask(value) if k.is_secret else (value or "(пусто)")
            rows.append(Row(k.name, shown, source, k.scope, k.type, k.legacy))
    rows.sort(key=lambda r: (r.source == "дефолт", r.name))
    return rows


# --------------------------------------------------------------------------- #
# check                                                                        #
# --------------------------------------------------------------------------- #
def _names() -> list[str]:
    return [k.name for k in KNOBS]


def _is_json(k: Knob) -> bool:
    """Ключи с JSON-значением (``doc`` начинается с «JSON»): битый JSON код читает как пустой."""
    return k.doc.startswith("JSON")


def _bad_value(k: Knob, value: str) -> bool:
    v = value.strip()
    if _is_json(k):
        if not v:
            return False
        try:
            json.loads(v)
        except ValueError:
            return True
        return False
    if k.type == "int":
        try:
            int(v)
        except ValueError:
            return v != ""
    elif k.type == "float":
        try:
            float(v)
        except ValueError:
            return v != ""
    elif k.type == "bool":
        return v.lower() not in _BOOL_OK
    return False


def _json_list(raw: str | None) -> list[str]:
    """Как ``_env_json_list`` кода: массив строк; пусто/битый JSON/не массив → ``[]``."""
    if not raw or not raw.strip():
        return []
    try:
        data = json.loads(raw)
    except ValueError:
        return []
    return [str(x).strip() for x in data if str(x).strip()] if isinstance(data, list) else []


def _owner_not_subtracted(
    file_values: Mapping[str, str], environ: Mapping[str, str]
) -> bool:
    """MAIL-PRIVACY-2 п.3: личность владельца задана (email/имя), но ни один токен
    ``DT_OUTLOOK_SELF_TOKENS`` (+``DT_USER_NAME``/email, как в ``outlook_self_tokens``) не слово
    с фамилией из списка приватных имен, - значит фамилия владельца НЕ вычитается из пробы
    приватности почты и режет его же письма (фейлкейс 30.10: битый JSON код читает как ``[]``).
    Токен из нескольких слов (полное имя) фамилию по отдельности из текста не вычтет - не считается.
    """
    def val(name: str) -> str:
        return (_effective(name, file_values, environ)[0] or "").strip()

    profile = _owner_profile(file_values, environ)  # PROFILE-1: профиль vault + .env как добавка
    if profile.data.name_variants:
        return False  # варианты объявлены профилем (не хрупким JSON из .env): вычитание задано
    user_name = profile.name or val("DT_USER_NAME")
    if user_name.lower() == "the user":
        user_name = ""
    email = val("DT_TIMETTA_USER_EMAIL")
    if not (user_name or email or profile.identity_tokens):
        return False  # личность не задана - предупреждать не о чем (его закроет required_empty)
    tokens = [*profile.identity_tokens, *_json_list(val("DT_OUTLOOK_SELF_TOKENS")),
              user_name, email]
    surnames = [n.lower() for n in
                (*profile.data.privacy_people, *_json_list(val("DT_LEGACY_PRIVACY_NAMES")))]
    if not surnames:
        return False  # приватных имен нет - вычитать нечего (пустой список: privacy_people_empty)
    words = [t.lower() for t in tokens if t and len(t.split()) == 1]
    return not any(sn in w for w in words for sn in surnames)


def _owner_profile(file_values: Mapping[str, str], environ: Mapping[str, str]) -> Any:
    """Профиль владельца того vault, который видит этот ``.env``/окружение (``DT_VAULT_PATH``)."""
    from core.owner import load_profile

    raw = (_effective("DT_VAULT_PATH", file_values, environ)[0] or "").strip()
    return load_profile(Path(raw) if raw else None)


def _owner_values(file_values: Mapping[str, str], environ: Mapping[str, str]) -> dict[str, str]:
    return {k: (_effective(k, file_values, environ)[0] or "")
            for k in ("DT_USER_NAME", "DT_OUTLOOK_SELF_TOKENS", "DT_LEGACY_PRIVACY_NAMES")}


def _connector_findings(
    file_values: Mapping[str, str], environ: Mapping[str, str],
) -> list[Finding]:
    """DEV-3-CORE: ``DT_CONNECTORS`` - опечатки в списке и явно включенный коннектор без секрета.

    ``auto`` и ``none`` замечаний не дают (auto без секрета - коннектор просто выключен)."""
    from core import connectors
    from core.secrets import secret_location

    raw = _effective("DT_CONNECTORS", file_values, environ)[0] or ""
    env = {"DT_CONNECTORS": raw}
    out: list[Finding] = []
    unknown = connectors.unknown_tokens(env)
    if unknown:
        out.append(Finding(
            "connectors_unknown",
            "DT_CONNECTORS: неизвестные коннекторы " + ", ".join(unknown)
            + " (есть: " + ", ".join(connectors.CONNECTORS) + ")", ("DT_CONNECTORS",)))
    if connectors.mode(env) != connectors.LIST:
        return out
    for key, conn in connectors.CONNECTORS.items():
        if not connectors.enabled(key, env):
            continue
        missing = []
        for req in conn.requires:
            have = bool((_effective(req.name, file_values, environ)[0] or "").strip())
            if not have and req.kind == "secret":
                have = secret_location(req.name) != "absent"  # Keychain тоже считается
            if not have:
                missing.append(req.name)
        if missing:
            out.append(Finding(
                "connector_secret_missing",
                f"коннектор {key} включен явно (DT_CONNECTORS), но нет {', '.join(missing)}: "
                + conn.hint, ("DT_CONNECTORS", *missing)))
    return out


def _perm_findings(env_path: Path, secrets_dir: Path | None) -> list[Finding]:
    out: list[Finding] = []
    if env_path.is_file():
        mode = stat.S_IMODE(env_path.stat().st_mode)
        if mode & 0o077:
            out.append(Finding(
                "perm_env", f"{env_path.name}: права {mode:o} (доступен не только владельцу) - "
                f"chmod 600 {env_path}"))
    if secrets_dir is not None and secrets_dir.is_dir():
        loose = []
        dmode = stat.S_IMODE(secrets_dir.stat().st_mode)
        if dmode & 0o077:
            loose.append(f"{secrets_dir.name}/ ({dmode:o})")
        for f in sorted(secrets_dir.iterdir()):
            if f.is_file() and stat.S_IMODE(f.stat().st_mode) & 0o077:
                loose.append(f"{f.name} ({stat.S_IMODE(f.stat().st_mode):o})")
        if loose:
            out.append(Finding(
                "perm_secrets", ".secrets: широкие права: " + ", ".join(loose)
                + " - chmod 700 каталог, chmod 600 файлы"))
    return out


def _git_findings(env_path: Path) -> list[Finding]:
    """``.env`` в репозитории обязан быть вне git (ignored, не tracked); вне репозитория - тихо."""
    if not env_path.is_file():
        return []
    cwd = str(env_path.parent)

    def git(*args: str) -> int | None:
        try:
            return subprocess.run(  # noqa: S603 - фиксированный argv
                ["git", *args], cwd=cwd, capture_output=True, timeout=5, check=False,  # noqa: S607
            ).returncode
        except (OSError, subprocess.SubprocessError):
            return None

    if git("rev-parse", "--is-inside-work-tree") != 0:
        return []
    out: list[Finding] = []
    if git("ls-files", "--error-unmatch", env_path.name) == 0:
        out.append(Finding("git_tracked", f"{env_path.name} под git (tracked) - убрать из индекса: "
                                          f"git rm --cached {env_path.name}"))
    if git("check-ignore", "-q", "--no-index", env_path.name) == 1:
        out.append(Finding("git_unignored", f"{env_path.name} не в .gitignore - секреты могут "
                                            "попасть в коммит"))
    return out


def check(
    env_path: Path,
    *,
    environ: Mapping[str, str] | None = None,
    secrets_dir: Path | None = None,
    tailscale: Callable[[], Any] | None = None,
    git_check: bool = True,
) -> CheckResult:
    """Проверка ``.env`` по реестру: неизвестные, устаревшие, пустые обязательные, права, режим.

    ``tailscale`` - функция статуса (по умолчанию ``core.tailscale.status``); нужна только при
    ``DT_MODE=server``. Тесты подставляют свою - живой Tailscale не вызывается."""
    environ = os.environ if environ is None else environ
    env_path = Path(env_path)
    file_values = env_values(env_path)
    mode = effective_mode(file_values, environ)
    res = CheckResult(mode=mode, env_path=env_path)
    add = res.findings.append

    if not env_path.is_file():
        add(Finding("env_missing", f"{env_path} нет - действуют дефолты (создать: dt config init)"))
        keys: list[str] = []
    else:
        keys = env_file.read_keys(env_path)

    # неизвестные / устаревшие / тестовые / дубликаты / значения
    unknown, deprecated, test_keys, instance_keys, dup, bad = [], [], [], [], [], []
    seen: set[str] = set()
    for key in keys:
        if key in seen:
            if key not in dup:
                dup.append(key)
            continue
        seen.add(key)
        k = by_name(key)
        if k is None:
            unknown.append(key)
            continue
        if k.scope == "deprecated":
            deprecated.append(key)
        elif k.scope == "test":
            test_keys.append(key)
        elif k.scope == "instance":
            instance_keys.append(key)
        value = file_values.get(key, "")
        if not k.is_secret and _bad_value(k, value):
            bad.append(key)
    if unknown:
        hints = []
        for key in unknown:
            near = difflib.get_close_matches(key, _names(), n=1, cutoff=0.8)
            hints.append(f"{key} (возможно {near[0]})" if near else key)
        add(Finding("unknown", "неизвестные ключи: " + ", ".join(hints), tuple(unknown)))
    for key in deprecated:
        k = by_name(key)
        assert k is not None  # noqa: S101
        add(Finding("deprecated", f"устарел {key}: {k.doc}", (key,)))
    if instance_keys:  # PERSONAL-1: настройки экземпляра - в оверлее, не в рабочем .env
        add(Finding("instance_key", "ключи экземпляра в рабочем .env (место - оверлей "
                    "engine/instances/<имя>.env, dt instance add): " + ", ".join(instance_keys),
                    tuple(instance_keys)))
    if test_keys:
        add(Finding("test_key", "тестовые ключи в боевом .env: " + ", ".join(test_keys),
                    tuple(test_keys)))
    if dup:
        add(Finding("duplicate", "ключ повторён (действует последний): " + ", ".join(dup),
                    tuple(dup)))
    if bad:
        add(Finding("bad_value", "значение не того формата (тип или JSON; битый JSON код читает "
                    "как пустой) у ключей: " + ", ".join(bad), tuple(bad)))

    # режим
    if mode not in ("local", "server", "client"):
        add(Finding("bad_mode", f"DT_MODE: допустимо {MODES_NOTE}", ("DT_MODE",)))
    if mode != "client":
        profile = _owner_profile(file_values, environ)
        empty = [
            k.name for k in KNOBS
            if k.required and not (_effective(k.name, file_values, environ)[0] or "").strip()
            # PROFILE-1: токены личности может дать профиль - тогда пустой ключ не дефект
            and not (k.name == "DT_OUTLOOK_SELF_TOKENS" and profile.identity_tokens)
        ]
        if empty:
            add(Finding("required_empty", "обязательные пусты: " + ", ".join(empty), tuple(empty)))
    if mode != "client" and _owner_not_subtracted(file_values, environ):
        add(Finding(
            "owner_not_subtracted",
            "владелец не вычитается из пробы приватности почты: задай DT_OUTLOOK_SELF_TOKENS "
            "(фамилия, email) - иначе фамилия владельца режет его же письма",
            ("DT_OUTLOOK_SELF_TOKENS",)))
    if mode != "client":
        profile = _owner_profile(file_values, environ)
        values = _owner_values(file_values, environ)
        from core.owner.check import env_duplicates

        dups = env_duplicates(profile, values)
        if dups:
            add(Finding(
                "owner_duplicate",
                "дубль источника: перенесите в профиль, уберите из .env - " + "; ".join(dups),
                ("DT_USER_NAME", "DT_OUTLOOK_SELF_TOKENS")))
        if not profile.exists and not _json_list(values["DT_LEGACY_PRIVACY_NAMES"]):
            add(Finding(
                "privacy_people_empty",
                "профиля владельца нет и список приватных имен пуст: личные документы людей из "
                "списка (зарплата/ГПХ/HR) не отфильтруются - dt owner init --people ФАМИЛИЯ ... "
                "(или DT_LEGACY_PRIVACY_NAMES)",
                ("DT_LEGACY_PRIVACY_NAMES",)))
    if mode != "client":
        for f in _connector_findings(file_values, environ):
            add(f)
    if mode != "client":
        from core import connectors
        from core.owner.domains import env_domain_list, owner_domains

        profile = _owner_profile(file_values, environ)
        env_doms = env_domain_list(_effective("DT_MAIL_OWNER_DOMAINS", file_values, environ)[0])
        eff = {name: _effective(name, file_values, environ)[0] or ""
               for name in ("DT_CONNECTORS", "DT_OUTLOOK_FOLDERS")}
        mail_on = connectors.enabled("outlook", eff)  # без почты домены владельца не нужны
        if mail_on and not owner_domains(profile) and not env_doms:
            add(Finding(
                "owner_domains_empty",
                "домены владельца не заданы: вся почта станет внешней (участники-коллеги - "
                "контрагенты) - owner.yaml: emails (домены берутся из адресов) или "
                "company.domains, либо DT_MAIL_OWNER_DOMAINS",
                ("DT_MAIL_OWNER_DOMAINS",)))
    if mode == "server":
        if tailscale is None:
            from core.tailscale import status as _status

            info = _status()
        else:
            info = tailscale()
        if info is None:
            add(Finding("server_no_tailscale", "DT_MODE=server, но адреса Tailscale нет - демон "
                        "стартует в local (войти в Tailscale; бинарь: DT_TAILSCALE_BIN)",
                        ("DT_MODE",)))
    if mode == "client":
        url = (_effective("DT_SERVER_URL", file_values, environ)[0] or "").strip()
        if not url:
            add(Finding("client_no_url", "DT_MODE=client, но DT_SERVER_URL пуст - "
                        "dt client join --server <url>", ("DT_SERVER_URL",)))

    for f in _perm_findings(env_path, secrets_dir):
        add(f)
    if git_check:
        for f in _git_findings(env_path):
            add(f)
    return res
