"""DEV-3-CORE п.2 - реестр коннекторов: что внешнее у экземпляра включено.

Три коннектора (``calendar`` - часть ``outlook``): ``timetta`` (CRM, зеркало только чтение),
``ticktick`` (захваты), ``outlook`` (почта и календарь через мост). Реестр - ДАННЫЕ: ключ,
подпись и ``requires`` (секрет Keychain/``.env`` либо ручка). Что именно исчезает у выключенного
коннектора (секции пульта, задания, виды карточек, проверки доктора, инструменты, шаги) записано
не здесь, а в таблице поверхности ``core.surface.manifest`` (ось «коннектор»), входы - в
``IngressAdapter.connector``: потребители читают реестр ТОЛЬКО через них.

``DT_CONNECTORS``:

* не задан / пуст / ``auto`` - **auto** (дефолт, сегодняшнее поведение): коннектор включен, если
  есть его ``requires`` (секрет в ``.env``/Keychain, ручка в окружении);
* ``none`` - все выключены (профиль «базовый DT»: знания, поиск, генерация, пульт без CRM);
* список (``timetta,ticktick`` или JSON-массив) - включены ровно перечисленные, без проверки
  секретов (нет секрета - предупреждение ``dt config check`` и красный доктор: явное решение).

Чистая функция от окружения: ``environ`` инъектируется (``dt config check`` читает окружение
чужого ``.env``), по умолчанию - ``os.environ``. Keychain-проба кэшируется на минуту
(``security`` - подпроцесс, а ``enabled`` зовут на каждый вызов реестров)."""

from __future__ import annotations

import json
import os
import time
from collections.abc import Mapping
from dataclasses import dataclass

__all__ = [
    "AUTO",
    "CONNECTORS",
    "Connector",
    "ConnectorDisabled",
    "ConnectorStatus",
    "NONE",
    "Requirement",
    "all_status",
    "enable_hint",
    "enabled",
    "mode",
    "normalize",
    "reset_cache",
    "status",
    "unknown_tokens",
]

AUTO, NONE, LIST = "auto", "none", "list"
ENV_NAME = "DT_CONNECTORS"
_ALIASES = {"calendar": "outlook"}  # календарь - часть коннектора outlook
_KEYCHAIN_TTL_S = 60.0


@dataclass(frozen=True)
class Requirement:
    """Что нужно коннектору в auto: секрет (``.env``/Keychain) либо ручка в окружении."""

    kind: str  # secret | knob
    name: str


@dataclass(frozen=True)
class Connector:
    key: str
    label: str
    requires: tuple[Requirement, ...]
    hint: str  # как включить, одной фразой


CONNECTORS: dict[str, Connector] = {
    "timetta": Connector(
        "timetta", "Timetta",
        (Requirement("secret", "TIMETTA_API_TOKEN"),),
        "TIMETTA_API_TOKEN в .env или Keychain (dt_secrets --migrate)"),
    "ticktick": Connector(
        "ticktick", "TickTick",
        (Requirement("secret", "TICKTICK_ACCESS_TOKEN"),),
        "TICKTICK_ACCESS_TOKEN в .env или Keychain (dt_secrets --migrate)"),
    "outlook": Connector(
        "outlook", "Outlook",
        (Requirement("knob", "DT_OUTLOOK_FOLDERS"),),
        "DT_OUTLOOK_FOLDERS в .env (папки почты) и Classic Outlook на этой машине"),
}


class ConnectorDisabled(Exception):
    """Операция принадлежит выключенному коннектору (конверт ``connector_disabled`` строит MCP)."""

    def __init__(self, subject: str, connectors: tuple[str, ...]) -> None:
        super().__init__(f"{subject}: коннектор выключен: {', '.join(connectors)}")
        self.subject = subject
        self.connectors = connectors


@dataclass(frozen=True)
class ConnectorStatus:
    key: str
    enabled: bool
    reason: str
    requires: tuple[str, ...]  # имена секретов/ручек (без значений)
    explicit: bool = False  # включен списком DT_CONNECTORS (не auto)
    missing: tuple[str, ...] = ()  # чего нет из requires

    def as_dict(self) -> dict[str, object]:
        return {"enabled": self.enabled, "reason": self.reason, "requires": list(self.requires)}


def normalize(key: str) -> str:
    """Ключ коннектора (``calendar`` -> ``outlook``); неизвестный - ``KeyError``."""
    k = _ALIASES.get(key.strip().lower(), key.strip().lower())
    if k not in CONNECTORS:
        raise KeyError(key)
    return k


def _tokens(raw: str) -> list[str]:
    text = raw.strip()
    if text.startswith("["):
        try:
            data = json.loads(text)
        except ValueError:
            return []
        return [str(x).strip().lower() for x in data if str(x).strip()] if isinstance(
            data, list) else []
    for sep in (";", " "):
        text = text.replace(sep, ",")
    return [t.strip().lower() for t in text.split(",") if t.strip()]


def _env(environ: Mapping[str, str] | None) -> Mapping[str, str]:
    return os.environ if environ is None else environ


def mode(environ: Mapping[str, str] | None = None) -> str:
    """``auto`` | ``none`` | ``list`` по ``DT_CONNECTORS``."""
    toks = _tokens(_env(environ).get(ENV_NAME) or "")
    if not toks or toks == [AUTO]:
        return AUTO
    if toks == [NONE]:
        return NONE
    return LIST


def _selected(environ: Mapping[str, str] | None) -> set[str]:
    out: set[str] = set()
    for tok in _tokens(_env(environ).get(ENV_NAME) or ""):
        try:
            out.add(normalize(tok))
        except KeyError:
            continue
    return out


def unknown_tokens(environ: Mapping[str, str] | None = None) -> list[str]:
    """Слова ``DT_CONNECTORS``, которых нет в реестре (опечатки; их называет config check)."""
    out: list[str] = []
    for tok in _tokens(_env(environ).get(ENV_NAME) or ""):
        if tok in (AUTO, NONE):
            continue
        try:
            normalize(tok)
        except KeyError:
            out.append(tok)
    return out


_keychain_cache: dict[str, tuple[float, bool]] = {}


def reset_cache() -> None:
    """Сбросить кэш Keychain-пробы (тесты, смена окружения)."""
    _keychain_cache.clear()


def _in_keychain(name: str) -> bool:
    hit = _keychain_cache.get(name)
    now = time.monotonic()
    if hit is not None and now - hit[0] < _KEYCHAIN_TTL_S:
        return hit[1]
    from core.secrets import in_keychain

    found = in_keychain(name)
    _keychain_cache[name] = (now, found)
    return found


def _present(req: Requirement, environ: Mapping[str, str] | None) -> bool:
    env = _env(environ)
    if (env.get(req.name) or "").strip():
        return True
    # Keychain - только у живого окружения процесса (инъектированный словарь герметичен)
    return req.kind == "secret" and environ is None and _in_keychain(req.name)


def status(key: str, environ: Mapping[str, str] | None = None) -> ConnectorStatus:
    """Состояние коннектора ``key`` с причиной (для манифеста, доктора, конверта отказа)."""
    k = normalize(key)
    conn = CONNECTORS[k]
    names = tuple(r.name for r in conn.requires)
    missing = tuple(r.name for r in conn.requires if not _present(r, environ))
    m = mode(environ)
    if m == NONE:
        return ConnectorStatus(k, False, f"{ENV_NAME}=none", names, missing=missing)
    if m == LIST:
        if k in _selected(environ):
            return ConnectorStatus(k, True, f"включен явно ({ENV_NAME})", names, True, missing)
        return ConnectorStatus(k, False, f"не в списке {ENV_NAME}", names, missing=missing)
    if missing:
        return ConnectorStatus(k, False, "auto: нет " + ", ".join(missing), names, missing=missing)
    return ConnectorStatus(k, True, "auto: " + ", ".join(names) + " найден", names)


def enabled(key: str, environ: Mapping[str, str] | None = None) -> bool:
    return status(key, environ).enabled


def enable_hint(keys: tuple[str, ...] | list[str], environ: Mapping[str, str] | None = None) -> str:
    """Как включить коннекторы ``keys`` (для конверта ``connector_disabled`` и доктора)."""
    parts = []
    for k in keys:
        st = status(k, environ)
        parts.append(f"{k} ({st.reason}): {CONNECTORS[k].hint}")
    return ("включить: " + "; ".join(parts) + f" - либо {ENV_NAME}=" + ",".join(keys)
            + " (ops/README.md, «Коннекторы»)")


def all_status(environ: Mapping[str, str] | None = None) -> dict[str, ConnectorStatus]:
    return {k: status(k, environ) for k in CONNECTORS}
