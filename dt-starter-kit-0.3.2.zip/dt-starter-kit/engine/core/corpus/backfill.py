"""CONTRACT-1 ФП-9 (P2) — бэкфилл устаревших ``source_path`` файлового корпуса.

Кейс справки 14.08 (фейлкейс 2): префикс пути был взят из ``source_path`` заметок —
каталога ``Bitrix24-…@energy-cons.bitrix24.ru``, которого на диске больше нет (пусто,
кроме ``.DS_Store``, mtime 16.07). Заметка живёт, а файл под ней переехал в живой
ingest-корень. Прямого вреда подъёму это уже не наносит (``resolve_source_path`` тянет
tail-резолвом по корням), но **строка в заметке лжёт**: её видит человек, её показывает
выдача, по ней строится обратный индекс ссылок. После ФП-1/ФП-2 это перестало быть
дырой в тропе и стало гигиеной корпуса — отсюда P2 и отдельный проход.

Что делает: для каждой заметки vault с непустым ``source_path``, который **как строка**
никуда не ведёт, но чей файл находится под ingest-корнем, переписывает строку на
**корень-относительную** форму (``Russia/BS/ТКП.pdf``). Именно относительную:
markdown — primary storage и синкается между машинами, абсолютный путь вбил бы в vault
машинно-специфичную строку (per-device резолв — в ``core.sources.resolver``).

Чего НЕ делает (осознанно):

* не трогает **виртуальные** ``source_path`` почты (``correspondence/conv:…``,
  ``…/msg:…``) — за ними файла нет вовсе, и это законно (`core/legacy/mail.py`);
* не трогает заметки под NDA-барьером и пути с NDA-маркером (NDA-1);
* не трогает записи, чья строка уже резолвится как есть, и те, где новое значение
  совпало бы со старым (идемпотентность повторного прогона);
* не пишет ничего при ``dry_run=True`` (дефолт) — сперва смотрим диспозицию.

Правка **хирургическая**: меняется только строка ``source_path:`` внутри YAML-блока,
остальной frontmatter и тело — байт-в-байт (образец —
:func:`core.operational.attribute.attribute_note_client`). Канон §9 п.11: прогресс по
ходу (не молчит до конца), прерываемо (каждая заметка — отдельная запись на диск,
повторный прогон продолжает), канарейка через ``limit``.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from core.config import default_vault_path

__all__ = ["BackfillStats", "backfill_source_paths"]

# Виртуальные ключи почтовых тредов — за ними файла нет by design.
_VIRTUAL_PREFIXES = ("conv:", "msg:")
_FM_RE = re.compile(r"^---\r?\n(.*?)\r?\n---\r?\n?", re.DOTALL)
_SOURCE_LINE_RE = re.compile(r"^(source_path:).*$", re.MULTILINE)


@dataclass
class BackfillStats:
    """Диспозиция прохода (счётчики + примеры правок для канарейки)."""

    notes: int = 0            # просмотрено заметок с source_path
    rewritten: int = 0        # строка обновлена (или была бы — при dry_run)
    already_ok: int = 0       # строка резолвится как есть — не трогаем
    virtual: int = 0          # conv:/msg: — законно виртуальные
    unresolved: int = 0       # файла не нашли нигде: писать нечего, показываем числом
    nda: int = 0              # NDA-барьер (заметка или путь)
    dry_run: bool = True
    examples: list[dict[str, str]] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        return {
            "notes": self.notes,
            "rewritten": self.rewritten,
            "already_ok": self.already_ok,
            "virtual": self.virtual,
            "unresolved": self.unresolved,
            "nda": self.nda,
            "dry_run": self.dry_run,
            "examples": list(self.examples),
        }


def _is_virtual(raw: str) -> bool:
    """``correspondence/conv:207549`` / ``…/msg:<id>`` — виртуальный ключ треда."""
    tail = raw.rsplit("/", 1)[-1]
    return any(tail.startswith(p) for p in _VIRTUAL_PREFIXES)


def _root_relative(live: Path, roots: list[tuple[str, Path]]) -> str | None:
    """Живой абсолютный путь → путь относительно СВОЕГО ingest-корня (или ``None``)."""
    for _name, root in roots:
        try:
            return live.relative_to(root).as_posix()
        except ValueError:
            continue
    return None


def _rewrite_source_line(text: str, value: str) -> str | None:
    """Хирургически заменить строку ``source_path:`` (или ``None``, если нечего менять)."""
    m = _FM_RE.match(text)
    if not m:
        return None
    fm = m.group(1)
    if not _SOURCE_LINE_RE.search(fm):
        return None
    new_fm = _SOURCE_LINE_RE.sub(f"source_path: {value}", fm, count=1)
    if new_fm == fm:
        return None
    return text[: m.start(1)] + new_fm + text[m.end(1) :]


def backfill_source_paths(
    vault_path: Path | None = None,
    *,
    dry_run: bool = True,
    limit: int | None = None,
    log: Callable[[str], None] | None = None,
    progress_every: int = 200,
) -> BackfillStats:
    """Обновить устаревшие ``source_path`` на корень-относительную живую форму.

    ``dry_run=True`` (дефолт) — только диспозиция и примеры, диск не меняется.
    ``limit`` — канарейка: обработать не больше N подходящих заметок (§9 п.11г — сперва
    подмножество, потом весь корпус). Возвращает :class:`BackfillStats`.
    """
    from core.file_ingest.config import load_ingest_roots
    from core.privacy import is_nda
    from core.sources import resolve_source_path
    from core.vault import iter_vault

    log = log or (lambda _m: None)
    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    roots = [(r.name, r.path) for r in load_ingest_roots(vault)]
    stats = BackfillStats(dry_run=dry_run)
    if not roots:
        log("[backfill] ingest-корни не настроены — переписывать не на что")
        return stats

    for note in iter_vault(vault, apply_nda=False):
        raw = note.frontmatter.get("source_path")
        if not (isinstance(raw, str) and raw.strip()):
            continue
        raw = raw.strip()
        stats.notes += 1
        if stats.notes % progress_every == 0:
            log(
                f"[backfill] {stats.notes} заметок | обновлено {stats.rewritten} | "
                f"живых {stats.already_ok} | не нашли {stats.unresolved}"
            )
        if _is_virtual(raw):
            stats.virtual += 1
            continue
        if is_nda(str(note.path)) or is_nda(raw):
            stats.nda += 1
            continue
        # Строка ведёт к файлу КАК ЕСТЬ (абсолютная или vault-относительная)? Не трогаем.
        as_is = Path(raw).expanduser()
        as_is = as_is if as_is.is_absolute() else vault / as_is
        if as_is.is_file():
            stats.already_ok += 1
            continue
        live = resolve_source_path(raw, vault_path=vault)
        if live is None:
            stats.unresolved += 1
            continue
        new_value = _root_relative(live, roots)
        if new_value is None or new_value == raw:
            # Файл найден, но не под ingest-корнем (легаси-корень) либо значение то же —
            # переписывать нечего: у легаси относительная форма легитимна.
            stats.already_ok += 1
            continue
        stats.rewritten += 1
        if len(stats.examples) < 10:
            stats.examples.append(
                {"note_id": note.id, "was": raw, "now": new_value}
            )
        if not dry_run:
            text = note.path.read_text(encoding="utf-8")
            updated = _rewrite_source_line(text, new_value)
            if updated is None:
                stats.rewritten -= 1
                stats.unresolved += 1
                continue
            note.path.write_text(updated, encoding="utf-8")
        if limit is not None and stats.rewritten >= max(0, int(limit)):
            log(f"[backfill] канарейка: остановка на {stats.rewritten} правках (limit)")
            break

    log(
        f"[backfill] готово: заметок {stats.notes}, "
        f"{'нашли к правке' if dry_run else 'обновлено'} {stats.rewritten}, "
        f"живых {stats.already_ok}, виртуальных {stats.virtual}, "
        f"не нашли {stats.unresolved}, NDA {stats.nda}"
    )
    return stats
