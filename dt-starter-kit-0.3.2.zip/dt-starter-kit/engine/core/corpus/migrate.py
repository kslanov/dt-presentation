"""Legacy→current corpus re-tagging (CORPUS-MIGRATE-1, phase 2/4).

Re-labels the *actual* material notes already ingested under ``_legacy/`` from
``corpus: legacy`` to ``corpus: current`` **in place** — the layer is defined by
frontmatter, not the folder (design §4), so no file is moved and no note is ever
deleted. Retrieval (CORPUS-LAYER-1) then boosts these current notes above the
archive.

Three moving parts, all idempotent and resumable (принцип 11):

* **Classification** (:func:`classify`, variant A) — a manifest entry migrates iff
  its ``source_path`` matches a configured *current* prefix (default ``2023-2026/``)
  **and** it resolves to a live file under an operational ingest root (the same path
  identity ``lift`` uses for 2023-2026→CDT_Internal). A recorded
  ``source_content_hash`` is a guard *if present* (must match the live file), but
  legacy entries typically lack one, so resolution alone confirms. Anything else
  stays ``legacy``: a ``2018-2023/`` prefix is a definite archive; a current prefix
  that does not resolve — or whose recorded hash does not match — is *ambiguous* and
  left untouched (we never mislabel what CDT_Internal doesn't confirm).

* **Re-tag** (:func:`_retag_frontmatter`) — a surgical rewrite of only the
  ``corpus:`` line (``curated``/``status`` untouched; the rest of the file
  byte-identical), so the content hash changes and an *incremental* reindex picks
  up exactly these notes (the CLI runs it after).

* **Ownership transfer (the guard)** — the migrated entry moves from the legacy
  ingest manifest to the current ingest manifest. This is mandatory: the legacy
  ingest's drop-loop unlinks a note whose ``source_path`` is in its manifest but
  vanished from discovery (`core/legacy/ingest.py`); once the legacy root is
  narrowed to ``2018-2023`` the ``2023-2026`` sources would vanish and their notes
  would be **deleted**. Transferring ownership removes them from the legacy
  manifest (drop-loop no longer sees them) and registers them in the current
  manifest under the same record template, so the future current-corpus owner
  (CORPUS-INGEST-CURRENT) recognises them as already-processed — no duplicates.

Invariant: ``core`` depends on neither MCP nor CLI. No LLM (Path B). Dry-run is
the default at the CLI; this module writes only when ``dry_run=False``.
"""

from __future__ import annotations

import re
import shutil
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.config import (
    current_ingest_manifest_path,
    default_vault_path,
    legacy_ingest_manifest_path,
)

# Reuse the exact manifest (de)serialization + byte-hash field name so the current
# manifest is a byte-for-byte-shaped sibling of the legacy one (single template,
# shared with CORPUS-INGEST-CURRENT phase 3). core→core, same layer — no cycle.
from core.legacy.ingest import HASH_FIELD, _load_manifest, _save_manifest
from core.sources.cache import file_content_hash
from core.sources.resolver import _resolve_under_ingest_roots

__all__ = ["RetagStats", "classify", "retag_corpus", "DEFAULT_CURRENT_PREFIXES"]

# Default source_path prefix(es) that mark the *current* (актуальное) corpus — the
# year-range that migrated into CDT_Internal. Configurable (CLI ``--prefix``); not
# a hardcode. A trailing ``/`` anchors the match to a path segment boundary.
DEFAULT_CURRENT_PREFIXES: tuple[str, ...] = ("2023-2026/",)

# Persist both manifests every N migrations so a hard kill (SIGKILL) still leaves
# a consistent, resumable checkpoint (SIGTERM/exception flush via the finally).
_CHECKPOINT_EVERY = 200

# Classification verdicts.
CURRENT = "current"
LEGACY = "legacy"
AMBIGUOUS = "ambiguous"


@dataclass
class RetagStats:
    """Outcome of a re-tag run (privacy: counters + a scope label only)."""

    total_entries: int = 0  # note-bearing legacy-manifest entries (before selection)
    selected: int = 0  # entries actually examined (after scope/limit selection)
    n_current: int = 0  # migrated legacy→current
    n_legacy_kept: int = 0  # non-current prefix — definite archive, untouched
    n_ambiguous: int = 0  # current prefix but unresolved/unconfirmed — left legacy
    already_current: int = 0  # note frontmatter already current (idempotent re-run)
    missing_note: int = 0  # manifest entry whose note file is gone (skipped)
    reindexed: int = 0  # notes an incremental reindex will pick up (== n_current)
    dry_run: bool = True
    scope: str = ""
    limit: int | None = None
    changed_note_paths: list[str] = field(default_factory=list)
    examples: list[str] = field(default_factory=list)  # a few migrated note paths
    backups: list[str] = field(default_factory=list)  # .bak files written
    legacy_manifest_path: str = ""
    current_manifest_path: str = ""
    elapsed_s: float = 0.0


# --------------------------------------------------------------------------- #
# Classification                                                              #
# --------------------------------------------------------------------------- #


def _classify(
    source_path: str,
    entry: dict[str, Any],
    vault_path: Path,
    *,
    current_prefixes: tuple[str, ...],
) -> tuple[str, Path | None, str | None]:
    """Classify one entry, returning ``(verdict, resolved_path, live_hash)``.

    Variant A (identity by path; recorded hash is a guard *if present*, реш. К.
    2026-07-15 — the canary found 0/6320 legacy entries carry a
    ``source_content_hash``, so requiring one classifies everything ambiguous):

    * :data:`CURRENT` — a current prefix **and** the ``source_path`` resolves to a
      live file under an operational ingest root (the same path identity ``lift``
      already uses for 2023-2026→CDT_Internal). A recorded ``source_content_hash``,
      **if present**, must match the live file (else :data:`AMBIGUOUS`); if absent
      (the common case), we accept by resolution.
    * :data:`AMBIGUOUS` (left legacy) — a current prefix that does **not** resolve,
      or a recorded hash that is present and does **not** match.
    * :data:`LEGACY` — a non-current prefix (e.g. ``2018-2023/``).

    ``resolved_path`` is the live file (None unless it resolved); ``live_hash`` is
    its byte-hash **only when already computed here** (a recorded hash was present),
    so the caller can stamp it without hashing twice. Pure/read-only.
    """
    if not any(source_path.startswith(p) for p in current_prefixes):
        return LEGACY, None, None
    resolved = _resolve_under_ingest_roots(source_path, vault_path)
    if resolved is None:
        return AMBIGUOUS, None, None  # current prefix, but not under the current root
    recorded = entry.get(HASH_FIELD)
    if not recorded:
        return CURRENT, resolved, None  # variant A: accept by resolution (no hash yet)
    live_hash = file_content_hash(resolved)
    if live_hash != str(recorded):
        return AMBIGUOUS, resolved, live_hash  # bytes differ → changed/other file
    return CURRENT, resolved, live_hash


def classify(
    source_path: str,
    entry: dict[str, Any],
    vault_path: Path,
    *,
    current_prefixes: tuple[str, ...] = DEFAULT_CURRENT_PREFIXES,
) -> str:
    """Classify one manifest entry → :data:`CURRENT` / :data:`LEGACY` / :data:`AMBIGUOUS`.

    See :func:`_classify` for the rule (variant A: identity by path; a recorded
    ``source_content_hash`` is a guard only when present). Pure/read-only.
    """
    return _classify(source_path, entry, vault_path, current_prefixes=current_prefixes)[0]


# --------------------------------------------------------------------------- #
# Frontmatter re-tag (surgical: only the corpus line)                          #
# --------------------------------------------------------------------------- #

# The leading YAML frontmatter block: opening fence, body, closing fence.
_FM_RE = re.compile(r"\A(---\r?\n)(.*?\r?\n)(---\r?\n)", re.DOTALL)
_CORPUS_LINE_RE = re.compile(r"^corpus:.*$", re.MULTILINE)


def _current_corpus(text: str) -> str | None:
    """The note's current ``corpus`` value from its frontmatter, or None if absent."""
    m = _FM_RE.match(text)
    if not m:
        return None
    line = _CORPUS_LINE_RE.search(m.group(2))
    if not line:
        return None
    return line.group(0).split(":", 1)[1].strip().strip("'\"") or None


def _retag_text(text: str, new_corpus: str) -> str | None:
    """Return ``text`` with the frontmatter ``corpus`` set to ``new_corpus``.

    Rewrites only the ``corpus:`` line (or inserts one before the closing fence if
    absent); every other byte is preserved. Returns ``None`` when there is no
    frontmatter block to edit (a shape we never expect for a legacy note)."""
    m = _FM_RE.match(text)
    if not m:
        return None
    open_fence, body, close_fence = m.group(1), m.group(2), m.group(3)
    if _CORPUS_LINE_RE.search(body):
        new_body = _CORPUS_LINE_RE.sub(f"corpus: {new_corpus}", body, count=1)
    else:
        new_body = body + f"corpus: {new_corpus}\n"
    return open_fence + new_body + close_fence + text[m.end():]


def _retag_frontmatter(note_file: Path, new_corpus: str) -> bool:
    """Re-tag ``note_file``'s corpus in place. Returns True if the file changed."""
    text = note_file.read_text(encoding="utf-8")
    new_text = _retag_text(text, new_corpus)
    if new_text is None or new_text == text:
        return False
    tmp = note_file.with_suffix(note_file.suffix + ".tmp")
    tmp.write_text(new_text, encoding="utf-8")
    tmp.replace(note_file)  # atomic within the same dir
    return True


# --------------------------------------------------------------------------- #
# Ownership transfer + backups                                                #
# --------------------------------------------------------------------------- #


def _backup(path: Path) -> str | None:
    """Copy ``path`` to ``path.bak`` (overwrite) before mutation; None if absent."""
    if not path.is_file():
        return None
    bak = path.with_suffix(path.suffix + ".bak")
    shutil.copy2(path, bak)
    return str(bak)


# --------------------------------------------------------------------------- #
# Re-tag run                                                                  #
# --------------------------------------------------------------------------- #


def retag_corpus(
    vault_path: Path | None = None,
    *,
    current_prefixes: tuple[str, ...] = DEFAULT_CURRENT_PREFIXES,
    scope: str | None = None,
    limit: int | None = None,
    dry_run: bool = True,
    log: Callable[[str], None] | None = None,
    legacy_manifest: Path | None = None,
    current_manifest: Path | None = None,
) -> RetagStats:
    """Re-tag confirmed legacy→current notes and transfer manifest ownership.

    Drives off the **legacy ingest manifest** (its keys are the source→note map and
    the drop-loop's ``prev``): every note-bearing entry is classified
    (:func:`classify`); a :data:`CURRENT` verdict re-tags the note's frontmatter,
    moves the entry legacy→current manifest, and marks the note for the CLI's
    incremental reindex. Entries that stay legacy/ambiguous are never touched.

    ``scope`` filters the candidate set to entries whose ``source_path`` starts with
    it (e.g. ``"2023-2026/Kazakhstan/Acme"`` for a canary). ``limit`` caps the
    number of notes **migrated** this run (a small, safe batch) — the same code as a
    full run, just a smaller selection. Both compose. ``dry_run`` (the CLI default)
    computes the full disposition and writes nothing.

    Idempotent + resumable: migrated entries leave the legacy manifest, so a re-run
    (or resume after a kill) re-examines only the remainder; both manifests are
    checkpointed every :data:`_CHECKPOINT_EVERY` migrations and flushed on
    interrupt. Notes are **never** deleted. Backups (``.bak``) of both manifests are
    written before the first mutation.
    """
    start = time.perf_counter()
    log = log or (lambda _m: None)
    vault_path = Path(vault_path) if vault_path is not None else default_vault_path()
    legacy_path = legacy_manifest or legacy_ingest_manifest_path()
    current_path = current_manifest or current_ingest_manifest_path()

    legacy = _load_manifest(legacy_path)
    current = _load_manifest(current_path)
    stats = RetagStats(
        dry_run=dry_run,
        scope=scope or "",
        limit=limit,
        legacy_manifest_path=str(legacy_path),
        current_manifest_path=str(current_path),
    )

    # Candidate set: note-bearing legacy entries, deterministic (sorted) order.
    note_keys = [sp for sp, e in legacy.items() if e.get("note_path")]
    stats.total_entries = len(note_keys)
    selection = sorted(sp for sp in note_keys if not scope or sp.startswith(scope))

    backed_up = False
    dirty = 0  # migrations since the last checkpoint

    def _checkpoint() -> None:
        if dry_run:
            return
        _save_manifest(legacy_path, legacy)
        _save_manifest(current_path, current)

    try:
        for source_path in selection:
            if limit is not None and stats.n_current >= limit:
                break  # canary batch complete — leave the rest untouched
            stats.selected += 1
            entry = legacy[source_path]
            note_rel = str(entry.get("note_path") or "")
            note_file = vault_path / note_rel

            verdict, resolved, live_hash = _classify(
                source_path, entry, vault_path, current_prefixes=current_prefixes
            )
            if verdict == LEGACY:
                stats.n_legacy_kept += 1
                continue
            if verdict == AMBIGUOUS:
                stats.n_ambiguous += 1
                log(f"[retag] ambiguous (kept legacy): {source_path}")
                continue

            # verdict == CURRENT
            if not note_file.is_file():
                stats.missing_note += 1
                log(f"[retag] note missing on disk, skipped: {note_rel}")
                continue

            already = _current_corpus(note_file.read_text(encoding="utf-8")) == CURRENT
            if already:
                stats.already_current += 1

            if dry_run:
                stats.n_current += 1
                if len(stats.examples) < 5:
                    stats.examples.append(note_rel)
                log(f"[retag] would migrate → current: {source_path}")
                continue

            # Backups once, before the first real mutation.
            if not backed_up:
                for p in (legacy_path, current_path):
                    bak = _backup(p)
                    if bak:
                        stats.backups.append(bak)
                backed_up = True

            # 1) Re-tag frontmatter (idempotent) → content hash changes → reindex.
            changed = _retag_frontmatter(note_file, CURRENT)
            # 2) Ownership transfer: legacy → current manifest (the guard). Stamp
            #    source_content_hash = byte-hash of the live file (legacy entries
            #    lack it — variant A) so the future current-ingest/relocation dedup
            #    works by content. Reuse the hash computed in _classify if any; else
            #    hash the already-resolved live file once (no double hashing).
            assert resolved is not None  # noqa: S101 — type-narrowing; CURRENT ⇒ live file
            stamped = dict(entry)
            stamped[HASH_FIELD] = live_hash or file_content_hash(resolved)
            current[source_path] = stamped
            legacy.pop(source_path, None)

            stats.n_current += 1
            if changed:
                stats.changed_note_paths.append(note_rel)
            if len(stats.examples) < 5:
                stats.examples.append(note_rel)
            log(f"[retag] migrated → current: {source_path}")

            dirty += 1
            if dirty >= _CHECKPOINT_EVERY:
                _checkpoint()
                dirty = 0
                log(f"[retag] checkpoint: {stats.n_current} migrated so far")
    finally:
        # Flush the final (or interrupted) state — SIGTERM maps to KeyboardInterrupt
        # at the CLI, so this persists a consistent, resumable checkpoint.
        if not dry_run and (dirty or stats.n_current):
            _checkpoint()

    stats.reindexed = len(stats.changed_note_paths)
    stats.elapsed_s = time.perf_counter() - start
    return stats
