"""DB-1 — the single SQLite backend for facts / sources / jobs (audit §4.5).

Before DB-1 three structural stores had drifted apart — ``facts.db`` (SQLite),
``sources/index.json`` (JSON, no transaction ⇒ a cron crash between load→save
could leave a half-written registry), and ``jobs.db`` (SQLite) — each with its own
connection and its own version stamp, with no shared migrations. This package is
the one place they now live: a single ``.derived/dt.db`` (``config.dt_db_path``),
one :func:`connect` (WAL + ``busy_timeout`` + ``row_factory``), and one ordered
migration framework (:mod:`core.db.migrations`) with a single schema version.

The public APIs of FACT-1/SRC-1/JOB-1 are **unchanged** — only the backend moved:
``core.facts.store``, ``core.sources.cache`` (registry) and
``core.orchestration.jobs`` all obtain their connection here and keep their table
inside ``dt.db``. On first open of the canonical DB, the pre-DB-1 files that sit
beside it are imported once and renamed ``.bak`` (:func:`import_legacy_stores`),
so nothing is lost and no re-import happens on later opens.

Multi-process is real (cron-sync + MCP server + JOB-1 worker write concurrently),
hence WAL + ``busy_timeout`` are mandatory. stdlib ``sqlite3``, no ORM. Path B —
no network, no LLM. Invariant: ``core/db`` imports neither MCP nor CLI.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

from core.config import dt_db_path
from core.db.migrations import (
    DB_SCHEMA_VERSION,
    apply_migrations,
    current_version,
    import_legacy_stores,
)

__all__ = [
    "DB_SCHEMA_VERSION",
    "connect",
    "schema_version",
    "table_counts",
]

# Busy timeout for a locked DB — cron-sync/MCP/worker contend on the same file.
_BUSY_TIMEOUT_MS = 5000
_CONNECT_TIMEOUT_S = 30.0


def connect(db_path: Path | None = None) -> sqlite3.Connection:
    """Open (creating + migrating) the unified DB and return a ready connection.

    Applies WAL + ``busy_timeout`` + ``row_factory=Row``, runs any pending schema
    migrations (idempotent), and — only for the canonical :func:`dt_db_path` —
    imports the pre-DB-1 stores once. ``db_path`` overrides the location (tests and
    the FACT-1/JOB-1 ``db_path=`` parameters pass their own). The caller closes it
    (the DAOs open-op-close, as before).
    """
    path = Path(db_path) if db_path is not None else dt_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=_CONNECT_TIMEOUT_S)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
    apply_migrations(conn)
    # Only the canonical unified DB pulls in legacy files sitting beside it — an
    # isolated test/subsystem DB (a different path) must never read real .derived.
    if path == dt_db_path():
        import_legacy_stores(conn, path)
    return conn


def schema_version(db_path: Path | None = None) -> int | None:
    """Current unified schema version of the DB, or ``None`` if it doesn't exist.

    Backs ``stored_schema_version`` in facts/jobs (one version for the whole DB)
    and the ``dt doctor`` line. A missing file returns ``None`` (nothing created
    yet); an existing file always reports at least the version just migrated to.
    """
    path = Path(db_path) if db_path is not None else dt_db_path()
    if not path.is_file():
        return None
    conn = connect(path)
    try:
        return current_version(conn)
    finally:
        conn.close()


def table_counts(db_path: Path | None = None) -> dict[str, int]:
    """Row counts for the core tables (facts / sources / jobs) — for ``dt doctor``.

    A missing table (nothing written yet) counts as 0 rather than raising.
    """
    path = Path(db_path) if db_path is not None else dt_db_path()
    counts = {"facts": 0, "sources": 0, "jobs": 0}
    if not path.is_file():
        return counts
    conn = connect(path)
    try:
        for table in counts:
            try:
                row = conn.execute(f"SELECT COUNT(*) AS n FROM {table}").fetchone()  # noqa: S608 — fixed names
                counts[table] = int(row["n"]) if row else 0
            except sqlite3.OperationalError:
                counts[table] = 0
    finally:
        conn.close()
    return counts
