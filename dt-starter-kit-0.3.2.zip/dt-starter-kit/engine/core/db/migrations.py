"""DB-1 — schema migrations + one-time legacy import for the unified ``dt.db``.

Two mechanisms, both **explicit and inspectable** (принцип «никакой магии»):

* **schema migrations** — an ordered list of ``(version, description, apply)`` steps
  recorded in a ``schema_migrations`` table. :func:`apply_migrations` runs the
  missing ones in a transaction, idempotently (a re-open applies nothing). This is
  the *single* schema version for the whole DB (facts + sources + jobs), replacing
  the three separate ``meta.schema_version`` stamps of FACT-1/JOB-1/SRC-1.
* **legacy import** — a one-time, guarded copy of the pre-DB-1 stores
  (``facts.db`` / ``jobs.db`` SQLite, ``sources/index.json`` JSON) into the unified
  tables, renaming each source to ``.bak`` (never deleted silently). Runs only when
  the canonical :func:`~core.config.dt_db_path` is opened, so an isolated test DB
  never reads a real ``.derived/`` file.

stdlib ``sqlite3`` only, no ORM. Path B: no network, no LLM.
"""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

__all__ = [
    "DB_SCHEMA_VERSION",
    "MIGRATIONS",
    "apply_migrations",
    "current_version",
    "import_legacy_stores",
]

Migration = tuple[int, str, Callable[[sqlite3.Connection], None]]

# Facts column → SQL type (everything else TEXT) — kept in lockstep with
# ``core.facts.store`` (imported lazily below to avoid an import cycle: the store
# imports this package). The column *names* come from ``FACT_COLUMNS`` so the two
# can never drift on the set of columns.
_FACTS_NUMERIC = {
    "value_num": "REAL", "confidence": "REAL", "schema_version": "INTEGER", "scale": "REAL",
}
_FACTS_BOOL = {"stale_hint", "is_total", "provisional"}


def _iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _facts_ddl() -> str:
    """DDL body for the ``facts`` table, columns from :data:`FACT_COLUMNS`."""
    from core.facts.schema import FACT_COLUMNS  # lazy: store imports this package

    defs: list[str] = []
    for col in FACT_COLUMNS:
        if col == "fact_id":
            defs.append("fact_id TEXT PRIMARY KEY")
        elif col in _FACTS_NUMERIC:
            defs.append(f"{col} {_FACTS_NUMERIC[col]}")
        elif col in _FACTS_BOOL:
            defs.append(f"{col} INTEGER")
        else:
            defs.append(f"{col} TEXT")
    return ", ".join(defs)


def _v1_initial_schema(conn: sqlite3.Connection) -> None:
    """v1 — the initial unified schema: facts + sources + jobs (+ shared meta).

    Each table mirrors its pre-DB-1 shape exactly (FACT-1 facts, SRC-1 registry,
    JOB-1 jobs) so the migrated data and the unchanged public APIs line up 1:1.
    """
    # facts (FACT-1) — same columns/indexes as the standalone facts.db.
    conn.execute(f"CREATE TABLE IF NOT EXISTS facts ({_facts_ddl()})")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_facts_entity ON facts(entity_ref)")
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_facts_source ON facts(source_content_hash)"
    )

    # sources (SRC-1 registry) — the JSON index.json, now a table. paths/note_refs
    # are JSON arrays so load_index() reconstructs the exact prior dict shape.
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS sources (
            content_hash TEXT PRIMARY KEY,
            paths TEXT,
            mtime REAL,
            size INTEGER,
            kind TEXT,
            status TEXT,
            last_lift TEXT,
            note_refs TEXT
        )
        """
    )

    # jobs (JOB-1) — identical shape to the standalone jobs.db.
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS jobs (
            job_id TEXT PRIMARY KEY,
            op TEXT NOT NULL,
            args_hash TEXT,
            args_json TEXT,
            state TEXT NOT NULL,
            phase TEXT,
            current INTEGER,
            total INTEGER,
            checkpoint_path TEXT,
            result_ref TEXT,
            error TEXT,
            cancel_requested INTEGER DEFAULT 0,
            worker_pid INTEGER,
            created_at TEXT,
            updated_at TEXT
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_state ON jobs(state)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_created ON jobs(created_at)")

    # Shared key/value meta (flags like legacy_imported; NOT per-subsystem version).
    conn.execute("CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)")


def _v2_events(conn: sqlite3.Connection) -> None:
    """v2 — the append-only pipeline event-log (PULT-EVENTLOG).

    One row per stage touch of an artifact (ingest→hub→index→link). Identity is
    ``note_id`` (the post-ingest thread) with ``source_hash`` on the ingest event
    (the file→note stitch); ``run_id`` groups one pipeline/bulk run. ``detail`` is
    JSON — stage metadata only (counts/statuses/relative paths), never body/sums.
    Append-only (insert), so no updated_at. Indexes back the two hot reads
    (timeline by note, recent feed by time) + run grouping.
    """
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS events (
            event_id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            note_id TEXT,
            source_hash TEXT,
            path TEXT,
            stage TEXT NOT NULL,
            status TEXT NOT NULL,
            detail TEXT,
            run_id TEXT
        )
        """
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_events_note ON events(note_id, ts)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_events_run ON events(run_id)")


def _v3_facts_fact2(conn: sqlite3.Connection) -> None:
    """v3 - FACT-2: ``facts`` += ``scale`` (REAL), ``section`` (TEXT), ``is_total`` (INTEGER).

    Идемпотентно: у БД, созданной ПОСЛЕ FACT-2, колонки уже есть (DDL v1 строится из
    ``FACT_COLUMNS``), поэтому добавляем только отсутствующие. Старые строки получают ``NULL``
    (``scale``) / ``NULL`` (``section``, ``is_total``) до переизвлечения - читатель трактует их как
    «нет масштаба / нет секции / не итог».
    """
    have = {row["name"] for row in conn.execute("PRAGMA table_info(facts)")}
    for col, ddl in (("scale", "REAL"), ("section", "TEXT"), ("is_total", "INTEGER")):
        if col not in have:
            conn.execute(f"ALTER TABLE facts ADD COLUMN {col} {ddl}")


_V4_COLUMNS = (
    ("valid_from", "TEXT"), ("valid_to", "TEXT"), ("known_at", "TEXT"), ("superseded_at", "TEXT"),
    ("superseded_by", "TEXT"), ("fact_key", "TEXT"), ("prev_fact_id", "TEXT"),
    ("provisional", "INTEGER"), ("date_basis", "TEXT"),
)


def _v4_facts_bitemporal(conn: sqlite3.Connection) -> None:
    """v4 - FACTS-BITEMPORAL-1: две оси времени и цепочка версий у ``facts``.

    Колонки ``valid_from/valid_to/known_at/superseded_at/superseded_by/fact_key/prev_fact_id/
    provisional/date_basis``; идемпотентно (БД, созданная после v4, колонки уже имеет - DDL v1
    строится
    из ``FACT_COLUMNS``). **Бэкфилл** - только из того, что уже лежит в БД, без обхода файловой
    системы: ``known_at`` = ``sources.mtime`` (нет в реестре - ``stat`` самого файла, нет файла -
    ``NULL``), ``valid_from`` = дата из имени файла, иначе дата mtime, иначе ``NULL``
    (``date_basis``
    ``name``/``mtime``/``''`` - по нему отчет «чем датировано»), ``fact_key`` по ``entity_ref`` +
    подпись + секция + единица + вид. Цепочка версий и черновики (нужен листинг папок) - отдельным
    явным шагом ``dt facts backfill``. Строка с ``date_basis IS NOT NULL`` уже бэкфиллена - повтор
    ничего не меняет. ``fact_id`` не трогается.
    """
    from core.facts import temporal
    from core.facts.schema import Fact

    have = {row["name"] for row in conn.execute("PRAGMA table_info(facts)")}
    for col, ddl in _V4_COLUMNS:
        if col not in have:
            conn.execute(f"ALTER TABLE facts ADD COLUMN {col} {ddl}")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_facts_key ON facts(fact_key)")
    rows = conn.execute(
        "SELECT fact_id, source_path, source_content_hash, entity_ref, kind, label, section, "
        "unit, currency FROM facts WHERE date_basis IS NULL"
    ).fetchall()
    if not rows:
        return
    mtimes: dict[str, float | None] = {}
    try:
        for r in conn.execute("SELECT content_hash, mtime FROM sources"):
            mtimes[str(r["content_hash"])] = r["mtime"]
    except sqlite3.OperationalError:
        pass
    batch: list[tuple[object, ...]] = []
    for r in rows:
        h = str(r["source_content_hash"])
        if h not in mtimes:
            try:
                mtimes[h] = Path(str(r["source_path"])).stat().st_mtime
            except OSError:
                mtimes[h] = None
        mtime = mtimes[h]
        valid_from, basis = temporal.document_date(str(r["source_path"]), mtime)
        probe = Fact(
            fact_id=r["fact_id"], entity_ref=r["entity_ref"], source_path="",
            source_content_hash="", locator="", kind=r["kind"], label=r["label"] or "",
            value_num=None, value_raw="", unit=r["unit"], currency=r["currency"],
            section=r["section"] or "",
        )
        batch.append((valid_from, temporal.known_at_iso(mtime), temporal.fact_key(probe), basis,
                      r["fact_id"]))
    conn.executemany(
        "UPDATE facts SET valid_from=?, known_at=?, fact_key=?, provisional=0, date_basis=?, "
        "schema_version=3 WHERE fact_id=?", batch,
    )


# Ordered migration steps. Append new steps with the next version — never rewrite
# an applied one (the framework only runs versions greater than the recorded max).
MIGRATIONS: list[Migration] = [
    (1, "initial unified schema (facts, sources, jobs, meta)", _v1_initial_schema),
    (2, "pipeline event-log (events) — PULT-EVENTLOG", _v2_events),
    (3, "facts: scale/section/is_total — FACT-2", _v3_facts_fact2),
    (4, "facts: две оси времени + цепочка версий — FACTS-BITEMPORAL-1", _v4_facts_bitemporal),
]

DB_SCHEMA_VERSION = MIGRATIONS[-1][0]


def current_version(conn: sqlite3.Connection) -> int:
    """Highest applied migration version (0 when the DB is brand new)."""
    try:
        row = conn.execute("SELECT MAX(version) AS v FROM schema_migrations").fetchone()
    except sqlite3.OperationalError:
        return 0
    return int(row["v"]) if row and row["v"] is not None else 0


def apply_migrations(conn: sqlite3.Connection) -> int:
    """Apply every migration newer than the recorded version; return the new one.

    Idempotent — with nothing pending it only reads the current version. Each step
    runs in its own transaction together with its ``schema_migrations`` stamp, so a
    crash mid-step rolls back cleanly and the next open re-runs it (a partially
    applied schema is *doведётся*, never left half-built).
    """
    prev_isolation = conn.isolation_level
    conn.isolation_level = None  # manual BEGIN/COMMIT so DDL is transactional
    try:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_migrations "
            "(version INTEGER PRIMARY KEY, applied_at TEXT)"
        )
        version = current_version(conn)
        for step_version, _desc, apply in MIGRATIONS:
            if step_version <= version:
                continue
            conn.execute("BEGIN")
            try:
                apply(conn)
                conn.execute(
                    "INSERT INTO schema_migrations(version, applied_at) VALUES (?, ?)",
                    (step_version, _iso()),
                )
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            version = step_version
        return version
    finally:
        conn.isolation_level = prev_isolation


# --------------------------------------------------------------------------- #
# One-time legacy import (pre-DB-1 stores → unified tables)                    #
# --------------------------------------------------------------------------- #
def _meta_flag(conn: sqlite3.Connection, key: str) -> str | None:
    try:
        row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    except sqlite3.OperationalError:
        return None
    return str(row["value"]) if row else None


def _table_empty(conn: sqlite3.Connection, table: str) -> bool:
    try:
        row = conn.execute(f"SELECT 1 FROM {table} LIMIT 1").fetchone()  # noqa: S608 — fixed names
    except sqlite3.OperationalError:
        return True
    return row is None


def _backup(path: Path) -> None:
    """Rename a migrated legacy file to ``<name>.bak`` (never delete silently)."""
    try:
        bak = path.with_name(path.name + ".bak")
        if bak.exists():
            bak.unlink()
        path.replace(bak)
    except OSError:
        pass  # best-effort — the data is already in the table


def _import_facts(conn: sqlite3.Connection, legacy_db: Path) -> int:
    """Copy rows from a pre-DB-1 ``facts.db`` into the unified ``facts`` table."""
    from core.facts.schema import FACT_COLUMNS

    src = sqlite3.connect(str(legacy_db))
    src.row_factory = sqlite3.Row
    try:
        try:
            # FACT-2: старый facts.db без новых колонок - берем те, что есть (остальные NULL).
            have = {r["name"] for r in src.execute("PRAGMA table_info(facts)")}
            use = [c for c in FACT_COLUMNS if c in have]
            if not use:
                return 0
            rows = src.execute(f"SELECT {', '.join(use)} FROM facts").fetchall()  # noqa: S608 — SQL from our own quoted identifiers, not user input
        except sqlite3.OperationalError:
            return 0
    finally:
        src.close()
    if not rows:
        return 0
    placeholders = ", ".join("?" for _ in use)
    cols = ", ".join(use)
    conn.executemany(
        f"INSERT OR IGNORE INTO facts ({cols}) VALUES ({placeholders})",  # noqa: S608 — SQL from our own quoted identifiers, not user input
        [tuple(r[c] for c in use) for r in rows],
    )
    conn.commit()
    return len(rows)


def _import_jobs(conn: sqlite3.Connection, legacy_db: Path) -> int:
    """Best-effort copy of a pre-DB-1 ``jobs.db`` into the unified ``jobs`` table."""
    cols = [
        "job_id", "op", "args_hash", "args_json", "state", "phase", "current",
        "total", "checkpoint_path", "result_ref", "error", "cancel_requested",
        "worker_pid", "created_at", "updated_at",
    ]
    src = sqlite3.connect(str(legacy_db))
    src.row_factory = sqlite3.Row
    try:
        try:
            rows = src.execute(f"SELECT {', '.join(cols)} FROM jobs").fetchall()  # noqa: S608 — SQL from our own quoted identifiers, not user input
        except sqlite3.OperationalError:
            return 0
    finally:
        src.close()
    if not rows:
        return 0
    placeholders = ", ".join("?" for _ in cols)
    conn.executemany(
        f"INSERT OR IGNORE INTO jobs ({', '.join(cols)}) VALUES ({placeholders})",  # noqa: S608 — SQL from our own quoted identifiers, not user input
        [tuple(r[c] for c in cols) for r in rows],
    )
    conn.commit()
    return len(rows)


def _import_sources(conn: sqlite3.Connection, legacy_index: Path) -> int:
    """Copy the SRC-1 ``index.json`` registry into the unified ``sources`` table.

    Preserves ``note_refs`` and ``paths`` (stored as JSON arrays), mirroring the
    prior in-JSON entry shape so ``load_index`` reconstructs it 1:1.
    """
    try:
        data = json.loads(legacy_index.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return 0
    if not isinstance(data, dict):
        return 0
    n = 0
    for content_hash, entry in data.items():
        if not isinstance(entry, dict):
            continue
        conn.execute(
            "INSERT OR IGNORE INTO sources "
            "(content_hash, paths, mtime, size, kind, status, last_lift, note_refs) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                str(content_hash),
                json.dumps(
                    [p for p in entry.get("paths", []) if isinstance(p, str)],
                    ensure_ascii=False,
                ),
                entry.get("mtime"),
                entry.get("size"),
                entry.get("kind"),
                entry.get("status"),
                entry.get("last_lift"),
                json.dumps(
                    [n for n in entry.get("note_refs", []) if isinstance(n, str)],
                    ensure_ascii=False,
                ),
            ),
        )
        n += 1
    conn.commit()
    return n


def import_legacy_stores(conn: sqlite3.Connection, db_path: Path) -> dict[str, int]:
    """One-time import of the pre-DB-1 stores that sit beside ``db_path``.

    Guarded three ways so it is safe and idempotent: a ``meta.legacy_imported``
    flag short-circuits after a full pass; each table is imported only when it is
    still **empty** AND its legacy file **exists** (and is not the DB itself); the
    legacy file is renamed to ``.bak`` on success. A second run (or a run after a
    partial crash) never duplicates rows. Returns per-store counts.
    """
    counts = {"facts": 0, "sources": 0, "jobs": 0}
    if _meta_flag(conn, "legacy_imported") == "1":
        return counts

    # A sibling facts.db/jobs.db is "legacy" only if it is NOT the store the config
    # currently points at — otherwise a standalone facts DB (DT_FACTS_DB_PATH set to
    # a file beside dt.db) would be mistaken for the pre-DB-1 file and renamed away.
    from core.config import facts_db_path, jobs_db_path

    active_facts = facts_db_path()
    active_jobs = jobs_db_path()

    parent = db_path.parent
    legacy_facts = parent / "facts.db"
    legacy_jobs = parent / "jobs.db"
    legacy_sources = parent / "sources" / "index.json"

    if (
        legacy_facts not in (db_path, active_facts)
        and legacy_facts.is_file()
        and _table_empty(conn, "facts")
    ):
        counts["facts"] = _import_facts(conn, legacy_facts)
        _backup(legacy_facts)
    if (
        legacy_jobs not in (db_path, active_jobs)
        and legacy_jobs.is_file()
        and _table_empty(conn, "jobs")
    ):
        counts["jobs"] = _import_jobs(conn, legacy_jobs)
        _backup(legacy_jobs)
    if legacy_sources.is_file() and _table_empty(conn, "sources"):
        counts["sources"] = _import_sources(conn, legacy_sources)
        _backup(legacy_sources)

    conn.execute(
        "INSERT OR REPLACE INTO meta(key, value) VALUES ('legacy_imported', '1')"
    )
    conn.commit()
    return counts
