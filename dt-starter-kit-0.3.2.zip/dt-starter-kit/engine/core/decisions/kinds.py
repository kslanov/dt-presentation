"""QUEUE-SERVER-1 — виды карточек реестра (фасады над ядрами решений; ``synth``, ``lint``).

Здесь нет логики решений: каждый вид читает свой стор, строит карточки единой формы и зовет СВОЕ
ядро (``decide_link``, ``decide_reattr``, ``decide_assignment``, ``route_capture``,
``decide_hub_candidate``, ``decide_hub_alias``, ``decide_golden_candidate``, ``snooze_lead`` /
``reject_lead``). Ядра, ``scaffold_hub`` и сторы не меняются.

Единственное, чего ядра не умели, - HUB-CAND-LINK-1: кандидат от сделки Timetta
(``timetta:deal:<code>``) при ``approve`` создает хаб, а затем (тем же действием человека)
записывает ``timetta_id`` сделки :func:`core.operational.hub_link.link_hub_to_deal`; действие
``link`` привязывает кандидата к уже существующему хабу (``params.hub_id``) и закрывает его
статусом ``linked``. Хаб никогда не создается и ``timetta_id`` никогда не пишется без явного
действия человека: список только читает.
"""

from __future__ import annotations

import dataclasses
from pathlib import Path
from typing import Any

from core.decisions.registry import (
    ActionSpec,
    CardKind,
    KindPage,
    KindUnavailable,
    QueueEnv,
    card_id,
)

__all__ = ["build_kinds", "similar_hubs", "KIND_LABELS", "BridgeKind"]

_TITLE_CAP = 90
# Сходство имени кандидата с именами/алиасами хаба: доля общих стем-ключей слов (Жаккар).
_SIMILAR_MIN_SHARE = 0.34
_SIMILAR_LIMIT = 3
_SIMILAR_POOL = 8  # сколько лучших читаем с диска, чтобы отличить свободные хабы от занятых


def _cut(text: Any, n: int) -> str:
    s = " ".join(str(text or "").split())
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"


def _slice(rows: list[Any], limit: int) -> list[Any]:
    return rows[:limit] if limit and limit > 0 else rows


def _card(
    kind: str,
    native: str,
    *,
    title: str,
    reason: str,
    since: str | None,
    meta: dict[str, Any],
    actions: list[dict[str, Any]],
    explainable: bool,
) -> dict[str, Any]:
    return {
        "id": card_id(kind, native),
        "kind": kind,
        "title": title,
        "reason": reason,
        "since": since or None,
        "meta": meta,
        "actions": actions,
        "explainable": explainable,
    }


def _rel(vault: Path, path: str | Path) -> str:
    try:
        return Path(path).resolve().relative_to(vault.resolve()).as_posix()
    except (ValueError, OSError):
        return str(path)


def _stat_stamp(path: Any) -> list[Any]:
    """``[путь, mtime_ns, размер]`` файла (нет файла - ``None``): часть токена снимка вида."""
    p = Path(path)
    try:
        st = p.stat()
    except OSError:
        return [str(p), None, None]
    return [str(p), st.st_mtime_ns, st.st_size]


def _hub_folders_stamp(vault: Any) -> list[Any]:
    """Токен каталога хабов: число/свежесть/размер ``*.md`` в папках хабов vault (``stat``).

    Правка алиаса/H1 хаба, новый хаб, удаление - меняют токен; хаб вне папок скаффолда ловит TTL."""
    from core.legacy.linking import _HUB_FOLDERS

    root = Path(vault)
    n = newest = total = 0
    for folder in sorted(set(_HUB_FOLDERS.values())):
        try:
            for md in (root / folder).glob("*.md"):
                st = md.stat()
                n += 1
                newest = max(newest, st.st_mtime_ns)
                total += st.st_size
        except OSError:
            continue
    return [str(root), n, newest, total]


# --------------------------------------------------------------------------- #
# link - предложения ссылок (серая зона semantic)                                #
# --------------------------------------------------------------------------- #
class LinkKind(CardKind):
    kind = "link"
    label = "Ссылки"
    actions = (
        ActionSpec("approve", "Применить", "primary"),
        ActionSpec("reject", "Отклонить", "secondary"),
    )

    def _load(self, env: QueueEnv) -> Any:
        from core.config import link_proposals_path
        from core.linking.propose import LinkProposalQueue

        return LinkProposalQueue.load(env.link_proposals or link_proposals_path())

    def cache_stamp(self, env: QueueEnv) -> Any:
        from core.config import link_proposals_path

        return [_stat_stamp(env.link_proposals or link_proposals_path())]

    def _pending(self, env: QueueEnv) -> list[Any]:
        from core.linking.propose import STATUS_PENDING

        rows = [p for p in self._load(env).by_id.values() if p.status == STATUS_PENDING]
        rows.sort(key=lambda p: (-p.score, p.source_note))
        return rows

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        rows = self._pending(env)
        cards = [
            _card(
                self.kind, p.id,
                title=f"Слинковать «{p.source_note}» → «{p.target_note}»",
                reason=f"semantic {float(p.score):.2f} · серая зона · {p.target_type}",
                since=None,
                meta={"source": p.source_note, "target": p.target_note,
                      "score": round(float(p.score), 4), "target_type": p.target_type,
                      "resolver": p.resolver},
                actions=[a.to_dict() for a in self.actions],
                explainable=True,
            )
            for p in _slice(rows, limit)
        ]
        return KindPage(cards, len(rows))

    def count(self, env: QueueEnv) -> int:
        return len(self._pending(env))

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.linking.decide import decide_link

        raw = decide_link(
            proposal_id=native_id, decision=action, queue=self._load(env),
            vault_path=env.vault_path(),
        )
        out = str(raw.get("outcome"))
        detail = str(raw.get("explanation") or "")
        if out == "applied":
            effect = ("ссылка уже была в заметке" if raw.get("already_present")
                      else "ссылка вставлена в «## Связано» заметки-источника")
            return {"outcome": "applied", "detail": detail, "effects": [effect]}
        if out == "rejected":
            return {"outcome": "rejected", "detail": detail,
                    "effects": ["пара отклонена навсегда"]}
        if out == "stale":
            return {"outcome": "stale", "detail": detail}
        return {"outcome": "refused", "code": "apply_failed", "detail": detail}

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        from core.operational.work import note_preview

        p = self._load(env).by_id.get(native_id)
        if p is None:
            return None
        vault = env.vault_path()

        def note(role: str, ref: str) -> dict[str, Any]:
            n = note_preview(ref, vault_path=vault)
            return {"role": role, "id": ref, "found": bool(n.get("found")),
                    "title": n.get("title") or ref, "preview": n.get("preview") or ""}

        evidence = " ".join(str(p.evidence_snippet or "").split())
        return {
            "notes": [note("source", p.source_note), note("target", p.target_note)],
            "score": round(float(p.score), 4),
            "resolver": p.resolver,
            "target_type": p.target_type,
            "evidence": evidence[:240],
            "rationale": p.rationale,
        }


# --------------------------------------------------------------------------- #
# reattr - переатрибуция заметки после переезда файла                           #
# --------------------------------------------------------------------------- #
class ReattrKind(CardKind):
    kind = "reattr"
    label = "Переатрибуция"
    actions = (
        ActionSpec("apply", "Применить", "primary"),
        ActionSpec("reject", "Отклонить", "secondary"),
    )

    def _load(self, env: QueueEnv) -> Any:
        from core.linking.reattr import ReattrQueue

        queue = ReattrQueue.load(env.reattr_proposals)
        if queue.read_error:
            raise KindUnavailable(
                "store_unavailable", f"очередь переатрибуции не прочитана: {queue.read_error}")
        return queue

    def _pending(self, env: QueueEnv) -> list[Any]:
        from core.linking.reattr import STATUS_PENDING

        rows = [p for p in self._load(env).by_id.values() if p.status == STATUS_PENDING]
        rows.sort(key=lambda p: (p.detected_at, p.id), reverse=True)
        return rows

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        rows = self._pending(env)
        cards = [
            _card(
                self.kind, p.id,
                title=(f"Переатрибуция: {', '.join(p.from_hubs) or 'без хаба'} → "
                       f"{', '.join(p.to_hubs)}"),
                reason=f"файл переехал между каталогами · {_cut(p.new_path, 70)}",
                since=p.detected_at,
                meta={"note_id": p.note_id, "old_path": p.old_path, "new_path": p.new_path,
                      "from_hubs": list(p.from_hubs), "to_hubs": list(p.to_hubs)},
                actions=[a.to_dict() for a in self.actions],
                explainable=True,
            )
            for p in _slice(rows, limit)
        ]
        return KindPage(cards, len(rows))

    def count(self, env: QueueEnv) -> int:
        return len(self._pending(env))

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.linking.reattr_decide import decide_reattr

        raw = decide_reattr(
            proposal_id=native_id, decision=action, queue=self._load(env),
            vault_path=env.vault_path(),
        )
        out = str(raw.get("outcome"))
        detail = str(raw.get("explanation") or "")
        if out == "applied":
            effects = [f"атрибуция перевешена на «{raw.get('client')}»"
                       if raw.get("changed") else "атрибуция уже была такой - файл не тронут"]
            if raw.get("needs_reindex"):
                effects.append("нужен reindex, чтобы заметку увидел ретривал")
            return {"outcome": "applied", "detail": detail, "effects": effects}
        if out == "rejected":
            return {"outcome": "rejected", "detail": detail,
                    "effects": ["тот же перенос больше не предложит переатрибуцию"]}
        if out == "stale":
            return {"outcome": "stale", "detail": detail}
        warn = (raw.get("warning") or [{}])[0] if isinstance(raw.get("warning"), list) else {}
        code = str(raw.get("code") or warn.get("code") or "failed")
        return {"outcome": "refused", "code": "unknown_card" if out == "not_found" else code,
                "detail": detail or str(warn.get("reason") or "")}

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        p = self._load(env).by_id.get(native_id)
        if p is None:
            return None
        return {"note_id": p.note_id, "old_path": p.old_path, "new_path": p.new_path,
                "from_hubs": list(p.from_hubs), "to_hubs": list(p.to_hubs),
                "detected_at": p.detected_at}


# --------------------------------------------------------------------------- #
# assignment - поручение администратору CRM (лейн #поручение)                   #
# --------------------------------------------------------------------------- #
_ASSIGNMENT_SENT_CONFIRM = "Письмо администратору CRM отправлено? Карточка закроется."
_ASSIGNMENT_REJECT_CONFIRM = "Отклонить поручение? Текст уйдет в архив инбокса, карточка закроется."


def _deal_label(d: dict[str, Any]) -> str:
    label = " ".join(str(x) for x in (d.get("code"), d.get("name")) if x)
    ring = d.get("ring")
    return f"{label} · {ring}" if ring and ring != "mine" else label


def _assignment_reason(card: dict[str, Any]) -> str:
    deal = card.get("deal")
    if not deal:
        return "сделка не определена - выберите в «ещё…»"
    name = " ".join(str(x) for x in (deal.get("code"), deal.get("name")) if x)
    return (f"сделка {name}" + (" · предложена движком" if card.get("deal_suggested") else "")
            + (f" · срок {card['due']}" if card.get("due") else ""))


class AssignmentKind(CardKind):
    kind = "assignment"
    label = "Поручения"
    actions = (
        ActionSpec("sent", "Отправлено", "secondary", confirm=_ASSIGNMENT_SENT_CONFIRM),
        ActionSpec("reject", "Отклонить", "danger", confirm=_ASSIGNMENT_REJECT_CONFIRM, more=True),
    )

    def _deals(self, env: QueueEnv) -> list[dict[str, Any]]:
        from core.operational.assignment import orbit_deals
        from core.operational.timetta.mirror import MirrorStore

        return orbit_deals(MirrorStore(env.mirror_path()))

    def _listing(self, env: QueueEnv) -> dict[str, Any]:
        from core.operational.assignment import list_assignments

        return list_assignments(
            state_path=env.capture_state_path(), inbox_dir=env.inbox_path(),
            deals=self._deals(env), admin_email=env.admin(),
        )

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        out = self._listing(env)
        deals = out["deals"]
        rows = out["cards"]
        cards = []
        for a in _slice(rows, limit):
            cand = [c["guid"] for c in a.get("candidates") or []]
            ordered = ([d for d in deals if d["guid"] in cand]
                       + [d for d in deals if d["guid"] not in cand])
            options = [{"value": d["guid"], "label": _deal_label(d),
                        "group": "кандидаты" if d["guid"] in cand else "орбита"} for d in ordered]
            chosen = (a.get("deal") or {}).get("guid")
            sent = dataclasses.replace(self.actions[0]).to_dict(params={
                "deal_guid": {"type": "select", "options": options, "default": chosen,
                              "more": True, "label": "Сделка (орбита, кольца 1–2)"}})
            cards.append(_card(
                self.kind, a["capture_id"],
                title="Поручение администратору CRM: " + _cut(a.get("title") or a.get("text"), 70),
                reason=_assignment_reason(a),
                since=a.get("captured"),
                meta={k: a.get(k) for k in (
                    "deal", "deal_suggested", "needs_deal", "candidates", "due", "formulation",
                    "subject", "body", "mailto", "admin_email", "lane_tag")},
                actions=[sent, self.actions[1].to_dict()],
                explainable=False,
            ))
        return KindPage(cards, len(rows))

    def explain_with(
        self, env: QueueEnv, native_id: str, params: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Черновик ОДНОЙ карточки под выбранную сделку (``params.deal_guid``): ``{draft: {...}}``.

        Чтение: ни манифест, ни inbox не меняются. Без ``deal_guid`` - как обычный ``explain``
        (``None``). Сделки вне орбиты колец 1-2 не принимаются (черновик собирается по орбите)."""
        guid = str(params.get("deal_guid") or "").strip()
        if not guid:
            return None
        from core.operational.assignment import list_assignments

        out = list_assignments(
            state_path=env.capture_state_path(), inbox_dir=env.inbox_path(),
            deals=self._deals(env), admin_email=env.admin(), capture_id=native_id, deal_guid=guid)
        found = out["cards"]
        if not found:
            return None
        keys = ("deal", "deal_suggested", "needs_deal", "due", "formulation", "subject", "body",
                "mailto", "admin_email")
        return {"draft": {k: found[0].get(k) for k in keys}}

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.operational.assignment import decide_assignment

        guid = str(params.get("deal_guid") or "").strip() or None
        raw = decide_assignment(
            native_id, action, deal_guid=guid, state_path=env.capture_state_path(),
            inbox_dir=env.inbox_path(),
        )
        out = str(raw.get("outcome"))
        if out == "sent":
            return {"outcome": "applied", "detail": "Поручение отмечено отправленным",
                    "effects": ["захват закрыт: routed_assignment"
                                + (" (сделка указана)" if guid else ""),
                                "заметка уехала в _staging/inbox/_done"]}
        if out == "rejected":
            return {"outcome": "rejected", "detail": "Поручение отклонено",
                    "effects": ["захват закрыт: dropped", "заметка уехала в _staging/inbox/_done"]}
        return {"outcome": "stale", "detail": str(raw.get("explanation") or "")}


# --------------------------------------------------------------------------- #
# untriaged - захват без распознанного тега                                      #
# --------------------------------------------------------------------------- #
_LANE_OPTIONS: tuple[dict[str, Any], ...] = (
    {"value": "knowledge", "label": "Знание",
     "confirm": "Маршрут: в знаниевый инбокс (разбор словами)?"},
    {"value": "assignment", "label": "Поручение",
     "confirm": "Маршрут: в поручения (карточка для администратора CRM)?"},
    {"value": "drop", "label": "Отклонить", "style": "danger",
     "confirm": "Маршрут: убрать (текст удаляется из учета)?"},
    {"value": "task", "label": "Задача", "more": True,
     "confirm": "Маршрут: останется задачей TickTick?"},
)
_LANE_PARAM = {"lane": {"type": "select", "ui": "buttons", "required": True,
                        "options": [dict(o) for o in _LANE_OPTIONS]}}


class UntriagedKind(CardKind):
    kind = "untriaged"
    label = "Захваты"
    actions = (ActionSpec("route", "Маршрут", "secondary", params=_LANE_PARAM),)

    def _rows(self, env: QueueEnv) -> tuple[list[dict[str, Any]], str]:
        from core.operational.capture_lane import annotate
        from core.operational.ticktick.capture import last_state_error, list_untriaged

        rows = annotate(list_untriaged(env.capture_state_path()))
        return rows, ("store_unavailable" if last_state_error() else "")

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        rows, error = self._rows(env)
        cards = []
        for u in _slice(rows, limit):
            tags = u.get("tags") or []
            cards.append(_card(
                self.kind, u["capture_id"],
                title=u.get("title") or _cut(u.get("text"), _TITLE_CAP),
                reason="захват без маршрута" + (" · #" + " #".join(tags) if tags else ""),
                since=u.get("captured"),
                meta={"text": u.get("text") or "", "tags": tags,
                      "suggested_lane": u.get("suggested_lane"),
                      "suggested_reason": u.get("suggested_reason")},
                actions=[a.to_dict() for a in self.actions],
                explainable=False,
            ))
        return KindPage(cards, len(rows), error=error)

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.operational.ticktick.capture import route_capture

        lane = str(params.get("lane") or "").strip()
        if lane not in {o["value"] for o in _LANE_OPTIONS}:
            raise ValueError(
                "укажи params.lane: " + " | ".join(str(o["value"]) for o in _LANE_OPTIONS))
        raw = route_capture(
            native_id, lane, state_path=env.capture_state_path(), inbox_dir=env.inbox_path()
        )
        if raw.get("outcome") == "stale":
            return {"outcome": "stale", "detail": str(raw.get("explanation") or "")}
        effect = {
            "knowledge": "захват ушел в знаниевый инбокс",
            "assignment": "захват стал карточкой «Поручение администратору CRM»",
            "task": "захват остался задачей TickTick",
            "drop": "текст удален из манифеста захвата",
        }[lane]
        return {"outcome": "routed", "detail": f"Маршрут: {lane}", "effects": [effect]}


# --------------------------------------------------------------------------- #
# hub - кандидат в хабы (+ HUB-CAND-LINK-1: сделка Timetta → timetta_id/link)   #
# --------------------------------------------------------------------------- #
_RESCAN_NOTE = "новый хаб станет виден линковке после rescan (dt_link --rescan)"
_DEAL_PREFIX = "timetta:deal:"


def _fold(text: Any) -> str:
    return str(text or "").casefold().strip()


def similar_hubs(
    vault: Path,
    name: str,
    *,
    entities: frozenset[str] | None = None,
    limit: int = _SIMILAR_LIMIT,
    catalog: list[Any] | None = None,
    flag_linked: bool = False,
) -> list[dict[str, Any]]:
    """До ``limit`` хабов каталога, имена/алиасы которых похожи на ``name`` (с долей сходства).

    Источник - единый каталог имен :func:`core.retrieval.hubcat.hub_catalog`; сходство -
    доля общих стем-ключей слов (Жаккар) по ЛУЧШЕМУ из имен хаба; порог :data:`_SIMILAR_MIN_SHARE`.
    ``flag_linked`` помечает хабы, у которых уже есть ``timetta_id`` (``busy``: привязка к ним
    молча перезаписала бы чужую сделку) и ставит свободные раньше занятых - свободный хаб не
    теряется за тремя занятыми. Только чтение."""
    from core.retrieval.hubcat import hub_catalog
    from core.text.stem import key_tokens

    q = set(key_tokens(name))
    if not q:
        return []
    entries = catalog if catalog is not None else hub_catalog(vault, None)
    scored: list[tuple[float, Any, str]] = []
    for entry in entries:
        if entities is not None and entry.entity not in entities:
            continue
        best, via = 0.0, ""
        for hub_name in entry.names:
            keys = set(hub_name.keys)
            union = q | keys
            share = len(q & keys) / len(union) if union else 0.0
            if share > best:
                best, via = share, hub_name.text
        if best >= _SIMILAR_MIN_SHARE:
            scored.append((best, entry, via))
    scored.sort(key=lambda t: (-t[0], t[1].note_id))
    pool = scored[:_SIMILAR_POOL] if flag_linked else scored[:limit]
    out = [{"hub_id": entry.note_id, "title": entry.h1.strip() or entry.note_id,
            "entity": entry.entity, "share": round(share, 2), "via": via,
            "busy": bool(_hub_timetta_id(vault, entry.path)) if flag_linked else False}
           for share, entry, via in pool]
    out.sort(key=lambda s: (s["busy"], -s["share"], s["hub_id"]))
    return out[:limit]


def _hub_timetta_id(vault: Path, rel_path: str) -> str:
    """``timetta_id`` из frontmatter хаба по vault-относительному пути ('' - нет/не прочитался)."""
    from core.vault import read_note

    try:
        value = read_note(vault / rel_path).frontmatter.get("timetta_id")
    except Exception:  # noqa: BLE001 - нечитаемый хаб не предлагаем как свободный
        return "?"
    return str(value).strip() if isinstance(value, str) and value.strip() else ""


class HubKind(CardKind):
    kind = "hub"
    label = "Хабы"
    actions = (
        ActionSpec("approve", "Создать", "primary",
                   confirm="Создать хаб? После создания понадобится rescan линковки."),
        ActionSpec("link", "Привязать к хабу", "secondary"),
        ActionSpec("reject", "Отклонить", "secondary", confirm="Отклонить кандидата навсегда?"),
    )

    def _load(self, env: QueueEnv) -> Any:
        from core.config import hub_candidates_path
        from core.linking.hub_candidates import HubCandidateQueue

        return HubCandidateQueue.load(env.hub_candidates or hub_candidates_path())

    def cache_stamp(self, env: QueueEnv) -> Any:
        from core.config import hub_candidates_path

        mirror = env.mirror_path()
        return [_stat_stamp(env.hub_candidates or hub_candidates_path()),
                _stat_stamp(mirror / "deals.json"), _stat_stamp(mirror / "orbit.json"),
                _hub_folders_stamp(env.vault_path())]

    def _pending(self, env: QueueEnv) -> list[Any]:
        rows = self._load(env).pending()
        rows.sort(key=lambda c: (-c.mentions, c.created or "", c.id))
        return rows

    def _orbit(self, env: QueueEnv) -> list[dict[str, Any]]:
        from core.operational import orbit
        from core.operational.assignment import orbit_deals
        from core.operational.timetta.mirror import MirrorStore

        try:
            return orbit_deals(MirrorStore(env.mirror_path()), orbit.enabled_rings())
        except Exception:  # noqa: BLE001 - нет зеркала = нет сделок, карточки отдаются без них
            return []

    @staticmethod
    def _deal_code(cand: Any) -> str | None:
        for src in cand.sources:
            if src.startswith(_DEAL_PREFIX):
                return src[len(_DEAL_PREFIX):]
        return None

    @staticmethod
    def _ring_info(cand: Any, deal: dict[str, Any] | None) -> dict[str, Any] | None:
        """``{ring, leader}`` кандидата от сделки: из зеркала, иначе из строки очереди."""
        if deal is not None:  # форма ``orbit_deals``: {guid, code, name, ring, leader}
            return {"ring": deal.get("ring") or "mine", "leader": deal.get("leader")}
        if getattr(cand, "ring", None):
            return {"ring": cand.ring, "leader": getattr(cand, "leader", None)}
        return None

    def _deal(
        self, env: QueueEnv, cand: Any, deals: list[dict[str, Any]] | None = None
    ) -> dict[str, Any] | None:
        """Сделка кандидата в орбите: по коду из источника, при нескольких - по имени."""
        code = self._deal_code(cand)
        if code is None:
            return None
        pool = deals if deals is not None else self._orbit(env)
        hits = [d for d in pool if str(d.get("code") or "")[:24] == code]
        if len(hits) > 1:
            hits = [d for d in hits if _fold(d.get("name")) == _fold(cand.name)] or hits
        return hits[0] if len(hits) == 1 else None

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        from core.linking.hub_candidates import HUB_ENTITIES
        from core.operational.ripe_leads import LEAD_ENTITIES
        from core.retrieval.hubcat import hub_catalog

        rows = self._pending(env)
        page = _slice(rows, limit)
        deals: list[dict[str, Any]] | None = None
        catalog: list[Any] | None = None
        vault = env.vault_path()
        cards = []
        for c in page:
            has_deal_source = self._deal_code(c) is not None
            deal = None
            if has_deal_source:
                deals = deals if deals is not None else self._orbit(env)
                deal = self._deal(env, c, deals)
            try:
                catalog = catalog if catalog is not None else hub_catalog(vault, None)
                similar = similar_hubs(
                    vault, c.name, catalog=catalog, flag_linked=has_deal_source,
                    entities=LEAD_ENTITIES if has_deal_source else None)
            except Exception:  # noqa: BLE001 - подсказка не обязана ронять карточку
                similar = []
            approve = dataclasses.replace(
                self.actions[0],
                confirm=self.actions[0].confirm + (
                    f" В хаб будет записан timetta_id сделки {deal.get('code')}." if deal else ""),
            ).to_dict(params={"entity": {
                "type": "select", "default": c.entity_guess,
                "options": [{"value": e, "label": e} for e in HUB_ENTITIES]}})
            actions = [approve]
            if deal is not None:
                actions.append(self.actions[1].to_dict(params={"hub_id": {
                    "type": "select", "required": True, "allow_custom": True,
                    "options": [{"value": s["hub_id"],
                                 "label": f"{s['title']} · {round(s['share'] * 100)}%"}
                                for s in similar if not s["busy"]]}}))
            actions.append(self.actions[2].to_dict())
            # SURFACE-HYGIENE-1: кольцо и ведущий сделки-источника (чужая сделка - с бейджем)
            ring_info = self._ring_info(c, deal)
            cards.append(_card(
                self.kind, c.id,
                title=f"Предлагаю хаб: {c.name}",
                reason=(f"{c.entity_guess or 'entity?'} · упоминаний: {c.mentions or '?'} "
                        f"за {c.days_active or '?'}д"
                        + (f" · сделка {deal.get('code')}" if deal else "")
                        + (f" · кольцо {ring_info['ring']}"
                           + (f" · ведет: {ring_info['leader']}" if ring_info.get("leader") else "")
                           if ring_info and ring_info.get("ring") != "mine" else "")),
                since=c.created,
                meta={"name": c.name, "entity_guess": c.entity_guess,
                      "suggested_hub_id": c.suggested_hub_id,
                      "signals": {"mentions": c.mentions, "days_active": c.days_active,
                                  "sources": list(c.sources)},
                      "deal": ({k: deal.get(k) for k in ("guid", "code", "name")}
                               if deal else None),
                      "ring": ring_info,
                      "similar_hubs": similar},
                actions=actions,
                explainable=True,
            ))
        return KindPage(cards, len(rows))

    def count(self, env: QueueEnv) -> int:
        return len(self._pending(env))

    # -- решение ------------------------------------------------------------------------------
    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        if action == "link":
            return self._link(env, native_id, params)
        from core.linking.hub_candidates import decide_hub_candidate

        queue = self._load(env)
        row = queue.by_id.get(native_id)
        sources = list(row.sources) if row is not None else []
        entity = str(params.get("entity") or "").strip() or None
        raw = decide_hub_candidate(
            native_id, action, entity, queue=queue, vault_path=env.vault_path())
        out = str(raw.get("outcome"))
        if out == "stale":
            return {"outcome": "stale", "detail": str(raw.get("explanation") or "")}
        if out == "rejected":
            return {"outcome": "rejected", "detail": str(raw.get("explanation") or ""),
                    "effects": ["кандидат ушел в стоп-журнал детектора"]}
        vault = env.vault_path()
        hub_path = str(raw.get("hub_path") or "")
        effects = [("хаб создан: " if out == "created" else "хаб уже был: ")
                   + _rel(vault, hub_path)]
        if any(s.startswith(_DEAL_PREFIX) for s in sources):
            effects.append(self._write_timetta_id(env, row, hub_path))
        effects.append(_RESCAN_NOTE)
        return {"outcome": "applied", "detail": f"Хаб {raw.get('hub_id')}", "effects": effects}

    def _write_timetta_id(self, env: QueueEnv, row: Any, hub_path: str) -> str:
        """Шаг 2 approve (HUB-CAND-LINK-1): ``timetta_id`` сделки в хаб; итог - строкой."""
        from core.operational.hub_link import HubLinkError, _resolve_hub, link_hub_to_deal

        deal = self._deal(env, row)
        if deal is None:
            return "timetta_id не записан: сделка не найдена в зеркале орбиты"
        vault = env.vault_path()
        try:
            existing = _resolve_hub(hub_path, vault).frontmatter.get("timetta_id")
            if isinstance(existing, str) and existing.strip():
                if existing.strip().lower() == str(deal["guid"]).lower():
                    return "timetta_id уже записан (та же сделка)"
                return "timetta_id не записан: у хаба уже указана другая сделка"
            link_hub_to_deal(
                hub_path, deal["guid"], vault_path=vault, mirror_path=env.mirror_path())
        except HubLinkError as exc:
            return f"timetta_id не записан: {_cut(exc, 120)}"
        return f"timetta_id записан ({deal.get('code')})"

    def _link(self, env: QueueEnv, native_id: str, params: dict[str, Any]) -> dict[str, Any]:
        from core.linking.hub_candidates import STATUS_PENDING
        from core.operational.hub_link import HubLinkError, _resolve_hub, link_hub_to_deal

        queue = self._load(env)
        row = queue.by_id.get(native_id)
        if row is None:
            raise ValueError(f"Кандидат …{native_id[-4:]} не найден в очереди кандидатов.")
        if row.status != STATUS_PENDING:
            return {"outcome": "stale",
                    "detail": f"Кандидат уже решен ({row.status}) - решение не требуется."}
        hub_ref = str(params.get("hub_id") or "").strip()
        if not hub_ref:
            raise ValueError("укажи params.hub_id: хаб, к которому привязать сделку")
        deal = self._deal(env, row)
        if deal is None:
            return {"outcome": "refused", "code": "no_deal",
                    "detail": "у кандидата нет сделки Timetta в орбите - привязывать нечего "
                              "(имя хаба - это алиас: вид alias)"}
        vault = env.vault_path()
        try:
            note = _resolve_hub(hub_ref, vault)
            existing = note.frontmatter.get("timetta_id")
            if isinstance(existing, str) and existing.strip() and (
                    existing.strip().lower() != str(deal["guid"]).lower()):
                return {"outcome": "refused", "code": "hub_already_linked",
                        "detail": f"у хаба {note.id} уже указана другая сделка - не перезаписываю"}
            link_hub_to_deal(note.id, deal["guid"], vault_path=vault, mirror_path=env.mirror_path())
        except HubLinkError as exc:
            return {"outcome": "refused", "code": "link_failed", "detail": _cut(exc, 200)}
        row.status = "linked"
        row.decided_at = env.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        row.hub_id = note.id
        queue.save()
        return {"outcome": "applied", "detail": f"Кандидат привязан к хабу {note.id}",
                "effects": [f"timetta_id записан у хаба {note.id} ({deal.get('code')})",
                            "кандидат закрыт: linked"]}

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        row = self._load(env).by_id.get(native_id)
        if row is None:
            return None
        has_deal = self._deal_code(row) is not None
        deal = self._deal(env, row) if has_deal else None
        return {
            "name": row.name, "entity_guess": row.entity_guess,
            "signals": {"mentions": row.mentions, "days_active": row.days_active},
            "sources": list(row.sources),
            "deal": {k: deal.get(k) for k in ("guid", "code", "name")} if deal else None,
            "similar_hubs": similar_hubs(env.vault_path(), row.name, flag_linked=has_deal),
        }


# --------------------------------------------------------------------------- #
# alias - кандидаты в алиасы хаба                                                #
# --------------------------------------------------------------------------- #
_ALIAS_SRC_RU = {"h1": "H1", "mirror": "Timetta", "domain": "домен", "folder": "папка"}


def _alias_sources(suggestion: dict[str, Any]) -> str:
    counted: dict[str, int] = {}
    for src in suggestion.get("sources") or []:
        counted[src["source"]] = counted.get(src["source"], 0) + (int(src.get("count") or 1))
    return " · ".join(
        _ALIAS_SRC_RU.get(k, k) + (f" ×{v}" if v > 1 else "") for k, v in counted.items())


class AliasKind(CardKind):
    kind = "alias"
    label = "Алиасы"
    actions = (
        ActionSpec("approve", "Принять выбранные", "primary"),
        ActionSpec("reject", "Отклонить", "secondary",
                   confirm="Отклонить алиасы этого хаба навсегда?"),
        ActionSpec("snooze", "Позже", "secondary"),
    )

    def _load(self, env: QueueEnv) -> Any:
        from core.config import hub_alias_candidates_path
        from core.linking.hub_aliases import AliasQueue

        return AliasQueue.load(env.hub_alias_candidates or hub_alias_candidates_path())

    def cache_stamp(self, env: QueueEnv) -> Any:
        from core.config import hub_alias_candidates_path

        return [_stat_stamp(env.hub_alias_candidates or hub_alias_candidates_path()),
                _hub_folders_stamp(env.vault_path())]

    def _pending(self, env: QueueEnv) -> list[Any]:
        rows = self._load(env).pending()
        rows.sort(key=lambda c: (c.entity != "client", -max(
            (len(s["sources"]) for s in c.suggestions), default=0), c.hub_id))
        return rows

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        from core.retrieval.hubcat import hub_catalog

        rows = self._pending(env)
        page = _slice(rows, limit)
        try:
            by_id = {e.note_id: e for e in hub_catalog(env.vault_path(), None)} if page else {}
        except Exception:  # noqa: BLE001 - без каталога карточка идет с id вместо заголовка
            by_id = {}
        cards = []
        for cand in page:
            entry = by_id.get(cand.hub_id)
            title = entry.h1.strip() if entry and entry.h1 else cand.hub_id
            have = [n.text for n in entry.names if n.source == "alias"] if entry else []
            options = [{"value": s["name"], "label": s["name"], "detail": _alias_sources(s),
                        "conflict": s.get("conflict") or None,
                        "selected": not s.get("conflict")} for s in cand.suggestions]
            approve = self.actions[0].to_dict(params={
                # required остается в контракте, но снимается при непустом extra: карточка без
                # отмеченных предложений, но со СВОИМИ вариантами валидна (клиент: _qCollect,
                # сервер: decide_hub_alias - «хотя бы одно из двух»)
                "aliases": {"type": "multiselect", "required": True, "options": options},
                "extra": {"type": "text", "required": False,
                          "placeholder": "свои варианты через запятую",
                          "label": "Свои варианты (если нужного имени нет в предложениях)"}})
            approve["confirm"] = ("Дописать отмеченные имена в aliases хаба? "
                                  "Остальной файл хаба не меняется.")
            cards.append(_card(
                self.kind, cand.hub_id,
                title=f"Алиасы хаба? {_cut(title, 70)}",
                reason=(f"{cand.hub_id} · {len(cand.suggestions)} предложен."
                        + (f" · уже: {_cut(', '.join(have), 60)}" if have else " · aliases нет")),
                since=cand.created,
                meta={"hub_id": cand.hub_id, "entity": cand.entity, "title": title,
                      "aliases": have, "suggestions": [
                          {**s, "selected": not s.get("conflict")} for s in cand.suggestions]},
                actions=[approve, self.actions[1].to_dict(), self.actions[2].to_dict()],
                explainable=True,
            ))
        return KindPage(cards, len(rows))

    def count(self, env: QueueEnv) -> int:
        return len(self._pending(env))

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.linking.hub_aliases import decide_hub_alias

        chosen = params.get("aliases")
        if chosen is not None and not isinstance(chosen, list):
            raise ValueError("params.aliases - список имен из предложений")
        extra = params.get("extra")
        if extra is not None and not isinstance(extra, str | list):
            raise ValueError("params.extra - строка через запятую или список своих вариантов")
        raw = decide_hub_alias(
            native_id, action, chosen if action == "approve" else None,
            queue=self._load(env), vault_path=env.vault_path(),
            extra=extra if action == "approve" else None,
        )
        out = str(raw.get("outcome"))
        if out == "stale":
            return {"outcome": "stale", "detail": str(raw.get("explanation") or "")}
        if out == "rejected":
            return {"outcome": "rejected", "detail": str(raw.get("explanation") or ""),
                    "effects": ["хаб ушел в стоп-журнал алиасов"]}
        if out == "snoozed":
            return {"outcome": "snoozed", "detail": f"Вернется {raw.get('snooze_until')}",
                    "effects": ["строка отложена на неделю"]}
        added = list(raw.get("added") or [])
        own = list(raw.get("extra_added") or [])
        effects = [f"aliases дописаны: {', '.join(added)}"] if added else []
        if own:
            effects.append(f"свои: {', '.join(own)}")
        return {"outcome": "applied",
                "detail": "Такие алиасы уже есть" if out == "exists" else "Алиасы записаны",
                "effects": effects}

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        row = self._load(env).by_id.get(native_id)
        if row is None:
            return None
        return {"hub_id": row.hub_id, "entity": row.entity, "suggestions": [
            {"name": s["name"], "sources": s.get("sources") or [], "conflict": s.get("conflict")}
            for s in row.suggestions]}


# --------------------------------------------------------------------------- #
# synth - «Состояние хаба?» (HUB-SYNTH-1): текст секции от сессии/провайдера, решает К.
# --------------------------------------------------------------------------- #
_SYNTH_SNOOZE = (3, 7, 14)


class SynthKind(CardKind):
    kind = "synth"
    label = "Состояние хабов"
    actions = (
        ActionSpec("approve", "Записать в хаб", "primary",
                   confirm="Записать секцию «Состояние» в хаб? Прежняя секция уйдет в "
                           "«Архив состояний», остальной файл хаба не меняется."),
        ActionSpec("reject", "Отклонить", "secondary", params={
            "reason": {"type": "text", "required": False, "label": "Причина",
                       "placeholder": "что не так с текстом"}}, more=True),
        ActionSpec("snooze", "Позже", "secondary", params={"days": {
            "type": "select", "default": 7,
            "options": [{"value": d, "label": f"{d} дн."} for d in _SYNTH_SNOOZE]}}, more=True),
    )

    def _store(self, env: QueueEnv) -> Any:
        from core.operational.hub_synth import SynthStore

        return SynthStore.load(env.hub_synth_file())

    def cache_stamp(self, env: QueueEnv) -> Any:
        return None  # стор мал и читается живьем: карточка должна исчезать сразу после решения

    def _pending(self, env: QueueEnv) -> list[dict[str, Any]]:
        return self._store(env).pending(env.utcnow())

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        rows = self._pending(env)
        cards = []
        for row in _slice(rows, limit):
            diff = row.get("diff") or {}
            changed = int(diff.get("added", 0)) + int(diff.get("changed", 0)) + int(
                diff.get("removed", 0))
            reason = (f"{row.get('items', 0)} пунктов · {len(row.get('sources') or [])} источников"
                      f" · изменилось {changed} строк")
            if row.get("style"):
                reason += " · есть ИИ-маркеры"
            cards.append(_card(
                self.kind, row["id"],
                title=f"Состояние хаба? {_cut(row.get('title') or row['hub_id'], 70)}",
                reason=reason, since=row.get("created"),
                meta={"hub_id": row["hub_id"], "title": row.get("title"), "text": row["text"],
                      "diff": diff, "uncovered": row.get("uncovered") or [],
                      "sources": row.get("sources") or [],
                      "covered_until": row.get("covered_until"),
                      "current_as_of": row.get("current_as_of"),
                      "current_source": row.get("current_source"),
                      "style": row.get("style"), "host": row.get("host"),
                      "model": row.get("model")},
                actions=[a.to_dict() for a in self.actions],
                explainable=True,
            ))
        return KindPage(cards, len(rows))

    def count(self, env: QueueEnv) -> int:
        return len(self._pending(env))

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.operational.hub_synth import SynthError, apply_card

        try:
            return apply_card(
                native_id, action, params, store_file=env.hub_synth_file(),
                vault_path=env.vault, now=env.now)
        except SynthError as exc:
            return {"outcome": "refused", "code": exc.code, "detail": str(exc)}

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        row = self._store(env).rows.get(native_id)
        if row is None:
            return None
        diff = row.get("diff") or {}
        meta = row.get("source_meta") or {}
        return {
            "hub_id": row["hub_id"], "covered_until": row.get("covered_until"),
            "sources": [{"locator": loc, **(meta.get(loc) or {})}
                        for loc in row.get("sources") or []],
            "leaves_current": [ln["text"] for ln in diff.get("lines") or [] if ln.get("op") == "-"],
            "uncovered": row.get("uncovered") or [],
            "diff": {k: diff.get(k, 0) for k in ("added", "changed", "removed")},
            "status": row.get("status"),
        }


# --------------------------------------------------------------------------- #
# lint - «Линт знаний» (KNOWLEDGE-LINT-1): противоречия, устаревшие хабы, сироты, дубли.
# --------------------------------------------------------------------------- #
_LINT_SNOOZE = (3, 7, 14)
_LINT_ORDER = ("fact_conflict", "hub_stale", "orphan", "duplicate", "claim")


def _lint_fact_label(e: dict[str, Any], letter: str) -> str:
    name = str(e.get("source_path") or "").rsplit("/", 1)[-1]
    return _cut(f"Оставить {letter}: {e.get('value_raw')} · {name}", 60)


class LintKind(CardKind):
    kind = "lint"
    label = "Линт знаний"
    actions = (
        ActionSpec("keep_a", "Оставить А", "primary",
                   confirm="Оставить значение А? Значение Б будет вытеснено (valid_to = сегодня) - "
                           "сам файл-источник не меняется."),
        ActionSpec("keep_b", "Оставить Б", "primary",
                   confirm="Оставить значение Б? Значение А будет вытеснено (valid_to = сегодня) - "
                           "сам файл-источник не меняется."),
        ActionSpec("synth", "Собрать состояние", "primary"),
        ActionSpec("attach", "Привязать к хабу", "primary",
                   confirm="Привязать заметку к хабу? В ее frontmatter дописывается одно поле "
                           "(client/project/links), остальной файл не меняется."),
        ActionSpec("mark", "Пометить дубль", "primary",
                   confirm="Пометить заметку как дубль? В ее frontmatter ставится duplicate_of: "
                           "<старая>; заметки не сливаются и не удаляются."),
        ActionSpec("note", "Дописать в хаб", "primary",
                   confirm="Дописать пункт под «Проверить (линт ДАТА)» в хабе? Остальной файл хаба "
                           "не меняется."),
        ActionSpec("snooze", "Позже", "secondary", params={"days": {
            "type": "select", "default": 7,
            "options": [{"value": d, "label": f"{d} дн."} for d in _LINT_SNOOZE]}}, more=True),
        ActionSpec("dismiss", "Не проблема", "secondary", params={
            "reason": {"type": "text", "required": False, "label": "Причина",
                       "placeholder": "почему не проблема"}}, more=True),
    )

    def _store(self, env: QueueEnv) -> Any:
        from core.lint.store import LintStore

        return LintStore.load(env.lint_findings_file())

    def _pending(self, env: QueueEnv) -> list[dict[str, Any]]:
        rows = self._store(env).pending()
        rows.sort(key=lambda r: (_LINT_ORDER.index(r["rule"]) if r.get("rule") in _LINT_ORDER
                                 else len(_LINT_ORDER), str(r.get("created") or ""), r["id"]))
        return rows

    def count(self, env: QueueEnv) -> int:
        return len(self._pending(env))

    def _actions_for(self, row: dict[str, Any]) -> list[dict[str, Any]]:
        from core.lint.registry import get_rule

        rule = get_rule(str(row.get("rule")))
        names = rule.actions if rule else ("dismiss",)
        out: list[dict[str, Any]] = []
        evidence = row.get("evidence") or []
        for name in names:
            spec = self.spec(name)
            if spec is None:
                continue
            if name in ("keep_a", "keep_b") and len(evidence) >= 2:
                idx = 0 if name == "keep_a" else 1
                meta = row.get("meta") or {}
                want = meta.get("a" if name == "keep_a" else "b")
                e = next((x for x in evidence if x.get("fact_id") == want), evidence[idx])
                out.append(dataclasses.replace(
                    spec, label=_lint_fact_label(e, "А" if name == "keep_a" else "Б")).to_dict())
            elif name == "attach":
                cands = row.get("candidates") or []
                params = {"hub_id": {
                    "type": "select", "required": True, "allow_custom": True,
                    "default": cands[0]["hub_id"] if cands else None,
                    "options": [{"value": c["hub_id"],
                                 "label": _cut(f"{c['title']} ({c['hub_id']}) · {c['where']}", 70)}
                                for c in cands]}}
                out.append(spec.to_dict(params=params))
            else:
                out.append(spec.to_dict())
        return out

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        from core.lint.registry import get_rule

        rows = self._pending(env)
        cards = []
        for row in _slice(rows, limit):
            rule = get_rule(str(row.get("rule")))
            chip = rule.label if rule else row.get("rule")
            cards.append(_card(
                self.kind, row["id"], title=str(row.get("title") or row["id"]),
                reason=str(row.get("reason") or ""), since=row.get("created"),
                meta={"rule": row.get("rule"), "rule_label": chip,
                      "subject": row.get("subject"), "evidence": row.get("evidence") or [],
                      "candidates": row.get("candidates") or [], **(row.get("meta") or {})},
                actions=self._actions_for(row), explainable=True,
            ))
        return KindPage(cards, len(rows))

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.lint.actions import apply_card
        from core.lint.env import LintEnv

        lint_env = LintEnv(vault=env.vault, mirror=env.mirror, now=env.now)
        return apply_card(native_id, action, params, env=lint_env,
                          store_file=env.lint_findings_file())

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        from core.lint.actions import explain_card

        row = self._store(env).rows.get(native_id)
        return explain_card(row) if row is not None else None


# --------------------------------------------------------------------------- #
# gold - кандидаты в золотой набор eval                                          #
# --------------------------------------------------------------------------- #
def _gold_rank(today: int | None) -> str:
    if today is None:
        return "сегодня заметки нет в выдаче"
    return f"сегодня ранг {today} (в топ-5)" if today <= 5 else f"сегодня ранг {today} (вне топ-5)"


class GoldKind(CardKind):
    kind = "gold"
    label = "eval"
    actions = (
        ActionSpec("accept", "Принять", "primary",
                   confirm="Дописать запрос в золотой набор (контрольная группа)? Набор "
                           "изменится - следующий прогон начнет новую базовую линию."),
        ActionSpec("reject", "Отклонить", "secondary", confirm="Отклонить кандидата навсегда?"),
        ActionSpec("snooze", "Отложить на 7 дн.", "secondary", more=True),
    )

    def _queue(self, env: QueueEnv, *, refresh: bool, recompute: bool) -> tuple[Any, str | None]:
        from core.eval_candidates import GoldenCandidateQueue, ensure_fresh

        if not recompute:  # доктор/счет: только прочитать кэш, ничего не пересчитывать и не писать
            return GoldenCandidateQueue.load(env.golden_candidates), None
        return ensure_fresh(
            queue_path=env.golden_candidates, journal_path=env.eval_journal,
            golden_file=env.golden_file, probe=env.golden_probe, now=env.now, force=refresh,
        )

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        # PULT-SURFACE-2: на чтении gold НИКОГДА не считает (реранкер ~5-29 с внутри read-вызова) -
        # отдается последний расчет; пересчет - кнопка (refresh) или шаг eval ночной цепочки.
        queue, error = self._queue(env, refresh=refresh, recompute=bool(refresh))
        rows = queue.pending()
        cards = []
        for g in _slice(rows, limit):
            card = g.to_card()
            titles = ", ".join(str(e.get("title") or e.get("note_id")) for e in card["expected"])
            options = [{"value": e["note_id"], "label": e.get("title") or e["note_id"],
                        "detail": (e.get("path") or e["note_id"])
                        + (f" · сегодня ранг {e['rank']}" if e.get("rank") else "")
                        + (" · хаб" if e.get("is_hub") else ""),
                        "selected": True} for e in card["expected"]]
            accept = self.actions[0].to_dict(params={"expected_ids": {
                "type": "multiselect", "more": True, "options": options,
                "label": "Ожидание - открытые после этого поиска заметки (сними лишние)"}})
            cards.append(_card(
                self.kind, g.id,
                title=f"В золотой набор? «{_cut(g.query, 70)}»",
                reason=(f"повторов {g.repeats} · ждём: {_cut(titles, 80)} · "
                        f"{_gold_rank(g.today_rank)}"),
                since=g.last_seen,
                meta={k: card[k] for k in ("query", "tool", "args", "expected", "repeats",
                                           "today_rank", "first_seen")},
                actions=[accept, self.actions[1].to_dict(), self.actions[2].to_dict()],
                explainable=False,
            ))
        return KindPage(cards, len(rows), error="store_unavailable" if error else "",
                        as_of=str(queue.refreshed_at or ""))

    def count(self, env: QueueEnv) -> int:
        return len(self._queue(env, refresh=False, recompute=False)[0].pending())

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.eval import golden_path
        from core.eval_candidates import GoldenCandidateQueue, decide_golden_candidate

        expected = params.get("expected_ids")
        if expected is not None and not isinstance(expected, list):
            raise ValueError("params.expected_ids - список note_id")
        raw = decide_golden_candidate(
            native_id, action, expected if action == "accept" else None,
            queue=GoldenCandidateQueue.load(env.golden_candidates),
            golden_file=env.golden_file or golden_path(env.vault_path()),
        )
        if raw.get("ok") is False:
            return {"outcome": "refused", "code": str(raw.get("code") or "refused"),
                    "detail": str(raw.get("error") or "")}
        out = str(raw.get("outcome"))
        detail = str(raw.get("explanation") or "")
        if out == "accepted":
            return {"outcome": "applied", "detail": detail,
                    "effects": [f"запрос дописан в golden-queries.yaml как {raw.get('golden_id')} "
                                "(контрольная группа)"]}
        if out == "rejected":
            return {"outcome": "rejected", "detail": detail,
                    "effects": ["запрос больше не предлагается"]}
        if out == "snoozed":
            return {"outcome": "snoozed", "detail": detail,
                    "effects": [f"отложено до {raw.get('until')}"]}
        return {"outcome": "stale", "detail": detail}


# --------------------------------------------------------------------------- #
# ripe_lead - дозревший лид: хаб без пары в Timetta                              #
# --------------------------------------------------------------------------- #
_SNOOZE_DAYS = (7, 14, 30)


class RipeLeadKind(CardKind):
    kind = "ripe_lead"
    label = "Дозрели"
    actions = (
        ActionSpec("snooze", "Отложить", "secondary", params={"days": {
            "type": "select", "default": 14,
            "options": [{"value": d, "label": f"{d} дн."} for d in _SNOOZE_DAYS]}}),
        ActionSpec("reject", "Отказать", "danger",
                   confirm="Отказать навсегда? Хаб не станет сделкой/проектом Timetta."),
    )

    def _leads(self, env: QueueEnv) -> list[dict[str, Any]]:
        from core.operational.ripe_leads import ripe_leads

        out = ripe_leads(vault_path=env.vault_path(), snooze_path=env.ripe_snooze, now=env.now)
        leads = [x for x in out["leads"] if x.get("ripe")]
        # SURFACE-HYGIENE-1 (R4): «дозрел для Timetta» - только свои лиды: хаб, чье имя совпало с
        # ЧУЖОЙ видимой сделкой (кольцо unit/group, не «слежу»), сделкой не станет: ведет коллега
        foreign = self._foreign_deal_names(env)
        return [x for x in leads if _fold(x.get("name")) not in foreign]

    @staticmethod
    def _foreign_deal_names(env: QueueEnv) -> set[str]:
        from core.operational import orbit
        from core.operational.timetta.mirror import MirrorStore

        try:
            store = MirrorStore(env.mirror_path())
            deals = orbit.visible(store.all("deals"), orbit.enabled_rings())
        except Exception:  # noqa: BLE001 - нет зеркала = нечего отсекать
            return set()
        return {_fold(d.get("name")) for d in deals
                if d.get("name") and orbit.ring(d) != orbit.RING_MINE and not orbit.is_watched(d)}

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        rows = self._leads(env)
        cards = [
            _card(
                self.kind, lead["id"],
                title=f"Дозрел лид: {_cut(lead.get('name'), 70)}",
                reason=" · ".join(lead.get("reasons") or []) or "готов стать сделкой",
                since=None,
                meta={k: lead.get(k) for k in ("name", "entity", "status", "track", "client",
                                               "path", "notes", "age_days", "activity_days",
                                               "deadline_days", "reasons")},
                actions=[a.to_dict() for a in self.actions],
                explainable=False,
            )
            for lead in _slice(rows, limit)
        ]
        return KindPage(cards, len(rows))

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        from core.operational.ripe_leads import reject_lead, snooze_lead

        if action == "snooze":
            days = float(params.get("days") or 14)
            raw = snooze_lead(native_id, days, snooze_path=env.ripe_snooze, vault_path=env.vault)
        else:
            raw = reject_lead(native_id, snooze_path=env.ripe_snooze, vault_path=env.vault)
        if raw.get("refused"):
            code = str(raw.get("code") or "refused")
            code = "unknown_card" if code == "unknown_item" else code
            return {"outcome": "refused", "code": code, "detail": str(raw.get("error") or "")}
        if action == "snooze":
            return {"outcome": "snoozed", "detail": f"До {raw.get('until')}",
                    "effects": [f"отложено на {raw.get('days'):g} дн."]}
        return {"outcome": "rejected", "detail": "Хаб убран из детектора",
                "effects": ["хаб не станет сделкой/проектом Timetta (запись в ripe_snooze.json)"]}


# --------------------------------------------------------------------------- #
# bridge - связи личной заметки с рабочим знанием (только личный экземпляр)        #
# --------------------------------------------------------------------------- #
def _bridge_rationale(row: dict[str, Any]) -> str:
    """Почему пара предложена: общие термины запроса и рабочей цитаты; без терминов - подпись
    кандидата (семантическая близость) либо прежняя общая фраза (карточка старого скана)."""
    terms = [str(t) for t in (row.get("terms") or [])]
    tail = "принятие запишет work_refs только в личную заметку (в рабочем vault не появится ничего)"
    if terms:
        return f"общие термины: {', '.join(terms)}; {tail}"
    if row.get("rationale"):
        return f"{row['rationale']}; {tail}"
    return f"рабочая заметка перекликается с личной; {tail}"


class BridgeKind(CardKind):
    """PERSONAL-1 п.5: предложение связи личной заметки с рабочей (карточку создает
    ``bridge_scan``).

    Вид регистрируется ТОЛЬКО при ``DT_INSTANCE_ROLE=personal`` (:func:`build_kinds`): в реестре
    рабочего экземпляра его нет. ``approve`` пишет ``work_refs`` в ЛИЧНУЮ заметку; ``reject`` - стоп
    пары на ``DT_BRIDGE_SNOOZE_DAYS``; ``snooze`` - скрыть на срок. Рабочий контур не затрагивается.
    """

    kind = "bridge"
    label = "Мост"
    actions = (
        ActionSpec("approve", "Связать", "primary"),
        ActionSpec("snooze", "Отложить", "secondary", params={"days": {
            "type": "select", "default": 7,
            "options": [{"value": d, "label": f"{d} дн."} for d in _SNOOZE_DAYS]}}),
        ActionSpec("reject", "Отклонить", "danger", more=True,
                   confirm="Отклонить эту пару? Она не вернется в течение срока остановки."),
    )

    def _store(self) -> Any:
        from core.bridge.store import BridgeStore

        return BridgeStore.load()

    # cache_stamp не переопределяем: выдача зависит от ВРЕМЕНИ (отложенная карточка возвращается по
    # сроку без изменения файла), снимок по mtime стора ее бы не вернул. Стор - маленький jsonl.

    def _pending(self, env: QueueEnv) -> list[dict[str, Any]]:
        return self._store().pending(env.utcnow())  # type: ignore[no-any-return]

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        rows = self._pending(env)
        cards = [
            _card(
                self.kind, r["id"],
                title=f"«{_cut(r.get('personal_title'), 50)}» ↔ «{_cut(r.get('work_title'), 50)}»",
                reason=f"{r.get('matched_by') or 'поиск'} · {float(r.get('score') or 0):.2f} · "
                       f"{r.get('work_corpus') or 'рабочее знание'}",
                since=r.get("created_at"),
                meta={"personal_path": r.get("personal_path"),
                      "work_note_id": r.get("work_note_id"),
                      "work_path": r.get("work_path"), "work_corpus": r.get("work_corpus"),
                      "score": r.get("score"), "matched_by": r.get("matched_by")},
                actions=[a.to_dict() for a in self.actions],
                explainable=True,
            )
            for r in _slice(rows, limit)
        ]
        return KindPage(cards, len(rows))

    def count(self, env: QueueEnv) -> int:
        return len(self._pending(env))

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        store = self._store()
        row = store.get(native_id)
        if row is None:
            raise ValueError(f"карточка моста {native_id!r} не найдена")
        if row.get("status") != "pending":
            return {"outcome": "stale",
                    "detail": f"карточка уже решена ({row.get('status')})"}
        now = env.utcnow()
        if action == "snooze":
            until = store.snooze(native_id, float(params.get("days") or 7), now=now)
            store.save()
            return {"outcome": "snoozed", "detail": f"До {until}",
                    "effects": [f"карточка скрыта до {until}"]}
        if action == "reject":
            until = store.mark_rejected(native_id, now=now)
            store.save()
            return {"outcome": "rejected", "detail": f"Пара остановлена до {until}",
                    "effects": ["связь не записана; пара не предлагается до конца срока"]}
        return self._approve(env, store, row, now)

    def _approve(self, env: QueueEnv, store: Any, row: dict[str, Any], now: Any) -> dict[str, Any]:
        from core.bridge.refs import add_work_ref
        from core.bridge.store import load_state, save_state
        from core.vault import FrontmatterError

        target = env.vault_path() / str(row.get("personal_path") or "")
        if not target.is_file():
            return {"outcome": "refused", "code": "note_missing",
                    "detail": f"личной заметки нет на месте: {row.get('personal_path')}"}
        ref = {"id": str(row["work_note_id"]), "title": str(row.get("work_title") or ""),
               "path": str(row.get("work_path") or ""),
               "at": now.strftime("%Y-%m-%dT%H:%M:%SZ")}
        try:
            changed, _refs = add_work_ref(target, ref, env.vault_path())
        except (FrontmatterError, OSError) as exc:
            return {"outcome": "refused", "code": "apply_failed",
                    "detail": f"work_refs не записан: {exc}"}
        store.mark_applied(row["id"], now=now)
        store.save()
        # собственная правка заметки не должна вернуть ее в дельту следующего скана
        state = load_state()
        entry = state.get("notes", {}).get(str(row.get("personal_path")))
        if entry is not None:
            st = target.stat()
            entry["sig"] = [st.st_mtime_ns, st.st_size]
            save_state(state)
        effect = (f"work_refs записан в {row.get('personal_path')}" if changed
                  else f"связь уже была в {row.get('personal_path')}")
        return {"outcome": "applied", "detail": "Связь с рабочим знанием записана в личную заметку",
                "effects": [effect]}

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        from core.bridge.scan import personal_quote

        row = self._store().get(native_id)
        if row is None:
            return None
        quote = str(row.get("quote_personal") or "")
        note = env.vault_path() / str(row.get("personal_path") or "")
        try:  # личная сторона - свежим чтением (заметка могла измениться после скана)
            quote = personal_quote(note.read_text(encoding="utf-8")) or quote
        except OSError:
            pass
        return {
            "notes": [
                {"role": "personal", "id": row.get("personal_note_id"), "found": note.is_file(),
                 "title": row.get("personal_title"), "preview": quote},
                {"role": "work", "id": row.get("work_note_id"), "found": True,
                 "title": row.get("work_title"), "preview": row.get("quote_work") or ""},
            ],
            "score": row.get("score"), "matched_by": row.get("matched_by"),
            "work_corpus": row.get("work_corpus"), "status": row.get("status"),
            "evidence": f"{row.get('matched_by') or 'поиск'}: оценка {row.get('score')}",
            # PERSONAL-3: «почему» - по общим терминам (их хранит кандидат); у карточек до B-части
            # терминов нет - прежняя фраза
            "terms": list(row.get("terms") or []),
            "rationale": _bridge_rationale(row),
        }


def _base_kinds() -> list[CardKind]:
    return [AssignmentKind(), UntriagedKind(), HubKind(), AliasKind(), SynthKind(), LintKind(),
            GoldKind(), ReattrKind(), LinkKind()]


def build_kinds() -> list[CardKind]:
    """Виды в порядке вкладки (ripe_lead последним - у него своя секция «Дозрели»).

    PERSONAL-3: состав видов - из манифеста роли (``core.surface.manifest.card_kinds``): рабочий
    экземпляр - все прежние виды без ``bridge``, личный - только ``bridge``. Раньше это была ветка
    ``if is_personal()`` здесь, теперь - данные таблицы поверхности."""
    from core.surface import manifest

    every: dict[str, CardKind] = {k.kind: k for k in [*_base_kinds(), BridgeKind(), RipeLeadKind()]}
    return [every[name] for name in manifest.card_kinds() if name in every]


KIND_LABELS = {k.kind: k.label for k in [*_base_kinds(), RipeLeadKind()]}
