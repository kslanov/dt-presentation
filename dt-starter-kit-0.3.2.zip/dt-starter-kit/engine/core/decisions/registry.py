"""QUEUE-SERVER-1 — реестр видов карточек очереди решений: один контракт, один list/decide/explain.

Решение человека - это КАРТОЧКА реестра. Вид (``CardKind``) умеет три вещи: отдать свои карточки
единой формы, принять решение ``(id, action, params)`` и объяснить «почему». Каждый вид - фасад над
своим готовым ядром (``decide_link``, ``decide_hub_candidate``, ``decide_hub_alias``,
``hub_synth.apply_card`` (HUB-SYNTH-1), ``decide_reattr``, ``decide_golden_candidate``,
``decide_assignment``, ``route_capture``, ``snooze_lead``/``reject_lead``):
ядро решений и сторы видов НЕ меняются, единого стора очереди нет. Новый детектор = новый вид в
реестре, а не новая пара инструментов MCP и не новый код в пульте.

**Карточка** (одной формы для всех видов)::

    {id: "<kind>:<native>", kind, title, reason, since, meta: {...поля вида},
     actions: [{action, label, style: primary|secondary|danger, params: {имя: {type, options?,
     default?, required?}}, confirm?, more?}], explainable: bool}

``params[имя].type``: ``select`` (``options: [{value, label, ...}]``; ``ui: "buttons"`` - по кнопке
на вариант) | ``multiselect`` (``options`` с ``selected``) | ``text``; ``more: true`` - виджет
параметра живет в раскрытии строки («ещё…»), ``label`` - подпись, ``allow_custom`` - можно ввести
свое значение.

**Исход** (одной формы)::

    {ok, outcome: applied|rejected|snoozed|routed|stale|refused, code?, detail, effects: [...],
     card_id, kind, action}

``effects`` - что реально сделано («хаб создан <путь>», «timetta_id записан»). ``stale`` - карточка
уже решена (не ошибка); ``refused`` - решение не принято, ничего не записано (``code``:
``unknown_card`` | ``bad_action`` | ``invalid_params`` | ``no_deal`` | ... из ядра вида).

**Аудит и телеметрия - здесь, в одном месте** (:func:`decide`): одна строка ``pult-actions.log``
(``pult_card_decide``: вид, id, действие, исход, хост/поверхность - БЕЗ текста карточки) и, если
решение состоялось (``applied|rejected|snoozed|routed``), событие метрик ``queue_decision``
(``card_kind``, ``decision``, ``host``). Ядра видов пишут и свои прежние события
(``hub_decision``/``link_decision``) - они сохраняются.

``core`` ⊥ mcp/cli; ни сети, ни LLM. Что зависит от слоя MCP (проба «сегодняшней выдачи» для
eval-кандидатов), приходит инъекцией через :class:`QueueEnv`.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "ActionSpec",
    "CardKind",
    "KindPage",
    "KindUnavailable",
    "QueueEnv",
    "STYLES",
    "OUTCOMES",
    "DECIDED_OUTCOMES",
    "card_id",
    "split_card_id",
    "get_registry",
    "kind_order",
    "queue",
    "decide",
    "explain",
    "pending_totals",
]

STYLES = ("primary", "secondary", "danger")
OUTCOMES = ("applied", "rejected", "snoozed", "routed", "stale", "refused")
# Исходы, при которых решение СОСТОЯЛОСЬ (идет в метрики); stale/refused решением не считаются.
DECIDED_OUTCOMES = ("applied", "rejected", "snoozed", "routed")
_DECISION_OF = {"applied": "approved", "rejected": "rejected", "snoozed": "snoozed",
                "routed": "routed"}
AUDIT_TOOL = "pult_card_decide"
EVENT_KIND = "queue_decision"


class KindUnavailable(Exception):
    """Вид не смог прочитать свой стор: ``code`` уходит в ``errors[kind]`` (ошибка ≠ пусто)."""

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(detail or code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class ActionSpec:
    """Действие над карточкой вида: кнопка + параметры, которые она принимает."""

    action: str
    label: str
    style: str = "secondary"
    params: dict[str, dict[str, Any]] = field(default_factory=dict)
    confirm: str = ""
    more: bool = False  # редкое действие: пульт прячет его в раскрытие строки («ещё…»)

    def to_dict(self, params: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
        out: dict[str, Any] = {
            "action": self.action,
            "label": self.label,
            "style": self.style,
            "params": dict(self.params if params is None else params),
        }
        if self.confirm:
            out["confirm"] = self.confirm
        if self.more:
            out["more"] = True
        return out


CACHE_PREFIX = "cards-"


@dataclass
class KindPage:
    """Результат ``CardKind.list``: карточки (не больше limit), сколько ждут всего, ошибка вида."""

    cards: list[dict[str, Any]]
    total: int
    error: str = ""  # код деградации; карточки при этом отдаются как есть (канон eval не читается)
    as_of: str = ""  # PULT-SURFACE-2: когда посчитан кэшируемый вид (gold); пусто - читается живьем


@dataclass
class QueueEnv:
    """Окружение видов: пути сторов и инъекции. Пусто - боевые значения из ``core.config``.

    Тесты подставляют пути фейковых сторов; боевой путь не нужен нигде, кроме конфигурации."""

    vault: Path | None = None
    link_proposals: Path | None = None
    reattr_proposals: Path | None = None
    hub_candidates: Path | None = None
    hub_alias_candidates: Path | None = None
    hub_synth: Path | None = None  # HUB-SYNTH-1: стор карточек «Состояние хаба?»
    lint_findings: Path | None = None  # KNOWLEDGE-LINT-1: стор находок линта (вид ``lint``)
    capture_state: Path | None = None
    inbox_dir: Path | None = None
    mirror: Path | None = None
    golden_candidates: Path | None = None
    eval_journal: Path | None = None
    golden_file: Path | None = None
    ripe_snooze: Path | None = None
    admin_email: str | None = None
    admin_email_set: bool = False  # True - admin_email задан явно (в т.ч. None), не читать из env
    # «Сегодняшняя выдача» для ранга eval-кандидата: зависит от слоя MCP (find_notes), инъекция.
    golden_probe: Callable[[str, dict[str, Any]], list[str]] | None = None
    now: datetime | None = None

    def vault_path(self) -> Path:
        from core.config import default_vault_path

        return Path(self.vault) if self.vault else default_vault_path()

    def hub_synth_file(self) -> Path:
        from core.config import hub_synth_path

        return Path(self.hub_synth) if self.hub_synth else hub_synth_path()

    def lint_findings_file(self) -> Path:
        from core.config import lint_findings_path

        return Path(self.lint_findings) if self.lint_findings else lint_findings_path()

    def capture_state_path(self) -> Path:
        if self.capture_state:
            return Path(self.capture_state)
        from core.config import ticktick_state_path

        return ticktick_state_path() / "capture_state.json"

    def inbox_path(self) -> Path:
        from core.config import staging_inbox_path

        return Path(self.inbox_dir) if self.inbox_dir else staging_inbox_path()

    def mirror_path(self) -> Path:
        from core.config import timetta_mirror_path

        return Path(self.mirror) if self.mirror else timetta_mirror_path()

    def admin(self) -> str | None:
        if self.admin_email_set:
            return self.admin_email
        from core.config import crm_admin_email

        return crm_admin_email()

    def utcnow(self) -> datetime:
        return self.now or datetime.now(UTC)


class CardKind:
    """Вид карточки. Подклассы лежат в :mod:`core.decisions.kinds`; здесь - контракт."""

    kind: str = ""
    label: str = ""  # подпись фильтра-чипа вкладки
    actions: tuple[ActionSpec, ...] = ()  # ВСЕ действия вида (допустимые имена decide)

    def spec(self, action: str) -> ActionSpec | None:
        return next((a for a in self.actions if a.action == action), None)

    def list(self, env: QueueEnv, limit: int, *, refresh: bool = False) -> KindPage:
        raise NotImplementedError

    def count(self, env: QueueEnv) -> int:
        """Сколько ждут решения (для доктора): без дорогих пересчетов и без записи в сторы."""
        return self.list(env, 0).total

    def cache_stamp(self, env: QueueEnv) -> Any:
        """Токен «от чего зависит выдача вида» (SURFACE-HYGIENE-1 п.3): mtime/размер сторов и
        каталога хабов. ``None`` - вид не кэшируется (читается живьем, как раньше). Выдача вида
        кэшируется
        тем же :func:`core.operational.snapshot.cached_read`, что в PULT-SURFACE-2:
        второго кэша нет."""
        return None

    def decide(
        self, env: QueueEnv, native_id: str, action: str, params: dict[str, Any]
    ) -> dict[str, Any]:
        """Решение: ``{outcome, detail?, effects?, code?}`` - исходная форма вида приводится к
        единой в :func:`decide`. ``ValueError`` ядра (неизвестный id/решение) ловит диспетчер."""
        raise NotImplementedError

    def explain(self, env: QueueEnv, native_id: str) -> dict[str, Any] | None:
        """«Почему» по карточке; ``None`` - вид не объясняется или карточки нет."""
        return None

    def explain_with(
        self, env: QueueEnv, native_id: str, params: dict[str, Any]
    ) -> dict[str, Any] | None:
        """«Почему» с параметрами (``pult_card_explain(card_id, params)``). По умолчанию параметры
        игнорируются; ``assignment`` собирает по ним черновик под выбранную сделку
        (SURFACE-HYGIENE-1)."""
        return self.explain(env, native_id)


# --------------------------------------------------------------------------- #
# Идентификаторы карточек                                                        #
# --------------------------------------------------------------------------- #
def card_id(kind: str, native_id: str) -> str:
    """Уникальный id карточки: ``<вид>:<родной id>`` (родной id может сам содержать ``:``)."""
    return f"{kind}:{native_id}"


def split_card_id(value: str) -> tuple[str, str]:
    """``"hub:abc"`` → ``("hub", "abc")``; нет префикса - ``("", value)``."""
    head, sep, tail = str(value or "").partition(":")
    return (head, tail) if sep else ("", str(value or ""))


# --------------------------------------------------------------------------- #
# Реестр                                                                         #
# --------------------------------------------------------------------------- #
_REGISTRY: dict[str, CardKind] | None = None
_REGISTRY_KINDS: tuple[str, ...] = ()


def get_registry() -> dict[str, CardKind]:
    """Реестр видов (порядок - порядок вкладки): создается лениво, один на процесс.

    DEV-3-CORE: состав видов зависит от коннекторов (``DT_CONNECTORS`` читается после
    ``load_env``, а реестр могли построить раньше) - реестр пересобирается, если набор видов
    манифеста сменился."""
    global _REGISTRY, _REGISTRY_KINDS
    from core.surface import manifest

    kinds = tuple(manifest.card_kinds())
    if _REGISTRY is None or kinds != _REGISTRY_KINDS:
        from core.decisions.kinds import build_kinds

        _REGISTRY = {k.kind: k for k in build_kinds()}
        _REGISTRY_KINDS = kinds
    return _REGISTRY


def kind_order() -> tuple[str, ...]:
    return tuple(get_registry())


def _error_code(exc: BaseException) -> str:
    if isinstance(exc, KindUnavailable):
        return exc.code
    return "store_unavailable" if isinstance(exc, OSError) else "error"


CARDS_TTL_ENV = "DT_PULT_CARDS_TTL_S"


def _list_page(kind: CardKind, env: QueueEnv, cap: int, refresh: bool) -> KindPage:
    """Страница вида: живьем либо из снимка (``cache_stamp`` != None): hub/alias/link считают
    ``similar_hubs``/алиасы/каталог (200-900 мс): второй вызов берет файл, пока сторы те же."""
    stamp = kind.cache_stamp(env)
    if stamp is None:
        return kind.list(env, cap, refresh=refresh)
    from core.operational.snapshot import cached_read, ttl_from_env

    def compute() -> dict[str, Any]:
        page = kind.list(env, cap, refresh=False)
        return {"cards": page.cards, "total": page.total, "error": page.error, "as_of": ""}

    payload, meta = cached_read(
        f"{CACHE_PREFIX}{kind.kind}-{cap}", ttl_from_env(CARDS_TTL_ENV, 600), compute, stamp=stamp)
    return KindPage(payload["cards"], int(payload["total"]), str(payload.get("error") or ""),
                    as_of=str(meta["as_of"]))


def _drop_cached_pages(kind: str) -> None:
    """Решение по карточке меняет сторы - снимки страниц вида устарели (stamp поймал бы позже)."""
    try:
        from core.operational.snapshot import invalidate

        invalidate(f"{CACHE_PREFIX}{kind}-")
    except Exception:  # noqa: BLE001, S110 - сброс снимка не должен ломать решение
        pass


def queue(
    env: QueueEnv | None = None,
    *,
    kinds: list[str] | None = None,
    limit: int = 50,
    refresh: bool = False,
) -> dict[str, Any]:
    """Карточки очереди: ``{cards, totals: {kind: pending}, errors: {kind: code}, as_of}``.

    Сбой одного вида - в ``errors``, остальные виды отдаются («ошибка ≠ пусто» в контракте).
    ``limit`` - карточек НА ВИД (``<=0`` - все); ``totals`` - сколько ждут решения на самом деле.
    ``refresh`` пересчитывает только ``gold`` (дорого: реранкер); без него ``gold`` НИКОГДА не
    считается на чтении - отдается последний расчет (его ведет шаг ``eval`` ночной цепочки либо
    кнопка), ``as_of_kinds`` называет время расчета, ``timings`` - сколько мс занял каждый вид."""
    env = env or QueueEnv()
    registry = get_registry()
    wanted = list(kinds) if kinds else list(registry)
    cards: list[dict[str, Any]] = []
    totals: dict[str, int] = {}
    errors: dict[str, str] = {}
    timings: dict[str, int] = {}
    as_of_kinds: dict[str, str] = {}
    cap = int(limit) if limit else 0
    for name in wanted:
        kind = registry.get(name)
        if kind is None:
            errors[name] = "unknown_kind"
            continue
        started = time.perf_counter()
        try:
            page = _list_page(kind, env, max(0, cap), bool(refresh))
        except Exception as exc:  # noqa: BLE001 - сбой вида не роняет остальные
            logger.warning("вид очереди %s не прочитан: %s", name, exc)
            errors[name] = _error_code(exc)
            timings[name] = int((time.perf_counter() - started) * 1000)
            continue
        timings[name] = int((time.perf_counter() - started) * 1000)
        if page.as_of:
            as_of_kinds[name] = page.as_of
        cards.extend(page.cards)
        totals[name] = page.total
        if page.error:
            errors[name] = page.error
    return {
        "cards": cards,
        "totals": totals,
        "errors": errors,
        "as_of": env.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "as_of_kinds": as_of_kinds,
        "timings": timings,
    }


def pending_totals(env: QueueEnv | None = None) -> tuple[dict[str, int], dict[str, str]]:
    """``({kind: ждут}, {kind: код ошибки})`` - для доктора: без пересчета eval-кандидатов."""
    env = env or QueueEnv()
    totals: dict[str, int] = {}
    errors: dict[str, str] = {}
    for name, kind in get_registry().items():
        try:
            totals[name] = kind.count(env)
        except Exception as exc:  # noqa: BLE001
            errors[name] = _error_code(exc)
    return totals, errors


def _outcome(
    kind: str,
    card: str,
    action: str,
    *,
    outcome: str,
    detail: str = "",
    effects: list[str] | None = None,
    code: str | None = None,
) -> dict[str, Any]:
    out: dict[str, Any] = {
        "ok": outcome not in ("refused",),
        "outcome": outcome,
        "detail": detail,
        "effects": list(effects or []),
        "card_id": card,
        "kind": kind,
        "action": action,
    }
    if code:
        out["code"] = code
    return out


def _refused(card: str, action: str, code: str, detail: str, kind: str = "") -> dict[str, Any]:
    return _outcome(kind, card, action, outcome="refused", code=code, detail=detail)


def _audit(result: dict[str, Any]) -> None:
    """Аудит решения ОДИН раз: строка ``pult-actions.log`` + (если решение состоялось) событие.

    Только идентификаторы, вид, действие, исход и кто решал; текста карточки здесь нет."""
    from core.host import current_host
    from core.metrics import record_event
    from core.operational.pult import record_action

    who = current_host()
    params: dict[str, Any] = {
        "kind": result["kind"] or "-",
        "id": result["card_id"],
        "action": result["action"],
        "host": who["name"],
        "surface": who["surface"],
    }
    if result.get("code"):
        params["code"] = result["code"]
    record_action(AUDIT_TOOL, params, result["outcome"])
    if result["outcome"] in DECIDED_OUTCOMES and result["kind"]:
        record_event(
            EVENT_KIND,
            card_kind=result["kind"],  # ``kind`` занят самим событием
            decision=_DECISION_OF[result["outcome"]],
            host=who["name"],
        )


def decide(
    card: str,
    action: str,
    params: dict[str, Any] | None = None,
    *,
    env: QueueEnv | None = None,
    audit: bool = True,
) -> dict[str, Any]:
    """Принять решение по карточке ``<kind>:<id>``. Исход - единой формы (см. док модуля).

    Неизвестная карточка/действие - ``refused`` без записи в сторы; ``ValueError`` ядра
    (неверный параметр) тоже становится ``refused``: отказ пересекает границу как ДАННЫЕ."""
    env = env or QueueEnv()
    name, native = split_card_id(card)
    kind = get_registry().get(name)
    if kind is None or not native:
        result = _refused(card, action, "unknown_card",
                          f"карточка {str(card)[:60]!r} не найдена: id вида «<вид>:<id>»")
    elif kind.spec(action) is None:
        result = _refused(card, action, "bad_action",
                          f"у вида {name} нет действия {action!r}: "
                          + ", ".join(a.action for a in kind.actions), name)
    else:
        try:
            raw = kind.decide(env, native, action, dict(params or {}))
            result = _outcome(
                name, card, action,
                outcome=str(raw.get("outcome") or "refused"),
                detail=str(raw.get("detail") or ""),
                effects=list(raw.get("effects") or []),
                code=raw.get("code"),
            )
        except ValueError as exc:
            missing = "не найден" in str(exc)
            result = _refused(card, action, "unknown_card" if missing else "invalid_params",
                              str(exc)[:240], name)
        except Exception as exc:  # noqa: BLE001 - отказ данными, а не исключением через границу
            logger.warning("решение %s/%s не принято: %s", card, action, exc)
            result = _refused(card, action, "error",
                              f"{type(exc).__name__}: {str(exc)[:200]}", name)
    if kind is not None:
        _drop_cached_pages(name)
    if audit:
        _audit(result)
    return result


def explain(
    card: str, *, env: QueueEnv | None = None, params: dict[str, Any] | None = None
) -> dict[str, Any]:
    """«Почему» по карточке: ``{ok, card_id, kind, why}``; ``why: null`` - вид не объясняется.

    Неизвестная карточка - ``{ok: false, refused: true, code: "unknown_card"}``."""
    env = env or QueueEnv()
    name, native = split_card_id(card)
    kind = get_registry().get(name)
    if kind is None or not native:
        return {"ok": False, "refused": True, "code": "unknown_card", "card_id": card,
                "detail": f"карточка {str(card)[:60]!r} не найдена: id вида «<вид>:<id>»"}
    try:
        why = kind.explain_with(env, native, dict(params or {}))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "refused": True, "code": _error_code(exc), "card_id": card,
                "kind": name, "detail": str(exc)[:200]}
    if why is None and kind.explain.__func__ is not CardKind.explain:  # type: ignore[attr-defined]
        # вид умеет объяснять, но карточки уже нет (решена/снята) - не то же, что «не объясняется»
        return {"ok": False, "refused": True, "code": "unknown_card", "card_id": card,
                "kind": name, "detail": "карточки нет в очереди (решена или снята)"}
    return {"ok": True, "card_id": card, "kind": name, "why": why}
