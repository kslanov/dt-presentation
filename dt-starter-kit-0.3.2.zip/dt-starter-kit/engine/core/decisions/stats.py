"""QUEUE-SERVER-1 п.3 — статистика решений по видам для доктора «Очередь решений».

Источник - журнал метрик: событие ``queue_decision`` (``card_kind``, ``decision``) пишет
:func:`core.decisions.registry.decide`; до появления фасада решения по ссылкам и кандидатам в хабы
писали сами ядра (``link_decision``/``hub_decision``) - их считаем ТОЛЬКО за период до первого
``queue_decision`` (иначе решение через фасад посчиталось бы дважды: событием ядра и событием
реестра). Доля принятых = принятые / (принятые + отклоненные); отложенные и маршрутизации в долю
не входят. Это ЗАМЕР детектора, не правка: порог ``warn`` - в :func:`noisy_kinds`.
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "MIN_DECISIONS",
    "PENDING_WARN",
    "SHARE_WARN",
    "WINDOW_DAYS",
    "decision_stats",
    "noisy_kinds",
    "share",
]

WINDOW_DAYS = 30
PENDING_WARN = 100      # у вида больше стольких ждущих карточек - очередь копится
SHARE_WARN = 0.2        # доля принятых ниже этой при MIN_DECISIONS решениях - детектор шумит
MIN_DECISIONS = 30

_APPROVED = ("approved", "auto")
# Решения, которые до фасада писали ядра: вид карточки по виду события.
_LEGACY_KIND = {"hub_decision": "hub", "link_decision": "link"}


def decision_stats(events: list[dict[str, Any]]) -> dict[str, dict[str, int]]:
    """``{вид: {approved, rejected}}`` по событиям окна (см. док модуля про двойной счет)."""
    stats: dict[str, dict[str, int]] = {}

    def bump(kind: str, decision: str) -> None:
        row = stats.setdefault(kind, {"approved": 0, "rejected": 0})
        if decision in _APPROVED:
            row["approved"] += 1
        elif decision == "rejected":
            row["rejected"] += 1

    queue_events = [e for e in events if e.get("kind") == "queue_decision" and e.get("card_kind")]
    first = min((str(e.get("ts") or "") for e in queue_events), default=None)
    for e in queue_events:
        bump(str(e["card_kind"]), str(e.get("decision") or ""))
    for e in events:
        legacy = _LEGACY_KIND.get(str(e.get("kind")))
        if legacy and (first is None or str(e.get("ts") or "") < first):
            bump(legacy, str(e.get("decision") or ""))
    return stats


def share(row: dict[str, int]) -> float | None:
    """Доля принятых среди принятых+отклоненных; ``None`` - решений нет."""
    total = row["approved"] + row["rejected"]
    return row["approved"] / total if total else None


def noisy_kinds(stats: dict[str, dict[str, int]]) -> list[str]:
    """Виды, у которых при ``MIN_DECISIONS``+ решениях доля принятых ниже ``SHARE_WARN``."""
    out = []
    for kind, row in stats.items():
        total = row["approved"] + row["rejected"]
        s = share(row)
        if total >= MIN_DECISIONS and s is not None and s < SHARE_WARN:
            out.append(kind)
    return sorted(out)
