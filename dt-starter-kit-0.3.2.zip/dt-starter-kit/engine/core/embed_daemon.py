"""NIGHT-CHAIN-1 п.3 — один эмбеддер на машину: демон владеет моделью, плановые джобы - его клиенты.

Было: каждый процесс грузил свою копию BGE-M3 (демон держит ее на MPS постоянно, ``dt_index``
поднимал вторую -> на 16 ГБ MPS OOM -> CPU в 5-10 раз медленнее; ночь 30.10: 40 мин на
``reindex_inc``).
Стало:

* сервер - ``POST /internal/embed`` демона (``mcp-server/server.py``): loopback-peer, без прокси-
  заголовков, Bearer **rw**-токен; НЕ MCP-инструмент (нет ни в ``tools/list`` профилей, ни в
  allowlist пульта). Здесь - чистые части без ASGI: разбор и проверка запроса (:func:`serve_embed`),
  упаковка векторов;
* клиент - :class:`RoutedEmbedder`: ``core.embeddings.get_embedder()`` отдает его в процессах,
  которые не владеют моделью (``DT_EMBED_VIA_DAEMON`` не 0 и процесс не демон). Живой
  ``/health`` демона +
  rw-токен -> вектора считает демон (под ``RLock`` его эмбеддера: честная очередь с хостами); нет
  демона/токена, таймаут, 5xx, битый ответ -> локальная загрузка, как раньше, одно предупреждение
  на процесс. ``DT_EMBED_VIA_DAEMON=0`` - код прежний: ``get_embedder()`` отдает локальный синглтон.

PERSONAL-1: экземпляр без модели (``DT_EMBED_OWNER=0``; личный демон) считает через СОСЕДА -
``DT_EMBED_URL`` (чужой ``/internal/embed``) с узким токеном соседа (``DT_EMBED_TOKEN`` /
``<секреты экземпляра>/embed_token``, не rw рабочего демона); откат на локальную загрузку - тот же.
Без ``DT_EMBED_URL`` адрес по-прежнему свой порт (``DT_WEB_PORT``) и rw-токен.

Приватность: тела чанков идут только по loopback и нигде не логируются (в журнал - число текстов,
устройство, миллисекунды). Вектора - base64 от little-endian float32 (байт-в-байт те, что посчитала
бы локальная модель; JSON-списки float64 были бы втрое больше).
"""

from __future__ import annotations

import base64
import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request
from typing import TYPE_CHECKING, Any

from core.embeddings import EMBEDDING_DIM, MAX_SEQ_LENGTH, MODEL_NAME, Embedder

if TYPE_CHECKING:
    import numpy as np

logger = logging.getLogger("dt.embed")

__all__ = [
    "DEFAULT_TIMEOUT_S",
    "EmbedRequestError",
    "RoutedEmbedder",
    "decode_vectors",
    "encode_vectors",
    "is_model_owner",
    "mark_model_owner",
    "request_limits",
    "reset_client",
    "serve_embed",
    "should_route",
    "via_daemon_enabled",
]

VIA_ENV = "DT_EMBED_VIA_DAEMON"
TIMEOUT_ENV = "DT_EMBED_DAEMON_TIMEOUT_S"
DEFAULT_TIMEOUT_S = 300.0  # холодный старт модели в демоне + очередь за генерацией хоста
_HEALTH_TTL_S = 60.0  # «демон жив» помним минуту, «не жив» - 15 с (рестарт демона подхватим)
_DEAD_TTL_S = 15.0
_MAX_CHARS_PER_TEXT = 8 * MAX_SEQ_LENGTH * 4  # токенайзер режет по MAX_SEQ_LENGTH токенов; запас
_MAX_BATCH_FACTOR = 4  # текстов в запросе <= 4 × батч кодирования (64 на mps -> 256)

_model_owner = False


def mark_model_owner() -> None:
    """Процесс - демон: модель его, к самому себе он не ходит (зовет ``serve_http``)."""
    global _model_owner
    _model_owner = True


def is_model_owner() -> bool:
    return _model_owner


def via_daemon_enabled() -> bool:
    """``DT_EMBED_VIA_DAEMON`` (дефолт 1; ``0/false/no/off`` - эмбеддер локальный, как раньше)."""
    raw = (os.environ.get(VIA_ENV) or "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


def should_route() -> bool:
    return via_daemon_enabled() and not _model_owner


def _timeout_s() -> float:
    raw = (os.environ.get(TIMEOUT_ENV) or "").strip()
    try:
        value = float(raw) if raw else DEFAULT_TIMEOUT_S
    except ValueError:
        return DEFAULT_TIMEOUT_S
    return value if value > 0 else DEFAULT_TIMEOUT_S


def request_limits() -> tuple[int, int]:
    """``(макс. текстов в запросе, макс. символов в одном тексте)`` - один источник для сервера и
    клиента. Тексты: ``4 × DT_EMBED_BATCH_SIZE`` (дефолт 64); символы: хвост за пределом
    ``MAX_SEQ_LENGTH`` токенов токенайзер все равно отбросил бы."""
    raw = (os.environ.get("DT_EMBED_BATCH_SIZE") or "").strip()
    try:
        batch = int(raw) if raw else 64
    except ValueError:
        batch = 64
    return max(1, batch) * _MAX_BATCH_FACTOR, _MAX_CHARS_PER_TEXT


# --------------------------------------------------------------------------- #
# Упаковка векторов                                                            #
# --------------------------------------------------------------------------- #
def encode_vectors(vectors: np.ndarray) -> dict[str, Any]:
    import numpy as np

    arr = np.ascontiguousarray(vectors, dtype="<f4")
    return {"dtype": "float32", "shape": [int(arr.shape[0]), int(arr.shape[1])],
            "b64": base64.b64encode(arr.tobytes()).decode("ascii")}


def decode_vectors(payload: Any, *, expect_rows: int) -> np.ndarray:
    """Обратная упаковка + проверка формы ``(expect_rows, EMBEDDING_DIM)`` float32 (иначе
    ``ValueError``)."""
    import numpy as np

    if not isinstance(payload, dict) or payload.get("dtype") != "float32":
        raise ValueError("vectors: ожидался float32-пакет")
    shape = payload.get("shape")
    if shape != [expect_rows, EMBEDDING_DIM]:
        raise ValueError(f"vectors: форма {shape}, ожидалась {[expect_rows, EMBEDDING_DIM]}")
    raw = base64.b64decode(str(payload.get("b64") or ""), validate=True)
    if len(raw) != expect_rows * EMBEDDING_DIM * 4:
        raise ValueError("vectors: размер данных не сходится с формой")
    return np.frombuffer(raw, dtype="<f4").reshape(expect_rows, EMBEDDING_DIM).astype(
        np.float32, copy=True)


# --------------------------------------------------------------------------- #
# Сервер: разбор запроса и расчет (ASGI-обвязка - в mcp-server/server.py)       #
# --------------------------------------------------------------------------- #
class EmbedRequestError(Exception):
    """Отказ запроса ``/internal/embed``: HTTP-статус + машинный код (текстов в сообщении нет)."""

    def __init__(self, status: int, code: str) -> None:
        self.status, self.code = status, code
        super().__init__(code)


def parse_request(raw: bytes) -> tuple[list[str], int | None, str]:
    """``(тексты, batch_size, формат ответа)`` из тела; нарушение - :class:`EmbedRequestError`."""
    max_texts, max_chars = request_limits()
    try:
        body = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        raise EmbedRequestError(400, "bad_json") from None
    if not isinstance(body, dict):
        raise EmbedRequestError(400, "bad_request")
    texts = body.get("texts")
    if not isinstance(texts, list) or not all(isinstance(t, str) for t in texts):
        raise EmbedRequestError(400, "texts_must_be_list_of_strings")
    if len(texts) > max_texts:
        raise EmbedRequestError(413, "too_many_texts")
    if any(len(t) > max_chars for t in texts):
        raise EmbedRequestError(413, "text_too_long")
    batch = body.get("batch_size")
    if batch is not None and (not isinstance(batch, int) or isinstance(batch, bool)
                              or not 1 <= batch <= 1024):
        raise EmbedRequestError(400, "bad_batch_size")
    fmt = body.get("format", "b64")
    if fmt not in {"b64", "json"}:
        raise EmbedRequestError(400, "bad_format")
    return texts, batch, fmt


def serve_embed(raw: bytes) -> dict[str, Any]:
    """Тело запроса -> ответ ``{vectors, model, device, ms, n}``.

    Считает ЛОКАЛЬНЫЙ эмбеддер процесса (его ``embed`` берет собственный ``RLock``: запросы
    плановых джобов и хостов - в одной очереди)."""
    from core.embeddings import local_embedder

    texts, batch, fmt = parse_request(raw)
    emb = local_embedder()
    started = time.perf_counter()
    vectors = emb.embed(texts, batch_size=batch)
    ms = int((time.perf_counter() - started) * 1000)
    packed: Any = (encode_vectors(vectors) if fmt == "b64" else vectors.tolist())
    return {"vectors": packed, "model": emb.model_id, "device": emb.device, "ms": ms,
            "n": len(texts)}


# --------------------------------------------------------------------------- #
# Клиент                                                                       #
# --------------------------------------------------------------------------- #
class _Client:
    """Состояние клиента процесса: кэш «демон жив», липкий откат на локальную загрузку, счетчики."""

    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.alive_until = 0.0
        self.dead_until = 0.0
        self.sticky_local = ""  # причина; после сбоя ЗАПРОСА демон в этом процессе не пробуем
        self.warned = False
        self.last_device = ""
        self.last_model = ""
        self.via = ""  # "daemon" | "local" - как считали последний раз
        self.chunks_by_device: dict[str, int] = {}
        self.seconds_by_device: dict[str, float] = {}
        self.calls = 0

    def warn_once(self, why: str) -> None:
        if self.warned:
            return
        self.warned = True
        logger.warning("[embeddings] демон DT недоступен для эмбеддинга (%s) - локальная загрузка "
                       "модели в этом процессе (медленнее, на 16 ГБ возможен MPS OOM)", why)


_client = _Client()


def reset_client() -> None:
    """Сбросить состояние клиента (тесты; новый процесс начинает с чистого)."""
    global _client
    _client = _Client()


def _port() -> int:
    try:
        return int(os.environ.get("DT_WEB_PORT") or 8787)
    except ValueError:
        return 8787


def _base_url() -> str:
    """Чей ``/internal/embed``: ``DT_EMBED_URL`` соседа либо свой порт (прежнее поведение)."""
    from core.instance import embed_url

    return embed_url() or f"http://127.0.0.1:{_port()}"


def _daemon_alive() -> bool:
    from core.daemon import fetch_health, fetch_health_url

    now = time.monotonic()
    if now < _client.alive_until:
        return True
    if now < _client.dead_until:
        return False
    from core.instance import embed_url

    neighbour = embed_url()
    alive = (fetch_health_url(neighbour, timeout=1.5) if neighbour
             else fetch_health(_port(), timeout=1.5))
    if alive is None:
        _client.dead_until = now + _DEAD_TTL_S
        return False
    _client.alive_until = now + _HEALTH_TTL_S
    return True


def _rw_token() -> str:
    """Токен к ``/internal/embed``: у экземпляра с соседом - его узкий, иначе rw (как было)."""
    from core.instance import embed_url
    from core.web_tokens import WebTokens

    try:
        tokens = WebTokens()
        return (tokens.embed() if embed_url() else tokens.rw()) or ""
    except Exception:  # noqa: BLE001 — нет токена = нет демона для нас
        return ""


def _post(texts: list[str], batch_size: int | None, token: str) -> dict[str, Any]:
    body: dict[str, Any] = {"texts": texts}
    if batch_size is not None:
        body["batch_size"] = int(batch_size)
    req = urllib.request.Request(  # noqa: S310 - loopback http (embed_url() допускает только его)
        f"{_base_url()}/internal/embed",
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=_timeout_s()) as resp:  # noqa: S310 — loopback http
        data = json.loads(resp.read().decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("ответ не объект")
    return data


def _chunks(texts: list[str]) -> list[list[str]]:
    """Порции под лимиты запроса (число текстов; суммарный объем ~ как у ``max_texts`` полных)."""
    max_texts, max_chars = request_limits()
    budget = max_texts * max_chars // 4  # ~8 МБ текста на запрос
    out: list[list[str]] = []
    cur: list[str] = []
    size = 0
    for t in texts:
        if cur and (len(cur) >= max_texts or size + len(t) > budget):
            out.append(cur)
            cur, size = [], 0
        cur.append(t)
        size += len(t)
    if cur:
        out.append(cur)
    return out


class RoutedEmbedder(Embedder):
    """Эмбеддер процесса-клиента: вектора - у демона, при любой его недоступности - локально.

    Не грузит модель, пока не пришлось откатиться: ``local_getter`` зовется лениво. ``device``/
    ``model_id`` отдают то, что ответил демон (иначе - локальные); ``via`` - ``daemon``/``local``.
    """

    def __init__(self, local_getter: Any) -> None:
        self._local_getter = local_getter

    # -- Embedder ----------------------------------------------------------
    def embed(self, texts: list[str], batch_size: int | None = None) -> np.ndarray:
        import numpy as np

        if not texts:
            return np.empty((0, EMBEDDING_DIM), dtype=np.float32)
        got = self._via_daemon(texts, batch_size)
        if got is not None:
            return got
        _client.via = "local"
        return self._local().embed(texts, batch_size=batch_size)

    @property
    def dim(self) -> int:
        return EMBEDDING_DIM

    @property
    def model_id(self) -> str:
        return _client.last_model or self._local_attr("model_id", MODEL_NAME)

    @property
    def device(self) -> str:
        if _client.via == "daemon" and _client.last_device:
            return _client.last_device
        return str(self._local_attr("device", "unknown"))

    @property
    def via(self) -> str:
        return _client.via

    @property
    def fallback_reason(self) -> str:
        return str(self._local_attr("fallback_reason", ""))

    @property
    def embed_stats(self) -> dict[str, Any]:
        local = dict(self._local_attr("embed_stats", {}) or {})
        by_dev = dict(local.get("chunks_by_device") or {})
        secs = dict(local.get("seconds_by_device") or {})
        for dev, n in _client.chunks_by_device.items():
            by_dev[dev] = by_dev.get(dev, 0) + n
        for dev, s in _client.seconds_by_device.items():
            secs[dev] = round(secs.get(dev, 0.0) + s, 3)
        if not by_dev and not local:
            return {}
        return {**local, "chunks_by_device": by_dev, "seconds_by_device": secs}

    def release_cache(self) -> None:
        if self._local_loaded():
            self._local().release_cache()

    # -- внутреннее --------------------------------------------------------
    def _local(self) -> Embedder:
        emb: Embedder = self._local_getter()
        return emb

    def _local_loaded(self) -> bool:
        from core import embeddings

        return embeddings._embedder is not None

    def _local_attr(self, name: str, default: Any) -> Any:
        return getattr(self._local(), name, default) if self._local_loaded() else default

    def _via_daemon(self, texts: list[str], batch_size: int | None) -> np.ndarray | None:
        import numpy as np

        c = _client
        if c.sticky_local:
            return None
        if not _daemon_alive():
            c.warn_once("нет живого /health")
            return None
        token = _rw_token()
        if not token:
            c.warn_once("нет токена эмбеддера соседа (embed_token / DT_EMBED_TOKEN)"
                        if _base_url() != f"http://127.0.0.1:{_port()}"
                        else "нет rw-токена (.secrets/web_token_rw / DT_WEB_TOKEN_RW)")
            return None
        _max_texts, max_chars = request_limits()
        if any(len(t) > max_chars for t in texts):
            c.warn_once("текст длиннее лимита запроса")
            return None
        parts: list[np.ndarray] = []
        device = model = ""
        for piece in _chunks(texts):
            try:
                data = _post(piece, batch_size, token)
                part = decode_vectors(data.get("vectors"), expect_rows=len(piece))
            except (urllib.error.URLError, OSError, TimeoutError, ValueError) as exc:
                # 4xx/5xx, таймаут, разрыв, битый ответ: дальше в этом процессе считаем локально
                c.sticky_local = type(exc).__name__
                c.warn_once(f"{type(exc).__name__}: {str(exc)[:120]}")
                return None
            parts.append(part)
            device = str(data.get("device") or device)
            model = str(data.get("model") or model)
            dev = str(data.get("device") or "unknown")
            c.chunks_by_device[dev] = c.chunks_by_device.get(dev, 0) + len(piece)
            c.seconds_by_device[dev] = c.seconds_by_device.get(dev, 0.0) + float(
                data.get("ms") or 0) / 1000.0
        c.calls += 1
        c.last_device, c.last_model, c.via = device, model, "daemon"
        if c.calls == 1:
            logger.info("[embeddings] device=%s via daemon (модель %s)", device or "?", model)
        return parts[0] if len(parts) == 1 else np.concatenate(parts, axis=0)
