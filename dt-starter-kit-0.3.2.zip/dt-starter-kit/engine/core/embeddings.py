"""Embeddings — local BGE-M3 via sentence-transformers (architecture §2).

Dense, multilingual (strong Russian) embeddings, dim 1024, L2-normalized for
cosine/inner-product search. The model is loaded lazily and once per process.

Design note — the :class:`Embedder` interface exists so the backend can be
swapped later (e.g. an API fallback such as voyage-multilingual-2). Per ТЗ we
implement ONLY the local BGE-M3 target. If the local model fails to load
(RAM/MPS), we raise an explicit :class:`EmbeddingModelError` with diagnostics —
we never silently fall back to a remote API.

Query vs document: BGE-M3 dense retrieval is symmetric — the official usage
prepends no instruction to queries (unlike e5-style models). So ``embed_query``
embeds the raw text, identically to documents.
"""

from __future__ import annotations

import logging
import os
import threading
import time

# Route BGE-M3 ops that have no MPS kernel to CPU *per op* instead of silently
# hanging the whole process (the 20-hour stall we hit). This MUST be set BEFORE
# torch is first imported — including transitively via sentence-transformers — so
# we set it at module import, ahead of every (lazy) ``import torch`` below. MPS
# stays the default device, so the bulk of the work still runs on the GPU and a
# full run drops to ~20–40 min; only unsupported ops trickle to CPU.
os.environ.setdefault("PYTORCH_ENABLE_MPS_FALLBACK", "1")

# SYNC-OFFLINE-1 insurance: bound EVERY huggingface_hub network op so a background
# run can never hang forever on a socket read (the 36h stall: the Mac slept mid-
# read of the model-update check → half-dead ESTABLISHED, infinite read). At a live
# cache the load is offline (``local_files_only``; PART-1) so these never fire — but
# if any legitimate network call remains, it now times out instead of wedging.
# ETAG timeout guards the metadata/HEAD check that actually hung; DOWNLOAD the body.
os.environ.setdefault("HF_HUB_ETAG_TIMEOUT", "10")
os.environ.setdefault("HF_HUB_DOWNLOAD_TIMEOUT", "30")

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import numpy as np

logger = logging.getLogger(__name__)

__all__ = [
    "Embedder",
    "BGEEmbedder",
    "EmbeddingModelError",
    "EMBEDDING_DIM",
    "MODEL_NAME",
    "get_embedder",
    "embed_texts",
    "embed_query",
]

MODEL_NAME = "BAAI/bge-m3"
EMBEDDING_DIM = 1024

# Hard cap on tokens per sequence. BGE-M3 supports up to 8192, but a single
# pathological long chunk (e.g. a legacy note the chunker under-split) padded to
# that length blows up memory. The chunker already targets 500–800 tokens; this
# is a backstop so one anomalous chunk can't allocate a giant tensor.
MAX_SEQ_LENGTH = 1024

# Only the files needed for dense embeddings. BGE-M3 ships three weight formats
# (model.safetensors + pytorch_model.bin + onnx ≈ 7GB); we fetch ONLY
# model.safetensors (~2.27GB) and the tokenizer/config. This keeps the download
# small, one-time, and local-first (no Hub round-trip on subsequent runs).
_ALLOW_PATTERNS = [
    "config.json",
    "config_sentence_transformers.json",
    "sentence_bert_config.json",
    "modules.json",
    "tokenizer.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
    "sentencepiece.bpe.model",
    "1_Pooling/*",
    "*.safetensors",
]


def _download_allowed() -> bool:
    """Разрешён ли разовый онлайн-докач модели (SYNC-OFFLINE-1).

    По умолчанию НЕТ — reindex офлайн (Path B). Включается только явным
    ``DT_EMBED_ALLOW_DOWNLOAD=1`` (``1``/``true``/``yes``) для разового прогрева кэша.
    """
    return os.environ.get("DT_EMBED_ALLOW_DOWNLOAD", "").strip().lower() in {
        "1", "true", "yes",
    }


class EmbeddingModelError(RuntimeError):
    """Raised when the local embedding model cannot be loaded or run.

    Carries diagnostics so a failure to start BGE-M3 (RAM/MPS) is a visible
    blocker rather than a silent degradation.
    """


class Embedder(ABC):
    """Interface for embedding backends. Implementations return (n, dim) arrays."""

    @abstractmethod
    def embed(self, texts: list[str], batch_size: int | None = None) -> np.ndarray:
        """Embed a list of texts into normalized vectors."""

    @property
    @abstractmethod
    def dim(self) -> int:
        """Embedding dimensionality."""

    @property
    def model_id(self) -> str:
        """Идентификатор модели (VEC-REUSE-1 п.5): вектор из индекса реюзается только при
        совпадении с меткой модели индекса. Фейки без переопределения = модель по умолчанию."""
        return MODEL_NAME

    @property
    def device(self) -> str:
        """Compute device the embedder runs on (for diagnostics/stats)."""
        return "unknown"

    @property
    def fallback_reason(self) -> str:
        """Почему устройство сменилось (``mps→cpu: …``); ``""`` — не менялось.

        WAVE0-HYGIENE п.7 (аудит B7): фолбэк MPS→CPU был немым — в логах только второй
        «Loading SentenceTransformer», причина проглатывалась. Теперь причина копится здесь
        и уходит в итоги reindex / событие index / doctor.
        """
        return ""

    @property
    def embed_stats(self) -> dict[str, Any]:
        """Накопленные за жизнь процесса счётчики: чанки/секунды по устройствам, OOM-повторы.

        WAVE1-MEASURE п.5: доля чанков на MPS/CPU и скорость — в отчёт reindex (по
        разности снимков до/после прогона). Пусто у фейков/бэкендов без учёта.
        """
        return {}

    def release_cache(self) -> None:
        """Release accelerator memory cached between encode calls (PERF-1).

        PyTorch's MPS allocator keeps freed tensors in a process-level cache
        that only ever grows across a long reindex; the streaming index loop
        calls this once per window so peak memory stays one-window-sized.
        No-op by default (CPU backends / test fakes) — override where it matters.
        """
        return None


def _detect_device() -> str:
    """Auto-pick a compute device: ``DT_EMBED_DEVICE`` override → MPS (Apple
    Silicon) → CUDA → CPU.

    The env override is the escape hatch when a backend misbehaves (e.g. forcing
    ``cpu`` if BGE-M3 hits an MPS kernel issue) — it short-circuits detection.
    """
    override = os.environ.get("DT_EMBED_DEVICE")
    if override and override.strip():
        return override.strip()
    try:
        import torch

        if torch.backends.mps.is_available():
            return "mps"
        if torch.cuda.is_available():
            return "cuda"
    except Exception:  # noqa: BLE001, S110 — torch import issues → CPU
        pass
    return "cpu"


def _default_batch_size(device: str) -> int:
    """A reasonable encode batch size for the device (GPUs amortize larger batches)."""
    override = os.environ.get("DT_EMBED_BATCH_SIZE")
    if override and override.strip().isdigit():
        return max(1, int(override.strip()))
    return 64 if device in ("mps", "cuda") else 32


# WAVE1-MEASURE п.5: MPS OOM → батч/2 и повтор НА MPS; на CPU — только после стольких
# подряд неудач на одном срезе (при 2,96 ГБ прогон уходил на CPU с первой же OOM-ошибки,
# хотя вдвое меньший батч помещался). Env ``DT_EMBED_OOM_RETRIES``.
DEFAULT_OOM_RETRIES = 4


def _oom_retries() -> int:
    raw = os.environ.get("DT_EMBED_OOM_RETRIES")
    if raw and raw.strip().isdigit():
        return max(0, int(raw.strip()))
    return DEFAULT_OOM_RETRIES


def _is_oom(exc: BaseException) -> bool:
    """Нехватка памяти ускорителя (MPS/CUDA): по имени класса и тексту — torch их не унифицирует."""
    if "outofmemory" in type(exc).__name__.lower():
        return True
    text = str(exc).lower()
    return any(
        marker in text
        for marker in ("out of memory", "invalid buffer size", "mps allocated")
    )


class BGEEmbedder(Embedder):
    """Local BGE-M3 dense embedder (the production target)."""

    def __init__(self, device: str | None = None, cache_folder: str | None = None) -> None:
        self._device = device or _detect_device()
        self._cache_folder = cache_folder
        self._batch_size = _default_batch_size(self._device)
        self._model = None  # lazily loaded
        # DAEMON-1-SPIKE: один эмбеддер на процесс, вызовы из потоков (демон на несколько хостов,
        # веб-пульт) - MPS/torch не потокобезопасны; RLock: ``embed`` зовет внутренние шаги.
        self._lock = threading.RLock()
        self._fallback_reason = ""
        # WAVE1-MEASURE п.5: учёт для index_report (кумулятивно за процесс).
        self._chunks_by_device: dict[str, int] = {}
        self._seconds_by_device: dict[str, float] = {}
        self._oom_retries_done = 0
        self._oom_cpu_fallbacks = 0

    def _load_on(self, device: str, cache: str) -> Any:
        from huggingface_hub import snapshot_download
        from sentence_transformers import SentenceTransformer

        # SYNC-OFFLINE-1 (Path B on практике): reindex must NOT touch the network.
        # Resolve the snapshot from the local cache ONLY (``local_files_only`` — no
        # Hub round-trip, so at a live cache there are zero network calls and the
        # eternal-read class is impossible). A cache MISS is a **hard, honest error**
        # with a hint — NOT a silent trip to the Hub (that silent fallback caused the
        # 36h hang). A one-time online fetch is opt-in only, via
        # ``DT_EMBED_ALLOW_DOWNLOAD=1`` (with the timeouts above as a backstop).
        try:
            local_path = snapshot_download(
                MODEL_NAME,
                cache_dir=cache,
                allow_patterns=_ALLOW_PATTERNS,
                local_files_only=True,
            )
        except Exception as exc:  # cache miss / offline resolve failed (re-raised below)
            if not _download_allowed():
                raise EmbeddingModelError(
                    f"Модель {MODEL_NAME!r} не найдена в локальном кэше ({cache}). "
                    "reindex работает офлайн (Path B) и в сеть НЕ ходит. Прогрей кэш "
                    "один раз явным онлайн-прогоном: "
                    f"DT_EMBED_ALLOW_DOWNLOAD=1 <reindex/dt-sync index> "
                    f"(качается ~2.27GB: {MODEL_NAME}). "
                    f"Исходная ошибка resolve: {exc!r}"
                ) from exc
            # Explicit opt-in: one-time network fetch of the allow-listed files.
            local_path = snapshot_download(
                MODEL_NAME,
                cache_dir=cache,
                allow_patterns=_ALLOW_PATTERNS,
            )

        # Load strictly from the resolved local path; local_files_only=True stops
        # SentenceTransformer from re-syncing the repo by id (no Hub call ever, even
        # on the opt-in download path — the files are already on disk by now).
        return SentenceTransformer(local_path, device=device, local_files_only=True)

    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        from core.config import models_path

        cache = self._cache_folder or str(models_path())
        try:
            self._model = self._load_on(self._device, cache)
            self._cap_seq_length()
        except EmbeddingModelError:
            # SYNC-OFFLINE-1: offline cache-miss hint from _load_on is device-
            # independent — surface it as-is (not an MPS kernel issue → no CPU retry).
            raise
        except Exception as exc:
            # MPS can fail to load/run some kernels for BGE-M3. Rather than hard-fail
            # on Apple Silicon, fall back once to CPU (still local, just slower) so
            # indexing keeps working; the override DT_EMBED_DEVICE=cpu makes it sticky.
            if self._device == "mps":
                self._note_fallback("загрузка модели", exc)
                try:
                    self._model = self._load_on("cpu", cache)
                    self._device = "cpu"
                    self._batch_size = _default_batch_size("cpu")
                    self._cap_seq_length()
                    return
                except Exception as cpu_exc:  # noqa: BLE001 — fall through to the raise below
                    logger.error(
                        "[embeddings] загрузка на CPU после сбоя MPS тоже не удалась: %r", cpu_exc
                    )
            raise EmbeddingModelError(
                f"Failed to load local embedding model {MODEL_NAME!r} "
                f"on device {self._device!r} (cache: {cache}). "
                "This is a hard blocker — no silent API fallback. "
                "Check available RAM/disk, MPS/torch install, and network for the "
                f"first ~2GB download. Original error: {exc!r}"
            ) from exc

    def _cap_seq_length(self) -> None:
        """Clamp the model's max sequence length to :data:`MAX_SEQ_LENGTH`.

        Bounds per-sequence padding so one anomalously long chunk can't allocate
        a giant tensor (a contributor to the 14 GB full-rebuild stall).
        """
        model = self._model
        if model is None:
            return
        current = getattr(model, "max_seq_length", None)
        if current is None or current > MAX_SEQ_LENGTH:
            model.max_seq_length = MAX_SEQ_LENGTH

    @property
    def dim(self) -> int:
        return EMBEDDING_DIM

    @property
    def device(self) -> str:
        return self._device

    @property
    def fallback_reason(self) -> str:
        return self._fallback_reason

    def _note_fallback(self, stage: str, exc: BaseException) -> None:
        """WARNING с причиной + запись в :attr:`fallback_reason` (no-silent-fallback, п.7)."""
        self._fallback_reason = f"mps→cpu ({stage}): {type(exc).__name__}: {exc}"[:400]
        logger.warning(
            "[embeddings] ФОЛБЭК MPS→CPU (%s): %r — прогон продолжится на CPU, медленнее; "
            "причина попадёт в итоги reindex/doctor (DT_EMBED_DEVICE=cpu делает выбор явным)",
            stage, exc,
        )

    def release_cache(self) -> None:
        """Flush the MPS allocator cache (PERF-1); no-op on CPU/CUDA-less setups.

        Best-effort by design: a failure to release cache must never break the
        run it is trying to protect.
        """
        if self._device != "mps":
            return
        try:
            import torch

            mps = getattr(torch, "mps", None)
            if mps is not None and hasattr(mps, "empty_cache"):
                mps.empty_cache()
        except Exception:  # noqa: BLE001, S110 — освобождение кэша не роняет прогон
            pass

    def _encode(self, texts: list[str], batch_size: int | None) -> np.ndarray:
        import numpy as np

        vectors = self._model.encode(
            texts,
            batch_size=batch_size or self._batch_size,
            normalize_embeddings=True,
            convert_to_numpy=True,
            show_progress_bar=False,
        )
        return np.asarray(vectors, dtype=np.float32)

    def _switch_to_cpu(self, exc: BaseException | None = None) -> bool:
        """Reload the model on CPU after an MPS failure; ``True`` on success.

        Companion to the load-time CPU fallback in :meth:`_ensure_model` — here we
        recover from an *encode-time* MPS kernel error so a multi-hour index run
        is not lost. The switch is sticky for the rest of the process.
        """
        from core.config import models_path

        if exc is not None:
            self._note_fallback("inference", exc)
        cache = self._cache_folder or str(models_path())
        try:
            self._model = self._load_on("cpu", cache)
            self._device = "cpu"
            self._batch_size = _default_batch_size("cpu")
            self._cap_seq_length()
            return True
        except Exception as cpu_exc:  # noqa: BLE001 — fall through to the caller's raise
            logger.error("[embeddings] перезагрузка на CPU после сбоя MPS не удалась: %r", cpu_exc)
            return False

    @property
    def embed_stats(self) -> dict[str, Any]:
        return {
            "chunks_by_device": dict(self._chunks_by_device),
            "seconds_by_device": {k: round(v, 3) for k, v in self._seconds_by_device.items()},
            "oom_retries": self._oom_retries_done,
            "oom_cpu_fallbacks": self._oom_cpu_fallbacks,
            "batch_size": self._batch_size,
        }

    def _count(self, device: str, n: int, seconds: float) -> None:
        self._chunks_by_device[device] = self._chunks_by_device.get(device, 0) + n
        self._seconds_by_device[device] = self._seconds_by_device.get(device, 0.0) + seconds

    def _on_oom(self, exc: BaseException, bs: int, failures: int, limit: int) -> int | None:
        """MPS OOM на срезе из ``bs`` текстов: новый (вдвое меньший) батч или ``None`` → на CPU.

        Освобождает кэш аллокатора и держит уменьшенный батч до конца процесса —
        прогоняемый корпус тот же, второй раз упираться в тот же потолок незачем.
        """
        if failures > limit or bs <= 1:
            return None
        self.release_cache()
        smaller = max(1, bs // 2)
        self._batch_size = min(self._batch_size, smaller)
        self._oom_retries_done += 1
        logger.warning(
            "[embeddings] MPS OOM (%s: %s) — батч %d→%d, повтор на MPS (%d из %d)",
            type(exc).__name__, str(exc)[:160], bs, smaller, failures, limit,
        )
        return smaller

    def embed(self, texts: list[str], batch_size: int | None = None) -> np.ndarray:
        """Потокобезопасная обертка: вызовы сериализуются (см. ``_embed_unlocked``)."""
        with self._lock:
            return self._embed_unlocked(texts, batch_size)

    def _embed_unlocked(self, texts: list[str], batch_size: int | None = None) -> np.ndarray:
        """Embed ``texts`` срезами по батчу, с адаптацией под память ускорителя.

        WAVE1-MEASURE п.5. Срез за срезом (между срезами на MPS — ``empty_cache``):
        OOM на MPS → батч/2 и повтор ТОГО ЖЕ среза на MPS (уже посчитанное не
        теряется); после ``DT_EMBED_OOM_RETRIES`` подряд неудач (или при батче 1) —
        на CPU с WARNING и причиной. Любая другая ошибка MPS (не память) — на CPU сразу,
        как раньше. Зависание без исключения здесь не ловится (``DT_EMBED_DEVICE=cpu``).
        """
        import numpy as np

        if not texts:
            return np.empty((0, EMBEDDING_DIM), dtype=np.float32)
        self._ensure_model()
        parts: list[np.ndarray] = []
        at = 0
        bs = max(1, min(batch_size or self._batch_size, len(texts)))
        failures = 0
        limit = _oom_retries()
        while at < len(texts):
            piece = texts[at : at + bs]
            device = self._device
            started = time.perf_counter()
            try:
                vectors = self._encode(piece, bs)
            except Exception as exc:
                if device != "mps":
                    raise EmbeddingModelError(
                        f"Embedding inference failed on device {device!r}: {exc!r}"
                    ) from exc
                cause: BaseException = exc
                if _is_oom(exc):
                    failures += 1
                    smaller = self._on_oom(exc, bs, failures, limit)
                    if smaller is not None:
                        bs = smaller
                        continue
                    self._oom_cpu_fallbacks += 1
                    cause = RuntimeError(
                        f"MPS OOM: после {min(failures - 1, limit)} повторов с меньшим "
                        f"батчем (последний {bs}) память всё ещё не хватает "
                        f"(последняя ошибка: {exc})"
                    )
                # Не память либо исчерпаны повторы: перезагрузка на CPU один раз, остаток — там.
                if not self._switch_to_cpu(cause):
                    raise EmbeddingModelError(
                        f"Embedding inference failed on device 'mps' and CPU reload "
                        f"failed: {cause!r}"
                    ) from exc
                bs = max(1, min(bs, self._batch_size))
                failures = 0
                continue
            self._count(device, len(piece), time.perf_counter() - started)
            parts.append(vectors)
            at += len(piece)
            failures = 0
            if device == "mps" and at < len(texts):
                self.release_cache()  # между батчами: MPS-аллокатор не копит буферы
        return parts[0] if len(parts) == 1 else np.concatenate(parts, axis=0)


# Process-wide singleton (model loaded once).
_embedder: Embedder | None = None
_embedder_lock = threading.Lock()
_routed: Embedder | None = None


def local_embedder() -> Embedder:
    """Локальный эмбеддер процесса (BGE-M3, синглтон). Им считает демон на ``/internal/embed`` и
    откатывается клиент, когда демона нет; сама модель грузится лениво при первом ``embed``."""
    global _embedder
    if _embedder is None:
        with _embedder_lock:  # два потока на холодном старте не создают два эмбеддера
            if _embedder is None:
                _embedder = BGEEmbedder()
    return _embedder


def get_embedder() -> Embedder:
    """Эмбеддер процесса для потребителей (индексатор, поиск, eval, плановые джобы).

    NIGHT-CHAIN-1: один эмбеддер на машину. Процесс, не владеющий моделью (не демон), при
    ``DT_EMBED_VIA_DAEMON`` не 0 получает маршрутизатор :class:`core.embed_daemon.RoutedEmbedder`:
    вектора считает демон (``/internal/embed``), при его недоступности - локальная загрузка.
    Демон и ``DT_EMBED_VIA_DAEMON=0`` - прежний локальный синглтон (:func:`local_embedder`)."""
    from core import embed_daemon

    if not embed_daemon.should_route():
        return local_embedder()
    global _routed
    if _routed is None:
        with _embedder_lock:
            if _routed is None:
                _routed = embed_daemon.RoutedEmbedder(local_embedder)
    return _routed


def set_embedder(embedder: Embedder) -> None:
    """Override the singleton (e.g. a fake in tests, or a future backend)."""
    global _embedder
    _embedder = embedder


def embed_texts(texts: list[str], batch_size: int | None = None) -> np.ndarray:
    """Embed a batch of texts → (n, 1024) normalized float32 array."""
    return get_embedder().embed(texts, batch_size=batch_size)


def embed_query(text: str) -> np.ndarray:
    """Embed a single query → (1024,) normalized float32 vector.

    No query instruction prefix — BGE-M3 dense retrieval is symmetric.
    """
    return get_embedder().embed([text])[0]
