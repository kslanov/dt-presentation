"""EVAL-1 (WAVE1-MEASURE) — золотой набор запросов и мера качества выдачи.

Основание: аудит 2026-10 (C0, D1) — качество ретривала не мерил никто: смоук С-1 проверяет
round-trip чтения («поиск что-то нашёл, и это читается»), а не «нашёл ли то, что надо». Без
линейки любой спор «нужен ли реранкер / стеммер / другой чанкинг» решается на глаз, а фиксы
волны 2 принимались бы субъективно. Здесь — линейка: 30 запросов с ожиданием (канон
``vault/_system/eval/golden-queries.yaml``, К. правит как заметку), метрики по ним и история
прогонов (``.derived/eval/history.jsonl``).

**Метрики** (считаются по запросам с ``источник: проверено``; ``гипотеза`` прогоняется и виден
в таблице, но в метрику не входит, пока К. не подтвердит ожидание):

* ``recall5`` — доля ожидаемых ``note_id`` в топ-5 (среднее по запросам);
* ``mrr`` — обратный ранг первого ожидаемого;
* ``hub3`` — хаб сущности в топ-3 (запросы про клиента/алиас);
* ``envelope`` — конверт там, где положен (честная пустота, неподнятый слайс, предупреждение),
  и его ОТСУТСТВИЕ при здоровом ответе (ложная тревога — такая же поломка);
* ``tail`` — находимость слов из хвоста длинного треда (индикатор капа индекса);
* ``corpus`` — доля ожидаемых хитов слоя ``current``, найденных в режиме auto;
* ``facts`` / ``read`` — контракты ``get_facts`` и ``read_note`` (цифры с адресом, сводка
  «что показано» почтового треда).

**Красный** — только падение ``recall5`` или ``hub3`` больше чем на 0.1 к ПРОШЛОМУ прогону того
же набора. Абсолютного порога нет: сегодня часть запросов промахивается по известным причинам
волны 2, и первый прогон — базовая линия (``baseline: true``). Сменился набор → прошлый прогон
не сравнивается (``baseline_reset``): иначе правка файла К. выглядела бы регрессией движка.

Инвариант: ``core`` ⊥ mcp/cli. Инструменты приходят параметром (``tools`` — модуль
``mcp-server/server.py`` или фейк), без сети и LLM здесь; в журнал едут идентификаторы и числа,
не тексты запросов и ответов.
"""

from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import eval_history_path

__all__ = [
    "ALLOWED_TOOLS",
    "GOLDEN_REL",
    "MAX_AGE_DAYS",
    "METRICS",
    "REGRESSION_DELTA",
    "EvalReport",
    "GoldenError",
    "Query",
    "TypeStat",
    "RECORD_BRANCH",
    "RECORD_ENV",
    "VARIANTS",
    "ablation_table",
    "eval_config",
    "latency_ms",
    "append_history",
    "compare_with_previous",
    "format_table",
    "golden_path",
    "last_runs",
    "load_golden",
    "record_policy",
    "run_eval",
    "type_deltas",
    "type_table",
]

GOLDEN_REL = Path("_system") / "eval" / "golden-queries.yaml"

# История прогонов — ``core.config.eval_history_path()`` (TEST-SANDBOX-1: функция, читает
# ``DT_DERIVED_ROOT`` в момент вызова, а не константа модуля — подпроцесс не видел бы подмены).
# Смоук С-6/С-10 — про эту машину: его сессия идёт с боевым ``DT_DERIVED_ROOT``
# (``tests/_smoke_env.py``).

# Красный: падение recall@5 или hub@3 больше этого к прошлому прогону.
REGRESSION_DELTA = 0.1
# Прогон старше этого — «измерение умерло» (недельный смоук + запас).
MAX_AGE_DAYS = 8.0

# Метрики в порядке показа; ``gating`` — те, от которых краснеет смоук.
METRICS: tuple[str, ...] = ("recall5", "mrr", "hub3", "envelope", "tail", "corpus", "facts", "read")
GATING: tuple[str, ...] = ("recall5", "hub3")

# Только чтение. ``get_facts`` пишет в facts-стор (апсерт поднятого источника) и ``retrieve``
# оставляет событие в журнале метрик — поэтому прогонять набор надо в песочнице (conftest
# смоука / ``dt_eval`` уводят БД, логи и журнал метрик в tmp), а не в боевых сторах.
ALLOWED_TOOLS: frozenset[str] = frozenset(
    {"find_notes", "find_latest", "read_note", "get_facts", "retrieve"}
)

_TOP_N = 5
_HUB_TOP_N = 3

# Русские и английские имена верхнего уровня — один смысл (К. пишет по-русски, код — по-английски).
_KEY_ALIASES = {
    "id": "id", "тип": "type", "type": "type", "вызов": "call", "call": "call",
    "ожидание": "expect", "expect": "expect", "источник": "source", "source": "source",
    "заметка": "note", "note": "note", "группа": "group", "group": "group",
}
_SOURCES = {"проверено": True, "verified": True, "гипотеза": False, "hypothesis": False}
# EVAL-2 п.5: группа запроса. «Рабочая» — под неё тюнят ретривал (запросы аудита, фейлкейсы);
# «контрольная» — принятые из употребления, под них НЕ тюнят: рост recall только на рабочей
# при плоской контрольной = переобучение. Дефолт — рабочая (канон до EVAL-2 без поля).
GROUP_WORK = "work"
GROUP_CONTROL = "control"
GROUPS: tuple[str, ...] = (GROUP_WORK, GROUP_CONTROL)
_GROUP_VALUES = {
    "рабочая": GROUP_WORK, "work": GROUP_WORK, "working": GROUP_WORK,
    "контрольная": GROUP_CONTROL, "control": GROUP_CONTROL,
}
_EXPECT_KEYS = {
    "note_ids", "any_of", "path_contains", "current_ids", "hub", "warning", "skipped_slices",
    "notes_empty", "facts", "facts_empty", "messages", "min_overlap", "latest_path_contains",
    "latest_path_excludes", "latest_final_path_contains", "latest_final_path_excludes", "top",
}
_LATEST_KEYS = {"latest_path_contains", "latest_path_excludes",
                "latest_final_path_contains", "latest_final_path_excludes"}


class GoldenError(ValueError):
    """Набор не прочитан/не валиден: все найденные проблемы разом (К. правит файл руками)."""


@dataclass(frozen=True)
class Call:
    tool: str
    args: dict[str, Any]
    expect: dict[str, Any] | None = None  # своё ожидание вызова (заменяет общее запроса)


@dataclass(frozen=True)
class Query:
    id: str
    type: str
    calls: tuple[Call, ...]
    expect: dict[str, Any]
    verified: bool
    note: str = ""
    group: str = GROUP_WORK

    @property
    def label(self) -> str:
        """Короткая подпись вызова для таблицы (без сырых аргументов целиком)."""
        parts = []
        for call in self.calls:
            arg = call.args.get("query") or call.args.get("note_id") or call.args.get("domain") \
                or call.args.get("person") or call.args.get("path") or ""
            extra = ",".join(
                f"{k}={v}" for k, v in call.args.items()
                if k in ("corpus", "sort", "kind") and v
            )
            parts.append(f"{call.tool}({arg}{'; ' + extra if extra and arg else extra})")
        return " | ".join(parts)


# --------------------------------------------------------------------------- #
# Загрузка и валидация канона                                                    #
# --------------------------------------------------------------------------- #
def golden_path(vault: Path | None = None) -> Path:
    """Путь канона ``<vault>/_system/eval/golden-queries.yaml`` (vault по умолчанию — боевой)."""
    if vault is None:
        from core.config import default_vault_path

        vault = default_vault_path()
    return Path(vault) / GOLDEN_REL


def _norm_query(raw: Any, index: int) -> tuple[Query | None, list[str]]:
    problems: list[str] = []
    if not isinstance(raw, dict):
        return None, [f"запрос #{index}: не словарь"]
    item: dict[str, Any] = {}
    for key, value in raw.items():
        canon = _KEY_ALIASES.get(str(key).strip())
        if canon is None:
            problems.append(f"запрос #{index}: неизвестный ключ {key!r}")
        else:
            item[canon] = value
    qid = str(item.get("id") or "").strip()
    where = f"запрос {qid or '#' + str(index)}"
    if not qid:
        problems.append(f"{where}: нет id")
    qtype = str(item.get("type") or "").strip()
    if not qtype:
        problems.append(f"{where}: нет типа")
    source = str(item.get("source") or "").strip().lower()
    if source not in _SOURCES:
        problems.append(f"{where}: источник {source!r} — нужно проверено|гипотеза")

    group_raw = str(item.get("group") or "").strip().lower()
    if group_raw and group_raw not in _GROUP_VALUES:
        problems.append(f"{where}: группа {group_raw!r} — нужно рабочая|контрольная")

    calls_raw = item.get("call")
    if isinstance(calls_raw, dict):
        calls_raw = [calls_raw]
    calls: list[Call] = []
    if not isinstance(calls_raw, list) or not calls_raw:
        problems.append(f"{where}: нет вызова")
    else:
        for call in calls_raw:
            tool = str(call.get("tool") or "") if isinstance(call, dict) else ""
            args = call.get("args") if isinstance(call, dict) else None
            if tool not in ALLOWED_TOOLS:
                problems.append(
                    f"{where}: инструмент {tool!r} не разрешён (только чтение: "
                    f"{', '.join(sorted(ALLOWED_TOOLS))})"
                )
                continue
            if args is not None and not isinstance(args, dict):
                problems.append(f"{where}: args вызова {tool} — не словарь")
                continue
            own = call.get("ожидание", call.get("expect")) if isinstance(call, dict) else None
            if own is not None and (not isinstance(own, dict) or not own):
                problems.append(f"{where}: ожидание вызова {tool} — не словарь/пусто")
                continue
            unknown_own = sorted(set(own or {}) - _EXPECT_KEYS)
            if unknown_own:
                problems.append(f"{where}: неизвестные ключи ожидания вызова {unknown_own}")
            calls.append(Call(tool, dict(args or {}), dict(own) if own else None))
    expect = item.get("expect")
    if expect is None:
        expect = {}
    if not isinstance(expect, dict):
        problems.append(f"{where}: ожидание — не словарь")
        expect = {}
    if not expect and not all(c.expect for c in calls):
        problems.append(f"{where}: пустое ожидание")
    unknown = sorted(set(expect) - _EXPECT_KEYS)
    if unknown:
        problems.append(f"{where}: неизвестные ключи ожидания {unknown}")
    if problems:
        return None, problems
    return (
        Query(
            id=qid, type=qtype, calls=tuple(calls), expect=dict(expect),
            verified=_SOURCES[source], note=str(item.get("note") or ""),
            group=_GROUP_VALUES.get(group_raw, GROUP_WORK),
        ),
        [],
    )


def load_golden(path: Path | None = None) -> list[Query]:
    """Прочитать канон; любая проблема → :class:`GoldenError` со ВСЕМИ замечаниями сразу."""
    import yaml  # type: ignore[import-untyped]

    target = Path(path) if path is not None else golden_path()
    try:
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    except OSError as exc:
        raise GoldenError(f"золотой набор не прочитан: {target}: {exc}") from exc
    except yaml.YAMLError as exc:
        raise GoldenError(f"золотой набор: невалидный YAML ({target}): {exc}") from exc
    items = data.get("queries") if isinstance(data, dict) else data
    if not isinstance(items, list) or not items:
        raise GoldenError(f"золотой набор пуст или без списка queries: {target}")
    queries: list[Query] = []
    problems: list[str] = []
    for i, raw in enumerate(items, start=1):
        query, errs = _norm_query(raw, i)
        problems.extend(errs)
        if query is not None:
            queries.append(query)
    # id берём из СЫРЫХ записей: запись с другой ошибкой в `queries` не попала бы, и дубль
    # спрятался бы за первой же правкой (К. чинил бы файл по одному замечанию за прогон).
    ids = [str(r.get("id") or "").strip() for r in items if isinstance(r, dict)]
    ids = [i for i in ids if i]
    problems.extend(f"дубль id {i}" for i in sorted({i for i in ids if ids.count(i) > 1}))
    if problems:
        raise GoldenError("золотой набор: " + "; ".join(problems))
    return queries


def golden_hash(
    queries: list[Query], group: str | None = None, qtype: str | None = None
) -> str:
    """Отпечаток ЗАЧТЁННОГО набора (проверенные запросы и их ожидания): смена → новая линия.

    ``group`` — отпечаток одной группы (правка контрольной не сбрасывает линию рабочей).
    В общем отпечатке группа контрольных запросов учитывается полем ``group``; у рабочих
    поля нет — отпечаток набора без контрольной группы совпадает с доEVAL-2 (история
    прежних прогонов остаётся сопоставимой). ``qtype`` — отпечаток одного типа запросов
    (EVAL-4: Δ по типу считается только при том же составе типа).
    """
    payload = []
    for q in sorted(queries, key=lambda q: q.id):
        if not q.verified or (group is not None and q.group != group):
            continue
        if qtype is not None and q.type != qtype:
            continue
        item: dict[str, Any] = {
            "id": q.id, "calls": [[c.tool, c.args, c.expect] for c in q.calls], "expect": q.expect,
        }
        if group is None and q.group != GROUP_WORK:
            item["group"] = q.group
        payload.append(item)
    blob = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:12]


# --------------------------------------------------------------------------- #
# Нормализация ответов и проверки                                                #
# --------------------------------------------------------------------------- #
@dataclass
class Observed:
    """Ответ инструмента в виде, удобном проверкам."""

    ids: list[str] = field(default_factory=list)       # note_id по порядку выдачи
    paths: list[str] = field(default_factory=list)     # путь заметки (find_notes) / файла (latest)
    final_paths: list[str] = field(default_factory=list)  # find_latest: latest_final ("" - нет)
    raw: Any = None
    error: str = ""


def _observe(tool: str, out: Any) -> Observed:
    obs = Observed(raw=out)
    if tool == "find_notes" and isinstance(out, dict):
        notes = [n for n in out.get("notes") or [] if isinstance(n, dict)]
        obs.ids = [str(n.get("note_id") or "") for n in notes]
        obs.paths = [str(n.get("path") or "") for n in notes]
    elif tool == "find_latest" and isinstance(out, dict):
        fams = [f for f in out.get("families") or [] if isinstance(f, dict)]
        obs.ids = [str(f.get("note_id") or "") for f in fams]
        obs.paths = [str((f.get("latest") or {}).get("path") or "") for f in fams]
        obs.final_paths = [str((f.get("latest_final") or {}).get("path") or "") for f in fams]
    elif tool == "retrieve" and isinstance(out, dict):
        for hits in (out.get("slices") or {}).values():
            for hit in hits or []:
                if isinstance(hit, dict) and hit.get("note_id"):
                    obs.ids.append(str(hit["note_id"]))
    return obs


def _codes(payload: Any) -> list[str]:
    """Коды деградации ответа: конверты, ``refused``, ``ok:false`` — без человеческих подсказок.

    Строка в ``warning`` (разброс дат SRC-FRESH-1) — подсказка, а не отказ: конвертом не
    считается и «здоровый» ответ не портит.
    """
    from core.contract import warnings_of

    if not isinstance(payload, dict):
        return []
    codes = [str(e.get("code")) for e in warnings_of(payload) if e.get("code")]
    if payload.get("refused"):
        codes.append(str(payload.get("code") or payload["refused"]))
    if payload.get("ok") is False or payload.get("found") is False:
        codes.append(str(payload.get("code") or "other"))
    return codes


def _has_hint(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    text_hint = isinstance(payload.get("warning"), str) and bool(payload["warning"])
    return text_hint or bool(_codes(payload))


def _rank(ids: list[str], wanted: set[str], limit: int | None = None) -> int | None:
    for i, nid in enumerate(ids[:limit], start=1):
        if nid in wanted:
            return i
    return None


@dataclass
class Check:
    """Одна проверка ожидания: метрика, оценка 0..1, что увидели."""

    metric: str
    score: float
    detail: str
    rank: int | None = None   # RETR-RERANK-1: ранг цели (проверки ``mrr``), для таблицы абляции


def _checks_for_call(q: Query, call_i: int, obs: Observed) -> list[Check]:
    """Проверки ожидания запроса на ОДНОМ ответе (многовызовные запросы — по каждому)."""
    exp = q.calls[call_i].expect or q.expect
    top = int(exp.get("top") or _TOP_N)
    out: list[Check] = []
    tool = q.calls[call_i].tool
    payload = obs.raw

    ids = obs.ids
    ranked_metric = "tail" if q.type == "хвост" else "recall5"

    wanted_all = [str(x) for x in exp.get("note_ids") or []]
    if wanted_all:
        found = [w for w in wanted_all if w in ids[:top]]
        out.append(Check(ranked_metric, len(found) / len(wanted_all),
                         f"{len(found)}/{len(wanted_all)} в топ-{top}"))
        if ranked_metric == "recall5":
            first = _rank(ids, set(wanted_all))
            out.append(Check("mrr", 1.0 / first if first else 0.0,
                             f"ранг {first}" if first else "нет в выдаче", rank=first))
    any_of = [str(x) for x in exp.get("any_of") or []]
    if any_of:
        first = _rank(ids, set(any_of))
        hit = first is not None and first <= top
        out.append(Check(ranked_metric, 1.0 if hit else 0.0,
                         f"любой из {len(any_of)}: {'да, ранг ' + str(first) if hit else 'нет'}"))
        if ranked_metric == "recall5":
            out.append(Check("mrr", 1.0 / first if first else 0.0,
                             f"ранг {first}" if first else "нет в выдаче", rank=first))
    needles = [str(x).lower() for x in exp.get("path_contains") or []]
    if needles:
        first = next(
            (i for i, p in enumerate(obs.paths, start=1) if any(n in p.lower() for n in needles)),
            None,
        )
        hit = first is not None and first <= top
        out.append(Check(ranked_metric, 1.0 if hit else 0.0,
                         f"путь с {needles[0]!r}: {'ранг ' + str(first) if hit else 'нет в топе'}"))
        if ranked_metric == "recall5":
            out.append(Check("mrr", 1.0 / first if first else 0.0,
                             f"ранг {first}" if first else "нет в выдаче", rank=first))
    current = [str(x) for x in exp.get("current_ids") or []]
    if current:
        found = [w for w in current if w in ids[:top]]
        out.append(Check("corpus", len(found) / len(current),
                         f"{len(found)}/{len(current)} слоя current в топ-{top}"))
    hub = exp.get("hub")
    if hub:
        rank = _rank(ids, {str(hub)})
        ok = rank is not None and rank <= _HUB_TOP_N
        out.append(Check("hub3", 1.0 if ok else 0.0,
                         f"хаб {hub}: " + (f"ранг {rank}" if rank else "нет в выдаче")))

    if tool in ("find_latest",) and (_LATEST_KEYS & set(exp)):
        out.append(_latest_check(exp, obs))

    # ----- конверт -----
    want_warn = exp.get("warning")
    codes = _codes(payload)
    if want_warn is not None:
        if want_warn == "none":
            out.append(Check("envelope", 1.0 if not codes else 0.0,
                             "без конверта" if not codes else f"лишний конверт {codes}"))
        elif want_warn == "any":
            ok = _has_hint(payload)
            out.append(Check("envelope", 1.0 if ok else 0.0,
                             "предупреждение есть" if ok else "предупреждения нет"))
        else:
            ok = str(want_warn) in codes
            out.append(Check("envelope", 1.0 if ok else 0.0,
                             f"конверт {want_warn}: " + ("есть" if ok else f"нет (есть {codes})")))
    elif wanted_all or any_of or needles or hub:
        out.append(Check("envelope", 1.0 if not codes else 0.0,
                         "здоровый ответ без конверта" if not codes else f"ложная тревога {codes}"))
    if exp.get("skipped_slices"):
        skipped = isinstance(payload, dict) and bool(payload.get("skipped_slices"))
        out.append(Check("envelope", 1.0 if skipped else 0.0,
                         "skipped_slices объявлены" if skipped else "слайсы пропущены молча"))
    if exp.get("notes_empty"):
        empty = not ids and not obs.error
        out.append(Check("envelope", 1.0 if empty else 0.0,
                         "честная пустота" if empty else f"{len(ids)} хитов вместо пустоты"))

    # ----- факты и чтение -----
    facts_exp = exp.get("facts")
    if facts_exp is not None or exp.get("facts_empty"):
        out.append(_facts_check(exp, payload))
    messages_exp = exp.get("messages")
    if messages_exp:
        out.append(_messages_check(messages_exp, payload))
    return out


def _latest_check(exp: dict[str, Any], obs: Observed) -> Check:
    """Первое семейство find_latest: ``latest`` (новейший файл) и ``latest_final`` (новейший
    не-черновик). ``latest_final_path_excludes`` при ``latest_final = null`` проходит (черновик
    не выдан за действующий - ровно то, что проверяется); ``latest_final_path_contains`` при
    ``null`` не проходит (действующей версии нет, а ждали файл)."""
    path = (obs.paths[0] if obs.paths else "").lower()
    final = (obs.final_paths[0] if obs.final_paths else "").lower()
    if not obs.paths:
        return Check("recall5", 0.0, "семейств нет")

    def keys(name: str) -> list[str]:
        return [str(x).lower() for x in exp.get(name) or []]

    want, bad = keys("latest_path_contains"), keys("latest_path_excludes")
    want_final, bad_final = keys("latest_final_path_contains"), keys("latest_final_path_excludes")
    ok = (not want or any(w in path for w in want)) and not any(b in path for b in bad)
    reason = "latest — не тот файл"
    if ok and (want_final or bad_final):
        ok = (not want_final or (bool(final) and any(w in final for w in want_final))) and not any(
            b in final for b in bad_final
        )
        reason = ("latest_final — не тот файл" if want_final or not final
                  else "черновик выдан за действующий")
    return Check("recall5", 1.0 if ok else 0.0,
                 "действующая версия указана верно" if ok else reason)


def _facts_check(exp: dict[str, Any], payload: Any) -> Check:
    facts = payload if isinstance(payload, list) else (
        payload.get("facts") if isinstance(payload, dict) else []
    )
    facts = [f for f in facts or [] if isinstance(f, dict)]
    spec = exp.get("facts") or {}
    if exp.get("facts_empty"):
        ok = not facts and bool(_codes(payload) or _has_hint(payload))
        want = exp.get("warning")
        if want and want not in ("none", "any"):
            ok = ok and str(want) in _codes(payload)
        return Check("facts", 1.0 if ok else 0.0,
                     "пусто + конверт" if ok else f"{len(facts)} фактов / конверта нет")
    problems = []
    if len(facts) < int(spec.get("min") or 1):
        problems.append(f"фактов {len(facts)}")
    locators = {str(f.get("locator") or "") for f in facts}
    for suffix in spec.get("locators_include") or []:
        if not any(loc.endswith(f"!{suffix}") or loc == suffix for loc in locators):
            problems.append(f"нет адреса {suffix}")
    if spec.get("currency") and not any(f.get("currency") == spec["currency"] for f in facts):
        problems.append(f"нет валюты {spec['currency']}")
    # FACT-2 п.8: единица/масштаб проверяются НА ЯЧЕЙКАХ из ``locators_include`` (не «где-нибудь»),
    # ``locators_exclude`` - ячейки, которых в выдаче быть не должно (A6-«этап» среди money).
    def _at(suffix: str) -> list[dict[str, Any]]:
        return [f for f in facts
                if str(f.get("locator") or "").endswith(f"!{suffix}") or f.get("locator") == suffix]

    targets = [f for suffix in spec.get("locators_include") or [] for f in _at(suffix)]
    if spec.get("unit") and any(f.get("unit") != spec["unit"] for f in targets):
        problems.append(f"единица не {spec['unit']}")
    if spec.get("scale") is not None and any(
        f.get("scale") is None or float(f["scale"]) != float(spec["scale"]) for f in targets
    ):
        problems.append(f"масштаб не {spec['scale']}")
    for suffix in spec.get("locators_exclude") or []:
        if _at(suffix):
            problems.append(f"лишний адрес {suffix}")
    problems.extend(_facts_time_problems(spec, facts))
    return Check("facts", 0.0 if problems else 1.0,
                 f"{len(facts)} фактов" if not problems else "; ".join(problems))


def _facts_time_problems(spec: dict[str, Any], facts: list[dict[str, Any]]) -> list[str]:
    """FACTS-BITEMPORAL-1: ожидания блока ``facts`` про время.

    ``as_of: ДАТА`` - КАЖДЫЙ факт ответа верен на дату (``valid_from`` ≤ даты < ``valid_to``; пустая
    граница - без ограничения): ответ на «цена на дату X» не подмешивает другие версии. ``current:
    true`` - ни один факт не вытеснен (``superseded_by``), не из черновика и не истек (``valid_to``
    пуст или позже сегодня): ответ на «актуальная цена». ``values_include`` - значения
    (``value_raw``), которые обязаны быть в выдаче (иначе проверка времени вырождается в «хоть
    что-то»).
    """
    problems: list[str] = []
    as_of = str(spec["as_of"])[:10] if spec.get("as_of") else None
    if as_of:
        bad = [f for f in facts
               if (f.get("valid_from") and str(f["valid_from"]) > as_of)
               or (f.get("valid_to") and str(f["valid_to"]) <= as_of)]
        if bad:
            problems.append(f"{len(bad)} фактов не верны на {as_of}")
    if spec.get("current"):
        from datetime import UTC, datetime

        today = datetime.now(UTC).date().isoformat()
        stale = [f for f in facts
                 if f.get("superseded_by") or f.get("provisional")
                 or (f.get("valid_to") and str(f["valid_to"]) <= today)]
        if stale:
            problems.append(f"{len(stale)} фактов не актуальны (вытеснены/черновик/истекли)")
    have = {str(f.get("value_raw")) for f in facts}
    for value in spec.get("values_include") or []:
        if str(value) not in have:
            problems.append(f"нет значения {value}")
    return problems


def _messages_check(spec: dict[str, Any], payload: Any) -> Check:
    msgs = payload.get("messages") if isinstance(payload, dict) else None
    if not isinstance(msgs, dict):
        return Check("read", 0.0, "нет сводки messages")
    last = msgs.get("last_inbound")
    problems = []
    if spec.get("last_inbound_shown_full") and last not in (msgs.get("shown_full") or []):
        problems.append("последнее входящее не в shown_full")
    if spec.get("no_shown_partial_for_last") and last in (msgs.get("shown_partial") or []):
        problems.append("последнее входящее показано частично")
    return Check("read", 0.0 if problems else 1.0,
                 "последнее входящее прочитано целиком" if not problems else "; ".join(problems))


# --------------------------------------------------------------------------- #
# Прогон                                                                         #
# --------------------------------------------------------------------------- #
@dataclass
class QueryResult:
    id: str
    type: str
    label: str
    verified: bool
    checks: list[Check]
    top_ids: list[str]
    ms: int
    errors: list[str] = field(default_factory=list)
    expect_text: str = ""
    extra: str = ""
    # EVAL-2 п.1: ожидаемые id, которых больше нет в vault (заметку перегенерировали/удалили).
    # Непустой → запрос НЕ прогонялся и в метрики не входит ни попаданием, ни промахом.
    stale: list[str] = field(default_factory=list)
    group: str = GROUP_WORK  # EVAL-2 п.5: рабочая | контрольная

    @property
    def score(self) -> float:
        """Доля пройденных проверок (для колонки ✓/✗ таблицы)."""
        return sum(c.score for c in self.checks) / len(self.checks) if self.checks else 0.0

    @property
    def passed(self) -> bool:
        return (
            not self.stale and bool(self.checks) and not self.errors
            and all(c.score >= 1.0 for c in self.checks)
        )


@dataclass
class GroupStat:
    """Метрики одной группы запросов (рабочая | контрольная)."""

    metrics: dict[str, float | None]
    counts: dict[str, int]
    n: int          # зачётных запросов группы (проверено, не stale)
    hash: str       # отпечаток зачётного набора ГРУППЫ: правка другой группы линию не сбрасывает


@dataclass
class TypeStat:
    """EVAL-4 п.1: метрики одного типа запросов (диагностика, не гейт)."""

    metrics: dict[str, float | None]
    counts: dict[str, int]
    n: int          # зачётных запросов типа (проверено, не stale)
    hash: str       # отпечаток зачётного состава ТИПА: сменился → Δ к прошлому «нет данных»


@dataclass
class EvalReport:
    ts: str
    results: list[QueryResult]
    metrics: dict[str, float | None]
    counts: dict[str, int]
    golden_hash: str
    duration_s: float
    errors: int = 0
    previous: dict[str, Any] | None = None
    baseline: bool = False
    baseline_reset: bool = False
    red: list[str] = field(default_factory=list)
    deltas: dict[str, float | None] = field(default_factory=dict)
    # EVAL-2 п.5: те же метрики по группам (рабочая | контрольная) и сравнение с прошлым ПО
    # КАЖДОЙ группе отдельно (красный — тоже: ``control:recall5`` против ``recall5``).
    groups: dict[str, GroupStat] = field(default_factory=dict)
    group_deltas: dict[str, dict[str, float | None]] = field(default_factory=dict)
    baseline_groups: list[str] = field(default_factory=list)  # группы без сопоставимого прошлого
    # EVAL-4 п.1: те же метрики по типу запроса и Δ к прошлому прогону (только при том же
    # составе типа). Красное правило типов не знает: это диагностика.
    by_type: dict[str, TypeStat] = field(default_factory=dict)
    type_deltas: dict[str, dict[str, float | None]] = field(default_factory=dict)
    # RETR-RERANK-1: с какой конфигурацией выдачи шёл прогон (``{rerank, semantic_always}``) —
    # без этого точки истории с реранкером и без него выглядели бы сравнимыми.
    config: dict[str, bool] = field(default_factory=dict)

    @property
    def hypotheses(self) -> int:
        return sum(1 for r in self.results if not r.verified and not r.stale)

    @property
    def verified_n(self) -> int:
        return sum(1 for r in self.results if r.verified and not r.stale)

    @property
    def all_failed(self) -> bool:
        return bool(self.results) and all(r.errors for r in self.results)

    @property
    def stale_ids(self) -> list[str]:
        """id запросов со stale-ожиданием (долг правки канона, не регрессия)."""
        return [r.id for r in self.results if r.stale]


def _expect_text(q: Query) -> str:
    e = dict(q.expect)
    for call in q.calls:  # вызовы со своим ожиданием: показываем объединённо
        e.update(call.expect or {})
    parts: list[str] = []
    if e.get("note_ids"):
        parts.append("id " + ",".join(str(x).replace("legacy-", "l-")[:14] for x in e["note_ids"]))
    if e.get("any_of"):
        parts.append("любой " + ",".join(str(x)[:14] for x in e["any_of"]))
    if e.get("path_contains"):
        parts.append("путь ~" + str(e["path_contains"][0])[:18])
    if e.get("hub"):
        parts.append(f"хаб@3 {e['hub']}")
    if e.get("min_overlap"):
        parts.append(f"пересеч.≥{e['min_overlap']}")
    for key in ("warning", "skipped_slices", "notes_empty", "facts", "facts_empty",
                "messages", "latest_path_contains", "latest_final_path_contains",
                "latest_final_path_excludes"):
        if e.get(key) not in (None, False, [], {}):
            parts.append(key if e[key] is True else f"{key}")
    return "; ".join(parts) or "—"


# --------------------------------------------------------------------------- #
# Stale-гард ожиданий (EVAL-2 п.1)                                               #
# --------------------------------------------------------------------------- #
_ID_LIST_KEYS = ("note_ids", "any_of", "current_ids")
_ID_ARG_CALLS = {"get_facts": ("note_id",), "read_note": ("note_id", "path")}


def note_exists(ref: str) -> bool:
    """Резолвится ли ссылка на заметку в боевом vault (единая точка :func:`resolve_note_path`).

    Модульная функция, а не вызов по месту: тесты подменяют её (conftest уводит прогон от
    живого vault), а ``run_eval(resolve=…)`` принимает свою. Сбой самого резолва — не повод
    объявлять запрос протухшим (проблема окружения ≠ проблема канона): считаем, что есть.
    """
    from core.vault import resolve_note_path

    try:
        return resolve_note_path(ref) is not None
    except Exception:  # noqa: BLE001 — сбой резолва не красит набор stale-ом
        return True


def expected_refs(q: Query) -> list[str]:
    """Все id заметок, на которые ссылается ожидание запроса (и ``args`` читающих вызовов).

    ``note_ids`` / ``any_of`` / ``current_ids`` / ``hub`` — из общего ожидания и из «своих»
    ожиданий вызовов; ``note_id``/``path`` — у ``get_facts``/``read_note`` (там id заметки —
    часть вызова, и промах резолва делает ЛЮБОЙ ответ ложным). Порядок стабилен, дубли убраны.
    """
    seen: dict[str, None] = {}

    def _add(value: Any) -> None:
        ref = str(value or "").strip()
        if ref:
            seen.setdefault(ref)

    for exp in [q.expect, *(c.expect or {} for c in q.calls)]:
        for key in _ID_LIST_KEYS:
            for ref in exp.get(key) or []:
                _add(ref)
        _add(exp.get("hub"))
    for call in q.calls:
        for key in _ID_ARG_CALLS.get(call.tool, ()):
            _add(call.args.get(key))
    return list(seen)


def stale_refs(q: Query, exists: Callable[[str], bool] | None = None) -> list[str]:
    """Ожидаемые id, которые не резолвятся (пусто — ожидания живы)."""
    check = exists or note_exists
    return [ref for ref in expected_refs(q) if not check(ref)]


def _run_query(q: Query, tools: Any) -> QueryResult:
    started = time.perf_counter()
    observed: list[Observed] = []
    errors: list[str] = []
    for call in q.calls:
        obs = Observed()
        try:
            out = getattr(tools, call.tool)(**call.args)
            obs = _observe(call.tool, out)
        except Exception as exc:  # noqa: BLE001 — упавший вызов = промах запроса, не прогона
            obs.error = f"{type(exc).__name__}: {str(exc)[:120]}"
            errors.append(obs.error)
        observed.append(obs)

    checks: list[Check] = []
    for i, obs in enumerate(observed):
        if obs.error:
            continue
        checks.extend(_checks_for_call(q, i, obs))
    extra = ""
    overlap = q.expect.get("min_overlap")  # общее ожидание запроса (не вызова)
    if overlap is not None and len(observed) >= 2 and not errors:
        a, b = (set(o.ids[:_TOP_N]) for o in observed[:2])
        ok = len(a & b) >= int(overlap)
        extra = f"пересечение топ-5: {len(a & b)}"
        checks.append(Check("recall5", 1.0 if ok else 0.0, extra))
    elif not checks and not errors:
        errors.append("ожидание не проверилось: нет совпавших ключей для вызова")
    top_ids = observed[0].ids[:_TOP_N] if observed else []
    return QueryResult(
        id=q.id, type=q.type, label=q.label, verified=q.verified, checks=checks,
        top_ids=top_ids, ms=int((time.perf_counter() - started) * 1000), errors=errors,
        expect_text=_expect_text(q), extra=extra,
    )


def _aggregate(
    results: list[QueryResult], group: str | None = None, qtype: str | None = None
) -> tuple[dict[str, float | None], dict[str, int]]:
    """Метрики по зачётным запросам: на запрос — среднее его проверок, по набору — среднее.

    ``group`` — только запросы этой группы, ``qtype`` — только этого типа (``None`` — все).
    Метрика без данных — ``None``
    («нет данных»), а не 0: пустая контрольная группа не притворяется нулевым качеством.
    """
    sums: dict[str, list[float]] = {m: [] for m in METRICS}
    for r in results:
        if not r.verified or r.stale or (group is not None and r.group != group):
            continue
        if qtype is not None and r.type != qtype:
            continue
        per_metric: dict[str, list[float]] = {}
        for check in r.checks:
            per_metric.setdefault(check.metric, []).append(check.score)
        for metric, scores in per_metric.items():
            sums[metric].append(sum(scores) / len(scores))
    metrics = {m: (round(sum(v) / len(v), 4) if v else None) for m, v in sums.items()}
    counts = {m: len(v) for m, v in sums.items()}
    return metrics, counts


def _group_stats(results: list[QueryResult], queries: list[Query]) -> dict[str, GroupStat]:
    stats: dict[str, GroupStat] = {}
    for group in GROUPS:
        metrics, counts = _aggregate(results, group)
        n = sum(1 for r in results if r.verified and not r.stale and r.group == group)
        stats[group] = GroupStat(metrics, counts, n, golden_hash(queries, group))
    return stats


def _type_stats(results: list[QueryResult], queries: list[Query]) -> dict[str, TypeStat]:
    """Метрики по каждому типу, встреченному в наборе (порядок — первого появления в каноне)."""
    stats: dict[str, TypeStat] = {}
    for qtype in dict.fromkeys(q.type for q in queries):
        metrics, counts = _aggregate(results, qtype=qtype)
        n = sum(1 for r in results if r.verified and not r.stale and r.type == qtype)
        stats[qtype] = TypeStat(metrics, counts, n, golden_hash(queries, qtype=qtype))
    return stats


def run_eval(
    queries: list[Query],
    tools: Any,
    *,
    previous: dict[str, Any] | None = None,
    now: datetime | None = None,
    progress: Callable[[str], None] | None = None,
    resolve: Callable[[str], bool] | None = None,
) -> EvalReport:
    """Прогнать набор на ``tools`` и сравнить с ``previous`` (последняя запись истории).

    Перед запросом его ожидаемые id резолвятся (``resolve``, по умолчанию
    :func:`note_exists`): не резолвится → запрос ``stale`` (не прогоняется, в метрики не входит —
    ни попаданием, ни промахом; id у legacy-заметок — хэш пути, перегенерация делает промах
    ложным и вечным).

    Упавший вызов (исключение инструмента) = промах этого запроса: запрос с ошибкой НЕ молчит
    «нулём метрики», а помечен в таблице и считается в ``errors``. Метрики по зачётным запросам
    считаются из того, что проверилось; если упали ВСЕ запросы, прогон недействителен
    (:attr:`EvalReport.all_failed`) — инфраструктура, а не качество.
    """
    started = time.perf_counter()
    results: list[QueryResult] = []
    for q in queries:
        dead = stale_refs(q, resolve)
        if dead:
            result = QueryResult(
                id=q.id, type=q.type, label=q.label, verified=q.verified, checks=[], top_ids=[],
                ms=0, expect_text=_expect_text(q), stale=dead, group=q.group,
            )
            results.append(result)
            if progress:
                progress(f"{q.id}: stale ({', '.join(d[:18] for d in dead[:3])})")
            continue
        result = _run_query(q, tools)
        result.group = q.group
        # запрос с ожиданием, но упавшим вызовом — это промах для метрик (иначе падение
        # поиска выглядело бы ростом качества: проверок нет — среднее считается без него)
        if result.errors and result.checks == [] and q.verified:
            result.checks = [Check(_primary_metric(q), 0.0, "вызов упал: " + result.errors[0])]
        results.append(result)
        if progress:
            progress(f"{q.id}: {'ok' if result.passed else 'мимо'} ({result.ms} мс)")
    metrics, counts = _aggregate(results)
    report = EvalReport(
        ts=(now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        results=results, metrics=metrics, counts=counts, golden_hash=golden_hash(queries),
        duration_s=round(time.perf_counter() - started, 1),
        errors=sum(1 for r in results if r.errors),
        groups=_group_stats(results, queries),
        by_type=_type_stats(results, queries),
        config=eval_config(),
    )
    compare_with_previous(report, previous)
    return report


def eval_config() -> dict[str, bool]:
    """Конфигурация выдачи на момент прогона: реранкер и «семантика всегда» (env или дефолт)."""
    from core.retrieval import rerank as rr

    return {"rerank": rr.rerank_enabled(), "semantic_always": rr.semantic_always_enabled()}


def latency_ms(report: EvalReport) -> dict[str, int | None]:
    """p50/p95 длительности запроса набора, мс (по прогнанным, не stale); пусто → ``None``."""
    values = sorted(r.ms for r in report.results if not r.stale and r.ms > 0)
    if not values:
        return {"p50": None, "p95": None}

    def pct(q: float) -> int:
        return values[min(len(values) - 1, max(0, round(q * (len(values) - 1))))]

    return {"p50": pct(0.5), "p95": pct(0.95)}


def _primary_metric(q: Query) -> str:
    """Метрика, в которую засчитывается промах упавшего вызова (по ожиданию запроса)."""
    e = dict(q.expect)
    for call in q.calls:
        e.update(call.expect or {})
    if q.type == "хвост":
        return "tail"
    if e.get("facts") is not None or e.get("facts_empty"):
        return "facts"
    if e.get("messages"):
        return "read"
    if e.get("notes_empty") or e.get("skipped_slices") or (
        e.get("warning") and not (e.get("note_ids") or e.get("any_of") or e.get("path_contains"))
    ):
        return "envelope"
    return "recall5"


def _red_label(group: str, metric: str) -> str:
    return metric if group == GROUP_WORK else f"{group}:{metric}"


def compare_with_previous(report: EvalReport, previous: dict[str, Any] | None) -> EvalReport:
    """Базовая линия / регрессия: красный только при падении recall@5 или hub@3 больше 0.1.

    Сравнение — **по каждой группе отдельно** (рабочая, контрольная): правка/рост одной группы
    не сбрасывает линию другой, а красный ставится группе, которая упала (``recall5`` — рабочая,
    ``control:recall5`` — контрольная). Первый прогон (``previous is None``) — базовая линия,
    красным не бывает. Другой отпечаток набора группы — её новая линия (``baseline_groups``);
    общий отпечаток сменился — ``baseline_reset`` (правка файла К. не регрессия движка).
    История до EVAL-2 (без ``groups``) читается как «весь набор был рабочим».
    """
    report.previous = previous
    if previous is None:
        report.baseline = True
        report.baseline_groups = [g for g in GROUPS if g in report.groups and report.groups[g].n]
        return report
    if previous.get("golden_hash") != report.golden_hash:
        report.baseline_reset = True
    else:
        prev_metrics = previous.get("metrics") or {}
        for metric in METRICS:
            cur, old = report.metrics.get(metric), prev_metrics.get(metric)
            report.deltas[metric] = (
                round(cur - old, 4) if cur is not None and old is not None else None
            )
    prev_groups = previous.get("groups") or {}
    for group in GROUPS:
        stat = report.groups.get(group)
        if stat is None or stat.n == 0:
            continue  # пустая группа: сравнивать нечего — «нет данных», а не регрессия
        prev = prev_groups.get(group)
        if prev is None and group == GROUP_WORK and "groups" not in previous:
            prev = {"hash": previous.get("golden_hash"), "metrics": previous.get("metrics")}
        if not prev or prev.get("hash") != stat.hash or not prev.get("metrics"):
            report.baseline_groups.append(group)
            continue
        deltas: dict[str, float | None] = {}
        for metric in METRICS:
            cur, old = stat.metrics.get(metric), prev["metrics"].get(metric)
            deltas[metric] = round(cur - old, 4) if cur is not None and old is not None else None
        report.group_deltas[group] = deltas
        for metric in GATING:
            delta = deltas.get(metric)
            if delta is not None and -delta > REGRESSION_DELTA + 1e-9:
                report.red.append(_red_label(group, metric))
    report.type_deltas = type_deltas(report.by_type, previous.get("by_type"))
    return report


def type_deltas(
    by_type: dict[str, TypeStat], prev_by_type: Any
) -> dict[str, dict[str, float | None]]:
    """Δ метрик по типу к прошлому прогону: только если состав типа не менялся (тот же отпечаток).

    Тип без прошлого (история до EVAL-4), с другим составом или без данных сегодня в словарь не
    попадает — «нет данных», а не нулевая динамика. В красное правило не входит.
    """
    out: dict[str, dict[str, float | None]] = {}
    if not isinstance(prev_by_type, dict):
        return out
    for qtype, stat in by_type.items():
        prev = prev_by_type.get(qtype)
        if stat.n == 0 or not isinstance(prev, dict) or prev.get("hash") != stat.hash:
            continue
        pm = prev.get("metrics") or {}
        out[qtype] = {
            m: (round(stat.metrics[m] - pm[m], 4)
                if stat.metrics.get(m) is not None and pm.get(m) is not None else None)
            for m in METRICS
        }
    return out


# --------------------------------------------------------------------------- #
# История                                                                        #
# --------------------------------------------------------------------------- #
def history_record(report: EvalReport) -> dict[str, Any]:
    """Строка истории: идентификаторы и числа, без текстов запросов и ответов.

    VENDOR-HYGIENE-1 п.3: ``host`` и ``mode`` (``in_process`` | ``mcp:<хост>``) — качество
    движка одинаково, а латентность и конверты по хостам разные; старые строки без них читаются.
    """
    from core.host import current_host, run_mode

    return {
        "ts": report.ts,
        "host": current_host()["name"],
        "mode": run_mode(),
        "baseline": report.baseline or report.baseline_reset,
        "baseline_reset": report.baseline_reset,
        "golden_hash": report.golden_hash,
        "queries": len(report.results),
        "verified": report.verified_n,
        "hypotheses": report.hypotheses,
        "errors": report.errors,
        "stale": report.stale_ids,
        "metrics": report.metrics,
        "counts": report.counts,
        "red": report.red,
        "groups": {
            g: {"metrics": st.metrics, "counts": st.counts, "verified": st.n, "hash": st.hash}
            for g, st in report.groups.items()
        },
        "by_type": {
            t: {"metrics": st.metrics, "counts": st.counts, "verified": st.n, "hash": st.hash}
            for t, st in report.by_type.items()
        },
        "duration_s": report.duration_s,
        "rerank": report.config.get("rerank"),
        "semantic_always": report.config.get("semantic_always"),
        "latency_ms": latency_ms(report),
        "per_query": [
            {"id": r.id, "ok": r.passed, "verified": r.verified, "ms": r.ms,
             "top": r.top_ids[:3], "group": r.group,
             **({"stale": r.stale} if r.stale else {})}
            for r in report.results
        ],
    }


RECORD_ENV = "DT_EVAL_RECORD"
RECORD_BRANCH = "main"


def _current_branch() -> str | None:
    """Ветка ``engine/`` (``git rev-parse --abbrev-ref HEAD``); не определилась → ``None``.

    Детач-HEAD даёт литерал ``HEAD`` — для политики это «не main» (понять, какой коммит под ним,
    дёшево не выходит; точка в линейку не пишется).
    """
    import subprocess

    from core.config import ENGINE_ROOT

    try:
        out = subprocess.run(  # noqa: S603 — фиксированная git-инвокация, ввода нет
            ["git", "-C", str(ENGINE_ROOT), "rev-parse", "--abbrev-ref", "HEAD"],  # noqa: S607
            capture_output=True, text=True, timeout=10, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    name = out.stdout.strip()
    return name if out.returncode == 0 and name else None


def record_policy(
    *, env: dict[str, str] | None = None, branch: Callable[[], str | None] | None = None
) -> tuple[bool, str]:
    """Писать ли прогон в боевую историю: ``(писать, пояснение)`` (SMOKE-SANDBOX-FIX п.2).

    Линейка истории — точки КОДА, влитого в main: от неё считается «красный» следующего прогона,
    поэтому прогон с рабочей ветки (код ещё не принят) её не пишет — иначе чужая точка 0.736
    (retr-chunk-1, 26.10) стала бы базой для сравнения. Правило: ``DT_EVAL_RECORD=1`` — писать
    принудительно (осознанная метка), иначе только на ветке :data:`RECORD_BRANCH`. Прогон при
    этом идёт и метрики выводятся — не пишется только строка в файл. Ветку определить не
    удалось → не пишем (молчаливая подмена линейки хуже пропущенной точки; причина — в пояснении).
    """
    import os

    environ = os.environ if env is None else env
    if str(environ.get(RECORD_ENV, "")).strip() == "1":
        return True, f"{RECORD_ENV}=1 — запись принудительна"
    name = (branch or _current_branch)()
    if name is None:
        return False, "история не записана: ветка не определилась (git rev-parse не ответил)"
    if name == RECORD_BRANCH:
        return True, f"ветка {name}"
    return False, (f"история не записана: ветка {name} (пишется только с {RECORD_BRANCH}; "
                   f"принудительно — {RECORD_ENV}=1)")


def append_history(report: EvalReport, path: Path | None = None) -> Path:
    """Дописать прогон в ``.derived/eval/history.jsonl``. Сбой записи — наружу (измерение,
    которое не сохранилось, нельзя выдавать за выполненное)."""
    target = Path(path) if path is not None else eval_history_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(history_record(report), ensure_ascii=False) + "\n")
    return target


def last_runs(
    n: int = 2, *, path: Path | None = None, now: datetime | None = None
) -> list[dict[str, Any]]:
    """Последние ``n`` прогонов (старые → новые) с ``age_days``; нет файла/битые строки → меньше."""
    target = Path(path) if path is not None else eval_history_path()
    try:
        lines = target.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    runs: list[dict[str, Any]] = []
    for line in lines:
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(rec, dict) and isinstance(rec.get("metrics"), dict):
            runs.append(rec)
    now_dt = now or datetime.now(UTC)
    out = runs[-max(1, n):]
    for rec in out:
        try:
            ts = datetime.strptime(str(rec.get("ts")), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
            rec["age_days"] = round((now_dt - ts).total_seconds() / 86400.0, 1)
        except ValueError:
            rec["age_days"] = None
    return out


# --------------------------------------------------------------------------- #
# Таблица и сводка                                                               #
# --------------------------------------------------------------------------- #
def _fmt(value: float | None) -> str:
    return "—" if value is None else f"{value:.2f}"


_METRIC_LABELS = {"recall5": "recall@5", "mrr": "MRR", "hub3": "hub@3", "envelope": "конверт",
                  "tail": "хвост", "corpus": "корпус", "facts": "факты", "read": "чтение"}
GROUP_LABELS = {GROUP_WORK: "рабочая", GROUP_CONTROL: "контрольная"}


def _metrics_line(
    metrics: dict[str, float | None], deltas: dict[str, float | None] | None = None
) -> str:
    parts = []
    for metric in METRICS:
        value = metrics.get(metric)
        if value is None:
            continue
        delta = (deltas or {}).get(metric)
        tail = f" (Δ {delta:+.2f})" if delta is not None else ""
        parts.append(f"{_METRIC_LABELS[metric]} {value:.2f}{tail}")
    return " · ".join(parts)


def summary_line(report: EvalReport) -> str:
    """Одна строка метрик ВСЕГО набора: ``recall@5 0.52 (Δ −0.03) · MRR … · hub@3 …``."""
    line = _metrics_line(report.metrics, report.deltas) or "метрик нет"
    if report.stale_ids:
        line += f" · stale {len(report.stale_ids)}"
    return line


def group_line(report: EvalReport, group: str) -> str:
    """Строка группы: метрики и Δ к прошлому ЭТОЙ группы; пустая группа — «нет данных»."""
    label = GROUP_LABELS[group]
    stat = report.groups.get(group)
    if stat is None or stat.n == 0:
        return f"{label}: нет данных (в группе нет проверенных запросов)"
    line = _metrics_line(stat.metrics, report.group_deltas.get(group)) or "метрик нет"
    tag = " [новая базовая линия]" if group in report.baseline_groups else ""
    return f"{label} ({stat.n}): {line}{tag}"


def type_table(report: EvalReport) -> list[str]:
    """Сводка по типам запросов (EVAL-4 п.1): тип, n, метрики и Δ к прошлому прогону того же
    состава типа. Диагностика — на красное не влияет. Тип без проверенных запросов — «нет данных».
    """
    if not report.by_type:
        return []
    rows = []
    for qtype, st in report.by_type.items():
        if st.n == 0:
            rows.append((qtype, "0", "нет данных (нет проверенных запросов)"))
            continue
        line = _metrics_line(st.metrics, report.type_deltas.get(qtype)) or "метрик нет"
        rows.append((qtype, str(st.n), line))
    w0 = max(len("тип"), *(len(r[0]) for r in rows))
    w1 = max(len("n"), *(len(r[1]) for r in rows))
    out = ["по типам запросов (диагностика, не гейт; Δ — к прошлому прогону при том же "
           "составе типа):",
           f"  {'тип'.ljust(w0)}  {'n'.rjust(w1)}  метрики"]
    out.extend(f"  {t.ljust(w0)}  {n.rjust(w1)}  {m}" for t, n, m in rows)
    return out


def red_text(red: list[str]) -> str:
    """Красные метрики человеку: ``recall5`` → ``recall@5``, ``control:hub3`` → ``контр. hub@3``."""
    out = []
    for item in red:
        group, _, metric = item.rpartition(":")
        name = _METRIC_LABELS.get(metric, metric)
        out.append(f"{GROUP_LABELS.get(group, group)} {name}" if group else name)
    return ", ".join(out)


def format_table(report: EvalReport) -> str:
    """Таблица «запрос → ожидание → факт» + сводка и вердикт (CLI ``dt_eval`` и деталь С-10)."""
    rows = []
    for r in report.results:
        verdict = "stale" if r.stale else "ошибка" if r.errors else ("✓" if r.passed else "✗")
        fact = ", ".join(i.replace("legacy-", "l-")[:16] for i in r.top_ids[:3])
        if r.stale:
            fact = "нет в vault: " + ", ".join(i.replace("legacy-", "l-")[:16] for i in r.stale[:2])
        elif r.errors:
            fact = r.errors[0][:40]
        elif r.extra:
            fact = r.extra
        elif not fact:  # не выдача (факты/чтение/конверт): что увидела проверка
            fact = "; ".join(c.detail for c in r.checks[:2]) or "—"
        mark = "" if r.verified else " (гипотеза)"
        rows.append((r.id, r.type[:9], r.label[:44], r.expect_text[:34], fact[:40],
                     verdict + mark))
    headers = ("id", "тип", "вызов", "ожидание", "факт (топ-3)", "итог")
    widths = [max(len(h), *(len(row[i]) for row in rows)) for i, h in enumerate(headers)]
    lines = ["  ".join(h.ljust(widths[i]) for i, h in enumerate(headers))]
    lines.append("  ".join("-" * w for w in widths))
    lines.extend("  ".join(c.ljust(widths[i]) for i, c in enumerate(row)) for row in rows)
    head = (f"EVAL-1: {report.verified_n} запросов в метрике, {report.hypotheses} гипотез вне "
            f"метрики, {report.errors} с ошибкой; {report.duration_s:.0f} с")
    lines.append("")
    lines.append(head)
    lines.append("всего: " + summary_line(report))
    lines.append(_config_line(report))
    lines.extend(group_line(report, g) for g in GROUPS)
    lines.extend(type_table(report))
    if report.stale_ids:
        lines.append(
            f"STALE {len(report.stale_ids)} ({', '.join(report.stale_ids)}): заметка "
            "перегенерирована или удалена — поправь id в golden-queries.yaml (в метрику эти "
            "запросы не входят, красным С-10 не делают)"
        )
    if report.baseline:
        lines.append("первый прогон — БАЗОВАЯ ЛИНИЯ (красным не бывает)")
    else:
        n_groups = sum(1 for g in GROUPS if g in report.groups and report.groups[g].n)
        compared = n_groups - len(report.baseline_groups)
        if report.baseline_groups:
            fresh = ", ".join(GROUP_LABELS[g] for g in report.baseline_groups)
            lines.append(
                f"набор изменился → новая базовая линия: {fresh}; "
                + ("остальные группы сравниваются с прошлым" if compared > 0
                   else "с прошлым не сравнивается")
            )
        if report.red:
            lines.append("КРАСНЫЙ: падение > 0.1 к прошлому по " + red_text(report.red))
        elif compared > 0:
            lines.append("к прошлому прогону: без регрессии (порог 0.1 по recall@5 и hub@3, "
                         "по каждой группе отдельно)")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# RETR-RERANK-1 п.6 — абляция: четыре варианта выдачи на одном наборе            #
# --------------------------------------------------------------------------- #
# (метка, название, реранкер, семантика всегда). Решение по дефолтам — К. по числам.
VARIANTS: tuple[tuple[str, str, bool, bool], ...] = (
    ("а", "база", False, False),
    ("б", "реранкер", True, False),
    ("в", "реранкер + семантика всегда", True, True),
    ("г", "только семантика всегда", False, True),
)


def _config_line(report: EvalReport) -> str:
    cfg = report.config or {}
    lat = latency_ms(report)
    parts = [
        "реранкер: " + ("вкл" if cfg.get("rerank") else "выкл"),
        "семантика: " + ("всегда" if cfg.get("semantic_always") else "лестница"),
    ]
    if lat["p50"] is not None:
        parts.append(f"латентность запроса p50 {lat['p50']} мс · p95 {lat['p95']} мс")
    return " · ".join(parts)


def _query_ranks(report: EvalReport) -> dict[str, int | None]:
    """Ранг цели по запросам, у которых он есть (проверка ``mrr``); нет в выдаче → ``None``."""
    out: dict[str, int | None] = {}
    for r in report.results:
        if r.stale or not r.verified:
            continue
        ranks = [c.rank for c in r.checks if c.metric == "mrr"]
        if any(c.metric == "mrr" for c in r.checks):
            found = [x for x in ranks if x is not None]
            out[r.id] = min(found) if found else None
    return out


def ablation_table(runs: list[tuple[str, str, EvalReport]]) -> str:
    """Сводная таблица абляции: метрики и латентность по вариантам + ранг цели по запросам.

    ``runs`` — ``[(метка, название, отчёт)]``. Вторая часть — только запросы, у которых цель не
    первая хотя бы в одном варианте (там и видна работа реранкера); ``—`` = нет в выдаче.
    """
    head = ("вар", "вариант", "recall@5", "MRR", "hub@3", "p50 мс", "p95 мс", "ошибок")
    rows: list[tuple[str, ...]] = []
    for label, name, rep in runs:
        lat = latency_ms(rep)
        rows.append((
            label, name, _fmt(rep.metrics.get("recall5")), _fmt(rep.metrics.get("mrr")),
            _fmt(rep.metrics.get("hub3")), str(lat["p50"] if lat["p50"] is not None else "—"),
            str(lat["p95"] if lat["p95"] is not None else "—"), str(rep.errors),
        ))
    widths = [max(len(h), *(len(r[i]) for r in rows)) for i, h in enumerate(head)]
    lines = ["  ".join(h.ljust(widths[i]) for i, h in enumerate(head)),
             "  ".join("-" * w for w in widths)]
    lines.extend("  ".join(c.ljust(widths[i]) for i, c in enumerate(r)) for r in rows)
    per = [(label, _query_ranks(rep)) for label, _, rep in runs]
    ids = [i for i in dict.fromkeys(i for _, rk in per for i in rk)
           if any(rk.get(i) != 1 for _, rk in per if i in rk)]
    if ids:
        lines.append("")
        lines.append("ранг цели по запросам (цель не первая хотя бы в одном варианте; "
                     "— = нет в выдаче):")
        lines.append("  " + "  ".join(["id".ljust(5), *(f"{lab:>3}" for lab, _ in per)]))
        for qid in ids:
            cells = [("—" if rk.get(qid) is None else str(rk[qid])) if qid in rk else "·"
                     for _, rk in per]
            lines.append("  " + "  ".join([qid.ljust(5), *(f"{c:>3}" for c in cells)]))
    return "\n".join(lines)
