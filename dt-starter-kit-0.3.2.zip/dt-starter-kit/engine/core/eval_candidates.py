"""EVAL-2 п.3 — кандидаты в золотой набор из употребления.

Золотой набор (EVAL-1) — снимок аудита; живые провалы поиска в него не попадают, и метрика
слепа к тому, чего не было в октябре. Журнал запросов (:mod:`core.eval_journal`) знает, что К.
искал и что открывал следом. Здесь из него выводятся **кандидаты** — запросы, которые стоит
добавить в набор, — и очередь решений «принять / отклонить / отложить» (образец —
``HubCandidateQueue`` из HUB-1).

**Кандидат.** Запросы группируются по нормализованному тексту (регистр, пунктуация, пробелы).
В группе считается число повторов и открытия заметок, которые следуют за поиском в окне
:data:`WINDOW_MIN` минут (неявное ожидание: открытая заметка = релевантна; открытие
приписывается ближайшему предшествующему поиску). Кандидат — группа, где **открыта заметка** и
(``≥2`` повторов ИЛИ открытая заметка не была в топ-5 выдачи на момент поиска: промах,
который К. починил руками). Группа без единого открытия кандидатом не бывает: ожидание
неизвестно, а «принять» без ожидания — пустая запись (ТЗ формально допускает «≥2 повтора»
и без открытия; здесь это сознательно уже — см. отчёт EVAL-2).

**Исключения.** Покрытое набором: тот же нормализованный текст ИЛИ то же ожидание (общая
заметка) при пересечении слов запросов ≥ :data:`COVER_OVERLAP` (доля от меньшего набора слов:
«ИТХ» уже покрыт запросом «КЭДО ИТХ» с тем же хабом). Заметка под NDA в кандидаты не идёт.

**Очередь** ``.derived/eval/candidates.json``: ``pending | accepted | rejected | snoozed``,
идемпотентный ``candidate_id`` (sha1 от нормализованного текста). ``rejected`` — стоп-журнал:
такой текст не воскресает. ``snoozed`` возвращается в ``pending`` по сроку. Пересчёт — при
чтении очереди (пульт), кэш :data:`CACHE_SECONDS` (без нового launchd-джоба).

**Решение** (:func:`decide_golden_candidate`): ``accept`` ДОПИСЫВАЕТ блок запроса в конец
``golden-queries.yaml`` ТЕКСТОМ (старые байты файла не меняются: комментарии на месте, YAML не
пере-дампится), проверяет результат ``load_golden`` до записи и пишет атомарно. Запрос —
``источник: проверено``, ``группа: контрольная``.

Инвариант: ``core`` ⊥ mcp/cli; сети и LLM нет; ретривал для «сегодняшнего ранга» приходит
параметром (``probe``) — как инструменты в :func:`core.eval.run_eval`.
"""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from collections import Counter
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import eval_candidates_path

__all__ = [
    "CACHE_SECONDS",
    "COVER_OVERLAP",
    "MIN_REPEATS",
    "WINDOW_MIN",
    "GoldenCandidate",
    "GoldenCandidateQueue",
    "NoteInfo",
    "decide_golden_candidate",
    "ensure_fresh",
    "normalize_query",
    "refresh_queue",
]

# Путь очереди — ``core.config.eval_candidates_path()`` (TEST-SANDBOX-1: функция, не константа).

WINDOW_MIN = 10          # окно «открытие после поиска», минут
MIN_REPEATS = 2          # повторов запроса для кандидата
CACHE_SECONDS = 3600     # кэш пересчёта очереди
COVER_OVERLAP = 0.6      # пересечение слов запросов при общем ожидании = «уже покрыто»
SNOOZE_DAYS = 7
MAX_EXPECTED = 5         # заметок-ожиданий в карточке (самые открываемые)
_TOP_N = 5
MAX_PROBES = 15          # «сегодняшний ранг» считаем для самых повторяемых (поиск дорог)

STATUS_PENDING = "pending"
STATUS_ACCEPTED = "accepted"
STATUS_REJECTED = "rejected"
STATUS_SNOOZED = "snoozed"
STATUS_RESOLVED = "resolved"  # снят пересчётом (покрыт набором / журнал состарился)
DECISIONS = ("accept", "reject", "snooze")

_PUNCT_RE = re.compile(r"[^\w\s]|_")


def normalize_query(text: Any) -> str:
    """Нижний регистр, без пунктуации, схлопнутые пробелы (ё = е)."""
    t = unicodedata.normalize("NFKC", str(text or "")).casefold().replace("ё", "е")
    return " ".join(_PUNCT_RE.sub(" ", t).split())


def candidate_id(norm: str) -> str:
    """Детерминированный 12-hex id по нормализованному тексту (без часов/random)."""
    return hashlib.sha1(f"golden:{norm}".encode()).hexdigest()[:12]  # noqa: S324 — id, не крипто


def _ts(now: datetime) -> str:
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse(value: Any) -> datetime | None:
    try:
        return datetime.strptime(str(value), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    except ValueError:
        return None


# --------------------------------------------------------------------------- #
# Заметка по ссылке: канонический id, заголовок, путь                            #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class NoteInfo:
    note_id: str
    title: str
    path: str       # vault-относительный
    is_hub: bool


def note_info(ref: str) -> NoteInfo | None:
    """Резолв ссылки любой формы (единая точка ``resolve_note_path``) → инфо о заметке.

    ``None`` — не резолвится ИЛИ под NDA-барьером. Сбой чтения файла — тоже ``None``
    (кандидат не строится по заметке, которую не прочитать).
    """
    from core.config import default_vault_path
    from core.privacy import any_nda
    from core.vault import read_note, resolve_note_path

    try:
        path = resolve_note_path(ref)
        if path is None:
            return None
        vault = default_vault_path()
        try:
            rel = str(path.resolve().relative_to(Path(vault).resolve()))
        except (ValueError, OSError):
            rel = str(path)
        note = read_note(path)
        if any_nda(rel, ref, note.id):
            return None
        title = str(note.frontmatter.get("title") or path.stem)
        return NoteInfo(note.id, title, rel, str(note.type or "").lower() == "hub")
    except Exception:  # noqa: BLE001 — нечитаемая заметка не строит кандидата
        return None


# --------------------------------------------------------------------------- #
# Строка очереди и очередь                                                       #
# --------------------------------------------------------------------------- #
@dataclass
class GoldenCandidate:
    id: str
    norm: str
    query: str                       # как К. написал в последний раз (показ на карточке)
    tool: str
    args: dict[str, Any]
    expected: list[dict[str, Any]] = field(default_factory=list)  # note_id,title,path,is_hub,rank
    repeats: int = 0
    today_rank: int | None = None
    first_seen: str = ""
    last_seen: str = ""
    status: str = STATUS_PENDING
    created: str | None = None
    decided_at: str | None = None
    snoozed_until: str | None = None
    golden_id: str | None = None     # qNN, под которым принят

    def to_row(self) -> dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> GoldenCandidate:
        return cls(
            id=str(row.get("id") or ""), norm=str(row.get("norm") or ""),
            query=str(row.get("query") or ""), tool=str(row.get("tool") or "find_notes"),
            args=dict(row.get("args") or {}),
            expected=[dict(e) for e in row.get("expected") or [] if isinstance(e, dict)],
            repeats=int(row.get("repeats") or 0),
            today_rank=row.get("today_rank") if isinstance(row.get("today_rank"), int) else None,
            first_seen=str(row.get("first_seen") or ""), last_seen=str(row.get("last_seen") or ""),
            status=str(row.get("status") or STATUS_PENDING), created=row.get("created"),
            decided_at=row.get("decided_at"), snoozed_until=row.get("snoozed_until"),
            golden_id=row.get("golden_id"),
        )

    def to_card(self) -> dict[str, Any]:
        """Форма карточки пульта (ТЗ п.4): ``{id, query, tool, args, expected[], repeats,
        today_rank, first_seen, last_seen}`` — id/заголовок/путь заметок и числа, без текстов."""
        return {
            "id": self.id, "query": self.query, "tool": self.tool, "args": dict(self.args),
            "expected": [
                {"note_id": e.get("note_id"), "title": e.get("title"), "path": e.get("path"),
                 "rank": e.get("rank"), "is_hub": bool(e.get("is_hub"))}
                for e in self.expected
            ],
            "repeats": self.repeats, "today_rank": self.today_rank,
            "first_seen": self.first_seen, "last_seen": self.last_seen,
        }


@dataclass
class GoldenCandidateQueue:
    """Очередь ``.derived/eval/candidates.json``, keyed by id (без сети)."""

    by_id: dict[str, GoldenCandidate] = field(default_factory=dict)
    refreshed_at: str | None = None
    path: Path | None = None

    @classmethod
    def load(cls, path: Path | None = None) -> GoldenCandidateQueue:
        target = Path(path) if path is not None else eval_candidates_path()
        by_id: dict[str, GoldenCandidate] = {}
        refreshed = None
        try:
            data = json.loads(target.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            data = {}  # очередь перестраиваемая: нет/битый файл = пусто (журнал пересоберёт)
        if isinstance(data, dict):
            refreshed = data.get("refreshed_at")
            for row in data.get("candidates") or []:
                if isinstance(row, dict) and row.get("id"):
                    cand = GoldenCandidate.from_row(row)
                    by_id[cand.id] = cand
        return cls(by_id=by_id, refreshed_at=refreshed, path=target)

    def save(self, path: Path | None = None) -> Path:
        chosen = Path(path or self.path or eval_candidates_path())
        chosen.parent.mkdir(parents=True, exist_ok=True)
        rows = sorted(self.by_id.values(), key=lambda c: (c.created or "", c.id))
        body = {"version": 1, "refreshed_at": self.refreshed_at,
                "candidates": [c.to_row() for c in rows]}
        tmp = chosen.with_suffix(chosen.suffix + ".tmp")
        tmp.write_text(json.dumps(body, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
        tmp.replace(chosen)
        return chosen

    def pending(self, now: datetime | None = None) -> list[GoldenCandidate]:
        """Pending-строки (отложенные, у которых срок вышел, считаются pending)."""
        stamp = now or datetime.now(UTC)
        out = []
        for c in self.by_id.values():
            if c.status == STATUS_PENDING:
                out.append(c)
            elif c.status == STATUS_SNOOZED:
                until = _parse(c.snoozed_until)
                if until is not None and until <= stamp:
                    out.append(c)
        return sorted(out, key=lambda c: (-c.repeats, c.last_seen, c.id))

    def count(self, status: str) -> int:
        return sum(1 for c in self.by_id.values() if c.status == status)


# --------------------------------------------------------------------------- #
# Группировка журнала                                                            #
# --------------------------------------------------------------------------- #
@dataclass
class _Group:
    norm: str
    query: str = ""
    tool: str = "find_notes"
    args: dict[str, Any] = field(default_factory=dict)
    repeats: int = 0
    first_seen: str = ""
    last_seen: str = ""
    opens: Counter[str] = field(default_factory=Counter)   # ссылка → сколько раз открыта
    missed: bool = False                                    # открыта заметка вне топ-5 поиска


def _query_text(args: dict[str, Any]) -> str:
    return str(args.get("query") or args.get("person") or args.get("domain") or "")


def group_events(
    events: list[dict[str, Any]],
    *,
    canon: Callable[[str], str] = lambda r: r,
    window_min: int = WINDOW_MIN,
) -> dict[str, _Group]:
    """Журнал → группы по нормализованному тексту (поиски) с открытиями в окне.

    ``canon`` приводит ссылку открытой заметки к её ``note_id`` (для сверки с ``top_ids``
    поиска). Открытие приписывается БЛИЖАЙШЕМУ предшествующему поиску, если с него прошло не
    более ``window_min`` минут; одно открытие не удваивается по нескольким поискам.
    """
    groups: dict[str, _Group] = {}
    last_search: tuple[datetime, str, list[str]] | None = None  # (ts, norm, top_ids)
    window = timedelta(minutes=window_min)
    for ev in events:
        ts = _parse(ev.get("ts"))
        if ts is None:
            continue
        if ev.get("event") == "search":
            raw_args = ev.get("args")
            args: dict[str, Any] = raw_args if isinstance(raw_args, dict) else {}
            text = _query_text(args)
            norm = normalize_query(text)
            if not norm:
                continue
            g = groups.setdefault(norm, _Group(norm=norm, first_seen=str(ev["ts"])))
            g.repeats += 1
            g.query, g.tool, g.args = text, str(ev.get("tool") or "find_notes"), dict(args)
            g.last_seen = str(ev["ts"])
            last_search = (ts, norm, [str(i) for i in ev.get("top_ids") or []])
        elif ev.get("event") == "open" and last_search is not None:
            s_ts, norm, top = last_search
            if ts - s_ts > window or ts < s_ts:
                continue
            ref = str(ev.get("note_id") or "")
            if not ref:
                continue
            g = groups[norm]
            cid = canon(ref)
            g.opens[cid] += 1
            if cid not in top[:_TOP_N] and ref not in top[:_TOP_N]:
                g.missed = True
    return groups


def _words(norm: str) -> set[str]:
    return set(norm.split())


def _covered(
    norm: str, expected_ids: set[str], golden: list[tuple[str, set[str]]]
) -> bool:
    """Уже покрыто набором: тот же текст, либо общее ожидание при пересечении слов ≥ порога."""
    words = _words(norm)
    for g_norm, g_ids in golden:
        if g_norm == norm:
            return True
        g_words = _words(g_norm)
        if not (words and g_words and expected_ids & g_ids):
            continue
        if len(words & g_words) / min(len(words), len(g_words)) >= COVER_OVERLAP - 1e-9:
            return True
    return False


def golden_signature(queries: list[Any], canon: Callable[[str], str]) -> list[tuple[str, set[str]]]:
    """Набор → ``[(нормализованный текст вызова, {канонические id ожидания})]`` на запрос-вызов."""
    from core.eval import expected_refs

    out: list[tuple[str, set[str]]] = []
    ids_by_query = {q.id: {canon(r) for r in expected_refs(q)} for q in queries}
    for q in queries:
        for call in q.calls:
            norm = normalize_query(_query_text(call.args))
            if norm:
                out.append((norm, ids_by_query[q.id]))
    return out


# --------------------------------------------------------------------------- #
# Пересчёт очереди                                                               #
# --------------------------------------------------------------------------- #
Probe = Callable[[str, dict[str, Any]], list[str]]


def _rank(ids: list[str], note_id: str) -> int | None:
    for i, nid in enumerate(ids, start=1):
        if nid == note_id:
            return i
    return None


def _fill_ranks(cand: GoldenCandidate, probe: Probe) -> None:
    """Сегодняшний ранг ожидаемых заметок в выдаче того же вызова; сбой ретривала → ``None``."""
    try:
        ids_today = [str(i) for i in probe(cand.tool, cand.args)]
    except Exception:  # noqa: BLE001 — нет ретривала: ранг неизвестен, кандидат остаётся
        return
    for e in cand.expected:
        e["rank"] = _rank(ids_today, str(e["note_id"]))
    ranks = [e["rank"] for e in cand.expected if isinstance(e["rank"], int)]
    cand.today_rank = min(ranks) if ranks else None


def build_candidates(
    events: list[dict[str, Any]],
    golden: list[Any],
    *,
    info: Callable[[str], NoteInfo | None] = note_info,
    probe: Probe | None = None,
    now: datetime | None = None,
) -> list[GoldenCandidate]:
    """Кандидаты по журналу: критерии и исключения — в докстринге модуля."""
    stamp = _ts(now or datetime.now(UTC))
    cache: dict[str, NoteInfo | None] = {}

    def _info(ref: str) -> NoteInfo | None:
        if ref not in cache:
            cache[ref] = info(ref)
        return cache[ref]

    def canon(ref: str) -> str:
        found = _info(ref)
        return found.note_id if found else ref

    groups = group_events(events, canon=canon)
    covered_sig = golden_signature(golden, canon)
    out: list[GoldenCandidate] = []
    for g in groups.values():
        notes: list[NoteInfo] = []
        for ref, _count in g.opens.most_common():
            found = _info(ref)
            if found is not None and found.note_id not in {n.note_id for n in notes}:
                notes.append(found)
        notes = notes[:MAX_EXPECTED]
        if not notes or not (g.repeats >= MIN_REPEATS or g.missed):
            continue
        if _covered(g.norm, {n.note_id for n in notes}, covered_sig):
            continue
        expected = [
            {"note_id": n.note_id, "title": n.title, "path": n.path, "is_hub": n.is_hub,
             "rank": None}
            for n in notes
        ]
        out.append(GoldenCandidate(
            id=candidate_id(g.norm), norm=g.norm, query=g.query, tool=g.tool, args=g.args,
            expected=expected, repeats=g.repeats, first_seen=g.first_seen,
            last_seen=g.last_seen, created=stamp,
        ))
    out.sort(key=lambda c: (-c.repeats, c.last_seen, c.id))
    if probe is not None:
        for cand in out[:MAX_PROBES]:
            _fill_ranks(cand, probe)
    return out


def refresh_queue(
    queue: GoldenCandidateQueue,
    events: list[dict[str, Any]],
    golden: list[Any],
    *,
    info: Callable[[str], NoteInfo | None] = note_info,
    probe: Probe | None = None,
    now: datetime | None = None,
) -> dict[str, int]:
    """Слить свежих кандидатов в очередь; вернуть счётчики ``{new, updated, resolved, woken}``.

    Новый → ``pending``; существующий ``pending`` обновляет сигналы (повторы, ожидание, ранг);
    ``accepted``/``rejected`` не трогаются никогда (``rejected`` — стоп-журнал); ``snoozed`` с
    истёкшим сроком возвращается в ``pending``; ``pending``, который по нынешним данным уже не
    кандидат (покрыт набором, журнал состарился), снимается статусом ``resolved`` — и
    возвращается в ``pending``, если сигнал вернулся (как ``resolved`` у HUB-1).
    """
    stamp = now or datetime.now(UTC)
    fresh = {c.id: c for c in build_candidates(events, golden, info=info, probe=probe, now=stamp)}
    counts = {"new": 0, "updated": 0, "resolved": 0, "woken": 0}
    for cid, cand in fresh.items():
        row = queue.by_id.get(cid)
        if row is None:
            queue.by_id[cid] = cand
            counts["new"] += 1
        elif row.status in (STATUS_PENDING, STATUS_RESOLVED) or (
            row.status == STATUS_SNOOZED and (_parse(row.snoozed_until) or stamp) <= stamp
        ):
            if row.status == STATUS_SNOOZED:
                counts["woken"] += 1
            created = row.created
            queue.by_id[cid] = cand
            cand.created = created or cand.created
            counts["updated"] += 1
    for cid, row in queue.by_id.items():
        due = row.status == STATUS_SNOOZED and (_parse(row.snoozed_until) or stamp) <= stamp
        if (row.status == STATUS_PENDING or due) and cid not in fresh:
            row.status = STATUS_RESOLVED
            row.decided_at = _ts(stamp)
            counts["resolved"] += 1
    queue.refreshed_at = _ts(stamp)
    return counts


def ensure_fresh(
    *,
    queue_path: Path | None = None,
    journal_path: Path | None = None,
    golden_file: Path | None = None,
    info: Callable[[str], NoteInfo | None] = note_info,
    probe: Probe | None = None,
    now: datetime | None = None,
    force: bool = False,
    max_age_s: int = CACHE_SECONDS,
) -> tuple[GoldenCandidateQueue, str | None]:
    """Очередь, пересчитанная не старше ``max_age_s`` (кэш 1 ч) — для чтения из пульта.

    Возвращает ``(очередь, ошибка)``; ``ошибка`` — человекочитаемая причина деградации (канон
    не читается → «покрыто набором» не определить, пересчёт НЕ делается, очередь отдаётся как
    есть), иначе ``None``. Нет файла журнала — пустой пересчёт, не ошибка.
    """
    from core import eval_journal
    from core.eval import GoldenError, load_golden

    stamp = now or datetime.now(UTC)
    queue = GoldenCandidateQueue.load(queue_path)
    last = _parse(queue.refreshed_at)
    if not force and last is not None and 0 <= (stamp - last).total_seconds() < max_age_s:
        return queue, None
    try:
        golden = load_golden(golden_file)
    except GoldenError as exc:
        return queue, f"золотой набор не прочитан — пересчёт кандидатов пропущен: {exc}"[:300]
    events = eval_journal.read_events(journal_path)
    refresh_queue(queue, events, golden, info=info, probe=probe, now=stamp)
    queue.save(queue_path)
    return queue, None


# --------------------------------------------------------------------------- #
# Решение: accept дописывает блок в канон                                        #
# --------------------------------------------------------------------------- #
_ID_RE = re.compile(r"^\s*-?\s*id:\s*[\"']?(q(\d+))[\"']?\s*(?:#.*)?$", re.MULTILINE)


def next_golden_id(text: str, existing: list[str]) -> str:
    """Следующий свободный ``qNN`` (по сырому тексту И по загруженным id: дубль невозможен)."""
    nums = [int(m.group(2)) for m in _ID_RE.finditer(text)]
    nums += [int(m.group(1)) for i in existing if (m := re.fullmatch(r"q(\d+)", i))]
    n = max(nums, default=0) + 1
    width = max(2, len(str(n)))
    return f"q{n:0{width}d}"


def _yaml_str(value: Any) -> str:
    """Скаляр/структура в flow-YAML. JSON-строка в двойных кавычках — валидный YAML-скаляр."""
    return json.dumps(value, ensure_ascii=False)


def _flow(value: Any) -> str:
    if isinstance(value, dict):
        inner = ", ".join(f"{k}: {_flow(v)}" for k, v in value.items())
        return "{" + inner + "}"
    if isinstance(value, list):
        return "[" + ", ".join(_flow(v) for v in value) + "]"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int | float):
        return json.dumps(value)
    return _yaml_str(str(value))


def render_block(
    qid: str, cand: GoldenCandidate, expected: list[NoteInfo], *, day: str, cand_id: str
) -> str:
    """Текст блока запроса для дописывания (отступ и стиль — как у ``q01…q30``)."""
    hubs = [n for n in expected if n.is_hub]
    plain = [n for n in expected if not n.is_hub]
    expect: dict[str, Any] = {}
    if plain:
        expect["note_ids"] = [n.note_id for n in plain]
    if hubs:
        expect["hub"] = hubs[0].note_id
        if len(hubs) > 1:  # второй и далее хаб — как обычное ожидание (hub@3 один на запрос)
            expect.setdefault("note_ids", []).extend(n.note_id for n in hubs[1:])
    note = f"из употребления, принято К. {day}; повторов {cand.repeats}"
    return (
        f"  # из употребления, кандидат {cand_id}\n"
        f"  - id: {qid}\n"
        f"    тип: употребление\n"
        f"    вызов: {_flow({'tool': cand.tool, 'args': cand.args})}\n"
        f"    ожидание: {_flow(expect)}\n"
        f"    источник: проверено\n"
        f"    группа: контрольная\n"
        f"    заметка: {_yaml_str(note)}\n"
    )


def _refuse(code: str, error: str, **extra: Any) -> dict[str, Any]:
    """Отказ ``accept``: ``{ok: false, refused, code, error}`` + конверт CONTRACT-2 с тем же
    кодом (машинная причина, а не только строка для человека)."""
    from core.contract import add_warning

    return add_warning(
        {"ok": False, "refused": code, "code": code, "error": error, **extra}, code, error
    )


def decide_golden_candidate(
    cid: str,
    decision: str,
    expected_ids: list[str] | None = None,
    *,
    queue: GoldenCandidateQueue,
    golden_file: Path,
    info: Callable[[str], NoteInfo | None] = note_info,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Решение по кандидату: ``accept`` | ``reject`` | ``snooze``.

    * ``accept`` — блок дописывается в конец канона (текстом, без пере-дампа YAML), id ``qNN``
      свободный, ``группа: контрольная``; результат проверяется :func:`core.eval.load_golden`
      ДО записи, запись атомарна. ``expected_ids`` (опц.) заменяет ожидание кандидата —
      заметки из «открытых»; каждая обязана резолвиться (иначе отказ ``unknown_note``).
    * ``reject`` — навсегда (стоп-журнал: текст больше не предлагается).
    * ``snooze`` — на :data:`SNOOZE_DAYS` суток, потом снова pending.

    Идемпотентно по id: повторное решение → ``{"outcome": "stale"}``. Неизвестный id или
    решение — ``ValueError`` (как у ``pult_hub_decide``). Отказ ``accept`` — конверт
    ``{ok: false, refused/code}`` и очередь НЕ меняется.
    """
    from core.eval import GoldenError, load_golden
    from core.operational.pult import record_action

    if decision not in DECISIONS:
        raise ValueError(f"unsupported decision {decision!r}; use 'accept', 'reject' or 'snooze'")
    audit: dict[str, Any] = {"candidate_id": cid, "decision": decision}
    row = queue.by_id.get(cid)
    if row is None:
        record_action("pult_golden_decide", audit, "not_found")
        raise ValueError(f"Кандидат …{cid[-4:]} не найден в очереди кандидатов золотого набора.")
    stamp = now or datetime.now(UTC)
    woken = row.status == STATUS_SNOOZED and (_parse(row.snoozed_until) or stamp) <= stamp
    if row.status != STATUS_PENDING and not woken:
        record_action("pult_golden_decide", audit, "stale")
        why = {
            STATUS_RESOLVED: "снят пересчётом (покрыт набором или журнал состарился)",
            STATUS_SNOOZED: f"отложен до {row.snoozed_until}",
        }.get(row.status, f"уже решён ({row.status})")
        return {"outcome": "stale", "candidate_id": cid,
                "explanation": f"Кандидат {why} — повторное решение не требуется."}

    day = stamp.strftime("%Y-%m-%d")
    if decision == "reject":
        row.status, row.decided_at = STATUS_REJECTED, _ts(stamp)
        queue.save()
        record_action("pult_golden_decide", audit, "rejected")
        return {"outcome": "rejected", "candidate_id": cid, "query": row.query,
                "explanation": "Отклонено навсегда — этот запрос больше не предлагается."}
    if decision == "snooze":
        row.status, row.decided_at = STATUS_SNOOZED, _ts(stamp)
        row.snoozed_until = _ts(stamp + timedelta(days=SNOOZE_DAYS))
        queue.save()
        record_action("pult_golden_decide", audit, "snoozed")
        return {"outcome": "snoozed", "candidate_id": cid, "until": row.snoozed_until,
                "explanation": f"Отложено на {SNOOZE_DAYS} дн."}

    # ---- accept ----
    refs = [str(x).strip() for x in (expected_ids or []) if str(x).strip()] or [
        str(e.get("note_id")) for e in row.expected if e.get("note_id")
    ]
    if not refs:
        record_action("pult_golden_decide", audit, "no_expectation")
        return _refuse("no_expectation", "у кандидата нет ожидаемых заметок — укажи expected_ids "
                       "(открой нужную заметку или выбери из открытых)")
    notes: list[NoteInfo] = []
    for ref in refs:
        found = info(ref)
        if found is None:
            record_action("pult_golden_decide", audit, "unknown_note")
            return _refuse("unknown_note", f"заметка {ref[:80]!r} не найдена в vault "
                           "(или под NDA) — ожидание не принято", note_id=ref)
        if found.note_id not in {n.note_id for n in notes}:
            notes.append(found)
    try:
        old_text = golden_file.read_text(encoding="utf-8")
        existing = [q.id for q in load_golden(golden_file)]
    except (OSError, GoldenError) as exc:
        record_action("pult_golden_decide", audit, "golden_unreadable")
        return _refuse("store_unavailable", f"золотой набор не прочитан — решение не записано: "
                       f"{str(exc)[:200]}")
    qid = next_golden_id(old_text, existing)
    prefix = "" if old_text.endswith("\n") else "\n"
    block = render_block(qid, row, notes, day=day, cand_id=cid)
    new_text = old_text + prefix + "\n" + block
    # проверка ДО записи: дописанный файл обязан остаться валидным набором с новым id
    probe_path = golden_file.with_suffix(golden_file.suffix + ".probe")
    try:
        probe_path.write_text(new_text, encoding="utf-8")
        new_ids = [q.id for q in load_golden(probe_path)]
    except (OSError, GoldenError) as exc:
        record_action("pult_golden_decide", audit, "invalid_block")
        return _refuse("invalid_block", f"дописанный блок не прошёл валидацию: {str(exc)[:200]}")
    finally:
        probe_path.unlink(missing_ok=True)
    if new_ids.count(qid) != 1 or len(new_ids) != len(existing) + 1:
        record_action("pult_golden_decide", audit, "invalid_block")
        return _refuse("invalid_block", "после дописывания набор не вырос ровно на один запрос")
    tmp = golden_file.with_suffix(golden_file.suffix + ".tmp")
    tmp.write_text(new_text, encoding="utf-8")
    tmp.replace(golden_file)
    row.status, row.decided_at, row.golden_id = STATUS_ACCEPTED, _ts(stamp), qid
    row.expected = [
        {"note_id": n.note_id, "title": n.title, "path": n.path, "is_hub": n.is_hub,
         "rank": next((e.get("rank") for e in row.expected if e.get("note_id") == n.note_id), None)}
        for n in notes
    ]
    queue.save()
    audit["golden_id"] = qid
    record_action("pult_golden_decide", audit, "accepted")
    return {
        "outcome": "accepted", "candidate_id": cid, "golden_id": qid, "group": "контрольная",
        "expected": [n.note_id for n in notes], "path": str(golden_file),
        "explanation": f"Запрос дописан в golden-queries.yaml как {qid} (контрольная группа); "
                       "набор изменился → следующий прогон dt_eval начнёт новую базовую линию "
                       "для этой группы.",
    }
