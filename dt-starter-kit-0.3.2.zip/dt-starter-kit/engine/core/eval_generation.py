"""MODEL-1 (закрытие) п.A - золотые задачи ГЕНЕРАЦИИ по хостам: оценщик без LLM и без сети.

``golden-queries.yaml`` (EVAL-1) меряет выдачу движка in-process; генерацию по хостам никто не
сравнивал, хотя данные лежат в ``07-outputs/*/``: ``meta.yaml`` (host, model, model_source,
engine_calls, use_case, params), ``prompt.md`` (постановка дословно), ``sources.md`` (источники),
``output.md`` (текст). Здесь - читатель этих папок:

* :func:`load_generation_golden` - ``vault/_system/eval/golden-generation.yaml`` (русские ключи,
  как у ``golden-queries.yaml``; ошибки - :class:`GenerationGoldenError` с машинным ``code``);
* :func:`evaluate_generation` - сопоставляет выход с задачей (дословная фраза в ``meta.task`` /
  ``prompt.md`` либо ``title``) и хостом, считает проверки ok / ✗ / «нет данных»;
* :func:`outputs_by_host` - все выходы по хостам (витрина ``pult_kpi`` и доктор);
* история ``.derived/eval/generation.jsonl`` - точка на хост на прогон.

Read-only к vault и журналам; нет LLM, нет сети (judge-LLM оценка текста - «не брать», аудит D).
Старые выходы читаются: нет ``host`` - хост «—» (прочерк), нет поля - проверка «нет данных», а не
ok и не ✗ (канон §9 п.22: неизвестное не выдается за норму). Задача ok = ВСЕ применимые
проверки ok.
"""

from __future__ import annotations

import json
import re
import unicodedata
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from core.eval import GoldenError

__all__ = [
    "GENERATION_GOLDEN_REL",
    "GenerationGoldenError",
    "GenTask",
    "CheckResult",
    "RunResult",
    "GenerationReport",
    "load_generation_golden",
    "generation_golden_path",
    "evaluate_generation",
    "task_matches_text",
    "format_generation_table",
    "generation_json",
    "history_points",
    "append_generation_history",
    "generation_history_path",
    "read_generation_history",
    "generation_status",
    "outputs_by_host",
    "host_outputs_health",
    "NO_HOST",
]

GENERATION_GOLDEN_REL = Path("_system") / "eval" / "golden-generation.yaml"
NO_HOST = "—"
STATUS_OK, STATUS_FAIL, STATUS_NODATA = "ok", "fail", "nodata"
TRACE_OUTPUT, TRACE_JOURNAL = "output", "journal"
# Окно журнала для задач со следом «журнал» (поручение): вызовы хоста после первого
# ``pult_assignments`` - это и есть прогон задачи.
JOURNAL_WINDOW_MIN = 30
JOURNAL_PATH = "журнал метрик"
_MAX_HISTORY = 500

# Русские и английские ключи - один смысл (К. пишет по-русски, код - по-английски).
_TASK_KEYS = {
    "id": "id", "тип": "type", "type": "type", "задача": "task", "task": "task",
    "след": "trace", "trace": "trace", "ожидание": "expect", "expect": "expect",
    "источник": "source", "source": "source", "заметка": "note", "note": "note",
}
_EXPECT_KEYS = {
    "кейс": "use_case", "use_case": "use_case", "клиент": "client_id", "client_id": "client_id",
    "источников": "sources_min", "sources_min": "sources_min", "хаб": "hub", "hub": "hub",
    "вызовов": "calls_max", "engine_calls": "calls_max", "стиль": "style", "style": "style",
    "модель": "model", "model": "model", "формат": "format", "format": "format",
    "вызвано": "called", "called": "called", "не_вызвано": "not_called",
    "not_called": "not_called",
}
_SOURCES = {"проверено": True, "verified": True, "гипотеза": False, "hypothesis": False}
_TRACES = {"выход": TRACE_OUTPUT, "output": TRACE_OUTPUT,
           "журнал": TRACE_JOURNAL, "journal": TRACE_JOURNAL}
_FORMATS = {"docx": "docx", "нет": "none", "none": "none", "md": "none"}
_MODEL_WORDS = {"объявлена", "declared", "известна", "known"}
_STYLE_DENSITY = {"в-норме", "в норме", "ok", "norm"}


class GenerationGoldenError(GoldenError):
    """Набор не прочитан/не валиден. ``code`` - машинный: ``golden_unreadable`` |
    ``golden_bad_yaml`` | ``golden_empty`` | ``golden_invalid`` (все замечания - в тексте)."""

    def __init__(self, message: str, code: str = "golden_invalid") -> None:
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class GenTask:
    id: str
    type: str
    task: str
    expect: dict[str, Any]
    verified: bool
    trace: str = TRACE_OUTPUT
    note: str = ""


@dataclass(frozen=True)
class CheckResult:
    name: str
    status: str  # ok | fail | nodata
    detail: str = ""

    @property
    def mark(self) -> str:
        return {STATUS_OK: "ok", STATUS_FAIL: "✗"}.get(self.status, "—")


@dataclass
class RunResult:
    task_id: str
    host: str
    version: str
    model: str
    model_source: str
    engine_calls: int | None
    created: str
    path: str
    checks: list[CheckResult] = field(default_factory=list)
    verified: bool = True

    @property
    def ok(self) -> bool:
        return bool(self.checks) and all(c.status == STATUS_OK for c in self.checks)

    @property
    def checks_ok(self) -> int:
        return sum(1 for c in self.checks if c.status == STATUS_OK)


@dataclass
class GenerationReport:
    tasks: list[GenTask]
    runs: list[RunResult]
    scanned: int  # папок выходов просмотрено
    unmatched: int  # без соответствия задаче - не golden-прогон, в таблицу не идут
    host_filter: str | None = None
    since: str | None = None
    by_host: list[dict[str, Any]] = field(default_factory=list)  # все выходы по хостам
    problems: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Канон                                                                       #
# --------------------------------------------------------------------------- #
def generation_golden_path(vault: Path | None = None) -> Path:
    if vault is None:
        from core.config import default_vault_path

        vault = default_vault_path()
    return Path(vault) / GENERATION_GOLDEN_REL


def _str_list(value: Any) -> list[str] | None:
    if isinstance(value, str):
        value = [value]
    if isinstance(value, list) and all(isinstance(x, str) and x.strip() for x in value):
        return [x.strip() for x in value]
    return None


def _norm_expect(raw: Any, where: str, problems: list[str]) -> dict[str, Any]:
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        problems.append(f"{where}: ожидание - не словарь")
        return {}
    out: dict[str, Any] = {}
    for key, value in raw.items():
        canon = _EXPECT_KEYS.get(str(key).strip())
        if canon is None:
            problems.append(f"{where}: неизвестная проверка {key!r}")
            continue
        if canon in ("use_case", "client_id", "hub"):
            if not isinstance(value, str) or not value.strip():
                problems.append(f"{where}: {key} - нужна непустая строка")
                continue
            out[canon] = value.strip()
        elif canon in ("sources_min", "calls_max"):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                problems.append(f"{where}: {key} - нужно целое >= 0")
                continue
            out[canon] = value
        elif canon == "style":
            if not isinstance(value, dict):
                problems.append(f"{where}: стиль - нужен словарь {{запрет: 0, плотность: в-норме}}")
                continue
            style: dict[str, Any] = {}
            for sk, sv in value.items():
                skey = str(sk).strip()
                if skey in ("запрет", "ban"):
                    if sv != 0 or isinstance(sv, bool):
                        problems.append(f"{where}: стиль.запрет - допустим только 0")
                    style["ban"] = 0
                elif skey in ("плотность", "density"):
                    if str(sv).strip().lower() not in _STYLE_DENSITY:
                        problems.append(f"{where}: стиль.плотность - допустимо «в-норме»")
                    style["density"] = "norm"
                else:
                    problems.append(f"{where}: стиль.{skey} - неизвестный ключ")
            out["style"] = style
        elif canon == "model":
            if str(value).strip().lower() not in _MODEL_WORDS:
                problems.append(f"{where}: модель - допустимо «объявлена»")
                continue
            out["model"] = "known"
        elif canon == "format":
            fmt = _FORMATS.get(str(value).strip().lower())
            if fmt is None:
                problems.append(f"{where}: формат {value!r} - нужно docx|нет")
                continue
            out["format"] = fmt
        else:  # called / not_called
            names = _str_list(value)
            if names is None:
                problems.append(f"{where}: {key} - нужен список имен инструментов")
                continue
            out[canon] = names
    return out


def _norm_task(raw: Any, index: int, problems: list[str]) -> GenTask | None:
    if not isinstance(raw, dict):
        problems.append(f"задача #{index}: не словарь")
        return None
    item: dict[str, Any] = {}
    for key, value in raw.items():
        canon = _TASK_KEYS.get(str(key).strip())
        if canon is None:
            problems.append(f"задача #{index}: неизвестный ключ {key!r}")
        else:
            item[canon] = value
    tid = str(item.get("id") or "").strip()
    where = f"задача {tid or '#' + str(index)}"
    if not tid:
        problems.append(f"{where}: нет id")
    task = " ".join(str(item.get("task") or "").split())
    if not task:
        problems.append(f"{where}: нет задачи (дословной фразы для хоста)")
    source = str(item.get("source") or "").strip().lower()
    if source not in _SOURCES:
        problems.append(f"{where}: источник {source!r} - нужно проверено|гипотеза")
    trace = _TRACES.get(str(item.get("trace") or "выход").strip().lower())
    if trace is None:
        problems.append(f"{where}: след {item.get('trace')!r} - нужно выход|журнал")
    expect = _norm_expect(item.get("expect"), where, problems)
    if not expect:
        problems.append(f"{where}: пустое ожидание - нечего проверять")
    if trace == TRACE_JOURNAL and not ({"called", "not_called", "calls_max"} & set(expect)):
        problems.append(f"{where}: след «журнал» - нужны вызвано/не_вызвано/вызовов")
    if trace == TRACE_OUTPUT and ({"called", "not_called"} & set(expect)):
        problems.append(f"{where}: вызвано/не_вызвано - только для следа «журнал»")
    if not tid or not task:
        return None
    return GenTask(
        id=tid, type=str(item.get("type") or "").strip(), task=task, expect=expect,
        verified=_SOURCES.get(source, True), trace=trace or TRACE_OUTPUT,
        note=str(item.get("note") or "").strip(),
    )


def load_generation_golden(path: Path | None = None) -> list[GenTask]:
    """Прочитать канон задач генерации; все проблемы - одним :class:`GenerationGoldenError`."""
    target = Path(path) if path is not None else generation_golden_path()
    try:
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    except OSError as exc:
        raise GenerationGoldenError(
            f"золотые задачи генерации не прочитаны: {target}: {exc}", "golden_unreadable"
        ) from exc
    except yaml.YAMLError as exc:
        raise GenerationGoldenError(
            f"золотые задачи генерации: невалидный YAML ({target}): {exc}", "golden_bad_yaml"
        ) from exc
    items = data.get("tasks") if isinstance(data, dict) else data
    if not isinstance(items, list) or not items:
        raise GenerationGoldenError(
            f"золотые задачи генерации: пусто или нет списка tasks: {target}", "golden_empty"
        )
    problems: list[str] = []
    tasks: list[GenTask] = []
    for i, raw in enumerate(items, start=1):
        task = _norm_task(raw, i, problems)
        if task is not None:
            tasks.append(task)
    ids = [str(r.get("id") or "").strip() for r in items if isinstance(r, dict)]
    ids = [i for i in ids if i]
    problems.extend(f"дубль id {i}" for i in sorted({i for i in ids if ids.count(i) > 1}))
    if problems:
        raise GenerationGoldenError("золотые задачи генерации: " + "; ".join(problems))
    return tasks


# --------------------------------------------------------------------------- #
# Чтение выходов                                                              #
# --------------------------------------------------------------------------- #
_FM_RE = re.compile(r"\A---\s*\n.*?\n---\s*\n?", re.DOTALL)
_WIKI_RE = re.compile(r"\[\[([^\]|#]+)(?:[|#][^\]]*)?\]\]")
_FILES_HEADING = "## Файлы"


def _norm(text: str) -> str:
    return " ".join(unicodedata.normalize("NFC", text or "").casefold().split())


def _body(text: str) -> str:
    return _FM_RE.sub("", text, count=1)


def _read(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return None


def _frontmatter(text: str) -> dict:
    m = _FM_RE.match(text or "")
    if not m:
        return {}
    try:
        data = yaml.safe_load(m.group(0).strip().strip("-"))
    except yaml.YAMLError:
        return {}
    return data if isinstance(data, dict) else {}


def _source_rows(text: str | None) -> list[list[str]]:
    """Строки данных таблицы ``sources.md`` (без шапки, разделителя и «(none)»)."""
    rows: list[list[str]] = []
    for line in (text or "").splitlines():
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if not cells or set("".join(cells)) <= set("-: "):
            continue
        # PROV-SESSION-1: поиски сессии - кандидаты, не источники (см. ``core.provenance``)
        if cells[0] in ("note_id", "origin", "search") or cells[0].startswith("(none"):
            continue
        rows.append(cells)
    return rows


def _delivered_docx(meta: dict) -> bool:
    """DELIVER-2 п.5: в ``meta.yaml: delivered`` есть запись формата docx (в папке клиента или в
    папке выхода) - первичный источник проверки «формат»: секция «## Файлы» перерисовывается и
    раньше терялась при повторном сохранении, запись меты - нет."""
    from core.output import delivered_records

    return any(str(r.get("format") or "").lower() == "docx" for r in delivered_records(meta))


def _files_docx(output_text: str, folder: Path) -> bool:
    if any(p.suffix.lower() == ".docx" for p in folder.glob("*.docx")):
        return True
    body = _body(output_text)
    if _FILES_HEADING not in body:
        return False
    section = body.split(_FILES_HEADING, 1)[1].split("\n## ", 1)[0]
    return ".docx" in section.casefold()


@dataclass
class _Output:
    path: Path
    meta: dict
    created: str
    host: str
    version: str
    model: str
    model_source: str
    engine_calls: int | None

    @property
    def title(self) -> str:
        return str(self.meta.get("title") or "")

    @property
    def is_run(self) -> bool:
        """EVAL-HYGIENE-1: прогон eval/selftest (``meta.purpose != work``)."""
        from core.purpose import is_quarantined

        return is_quarantined(self.meta)


def _load_output(folder: Path) -> _Output | None:
    from core.output import model_source_of, read_meta

    meta = read_meta(folder / "meta.yaml")
    if not meta:
        return None
    raw_host = meta.get("host")
    host: dict = raw_host if isinstance(raw_host, dict) else {}
    calls = meta.get("engine_calls")
    return _Output(
        path=folder, meta=meta, created=str(meta.get("created") or ""),
        host=str(host.get("name") or "").strip() or NO_HOST,
        version=str(host.get("version") or "").strip(),
        model=str(meta.get("model") or "").strip(), model_source=model_source_of(meta),
        engine_calls=calls if isinstance(calls, int) and not isinstance(calls, bool) else None,
    )


def _iter_outputs(vault: Path | None) -> list[_Output]:
    from core.config import outputs_path

    root = outputs_path(vault)
    out: list[_Output] = []
    try:
        folders = sorted(p for month in root.iterdir() if month.is_dir()
                         for p in month.iterdir() if p.is_dir())
    except OSError:
        return out
    for folder in folders:
        item = _load_output(folder)
        if item is not None:
            out.append(item)
    return out


def _created_dt(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _host_match(host: str, wanted: str | None) -> bool:
    return wanted is None or _norm(wanted) in _norm(host)


def _since_ok(created: str, since: str | None) -> bool:
    if not since:
        return True
    return created[:10] >= since  # ISO-даты сравниваются как строки


_TRAIL_PUNCT = ".!…"


def _phrase(text: str) -> str:
    """Фраза задачи для сопоставления: нормализация + без конечной точки.

    29.10 (g1 в Kimi): К. дописал к фразе «, в папку клиента» - фраза с точкой на конце перестала
    быть подстрокой `[Task]`, хотя задача та же. Конечная пунктуация к смыслу не относится; хвост
    после фразы допустим (фраза - префикс/подстрока постановки), правка внутри фразы - нет."""
    return _norm(text).rstrip(_TRAIL_PUNCT).strip()


def task_matches_text(task: GenTask, texts: Iterable[str], *, title: str = "") -> bool:
    """Постановка (любой из ``texts``) содержит фразу задачи либо ``title`` равен ей.

    ЕДИНАЯ функция сопоставления «выход ↔ задача» (EVAL-HYGIENE-1): ею же движок при
    ``output_begin`` решает, что выход - прогон eval (``core.purpose``), и ею eval-раннер
    находит прогон постфактум. Две копии разошлись бы на правке канона."""
    phrase = _phrase(task.task)
    if any(phrase and phrase in _norm(c) for c in texts):
        return True
    return _phrase(title) == phrase  # запасной путь: заголовок выхода = фраза задачи


def _matches_task(task: GenTask, out: _Output) -> bool:
    candidates = [str(out.meta.get("task") or "")]
    prompt = _read(out.path / "prompt.md")
    if prompt:
        candidates.append(_body(prompt))
    return task_matches_text(task, candidates, title=out.title)


# --------------------------------------------------------------------------- #
# Проверки                                                                    #
# --------------------------------------------------------------------------- #
def _check_output(task: GenTask, out: _Output) -> list[CheckResult]:
    exp = task.expect
    meta = out.meta
    res: list[CheckResult] = []
    sources_text = _read(out.path / "sources.md")
    output_text = _read(out.path / "output.md")
    rows = _source_rows(sources_text)

    if "use_case" in exp:
        got = str(meta.get("use_case") or "")
        if not got:
            res.append(CheckResult("кейс", STATUS_NODATA, "в мете нет use_case (ad-hoc)"))
        else:
            res.append(CheckResult("кейс", STATUS_OK if got == exp["use_case"] else STATUS_FAIL,
                                   got))
    if "client_id" in exp:
        raw_params = meta.get("params")
        params: dict = raw_params if isinstance(raw_params, dict) else {}
        got = str(params.get("client_id") or "")
        if not got:
            res.append(CheckResult("клиент", STATUS_NODATA, "в мете нет params.client_id"))
        else:
            res.append(CheckResult("клиент", STATUS_OK if got == exp["client_id"] else STATUS_FAIL,
                                   got))
    if "sources_min" in exp:
        if sources_text is None:
            res.append(CheckResult("источники", STATUS_NODATA, "нет sources.md"))
        else:
            n = len(rows)
            res.append(CheckResult("источники", STATUS_OK if n >= exp["sources_min"]
                                   else STATUS_FAIL, f"{n} (нужно ≥ {exp['sources_min']})"))
    if "hub" in exp:
        hub = exp["hub"]
        if sources_text is None and output_text is None:
            res.append(CheckResult("хаб", STATUS_NODATA, "нет sources.md и output.md"))
        else:
            in_sources = any(hub in cell for r in rows for cell in r)
            wiki = {m.strip() for m in _WIKI_RE.findall(_body(output_text or ""))}
            fm_wiki = {
                str(x) for k in ("hubs", "related") for x in
                (_frontmatter(output_text or "").get(k) or []) if isinstance(x, str)
            }
            found = in_sources or hub in wiki or hub in fm_wiki
            res.append(CheckResult("хаб", STATUS_OK if found else STATUS_FAIL,
                                   hub if found else f"{hub} не найден среди источников"))
    if "calls_max" in exp:
        if out.engine_calls is None:
            res.append(CheckResult("вызовов", STATUS_NODATA, "в мете нет engine_calls"))
        else:
            res.append(CheckResult("вызовов", STATUS_OK if out.engine_calls <= exp["calls_max"]
                                   else STATUS_FAIL, f"{out.engine_calls} (≤ {exp['calls_max']})"))
    if "style" in exp:
        res.append(_check_style(exp["style"], output_text))
    if "model" in exp:
        known = out.model_source != "unknown"
        res.append(CheckResult("модель", STATUS_OK if known else STATUS_FAIL,
                               f"{out.model or '—'} ({out.model_source})"))
    if "format" in exp:
        delivered_docx = _delivered_docx(out.meta)
        if output_text is None and not delivered_docx:
            res.append(CheckResult("формат", STATUS_NODATA, "нет output.md"))
        else:
            # DELIVER-2 п.5: docx собран, если он есть в ``delivered`` меты; «## Файлы» и docx в
            # папке выхода - вторично (выходы до DELIVER-2 доставку в мету не писали)
            has = delivered_docx or _files_docx(output_text or "", out.path)
            want = exp["format"] == "docx"
            detail = ("docx собран (delivered)" if delivered_docx
                      else "docx собран" if has else "docx нет")
            res.append(CheckResult("формат", STATUS_OK if has == want else STATUS_FAIL, detail))
    return res


def _check_style(spec: dict[str, Any], output_text: str | None) -> CheckResult:
    if output_text is None:
        return CheckResult("стиль", STATUS_NODATA, "нет output.md")
    from core.style_markers import check_text

    report = check_text(_body(output_text))
    if report.unavailable:
        return CheckResult("стиль", STATUS_NODATA,
                           f"канон маркеров недоступен: {report.unavailable}")
    bad: list[str] = []
    if "ban" in spec and report.ban:
        bad.append(f"запрет ×{sum(int(h.get('count', 1)) for h in report.ban)}")
    if "density" in spec and report.density:
        dens = report.density
        bad.append(f"плотность {dens.get('per_1000_words')} > {dens.get('threshold')}")
    return CheckResult("стиль", STATUS_FAIL if bad else STATUS_OK, "; ".join(bad) or "чисто")


def _journal_runs(
    task: GenTask, since: str | None, host_filter: str | None, events: list[dict[str, Any]]
) -> list[RunResult]:
    """Задача со следом «журнал»: по хосту - окно вызовов от первого вызова ``called[0]``."""
    from core.metrics import UI_PREFIX, _parse_ts

    exp = task.expect
    anchor = (exp.get("called") or [None])[0]
    by_host: dict[str, list[dict[str, Any]]] = {}
    for e in events:
        if str(e.get("tool") or "").startswith(UI_PREFIX):
            continue
        if str(e.get("surface") or "") in ("webpult", "cli"):
            continue  # веб-пульт и CLI - не хост с чат-моделью (их вызовы - не прогон задачи)
        host = str(e.get("host") or "").strip() or NO_HOST
        if not _host_match(host, host_filter) or not _since_ok(str(e.get("ts") or ""), since):
            continue
        by_host.setdefault(host, []).append(e)
    runs: list[RunResult] = []
    for host, evs in sorted(by_host.items()):
        evs.sort(key=lambda e: str(e.get("ts") or ""))
        starts = [e for e in evs if anchor is None or e.get("tool") == anchor]
        if not starts:
            continue
        first = starts[-1]  # последний прогон хоста
        t0 = _parse_ts(first.get("ts"))
        if t0 is None:
            continue
        window = [e for e in evs
                  if (t := _parse_ts(e.get("ts"))) is not None
                  and t0 <= t <= t0 + timedelta(minutes=JOURNAL_WINDOW_MIN)]
        tools = {str(e.get("tool") or "") for e in window}
        checks: list[CheckResult] = []
        if exp.get("called"):
            missing = [t for t in exp["called"] if t not in tools]
            checks.append(CheckResult("вызвано", STATUS_FAIL if missing else STATUS_OK,
                                      ("нет: " + ", ".join(missing)) if missing
                                      else ", ".join(exp["called"])))
        if exp.get("not_called"):
            extra = [t for t in exp["not_called"] if t in tools]
            checks.append(CheckResult("не_вызвано", STATUS_FAIL if extra else STATUS_OK,
                                      ("лишние: " + ", ".join(extra)) if extra else "чисто"))
        if "calls_max" in exp:
            n = len(window)
            checks.append(CheckResult("вызовов", STATUS_OK if n <= exp["calls_max"]
                                      else STATUS_FAIL, f"{n} (≤ {exp['calls_max']})"))
        runs.append(RunResult(
            task_id=task.id, host=host, version="", model="", model_source="unknown",
            engine_calls=len(window), created=str(first.get("ts") or ""), path=JOURNAL_PATH,
            checks=checks, verified=task.verified,
        ))
    return runs


def evaluate_generation(
    *,
    vault: Path | None = None,
    golden: Path | None = None,
    host: str | None = None,
    since: str | None = None,
    events_path: Path | None = None,
) -> GenerationReport:
    """Прогон оценщика: канон + выходы (+ журнал метрик для задач «журнал») → отчет.

    ``host`` - подстрока имени хоста (без регистра); ``since`` - ``YYYY-MM-DD`` (по ``created``
    выхода/ts события). На одну пару «задача × хост» в таблицу идет ПОСЛЕДНИЙ выход.
    """
    tasks = load_generation_golden(golden if golden is not None else generation_golden_path(vault))
    outputs = _iter_outputs(vault)
    matched_paths: set[Path] = set()
    best: dict[tuple[str, str], tuple[str, RunResult]] = {}
    for out in outputs:
        if not _host_match(out.host, host) or not _since_ok(out.created, since):
            continue
        for task in tasks:
            if task.trace != TRACE_OUTPUT or not _matches_task(task, out):
                continue
            matched_paths.add(out.path)
            run = RunResult(
                task_id=task.id, host=out.host, version=out.version, model=out.model,
                model_source=out.model_source, engine_calls=out.engine_calls,
                created=out.created, path=str(out.path), checks=_check_output(task, out),
                verified=task.verified,
            )
            key = (task.id, out.host)
            if key not in best or out.created >= best[key][0]:
                best[key] = (out.created, run)
    runs = [r for _, r in best.values()]
    problems: list[str] = []
    journal_tasks = [t for t in tasks if t.trace == TRACE_JOURNAL]
    if journal_tasks:
        from core.metrics import read_events

        try:
            events = [e for e in read_events(path=events_path) if e.get("kind") == "tool_call"]
        except Exception as exc:  # noqa: BLE001 - журнал вторичен: причина в отчет
            events, problems = [], [f"журнал метрик не прочитан: {exc}"[:200]]
        for task in journal_tasks:
            runs.extend(_journal_runs(task, since, host, events))
    order = {t.id: i for i, t in enumerate(tasks)}
    runs.sort(key=lambda r: (order.get(r.task_id, 99), r.host))
    return GenerationReport(
        tasks=tasks, runs=runs, scanned=len(outputs),
        unmatched=sum(1 for o in outputs if o.path not in matched_paths
                      and _host_match(o.host, host) and _since_ok(o.created, since)),
        host_filter=host, since=since,
        by_host=_by_host(outputs, host=host, since=since), problems=problems,
    )


def _by_host(
    outputs: list[_Output], *, host: str | None = None, since: str | None = None,
    days: int | None = None, now: datetime | None = None,
) -> list[dict[str, Any]]:
    cutoff = (now or datetime.now()) - timedelta(days=days) if days else None
    agg: dict[str, dict[str, Any]] = {}
    for o in outputs:
        if not _host_match(o.host, host) or not _since_ok(o.created, since):
            continue
        if cutoff is not None:
            dt = _created_dt(o.created)
            if dt is None or dt < cutoff:
                continue
        row = agg.setdefault(o.host, {"host": o.host, "count": 0, "model_known": 0,
                                      "calls_known": 0, "last": ""})
        row["count"] += 1
        row["model_known"] += o.model_source != "unknown"
        row["calls_known"] += o.engine_calls is not None
        row["last"] = max(row["last"], o.created)
    rows = sorted(agg.values(), key=lambda r: (-r["count"], r["host"]))
    for r in rows:
        r["model_share"] = round(r["model_known"] / r["count"], 2) if r["count"] else None
    return rows


def outputs_by_host(
    days: int = 30, *, vault: Path | None = None, now: datetime | None = None,
    include_runs: bool = False,
) -> dict[str, Any]:
    """Выходы за ``days`` дн по хостам: ``{days, total, hosts: [{host, count, model_known,
    model_share, last}], no_host}``. ``host: "—"`` - выход без ``host`` в мете (старый или
    дефект гигиены); ``model_share`` - доля с ``model_source ≠ unknown``. Прогоны eval/selftest
    (``purpose != work``) не считаются (EVAL-HYGIENE-1; ``include_runs=True`` - со всеми).
    Read-only."""
    outputs = [o for o in _iter_outputs(vault) if include_runs or not o.is_run]
    rows = _by_host(outputs, days=max(1, int(days)), now=now)
    return {
        "days": max(1, int(days)), "total": sum(r["count"] for r in rows), "hosts": rows,
        "no_host": sum(r["count"] for r in rows if r["host"] == NO_HOST),
    }


def host_outputs_health(
    seen_hosts: list[str] | None = None, *, days: int = 30, vault: Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Сверка «хост в телеметрии ↔ выходы с этим хостом» (доктор «Хосты: выходы»).

    ``adopted_since`` - ``created`` самого раннего выхода с ``host`` в мете (с этого момента
    движок штампует хост); ``missing`` - выходы окна БЕЗ ``host`` созданные после этого момента:
    дефект гигиены (старые папки без поля - не дефект, их не бэкфиллим). ``silent`` -
    хосты из ``seen_hosts`` (телеметрия), у которых за окно нет ни одного выхода - справка:
    хост ходит в DT, но результат в vault не возвращает (читает, а не пишет, либо контур выхода
    не соблюден). Нет выходов с ``host`` - ``adopted_since: None``, дефектов нет."""
    outputs = _iter_outputs(vault)
    stamped = sorted(o.created for o in outputs if o.host != NO_HOST and o.created)
    adopted = stamped[0] if stamped else None
    cutoff = (now or datetime.now()) - timedelta(days=max(1, int(days)))
    window = [o for o in outputs if (dt := _created_dt(o.created)) is not None and dt >= cutoff]
    missing = [o.path.name for o in window
               if o.host == NO_HOST and adopted is not None and o.created >= adopted]
    present = {o.host for o in window}
    silent = sorted(h for h in (seen_hosts or []) if h not in present)
    return {"days": max(1, int(days)), "total": len(window), "adopted_since": adopted,
            "missing": missing, "silent": silent, "hosts": sorted(present - {NO_HOST})}


# --------------------------------------------------------------------------- #
# Вывод                                                                       #
# --------------------------------------------------------------------------- #
def _host_cell(host: str, version: str = "") -> str:
    """Колонка «хост»: ``имя/версия``; имя SDK по умолчанию - ``mcp/0.1.0 (аноним)``
    (клиент не назвал себя - KIMI-INSTALL-2); без хоста - прочерк."""
    from core.host import is_anonymous

    label = f"{host}/{version}" if version else host
    return f"{label} (аноним)" if host != NO_HOST and is_anonymous(host) else label


def _ver(run: RunResult) -> str:
    return _host_cell(run.host, run.version)


def format_generation_table(report: GenerationReport) -> str:
    """Таблица «задача × хост»: проверки ok/✗/—, engine_calls, модель, дата + выходы по хостам."""
    lines: list[str] = []
    flt = "".join([f" хост~{report.host_filter}" if report.host_filter else "",
                   f" с {report.since}" if report.since else ""])
    lines.append(f"Золотые задачи генерации: {len(report.tasks)} задач, "
                 f"просмотрено выходов {report.scanned}{',' + flt if flt else ''}; "
                 f"без соответствия задаче {report.unmatched} (не golden-прогон).")
    lines.append("")
    if report.runs:
        names = ["кейс", "клиент", "источники", "хаб", "вызовов", "стиль", "модель", "формат",
                 "вызвано", "не_вызвано"]
        used = [n for n in names if any(c.name == n for r in report.runs for c in r.checks)]
        header = ["задача", "хост", *used, "calls", "модель", "дата", "итог"]
        rows = []
        for r in report.runs:
            cell = {c.name: c.mark for c in r.checks}
            model = f"{r.model or '—'} ({r.model_source})" if r.path != JOURNAL_PATH else "—"
            rows.append([
                r.task_id + ("" if r.verified else "?"), _ver(r),
                *[cell.get(n, "·") for n in used],
                "—" if r.engine_calls is None else str(r.engine_calls), model,
                r.created[:16].replace("T", " "), "OK" if r.ok else "✗",
            ])
        lines.extend(_grid(header, rows))
        lines.append("")
        ok = {t.id for t in report.tasks if t.verified
              and any(r.task_id == t.id and r.ok for r in report.runs)}
        lines.append(f"задач ok хотя бы на одном хосте: {len(ok)} из "
                     f"{sum(1 for t in report.tasks if t.verified)} проверенных "
                     "(гипотезы помечены «?» и в счет не идут).")
        lines.append("«—» нет данных (старый выход без поля), «·» проверка не применяется; "
                     "итог OK = все применимые проверки ok.")
    else:
        lines.append("Прогонов золотых задач нет: ни один выход не соответствует дословной "
                     "фразе задачи (и нет вызовов в журнале).")
        lines.append("Задачи для хоста: " + "; ".join(f"{t.id} {t.type}" for t in report.tasks))
    lines.append("")
    lines.append("Выходы по хостам (все, не только golden):")
    if report.by_host:
        lines.extend(_grid(
            ["хост", "выходов", "модель известна", "engine_calls есть", "последний"],
            [[_host_cell(r["host"]), str(r["count"]),
              f"{r['model_known']}/{r['count']}", f"{r['calls_known']}/{r['count']}",
              r["last"][:10]] for r in report.by_host],
        ))
    else:
        lines.append("  (выходов нет)")
    for p in report.problems:
        lines.append(f"! {p}")
    return "\n".join(lines)


def _grid(header: list[str], rows: list[list[str]]) -> list[str]:
    widths = [max(len(header[i]), *(len(r[i]) for r in rows)) for i in range(len(header))]

    def fmt(cells: list[str]) -> str:
        return "  ".join(c.ljust(widths[i]) for i, c in enumerate(cells)).rstrip()

    return [fmt(header), fmt(["-" * w for w in widths]), *[fmt(r) for r in rows]]


def generation_json(report: GenerationReport) -> dict[str, Any]:
    return {
        "tasks": [{"id": t.id, "type": t.type, "verified": t.verified, "trace": t.trace}
                  for t in report.tasks],
        "scanned": report.scanned, "unmatched": report.unmatched,
        "host_filter": report.host_filter, "since": report.since,
        "runs": [{
            "task": r.task_id, "host": r.host, "version": r.version, "model": r.model or None,
            "model_source": r.model_source, "engine_calls": r.engine_calls,
            "created": r.created, "path": r.path, "ok": r.ok, "verified": r.verified,
            "checks": [{"name": c.name, "status": c.status, "detail": c.detail}
                       for c in r.checks],
        } for r in report.runs],
        "by_host": report.by_host, "problems": report.problems,
    }


# --------------------------------------------------------------------------- #
# История                                                                     #
# --------------------------------------------------------------------------- #
def generation_history_path() -> Path:
    """``.derived/eval/generation.jsonl`` (корень - ``derived_root``: песочница видна и тестам)."""
    from core.config import derived_root

    return derived_root() / "eval" / "generation.jsonl"


def history_points(
    report: GenerationReport, *, now: datetime | None = None
) -> list[dict[str, Any]]:
    """Точка на хост: ``{ts, host, model, tasks_total, matched, tasks_ok, checks_ok,
    checks_total, score, per_task}``. ``score`` = задач ok / проверенных задач набора."""
    stamp = (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ")
    verified = [t for t in report.tasks if t.verified]
    points: list[dict[str, Any]] = []
    for host in sorted({r.host for r in report.runs}):
        mine = [r for r in report.runs if r.host == host]
        models = sorted({r.model for r in mine if r.model})
        ok_ids = {r.task_id for r in mine if r.ok and r.verified}
        points.append({
            "ts": stamp, "host": host, "model": ", ".join(models) or None,
            "tasks_total": len(verified), "matched": len(mine), "tasks_ok": len(ok_ids),
            "checks_ok": sum(r.checks_ok for r in mine),
            "checks_total": sum(len(r.checks) for r in mine),
            "score": round(len(ok_ids) / len(verified), 2) if verified else None,
            "per_task": {r.task_id: r.ok for r in mine},
        })
    return points


def append_generation_history(
    report: GenerationReport, path: Path | None = None, *, now: datetime | None = None
) -> tuple[Path, int]:
    """Дописать точки (по хосту) в историю. Сбой записи - наружу. Нет прогонов - ничего."""
    target = Path(path) if path is not None else generation_history_path()
    points = history_points(report, now=now)
    if not points:
        return target, 0
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as fh:
        for p in points:
            fh.write(json.dumps(p, ensure_ascii=False) + "\n")
    return target, len(points)


def read_generation_history(path: Path | None = None) -> list[dict[str, Any]]:
    """Точки истории (старые → новые); нет файла/битые строки → меньше."""
    target = Path(path) if path is not None else generation_history_path()
    try:
        lines = target.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out: list[dict[str, Any]] = []
    for line in lines[-_MAX_HISTORY:]:
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(rec, dict) and rec.get("host"):
            out.append(rec)
    return out


def generation_status(points: int = 14, *, path: Path | None = None) -> dict[str, Any]:
    """Для виджета «Качество выдачи» (вторая строка): ``{hosts: {<host>: {last_ts, model,
    tasks_ok, tasks_total, matched, score, history: [{ts, score}]}}}``. Нет истории → пустой
    ``hosts`` (это не ошибка: ручной прогон на хосте еще не делали)."""
    n = max(1, min(int(points or 14), 100))
    hosts: dict[str, dict[str, Any]] = {}
    for rec in read_generation_history(path):
        host = str(rec["host"])
        row = hosts.setdefault(host, {"history": []})
        row["history"].append({"ts": rec.get("ts"), "score": rec.get("score")})
        row.update(
            last_ts=rec.get("ts"), model=rec.get("model"), tasks_ok=rec.get("tasks_ok"),
            tasks_total=rec.get("tasks_total"), matched=rec.get("matched"),
            score=rec.get("score"),
        )
    for row in hosts.values():
        row["history"] = row["history"][-n:]
    return {"hosts": hosts}
