"""EVAL-2 п.2 — локальный журнал запросов: сырьё для кандидатов в золотой набор.

Золотой набор (EVAL-1) — снимок аудита; живые провалы поиска в него не попадают. Чтобы набор
рос из употребления, нужно знать, ЧТО К. реально искал и что открывал следом. Эти данные
нигде не оседали: ``metrics.jsonl`` намеренно хранит только имя/исход/мс (privacy-контракт —
ни аргументов, ни ответов).

Поэтому журнал — **отдельный файл и отдельный модуль** (``.derived/eval/queries.jsonl``), а
``metrics.jsonl`` остаётся без аргументов. Две строки событий:

* ``search`` — ``find_notes`` / ``find_latest`` / ``retrieve``:
  ``{ts, event, tool, args: {query|person|domain|corpus|sort|use_case_id}, top_ids[:5], n, ms}``;
* ``open``   — ``read_note`` / ``lift_source`` / ``work_note_preview``:
  ``{ts, event, tool, note_id}``; ``get_facts`` (PROV-SESSION-1) — один вызов, одна запись:
  ``{ts, event, tool, paths: [source_path…≤2×_TOP_N]}`` (пути источников возвращённых фактов,
  без значений и ключей фактов; ``note_id`` нет — кандидатов EVAL-2 запись не касается).

PROV-SESSION-1: журнал — ещё и журнал провенанса выходов (``core.provenance``): каждое событие
несёт ``host`` и, при http-контексте MCP, ``sid`` (первые 8 символов id сессии; без http — поля
нет). Хосты selftest (``core.purpose.is_selftest_host``, ``DT_SELFTEST=1``) в журнал не пишутся;
``read_events`` отфильтровывает их и из старых записей (кандидаты EVAL-2 их не видят).

Что НЕ пишется: тексты ответов, превью, тела заметок, фрагменты чужих писем; всё, что под
NDA-барьером (``core.privacy.any_nda`` по id/пути/source_path), в журнал не попадает — барьер
действует выше (поиск такое не отдаёт), здесь второй замок на случай дыры выше. Всё локально,
наружу журнал не уходит.

Выключатель — ``DT_EVAL_QUERY_LOG=0``. Ретенция — :data:`RETENTION_DAYS` дней, чистка при
записи раз в сутки (маркер-файл рядом). Запись best-effort: журнал наблюдает за движком и не
имеет права его ломать (как ``core.metrics``). Одна точка вызова — ``guarded_tool`` в
``mcp-server/server.py`` (рядом с ``_record_thread_read``).
"""

from __future__ import annotations

import contextlib
import contextvars
import fcntl
import json
import logging
import os
from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import eval_journal_path

logger = logging.getLogger(__name__)

__all__ = [
    "ENV_SWITCH",
    "HEADER_NO_JOURNAL",
    "suppressed",
    "OPEN_TOOLS",
    "RETENTION_DAYS",
    "FACTS_TOOLS",
    "SEARCH_ARGS",
    "SEARCH_TOOLS",
    "enabled",
    "read_events",
    "record_call",
]

# Путь журнала — ``core.config.eval_journal_path()`` (TEST-SANDBOX-1: функция, не константа).

ENV_SWITCH = "DT_EVAL_QUERY_LOG"
RETENTION_DAYS = 90

# PERSONAL-1: мост личного экземпляра шлет рабочему демону ТЕКСТ личной заметки как поисковый
# запрос. Заголовок ``X-DT-No-Journal: 1`` на ``/api/<tool>`` просит не писать этот вызов в журнал
# запросов: иначе личный текст осел бы в рабочем ``eval/queries.jsonl`` (90 дней) и всплыл
# кандидатом в золотой набор на рабочем пульте. Без заголовка поведение журнала прежнее.
HEADER_NO_JOURNAL = "X-DT-No-Journal"
_SUPPRESSED: contextvars.ContextVar[bool] = contextvars.ContextVar(
    "dt_eval_journal_suppressed", default=False)


@contextlib.contextmanager
def suppressed(flag: bool = True) -> Iterator[None]:
    """На время блока (поток вызова инструмента) ``record_call`` ничего не пишет."""
    token = _SUPPRESSED.set(bool(flag) or _SUPPRESSED.get())
    try:
        yield
    finally:
        _SUPPRESSED.reset(token)

SEARCH_TOOLS = frozenset({"find_notes", "find_latest", "retrieve"})
OPEN_TOOLS = frozenset({"read_note", "lift_source", "work_note_preview"})
FACTS_TOOLS = frozenset({"get_facts"})  # PROV-SESSION-1: открытие источников фактов
# Аргументы поиска, которые едут в журнал (ТЗ): остальное (limit/params/client/…) — шум.
SEARCH_ARGS = ("query", "person", "domain", "corpus", "sort", "use_case_id")
_TOP_N = 5
_FACT_PATHS_MAX = _TOP_N * 2


def enabled() -> bool:
    """Журнал включён, если ``DT_EVAL_QUERY_LOG`` не равен ``0``/``false``/``off``/``no``."""
    return os.environ.get(ENV_SWITCH, "1").strip().lower() not in {"0", "false", "off", "no"}


def _ts(now: datetime | None = None) -> str:
    return (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_ts(value: Any) -> datetime | None:
    try:
        return datetime.strptime(str(value), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    except ValueError:
        return None


def _nda(*refs: Any) -> bool:
    from core.privacy import any_nda

    return any_nda(*[str(r) for r in refs if r])


# --------------------------------------------------------------------------- #
# Сбор события из вызова инструмента                                             #
# --------------------------------------------------------------------------- #
def _search_hits(tool: str, result: Any) -> list[tuple[str, tuple[Any, ...]]]:
    """``(note_id, (path…))`` по порядку выдачи; пути нужны только NDA-замку."""
    out: list[tuple[str, tuple[Any, ...]]] = []
    if not isinstance(result, dict):
        return out
    if tool == "find_notes":
        for n in result.get("notes") or []:
            if isinstance(n, dict) and n.get("note_id"):
                out.append((str(n["note_id"]), (n.get("path"), n.get("source_path"))))
    elif tool == "find_latest":
        for f in result.get("families") or []:
            if isinstance(f, dict) and f.get("note_id"):
                out.append((str(f["note_id"]),
                            (f.get("directory"), (f.get("latest") or {}).get("path"))))
    elif tool == "retrieve":
        for hits in (result.get("slices") or {}).values():
            for h in hits or []:
                if isinstance(h, dict) and h.get("note_id"):
                    out.append((str(h["note_id"]), (h.get("source_path"),)))
    return out


def build_event(
    tool: str, bound: dict[str, Any], result: Any, ms: float, *, now: datetime | None = None
) -> dict[str, Any] | None:
    """Событие журнала для вызова инструмента или ``None`` (не наш инструмент / нечего писать).

    ``bound`` — аргументы вызова по ИМЕНАМ параметров (позиционные уже разобраны вызывающим).
    Отказ инструмента (``ok: false``/исключение) в журнал не идёт: ни поиска, ни открытия не
    было, а кандидат из отказа был бы шумом.
    """
    if isinstance(result, dict) and (result.get("ok") is False or result.get("refused")):
        return None
    if tool in SEARCH_TOOLS:
        hits = _search_hits(tool, result)
        safe = [nid for nid, paths in hits if not _nda(nid, *paths)]
        args = {k: bound[k] for k in SEARCH_ARGS if bound.get(k) not in (None, "")}
        if not args:
            return None  # пустой поиск (честная пустота find_notes без аргументов) — не запрос
        return {"ts": _ts(now), "event": "search", "tool": tool, "args": args,
                "top_ids": safe[:_TOP_N], "n": len(safe), "ms": round(ms)}
    if tool in FACTS_TOOLS:
        facts = result.get("facts") if isinstance(result, dict) else result
        fact_paths: list[str] = []
        for f in facts if isinstance(facts, list) else []:
            sp = str(f.get("source_path") or "") if isinstance(f, dict) else ""
            if sp and sp not in fact_paths and not _nda(sp):
                fact_paths.append(sp)
        if not fact_paths:
            return None  # фактов нет - читать нечего, источником это не станет
        return {"ts": _ts(now), "event": "open", "tool": tool,
                "paths": fact_paths[:_FACT_PATHS_MAX]}
    if tool in OPEN_TOOLS:
        ref = bound.get("note_id") or bound.get("path") or bound.get("name")
        if isinstance(result, dict) and result.get("id"):
            ref = result["id"]  # read_note отдаёт канонический id заметки
        if not ref:
            return None
        if isinstance(result, dict) and result.get("found") is False:
            return None
        paths = (bound.get("path"), result.get("path") if isinstance(result, dict) else None)
        if _nda(ref, *paths):
            return None
        return {"ts": _ts(now), "event": "open", "tool": tool, "note_id": str(ref)}
    return None


# --------------------------------------------------------------------------- #
# Запись, ретенция                                                               #
# --------------------------------------------------------------------------- #
@contextlib.contextmanager
def _locked(path: Path) -> Iterator[None]:
    """Эксклюзивная блокировка файла журнала (несколько процессов MCP + чистка)."""
    lock = path.with_suffix(path.suffix + ".lock")
    lock.parent.mkdir(parents=True, exist_ok=True)
    with lock.open("a+") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def prune(path: Path | None = None, *, now: datetime | None = None,
          days: int = RETENTION_DAYS) -> int:
    """Срезать строки старше ``days`` суток (атомарной перезаписью); вернуть число срезанных.

    Нечитаемая/битая строка не срезается молча по возрасту — у неё нет ``ts``, но и пользы нет:
    её выбрасываем (журнал перестраиваемый), счётчик её тоже учитывает.
    """
    target = Path(path) if path is not None else eval_journal_path()
    try:
        lines = target.read_text(encoding="utf-8").splitlines()
    except OSError:
        return 0
    cutoff = (now or datetime.now(UTC)) - timedelta(days=days)
    keep: list[str] = []
    for line in lines:
        try:
            ts = _parse_ts(json.loads(line).get("ts"))
        except (json.JSONDecodeError, AttributeError):
            ts = None
        if ts is not None and ts >= cutoff:
            keep.append(line)
    dropped = len(lines) - len(keep)
    if dropped:
        tmp = target.with_suffix(target.suffix + ".tmp")
        tmp.write_text("\n".join(keep) + ("\n" if keep else ""), encoding="utf-8")
        tmp.replace(target)
    return dropped


def _prune_due(path: Path, now: datetime) -> bool:
    """Раз в сутки: маркер-файл рядом хранит дату последней чистки."""
    marker = path.with_suffix(path.suffix + ".pruned")
    today = now.strftime("%Y-%m-%d")
    try:
        if marker.read_text(encoding="utf-8").strip() == today:
            return False
    except OSError:
        pass
    marker.write_text(today, encoding="utf-8")
    return True


def write_event(event: dict[str, Any], path: Path | None = None,
                *, now: datetime | None = None) -> None:
    target = Path(path) if path is not None else eval_journal_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    stamp = now or datetime.now(UTC)
    with _locked(target):
        if _prune_due(target, stamp):
            prune(target, now=stamp)
        with target.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(event, ensure_ascii=False) + "\n")


def _host_name() -> str:
    from core.host import current_host

    return current_host()["name"]


def _is_selftest(host: Any) -> bool:
    from core.purpose import is_selftest_host, selftest_env

    return selftest_env() or is_selftest_host(str(host or ""))


def record_call(
    tool: str, bound: dict[str, Any], result: Any, ms: float, *, now: datetime | None = None
) -> None:
    """Точка вызова из ``guarded_tool``: событие → журнал. Никогда не бросает."""
    try:
        if not enabled() or tool not in SEARCH_TOOLS | OPEN_TOOLS | FACTS_TOOLS:
            return
        if _SUPPRESSED.get():
            return  # PERSONAL-1: вызов моста личного экземпляра - не журналируется (см. выше)
        host = _host_name()
        if _is_selftest(host):
            return  # PROV-SESSION-1: spike/selftest-хосты - шум, не провенанс и не кандидаты
        event = build_event(tool, bound, result, ms, now=now)
        if event is not None:
            event["host"] = host  # VENDOR-HYGIENE-1 п.3
            from core.host import request_fields

            sid = request_fields().get("sid")
            if sid:
                event["sid"] = sid  # PROV-SESSION-1: http-сессия MCP; у stdio/CLI/пульта поля нет
            write_event(event, now=now)
    except Exception:  # noqa: BLE001 — журнал наблюдает за движком, не ломает его
        logger.debug("eval_journal: запись не удалась", exc_info=True)


# --------------------------------------------------------------------------- #
# Чтение                                                                         #
# --------------------------------------------------------------------------- #
def read_events(
    path: Path | None = None, *, since: datetime | None = None, include_selftest: bool = False
) -> list[dict[str, Any]]:
    """События журнала по возрастанию времени (битые строки пропускаются; нет файла → []).

    Записи хостов selftest (старые, до PROV-SESSION-1) по умолчанию отфильтрованы: в провенанс и в
    кандидаты EVAL-2 им не место. ``DT_SELFTEST`` здесь не смотрим - он про текущий процесс."""
    target = Path(path) if path is not None else eval_journal_path()
    try:
        lines = target.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out: list[dict[str, Any]] = []
    for line in lines:
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(rec, dict) or rec.get("event") not in ("search", "open"):
            continue
        ts = _parse_ts(rec.get("ts"))
        if ts is None or (since is not None and ts < since):
            continue
        if not include_selftest:
            from core.purpose import is_selftest_host

            if is_selftest_host(str(rec.get("host") or "")):
                continue
        out.append(rec)
    out.sort(key=lambda r: str(r["ts"]))
    return out
