"""EVAL-HYGIENE-1 п.2 - карантин доставки прогонов: ``<корень>/_eval/<ГГГГ-ММ>/<папка выхода>/``.

Выход с ``purpose != work`` не имеет права попасть в живую папку клиента: любая доставка
(``save_output(dest|format)``, ``place_download``, ``store_file*``) уходит в ``_eval`` ТОГО ЖЕ
ingest-корня, а в ответ и в ``meta.yaml: delivered`` пишется и факт, и просьба
(``intended_dest``). ``_eval`` - маркер пути того же класса, что ``_nda``
(:func:`core.privacy.is_eval`): файлы под ним не идут в знание, но eval-проверка «delivered docx»
читает ``meta.delivered`` и видит их.

Модуль не пишет файлов: он только пересчитывает адрес (``dest``/``rel_path`` → адрес под
``_eval``); запись, гарды (NDA/containment/sha) - прежний write-слой. NDA-адрес не
перенаправляется: пусть обычный гард откажет по ``nda``, а не спрячется за карантином.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from core.privacy import is_nda

__all__ = [
    "QUARANTINE_DIR",
    "Quarantine",
    "Redirect",
    "annotate",
    "for_output",
    "redirect_dest",
    "redirect_rel",
    "session_hours",
    "session_quarantine",
]

logger = logging.getLogger(__name__)

QUARANTINE_DIR = "_eval"
_SESSION_ENV = "DT_EVAL_SESSION_H"
DEFAULT_SESSION_H = 2.0
_SAFE = re.compile(r"[^\w.-]+", re.UNICODE)


@dataclass(frozen=True)
class Quarantine:
    month: str  # ГГГГ-ММ
    folder: str  # имя папки выхода (или selftest-<хост>)

    @property
    def dir(self) -> str:
        return f"{QUARANTINE_DIR}/{self.month}/{self.folder}"


@dataclass(frozen=True)
class Redirect:
    root_name: str
    dest: str  # куда фактически (каталог под _eval) либо rel_path для store_file
    intended: str  # куда просили: ``<корень>/<адрес>``


def session_hours() -> float:
    try:
        return max(0.1, float(os.environ.get(_SESSION_ENV, "") or DEFAULT_SESSION_H))
    except ValueError:
        return DEFAULT_SESSION_H


def for_output(out_dir: Path) -> Quarantine | None:
    """Карантин выхода: мета папки несет ``purpose != work`` → ``Quarantine``, иначе ``None``."""
    from core.output import read_meta
    from core.purpose import is_quarantined

    out_dir = Path(out_dir)
    if not is_quarantined(read_meta(out_dir / "meta.yaml")):
        return None
    return Quarantine(month=out_dir.parent.name, folder=out_dir.name)


def session_quarantine(
    vault_path: Path | None = None, *, now: datetime | None = None
) -> Quarantine | None:
    """Карантин для инструментов БЕЗ папки выхода (``place_download``/``store_file*``).

    Решение детерминированное, по хосту вызова: тестовый хост (``shim-test``…) или
    ``DT_SELFTEST=1`` → ``selftest-<хост>``; иначе - ПОСЛЕДНИЙ выход этого хоста за окно
    ``DT_EVAL_SESSION_H`` (2 ч), и только если он помечен ``eval``/``selftest`` (после рабочего
    ``output_begin`` доставка снова обычная)."""
    from core.config import outputs_path
    from core.host import current_host
    from core.output import read_meta
    from core.purpose import is_quarantined, is_selftest_host, selftest_env

    now = now or datetime.now()
    host = str(current_host().get("name") or "")
    if is_selftest_host(host) or selftest_env():
        tag = _SAFE.sub("-", host).strip("-") or "host"
        return Quarantine(month=now.strftime("%Y-%m"), folder=f"selftest-{tag}")
    cutoff = now - timedelta(hours=session_hours())
    root = outputs_path(vault_path)
    # Ключ «последний»: ``created`` (секунды) + mtime меты - два ``output_begin`` в одну секунду
    # (тест/быстрый хост) иначе выбирались бы в порядке обхода каталога, а не по времени.
    best: tuple[tuple[str, int], Path, dict] | None = None
    for month in {now.strftime("%Y-%m"), cutoff.strftime("%Y-%m")}:
        month_dir = root / month
        if not month_dir.is_dir():
            continue
        for folder in month_dir.iterdir():
            meta = read_meta(folder / "meta.yaml") if folder.is_dir() else {}
            raw_host = meta.get("host")
            name = str(raw_host.get("name") or "") if isinstance(raw_host, dict) else ""
            created = str(meta.get("created") or "")
            if name != host or not created:
                continue
            try:
                when = datetime.fromisoformat(created)
            except ValueError:
                continue
            if when < cutoff:
                continue
            try:
                written = (folder / "meta.yaml").stat().st_mtime_ns
            except OSError:
                written = 0
            key = (created, written)
            if best is None or key > best[0]:
                best = (key, folder, meta)
    if best is None or not is_quarantined(best[2]):
        return None
    return Quarantine(month=best[1].parent.name, folder=best[1].name)


def _alias_target(dest: str, root_name: str, vault_path: Path | None) -> tuple[str, str]:
    """``dest`` (алиас либо путь) → ``(корень, каталог)`` как их разрешит write-слой."""
    from core.file_ingest.aliases import resolve_alias

    alias = resolve_alias(dest, vault_path)
    if alias is not None:
        return alias.root_name, alias.rel_path
    return root_name, str(dest or "").strip().rstrip("/")


def redirect_dest(
    quarantine: Quarantine | None, dest: str, root_name: str, vault_path: Path | None = None
) -> Redirect | None:
    """Адрес каталога доставки → под ``_eval`` (тот же корень). ``None`` - перенаправлять нечего
    (нет карантина) либо исходный адрес NDA (обычный гард откажет сам)."""
    if quarantine is None:
        return None
    root, base = _alias_target(dest, root_name, vault_path)
    if is_nda(base):
        return None
    return Redirect(root, quarantine.dir, f"{root}/{base}" if base else root)


def redirect_rel(
    quarantine: Quarantine | None, root_name: str, rel_path: str
) -> Redirect | None:
    """Адрес ФАЙЛА (``store_file``) → ``_eval/<месяц>/<папка>/<имя файла>`` в том же корне."""
    if quarantine is None:
        return None
    raw = str(rel_path or "").strip()
    if is_nda(raw) or not raw or Path(raw).is_absolute():
        return None
    name = Path(raw).name
    if not name or name in {".", ".."}:
        return None
    return Redirect(root_name, f"{quarantine.dir}/{name}", f"{root_name}/{raw}")


def annotate(result: Any, redirect: Redirect | None) -> Any:
    """Ответ доставки + ``quarantined: True`` и ``intended_dest`` (только при перенаправлении)."""
    if redirect is not None and isinstance(result, dict) and result.get("ok"):
        result["quarantined"] = True
        result["intended_dest"] = redirect.intended
    return result
