"""EVAL-3 п.3 — качество выдачи как данные для плитки пульта (read-only, из истории прогонов).

Одна сводка из ``.derived/eval/history.jsonl`` (его пишут ``dt_eval``, смоук С-10 и ночной шаг
``eval`` цепочки index): последний прогон, дельта к прошлому, ряд для спарклайна, промахи
последнего прогона и stale, размер очереди кандидатов и возраст канона. Нового прогона и поиска
здесь нет — только чтение (< 50 мс): плитке хватает того, что ``history_record`` уже хранит.

Текстов запросов история не хранит (privacy EVAL-1): тип и формулировку промаха берём из канона
``golden-queries.yaml`` по ``id`` в момент чтения. Канон не читается / запроса в нём больше нет —
промах всё равно показан (id и топ-3), без формулировки.

Принцип 14: сравнения и пороги (дельта, «устарело») считаются ЗДЕСЬ, а не во фронте.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.contract import CODE_NO_RUNS, CODE_STORE_UNAVAILABLE, add_warning

__all__ = ["OUTDATED_DAYS", "eval_status"]

# Прогон старше этого — плитка помечает «устарело» (ночной шаг + запас).
OUTDATED_DAYS = 2.0
_DELTA_METRICS = ("recall5", "hub3", "mrr")
_MAX_POINTS = 60
_MISSES_CAP = 40


def _rerank_view(cur: dict[str, Any] | None) -> dict[str, Any]:
    """RETR-RERANK-1 п.5: значок «реранкер: вкл/выкл» плитки.

    ``enabled``/``semantic_always`` — конфигурация выдачи СЕЙЧАС (env/дефолт процесса пульта);
    ``last_run`` — с какой конфигурацией шёл последний прогон набора (``None`` — точка без поля:
    история до RETR-RERANK-1), чтобы значок не выдавал цифры без реранкера за цифры с ним.
    """
    from core.retrieval import rerank as rr

    out: dict[str, Any] = {
        "enabled": rr.rerank_enabled(), "semantic_always": rr.semantic_always_enabled(),
        "last_run": None,
    }
    if cur is not None and cur.get("rerank") is not None:
        out["last_run"] = {"rerank": bool(cur.get("rerank")),
                           "semantic_always": bool(cur.get("semantic_always"))}
    return out


def _group_view(rec: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for group, info in (rec.get("groups") or {}).items():
        if isinstance(info, dict):
            out[group] = {"metrics": info.get("metrics") or {}, "verified": info.get("verified", 0)}
    return out


def _delta(
    cur: dict[str, Any], prev: dict[str, Any] | None
) -> tuple[dict[str, float | None], str | None]:
    """Δ метрик к прошлому прогону и ``basis`` — по какому срезу сравнили.

    ``all`` — набор не менялся (общий отпечаток тот же); ``work`` — общий сменился (принят
    запрос из употребления), но отпечаток рабочей группы тот же — сравниваем её (рост
    контрольной не должен прятать динамику); иначе дельты нет (``None``, basis ``None``).
    """
    empty: dict[str, float | None] = dict.fromkeys(_DELTA_METRICS)
    if not prev:
        return empty, None
    pairs: tuple[dict[str, Any], dict[str, Any]] | None = None
    basis = None
    if prev.get("golden_hash") == cur.get("golden_hash"):
        pairs, basis = (cur.get("metrics") or {}, prev.get("metrics") or {}), "all"
    else:
        cw = (cur.get("groups") or {}).get("work") or {}
        pw = (prev.get("groups") or {}).get("work")
        if pw is None and "groups" not in prev:  # история до EVAL-2: весь набор был рабочим
            pw = {"hash": prev.get("golden_hash"), "metrics": prev.get("metrics")}
        if pw and cw.get("hash") and cw.get("hash") == pw.get("hash"):
            pairs, basis = (cw.get("metrics") or {}, pw.get("metrics") or {}), "work"
    if pairs is None:
        return empty, None
    out: dict[str, float | None] = {}
    for m in _DELTA_METRICS:
        a, b = pairs[0].get(m), pairs[1].get(m)
        out[m] = round(a - b, 4) if a is not None and b is not None else None
    return out, basis


def _type_view(cur: dict[str, Any], prev: dict[str, Any] | None) -> list[dict[str, Any]]:
    """EVAL-4 п.1: срез последнего прогона по типам запросов + Δ к прошлому прогону.

    Δ — только если состав типа (отпечаток) не менялся; иначе ``None`` («нет данных»). История
    до EVAL-4 без ``by_type`` — пустой список. Диагностика: на красное и ``delta`` не влияет.
    """
    from core.eval import METRICS, type_deltas

    by_type = cur.get("by_type")
    if not isinstance(by_type, dict):
        return []
    from core.eval import TypeStat

    stats = {
        t: TypeStat(info.get("metrics") or {}, info.get("counts") or {},
                    int(info.get("verified") or 0), str(info.get("hash") or ""))
        for t, info in by_type.items() if isinstance(info, dict)
    }
    deltas = type_deltas(stats, (prev or {}).get("by_type"))
    out = []
    for qtype, st in stats.items():
        d = deltas.get(qtype)
        out.append({
            "type": qtype, "n": st.n,
            "metrics": {m: st.metrics.get(m) for m in METRICS if st.metrics.get(m) is not None},
            "delta": {m: v for m, v in (d or {}).items() if v is not None},
            "delta_known": d is not None,
        })
    return out


def _canon_view(
    golden_file: Path | None,
) -> tuple[dict[str, tuple[str, str]], float | None, str | None]:
    """``({id: (тип, формулировка)}, возраст канона в днях, ошибка)``."""
    from core.eval import GoldenError, golden_path, load_golden

    try:
        path = golden_file or golden_path()
        age = (datetime.now(UTC).timestamp() - path.stat().st_mtime) / 86400.0
        queries = load_golden(path)
    except (GoldenError, OSError) as exc:
        return {}, None, str(exc)[:200]
    return {q.id: (q.type, q.label) for q in queries}, round(age, 1), None


def _generation_view(points: int) -> dict[str, Any]:
    try:
        from core.eval_generation import generation_status

        return generation_status(points)
    except Exception:  # noqa: BLE001 — вторая строка не должна ронять плитку
        return {"hosts": {}}


def eval_status(
    points: int = 14,
    *,
    history_path: Path | None = None,
    golden_file: Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Сводка качества выдачи для плитки пульта (см. модуль).

    Пустая история — ``last: None`` и конверт ``no_runs``; канон не прочитался — промахи без
    формулировок + конверт ``store_unavailable``."""
    from core.eval import last_runs, red_text

    n = max(1, min(int(points or 14), _MAX_POINTS))
    runs = last_runs(n + 1, path=history_path, now=now)
    window = runs[-n:]
    labels, canon_age, canon_error = _canon_view(golden_file)
    queue_n = 0
    try:
        from core.eval_candidates import GoldenCandidateQueue

        queue_n = len(GoldenCandidateQueue.load().pending())
    except Exception:  # noqa: BLE001 — очередь вторична для плитки
        queue_n = 0
    out: dict[str, Any] = {
        "last": None, "prev": None, "delta": dict.fromkeys(_DELTA_METRICS), "delta_basis": None,
        "by_type": [], "red": [], "red_text": "", "history": [], "misses": [], "stale_ids": [],
        "candidates_pending": queue_n, "canon_age_days": canon_age,
        "outdated": False, "outdated_days": OUTDATED_DAYS,
        "rerank": _rerank_view(None),
        # MODEL-1: вторая строка виджета - золотые задачи ГЕНЕРАЦИИ по хостам (история ручных
        # прогонов dt_eval --generation). Нет истории - ``hosts: {}`` (не ошибка).
        "generation": _generation_view(n),
    }
    if canon_error:
        add_warning(out, CODE_STORE_UNAVAILABLE,
                    f"золотой набор не прочитан — формулировки промахов недоступны: {canon_error}")
    if not runs:
        return add_warning(out, CODE_NO_RUNS,
                           "прогонов золотого набора ещё нет — запусти dt_eval или "
                           "dt_sync index --steps eval")
    cur = runs[-1]
    prev = runs[-2] if len(runs) > 1 else None
    out["rerank"] = _rerank_view(cur)
    cur_groups = _group_view(cur)
    out["last"] = {
        "ts": cur.get("ts"), "metrics": cur.get("metrics") or {}, "groups": cur_groups,
        "stale": list(cur.get("stale") or []), "verified": cur.get("verified", 0),
        "hypotheses": cur.get("hypotheses", 0), "age_days": cur.get("age_days"),
        "baseline": bool(cur.get("baseline")),
    }
    if prev is not None:
        out["prev"] = {"ts": prev.get("ts"), "metrics": prev.get("metrics") or {}}
    out["delta"], out["delta_basis"] = _delta(cur, prev)
    out["by_type"] = _type_view(cur, prev)
    out["red"] = list(cur.get("red") or [])
    out["red_text"] = red_text(out["red"]) if out["red"] else ""
    out["stale_ids"] = list(cur.get("stale") or [])
    age = cur.get("age_days")
    out["outdated"] = age is not None and age > OUTDATED_DAYS
    for rec in window:
        groups = rec.get("groups") or {}
        control = groups.get("control") or {}
        m = rec.get("metrics") or {}
        out["history"].append({
            "ts": rec.get("ts"), "recall5": m.get("recall5"), "hub3": m.get("hub3"),
            "mrr": m.get("mrr"),
            "control_recall5": (control.get("metrics") or {}).get("recall5")
            if control.get("verified") else None,
        })
    misses = []
    for q in cur.get("per_query") or []:
        if not isinstance(q, dict) or q.get("ok") or q.get("stale") or not q.get("verified", True):
            continue  # попали, протухли (долг канона) или гипотеза (в метрику не входит)
        qtype, label = labels.get(str(q.get("id")), ("", ""))
        misses.append({"id": q.get("id"), "type": qtype, "label": label,
                       "group": q.get("group") or "work", "top": list(q.get("top") or [])[:3]})
    out["misses_total"] = len(misses)
    out["misses"] = misses[:_MISSES_CAP]
    return out
