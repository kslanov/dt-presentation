"""PULT-EVENTLOG — сквозной лог стадий пайплайна (фундамент журнала).

По каждому артефакту, идущему через пайплайн (**загрузили → положили в хаб →
проиндексировали → слинковали**), стадия пишет одно событие, привязанное к
артефакту → лента «путь этого файла/заметки по стадиям». До сих пор стадии жили в
разных манифестах и не были сшиты в одну ленту; это — единый event-log
(ТЗ ``docs/tz/pult-eventlog-pipeline-events.md``, roadmap §4c).

**Не путать с** :func:`core.metrics.record_event` — та пишет *агрегатную*
аналитику (JSONL для ``dt-kpi``), а тут — *per-artifact* lifecycle в таблице
``events`` единой ``dt.db`` (DB-1, миграция v2): queryable «таймлайн артефакта X»,
ACID.

Идентичность. Файл на входе — ``source_hash`` (byte-hash, SRC-1
``file_content_hash``); после ingest артефакт — заметка (``note_id``). Общая нить
post-ingest = **``note_id``**; ingest-событие дополнительно несёт ``source_hash``
(сшивка файл→заметка). Лента собирается по ``note_id`` (``source_hash`` резолвится
в ``note_id`` через ingest-событие).

Инварианты:

* **Best-effort.** :func:`emit`/:func:`emit_batch` проглатывают ЛЮБОЕ исключение —
  лог не критичный путь, пайплайн важнее (сбой БД никогда не роняет стадию).
* **Реюз DB-1.** Один insert через :func:`core.db.connect` (WAL + миграции), не
  ещё один JSON и не второй коннект.
* **Не перегружать.** Per-artifact события — только про то, что идёт через
  пайплайн (новые/изменённые); bulk-операция (полный reindex) пишет ОДНО
  run-событие, не по-заметочно.
* **Приватность.** ``detail`` — только метаданные стадии (counts/статусы/
  относительные пути), без тела/сумм.
* ``core`` ⊥ mcp/cli; Path B (без сети/LLM). Детерминизм.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

__all__ = [
    "STAGES",
    "last_read_error",
    "Event",
    "artifact_timeline",
    "emit",
    "emit_batch",
    "new_run_id",
    "recent_events",
    "stage_counts",
]

# Известные стадии (расширяемо: refine|attribute|facts|source подключат emit()
# позже одной строкой — эмиттер реюзабельный, не в объёме этого ТЗ).
STAGES = ("ingest", "hub", "index", "link")


def _now_iso(now: str | None = None) -> str:
    return now or datetime.now(UTC).isoformat(timespec="seconds")


def new_run_id() -> str:
    """Свежий идентификатор прогона — группирует события одной стадии/пачки."""
    return uuid.uuid4().hex


@dataclass(frozen=True)
class Event:
    """Одно событие ленты (одна строка ``events``)."""

    event_id: int
    ts: str
    note_id: str | None
    source_hash: str | None
    path: str | None
    stage: str
    status: str
    detail: dict[str, Any]
    run_id: str | None


def _with_corr_id(detail: dict[str, Any] | None) -> dict[str, Any] | None:
    """CODE-5-1: досыпать ``corr_id`` в ``detail`` — сшивка события с логом.

    Только когда corr_id реально установлен (CLI-запуск/MCP-вызов); иначе detail
    не трогаем (обратная совместимость: прямые вызовы/тесты без прогона не меняются).
    Не перекрывает явный ``detail['corr_id']``."""
    try:
        from core.logging_setup import get_corr_id

        cid = get_corr_id()
    except Exception:  # noqa: BLE001 — corr_id опционален, лог best-effort
        cid = ""
    if not cid:
        return detail
    merged = dict(detail or {})
    merged.setdefault("corr_id", cid)
    return merged


def _detail_json(detail: dict[str, Any] | None) -> str | None:
    """Сериализовать ``detail`` в JSON (best-effort — незнакомое → str)."""
    detail = _with_corr_id(detail)
    if not detail:
        return None
    try:
        return json.dumps(detail, ensure_ascii=False, sort_keys=True, default=str)
    except (TypeError, ValueError):
        return None


def emit(
    stage: str,
    status: str,
    *,
    note_id: str | None = None,
    source_hash: str | None = None,
    path: str | None = None,
    detail: dict[str, Any] | None = None,
    run_id: str | None = None,
    now: str | None = None,
    db_path: Path | None = None,
) -> None:
    """Записать одно событие стадии. **Best-effort — не бросает никогда.**

    Один insert через DB-1 :func:`~core.db.connect`. Любое исключение (сбой БД,
    заблокированный файл, битый ``detail``) проглатывается: лог не должен ронять
    пайплайн. ``detail`` — только метаданные стадии (без тела/сумм).
    """
    try:
        from core.db import connect

        conn = connect(db_path)
        try:
            conn.execute(
                "INSERT INTO events (ts, note_id, source_hash, path, stage, status, "
                "detail, run_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    _now_iso(now),
                    note_id,
                    source_hash,
                    path,
                    stage,
                    status,
                    _detail_json(detail),
                    run_id,
                ),
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:  # noqa: BLE001, S110 — лог best-effort: пайплайн важнее события
        pass


def emit_batch(
    rows: list[dict[str, Any]],
    *,
    now: str | None = None,
    db_path: Path | None = None,
) -> None:
    """Пакетная вставка событий одной транзакцией (для стадии, гонящей пачку).

    Каждая строка — dict с ключами ``stage``/``status`` (обязательны) и
    опциональными ``note_id``/``source_hash``/``path``/``detail``/``run_id``.
    **Best-effort** — исключение проглатывается; пустой список — no-op (без
    открытия БД).
    """
    if not rows:
        return
    try:
        from core.db import connect

        stamp = _now_iso(now)
        params = [
            (
                stamp,
                r.get("note_id"),
                r.get("source_hash"),
                r.get("path"),
                r["stage"],
                r["status"],
                _detail_json(r.get("detail")),
                r.get("run_id"),
            )
            for r in rows
        ]
        conn = connect(db_path)
        try:
            conn.executemany(
                "INSERT INTO events (ts, note_id, source_hash, path, stage, status, "
                "detail, run_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                params,
            )
            conn.commit()
        finally:
            conn.close()
    except Exception:  # noqa: BLE001, S110 — best-effort, как emit
        pass


# --------------------------------------------------------------------------- #
# Query API — таймлайн артефакта / свежая лента / сводка (PART-4)              #
# --------------------------------------------------------------------------- #
def _row_to_event(row: sqlite3.Row) -> Event:
    raw = row["detail"]
    detail: dict[str, Any] = {}
    if raw:
        try:
            parsed = json.loads(raw)
            if isinstance(parsed, dict):
                detail = parsed
        except (TypeError, ValueError):
            detail = {}
    return Event(
        event_id=int(row["event_id"]),
        ts=str(row["ts"]),
        note_id=row["note_id"],
        source_hash=row["source_hash"],
        path=row["path"],
        stage=str(row["stage"]),
        status=str(row["status"]),
        detail=detail,
        run_id=row["run_id"],
    )


# CONTRACT-2 С7: причина последнего сбоя чтения журнала. Модуль отдаёт списки
# событий (менять их форму нельзя — это контракт ленты), поэтому «не смогли прочитать»
# фиксируется здесь, а конверт собирает вызывающий (:func:`last_read_error`).
_LAST_READ_ERROR: dict[str, str] = {"reason": ""}


def last_read_error() -> str:
    """Причина последнего сбоя чтения журнала (``""`` — читалось нормально).

    Нужна, чтобы «событий нет» и «журнал не прочитался» перестали быть одним и тем же
    пустым списком: инструмент кладёт причину в конверт деградации.
    """
    return _LAST_READ_ERROR["reason"]


def _query(sql: str, params: tuple[Any, ...], db_path: Path | None) -> list[Event]:
    """Read-only helper — best-effort ([] при любом сбое/отсутствии таблицы).

    Сбой НЕ роняет чтение (лог не критичный путь), но и не выдаётся за пустоту:
    причина запоминается в :func:`last_read_error` (CONTRACT-2 С7).
    """
    try:
        from core.db import connect

        conn = connect(db_path)
        try:
            rows = conn.execute(sql, params).fetchall()
        finally:
            conn.close()
    except Exception as exc:  # noqa: BLE001 — read best-effort
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return []
    _LAST_READ_ERROR["reason"] = ""
    return [_row_to_event(r) for r in rows]


def _identity_keys(ref: str) -> tuple[set[str], set[str]]:
    """Все написания одной заметки: ``(значения note_id, значения path)`` (ФП-3).

    Историческая причина существования этой функции — Д8 из FINDINGS: стадии писали в
    одно поле РАЗНЫЕ формы (``index``/``link`` — frontmatter id, ``hub`` — путь
    заметки), поэтому таймлайн расщеплялся на две половины и ни один вызов не собирал
    его целиком. Эмиттер починен (ниже по стеку ``hub`` тоже пишет ``note_id``), но
    события, записанные ДО фикса, никуда не делись — читатель обязан понимать обе формы.

    Резолв — единой точкой ФП-1 (:func:`core.vault.resolve_note_path`), поэтому на вход
    годится любая форма ссылки: id, путь, имя файла, ``source_path``. Заметки нет на
    диске → возвращаем ровно то, что дали (события всё равно могут быть — заметку могли
    удалить). Best-effort: сбой резолва не ломает чтение лога.
    """
    ids = {ref}
    paths: set[str] = set()
    try:
        from core.config import default_vault_path
        from core.vault import read_note, resolve_note_path

        vault = default_vault_path().resolve()
        resolved = resolve_note_path(ref, vault_path=vault)
        if resolved is None:
            return ids, paths
        rel = resolved.relative_to(vault).as_posix()
        paths.add(rel)
        ids.add(rel)  # события стадии hub до ФП-3 писали путь в поле note_id
        note = read_note(resolved)
        if note.id:
            ids.add(note.id)
    except Exception:  # noqa: BLE001 — чтение лога не критичный путь
        return ids, paths
    return ids, paths


def artifact_timeline(
    note_id: str | None = None,
    source_hash: str | None = None,
    *,
    db_path: Path | None = None,
) -> list[Event]:
    """События одного артефакта по времени (ingest→hub→index→link).

    **CONTRACT-1 ФП-3 (Д8).** Одна идентичность на всю ленту: ссылка любой формы
    приводится к набору написаний одной заметки (:func:`_identity_keys`), и события
    собираются по ``note_id`` **и** по ``path`` — так в одном таймлайне оказываются и
    ingest, и hub, и index, и link, включая события, записанные до фикса эмиттера.

    По ``source_hash`` (файл): ``note_id`` резолвится через ingest-событие того же файла
    — по **последнему** (файл мог быть переинжещен), а не по первому. Заметки за файлом
    нет вовсе (операционный корень — файл регистрируется, заметка не создаётся) →
    возвращаются события самого файла по ``source_hash``, а не пустая лента: факт
    «файл зарегистрирован» существует, и молчать о нём — та же тихая пустота.

    Несуществующий артефакт → ``[]``.
    """
    if note_id is None and source_hash is not None:
        resolved = _query(
            "SELECT * FROM events WHERE source_hash = ? AND note_id IS NOT NULL "
            "ORDER BY ts DESC, event_id DESC LIMIT 1",
            (source_hash,),
            db_path,
        )
        if resolved:
            note_id = resolved[0].note_id
        else:
            # Заметки нет — отдаём ленту файла (ingest-события по этому байт-хешу).
            return _query(
                "SELECT * FROM events WHERE source_hash = ? ORDER BY ts, event_id",
                (source_hash,),
                db_path,
            )
    if note_id is None:
        return []
    ids, paths = _identity_keys(str(note_id))
    id_marks = ", ".join("?" for _ in ids)
    clauses = [f"note_id IN ({id_marks})"]
    params: list[Any] = list(ids)
    if paths:
        path_marks = ", ".join("?" for _ in paths)
        clauses.append(f"path IN ({path_marks})")
        params.extend(paths)
    where = " OR ".join(clauses)
    return _query(
        f"SELECT * FROM events WHERE {where} ORDER BY ts, event_id",  # noqa: S608 — плейсхолдеры строятся по числу значений, сами значения параметризованы
        tuple(params),
        db_path,
    )


def recent_events(
    limit: int = 100,
    stage: str | None = None,
    since: str | None = None,
    status: str | None = None,
    *,
    db_path: Path | None = None,
) -> list[Event]:
    """Свежая лента (новые сверху) с фильтрами ``stage``/``since``/``status``."""
    clauses: list[str] = []
    params: list[Any] = []
    if stage:
        clauses.append("stage = ?")
        params.append(stage)
    if status:
        clauses.append("status = ?")
        params.append(status)
    if since:
        clauses.append("ts >= ?")
        params.append(since)
    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
    params.append(max(1, int(limit)))
    return _query(
        f"SELECT * FROM events {where} ORDER BY ts DESC, event_id DESC LIMIT ?",  # noqa: S608 — clauses фиксированы, значения параметризованы
        tuple(params),
        db_path,
    )


def stage_counts(
    since: str | None = None, *, db_path: Path | None = None
) -> dict[str, Any]:
    """Сводка ``{stage: count}`` (для doctor/виджета). ``total`` — сумма по всем.

    ``since`` ограничивает окном по ``ts``. Отсутствие таблицы/сбой → нули по
    известным стадиям.
    """
    counts: dict[str, Any] = dict.fromkeys(STAGES, 0)
    try:
        from core.db import connect

        conn = connect(db_path)
        try:
            if since:
                rows = conn.execute(
                    "SELECT stage, COUNT(*) AS n FROM events WHERE ts >= ? GROUP BY stage",
                    (since,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT stage, COUNT(*) AS n FROM events GROUP BY stage"
                ).fetchall()
        finally:
            conn.close()
    except Exception as exc:  # noqa: BLE001 — read best-effort
        # CONTRACT-2 С20: нули внутри «успешного» блока витрины врали, что событий нет.
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return {**counts, "total": 0, "error": str(exc)[:200]}
    for r in rows:
        counts[str(r["stage"])] = int(r["n"])
    counts["total"] = sum(v for k, v in counts.items() if k != "total")
    return counts
