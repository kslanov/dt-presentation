"""Exemplar-as-template — reuse the *form* of a past real document (TMPL-1, §10a).

The production audit (Acme) showed the engine could echo an author's *tone*
(:func:`core.style.select_exemplars`) but had no path to reuse the *form* of a
concrete past document — so "сделай КП как образец оформления" produced an
invented structure with a placeholder letterhead. This package is that path:

- :func:`~core.exemplars.registry.find_exemplar` ranks the corpus of real
  documents (same client > same industry > any, ``type: template`` boost, recency)
  and returns the best :class:`~core.exemplars.registry.Exemplar`, or ``None``.
- :func:`~core.exemplars.render.as_template` lifts that exemplar (SRC-1 for
  binaries, markdown body otherwise) into a
  :class:`~core.exemplars.render.RenderSpec` — the ordered outline + letterhead +
  salutation/closing — rendered compactly into the ``[Образец оформления]`` section.

Distinct from ``[Style exemplars]`` (tone): this is form/blank. Invariants:
``core/exemplars`` imports neither MCP nor CLI; Path B — discovery and extraction
are offline & deterministic (no network, no LLM); SRC-1 is reused for binaries.
"""

from __future__ import annotations

from core.exemplars.registry import Exemplar, exemplar_from_ref, find_exemplar
from core.exemplars.render import RenderSpec, as_template

__all__ = [
    "Exemplar",
    "RenderSpec",
    "as_template",
    "exemplar_from_ref",
    "find_exemplar",
]
