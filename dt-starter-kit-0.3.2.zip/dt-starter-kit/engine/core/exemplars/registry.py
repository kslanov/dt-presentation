"""Exemplar discovery — find a past real document to clone the *form* of (TMPL-1).

The production audit (Acme) found the engine could pull the *tone* of past work
(:func:`core.style.select_exemplars`) but never its **form**: given "найди пример
КП как образец оформления" it built a letter structure from abstract rules and a
placeholder letterhead. This module supplies the missing path — a deterministic,
ranked search over the corpus of real documents for one whose **structure and
letterhead** can be reused as a template.

:func:`find_exemplar` ranks candidates by an explainable order — **same client >
same industry > any**, with a ``type: template`` boost (a curated form-example)
and recency as the tie-breaker — and returns the single best :class:`Exemplar`, or
``None`` when nothing on-genre exists (never inventing one). :mod:`core.exemplars.
render` then lifts that exemplar into a :class:`~core.exemplars.render.RenderSpec`.

Distinct from ``select_exemplars`` (tone) — this is about form/blank, surfaced in
generation as the separate ``[Образец оформления]`` section.

Invariants: ``core/exemplars`` imports neither MCP nor CLI; Path B — discovery is
offline & deterministic (``iter_vault`` only, no network, no LLM).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.config import default_vault_path
from core.privacy import is_nda
from core.vault import Note, iter_vault, read_note, resolve_note_path

__all__ = ["Exemplar", "find_exemplar", "exemplar_from_ref"]

# Note types that can serve as a form exemplar: curated skeleton-examples
# (``template``), accepted past artifacts (``output``), rendered past documents
# (``style-sample``) and generic ingested documents (``document``).
_EXEMPLAR_TYPES = frozenset({"template", "output", "style-sample", "document"})

# Ranking tiers (higher wins). ``same client`` beats ``same industry`` beats any
# on-genre match; the ``type: template`` boost and recency are sub-keys, so a
# same-client non-template still outranks an any-tier template.
_TIER_CLIENT = 2
_TIER_INDUSTRY = 1
_TIER_ANY = 0


@dataclass
class Exemplar:
    """One ranked form-exemplar: a real past document to clone the form of.

    ``source_path`` is the binary original (docx/pptx/…) when the note carries one
    — :func:`~core.exemplars.render.as_template` lifts it via SRC-1; ``None`` means
    the note's own markdown body holds the clean ``#``-structure. ``why`` is the
    human-readable ranking reason (``"тот же клиент"`` / ``"та же отрасль"`` …) for
    the inspector; ``score`` the numeric rank key.
    """

    note_id: str
    path: str
    source_path: str | None
    genre: str
    fmt: str | None
    client: str | None
    score: float
    why: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "note_id": self.note_id,
            "path": self.path,
            "source_path": self.source_path,
            "genre": self.genre,
            "fmt": self.fmt,
            "client": self.client,
            "score": self.score,
            "why": self.why,
        }


def _norm(value: Any) -> str:
    """Lowercase + strip a scalar to a comparable token (``""`` for empty/None)."""
    return str(value).strip().lower() if value not in (None, "") else ""


def _first_id(value: Any) -> str:
    """First bare id of a wikilink field that may be a scalar or a list."""
    if isinstance(value, list):
        return _norm(value[0]) if value else ""
    return _norm(value)


def _norm_genre(genre: Any) -> str:
    """Normalize a genre for matching: lowercase + singularize simple plurals.

    The corpus tags samples ``genre: letter`` (singular) but folders are plural
    (``01-style/letters/``); this collapses both sides so ``"letters"`` matches
    ``"letter"`` and a couple of Russian/English irregulars line up.
    """
    g = _norm(genre)
    if not g:
        return ""
    irregular = {
        "analyses": "analysis",
        "strategies": "strategy",
        "справки": "справка",
        "письма": "письмо",
        "отчёты": "отчет",
        "отчеты": "отчет",
        "доклады": "доклад",
    }
    if g in irregular:
        return irregular[g]
    if g.endswith("ies") and len(g) > 3:
        return g[:-3] + "y"
    if g.endswith("s") and len(g) > 1:
        return g[:-1]
    return g


def _norm_fmt(fmt: Any) -> str:
    """Normalize a format/extension hint: lowercase, drop a leading dot."""
    return _norm(fmt).lstrip(".")


# Root folders → the genre implied by their immediate subfolder, used only when a
# note carries no explicit ``genre`` in frontmatter.
_GENRE_ROOTS = ("01-style", "06-templates", "07-outputs")

# EXEMPLAR-GENRE (PART-2): the KP genre and the tokens that recognise a commercial
# offer by name/title/alias when no explicit ``genre`` frontmatter is present. Past
# KP live as ``type: document`` in ``_legacy/`` (``kp-dlya-ao-acme``) or under a
# dated ``07-outputs/`` bucket (folder = date, not a genre), so neither the folder
# rule nor a frontmatter genre catches them — the heuristic does. Matched as a
# lowercased substring against id/title/filename/aliases (``kp-``/``кп_`` as an
# affix, the phrases anywhere). Deliberately narrow: only КП, no wider re-tagging.
GENRE_COMMERCIAL_OFFER = "commercial_offer"
_COMMERCIAL_OFFER_PHRASES = (
    "коммерческое предложение",
    "коммерческого предложения",
    "commercial offer",
)
_COMMERCIAL_OFFER_AFFIXES = ("кп-", "кп_", "kp-", "kp_")


def _looks_like_commercial_offer(note: Note) -> bool:
    """Heuristic: does this note read as a commercial offer (КП)? (PART-2).

    Fires only as a fallback when frontmatter carries no explicit ``genre`` — a
    curated genre always wins (see :func:`_note_genre`). Scans the note id, title,
    filename stem and any ``aliases`` for a КП phrase (anywhere) or a ``kp-``/``кп_``
    affix (word-initial marker used by ingested КП filenames). Substring match on the
    phrases is safe — they are long and unambiguous; the affixes require the ``-``/``_``
    so ``кпд``/``kpi`` never trip.
    """
    haystacks: list[str] = [
        _norm(note.id),
        _norm(note.frontmatter.get("title")),
        _norm(note.path.stem),
    ]
    aliases = note.frontmatter.get("aliases")
    if isinstance(aliases, list):
        haystacks.extend(_norm(a) for a in aliases)
    elif aliases:
        haystacks.append(_norm(aliases))

    for hay in haystacks:
        if not hay:
            continue
        if any(phrase in hay for phrase in _COMMERCIAL_OFFER_PHRASES):
            return True
        if hay.startswith(_COMMERCIAL_OFFER_AFFIXES):
            return True
        if any(f" {affix}" in hay for affix in _COMMERCIAL_OFFER_AFFIXES):
            return True
    return False


def _note_genre(note: Note) -> str:
    """Genre of a candidate note: frontmatter ``genre`` first, else folder, else КП.

    Under a known root (``01-style/letters/…``) the immediate subfolder names the
    genre. Failing that, the commercial-offer heuristic (:func:`_looks_like_commercial_offer`)
    tags a КП by id/title/name/aliases (PART-2). Anything else yields ``""``
    (unclassifiable → excluded by the caller). Explicit frontmatter always wins.
    """
    fg = note.frontmatter.get("genre")
    if fg:
        return _norm(fg)
    parts = [p for p in note.path.parts]
    for i, part in enumerate(parts):
        if part in _GENRE_ROOTS and i + 1 < len(parts):
            nxt = parts[i + 1]
            # A dated outputs bucket (07-outputs/2026-07/) is not a genre.
            if not nxt[:4].isdigit():
                return _norm(nxt)
    if _looks_like_commercial_offer(note):
        return GENRE_COMMERCIAL_OFFER
    return ""


def _candidate_fmt(source_path: str | None, fm: dict[str, Any]) -> str:
    """Format of a candidate: explicit ``format`` field, else source ext, else md."""
    explicit = fm.get("format") or fm.get("fmt")
    if explicit:
        return _norm_fmt(explicit)
    if source_path:
        suffix = Path(source_path).suffix
        if suffix:
            return _norm_fmt(suffix)
    return "md"


def _source_path(fm: dict[str, Any]) -> str | None:
    sp = fm.get("source_path")
    if isinstance(sp, str) and sp.strip():
        return sp.strip()
    return None


def _recency(fm: dict[str, Any]) -> str:
    """Recency sort key (ISO dates sort lexically); missing dates sort last."""
    return str(fm.get("modified") or fm.get("created") or "")


@dataclass
class _Candidate:
    """Raw candidate fields gathered in one vault pass, tiered after it (internal)."""

    note_id: str
    path: str
    source_path: str | None
    fmt: str
    client: str
    industry: str
    modified: str
    is_template: bool


def find_exemplar(
    genre: str,
    *,
    client: str | None = None,
    fmt: str | None = None,
    vault_path: Path | None = None,
) -> Exemplar | None:
    """Find the best form-exemplar of ``genre``, or ``None`` (TMPL-1 PART-1).

    Candidates are notes whose ``type`` is one of ``template``/``output``/
    ``style-sample``/``document`` and whose genre (frontmatter or folder) matches
    ``genre``; ``fmt`` (a format/extension) narrows further when given. Ranking is
    deterministic and explainable: **same ``client``** (by wikilink) beats **same
    industry** (resolved from the client hub) beats any on-genre match; a
    ``type: template`` gets a curated-form boost; recency breaks ties. Returns the
    single top :class:`Exemplar`, or ``None`` when nothing matches — the caller
    must not invent one.
    """
    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    target_genre = _norm_genre(genre)
    if not target_genre:
        return None
    client_id = _norm(client) if client else ""
    want_fmt = _norm_fmt(fmt) if fmt else ""

    industry = ""  # target client's industry, resolved from its hub in this pass
    candidates: list[_Candidate] = []

    for note in iter_vault(vault):
        if client_id and _norm(note.id) == client_id:
            industry = _first_id(note.frontmatter.get("industry"))

        if note.type not in _EXEMPLAR_TYPES:
            continue
        if _norm_genre(_note_genre(note)) != target_genre:
            continue

        fm = note.frontmatter
        sp = _source_path(fm)
        # NDA-1: never offer an NDA note or an NDA source as a form-exemplar.
        if is_nda(str(note.path)) or (sp and is_nda(sp)):
            continue
        cfmt = _candidate_fmt(sp, fm)
        if want_fmt and cfmt != want_fmt:
            continue

        candidates.append(
            _Candidate(
                note_id=note.id,
                path=str(note.path),
                source_path=sp,
                fmt=cfmt,
                client=_first_id(fm.get("client")),
                industry=_first_id(fm.get("industry")),
                modified=_recency(fm),
                is_template=note.type == "template",
            )
        )

    if not candidates:
        return None

    def _rank(c: _Candidate) -> tuple[int, int, str]:
        if client_id and c.client == client_id:
            tier = _TIER_CLIENT
        elif industry and c.industry == industry:
            tier = _TIER_INDUSTRY
        else:
            tier = _TIER_ANY
        return (tier, 1 if c.is_template else 0, c.modified)

    best = max(candidates, key=_rank)
    tier, tboost, modified = _rank(best)
    return Exemplar(
        note_id=best.note_id,
        path=best.path,
        source_path=best.source_path,
        genre=target_genre,
        fmt=best.fmt,
        client=best.client or None,
        score=float(tier * 10 + tboost),
        why=_why(tier, bool(tboost), modified),
    )


def _why(tier: int, is_template: bool, modified: str) -> str:
    """Human ranking reason for the inspector (``why``)."""
    base = {
        _TIER_CLIENT: "тот же клиент",
        _TIER_INDUSTRY: "та же отрасль",
        _TIER_ANY: "тот же жанр",
    }[tier]
    if is_template:
        base += ", курированный шаблон"
    if modified:
        base += f", свежесть {modified}"
    return base


def exemplar_from_ref(
    ref: str, *, vault_path: Path | None = None
) -> Exemplar | None:
    """Build an :class:`Exemplar` from an explicit ``exemplar_ref`` (note id or path).

    A path-looking ref (``/…`` / ``\\`` / a file suffix) is taken as a binary source
    directly; otherwise it is a note id resolved from the vault (its frontmatter
    supplies ``source_path``/genre/client). Returns ``None`` when a note id does not
    resolve — the caller then omits the section (never blocks here).
    """
    ref = (ref or "").strip()
    if not ref:
        return None
    vault = Path(vault_path) if vault_path is not None else default_vault_path()

    # CONTRACT-1 ФП-1: ссылка сперва пробуется как ЗАМЕТКА единой точкой резолва (путь
    # vault-относительный/абсолютный, frontmatter id, имя файла, source_path) — форма
    # ``03-projects/kp-2025.md`` из выдачи ``find_notes``/``read_note`` раньше уезжала в
    # ветку «путь к бинарю» только потому, что в строке есть слэш.
    resolved = resolve_note_path(ref, vault_path=vault)
    if resolved is not None:
        return _from_note(read_note(resolved))

    looks_like_path = "/" in ref or "\\" in ref or bool(Path(ref).suffix)
    if looks_like_path:
        if is_nda(ref):  # NDA-1: an explicit NDA path is never a form-exemplar
            return None
        return Exemplar(
            note_id="",
            path=ref,
            source_path=ref,
            genre="",
            fmt=_norm_fmt(Path(ref).suffix) or None,
            client=None,
            score=0.0,
            why="явный exemplar_ref (путь)",
        )

    for note in iter_vault(vault):
        if _norm(note.id) != _norm(ref):
            continue
        return _from_note(note)
    return None


def _from_note(note: Note) -> Exemplar | None:
    """Заметка → :class:`Exemplar` явной ссылки (``None`` — NDA, NDA-1).

    NDA-гард здесь тот же, что в :func:`find_exemplar` (сама заметка ИЛИ её источник):
    единый резолвер ФП-1 умеет дотянуться до заметки по пути, а ``iter_vault``
    NDA-заметки отфильтровывал — без этой проверки барьер стал бы слабее.
    """
    fm = note.frontmatter
    sp = _source_path(fm)
    if is_nda(str(note.path)) or (sp and is_nda(sp)):
        return None
    return Exemplar(
        note_id=note.id,
        path=str(note.path),
        source_path=sp,
        genre=_note_genre(note) or "",
        fmt=_candidate_fmt(sp, fm),
        client=_first_id(fm.get("client")) or None,
        score=0.0,
        why="явный exemplar_ref (заметка)",
    )
