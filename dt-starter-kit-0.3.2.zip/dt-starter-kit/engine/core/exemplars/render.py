"""Exemplar → template render — extract a document's *form* (TMPL-1 PART-2).

Turns a ranked :class:`~core.exemplars.registry.Exemplar` into a
:class:`RenderSpec`: the ordered **section outline**, the **letterhead** block, the
**salutation** and **closing** markers, and any **boilerplate** — the reusable
*form* of a past document, separate from its client-specific content. A binary
original (docx/pptx/…) is lifted via SRC-1 (:func:`core.sources.lift_from`, no
re-parsing); a markdown note supplies its clean ``#``-structure directly.

Extraction is **deterministic** (Path B — no LLM): markdown headings, or, for a
lifted text layer, heading-like lines (numbered / capitalised / short titles).
:meth:`RenderSpec.to_output_format` renders a *compact* block for the
``[Образец оформления]`` section — outline + blank + an instruction to reproduce
the form (content comes from facts/context; missing requisites are flagged, never
invented) — deliberately not the whole document.

Invariants: ``core/exemplars`` imports neither MCP nor CLI; SRC-1 is reused for
binaries (parsers are not duplicated). A lift that comes back ``unavailable``
degrades softly to a partial/empty spec — never a crash.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.exemplars.registry import Exemplar
from core.vault import read_note

__all__ = ["RenderSpec", "as_template"]

# NDA-1: soft-refusal reason for an NDA-marked exemplar (matches the resolver's).
_NDA_REASON = "NDA-исключение (_nda)"

# Salutation openers (RU/EN), matched at a line start, case-insensitive.
_SALUTATION_RE = re.compile(
    r"^(уважаем\w*|здравствуйте|добр(ый|ое) (день|утро|вечер)|дорог\w*|dear)\b",
    re.IGNORECASE,
)

# Closing/sign-off markers (RU/EN).
_CLOSING_RE = re.compile(
    r"^(с уважением|с наилучшими|искренне ваш\w*|всего доброго|"
    r"best regards|sincerely|kind regards|yours (sincerely|faithfully))\b",
    re.IGNORECASE,
)

# Boilerplate/service formulas worth surfacing as reusable form.
_BOILERPLATE_RE = re.compile(
    r"(конфиденциальн\w*|не является (публичной )?офертой|все права защищены|"
    r"confidential|all rights reserved)",
    re.IGNORECASE,
)

# Requisite/letterhead signals (company forms, contacts) — a top line carrying
# one of these reads as letterhead rather than prose.
_LETTERHEAD_RE = re.compile(
    r"(ООО|АО|ТОО|ЗАО|ПАО|ИП|LLC|Inc\.|Ltd|ИНН|КПП|БИН|ОГРН|"
    r"тел[\.:]|e-?mail|www\.|@|г\.\s|ул\.\s|просп)",
    re.IGNORECASE,
)

# A heading-like line in a lifted text layer: numbered (``1.`` / ``2)`` / ``1.2``)
# or a short ALL-CAPS / Title line without terminal sentence punctuation.
_NUMBERED_RE = re.compile(r"^\s*(\d+([.)]\d+)*[.)]?|[IVXLC]+\.)\s+\S")

_MAX_SECTIONS = 40
_MAX_LETTERHEAD_LINES = 8
_SAMPLE_CHARS = 220


@dataclass
class RenderSpec:
    """The extracted *form* of an exemplar (TMPL-1 PART-2).

    ``sections`` is the ordered outline (indented by heading depth for markdown);
    ``letterhead`` the top requisite/header block; ``salutation``/``closing`` the
    opener and sign-off; ``boilerplate`` recurring service formulas; ``sample`` one
    short body-paragraph excerpt (used only as a fallback hint). ``source_note`` /
    ``source_path`` / ``fmt`` carry provenance. ``available`` is False when the
    binary source could not be lifted (``reason`` says why) — the spec is then
    empty/partial but never absent.
    """

    sections: list[str] = field(default_factory=list)
    letterhead: str | None = None
    salutation: str | None = None
    closing: str | None = None
    boilerplate: list[str] = field(default_factory=list)
    sample: str | None = None
    source_note: str = ""
    source_path: str | None = None
    fmt: str | None = None
    available: bool = True
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "sections": list(self.sections),
            "letterhead": self.letterhead,
            "salutation": self.salutation,
            "closing": self.closing,
            "boilerplate": list(self.boilerplate),
            "sample": self.sample,
            "source_note": self.source_note,
            "source_path": self.source_path,
            "fmt": self.fmt,
            "available": self.available,
            "reason": self.reason,
            "output_format": self.to_output_format(),
        }

    def to_output_format(self) -> str:
        """Compact render for the ``[Образец оформления]`` section (not the whole doc).

        Leads with the instruction — reproduce THIS form and letterhead; the content
        comes from the facts/context, requisites are never invented (a missing
        letterhead is flagged) — and the exemplar wins over the abstract skeleton.
        Then the provenance line, the letterhead, salutation, the section outline
        and the closing. Empty pieces are shown as honest placeholders.
        """
        lines: list[str] = [_INSTRUCTION]
        src = self.source_path or self.source_note or "(источник неизвестен)"
        note = self.source_note or "(без id)"
        lines.append(f"Источник формы: {note} — {src} [{self.fmt or '?'}]")
        if not self.available:
            lines.append(f"⚠ образец не удалось поднять ({self.reason}) — форма частична.")

        lines.append("")
        lines.append("Бланк / шапка:")
        lines.append(
            self.letterhead
            or "(бланк не обнаружен — НЕ выдумывай реквизиты; если бланк нужен, отметь пропуск)"
        )

        lines.append("")
        lines.append(f"Приветствие: {self.salutation or '(не обнаружено)'}")

        lines.append("")
        lines.append("Структура (повтори порядок и состав разделов):")
        if self.sections:
            for i, sec in enumerate(self.sections, start=1):
                lines.append(f"  {i}. {sec}")
        else:
            lines.append("  (заголовков не выделено — повтори общую форму источника)")

        lines.append("")
        lines.append(f"Подпись / закрытие: {self.closing or '(не обнаружено)'}")

        if self.boilerplate:
            lines.append("")
            lines.append("Служебные формулы (сохрани при уместности):")
            for b in self.boilerplate:
                lines.append(f"  - {b}")

        if self.sample and not self.sections:
            lines.append("")
            lines.append(f"Образец абзаца: {self.sample}")

        return "\n".join(lines)


_INSTRUCTION = (
    "Следуй СТРУКТУРЕ и БЛАНКУ этого образца — это форма, а не содержание. "
    "Наполнение бери из фактов и контекста; реквизиты/суммы НЕ выдумывай (если "
    "бланка нет — отметь пропуск). Этот образец приоритетнее абстрактного "
    "скелета формата: скелет — вспомогательный."
)


def as_template(ex: Exemplar, *, vault_path: Path | None = None) -> RenderSpec:
    """Lift ``ex`` into a :class:`RenderSpec` (TMPL-1 PART-2).

    Binary source (``ex.source_path``) → SRC-1 ``lift_from`` (best-effort structure
    from the text layer; ``unavailable`` degrades softly); otherwise the note's
    markdown body (clean ``#``-structure). Deterministic; no network, no LLM.

    NDA-1: an NDA-marked note or source is refused softly (empty spec) — the barrier
    holds even if an NDA exemplar reached here by another path.
    """
    from core.privacy import is_nda

    if is_nda(ex.path) or (ex.source_path and is_nda(ex.source_path)):
        return RenderSpec(
            source_note=ex.note_id,
            source_path=ex.source_path,
            fmt=ex.fmt,
            available=False,
            reason=_NDA_REASON,
        )
    if ex.source_path:
        return _from_binary(ex, vault_path=vault_path)
    return _from_markdown(ex)


def _from_markdown(ex: Exemplar) -> RenderSpec:
    """Extract the form from a markdown note body (clean ``#``-structure)."""
    body = ""
    try:
        if ex.path:
            body = read_note(Path(ex.path)).body
    except (OSError, ValueError):
        body = ""

    sections = _markdown_sections(body)
    lines = [ln.rstrip() for ln in body.splitlines()]
    non_heading = [ln for ln in lines if not ln.lstrip().startswith("#")]
    return _assemble_spec(ex, sections=sections, text_lines=non_heading, fmt="md")


def _from_binary(ex: Exemplar, *, vault_path: Path | None) -> RenderSpec:
    """Extract the form from a lifted binary source (SRC-1), degrading softly."""
    # Imported lazily so exemplar discovery doesn't pull the sources stack.
    from core.sources import lift_from

    lifted = lift_from(path=ex.source_path, vault_path=vault_path)
    if lifted.status != "ok":
        return RenderSpec(
            source_note=ex.note_id,
            source_path=ex.source_path,
            fmt=ex.fmt,
            available=False,
            reason=lifted.reason or "источник недоступен",
        )
    text_lines = [ln.rstrip() for ln in (lifted.text or "").splitlines()]
    sections = _text_sections(text_lines)
    return _assemble_spec(ex, sections=sections, text_lines=text_lines, fmt=ex.fmt or lifted.kind)


def _assemble_spec(
    ex: Exemplar, *, sections: list[str], text_lines: list[str], fmt: str | None
) -> RenderSpec:
    """Shared assembly: letterhead / salutation / closing / boilerplate / sample."""
    salutation, sal_idx = _find_salutation(text_lines)
    closing = _find_closing(text_lines)
    letterhead = _letterhead(text_lines, sal_idx)
    boilerplate = _boilerplate(text_lines)
    sample = _sample_paragraph(text_lines, sal_idx)
    return RenderSpec(
        sections=sections,
        letterhead=letterhead,
        salutation=salutation,
        closing=closing,
        boilerplate=boilerplate,
        sample=sample,
        source_note=ex.note_id,
        source_path=ex.source_path,
        fmt=fmt,
    )


def _markdown_sections(body: str) -> list[str]:
    """Ordered ``#``-headings, indented by depth (``## X`` → ``  X``)."""
    out: list[str] = []
    for raw in body.splitlines():
        line = raw.strip()
        m = re.match(r"^(#{1,6})\s+(.*\S)\s*$", line)
        if not m:
            continue
        level = len(m.group(1))
        text = m.group(2).strip()
        out.append(("  " * (level - 1)) + text)
        if len(out) >= _MAX_SECTIONS:
            break
    return out


def _text_sections(lines: list[str]) -> list[str]:
    """Heading-like lines from a lifted text layer (numbered / caps / short title)."""
    out: list[str] = []
    for raw in lines:
        line = raw.strip()
        if not line or len(line) > 80:
            continue
        if _NUMBERED_RE.match(line):
            out.append(line)
        elif _is_title_line(line):
            out.append(line)
        if len(out) >= _MAX_SECTIONS:
            break
    return out


def _is_title_line(line: str) -> bool:
    """A short, heading-ish line: ALL-CAPS or Title-case, no terminal '.'/'!'/'?'."""
    if line[-1:] in ".!?,:;":
        return False
    if not any(ch.isalpha() for ch in line):
        return False
    letters = [ch for ch in line if ch.isalpha()]
    if letters and all(ch.isupper() for ch in letters) and len(line) <= 70:
        return True
    # Title-ish: <= 6 words, first letter uppercase, few lowercase-only words.
    words = line.split()
    if len(words) <= 6 and line[:1].isupper() and len(line) <= 60:
        return True
    return False


def _find_salutation(lines: list[str]) -> tuple[str | None, int]:
    """First salutation line and its index (``-1`` when none)."""
    for i, raw in enumerate(lines):
        line = raw.strip()
        if line and _SALUTATION_RE.match(line):
            return line, i
    return None, -1


def _find_closing(lines: list[str]) -> str | None:
    """Closing marker plus up to two following non-empty signature lines."""
    for i, raw in enumerate(lines):
        line = raw.strip()
        if line and _CLOSING_RE.match(line):
            sig = [line]
            for follow in lines[i + 1 : i + 4]:
                f = follow.strip()
                if f:
                    sig.append(f)
                if len(sig) >= 3:
                    break
            return " / ".join(sig)
    return None


def _letterhead(lines: list[str], sal_idx: int) -> str | None:
    """Top requisite/header block: lines before the salutation that read as a blank.

    Bounded to the first :data:`_MAX_LETTERHEAD_LINES` non-empty, non-heading lines
    before the salutation; kept only when at least one carries a letterhead signal
    (company form / contacts), so plain prose is not mistaken for a blank.
    """
    upto = sal_idx if sal_idx >= 0 else len(lines)
    head: list[str] = []
    for raw in lines[:upto]:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        head.append(line)
        if len(head) >= _MAX_LETTERHEAD_LINES:
            break
    if not head:
        return None
    if not any(_LETTERHEAD_RE.search(ln) for ln in head):
        return None
    return "\n".join(head)


def _boilerplate(lines: list[str]) -> list[str]:
    """Recurring service formulas (confidentiality / offer disclaimers …)."""
    out: list[str] = []
    seen: set[str] = set()
    for raw in lines:
        line = raw.strip()
        if line and _BOILERPLATE_RE.search(line):
            key = line.lower()
            if key not in seen:
                seen.add(key)
                out.append(line)
    return out


def _sample_paragraph(lines: list[str], sal_idx: int) -> str | None:
    """One short body-paragraph excerpt after the salutation (fallback hint only)."""
    start = sal_idx + 1 if sal_idx >= 0 else 0
    for raw in lines[start:]:
        line = raw.strip()
        if len(line) >= 40 and not line.startswith("#") and not _CLOSING_RE.match(line):
            excerpt = line[:_SAMPLE_CHARS]
            return excerpt + ("…" if len(line) > _SAMPLE_CHARS else "")
    return None
