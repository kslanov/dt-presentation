"""Facts Plane — typed, labelled facts over lifted sources (FACT-1, §10a).

Turns SRC-1's cell-addressable :class:`~core.sources.resolver.LiftResult` into a
semantic layer of :class:`~core.facts.schema.Fact` objects — *"себестоимость
витрины = 480"* vs *"витрина+ЭХД = 654,1"*, each with a back-traceable locator —
so generation uses the exact right number instead of guessing (production audit,
Acme). :func:`~core.facts.extract.extract_facts` is a pure deterministic function
(Path B — no LLM/network); :mod:`~core.facts.store` persists and queries them.

Invariants (tests): ``core/facts`` ⊥ MCP/CLI; extractor ⊥ store.
"""

from __future__ import annotations

from core.facts.extract import extract_facts
from core.facts.materialize import ensure_facts
from core.facts.schema import (
    EXTRACTOR_VERSION,
    FACT_KINDS,
    SCHEMA_VERSION,
    Fact,
    compute_fact_id,
)
from core.facts.store import get_facts, init_db, replace_source_facts, upsert_facts

__all__ = [
    "Fact",
    "compute_fact_id",
    "extract_facts",
    "get_facts",
    "upsert_facts",
    "replace_source_facts",
    "ensure_facts",
    "init_db",
    "FACT_KINDS",
    "SCHEMA_VERSION",
    "EXTRACTOR_VERSION",
]
