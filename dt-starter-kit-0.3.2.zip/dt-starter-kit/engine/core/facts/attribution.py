"""Атрибуция фактов к сущности: ``entity_ref`` = хаб, а не id легаси-заметки (FACTS-BITEMPORAL-1
п.5).

Класс дефекта (тот же, что в HUB-SYNTH-1): у 4 из 5 источников стора ``entity_ref`` - id заметки
(``legacy-19186d4ed0ab``), хаб только у Acme, и факты по хабу (``get_facts(entity=…)``, досье
``hub_synth_context``) не находят то, что к клиенту относится.

Правило (ТЗ): ``entity_ref`` меняется ТОЛЬКО там, где резолв однозначен (ровно один клиентский хаб),
иначе остается прежнее значение. Резолв - детерминированный, по каталогу имен хабов
(:func:`core.retrieval.hubcat.hub_catalog` - тот же, что у поиска и ``parse_task``):

1. подсказка вызывающего сама является id клиентского хаба - берем ее;
2. имена хабов (заголовок/алиасы) целым словом в пути источника: ровно один хаб - он;
3. два и больше хабов или ни одного - ``None`` (оставить прежнее).

Источники ВНЕ vault (легаси-файлы) резолвятся только по пути: содержимое не читается. Ошибка
каталога/vault - тоже ``None``: атрибуция - улучшение, а не условие записи факта.
"""

from __future__ import annotations

import unicodedata
from pathlib import Path

__all__ = ["resolve_entity", "resolve_entity_detail"]

_CLIENT = "client"


def _path_probe(source_path: str) -> str:
    """Путь источника как текст для сопоставления имен: сегменты папок и имя файла без
    расширения."""
    p = Path(unicodedata.normalize("NFC", str(source_path or "")))
    parts = [*p.parent.parts[-8:], p.stem]  # хвост пути: корень диска/iCloud к клиенту не относится
    return " / ".join(x for x in parts if x not in ("/", ""))


def resolve_entity_detail(
    source_path: str, *, hint: str | None = None, vault_path: Path | None = None
) -> tuple[str | None, str]:
    """``(hub_id | None, причина)``: однозначный клиентский хаб источника или ``None`` с
    пояснением."""
    try:
        from core.config import default_vault_path
        from core.retrieval.hubcat import hub_catalog, match_hubs

        vault = Path(vault_path) if vault_path is not None else default_vault_path()
        catalog = hub_catalog(vault, (_CLIENT,))
    except Exception as exc:  # noqa: BLE001 - каталог недоступен: оставляем прежнее
        return None, f"каталог хабов недоступен: {str(exc)[:80]}"
    if hint and any(e.note_id == hint for e in catalog):
        return hint, "подсказка - клиентский хаб"
    hits = match_hubs(_path_probe(source_path), catalog)
    ids = sorted({h.note_id for h in hits})
    if len(ids) == 1:
        return ids[0], f"имя хаба в пути ({hits[0].name})"
    if not ids:
        return None, "имя хаба в пути не найдено"
    return None, f"неоднозначно: {', '.join(ids[:4])}"


def resolve_entity(
    source_path: str, *, hint: str | None = None, vault_path: Path | None = None
) -> str | None:
    """Хаб источника (однозначно) или ``None`` - вызывающий оставляет прежний ``entity_ref``."""
    return resolve_entity_detail(source_path, hint=hint, vault_path=vault_path)[0]
