"""Бэкфилл временных осей и атрибуции существующих фактов (FACTS-BITEMPORAL-1 п.1/п.5).

Миграция БД v4 (:func:`core.db.migrations._v4_facts_bitemporal`) заполняет только то, что видно из
самой
БД: ``known_at``/``valid_from``/``fact_key``. Здесь - второй, явный шаг, которому нужен листинг
папок
и каталог хабов (отсюда отдельная команда ``dt facts backfill``, а не миграция при открытии БД):

1. **атрибуция**: ``entity_ref`` → клиентский хаб, если источник резолвится однозначно
   (:mod:`core.facts.attribution`); прежнее значение остается при любой неоднозначности. Журнал
   смены
   (``источник: было → стало``) - в отчете;
2. **черновики**: ``provisional`` по маркерам имени/папки (``family_of``, маркеры свежести не
меняются);
3. ``fact_key`` пересчитывается там, где сменился ``entity_ref``;
4. **цепочка версий** по каждому семейству (:func:`core.facts.temporal.plan_links`).

Сначала строится ПЛАН целиком в памяти (чтение стора ``mode=ro``): ``dry-run`` = план без записи.
Применение идемпотентно - повторный прогон ничего не меняет. Без LLM и сети; файлы источников не
читаются (только листинг папки).
"""

from __future__ import annotations

import sqlite3
from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.facts import temporal
from core.facts.attribution import resolve_entity_detail
from core.facts.schema import Fact
from core.facts.store import _ro_connect

__all__ = ["BackfillPlan", "plan_backfill", "apply_backfill"]

_SELECT = (
    "SELECT fact_id, entity_ref, source_path, source_content_hash, locator, kind, label, section, "
    "unit, currency, valid_from, known_at, provisional, date_basis, fact_key FROM facts"
)


@dataclass
class _Source:
    path: str
    content_hash: str
    n: int
    entity_old: str | None
    entity_new: str | None = None
    entity_reason: str = ""
    draft: bool = False
    members: int = 1


@dataclass
class BackfillPlan:
    """План бэкфилла: что поменяется и сводка для отчета."""

    total: int = 0
    sources: list[_Source] = field(default_factory=list)
    dating: dict[str, int] = field(default_factory=dict)       # name/mtime/'' → число фактов
    provisional_facts: int = 0
    entity_changes: dict[str, str] = field(default_factory=dict)  # fact_id → новый entity_ref
    key_updates: dict[str, str] = field(default_factory=dict)    # fact_id → новый fact_key
    link_updates: dict[str, dict[str, str | None]] = field(default_factory=dict)
    superseded: int = 0
    hidden_from_default: int = 0   # сколько фактов уйдет из дефолтной выдачи (вытеснены на сегодня)
    visible_before: int = 0        # дефолтная выдача до бэкфилла: все факты без ordinal
    visible_after: int = 0
    families: int = 0
    unmigrated: bool = False
    provisional_updates: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "total": self.total, "dating": self.dating, "provisional_facts": self.provisional_facts,
            "entity_changes": len(self.entity_changes), "superseded": self.superseded,
            "hidden_from_default": self.hidden_from_default, "families": self.families,
            "visible_before": self.visible_before, "visible_after": self.visible_after,
        }


def _probe(r: dict[str, Any], entity: str | None) -> Fact:
    return Fact(
        fact_id=r["fact_id"], entity_ref=entity, source_path="", source_content_hash="",
        locator="", kind=r["kind"], label=r["label"] or "", value_num=None, value_raw="",
        unit=r["unit"], currency=r["currency"], section=r["section"] or "",
    )


def plan_backfill(
    db_path: Path | None = None, *, vault_path: Path | None = None, today: str | None = None
) -> BackfillPlan:
    """Построить план по стору (только чтение). БД без колонок v4 → ``unmigrated=True``, плана
    нет."""
    from core.config import facts_db_path

    plan = BackfillPlan()
    conn = _ro_connect(db_path or facts_db_path())
    if conn is None:
        return plan
    try:
        have = {r["name"] for r in conn.execute("PRAGMA table_info(facts)")}
        if "date_basis" not in have:
            plan.unmigrated = True
            return plan
        rows = [dict(r) for r in conn.execute(_SELECT)]
    finally:
        conn.close()
    plan.total = len(rows)
    plan.dating = dict(Counter(str(r["date_basis"] or "") for r in rows))
    day = today or datetime.now(UTC).date().isoformat()
    plan.visible_before = sum(1 for r in rows if r["kind"] != "ordinal")

    # --- источники: атрибуция и черновики -------------------------------------------------------
    by_hash: dict[str, _Source] = {}
    for r in rows:
        h = str(r["source_content_hash"])
        s = by_hash.get(h)
        if s is None:
            s = by_hash[h] = _Source(str(r["source_path"]), h, 0, r["entity_ref"])
        s.n += 1
    lineage: dict[str, tuple[set[str], set[str], set[str]]] = {}
    for s in sorted(by_hash.values(), key=lambda x: x.path):
        hub, why = resolve_entity_detail(s.path, hint=s.entity_old, vault_path=vault_path)
        s.entity_reason = why
        if hub and hub != s.entity_old:
            s.entity_new = hub
        try:
            paths, drafts, archived = temporal.lineage_of(s.path)
        except Exception:  # noqa: BLE001 - листинг папки не обязателен
            paths, drafts, archived = {s.path}, set(), set()
        lineage[s.path] = (paths, drafts, archived)
        s.draft = s.path in drafts
        s.members = len(paths)
        plan.sources.append(s)

    new_entity = {s.content_hash: s.entity_new for s in plan.sources if s.entity_new}
    draft_hash = {s.content_hash for s in plan.sources if s.draft}
    for r in rows:
        h = str(r["source_content_hash"])
        entity = new_entity.get(h, r["entity_ref"])
        if h in new_entity:
            plan.entity_changes[r["fact_id"]] = new_entity[h]
        key = temporal.fact_key(_probe(r, entity))
        if key != r["fact_key"]:
            plan.key_updates[r["fact_id"]] = key
        want_prov = 1 if h in draft_hash else 0
        if want_prov != int(r["provisional"] or 0):
            plan.provisional_updates[r["fact_id"]] = want_prov
        r["provisional"] = want_prov
    plan.provisional_facts = sum(1 for r in rows if r["provisional"])

    # --- цепочки по семействам -----------------------------------------------------------------
    for r in rows:
        r["_match_key"] = temporal.match_key(_probe(r, None))
    seen: set[frozenset[str]] = set()
    merged: dict[str, dict[str, str | None]] = {}
    for path in sorted(lineage):
        paths, _drafts, archived = lineage[path]
        family_key = frozenset(paths)
        if family_key in seen:
            continue
        seen.add(family_key)
        sub = [r for r in rows if r["source_path"] in paths]
        lp = temporal.plan_links(sub, archived_paths=archived)
        merged.update(lp.updates)
        plan.superseded += lp.superseded
        plan.families += 1 if lp.versions > 1 else 0
    plan.link_updates = merged
    hidden = 0
    for r in rows:
        u = merged.get(r["fact_id"])
        if u and u["valid_to"] and u["valid_to"] <= day and r["kind"] != "ordinal":
            hidden += 1
    plan.hidden_from_default = hidden
    plan.visible_after = plan.visible_before - hidden
    return plan


def apply_backfill(plan: BackfillPlan, db_path: Path | None = None) -> dict[str, int]:
    """Записать план одной транзакцией (идемпотентно). Возвращает ``{entity, keys, provisional,
    links}``."""
    from core.config import facts_db_path
    from core.db import connect

    if plan.unmigrated:
        return {"entity": 0, "keys": 0, "provisional": 0, "links": 0}
    conn = connect(db_path or facts_db_path())
    try:
        with conn:
            _executemany(conn, "UPDATE facts SET entity_ref=? WHERE fact_id=?",
                         [(v, k) for k, v in plan.entity_changes.items()])
            _executemany(conn, "UPDATE facts SET fact_key=? WHERE fact_id=?",
                         [(v, k) for k, v in plan.key_updates.items()])
            _executemany(conn, "UPDATE facts SET provisional=? WHERE fact_id=?",
                         [(v, k) for k, v in plan.provisional_updates.items()])
        lp = temporal.LinkPlan(updates=plan.link_updates)
        links = temporal.apply_plan(conn, lp)
    finally:
        conn.close()
    return {"entity": len(plan.entity_changes), "keys": len(plan.key_updates),
            "provisional": len(plan.provisional_updates), "links": links}


def _executemany(conn: sqlite3.Connection, sql: str, batch: list[tuple[object, ...]]) -> None:
    if batch:
        conn.executemany(sql, batch)
