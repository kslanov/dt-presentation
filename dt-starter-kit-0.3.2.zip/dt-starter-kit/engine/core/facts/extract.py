"""Deterministic fact extraction from a lifted source (FACT-1, PART-2).

Reads a SRC-1 :class:`~core.sources.resolver.LiftResult` and derives typed,
labelled :class:`~core.facts.schema.Fact` objects. A number in a sheet is given
meaning by its neighbouring labels — two layouts, both supported, neither
hardcoded as the only one:

- **label to the left** (common in estimates): the leftmost text cell in the same
  row (``A7`` → ``B7``);
- **header above**: the nearest text cell scanning up the same column.

Text formats (docx/pdf/pptx) get regex extraction over the flat ``text`` layer:
Kazakh БИН/ИИН (12 digits, control-digit validated), e-mail, phone, and
best-effort free-text amounts.

Path B: **fully deterministic — no LLM, no network**. The same bytes in yield the
same facts out (``extracted_at`` is stamped later by the store, not here, so the
pure function stays reproducible). :func:`extract_facts` never touches the store —
extractor ⊥ store, exactly as SRC-1 keeps parsers ⊥ cache.
"""

from __future__ import annotations

import datetime as _dt
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from core.facts.schema import (
    KIND_BIN,
    KIND_CONTACT,
    KIND_DATE,
    KIND_MONEY,
    KIND_ORDINAL,
    KIND_QUANTITY,
    KIND_RATE,
    Fact,
    compute_fact_id,
)
from core.facts.units import (
    detect_currency,
    detect_scale,
    detect_unit,
    detect_vat,
    has_percent,
)

if TYPE_CHECKING:
    from core.sources.parsers import Cell, Row, Table
    from core.sources.resolver import LiftResult

__all__ = ["extract_facts"]

# Confidence tiers — how cleanly the label matched (PART-2).
CONF_HIGH = 0.9  # a single clean row label (optionally + a header)
CONF_MEDIUM = 0.6  # only a header, or an ambiguous row (several text candidates)
CONF_LOW = 0.3  # weak / best-effort (free-text amount, unvalidated requisite)
CONF_NONE = 0.15  # a number with no label at all — kept, never invented

# --- lexical signals (lowercased, matched as substrings on the label/context) --
_MONEY_TERMS = (
    "сумма", "стоимост", "цена", "итог", "бюджет", "себестоимост", "выручк",
    "затрат", "расход", "оплат", "прайс", "amount", "cost", "price", "total",
    "руб", "тенге", "тнг",
)
_RATE_TERMS = ("ставк", "процент", "rate", "%")
_DATE_TERMS = ("дата", "срок", "период", "date", "дедлайн", "deadline")

# currency token → normalized code. Order matters (longer/specific first).
_CURRENCY_MAP = (
    ("₸", "KZT"), ("тг", "KZT"), ("тенге", "KZT"), ("тнг", "KZT"), ("kzt", "KZT"),
    ("₽", "RUB"), ("руб", "RUB"), ("rub", "RUB"),
    ("$", "USD"), ("usd", "USD"),
    ("€", "EUR"), ("eur", "EUR"),
)

_BIN_RE = re.compile(r"\b(\d{12})\b")
_EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")
_PHONE_RE = re.compile(r"(?:\+7|8)[\s\-(]*\d{3}[\s\-)]*\d{3}[\s\-]*\d{2}[\s\-]*\d{2}")
# Free-text amount: digits (with spaces/thousands/locale decimal) then a currency.
_AMOUNT_RE = re.compile(
    r"(\d[\d\s.,]*\d|\d)\s*(₸|₽|руб\.?|тенге|тнг|kzt|rub|usd|\$|eur|€)",
    re.IGNORECASE,
)
# An ISO date/datetime string — SRC-1 normalizes date cells to isoformat, so a
# date reaches us as a string (never a bare datetime after the cache roundtrip).
_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2})?)?")
# A whole cell string that is just a locale-formatted number ("654,1", "1 200,50").
_NUMERIC_STR_RE = re.compile(r"^-?\d{1,3}(?:[   ]?\d{3})*(?:[.,]\d+)?$")


def extract_facts(lifted: LiftResult, *, entity_ref: str | None = None) -> list[Fact]:
    """Extract typed facts from a lifted source (pure, deterministic).

    Spreadsheets (``lifted.tables``) go through the label heuristic; other kinds
    fall back to regex over ``lifted.text``. Returns ``[]`` for an unavailable /
    empty lift. ``entity_ref`` (the client/deal hub the source was resolved from)
    is attached to every fact for later scoping.
    """
    if lifted.status != "ok":
        return []
    # NDA-1 defense-in-depth: never derive facts from an NDA-marked source (the
    # lift already refuses, so this only guards a legacy ok-status result).
    from core.privacy import is_nda

    if is_nda(lifted.path):
        return []
    facts: list[Fact] = []
    if lifted.tables:
        for table in lifted.tables:
            facts.extend(
                _facts_from_table(
                    table,
                    source_path=lifted.path,
                    content_hash=lifted.content_hash,
                    stale_hint=lifted.stale_hint,
                    entity_ref=entity_ref,
                )
            )
    else:
        facts.extend(
            _facts_from_text(
                lifted.text,
                source_path=lifted.path,
                content_hash=lifted.content_hash,
                stale_hint=lifted.stale_hint,
                entity_ref=entity_ref,
            )
        )
    return facts


# --------------------------------------------------------------------------- #
# Spreadsheet path (FACT-2: контекст по колонке, объединения, границы таблиц)  #
# --------------------------------------------------------------------------- #
#
# Лист режется на блоки-таблицы; у каждой - своя цепочка шапки колонки (``header_chain``), и число
# получает тип/единицу/валюту/НДС ИЗ ЦЕПОЧКИ колонки (затем из заголовка таблицы и ярлыка строки),
# а не из слов «всей строки». Ярлык строки - ближайшая подходящая подпись слева, секция - самая
# левая (отдельное поле). Порядковые номера (колонка «№»/«Этап») - ``ordinal``, а не деньги.

_NAME_HINT_RE = re.compile(
    r"наименован|название|статья|показател|позици|компонент|услуг|работ|предмет|роль|должност"
    r"|товар|продукт|модул|\b(?:item|name|description|role)\b"
)
_SKIP_HINT_RE = re.compile(
    r"срок|ед\.?\s?изм|единиц|примечан|комментар|remark|\bnotes?\b|результат|deliverable"
    r"|статус|ответственн"
)
_ORDINAL_HEADER_RE = re.compile(
    r"^(?:№|n|no\.?|nr\.?|#|п\s*/\s*п|№\s*п\s*/\s*п|номер|этап|num\.?)$"
)
_DURATION_RE = re.compile(
    r"^\d+(?:[-–]\d+)?\s*(?:мес\w*|дн\w*|дней|нед\w*|год\w*|лет|кв\.?|час\w*|ч\.?)$"
)
_TOTAL_RE = re.compile(r"^\s*(?:итого|итог|всего|total|grand total)\b", re.IGNORECASE)
_MAX_LABEL_LEN = 160  # длиннее - не подпись, а описание/перечень результатов
_MAX_MERGE_AREA = 2000  # объединение шире - не растягиваем (заголовок на весь лист)


def _col_idx(col: str) -> int:
    """Column letters → 1-based index (``"A"``→1, ``"B"``→2, ``"AA"``→27)."""
    idx = 0
    for ch in col.upper():
        idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return idx


def _is_number(cell: Cell) -> bool:
    return bool(cell.is_number) and not _is_date(cell.value)


def _is_date(value: object) -> bool:
    """A date cell: a datetime/date object OR (post-cache) an ISO-date string."""
    if isinstance(value, (_dt.datetime, _dt.date)):
        return True
    return isinstance(value, str) and bool(_ISO_DATE_RE.match(value.strip()))


def _cell_text(cell: Cell) -> str:
    """The cell's textual content if it is a non-numeric, non-date label, else ''."""
    if _is_number(cell) or _is_date(cell.value):
        return ""
    if isinstance(cell.value, str):
        s = cell.value.strip()
        # A string that is really a locale number is a value, not a label.
        return "" if _NUMERIC_STR_RE.match(s) else s
    return ""


def _numeric_str(cell: Cell) -> tuple[float, str] | None:
    """If the cell holds a number (real or a locale-string), return (value, raw)."""
    if _is_number(cell):
        return float(cell.value), _num_raw(cell.value)
    if isinstance(cell.value, str):
        s = cell.value.strip()
        if _NUMERIC_STR_RE.match(s):
            norm = s.replace(" ", "").replace(" ", "").replace(" ", "")
            norm = norm.replace(",", ".")
            try:
                return float(norm), s
            except ValueError:
                return None
    return None


def _num_raw(value: object) -> str:
    """Original-ish string form of a real number (no trailing ``.0`` on integers)."""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def _norm_ws(text: str) -> str:
    return " ".join(text.split())


@dataclass
class _Table:
    """Один блок листа: границы, шапка, данные."""

    c0: int
    c1: int
    head_rows: list[int] = field(default_factory=list)  # номера строк шапки/заголовка
    title_rows: list[int] = field(default_factory=list)  # подмножество head_rows - заголовок
    data_rows: list[Row] = field(default_factory=list)  # строки с числом/датой
    has_data: bool = False


class _Sheet:
    """Индекс листа: ячейки, текст объединенных диапазонов, колонки-блоки."""

    def __init__(self, table: Table) -> None:
        self.table = table
        self.cells: dict[tuple[int, int], Cell] = {}
        self.rows: dict[int, Row] = {}
        for row in table.rows:
            self.rows[row.r] = row
            for cell in row.cells:
                self.cells[(row.r, _col_idx(cell.col))] = cell
        # текст объединенной ячейки на ВСЕХ накрытых клетках (кроме левой верхней)
        self.span_text: dict[tuple[int, int], str] = {}
        for r0, c0, r1, c1 in table.merges:
            top = self.cells.get((r0, c0))
            if top is None or (r1 - r0 + 1) * (c1 - c0 + 1) > _MAX_MERGE_AREA:
                continue
            text = _cell_text(top)
            if not text:
                continue
            for rr in range(r0, r1 + 1):
                for cc in range(c0, c1 + 1):
                    if (rr, cc) != (r0, c0):
                        self.span_text[(rr, cc)] = text

    def text_at(self, r: int, c: int) -> str:
        cell = self.cells.get((r, c))
        if cell is not None:
            return _cell_text(cell)
        return self.span_text.get((r, c), "")

    def row_texts(self, r: int, c0: int, c1: int) -> list[tuple[int, str]]:
        """Тексты строки в колонках блока (с объединенными), по возрастанию колонки."""
        out: list[tuple[int, str]] = []
        for c in range(c0, c1 + 1):
            t = self.text_at(r, c)
            if t:
                out.append((c, t))
        return out

    def column_bands(self) -> list[tuple[int, int]]:
        """Блоки колонок: пустая колонка режет лист, только если с обеих сторон есть числа.

        Два расчета рядом через пустую колонку (ПГМ | ЭХД) - две таблицы; пустая колонка-отбивка
        между подписью (A) и числами (C) - НЕ граница (слева чисел нет).
        """
        occupied = sorted({c for _r, c in self.cells})
        if not occupied:
            return []
        numeric_cols = {
            c for (_r, c), cell in self.cells.items()
            if _numeric_str(cell) is not None or _is_date(cell.value)  # csv: числа - строки
        }
        bands: list[list[int]] = [[occupied[0]]]
        for c in occupied[1:]:
            if c - bands[-1][-1] > 1:
                bands.append([c])
            else:
                bands[-1].append(c)
        merged = [bands[0]]
        for band in bands[1:]:
            left_num = any(c in numeric_cols for c in merged[-1])
            right_num = any(c in numeric_cols for c in band)
            if left_num and right_num:
                merged.append(band)
            else:
                merged[-1] = merged[-1] + band
        return [(b[0], b[-1]) for b in merged]


def _row_kind(sheet: _Sheet, row: Row, c0: int, c1: int) -> tuple[str, int]:
    """``data`` (есть число/дата) | ``textN`` (>=2 текста) | ``text1`` (один); число текстов."""
    has_num = False
    texts = 0
    for cell in row.cells:
        ci = _col_idx(cell.col)
        if not c0 <= ci <= c1:
            continue
        if _is_number(cell) or _is_date(cell.value) or _numeric_str(cell) is not None:
            has_num = True
        elif _cell_text(cell):
            texts += 1
    if has_num:
        return "data", texts
    return ("textN" if texts >= 2 else "text1"), texts


def _split_tables(sheet: _Sheet, c0: int, c1: int) -> list[_Table]:
    """Блок колонок → таблицы: новая шапка после чисел или голое число после пропуска строк."""
    tables: list[_Table] = []
    cur = _Table(c0, c1)
    cur_num_cols: set[int] = set()  # колонки с числами в строках данных текущей таблицы
    pending: list[int] = []  # text1-строки после последней data-строки (кандидаты в заголовок)
    prev_r: int | None = None
    for r in sorted(sheet.rows):
        row = sheet.rows[r]
        if not any(c0 <= _col_idx(c.col) <= c1 for c in row.cells):
            continue
        kind, ntext = _row_kind(sheet, row, c0, c1)
        gap = prev_r is not None and r - prev_r > 2  # две пустые строки и больше: разрыв
        prev_r = r
        if kind == "data":
            row_cols = {
                _col_idx(c.col) for c in row.cells
                if c0 <= _col_idx(c.col) <= c1
                and (_numeric_str(c) is not None or _is_date(c.value))
            }
            # голое число после разрыва (>= 2 пустых строк; одна - отбивка внутри таблицы) -
            # отдельная таблица без шапки, КРОМЕ продолжения колонки, где в таблице уже есть числа
            if cur.has_data and gap and ntext == 0 and not row_cols <= cur_num_cols:
                tables.append(cur)
                cur = _Table(c0, c1)
                cur_num_cols = set()
                pending = []
            cur.data_rows.append(row)
            cur.has_data = True
            cur_num_cols |= row_cols
            pending = []
            continue
        if cur.has_data:
            if kind == "textN":
                tables.append(cur)  # строка из одних текстов после чисел - новая шапка
                cur = _Table(c0, c1, head_rows=[*pending, r], title_rows=list(pending))
                cur_num_cols = set()
                pending = []
            else:
                pending.append(r)  # одиночный текст: секция внутри таблицы или заголовок следующей
        else:
            cur.head_rows.append(r)
    if cur.head_rows or cur.data_rows:
        tables.append(cur)
    for t in tables:
        _classify_head(sheet, t)
    return tables


def _classify_head(sheet: _Sheet, t: _Table) -> None:
    """Из строк шапки выделить заголовок: text1-строки ДО первой textN-строки.

    Если textN-строк в шапке нет (одна подпись над колонкой), все строки - цепочка колонки.
    """
    if t.title_rows:  # уже выделен (шапка после чисел)
        return
    kinds = [(r, _row_kind(sheet, sheet.rows[r], t.c0, t.c1)[0]) for r in t.head_rows]
    if not any(k == "textN" for _r, k in kinds):
        return
    for r, k in kinds:
        if k == "text1":
            t.title_rows.append(r)
        else:
            break


def _chain(sheet: _Sheet, t: _Table, c: int) -> list[str]:
    """``header_chain`` колонки ``c``: тексты шапки сверху вниз (объединенные накрывают колонку)."""
    parts: list[str] = []
    for r in t.head_rows:
        if r in t.title_rows:
            continue
        text = _norm_ws(sheet.text_at(r, c))
        if text and (not parts or parts[-1].casefold() != text.casefold()):
            parts.append(text)
    return parts


def _title(sheet: _Sheet, t: _Table) -> str:
    parts = []
    for r in t.title_rows:
        for _c, text in sheet.row_texts(r, t.c0, t.c1):
            norm = _norm_ws(text)
            if norm and norm not in parts:
                parts.append(norm)
    return " · ".join(parts)


def _is_total_row(texts: list[tuple[int, str]], first_num_col: int) -> bool:
    return any(c < first_num_col and _TOTAL_RE.match(t) for c, t in texts)


def _column_roles(
    sheet: _Sheet, t: _Table, chains: dict[int, list[str]]
) -> tuple[set[int], set[int], set[int]]:
    """``(ordinal, skip, name)`` - номера колонок блока по подписи шапки и значениям."""
    ordinal: set[int] = set()
    skip: set[int] = set()
    name: set[int] = set()
    numeric_cols: dict[int, list[float]] = {}
    for row in t.data_rows:
        texts = sheet.row_texts(row.r, t.c0, t.c1)
        first_num = min(
            (
                _col_idx(c.col) for c in row.cells
                if t.c0 <= _col_idx(c.col) <= t.c1 and _numeric_str(c) is not None
            ),
            default=t.c1 + 1,
        )
        if _is_total_row(texts, first_num):
            continue
        for cell in row.cells:
            ci = _col_idx(cell.col)
            num = _numeric_str(cell)
            if t.c0 <= ci <= t.c1 and num is not None and not _is_date(cell.value):
                numeric_cols.setdefault(ci, []).append(num[0])
    for c in range(t.c0, t.c1 + 1):
        head = " ".join(chains.get(c, [])).lower()
        if _NAME_HINT_RE.search(head):
            name.add(c)
        if _SKIP_HINT_RE.search(head):
            skip.add(c)
        values = numeric_cols.get(c)
        if not values:
            continue
        ints = all(v == int(v) and v >= 0 for v in values)
        levels = [lv.lower().strip(" .:") for lv in chains.get(c, [])]
        if ints and any(_ORDINAL_HEADER_RE.match(lv) for lv in levels):
            ordinal.add(c)
    # без шапки: ЛЕВАЯ числовая колонка с монотонными целыми 1..N (N >= 2)
    if numeric_cols:
        left = min(numeric_cols)
        vals = numeric_cols[left]
        if (
            left not in ordinal and not chains.get(left) and len(vals) >= 2
            and vals == [float(i) for i in range(1, len(vals) + 1)]
        ):
            ordinal.add(left)
    return ordinal, skip, name


def _label_for(
    texts: list[tuple[int, str]], c: int, skip: set[int], name: set[int]
) -> tuple[int, str] | None:
    """Ярлык строки: ближайшая подходящая подпись СЛЕВА (колонка с шапкой «Наименование» - вперед).

    Из кандидатов исключены колонки сроков/комментариев, длительности («4-5 мес») и перечни
    результатов. Текст в колонке порядковых номеров («ИТОГО» под «Этап») - допустимая подпись
    (числа-номера сюда не попадают: это не тексты). Подписи нет - ``None`` (число без ярлыка).
    """
    cands = [
        (cc, tt) for cc, tt in texts
        if cc < c and cc not in skip
        and not _DURATION_RE.match(tt.lower().strip()) and len(tt) <= _MAX_LABEL_LEN
    ]
    if not cands:
        return None
    named = [x for x in cands if x[0] in name]
    return (named or cands)[-1]


def _signal_kind(text: str) -> str | None:
    """Тип по ОДНОЙ подписи: деньги (валюта) > количество (единица) > ставка > деньги (слово)."""
    if not text:
        return None
    low = text.lower()
    if detect_currency(low):
        return KIND_MONEY
    if detect_unit(low):
        return KIND_QUANTITY
    if has_percent(low) or ("ставк" in low and not detect_currency(low)):
        return KIND_RATE
    if any(t in low for t in _MONEY_TERMS):
        return KIND_MONEY
    return None


def _facts_from_table(
    table: Table,
    *,
    source_path: str,
    content_hash: str,
    stale_hint: bool,
    entity_ref: str | None,
) -> list[Fact]:
    """Факты одного листа: блоки колонок → таблицы → число с контекстом ЕГО колонки."""
    sheet = _Sheet(table)
    facts: list[Fact] = []
    for c0, c1 in sheet.column_bands():
        for t in _split_tables(sheet, c0, c1):
            facts.extend(
                _facts_from_block(
                    sheet, t, source_path=source_path, content_hash=content_hash,
                    stale_hint=stale_hint, entity_ref=entity_ref,
                )
            )
    return facts


def _facts_from_block(
    sheet: _Sheet,
    t: _Table,
    *,
    source_path: str,
    content_hash: str,
    stale_hint: bool,
    entity_ref: str | None,
) -> list[Fact]:
    chains = {c: _chain(sheet, t, c) for c in range(t.c0, t.c1 + 1)}
    title = _title(sheet, t)
    ordinal, skip, name = _column_roles(sheet, t, chains)

    # Явные (валюта, масштаб) денежных колонок блока: единственная пара - наследуется колонками
    # без собственной (итоговые «Итого ... по этапу» рядом с «(млн тенге)»).
    explicit: set[tuple[str | None, float | None, str | None]] = set()
    for chain in chains.values():
        text = " / ".join(chain)
        if _signal_kind(text) == KIND_MONEY and (detect_currency(text) or detect_scale(text)):
            explicit.add((detect_currency(text), detect_scale(text), detect_vat(text)))
    inheritable = next(iter(explicit)) if len(explicit) == 1 else None

    # частота ярлыков в таблице (для «ярлык уникален»)
    label_count: dict[str, int] = {}
    prepared: list[tuple[Row, list[tuple[int, str]]]] = []
    for row in t.data_rows:
        texts = sheet.row_texts(row.r, t.c0, t.c1)
        prepared.append((row, texts))
        first = next((c for c, _t in texts), None)
        if first is not None:
            for cell in row.cells:
                if _numeric_str(cell) is not None or _is_date(cell.value):
                    lab = _label_for(texts, _col_idx(cell.col), skip, name)
                    if lab:
                        label_count[lab[1]] = label_count.get(lab[1], 0) + 1
                    break

    facts: list[Fact] = []
    for row, texts in prepared:
        numeric_cols = [
            _col_idx(c.col) for c in row.cells
            if t.c0 <= _col_idx(c.col) <= t.c1
            and (_numeric_str(c) is not None or _is_date(c.value))
        ]
        is_total = _is_total_row(texts, min(numeric_cols, default=t.c1 + 1))
        for cell in row.cells:
            ci = _col_idx(cell.col)
            if not t.c0 <= ci <= t.c1:
                continue
            is_date = _is_date(cell.value)
            numeric = _numeric_str(cell)
            if not is_date and numeric is None:
                continue

            lab = _label_for(texts, ci, skip, name)
            row_label = lab[1] if lab else ""
            label_col = lab[0] if lab else None
            chain = chains.get(ci, [])
            chain_text = " / ".join(chain)
            section = ""
            if label_col is not None:
                left = [
                    (cc, tt) for cc, tt in texts
                    if cc < label_col and cc not in skip
                ]
                if left and left[0][1] != row_label:
                    section = left[0][1]

            label = f"{chain_text} — {row_label}" if chain_text and row_label else (
                row_label or chain_text
            )
            locator = f"{sheet.table.sheet}!{cell.ref}"
            unit: str | None = None
            scale: float | None = None
            currency: str | None = None
            vat: str | None = None
            inherited = False

            if is_date:
                kind = KIND_DATE
                value_num: float | None = None
                value_raw = _date_raw(cell.value)
            else:
                assert numeric is not None  # noqa: S101 — type-narrowing assert; non-None guaranteed above
                value_num, value_raw = numeric
                if ci in ordinal:
                    kind = KIND_ORDINAL
                else:
                    kind = (
                        _signal_kind(chain_text) or _signal_kind(row_label) or _signal_kind(title)
                        or KIND_QUANTITY
                    )
                    sources = [chain_text, title, row_label]
                    if kind == KIND_MONEY:
                        currency = next((c for s in sources if (c := detect_currency(s))), None)
                        vat = next((v for s in sources if (v := detect_vat(s))), None)
                        scale = next((m for s in sources if (m := detect_scale(s))), None)
                        if currency is None and scale is None and inheritable is not None:
                            currency, scale, inh_vat = inheritable
                            vat = vat or inh_vat
                            inherited = currency is not None or scale is not None
                        unit = currency
                    elif kind == KIND_QUANTITY:
                        unit = next(
                            (u for s in (chain_text, row_label, title) if (u := detect_unit(s))),
                            None,
                        )
                        scale = next((m for s in (chain_text, row_label) if (m := detect_scale(s))),
                                     None)
                    elif kind == KIND_RATE:
                        unit = "%"

            confidence = _confidence(
                row_label, bool(chain),
                unique=bool(row_label) and label_count.get(row_label, 0) == 1,
                inherited=inherited,
            )
            facts.append(
                Fact(
                    fact_id=compute_fact_id(content_hash, locator, kind),
                    entity_ref=entity_ref,
                    source_path=source_path,
                    source_content_hash=content_hash,
                    locator=locator,
                    kind=kind,
                    label=label,
                    value_num=value_num,
                    value_raw=value_raw,
                    unit=unit,
                    currency=currency if kind == KIND_MONEY else None,
                    vat_flag=vat if kind == KIND_MONEY else None,
                    confidence=confidence,
                    stale_hint=stale_hint,
                    scale=scale,
                    section=section,
                    is_total=is_total,
                )
            )
    return facts


def _confidence(row_label: str, has_chain: bool, *, unique: bool, inherited: bool) -> float:
    """HIGH - ярлык строки и шапка колонки (или ярлык уникален в таблице); MEDIUM - что-то одно;
    NONE - ни того ни другого. Унаследованная единица (не из своей колонки) выше MEDIUM не
    бывает."""
    if row_label and (has_chain or unique):
        conf = CONF_HIGH
    elif row_label or has_chain:
        conf = CONF_MEDIUM
    else:
        conf = CONF_NONE
    return min(conf, CONF_MEDIUM) if inherited else conf


def _date_raw(value: object) -> str:
    if isinstance(value, (_dt.datetime, _dt.date)):
        return value.isoformat()
    return str(value)


# --------------------------------------------------------------------------- #
# Text path (regex)                                                           #
# --------------------------------------------------------------------------- #


def _facts_from_text(
    text: str,
    *,
    source_path: str,
    content_hash: str,
    stale_hint: bool,
    entity_ref: str | None,
) -> list[Fact]:
    """Regex-extract requisites / contacts / best-effort amounts from flat text."""
    facts: list[Fact] = []

    def add(kind: str, label: str, value_raw: str, start: int, conf: float,
            value_num: float | None = None, currency: str | None = None) -> None:
        locator = f"text@{start}"
        facts.append(
            Fact(
                fact_id=compute_fact_id(content_hash, locator, kind),
                entity_ref=entity_ref,
                source_path=source_path,
                source_content_hash=content_hash,
                locator=locator,
                kind=kind,
                label=label,
                value_num=value_num,
                value_raw=value_raw,
                currency=currency,
                confidence=conf,
                stale_hint=stale_hint,
            )
        )

    lowered = text.lower()
    seen_spans: set[tuple[int, int]] = set()

    for m in _BIN_RE.finditer(text):
        digits = m.group(1)
        window = lowered[max(0, m.start() - 24): m.start()]
        has_kw = any(k in window for k in ("бин", "иин", "bin", "iin"))
        valid = _valid_bin_iin(digits)
        if not has_kw and not valid:
            continue  # a bare 12-digit run without context is likely not a requisite
        conf = CONF_HIGH if has_kw and valid else (CONF_MEDIUM if valid else CONF_LOW)
        add(KIND_BIN, "БИН/ИИН", digits, m.start(), conf)
        seen_spans.add(m.span())

    for m in _EMAIL_RE.finditer(text):
        add(KIND_CONTACT, "email", m.group(0), m.start(), CONF_HIGH)

    for m in _PHONE_RE.finditer(text):
        add(KIND_CONTACT, "телефон", m.group(0), m.start(), CONF_MEDIUM)

    for m in _AMOUNT_RE.finditer(text):
        raw = m.group(1).strip()
        cur = detect_currency(m.group(2).lower())
        norm = raw.replace(" ", "").replace(" ", "").replace(" ", "").replace(",", ".")
        try:
            value_num = float(norm)
        except ValueError:
            continue
        add(KIND_MONEY, "сумма (из текста)", f"{raw} {m.group(2)}".strip(),
            m.start(), CONF_LOW, value_num=value_num, currency=cur)

    return facts


def _valid_bin_iin(digits: str) -> bool:
    """Kazakh БИН/ИИН control-digit check (weights, with the 11-collision fallback)."""
    if len(digits) != 12 or not digits.isdigit():
        return False
    d = [int(c) for c in digits]
    w1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    s = sum(d[i] * w1[i] for i in range(11)) % 11
    if s == 10:
        w2 = [3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 2]
        s = sum(d[i] * w2[i] for i in range(11)) % 11
        if s == 10:
            return False
    return s == d[11]
