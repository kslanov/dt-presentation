"""Материализация фактов источника с гейтом версии экстрактора (FACT-2 п.7).

Одна точка для сервера (``get_facts``) и CLI (``dt_facts``): подъем источника уже сделан
вызывающим, здесь решается, что делать со стором:

* фактов этого ``source_content_hash`` нет → извлечь и записать (``extracted``);
* есть, но ``extractor_version`` хоть одной строки ≠ текущей → переизвлечь и ЗАМЕНИТЬ все строки
  источника (``reextracted``; как ``chunker_version`` у индекса). ``source_path`` фактов при этом
  - живой путь из подъема (мертвые пути прежних экстракций лечатся бесплатно);
* версия та же → стор как есть (``cached``).

FACTS-BITEMPORAL-1: каждая запись проходит через :func:`write_source_facts` - факты получают оси
времени и ``fact_key`` (:mod:`core.facts.temporal`), запись НЕ удаляет прежние версии пути, затем
цепочка версий семейства пересобирается (вытеснение/``prev_fact_id``, черновик ничего не вытесняет).
``entity_ref`` при записи - хаб, если источник резолвится однозначно
(:mod:`core.facts.attribution`),
иначе прежнее значение.

Экстрактор ⊥ стор сохраняется: модуль-посредник, а не ``extract`` -> ``store``.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from core.facts import temporal
from core.facts.attribution import resolve_entity
from core.facts.extract import extract_facts
from core.facts.schema import EXTRACTOR_VERSION, Fact
from core.facts.store import get_facts, replace_source_facts, upsert_facts

if TYPE_CHECKING:
    from core.sources.resolver import LiftResult

__all__ = ["ensure_facts", "needs_reextract", "write_source_facts"]


def needs_reextract(version: str | None) -> bool:
    """Версия экстрактора строки отличается от текущей (или не записана)."""
    return (version or "") != EXTRACTOR_VERSION


def write_source_facts(
    lifted: LiftResult, facts: list[Fact], *, replace: bool = False, db_path: Path | None = None
) -> int:
    """Записать факты источника: оси времени → запись (без удаления прежних версий) → цепочка.

    ``replace=True`` - заменить все строки этого ``source_content_hash`` (переизвлечение другим
    экстрактором). Поиск семейства/черновика не должен ронять запись: сбой листинга папки -
    семейство из одного файла, цепочка пересоберется при следующем подъеме соседа."""
    try:
        paths, drafts, archived = temporal.lineage_of(lifted.path, mtime=lifted.mtime)
    except Exception:  # noqa: BLE001 - подсказка свежести не операция
        paths, drafts, archived = {lifted.path}, set(), set()
    temporal.stamp_facts(
        facts, path=lifted.path, mtime=lifted.mtime, draft=lifted.path in drafts
    )
    if replace:
        written = replace_source_facts(
            facts, source_content_hash=lifted.content_hash, db_path=db_path
        )
    else:
        written = upsert_facts(facts, db_path=db_path, keep_history=True)
    temporal.relink_paths(paths | {lifted.path}, archived_paths=archived, db_path=db_path)
    return written


def _attribute(facts: list[Fact], lifted: LiftResult, hint: str | None) -> None:
    """``entity_ref`` = однозначный хаб источника; нет резолва - остается ``hint`` (прежнее)."""
    hub = resolve_entity(lifted.path, hint=hint)
    for f in facts:
        f.entity_ref = hub or hint


def ensure_facts(
    lifted: LiftResult, *, entity_ref: str | None = None, db_path: Path | None = None
) -> str:
    """Привести факты источника к текущей версии экстрактора; вернуть ``cached``/``extracted``/
    ``reextracted``. ``lifted`` должен быть ``status == "ok"`` (проверяет вызывающий)."""
    existing = get_facts(
        source_content_hash=lifted.content_hash, include_ordinal=True,
        include_superseded=True, db_path=db_path,
    )
    if not existing:
        facts = extract_facts(lifted, entity_ref=entity_ref)
        _attribute(facts, lifted, entity_ref)
        write_source_facts(lifted, facts, db_path=db_path)
        return "extracted"
    if any(needs_reextract(f.extractor_version) for f in existing):
        # entity_ref прежней выборки сохраняем: переизвлечение не имеет права «потерять» хаб
        keep_entity = entity_ref or next((f.entity_ref for f in existing if f.entity_ref), None)
        facts = extract_facts(lifted, entity_ref=keep_entity)
        _attribute(facts, lifted, keep_entity)
        write_source_facts(lifted, facts, replace=True, db_path=db_path)
        return "reextracted"
    return "cached"
