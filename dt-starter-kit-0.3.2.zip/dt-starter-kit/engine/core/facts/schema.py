"""Fact model + identity (FACT-1, PART-1).

A :class:`Fact` is one typed, labelled datum lifted from a source file — the
semantic layer the production audit (Acme) found missing: not "480" and "654,1"
as bare cells, but *"себестоимость витрины = 480"* vs *"витрина+ЭХД = 654,1"*,
each with a back-traceable locator so the two can never be confused.

Identity is deterministic and idempotent: ``fact_id = hash(source_content_hash +
locator + kind)``. Re-running the extractor over the same bytes yields the same
ids (no duplicates on upsert); a content change yields a new hash → new ids → the
store re-writes (see :mod:`core.facts.store`). No time / randomness enters the id.

Path B: this module is pure data — no IO, no network, no LLM.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, fields
from typing import Any

__all__ = [
    "Fact",
    "compute_fact_id",
    "SCHEMA_VERSION",
    "EXTRACTOR_VERSION",
    "KIND_MONEY",
    "KIND_QUANTITY",
    "KIND_DATE",
    "KIND_RATE",
    "KIND_REQUISITE",
    "KIND_BIN",
    "KIND_CONTACT",
    "KIND_ORDINAL",
    "FACT_KINDS",
    "FACT_COLUMNS",
]

# Bumped when the stored row shape changes; DB-1 will migrate on this. Independent
# of EXTRACTOR_VERSION (the heuristic's version — a re-extract can change values
# without a schema change).
# FACT-2: форма строки += ``scale``/``section``/``is_total`` (миграция БД v3).
# FACTS-BITEMPORAL-1: форма строки += две оси времени и цепочка версий (миграция БД v4).
SCHEMA_VERSION = 3
# FACT-2: контекст по колонке, единицы/масштаб, ordinal, границы таблиц, уверенность. Сервер и
# ``dt_facts`` сравнивают версию с хранимой и переизвлекают устаревшее (как ``chunker_version``).
EXTRACTOR_VERSION = "fact-2.0"

KIND_MONEY = "money"
KIND_QUANTITY = "quantity"
KIND_DATE = "date"
KIND_RATE = "rate"
KIND_REQUISITE = "requisite"
KIND_BIN = "bin"
KIND_CONTACT = "contact"
# FACT-2: порядковый номер/этап (колонка «№», «Этап», «п/п» или монотонные 1..N). Хранится, но в
# выдаче ``get_facts`` без явного ``kind="ordinal"`` не отдается: это не количество и не деньги.
KIND_ORDINAL = "ordinal"

FACT_KINDS = frozenset(
    {
        KIND_MONEY,
        KIND_QUANTITY,
        KIND_DATE,
        KIND_RATE,
        KIND_REQUISITE,
        KIND_BIN,
        KIND_CONTACT,
        KIND_ORDINAL,
    }
)


def compute_fact_id(source_content_hash: str, locator: str, kind: str) -> str:
    """Stable id for a fact: ``sha256(content_hash | locator | kind)`` (16 hex).

    Deterministic and idempotent — same source bytes + same cell/anchor + same
    kind ⇒ same id, so a re-extract upserts in place rather than duplicating. The
    content hash (not the path) anchors identity, so a relocated-but-identical file
    keeps its fact ids.
    """
    raw = f"{source_content_hash}|{locator}|{kind}".encode()
    return hashlib.sha256(raw).hexdigest()[:16]


@dataclass
class Fact:
    """One typed, labelled fact extracted from a source (PART-1 schema).

    ``value_num`` is the parsed number (``None`` for a date, whose value lives in
    ``value_raw`` as an ISO string); ``value_raw`` preserves the file's original
    form including a locale comma (``"654,1"``). ``vat_flag`` is ``with`` /
    ``without`` / ``None`` (unknown). ``confidence`` (0..1) reflects how cleanly the
    label matched. ``stale_hint`` is propagated from the source (xlsx formula-cache
    values may be stale). ``extracted_at`` is stamped by the store on write, not by
    the pure extractor — kept empty on a freshly extracted fact.

    FACT-2: ``unit`` - каноническая единица (деньги - код валюты, количества - ``чел.-дн``/``шт``/…,
    ставки - ``%``); ``scale`` - множитель подписи (``1e6`` для «млн»), ``value_num`` им НИКОГДА
    не домножается, а ``value_base = value_num × scale`` - производное поле выдачи
    (:meth:`to_dict`); ``section`` - самая левая текстовая ячейка строки, если она отличается от
    ярлыка (в ``label`` не склеивается); ``is_total`` - строка «Итого/Всего/Total».
    """

    fact_id: str
    entity_ref: str | None
    source_path: str
    source_content_hash: str
    locator: str
    kind: str
    label: str
    value_num: float | None
    value_raw: str
    unit: str | None = None
    currency: str | None = None
    vat_flag: str | None = None
    confidence: float = 0.0
    stale_hint: bool = False
    extracted_at: str = ""
    extractor_version: str = EXTRACTOR_VERSION
    schema_version: int = SCHEMA_VERSION
    scale: float | None = None
    section: str = ""
    is_total: bool = False
    # FACTS-BITEMPORAL-1 (см. :mod:`core.facts.temporal`): ``valid_from``/``valid_to`` - ось «когда
    # верно» (даты ``YYYY-MM-DD``, полуинтервал ``[from, to)``, ``valid_to=None`` - пока верно);
    # ``known_at`` - ось «когда узнали» (UTC ISO, mtime источника); ``superseded_at``/
    # ``superseded_by`` - когда и каким фактом вытеснен; ``fact_key`` - устойчивая идентичность
    # сквозь версии; ``prev_fact_id`` - факт предыдущей версии; ``provisional`` - факт черновика
    # (ничего не вытесняет); ``date_basis`` - чем датирован ``valid_from``: ``name``/``mtime``/
    # ``""`` (не удалось). ``fact_id`` от времени НЕ зависит.
    valid_from: str | None = None
    valid_to: str | None = None
    known_at: str | None = None
    superseded_at: str | None = None
    superseded_by: str | None = None
    fact_key: str | None = None
    prev_fact_id: str | None = None
    provisional: bool = False
    date_basis: str | None = None

    @property
    def value_base(self) -> float | None:
        """Производное: ``value_num × scale`` (в базовых единицах); ``None`` без масштаба/числа."""
        if self.value_num is None or self.scale is None:
            return None
        return self.value_num * self.scale

    def to_dict(self) -> dict[str, Any]:
        """JSON-serializable form (shape mirrors ``LiftResult.to_dict``)."""
        return {
            "fact_id": self.fact_id,
            "entity_ref": self.entity_ref,
            "source_path": self.source_path,
            "source_content_hash": self.source_content_hash,
            "locator": self.locator,
            "kind": self.kind,
            "label": self.label,
            "value_num": self.value_num,
            "value_raw": self.value_raw,
            "unit": self.unit,
            "currency": self.currency,
            "vat_flag": self.vat_flag,
            "confidence": self.confidence,
            "stale_hint": self.stale_hint,
            "extracted_at": self.extracted_at,
            "extractor_version": self.extractor_version,
            "schema_version": self.schema_version,
            "scale": self.scale,
            "section": self.section,
            "is_total": self.is_total,
            # производное (не хранится): value_num × scale; value_num в выдаче - как в ячейке
            "value_base": self.value_base,
            # FACTS-BITEMPORAL-1: оси времени и цепочка версий
            "valid_from": self.valid_from,
            "valid_to": self.valid_to,
            "known_at": self.known_at,
            "superseded_at": self.superseded_at,
            "superseded_by": self.superseded_by,
            "fact_key": self.fact_key,
            "prev_fact_id": self.prev_fact_id,
            "provisional": self.provisional,
            "date_basis": self.date_basis,
        }


# Ordered column list — the single source of truth shared by the store's DDL,
# INSERT, and row→Fact hydration so they never drift.
FACT_COLUMNS: tuple[str, ...] = tuple(f.name for f in fields(Fact))
