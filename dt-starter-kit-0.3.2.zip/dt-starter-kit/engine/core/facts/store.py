"""SQLite fact store + query (FACT-1, PART-3; backend unified by DB-1).

Persists extracted :class:`~core.facts.schema.Fact` rows in the ``facts`` table of
the shared ``dt.db`` (DB-1: one connection, one schema version, one migration
framework — see :mod:`core.db`). Upsert is keyed by ``fact_id`` and is idempotent —
a re-run over the same bytes rewrites in place, never duplicates. When a source's
content hash changes, the stale rows for that path are dropped first
(re-extraction ⇒ overwrite). The DB is derivable from the SRC-1 lift cache, so it
lives under ``.derived/`` (gitignored) and is rebuildable.

DB-1 changed only the **backend** — the public API (:func:`upsert_facts`,
:func:`get_facts`, :func:`init_db`, :func:`stored_schema_version`) is unchanged.
The facts table now shares ``dt.db`` with sources/jobs; the pre-DB-1
``facts.db`` is imported once on first open (renamed ``.bak``).

This module depends on :mod:`core.facts.schema` but **not** on
:mod:`core.facts.extract` — the extractor is a pure function, the store is
separate (extractor ⊥ store, as parsers ⊥ cache in SRC-1). Path B: no network,
no LLM.
"""

from __future__ import annotations

import sqlite3
from datetime import UTC, datetime
from pathlib import Path

from core.config import facts_db_path
from core.db import connect, schema_version
from core.facts.schema import FACT_COLUMNS, KIND_ORDINAL, Fact
from core.facts.temporal import match_key, norm_day

__all__ = [
    "upsert_facts", "get_facts", "init_db", "stored_schema_version", "last_read_error",
    "replace_source_facts", "source_versions", "facts_by_ids",
]

# CONTRACT-2 С7 — причина последнего сбоя чтения стора («» — читалось нормально).
_LAST_READ_ERROR: dict[str, str] = {"reason": ""}


def last_read_error() -> str:
    """Причина последнего сбоя чтения facts-стора (``""`` — сбоя не было)."""
    return _LAST_READ_ERROR["reason"]

# Columns stored as 0/1 integers (the rest are handled by their Python type).
_BOOL_COLS = {"stale_hint", "is_total", "provisional"}


def init_db(db_path: Path | None = None) -> None:
    """Ensure the shared DB (incl. the ``facts`` table) exists and is migrated."""
    connect(db_path or facts_db_path()).close()


def stored_schema_version(db_path: Path | None = None) -> int | None:
    """The DB schema version, or ``None`` if the DB doesn't exist yet.

    Now the *unified* DB-1 schema version (one version for facts/sources/jobs),
    not a facts-only ``meta.schema_version``. Same signature/return contract.
    """
    return schema_version(db_path or facts_db_path())


def _to_row(fact: Fact, extracted_at: str) -> tuple[object, ...]:
    values: list[object] = []
    for col in FACT_COLUMNS:
        if col == "extracted_at":
            values.append(extracted_at)
        elif col in _BOOL_COLS:
            values.append(1 if getattr(fact, col) else 0)
        else:
            values.append(getattr(fact, col))
    return tuple(values)


def _from_row(row: sqlite3.Row) -> Fact:
    data = dict(row)
    return Fact(
        fact_id=data["fact_id"],
        entity_ref=data["entity_ref"],
        source_path=data["source_path"],
        source_content_hash=data["source_content_hash"],
        locator=data["locator"],
        kind=data["kind"],
        label=data["label"],
        value_num=data["value_num"],
        value_raw=data["value_raw"],
        unit=data["unit"],
        currency=data["currency"],
        vat_flag=data["vat_flag"],
        confidence=float(data["confidence"] or 0.0),
        stale_hint=bool(data["stale_hint"]),
        extracted_at=data["extracted_at"] or "",
        extractor_version=data["extractor_version"],
        schema_version=int(data["schema_version"]),
        # FACT-2: строки до миграции v3 несут NULL - «нет масштаба / секции / не итог»
        scale=float(data["scale"]) if data.get("scale") is not None else None,
        section=data.get("section") or "",
        is_total=bool(data.get("is_total")),
        # FACTS-BITEMPORAL-1: строки до миграции v4 несут NULL - «не датировано / не связано»
        valid_from=data.get("valid_from"),
        valid_to=data.get("valid_to"),
        known_at=data.get("known_at"),
        superseded_at=data.get("superseded_at"),
        superseded_by=data.get("superseded_by"),
        fact_key=data.get("fact_key"),
        prev_fact_id=data.get("prev_fact_id"),
        provisional=bool(data.get("provisional")),
        date_basis=data.get("date_basis"),
    )


def upsert_facts(
    facts: list[Fact],
    *,
    db_path: Path | None = None,
    now: str | None = None,
    keep_history: bool = False,
) -> int:
    """Upsert facts by ``fact_id`` (idempotent); returns the number written.

    Before inserting, any stored rows for a source **path** whose content hash
    differs from the batch's are deleted — a re-extraction of changed bytes
    overwrites rather than accumulating stale facts. Re-running over identical
    bytes rewrites the same ids in place (no duplicates). ``extracted_at`` is
    stamped here (UTC ISO), keeping the extractor pure.

    FACTS-BITEMPORAL-1: ``keep_history=True`` (так зовет
    :func:`core.facts.materialize.ensure_facts`)
    НЕ удаляет факты прежней версии того же пути - правка файла на месте тоже версия, и ее факты
    остаются в цепочке (вытесненные; дефолтная выдача их не показывает, значит для читателя
    результат прежний).
    """
    if not facts:
        return 0
    stamp = now or datetime.now(UTC).isoformat(timespec="seconds")

    conn = connect(db_path or facts_db_path())
    try:
        # Drop stale rows: same source_path, different content hash.
        if not keep_history:
            for source_path, content_hash in {
                (f.source_path, f.source_content_hash) for f in facts
            }:
                conn.execute(
                    "DELETE FROM facts WHERE source_path=? AND source_content_hash!=?",
                    (source_path, content_hash),
                )
        placeholders = ", ".join("?" for _ in FACT_COLUMNS)
        cols = ", ".join(FACT_COLUMNS)
        conn.executemany(
            f"INSERT OR REPLACE INTO facts ({cols}) VALUES ({placeholders})",  # noqa: S608 — SQL from our own quoted identifiers, not user input
            [_to_row(f, stamp) for f in facts],
        )
        conn.commit()
    finally:
        conn.close()
    return len(facts)


def replace_source_facts(
    facts: list[Fact],
    *,
    source_content_hash: str,
    db_path: Path | None = None,
    now: str | None = None,
) -> int:
    """Заменить ВСЕ факты источника (по ``source_content_hash``) новой выборкой (FACT-2 п.7).

    Переизвлечение другим экстрактором меняет не только значения, но и сами ``fact_id`` (kind -
    часть идентичности: ячейка ``A6`` была ``money``, стала ``ordinal``), поэтому upsert по id
    оставил бы старые строки рядом с новыми. Удаление и вставка идут одной транзакцией: при сбое
    остается прежняя выборка. Пустой ``facts`` очищает источник (экстрактор ничего не нашел).
    """
    stamp = now or datetime.now(UTC).isoformat(timespec="seconds")
    conn = connect(db_path or facts_db_path())
    try:
        with conn:  # транзакция: DELETE + INSERT атомарны
            conn.execute("DELETE FROM facts WHERE source_content_hash=?", (source_content_hash,))
            if facts:
                placeholders = ", ".join("?" for _ in FACT_COLUMNS)
                cols = ", ".join(FACT_COLUMNS)
                conn.executemany(
                    f"INSERT OR REPLACE INTO facts ({cols}) VALUES ({placeholders})",  # noqa: S608 — SQL from our own quoted identifiers, not user input
                    [_to_row(f, stamp) for f in facts],
                )
    finally:
        conn.close()
    return len(facts)


def _ro_connect(path: Path) -> sqlite3.Connection | None:
    """Соединение ТОЛЬКО на чтение (без миграций и без создания файла); нет файла - ``None``."""
    if not path.is_file():
        return None
    conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def source_versions(db_path: Path | None = None) -> list[dict[str, object]]:
    """Источники стора: ``[{source_path, source_content_hash, version, n, entity_ref}]``.

    Для ``dt_facts --reextract`` и доктора. Читает БД **только на чтение** (``mode=ro``): ни
    миграции, ни создания файла - сухой прогон на боевом сторе ничего в нем не меняет. ``version``
    - ``extractor_version`` строк источника (при разных - наименьшая). Стор не открылся -
    ``[]`` (причина в :func:`last_read_error`); файла нет - ``[]`` без причины.
    """
    _LAST_READ_ERROR["reason"] = ""
    try:
        conn = _ro_connect(db_path or facts_db_path())
        if conn is None:
            return []
    except sqlite3.Error as exc:
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return []
    try:
        rows = conn.execute(
            "SELECT source_content_hash AS h, MAX(source_path) AS p, "
            "MIN(extractor_version) AS v, COUNT(*) AS n, MAX(entity_ref) AS e FROM facts "
            "GROUP BY source_content_hash ORDER BY p"
        ).fetchall()
    except sqlite3.Error as exc:
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return []
    finally:
        conn.close()
    return [
        {"source_path": r["p"], "source_content_hash": r["h"], "version": r["v"], "n": r["n"],
         "entity_ref": r["e"]}
        for r in rows
    ]


def get_facts(
    *,
    entity_ref: str | None = None,
    kind: str | None = None,
    source_content_hash: str | None = None,
    min_confidence: float = 0.0,
    fresher_than: str | None = None,
    include_ordinal: bool = False,
    as_of: str | None = None,
    known_as_of: str | None = None,
    include_superseded: bool = False,
    today: str | None = None,
    db_path: Path | None = None,
) -> list[Fact]:
    """Query stored facts with optional filters (all ANDed).

    ``fresher_than`` keeps facts whose ``known_at`` (нет - ``extracted_at``) is ≥ the given ISO
    string.

    FACTS-BITEMPORAL-1 - срез по двум осям времени (даты ``YYYY-MM-DD``; полуинтервал ``[from,
    to)``):

    * по умолчанию - только **актуальные** на ``today``: ``valid_to`` пуст или позже сегодня
      (вытесненные новой версией документа скрыты); факт черновика (``provisional``) скрыт, если у
      него есть действующий не-черновой двойник (тот же ключ, та же папка);
    * ``as_of=D`` - верное на дату: ``valid_from`` пуст или ``≤ D`` и ``valid_to`` пуст или ``> D``;
    * ``known_as_of=D`` - что знали на дату: ``known_at ≤ D`` и на тот день еще не вытеснено
      (``superseded_at`` пуст или ``> D``);
    * ``include_superseded=True`` - вся история без среза (``as_of``/``known_as_of`` при этом
      все равно применяются, если заданы).

    FACT-2: факты ``ordinal`` (порядковые номера/этапы) без явного ``kind="ordinal"`` и без
    ``include_ordinal=True`` НЕ отдаются - это не деньги и не количества.
    An empty store (nothing extracted yet) yields ``[]``. Results are ordered by
    locator for stable output. Opening the DB also runs any pending schema
    migration + one-time legacy import (DB-1), so the first ``get_facts`` after an
    upgrade sees the migrated rows rather than an empty result.
    """
    clauses: list[str] = []
    params: list[object] = []
    if entity_ref is not None:
        clauses.append("entity_ref = ?")
        params.append(entity_ref)
    if kind is not None:
        clauses.append("kind = ?")
        params.append(kind)
    elif not include_ordinal:
        clauses.append("kind != ?")
        params.append(KIND_ORDINAL)
    if source_content_hash is not None:
        clauses.append("source_content_hash = ?")
        params.append(source_content_hash)
    if min_confidence > 0.0:
        clauses.append("confidence >= ?")
        params.append(min_confidence)
    if fresher_than is not None:
        clauses.append("COALESCE(known_at, extracted_at) >= ?")
        params.append(fresher_than)
    as_of_day = norm_day(as_of)
    known_day = norm_day(known_as_of)
    if as_of is not None and as_of_day is None:
        return _bad_date("as_of", as_of)
    if known_as_of is not None and known_day is None:
        return _bad_date("known_as_of", known_as_of)
    if as_of_day is not None:
        clauses.append("(valid_from IS NULL OR valid_from <= ?)")
        params.append(as_of_day)
        clauses.append("(valid_to IS NULL OR valid_to > ?)")
        params.append(as_of_day)
    if known_day is not None:
        clauses.append("(known_at IS NULL OR substr(known_at, 1, 10) <= ?)")
        params.append(known_day)
        clauses.append("(superseded_at IS NULL OR substr(superseded_at, 1, 10) > ?)")
        params.append(known_day)
    current_view = as_of_day is None and known_day is None and not include_superseded
    if current_view:
        clauses.append("(valid_to IS NULL OR valid_to > ?)")
        params.append(today or datetime.now(UTC).date().isoformat())

    where = f" WHERE {' AND '.join(clauses)}" if clauses else ""
    _LAST_READ_ERROR["reason"] = ""
    try:
        # CONTRACT-2 С7: открытие БД тоже внутри try — заблокированный файл падал
        # ИСКЛЮЧЕНИЕМ через границу инструмента (хуже тихой пустоты).
        conn = connect(db_path or facts_db_path())
    except sqlite3.Error as exc:
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return []
    try:
        rows = conn.execute(
            f"SELECT * FROM facts{where} ORDER BY source_path, locator", params  # noqa: S608 — SQL from our own quoted identifiers, not user input
        ).fetchall()
    except sqlite3.OperationalError as exc:
        # CONTRACT-2 С7: «фактов нет» и «стор не прочитался» — разные вещи. Форму
        # возврата (список) не меняем, причину кладём рядом (см. last_read_error).
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return []
    finally:
        conn.close()
    out = [_from_row(r) for r in rows]
    if (current_view or as_of_day is not None) and not include_superseded:
        out = _shadow_provisional(out)
    return out


def facts_by_ids(ids: list[str], *, db_path: Path | None = None) -> dict[str, Fact]:
    """Факты по ``fact_id`` (любой срез: вытесненные и черновики тоже) - для цепочки «было → стало».

    Сбой чтения - пустой словарь (причина в :func:`last_read_error`): вызывающий деградирует к факту
    без истории, а не падает."""
    wanted = sorted({str(i) for i in ids if i})
    if not wanted:
        return {}
    _LAST_READ_ERROR["reason"] = ""
    try:
        conn = connect(db_path or facts_db_path())
    except sqlite3.Error as exc:
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return {}
    out: dict[str, Fact] = {}
    try:
        for i in range(0, len(wanted), 400):
            chunk = wanted[i:i + 400]
            ph = ", ".join("?" for _ in chunk)
            for r in conn.execute(
                f"SELECT * FROM facts WHERE fact_id IN ({ph})", chunk  # noqa: S608 - плейсхолдеры, не данные
            ):
                fact = _from_row(r)
                out[fact.fact_id] = fact
    except sqlite3.OperationalError as exc:
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return {}
    finally:
        conn.close()
    return out


def _bad_date(name: str, value: str) -> list[Fact]:
    """Неразбираемая дата среза: пустая выдача + причина (не молча все факты, как при сбое
    стора)."""
    _LAST_READ_ERROR["reason"] = f"{name}: ожидается дата YYYY-MM-DD, получено {value!r}"[:200]
    return []


def _shadow_provisional(facts: list[Fact]) -> list[Fact]:
    """Факт черновика скрыт, если рядом есть не-черновой факт с тем же ключом (из той же папки).

    Черновик ничего не вытесняет, но и не должен выглядеть «еще одной актуальной» цифрой рядом с
    действующей. Без действующего двойника (черновик - единственный носитель) факт остается."""
    if not any(f.provisional for f in facts):
        return facts
    final = {(str(Path(f.source_path).parent), match_key(f)) for f in facts if not f.provisional}
    return [
        f for f in facts
        if not f.provisional or (str(Path(f.source_path).parent), match_key(f)) not in final
    ]
