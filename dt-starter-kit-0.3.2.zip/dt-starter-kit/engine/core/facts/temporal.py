"""Две оси времени у фактов и цепочка версий источника (FACTS-BITEMPORAL-1).

Факт знает не только «что» (значение), но и **когда это верно** (``valid_from``/``valid_to``,
полуинтервал ``[from, to)``) и **когда мы это узнали** (``known_at``). Новая версия документа
(то же семейство, новее по дате, не черновик/архив) вытесняет факты старой с тем же ключом:
``valid_to`` старого = ``valid_from`` нового, ``superseded_by`` = id нового, у нового
``prev_fact_id`` = id старого. Ничего не удаляется - история остается, запросы выбирают срез
(:func:`core.facts.store.get_facts`: ``as_of`` / ``known_as_of`` / ``include_superseded``).

Модуль делится на два слоя:

* **чистые функции** (без IO, без LLM, без часов): :func:`document_date`, :func:`known_at_iso`,
  :func:`fact_key`, :func:`match_key`, :func:`stamp_facts`, :func:`plan_links`. Один вход - один
  выход, поэтому бэкфилл и подъем дают одно и то же;
* **запись в стор** (:func:`apply_plan`, :func:`relink_paths`) - применяет ПЛАН одной транзакцией;
  идемпотентна (план строится заново с нуля по всем фактам семейства и пишется только разница).

Правила (ТЗ п.2): **черновик** (``draft``) не вытесняет действующую версию - его факты
``provisional``, ``valid_to`` у старых не ставится; **архивная** копия тоже ничего не вытесняет,
но сама может быть вытеснена; **старая версия, поднятая после новой**, встает в прошлое - план
всегда строится по ДАТАМ версий, а не по порядку подъема; версия без даты в цепочку не входит.

``fact_key`` (ТЗ): hash от ``entity_ref`` + нормализованный ``label`` + ``section`` +
``unit/currency`` + ``kind``. Цепочку внутри семейства связывает :func:`match_key` - тот же ключ
БЕЗ ``entity_ref``: у версий, не разрешившихся в хаб, ``entity_ref`` - id разных заметок, и по
``fact_key`` они бы не сошлись, хотя семейство уже само задает сущность (отклонение от буквы ТЗ,
причина - в отчете). Без LLM, без сети.
"""

from __future__ import annotations

import hashlib
import re
import sqlite3
import unicodedata
from collections import defaultdict
from collections.abc import Collection, Iterable
from dataclasses import dataclass, field
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any

from core.facts.schema import Fact

__all__ = [
    "BASIS_NAME",
    "BASIS_MTIME",
    "BASIS_NONE",
    "document_date",
    "known_at_iso",
    "fact_key",
    "match_key",
    "stamp_facts",
    "LinkPlan",
    "plan_links",
    "apply_plan",
    "relink_paths",
    "lineage_of",
    "norm_day",
]

BASIS_NAME = "name"    # дата документа прочитана из имени файла
BASIS_MTIME = "mtime"  # имени-даты нет - mtime источника
BASIS_NONE = ""        # датировать нечем (нет ни даты в имени, ни mtime)

# --- дата в имени файла -------------------------------------------------------------------------
# Порядок важен: полная дата точнее года-месяца; «2026-2029» (диапазон лет) ни одним не берется.
_YMD_RE = re.compile(r"(?<!\d)(20\d{2})[-._]?(0[1-9]|1[0-2])[-._]?(0[1-9]|[12]\d|3[01])(?!\d)")
_DMY_RE = re.compile(r"(?<!\d)(0[1-9]|[12]\d|3[01])[-._](0[1-9]|1[0-2])[-._](20\d{2}|\d{2})(?!\d)")
_YM_RE = re.compile(r"(?<!\d)(20\d{2})[-._](0[1-9]|1[0-2])(?!\d)")
_MY_RE = re.compile(r"(?<!\d)(0[1-9]|1[0-2])[-._](20\d{2})(?!\d)")

_SPACE_RE = re.compile(r"\s+")
_EDGE_PUNCT = " \t\r\n:;,.-–—_*«»\"'()[]"


def _valid_date(y: int, m: int, d: int) -> str | None:
    try:
        return date(y, m, d).isoformat()
    except ValueError:
        return None


def _name_date(name: str) -> str | None:
    """Дата из имени файла (без расширения): ``YYYYMMDD``/``YYYY-MM-DD``, ``DD.MM.YYYY``,
    ``YYYY-MM``, ``MM.YYYY`` (месяц - первое число). Только числовые формы, без эвристик по
    тексту."""
    stem = Path(unicodedata.normalize("NFC", str(name or ""))).stem
    for rx, order in ((_YMD_RE, "ymd"), (_DMY_RE, "dmy"), (_YM_RE, "ym"), (_MY_RE, "my")):
        for m in rx.finditer(stem):
            g = m.groups()
            if order == "ymd":
                got = _valid_date(int(g[0]), int(g[1]), int(g[2]))
            elif order == "dmy":
                year = int(g[2]) if len(g[2]) == 4 else 2000 + int(g[2])
                got = _valid_date(year, int(g[1]), int(g[0]))
            elif order == "ym":
                got = _valid_date(int(g[0]), int(g[1]), 1)
            else:
                got = _valid_date(int(g[1]), int(g[0]), 1)
            if got:
                return got
    return None


def _mtime_dt(mtime: float | None) -> datetime | None:
    if not mtime or mtime <= 0:
        return None
    try:
        return datetime.fromtimestamp(float(mtime), UTC)
    except (OverflowError, OSError, ValueError):
        return None


def document_date(path: str, mtime: float | None) -> tuple[str | None, str]:
    """``(valid_from, basis)``: дата документа из имени файла, иначе дата mtime (UTC), иначе
    ``None``.

    Явных дат из ТЕКСТА документа здесь нет (ТЗ: новых эвристик не писать): экстрактор сам
    отдает ``kind=date`` как отдельные факты, а дата документа - свойство версии, не ячейки."""
    named = _name_date(Path(str(path or "")).name)
    if named:
        return named, BASIS_NAME
    dt = _mtime_dt(mtime)
    if dt is not None:
        return dt.date().isoformat(), BASIS_MTIME
    return None, BASIS_NONE


def known_at_iso(mtime: float | None) -> str | None:
    """Ось «узнали»: mtime источника как UTC ISO (секунды); ``None`` - mtime неизвестен."""
    dt = _mtime_dt(mtime)
    return dt.isoformat(timespec="seconds") if dt is not None else None


def norm_day(value: str | None) -> str | None:
    """``YYYY-MM-DD`` из даты/даты-времени ISO; невалидное → ``None``."""
    text = str(value or "").strip()[:10]
    try:
        return date.fromisoformat(text).isoformat()
    except ValueError:
        return None


# --- идентичность ------------------------------------------------------------------------------
def _norm(text: str | None) -> str:
    """Нормализация подписи для ключа: NFC, casefold, ё→е, схлопнутые пробелы, края без
    пунктуации."""
    norm = unicodedata.normalize("NFC", str(text or "")).casefold().replace("ё", "е")
    return _SPACE_RE.sub(" ", norm).strip(_EDGE_PUNCT)


def _key_parts(f: Fact) -> tuple[str, str, str, str]:
    return (_norm(f.label), _norm(f.section), f"{f.unit or ''}/{f.currency or ''}", f.kind)


def fact_key(f: Fact) -> str:
    """Устойчивая идентичность факта сквозь версии: ``entity_ref`` + label + section + unit/currency
    + kind (16 hex). От значения и источника не зависит - новая версия документа даст тот же
    ключ."""
    raw = "|".join((f.entity_ref or "", *_key_parts(f)))
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def match_key(f: Fact) -> str:
    """Тот же ключ БЕЗ ``entity_ref`` - им связывается цепочка внутри семейства (см. докстринг
    модуля)."""
    return hashlib.sha256("|".join(_key_parts(f)).encode()).hexdigest()[:16]


def stamp_facts(
    facts: list[Fact], *, path: str, mtime: float | None, draft: bool = False
) -> list[Fact]:
    """Проставить оси времени и ``fact_key`` свежеизвлеченным фактам (на месте, возвращает тот же
    список).

    ``valid_from`` - :func:`document_date`; ``known_at`` - mtime источника; ``provisional`` -
    источник помечен черновиком. ``valid_to``/``superseded_*``/``prev_fact_id`` проставляет только
    цепочка (:func:`plan_links`), поэтому здесь они пустые."""
    valid_from, basis = document_date(path, mtime)
    known = known_at_iso(mtime)
    for f in facts:
        f.valid_from = valid_from
        f.date_basis = basis
        f.known_at = known
        f.provisional = bool(draft)
        f.fact_key = fact_key(f)
    return facts


# --- цепочка версий ----------------------------------------------------------------------------
_LOC_RE = re.compile(r"^(?P<sheet>.*)!(?P<col>[A-Za-z]+)(?P<row>\d+)$")


def _col_idx(col: str) -> int:
    idx = 0
    for ch in col.upper():
        idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return idx


def _loc_key(locator: str) -> tuple[Any, ...]:
    """Естественный порядок локаторов ``Лист!B12`` (лист, строка, колонка), иначе по строке."""
    m = _LOC_RE.match(locator or "")
    if not m:
        return (str(locator or ""), 0, 0)
    return (m.group("sheet"), int(m.group("row")), _col_idx(m.group("col")))


@dataclass
class _Version:
    content_hash: str
    path: str
    valid_from: str | None
    known_at: str
    provisional: bool
    archived: bool
    by_key: dict[str, list[dict[str, Any]]] = field(default_factory=dict)

    @property
    def order(self) -> tuple[str, str, str, str]:
        return (self.valid_from or "", self.known_at, self.path, self.content_hash)


@dataclass
class LinkPlan:
    """Результат :func:`plan_links`: что записать и сводка (для отчета и dry-run).

    ``updates`` - ``{fact_id: {valid_to, superseded_at, superseded_by, prev_fact_id}}`` для ВСЕХ
    фактов семейства (пустые значения - сброс прежней связи, чтобы пересчет был идемпотентным)."""

    updates: dict[str, dict[str, str | None]] = field(default_factory=dict)
    versions: int = 0
    chain_versions: int = 0
    provisional_versions: int = 0
    undated_versions: int = 0
    superseded: int = 0
    unchanged_keys: int = 0

    def to_dict(self) -> dict[str, int]:
        return {
            "versions": self.versions, "chain_versions": self.chain_versions,
            "provisional_versions": self.provisional_versions,
            "undated_versions": self.undated_versions, "superseded": self.superseded,
        }


def plan_links(
    rows: Iterable[dict[str, Any]], *, archived_paths: Collection[str] = ()
) -> LinkPlan:
    """Построить цепочку версий по фактам семейства (чистая функция, порядок входа не важен).

    ``rows`` - словари с ``fact_id, source_path, source_content_hash, locator, kind, label, section,
    unit, currency, valid_from, known_at, provisional``. Версия = ``source_content_hash`` (правка
    файла на месте - тоже новая версия). Версии упорядочиваются по ДАТЕ документа, а не по
    времени подъема: старая версия, поднятая после новой, встает в прошлое. В цепочку входят версии
    с ``valid_from`` и не черновики; преемником может быть только НЕ архивная версия.

    Внутри версии одинаковые ключи (строки таблицы с равной подписью) пары к паре по порядку
    локаторов: k-й факт ключа версии V вытесняется k-м фактом того же ключа ближайшей более поздней
    версии, где таких фактов хватает; без пары - остается действующим.
    """
    archived = {str(p) for p in archived_paths}
    versions: dict[str, _Version] = {}
    all_ids: list[str] = []
    for r in rows:
        h = str(r["source_content_hash"])
        v = versions.get(h)
        if v is None:
            v = _Version(
                content_hash=h, path=str(r["source_path"]), valid_from=r.get("valid_from"),
                known_at=str(r.get("known_at") or ""), provisional=bool(r.get("provisional")),
                archived=str(r["source_path"]) in archived,
            )
            versions[h] = v
        all_ids.append(str(r["fact_id"]))
        v.by_key.setdefault(str(r["_match_key"]), []).append(r)
    plan = LinkPlan(versions=len(versions))
    plan.updates = {
        fid: {"valid_to": None, "superseded_at": None, "superseded_by": None, "prev_fact_id": None}
        for fid in all_ids
    }
    plan.provisional_versions = sum(1 for v in versions.values() if v.provisional)
    plan.undated_versions = sum(1 for v in versions.values() if not v.valid_from)
    chain = sorted(
        (v for v in versions.values() if v.valid_from and not v.provisional), key=lambda v: v.order
    )
    plan.chain_versions = len(chain)
    for v in chain:
        for facts in v.by_key.values():
            facts.sort(key=lambda r: _loc_key(str(r["locator"])))

    preds: dict[str, list[tuple[tuple[str, str], dict[str, Any]]]] = defaultdict(list)
    for idx, v in enumerate(chain):
        for key, facts in v.by_key.items():
            for k, old in enumerate(facts):
                succ: dict[str, Any] | None = None
                succ_v: _Version | None = None
                for w in chain[idx + 1:]:
                    if w.archived:
                        continue
                    cands = w.by_key.get(key, [])
                    if len(cands) > k:
                        succ, succ_v = cands[k], w
                        break
                if succ is None or succ_v is None:
                    continue
                upd = plan.updates[str(old["fact_id"])]
                upd["valid_to"] = succ_v.valid_from
                upd["superseded_at"] = max(v.known_at, succ_v.known_at) or None
                upd["superseded_by"] = str(succ["fact_id"])
                preds[str(succ["fact_id"])].append(((v.valid_from or "", v.known_at), old))
                plan.superseded += 1
    for sid, olds in preds.items():
        # у преемника - ближайший по дате предшественник (архивная копия не перебивает основную)
        plan.updates[sid]["prev_fact_id"] = str(max(olds, key=lambda c: c[0])[1]["fact_id"])
    return plan


_COLS = (
    "fact_id, source_path, source_content_hash, locator, kind, label, section, unit, currency, "
    "valid_from, known_at, provisional, entity_ref"
)
_IN_CHUNK = 400


def _fetch_rows(conn: sqlite3.Connection, paths: Collection[str]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    plist = sorted({str(p) for p in paths})
    for i in range(0, len(plist), _IN_CHUNK):
        chunk = plist[i:i + _IN_CHUNK]
        ph = ", ".join("?" for _ in chunk)
        for r in conn.execute(
            f"SELECT {_COLS} FROM facts WHERE source_path IN ({ph})", chunk  # noqa: S608 - плейсхолдеры, не данные
        ):
            row = dict(r)
            probe = Fact(
                fact_id=row["fact_id"], entity_ref=row["entity_ref"], source_path="",
                source_content_hash="", locator="", kind=row["kind"], label=row["label"] or "",
                value_num=None, value_raw="", unit=row["unit"], currency=row["currency"],
                section=row["section"] or "",
            )
            row["_match_key"] = match_key(probe)
            out.append(row)
    return out


def apply_plan(conn: sqlite3.Connection, plan: LinkPlan) -> int:
    """Записать план одной транзакцией; только изменившиеся строки. Возвращает число обновленных."""
    if not plan.updates:
        return 0
    cur: dict[str, tuple[Any, ...]] = {}
    ids = list(plan.updates)
    for i in range(0, len(ids), _IN_CHUNK):
        chunk = ids[i:i + _IN_CHUNK]
        ph = ", ".join("?" for _ in chunk)
        for r in conn.execute(
            "SELECT fact_id, valid_to, superseded_at, superseded_by, prev_fact_id "  # noqa: S608
            f"FROM facts WHERE fact_id IN ({ph})", chunk,
        ):
            cur[r["fact_id"]] = (r["valid_to"], r["superseded_at"], r["superseded_by"],
                                 r["prev_fact_id"])
    batch = []
    for fid, u in plan.updates.items():
        want = (u["valid_to"], u["superseded_at"], u["superseded_by"], u["prev_fact_id"])
        if cur.get(fid) != want:
            batch.append((*want, fid))
    if batch:
        with conn:
            conn.executemany(
                "UPDATE facts SET valid_to=?, superseded_at=?, superseded_by=?, prev_fact_id=? "
                "WHERE fact_id=?", batch,
            )
    return len(batch)


def lineage_of(path: str, *, mtime: float | None = None) -> tuple[set[str], set[str], set[str]]:
    """Пути семейства версий вокруг ``path`` → ``(пути, черновики, архивные)``.

    Берет :func:`core.sources.freshness.family_of` как есть (правила и маркеры свежести здесь не
    меняются): листинг одной папки, содержимое файлов не читается. Сам ``path`` входит всегда."""
    from core.sources.freshness import family_of

    fam = family_of(path, mtime=mtime)
    paths = {m.path for m in fam.members} | {str(path)}
    drafts = {m.path for m in fam.members if m.draft}
    archived = {m.path for m in fam.members if m.archived}
    return paths, drafts, archived


def relink_paths(
    paths: Collection[str], *, archived_paths: Collection[str] = (),
    db_path: Path | None = None, conn: sqlite3.Connection | None = None,
) -> LinkPlan:
    """Пересобрать цепочку версий для фактов, лежащих под ``paths``, и записать (идемпотентно)."""
    from core.config import facts_db_path
    from core.db import connect

    own = conn is None
    c = conn or connect(db_path or facts_db_path())
    try:
        plan = plan_links(_fetch_rows(c, paths), archived_paths=archived_paths)
        apply_plan(c, plan)
        return plan
    finally:
        if own:
            c.close()
