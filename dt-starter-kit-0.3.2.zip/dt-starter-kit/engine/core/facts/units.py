"""Единицы, масштаб и валюта из подписей колонок (FACT-2 п.1-2). Чистые функции, без I/O.

Подпись («Себестоимость проекта (млн тенге, без НДС)») раскладывается на независимые части:

* **валюта** - код ``KZT``/``RUB``/``USD``/``EUR`` (:func:`detect_currency`);
* **масштаб** - множитель ``1e3``/``1e6``/``1e9`` (:func:`detect_scale`), ``value_num`` им НИКОГДА
  не домножается - он только описывает, во что «упакована» цифра (``value_base`` - производное);
* **единица количества** - канон из :data:`_UNIT_MAP` (``чел.-дн``, ``чел.-ч``, ``ч``, ``дн``,
  ``мес``, ``шт``, ``м²``) и ``%`` для ставок (:func:`detect_unit`);
* **НДС** - ``without``/``with``/``None`` (:func:`detect_vat`).

Порядок источников (колонка → заголовок таблицы → ярлык строки) решает вызывающий
(:mod:`core.facts.extract`); здесь - только разбор одного текста.
"""

from __future__ import annotations

import re

__all__ = [
    "CURRENCY_CODES",
    "detect_currency",
    "detect_scale",
    "detect_unit",
    "detect_vat",
    "has_percent",
]

# Буквы, по которым слово «продолжается»: токен валюты/масштаба не должен быть частью чужого слова
# («рубрика» ≠ «руб», «тыс» в «Тыс.» - да).
_L = r"[a-zа-яё]"

# (код, регулярка). Длинные/специфичные - раньше. ``₸``/``$``/``€`` - символы, без границ слова.
_CURRENCY_RES: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("KZT", re.compile(rf"₸|(?<!{_L})(?:тенге|тнг|тг|kzt)(?!{_L})")),
    ("RUB", re.compile(rf"₽|(?<!{_L})(?:руб(?:л\w*)?|rub)(?!{_L})")),
    ("USD", re.compile(rf"\$|(?<!{_L})(?:usd|долл\w*|dollar\w*)(?!{_L})")),
    ("EUR", re.compile(rf"€|(?<!{_L})(?:eur|евро|euro)(?!{_L})")),
)
CURRENCY_CODES = frozenset(code for code, _ in _CURRENCY_RES)

# (множитель, регулярка).
_SCALE_RES: tuple[tuple[float, re.Pattern[str]], ...] = (
    (1e9, re.compile(rf"(?<!{_L})(?:млрд|миллиард\w*|bn|billion)(?!{_L})")),
    (1e6, re.compile(rf"(?<!{_L})(?:млн|миллион\w*|mln|mn|million)(?!{_L})")),
    (1e3, re.compile(rf"(?<!{_L})(?:тыс|тысяч(?:а|и|ам|ах|ей)?|thousand)(?!{_L})")),
)

# Каноническая единица → регулярка с синонимами. Порядок значим: составные («чел.-дн») раньше
# простых («дн»), иначе «чел.-дн.» распознается как «дн».
_UNIT_MAP: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("чел.-дн", re.compile(
        rf"чел\.?\s*[-–/.]?\s*(?:дн|день|дня|дни|дней|д)(?!{_L})"
        rf"|человеко[-\s]?(?:дн|день|дня|дни|дней)\w*|man[-\s]?days?|(?<!{_L})ч/д(?!{_L})"
        r"|(?<![a-zа-яё])чд(?![a-zа-яё])"
    )),
    ("чел.-ч", re.compile(
        rf"чел\.?\s*[-–/.]?\s*(?:ч|час\w*)(?!{_L})|человеко[-\s]?час\w*|man[-\s]?hours?"
        r"|(?<![a-zа-яё])ч/ч(?![a-zа-яё])"
    )),
    ("чел.-мес", re.compile(
        r"чел\.?\s*[-–/.]?\s*мес\w*|человеко[-\s]?мес\w*|man[-\s]?months?"
    )),
    ("м²", re.compile(rf"м²|(?<!{_L})(?:м2|кв\.?\s*м\w*|sq\.?\s*m)(?!{_L})")),
    ("шт", re.compile(rf"(?<!{_L})(?:шт|штук\w*|pcs|pieces)(?!{_L})")),
    ("мес", re.compile(rf"(?<!{_L})(?:мес|месяц\w*|months?)(?!{_L})")),
    ("дн", re.compile(rf"(?<!{_L})(?:дн|дней|день|дня|дни|days?)(?!{_L})")),
    ("ч", re.compile(rf"(?<!{_L})(?:ч|час\w*|hours?|hrs?)(?!{_L})")),
)

_PERCENT_RE = re.compile(rf"%|(?<!{_L})(?:процент\w*|percent)(?!{_L})")
_VAT_WITHOUT = ("без ндс", "без ндc", "excl. vat", "excl vat", "ex vat", "without vat")
_VAT_WITH = ("с ндс", "в т.ч. ндс", "в тч ндс", "включая ндс", "вкл. ндс", "вкл ндс", "with vat",
             "incl. vat", "incl vat")


def detect_currency(text: str) -> str | None:
    """Код валюты по подписи/ярлыку (``₸``, «тенге», «руб.», ``USD``…) или ``None``."""
    low = text.lower()
    for code, rx in _CURRENCY_RES:
        if rx.search(low):
            return code
    return None


def detect_scale(text: str) -> float | None:
    """Множитель из слов «млрд»/«млн»/«тыс.» (``1e9``/``1e6``/``1e3``) или ``None``."""
    low = text.lower()
    for mult, rx in _SCALE_RES:
        if rx.search(low):
            return mult
    return None


def detect_unit(text: str) -> str | None:
    """Каноническая единица количества (``чел.-дн``, ``шт``, ``мес``…) или ``None``.

    Валюта и ``%`` сюда не входят: у денег единица - код валюты, у ставки - ``%``
    (:func:`detect_currency`, :func:`has_percent`).
    """
    low = text.lower()
    for canon, rx in _UNIT_MAP:
        if rx.search(low):
            return canon
    return None


def has_percent(text: str) -> bool:
    """В подписи есть ``%``/«процент» - колонка ставок/долей."""
    return bool(_PERCENT_RE.search(text.lower()))


def detect_vat(text: str) -> str | None:
    """``without`` («без НДС») / ``with`` («с НДС», «вкл. НДС») / ``None`` (не сказано)."""
    low = text.lower()
    if any(t in low for t in _VAT_WITHOUT):
        return "without"
    if any(t in low for t in _VAT_WITH):
        return "with"
    return None
