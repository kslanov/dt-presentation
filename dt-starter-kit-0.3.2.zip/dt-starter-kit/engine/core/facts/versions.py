"""Чтение временной плоскости фактов: цепочка версий источника и сводка для доктора
(FACTS-BITEMPORAL-1).

Только чтение (``mode=ro``): ни миграций, ни создания файла, ни записи. Два потребителя:

* :func:`version_chain` - ``dt facts versions <источник>``: версии семейства по датам документа, у
каждой
  - сколько фактов, чем датирована, не черновик ли, сколько вытеснено, и примеры «было → стало»;
* :func:`time_stats` - доктор «Факты: время» (актуальные/вытесненные/provisional, семейства с
цепочкой,
  недатированные, порванные цепочки, зерно KNOWLEDGE-LINT-1: число противоречий).

Семейство берется тем же :func:`core.sources.freshness.family_of`, что и везде (правил не меняем);
листинг папки снимается один раз на папку.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.facts import temporal
from core.facts.store import _ro_connect

__all__ = ["version_chain", "time_stats", "contradiction_groups", "TimeStats"]

_ROW_SQL = (
    "SELECT fact_id, source_path, source_content_hash, locator, kind, label, section, unit,"
    " currency, entity_ref, value_num, value_raw, valid_from, valid_to, known_at, superseded_at,"
    " superseded_by,"
    " prev_fact_id, provisional, date_basis, fact_key FROM facts"
)
_MAX_SOURCES_FOR_FAMILIES = 400  # больше - семейства не считаем (листинг папок на каждый источник)


def _rows(db_path: Path | None) -> list[dict[str, Any]] | None:
    """Все строки стора на чтение; ``None`` - стора нет или схема до v4 (причина -
    ``last_read_error``)."""
    from core.config import facts_db_path

    conn = _ro_connect(db_path or facts_db_path())
    if conn is None:
        return []
    try:
        have = {r["name"] for r in conn.execute("PRAGMA table_info(facts)")}
        if "date_basis" not in have:
            return None
        out = []
        for r in conn.execute(_ROW_SQL):
            row = dict(r)
            row["_match_key"] = temporal.match_key(_probe(row))
            out.append(row)
        return out
    finally:
        conn.close()


def _probe(r: dict[str, Any]) -> Any:
    from core.facts.schema import Fact

    return Fact(
        fact_id=r["fact_id"], entity_ref=None, source_path="", source_content_hash="", locator="",
        kind=r["kind"], label=r["label"] or "", value_num=None, value_raw="", unit=r["unit"],
        currency=r["currency"], section=r["section"] or "",
    )


def _family(
    path: str, listings: dict[str, list[tuple[str, float]]]
) -> tuple[set[str], set[str], set[str]]:
    """``(пути, черновики, архивные)`` семейства вокруг ``path`` с кэшем листинга по папке."""
    from core.sources.freshness import family_files, family_of

    parent = str(Path(path).parent)
    if parent not in listings:
        listings[parent] = family_files(parent)
    fam = family_of(path, files=listings[parent])
    return (
        {m.path for m in fam.members} | {path},
        {m.path for m in fam.members if m.draft},
        {m.path for m in fam.members if m.archived},
    )


def version_chain(source: str, *, db_path: Path | None = None) -> dict[str, Any]:
    """Цепочка версий семейства вокруг файла ``source`` (по сохраненным фактам).

    ``{source, versions: [{path, content_hash, valid_from, valid_to, known_at, date_basis, facts,
    superseded, provisional, archived}], changes: [{label, was, now, valid_to}], status}``;
    ``status`` - ``ok`` | ``unmigrated`` | ``empty``. Версии - по дате документа (старые сверху)."""
    rows = _rows(db_path)
    if rows is None:
        return {"source": source, "versions": [], "changes": [], "status": "unmigrated"}
    listings: dict[str, list[tuple[str, float]]] = {}
    try:
        paths, drafts, archived = _family(source, listings)
    except Exception:  # noqa: BLE001 - листинг папки не обязателен
        paths, drafts, archived = {source}, set(), set()
    sub = [r for r in rows if r["source_path"] in paths]
    by_hash: dict[str, dict[str, Any]] = {}
    by_id = {r["fact_id"]: r for r in sub}
    for r in sub:
        v = by_hash.setdefault(r["source_content_hash"], {
            "path": r["source_path"], "content_hash": r["source_content_hash"],
            "valid_from": r["valid_from"], "valid_to": None, "known_at": r["known_at"],
            "date_basis": r["date_basis"], "facts": 0, "superseded": 0,
            "provisional": bool(r["provisional"]), "archived": r["source_path"] in archived,
            "draft_marker": r["source_path"] in drafts,
        })
        v["facts"] += 1
        if r["superseded_by"]:
            v["superseded"] += 1
            v["valid_to"] = max(v["valid_to"] or "", r["valid_to"] or "") or None
    versions = sorted(by_hash.values(), key=lambda v: (v["valid_from"] or "", v["known_at"] or "",
                                                      v["path"]))
    changes: list[dict[str, Any]] = []
    for r in sub:
        succ = by_id.get(r["superseded_by"] or "")
        if succ is None:
            continue
        changes.append({
            "label": r["label"], "section": r["section"], "locator": r["locator"],
            "was": r["value_raw"], "now": succ["value_raw"],
            "changed": r["value_raw"] != succ["value_raw"],
            "valid_from": r["valid_from"], "valid_to": r["valid_to"],
            "from": r["source_path"], "to": succ["source_path"],
        })
    changes.sort(key=lambda c: (c["valid_to"] or "", c["label"], c["locator"]))
    return {"source": source, "versions": versions, "changes": changes,
            "status": "ok" if versions else "empty"}


@dataclass
class TimeStats:
    """Сводка плоскости времени для доктора."""

    total: int = 0
    current: int = 0
    superseded: int = 0
    provisional: int = 0
    undated: int = 0
    sources: int = 0
    sources_in_chain: int = 0
    families_multi: int = 0       # семейства с >1 поднятой версией
    broken_families: int = 0      # у новой версии есть пары, а старые факты не вытеснены
    broken_facts: int = 0
    contradictions: int = 0       # fact_key: разные значения у актуальных фактов разных семейств
    unmigrated: bool = False
    families_skipped: bool = False
    notes: list[str] = field(default_factory=list)

    @property
    def undated_share(self) -> float:
        return self.undated / self.total if self.total else 0.0


def _lineage(
    rows: list[dict[str, Any]], hashes: dict[str, str], by_id: dict[str, dict[str, Any]],
    st: TimeStats,
) -> dict[str, int]:
    """Путь источника → номер семейства версий (``families_multi``/``broken_*`` копятся в ``st``).

    Одна версия на хэш, листинг папки на папку; больше :data:`_MAX_SOURCES_FOR_FAMILIES` источников
    семейства не считаем (``families_skipped``)."""
    if len(hashes) > _MAX_SOURCES_FOR_FAMILIES:
        st.families_skipped = True
        st.notes.append(f"семейства не считались: источников больше {_MAX_SOURCES_FOR_FAMILIES}")
        return {}
    listings: dict[str, list[tuple[str, float]]] = {}
    seen: dict[frozenset[str], int] = {}
    lineage_of_path: dict[str, int] = {}
    for path in sorted(set(hashes.values())):
        try:
            paths, _d, archived = _family(path, listings)
        except Exception:  # noqa: BLE001
            paths, archived = {path}, set()
        key = frozenset(paths)
        if key not in seen:
            seen[key] = len(seen)
            sub = [r for r in rows if r["source_path"] in paths]
            plan = temporal.plan_links(sub, archived_paths=archived)
            if plan.versions > 1:
                st.families_multi += 1
            miss = [fid for fid, u in plan.updates.items()
                    if u["superseded_by"] and not by_id[fid]["superseded_by"]]
            if miss:
                st.broken_families += 1
                st.broken_facts += len(miss)
        for p in paths:
            lineage_of_path.setdefault(p, seen[key])
    return lineage_of_path


def _contradictions(
    rows: list[dict[str, Any]], day: str, lineage_of_path: dict[str, int]
) -> list[list[dict[str, Any]]]:
    """Группы актуальных фактов с одним ``fact_key`` из РАЗНЫХ семейств и разными значениями.

    Один счет для доктора («Факты: время») и детектора ``fact_conflict`` линта. Порядок групп и
    фактов в них детерминирован (по ключу; факты - новее документ первым)."""
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for r in rows:
        expired = bool(r["valid_to"]) and r["valid_to"] <= day
        if (r["provisional"] or expired or r["kind"] == "ordinal"
                or r["value_num"] is None or not r["fact_key"]):
            continue
        groups[r["fact_key"]].append(r)
    out: list[list[dict[str, Any]]] = []
    for key in sorted(groups):
        facts = groups[key]
        fams = {lineage_of_path.get(f["source_path"], f["source_path"]) for f in facts}
        values = {round(float(f["value_num"]), 6) for f in facts}
        if len(fams) > 1 and len(values) > 1:
            out.append(sorted(facts, key=lambda f: (
                str(f["valid_from"] or ""), str(f["known_at"] or ""), f["fact_id"]), reverse=True))
    return out


def contradiction_groups(
    db_path: Path | None = None, *, today: str | None = None
) -> list[list[dict[str, Any]]] | None:
    """Противоречия стора для линта (только чтение): список групп фактов; ``None`` - стор до v4.

    Тот же счет, что у доктора «Факты: время» (:func:`time_stats`): актуальные факты одного
    ``fact_key`` из разных семейств версий с разными значениями. Факт - строка стора со всеми
    осями времени (``source_path``, ``locator``, ``value_raw``, ``valid_from``, ``known_at``...)."""
    rows = _rows(db_path)
    if rows is None:
        return None
    if not rows:
        return []
    day = today or datetime.now(UTC).date().isoformat()
    hashes: dict[str, str] = {}
    for r in rows:
        hashes.setdefault(r["source_content_hash"], r["source_path"])
    by_id = {r["fact_id"]: r for r in rows}
    lineage = _lineage(rows, hashes, by_id, TimeStats())
    return _contradictions(rows, day, lineage)


def time_stats(db_path: Path | None = None, *, today: str | None = None) -> TimeStats:
    """Сводка по стору (только чтение). Сбой чтения → ``unmigrated=False`` и пустая сводка +
    ``notes``."""
    st = TimeStats()
    rows = _rows(db_path)
    if rows is None:
        st.unmigrated = True
        return st
    day = today or datetime.now(UTC).date().isoformat()
    st.total = len(rows)
    if not rows:
        return st
    st.superseded = sum(1 for r in rows if r["superseded_by"])
    st.provisional = sum(1 for r in rows if r["provisional"])
    st.undated = sum(1 for r in rows if not r["valid_from"])
    st.current = sum(1 for r in rows if not r["valid_to"] or r["valid_to"] > day)
    hashes: dict[str, str] = {}
    for r in rows:
        hashes.setdefault(r["source_content_hash"], r["source_path"])
    st.sources = len(hashes)
    by_id = {r["fact_id"]: r for r in rows}
    chained = {r["source_content_hash"] for r in rows if r["superseded_by"] or r["prev_fact_id"]}
    st.sources_in_chain = len(chained)

    # --- семейства: одна версия на хэш, листинг папки на папку --------------------------------
    lineage_of_path = _lineage(rows, hashes, by_id, st)
    # --- зерно KNOWLEDGE-LINT-1: противоречия среди актуальных фактов разных семейств ------------
    st.contradictions = len(_contradictions(rows, day, lineage_of_path))
    return st
