"""File ingest — the input bus for operational + knowledge folders (INGEST-1, §4a).

Operational sources (calcs, КП, contracts) live in an iCloud folder outside the
vault (cross-device). This package is the "input bus": scan the configured roots →
NDA filter → route → sink. It is the **file adapter** for the future INGRESS-1
contract, not a subsystem of its own.

- :mod:`core.file_ingest.config` — declarative ``_system/ingest-roots.yaml`` (per-device
  resolve; ``is_nda`` always excluded).
- :mod:`core.file_ingest.scan` — incremental scan by content-hash (resume, checkpoint,
  graceful SIGTERM), iCloud-dataless aware.
- :mod:`core.file_ingest.routes` — operational → SRC-1 ``register_source``; knowledge →
  legacy ``ingest_corpus`` + reindex (thin reuse, extractors not rewritten).

Invariants: ``core/file_ingest`` imports neither MCP nor CLI; Path B — no LLM/inference;
network only for iCloud materialization of a file. Reuses SRC-1 ``register_source``,
legacy ``ingest_corpus`` and NDA-1 ``is_nda`` rather than duplicating them.
"""

from __future__ import annotations

from core.file_ingest.config import IngestRoot, load_ingest_roots
from core.file_ingest.scan import ScanStats, scan

__all__ = ["IngestRoot", "load_ingest_roots", "ScanStats", "scan"]
