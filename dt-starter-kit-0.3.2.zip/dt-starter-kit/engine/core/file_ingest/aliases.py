"""Реестр алиасов рабочих папок — ФТ-2 (FT-12 PART-1).

Проблема из ФТ: пути в хранилище разнородны по написанию — ``Kazakhstan/Globex``
латиницей, ``Russia/Подводные технологии`` кириллицей. Поиск папки перед каждой
записью расходует вызовы моста и даёт ошибки адресации. Алиас сворачивает адрес
папки в один короткий токен: «положи в ЦОД» → ``place_download(dest="цод")``.

Файл — ``_system/folder-aliases.yaml`` (человекочитаемый, версионируемый, рядом с
``ingest-roots.yaml``)::

    aliases:
      цод:
        root_name: current
        rel_path: Kazakhstan/Globex/ЦОД
      globex:
        root_name: current
        rel_path: Kazakhstan/Globex

Сопоставление (:func:`resolve_alias`) — **три уровня, от точного к терпимому**, без
внешних зависимостей:

1. точное имя (NFC + casefold);
2. нормализованный ключ: убраны пробелы/``-``/``_``/``.`` и регистр;
3. транслит-скелет: кириллица→латиница по таблице + свёртка латинских вариантов
   написания (``ts``/``c``, ``kh``/``h``, ``y``/``i``, ``sh``…), поэтому «ЦОД»,
   «цод», «TSOD» и «cod» — один ключ, а «Глобекс» находит алиас
   ``Globex``. Уровень 3 применяется, только если совпадение **единственно**:
   свёртка терпима, и молча выбирать один из двух похожих алиасов при записи в
   клиентскую папку нельзя (та же логика, что запрет автовыбора «самого свежего»
   кандидата в ФТ-1).

:func:`set_alias` регистрирует алиас, только если цель проходит **те же гарды, что
запись** (:func:`core.file_ingest.write_target.resolve_write_target`): ``root_name``
∈ ingest-корни, containment по ``resolve``, не ``_nda``. Мимо гардов алиас не
попадает в файл — реестр не может стать обходным путём к запрещённой папке.

Слой: ни MCP, ни CLI, ни сети, ни LLM; аудит ``folder_alias_set`` — на MCP-обёртке.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]  # стаб-гэп PyYAML — как в operational/storage.py

from core.config import folder_aliases_path
from core.file_ingest.write_target import (
    DEFAULT_ROOT_NAME,
    WriteTargetError,
    resolve_write_target,
)

__all__ = [
    "FolderAlias",
    "AliasError",
    "resolve_alias",
    "list_aliases",
    "set_alias",
    "alias_keys",
]


class AliasError(RuntimeError):
    """Алиас не зарегистрирован (гард цели / некорректное имя). ``code`` — машинный."""

    def __init__(self, message: str, code: str = "refused") -> None:
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class FolderAlias:
    """Один алиас: короткое имя → адрес папки под ingest-корнем."""

    name: str
    root_name: str
    rel_path: str

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "root_name": self.root_name, "rel_path": self.rel_path}


# --------------------------------------------------------------------------- #
# Нормализация имени: регистр / разделители / транслит                         #
# --------------------------------------------------------------------------- #

# Разделители, которые в имени алиаса ничего не значат («под. технологии» ==
# «подтехнологии»).
_SEP_RE = re.compile(r"[\s\-_.·/]+")

# Кириллица → латиница. Многобуквенные цели (``zh``/``kh``/``ts``/``ch``/``sh``)
# — общепринятый транслит; следующий шаг (:data:`_LAT_FOLD`) сворачивает их и
# конкурирующие латинские написания к одному скелету, поэтому таблица может быть
# «наивной» — важно лишь, чтобы обе стороны сходились в одну форму.
_RU2LAT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e",
    "ж": "zh", "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m",
    "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "kh", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "shch",
    "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya",
    # казахская/украинская латиница-соседи, встречающиеся в именах папок
    "і": "i", "ї": "i", "є": "e", "ґ": "g", "ә": "a", "ғ": "g", "қ": "k",
    "ң": "n", "ө": "o", "ұ": "u", "ү": "u", "һ": "h",
}

# Свёртка латинских написаний к скелету. Порядок значим: длинные диграфы раньше
# коротких. Цель — чтобы «tsod», «cod» и транслит «цод» дали одну строку.
_LAT_FOLD: tuple[tuple[str, str], ...] = (
    ("shch", "sc"), ("sch", "sc"), ("sh", "s"), ("ch", "c"), ("zh", "z"),
    ("kh", "h"), ("ph", "f"), ("ts", "c"), ("ck", "k"), ("th", "t"),
    ("yu", "u"), ("ya", "a"), ("yo", "o"), ("ye", "e"), ("ee", "i"),
    ("j", "z"), ("w", "v"), ("q", "k"), ("x", "ks"), ("y", "i"),
)


def _nfc(text: str) -> str:
    return unicodedata.normalize("NFC", str(text or ""))


def _exact_key(name: str) -> str:
    """Уровень 1: NFC + casefold + обрезка (регистронезависимо, буква-в-букву)."""
    return _nfc(name).strip().casefold()


def _norm_key(name: str) -> str:
    """Уровень 2: то же, но без пробелов/``-``/``_``/``.``/``/``."""
    return _SEP_RE.sub("", _exact_key(name))


def _skeleton_key(name: str) -> str:
    """Уровень 3: транслит-скелет (кириллица→латиница + свёртка латинских форм)."""
    src = _norm_key(name)
    lat = "".join(_RU2LAT.get(ch, ch) for ch in src)
    for src_seq, dst in _LAT_FOLD:
        lat = lat.replace(src_seq, dst)
    # схлопнуть удвоения («ss» → «s»): написания вроде «rossiya»/«rosia» сходятся
    out: list[str] = []
    for ch in lat:
        if not out or out[-1] != ch:
            out.append(ch)
    return "".join(out)


def alias_keys(name: str) -> tuple[str, str, str]:
    """Три ключа сопоставления имени (точный / нормализованный / скелет) — для тестов."""
    return _exact_key(name), _norm_key(name), _skeleton_key(name)


# --------------------------------------------------------------------------- #
# Чтение / запись реестра                                                      #
# --------------------------------------------------------------------------- #


def _parse_alias(name: Any, entry: Any) -> FolderAlias | None:
    """Один алиас из YAML-записи, или ``None`` если запись некорректна."""
    alias = _nfc(name).strip()
    if not alias:
        return None
    if isinstance(entry, str):
        # короткая форма для правки руками: «алиас: rel/path» на корне по умолчанию
        root_name, rel_path = DEFAULT_ROOT_NAME, entry.strip()
    elif isinstance(entry, dict):
        root_name = str(entry.get("root_name", "") or "").strip()
        rel_path = str(entry.get("rel_path", "") or "").strip()
    else:
        return None
    if not root_name:
        return None
    return FolderAlias(name=alias, root_name=root_name, rel_path=rel_path.strip("/"))


def list_aliases(vault_path: Path | None = None) -> list[FolderAlias]:
    """Все алиасы реестра, по имени. Нет файла / битый YAML / чужая форма → ``[]``.

    Read-only и никогда не бросает: реестр — удобство адресации, его отсутствие не
    должно ломать ни один вызов (адресовать папку можно и root-относительным путём).
    """
    path = folder_aliases_path(vault_path)
    if not path.is_file():
        return []
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (yaml.YAMLError, OSError):
        return []
    if not isinstance(data, dict):
        return []
    raw = data.get("aliases")
    if not isinstance(raw, dict):
        return []
    out: list[FolderAlias] = []
    seen: set[str] = set()
    for name, entry in raw.items():
        alias = _parse_alias(name, entry)
        if alias is None or _exact_key(alias.name) in seen:
            continue
        seen.add(_exact_key(alias.name))
        out.append(alias)
    return sorted(out, key=lambda a: _exact_key(a.name))


def resolve_alias(name: str, vault_path: Path | None = None) -> FolderAlias | None:
    """Найти алиас по имени: точное → нормализованное → транслит-скелет.

    Регистронезависимо, кириллица и латиница. Уровень скелета срабатывает только
    при **единственном** совпадении (иначе ``None`` — молча выбирать одну из двух
    похожих папок нельзя). Ничего не найдено → ``None`` (вызывающий трактует
    ``dest`` как root-относительный путь).
    """
    if not str(name or "").strip():
        return None
    aliases = list_aliases(vault_path)
    if not aliases:
        return None
    for key_fn in (_exact_key, _norm_key):
        key = key_fn(name)
        for alias in aliases:
            if key_fn(alias.name) == key:
                return alias
    skeleton = _skeleton_key(name)
    hits = [a for a in aliases if _skeleton_key(a.name) == skeleton]
    return hits[0] if len(hits) == 1 else None


def set_alias(
    name: str,
    root_name: str,
    rel_path: str,
    *,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Зарегистрировать/обновить алиас — только если цель проходит гарды записи.

    Гарды — те же, что у записи файла (:func:`resolve_write_target`): ``root_name``
    ∈ ``ingest-roots.yaml``, containment по ``resolve`` (``../``/абсолютный/
    симлинк-эскейп → отказ), не ``_nda``. Отказ → :class:`AliasError` (файл реестра
    НЕ трогается). ``rel_path`` пустой (или ``"."``) = сам корень.

    Возврат ``{ok, name, root_name, rel_path, path, exists, created, updated}``
    (``path`` — абсолютный целевой путь; ``exists`` — существует ли папка уже:
    алиас разрешено завести заранее, но полезно видеть, что её ещё нет).
    """
    alias_name = _nfc(name).strip()
    if not alias_name:
        raise AliasError("имя алиаса не задано", "bad_alias_name")
    if _SEP_RE.sub("", alias_name) == "":
        raise AliasError("имя алиаса состоит только из разделителей", "bad_alias_name")
    try:
        target = resolve_write_target(
            root_name, rel_path, vault_path=vault_path, allow_root=True
        )
    except WriteTargetError as exc:
        raise AliasError(str(exc), exc.code) from exc

    path = folder_aliases_path(vault_path)
    existing = {a.name: a for a in list_aliases(vault_path)}
    previous = None
    for other in list(existing.values()):
        if _exact_key(other.name) == _exact_key(alias_name):
            previous = other
            existing.pop(other.name, None)
            break
    existing[alias_name] = FolderAlias(
        name=alias_name, root_name=target.root_name, rel_path=target.rel_path
    )
    payload = {
        "aliases": {
            a.name: {"root_name": a.root_name, "rel_path": a.rel_path}
            for a in sorted(existing.values(), key=lambda a: _exact_key(a.name))
        }
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(
            yaml.safe_dump(payload, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
        tmp.replace(path)  # атомарная подмена реестра
    except OSError as exc:
        tmp.unlink(missing_ok=True)
        raise AliasError(f"не удалось записать реестр алиасов: {exc}", "write_failed") from exc

    return {
        "ok": True,
        "name": alias_name,
        "root_name": target.root_name,
        "rel_path": target.rel_path,
        "path": str(target.path),
        "exists": target.path.is_dir(),
        "created": previous is None,
        "updated": previous is not None,
    }
