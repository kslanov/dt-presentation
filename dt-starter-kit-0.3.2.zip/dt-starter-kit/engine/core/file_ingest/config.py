"""Declarative watched-roots config for the file ingest (INGEST-1 PART-1).

The ingest is driven by a human-readable, versioned YAML at
``_system/ingest-roots.yaml`` — a list of folders to watch, each with a route
(``knowledge`` | ``operational``), include/exclude globs and optional hints:

    roots:
      - name: acme-ops
        path: ${DT_ICLOUD}/legacy/2023-2026/Acme
        route: operational
        include: ["**/*.xlsx", "**/*.docx", "**/*.pdf"]
        exclude: ["**/~$*"]
        entity_hint: client-acme
      - name: methodology
        path: ~/Docs/Методология
        route: knowledge
        note_type: reference

Absolute ``path`` is resolved **per device** (the iCloud root differs per machine):
``DT_INGEST_ROOT_<NAME>`` (uppercased, non-alnum→``_``) overrides ``path`` outright;
otherwise ``~`` and ``${VAR}`` are expanded. A broken/empty/absent config yields
``[]`` (the ingest does nothing, never crashes).

NDA-1: :func:`core.privacy.is_nda` is **always** part of the exclude test, on top of
the user globs — it cannot be turned off by config.

Invariants: ``core/file_ingest`` imports neither MCP nor CLI; pure/deterministic (no
network here — the config layer only reads YAML + env).
"""

from __future__ import annotations

import fnmatch
import os
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from core.config import ingest_roots_path
from core.privacy import is_eval, is_nda

__all__ = ["IngestRoot", "load_ingest_roots", "path_matches", "ROUTES"]

ROUTE_KNOWLEDGE = "knowledge"
ROUTE_OPERATIONAL = "operational"
ROUTES = frozenset({ROUTE_KNOWLEDGE, ROUTE_OPERATIONAL})

# Corpus layer of a knowledge root's notes (CORPUS-INGEST-CURRENT). Default
# ``legacy`` keeps every pre-existing root backward-compatible (the field is
# optional in ingest-roots.yaml); ``current`` marks a live curated root
# (CDT_Internal) whose files become ``corpus: current`` notes.
CORPUS_LEGACY = "legacy"
CORPUS_CURRENT = "current"
CORPORA = frozenset({CORPUS_LEGACY, CORPUS_CURRENT})

_DEFAULT_INCLUDE = ("**/*",)
_ENV_NAME_RE = re.compile(r"[^A-Z0-9]+")


@dataclass
class IngestRoot:
    """One watched root: where, which route, and how to filter it."""

    name: str
    path: Path
    route: str
    include: tuple[str, ...] = _DEFAULT_INCLUDE
    exclude: tuple[str, ...] = ()
    note_type: str | None = None
    entity_hint: str | None = None
    # Corpus layer for a knowledge root's notes (CORPUS-INGEST-CURRENT). Default
    # ``legacy`` (backward compatible); ``current`` for a live curated root.
    corpus: str = CORPUS_LEGACY

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "path": str(self.path),
            "route": self.route,
            "include": list(self.include),
            "exclude": list(self.exclude),
            "note_type": self.note_type,
            "entity_hint": self.entity_hint,
            "corpus": self.corpus,
        }


def _nfc(text: str) -> str:
    return unicodedata.normalize("NFC", text)


def _glob_match(rel_posix: str, pattern: str) -> bool:
    """Case-insensitive glob over a relative posix path (mirrors legacy discover).

    The path is anchored with a leading ``/`` so ``**/X``-style patterns match at
    any depth including the top level; ``**`` reduces to ``*`` (fnmatch's ``*``
    already crosses ``/``); both sides NFC-normalized for Cyrillic.
    """
    hay = "/" + _nfc(rel_posix).lstrip("/")
    pat = _nfc(pattern).replace("**", "*")  # only the hay is anchored, as in legacy
    return fnmatch.fnmatchcase(hay.lower(), pat.lower())


def path_matches(
    rel_posix: str, *, include: tuple[str, ...], exclude: tuple[str, ...]
) -> bool:
    """True when ``rel_posix`` passes include/exclude AND is not NDA (NDA-1).

    ``is_nda`` is checked first and unconditionally — a user config can never let an
    NDA path through. Then it must match ≥1 include glob and no exclude glob.
    """
    if is_nda(rel_posix):
        return False
    if is_eval(rel_posix):  # EVAL-HYGIENE-1: карантин прогонов - тот же класс маркера, что _nda
        return False
    if not any(_glob_match(rel_posix, g) for g in (include or _DEFAULT_INCLUDE)):
        return False
    if any(_glob_match(rel_posix, g) for g in exclude):
        return False
    return True


def _env_override(name: str) -> str | None:
    """``DT_INGEST_ROOT_<NAME>`` (name uppercased, non-alnum → ``_``), or None."""
    key = "DT_INGEST_ROOT_" + _ENV_NAME_RE.sub("_", name.upper()).strip("_")
    val = os.environ.get(key)
    return val.strip() if val and val.strip() else None


def _resolve_path(name: str, raw_path: str) -> Path:
    """Resolve a root path per-device: env override > ``${VAR}``/``~`` expansion."""
    override = _env_override(name)
    raw = override if override is not None else raw_path
    return Path(os.path.expanduser(os.path.expandvars(raw)))


def _str_tuple(value: Any) -> tuple[str, ...]:
    if isinstance(value, str):
        return (value,) if value.strip() else ()
    if isinstance(value, (list, tuple)):
        return tuple(str(v) for v in value if str(v).strip())
    return ()


def _parse_root(entry: Any) -> IngestRoot | None:
    """Build one :class:`IngestRoot` from a YAML entry, or ``None`` if malformed."""
    if not isinstance(entry, dict):
        return None
    name = str(entry.get("name", "")).strip()
    raw_path = str(entry.get("path", "")).strip()
    route = str(entry.get("route", "")).strip().lower()
    if not name or not raw_path or route not in ROUTES:
        return None
    include = _str_tuple(entry.get("include")) or _DEFAULT_INCLUDE
    exclude = _str_tuple(entry.get("exclude"))
    note_type = entry.get("note_type")
    entity_hint = entry.get("entity_hint")
    # Optional corpus layer (default legacy); an unknown value falls back to legacy
    # so a typo never silently mislabels a whole root as current.
    corpus = str(entry.get("corpus", "")).strip().lower()
    if corpus not in CORPORA:
        corpus = CORPUS_LEGACY
    return IngestRoot(
        name=name,
        path=_resolve_path(name, raw_path),
        route=route,
        include=include,
        exclude=exclude,
        note_type=str(note_type).strip() if note_type else None,
        entity_hint=str(entity_hint).strip() if entity_hint else None,
        corpus=corpus,
    )


def load_ingest_roots(vault_path: Path | None = None) -> list[IngestRoot]:
    """Load + resolve the watched roots from ``ingest-roots.yaml`` (INGEST-1 PART-1).

    Missing file, unreadable YAML, or a shape that is not ``{roots: [...]}`` all
    yield ``[]`` — the ingest simply does nothing. Individual malformed entries
    (missing name/path or a bad route) are skipped; the rest still load.
    """
    path = ingest_roots_path(vault_path)
    if not path.is_file():
        return []
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (yaml.YAMLError, OSError):
        return []
    if not isinstance(data, dict):
        return []
    raw_roots = data.get("roots")
    if not isinstance(raw_roots, list):
        return []
    roots: list[IngestRoot] = []
    seen: set[str] = set()
    for entry in raw_roots:
        root = _parse_root(entry)
        if root is None or root.name in seen:
            continue
        seen.add(root.name)
        roots.append(root)
    return roots
