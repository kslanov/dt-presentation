"""File-ingest manifest — content-hash keyed processed-file ledger (INGEST-1).

The scan's incrementality/resume/idempotency ledger: ``content_hash → record``.
Keyed by hash (not path or mtime) so identity survives the per-device iCloud path
and the mtime trap — presence of a hash means "already processed". Same atomic
write-then-replace + malformed-is-rebuildable convention as the legacy/outlook
manifests. No network, no LLM.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from core.adapters import load_json_store

__all__ = ["load_manifest", "save_manifest"]


def load_manifest(path: Path) -> dict[str, dict[str, Any]]:
    """Read the manifest (``content_hash → record``); ``{}`` if the file does not exist.

    Файл есть, но битый → :class:`~core.adapters.StoreUnavailableError` (ADAPTER-HONEST-1):
    пустой реестр = «ничего не обработано», и весь корень файлов ушёл бы в переобработку."""
    data = load_json_store(path, adapter="file_ingest_manifest", expect=dict)
    if data is None:
        return {}
    return {str(k): v for k, v in data.items() if isinstance(v, dict)}


def save_manifest(path: Path, manifest: dict[str, dict[str, Any]]) -> None:
    """Persist the manifest atomically (write-temp-then-replace), creating parents."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    tmp.replace(path)
