"""Ingest sinks — operational (SRC-1 registry) vs knowledge (legacy note+index).

Two routes, each a **thin reuse** of existing machinery (INGEST-1 PART-3/4):

- **operational** → :func:`core.sources.cache.register_source`: record the file's
  ``content_hash``/path/mtime/size/kind in the SRC-1 ``sources`` registry so it is
  on-demand liftable (SRC-1/FACT-1/TMPL-1 work on it) **without** a note or index
  entry. An optional ``entity_hint`` is stored as the registry's ``note_ref`` — the
  "file ↔ card/entity" link for a future auto-``source_path`` (the card itself is
  never touched, принцип 10).
- **knowledge** → :func:`core.legacy.ingest.ingest_corpus` (extract → normalize →
  ``_legacy`` markdown note) then an incremental :func:`core.retrieval.index.reindex`.
  The legacy extractors/linking are reused verbatim — not reimplemented.

Knowledge vs operational are deliberately separated: the operational route never
indexes and never writes a note. Path B; the only side effects are the local
registry, the ingest notes, and the index (a local knowledge-ingest artifact, like
legacy — not an external-system write).
"""

from __future__ import annotations

import logging
from pathlib import Path

from core.file_ingest.config import IngestRoot

__all__ = ["route_operational", "route_knowledge"]


def route_operational(
    content_hash: str,
    *,
    path: str,
    mtime: float,
    size: int,
    kind: str,
    entity_hint: str | None = None,
) -> None:
    """Register one file in the SRC-1 source registry (no note, no index).

    Reuses :func:`core.sources.cache.register_source`; ``entity_hint`` (a card /
    entity id from the root config) rides along as the registry ``note_ref`` so the
    "file ↔ entity" association is recorded for later — without editing the card.
    """
    from core.sources.cache import forget_path_versions, register_source

    register_source(
        content_hash,
        path=path,
        mtime=mtime,
        size=size,
        kind=kind,
        status="registered",
        note_ref=entity_hint,
    )
    # INGEST-SCHEDULE PART-3б: an operational file is keyed by PATH (mutable root →
    # byte-hash is the version). A re-registered (edited) file leaves a stale
    # old-hash row still listing this path; prune those so the registry stays
    # path-current and does not grow one dead entry per edit. resolve/lift already
    # pick the live version (path-first, live-hash) — this just bounds the registry.
    forget_path_versions(path, keep_hash=content_hash)
    # PULT-EVENTLOG: операционный ingest — файл зарегистрирован, заметки нет
    # (note_id=None; нить — source_hash). Best-effort (сбой лога не ломает ingest).
    from core.eventlog import emit

    emit(
        "ingest",
        "registered",
        source_hash=content_hash,
        path=path,
        detail={"route": "operational", "kind": kind},
    )


def route_knowledge(
    roots: list[IngestRoot],
    *,
    vault_path: Path | None = None,
    dry_run: bool = False,
    content_hashes: dict[str, str] | None = None,
    reindex: bool = True,
) -> bool:
    """Run the legacy note pipeline over ``roots`` then reindex (INGEST-1 PART-4).

    A thin wrapper: for each knowledge root call ``ingest_corpus`` (extract→note),
    then trigger one incremental ``reindex``. NDA-1 holds inside ``ingest_corpus``
    too (its discovery skips ``is_nda`` paths). ``dry_run`` computes but writes
    nothing and does not reindex. ``content_hashes`` (abs path → byte-hash, already
    computed by the scan) is forwarded so ``ingest_corpus`` dedups by **content,
    not path** without re-hashing — the scan and legacy manifests share one
    byte-hash identity, so a file moved within an imported root is not re-imported
    (INGEST-DEDUP PART-3). Returns whether a reindex was triggered.

    ``reindex=False`` (WAVE0-HYGIENE п.3): notes are rendered, the incremental reindex is
    left to the caller — the nightly ``dt_sync index`` chain runs ``reindex_inc`` right
    after this step, so an inner reindex doubled the model load and the vault walk.
    """
    if dry_run or not roots:
        return False

    from core.config import default_vault_path
    from core.legacy.ingest import ingest_corpus

    vp = Path(vault_path) if vault_path is not None else default_vault_path()
    for root in roots:
        # CORPUS-INGEST-CURRENT: a root's layer (legacy default / current) flows into
        # the note frontmatter + which manifest owns it. INGEST-SCHEDULE therefore
        # picks up new CDT_Internal files as current-knowledge notes automatically.
        ingest_corpus(
            vp, roots=[root.path], dry_run=False, content_hashes=content_hashes,
            corpus=root.corpus,
        )
    if not reindex:
        return False
    from core.retrieval.index import IndexBusyError
    from core.retrieval.index import reindex as _reindex

    try:
        _reindex(vp)
    except IndexBusyError as exc:  # занят или версия чанкера ≠ кода (п.9): ingest не падает
        logging.getLogger(__name__).warning("reindex skipped — %s", exc)
        return False
    return True
