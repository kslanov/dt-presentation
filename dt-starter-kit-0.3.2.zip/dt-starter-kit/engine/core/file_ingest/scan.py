"""Incremental file-ingest scan — the input bus (INGEST-1 PART-2).

Walks the configured roots, filters (include/exclude + NDA-1 ``is_nda``), handles
iCloud dataless placeholders, and routes **new/changed** files to their sink while
skipping unchanged ones. Identity and incrementality are by **content_hash** (not
path or mtime — the iCloud root differs per device and mtime lies): a file whose
hash is already in ``file_ingest_manifest.json`` is done.

Steady-state cost (INGEST-SCHEDULE PART-3а): a **fast-path** skips a file whose
``path`` is known and whose ``mtime+size`` are unchanged **without hashing it or
materializing a dataless placeholder** — so a frequent scheduled pass over a large
mutable operational root costs one ``stat`` per file, not a full re-hash (the same
tradeoff the legacy INGEST-DEDUP fast-path makes). A real edit shifts ``mtime|size``
and falls through to the byte-hash, which re-routes it.

Principle 11 (bulk): a progress line per file, the manifest checkpointed as it goes
(so a re-run resumes and repeats do nothing), and graceful ``SIGTERM`` — on a
signal the current checkpoint is flushed and the scan stops cleanly.

iCloud dataless (PART-0 FINDINGS): a placeholder is detected by ``st_flags &
SF_DATALESS`` / zero disk blocks **before** any read (reading blocks while it
downloads). On ``--apply`` we ``brctl download`` with a timeout; if it does not
materialize we mark it ``pending_download`` and skip — never read a stub, never
crash — and the next pass retries. In dry-run we never download (report only).

Invariants: ``core/file_ingest`` imports neither MCP nor CLI; Path B — no LLM; the only
network is the iCloud materialization of a file (never inference).
"""

from __future__ import annotations

import os
import signal
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core import runlock
from core.adapters import AdapterInterrupted
from core.config import file_ingest_manifest_path, ingest_materialize_timeout
from core.file_ingest.config import (
    ROUTE_KNOWLEDGE,
    ROUTE_OPERATIONAL,
    IngestRoot,
    load_ingest_roots,
    path_matches,
)
from core.file_ingest.manifest import load_manifest, save_manifest
from core.fsguard import SF_DATALESS, guarded_call, is_dataless, materialize
from core.sources.cache import file_content_hash

__all__ = ["ScanStats", "FileAction", "scan", "is_dataless", "SF_DATALESS", "materialize"]

# is_dataless / SF_DATALESS live in core.fsguard (WAVE0-HYGIENE п.3): the legacy ingest
# needs the same guard before it reads a file, and core.legacy must not import this module.

# Statuses recorded per file (also the ScanStats counters).
STATUS_NEW = "new"
STATUS_CHANGED = "changed"
STATUS_UNCHANGED = "unchanged"
STATUS_NDA = "nda_skipped"
STATUS_EVAL = "eval_quarantine"  # EVAL-HYGIENE-1: под _eval - прогон eval/selftest, не знание
STATUS_EXCLUDED = "excluded"
STATUS_PENDING = "pending_download"
STATUS_ERROR = "error"

# Checkpoint the manifest every N processed files (resume granularity, principle 11).
_CHECKPOINT_EVERY = 25


@dataclass
class FileAction:
    """One file's disposition in a scan (route filled only when it was routed)."""

    path: str
    status: str
    route: str = ""
    content_hash: str = ""
    root: str = ""
    reason: str = ""  # SRC-ICLOUD-1: ``source_not_local`` у пропуска iCloud-заглушки


@dataclass
class ScanStats:
    """Roll-up of one scan pass (principle 11 progress + audit counters)."""

    roots: int = 0
    total_seen: int = 0
    new: int = 0
    changed: int = 0
    unchanged: int = 0
    nda_skipped: int = 0
    eval_skipped: int = 0
    excluded: int = 0
    pending_download: int = 0
    errors: int = 0
    operational_registered: int = 0
    knowledge_roots_ingested: int = 0
    reindex_triggered: bool = False
    dry_run: bool = True
    elapsed_s: float = 0.0
    manifest_path: str = ""
    interrupted: bool = False
    actions: list[FileAction] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "roots": self.roots,
            "total_seen": self.total_seen,
            "new": self.new,
            "changed": self.changed,
            "unchanged": self.unchanged,
            "nda_skipped": self.nda_skipped,
            "eval_skipped": self.eval_skipped,
            "excluded": self.excluded,
            "pending_download": self.pending_download,
            "errors": self.errors,
            "operational_registered": self.operational_registered,
            "knowledge_roots_ingested": self.knowledge_roots_ingested,
            "reindex_triggered": self.reindex_triggered,
            "dry_run": self.dry_run,
            "elapsed_s": round(self.elapsed_s, 3),
            "manifest_path": self.manifest_path,
            "interrupted": self.interrupted,
        }


# --------------------------------------------------------------------------- #
# iCloud dataless (PART-0 FINDINGS)                                            #
# --------------------------------------------------------------------------- #


# --------------------------------------------------------------------------- #
# Scan                                                                        #
# --------------------------------------------------------------------------- #


def _iter_root_files(root: IngestRoot) -> list[tuple[Path, str]]:
    """Yield ``(abs_path, rel_posix)`` for every file under a root, sorted.

    Hidden dot-dirs are skipped; the relative posix path is what include/exclude/
    ``is_nda`` match against (structure, not the per-device absolute prefix).
    """
    base = root.path
    out: list[tuple[Path, str]] = []
    if not base.is_dir():
        return out
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = sorted(d for d in dirnames if not d.startswith("."))
        for name in sorted(filenames):
            if name.startswith("."):
                continue
            abs_path = Path(dirpath) / name
            rel = abs_path.relative_to(base).as_posix()
            out.append((abs_path, rel))
    return out


def scan(
    *,
    vault_path: Path | None = None,
    root_name: str | None = None,
    route: str | None = None,
    dry_run: bool = True,
    log: Callable[[str], None] | None = None,
    reindex: bool = True,
) -> ScanStats:
    """Run one incremental ingest pass over the configured roots (INGEST-1 PART-2).

    ``dry_run`` (default) computes the full disposition but writes nothing — no
    registry, no notes, no manifest, no reindex, and **no iCloud download**.
    ``dry_run=False`` (apply) routes new/changed files: operational →
    ``register_source``, knowledge → ``ingest_corpus`` + incremental reindex, and
    checkpoints the manifest as it goes. ``root_name`` limits the pass to one root;
    ``route`` (``operational``/``knowledge``) narrows to roots of that route — both
    are pure root-set filters (same as before, just scoped), the ingest logic is
    unchanged. Graceful ``SIGTERM``: the current checkpoint is flushed and stops.

    ``reindex=False`` (WAVE0-HYGIENE п.3): the knowledge route renders notes but does NOT
    run its own incremental reindex — the nightly chain (``dt_sync index``) runs
    ``reindex_inc`` right after, and a second pass meant two model loads and two vault walks.
    """
    from core.file_ingest import routes  # local: keeps config layer import-light

    start = time.perf_counter()
    log = log or print
    roots = load_ingest_roots(vault_path)
    if root_name:
        roots = [r for r in roots if r.name == root_name]
    if route:
        roots = [r for r in roots if r.route == route]

    manifest_path = file_ingest_manifest_path()
    manifest = load_manifest(manifest_path)
    # path → stored hash, so a same-path file with a new hash reads as "changed"
    # (re-routed, old hash entry pruned) rather than an unrelated "new".
    path_index = _build_path_index(manifest)
    stats = ScanStats(
        roots=len(roots), dry_run=dry_run, manifest_path=str(manifest_path)
    )

    stop = _install_sigterm()
    timeout_s = ingest_materialize_timeout()
    # Knowledge roots that gained ≥1 new/changed file → ingest_corpus once each.
    knowledge_pending: list[IngestRoot] = []
    processed_since_ckpt = 0

    # INGRESS-1 п.4: отказы прохода копим по (адаптер, причина) и пишем в журнал одной пачкой в
    # конце — на тысячах исключенных файлов не тысячи open() на каждый.
    refusals: dict[tuple[str, str], list[tuple[str, None]]] = {}

    def _refuse(root: IngestRoot, reason: str, rel_path: str) -> None:
        refusals.setdefault((f"files:{root.route}", reason), []).append((rel_path, None))

    files: list[tuple[IngestRoot, Path, str]] = []
    for root in roots:
        for abs_path, rel in _iter_root_files(root):
            files.append((root, abs_path, rel))
    total = len(files)

    for i, (root, abs_path, rel) in enumerate(files, start=1):
        if stop["flag"]:
            stats.interrupted = True
            break
        stats.total_seen += 1
        runlock.beat()  # WAVE0-HYGIENE п.3: heartbeat на файл — сторож видит прогресс

        if not path_matches(rel, include=root.include, exclude=root.exclude):
            # NDA is folded into path_matches → distinguish for the audit/counters.
            from core.privacy import is_eval, is_nda

            if is_nda(rel):
                stats.nda_skipped += 1
                stats.actions.append(FileAction(str(abs_path), STATUS_NDA, root=root.name))
                _refuse(root, "nda_path", rel)  # только счетчик: путь в журнал не идет
            elif is_eval(rel):
                stats.eval_skipped += 1
                stats.actions.append(FileAction(str(abs_path), STATUS_EVAL, root=root.name))
                _refuse(root, "eval_quarantine", rel)  # только счетчик
            else:
                stats.excluded += 1
                _refuse(root, "exclude_rule", rel)
            continue

        action = _process_file(
            root, abs_path, rel, manifest=manifest, path_index=path_index,
            dry_run=dry_run, timeout_s=timeout_s, routes=routes,
        )
        stats.actions.append(action)
        _tally(stats, action)
        if action.status == STATUS_PENDING:
            _refuse(root, "dataless", rel)  # iCloud-заглушка: повторится на следующем проходе
        elif action.status == STATUS_ERROR:
            _refuse(root, "error", rel)

        if action.status in (STATUS_NEW, STATUS_CHANGED):
            if root.route == ROUTE_KNOWLEDGE and root not in knowledge_pending:
                knowledge_pending.append(root)
            processed_since_ckpt += 1
            if not dry_run and processed_since_ckpt >= _CHECKPOINT_EVERY:
                save_manifest(manifest_path, manifest)
                processed_since_ckpt = 0

        elapsed = time.perf_counter() - start
        eta = (elapsed / i) * (total - i) if i else 0.0
        log(
            f"[ingest] {i}/{total} | {root.route}:{root.name} | {action.status} "
            f"| {elapsed:.1f}s | ~{eta:.0f}s eta"
        )

    # OCR-1 (приемка 29.10): после OCR файл не меняется, но заметку надо перерисовать -
    # знаниевый корень с ожидающими ``ocr_refresh`` идет в маршрут и без измененных файлов.
    if not stop["flag"]:
        from core.legacy.ingest import pending_ocr_refresh

        for root in roots:
            if (root.route == ROUTE_KNOWLEDGE and root not in knowledge_pending
                    and pending_ocr_refresh(root.corpus) > 0):
                knowledge_pending.append(root)
                log(f"[ingest] {root.route}:{root.name} | ocr_refresh pending → knowledge route")

    # Knowledge route: delegate rendering to the legacy pipeline, then reindex once.
    if not stop["flag"] and knowledge_pending:
        vp = vault_path
        # Forward the byte-hashes already computed this scan so the legacy ingest
        # dedups by content (not path) without re-hashing — one shared identity
        # across the scan and legacy manifests (INGEST-DEDUP PART-3).
        content_hashes = {
            a.path: a.content_hash
            for a in stats.actions
            if a.route == ROUTE_KNOWLEDGE and a.content_hash
        }
        did = routes.route_knowledge(
            knowledge_pending, vault_path=vp, dry_run=dry_run,
            content_hashes=content_hashes, reindex=reindex,
        )
        stats.knowledge_roots_ingested = len(knowledge_pending)
        stats.reindex_triggered = did

    if not dry_run:
        save_manifest(manifest_path, manifest)

    stats.elapsed_s = time.perf_counter() - start
    _flush_refusals(refusals)
    _audit(stats, route)
    return stats


def _flush_refusals(refusals: dict[tuple[str, str], list[tuple[str, None]]]) -> None:
    """Журнал отказов прохода (INGRESS-1 п.4): ``exclude_rule``/``dataless``/``error`` — с путем
    относительно корня; ``nda_path`` — счетчик без строки (политика ``counter``)."""
    from core.ingress.refusals import refuse_many

    for (adapter, reason), items in refusals.items():
        refuse_many(adapter, reason, items)


def _build_path_index(manifest: dict[str, dict[str, Any]]) -> dict[str, str]:
    """Map each recorded path → its content_hash (for change detection)."""
    index: dict[str, str] = {}
    for content_hash, entry in manifest.items():
        for p in entry.get("paths", []):
            if isinstance(p, str):
                index[p] = content_hash
    return index


def _process_file(
    root: IngestRoot,
    abs_path: Path,
    rel: str,
    *,
    manifest: dict[str, dict[str, Any]],
    path_index: dict[str, str],
    dry_run: bool,
    timeout_s: float,
    routes: Any,
) -> FileAction:
    """Classify + (unless dry-run) route one file. Never raises for expected cases."""
    try:
        st = abs_path.stat()  # cheap; available on an iCloud placeholder without a download
    except OSError:
        return FileAction(str(abs_path), STATUS_ERROR, root=root.name)

    # INGEST-DEDUP fast-path (INGEST-SCHEDULE PART-3а): same path + unchanged
    # mtime+size → UNCHANGED **without hashing** (and without materializing a
    # dataless placeholder). Steady-state cost = one stat per file, so a frequent
    # operational cadence stays cheap on a large mutable root. A real edit shifts
    # mtime|size → falls through to the byte-hash path below (same risk tradeoff as
    # the legacy INGEST-DEDUP fast-path).
    prev = path_index.get(str(abs_path))
    if prev is not None:
        entry = manifest.get(prev)
        if isinstance(entry, dict) and entry.get("mtime") == st.st_mtime \
                and entry.get("size") == st.st_size:
            return FileAction(
                str(abs_path), STATUS_UNCHANGED, route=root.route,
                content_hash=prev, root=root.name,
            )

    try:
        # Dataless must be handled BEFORE hashing (a read would block, PART-0).
        if is_dataless(abs_path):
            if dry_run or not materialize(abs_path, timeout_s=timeout_s):
                return FileAction(
                    str(abs_path), STATUS_PENDING, root=root.name, reason="source_not_local"
                )

        # WAVE0-HYGIENE п.3: даже «скачанный» файл может зависнуть на чтении (fileproviderd
        # после сна) — хэш под таймаутом; зависание = pending (повторим), не вечное ожидание.
        content_hash = guarded_call(file_content_hash, abs_path, what="хэш файла")
        st = abs_path.stat()  # re-stat post-materialize so the record's mtime/size are live
    except AdapterInterrupted:
        return FileAction(str(abs_path), STATUS_PENDING, root=root.name)
    except OSError:
        return FileAction(str(abs_path), STATUS_ERROR, root=root.name)

    if content_hash in manifest:  # same bytes already processed → skip (by hash)
        return FileAction(
            str(abs_path), STATUS_UNCHANGED, route=root.route,
            content_hash=content_hash, root=root.name,
        )

    key = str(abs_path)
    prev_hash = path_index.get(key)
    status = STATUS_CHANGED if prev_hash is not None else STATUS_NEW
    kind = abs_path.suffix.lower().lstrip(".") or "unknown"

    if not dry_run:
        if root.route == ROUTE_OPERATIONAL:
            routes.route_operational(
                content_hash, path=key, mtime=st.st_mtime,
                size=st.st_size, kind=kind, entity_hint=root.entity_hint,
            )
        if prev_hash is not None:  # prune the stale entry for this path
            _forget_path(manifest, prev_hash, key)
        manifest[content_hash] = {
            "paths": [key],
            "mtime": st.st_mtime,
            "size": st.st_size,
            "kind": kind,
            "route": root.route,
            "root": root.name,
            "status": "processed",
        }
        path_index[key] = content_hash
    return FileAction(
        str(abs_path), status, route=root.route,
        content_hash=content_hash, root=root.name,
    )


def _forget_path(manifest: dict[str, dict[str, Any]], content_hash: str, path: str) -> None:
    """Drop ``path`` from an old hash entry; remove the entry if it becomes empty."""
    entry = manifest.get(content_hash)
    if not isinstance(entry, dict):
        return
    paths = [p for p in entry.get("paths", []) if isinstance(p, str) and p != path]
    if paths:
        entry["paths"] = paths
    else:
        manifest.pop(content_hash, None)


def _tally(stats: ScanStats, action: FileAction) -> None:
    if action.status in (STATUS_NEW, STATUS_CHANGED):
        if action.status == STATUS_NEW:
            stats.new += 1
        else:
            stats.changed += 1
        if action.route == ROUTE_OPERATIONAL:
            stats.operational_registered += 1
    elif action.status == STATUS_UNCHANGED:
        stats.unchanged += 1
    elif action.status == STATUS_PENDING:
        stats.pending_download += 1
    elif action.status == STATUS_ERROR:
        stats.errors += 1


def _install_sigterm() -> dict[str, bool]:
    """Set a graceful SIGTERM flag; a no-op off the main thread (tests/threads)."""
    stop = {"flag": False}

    def _handler(_signum: int, _frame: Any) -> None:
        stop["flag"] = True

    try:
        signal.signal(signal.SIGTERM, _handler)
    except (ValueError, OSError):
        pass  # not on the main thread → skip; the scan still completes
    return stop


def _audit(stats: ScanStats, route: str | None = None) -> None:
    """Audit the pass via record_action — route counters only, no names/content.

    WAVE1-MEASURE п.4: ``route`` (``knowledge``/``operational``/``all``) и ``seen`` — по ним
    ``core.operational.freshness`` находит «последний полный скан знаниевого корня»:
    без маршрута оперативный и знаниевый проходы в журнале неразличимы.
    """
    try:
        from core.operational.pult import record_action

        record_action(
            "ingest_scan",
            {
                "roots": stats.roots,
                "new": stats.new,
                "unchanged": stats.unchanged,
                "nda": stats.nda_skipped,
                "pending": stats.pending_download,
                "route": route or "all",
                "seen": stats.total_seen,
                "op_registered": stats.operational_registered,
                "kn_roots": stats.knowledge_roots_ingested,
                "dry_run": stats.dry_run,
            },
            outcome="interrupted" if stats.interrupted else "ok",
        )
    except Exception:  # noqa: BLE001, S110 — audit must never break the scan
        pass
