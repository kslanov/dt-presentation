"""INGEST-VIS-1 — файловая трасса инжеста: «файл → заметка → индекс», без нового стейта.

Вопрос К.: «не понимаю, как смотреть, что новый файл в оперативном хранилище был
проиндексирован и как лёг в vault». Агрегаты на пульте («Источники», счётчики,
last_ingest) отвечают «сколько», но не «а мой файл X?». При этом вся фактура для
файл-уровневой трассы уже детерминированно лежит на диске:

* ``current_ingest_manifest.json`` / ``legacy_ingest_manifest.json`` —
  ``source_path → {note_path, content_hash, mtime, size}`` (что стало заметкой);
* ``index_manifest.json`` — ``note_id → {path, mtime, indexed_at, chunk_ids}``
  (что попало в индекс и когда).

Джойн трёх манифестов по ``note_path`` даёт полную трассу. Поэтому здесь **нет
никакого нового журнала**: только чтение уже существующих манифестов (read-only, без
сети, без обхода деревьев файлов). Обращения к ФС — только по **отфильтрованным**
строкам: один ``stat`` заметки и чтение её «головы» (первые ~4 КБ — frontmatter).
Замер на живых данных: 12,8k записей индекс-манифеста читаются за ~50 мс, 6,8k
``stat`` — за ~50 мс, то есть весь джойн — десятки миллисекунд.

TRACE-FIX-1 — три РАЗНЫЕ даты, и путать их нельзя (кейс К.: «Семинар PI — точно не
инжест 7 авг, я только линковал»):

* ``ingested_at`` — когда инжест **записал заметку**: время создания файла на диске
  (``st_birthtime``). Линковка перезаписывает «## Связано» и двигает mtime, а birthtime
  не трогает — именно поэтому раньше поле «инжест» омолаживалось после каждого разбора
  связей. Нет birthtime (не-APFS/чужая ФС) → откат на mtime, и тогда строка честно
  подписана «изменена» (``ingested_from`` говорит, что показывать);
* ``modified_at`` — mtime заметки. Полезен сам по себе («заметку тронули позже
  индекса» считается по нему), просто он НЕ инжест;
* ``doc_date`` — ``created:`` из frontmatter. Вопреки первому впечатлению это **дата
  исходного документа**, а не инжеста: легаси-рендер пишет туда mtime файла-источника
  (``core/legacy/render.py`` → ``_created_date(lf.mtime)``), поэтому у записки 2023
  года там 2023-01-09, хотя в vault она легла в 2026-м. Показываем отдельно и под
  своим именем.

Статусы строки (:data:`STATUSES`) — честные, каждый выводится из факта, а не из
предположения:

* ``indexed`` — заметка в индекс-манифесте и не менялась после индексации;
* ``waiting_index`` — заметки в индексе нет либо она новее записи индекса (ждёт
  ближайшего reindex);
* ``nda`` — путь под NDA-барьером (:func:`core.privacy.is_nda`, маркеры из
  ``DT_NDA_MARKERS``): такая заметка **никогда** не попадёт в индекс by design, и
  «ждёт индекс» про неё было бы неправдой — виджет нагонял бы тревогу вечно;
* ``note_missing`` — манифест помнит заметку, а на диске её нет (удалили руками);
* ``duplicate`` — несколько источников свёрнуты в одну заметку (легаси-дедуп по
  содержимому): показываем как дубликат, а не как отдельный инжест.

Чего здесь принципиально НЕТ (и почему): ``pending_download``/dataless по файлам,
которые ещё не заинжещены, — этого состояния никто не персистит (``ScanStats`` живёт
один прогон), а узнать его можно только обходом корней, что для read-only трассы
дороже пользы. Поэтому пустой результат поиска возвращает ``hint`` с возможными
причинами вместо выдуманного статуса.

Инварианты: ``core/file_ingest`` ⊥ MCP/CLI; чистая функция от манифестов (плюс ``stat``);
ни сети, ни LLM.
"""

from __future__ import annotations

import json
import re
import unicodedata
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import (
    current_ingest_manifest_path,
    default_vault_path,
    index_manifest_path,
    legacy_ingest_manifest_path,
)
from core.privacy import is_nda

__all__ = [
    "TraceRow",
    "ingest_trace",
    "DEFAULT_LIMIT",
    "MAX_LIMIT",
    "STATUSES",
    "CORPUS_CURRENT",
    "CORPUS_LEGACY",
]

DEFAULT_LIMIT = 20
# Потолок выдачи: трасса — «посмотреть последние/найти свой файл», а не выгрузка.
MAX_LIMIT = 200

CORPUS_CURRENT = "current"
CORPUS_LEGACY = "legacy"

STATUS_INDEXED = "indexed"
STATUS_WAITING = "waiting_index"
STATUS_NDA = "nda"
STATUS_NOTE_MISSING = "note_missing"
STATUS_DUPLICATE = "duplicate"
STATUSES = (
    STATUS_INDEXED,
    STATUS_WAITING,
    STATUS_NDA,
    STATUS_NOTE_MISSING,
    STATUS_DUPLICATE,
)

# Запас на «заметку записали, индекс её взял в тот же миг»: mtime и indexed_at пишут
# разные проходы, и секундные округления не должны выглядеть как «заметка новее».
_INDEX_LAG_TOLERANCE_S = 2.0


@dataclass(frozen=True)
class TraceRow:
    """Одна строка трассы: файл-источник → заметка → индекс."""

    source_path: str
    root: str
    corpus: str
    note_path: str | None
    ingested_at: str | None
    # Откуда взят ``ingested_at``: ``birthtime`` (файл создан = инжест записал) или
    # ``mtime`` (birthtime недоступен — UI обязан подписать строку «изменена»).
    ingested_from: str
    modified_at: str | None
    doc_date: str | None  # ``created:`` из frontmatter = дата исходного документа
    indexed: bool
    index_age: float | None  # часов с момента индексации (None — не в индексе)
    status: str
    chunks: int = 0
    size: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "source_path": self.source_path,
            "root": self.root,
            "corpus": self.corpus,
            "note_path": self.note_path,
            "ingested_at": self.ingested_at,
            "ingested_from": self.ingested_from,
            "modified_at": self.modified_at,
            "doc_date": self.doc_date,
            "indexed": self.indexed,
            "index_age": self.index_age,
            "status": self.status,
            "chunks": self.chunks,
            "size": self.size,
        }


def _nfc(text: str) -> str:
    return unicodedata.normalize("NFC", str(text or ""))


def _load_json(path: Path) -> dict[str, Any]:
    """Манифест как dict; нет файла / битый / чужая форма → ``{}`` (трасса просто пуста)."""
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _knowledge_root_name(vault_path: Path | None) -> str:
    """Имя ingest-корня для ``current``-строк (в манифесте оно не хранится).

    Ключи ``current_ingest_manifest`` — пути относительно знаниевого корня, а имя
    корня рядом не лежит. При единственном знаниевом корне (штатная конфигурация)
    имя однозначно; при нескольких честнее показать корпус, чем угадывать.
    """
    try:
        from core.file_ingest.config import CORPUS_CURRENT as _CUR
        from core.file_ingest.config import load_ingest_roots

        names = [r.name for r in load_ingest_roots(vault_path) if r.corpus == _CUR]
    except Exception:  # noqa: BLE001 — конфиг не должен ронять read-only трассу
        return CORPUS_CURRENT
    return names[0] if len(names) == 1 else CORPUS_CURRENT


def _index_by_note_path(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """``index_manifest`` → ``{vault-относительный путь заметки: запись}``."""
    out: dict[str, dict[str, Any]] = {}
    for rec in manifest.values():
        if not isinstance(rec, dict):
            continue
        path = rec.get("path")
        if isinstance(path, str) and path:
            out[_nfc(path)] = rec
    return out


def _chunk_count(rec: dict[str, Any]) -> int:
    """Число чанков заметки в индексе (в манифесте два исторических поля)."""
    ids = rec.get("chunk_ids")
    if isinstance(ids, list):
        return len(ids)
    chunks = rec.get("chunks")
    if isinstance(chunks, int):
        return chunks
    if isinstance(chunks, list):
        return len(chunks)
    return 0


def _iso(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=UTC).isoformat().replace("+00:00", "Z")


# Сколько байт «головы» заметки читать ради frontmatter: он идёт первым и у наших
# заметок укладывается в сотни байт (запас ×10, чтение обрывается на закрывающем ---).
_HEAD_BYTES = 4096

# Начало/конец frontmatter + строка даты документа.
_FM_FENCE = "---"
_CREATED_RE = re.compile(r"^created\s*:\s*(.+?)\s*$", re.MULTILINE)

# Допуск при сверке birthtime с mtime: birthtime ПОЗЖЕ mtime — признак того, что ФС
# отдала мусор (или файл скопировали поверх), такому значению не верим.
_BIRTH_SANITY_S = 2.0


def _note_times(path: Path) -> tuple[float | None, float | None]:
    """``(birthtime, mtime)`` заметки одним ``stat``; недоступное → ``None``.

    ``st_birthtime`` есть на APFS/HFS+ (macOS) и BSD; на других ФС атрибут может
    отсутствовать или быть нулевым — тогда вызывающий честно откатывается на mtime.
    """
    try:
        st = path.stat()
    except OSError:
        return None, None
    mtime = float(st.st_mtime)
    birth = getattr(st, "st_birthtime", None)
    try:
        birth = float(birth) if birth else None
    except (TypeError, ValueError):
        birth = None
    if birth is not None and (birth <= 0 or birth > mtime + _BIRTH_SANITY_S):
        birth = None  # ФС отдала бессмыслицу — лучше честный mtime, чем ложный «инжест»
    return birth, mtime


def _doc_date_from_head(path: Path) -> str | None:
    """``created:`` из frontmatter — читая только «голову» файла (~4 КБ).

    Это дата ИСХОДНОГО документа (легаси-рендер пишет туда mtime источника), поэтому
    поле называется ``doc_date``, а не «инжест». Читаем ≤20 строк выдачи, так что
    стоимость того же порядка, что существующий ``stat``.
    """
    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            head = fh.read(_HEAD_BYTES)
    except OSError:
        return None
    if not head.startswith(_FM_FENCE):
        return None
    end = head.find("\n" + _FM_FENCE, len(_FM_FENCE))
    block = head[:end] if end != -1 else head
    match = _CREATED_RE.search(block)
    if not match:
        return None
    raw = match.group(1).strip().strip("'\"")
    parsed = _parse_iso(raw)
    return _iso(parsed.timestamp()) if parsed is not None else None


def _parse_iso(value: Any) -> datetime | None:
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt


def _matches(query: str, *fields: str | None) -> bool:
    """Подстрока по любому из полей: регистронезависимо, NFC (кириллица как есть)."""
    needle = _nfc(query).strip().casefold()
    if not needle:
        return True
    return any(needle in _nfc(f).casefold() for f in fields if f)


def ingest_trace(
    query: str | None = None,
    root: str | None = None,
    limit: int = DEFAULT_LIMIT,
    offset: int = 0,
    *,
    vault_path: Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Трасса инжеста: последние файлы «источник → заметка → индекс» (read-only).

    ``query`` — подстрока по пути источника ИЛИ по пути заметки (регистронезависимо,
    кириллица), отвечает на «а мой файл X попал в vault и индекс?». ``root`` — фильтр
    по корню/корпусу (подстрока). ``limit`` — размер порции (потолок :data:`MAX_LIMIT`),
    ``offset`` — сколько строк пропустить: пульт листает «показать ещё» по этой паре
    (PULT-FILES-1; 6,8k строк одним куском — простыня, а не виджет).

    Сортировка — по ``ingested_at`` (новые сверху) **и по ``source_path`` при равных
    датах**: волна инжеста пишет заметки в одну секунду, и без второго ключа порядок
    между вызовами мог бы разъезжаться — при листании это давало бы дубли и пропуски.

    Возврат ``{ok, query, root, limit, offset, total, shown, has_more, rows, counts,
    index_as_of, hint}``: ``total`` — сколько записей подошло под фильтр (обычно больше
    ``shown``), ``has_more`` — есть ли что листать дальше, ``counts`` — разбивка по
    статусам среди подошедших (по всем, не по порции), ``hint`` — человекочитаемая
    подсказка, когда искомого не нашлось. Никогда не бросает: битые/отсутствующие
    манифесты дают пустую трассу.
    """
    now = now or datetime.now(UTC)
    vault = vault_path or default_vault_path()
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        limit = DEFAULT_LIMIT
    limit = max(1, min(limit, MAX_LIMIT))
    try:
        offset = max(0, int(offset))
    except (TypeError, ValueError):
        offset = 0

    current = _load_json(current_ingest_manifest_path())
    legacy = _load_json(legacy_ingest_manifest_path())
    index = _index_by_note_path(_load_json(index_manifest_path()))
    current_root = _knowledge_root_name(vault_path)

    # Дубли: одна заметка на несколько источников (легаси-дедуп по содержимому).
    note_users: dict[str, int] = {}
    for manifest in (current, legacy):
        for rec in manifest.values():
            if isinstance(rec, dict) and rec.get("note_path"):
                key = _nfc(rec["note_path"])
                note_users[key] = note_users.get(key, 0) + 1

    # 1. фильтр ДО обращений к ФС (по манифестам) — в типичном поиске остаются единицы
    candidates: list[tuple[str, str, str, dict[str, Any]]] = []
    for manifest, corpus, root_name in (
        (current, CORPUS_CURRENT, current_root),
        (legacy, CORPUS_LEGACY, CORPUS_LEGACY),
    ):
        for source_path, rec in manifest.items():
            if not isinstance(rec, dict):
                continue
            note_path = rec.get("note_path") or None
            if query and not _matches(query, source_path, note_path):
                continue
            if root and not _matches(root, root_name, corpus):
                continue
            candidates.append((str(source_path), corpus, root_name, rec))

    # 2. заметки отфильтрованных — один stat + «голова» файла на строку (TRACE-FIX-1):
    #    birthtime = когда инжест записал заметку, mtime = когда её тронули последний
    #    раз (линковка!), frontmatter created = дата исходного документа. Три даты,
    #    три поля — раньше все три подменял один mtime под подписью «инжест».
    rows: list[tuple[float, TraceRow]] = []
    for source_path, corpus, root_name, rec in candidates:
        note_path = rec.get("note_path") or None
        note_birth: float | None = None
        note_mtime: float | None = None
        if note_path:
            note_birth, note_mtime = _note_times(vault / note_path)

        idx_rec = index.get(_nfc(note_path)) if note_path else None
        indexed_at = _parse_iso((idx_rec or {}).get("indexed_at"))
        idx_mtime = (idx_rec or {}).get("mtime")
        fresh_in_index = bool(idx_rec) and (
            not isinstance(idx_mtime, (int, float))
            or note_mtime is None
            or note_mtime <= float(idx_mtime) + _INDEX_LAG_TOLERANCE_S
        )

        if (note_path and is_nda(note_path)) or is_nda(source_path):
            status = STATUS_NDA  # в индекс не попадёт by design — «ждёт» было бы ложью
        elif note_path and note_users.get(_nfc(note_path), 0) > 1:
            status = STATUS_DUPLICATE
        elif note_path and note_mtime is None:
            status = STATUS_NOTE_MISSING
        elif fresh_in_index:
            status = STATUS_INDEXED
        else:
            status = STATUS_WAITING

        # Сортировка и подпись «инжест» — по birthtime; нет его → mtime, и тогда
        # ``ingested_from="mtime"`` велит UI подписать строку «изменена».
        if note_birth is not None:
            sort_ts, ingested_from = note_birth, "birthtime"
        elif note_mtime is not None:
            sort_ts, ingested_from = note_mtime, "mtime"
        else:
            sort_ts, ingested_from = _float(rec.get("mtime")), "mtime"
        rows.append((
            sort_ts,
            TraceRow(
                source_path=source_path,
                root=root_name,
                corpus=corpus,
                note_path=note_path,
                ingested_at=_iso(sort_ts) if sort_ts else None,
                ingested_from=ingested_from,
                modified_at=_iso(note_mtime) if note_mtime else None,
                doc_date=None,  # заполняется ниже — только у строк выдачи
                indexed=status == STATUS_INDEXED,
                index_age=(
                    round(max(0.0, (now - indexed_at).total_seconds()) / 3600, 2)
                    if indexed_at is not None
                    else None
                ),
                status=status,
                chunks=_chunk_count(idx_rec or {}),
                size=int(_float(rec.get("size"))),
            ),
        ))

    # Полный порядок: свежие сверху, ничьи разводим путём источника — иначе листание
    # по offset могло бы повторить или потерять строку между вызовами.
    rows.sort(key=lambda pair: (-pair[0], pair[1].source_path))
    page = rows[offset:offset + limit]
    # Дата исходного документа — чтением «головы» файла, и ТОЛЬКО у строк порции
    # (≤ limit): для 6,8k кандидатов это стоило бы 1,5 с на каждый запрос вместо 50 мс.
    shown = [
        replace(row, doc_date=_doc_date_from_head(vault / row.note_path))
        if row.note_path
        else row
        for _, row in page
    ]
    counts: dict[str, int] = {}
    for _, row in rows:
        counts[row.status] = counts.get(row.status, 0) + 1

    index_as_of = None
    ages = [r.index_age for _, r in rows if r.index_age is not None]
    if ages:
        index_as_of = round(min(ages), 2)  # самая свежая индексация среди подошедших

    return {
        "ok": True,
        "query": query or None,
        "root": root or None,
        "limit": limit,
        "offset": offset,
        "total": len(rows),
        "shown": len(shown),
        "has_more": offset + len(shown) < len(rows),
        "rows": [row.to_dict() for row in shown],
        "counts": counts,
        "index_as_of": index_as_of,
        "hint": _hint(query, len(rows), current, legacy),
    }


def _float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _hint(
    query: str | None, total: int, current: dict[str, Any], legacy: dict[str, Any]
) -> str:
    """Человекочитаемая подсказка, когда искомого нет (пустой результат тоже ответ)."""
    if total:
        return ""
    if not current and not legacy:
        return (
            "манифесты инжеста пусты — ingest ещё не запускался "
            "(dt_ingest --apply / плановый скан)"
        )
    if query and is_nda(query):
        return "путь под NDA-барьером — такие файлы в vault и индекс не попадают by design"
    if query:
        return (
            f"файла по «{query}» в манифестах инжеста нет: либо скан его ещё не видел "
            "(файл новый / iCloud не докачал), либо он отфильтрован include/exclude "
            "корня, либо это дубль уже заинжещенного содержимого"
        )
    return "под фильтр ничего не подошло"
