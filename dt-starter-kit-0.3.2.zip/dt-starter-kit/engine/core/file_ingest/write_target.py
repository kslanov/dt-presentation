"""Гарды привилегированной записи под ingest-корень — общий слой (FT-12).

До FT-12 гарды жили внутри :mod:`core.operational.store_file` (единственный канал
записи файла из чата). Появились два новых адресата тех же правил — ``place_download``
(перенос скачанного файла, ФТ-1) и реестр алиасов папок (``folder_alias_set``, ФТ-2),
и правила обязаны быть **одни и те же** (ТЗ: «гарды store_file, поведение
идентичное»), а не три похожие копии. Модуль — этот общий слой; ``store_file``
переписан на него, поведение и тексты отказов сохранены байт-в-байт.

Что здесь:

* :func:`resolve_write_target` — шаги «корень → NDA → containment» одной функцией:
  ``root_name`` обязан быть в ``_system/ingest-roots.yaml`` и существовать на диске;
  ``rel_path`` — непустой относительный; ``resolve()`` итога обязан лежать под
  корнем (``../``/абсолютный/симлинк-эскейп → отказ); ``_nda`` — отказ до и после
  resolve (:func:`core.privacy.is_nda`);
* :func:`resolve_dest_target` — тот же резолв, но для чатового адреса ``dest``
  (алиас папки ФТ-2 либо root-относительный путь) + имя файла: одна семантика
  адресации у ``place_download`` (ФТ-1) и ``save_output(dest=…)`` (ФТ-4);
* :func:`sha256_file` — потоковый хэш файла на диске (50 МБ без чтения в память);
* :func:`existing_disposition` — «нет / байт-идентичный / отличающийся» для
  идемпотентности и безопасности перезаписи;
* :func:`write_atomic` — запись готовых байтов под корень с той же семантикой
  идемпотентности/перезаписи (tmp+fsync+``replace``, сверка sha после записи);
* :func:`write_atomic_stream` — то же, но источник — файл на диске (порционная сборка
  ФТ-5 отдаёт готовый ``.part``, читать его в память незачем).

Дом — ``core/file_ingest`` (нижний слой: ingest-корни описаны здесь), поэтому
``core.operational.*`` может импортировать его без цикла. Слой чист: ни MCP, ни CLI,
ни сети, ни LLM.

``store_file`` пользуется гардами отсюда, но собственную запись сохраняет: у него
свои шаги (заявленный клиентом sha256 сверяется ДО записи) и точка инъекции
повреждения для теста — его контракт зафиксирован снапшотом и не переписывается ради
общности.
"""

from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.privacy import is_nda

__all__ = [
    "WriteTargetError",
    "WriteTarget",
    "resolve_write_target",
    "resolve_dest_target",
    "sha256_file",
    "existing_disposition",
    "write_atomic",
    "write_atomic_stream",
    "ABSENT",
    "IDENTICAL",
    "DIFFERS",
    "DEFAULT_ROOT_NAME",
]

# Ingest-корень по умолчанию для чатовых инструментов доставки файла (ФТ-1
# ``place_download(root_name="current")``, короткая форма записи реестра алиасов).
# Один литерал на все точки, чтобы дефолт не расползся по модулям.
DEFAULT_ROOT_NAME = "current"

# Диспозиция существующего целевого файла (:func:`existing_disposition`).
ABSENT = "absent"
IDENTICAL = "identical"
DIFFERS = "differs"

# Размер блока потокового хэширования/копирования (файл не читаем в память целиком).
_HASH_CHUNK = 1024 * 1024

# Суффикс временного файла рядом с целью (``replace`` атомарен только внутри одной ФС).
_WRITE_TMP_SUFFIX = ".dt-write.tmp"


class WriteTargetError(RuntimeError):
    """Отказ гарда записи. ``code`` — машиночитаемая причина (NFR «диагностируемость»)."""

    def __init__(self, message: str, code: str = "refused") -> None:
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class WriteTarget:
    """Проверенный адрес записи: корень, абсолютный путь и путь относительно корня."""

    root_name: str
    root_dir: Path
    path: Path
    rel_path: str


def _within(target: Path, root: Path) -> bool:
    """True, если ``target`` (уже resolve-нутый) лежит под ``root`` (resolve-нутым)."""
    try:
        target.relative_to(root)
    except ValueError:
        return False
    return True


def resolve_write_target(
    root_name: str,
    rel_path: str,
    *,
    vault_path: Path | None = None,
    allow_root: bool = False,
) -> WriteTarget:
    """Проверить адрес записи гардами корня/NDA/containment и вернуть :class:`WriteTarget`.

    ``allow_root=True`` разрешает пустой ``rel_path`` (или ``"."``) — адрес самого
    корня; нужен реестру алиасов (алиас может указывать на корень целиком), запись
    файла всегда идёт по непустому пути. Любой отказ — :class:`WriteTargetError`
    с ``code``: ``unknown_root`` / ``root_missing`` / ``nda`` / ``bad_rel_path`` /
    ``containment``.
    """
    from core.file_ingest.config import load_ingest_roots

    # --- 1. корень из ingest-roots.yaml (operational/knowledge) --------------
    roots = {r.name: r for r in load_ingest_roots(vault_path)}
    root = roots.get(root_name)
    if root is None:
        raise WriteTargetError(
            f"неизвестный ingest-корень: {root_name!r} "
            f"(доступны: {', '.join(sorted(roots)) or '—'})",
            "unknown_root",
        )
    root_dir = Path(root.path).resolve()
    if not root_dir.is_dir():
        raise WriteTargetError(
            f"корень {root_name!r} не существует на диске: {root_dir}", "root_missing"
        )

    # --- 2. NDA + относительность пути (до любых обращений к ФС по target) ----
    if is_nda(rel_path):
        raise WriteTargetError("NDA-путь — запись запрещена", "nda")
    raw = str(rel_path or "").strip()
    if allow_root and raw.strip("/") in {"", "."}:
        return WriteTarget(root_name=root_name, root_dir=root_dir, path=root_dir, rel_path="")
    rp = Path(raw)
    if rp.is_absolute() or not raw:
        raise WriteTargetError(
            "rel_path должен быть непустым относительным путём", "bad_rel_path"
        )

    # --- 3. containment по resolve (../, симлинк-эскейп — отказ) --------------
    target = (root_dir / rp).resolve()
    if not _within(target, root_dir):
        raise WriteTargetError(
            f"путь вне ingest-корня {root_name!r}: {rel_path}", "containment"
        )
    # NDA ещё раз по итоговому пути (перестраховка: symlink/сегменты корня).
    if is_nda(target):
        raise WriteTargetError("NDA-путь — запись запрещена", "nda")
    return WriteTarget(
        root_name=root_name,
        root_dir=root_dir,
        path=target,
        rel_path=target.relative_to(root_dir).as_posix(),
    )


def resolve_dest_target(
    dest: str,
    filename: str,
    *,
    root_name: str = DEFAULT_ROOT_NAME,
    vault_path: Path | None = None,
) -> tuple[WriteTarget, str | None]:
    """Чатовый адрес ``dest`` + имя файла → проверенная цель записи (FT-12/FT-4).

    ``dest`` — либо алиас папки (реестр ФТ-2), либо путь относительно ingest-корня
    ``root_name``. Алиас — **полный** адрес (несёт свой корень), поэтому найденный в
    реестре он приоритетнее переданного ``root_name``. Хвостовой ``/`` — косметика
    («ЦОД/»), ведущий НЕ снимаем: абсолютный ``dest`` обязан получить отказ гарда,
    а не молча стать относительным. Гарды и тексты отказов — :func:`resolve_write_target`.

    Возвращает ``(WriteTarget, имя алиаса | None)``. Одна семантика адресации для
    ``place_download`` (ФТ-1) и ``save_output(dest=…)`` (ФТ-4) — не две похожие копии.
    """
    from core.file_ingest.aliases import resolve_alias

    alias = resolve_alias(dest, vault_path)
    if alias is not None:
        base, root = alias.rel_path, alias.root_name
    else:
        base, root = str(dest or "").strip().rstrip("/"), root_name
    rel = f"{base}/{filename}" if base else filename
    target = resolve_write_target(root, rel, vault_path=vault_path)
    return target, (alias.name if alias else None)


def sha256_file(path: Path) -> str:
    """sha256 файла на диске потоково (без чтения целиком в память)."""
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(_HASH_CHUNK), b""):
            digest.update(block)
    return digest.hexdigest()


def existing_disposition(target: Path, sha256_hex: str, *, label: str | None = None) -> str:
    """:data:`ABSENT` / :data:`IDENTICAL` / :data:`DIFFERS` для целевого пути.

    ``IDENTICAL`` → вызывающий возвращает идемпотентный ``existed`` и НЕ переписывает
    файл (mtime цел); ``DIFFERS`` → нужен явный ``overwrite``. Путь, занятый
    не-файлом, — отказ (``code="target_not_file"``).
    """
    if not target.exists():
        return ABSENT
    if not target.is_file():
        raise WriteTargetError(
            f"путь занят не-файлом: {label or target}", "target_not_file"
        )
    return IDENTICAL if sha256_file(target) == sha256_hex else DIFFERS


def _overwrite_gate(target: WriteTarget, sha: str, overwrite: bool) -> tuple[str, bool]:
    """Диспозиция цели + проверка права на перезапись (общая для обоих писателей)."""
    disposition = existing_disposition(target.path, sha, label=target.rel_path)
    if disposition == IDENTICAL:
        return IDENTICAL, False
    overwritten = disposition != ABSENT
    if overwritten and not overwrite:
        raise WriteTargetError(
            f"файл существует и отличается: {target.rel_path} — нужен overwrite=True",
            "exists_differs",
        )
    return disposition, overwritten


def write_atomic_stream(
    target: WriteTarget,
    src: Path,
    *,
    overwrite: bool = False,
    sha256_hex: str | None = None,
) -> dict[str, Any]:
    """То же, что :func:`write_atomic`, но источник — файл на диске (FT-5).

    Нужно там, где байты уже собраны рядом (порционная запись собирает бинарь в
    ``.derived/``) и читать их целиком в память незачем: копируем блоками в ``.tmp``
    рядом с целью, ``fsync``, сверяем sha256 **до** подмены, затем ``os.replace``.
    ``sha256_hex`` — уже посчитанный хэш источника (не считаем второй раз).
    Источник остаётся на месте — удаляет его вызывающий (это его scratch).
    """
    sha = (sha256_hex or sha256_file(src)).lower()
    disposition, overwritten = _overwrite_gate(target, sha, overwrite)
    size = src.stat().st_size
    if disposition == IDENTICAL:
        return {
            "path": target.rel_path, "abs_path": str(target.path), "size": size,
            "sha256": sha, "existed": True, "overwritten": False,
        }

    target.path.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.path.with_name(target.path.name + _WRITE_TMP_SUFFIX)
    try:
        with src.open("rb") as fsrc, tmp.open("wb") as fdst:
            for block in iter(lambda: fsrc.read(_HASH_CHUNK), b""):
                fdst.write(block)
            fdst.flush()
            os.fsync(fdst.fileno())
        if sha256_file(tmp) != sha:
            tmp.unlink(missing_ok=True)
            raise WriteTargetError(
                "повреждение при копировании (tmp не сошёлся) — файл не записан",
                "verify_failed",
            )
        os.replace(tmp, target.path)
    except OSError as exc:
        tmp.unlink(missing_ok=True)
        raise WriteTargetError(f"ошибка записи: {exc}", "write_failed") from exc
    return {
        "path": target.rel_path, "abs_path": str(target.path), "size": size,
        "sha256": sha, "existed": overwritten, "overwritten": overwritten,
    }


def write_atomic(
    target: WriteTarget, data: bytes, *, overwrite: bool = False
) -> dict[str, Any]:
    """Записать готовые байты в проверенную цель — атомарно и идемпотентно (FT-4).

    Семантика перезаписи — как у ``store_file``/``place_download``: существующий
    **байт-идентичный** файл не переписывается (``existed``, mtime цел);
    **отличающийся** — отказ без ``overwrite=True`` (клиентские файлы молча не
    затираем). Запись через ``.tmp`` рядом с целью + ``fsync`` + ``os.replace``:
    под целевым именем частичный файл не наблюдаем ни в один момент. После подмены
    файл перечитывается с диска и сверяется по sha256 — не сошлось → удалить, ошибка.

    Возврат ``{path, abs_path, size, sha256, existed, overwritten}`` (``path`` —
    относительный корню, posix; ``abs_path`` — он же абсолютным, CONTRACT-1 ФП-7: этой
    формой доставленный файл принимает ``lift_source``, root-относительная резолвится
    лишь эвристикой хвоста). Отказы — :class:`WriteTargetError` с ``code``
    (``exists_differs`` / ``target_not_file`` / ``write_failed`` / ``verify_failed``).
    """
    sha = hashlib.sha256(data).hexdigest()
    disposition, overwritten = _overwrite_gate(target, sha, overwrite)
    if disposition == IDENTICAL:
        return {
            "path": target.rel_path, "abs_path": str(target.path), "size": len(data),
            "sha256": sha, "existed": True, "overwritten": False,
        }

    target.path.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.path.with_name(target.path.name + _WRITE_TMP_SUFFIX)
    try:
        with tmp.open("wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, target.path)
    except OSError as exc:
        tmp.unlink(missing_ok=True)
        raise WriteTargetError(f"ошибка записи: {exc}", "write_failed") from exc
    if sha256_file(target.path) != sha:
        target.path.unlink(missing_ok=True)
        raise WriteTargetError(
            "повреждение при записи (итог не сошёлся) — файл удалён", "verify_failed"
        )
    return {
        "path": target.rel_path, "abs_path": str(target.path), "size": len(data),
        "sha256": sha, "existed": overwritten, "overwritten": overwritten,
    }
