"""Гарды чтения файлов с iCloud (WAVE0-HYGIENE п.3, аудит B3).

Чтение dataless-заглушки iCloud блокируется в ядре до пробуждения fileproviderd (или падает
``EDEADLK``), и поток, который читает, зависает **без возможности прервать**. Ночной
``file_ingest_knowledge`` рвался именно так (6 из 7 ночей), а heartbeat в нём не бился —
сторож не отличал «медленно» от «повис». Два примитива:

* :func:`is_dataless` — признак заглушки БЕЗ чтения (``st_flags`` / нулевые блоки /
  ``.name.icloud``); проверять **до** любого ``open``/хэша/экстракции;
* :func:`guarded_call` — вызов чтения под таймаутом **и** с детектором сна (настенные
  часы ушли вперёд монотонных): зависший вызов — отказ :class:`~core.adapters.AdapterInterrupted`
  (``adapter_interrupted`` по контракту ADAPTER-HONEST-1), а не вечное ожидание. Зависший
  поток остаётся в фоне как daemon — прервать блокирующее чтение в ядре нельзя; число
  таких «висяков» ограничено (:func:`stuck_reads`), чтобы прогон останавливал себя сам.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import contextlib
import os
import subprocess
import threading
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any, TypeVar

from core import runlock
from core.adapters import AdapterInterrupted

__all__ = [
    "SF_DATALESS",
    "guarded_call",
    "ONEDRIVE_HINT",
    "cloud_provider",
    "icloud_hint",
    "not_local_hint",
    "is_dataless",
    "materialize",
    "read_timeout_s",
    "sleep_gap_s",
    "stuck_reads",
]

T = TypeVar("T")

# macOS BSD flag, выставляемый APFS на dataless-файл (вытеснен / не скачан) — авторитетный
# признак (spike INGEST-1 PART-0). Нулевые дисковые блоки подтверждают.
SF_DATALESS = 0x40000000

DEFAULT_READ_TIMEOUT_S = 300.0
DEFAULT_SLEEP_GAP_S = 30.0
_POLL_S = 1.0

_stuck_lock = threading.Lock()
_stuck: list[threading.Thread] = []


def is_dataless(path: Path) -> bool:
    """True, если ``path`` — заглушка iCloud (не скачан). Без чтения файла.

    Основной сигнал ``st_flags & SF_DATALESS``; подтверждение — нулевые блоки при
    положительном размере; запасной — соседний ``.<name>.icloud``. Определять нужно ДО
    хэширования: чтение заглушки блокируется, пока iCloud качает (4 с на 51 КБ, без
    предела — офлайн).
    """
    try:
        st = Path(path).lstat()
    except OSError:
        return False
    flags = getattr(st, "st_flags", 0)
    if flags & SF_DATALESS:
        return True
    if st.st_size > 0 and st.st_blocks == 0:
        return True
    p = Path(path)
    return p.with_name("." + p.name + ".icloud").exists()


ONEDRIVE_HINT = ("OneDrive: Files On-Demand - включите «Всегда хранить на этом устройстве» "
                 "для папки vault")


def cloud_provider(path: str | Path) -> str:
    """Провайдер облачной папки по пути: ``onedrive`` (``…/Library/CloudStorage/OneDrive…``) либо
    ``icloud`` (все прочее: прежнее поведение SRC-ICLOUD-1)."""
    parts = [p.casefold() for p in Path(path).parts]
    if "cloudstorage" in parts and any(p.startswith("onedrive") for p in parts):
        return "onedrive"
    return "icloud"


def materialize(path: Path, *, timeout_s: float) -> bool:
    """Запросить ``brctl download`` и ждать материализации до ``timeout_s``.

    PERSONAL-2: для OneDrive ``brctl`` не годится - попытки скачать нет, ответ сразу по флагу
    (``not is_dataless``); файл остается ``not_local`` с подсказкой :data:`ONEDRIVE_HINT`.

    True - у файла появились байты (флаг dataless снят); False - не успел (вызывающий помечает
    «не локален»). Best-effort: нет/упал ``brctl`` - просто ждем до таймаута. Единая точка для
    ingest (``pending_download``), подъемов источников (``source_not_local``) и place_download.
    """
    if cloud_provider(path) == "onedrive":
        return not is_dataless(path)
    try:
        subprocess.run(  # noqa: S603 — args code-built, no shell; inputs are our own paths
            ["brctl", "download", str(path)],  # noqa: S607 — brctl (iCloud) resolved from PATH by design (system tool)
            capture_output=True,
            timeout=max(5.0, timeout_s),
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        pass
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if not is_dataless(path):
            return True
        time.sleep(0.5)
    return not is_dataless(path)


def icloud_hint(path: str | Path) -> str:
    """Подсказка владельцу для конверта ``source_not_local`` (SRC-ICLOUD-1)."""
    return ("файл в iCloud не скачан - открыть в Finder или `brctl download "
            f"{path}`; демон (launchd) iCloud не материализует")


def not_local_hint(path: str | Path) -> str:
    """Подсказка для ``source_not_local`` по провайдеру пути (OneDrive - Files On-Demand, иначе
    iCloud)."""
    return ONEDRIVE_HINT if cloud_provider(path) == "onedrive" else icloud_hint(path)


def _env_float(name: str, default: float) -> float:
    try:
        value = float((os.environ.get(name) or "").strip())
    except ValueError:
        return default
    return value if value > 0 else default


def read_timeout_s() -> float:
    """Таймаут одного чтения/экстракции файла, с (``DT_INGEST_READ_TIMEOUT_S``, 300)."""
    return _env_float("DT_INGEST_READ_TIMEOUT_S", DEFAULT_READ_TIMEOUT_S)


def sleep_gap_s() -> float:
    """Расхождение настенных/монотонных часов, считающееся сном (``DT_INGEST_SLEEP_GAP_S``, 30)."""
    return _env_float("DT_INGEST_SLEEP_GAP_S", DEFAULT_SLEEP_GAP_S)


def stuck_reads() -> int:
    """Сколько прерванных чтений ещё висят в фоновых потоках (живые daemon-потоки)."""
    with _stuck_lock:
        _stuck[:] = [t for t in _stuck if t.is_alive()]
        return len(_stuck)


def guarded_call(
    fn: Callable[..., T],
    *args: Any,
    timeout_s: float | None = None,
    what: str = "чтение файла",
    **kwargs: Any,
) -> T:
    """``fn(*args, **kwargs)`` под таймаутом и детектором сна; зависание → отказ.

    Вызов идёт в daemon-потоке, главный поток ждёт шагами по секунде и **бьёт heartbeat**
    (:func:`core.runlock.beat`) — пока мы живо ждём, сторож не снимает прогон. Исключение
    из ``fn`` пробрасывается как есть (``OSError``/``EDEADLK`` и т.п. — обычные отказы
    чтения). Таймаут или сон (настенные часы обогнали монотонные больше чем на
    :func:`sleep_gap_s`) → :class:`AdapterInterrupted`: после пробуждения незавершённое
    чтение — отказ, а не «подождём ещё» (инцидент 2026-10-13).
    """
    limit = read_timeout_s() if timeout_s is None else timeout_s
    box: dict[str, Any] = {}
    done = threading.Event()

    def _worker() -> None:
        try:
            box["value"] = fn(*args, **kwargs)
        except BaseException as exc:  # noqa: BLE001 — пробрасываем в вызывающий поток
            box["error"] = exc
        finally:
            done.set()

    thread = threading.Thread(target=_worker, name=f"guarded:{what}", daemon=True)
    started_mono, started_wall = time.monotonic(), time.time()
    thread.start()
    while not done.wait(_POLL_S):
        runlock.beat()
        mono = time.monotonic() - started_mono
        wall = time.time() - started_wall
        if wall - mono > sleep_gap_s():
            _park(thread)
            raise AdapterInterrupted(
                f"{what}: машина спала посреди вызова (~{wall:.0f}с); "
                "незавершённое после пробуждения чтение — отказ, не ожидание",
                adapter="file_read", what=what,
            )
        if mono >= limit:
            _park(thread)
            raise AdapterInterrupted(
                f"{what}: нет ответа за {limit:.0f}с (iCloud/диск завис) — пропущено, "
                "следующий проход повторит",
                adapter="file_read", what=what,
            )
    if "error" in box:
        raise box["error"]
    return box["value"]  # type: ignore[no-any-return]


def _park(thread: threading.Thread) -> None:
    with _stuck_lock:
        _stuck.append(thread)
    with contextlib.suppress(Exception):
        runlock.beat()
