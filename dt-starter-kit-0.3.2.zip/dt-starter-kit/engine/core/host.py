"""VENDOR-HYGIENE-1 п.1 — кто сейчас вызывает движок: хост процесса.

Движок знает хост, но не обязан знать модель (``docs/design-model-1-vendor-independence.md``,
принцип 1): хост сообщает себя в handshake MCP (``clientInfo`` ``{name, version}``), модель — только
если клиент ее объявит. Здесь — один модульный кэш на процесс: stdio-сервер обслуживает одного
клиента, поэтому «хост процесса» однозначен.

Три поверхности:

* ``mcp`` — имя/версия приходят от клиента после ``initialize`` (до него — ``unknown``);
* ``webpult`` — веб-пульт в своем процессе (ставит ``webpult/server.py``);
* ``cli`` — всё остальное (CLI, launchd, тесты): значение по умолчанию.

В коде нет ни одного вендорного имени: имя хоста — строка, которую прислал сам хост.
``core`` не зависит от MCP SDK — снятие ``clientInfo`` с контекста запроса делает граница MCP
(``mcp-server/server.py``) и передает сюда готовые строки через :func:`adopt_client_info`.
"""

from __future__ import annotations

import contextvars
import re
import threading
from typing import Any

__all__ = [
    "ANONYMOUS_NAMES",
    "bind_session_host",
    "SURFACE_CLI",
    "SURFACE_MCP",
    "SURFACE_WEBPULT",
    "UNKNOWN_HOST",
    "adopt_client_info",
    "begin_mcp_host",
    "current_host",
    "host_label",
    "is_anonymous",
    "needs_handshake",
    "request_fields",
    "reset_host",
    "run_mode",
    "set_host",
    "set_request",
    "clear_request",
    "unbind_session_host",
]

SURFACE_MCP = "mcp"
SURFACE_WEBPULT = "webpult"
SURFACE_CLI = "cli"
UNKNOWN_HOST = "unknown"
# KIMI-INSTALL-2: имя по умолчанию клиента MCP SDK (``clientInfo.name`` без явного имени). Хост с
# таким именем - «анонимный»: клиент не назвал себя (часто это собственный клиент модели, поднявший
# наш сервер сам, а не штатная регистрация MCP у хоста), в реестр ``host-access`` его не вписывают.
ANONYMOUS_NAMES = frozenset({"mcp"})

# Имя/версия/модель идут в метаданные выходов и в журнал метрик — только короткий «машинный»
# вид (как у кодов деградации): недоверенная строка клиента не должна тащить в vault пути,
# переводы строк или целые тексты.
_SAFE_RE = re.compile(r"[^A-Za-z0-9._+\-/ ]+")
_NAME_MAX = 60
_VERSION_MAX = 40
_MODEL_MAX = 80

_lock = threading.Lock()
_state: dict[str, Any] = {"name": SURFACE_CLI, "version": "", "surface": SURFACE_CLI, "model": ""}


def _clean(value: Any, limit: int) -> str:
    text = _SAFE_RE.sub("", " ".join(str(value or "").split())).strip()
    return text[:limit]


def is_anonymous(name: Any) -> bool:
    """Имя хоста не говорит, кто это: пустое либо имя по умолчанию SDK (:data:`ANONYMOUS_NAMES`).
    ``unknown`` (до handshake / события без хоста) - не аноним, а «неизвестно»."""
    text = " ".join(str(name or "").split()).casefold()
    return not text or text in ANONYMOUS_NAMES


def current_host() -> dict[str, Any]:
    """``{name, version, surface}`` (+ ``model``, если хост сам объявил модель в handshake; +
    ``anonymous: True``, если MCP-клиент назвался именем SDK по умолчанию - KIMI-INSTALL-2)."""
    bound = _session_host.get()  # DAEMON-1-SPIKE: хост сессии (запроса) приоритетнее хоста процесса
    if bound is not None:
        return _as_view(bound)
    with _lock:
        return _as_view(_state)


def _as_view(src: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {k: src[k] for k in ("name", "version", "surface")}
    if src["model"]:
        out["model"] = src["model"]
    if src["surface"] == SURFACE_MCP and src["name"] != UNKNOWN_HOST and is_anonymous(src["name"]):
        out["anonymous"] = True
    return out


def host_label(host: dict[str, Any] | None = None) -> str:
    """``имя/версия`` (или просто имя) — для строк ``sources.md`` и подписей."""
    h = host or current_host()
    name = h.get("name") or UNKNOWN_HOST
    return f"{name}/{h['version']}" if h.get("version") else name


def run_mode() -> str:
    """Режим прогона для истории eval: ``in_process`` или ``mcp:<хост>``."""
    h = current_host()
    return f"mcp:{h['name']}" if h["surface"] == SURFACE_MCP else "in_process"


def set_host(name: str, *, surface: str, version: str = "", model: str = "") -> None:
    """Явно задать хост процесса (веб-пульт, CLI). Перетирает прежнее значение."""
    with _lock:
        _state.update(
            name=_clean(name, _NAME_MAX) or UNKNOWN_HOST,
            version=_clean(version, _VERSION_MAX),
            surface=surface,
            model=_clean(model, _MODEL_MAX),
        )


def begin_mcp_host() -> None:
    """Процесс стал MCP-сервером: поверхность ``mcp``, имя ``unknown`` до handshake."""
    set_host(UNKNOWN_HOST, surface=SURFACE_MCP)


def adopt_client_info(name: Any, version: Any = "", model: Any = "") -> bool:
    """Запомнить ``clientInfo`` из handshake — ОДИН раз на процесс.

    Работает только пока хост процесса — безымянный MCP-клиент (``begin_mcp_host``): веб-пульт и
    CLI хост не меняют, а уже снятое имя не перетирается (кэш на процесс). Пустое имя — не
    handshake, ``False``. Возвращает ``True``, если кэш обновлен.
    """
    clean = _clean(name, _NAME_MAX)
    if not clean or _session_host.get() is not None:  # хост сессии процесс не перетирает
        return False
    with _lock:
        if _state["surface"] != SURFACE_MCP or _state["name"] != UNKNOWN_HOST:
            return False
        _state.update(
            name=clean, version=_clean(version, _VERSION_MAX), model=_clean(model, _MODEL_MAX)
        )
        return True


def needs_handshake() -> bool:
    """MCP-процесс, у которого хост еще не снят (``True`` — стоит попробовать контекст запроса)."""
    if _session_host.get() is not None:  # хост задан сессией - снимать с процесса нечего
        return False
    with _lock:
        return _state["surface"] == SURFACE_MCP and _state["name"] == UNKNOWN_HOST


# --------------------------------------------------------------------------- #
# DAEMON-1-SPIKE - идентичность хоста на СЕССИЮ, а не на процесс                              #
# --------------------------------------------------------------------------- #
# Один процесс движка обслуживает несколько хостов (http-транспорт): ``clientInfo`` берется с
# каждого запроса (граница MCP, ``mcp-server/server.py``) и кладется сюда на время вызова.
# ``current_host()`` читает ContextVar раньше хоста процесса, поэтому все потребители (провенанс
# выходов, суффикс папки, аудит, телеметрия, host-access) работают по сессии без правок.
# Хост процесса (``_state``) остается для stdio/CLI/веб-пульта: там ContextVar пуст.
_session_host: contextvars.ContextVar[dict[str, Any] | None] = contextvars.ContextVar(
    "dt_host", default=None
)


def bind_session_host(
    name: Any, version: Any = "", model: Any = "", *, surface: str = SURFACE_MCP
) -> contextvars.Token:
    """Хост текущего вызова (контекст запроса). Возвращает токен для :func:`unbind_session_host`.

    Пустое имя -> ``unknown`` (клиент не прислал ``clientInfo``), как до handshake у stdio."""
    return _session_host.set(
        {
            "name": _clean(name, _NAME_MAX) or UNKNOWN_HOST,
            "version": _clean(version, _VERSION_MAX),
            "surface": surface,
            "model": _clean(model, _MODEL_MAX),
        }
    )


def unbind_session_host(token: contextvars.Token) -> None:
    _session_host.reset(token)


# --------------------------------------------------------------------------- #
# WEBPULT-ACCESS-1 п.3 - контекст запроса веб-пульта (кто звонит: режим токена, хвост, peer)  #
# --------------------------------------------------------------------------- #
# Веб-сервер ставит контекст вокруг вызова инструмента (поток запроса); граница MCP и аудит
# (``record_action``) дописывают его в ``tool_call``/``pult-actions.log``. ContextVar, а не
# глобал: ThreadingHTTPServer обслуживает запросы параллельно. Токен целиком сюда не попадает -
# только последние 4 символа (``tok``), режим (``auth``) и peer (``peer``).
_request: contextvars.ContextVar[dict[str, str] | None] = contextvars.ContextVar(
    "dt_web_request", default=None
)


def set_request(auth: str, tok: str, peer: str, sid: str = "") -> contextvars.Token:
    """Контекст запроса. ``sid`` (DAEMON-1) - ПЕРВЫЕ 8 символов id MCP-сессии: по ним доктор считает
    сессии по хостам; id случайный, целиком не хранится. Пустой - поле в записях не появляется."""
    peer_ip = re.sub(r"[^0-9A-Fa-f.:]", "", str(peer or ""))[:45]  # IPv4/IPv6, без мусора
    fields = {"auth": _clean(auth, 8), "tok": _clean(tok, 8), "peer": peer_ip}
    short = re.sub(r"[^0-9A-Za-z]", "", str(sid or ""))[:8]
    if short:
        fields["sid"] = short
    return _request.set(fields)


def clear_request(token: contextvars.Token) -> None:
    _request.reset(token)


def request_fields() -> dict[str, str]:
    """``{auth, tok, peer[, sid]}`` текущего http-запроса (пульт или MCP-http); вне - пусто."""
    return dict(_request.get() or {})


def reset_host() -> None:
    """Вернуть состояние по умолчанию (``cli``) — для тестов."""
    with _lock:
        _state.update(name=SURFACE_CLI, version="", surface=SURFACE_CLI, model="")
