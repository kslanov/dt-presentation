"""VENDOR-HYGIENE-1 п.6 — доступ хостов к папкам: ``vault/_system/host-access.yaml``.

Один набор доверенных папок и одни правила для всех MCP-хостов (дизайн MODEL-1, принцип 3,
решение К. 26.10): чтение напрямую допустимо, запись в vault — только инструментами DT, папки
``_nda`` не выдаются никому. Список хранится в vault (человекочитаемый, версионируемый), движок
его только ЧИТАЕТ: показывает доктором/пультом и сверяет с телеметрией («какой хост вообще
ходит к нам и записан ли он»). Что именно хост видит на самом деле, определяет хост — это
реестр выданного, не механизм принуждения.

Формат::

    <имя хоста из handshake>:
      folders: [<абсолютный путь>, ...]   # [] — ничего не выдано
      granted: 2026-10-27                 # когда выдано
      note: "..."                         # пояснение
      aliases: [<другое имя того же хоста>]   # опционально

Чистое чтение; ``core`` не зависит от MCP.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from pathlib import Path
from typing import Any

import yaml

from core.config import vault_system_path

__all__ = [
    "HOST_ACCESS_FILE",
    "HostAccess",
    "host_access_path",
    "load_host_access",
    "match_host",
    "nda_folders",
    "overview",
    "seen_mcp_hosts",
    "unregistered_hosts",
]

HOST_ACCESS_FILE = "host-access.yaml"
USAGE_WINDOW_DAYS = 30


def host_access_path(vault_path: Path | None = None) -> Path:
    return vault_system_path(vault_path) / HOST_ACCESS_FILE


@dataclass(frozen=True)
class HostAccess:
    name: str
    folders: tuple[str, ...] = ()
    granted: str = ""
    note: str = ""
    aliases: tuple[str, ...] = field(default_factory=tuple)

    def names(self) -> set[str]:
        return {self.name.lower(), *(a.lower() for a in self.aliases)}


def _str_list(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise ValueError("ожидается список")
    return tuple(str(v).strip() for v in value if str(v).strip())


def load_host_access(path: Path | None = None) -> tuple[dict[str, HostAccess], str | None]:
    """``(записи по имени хоста, ошибка)``. Нет файла → ``({}, "нет файла …")``; битый → текст.

    Ошибка — строка, а не исключение: вызывающий (доктор, пульт) показывает ее как есть.
    """
    target = Path(path) if path is not None else host_access_path()
    if not target.is_file():
        return {}, f"нет файла {target}"
    try:
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError) as exc:
        return {}, f"не читается {target}: {str(exc)[:200]}"
    if data is None:
        return {}, None
    if not isinstance(data, dict):
        return {}, f"{target}: ожидается словарь «хост → {{folders, granted, note}}»"
    out: dict[str, HostAccess] = {}
    for name, entry in data.items():
        if not isinstance(entry, dict):
            return {}, f"{target}: запись хоста {name!r} должна быть словарем"
        try:
            granted = entry.get("granted")
            out[str(name)] = HostAccess(
                name=str(name),
                folders=_str_list(entry.get("folders")),
                granted=granted.isoformat() if isinstance(granted, (date, datetime))
                else str(granted or ""),
                note=str(entry.get("note") or "").strip(),
                aliases=_str_list(entry.get("aliases")),
            )
        except ValueError as exc:
            return {}, f"{target}: хост {name!r}: {exc}"
    return out, None


def match_host(entries: dict[str, HostAccess], name: str) -> HostAccess | None:
    """Запись по имени хоста из handshake (без учета регистра; имя или алиас)."""
    low = str(name or "").strip().lower()
    return next((e for e in entries.values() if low in e.names()), None)


def nda_folders(entries: dict[str, HostAccess]) -> list[tuple[str, str]]:
    """Выданные папки под NDA-барьером: ``[(хост, папка)]`` — правило «``_nda`` никому»."""
    from core.privacy import is_nda

    return [(e.name, f) for e in entries.values() for f in e.folders if is_nda(f)]


def seen_mcp_hosts(days: int = USAGE_WINDOW_DAYS) -> list[dict[str, Any]] | None:
    """MCP-хосты из телеметрии за окно: ``[{host, calls}]``; журнал не прочитался → ``None``.

    Веб-пульт (``webpult``), CLI и безымянный хост (``unknown`` — события до учета хостов или
    до handshake) сюда не входят: доступ к папкам выдается хостам с чат-моделью.
    """
    from core.contract import CODE_STORE_UNAVAILABLE, has_warning
    from core.metrics import usage_summary

    summary = usage_summary(days)
    if has_warning(summary, CODE_STORE_UNAVAILABLE):
        return None
    return [
        {"host": r["host"], "calls": r["calls"]}
        for r in summary["hosts"]
        if r["surface"] == "mcp" and r["host"] != "unknown"
    ]


def unregistered_hosts(
    entries: dict[str, HostAccess], seen: list[dict[str, Any]]
) -> list[str]:
    """Хосты из телеметрии, которых нет в yaml (по имени/алиасу). Анонимные (имя SDK по
    умолчанию, :func:`core.host.is_anonymous`) сюда не входят: вписывать «mcp» в реестр бессмысленно
    (см. :func:`anonymous_hosts`)."""
    from core.host import is_anonymous

    return sorted({r["host"] for r in seen
                   if not is_anonymous(r["host"]) and match_host(entries, r["host"]) is None})


def anonymous_hosts(seen: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Анонимные клиенты из телеметрии: ``[{host, calls}]`` (имя SDK по умолчанию - клиент не
    назвал себя; часто модель Kimi поднимает наш сервер своим клиентом)."""
    from core.host import is_anonymous

    return [r for r in seen if is_anonymous(r["host"])]


def overview(path: Path | None = None) -> dict[str, Any]:
    """Сводка для пульта (read-only): хосты и их папки + проблемы сверки.

    ``{path, hosts:[{name, folders, granted, note, calls}], nda_folders, unregistered, error?}``;
    ``calls`` — вызовы хоста за 30 дн из телеметрии (``None`` — журнал не прочитался).
    """
    entries, error = load_host_access(path)
    seen = seen_mcp_hosts()
    calls_by = {}
    for r in seen or []:
        entry = match_host(entries, r["host"])
        key = entry.name if entry else r["host"]
        calls_by[key] = calls_by.get(key, 0) + r["calls"]
    out: dict[str, Any] = {
        "path": str(Path(path) if path is not None else host_access_path()),
        "hosts": [
            {"name": e.name, "folders": list(e.folders), "granted": e.granted, "note": e.note,
             "calls": calls_by.get(e.name, 0) if seen is not None else None}
            for e in entries.values()
        ],
        "nda_folders": [{"host": h, "folder": f} for h, f in nda_folders(entries)],
        "unregistered": unregistered_hosts(entries, seen) if seen is not None else [],
        "anonymous": [r["host"] for r in anonymous_hosts(seen)] if seen is not None else [],
    }
    if error:
        out["error"] = error
    return out
