"""TOOLS-PROFILES-1 п.4 / HOSTS-ATTACH-1 - конфиги MCP-хостов из одного шаблона (host-config).

Движок - сервис, хост - клиент (DAEMON-1): хост подключается к демону ``com.dt.server``, а не
запускает свой ``server.py``. Три формы записи ``mcpServers.digital-twin`` из одного источника:

* :func:`daemon_url_entry` - ``{url: http://127.0.0.1:<порт>/mcp/<профиль>, headers: {Authorization:
  Bearer …}}`` (Kimi, Cursor, Cherry Studio - клиенты, умеющие url; у Cherry плюс ``type``);
* :func:`shim_entry` - ``{command: <venv python>, args: [cli/dt_shim.py, --profile, <p>,
  --token-file, <абс. путь>]}`` для хостов, которые умеют только команду (Claude Desktop/
  Cowork); токена в записи нет - мост читает файл;
* :func:`server_entry` - прежняя stdio-форма (``command/args/env``): ``--legacy-stdio`` для тестов и
  fallback, байт-в-байт как было.

Запись в конфиги хостов - ТОЛЬКО своя запись и только явным ``--install``
(:func:`install_entry`): один
член ``mcpServers.digital-twin`` байт-точным редактором ``core/mcp_json_edit.py``, с бэкапом рядом
(пересмотр решения TOOLS-PROFILES-1 «в чужие конфиги не пишем» по прецеденту KIMI-INSTALL-2).
``--out`` по-прежнему отказывает на конфигах хостов (:func:`refuse_foreign_config`): писать
туда можно только ``--install``. :func:`verify_host` читает конфиг и отвечает ``daemon`` |
``stdio-legacy`` | ``missing`` | ``foreign``. Токены в вердиктах - только хвост 4 символа.

Чистая функция от путей/параметров; ``core`` не зависит от MCP и CLI.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from collections.abc import Callable, Iterable
from pathlib import Path
from typing import Any

from core.config import ENGINE_ROOT

__all__ = [
    "DAEMON_HOSTS",
    "DesktopControl",
    "HOSTS",
    "PROFILES",
    "PLUGIN_DIR",
    "TOKEN_PLACEHOLDERS",
    "daemon_port",
    "daemon_url",
    "daemon_url_entry",
    "default_profile",
    "desktop_control",
    "foreign_config_paths",
    "host_config",
    "host_entry",
    "install_entry",
    "install_target",
    "instance_entry_verdicts",
    "kimi_plugin_manifest",
    "refuse_foreign_config",
    "render",
    "server_entry",
    "shim_entry",
    "token_file",
    "verify_host",
]

HOSTS = ("claude", "cursor", "kimi", "cherry", "url")
# хосты со своим файлом конфига (``--install``/``--verify``); cherry - свой стор в UI, url - голая
DAEMON_HOSTS = ("claude", "cursor", "kimi")
PROFILES = ("lean", "pult", "full")
SERVER_NAME = "digital-twin"
DEFAULT_PORT = 8787
# PERSONAL-1 п.6: личный экземпляр подключается ОТДЕЛЬНОЙ записью ``digital-twin-<экземпляр>`` на
# свой порт и со своим токеном; запись рабочего (``digital-twin``) не меняется ни на байт.
TOKEN_PLACEHOLDERS = {"read": "<web_token>", "rw": "<web_token_rw>"}
# Профиль по умолчанию: Desktop/Cowork - full (пишут выходы), остальные - lean.
_DEFAULT_PROFILE = {"claude": "full"}
PLUGIN_DIR = ENGINE_ROOT / "plugins" / "kimi-work"

# Куда хост кладет СВОЙ конфиг: сюда генератор не пишет (только печатает, что вставить).
_FOREIGN = {
    "claude": ("Library/Application Support/Claude/claude_desktop_config.json",
               ".config/Claude/claude_desktop_config.json"),
    "cursor": (".cursor/mcp.json",),
    "kimi": (".kimi/mcp.json", ".kimi-code/mcp.json", ".kimi-code/config.json"),
}


def _python(engine: Path) -> str:
    venv = engine / ".venv" / "bin" / "python"
    return str(venv) if venv.is_file() else sys.executable


def server_entry(
    profile: str = "full",
    *,
    engine: Path | None = None,
    sandbox: str | Path | None = None,
    desc_chars: int | None = None,
    user_name: str | None = None,
) -> dict[str, Any]:
    """Запись сервера: ``{command, args, env}`` (общий шаблон всех хостов).

    ``sandbox`` — каталог ``DT_DERIVED_ROOT``: хост работает на песочнице производных данных,
    боевой ``.derived`` не трогается (клон готовит человек; ``spikes/make_sandbox_ws.sh``).
    """
    if profile not in PROFILES:
        raise ValueError(f"неизвестный профиль {profile!r}: допустимы {', '.join(PROFILES)}")
    root = Path(engine) if engine is not None else ENGINE_ROOT
    env: dict[str, str] = {"PYTHONPATH": str(root)}
    if sandbox:
        env["DT_DERIVED_ROOT"] = str(Path(sandbox).expanduser().resolve())
    if desc_chars:
        env["DT_TOOL_DESC_CHARS"] = str(int(desc_chars))
    if user_name:
        env["DT_USER_NAME"] = user_name
    return {
        "command": _python(root),
        "args": [str(root / "mcp-server" / "server.py"), "--profile", profile],
        "env": env,
    }


def server_name(instance: str | None = None) -> str:
    """Ключ записи в конфиге хоста: ``digital-twin`` или ``digital-twin-<экземпляр>``."""
    return f"{SERVER_NAME}-{instance}" if instance else SERVER_NAME


def instance_params(instance: str, instances_dir: Path | None = None) -> tuple[int, Path]:
    """``(порт, каталог секретов)`` экземпляра из его оверлея; нет оверлея - ``ValueError``."""
    from core.config import env_file

    overlay = env_file.instance_overlay_path(instance, instances_dir)
    if not overlay.is_file():
        raise ValueError(f"экземпляра {instance!r} нет ({overlay}): dt instance add {instance} …")
    port = env_file.read_value(overlay, "DT_WEB_PORT")
    secrets_dir = env_file.read_value(overlay, "DT_SECRETS_DIR")
    if not port or not str(port).isdigit() or not secrets_dir:
        raise ValueError(f"оверлей {overlay}: нет DT_WEB_PORT/DT_SECRETS_DIR")
    return int(port), Path(secrets_dir)


def default_profile(host: str) -> str:
    """Профиль по умолчанию для хоста: ``claude`` - full, остальные - lean."""
    return _DEFAULT_PROFILE.get(host, "lean")


def daemon_port() -> int:
    """Порт демона: ``DT_WEB_PORT`` либо 8787 (как у ``pult_web_status`` и доктора)."""
    try:
        return int(os.environ.get("DT_WEB_PORT") or DEFAULT_PORT)
    except ValueError:
        return DEFAULT_PORT


def daemon_url(profile: str, port: int | None = None, server: str | None = None) -> str:
    """``http://127.0.0.1:<порт>/mcp/<профиль>`` - loopback: ``/mcp`` демона отвечает только ему.

    CONFIG-1: ``server`` (``dns | ip | host:порт | http://…``) - адрес демона-сервера по Tailscale:
    ``http://<server>:<порт>/mcp/<профиль>`` (сервер в режиме ``DT_MODE=server``)."""
    if profile not in PROFILES:
        raise ValueError(f"неизвестный профиль {profile!r}: допустимы {', '.join(PROFILES)}")
    if server:
        from core.client import JoinError, server_base

        try:
            base = server_base(server, port)
        except JoinError as exc:
            raise ValueError(exc.reason) from exc
        return f"{base}/mcp/{profile}"
    return f"http://127.0.0.1:{port or daemon_port()}/mcp/{profile}"


def token_file(access: str = "rw", secrets: Path | None = None) -> Path:
    """Абсолютный путь файла токена (``.secrets/web_token`` / ``web_token_rw``); ``secrets`` -
    каталог секретов ЭКЗЕМПЛЯРА (PERSONAL-1), по умолчанию каталог этого процесса."""
    from core.web_tokens import READ_FILE, RW_FILE
    from core.web_tokens import secrets_dir as _secrets_dir

    if access not in ("read", "rw"):
        raise ValueError(f"неизвестный вид токена {access!r}: read | rw")
    base = Path(secrets) if secrets is not None else _secrets_dir()
    return (base / (RW_FILE if access == "rw" else READ_FILE)).resolve()


def _token(access: str, secrets: Path | None = None) -> str | None:
    from core.web_tokens import WebTokens

    tokens = WebTokens(directory=secrets) if secrets is not None else WebTokens()
    return tokens.rw() if access == "rw" else tokens.read()


def daemon_url_entry(
    profile: str = "lean", access: str = "rw", *, port: int | None = None,
    placeholder: bool = False, with_type: bool = False, server: str | None = None,
    secrets: Path | None = None,
) -> dict[str, Any]:
    """``{url, headers: {Authorization: Bearer <токен>}}`` (+ ``type: streamableHttp`` для Cherry).

    Токен - настоящий (секрет самого пользователя в его терминале; вставлять в чат нельзя),
    ``placeholder=True`` - ``<web_token_rw>``. Нет токена (``.secrets`` не созданы) - отказ
    ``ValueError``: запись без токена демон отвергнет (401)."""
    token = TOKEN_PLACEHOLDERS[access] if placeholder else _token(access, secrets)
    if not token:
        raise ValueError(
            f"нет {access}-токена демона (.secrets/{token_file(access, secrets).name} / env): "
            "запусти демон (`bash ops/install_launchd.sh`) - токены создаются при старте")
    entry: dict[str, Any] = {}
    if with_type:
        entry["type"] = "streamableHttp"
    entry["url"] = daemon_url(profile, port, server)
    entry["headers"] = {"Authorization": f"Bearer {token}"}
    return entry


def shim_entry(
    profile: str = "full", access: str = "rw", *, engine: Path | None = None,
    port: int | None = None, server: str | None = None, secrets: Path | None = None,
    label: str | None = None,
) -> dict[str, Any]:
    """Запись моста: ``{command: <venv python>, args: [<engine>/cli/dt_shim.py, --profile, <p>,
    [--port N,] --token-file <абс. путь>]}`` - БЕЗ ``env`` и без токена (в ``ps`` виден путь к
    файлу, токен - нет). ``--port`` - только если порт не 8787. CONFIG-1: с ``server`` мост ходит на
    сервер - ``--url http://<server>:<порт>/mcp/<профиль>`` вместо ``--profile``/``--port``."""
    if profile not in PROFILES:
        raise ValueError(f"неизвестный профиль {profile!r}: допустимы {', '.join(PROFILES)}")
    root = Path(engine) if engine is not None else ENGINE_ROOT
    args = [str(root / "cli" / "dt_shim.py")]
    if server:
        args += ["--url", daemon_url(profile, port, server)]
    else:
        args += ["--profile", profile]
        chosen = port or daemon_port()
        if chosen != DEFAULT_PORT:
            args += ["--port", str(chosen)]
    args += ["--token-file", str(token_file(access, secrets))]
    if label:  # метка launchd демона экземпляра - в подсказке моста «как поднять демон»
        args += ["--label", label]
    return {"command": _python(root), "args": args}


def host_entry(
    host: str, profile: str | None = None, *, access: str = "rw", placeholder: bool = False,
    port: int | None = None, engine: Path | None = None, server: str | None = None,
    instance: str | None = None, instances_dir: Path | None = None,
) -> dict[str, Any]:
    """Запись ``digital-twin`` для хоста: ``claude`` - мост, ``cursor``/``kimi`` - url, ``cherry`` -
    url + ``type``, ``url`` - голая url-форма для любого клиента."""
    if host not in HOSTS:
        raise ValueError(f"неизвестный хост {host!r}: допустимы {', '.join(HOSTS)}")
    chosen = profile or default_profile(host)
    secrets: Path | None = None
    label: str | None = None
    if instance:  # PERSONAL-1: порт и токены ЭКЗЕМПЛЯРА, а не этого процесса
        if server:
            raise ValueError("--instance: локальный экземпляр, без --server")
        port, secrets = instance_params(instance, instances_dir)
        label = f"com.dt.server-{instance}"
    if host == "claude":
        return shim_entry(chosen, access, engine=engine, port=port, server=server,
                          secrets=secrets, label=label)
    return daemon_url_entry(chosen, access, port=port, placeholder=placeholder,
                            with_type=host == "cherry", server=server, secrets=secrets)


def host_config(
    host: str, profile: str | None = None, *, legacy_stdio: bool = False, **kwargs: Any
) -> dict[str, Any]:
    """Что вставить в конфиг хоста: ``{"mcpServers": {"digital-twin": {…}}}``; ``url`` - голая.

    По умолчанию - модель демона (:func:`host_entry`); ``legacy_stdio=True`` - прежняя stdio-форма
    (:func:`server_entry`, байт-в-байт как раньше; ``sandbox``/``desc_chars``/``user_name`` -
    только с ней). Хост ``url`` печатает голую запись (без обертки ``mcpServers``)."""
    if host not in HOSTS:
        raise ValueError(f"неизвестный хост {host!r}: допустимы {', '.join(HOSTS)}")
    if legacy_stdio:
        if kwargs.get("instance"):
            raise ValueError("--instance: только форма демона (url/мост), не --legacy-stdio")
        if kwargs.get("server"):
            raise ValueError("--server: только форма демона (url/мост), не --legacy-stdio")
        if host not in DAEMON_HOSTS:
            raise ValueError(f"--legacy-stdio: только {', '.join(DAEMON_HOSTS)}")
        legacy = {k: kwargs[k] for k in ("sandbox", "desc_chars", "user_name", "engine")
                  if kwargs.get(k) is not None}
        return {"mcpServers": {SERVER_NAME: server_entry(profile or "full", **legacy)}}
    if kwargs.get("sandbox") or kwargs.get("desc_chars") or kwargs.get("user_name"):
        raise ValueError("--sandbox/--desc-chars: только с --legacy-stdio (демон берет настройки "
                         "из своего .env)")
    entry = host_entry(
        host, profile, access=kwargs.get("access", "rw"),
        placeholder=bool(kwargs.get("placeholder")), port=kwargs.get("port"),
        engine=kwargs.get("engine"), server=kwargs.get("server"),
        instance=kwargs.get("instance"), instances_dir=kwargs.get("instances_dir"),
    )
    return entry if host == "url" else {"mcpServers": {server_name(kwargs.get("instance")): entry}}


def kimi_plugin_manifest(
    profile: str = "lean", *, skills: list[str] | None = None, version: str = "0.1.0",
    tool_names: Iterable[str] | None = None,
) -> dict[str, Any]:
    """Манифест плагина Kimi Work: скиллы (``./skills/``) и ``skillInstructions`` - БЕЗ MCP.

    HOSTS-ATTACH-1 п.4: в бандле Kimi (app.asar, 30.10) MCP-сервер плагина классифицируется как
    ``gateway-hosted`` (origin маркета Kimi) либо ``unsupported-local-mcp``; «legacy local MCP
    safety scan» снимает такие плагины из daimon. Поэтому **плагин = только скиллы, MCP =
    ``mcp.json`` агента** (``dt plugin kimi --install`` пишет туда url демона).

    ``skills`` - имена для ``skillInstructions``; не заданы - берутся из реестра скиллов
    (``core.skills.load_skills``): список в манифесте никогда не пишется руками. С ``tool_names``
    (инструменты профиля) реестр подгоняется ``fit_profile`` - скилл ⊆ профиль (MODEL-1-FIT)."""
    if skills is None:
        from core.skills import fit_profile, load_skills

        registry = load_skills()
        if tool_names is not None:
            registry = fit_profile(registry, tool_names)[0]
        skills = [s.name for s in registry]
    return {
        "$schema": "https://kimi.com/schemas/kimi.plugin.schema.json",
        "name": "digital-twin",
        "version": version,
        "description": ("Digital Twin: поиск по корпусу, структурные факты и генерация "
                        "артефактов в стиле автора через движок (профиль инструментов "
                        f"{profile})."),
        "keywords": ["digital twin", "vault", "retrieval"],
        "author": "CDT",
        "license": "UNLICENSED",
        "skills": "./skills/",
        "skillInstructions": (
            "Источник данных — инструменты Digital Twin (поиск, чтение, факты); файлы vault "
            "напрямую не читать. Артефакт собирается по скиллу generate-artifact, "
            "выход оформляется save-output. Список скиллов: " + ", ".join(skills) + "."
        ),
        "interface": {
            "displayName": "Digital Twin",
            "shortDescription": "Личный vault: поиск, факты, генерация в стиле автора",
            "category": "PRODUCTIVITY",
            "hostKind": "local",
            "platforms": ["macos"],
            "tryPrompts": ["Что у нас есть по ИТХ?", "Сделай справку по проекту"],
        },
    }


def foreign_config_paths(home: Path | None = None) -> list[Path]:
    """Конфиги хостов, в которые генератор не пишет."""
    base = Path(home) if home is not None else Path.home()
    return [(base / rel) for rels in _FOREIGN.values() for rel in rels]


def refuse_foreign_config(target: Path, home: Path | None = None) -> str | None:
    """Причина отказа, если ``target`` — конфиг чужого хоста; ``None`` — писать можно.

    ``--out`` пишет только в НАШИ файлы: в конфиг хоста можно только явным ``--install`` (одним
    членом ``digital-twin`` с бэкапом, :func:`install_entry`), а не выводом целого файла."""
    path = Path(target).expanduser()
    resolved = path.resolve()
    for foreign in foreign_config_paths(home):
        if resolved == foreign.resolve(strict=False):
            return (f"{foreign} — конфиг хоста: --out в него не пишет; запись только своим членом "
                    "и явным --install (с бэкапом)")
    if path.name in {"claude_desktop_config.json"}:
        return f"{path.name} — конфиг хоста: --out в него не пишет (используй --install)"
    return None


class HostConfigError(Exception):
    """Отказ установки/сверки с кодом (``host_not_found``, ``use_plugin``, ``live_guard``,
    ``desktop_running``, ``desktop_wont_quit``)."""

    def __init__(self, code: str, reason: str) -> None:
        super().__init__(f"{code}: {reason}")
        self.code, self.reason = code, reason


def _real_home() -> Path:
    import pwd

    return Path(pwd.getpwuid(os.getuid()).pw_dir).resolve()


def install_target(host: str, home: Path | None = None) -> Path:
    """Конфиг хоста, в который ``--install`` пишет свой член: существующий файл из ``_FOREIGN`` либо
    (нет файла) первый путь, чей каталог существует. Хост не установлен - ``host_not_found``.
    Kimi ставится ``dt plugin kimi --install`` (скиллы + mcp.json агента одной командой)."""
    if host == "kimi":
        raise HostConfigError("use_plugin", "Kimi: `dt plugin kimi --out plugins/kimi-work "
                                            "--install` (скиллы плагина + mcp.json агента)")
    if host not in ("claude", "cursor"):
        raise HostConfigError("no_config_file", f"{host}: своего файла конфига нет (запись - "
                                                "руками в UI хоста)")
    base = Path(home) if home is not None else Path.home()
    candidates = [base / rel for rel in _FOREIGN[host]]
    for path in candidates:
        if path.is_file():
            return path
    for path in candidates:
        if path.parent.is_dir():
            return path
    raise HostConfigError("host_not_found", f"{host}: нет ни файла, ни каталога конфига "
                                            f"({candidates[0].parent}) - хост не запускался")


# --- Claude Desktop перезаписывает свой конфиг при выходе (PERSONAL-3 п.D) ---------------------- #
DESKTOP_APP = "Claude"
QUIT_WAIT_S = 60.0  # сколько ждем выхода Desktop после просьбы выйти (kill не делаем никогда)
SETTLE_S = 2.0  # пауза между выходом и записью: Desktop успевает дописать свой конфиг


class DesktopControl:
    """Состояние и управление приложением Claude Desktop (macOS). Подменяется в тестах целиком.

    ``running`` - ``pgrep -x Claude`` и ``osascript 'application "Claude" is running'``; ошибка
    ``osascript`` (нет прав на автоматизацию, нет команды) считается «запущен»: пропустить запись
    при работающем Desktop дороже, чем отказать лишний раз."""

    def __init__(self, run: Callable[[list[str]], tuple[int, str]] | None = None,
                 sleep: Callable[[float], None] = time.sleep,
                 clock: Callable[[], float] = time.monotonic) -> None:
        self._run = run or self._default_run
        self.sleep, self.clock = sleep, clock

    @staticmethod
    def _default_run(argv: list[str]) -> tuple[int, str]:
        try:
            done = subprocess.run(argv, capture_output=True, text=True, timeout=15,  # noqa: S603
                                  check=False)
        except (OSError, subprocess.SubprocessError) as exc:
            return 127, str(exc)
        return done.returncode, (done.stdout or "").strip()

    def running(self) -> bool:
        code, _out = self._run(["pgrep", "-x", DESKTOP_APP])
        if code == 0:
            return True
        code, out = self._run(
            ["osascript", "-e", f'application "{DESKTOP_APP}" is running'])
        return code != 0 or out.strip().lower() == "true"

    def quit(self) -> None:
        self._run(["osascript", "-e", f'tell application "{DESKTOP_APP}" to quit'])

    def launch(self) -> None:
        self._run(["open", "-a", DESKTOP_APP])


def desktop_control() -> DesktopControl:
    """Управление Desktop по умолчанию (тесты подменяют его: боевой Desktop не трогаем)."""
    return DesktopControl()


def _write_with_desktop(
    host: str, target: Path, write: Callable[[], dict[str, Any]], *, relaunch: bool,
    desktop: DesktopControl | None,
) -> tuple[dict[str, Any], list[str]]:
    """Запись в конфиг Desktop с учетом того, что он перезаписывает файл при выходе из своей памяти.

    Не запущен - пишем. Запущен: по умолчанию отказ ``desktop_running`` (запись пропала бы), с
    ``relaunch`` - выход → ожидание ≤ 60 с (иначе ``desktop_wont_quit``, без kill и без записи) →
    пауза 2 с → запись → запуск. Возвращает результат записи и шаги (для вывода и аудита)."""
    ctl = desktop or desktop_control()
    steps: list[str] = []
    if host != "claude" or target.name != "claude_desktop_config.json" or not ctl.running():
        steps.append("Desktop не запущен" if host == "claude" else f"{host}: запуск не проверяется")
        return write(), steps
    if not relaunch:
        raise HostConfigError(
            "desktop_running",
            "Claude Desktop запущен и перезапишет конфиг при выходе из своей памяти - запись "
            "пропадет. Закрой Desktop или повтори с --relaunch (выход → запись → запуск)")
    steps.append("Desktop запущен: прошу выйти")
    ctl.quit()
    deadline = ctl.clock() + QUIT_WAIT_S
    while ctl.running():
        if ctl.clock() >= deadline:
            raise HostConfigError(
                "desktop_wont_quit",
                f"Desktop не вышел за {QUIT_WAIT_S:.0f} с (kill не делаю): "
                "закрой его сам и повтори")
        ctl.sleep(1.0)
    steps.append("Desktop вышел")
    ctl.sleep(SETTLE_S)
    done = write()
    steps.append("запись выполнена")
    ctl.launch()
    steps.append("Desktop запущен снова")
    return done, steps


def install_entry(
    host: str, entry: dict[str, Any], *, home: Path | None = None, path: Path | None = None,
    now: Any = None, name: str = SERVER_NAME, relaunch: bool = False,
    desktop: DesktopControl | None = None,
) -> dict[str, Any]:
    """``--install``: записать ``mcpServers.<name>`` в конфиг хоста (один член, бэкап рядом).

    Возвращает ``{path, outcome, backup, steps}`` (``outcome``: created|added|updated|unchanged;
    ``unchanged`` - ни бэкапа, ни записи). Битый JSON - :class:`HostConfigError`
    ``invalid_json`` без записи. Под pytest запись в настоящий домашний каталог запрещена кодом
    (тесты подменяют ``HOME``).

    PERSONAL-3: хост ``claude`` при запущенном Desktop - отказ ``desktop_running`` (он
    перезаписывает конфиг при выходе, запись пропала бы); ``relaunch=True`` делает «выход → запись →
    запуск» штатно (:func:`_write_with_desktop`); шаги идут в результат и в аудит."""
    from core.mcp_json_edit import McpJsonError, install_member

    target = Path(path) if path is not None else install_target(host, home)
    if "PYTEST_CURRENT_TEST" in os.environ and target.resolve().is_relative_to(_real_home()):
        raise HostConfigError("live_guard", f"тест целится в настоящий конфиг хоста {target}: "
                                            "подмени HOME")

    def write() -> dict[str, Any]:
        try:
            done = install_member(target, name, entry, now=now)
        except McpJsonError as exc:
            raise HostConfigError(exc.code, exc.reason) from exc
        return {"path": str(done.path), "outcome": done.outcome,
                "backup": str(done.backup) if done.backup else None}

    result, steps = _write_with_desktop(host, target, write, relaunch=relaunch, desktop=desktop)
    result["steps"] = steps
    _audit_install(host, name, result)
    return result


def uninstall_entry(
    host: str, *, home: Path | None = None, path: Path | None = None, now: Any = None,
    name: str = SERVER_NAME, relaunch: bool = False, desktop: DesktopControl | None = None,
) -> dict[str, Any]:
    """``dt uninstall``: снять ``mcpServers.<name>`` из конфига хоста (один член, бэкап рядом).

    Возвращает ``{path, outcome, backup, steps}`` (``outcome``: removed|absent; ``absent`` - файла/
    ключа нет, ничего не записано). Те же охранные условия, что у :func:`install_entry`: под pytest
    запись в настоящий дом запрещена (``live_guard``), Claude Desktop при запуске - отказ
    ``desktop_running`` либо штатный «выход → запись → запуск» с ``relaunch``."""
    from core.mcp_json_edit import McpJsonError, read_config, remove_member

    target = Path(path) if path is not None else install_target(host, home)
    if "PYTEST_CURRENT_TEST" in os.environ and target.resolve().is_relative_to(_real_home()):
        raise HostConfigError("live_guard", f"тест целится в настоящий конфиг хоста {target}: "
                                            "подмени HOME")
    doc, _text, error = read_config(target)
    if error:
        raise HostConfigError("invalid_json", f"{error}; не перезаписываю")
    servers = (doc or {}).get("mcpServers")
    if not isinstance(servers, dict) or name not in servers:
        return {"path": str(target), "outcome": "absent", "backup": None,
                "steps": ["записи нет"]}

    def write() -> dict[str, Any]:
        try:
            done = remove_member(target, name, now=now)
        except McpJsonError as exc:
            raise HostConfigError(exc.code, exc.reason) from exc
        return {"path": str(done.path), "outcome": done.outcome,
                "backup": str(done.backup) if done.backup else None}

    result, steps = _write_with_desktop(host, target, write, relaunch=relaunch, desktop=desktop)
    result["steps"] = steps
    return result


def _audit_install(host: str, name: str, result: dict[str, Any]) -> None:
    """Аудит записи в конфиг хоста (best-effort): хост, ключ, исход, шаги - без содержимого."""
    try:
        from core.operational.pult import record_action

        record_action("host_config_install", {
            "host": host, "entry": name, "steps": ";".join(result["steps"]).replace(" ", "_")},
            str(result["outcome"]))
    except Exception:  # noqa: BLE001, S110 - аудит не должен ронять установку
        pass


# --- сверка (только чтение) ------------------------------------------------------------------- #
VERDICT_DAEMON, VERDICT_LEGACY = "daemon", "stdio-legacy"
VERDICT_MISSING, VERDICT_FOREIGN = "missing", "foreign"


def _flag(args: list[str], name: str) -> str | None:
    for i, a in enumerate(args):
        if a == name and i + 1 < len(args):
            return str(args[i + 1])
        if a.startswith(name + "="):
            return a.split("=", 1)[1]
    return None


def _classify(
    entry: Any, port: int, server: str | None = None, secrets: Path | None = None
) -> dict[str, Any]:
    """Запись ``digital-twin`` -> ``{verdict, form, profile, reason, token_tail}`` (без токена).

    ``server`` (CONFIG-1, клиент без движка) - ``http://host:порт`` сервера: запись на его url тоже
    «наша» (демон там, не здесь)."""
    from urllib.parse import urlparse

    from core.web_tokens import WebTokens, tail

    def out(verdict: str, form: str = "", profile: str = "", reason: str = "",
            token_tail: str = "") -> dict[str, Any]:
        return {"verdict": verdict, "form": form, "profile": profile, "reason": reason,
                "token_tail": token_tail}

    if not isinstance(entry, dict):
        return out(VERDICT_FOREIGN, reason="запись не объект")
    url, command, args = entry.get("url"), entry.get("command"), entry.get("args")
    remote = urlparse(server) if server else None

    def _is_ours(u: Any) -> bool:
        if u.hostname in ("127.0.0.1", "localhost", "::1") and (u.port or 80) == port:
            return True
        return bool(remote and u.hostname == remote.hostname
                    and (u.port or 80) == (remote.port or 80))

    if isinstance(url, str):
        u = urlparse(url)
        profile = u.path.rstrip("/").rsplit("/", 1)[-1]
        ours = (_is_ours(u) and u.path.rstrip("/") == f"/mcp/{profile}" and profile in PROFILES)
        if not ours:
            return out(VERDICT_FOREIGN, "url",
                       reason=f"url не на наш демон (порт {port}, /mcp/<профиль>)")
        headers = entry.get("headers")
        auth = str(headers.get("Authorization") or "") if isinstance(headers, dict) else ""
        token = auth[7:] if auth.startswith("Bearer ") else ""
        if not token:
            return out(VERDICT_FOREIGN, "url", profile, "url наш, но нет заголовка Authorization")
        known = WebTokens(directory=secrets) if secrets is not None else WebTokens()
        if token not in (known.rw(), known.read()):
            return out(VERDICT_FOREIGN, "url", profile,
                       "токен в записи не совпадает с .secrets (перевыпущен?)", tail(token))
        return out(VERDICT_DAEMON, "url", profile, token_tail=tail(token))
    if isinstance(command, str) and isinstance(args, list):
        strs = [str(a) for a in args]
        if any(a.endswith("dt_shim.py") for a in strs):
            profile = _flag(strs, "--profile") or ""
            given_url = _flag(strs, "--url") or ""
            shim_ours = True
            if given_url:
                u = urlparse(given_url)
                profile = u.path.rstrip("/").rsplit("/", 1)[-1]
                shim_ours = _is_ours(u)
            else:
                shim_ours = int(_flag(strs, "--port") or DEFAULT_PORT) == port
            tok = _flag(strs, "--token-file")
            if profile not in PROFILES or not shim_ours:
                return out(VERDICT_FOREIGN, "shim", profile, f"мост не на наш порт {port}/профиль")
            if not tok or not Path(tok).expanduser().is_file():
                return out(VERDICT_FOREIGN, "shim", profile, "токен-файл моста не существует")
            return out(VERDICT_DAEMON, "shim", profile)
        if any(a.endswith("server.py") for a in strs) and "--transport" not in strs:
            return out(VERDICT_LEGACY, "stdio", _flag(strs, "--profile") or "full",
                       "старая stdio-команда server.py (свой процесс движка на хост)")
    return out(VERDICT_FOREIGN, reason="запись не наша (ни url демона, ни мост, ни server.py)")


def verify_host(
    host: str, *, home: Path | None = None, port: int | None = None, path: Path | None = None,
    sessions: Any = None, server: str | None = None, instance: str | None = None,
    instances_dir: Path | None = None,
) -> dict[str, Any]:
    """Что стоит в конфиге хоста (ТОЛЬКО чтение): daemon | stdio-legacy | missing | foreign.

    CONFIG-1: ``server`` (или ``DT_SERVER_URL`` при ``DT_MODE=client``) - запись на url сервера по
    Tailscale тоже ``daemon``. ``{host, verdict, form, profile, path, reason, token_tail}``.
    Конфиг claude - оба пути
    ``_FOREIGN`` (берется тот, где есть наш ключ). ``cherry`` - свой стор в UI (чужую базу не
    читаем): только
    употребление - есть ли сессии хоста по url в телеметрии за 30 дн (``sessions`` - инъекция
    ``() -> {хост: число}``). Токены в вердикт не попадают (только хвост 4 символа)."""
    from core.mcp_json_edit import read_config

    chosen_port = port or daemon_port()
    secrets: Path | None = None
    if instance:  # PERSONAL-1: запись ``digital-twin-<экземпляр>`` на порт и токены экземпляра
        chosen_port, secrets = instance_params(instance, instances_dir)
        server = None
    if instance is None and server is None:
        from core.client import configured_server, is_client, server_base

        if is_client():
            try:
                server = server_base(configured_server() or "")
            except Exception:  # noqa: BLE001 - нет/битый адрес: сверяем как локальный
                server = None
    elif server is not None and "://" not in server:
        from core.client import server_base

        server = server_base(server)
    if host == "cherry":
        from core.daemon import sessions_by_host

        by_host = (sessions or (lambda: sessions_by_host(24.0 * 30)))()
        if by_host is None:
            return {"host": host, "verdict": VERDICT_MISSING, "form": "", "profile": "", "path": "",
                    "reason": "журнал метрик не прочитался", "token_tail": ""}
        seen = {h: n for h, n in by_host.items() if "cherry" in h.casefold()}
        verdict = VERDICT_DAEMON if seen else VERDICT_MISSING
        why = (f"сессий по url за 30 дн: {sum(seen.values())} ({', '.join(sorted(seen))})" if seen
               else "сессий по url в телеметрии за 30 дн нет (регистрация - руками в UI Cherry)")
        return {"host": host, "verdict": verdict, "form": "url", "profile": "", "path": "",
                "reason": why, "token_tail": ""}
    if host == "kimi":
        from core.kimi_install import MCP_FILE, kimi_agent_home

        paths = [Path(path) if path is not None else kimi_agent_home() / MCP_FILE]
    elif host in ("claude", "cursor"):
        paths = [Path(path)] if path is not None else [
            (Path(home) if home is not None else Path.home()) / rel for rel in _FOREIGN[host]]
    else:
        raise ValueError(f"--verify: хосты {', '.join(DAEMON_HOSTS)}, cherry")
    first_error = ""
    for candidate in paths:
        if "PYTEST_CURRENT_TEST" in os.environ and candidate.resolve().is_relative_to(_real_home()):
            continue  # под pytest настоящие конфиги хостов не читаем (герметичность; HOME - в tmp)
        doc, _, error = read_config(candidate)
        if error:
            first_error = first_error or error
            continue
        servers = (doc or {}).get("mcpServers")
        key = server_name(instance)
        if isinstance(servers, dict) and key in servers:
            return {"host": host, "path": str(candidate),
                    **_classify(servers[key], chosen_port, server, secrets)}
    why = first_error or f"в конфиге нет ключа {server_name(instance)} (либо файла нет)"
    return {"host": host, "verdict": VERDICT_MISSING, "form": "", "profile": "",
            "path": str(paths[0]), "reason": why, "token_tail": ""}


def instance_entry_verdicts(
    host: str = "claude", *, instances: list[str] | None = None,
    instances_dir: Path | None = None, home: Path | None = None,
    verify: Callable[..., dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """PERSONAL-3 п.D3: для КАЖДОГО экземпляра из ``instances/`` ожидается запись
    ``digital-twin-<имя>`` на его порт в конфиге хоста. Возвращает вердикты (:func:`verify_host` с
    ``instance``) с ``name``; ``missing`` - запись пропала (Claude Desktop перезаписывает конфиг
    при выходе из своей памяти).
    Только чтение. Под pytest список экземпляров не читается из боевого ``engine/instances``
    (герметичность: как и конфиги хостов), если не передан явно."""
    if instances is None:
        if "PYTEST_CURRENT_TEST" in os.environ and instances_dir is None:
            return []
        from core.instance_admin import list_instances

        instances = list_instances(instances_dir)
    check = verify or verify_host
    out: list[dict[str, Any]] = []
    for name in instances:
        try:
            verdict = check(host, instance=name, instances_dir=instances_dir, home=home)
        except Exception as exc:  # noqa: BLE001 - не прочитался: сказано, а не «все хорошо»
            verdict = {"host": host, "verdict": VERDICT_MISSING, "reason": f"не прочитан: {exc}",
                       "form": "", "profile": "", "path": "", "token_tail": ""}
        out.append({**verdict, "name": name})
    return out


def render(config: dict[str, Any]) -> str:
    return json.dumps(config, ensure_ascii=False, indent=2)
