"""AI-assisted ingestion of inbox items (architecture §4, ТЗ D6).

Refines a quick-capture element from ``_staging/inbox/`` into a placed vault
note: ``inbox item → refinement proposal {type, frontmatter, summary?,
target_path} → confirm → write to vault``.

**Path B (decision 2026-06-17):** the *proposal* is produced by Claude in Cowork.
``core/`` never calls an LLM — it only (1) assembles the structured refinement
*request* Cowork needs (item text + entity catalog + ``parse_task`` hints +
frontmatter schema + candidate folders) and (2) applies a confirmed proposal.

Invariant: ``core/`` depends on neither MCP nor CLI; no network LLM calls here.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from core.config import default_vault_path, staging_inbox_path
from core.metrics import record_event
from core.operational.ticktick.capture import ASSIGNMENT_TAGS
from core.parse_task import parse_task
from core.vault import Note, write_note

__all__ = [
    "InboxItem",
    "EntityRef",
    "RefinementRequest",
    "list_inbox",
    "build_refinement_request",
    "inbox_lane",
    "is_assignment",
    "apply_refinement",
]

# Quick-capture files we treat as raw inbox items (§4 "Manual notes").
_INBOX_SUFFIXES = (".md", ".txt")

# Content-file types per §1; the proposal picks one for ``type``.
CONTENT_TYPES: tuple[str, ...] = (
    "note",
    "document",
    "meeting",
    "task",
    "style-sample",
    "template",
    "output",
)

# Hub entities that form the catalog Cowork matches against (§1).
_CATALOG_ENTITIES: tuple[str, ...] = (
    "client",
    "industry",
    "direction",
    "product",
    "project",
)

# Frontmatter schema (§1) handed to Cowork verbatim so the proposed frontmatter
# uses the right fields and wikilink shape.
FRONTMATTER_SCHEMA = """\
id: <slug>                     # stable unique id; if omitted — the vault-relative path without .md
type: note                     # one of CONTENT_TYPES (note | document | meeting | task | ...)
created: YYYY-MM-DD
modified: YYYY-MM-DD
status: active
tags: [..]                     # soft labels (state/property)

# wikilinks — "to what does this belong" (hard classification):
client: "[[client-x]]"
project: "[[project-alpha]]"
deal: "[[deal-client-x-aims]]"
industry: "[[industry-fintech]]"
direction: "[[direction-erp]]"
product: ["[[product-aims]]"]  # may be several

# optional, by type:
participants: ["[[ivan-petrov]]"]
genre: report                  # only on style-sample
sources: ["[[note-123]]"]      # only on output
"""


@dataclass
class InboxItem:
    """A raw, unprocessed element sitting in ``_staging/inbox/``."""

    path: Path
    text: str


@dataclass
class EntityRef:
    """One hub in the catalog: its ``id`` plus the names Cowork/linking can match on.

    HUB-ALIAS-1: ``aliases`` - ВСЕ имена хаба из единого каталога
    (:func:`core.retrieval.hubcat.hub_catalog`: frontmatter-алиасы, H1 целиком и фрагменты «…»/(…),
    слаг id от 4 знаков); ``explicit`` - подмножество, которое владелец записал в frontmatter
    ``aliases:`` руками. Контракт ``EntityRef(entity, id, aliases)`` прежний.
    """

    entity: str
    id: str
    aliases: list[str] = field(default_factory=list)
    explicit: list[str] = field(default_factory=list)


@dataclass
class RefinementRequest:
    """Everything Cowork needs to propose a placement for one inbox item.

    This is the structured request the engine assembles (Path B). Cowork turns
    it into a ``{type, frontmatter, summary?, target_path}`` proposal which the
    user confirms and :func:`apply_refinement` then writes to the vault.
    """

    item: InboxItem
    catalog: list[EntityRef]
    hints: dict[str, str]
    types: tuple[str, ...]
    schema: str
    target_folders: list[str]

    def render(self) -> str:
        """Render as a human/Cowork-readable prompt."""
        lines: list[str] = []
        lines.append(f"# Refinement request — {self.item.path.name}")
        lines.append("")
        lines.append(
            "Propose where this captured note belongs in the vault. Return a YAML "
            "proposal with keys: type, target_path, frontmatter (with entity "
            "wikilinks), and summary (only if the text is long)."
        )
        lines.append("")

        lines.append("## Captured text")
        lines.append("```")
        lines.append(self.item.text.strip() or "(empty)")
        lines.append("```")
        lines.append("")

        lines.append("## Entity hints (parse_task matcher)")
        if self.hints:
            for key, value in self.hints.items():
                lines.append(f"- {key}: {value}")
        else:
            lines.append("- (no entities matched in the text)")
        lines.append("")

        lines.append("## Entity catalog (id — aliases)")
        by_entity: dict[str, list[EntityRef]] = {}
        for ref in self.catalog:
            by_entity.setdefault(ref.entity, []).append(ref)
        for entity in _CATALOG_ENTITIES:
            refs = by_entity.get(entity)
            if not refs:
                continue
            lines.append(f"### {entity}")
            for ref in refs:
                alias = f" — {', '.join(ref.aliases)}" if ref.aliases else ""
                lines.append(f"- {ref.id}{alias}")
        lines.append("")

        lines.append("## Content types (pick one for `type`)")
        lines.append("- " + " | ".join(self.types))
        lines.append("")

        lines.append("## Frontmatter schema (§1)")
        lines.append("```yaml")
        lines.append(self.schema.rstrip())
        lines.append("```")
        lines.append("")

        lines.append("## Candidate target folders")
        for folder in self.target_folders:
            lines.append(f"- {folder}")
        lines.append("")
        return "\n".join(lines)


def list_inbox(inbox_dir: Path | None = None) -> list[InboxItem]:
    """Collect unprocessed ``.md``/``.txt`` elements from ``_staging/inbox/``.

    Hidden files (``.DS_Store`` etc.) are skipped. Returns an empty list if the
    inbox does not exist yet.
    """
    inbox_dir = Path(inbox_dir) if inbox_dir is not None else staging_inbox_path()
    if not inbox_dir.is_dir():
        return []

    items: list[InboxItem] = []
    for path in sorted(inbox_dir.iterdir()):
        if not path.is_file() or path.name.startswith("."):
            continue
        if path.suffix.lower() not in _INBOX_SUFFIXES:
            continue
        items.append(InboxItem(path=path, text=path.read_text(encoding="utf-8")))
    return items


def _entity_catalog(vault_path: Path) -> list[EntityRef]:
    """Каталог хабов (id + все имена) по сущностям каталога - обертка над ЕДИНЫМ каталогом имен.

    Собственного обхода vault здесь больше нет (HUB-ALIAS-1): имена берет
    :func:`core.retrieval.hubcat.hub_catalog`. Слаг id короче 4 знаков в имена не идет (он и так
    не совпал бы ни в прозе, ни как ярлык папки); короткие аббревиатуры из H1 («ГЛБ») остаются -
    потребитель (``deterministic``) принимает любое короткое имя ТОЛЬКО целым словом в том же
    регистре.
    """
    from core.retrieval.hubcat import hub_catalog

    order = {name: i for i, name in enumerate(_CATALOG_ENTITIES)}
    catalog: list[EntityRef] = []
    for entry in hub_catalog(vault_path, _CATALOG_ENTITIES):
        names = [n for n in entry.names if not (n.source == "slug" and len(n.text) < 4)]
        catalog.append(
            EntityRef(
                entity=entry.entity,
                id=entry.note_id,
                aliases=[n.text for n in names],
                explicit=[n.text for n in names if n.explicit],
            )
        )
    catalog.sort(key=lambda r: (order[r.entity], r.id))
    return catalog


def _candidate_folders(hints: dict[str, str]) -> list[str]:
    """Candidate vault folders derived from the matched entity links (§3).

    PERSONAL-2: у личного экземпляра с ``DT_PERSONAL_CONTENT_DIRS``/``DT_PERSONAL_IDEAS_DIR`` целями
    размещения служат папки ЕГО vault (контент по типу источника, идеи), а не рабочие."""
    from core import instance

    if instance.is_personal():
        own = [*instance.personal_content_dirs(), *filter(None, [instance.personal_ideas_dir()])]
        if own:
            return [f"{d}/" for d in dict.fromkeys(own)]
    folders: list[str] = []
    project_id = hints.get("project_id")
    if project_id:
        # Project notes live under their hub folder; the project id carries the
        # ``project-`` prefix, the folder usually does not.
        slug = project_id.removeprefix("project-")
        folders.append(f"03-projects/{slug}/notes/")
        folders.append(f"03-projects/{slug}/documents/")
    if hints.get("client_id"):
        folders.append("04-clients/")
    # VAULT-1: ``05-operational/`` УДАЛЁН из vault (аудит 2026-07-29; карта разделов
    # — 02-architecture §9a) — больше не предлагаем его как посадку захвата (был
    # мёртвый ориентир для LLM-разбора инбокса). Посадки: notes/ хаба (выше) +
    # стабильные знания ниже.
    # Stable knowledge, when the note is reference material rather than a project log.
    folders.append("02-knowledge/")
    # De-duplicate, preserve order.
    seen: set[str] = set()
    return [f for f in folders if not (f in seen or seen.add(f))]


def build_refinement_request(
    item: InboxItem,
    *,
    vault_path: Path | None = None,
) -> RefinementRequest:
    """Assemble the structured refinement request for one inbox ``item`` (Path B).

    Reuses the ``parse_task`` entity matcher for hints and walks the vault hubs
    for the full catalog. No LLM call — Cowork consumes this to propose a
    placement.
    """
    vault_path = vault_path or default_vault_path()

    parsed = parse_task(item.text, vault_path=vault_path)
    # Drop the heuristic use_case — refinement is about placement, not a use case.
    hints = {k: v for k, v in parsed.params.items() if k.endswith("_id")}

    return RefinementRequest(
        item=item,
        catalog=_entity_catalog(vault_path),
        hints=hints,
        types=CONTENT_TYPES,
        schema=FRONTMATTER_SCHEMA,
        target_folders=_candidate_folders(hints),
    )


# --------------------------------------------------------------------------- #
# Лейн поручения (#поручение / #тиметта) — карточка «Поручение администратору CRM»
# --------------------------------------------------------------------------- #
# RETIRE-WRITE-1: движок в Timetta не пишет, поэтому «классификация захвата в Timetta-интент»
# (DealRef/OperationalRequest/build_operational_request/discard_inbox_item) ушла в архивную ветку
# ``archive/timetta-write``. Захват этого лейна превращается в черновик поручения —
# :mod:`core.operational.assignment`.
def inbox_lane(item: InboxItem) -> str | None:
    """The capture lane tag from an inbox item's provenance footer (``lane: …``).

    B2a writes ``lane: <tag>`` (e.g. ``поручение`` / ``знание``) into the footer of
    every captured file. Returns the bare tag word, or ``None`` for a hand-written
    note that has no such footer.
    """
    for line in item.text.splitlines():
        stripped = line.strip()
        if stripped.lower().startswith("lane:"):
            return stripped.split(":", 1)[1].strip() or None
    return None


def is_assignment(item: InboxItem) -> bool:
    """True iff ``item`` was captured into the assignment lane (``#поручение``/``#тиметта``)."""
    lane = inbox_lane(item)
    return lane is not None and lane.strip().lower() in ASSIGNMENT_TAGS


def _compose_body(item: InboxItem, summary: str | None) -> str:
    """Note body: original text, with a summary section prepended if given."""
    original = item.text.strip()
    if summary and summary.strip():
        return f"## Резюме\n\n{summary.strip()}\n\n---\n\n{original}\n"
    return f"{original}\n"


def apply_refinement(
    item: InboxItem,
    proposal: dict,
    *,
    vault_path: Path | None = None,
) -> Path:
    """Write the confirmed ``proposal`` into the vault and clear the inbox item.

    ``proposal`` keys: ``type``, ``frontmatter`` (dict), ``target_path`` (vault-
    relative or absolute, including the ``.md`` filename), optional ``summary``.
    Returns the path of the written note.
    """
    vault_path = vault_path or default_vault_path()

    target_raw = proposal.get("target_path")
    if not target_raw:
        raise ValueError("proposal is missing 'target_path'")
    target = Path(target_raw)
    if not target.is_absolute():
        target = vault_path / target
    if target.suffix.lower() != ".md":
        raise ValueError(f"target_path must be a .md file, got: {target_raw}")
    # Containment guard: the resolved target must stay inside the vault.
    # Blocks `../`-style traversal, absolute paths outside the vault and
    # symlink escapes (resolve() follows symlinks in existing parents).
    vault_root = vault_path.resolve()
    resolved = target.resolve()
    if not resolved.is_relative_to(vault_root):
        raise ValueError(f"target_path escapes the vault: {target_raw}")

    frontmatter = dict(proposal.get("frontmatter") or {})
    # Keep type consistent: explicit proposal type wins, else fall back to fm.
    note_type = proposal.get("type") or frontmatter.get("type")
    if note_type:
        frontmatter["type"] = note_type
    frontmatter.setdefault("id", target.stem)

    body = _compose_body(item, proposal.get("summary"))

    target.parent.mkdir(parents=True, exist_ok=True)
    note = Note(
        id=str(frontmatter["id"]),
        type=frontmatter.get("type"),
        path=target,
        frontmatter=frontmatter,
        body=body,
    )
    written = write_note(note)

    # Clear the source from the inbox now that it is placed.
    item.path.unlink(missing_ok=True)

    # KPI-1 (метрика 1, v1-приближение): факт применения разметки. Privacy —
    # только папка верхнего уровня и размер, никаких имён/текстов.
    rel = resolved.relative_to(vault_root)
    record_event(
        "inbox_applied",
        target_dir=rel.parts[0] if len(rel.parts) > 1 else "",
        size=len(body),
    )
    return written
