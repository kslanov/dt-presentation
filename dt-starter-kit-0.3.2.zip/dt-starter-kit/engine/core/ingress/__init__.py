"""INGRESS-1 — плоскость входа: реестр адаптеров, общая статистика, провенанс, журнал отказов.

Новый вход = адаптер, а не подсистема (roadmap §4a, 02-architecture §10a, принцип 14): дескриптор в
:mod:`core.ingress.registry` + ``run`` + карта полей в :mod:`core.ingress.stats` + провенанс
:mod:`core.ingress.provenance` + ``refuse`` :mod:`core.ingress.refusals`.
"""
