"""INGRESS-1 п.3 — провенанс входа: что это за артефакт, откуда он и когда пришел.

Три носителя, один читатель. Заметки файлов/почты несут провенанс во frontmatter, inbox-файл
захвата — в футере (``источник: ticktick / lane / taskId / captured / modified``; его парсят
``core/ingest.py::inbox_lane`` и ``assignment.py::_FOOTER_RE`` — формат НЕ меняется). Общий
:class:`Provenance` и :func:`read_provenance` читают любой из носителей; писатели
(:func:`stamp_fields`) дописывают недостающее в frontmatter новых заметок:

    source: files | mail            # семейство адаптера
    source_id: <source_path | conversation_id>
    ingested: 2026-10-28T09:30:00Z  # когда заметка записана входом
    ingress_run: <run_id>           # общий с лентой событий

Старые заметки без новых ключей читаются выводом из имеющихся (``source_type: email-thread`` →
``mail``; ``type: legacy-source`` + ``source_path`` → ``files``); бэкфилла нет — нечем подтвердить
время, а выводимое честно помечено ``inferred=True``. Файл без провенанса → ``None``, не исключение.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

__all__ = [
    "REQUIRED",
    "Provenance",
    "read_provenance",
    "stamp_fields",
]

# Обязательные поля свежеписанного артефакта (``ingress_run``/``source_content_hash`` — по наличию).
REQUIRED = ("source", "source_id", "ingested")

_CAPTURE_FOOTER = re.compile(r"\n---\nисточник:\s*ticktick\s*\n", re.IGNORECASE)
_FOOTER_FIELD = re.compile(r"^(lane|taskId|captured|modified):\s*(.*?)\s*$", re.MULTILINE)


@dataclass(frozen=True)
class Provenance:
    source: str  # files | mail | capture
    source_id: str
    source_path: str | None = None
    source_content_hash: str | None = None
    source_modified: str | None = None
    ingested: str | None = None
    run_id: str | None = None
    inferred: bool = False  # True — поля выведены из старых ключей (до INGRESS-1)

    def missing(self) -> list[str]:
        """Обязательные поля, которых нет (пусто — провенанс полон)."""
        return [name for name in REQUIRED if not getattr(self, name)]

    @property
    def complete(self) -> bool:
        return not self.missing()


def stamp_fields(source: str, source_id: str, *, run_id: str | None = None) -> dict[str, Any]:
    """Ключи провенанса для frontmatter ПИСАТЕЛЯ: ``source``, ``source_id``, ``ingested``,
    ``ingress_run`` (run_id — из аргумента, иначе из контекста прогона; нет прогона — ключа нет)."""
    if run_id is None:
        try:
            from core.ingress.run import current_run

            run = current_run()
            run_id = run.run_id if run is not None else None
        except Exception:  # noqa: BLE001
            run_id = None
    out: dict[str, Any] = {
        "source": source,
        "source_id": source_id,
        "ingested": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    if run_id:
        out["ingress_run"] = run_id
    return out


def _s(value: Any) -> str | None:
    text = "" if value is None else str(value).strip()
    return text or None


def _from_frontmatter(fm: dict[str, Any]) -> Provenance | None:
    source = _s(fm.get("source"))
    inferred = False
    if source not in ("files", "mail"):
        # Старая заметка (до INGRESS-1): выводим семейство из имеющихся ключей.
        if _s(fm.get("source_type")) == "email-thread":
            source = "mail"
        elif fm.get("type") == "legacy-source" and _s(fm.get("source_path")):
            source = "files"
        else:
            return None
        inferred = True
    source_path = _s(fm.get("source_path"))
    source_id = _s(fm.get("source_id"))
    if source_id is None:
        source_id = _s(fm.get("conversation_id")) if source == "mail" else source_path
        source_id = source_id or source_path
        inferred = inferred or source_id is not None
    if source_id is None:
        return None
    modified = _s(fm.get("last_date")) if source == "mail" else _s(fm.get("created"))
    return Provenance(
        source=source,
        source_id=source_id,
        source_path=source_path,
        source_content_hash=_s(fm.get("source_content_hash")),
        source_modified=modified,
        ingested=_s(fm.get("ingested")),
        run_id=_s(fm.get("ingress_run")),
        inferred=inferred and not fm.get("ingested"),
    )


def _from_capture_footer(text: str) -> Provenance | None:
    match = _CAPTURE_FOOTER.search(text)
    if match is None:
        return None
    fields = {k: v for k, v in _FOOTER_FIELD.findall(text[match.start():])}
    task_id = _s(fields.get("taskId"))
    if task_id is None:
        return None
    return Provenance(
        source="capture",
        source_id=task_id,
        source_modified=_s(fields.get("modified")),
        ingested=_s(fields.get("captured")),
    )


def read_provenance(target: Any) -> Provenance | None:
    """Провенанс заметки/inbox-файла: ``Path`` (читается файл), ``Note`` (frontmatter) или ``str``
    (текст inbox-файла). Нечитаемо/нет провенанса → ``None``."""
    try:
        if isinstance(target, str):
            return _from_capture_footer(target)
        if hasattr(target, "frontmatter"):  # core.vault.Note
            return _from_frontmatter(dict(target.frontmatter))
        path = Path(target)
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError, TypeError):
        return None
    if text.startswith("---\n"):  # заметка с frontmatter
        try:
            from core.vault import read_note

            return _from_frontmatter(dict(read_note(path).frontmatter))
        except Exception:  # noqa: BLE001 — битый YAML = нет провенанса, не исключение
            return None
    return _from_capture_footer(text)
