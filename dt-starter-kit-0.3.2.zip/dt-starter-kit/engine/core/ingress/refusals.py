"""INGRESS-1 п.4 — журнал отказов входа: что адаптер отбросил и почему (предусловие MAIL-FILTER-1).

Раньше отброшенное оставалось счетчиком (``skipped_noise``) и пятью примерами в stats: разбирать
«почему письмо не вошло» (q12 EVAL-4: автоуведомления b2b_invoice новее живого треда) было нечем.
Теперь все адаптеры отказывают через :func:`refuse` — один словарь причин
(:data:`REASONS`), один файл ``.derived/ingress/refusals.jsonl`` (append; :func:`prune` срезает
старше 30 дней на старте прогона), одно чтение :func:`refusals_summary`.

**Политика подсказки (hint) — часть контракта** (:data:`HINT_POLICY`), а не вкус вызывающего:

* ``counter`` — ``privacy_personal``, ``nda_path``: ТОЛЬКО счетчик в stats, в
  журнале НИ строки (как ``личное``-захват сегодня): сама запись об отказе не должна нести
  приватное ни текстом, ни путем;
* ``rule_class`` — ``privacy_probe`` (MAIL-PRIVACY-2): строка пишется ТОЛЬКО если вызывающий дал
  КЛАСС правила (``privacy-name|privacy-term|privacy-contract``, без значения - фамилии/слова) и
  id источника; ``hint`` - лишь ``inbox|sent[ · YYYY-MM-DD]`` (папка и дата письма), любой другой
  hint отбрасывается. Тема, участники и сама фамилия в журнал не попадают. Без класса/id (OCR,
  легаси-файлы) - прежний режим: только счетчик;
* ``subject_domain`` — ``noise_sender``/``noise_subject``/``meeting_response``: тема ``[:60]`` +
  домен отправителя (адрес не пишем);
* ``path`` — файловые причины: путь ОТНОСИТЕЛЬНО корня (абсолютный путь обрезается);
* ``id`` — ``multi_thread``, ``untagged``, ``operative_tag``: только непрозрачный id источника,
  без заголовков и текстов.

Необязательное поле строки ``rule`` (MAIL-FILTER-1) - ИМЯ сработавшего правила адаптера
(``senders/b2b_invoice@acme.kz``): ключ из ``_system/mail-filter.yaml`` (данные владельца), а не
текст письма. Политики hint оно не меняет и в ``counter``-причины не попадает.

Защита в глубину: любой ``hint``/``source_id``, под NDA-барьером (``core.privacy.is_nda``),
превращает отказ в «только счетчик» независимо от причины. Повторный отказ той же единицы не
пишется заново в пределах :data:`DEDUP_H` (иначе fast-синк каждые 30 мин переписывал бы тысячи
исключенных файлов), но обновляется раз в трое суток — отказ остается в 7-дневной сводке.

Запись best-effort: журнал наблюдает за входом и не имеет права его ломать.
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Iterable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import ingress_dir

__all__ = [
    "DEDUP_H",
    "HINT_POLICY",
    "REASONS",
    "RefusalTally",
    "prune",
    "refuse",
    "refuse_many",
    "refusals_path",
    "refusals_summary",
    "subject_domain_hint",
]

logger = logging.getLogger("dt.ingress")

# Словарь причин (ТЗ п.4). Значение — политика подсказки.
HINT_POLICY: dict[str, str] = {
    "privacy_personal": "counter",
    "privacy_probe": "rule_class",
    "nda_path": "counter",
    "eval_quarantine": "counter",  # EVAL-HYGIENE-1: файл под _eval (прогон eval/selftest)
    "exclude_rule": "path",
    "noise_sender": "subject_domain",
    "noise_subject": "subject_domain",
    "meeting_response": "subject_domain",
    "multi_thread": "id",
    "untagged": "id",
    "operative_tag": "id",
    "dataless": "path",
    "interrupted": "path",
    "unsupported": "path",
    "needs_ocr": "path",
    "ocr_low_confidence": "path",  # OCR-1 п.4: предупреждение, документ в корпусе
    "needs_conversion": "path",
    "error": "path",
}
REASONS = tuple(HINT_POLICY)
HINT_MAX = 60
# privacy_probe: что вообще может лечь в строку (класс правила, а не значение; папка · дата письма)
PRIVACY_RULE_CLASSES = ("privacy-name", "privacy-term", "privacy-contract")
_PROBE_HINT_RE = re.compile(r"(inbox|sent)( · \d{4}-\d{2}-\d{2})?")
DEDUP_H = 72.0  # повтор той же единицы не пишем; раз в 3 суток обновляем (сводка — 7 дней)
KEEP_DAYS = 30
_FILE = "refusals.jsonl"
_SUMMARY_LAST = 20


def refusals_path() -> Path:
    return ingress_dir() / _FILE


class RefusalTally(dict):  # type: ignore[type-arg]
    """Счетчики отказов прогона ``{(adapter, reason): n}`` — в т.ч. для ``counter``-причин,
    которых в журнале нет: адаптер кладет итог в свою stats, не в файл."""

    def add(self, adapter: str, reason: str, n: int = 1) -> None:
        self[(adapter, reason)] = self.get((adapter, reason), 0) + n


# --------------------------------------------------------------------------- #
# Подсказки                                                                     #
# --------------------------------------------------------------------------- #
_ADDR_RE = re.compile(r"[\w.+-]+@([\w-]+(?:\.[\w-]+)+)")


def subject_domain_hint(subject: str | None, sender: str | None = None) -> str:
    """``тема[:60] · домен`` (адрес отправителя не пишем, только домен)."""
    subj = " ".join(str(subject or "").split())[:HINT_MAX]
    m = _ADDR_RE.search(str(sender or ""))
    domain = m.group(1).lower() if m else ""
    return f"{subj} · {domain}" if domain else subj


def _rel_path(value: str) -> str:
    """Путь относительно корня: абсолютный префикс (и домашний каталог) не пишем."""
    text = str(value or "").strip().replace("\\", "/")
    if text.startswith("/"):
        parts = [p for p in text.split("/") if p]
        # без корня адаптера остается только хвост пути: достаточно, чтобы найти файл, и
        # не тащит в журнал имя пользователя/устройства
        text = "/".join(parts[-4:])
    return text[:240]


def _is_nda(*values: str | None) -> bool:
    try:
        from core.privacy import is_nda

        return any(v and is_nda(v) for v in values)
    except Exception:  # noqa: BLE001 — гард приватности не должен падать, но и не должен молчать
        return True  # не смогли проверить — безопаснее считать приватным (только счетчик)


# --------------------------------------------------------------------------- #
# Запись                                                                        #
# --------------------------------------------------------------------------- #
_seen: dict[str, dict[str, float]] = {}  # путь журнала → {ключ: epoch последней записи}


def _key(adapter: str, reason: str, ident: str) -> str:
    return f"{adapter}\x1f{reason}\x1f{ident}"


def _load_seen(path: Path) -> dict[str, float]:
    cached = _seen.get(str(path))
    if cached is not None:
        return cached
    out: dict[str, float] = {}
    cutoff = datetime.now(UTC) - timedelta(hours=DEDUP_H)
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                row = json.loads(line)
                ts = datetime.strptime(row["ts"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
            except (ValueError, KeyError, TypeError):
                continue
            if ts >= cutoff:
                ident = str(row.get("source_id") or row.get("hint") or "")
                out[_key(str(row.get("adapter")), str(row.get("reason")), ident)] = ts.timestamp()
    except OSError:
        pass
    _seen[str(path)] = out
    return out


def _ctx_run_id() -> str | None:
    try:
        from core.ingress.run import current_run

        run = current_run()
        return run.run_id if run is not None else None
    except Exception:  # noqa: BLE001
        return None


def refuse_many(
    adapter: str,
    reason: str,
    items: Iterable[tuple[str | None, str | None]],
    *,
    run_id: str | None = None,
    tally: RefusalTally | None = None,
    now: datetime | None = None,
    rule: str | None = None,
) -> int:
    """Пачка отказов одной причины: ``items`` — ``(hint, source_id)``. Возвращает, сколько строк
    записано в журнал (файл открывается один раз — на тысячи исключенных файлов не 50к open).
    ``rule`` - имя сработавшего правила на всю пачку (в строку журнала, кроме ``counter``).

    ``counter``-причины и NDA-подсказки в журнал не попадают, но ``tally`` считает всё.
    """
    if reason not in HINT_POLICY:
        logger.warning("refuse: неизвестная причина %r (адаптер %s) — приведена к error",
                       reason, adapter)
        reason = "error"
    policy = HINT_POLICY[reason]
    rid = run_id or _ctx_run_id()
    moment = now or datetime.now(UTC)
    stamp = moment.strftime("%Y-%m-%dT%H:%M:%SZ")
    written = 0
    rows: list[str] = []
    try:
        path = refusals_path()
        seen = _load_seen(path) if policy != "counter" else {}
        rule_class = str(rule or "").partition(":")[0] if policy == "rule_class" else None
        for raw_hint, raw_id in items:
            if tally is not None:
                tally.add(adapter, reason)
            if policy == "counter":
                continue
            hint: str | None
            source_id: str | None
            if policy == "rule_class":
                if rule_class not in PRIVACY_RULE_CLASSES or not raw_id:
                    continue  # без класса правила/id - как counter: ни строки
                hint = raw_hint if _PROBE_HINT_RE.fullmatch(str(raw_hint or "")) else None
                source_id = raw_id
            elif policy == "path":
                hint = _rel_path(raw_hint or raw_id or "")
                source_id = hint
            elif policy == "subject_domain":
                hint = str(raw_hint or "")[: HINT_MAX + 80]  # собрано subject_domain_hint
                source_id = raw_id
            else:  # id — без подсказки: заголовков и текстов нет
                hint, source_id = None, raw_id
            source_id = str(source_id or "")[:200] or None
            if _is_nda(hint, source_id):
                continue
            key = _key(adapter, reason, source_id or hint or "")
            last = seen.get(key)
            if last is not None and moment.timestamp() - last < DEDUP_H * 3600:
                continue
            row: dict[str, Any] = {"ts": stamp, "adapter": adapter, "reason": reason}
            if hint:
                row["hint"] = hint
            if source_id:
                row["source_id"] = source_id
            if rule_class is not None:
                row["rule"] = rule_class  # только класс: значение (фамилия/слово) не пишем
            elif rule:
                row["rule"] = str(rule)[:120]
            if rid:
                row["run_id"] = rid
            rows.append(json.dumps(row, ensure_ascii=False))
            seen[key] = moment.timestamp()
            written += 1
        if rows:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as fh:
                fh.write("\n".join(rows) + "\n")
    except Exception:  # noqa: BLE001 — журнал отказов не ломает вход
        logger.debug("refusals: запись не удалась", exc_info=True)
        return 0
    return written


def refuse(
    adapter: str,
    reason: str,
    *,
    hint: str | None = None,
    source_id: str | None = None,
    run_id: str | None = None,
    tally: RefusalTally | None = None,
    now: datetime | None = None,
    rule: str | None = None,
) -> bool:
    """Зафиксировать один отказ. ``True`` — строка записана в журнал; ``False`` — только счетчик
    (политика ``counter``, NDA-подсказка, повтор в окне дедупа или сбой записи).

    ``tally`` (если дан) получает +1 в любом случае: итог прогона знает и об отказах, которых в
    журнале нет по политике приватности. Незнакомая причина приводится к ``error`` с
    предупреждением в лог — вызывающий обязан брать причину из :data:`REASONS`.
    """
    return bool(
        refuse_many(adapter, reason, [(hint, source_id)], run_id=run_id, tally=tally, now=now,
                    rule=rule)
    )


def prune(keep_days: int = KEEP_DAYS, *, now: datetime | None = None) -> int:
    """Срезать строки старше ``keep_days`` (на старте прогона). Возвращает, сколько срезано."""
    path = refusals_path()
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return 0
    cutoff = (now or datetime.now(UTC)) - timedelta(days=keep_days)
    kept: list[str] = []
    for line in lines:
        try:
            ts = datetime.strptime(json.loads(line)["ts"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
        except (ValueError, KeyError, TypeError):
            kept.append(line)  # непонятную строку чистка не трогает — разбирает человек
            continue
        if ts >= cutoff:
            kept.append(line)
    dropped = len(lines) - len(kept)
    if dropped:
        try:
            tmp = path.with_suffix(".jsonl.tmp")
            tmp.write_text("".join(f"{ln}\n" for ln in kept), encoding="utf-8")
            tmp.replace(path)
            _seen.pop(str(path), None)
        except OSError:
            return 0
    return dropped


# --------------------------------------------------------------------------- #
# Чтение                                                                        #
# --------------------------------------------------------------------------- #
def refusals_summary(
    days: int = 7, *, now: datetime | None = None, path: Path | None = None
) -> dict[str, Any]:
    """``{days, total, by_adapter: {adapter: {reason: n}}, last: [≤20 строк], last_by_adapter}``.

    Журнала нет → нули (отказов не было). Файл есть, но не читается (или в нем нет ни одной
    разбираемой строки) → ``warning`` с кодом ``store_unavailable`` (§9 п.22): тишина здесь
    означала бы «ничего не отбрасывалось» — ровно то, что журнал и призван проверять.
    """
    target = Path(path) if path is not None else refusals_path()
    out: dict[str, Any] = {
        "days": days, "total": 0, "by_adapter": {}, "last": [], "last_by_adapter": {},
    }
    if not target.is_file():
        return out
    try:
        lines = [ln for ln in target.read_text(encoding="utf-8").splitlines() if ln.strip()]
    except (OSError, UnicodeDecodeError) as exc:
        return _unavailable(out, target, str(exc)[:120])
    cutoff = (now or datetime.now(UTC)) - timedelta(days=days)
    rows: list[dict[str, Any]] = []
    parsed = 0
    for line in lines:
        try:
            row = json.loads(line)
            ts = datetime.strptime(row["ts"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
            adapter, reason = str(row["adapter"]), str(row["reason"])
        except (ValueError, KeyError, TypeError):
            continue
        parsed += 1
        if ts >= cutoff:
            rows.append({**row, "adapter": adapter, "reason": reason})
    if lines and not parsed:
        return _unavailable(out, target, "в журнале нет ни одной разбираемой строки")
    for row in rows:
        bucket = out["by_adapter"].setdefault(row["adapter"], {})
        bucket[row["reason"]] = bucket.get(row["reason"], 0) + 1
    out["total"] = len(rows)
    def brief(row: dict[str, Any]) -> dict[str, Any]:
        keys = ("ts", "adapter", "reason", "rule", "hint", "source_id")
        return {k: row[k] for k in keys if k in row}

    out["last"] = [brief(row) for row in rows[-_SUMMARY_LAST:][::-1]]
    # последние 20 ПО КАЖДОМУ адаптеру — для строк источников панели «Хранилище»
    out["last_by_adapter"] = {}
    for adapter in out["by_adapter"]:
        mine = [x for x in rows if x["adapter"] == adapter]
        out["last_by_adapter"][adapter] = [brief(r) for r in mine[-_SUMMARY_LAST:][::-1]]
    return out


def _unavailable(out: dict[str, Any], target: Path, why: str) -> dict[str, Any]:
    from core.contract import CODE_STORE_UNAVAILABLE, add_warning

    return add_warning(
        out, CODE_STORE_UNAVAILABLE,
        f"журнал отказов не прочитался: {target} — {why}; счетчики НЕ собраны "
        "(ноль здесь означал бы «ничего не отбрасывалось»)",
        journal=str(target),
    )
