"""INGRESS-1 п.1 — реестр адаптеров входа: ОДНО место, где перечислены источники.

Раньше источники входа были перечислены руками в пяти местах (шаги ``dt_sync``, свежесть,
``ingest_sources``/``INGEST_OPS``, ``SUBMITTABLE_OPS``, чеки доктора), и новый вход = правка пяти
файлов. Теперь — дескриптор :class:`IngressAdapter` здесь, а потребители ПРОИЗВОДЯТ свои списки из
:data:`ADAPTERS` (и подписываются на изменения реестра: ``register``/``unregister`` обновляют их на
лету — на этом стоит гард невакуумности, тест подкладывает фиктивный адаптер).

Имена шагов ``dt_sync`` и ``ops`` JOB-1 НЕ меняются: на них завязаны launchd-логи, свежесть,
пульт и ``test_sync_steps``. Не-входные шаги (``reconcile``, ``link_auto``, ``hub_scan``,
``reindex_inc``, ``eval``, ``doctor``) в реестр не входят — они остаются в ``dt_sync`` как есть.

``run`` — тонкая обертка над существующей точкой входа (``pull_capture``, ``ingest_mail``,
``scan``, ``ingest_corpus``) с общей сигнатурой ``(dry_run, limit, should_stop, on_progress,
**adapter_args) -> IngressStats``. Не все родные функции умеют ``limit``/``should_stop`` (``scan``
останавливается по SIGTERM, ``pull_capture`` — один быстрый запрос): неподдержанное обертка
молча не имитирует, а игнорирует (см. docstring каждой). Зеркало Timetta — только дескриптор
(``run=None``): оно в ``dt_status --refresh``, заметок не пишет.
"""

from __future__ import annotations

import contextlib
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.ingress.run import ingress_run
from core.ingress.stats import IngressStats

__all__ = [
    "ADAPTERS",
    "IngressAdapter",
    "RunFn",
    "adapters",
    "get",
    "ingest_ops",
    "refresh",
    "register",
    "subscribe",
    "temporary",
    "unregister",
]

KINDS = ("inbox", "note", "registry", "mirror")
MODES = ("fast", "index", "manual")
RunFn = Callable[..., IngressStats]
PathFn = Callable[[], Path]


@dataclass(frozen=True)
class IngressAdapter:
    """Дескриптор входа. ``kind``: ``inbox`` (inbox-файл), ``note`` (заметка vault), ``registry``
    (запись реестра источников без заметки), ``mirror`` (зеркало внешней системы)."""

    key: str
    label: str
    kind: str
    mode: str  # fast | index | manual (запускается руками/из пульта, без шага расписания)
    step: str | None  # шаг dt_sync (имя прежнее)
    op: str | None  # JOB-1 op (``submit_job(op, {"mode": "light"|"full"})``)
    state_paths: tuple[PathFn, ...]
    stale_after_h: float | None  # порог «протух» (свежесть/доктор); None — не отслеживается
    order: int  # порядок шага внутри режима
    run: RunFn | None
    # --- поля для потребителей (чтобы у них не осталось своих копий таблиц) ---
    ingest_key: str | None = None  # ключ INGEST_OPS / источника панели «Хранилище»
    freshness_key: str | None = None  # имя источника в плитке «Свежесть» (None — не показывать)
    fresh_order: int = 100  # позиция строки в «Свежести»
    sync_steps: tuple[str, ...] = ()  # шаги точечной кнопки «обновить» (режим — ``mode``)
    map_key: str | None = None  # ключ в ``stats.FIELD_MAPS`` (по умолчанию — ``key``)
    storage_row: bool = True  # показывать фиксированной строкой в ``ingest_sources``
    storage_order: int = 100  # позиция строки в панели «Хранилище»
    storage_extra: Callable[[], dict[str, Any]] | None = None  # доп. поля строки (roots/exists)
    extra: dict[str, Any] = field(default_factory=dict)
    # PERSONAL-3: роли экземпляров, у которых есть этот вход (манифест роли читает отсюда)
    roles: tuple[str, ...] = ("work",)
    # DEV-3-CORE: коннектор, которому принадлежит вход (``core.connectors``): выключен - адаптера
    # нет в ``adapters()`` (шаг dt_sync пропущен, строки свежести/«Хранилища» не показаны);
    # ``None`` - вход без внешнего сервиса (файлы, легаси)
    connector: str | None = None

    def __post_init__(self) -> None:
        if self.kind not in KINDS:
            raise ValueError(f"adapter {self.key!r}: kind {self.kind!r} не из {KINDS}")
        if self.mode not in MODES:
            raise ValueError(f"adapter {self.key!r}: mode {self.mode!r} не из {MODES}")


# --------------------------------------------------------------------------- #
# Реестр                                                                        #
# --------------------------------------------------------------------------- #
ADAPTERS: dict[str, IngressAdapter] = {}
_listeners: list[Callable[[], None]] = []


def subscribe(callback: Callable[[], None]) -> None:
    """Потребитель просит вызвать ``callback`` при изменении реестра (и вызывает его сразу сам)."""
    if callback not in _listeners:
        _listeners.append(callback)


def _notify() -> None:
    for cb in list(_listeners):
        cb()


def refresh() -> None:
    """Потребители пересобирают свои списки из реестра (сменилось то, что реестр читает снаружи:
    ``DT_CONNECTORS``, роль процесса)."""
    _notify()


def register(adapter: IngressAdapter, *, replace: bool = False) -> None:
    if adapter.key in ADAPTERS and not replace:
        raise ValueError(f"adapter {adapter.key!r} уже зарегистрирован")
    ADAPTERS[adapter.key] = adapter
    _notify()


def unregister(key: str) -> None:
    ADAPTERS.pop(key, None)
    _notify()


@contextlib.contextmanager
def temporary(adapter: IngressAdapter) -> Iterator[IngressAdapter]:
    """Подложить адаптер на время (тесты невакуумности): везде появился — везде исчез."""
    register(adapter)
    try:
        yield adapter
    finally:
        unregister(adapter.key)


def get(key: str) -> IngressAdapter:
    return ADAPTERS[key]


def connector_enabled(adapter: IngressAdapter) -> bool:
    """Включен ли коннектор адаптера (вход без коннектора - всегда)."""
    if adapter.connector is None:
        return True
    from core import connectors

    return connectors.enabled(adapter.connector)


def adapters(
    mode: str | None = None, role: str | None = None, *, enabled_only: bool = True,
) -> list[IngressAdapter]:
    """Адаптеры (по ``mode`` и ``role``, если заданы) в порядке ``order``, затем ключа.

    ``role=None`` - все (как до PERSONAL-3); потребители экземпляра передают его роль.
    DEV-3-CORE: адаптеры выключенных коннекторов не отдаются (``enabled_only=False`` - весь
    реестр: ops JOB-1 и конверт ``connector_disabled`` должны знать и о выключенных)."""
    rows = [a for a in ADAPTERS.values()
            if (mode is None or a.mode == mode) and (role is None or role in a.roles)
            and (not enabled_only or connector_enabled(a))]
    return sorted(rows, key=lambda a: (a.order, a.key))


def ingest_ops(role: str | None = None, *, enabled_only: bool = False) -> dict[str, str]:
    """``{ingest_key: op}`` — то, что раньше было ``storage.INGEST_OPS`` (по роли, если задана).

    Таблица ops полная (выключенный коннектор отказывает на ``submit_job``, а не «нет op»)."""
    return {a.ingest_key: a.op for a in adapters(role=role, enabled_only=enabled_only)
            if a.ingest_key and a.op}


# --------------------------------------------------------------------------- #
# run-обертки над существующими точками входа                                   #
# --------------------------------------------------------------------------- #
def _wrapped(key: str, call: Callable[..., Any]) -> RunFn:
    def run(
        dry_run: bool = True,
        limit: int | None = None,
        should_stop: Callable[[], bool] | None = None,
        on_progress: Callable[[str], None] | None = None,
        **args: Any,
    ) -> IngressStats:
        with ingress_run(key, dry_run=dry_run) as handle:
            native = call(dry_run=dry_run, limit=limit, should_stop=should_stop,
                          on_progress=on_progress, **args)
            return handle.finish(native)

    run.__name__ = f"run_{key.replace(':', '_')}"
    run.__doc__ = f"Прогон адаптера {key!r} → IngressStats (limit/should_stop — см. модуль)."
    return run


def _call_capture(*, dry_run: bool, **_ignored: Any) -> Any:
    """``pull_capture``: один быстрый запрос, ``limit``/``should_stop`` не поддерживает."""
    from core.operational.ticktick.connector import TickTickConnector

    return TickTickConnector.from_env().pull_capture(dry_run=dry_run)


def _call_mail(
    *, dry_run: bool, limit: int | None, should_stop: Any, on_progress: Any,
    since: str | None = None, scope: str = "incremental", **args: Any,
) -> Any:
    from core.config import default_vault_path
    from core.legacy.mail import ingest_mail
    from core.operational.outlook_bridge import OutlookBridge

    return ingest_mail(
        default_vault_path(), OutlookBridge(require_preflight=True), since=since or None,
        scope=scope, dry_run=dry_run, limit=limit, should_stop=should_stop,
        on_progress=on_progress, **args,
    )


def _call_files(route: str) -> Callable[..., Any]:
    def call(
        *, dry_run: bool, on_progress: Any, root: str | None = None,
        reindex: bool | None = None, **_ignored: Any,
    ) -> Any:
        """``scan``: прогресс в ``on_progress``; ``limit``/``should_stop`` не поддерживает
        (останавливается по SIGTERM с сохранением чекпойнта)."""
        from core.config import default_vault_path
        from core.file_ingest import scan

        extra = {} if reindex is None else {"reindex": reindex}  # дефолт scan — reindex=True
        return scan(
            vault_path=default_vault_path(), root_name=root or None, route=route,
            dry_run=dry_run, log=on_progress, **extra,
        )

    return call


def _call_legacy(
    *, dry_run: bool, limit: int | None, scope: str = "incremental",
    root: str | None = None, **_ignored: Any,
) -> Any:
    """``ingest_corpus``: ``should_stop`` не поддерживает; ``limit`` — канареечный батч."""
    from core.config import default_vault_path, legacy_roots
    from core.legacy.ingest import ingest_corpus

    roots = [Path(root)] if root else legacy_roots()
    return ingest_corpus(
        default_vault_path(), roots, scope=scope, dry_run=dry_run, limit=limit,
        prune=limit is None,
    )


def _legacy_storage_extra() -> dict[str, Any]:
    """Поля строки «Легаси-корпус» панели «Хранилище»: корни и существование на этом устройстве."""
    from core.config import legacy_roots

    roots = [str(p) for p in legacy_roots()]
    return {
        "roots": roots,
        "exists": bool(roots) and all(Path(p).exists() for p in roots),
        "configured": bool(roots),
    }


def _builtin() -> list[IngressAdapter]:
    from core.config import (
        file_ingest_manifest_path,
        legacy_ingest_manifest_path,
        outlook_ingest_manifest_path,
        ticktick_state_path,
        timetta_mirror_path,
    )

    return [
        IngressAdapter(
            key="timetta", label="Timetta (зеркало, только чтение)", kind="mirror", mode="fast",
            step="refresh", op=None,
            state_paths=(lambda: timetta_mirror_path() / "cursor.json",),
            stale_after_h=26.0, order=10, run=None,
            freshness_key="timetta", fresh_order=20, sync_steps=("refresh", "reconcile"),
            storage_row=False, connector="timetta",
        ),
        IngressAdapter(
            key="capture", label="Захваты (TickTick)", kind="inbox", mode="fast",
            step="pull_capture", op="ingest_capture",
            state_paths=(lambda: ticktick_state_path() / "capture_state.json",),
            stale_after_h=26.0, order=20, run=_wrapped("capture", _call_capture),
            ingest_key="capture", freshness_key="ticktick", fresh_order=30,
            sync_steps=("pull_capture",), storage_order=30, roles=("work", "personal"),
            connector="ticktick",
        ),
        IngressAdapter(
            key="files:operational", label="Файлы: оперативные корни (реестр источников)",
            kind="registry", mode="fast", step="file_ingest", op="ingest_operational",
            state_paths=(file_ingest_manifest_path,), stale_after_h=None, order=30,
            run=_wrapped("files:operational", _call_files("operational")),
            ingest_key="operational", storage_row=False,  # строки — из ingest-roots.yaml
        ),
        IngressAdapter(
            key="mail", label="Почта (Outlook)", kind="note", mode="fast", step="mail_ingest",
            op="ingest_mail", state_paths=(outlook_ingest_manifest_path,), stale_after_h=26.0,
            order=40, run=_wrapped("mail", _call_mail), ingest_key="mail",
            freshness_key="mail", fresh_order=10, sync_steps=("mail_ingest",), storage_order=20,
            connector="outlook",
        ),
        IngressAdapter(
            key="files:knowledge", label="Файлы: знаниевые корни (заметки + индекс)", kind="note",
            mode="index", step="file_ingest_knowledge", op="ingest_knowledge",
            state_paths=(file_ingest_manifest_path,), stale_after_h=48.0, order=10,
            run=_wrapped("files:knowledge", _call_files("knowledge")),
            ingest_key="knowledge", freshness_key="files:knowledge", fresh_order=60,
            sync_steps=("file_ingest_knowledge",), storage_row=False, roles=("work", "personal"),
        ),
        IngressAdapter(
            key="legacy", label="Легаси-корпус (Bitrix)", kind="note", mode="manual", step=None,
            op="ingest_legacy", state_paths=(legacy_ingest_manifest_path,), stale_after_h=None,
            order=0, run=_wrapped("legacy", _call_legacy), ingest_key="legacy",
            storage_order=10, storage_extra=_legacy_storage_extra,
        ),
    ]


for _adapter in _builtin():
    ADAPTERS[_adapter.key] = _adapter
