"""INGRESS-1 — контекст прогона адаптера и итоги последних прогонов.

``ingress_run(adapter)`` — обертка вокруг ЛЮБОГО входа (CLI, JOB-1, ``run`` из реестра): минтит
``run_id`` (общий с лентой событий), чистит журнал отказов старше 30 дней, кладет контекст в
``ContextVar`` (``refuse``/события берут ``run_id`` отсюда) и по ``finish(native)`` пишет общий итог
:class:`~core.ingress.stats.IngressStats` в ``.derived/ingress/last_runs.json`` — оттуда его читают
доктор и пульт. Всё best-effort: учет прогона не имеет права ломать сам прогон.
"""

from __future__ import annotations

import contextlib
import contextvars
import fcntl
import json
import logging
import time
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import ingress_dir
from core.ingress.stats import IngressStats, convert

__all__ = [
    "RunHandle",
    "current_run",
    "ingress_run",
    "last_runs_path",
    "read_last_runs",
    "record_last_run",
]

logger = logging.getLogger("dt.ingress")
_current: contextvars.ContextVar[RunHandle | None] = contextvars.ContextVar(
    "dt_ingress_run", default=None
)


def last_runs_path() -> Path:
    return ingress_dir() / "last_runs.json"


@dataclass
class RunHandle:
    adapter: str
    run_id: str
    dry_run: bool = False
    started: float = field(default_factory=time.perf_counter)
    stats: IngressStats | None = None

    def finish(self, native: Any, *, map_key: str | None = None) -> IngressStats:
        """Родной итог → общий :class:`IngressStats` + запись в ``last_runs.json``."""
        out = convert(self.adapter, native, map_key=map_key, run_id=self.run_id,
                      elapsed_s=time.perf_counter() - self.started)
        out.dry_run = bool(out.dry_run or self.dry_run)
        self.stats = out
        record_last_run(out)
        return out


def current_run() -> RunHandle | None:
    return _current.get()


@contextlib.contextmanager
def ingress_run(adapter: str, *, dry_run: bool = False) -> Iterator[RunHandle]:
    """Контекст прогона: ``run_id``, чистка журнала отказов, ``ContextVar`` для ``refuse``."""
    from core.eventlog import new_run_id
    from core.ingress.refusals import prune

    handle = RunHandle(adapter=adapter, run_id=new_run_id(), dry_run=dry_run)
    try:
        prune()  # старше 30 дней — на старте прогона (best-effort внутри)
    except Exception:  # noqa: BLE001
        logger.debug("ingress: prune не удался", exc_info=True)
    token = _current.set(handle)
    try:
        yield handle
    finally:
        _current.reset(token)


@contextlib.contextmanager
def _locked(path: Path) -> Iterator[None]:
    lock = path.with_suffix(path.suffix + ".lock")
    lock.parent.mkdir(parents=True, exist_ok=True)
    with lock.open("a+") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def read_last_runs(path: Path | None = None) -> dict[str, dict[str, Any]]:
    """``{adapter: {"last": {...}, "last_apply": {...}}}``; нет файла/битый → ``{}``."""
    target = Path(path) if path is not None else last_runs_path()
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def record_last_run(stats: IngressStats, path: Path | None = None) -> None:
    """Запомнить итог прогона: ``last`` (любой) и ``last_apply`` (не dry-run). Best-effort."""
    target = Path(path) if path is not None else last_runs_path()
    entry = {**stats.to_dict(), "ts": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")}
    try:
        with _locked(target):
            data = read_last_runs(target)
            slot = data.setdefault(stats.adapter, {})
            slot["last"] = entry
            if not stats.dry_run:
                slot["last_apply"] = entry
            tmp = target.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1, sort_keys=True),
                           encoding="utf-8")
            tmp.replace(target)
    except Exception:  # noqa: BLE001 — учет прогона не ломает прогон
        logger.debug("ingress: last_runs не записан", exc_info=True)
