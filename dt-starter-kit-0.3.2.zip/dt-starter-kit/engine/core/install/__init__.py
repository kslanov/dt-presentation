"""DEV-3-KIT - ``dt install`` / ``dt uninstall``: фаза 1 инсталлера (технический сетап).

Оркестратор НАД существующими командами движка, а не их копия: каждый шаг (:mod:`.steps`) зовет
готовую функцию/CLI (``dt config``, ``dt vault``, ``dt owner``, ``dt host-config``, ``dt_sync``,
``dt doctor``, ``ops/launchd/*.plist``) и добавляет к ним три вещи - ``check()`` (что уже сделано,
только чтение), порядок и состояние (``.derived/install/state.json``: где остановились, чем
кончилось, проценты скачивания). Все внешние вызовы (подпроцессы, ``launchctl``, Desktop,
``snapshot_download``, ввод) приходят через :class:`.context.Tools` - тесты подставляют подделки.
"""

from __future__ import annotations

from core.install.base import InstallError, Step, StepCheck, StepResult

__all__ = ["InstallError", "Step", "StepCheck", "StepResult"]
