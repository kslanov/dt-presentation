"""Базовые типы шага установки: :class:`Step` (``check`` + ``run`` + пояснение), отказ."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from core.install.context import InstallContext

__all__ = ["DONE", "PARTIAL", "ABSENT", "InstallError", "Step", "StepCheck", "StepResult"]

DONE, PARTIAL, ABSENT = "done", "partial", "absent"


class InstallError(Exception):
    """Шаг не выполнен: машинный ``code``, причина и ``hint`` - что сделать человеку."""

    def __init__(self, code: str, reason: str, hint: str = "") -> None:
        super().__init__(f"{code}: {reason}")
        self.code, self.reason, self.hint = code, reason, hint


@dataclass(frozen=True)
class StepCheck:
    """Итог ``check()`` (только чтение): ``done`` - сделано, ``partial`` - начато, ``absent``."""

    state: str
    reason: str = ""

    @property
    def done(self) -> bool:
        return self.state == DONE


@dataclass
class StepResult:
    """Итог ``run()``: ``output`` - хвост вывода для ``state.json``, ``note`` - строка человеку."""

    output: str = ""
    note: str = ""
    skipped: bool = False
    details: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class Step:
    name: str
    title: str
    explain: str
    check: Callable[[InstallContext], StepCheck]
    run: Callable[[InstallContext], StepResult]
    #: что вызывает шаг (для отчета/справки): существующие команды движка
    calls: str = ""
