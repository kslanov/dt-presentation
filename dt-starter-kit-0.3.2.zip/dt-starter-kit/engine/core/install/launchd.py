"""Шаг ``launchd``: плановые задания по манифесту (``core.surface.manifest.launchd_jobs``).

Состав: ``server``, ``sync.fast``, ``sync.index``, ``backup`` - всегда; ``meetings`` - только при
коннекторе ``outlook`` (по ``.env`` ЦЕЛИ, а не окружению процесса); ``smoke`` и ``run.watchdog`` -
``--ops-full`` (владельцу; новому человеку не ставятся). Плисты - из ``ops/launchd/*.plist`` с
подстановкой путей (как делал ``ops/install_launchd.sh``, который теперь - тонкая обертка над
``dt install --step launchd --ops-full``), загрузка ``launchctl``, проверка ``launchctl list``.

Идемпотентность: плист переписывается и перезагружается только если изменился или не загружен;
повтор на готовом составе ничего не трогает (демон не перезапускается зря). Снятые устаревшие
задания (``com.dt.sync.full``, ``com.dt.webpult``) убираются, как раньше.

Рабочий демон слушает ``0.0.0.0`` (пульт с телефона по Wi-Fi/Tailscale) ТОЛЬКО с ``--ops-full``
(так ставит владелец); у остальных - ``127.0.0.1``: сетевой доступ к пульту - явное решение.
"""

from __future__ import annotations

import plistlib
import re
from pathlib import Path
from typing import Any

from core.install.base import ABSENT, DONE, PARTIAL, InstallError, StepCheck, StepResult
from core.install.context import InstallContext
from core.surface import manifest

__all__ = [
    "LEGACY_LABELS", "expected_jobs", "installed_labels", "jobs_dir", "label_of",
    "launchd_step_check", "launchd_step_run", "loaded_labels", "remove_labels", "render_plist",
]

LEGACY_LABELS = ("com.dt.sync.full", "com.dt.webpult")  # заменены (fast/index и com.dt.server)
_PLACEHOLDERS = ("__ENGINE_DIR__", "__UV_BIN_DIR__")
_LISTED = re.compile(r"^\S+\s+\S+\s+(?P<label>\S+)$", re.M)


def label_of(key: str) -> str:
    return f"com.dt.{key}"


def jobs_dir(ctx: InstallContext) -> Path:
    return ctx.home / "Library" / "LaunchAgents"


def expected_jobs(ctx: InstallContext) -> list[str]:
    """Ключи заданий, которые должны стоять: из манифеста по ``.env`` цели и ``--ops-full``."""
    return manifest.launchd_jobs(ops_full=ctx.ops_full, environ=ctx.environ())


def _uv_bin_dir(ctx: InstallContext) -> str:
    found = ctx.tools.probe.which("uv")
    return str(Path(found).parent) if found else str(ctx.home / ".local" / "bin")


def render_plist(
    ctx: InstallContext, key: str, *, uv_bin_dir: str | None = None,
) -> dict[str, Any]:
    """Плист задания ``key`` (словарь): шаблон с подставленными путями, логи - в derived цели."""
    src = ctx.engine_dir / "ops" / "launchd" / f"{label_of(key)}.plist"
    if not src.is_file():
        raise InstallError("launchd", f"нет шаблона {src}",
                           "это не полный набор engine/ops/launchd")
    text = src.read_text(encoding="utf-8")
    text = text.replace("__ENGINE_DIR__", str(ctx.engine_dir)).replace(
        "__UV_BIN_DIR__", uv_bin_dir or _uv_bin_dir(ctx))
    data = plistlib.loads(text.encode("utf-8"))
    if not isinstance(data, dict):
        raise InstallError("launchd", f"{src.name}: не словарь plist")
    logs = ctx.derived / "logs"
    for field in ("StandardOutPath", "StandardErrorPath"):
        if field in data:
            data[field] = str(logs / Path(str(data[field])).name)
    args = list(data.get("ProgramArguments") or [])
    if key == "server" and not ctx.ops_full and "--host" in args:
        args[args.index("--host") + 1] = "127.0.0.1"
        data["ProgramArguments"] = args
    return data


def _read_plist(path: Path) -> dict[str, Any] | None:
    try:
        data = plistlib.loads(path.read_bytes())
    except (OSError, plistlib.InvalidFileException, ValueError):
        return None
    return data if isinstance(data, dict) else None


def loaded_labels(ctx: InstallContext) -> set[str]:
    """Метки, загруженные в launchd (``launchctl list``, только чтение)."""
    code, out = ctx.tools.launchctl(["list"])
    if code != 0:
        return set()
    return {m.group("label") for m in _LISTED.finditer(out)}


def installed_labels(ctx: InstallContext) -> list[str]:
    """Метки ``com.dt.*`` с плистом в LaunchAgents ЭТОЙ установки (их ``WorkingDirectory`` -
    наш engine): чужой checkout не наш и не трогается."""
    out: list[str] = []
    base = jobs_dir(ctx)
    if not base.is_dir():
        return out
    for path in sorted(base.glob("com.dt.*.plist")):
        data = _read_plist(path)
        if data is not None and str(data.get("WorkingDirectory")) == str(ctx.engine_dir):
            out.append(path.stem)
    return out


def launchd_step_check(ctx: InstallContext) -> StepCheck:
    keys = expected_jobs(ctx)
    loaded = loaded_labels(ctx)
    good: list[str] = []
    bad: list[str] = []
    for key in keys:
        label = label_of(key)
        data = _read_plist(jobs_dir(ctx) / f"{label}.plist")
        if data is None:
            bad.append(f"{label}: нет плиста")
        elif any(ph in str(data) for ph in _PLACEHOLDERS):
            bad.append(f"{label}: не подставлены пути")
        elif str(data.get("WorkingDirectory")) != str(ctx.engine_dir):
            bad.append(f"{label}: плист смотрит в другой engine")
        elif label not in loaded:
            bad.append(f"{label}: не загружен")
        else:
            good.append(label)
    if not bad:
        return StepCheck(DONE, f"загружены {len(good)}: " + ", ".join(good))
    state = PARTIAL if good else ABSENT
    return StepCheck(state, "; ".join(bad))


def _same(a: dict[str, Any] | None, b: dict[str, Any]) -> bool:
    return a is not None and plistlib.dumps(a, sort_keys=True) == plistlib.dumps(b, sort_keys=True)


def _launchctl(ctx: InstallContext, *argv: str) -> int:
    return ctx.tools.launchctl(list(argv))[0]


def launchd_step_run(ctx: InstallContext) -> StepResult:
    base = jobs_dir(ctx)
    ctx.guard(base, ctx.derived)
    base.mkdir(parents=True, exist_ok=True)
    (ctx.derived / "logs").mkdir(parents=True, exist_ok=True)
    notes: list[str] = []
    loaded = loaded_labels(ctx)
    for label in LEGACY_LABELS:  # миграция: заменены fast/index и com.dt.server
        legacy = base / f"{label}.plist"
        if legacy.is_file():
            _launchctl(ctx, "unload", str(legacy))
            legacy.unlink()
            notes.append(f"снят устаревший {label}")
        elif label in loaded:
            _launchctl(ctx, "remove", label)
            notes.append(f"снят устаревший {label} (без файла)")
    uv_dir = _uv_bin_dir(ctx)
    changed: list[str] = []
    for key in expected_jobs(ctx):
        label = label_of(key)
        target = base / f"{label}.plist"
        want = render_plist(ctx, key, uv_bin_dir=uv_dir)
        if _same(_read_plist(target), want) and label in loaded:
            continue
        target.write_bytes(plistlib.dumps(want, sort_keys=False))
        _launchctl(ctx, "unload", str(target))
        code = _launchctl(ctx, "load", "-w", str(target))
        if code != 0:
            raise InstallError("launchd", f"launchctl load {label} вернул {code}",
                               "посмотри `launchctl list | grep dt` и повтори: "
                               "dt install --step launchd")
        changed.append(label)
    note = (f"загружено {len(changed)}: {', '.join(changed)}" if changed
            else "все задания уже загружены (без изменений)")
    return StepResult(output="; ".join([*notes, note]), note="; ".join([*notes, note]))


def remove_labels(ctx: InstallContext, labels: list[str]) -> list[str]:
    """``unload`` + удаление плиста для каждой метки ЭТОЙ установки; возвращает снятые."""
    removed: list[str] = []
    for label in labels:
        path = jobs_dir(ctx) / f"{label}.plist"
        if not path.is_file():
            continue
        _launchctl(ctx, "unload", str(path))
        path.unlink()
        removed.append(label)
    return removed
