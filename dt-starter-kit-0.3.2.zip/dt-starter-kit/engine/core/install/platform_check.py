"""Шаг ``platform``: macOS ≥ 14, arm64/x86_64, свободное место, ``uv``, ``git``, Python из ``uv``.

Только проверка и подсказка: ``uv``/Xcode CLT/``brew`` установщик НЕ ставит (решение ТЗ DEV-3-KIT) -
отказ называет команду, которую человек выполнит сам. Факты о машине - через :class:`PlatformProbe`
(тесты подставляют «не macOS», «мало места»).
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
from collections.abc import Sequence
from pathlib import Path

__all__ = ["MIN_MACOS", "NEED_FREE_GIB", "PlatformProbe", "evaluate"]

MIN_MACOS = 14
NEED_FREE_GIB = 12.0  # модели ~4.5 ГБ + индекс + запас на первую индексацию
NEED_FREE_WITH_MODELS_GIB = 2.0  # модели уже на диске: нужен только индекс
SUPPORTED_ARCH = ("arm64", "x86_64")
_GIB = 1024**3

UV_HINT = ("поставь uv: curl -LsSf https://astral.sh/uv/install.sh | sh "
           "(затем открой новый терминал)")
GIT_HINT = "поставь git: xcode-select --install (Command Line Tools) и повтори"


class PlatformProbe:
    """Факты о машине; каждый метод - одна проба (подменяется в тестах целиком)."""

    def system(self) -> str:
        return platform.system()

    def mac_version(self) -> str:
        return platform.mac_ver()[0]

    def machine(self) -> str:
        return platform.machine()

    def free_bytes(self, path: Path) -> int:
        probe = Path(path)
        while not probe.exists() and probe != probe.parent:
            probe = probe.parent
        return shutil.disk_usage(probe).free

    def which(self, name: str) -> str | None:
        return shutil.which(name)

    def uv_python(self, cwd: Path) -> str | None:
        """Путь Python, который выберет ``uv`` для проекта (``uv python find``); нет - ``None``."""
        argv: Sequence[str] = ["uv", "python", "find"]
        try:
            done = subprocess.run(argv, cwd=str(cwd), capture_output=True, text=True,  # noqa: S603
                                  timeout=30, check=False,
                                  env={k: v for k, v in os.environ.items() if k != "VIRTUAL_ENV"})
        except (OSError, subprocess.SubprocessError):
            return None
        out = done.stdout.strip().splitlines()
        return out[-1] if done.returncode == 0 and out else None


def _major(version: str) -> int:
    head = version.split(".", 1)[0]
    return int(head) if head.isdigit() else 0


def evaluate(probe: PlatformProbe, *, workspace: Path, engine_dir: Path,
             models_present: bool = False) -> tuple[list[str], list[str]]:
    """``(замечания, подсказки)``: пусто - машина подходит; порядок - от главного к мелкому."""
    problems: list[str] = []
    hints: list[str] = []
    if probe.system() != "Darwin":
        return [f"система {probe.system() or '?'}: поддерживается только macOS"], [
            "Linux/Windows - отдельная ветка, в этой версии не входит"]
    ver = probe.mac_version()
    if _major(ver) < MIN_MACOS:
        problems.append(f"macOS {ver or '?'}: нужна {MIN_MACOS} или новее")
        hints.append("обнови macOS (Системные настройки → Основные → Обновление ПО)")
    if probe.machine() not in SUPPORTED_ARCH:
        problems.append(f"архитектура {probe.machine() or '?'}: нужна arm64 или x86_64")
    need = NEED_FREE_WITH_MODELS_GIB if models_present else NEED_FREE_GIB
    free = probe.free_bytes(workspace) / _GIB
    if free < need:
        problems.append(f"свободно {free:.1f} ГБ, нужно не меньше {need:g} ГБ")
        hints.append("освободи место на диске, где лежит рабочая папка, и повтори")
    if probe.which("uv") is None:
        problems.append("нет uv")
        hints.append(UV_HINT)
    if probe.which("git") is None:
        problems.append("нет git")
        hints.append(GIT_HINT)
    if probe.which("uv") is not None and probe.uv_python(engine_dir) is None:
        problems.append("uv не нашел Python для проекта")
        hints.append("uv python install 3.12 (uv сам скачает Python, sudo не нужен)")
    return problems, hints
