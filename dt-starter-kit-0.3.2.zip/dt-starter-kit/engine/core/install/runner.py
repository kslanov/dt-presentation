"""Оркестратор ``dt install``: порядок, возобновление, ``--check``, ``--dry-run``, состояние.

* без аргументов - с первого незавершенного шага (``check()`` по фактам, а не по ``state.json``);
* ``--step <имя>`` - один шаг (выполняется, даже если уже сделан: шаги идемпотентны);
* ``--from <имя>`` - с этого шага и дальше (готовые пропускаются);
* ``--check`` / ``--dry-run`` - ничего не пишут (ни состояния, ни файлов цели);
* ошибка шага - код выхода 1, причина, «что сделать» и команда повтора; ``sudo`` нигде нет.
"""

from __future__ import annotations

import json
import traceback
from collections.abc import Sequence
from dataclasses import dataclass

from core.install.base import ABSENT, DONE, PARTIAL, InstallError, Step, StepCheck
from core.install.context import InstallContext

__all__ = ["Row", "check_rows", "render_table", "run_install"]

_LABEL = {DONE: "сделано", PARTIAL: "частично", ABSENT: "нет"}
_MARK = {DONE: "✓", PARTIAL: "~", ABSENT: "·"}


@dataclass(frozen=True)
class Row:
    step: Step
    check: StepCheck

    def as_dict(self) -> dict[str, str]:
        return {"step": self.step.name, "title": self.step.title, "state": self.check.state,
                "reason": self.check.reason}


def _safe_check(step: Step, ctx: InstallContext) -> StepCheck:
    try:
        return step.check(ctx)
    except InstallError as exc:
        return StepCheck(ABSENT, exc.reason)
    except Exception as exc:  # noqa: BLE001 - проба не должна ронять таблицу
        return StepCheck(ABSENT, f"проверка не выполнилась ({type(exc).__name__}: {exc})")


def check_rows(ctx: InstallContext, steps: Sequence[Step]) -> list[Row]:
    return [Row(s, _safe_check(s, ctx)) for s in steps]


def render_table(rows: Sequence[Row]) -> list[str]:
    width = max((len(r.step.name) for r in rows), default=8)
    lines = [f"{'шаг':<{width}}  состояние  почему", "-" * (width + 40)]
    for row in rows:
        mark, label = _MARK[row.check.state], _LABEL[row.check.state]
        lines.append(f"{row.step.name:<{width}}  {mark} {label:<9}  {row.check.reason}")
    done = sum(1 for r in rows if r.check.done)
    lines.append(f"\nсделано {done} из {len(rows)}")
    return lines


def _select(steps: Sequence[Step], only: str | None, start: str | None) -> list[Step]:
    names = [s.name for s in steps]
    if only is not None:
        if only not in names:
            raise InstallError("bad_step", f"нет шага {only!r}", f"шаги: {', '.join(names)}")
        return [s for s in steps if s.name == only]
    if start is not None:
        if start not in names:
            raise InstallError("bad_step", f"нет шага {start!r}", f"шаги: {', '.join(names)}")
        return list(steps[names.index(start):])
    return list(steps)


def _print_footprint(ctx: InstallContext) -> None:
    """Что установка держит в системе (задания, записи хостов, экземпляры) - или «ничего»."""
    from core.install.uninstall import footprint

    try:
        stands = footprint(ctx)
    except Exception as exc:  # noqa: BLE001 - информационная строка не роняет --check
        ctx.say(f"в системе: не прочитано ({type(exc).__name__})")
        return
    if stands:
        ctx.say("в системе стоит: " + "; ".join(stands))
    else:
        ctx.say("ничего не стоит: нет заданий launchd и записей в хостах "
                "(vault, .env, модели - данные, их установка не считает)")


def _print_failure(ctx: InstallContext, step: Step, err: InstallError) -> None:
    ctx.say(f"✗ {step.name} ({err.code}): {err.reason}")
    if err.hint:
        ctx.say(f"  что сделать: {err.hint}")
    ctx.say(f"  повторить: dt install --step {step.name}   (или `dt install` - продолжит отсюда)")


def run_install(
    ctx: InstallContext, steps: Sequence[Step], *, only: str | None = None,
    start: str | None = None, check_only: bool = False, as_json: bool = False,
) -> int:
    """Выполнить установку; код выхода: 0 - все выбранные шаги сделаны, 1 - ошибка шага/не все
    готово при ``--check``."""
    try:
        chosen = _select(steps, only, start)
    except InstallError as exc:
        ctx.say(f"отказ: {exc.reason}; {exc.hint}")
        return 2
    if check_only:
        rows = check_rows(ctx, chosen)
        if as_json:
            ctx.say(json.dumps([r.as_dict() for r in rows], ensure_ascii=False, indent=2))
        else:
            for line in render_table(rows):
                ctx.say(line)
            _print_footprint(ctx)
        return 0 if all(r.check.done for r in rows) else 1

    plan_rows = check_rows(ctx, chosen)
    if ctx.dry_run:
        return _dry_run(ctx, plan_rows, forced=only is not None, as_json=as_json)

    state = ctx.state
    total = len(chosen)
    for idx, row in enumerate(plan_rows, 1):
        step = row.step
        if row.check.done and only is None:
            ctx.say(f"✓ [{idx}/{total}] {step.name}: уже сделано - {row.check.reason}")
            if state is not None and state.record(step.name).status != "done":
                state.mark(step.name, "done", output="(уже было сделано)")
            continue
        ctx.say(f"→ [{idx}/{total}] {step.name}: {step.title}")
        ctx.say(f"  {step.explain}")
        try:
            if state is not None:
                ctx.guard(state.path)
                state.mark(step.name, "running")
                state.save()
            result = step.run(ctx)
            after = step.check(ctx)
            if not result.skipped and not after.done:
                raise InstallError("verify", f"шаг выполнен, но проверка не прошла: {after.reason}",
                                   "посмотри вывод выше и повтори шаг")
        except InstallError as exc:
            if state is not None and exc.code != "live_guard":
                state.mark(step.name, "failed", error=f"{exc.code}: {exc.reason}")
                state.save()
            _print_failure(ctx, step, exc)
            return 1
        except Exception as exc:  # noqa: BLE001 - любая неожиданность - отказ шага, не трейсбэк
            if state is not None:
                state.mark(step.name, "failed", error=f"{type(exc).__name__}: {exc}")
                state.save()
            ctx.say(f"✗ {step.name}: непредвиденная ошибка {type(exc).__name__}: {exc}")
            ctx.say("  " + traceback.format_exc().strip().splitlines()[-1])
            ctx.say(f"  повторить: dt install --step {step.name}")
            return 1
        if state is not None:
            state.mark(step.name, "skipped" if result.skipped else "done", output=result.output)
            state.save()
        ctx.say(f"  ✓ {result.note or after.reason}")
    if only is None and start is None:
        ctx.say("\nУстановка завершена. Дальше: вставьте installer/INSTALL.md в Claude - "
                "он проведет по настройке под вас (профиль, стиль, интеграции).")
    return 0


def _dry_run(ctx: InstallContext, rows: Sequence[Row], *, forced: bool, as_json: bool) -> int:
    out = []
    for row in rows:
        will = forced or not row.check.done
        out.append({**row.as_dict(), "action": "run" if will else "skip"})
    if as_json:
        ctx.say(json.dumps(out, ensure_ascii=False, indent=2))
        return 0
    ctx.say("dry-run: ничего не меняю. План:")
    for item in out:
        verb = "выполнил бы" if item["action"] == "run" else "пропустил бы (уже сделано)"
        ctx.say(f"  {item['step']:<9} {verb}: {item['reason']}")
    return 0
