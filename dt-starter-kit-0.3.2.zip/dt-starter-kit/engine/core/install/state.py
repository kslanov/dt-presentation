"""Состояние установки: ``<derived>/install/state.json`` (шаг → статус, время, вывод, проценты).

Состояние - ПАМЯТЬ о прогонах (чем кончился, на каком проценте скачивание, какие ответы мастера
дал человек), а не источник правды о том, что сделано: истину отвечает ``check()`` шага по живой
системе. Поэтому на машине, поставленной руками (``state.json`` нет), ``dt install --check``
показывает «сделано» по фактам. Ни ключей, ни токенов в состоянии нет: ответы мастера - имя,
почты, компания, домены, хост, коннекторы (не секреты); вывод шагов обрезан.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.mcp_json_edit import write_text_atomic

__all__ = ["InstallState", "STATE_REL", "StepRecord", "load_state"]

STATE_REL = Path("install") / "state.json"
SCHEMA = 1
_OUTPUT_CAP = 2000


def _now() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


@dataclass
class StepRecord:
    status: str = "pending"  # pending | running | done | failed | skipped
    at: str = ""
    output: str = ""
    error: str = ""
    attempts: int = 0
    progress: int | None = None  # проценты (скачивание моделей)

    def as_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"status": self.status, "at": self.at, "attempts": self.attempts}
        if self.output:
            out["output"] = self.output
        if self.error:
            out["error"] = self.error
        if self.progress is not None:
            out["progress"] = self.progress
        return out


@dataclass
class InstallState:
    path: Path
    steps: dict[str, StepRecord] = field(default_factory=dict)
    answers: dict[str, Any] = field(default_factory=dict)
    updated: str = ""
    _dirty: bool = field(default=False, repr=False)

    def record(self, name: str) -> StepRecord:
        return self.steps.setdefault(name, StepRecord())

    def mark(self, name: str, status: str, *, output: str = "", error: str = "",
             progress: int | None = None) -> None:
        rec = self.record(name)
        if status == "running":
            rec.attempts += 1
        rec.status, rec.at = status, _now()
        rec.output = output[-_OUTPUT_CAP:] if output else rec.output if status == "running" else ""
        rec.error = error[:500]
        if progress is not None:
            rec.progress = progress
        elif status == "done":
            rec.progress = None
        self._dirty = True

    def set_progress(self, name: str, percent: int) -> None:
        rec = self.record(name)
        if rec.progress != percent:
            rec.progress = percent
            self._dirty = True

    def as_dict(self) -> dict[str, Any]:
        return {"schema": SCHEMA, "updated": self.updated or _now(), "answers": self.answers,
                "steps": {k: v.as_dict() for k, v in self.steps.items()}}

    def save(self) -> None:
        self.updated = _now()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        text = json.dumps(self.as_dict(), ensure_ascii=False, indent=2)
        write_text_atomic(self.path, text + "\n")
        self._dirty = False

    def clear(self) -> None:
        self.path.unlink(missing_ok=True)
        self.steps.clear()


def load_state(path: Path) -> InstallState:
    """Прочитать состояние; нет файла/битый JSON - пустое (прогон начнется с чистого листа)."""
    state = InstallState(path=Path(path))
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return state
    if not isinstance(data, dict):
        return state
    state.updated = str(data.get("updated") or "")
    answers = data.get("answers")
    state.answers = dict(answers) if isinstance(answers, dict) else {}
    steps = data.get("steps")
    for name, raw in (steps.items() if isinstance(steps, dict) else []):
        if not isinstance(raw, dict):
            continue
        prog = raw.get("progress")
        state.steps[str(name)] = StepRecord(
            status=str(raw.get("status") or "pending"), at=str(raw.get("at") or ""),
            output=str(raw.get("output") or ""), error=str(raw.get("error") or ""),
            attempts=int(raw.get("attempts") or 0),
            progress=int(prog) if isinstance(prog, (int, float)) else None)
    return state
