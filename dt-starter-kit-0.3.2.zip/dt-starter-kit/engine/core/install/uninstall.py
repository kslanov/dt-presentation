"""``dt uninstall``: снять то, что поставила установка, оставив данные человека.

Снимается: задания launchd ЭТОЙ установки (плист с ``WorkingDirectory`` = наш engine; чужой checkout
не трогаем), запись ``digital-twin`` в конфигах хостов (Claude Desktop - ``--relaunch``), экземпляры
(``dt instance remove`` для каждого). Остаются: vault, ``.env``, модели, секреты, ``.derived``.

``--purge`` дополнительно удаляет ``.derived`` (индекс, состояние), каталог секретов и модели - с
явным подтверждением (``--yes`` или слово «удалить»). **Vault не удаляется никогда**: цель purge,
которая совпадает с vault, лежит внутри него или содержит его, отклоняется (гард), что бы ни
сказали флаги. ``--dry-run`` печатает план и ничего не меняет.

``footprint`` - что установка оставила в системе сейчас (задания, записи хостов, экземпляры):
пусто - «ничего не стоит»; его же печатает ``dt install --check``.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from core.install import launchd as ld
from core.install.base import InstallError
from core.install.context import InstallContext

__all__ = ["CONFIRM_WORD", "footprint", "purge_targets", "uninstall"]

CONFIRM_WORD = "удалить"
_HOSTS = ("claude", "cursor")


def _host_entries(ctx: InstallContext) -> list[tuple[str, str]]:
    """``[(хост, вердикт)]`` для хостов, где есть запись ``digital-twin`` (только чтение)."""
    from core.host_config import verify_host

    out: list[tuple[str, str]] = []
    for host in _HOSTS:
        try:
            verdict = verify_host(host, home=ctx.home)
        except Exception:  # noqa: BLE001, S112 - нет конфига хоста: записи нет
            continue
        if verdict["verdict"] != "missing":
            out.append((host, str(verdict["verdict"])))
    return out


def _instances(ctx: InstallContext) -> list[str]:
    from core.instance_admin import list_instances

    return list_instances(ctx.instances_path())


def footprint(ctx: InstallContext) -> list[str]:
    """Что установка держит в системе: пусто - ничего не стоит."""
    out: list[str] = []
    loaded = ld.loaded_labels(ctx)
    for label in ld.installed_labels(ctx):
        out.append(f"launchd: {label}" + (" (загружен)" if label in loaded else " (плист)"))
    out += [f"хост {host}: запись digital-twin ({verdict})" for host, verdict in _host_entries(ctx)]
    out += [f"экземпляр: {name}" for name in _instances(ctx)]
    return out


def _overlaps(a: Path, b: Path) -> bool:
    a, b = a.resolve(), b.resolve()
    return a == b or a.is_relative_to(b) or b.is_relative_to(a)


def purge_targets(ctx: InstallContext) -> list[Path]:
    """Что удаляет ``--purge``: производные, секреты, модели (кэш двух наших моделей и манифест)."""
    from core.install.models import MANIFEST, MODELS

    targets = [ctx.derived, ctx.workspace / ".secrets"]
    targets += [ctx.models_dir / s.dirname for s in MODELS] + [ctx.models_dir / MANIFEST]
    return [t for t in targets if t.exists() or t.is_symlink()]


def _remove(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink()
    else:
        shutil.rmtree(path)


def uninstall(ctx: InstallContext, *, purge: bool = False) -> int:
    say = ctx.say
    plan: list[str] = []
    labels = ld.installed_labels(ctx)
    plan += [f"снять задание {label}" for label in labels]
    entries = _host_entries(ctx)
    plan += [f"снять запись digital-twin из {host} ({verdict})" for host, verdict in entries
             if verdict != "foreign"]
    plan += [f"снять экземпляр {name} (vault/секреты остаются)" for name in _instances(ctx)]
    targets = purge_targets(ctx) if purge else []
    refused = [t for t in targets if _overlaps(t, ctx.vault)]
    allowed = [t for t in targets if t not in refused]
    plan += [f"удалить {t}" for t in allowed]
    keep = "vault, .env" + ("" if purge else ", модели, секреты, .derived")
    if ctx.dry_run:
        say("dry-run: ничего не снимаю. План:" if plan else "dry-run: снимать нечего.")
        for line in plan:
            say(f"  {line}")
        for t in refused:
            say(f"  ОТКАЖУСЬ удалять {t}: пересекается с vault")
        say(f"  останется: {keep}")
        return 0
    if purge and allowed and not ctx.yes:
        answer = ctx.tools.prompt(
            f"--purge удалит {', '.join(str(t) for t in allowed)} (vault не тронется). "
            f"Для подтверждения напиши «{CONFIRM_WORD}»", "")
        if answer.strip().lower() != CONFIRM_WORD:
            say("отмена: ничего не удалено")
            return 1
    failed = 0
    for done in ld.remove_labels(ctx, labels):
        say(f"  ✓ снято задание {done}")
    failed += _remove_hosts(ctx, entries)
    from core.instance_admin import remove_instance

    for name in _instances(ctx):
        remove_instance(name, instances_dir=ctx.instances_path(),
                        launchd_dir=ld.jobs_dir(ctx),
                        runner=lambda argv: ctx.tools.launchctl(list(argv))[0])
        say(f"  ✓ снят экземпляр {name} (vault, derived и секреты экземпляра остались)")
    for t in refused:
        say(f"  ✗ не удаляю {t}: пересекается с vault ({ctx.vault}); vault не удаляется никогда")
        failed += 1
    for t in allowed:
        _remove(t)
        say(f"  ✓ удалено {t}")
    if ctx.state is not None and ctx.state.path.exists():
        for name in ("launchd", "host"):
            ctx.state.steps.pop(name, None)
        ctx.guard(ctx.state.path)
        ctx.state.save()
    say(f"останется: {keep}")
    if failed:
        return 1
    say("Готово: установка снята." if plan else "Снимать было нечего: установка ничего не держала.")
    return 0


def _remove_hosts(ctx: InstallContext, entries: list[tuple[str, str]]) -> int:
    from core.host_config import HostConfigError, uninstall_entry

    failed = 0
    for host, verdict in entries:
        if verdict == "foreign":
            ctx.say(f"  · хост {host}: запись digital-twin не наша - не трогаю")
            continue
        try:
            ctx.guard(ctx.home)
            done = uninstall_entry(host, home=ctx.home, relaunch=ctx.relaunch,
                                   desktop=ctx.tools.desktop)
        except (HostConfigError, InstallError) as exc:
            code = getattr(exc, "code", "")
            hint = " (закрой Claude Desktop или повтори с --relaunch)" if code == (
                "desktop_running") else ""
            ctx.say(f"  ✗ хост {host}: {exc}{hint}")
            failed += 1
            continue
        ctx.say(f"  ✓ хост {host}: {done['outcome']} ({done['path']})")
    return failed
