"""Мастер вопросов ``dt install``: vault, имя/почты/компания/домены владельца, хост, коннекторы.

Спрашивает только то, чего еще нет ни во флагах, ни в ``state.json`` (повтор не переспрашивает).
Ключей и токенов мастер НЕ просит никогда: секреты - отдельной командой
(``dt config set KEY --stdin``, см. ``installer/brain/04-integrations.md``). ``--yes`` - без
вопросов: значения из флагов/состояния, умолчания для необязательного; нет обязательного
(имя, почта) - отказ с подсказкой флага.
Ответы сохраняются в ``state.json`` (это не секреты).
"""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path

from core import connectors
from core.install.base import InstallError
from core.install.context import HOST_CHOICES, InstallContext

__all__ = ["ALL_FIELDS", "complete", "parse_list", "validate_connectors"]

ALL_FIELDS = ("vault", "name", "emails", "company", "domains", "internal_domains", "host",
              "connectors")
_REQUIRED_YES = {"name": "--name", "emails": "--email"}
_LIST_FIELDS = {"emails", "domains", "internal_domains"}
_QUESTIONS = {
    "vault": "Где лежит ваш vault (папка с заметками)",
    "name": "Как вас зовут (имя и фамилия)",
    "emails": "Ваши рабочие адреса почты (через запятую)",
    "company": "Компания (можно пропустить)",
    "domains": "Почтовые домены компании (через запятую; можно пропустить)",
    "internal_domains": "Служебные домены группы (через запятую; можно пропустить)",
    "host": f"Какой ассистент подключаем ({'/'.join(HOST_CHOICES)})",
    "connectors": "Внешние коннекторы: none или список (timetta, ticktick, outlook)",
}


def parse_list(raw: str) -> list[str]:
    return [p.strip() for p in raw.replace(";", ",").split(",") if p.strip()]


def validate_connectors(value: str) -> str:
    """``none`` | ``auto`` | список известных коннекторов (через запятую); иначе - отказ."""
    text = (value or "").strip().lower()
    if text in ("", "none"):
        return "none"
    if text == "auto":
        return "auto"
    keys: list[str] = []
    for tok in parse_list(text):
        try:
            keys.append(connectors.normalize(tok))
        except KeyError:
            raise InstallError(
                "bad_connector", f"неизвестный коннектор {tok!r}",
                f"допустимо: none, auto, {', '.join(connectors.CONNECTORS)}") from None
    return ",".join(dict.fromkeys(keys))


def _default(ctx: InstallContext, field: str) -> str:
    return {"vault": str(ctx.vault), "host": "claude", "connectors": "none"}.get(field, "")


def _get(ctx: InstallContext, field: str) -> str | list[str]:
    return getattr(ctx.answers, field)


def complete(ctx: InstallContext, need: Sequence[str] = ALL_FIELDS) -> None:
    """Дополнить ``ctx.answers`` недостающим по ``need``; сохранить в состояние (не при dry-run)."""
    changed = False
    asked: set[str] = set(ctx.state.answers.get("_asked", [])) if ctx.state else set()
    for field in need:
        if _get(ctx, field) or field in asked:
            continue
        if ctx.yes:
            if field in _REQUIRED_YES:
                raise InstallError(
                    "answers_missing", f"в режиме --yes не задано: {field}",
                    f"передай {_REQUIRED_YES[field]} (или запусти без --yes - спрошу)")
            default = _default(ctx, field)
            if default:
                _put(ctx, field, default)
            continue
        default = _default(ctx, field)
        answer = ctx.tools.prompt(_QUESTIONS[field], default)
        if not answer and field in _REQUIRED_YES:
            raise InstallError("answers_missing", f"нужно значение: {field}",
                               "повтори `dt install` и ответь на вопрос")
        asked.add(field)  # пропущенное необязательное повтор не переспрашивает
        changed = True
        if answer:
            _put(ctx, field, answer)
    _normalize(ctx)
    if ctx.answers.vault:
        ctx.vault = Path(ctx.answers.vault).expanduser().resolve()
    if (changed or ctx.state is not None) and not ctx.dry_run and ctx.state is not None:
        ctx.guard(ctx.state.path)
        ctx.state.answers = {**ctx.answers.as_dict(), "_asked": sorted(asked)}
        ctx.state.save()


def _put(ctx: InstallContext, field: str, value: str) -> None:
    setattr(ctx.answers, field, parse_list(value) if field in _LIST_FIELDS else value)


def _normalize(ctx: InstallContext) -> None:
    ans = ctx.answers
    if ans.host and ans.host not in HOST_CHOICES:
        raise InstallError("bad_host", f"неизвестный хост {ans.host!r}",
                           f"допустимо: {', '.join(HOST_CHOICES)}")
    if ans.connectors:
        ans.connectors = validate_connectors(ans.connectors)
