"""PERSONAL-1 п.1 - экземпляр движка: имя, роль, каталог секретов, соседи (эмбеддер, рабочий демон).

Один движок - несколько экземпляров: рабочий (без оверлея, как всегда) и личный (``DT_INSTANCE=
personal``, оверлей ``engine/instances/personal.env`` поверх ``engine/.env``, см.
:func:`core.config.env_file.load_env_layers`). Здесь - чтение того, что оверлей выставляет:

* ``DT_INSTANCE`` / ``DT_INSTANCE_ROLE`` (``work`` по умолчанию | ``personal``);
* ``DT_SECRETS_DIR`` - каталог секретов экземпляра (по умолчанию прежний ``<workspace>/.secrets``);
* ``DT_EMBED_OWNER`` (``0`` - демон не грузит модель) и ``DT_EMBED_URL`` (чей ``/internal/embed``);
* ``DT_WORK_URL`` / ``DT_WORK_TOKEN_FILE`` - рабочий демон для моста (ТОЛЬКО у роли ``personal``).

Клапан конструкцией (дизайн PROFILE-1 §3): у рабочей роли :func:`work_url` и :func:`work_token`
всегда пусты - даже если ключи по ошибке оказались в окружении, клиента к рабочему демону не
собрать, а личный vault рабочий экземпляр не видит вовсе (его пути нет ни в ``.env``, ни в коде).

Модуль - только stdlib (+ корни ``core.config._roots``): листовой, им пользуются конфиг, демон,
эмбеддер и мост без циклов. Значения читаются из ``os.environ`` в момент вызова.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from urllib.parse import urlparse

__all__ = [
    "DEFAULT_BRIDGE_EXCLUDE",
    "DEFAULT_INBOX",
    "DEFAULT_INDEX_EXCLUDE",
    "DEFAULT_JOURNAL_DIR",
    "ENV_BRIDGE_EXCLUDE",
    "ENV_CONTENT_DIRS",
    "ENV_EMBED_OWNER",
    "ENV_EMBED_URL",
    "ENV_IDEAS_DIR",
    "ENV_INBOX",
    "ENV_INDEX_EXCLUDE",
    "ENV_INSTANCE",
    "ENV_JOURNAL_DIR",
    "ENV_ROLE",
    "ENV_SECRETS_DIR",
    "ENV_UNTAGGED_LANE",
    "ENV_WORK_TOKEN_FILE",
    "ENV_WORK_URL",
    "ROLE_PERSONAL",
    "ROLE_WORK",
    "ROLES",
    "UNTAGGED_LANES",
    "InstanceError",
    "bridge_exclude",
    "describe",
    "embed_owner",
    "embed_url",
    "excluded",
    "glob_match",
    "index_exclude",
    "instance_name",
    "instance_role",
    "is_personal",
    "personal_content_dirs",
    "personal_ideas_dir",
    "personal_inbox",
    "personal_journal_dir",
    "safe_rel",
    "secrets_path",
    "untagged_lane",
    "work_token",
    "work_token_path",
    "work_url",
]

logger = logging.getLogger("dt.instance")

ENV_INSTANCE = "DT_INSTANCE"
ENV_ROLE = "DT_INSTANCE_ROLE"
ENV_SECRETS_DIR = "DT_SECRETS_DIR"
ENV_EMBED_OWNER = "DT_EMBED_OWNER"
ENV_EMBED_URL = "DT_EMBED_URL"
ENV_WORK_URL = "DT_WORK_URL"
ENV_WORK_TOKEN_FILE = "DT_WORK_TOKEN_FILE"  # noqa: S105 - имя переменной, не секрет
# PERSONAL-2 п.1: папки личного vault - ручки оверлея (пути от корня vault). Нет ручек - каркас
# PERSONAL-1 (дневник ``05-journal``, ``личное`` -> инбокс).
ENV_JOURNAL_DIR = "DT_PERSONAL_JOURNAL_DIR"
ENV_IDEAS_DIR = "DT_PERSONAL_IDEAS_DIR"
ENV_CONTENT_DIRS = "DT_PERSONAL_CONTENT_DIRS"
ENV_INBOX = "DT_PERSONAL_INBOX"
# PERSONAL-3 п.C: полоса для задач БЕЗ тега в списке захвата личного (дефолт - пропуск).
ENV_UNTAGGED_LANE = "DT_PERSONAL_UNTAGGED_LANE"
UNTAGGED_LANES = ("skip", "personal", "journal", "content")
DEFAULT_JOURNAL_DIR = "05-journal"
DEFAULT_INBOX = "_staging/inbox"
# PERSONAL-2 п.2: исключения (glob от корня vault, через запятую). Мост не опрашивает такие заметки
# и не шлет их текст рабочему демону; индекс личного их не берет (у рабочего индекс прежний).
ENV_BRIDGE_EXCLUDE = "DT_BRIDGE_EXCLUDE"
ENV_INDEX_EXCLUDE = "DT_INDEX_EXCLUDE"
DEFAULT_BRIDGE_EXCLUDE = ("Templates/**",)
DEFAULT_INDEX_EXCLUDE = ("Templates/**", ".smart-*/**", ".trash/**")
ROLE_WORK, ROLE_PERSONAL = "work", "personal"
ROLES = (ROLE_WORK, ROLE_PERSONAL)
_LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})
_FALSE = frozenset({"0", "false", "no", "off"})


class InstanceError(ValueError):
    """Недопустимая настройка экземпляра (роль, адрес соседа)."""


def _env(name: str) -> str:
    return (os.environ.get(name) or "").strip()


def instance_name() -> str | None:
    """Имя экземпляра (``DT_INSTANCE``) или ``None`` - обычный (рабочий) процесс без оверлея."""
    return _env(ENV_INSTANCE) or None


def instance_role() -> str:
    """Роль: ``DT_INSTANCE_ROLE`` (``work`` по умолчанию). Незнакомое значение - ошибка: опечатка
    в роли не должна тихо дать рабочие права личному vault."""
    raw = _env(ENV_ROLE).lower()
    if not raw:
        return ROLE_WORK
    if raw not in ROLES:
        raise InstanceError(f"{ENV_ROLE}={raw!r}: допустимы {', '.join(ROLES)}")
    return raw


def is_personal() -> bool:
    return instance_role() == ROLE_PERSONAL


def secrets_path() -> Path:
    """Каталог секретов экземпляра: ``DT_SECRETS_DIR`` либо прежний ``<workspace>/.secrets``."""
    override = _env(ENV_SECRETS_DIR)
    if override:
        return Path(override)
    from core.config._roots import WORKSPACE_ROOT

    return WORKSPACE_ROOT / ".secrets"


def embed_owner() -> bool:
    """Владеет ли демон моделью эмбеддинга (``DT_EMBED_OWNER``, дефолт 1; ``0/false/no/off`` - нет:
    вектора и запросы считает сосед по ``DT_EMBED_URL``, при его недоступности - локально)."""
    return (_env(ENV_EMBED_OWNER) or "1").lower() not in _FALSE


def embed_url() -> str | None:
    """Адрес соседа-владельца модели (``http://127.0.0.1:<порт>``) или ``None`` - свой порт.

    Только loopback: токен уходит по этому адресу, а ``/internal/embed`` и так отвечает только
    loopback-peer. Чужой хост игнорируется с предупреждением (откат - как будто адреса нет)."""
    raw = _env(ENV_EMBED_URL)
    if not raw:
        return None
    parsed = urlparse(raw)
    if parsed.scheme != "http" or (parsed.hostname or "") not in _LOOPBACK_HOSTS or not parsed.port:
        logger.warning("%s=%r проигнорирован: нужен http://127.0.0.1:<порт> (токен не покидает "
                       "машину)", ENV_EMBED_URL, parsed.scheme + "://" + (parsed.hostname or "?"))
        return None
    return f"http://{parsed.hostname}:{parsed.port}"


def work_url() -> str | None:
    """Адрес рабочего демона для моста; ``None`` у рабочей роли и без ``DT_WORK_URL``."""
    if instance_role() != ROLE_PERSONAL:
        return None
    return _env(ENV_WORK_URL).rstrip("/") or None


def work_token_path() -> Path | None:
    """Файл токена ЧТЕНИЯ рабочего демона (``DT_WORK_TOKEN_FILE``); ``None`` у рабочей роли."""
    if instance_role() != ROLE_PERSONAL:
        return None
    raw = _env(ENV_WORK_TOKEN_FILE)
    return Path(raw) if raw else None


def work_token() -> str | None:
    """Токен чтения рабочего демона из файла (нигде не печатается); нет файла - ``None``."""
    path = work_token_path()
    if path is None:
        return None
    try:
        return path.read_text(encoding="utf-8").strip() or None
    except OSError:
        return None


def safe_rel(value: str | None) -> str | None:
    """Папка от корня vault в каноничном виде (``a/b``) либо ``None``.

    Пустое, абсолютное, с ``..`` и сегмент ``.obsidian`` не принимаются: папка экземпляра не выходит
    из vault и не лезет в служебные каталоги Obsidian."""
    text = (value or "").strip().replace("\\", "/")
    if not text or text.startswith("/"):
        return None
    raw = text.strip("/")
    parts = [p for p in raw.split("/") if p not in ("", ".")]
    if not parts or ".." in parts or ".obsidian" in parts:
        return None
    return "/".join(parts)


def personal_journal_dir() -> str:
    """Папка дневника (``DT_PERSONAL_JOURNAL_DIR``, дефолт ``05-journal``); битое - дефолт."""
    return safe_rel(_env(ENV_JOURNAL_DIR)) or DEFAULT_JOURNAL_DIR


def personal_ideas_dir() -> str | None:
    """Папка идей (``DT_PERSONAL_IDEAS_DIR``): задана - ``#личное`` пишется заметкой идеи, нет -
    инбокс ``lane: personal`` (PERSONAL-1)."""
    return safe_rel(_env(ENV_IDEAS_DIR))


def personal_content_dirs() -> list[str]:
    """Папки контента для подсказки размещения (``DT_PERSONAL_CONTENT_DIRS``: через запятую или
    JSON)."""
    raw = _env(ENV_CONTENT_DIRS)
    if not raw:
        return []
    items: list[str]
    if raw.startswith("["):
        import json

        try:
            data = json.loads(raw)
        except ValueError:
            data = []
        items = [str(x) for x in data] if isinstance(data, list) else []
    else:
        items = raw.split(",")
    out: list[str] = []
    for item in items:
        rel = safe_rel(item)
        if rel and rel not in out:
            out.append(rel)
    return out


def untagged_lane() -> str:
    """Полоса личного захвата для задач без тега: ``skip`` (дефолт) | ``personal`` | ``journal`` |
    ``content``. Незнакомое значение - ``skip`` (опечатка не должна тащить задачи в vault)."""
    raw = _env(ENV_UNTAGGED_LANE).lower()
    return raw if raw in UNTAGGED_LANES else "skip"


def personal_inbox() -> str:
    """Инбокс личного vault от его корня (``DT_PERSONAL_INBOX``, дефолт ``_staging/inbox``)."""
    return safe_rel(_env(ENV_INBOX)) or DEFAULT_INBOX


def _globs(raw: str) -> list[str]:
    """Список glob-ов (через запятую или JSON); пустые и небезопасные (``..``) отброшены."""
    text = raw.strip()
    if text.startswith("["):
        import json

        try:
            data = json.loads(text)
        except ValueError:
            data = []
        items = [str(x) for x in data] if isinstance(data, list) else []
    else:
        items = text.split(",")
    out: list[str] = []
    for item in items:
        pat = item.strip().replace("\\", "/").lstrip("/")
        if pat and ".." not in pat.split("/") and pat not in out:
            out.append(pat)
    return out


def bridge_exclude() -> list[str]:
    """Заметки вне моста: ``DT_BRIDGE_EXCLUDE`` (дефолт ``Templates/**``). Ручка есть, но пуста -
    исключений нет (владелец убрал их сознательно); нет ручки - дефолт."""
    raw = os.environ.get(ENV_BRIDGE_EXCLUDE)
    return list(DEFAULT_BRIDGE_EXCLUDE) if raw is None else _globs(raw)


def index_exclude() -> list[str]:
    """Исключения индекса ЛИЧНОГО экземпляра (``DT_INDEX_EXCLUDE``; дефолт ``Templates/**``,
    ``.smart-*/**``, ``.trash/**``). У рабочей роли - пусто: рабочий индекс прежний."""
    if instance_role() != ROLE_PERSONAL:
        return []
    raw = os.environ.get(ENV_INDEX_EXCLUDE)
    return list(DEFAULT_INDEX_EXCLUDE) if raw is None else _globs(raw)


def _fold(text: str) -> str:
    import unicodedata

    return unicodedata.normalize("NFC", text).casefold()


def glob_match(rel: str, pattern: str) -> bool:
    """Подходит ли путь от корня vault под glob: ``**`` - любые сегменты, ``*``/``?`` - внутри
    сегмента.

    ``Templates/**`` ловит всё под папкой (и саму папку). Сравнение без учета регистра и в NFC:
    на macOS имена в NFD и регистр не различается, а исключение - замок утечки, он не должен
    обходиться написанием."""
    import re

    path = _fold(rel.replace("\\", "/").strip("/"))
    pat = _fold(pattern.replace("\\", "/").strip("/"))
    if pat.endswith("/**"):
        head = pat[:-3]
        if glob_match(path, head):
            return True
    rx = ""
    i = 0
    while i < len(pat):
        c = pat[i]
        if pat.startswith("**/", i):
            rx += "(?:.*/)?"
            i += 3
            continue
        if c == "*" and pat.startswith("**", i):
            rx += ".*"
            i += 2
            continue
        rx += "[^/]*" if c == "*" else ("[^/]" if c == "?" else re.escape(c))
        i += 1
    return re.fullmatch(rx, path) is not None


def excluded(rel: str, patterns: list[str] | tuple[str, ...]) -> bool:
    """Путь заметки под любым из glob-исключений."""
    return any(glob_match(rel, p) for p in patterns)


def describe() -> dict[str, object]:
    """Сводка для ``/health`` и доктора БЕЗ секретов: имя, роль, владение моделью."""
    return {"name": instance_name(), "role": instance_role(), "embed_owner": embed_owner()}
