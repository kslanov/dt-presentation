"""PERSONAL-1 п.1 - администрирование экземпляров: ``dt instance add|list|status|remove``.

``add`` создаёт ВСЁ, что нужно второму экземпляру, и ничего не трогает в рабочем:

* оверлей ``engine/instances/<имя>.env`` (ключи ``DT_*`` экземпляра: роль, vault, derived, порт,
  каталог секретов, сосед-эмбеддер, рабочий демон для моста) - его единственный писатель;
* каталог секретов экземпляра (0700) с СВОИМИ токенами ``web_token``/``web_token_rw`` и - у роли
  ``personal`` - копиями двух токенов рабочего демона: ``work_token`` (токен ЧТЕНИЯ рабочего,
  никогда ``_rw``) и ``embed_token`` (узкий: только ``/internal/embed``; выпускается на стороне
  рабочего демона, если его ещё нет - единственная запись в рабочие секреты, и только эта дверь);
* каталог derived экземпляра, каркас vault (:mod:`core.vault_template`);
* три plist-а ``com.dt.server-<имя>`` / ``com.dt.sync.fast-<имя>`` / ``com.dt.sync.index-<имя>``
  с ``EnvironmentVariables: DT_INSTANCE`` - из тех же шаблонов ``ops/launchd/*.plist``, что и у
  рабочего (шаблоны не меняются: на них гард «в plist нет DT_*» - здесь ключ добавляется только в
  ПОРОЖДЁННЫЙ файл).

Все пути и вызов ``launchctl`` - параметры (тесты и приёмка гоняются на tmp; боевой
``~/Library/LaunchAgents`` и launchd здесь не трогаются, пока не передан
``launchd_dir``/``runner``).
Значения токенов нигде не печатаются: отчёт несёт пути и хвосты.
"""

from __future__ import annotations

import os
import plistlib
import re
import secrets
import subprocess
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core import instance as _inst
from core.config import derived_root, env_file
from core.web_tokens import EMBED_FILE, READ_FILE, RW_FILE, _write_secret, tail

__all__ = [
    "AddResult",
    "work_status",
    "InstanceExists",
    "LABELS",
    "add_instance",
    "instance_status",
    "list_instances",
    "overlay_text",
    "remove_instance",
    "render_plists",
]

_ENGINE_ROOT = Path(__file__).resolve().parents[1]
_LAUNCH_AGENTS = Path.home() / "Library" / "LaunchAgents"
WORK_TOKEN_FILE = "work_token"  # noqa: S105 - имя файла, не секрет
DEFAULT_WORK_URL = "http://127.0.0.1:8787"
FAST_INTERVAL_S = 1800  # 30 мин, как у рабочего оборота
FAST_STEPS = "pull_capture,file_ingest"  # без refresh/mail: у личного нет Timetta и почты
INDEX_HOUR, INDEX_MINUTE = 3, 30
#: роль → какие plist-ы ставим (ключ шаблона ``com.dt.<ключ>`` → суффикс метки добавляет имя)
LABELS = {
    "server": "com.dt.server",
    "fast": "com.dt.sync.fast",
    "index": "com.dt.sync.index",
}
_TEMPLATES = {"server": "com.dt.server", "fast": "com.dt.sync.fast", "index": "com.dt.sync.index"}
_LOG_NAMES = {"server": "launchd.server", "fast": "launchd.fast", "index": "launchd.index"}


class InstanceExists(Exception):
    """Экземпляр с таким именем уже создан (оверлей есть) - перезаписи нет."""


@dataclass
class AddResult:
    name: str
    role: str
    overlay: Path
    vault: Path
    derived: Path
    secrets: Path
    port: int
    plists: dict[str, Path] = field(default_factory=dict)
    skeleton: list[str] = field(default_factory=list)
    tokens: dict[str, str] = field(default_factory=dict)  # имя файла → хвост токена (не значение)
    work_token_copied: bool = False
    embed_token_ready: bool = False
    loaded: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name, "role": self.role, "overlay": str(self.overlay),
            "vault": str(self.vault), "derived": str(self.derived), "secrets": str(self.secrets),
            "port": self.port, "plists": {k: str(v) for k, v in self.plists.items()},
            "skeleton": self.skeleton, "tokens": self.tokens,
            "work_token_copied": self.work_token_copied,
            "embed_token_ready": self.embed_token_ready, "loaded": self.loaded,
            "notes": self.notes,
        }


Runner = Callable[[Sequence[str]], int]


def _launchctl(argv: Sequence[str]) -> int:  # pragma: no cover - боевой launchctl, в тестах подмена
    return subprocess.run(["launchctl", *argv], check=False,  # noqa: S603, S607
                          capture_output=True).returncode


def label_for(kind: str, name: str) -> str:
    return f"{LABELS[kind]}-{name}"


def overlay_text(
    name: str, *, role: str, vault: Path, derived: Path, secrets_dir: Path, port: int,
    work_url: str | None, folders: dict[str, str] | None = None,
) -> str:
    """Текст оверлея экземпляра (детерминированный: те же входы - те же байты).

    ``DT_INSTANCE`` в оверлее НЕТ: имя приходит из окружения процесса (plist), оверлей выбирается по
    нему - а не наоборот. У роли ``personal`` эмбеддер - сосед (рабочий демон), модель не
    грузится."""
    lines = [
        f"# PERSONAL-1: оверлей экземпляра {name!r} (dt instance add; поверх engine/.env).",
        "# Ключи здесь побеждают .env, реальное окружение побеждает оба. Секретов в файле нет:",
        "# токены лежат в каталоге секретов экземпляра (DT_SECRETS_DIR).",
        f"DT_INSTANCE_ROLE={env_file.format_value(role)}",
        f"DT_VAULT_PATH={env_file.format_value(str(vault))}",
        f"DT_DERIVED_ROOT={env_file.format_value(str(derived))}",
        f"DT_WEB_PORT={port}",
        f"DT_SECRETS_DIR={env_file.format_value(str(secrets_dir))}",
    ]
    if role == _inst.ROLE_PERSONAL:
        neighbour = work_url or DEFAULT_WORK_URL
        lines += [
            "DT_EMBED_OWNER=0",
            f"DT_EMBED_URL={env_file.format_value(neighbour)}",
            f"DT_WORK_URL={env_file.format_value(neighbour)}",
            f"DT_WORK_TOKEN_FILE={env_file.format_value(str(secrets_dir / WORK_TOKEN_FILE))}",
        ]
        lines += [f"{k}={env_file.format_value(v)}" for k, v in (folders or {}).items()]
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------- #
# plist-ы из шаблонов ops/launchd                                               #
# --------------------------------------------------------------------------- #
def _load_template(kind: str, engine_dir: Path, uv_bin_dir: str) -> dict[str, Any]:
    src = engine_dir / "ops" / "launchd" / f"{_TEMPLATES[kind]}.plist"
    text = src.read_text(encoding="utf-8")
    text = text.replace("__ENGINE_DIR__", str(engine_dir)).replace("__UV_BIN_DIR__", uv_bin_dir)
    data = plistlib.loads(text.encode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{src}: не plist-словарь")
    return data


def render_plists(
    name: str, *, port: int, derived: Path, engine_dir: Path | None = None,
    uv_bin_dir: str | None = None, host: str = "127.0.0.1",
) -> dict[str, bytes]:
    """Три plist-а экземпляра: ``{server|fast|index: байты}``.

    Берутся шаблоны рабочего (``ops/launchd``) и перекраиваются: метка ``…-<имя>``, порт сервера,
    шаги быстрого оборота (``--steps pull_capture,file_ingest``), ночной запуск в 03:30, логи в
    derived экземпляра, ``EnvironmentVariables.DT_INSTANCE``. Рабочие plist-ы не затрагиваются.
    Демон экземпляра слушает ``host`` (по умолчанию loopback: в отличие от рабочего, личный пульт
    не выставляется в Wi-Fi/Tailscale без явного решения)."""
    if not env_file.valid_instance_name(name):
        raise env_file.EnvFileError(f"недопустимое имя экземпляра: {name!r}")
    engine_dir = Path(engine_dir) if engine_dir is not None else _ENGINE_ROOT
    uv_dir = uv_bin_dir or str(Path.home() / ".local" / "bin")
    logs = Path(derived) / "logs"
    out: dict[str, bytes] = {}
    for kind in LABELS:
        data = _load_template(kind, engine_dir, uv_dir)
        data["Label"] = label_for(kind, name)
        env = dict(data.get("EnvironmentVariables") or {})
        env[_inst.ENV_INSTANCE] = name
        data["EnvironmentVariables"] = env
        data["StandardOutPath"] = str(logs / f"{_LOG_NAMES[kind]}.out.log")
        data["StandardErrorPath"] = str(logs / f"{_LOG_NAMES[kind]}.err.log")
        args = list(data["ProgramArguments"])
        if kind == "server":
            args[args.index("--port") + 1] = str(port)
            args[args.index("--host") + 1] = host
        elif kind == "fast":
            data["StartInterval"] = FAST_INTERVAL_S
            args += ["--steps", FAST_STEPS]
        else:
            data["StartCalendarInterval"] = {"Hour": INDEX_HOUR, "Minute": INDEX_MINUTE}
        data["ProgramArguments"] = args
        out[kind] = plistlib.dumps(data, sort_keys=False)
    return out


# --------------------------------------------------------------------------- #
# add / list / status / remove                                                  #
# --------------------------------------------------------------------------- #
def _ensure_secret(path: Path, *, fresh: bool = True) -> str:
    """Токен файлом 0600: есть - возвращаем (не затираем), нет - выпускаем."""
    try:
        existing = path.read_text(encoding="utf-8").strip()
    except OSError:
        existing = ""
    if existing:
        return existing
    token = secrets.token_urlsafe(24)
    _write_secret(path, token)
    return token


def _copy_secret(src: Path, dst: Path) -> bool:
    try:
        value = src.read_text(encoding="utf-8").strip()
    except OSError:
        return False
    if not value:
        return False
    _write_secret(dst, value)
    return True


def _capture_overlay(project: str | None, lane: str | None) -> dict[str, str]:
    """Ключи оверлея для источника захвата личного; ``ValueError`` на неверную полосу или
    ``untagged_lane`` не skip при списке, совпадающем с рабочим (``same_project``)."""
    from core.personal import capture_source as cs

    out: dict[str, str] = {}
    value = " ".join((project or "").split())
    if value:
        out[cs.ID_KEY if cs.is_project_id(value) else cs.NAME_KEY] = value
    chosen = (lane or "").strip().lower()
    if chosen:
        if chosen not in _inst.UNTAGGED_LANES:
            raise ValueError(f"{_inst.ENV_UNTAGGED_LANE}: нужно одно из "
                             f"{', '.join(_inst.UNTAGGED_LANES)}")
        out[_inst.ENV_UNTAGGED_LANE] = chosen
    if chosen not in ("", "skip") and cs.same_project(
            (out.get(cs.ID_KEY, ""), out.get(cs.NAME_KEY, ""))):
        raise ValueError(f"same_project: untagged_lane={chosen} при общем с рабочим списке "
                         f"захвата: {cs.HINT}")
    return out


def add_instance(
    name: str, *, vault: Path, port: int, role: str = _inst.ROLE_PERSONAL,
    work_url: str | None = None, engine_dir: Path | None = None, workspace: Path | None = None,
    derived: Path | None = None, secrets_dir: Path | None = None,
    instances_dir: Path | None = None, launchd_dir: Path | None = None,
    work_secrets_dir: Path | None = None, uv_bin_dir: str | None = None,
    work_vault: Path | None = None,
    skeleton: Callable[[Path, str], list[str]] | None = None,
    load: bool = True, runner: Runner | None = None,
    journal_dir: str | None = None, ideas_dir: str | None = None,
    content_dirs: Sequence[str] | None = None,
    capture_project: str | None = None, untagged_lane: str | None = None,
    bridge_exclude: str | None = None,
) -> AddResult:
    """Создать экземпляр ``name``: оверлей, секреты, derived, каркас vault, plist-ы, загрузка.

    ``work_secrets_dir`` - каталог секретов РАБОЧЕГО демона (откуда берутся токен чтения и узкий
    токен эмбеддера); по умолчанию ``<workspace>/.secrets``. ``skeleton(vault, kind)`` -
    генератор каркаса
    (по умолчанию :func:`core.vault_template.build_vault`; ``work_vault`` - откуда он копирует
    профиль и канон ИИ-маркеров, по умолчанию vault этого процесса). ``load=False`` - plist-ы
    только пишутся.
    Повтор на существующий экземпляр - :class:`InstanceExists` (ни одного файла не изменено).

    PERSONAL-2: ``journal_dir``/``ideas_dir``/``content_dirs`` (пути от корня vault) - ручки папок
    личного vault, который уже есть: в оверлей идут ``DT_PERSONAL_*``, каркас создает только
    ``_system/``, инбокс и заданные папки дневника/идей
    (:func:`core.vault_template.build_vault`)."""
    if role not in _inst.ROLES:
        raise ValueError(f"роль {role!r}: допустимы {', '.join(_inst.ROLES)}")
    if not 1024 <= int(port) <= 65535:
        raise ValueError(f"порт {port}: нужен 1024-65535")
    engine_dir = Path(engine_dir) if engine_dir is not None else _ENGINE_ROOT
    workspace = Path(workspace) if workspace is not None else engine_dir.parent
    instances_dir = Path(instances_dir) if instances_dir is not None else engine_dir / "instances"
    overlay = env_file.instance_overlay_path(name, instances_dir)
    if overlay.exists():
        raise InstanceExists(f"экземпляр {name!r} уже есть ({overlay}); сначала dt instance remove")
    workspace = workspace.resolve()
    vault = Path(vault).expanduser().resolve()
    work_derived = derived_root().resolve()
    derived = (Path(derived).expanduser().resolve() if derived
               else workspace / f"{work_derived.name}-{name}")
    sec = (Path(secrets_dir).expanduser().resolve() if secrets_dir
           else workspace / f".secrets-{name}")
    work_sec = (Path(work_secrets_dir).expanduser().resolve() if work_secrets_dir
                else workspace / ".secrets")
    if vault == workspace / "vault" or sec == work_sec or derived == work_derived:
        raise ValueError("экземпляр не может делить vault/derived/секреты с рабочим")

    folders: dict[str, str] = {}
    for key, raw in ((_inst.ENV_JOURNAL_DIR, journal_dir), (_inst.ENV_IDEAS_DIR, ideas_dir)):
        if raw:
            rel = _inst.safe_rel(raw)
            if rel is None:
                raise ValueError(f"{key}: папка от корня vault, без абсолютного пути и '..'")
            folders[key] = rel
    if content_dirs:
        rels = [_inst.safe_rel(d) for d in content_dirs]
        if any(r is None for r in rels):
            raise ValueError(f"{_inst.ENV_CONTENT_DIRS}: каждая папка от корня vault, без '..'")
        folders[_inst.ENV_CONTENT_DIRS] = ",".join(str(r) for r in rels)
    if folders and role != _inst.ROLE_PERSONAL:
        raise ValueError("папки дневника/идей/контента - только у роли personal")
    # PERSONAL-3 п.C: свой список TickTick и полоса для задач без тега (гард same_project)
    capture: dict[str, str] = {}
    if capture_project or untagged_lane:
        if role != _inst.ROLE_PERSONAL:
            raise ValueError("--capture-project/--untagged-lane - только у роли personal")
        capture = _capture_overlay(capture_project, untagged_lane)
    if bridge_exclude is not None:  # PERSONAL-3 п.D4: исключения моста ДО первого индекса
        if role != _inst.ROLE_PERSONAL:
            raise ValueError("--bridge-exclude - только у роли personal")
        from core.instance_settings import SettingsError, normalize

        try:
            capture[_inst.ENV_BRIDGE_EXCLUDE] = normalize(_inst.ENV_BRIDGE_EXCLUDE, bridge_exclude)
        except SettingsError as exc:
            raise ValueError(exc.detail) from exc

    res = AddResult(name=name, role=role, overlay=overlay, vault=vault, derived=derived,
                    secrets=sec, port=int(port))
    # 1. секреты экземпляра: свои токены; у personal - токен чтения и узкий токен рабочего
    sec.mkdir(parents=True, exist_ok=True)
    os.chmod(sec, 0o700)
    for fname in (READ_FILE, RW_FILE):
        res.tokens[fname] = tail(_ensure_secret(sec / fname))
    if role == _inst.ROLE_PERSONAL:
        res.work_token_copied = _copy_secret(work_sec / READ_FILE, sec / WORK_TOKEN_FILE)
        if not res.work_token_copied:
            res.notes.append(
                f"нет токена чтения рабочего демона ({work_sec / READ_FILE}): мост даст "
                "work_unavailable, пока файл не появится (dt web-token show read на рабочем)")
        # узкий токен эмбеддера: выпускается рядом с рабочими секретами, если его там нет
        # (рабочий демон о нём узнает при следующем запросе - токены читаются с диска)
        embed = _ensure_secret(work_sec / EMBED_FILE) if work_sec.is_dir() else ""
        if embed:
            _write_secret(sec / EMBED_FILE, embed)
            res.embed_token_ready = True
        else:
            res.notes.append(f"каталога секретов рабочего ({work_sec}) нет: эмбеддинг "
                             "откатится на локальную модель")
    # 2. derived и каркас vault
    derived.mkdir(parents=True, exist_ok=True)
    (derived / "logs").mkdir(exist_ok=True)
    if skeleton is None:
        from core.config import default_vault_path
        from core.vault_template import build_vault

        source = Path(work_vault) if work_vault else default_vault_path()

        def skeleton(target: Path, kind: str) -> list[str]:
            return build_vault(
                target, kind, work_vault=source, journal_dir=folders.get(_inst.ENV_JOURNAL_DIR),
                ideas_dir=folders.get(_inst.ENV_IDEAS_DIR))

    res.skeleton = skeleton(vault, role)
    # 3. оверлей (последним среди данных: есть оверлей = экземпляр создан целиком)
    text = overlay_text(name, role=role, vault=vault, derived=derived, secrets_dir=sec,
                        port=int(port), work_url=work_url, folders={**folders, **capture})
    instances_dir.mkdir(parents=True, exist_ok=True)
    env_file.write_new(overlay, text)
    # 4. plist-ы
    uv = uv_bin_dir or _uv_bin_dir()
    la = Path(launchd_dir) if launchd_dir is not None else _LAUNCH_AGENTS
    la.mkdir(parents=True, exist_ok=True)
    for kind, blob in render_plists(name, port=int(port), derived=derived, engine_dir=engine_dir,
                                    uv_bin_dir=uv).items():
        target = la / f"{label_for(kind, name)}.plist"
        target.write_bytes(blob)
        res.plists[kind] = target
    if load:
        run = runner or _launchctl
        for kind, target in res.plists.items():
            run(["unload", str(target)])
            if run(["load", "-w", str(target)]) == 0:
                res.loaded.append(label_for(kind, name))
    return res


def _uv_bin_dir() -> str:
    import shutil

    found = shutil.which("uv")
    return str(Path(found).parent) if found else str(Path.home() / ".local" / "bin")


# ключи оверлея экземпляра: константами (читаем файл-оверлей, не окружение процесса)
KEY_VAULT, KEY_DERIVED, KEY_SECRETS = "DT_VAULT_PATH", "DT_DERIVED_ROOT", _inst.ENV_SECRETS_DIR
KEY_PORT, KEY_ROLE = "DT_WEB_PORT", _inst.ENV_ROLE
_OVERLAY_KEYS = (
    _inst.ENV_JOURNAL_DIR, _inst.ENV_IDEAS_DIR, _inst.ENV_CONTENT_DIRS, KEY_ROLE, KEY_VAULT,
    KEY_DERIVED, KEY_PORT, KEY_SECRETS, "DT_EMBED_OWNER", _inst.ENV_EMBED_URL, _inst.ENV_WORK_URL,
    _inst.ENV_WORK_TOKEN_FILE, _inst.ENV_UNTAGGED_LANE, "DT_TICKTICK_CAPTURE_PROJECT_NAME",
    "DT_TICKTICK_CAPTURE_PROJECT_ID")


def _read_overlay(path: Path) -> dict[str, str]:
    return {k: v for k in _OVERLAY_KEYS if (v := env_file.read_value(path, k)) is not None}


def list_instances(instances_dir: Path | None = None) -> list[str]:
    base = Path(instances_dir) if instances_dir is not None else _ENGINE_ROOT / "instances"
    if not base.is_dir():
        return []
    return sorted(p.stem for p in base.glob("*.env") if env_file.valid_instance_name(p.stem))


def instance_status(
    name: str, *, instances_dir: Path | None = None, launchd_dir: Path | None = None,
    health: Callable[[str], dict[str, Any] | None] | None = None,
    runner_list: Callable[[], str] | None = None,
) -> dict[str, Any]:
    """Статус экземпляра для CLI: оверлей, пути, plist-ы, ``/health`` (CLI, не демон).

    ``health(url)`` - инъекция (по умолчанию :func:`core.daemon.fetch_health_url`);
    ``runner_list`` - вывод ``launchctl list`` (по умолчанию живой). Ни токенов, ни секретов
    в ответе."""
    overlay = env_file.instance_overlay_path(name, instances_dir)
    if not overlay.is_file():
        return {"name": name, "exists": False}
    cfg = _read_overlay(overlay)
    la = Path(launchd_dir) if launchd_dir is not None else _LAUNCH_AGENTS
    if health is None:
        from core.daemon import fetch_health_url

        def health(url: str) -> dict[str, Any] | None:
            return fetch_health_url(url)

    port = int(cfg.get(KEY_PORT) or 0)
    listed = (runner_list() if runner_list else _launchctl_list())
    labels = {kind: label_for(kind, name) for kind in LABELS}
    h = health(f"http://127.0.0.1:{port}") if port else None
    return {
        "name": name, "exists": True, "overlay": str(overlay),
        "role": cfg.get(KEY_ROLE, _inst.ROLE_WORK),
        "vault": cfg.get(KEY_VAULT), "derived": cfg.get(KEY_DERIVED),
        "port": port, "secrets": cfg.get(KEY_SECRETS),
        "embed_url": cfg.get(_inst.ENV_EMBED_URL), "work_url": cfg.get(_inst.ENV_WORK_URL),
        "plists": {k: (la / f"{lab}.plist").is_file() for k, lab in labels.items()},
        "loaded": {k: bool(re.search(rf"(^|\s){re.escape(lab)}$", listed, re.M))
                   for k, lab in labels.items()},
        "health": ({"ok": bool(h.get("ok")), "instance": h.get("instance")} if h else None),
    }


def work_status(
    *, health: Callable[[str], dict[str, Any] | None] | None = None, port: int | None = None
) -> dict[str, Any]:
    """Рабочий экземпляр для ``dt instance status``: порт процесса и ``/health`` (CLI, не демон).

    Рабочий демон о личном не знает - здесь только его собственное состояние; ``instance`` в его
    ``/health`` отсутствует (рабочий экземпляр без оверлея)."""
    if health is None:
        from core.daemon import fetch_health_url

        def health(url: str) -> dict[str, Any] | None:
            return fetch_health_url(url)

    chosen = port or int(os.environ.get(KEY_PORT) or 8787)
    h = health(f"http://127.0.0.1:{chosen}")
    return {"name": "work", "role": _inst.ROLE_WORK, "port": chosen,
            "health": ({"ok": bool(h.get("ok")), "instance": h.get("instance")} if h else None)}


def _launchctl_list() -> str:  # pragma: no cover - боевой launchctl
    try:
        return subprocess.run(["launchctl", "list"], check=False,  # noqa: S607
                              capture_output=True, text=True).stdout
    except OSError:
        return ""


def remove_instance(
    name: str, *, instances_dir: Path | None = None, launchd_dir: Path | None = None,
    runner: Runner | None = None,
) -> dict[str, Any]:
    """Снять plist-ы экземпляра (``unload`` + удаление файлов) и его оверлей.

    Vault, derived и секреты НЕ трогаются (данные владельца; удалять руками). Возвращает отчёт.

    Под pytest отказ ``live_guard``, если ``instances_dir`` - настоящая папка движка (01.11: тест
    ``uninstall`` на дефолтном контексте снес боевой ``instances/personal.env``)."""
    overlay = env_file.instance_overlay_path(name, instances_dir)
    if "PYTEST_CURRENT_TEST" in os.environ:
        from core.config._roots import ENGINE_ROOT

        if overlay.resolve().is_relative_to(ENGINE_ROOT.resolve() / "instances"):
            raise PermissionError(
                f"live_guard: тест целится в боевой оверлей {overlay} - дай tmp instances_dir")
    la = Path(launchd_dir) if launchd_dir is not None else _LAUNCH_AGENTS
    run = runner or _launchctl
    removed: list[str] = []
    for kind in LABELS:
        target = la / f"{label_for(kind, name)}.plist"
        if target.is_file():
            run(["unload", str(target)])
            target.unlink()
            removed.append(target.name)
    cfg = _read_overlay(overlay) if overlay.is_file() else {}
    existed = overlay.is_file()
    if existed:
        overlay.unlink()
    return {"name": name, "plists_removed": removed, "overlay_removed": existed,
            "kept": [p for p in (cfg.get(KEY_VAULT), cfg.get(KEY_DERIVED),
                                 cfg.get(KEY_SECRETS)) if p]}
