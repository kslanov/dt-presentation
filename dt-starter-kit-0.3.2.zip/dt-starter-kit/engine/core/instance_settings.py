"""PERSONAL-2 п.1/п.6 - настройки ЭКЗЕМПЛЯРА: ``dt instance set`` и секции пульта.

Секции пульта - ``bridge`` и ``personal``.

Ручки живут в оверлее экземпляра (``engine/instances/<имя>.env``); писатель один -
:func:`core.config.env_file.set_key` (байт-точная правка одной строки, бэкап, права 600). Список
допустимых ключей и их проверка - здесь (:data:`FIELDS`): ключ вне списка и значение, не прошедшее
проверку, - отказ без записи.

Демон перечитывает ручки при вызове: после записи значение кладется и в ``os.environ`` процесса
(``apply_env=True``), поэтому ``pult_settings_get`` и ``bridge_scan`` видят его без рестарта;
отдельные процессы (launchd-джобы) берут новое значение из оверлея при старте.

Секция ``bridge``: ``min_score``, ``exclude``, ``snooze_days``, ``limit``, ``budget_s``;
``personal``: папки (``journal_dir``, ``ideas_dir``, ``content_dirs``, ``inbox``), ``index_exclude``
и источник захвата (``capture_project``, ``untagged_lane``; PERSONAL-3). Рабочий экземпляр (без
``DT_INSTANCE``) настроек этих секций не имеет: :class:`SettingsError` ``not_an_instance``.
"""

from __future__ import annotations

import os
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core import instance as _inst
from core.config import env_file
from core.personal import capture_source as _capture

__all__ = ["FIELDS", "SECTIONS", "Field", "SettingsError", "get_section", "normalize", "set_key",
           "set_section"]


class SettingsError(ValueError):
    """Отказ настройки: ``code`` - ``unknown_key`` | ``invalid_value`` | ``not_an_instance`` | …"""

    def __init__(self, code: str, detail: str) -> None:
        super().__init__(detail)
        self.code, self.detail = code, detail


def _float01(value: str) -> str:
    x = float(value)
    if not 0.0 <= x <= 1.0:
        raise ValueError("нужно число 0..1")
    return f"{x:g}"


def _posint(value: str) -> str:
    n = int(value)
    if n <= 0:
        raise ValueError("нужно целое больше нуля")
    return str(n)


def _corpus(value: str) -> str:
    v = value.strip().lower()
    if v not in ("vault", "both"):
        raise ValueError("нужно vault или both")
    return v


def _project(value: str) -> str:
    v = " ".join(value.split())
    if len(v) > 200:
        raise ValueError("слишком длинное имя списка")
    return v


def _lane(value: str) -> str:
    v = value.strip().lower()
    if v and v not in _inst.UNTAGGED_LANES:
        raise ValueError(f"нужно одно из: {', '.join(_inst.UNTAGGED_LANES)}")
    return v


def _dir(value: str) -> str:
    if not value.strip():
        return ""  # пусто - снять ручку (вернуться к дефолту)
    rel = _inst.safe_rel(value)
    if rel is None:
        raise ValueError("папка от корня vault: без абсолютного пути, '..' и .obsidian")
    return rel


def _dirs(value: str) -> str:
    items = [x for x in (v.strip() for v in value.split(",")) if x]
    return ",".join(_dir(x) for x in items)


def _globs(value: str) -> str:
    items = [x.strip().replace("\\", "/").lstrip("/") for x in value.split(",") if x.strip()]
    for item in items:
        if ".." in item.split("/"):
            raise ValueError("glob от корня vault: без '..'")
    return ",".join(items)


@dataclass(frozen=True)
class Field:
    section: str
    name: str  # имя в секции пульта
    key: str  # ручка оверлея
    check: Callable[[str], str]
    doc: str


FIELDS: tuple[Field, ...] = (
    Field("bridge", "min_score", "DT_BRIDGE_MIN_SCORE", _float01,
          "порог оценки кандидата моста (0..1)"),
    Field("bridge", "exclude", _inst.ENV_BRIDGE_EXCLUDE, _globs,
          "заметки вне моста (glob от корня vault, через запятую; пусто - без исключений)"),
    Field("bridge", "min_score_fts", "DT_BRIDGE_MIN_SCORE_FTS", _float01,
          "порог оценки для хита без семантики (чистый fts, 0..1)"),
    Field("bridge", "min_score_legacy", "DT_BRIDGE_MIN_SCORE_LEGACY", _float01,
          "порог оценки для хитов легаси рабочего (0..1; при корпусе both)"),
    Field("bridge", "work_corpus", "DT_BRIDGE_WORK_CORPUS", _corpus,
          "корпус рабочего поиска: vault | both (vault + легаси)"),
    Field("bridge", "min_body_chars", "DT_BRIDGE_MIN_BODY_CHARS", _posint,
          "короче (без служебных строк шаблона) - заметка-заглушка, не опрашивается"),
    Field("bridge", "min_quote_chars", "DT_BRIDGE_MIN_QUOTE_CHARS", _posint,
          "рабочая цитата короче - страница/кусок пропускается"),
    Field("bridge", "snooze_days", "DT_BRIDGE_SNOOZE_DAYS", _posint,
          "стоп пары после отказа, дней"),
    Field("bridge", "limit", "DT_BRIDGE_LIMIT", _posint, "хитов рабочего поиска на заметку"),
    Field("bridge", "budget_s", "DT_BRIDGE_BUDGET_S", _posint, "бюджет шага bridge, секунд"),
    Field("personal", "journal_dir", _inst.ENV_JOURNAL_DIR, _dir, "папка дневника"),
    Field("personal", "ideas_dir", _inst.ENV_IDEAS_DIR, _dir,
          "папка идей (#личное → заметка идеи; пусто - в инбокс)"),
    Field("personal", "content_dirs", _inst.ENV_CONTENT_DIRS, _dirs,
          "папки контента для подсказки размещения (через запятую)"),
    Field("personal", "inbox", _inst.ENV_INBOX, _dir, "инбокс личного vault"),
    Field("personal", "capture_project", _capture.NAME_KEY, _project,
          "список TickTick для захвата личного (имя или id; пусто - список рабочего)"),
    Field("personal", "untagged_lane", _inst.ENV_UNTAGGED_LANE, _lane,
          "полоса для задач без тега: skip | personal | journal | content (не skip - только при "
          "отдельном списке)"),
    Field("personal", "index_exclude", _inst.ENV_INDEX_EXCLUDE, _globs,
          "заметки вне индекса личного (glob от корня vault, через запятую)"),
)
SECTIONS = tuple(dict.fromkeys(f.section for f in FIELDS))
_BY_KEY = {f.key: f for f in FIELDS}
_BY_KEY[_capture.ID_KEY] = _BY_KEY[_capture.NAME_KEY]  # id списка - та же ручка capture_project
_BY_NAME = {(f.section, f.name): f for f in FIELDS}


def normalize(key: str, value: str) -> str:
    """Проверенное значение ручки; нет ручки или значение не подошло - :class:`SettingsError`."""
    field = _BY_KEY.get(key)
    if field is None:
        raise SettingsError("unknown_key", f"{key}: такой настройки у экземпляра нет "
                                           f"({', '.join(sorted(_BY_KEY))})")
    try:
        return field.check(str(value))
    except (ValueError, TypeError) as exc:
        raise SettingsError("invalid_value", f"{key}: {exc}") from exc


def _overlay(name: str | None, instances_dir: Path | None) -> tuple[str, Path]:
    chosen = name or _inst.instance_name()
    if not chosen:
        raise SettingsError("not_an_instance",
                            "это рабочий экземпляр: настройки bridge/personal - у личного")
    path = env_file.instance_overlay_path(chosen, instances_dir)
    if not path.is_file():
        raise SettingsError("no_overlay", f"оверлея экземпляра {chosen!r} нет ({path})")
    return chosen, path


def _guard(path: Path, writes: dict[str, str | None]) -> None:
    """PERSONAL-3 п.C2: ``untagged_lane != skip`` при списке захвата, совпадающем с рабочим, - отказ
    ``same_project`` (задачи без тега ушли бы в оба vault). ``writes`` - что собираются записать
    (``None`` - убрать ключ); проверяется состояние оверлея ПОСЛЕ записи."""
    keys = (_capture.ID_KEY, _capture.NAME_KEY, _inst.ENV_UNTAGGED_LANE)
    state = {k: (env_file.read_value(path, k) or "") for k in keys}
    for key, value in writes.items():
        state[key] = value or ""
    lane = state[_inst.ENV_UNTAGGED_LANE].strip().lower()
    if lane in ("", "skip"):
        return
    if _capture.same_project((state[_capture.ID_KEY].strip(), state[_capture.NAME_KEY].strip())):
        raise SettingsError("same_project", f"untagged_lane={lane} при общем с рабочим списке "
                                            f"захвата: {_capture.HINT}")


def _field_writes(field: Field, clean: str) -> dict[str, str | None]:
    """Что записать в оверлей для поля: ключ -> значение (``None`` - убрать ключ)."""
    if field.key == _capture.NAME_KEY:  # одно поле - два ключа: id списка либо имя
        if not clean:
            return {_capture.NAME_KEY: None, _capture.ID_KEY: None}
        if _capture.is_project_id(clean):
            return {_capture.ID_KEY: clean, _capture.NAME_KEY: None}
        return {_capture.NAME_KEY: clean, _capture.ID_KEY: None}
    if field.key == _inst.ENV_UNTAGGED_LANE and not clean:
        return {field.key: None}
    return {field.key: clean}


def _write(path: Path, writes: dict[str, str | None], *, apply_env: bool) -> bool:
    """Записать ключи в оверлей писателем ``env_file``; применить к процессу. ``True`` - что-то
    изменилось. Убранный ключ в процессе возвращается к значению ``engine/.env`` (слой ниже)."""
    changed = False
    for key, value in writes.items():
        edit = (env_file.unset_key(path, key) if value is None
                else env_file.set_key(path, key, value))
        changed = changed or edit.changed
        if apply_env:
            below = (env_file.read_value(env_file._ENGINE_DIR / ".env", key)
                     if value is None else value)
            if below is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = below
    return changed


def set_key(
    key: str, value: str, *, name: str | None = None, instances_dir: Path | None = None,
    apply_env: bool = True,
) -> env_file.EnvEdit:
    """Записать ручку в оверлей экземпляра (писатель ``env_file``) и применить к процессу."""
    clean = normalize(key, value)
    _chosen, path = _overlay(name, instances_dir)
    field = _BY_KEY[key]
    writes = _field_writes(field, clean)
    _guard(path, writes)
    apply = apply_env and (name is None or name == _inst.instance_name())
    changed = _write(path, writes, apply_env=apply)
    return env_file.EnvEdit(key, "replaced" if changed else "unchanged", path)


def _effective(f: Field) -> str:
    raw = os.environ.get(f.key)
    if f.key == _inst.ENV_BRIDGE_EXCLUDE:
        return ",".join(_inst.bridge_exclude())
    if f.key == _inst.ENV_INDEX_EXCLUDE:
        return ",".join(_inst.index_exclude())
    if f.key == "DT_BRIDGE_MIN_SCORE":
        from core.bridge.scan import min_score

        return f"{min_score():g}"
    if f.key == "DT_BRIDGE_SNOOZE_DAYS":
        from core.bridge.store import snooze_days

        return str(snooze_days())
    if f.key == "DT_BRIDGE_LIMIT":
        from core.bridge.scan import candidate_limit

        return str(candidate_limit())
    if f.key == "DT_BRIDGE_BUDGET_S":
        from core.bridge.scan import budget_s

        return f"{budget_s():g}"
    if f.key == _inst.ENV_JOURNAL_DIR:
        return _inst.personal_journal_dir()
    if f.key == _inst.ENV_IDEAS_DIR:
        return _inst.personal_ideas_dir() or ""
    if f.key == _inst.ENV_CONTENT_DIRS:
        return ",".join(_inst.personal_content_dirs())
    if f.key == _inst.ENV_INBOX:
        return _inst.personal_inbox()
    if f.key == _capture.NAME_KEY:  # свой список личного (пусто - наследует список рабочего)
        return str(_capture.describe()["project"])
    if f.key == _inst.ENV_UNTAGGED_LANE:
        return _inst.untagged_lane()
    return raw or ""


def get_section(section: str) -> dict[str, Any]:
    """Действующие значения секции: ``{поле: {value, key, doc, set}}`` (``set`` - есть ли ручка)."""
    if section not in SECTIONS:
        raise SettingsError("unknown_section", f"секции {section!r} нет ({', '.join(SECTIONS)})")
    if not _inst.instance_name():
        raise SettingsError("not_an_instance",
                            "это рабочий экземпляр: настройки bridge/personal - у личного")
    return {f.name: {"value": _effective(f), "key": f.key, "doc": f.doc, "set": _is_set(f)}
            for f in FIELDS if f.section == section}


def _is_set(f: Field) -> bool:
    if f.key == _capture.NAME_KEY:
        return bool(_capture.describe()["own"])
    return bool((os.environ.get(f.key) or "").strip())


def set_section(
    section: str, values: dict[str, Any], *, name: str | None = None,
    instances_dir: Path | None = None, apply_env: bool = True,
) -> dict[str, Any]:
    """Записать поля секции: сначала проверяются ВСЕ (одно битое - ничего не записано).

    Возвращает ``{changed: [поля], values: <секция после записи>}``."""
    if section not in SECTIONS:
        raise SettingsError("unknown_section", f"секции {section!r} нет ({', '.join(SECTIONS)})")
    plan: list[tuple[Field, str]] = []
    for fname, value in values.items():
        field = _BY_NAME.get((section, str(fname)))
        if field is None:
            raise SettingsError("unknown_key", f"{section}.{fname}: такого поля нет")
        plan.append((field, normalize(field.key, "" if value is None else str(value))))
    _chosen, path = _overlay(name, instances_dir)  # нет экземпляра/оверлея - отказ до первой записи
    merged: dict[str, str | None] = {}
    for field, clean in plan:
        merged.update(_field_writes(field, clean))
    _guard(path, merged)  # гард видит итоговое состояние всех полей разом (список + полоса)
    apply = apply_env and (name is None or name == _inst.instance_name())
    changed: list[str] = []
    for field, clean in plan:
        if _write(path, _field_writes(field, clean), apply_env=apply):
            changed.append(field.name)
    return {"changed": changed, "values": get_section(section) if apply_env else {}}
