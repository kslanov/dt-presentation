"""KIMI-INSTALL-1 - плагин Kimi ставится и проверяется командой (``dt plugin kimi --install``).

Kimi хранит плагины так (``KIMI_PLUGINS_DIR``): ``installed.json`` (``{version, plugins:[{id, root,
source, enabled, installedAt, updatedAt, originalSource}]}``) + ``managed/<id>/`` - копия каталога
плагина на момент установки. Plugin Builder делает ровно это; здесь то же командой.

Инварианты записи (в каталог Kimi пишем только это):
* ``managed/digital-twin/`` - копия сборки: во временный каталог рядом -> rename;
* своя запись ``digital-twin`` в ``installed.json`` (целиком через temp+rename, неизвестные поля и
  чужие записи сохраняются; без изменений формат файла - тот же ``indent=2``, тот же конец строки);
* снятие ``digital-twin-lean`` (запись + каталог) - наш же плагин спайка M2b, не чужой.

Корень Kimi - константа с переопределением ``DT_KIMI_PLUGINS_DIR`` (тесты - в tmp). Каталога нет
(Kimi не установлен) - отказ ``kimi_not_found``, каталог не создается. Под pytest запись в боевой
каталог (константу) запрещена кодом - ``kimi_live_guard``.

KIMI-INSTALL-2: модель развертывания на Kimi - **плагин = скиллы, MCP = ``mcp.json`` агента**. Kimi
Work 3.2.22 не поддерживает локальные MCP-плагины (классификатор: ``gateway-hosted`` либо
``unsupported-local-mcp``), поэтому сервер DT регистрируется там, откуда его берет агент
``kimi-code``: ``<KIMI_AGENT_HOME>/mcp.json``. ``install`` пишет туда ТОЛЬКО ключ
``mcpServers.digital-twin``.

HOSTS-ATTACH-1: запись - url демона (``{url: http://127.0.0.1:<порт>/mcp/lean, headers:
{Authorization: Bearer <rw>}}``, ``host_config.daemon_url_entry``), а не stdio-команда: хост
подключается к работающему движку (DAEMON-1), своего процесса не запускает; манифест плагина MCP не
несет. Токен сравнивается и пишется, но в вердикты/ошибки/логи не попадает. Правка - точечная
(``core/mcp_json_edit.py``): вставляется один член либо заменяется значение нашей записи (stdio-поля
старой записи снимаются целиком), все остальные байты файла (чужие серверы, неизвестные поля,
пробелы, переносы, CRLF, конец файла) остаются как были; запись - temp+rename. Нет каталога агента -
отказ ``kimi_agent_not_found`` (не создаем), битый JSON - отказ ``mcp_json_invalid`` без
перезаписи. Снятие ключа - вручную (``--uninstall`` нет). Каталог агента - константа с
переопределением ``DT_KIMI_AGENT_HOME``; под pytest запись в константу запрещена кодом.

``verify_install`` только читает: сверяет запись и манифест в Kimi со сборкой (версия, манифест,
набор и тексты скиллов, существование сервера на диске) -> ``{ok, installed, stale, reason}``.
``core`` не зависит от CLI/MCP.
"""

from __future__ import annotations

import json
import os
import shutil
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

__all__ = [
    "KIMI_AGENT_HOME",
    "KIMI_PLUGINS_DIR",
    "LEGACY_IDS",
    "PLUGIN_ID",
    "KimiInstallError",
    "install",
    "kimi_agent_home",
    "kimi_plugins_dir",
    "verify_install",
]

PLUGIN_ID = "digital-twin"
# наш же плагин спайка M2b (26.10): сервер из снятого worktree, скиллов нет - ставить поверх нельзя
LEGACY_IDS = ("digital-twin-lean",)
KIMI_PLUGINS_DIR = (
    Path.home() / "Library" / "Application Support" / "kimi-desktop" / "daimon-share" / "daimon"
    / "runtime" / "kimi-code" / "home" / "plugins"
)
# KIMI-INSTALL-2: домашний каталог агента ``kimi-code`` - в нем ``plugins/`` и ``mcp.json``
KIMI_AGENT_HOME = KIMI_PLUGINS_DIR.parent
ENV_VAR = "DT_KIMI_PLUGINS_DIR"
AGENT_ENV_VAR = "DT_KIMI_AGENT_HOME"
MCP_FILE = "mcp.json"
MCP_KEY = "digital-twin"
_MCP_FIELDS = ("url", "headers")  # HOSTS-ATTACH-1: url-форма (прежняя stdio - command/args/env/cwd)
INSTALLED = "installed.json"
MANIFEST = "kimi.plugin.json"
_COPY_IGNORE = shutil.ignore_patterns(".DS_Store", "__pycache__", "*.pyc")


class KimiInstallError(Exception):
    """Отказ установки с машиночитаемым кодом (``kimi_not_found``, ``build_invalid``, ...)."""

    def __init__(self, code: str, reason: str) -> None:
        super().__init__(f"{code}: {reason}")
        self.code = code
        self.reason = reason


def kimi_plugins_dir() -> Path:
    """Корень плагинов Kimi: ``DT_KIMI_PLUGINS_DIR`` либо константа машины."""
    override = os.environ.get(ENV_VAR, "").strip()
    return Path(override).expanduser() if override else KIMI_PLUGINS_DIR


def kimi_agent_home(plugins_dir: Path | None = None) -> Path:
    """Домашний каталог агента Kimi: ``DT_KIMI_AGENT_HOME``; иначе, если каталог плагинов задан явно
    (аргумент или ``DT_KIMI_PLUGINS_DIR``), - его родитель (раскладка ``home/plugins``); иначе
    константа машины. Явный корень плагинов не должен молча привести к записи в боевой
    ``mcp.json``."""
    override = os.environ.get(AGENT_ENV_VAR, "").strip()
    if override:
        return Path(override).expanduser()
    if plugins_dir is not None or os.environ.get(ENV_VAR, "").strip():
        return (plugins_dir if plugins_dir is not None else kimi_plugins_dir()).parent
    return KIMI_AGENT_HOME


def _now_iso(now: datetime | None = None) -> str:
    """Формат Kimi: ``2026-10-29T08:38:38.434Z`` (мс, Z)."""
    moment = (now or datetime.now(UTC)).astimezone(UTC)
    return moment.strftime("%Y-%m-%dT%H:%M:%S.") + f"{moment.microsecond // 1000:03d}Z"


def kimi_live_guard(root: Path) -> None:
    """Под pytest в боевой каталог Kimi не пишем: тест обязан задать ``DT_KIMI_PLUGINS_DIR``."""
    if "PYTEST_CURRENT_TEST" in os.environ and root.resolve() == KIMI_PLUGINS_DIR.resolve():
        raise KimiInstallError(
            "live_guard", f"тест целится в боевой каталог Kimi {root}: задай {ENV_VAR}")


def kimi_agent_live_guard(home: Path) -> None:
    """Под pytest в боевой каталог агента Kimi не пишем: нужен ``DT_KIMI_AGENT_HOME``."""
    if "PYTEST_CURRENT_TEST" in os.environ and home.resolve() == KIMI_AGENT_HOME.resolve():
        raise KimiInstallError(
            "live_guard", f"тест целится в боевой каталог агента Kimi {home}: "
            f"задай {AGENT_ENV_VAR}")


# --------------------------------------------------------------------------- #
# installed.json                                                              #
# --------------------------------------------------------------------------- #
def _read_installed(root: Path) -> tuple[dict[str, Any] | None, bool, str | None]:
    """``(документ | None, конец_строки_есть, ошибка)``: нет файла -> ``(None, True, None)``."""
    path = root / INSTALLED
    if not path.is_file():
        return None, True, None
    try:
        text = path.read_text(encoding="utf-8")
        data = json.loads(text)
    except (OSError, json.JSONDecodeError) as exc:
        return None, True, f"{path}: {exc}"
    if not isinstance(data, dict) or not isinstance(data.get("plugins"), list):
        return None, True, f"{path}: нет списка plugins"
    return data, text.endswith("\n"), None


def _write_installed(root: Path, data: dict[str, Any], trailing_newline: bool) -> None:
    """Целиком, temp+rename; формат как у Kimi (``indent=2``, кириллица как есть)."""
    path = root / INSTALLED
    text = json.dumps(data, ensure_ascii=False, indent=2) + ("\n" if trailing_newline else "")
    tmp = root / f".{INSTALLED}.dt-tmp-{os.getpid()}"
    try:
        tmp.write_text(text, encoding="utf-8")
        if path.exists():
            shutil.copymode(path, tmp)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def _entry(data: dict[str, Any], plugin_id: str) -> dict[str, Any] | None:
    for item in data["plugins"]:
        if isinstance(item, dict) and item.get("id") == plugin_id:
            return item
    return None


# --------------------------------------------------------------------------- #
# Сборка -> managed                                                           #
# --------------------------------------------------------------------------- #
def _read_manifest(directory: Path) -> tuple[dict[str, Any] | None, str | None]:
    path = directory / MANIFEST
    if not path.is_file():
        return None, f"нет {path}"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return None, f"{path}: {exc}"
    if not isinstance(data, dict):
        return None, f"{path}: не словарь"
    return data, None


def _skill_files(directory: Path) -> dict[str, bytes]:
    """``{имя скилла: байты SKILL.md}`` каталога плагина."""
    out: dict[str, bytes] = {}
    for item in sorted((directory / "skills").glob("*/SKILL.md")):
        out[item.parent.name] = item.read_bytes()
    return out


def _server_paths(manifest: dict[str, Any]) -> list[str]:
    """Пути, которые хост запустит: ``command`` и ``args[0]`` каждого MCP-сервера манифеста."""
    paths: list[str] = []
    servers = manifest.get("mcpServers")
    for conf in (servers.values() if isinstance(servers, dict) else []):
        if not isinstance(conf, dict):
            continue
        if isinstance(conf.get("command"), str):
            paths.append(conf["command"])
        args = conf.get("args")
        if isinstance(args, list) and args and isinstance(args[0], str):
            paths.append(args[0])
    return paths


def _check_build(build: Path) -> None:
    manifest, error = _read_manifest(build)
    if manifest is None:
        raise KimiInstallError("build_invalid", f"{error}; сначала `dt plugin kimi --out …`")
    if manifest.get("name") != PLUGIN_ID:
        raise KimiInstallError(
            "build_invalid", f"имя плагина в манифесте {manifest.get('name')!r}, ожидалось "
            f"{PLUGIN_ID!r}")
    if not _skill_files(build):
        raise KimiInstallError("build_invalid", f"в {build / 'skills'} нет ни одного SKILL.md")


def _swap_dir(build: Path, target: Path) -> None:
    """Копия сборки в ``target``: во временный каталог рядом -> rename (старый - в сторону, потом
    удалить). Недокопированное (сбой посреди) в ``target`` не видно."""
    managed = target.parent
    managed.mkdir(parents=True, exist_ok=True)
    tmp = managed / f".{target.name}.dt-tmp-{os.getpid()}"
    old = managed / f".{target.name}.dt-old-{os.getpid()}"
    shutil.rmtree(tmp, ignore_errors=True)
    shutil.copytree(build, tmp, ignore=_COPY_IGNORE)
    try:
        if target.exists() or target.is_symlink():
            os.rename(target, old)
        os.rename(tmp, target)
    except OSError:
        if old.exists() and not target.exists():
            os.rename(old, target)  # откат: старая копия на месте
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    shutil.rmtree(old, ignore_errors=True)


def _remove_managed(path: Path) -> None:
    if path.is_symlink():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)


# --------------------------------------------------------------------------- #
# mcp.json агента (KIMI-INSTALL-2)                                             #
# --------------------------------------------------------------------------- #
def _mcp_block() -> dict[str, Any] | None:
    """Ожидаемая запись ``mcpServers.digital-twin`` - url демона профиля lean с rw-токеном
    (``host_config.daemon_url_entry``); нет токена (``.secrets`` не созданы) - ``None``.

    Единый источник записи для ``install`` и сверки: из манифеста сборки блок больше не берется
    (манифест плагина MCP не несет)."""
    from core.host_config import daemon_url_entry

    try:
        return daemon_url_entry("lean", "rw")
    except ValueError:
        return None


def _read_mcp(home: Path) -> tuple[dict[str, Any] | None, str | None, str | None]:
    """``(документ | None, текст | None, ошибка)``: нет файла -> ``(None, None, None)``."""
    from core.mcp_json_edit import read_config

    return read_config(home / MCP_FILE)


def _write_mcp(home: Path, text: str) -> None:
    """Целиком, temp+rename, права как у прежнего файла."""
    from core.mcp_json_edit import write_text_atomic

    write_text_atomic(home / MCP_FILE, text)


def _new_mcp_text(
    text: str | None, doc: dict[str, Any] | None, block: dict[str, Any]
) -> tuple[str | None, str]:
    """``(новый текст | None если менять нечего, исход)``; исход created|added|updated|unchanged.
    Правка точечная (``core.mcp_json_edit.plan_member``); поля старой stdio-записи снимаются."""
    from core.mcp_json_edit import plan_member

    return plan_member(text, doc, MCP_KEY, block)


def install(
    build: Path, *, plugins_dir: Path | None = None, now: datetime | None = None,
    agent_home: Path | None = None,
) -> dict[str, Any]:
    """Поставить сборку ``build`` в Kimi: скиллы плагина + сервер в ``mcp.json`` агента.

    Возвращает ``{root, target, installed_at, updated_at, removed, mcp, mcp_path}`` (``removed`` -
    снятые устаревшие плагины; ``mcp`` - ``created|added|updated|unchanged``); отказ -
    :class:`KimiInstallError`. Все проверки (каталоги, сборка, оба JSON) - ДО первой записи: отказ
    не оставляет полуустановки."""
    root = Path(plugins_dir) if plugins_dir is not None else kimi_plugins_dir()
    home = Path(agent_home) if agent_home is not None else kimi_agent_home(plugins_dir)
    build = Path(build)
    kimi_live_guard(root)
    kimi_agent_live_guard(home)
    if not root.is_dir():
        raise KimiInstallError(
            "kimi_not_found", f"нет каталога плагинов Kimi: {root} (Kimi не установлен или не "
            f"запускался; другой путь - {ENV_VAR})")
    if not home.is_dir():
        raise KimiInstallError(
            "kimi_agent_not_found", f"нет каталога агента Kimi: {home} (агент kimi-code не "
            f"запускался; другой путь - {AGENT_ENV_VAR}); не создаю")
    _check_build(build)
    block = _mcp_block()
    if block is None:
        raise KimiInstallError(
            "no_token", "нет rw-токена демона (.secrets/web_token_rw / env): запись url в mcp.json "
            "без токена демон отвергнет; запусти демон (`bash ops/install_launchd.sh`) - токены "
            "создаются при старте")
    mcp_doc, mcp_text, mcp_error = _read_mcp(home)
    if mcp_error:
        raise KimiInstallError("mcp_json_invalid", f"{mcp_error}; не перезаписываю")
    data, trailing, error = _read_installed(root)
    if error:
        raise KimiInstallError("installed_json_invalid", f"{error}; не перезаписываю")
    if data is None:
        data = {"version": 1, "plugins": []}
    target = root / "managed" / PLUGIN_ID
    stamp = _now_iso(now)

    _swap_dir(build, target)

    existing = _entry(data, PLUGIN_ID)
    entry: dict[str, Any] = dict(existing) if existing else {}
    entry.update({
        "id": PLUGIN_ID, "root": str(target), "source": "local-path",
        "enabled": entry["enabled"] if isinstance(entry.get("enabled"), bool) else True,
        "installedAt": entry.get("installedAt") or stamp, "updatedAt": stamp,
        "originalSource": str(build.resolve()),
    })
    # устаревший плагин спайка: запись и/или каталог (Kimi сам может убрать запись, оставив каталог)
    removed = [legacy for legacy in LEGACY_IDS
               if _entry(data, legacy) is not None or (root / "managed" / legacy).exists()]
    plugins: list[Any] = [p for p in data["plugins"]
                          if not (isinstance(p, dict) and p.get("id") in LEGACY_IDS)]
    if existing is not None:
        plugins = [entry if p is existing else p for p in plugins]
    else:
        plugins.append(entry)
    data["plugins"] = plugins
    _write_installed(root, data, trailing)
    for legacy in LEGACY_IDS:  # каталог - после записи реестра: сбой раньше оставит согласованное
        _remove_managed(root / "managed" / legacy)
    new_text, mcp_outcome = _new_mcp_text(mcp_text, mcp_doc, block)
    if new_text is not None:
        _write_mcp(home, new_text)
    return {"root": str(root), "target": str(target), "installed_at": entry["installedAt"],
            "updated_at": stamp, "removed": removed, "mcp": mcp_outcome,
            "mcp_path": str(home / MCP_FILE)}


# --------------------------------------------------------------------------- #
# Проверка                                                                    #
# --------------------------------------------------------------------------- #
def _verdict(installed: bool, stale: list[str], reason: str, **extra: Any) -> dict[str, Any]:
    return {"ok": installed and not stale, "installed": installed, "stale": stale,
            "reason": reason, **extra}


def _legacy_problem(root: Path, legacy: str, entry: dict[str, Any] | None) -> str:
    """Почему устаревший плагин спайка плох: путь сервера, которого нет на диске."""
    base = Path(str((entry or {}).get("root") or root / "managed" / legacy))
    manifest, _ = _read_manifest(base)
    for path in _server_paths(manifest or {}):
        if not Path(path).exists():
            return f"сервер {path} не существует"
    return "плагин спайка M2b (без скиллов): ставить поверх нужно digital-twin"


def _mcp_state(home: Path, expected: dict[str, Any] | None) -> dict[str, Any]:
    """Регистрация сервера в ``mcp.json`` агента против ожидаемой url-записи (только чтение).

    ``{state, reason, path, stale}``: ``registered`` (url и заголовок Authorization совпадают) |
    ``stdio_legacy`` (старая stdio-команда ``server.py``: свой процесс движка на сессию - дрейф,
    лечит ``--install``) | ``missing`` (нет файла/ключа/каталога агента) | ``differs`` (url/токен не
    те) | ``invalid`` (битый JSON). ``stale`` - код вердикта (``mcp_missing``/``mcp_stdio_legacy``/
    ``mcp_differs``/``mcp_invalid``) или ``None``. Токен сравнивается, в ``reason`` не попадает."""
    path = home / MCP_FILE
    base = {"path": str(path)}
    if not home.is_dir():
        return {**base, "state": "missing", "stale": "mcp_missing",
                "reason": f"каталога агента Kimi нет: {home}"}
    doc, _, error = _read_mcp(home)
    if error:
        return {**base, "state": "invalid", "stale": "mcp_invalid",
                "reason": f"mcp.json не читается: {error}"}
    servers = (doc or {}).get("mcpServers")
    current = servers.get(MCP_KEY) if isinstance(servers, dict) else None
    if not isinstance(current, dict):
        why = "нет файла mcp.json" if doc is None else f"в mcp.json нет ключа {MCP_KEY}"
        return {**base, "state": "missing", "stale": "mcp_missing", "reason": why}
    if expected is not None and all(current.get(k) == expected.get(k) for k in _MCP_FIELDS):
        return {**base, "state": "registered", "stale": None, "reason": "",
                "url": current.get("url")}
    from core.host_config import VERDICT_LEGACY, _classify, daemon_port

    verdict = _classify(current, daemon_port())
    if verdict["verdict"] == VERDICT_LEGACY:
        return {**base, "state": "stdio_legacy", "stale": "mcp_stdio_legacy",
                "reason": "старая stdio-запись (свой процесс движка на сессию) - "
                          "`dt plugin kimi --install` заменит ее url демона"}
    why = verdict["reason"] or "url/Authorization не совпадают с ожидаемой записью"
    if expected is None:
        why = "нет rw-токена демона для сверки; " + why
    return {**base, "state": "differs", "stale": "mcp_differs",
            "reason": f"запись {MCP_KEY} в mcp.json расходится с ожидаемой: {why}"}


def verify_install(
    build: Path | None, *, plugins_dir: Path | None = None, agent_home: Path | None = None,
) -> dict[str, Any]:
    """Сверка Kimi со сборкой ``build`` (только чтение): плагин (скиллы) И MCP агента.

    К вердикту плагина (:func:`_verify_plugin`) добавляется ``mcp`` (``registered|stdio_legacy|
    missing|differs|invalid``), ``mcp_path`` и коды ``mcp_missing``/``mcp_stdio_legacy``/
    ``mcp_differs``/``mcp_invalid`` в ``stale``; ``ok`` - только при обоих. Ожидаемая запись - url
    демона профиля lean (:func:`_mcp_block`), из манифеста сборки не берется."""
    verdict = _verify_plugin(build, plugins_dir=plugins_dir)
    if not verdict.get("kimi_found"):
        return verdict
    home = Path(agent_home) if agent_home is not None else kimi_agent_home(plugins_dir)
    state = _mcp_state(home, _mcp_block())
    verdict["plugin_reason"] = verdict["reason"]  # расхождения плагина отдельно от MCP
    verdict["mcp"], verdict["mcp_path"] = state["state"], state["path"]
    verdict["mcp_reason"] = state["reason"]
    if state["stale"]:
        verdict["stale"] = [*verdict["stale"], state["stale"]]
        verdict["reason"] = "; ".join(filter(None, [verdict["reason"], state["reason"]]))
    verdict["ok"] = bool(verdict["installed"]) and not verdict["stale"]
    return verdict


def _verify_plugin(
    build: Path | None, *, plugins_dir: Path | None = None,
) -> dict[str, Any]:
    """Сверка плагина (скиллы, манифест) в Kimi со сборкой ``build`` (только чтение).

    ``stale`` - коды расхождений: id устаревшего плагина (``digital-twin-lean``), ``no_entry``,
    ``disabled``, ``no_manifest``, ``no_build``, ``version``, ``manifest``, ``server``,
    ``skills``; устаревший плагин спайка засчитывается и по записи, и по оставшемуся каталогу
    ``managed/<id>``. ``kimi_found`` ложь - каталога Kimi нет (не ошибка установки: для доктора
    это справка)."""
    root = Path(plugins_dir) if plugins_dir is not None else kimi_plugins_dir()
    if not root.is_dir():
        return _verdict(False, [], f"каталога Kimi нет: {root}", kimi_found=False)
    data, _, error = _read_installed(root)
    if error:
        return _verdict(False, ["installed_json"], f"installed.json не читается: {error}",
                        kimi_found=True)
    stale: list[str] = []
    reasons: list[str] = []
    for legacy in LEGACY_IDS:
        item = _entry(data, legacy) if data else None
        if item is not None or (root / "managed" / legacy).exists():
            stale.append(legacy)
            note = "" if item is not None else " (запись снята, каталог остался)"
            reasons.append(f"{legacy}{note}: {_legacy_problem(root, legacy, item)}")
    entry = _entry(data, PLUGIN_ID) if data else None
    if entry is None:
        stale.append("no_entry")
        reasons.append(f"в installed.json нет записи {PLUGIN_ID}")
        return _verdict(False, stale, "; ".join(reasons), kimi_found=True)

    extra: dict[str, Any] = {
        "kimi_found": True, "installed_at": entry.get("installedAt"),
        "updated_at": entry.get("updatedAt"),
    }
    if entry.get("enabled") is False:
        stale.append("disabled")
        reasons.append("плагин отключен в Kimi (enabled=false)")
    managed = Path(str(entry.get("root") or root / "managed" / PLUGIN_ID))
    installed_manifest, merr = _read_manifest(managed)
    if installed_manifest is None:
        stale.append("no_manifest")
        reasons.append(f"манифест в Kimi не читается: {merr}")
        return _verdict(True, stale, "; ".join(reasons), **extra)
    for path in _server_paths(installed_manifest):
        if not Path(path).exists():
            stale.append("server")
            reasons.append(f"сервер {path} не существует")
            extra["missing_server"] = path
            break
    build_dir = Path(build) if build is not None else None
    built, berr = (_read_manifest(build_dir) if build_dir is not None
                   else (None, "сборка не задана"))
    if build_dir is None or built is None:
        stale.append("no_build")
        reasons.append(f"сборки для сверки нет ({berr}): `dt plugin kimi --out …`")
        return _verdict(True, stale, "; ".join(reasons), **extra)
    if installed_manifest.get("version") != built.get("version"):
        stale.append("version")
        reasons.append(f"версия в Kimi {installed_manifest.get('version')}, в сборке "
                       f"{built.get('version')}")
    elif installed_manifest != built:
        stale.append("manifest")
        reasons.append("манифест в Kimi отличается от сборки (пути/сервер/скиллы в тексте)")
    have, want = _skill_files(managed), _skill_files(build_dir)
    if have != want:
        stale.append("skills")
        diff = sorted(set(have) ^ set(want)) or sorted(n for n in want if have[n] != want[n])
        reasons.append(f"скиллы в Kimi расходятся со сборкой: {', '.join(diff)}")
    return _verdict(True, stale, "; ".join(reasons) or "манифест и скиллы = сборка", **extra)
