"""MODEL-1 п.D - плагин Kimi как артефакт: версия, README подключения, статус сборки для доктора.

``dt plugin kimi --out DIR`` (``cli/dt_plugin.py``) собирает каталог плагина из реестра скиллов и
шаблона манифеста; здесь - то, что нужно и сборке, и доктору (``core`` не зависит от CLI/MCP):

* :func:`engine_version` - версия из ``pyproject.toml`` (манифест несет ее же);
* :func:`render_readme` - README каталога плагина: шаги подключения, самопроверка, Cursor;
* :func:`write_status` / :func:`read_status` - ``.derived/status/kimi-plugin.json``: когда собран,
  сколько скиллов, профиль, результат самопроверки - источник строки доктора «Плагин Kimi».
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import ENGINE_ROOT, status_dir

__all__ = [
    "STATUS_FILE",
    "engine_version",
    "plugin_skills",
    "read_status",
    "render_readme",
    "skills_digest",
    "status_path",
    "write_status",
]

STATUS_FILE = "kimi-plugin.json"
PROTOCOL_DOC = "docs/findings/model-1-close.md"


def engine_version(pyproject: Path | None = None) -> str:
    """``[project].version`` из ``pyproject.toml``; не прочитался - ``0.0.0`` (сборка не падает)."""
    from core.version import engine_version as release_version

    version = release_version(pyproject.parent if pyproject else None)
    return "0.0.0" if version == "unknown" else version


def skills_digest(skills: list[Any], owner_version: str = "") -> str:
    """Короткий отпечаток реестра скиллов (имя + текст) + версия профиля владельца, если ее скилл
    ``dt-owner`` в составе: по нему доктор видит устаревший плагин (правка ``rules.md`` без
    пересборки).

    Пустая ``owner_version`` не меняет хэш - дайджест плагина без профиля прежний."""
    h = hashlib.sha256()
    for sk in sorted(skills, key=lambda s: s.name):
        h.update(sk.name.encode())
        h.update(b"\0")
        h.update(sk.text.encode())
        h.update(b"\0")
    if owner_version:
        h.update(b"owner\0")
        h.update(owner_version.encode())
    return h.hexdigest()[:16]


def plugin_skills(
    base: list[Any], *, lint_tools: Iterable[str], profile_tools: Iterable[str],
) -> tuple[list[Any], dict[str, list[str]], str, str]:
    """Состав плагина: скиллы из git + сгенерированный ``dt-owner`` (PROFILE-1), подогнанные под
    профиль (:func:`core.skills.fit_profile`).

    ``(скиллы, skipped, owner_version, owner_note)``: ``owner_version`` - версия профиля владельца,
    если скилл вошел в плагин (иначе ``""``), ``owner_note`` - почему его нет (нет профиля / пустой
    ``rules.md`` / линтер / вне профиля), иначе ``""``. ОДНА функция для сборки и для доктора: что
    доктор ждет в плагине сейчас, то сборка и кладет."""
    from core.owner import load_profile
    from core.owner.export import SKILL_NAME, owner_skill
    from core.skills import fit_profile

    profile = load_profile()
    owner, note = owner_skill(profile, lint_tools)
    skills = [*base, owner] if owner is not None else list(base)
    fit, skipped = fit_profile(skills, profile_tools)
    included = owner is not None and any(s.name == SKILL_NAME for s in fit)
    if owner is not None and not included:
        note = "вне профиля: " + ", ".join(skipped.get(SKILL_NAME, []))
    return fit, skipped, (profile.version if included else ""), ("" if included else note)


def status_path() -> Path:
    return status_dir() / STATUS_FILE


def write_status(record: dict[str, Any], path: Path | None = None) -> Path:
    """Атомарно записать статус сборки (``tmp`` + ``replace``)."""
    target = Path(path) if path is not None else status_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(json.dumps(record, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    tmp.replace(target)
    return target


def read_status(path: Path | None = None) -> tuple[dict[str, Any] | None, str | None]:
    """``(запись | None, ошибка)``: нет файла -> ``(None, None)``; битый -> ``(None, причина)``."""
    target = Path(path) if path is not None else status_path()
    if not target.is_file():
        return None, None
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return None, f"{target}: {exc}"
    if not isinstance(data, dict):
        return None, f"{target}: не словарь"
    return data, None


def new_status(
    *, out: Path, version: str, profile: str, skills: list[Any], selftest_ok: bool | None,
    selftest_line: str = "", now: datetime | None = None,
    skipped: dict[str, list[str]] | None = None, profile_tools: Iterable[str] | None = None,
    owner_version: str = "",
) -> dict[str, Any]:
    """Статус сборки. ``skills`` - то, что реально в плагине (после ``fit_profile``);
    ``skipped`` - что отброшено профилем; ``profile_tools`` - инструменты профиля на момент сборки
    (по ним доктор пересчитывает, какие скиллы реестра подходят сейчас); ``owner_version`` - версия
    профиля владельца, с которой собран ``dt-owner`` (``""`` - скилла в плагине нет)."""
    return {
        "built_at": (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "version": version, "profile": profile, "out": str(out),
        "skills": sorted(s.name for s in skills),
        "skills_digest": skills_digest(skills, owner_version), "owner_version": owner_version,
        "skipped": dict(sorted((skipped or {}).items())),
        "profile_tools": sorted(profile_tools or []),
        "selftest_ok": selftest_ok, "selftest": selftest_line,
    }


def render_readme(
    *, version: str, profile: str, skills: list[str], built: str, engine: Path | None = None,
    skipped: dict[str, list[str]] | None = None, tools_n: int | None = None,
) -> str:
    """README каталога плагина (создается сборкой): подключение, самопроверка, Cursor, приемка.

    ``skills`` - скиллы, вошедшие в плагин (подмножество профиля, ``fit_profile``); ``skipped`` -
    отброшенные с перечнем недостающих инструментов; ``tools_n`` - число инструментов профиля."""
    root = engine or ENGINE_ROOT
    out = "plugins/kimi-work"
    listing = "\n".join(f"- `{n}`" for n in skills)
    tools_s = f" ({tools_n} инструментов)" if tools_n else ""
    off = ""
    if skipped:
        rows = "\n".join(f"- `{n}` - нет: {', '.join(t)}" for n, t in sorted(skipped.items()))
        off = (f"\n### Вне профиля {profile}\nНа хосте их не будет (инструментов нет в "
               "профиле, prompt велел бы сделать невозможное); работают на хосте с профилем "
               f"`pult|full`:\n{rows}\n")
    return f"""# Плагин «Digital Twin» для Kimi Work (v{version})

Собрано `dt plugin kimi` {built}: **{len(skills)} скиллов** (профиль `{profile}`{tools_s}); MCP
сервера в плагине НЕТ: инструменты DT приходят из демона движка (`com.dt.server`, url в `mcp.json`
агента). Каталог генерируется целиком - руками не править: пересобрать
`cd {root} && uv run python cli/dt.py plugin kimi --out <каталог>`.

## Подключение
1. Одна команда: собрать, самопроверить, поставить в Kimi и сверить установленное со сборкой
   ```bash
   cd {root} && uv run python cli/dt.py plugin kimi --out {out} --install
   ```
   **Модель развертывания на Kimi: плагин = скиллы, MCP = `mcp.json` агента.** Kimi Work 3.2.22
   не поддерживает локальные MCP-плагины (в бандле MCP плагина классифицируется как
   `gateway-hosted` либо `unsupported-local-mcp` и снимается), поэтому команда делает два дела:
   копирует каталог в `managed/digital-twin/` Kimi с записью в `installed.json` (скиллы; чужие
   записи не трогает, устаревший `digital-twin-lean` снимает) и регистрирует сервер в `mcp.json`
   агента `kimi-code` ТОЛЬКО ключом `mcpServers.digital-twin` = url демона
   (`http://127.0.0.1:<порт>/mcp/lean` + `Authorization: Bearer <rw-токен>`; остальные байты файла
   не меняются, старая stdio-запись заменяется целиком; снять - вручную). Демон должен быть
   установлен (`bash ops/install_launchd.sh`) - токены создаются при его старте. Затем
   **перезапустить Kimi Work и начать новую сессию**: скиллы подхватятся, а в `tools_added`
   появятся инструменты `digital-twin` (deferred, через `select_tools`). Проверка без записи:
   `uv run python cli/dt.py plugin kimi --verify-install` (скиллы и MCP отдельными строками; доктор:
   «Плагин Kimi … установлен в Kimi, MCP агента: url → :8787/lean»). Манифест содержит
   абсолютные пути этой машины.
2. Самопроверка (реестр: `tools/list` = профиль, prompts = скиллы профиля; при живом демоне -
   еще и `tools/list` по url):
   ```bash
   cd {root} && uv run python cli/dt.py plugin kimi --selftest
   cd {root} && uv run python mcp-server/server.py --selftest --transport http
   ```
3. Токен в записи - секрет пользователя: в чат не вставлять. Свой профиль/порт:
   `dt host-config kimi --profile {profile} --token-placeholder` печатает запись без токена.
4. Приемка на этом хосте - протокол `{PROTOCOL_DOC}`: прогнать проверенные задачи профиля
   дословно из `vault/_system/eval/golden-generation.yaml` (g1, g2, g5; g3 - вне профиля lean, g4 -
   после подтверждения К.), затем `uv run python cli/dt_eval.py --generation --host kimi`.

## Скиллы ({len(skills)})
{listing}
{off}
## Cursor и другие хосты
Cursor плагинов не берет: `uv run python cli/dt.py host-config cursor --profile {profile}` печатает
запись `mcpServers` (url демона) для `~/.cursor/mcp.json`; `--install` пишет ее сам (только свой
ключ, бэкап рядом), затем перезапустить Cursor; скиллы там приходят как MCP `prompts` сервера.
Cherry Studio: `dt host-config cherry` + `dt skills export cherry` (см. `docs/ops.md`).
"""
