"""Layer-B legacy-corpus ingest (ТЗ phase5).

Turns valuable legacy files (pptx/pdf/docx/xlsx/text/email) into markdown notes
inside the same ``vault/`` as curated layer A. This package holds the
deterministic, LLM-free pieces: text extraction (``extract``), discovery,
normalization, dedup, and note rendering. Stage 2 ships ``extract`` only.
"""
