"""Extraction cache for legacy docs (ТЗ phase5, layer B, stage 3).

Extraction (pdf/xlsx especially) is expensive, so each source's normalized text
+ metadata is cached as ``<derived>/legacy_extracted/<hash(source_path)>.json``.
A cached record is reused unless the source's ``mtime``/``size`` changed — that
is the incrementality guard for the file→markdown step (the note→index step has
its own manifest, Polish-2).

``extract_cached`` ties together :func:`core.legacy.extract.extract` and
:func:`core.legacy.normalize.normalize`, returning the cached/fresh record plus a
``hit`` flag. Deterministic, no LLM.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import legacy_extracted_path
from core.legacy.dedup import content_hash
from core.legacy.discover import LegacyFile
from core.legacy.extract import LegacyDoc, extract
from core.legacy.normalize import normalize

__all__ = [
    "CacheResult",
    "cache_file_path",
    "extract_cached",
    "peek_cached",
    "build_record",
    "build_record_from_doc",
    "load_cache_record",
]


@dataclass
class CacheResult:
    """Result of :func:`extract_cached`.

    ``record`` is the JSON-serializable extraction record; ``hit`` is ``True``
    when it came from the cache (no re-extraction), ``False`` when freshly built.
    """

    record: dict[str, Any]
    hit: bool


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def cache_file_path(source_path: str) -> Path:
    """``<derived>/legacy_extracted/<sha256(source_path)>.json`` for a source."""
    digest = hashlib.sha256(source_path.encode("utf-8")).hexdigest()
    return legacy_extracted_path() / f"{digest}.json"


def load_cache_record(path: Path) -> dict[str, Any] | None:
    """Read a cache record, or ``None`` if missing/malformed (rebuildable)."""
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    return data if isinstance(data, dict) else None


def _save_record(path: Path, record: dict[str, Any]) -> None:
    """Persist a cache record atomically (write-temp-then-replace)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(record, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    tmp.replace(path)


def build_record(lf: LegacyFile) -> dict[str, Any]:
    """Extract + normalize ``lf`` into a fresh record (no IO / no caching)."""
    return build_record_from_doc(lf, extract(lf.path))


def build_record_from_doc(lf: LegacyFile, doc: LegacyDoc) -> dict[str, Any]:
    """Normalize an already-extracted ``doc`` for ``lf`` into a fresh record.

    The body of :func:`build_record` once the extraction is in hand. Reused by the
    Outlook mail ingest (stage 8), which produces its ``doc`` from a live message
    via :func:`core.legacy.extract.extract_email_message` rather than from a file.
    No IO / no caching.
    """
    norm = normalize(
        doc,
        section=lf.section,
        client=lf.client,
        filename=lf.filename,
        era=lf.era,
    )
    # Dedup hashes the *content* (unit texts), NOT the provenance preamble — two
    # byte-identical sources in different folders must collapse to one note.
    return {
        "source_path": lf.source_path,
        "mtime": lf.mtime,
        "size": lf.size,
        "source_type": doc.source_type,
        "status": doc.status,
        "needs_ocr": doc.needs_ocr,
        "needs_conversion": doc.needs_conversion,
        "skip_reason": doc.skip_reason,
        "error": doc.error,
        "meta": doc.meta,
        "units": [
            {"kind": u.kind, "no": u.no, "title": u.title, "text": u.text}
            for u in doc.units
        ],
        "preamble": norm.preamble,
        "body": norm.body,
        "content_hash": content_hash(doc.text),
        "cached_at": _now_iso(),
    }


def extract_cached(lf: LegacyFile, *, force: bool = False) -> CacheResult:
    """Return ``lf``'s extraction record, reusing the cache when still valid.

    A cached record is reused iff its stored ``mtime`` and ``size`` both equal the
    source's current ones (and ``force`` is false); otherwise the source is
    re-extracted and the cache rewritten.
    """
    path = cache_file_path(lf.source_path)
    if not force:
        cached = _valid_cache(path, lf)
        if cached is not None:
            return CacheResult(record=cached, hit=True)

    record = build_record(lf)
    _save_record(path, record)
    return CacheResult(record=record, hit=False)


def _valid_cache(path: Path, lf: LegacyFile) -> dict[str, Any] | None:
    """Return the cached record iff it matches ``lf``'s mtime+size, else ``None``."""
    cached = load_cache_record(path)
    if (
        cached is not None
        and cached.get("mtime") == lf.mtime
        and cached.get("size") == lf.size
    ):
        return cached
    return None


def peek_cached(lf: LegacyFile) -> CacheResult:
    """Like :func:`extract_cached` but never writes the cache (for dry runs).

    Returns a valid cached record (``hit=True``) when present, otherwise builds a
    fresh record in memory (``hit=False``) without persisting it.
    """
    cached = _valid_cache(cache_file_path(lf.source_path), lf)
    if cached is not None:
        return CacheResult(record=cached, hit=True)
    return CacheResult(record=build_record(lf), hit=False)
