"""Exact-duplicate detection for legacy docs (ТЗ phase5, layer B, stage 3).

Legacy corpora are full of byte-for-byte repeats (About_EC_*.pptx copies,
re-sent ТКП). We collapse *exact* duplicates of the **normalized** text: the
first occurrence (in caller-provided order) is the representative and indexed;
the rest are marked ``duplicate_of`` and produce no note. Near-duplicate (fuzzy)
detection is explicitly out of scope here.

Deterministic, no LLM. Determinism of which copy wins is the caller's order —
pass ids sorted by ``source_path`` for reproducible representatives.
"""

from __future__ import annotations

import hashlib

__all__ = ["content_hash", "find_duplicates"]


def content_hash(text: str) -> str:
    """sha256 of the normalized text — the exact-duplicate key."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def find_duplicates(hashes: dict[str, str]) -> dict[str, str]:
    """Map each duplicate id → its representative id (first id seen per hash).

    ``hashes`` is an *ordered* mapping ``id → content_hash``; the first id for a
    given hash is the representative and is absent from the result, every later
    id with the same hash maps to it. Unique ids do not appear in the result.
    """
    first_for_hash: dict[str, str] = {}
    duplicate_of: dict[str, str] = {}
    for ident, digest in hashes.items():
        rep = first_for_hash.get(digest)
        if rep is None:
            first_for_hash[digest] = ident
        else:
            duplicate_of[ident] = rep
    return duplicate_of
