"""Legacy-corpus discovery (ТЗ phase5, layer B, stage 3).

Walks the configured ``legacy_roots`` and, for every file, computes the metadata
the rest of the pipeline needs — ``source_path`` (relative to the Bitrix root),
``era``/``section``/``client`` from the folder structure, ``mime`` — and applies
the config-driven exclusion rules:

- **noise/marketing** globs → excluded (kept out of the index, counted);
- **privacy** globs + surname tokens → skipped as personal data (never indexed,
  logged separately as ``skipped_privacy``).

Everything is config-driven (``core.config``) — no hardcoded patterns — and fully
deterministic: no LLM, results sorted by ``source_path``. This module decides
*what* to ingest; extraction/normalization/caching live in sibling modules.
"""

from __future__ import annotations

import fnmatch
import mimetypes
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

from core.config import (
    legacy_exclude_globs,
    legacy_privacy_contract_terms,
    legacy_privacy_globs,
    legacy_privacy_hr_folders,
    legacy_privacy_name_tokens,
    legacy_privacy_person_signal_terms,
    legacy_privacy_salary_terms,
    legacy_privacy_weak_hr_terms,
    legacy_roots,
    legacy_section_map,
)
from core.privacy import is_eval, is_nda

__all__ = [
    "LegacyFile",
    "DiscoveryResult",
    "discover",
    "file_metadata",
    "privacy_reason",
    "first_term_hit",
    "nfc",
]

# A root whose name looks like "2018-2023" names an era; the Bitrix root is its
# parent, so ``source_path`` is taken relative to that parent (era prefix kept).
_ERA_RE = re.compile(r"^\d{4}-\d{4}$")
# Leading folder numbering to strip before mapping a section ("00. Presale").
_SECTION_NUM_RE = re.compile(r"^\s*\d+\s*[.)]\s*")
# Office lock/temp files we never look at.
_SKIP_NAME_PREFIXES = ("~$", ".")


@dataclass
class LegacyFile:
    """A discovered source file slated for ingest, with its computed metadata."""

    path: Path  # absolute path on disk
    source_path: str  # posix path relative to the Bitrix root (includes era)
    filename: str
    ext: str  # lowercased, with leading dot ("" if none)
    size: int
    mtime: float
    era: str  # "2018-2023" / "2023-2026" / "" if undetermined
    section: str  # canonicalized first-level folder
    client: str  # second-level folder, if any
    mime: str


@dataclass
class ExcludedFile:
    """A file kept out of the index, with the rule that matched it."""

    source_path: str
    reason: str  # e.g. "glob:**/Сайт/**" or "privacy-glob:..." / "privacy-name:..."


@dataclass
class DiscoveryResult:
    """Outcome of a discovery pass over the roots."""

    files: list[LegacyFile] = field(default_factory=list)
    excluded: list[ExcludedFile] = field(default_factory=list)
    skipped_privacy: list[ExcludedFile] = field(default_factory=list)


# --------------------------------------------------------------------------- #
# Matching helpers                                                            #
# --------------------------------------------------------------------------- #


def nfc(text: str) -> str:
    """Normalize text to Unicode NFC (composed form).

    macOS stores filenames decomposed (NFD), while our config patterns/tokens
    (Cyrillic "шаблоны презентаций", "Сайт", "личное", surnames) are composed
    (NFC). Comparing a raw NFD path against an NFC pattern silently fails for
    Cyrillic — so **both sides** of every exclude/privacy/self-token comparison
    are funnelled through here first. Idempotent; safe to apply repeatedly.
    """
    return unicodedata.normalize("NFC", text)


def _glob_match(rel_posix: str, pattern: str) -> bool:
    """Case-insensitive glob over a relative posix path.

    The path is anchored with a leading "/" so ``**/X/**``-style patterns match a
    directory component ``X`` at any depth *including* the top level. ``**`` is
    reduced to ``*`` (fnmatch's ``*`` already crosses ``/``). Both sides are
    NFC-normalized so Cyrillic matches regardless of the source's normal form.
    """
    hay = "/" + nfc(rel_posix).lstrip("/")
    pat = nfc(pattern).replace("**", "*")
    return fnmatch.fnmatchcase(hay.lower(), pat.lower())


# Word/stem matching over Unicode tokens (underscore is a SEPARATOR, so
# "Оклад_2022" tokenizes to ["оклад", "2022"] and a stem still matches).
_TOKEN_RE = re.compile(r"[^\W_]+", re.UNICODE)


def _tokens(text: str) -> list[str]:
    """Lowercased Unicode word tokens (letters/digits; ``_`` and punctuation split)."""
    return _TOKEN_RE.findall(nfc(text).lower())


def _term_hits(tokens: list[str], term: str) -> bool:
    """Whether ``term`` matches any token: whole-word for short (≤3) abbreviations
    (``сз``/``гпх``/``hr``), stem-prefix for longer terms (``зарплат``→``зарплата``)."""
    t = nfc(term).lower()
    if len(t) <= 3:
        return any(tok == t for tok in tokens)
    return any(tok.startswith(t) for tok in tokens)


def _first_hit(tokens: list[str], terms: list[str]) -> str | None:
    """First term in ``terms`` that matches a token, else ``None``."""
    for term in terms:
        if _term_hits(tokens, term):
            return term
    return None


def first_term_hit(text: str, terms: list[str] | tuple[str, ...]) -> str | None:
    """Первый из ``terms``, совпавший со словом ``text`` (те же правила слово/основа, что у A1)."""
    return _first_hit(_tokens(text), list(terms))


def _is_hr_folder(segment: str) -> bool:
    """A path segment is an HR folder when a word-token matches an HR name, or it
    is a salary-stem folder (``Зарплата``/``Оклады``)."""
    toks = _tokens(segment)
    hr = set(legacy_privacy_hr_folders())
    if any(tok in hr for tok in toks):
        return True
    return any(tok.startswith("зарплат") or tok.startswith("оклад") for tok in toks)


def privacy_reason(
    rel_posix: str,
    *,
    salary_terms: list[str] | None = None,
    surname_rule: bool = True,
    context_terms: list[str] | None = None,
) -> str | None:
    """Return the privacy rule matching this path/text, or ``None`` (never index).

    Word/stem-based (decision К., stage 8b/8c), reused verbatim by the mail
    ingest's participant/subject probe. Rules, in order:

    * **A1** — a STRONG salary term (``оклад``/``зарплат``/``вилк``/``личн``) as a
      word in the **file name** → privacy. (``Доклад`` ≠ ``оклад``.)
    * **A1b** — a WEAK HR term (``кадр``/``штат``) in the name, but ONLY with a
      personal signal (``справк``/``выписк``/``расписани``/… or a strong term) in
      the name/path, or inside an HR/ГПХ folder. Alone they index (HR-system
      ТЗ/methodology is solution knowledge К. keeps).
    * **A3** — inside an HR/ГПХ folder (or with ``ГПХ`` anywhere), a file whose
      **name** carries a contract term (``договор``/``ГПХ``/…) → privacy. The rest
      of such folders index.
    * **A2** — a **surname** token, but ONLY together with a salary/ГПХ/HR/contract
      context somewhere in the path. A surname alone never filters.

    A trailing explicit glob escape hatch (``DT_LEGACY_PRIVACY_GLOBS``) is honored
    last. The email probe arrives as a single ``/``-free segment, so it is matched
    as one "name" (A1/A1b/A2 apply; folder rule A3 is naturally inert).

    ``salary_terms`` (MAIL-FILTER-1) подменяет набор A1-терминов (почта сужает его, пока в теме нет
    зарплатного контекста); ``surname_rule=False`` отключает A2 (почта: Sent - свои письма с
    договором клиенту не персональные данные). Для файлов оба параметра не заданы - прежнее.

    ``context_terms`` (MAIL-PRIVACY-2) подменяет контекст A2 (``legacy_privacy_contract_terms()``):
    почта передает его без голого «договор» - коммерческая переписка не персональные данные. На
    A1/A1b/A3 не влияет; для файлов не задан - прежнее, байт-в-байт.
    """
    norm = nfc(rel_posix)
    segments = [s for s in norm.split("/") if s]
    name = segments[-1] if segments else norm
    name_tokens = _tokens(name)
    path_tokens = _tokens(norm)
    folder_segments = segments[:-1]

    contract_terms = legacy_privacy_contract_terms()
    gph_present = _term_hits(path_tokens, "гпх")
    in_hr_folder = any(_is_hr_folder(seg) for seg in folder_segments)

    # A1 — strong salary term in the file name.
    hit = _first_hit(
        name_tokens, legacy_privacy_salary_terms() if salary_terms is None else salary_terms
    )
    if hit is not None:
        return f"privacy-term:{hit}"

    # A1b — weak HR term (кадр/штат) only with a personal signal in the name/path
    # or inside an HR/ГПХ folder; alone it is HR-system ТЗ/methodology (kept).
    weak = _first_hit(name_tokens, legacy_privacy_weak_hr_terms())
    if weak is not None and (
        in_hr_folder
        or gph_present
        or _first_hit(path_tokens, legacy_privacy_person_signal_terms()) is not None
    ):
        return f"privacy-term:{weak}"

    # A3 — contract-named file inside an HR/ГПХ folder (ГПХ anywhere counts).
    if in_hr_folder or gph_present:
        contract_in_name = _first_hit(name_tokens, contract_terms)
        if contract_in_name is not None:
            return f"privacy-contract:{contract_in_name}"

    # A2 — surname only with salary/ГПХ/HR/contract context.
    has_context = (
        in_hr_folder
        or gph_present
        or _first_hit(path_tokens, contract_terms if context_terms is None else context_terms)
        is not None
    )
    if has_context and surname_rule:
        surname = _first_hit(path_tokens, legacy_privacy_name_tokens())
        if surname is not None:
            return f"privacy-name:{surname}"

    # Explicit glob escape hatch (env-supplied; empty by default).
    for pattern in legacy_privacy_globs():
        if _glob_match(rel_posix, pattern):
            return f"privacy-glob:{pattern}"
    return None


def _exclude_reason(rel_posix: str) -> str | None:
    """Return the noise/marketing glob matching this path, or ``None``."""
    for pattern in legacy_exclude_globs():
        if _glob_match(rel_posix, pattern):
            return f"glob:{pattern}"
    return None


# --------------------------------------------------------------------------- #
# Metadata                                                                    #
# --------------------------------------------------------------------------- #


def _section_of(raw: str) -> str:
    """Strip "NN. " numbering and canonicalize via the configurable section map.

    The lookup key and fallback are NFC-normalized so an NFD folder name off a
    Mac still hits the (NFC) section map.
    """
    stripped = nfc(_SECTION_NUM_RE.sub("", raw).strip())
    return legacy_section_map().get(stripped.lower(), stripped)


def file_metadata(path: Path, root: Path) -> LegacyFile:
    """Compute :class:`LegacyFile` metadata for ``path`` under ingest ``root``.

    ``era`` is the root's name when it looks like ``YYYY-YYYY``; ``source_path`` is
    then taken relative to the root's parent (Bitrix root) so the era prefixes it.
    ``section``/``client`` come from the first/second folder levels under the root.
    """
    root = root.resolve()
    path = path.resolve()
    era = root.name if _ERA_RE.match(root.name) else ""
    base = root.parent if era else root

    # Normalize every derived string to NFC at this single point so matching,
    # rendering, tags and the manifest are all consistent regardless of the
    # filesystem's normal form (macOS yields NFD).
    source_path = nfc(path.relative_to(base).as_posix())
    inner_parts = path.relative_to(root).parts
    dirs = inner_parts[:-1]  # drop the filename
    section = _section_of(dirs[0]) if dirs else ""
    client = nfc(dirs[1]) if len(dirs) >= 2 else ""

    stat = path.stat()
    return LegacyFile(
        path=path,
        source_path=source_path,
        filename=nfc(path.name),
        ext=path.suffix.lower(),
        size=stat.st_size,
        mtime=stat.st_mtime,
        era=era,
        section=section,
        client=client,
        mime=mimetypes.guess_type(path.name)[0] or "",
    )


# --------------------------------------------------------------------------- #
# Discovery                                                                   #
# --------------------------------------------------------------------------- #


def _iter_files(root: Path):
    """Yield non-hidden, non-lock files under ``root`` (deterministic order)."""
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if any(path.name.startswith(pfx) for pfx in _SKIP_NAME_PREFIXES):
            continue
        yield path


def discover(roots: list[Path] | None = None) -> DiscoveryResult:
    """Walk ``roots`` (default: ``config.legacy_roots()``) → :class:`DiscoveryResult`.

    Privacy is checked first (a personal-data file is never merely "excluded"),
    then noise globs; whatever survives is an ingest candidate. Files are returned
    sorted by ``source_path`` for stable, reproducible runs.
    """
    roots = roots if roots is not None else legacy_roots()
    result = DiscoveryResult()
    for root in roots:
        root = Path(root)
        if not root.is_dir():
            continue
        for path in _iter_files(root):
            meta = file_metadata(path, root)
            rel = meta.source_path
            # NDA-1: an _nda path is never indexed — enforced here too so the
            # knowledge ingest (INGEST-1 reuses ingest_corpus→discover) can't leak it.
            if is_nda(rel):
                result.skipped_privacy.append(ExcludedFile(rel, "nda"))
                continue
            # EVAL-HYGIENE-1: карантин прогонов (``_eval``) - не знание, тот же класс маркера
            if is_eval(rel):
                result.skipped_privacy.append(ExcludedFile(rel, "eval_quarantine"))
                continue
            privacy = privacy_reason(rel)
            if privacy is not None:
                result.skipped_privacy.append(ExcludedFile(rel, privacy))
                continue
            excluded = _exclude_reason(rel)
            if excluded is not None:
                result.excluded.append(ExcludedFile(rel, excluded))
                continue
            result.files.append(meta)

    result.files.sort(key=lambda f: f.source_path)
    result.excluded.sort(key=lambda e: e.source_path)
    result.skipped_privacy.sort(key=lambda e: e.source_path)
    return result
