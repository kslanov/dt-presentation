"""Deterministic text extractors for legacy files (ТЗ phase5, layer B, stage 2).

Each file type has an extractor that returns a single :class:`LegacyDoc`: the
extracted text split into provenance-carrying *units* (slide / page / section /
sheet / email / block), plus the flat full text and per-type metadata. The
public entry point is :func:`extract`, which dispatches on file extension.

Invariants:
- **No LLM, fully deterministic.** Pure parsing — same bytes in, same text out.
- **Robust to broken files.** Any parser exception is caught and turned into
  ``status="error"`` (with the message) — extraction of one bad file never
  aborts a batch.
- **Parser libraries are lazy-imported** inside each extractor, so importing
  this module costs nothing and ``core/`` stays usable without the optional
  ``parsers`` extra installed.

What this module does *not* do (later stages): discovery/exclusion/privacy
(``discover.py``), preamble/hub-link normalization (``normalize.py``), dedup
(``dedup.py``), markdown rendering, and indexing. Extraction here is raw text +
provenance only.

CODE-4: this is a **facade** over a domain-split package. ``_base`` holds the
types, statuses, shared helpers and the **format registry**; the per-format
submodules (``_text``/``_pdf``/``_email``/``_office``) each self-register their
extensions on import. Importing them below is what populates the registry, and
:func:`extract` is a **pure registry lookup** — no ``if/elif`` over formats. A
new format is a new submodule + a ``register`` call, with **zero** changes here
(open/closed). The public surface is frozen — ``__all__`` is identical (by set,
7 names) to the pre-split ``core/legacy/extract.py`` and dispatch behaviour
(handler per ext, ok/skipped/error/needs_conversion buckets, error-string format)
is byte-identical.
"""

from __future__ import annotations

from pathlib import Path

# Import the per-format submodules for their registration side-effects — this
# populates the registry the dispatcher reads. Adding a format means adding a
# submodule + a ``register`` call there; this list grows, the dispatcher does not.
from . import _email, _office, _pdf, _text  # noqa: F401 — registration side-effect
from ._base import (
    STATUS_ERROR,
    STATUS_OK,
    STATUS_SKIPPED,
    LegacyDoc,
    LegacyUnit,
    get_extractor,
)

# The LibreOffice-conversion seam. These live in ``_base`` but are re-exported
# here (redundant alias = intentional re-export) because this facade module is
# the single monkeypatch point — ``_base._convert_then`` reads them back off this
# module, exactly as the pre-split monolith did (tests patch them here). Not part
# of the frozen public ``__all__`` (they were never in it).
from ._base import _convert_to as _convert_to
from ._base import _soffice_available as _soffice_available
from ._base import _soffice_bin as _soffice_bin
from ._email import extract_email_message

__all__ = [
    "LegacyUnit",
    "LegacyDoc",
    "extract",
    "extract_email_message",
    "STATUS_OK",
    "STATUS_SKIPPED",
    "STATUS_ERROR",
]


def extract(path: str | Path) -> LegacyDoc:
    """Extract text from ``path``, dispatching on its extension.

    Never raises for content reasons: a missing file or a parser failure becomes
    ``status="error"``, an unsupported type becomes ``status="skipped"``, and a
    legacy binary needing an unavailable LibreOffice convert becomes
    ``needs_conversion`` (a recoverable bucket, not an error).

    Dispatch is a pure registry lookup (:func:`core.legacy.extract._base.get_extractor`):
    there is deliberately **no per-format branching** here — the extension →
    handler binding lives with each format's submodule.
    """
    path = Path(path)
    ext = path.suffix.lower()
    source_type = ext.lstrip(".") or "unknown"

    if not path.is_file():
        return LegacyDoc(
            source_type=source_type,
            status=STATUS_ERROR,
            error=f"file not found: {path}",
        )

    extractor = get_extractor(ext)
    if extractor is None:
        return LegacyDoc(
            source_type=source_type,
            status=STATUS_SKIPPED,
            skip_reason=f"unsupported:{source_type}",
        )

    try:
        return extractor(path, source_type)
    except Exception as exc:  # noqa: BLE001 — robustness: never abort a batch
        return LegacyDoc(
            source_type=source_type,
            status=STATUS_ERROR,
            error=f"{type(exc).__name__}: {exc}",
        )
