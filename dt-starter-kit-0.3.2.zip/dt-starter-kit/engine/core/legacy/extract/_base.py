"""Extractor package base — types, statuses, shared helpers, format registry (CODE-4).

The leaf of the package's internal import graph: every per-format submodule
(``_text``/``_pdf``/``_email``/``_office``) imports from here and nothing here
imports a submodule, so there are no cycles. Moved verbatim out of the pre-split
``core/legacy/extract.py`` — behaviour is byte-identical.

The **registry** replaces the old ``if/elif`` ladder: each per-format submodule
calls :func:`register` on import to bind its extensions to a handler, and the
facade's ``extract`` does a pure :func:`get_extractor` lookup. Adding a format is
a new submodule + ``register`` call — the dispatcher never changes (open/closed).

Invariants (unchanged from the monolith):
- **No LLM, fully deterministic.** Pure parsing — same bytes in, same text out.
- **Robust to broken files.** ``extract`` turns any parser exception into
  ``status="error"``; a batch never aborts.
- **Parser libraries are lazy-imported** inside each handler, so importing the
  package costs nothing and ``core/`` stays usable without the ``parsers`` extra.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Extraction dispositions. `ok` → text was extracted; `skipped` → recognized but
# intentionally not extracted (unsupported binary type, or a pdf that needs OCR);
# `error` → a parser raised on a corrupt/unreadable file.
STATUS_OK = "ok"
STATUS_SKIPPED = "skipped"
STATUS_ERROR = "error"


@dataclass
class LegacyUnit:
    """One provenance unit of an extracted document.

    ``kind`` is the unit granularity (``slide``/``page``/``section``/``sheet``/
    ``email``/``block``); ``no`` is its 1-based index where meaningful (slide/
    page/sheet number), else ``None``; ``title`` is an optional human label
    (sheet name, section heading). ``text`` is the unit's extracted text.
    """

    kind: str
    text: str
    no: int | None = None
    title: str = ""


@dataclass
class LegacyDoc:
    """Result of extracting one legacy file.

    ``text`` is the flat concatenation of all unit texts (convenience for hashing
    / quick checks); ``units`` carries the same content split for provenance.
    ``meta`` holds per-type extras (email headers, sheet names, truncation flags).
    On a non-``ok`` status ``units``/``text`` are empty and ``error``/``skip_reason``
    explain why; ``needs_ocr`` marks an image-only pdf (body deliberately empty —
    OCR is a separate sub-phase); ``needs_conversion`` marks a legacy binary
    (old ``.doc``/``.ppt`` or broken OOXML) that requires a LibreOffice convert
    that was unavailable — a recoverable bucket distinct from ``error``.
    """

    source_type: str
    status: str = STATUS_OK
    units: list[LegacyUnit] = field(default_factory=list)
    needs_ocr: bool = False
    needs_conversion: bool = False
    skip_reason: str = ""
    error: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def text(self) -> str:
        """Flat full text — non-empty unit texts joined by blank lines."""
        return "\n\n".join(u.text for u in self.units if u.text.strip())


# --------------------------------------------------------------------------- #
# Format registry (open/closed dispatch)                                       #
# --------------------------------------------------------------------------- #

# An extractor takes the file path + its ``source_type`` (extension without the
# dot) and returns a :class:`LegacyDoc`. Handlers self-register their extensions.
Extractor = Callable[[Path, str], "LegacyDoc"]

_REGISTRY: dict[str, Extractor] = {}


def register(*exts: str) -> Callable[[Extractor], Extractor]:
    """Decorator: bind ``exts`` (``".docx"``, …) to the decorated handler.

    Also usable non-decorated — ``register(".txt")(handler)`` — so a submodule can
    register a handler defined elsewhere (e.g. the base text reader). Extensions
    are lower-cased; a later registration for the same ext wins (last import).
    """

    def deco(fn: Extractor) -> Extractor:
        for ext in exts:
            _REGISTRY[ext.lower()] = fn
        return fn

    return deco


def get_extractor(ext: str) -> Extractor | None:
    """Return the handler registered for ``ext`` (lower-cased), or ``None``."""
    return _REGISTRY.get(ext.lower())


# --------------------------------------------------------------------------- #
# Shared helpers                                                               #
# --------------------------------------------------------------------------- #


def _clean(text: str) -> str:
    """Trim trailing whitespace per line and drop a trailing blank tail."""
    return "\n".join(line.rstrip() for line in text.splitlines()).strip()


def _extract_text(path: Path, source_type: str) -> LegacyDoc:
    """txt/md/csv/tsv/log → one block, read as UTF-8 (lossy on bad bytes)."""
    raw = path.read_text(encoding="utf-8", errors="replace")
    body = _clean(raw)
    units = [LegacyUnit(kind="block", text=body)] if body else []
    return LegacyDoc(source_type=source_type, units=units)


# --------------------------------------------------------------------------- #
# LibreOffice headless conversion (legacy binary recovery, ТЗ phase5 8b)       #
# --------------------------------------------------------------------------- #

# Seconds to allow a single soffice conversion before giving up (a stuck convert
# must not hang a batch). Override with DT_SOFFICE_TIMEOUT.
_SOFFICE_TIMEOUT_DEFAULT = 120


def _soffice_bin() -> str | None:
    """Path to a LibreOffice CLI (``soffice``/``libreoffice``), or ``None``."""
    import os
    import shutil

    override = os.environ.get("DT_SOFFICE_BIN")
    if override:
        return override if shutil.which(override) or Path(override).exists() else None
    return shutil.which("soffice") or shutil.which("libreoffice")


def _soffice_available() -> bool:
    """Whether a LibreOffice CLI is on PATH (gates the conversion fallback)."""
    return _soffice_bin() is not None


def _convert_to(path: Path, target_ext: str) -> Path | None:
    """Convert ``path`` to ``target_ext`` via headless LibreOffice (read-only on
    the source). Returns the converted temp file, or ``None`` if soffice is
    missing or produced no output. Raises only on a subprocess error (caught by
    :func:`extract`)."""
    import os
    import subprocess
    import tempfile

    binp = _soffice_bin()
    if not binp:
        return None
    timeout = _SOFFICE_TIMEOUT_DEFAULT
    raw_to = os.environ.get("DT_SOFFICE_TIMEOUT")
    if raw_to and raw_to.strip().isdigit() and int(raw_to) > 0:
        timeout = int(raw_to)
    outdir = tempfile.mkdtemp(prefix="dt_soffice_")
    cmd = [
        binp,
        "--headless",
        "--convert-to",
        target_ext,
        "--outdir",
        outdir,
        str(path),
    ]
    subprocess.run(  # noqa: S603 — cmd built from our own paths/extensions
        cmd, capture_output=True, text=True, timeout=timeout, check=False
    )
    out = Path(outdir) / f"{path.stem}.{target_ext}"
    return out if out.is_file() else None


def _convert_then(
    path: Path, source_type: str, target_ext: str, parser: Any
) -> LegacyDoc:
    """soffice-convert ``path`` to ``target_ext`` and run ``parser`` on the result.

    Graceful by contract: soffice missing → ``needs_conversion`` sentinel (not an
    error); conversion yielding no file → ``error``. The converted temp tree is
    always cleaned. If the converted file still fails to parse, that exception
    propagates to :func:`extract`'s handler (→ ``error``) — never re-converted.

    ``_soffice_available`` / ``_convert_to`` are resolved off the public
    ``core.legacy.extract`` module (not the local names) so the single monkeypatch
    seam is the package facade — byte-identical to the pre-split monolith, where
    these lived on that same module and tests patch them there. A lazy import
    keeps ``_base`` a leaf at import time (the facade is fully initialised by the
    time any conversion actually runs).
    """
    import shutil

    from core.legacy import extract as _facade

    if not _facade._soffice_available():
        return LegacyDoc(
            source_type=source_type,
            status=STATUS_SKIPPED,
            needs_conversion=True,
            skip_reason=f"needs_conversion:{source_type}",
        )
    converted = _facade._convert_to(path, target_ext)
    if converted is None:
        return LegacyDoc(
            source_type=source_type,
            status=STATUS_ERROR,
            error=f"LibreOffice conversion to {target_ext} produced no output",
        )
    try:
        doc = parser(converted, source_type)
    finally:
        shutil.rmtree(converted.parent, ignore_errors=True)
    return doc


def _is_package_error(exc: Exception) -> bool:
    """Whether ``exc`` means "not a valid OOXML package" → try conversion.

    Covers python-pptx/docx ``PackageNotFoundError`` (missing file / non-zip /
    old binary renamed to OOXML) and openpyxl ``InvalidFileException`` /
    ``zipfile.BadZipFile`` (e.g. a real ``.xls`` saved as ``.xlsx``). Matched by
    class name to avoid importing the optional parser libs here.
    """
    return type(exc).__name__ in {
        "PackageNotFoundError",
        "BadZipFile",
        "InvalidFileException",
    }


# --------------------------------------------------------------------------- #
# Email text assembly (shared by the .eml/.msg extractors + live-Outlook map)  #
# --------------------------------------------------------------------------- #


def _email_unit_text(
    headers: dict[str, str],
    body: str,
    attachments: list[str],
    *,
    folder: str = "",
) -> str:
    """Build one email unit's text: a header block + the plain-text body.

    Shared by the ``.eml``/``.msg`` file extractors and the live-Outlook bridge
    mapping so a saved email and a pulled message render identically. ``folder``
    is the Outlook source folder (live messages only; empty for files).
    """
    head_lines = [
        f"Тема: {headers['subject']}" if headers["subject"] else "",
        f"От: {headers['from']}" if headers["from"] else "",
        f"Кому: {headers['to']}" if headers["to"] else "",
        f"Копия: {headers['cc']}" if headers["cc"] else "",
        f"Дата: {headers['date']}" if headers["date"] else "",
        f"Папка: {folder}" if folder else "",
    ]
    if attachments:
        head_lines.append("Вложения: " + ", ".join(attachments))
    return _clean("\n".join(line for line in head_lines if line) + "\n\n" + body)


def _email_body(msg: Any) -> str:
    """Best-effort plain-text body of an email (prefer text/plain part)."""
    if msg.is_multipart():
        plain = msg.get_body(preferencelist=("plain",))
        if plain is not None:
            return _clean(plain.get_content())
        html = msg.get_body(preferencelist=("html",))
        if html is not None:
            return _clean(_strip_html(html.get_content()))
        return ""
    content = msg.get_content()
    if (msg.get_content_type() or "").lower() == "text/html":
        return _clean(_strip_html(content))
    return _clean(content if isinstance(content, str) else str(content))


def _strip_html(html: str) -> str:
    """Crude tag strip for HTML-only emails (deterministic, no dependency)."""
    import re

    text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", html)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    text = re.sub(r"&nbsp;", " ", text)
    text = re.sub(r"&amp;", "&", text)
    text = re.sub(r"&lt;", "<", text)
    text = re.sub(r"&gt;", ">", text)
    return re.sub(r"[ \t]+", " ", text)
