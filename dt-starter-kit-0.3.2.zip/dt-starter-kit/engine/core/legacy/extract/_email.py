"""Email extraction — .eml / .msg files + the live-Outlook message mapping (CODE-4).

Moved verbatim out of the pre-split ``core/legacy/extract.py``; self-registers
``.eml`` and ``.msg`` on import. The header/body assembly and HTML-body handling
live in :mod:`core.legacy.extract._base` (shared with the live-Outlook mapping).
``extract_email_message`` is the file-less counterpart for the JXA bridge and is
re-exported by the facade (public surface); it maps a message dict, so it is not
tied to a file extension and is not registered.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ._base import (
    STATUS_ERROR,
    LegacyDoc,
    LegacyUnit,
    _clean,
    _email_body,
    _email_unit_text,
    register,
)


@register(".eml")
def _extract_eml(path: Path, source_type: str) -> LegacyDoc:
    """eml → one email unit: headers + plain-text body; attachment names in meta."""
    from email import policy
    from email.parser import BytesParser

    with path.open("rb") as fh:
        msg = BytesParser(policy=policy.default).parse(fh)

    headers = {
        "subject": (msg["subject"] or "").strip(),
        "from": (msg["from"] or "").strip(),
        "to": (msg["to"] or "").strip(),
        "cc": (msg["cc"] or "").strip(),
        "date": (msg["date"] or "").strip(),
    }
    body = _email_body(msg)
    attachments = [
        name for part in msg.iter_attachments() if (name := part.get_filename())
    ]

    text = _email_unit_text(headers, body, attachments)
    units = [LegacyUnit(kind="email", text=text)] if text else []
    meta: dict[str, Any] = {**headers, "attachments": attachments}
    return LegacyDoc(source_type=source_type, units=units, meta=meta)


@register(".msg")
def _extract_msg(path: Path, source_type: str) -> LegacyDoc:
    """Outlook .msg → one email unit (lazy ``extract-msg``; degrade if absent).

    Saved ``.msg`` files are rare in the corpus (live Outlook is read via the
    JXA bridge in Phase 7). If ``extract-msg`` is not installed we surface a
    clear error rather than a hard crash.
    """
    try:
        import extract_msg  # type: ignore[import-not-found]
    except ImportError:
        return LegacyDoc(
            source_type=source_type,
            status=STATUS_ERROR,
            error="extract-msg not installed (pip install extract-msg) — .msg unsupported",
        )

    with extract_msg.Message(str(path)) as msg:
        headers = {
            "subject": (msg.subject or "").strip(),
            "from": (msg.sender or "").strip(),
            "to": (msg.to or "").strip(),
            "cc": (msg.cc or "").strip(),
            "date": str(msg.date or "").strip(),
        }
        body = _clean(msg.body or "")
        attachments = [
            att.longFilename or att.shortFilename
            for att in msg.attachments
            if (att.longFilename or att.shortFilename)
        ]

    text = _email_unit_text(headers, body, attachments)
    units = [LegacyUnit(kind="email", text=text)] if text else []
    meta: dict[str, Any] = {**headers, "attachments": attachments}
    return LegacyDoc(source_type=source_type, units=units, meta=meta)


# --------------------------------------------------------------------------- #
# Live-Outlook message mapping (ТЗ phase5, stage 8)                            #
# --------------------------------------------------------------------------- #


def extract_email_message(message: dict[str, Any]) -> LegacyDoc:
    """Map a message dict from the Outlook JXA bridge into a :class:`LegacyDoc`.

    The read-only, file-less counterpart of :func:`_extract_eml`: a live message
    pulled from Classic Outlook renders to the *same* one-``email``-unit shape, so
    the layer-B normalize/render/dedup pipeline treats it identically. Provenance
    (folder + subject + date + entryID) lives in the unit header and in ``meta``.
    Robust to missing keys; a body-less, subject-less message yields no units
    (``status`` stays ``ok`` but the caller drops it as empty).

    Expected ``message`` keys (all optional): ``subject``, ``from``, ``to``,
    ``cc``, ``date``, ``body``, ``entryID``, ``folder``, ``conversationId``,
    ``attachments`` (list of names).
    """
    headers = {
        "subject": str(message.get("subject") or "").strip(),
        "from": str(message.get("from") or "").strip(),
        "to": str(message.get("to") or "").strip(),
        "cc": str(message.get("cc") or "").strip(),
        "date": str(message.get("date") or "").strip(),
    }
    folder = str(message.get("folder") or "").strip()
    body = _clean(str(message.get("body") or ""))
    attachments = [
        str(a).strip() for a in (message.get("attachments") or []) if str(a).strip()
    ]
    text = _email_unit_text(headers, body, attachments, folder=folder)
    units = [LegacyUnit(kind="email", text=text)] if text else []
    meta: dict[str, Any] = {
        **headers,
        "folder": folder,
        "entry_id": str(message.get("entryID") or "").strip(),
        "conversation_id": str(message.get("conversationId") or "").strip(),
        "attachments": attachments,
    }
    return LegacyDoc(source_type="email", units=units, meta=meta)
