"""Office-family extraction — docx/doc, pptx/ppt, xlsx/xls/xlsb, rtf (CODE-4).

The openpyxl / python-pptx / python-docx / xlrd / pyxlsb / striprtf / LibreOffice
family. Moved verbatim out of the pre-split ``core/legacy/extract.py``; each
handler self-registers its extensions on import. Parser libraries are
lazy-imported inside the handlers. Broken-OOXML / legacy-binary files fall back
to a headless LibreOffice conversion via :func:`core.legacy.extract._base._convert_then`.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.config import legacy_xlsx_cell_cap

from ._base import (
    STATUS_ERROR,
    STATUS_SKIPPED,
    LegacyDoc,
    LegacyUnit,
    _clean,
    _convert_then,
    _is_package_error,
    register,
)


# --------------------------------------------------------------------------- #
# PowerPoint                                                                   #
# --------------------------------------------------------------------------- #
@register(".pptx", ".pptm")
def _extract_pptx(path: Path, source_type: str) -> LegacyDoc:
    """pptx → slides; a non-OOXML/old-binary file falls back to conversion."""
    try:
        return _parse_pptx_file(path, source_type)
    except Exception as exc:
        if _is_package_error(exc):
            return _convert_then(path, source_type, "pptx", _parse_pptx_file)
        raise


def _parse_pptx_file(path: Path, source_type: str) -> LegacyDoc:
    """pptx → one unit per slide: shape text + tables + speaker notes."""
    from pptx import Presentation

    prs = Presentation(str(path))
    slide_count = len(prs.slides)
    units: list[LegacyUnit] = []
    for i, slide in enumerate(prs.slides, start=1):
        parts: list[str] = []
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                t = shape.text_frame.text
                if t and t.strip():
                    parts.append(t.strip())
            if getattr(shape, "has_table", False):
                parts.append(_table_text(shape.table))
        notes = ""
        if slide.has_notes_slide:
            ntf = slide.notes_slide.notes_text_frame
            if ntf is not None and ntf.text.strip():
                notes = ntf.text.strip()
        if notes:
            parts.append(f"Заметки докладчика: {notes}")
        body = _clean("\n".join(p for p in parts if p))
        if body:
            units.append(LegacyUnit(kind="slide", no=i, text=body))
    return LegacyDoc(
        source_type=source_type, units=units, meta={"slides": slide_count}
    )


def _table_text(table: Any) -> str:
    """Render a pptx/docx table as tab-separated rows."""
    rows = []
    for row in table.rows:
        cells = [(cell.text or "").strip() for cell in row.cells]
        if any(cells):
            rows.append("\t".join(cells))
    return "\n".join(rows)


@register(".ppt")
def _extract_ppt(path: Path, source_type: str) -> LegacyDoc:
    """Legacy binary .ppt → convert to pptx via LibreOffice, then extract."""
    return _convert_then(path, source_type, "pptx", _parse_pptx_file)


# --------------------------------------------------------------------------- #
# Word                                                                         #
# --------------------------------------------------------------------------- #
@register(".docx", ".docm")
def _extract_docx(path: Path, source_type: str) -> LegacyDoc:
    """docx → sections; a non-OOXML/old-binary file falls back to conversion."""
    try:
        return _parse_docx_file(path, source_type)
    except Exception as exc:
        if _is_package_error(exc):
            return _convert_then(path, source_type, "docx", _parse_docx_file)
        raise


def _parse_docx_file(path: Path, source_type: str) -> LegacyDoc:
    """docx → sections split on Heading paragraphs; no headings → one block."""
    import docx

    document = docx.Document(str(path))
    sections: list[LegacyUnit] = []
    preamble: list[str] = []  # content before the first heading
    cur_title = ""
    cur_parts: list[str] = []
    saw_heading = False

    def flush() -> None:
        body = _clean("\n".join(p for p in cur_parts if p))
        if body or cur_title:
            sections.append(LegacyUnit(kind="section", title=cur_title, text=body))

    for block in _iter_docx_blocks(document):
        if block[0] == "table":  # ("table", text)
            cur_parts.append(block[1])
            continue
        _, para, style = block  # ("para", text, style)
        if style.startswith("heading") and para.strip():
            if saw_heading:
                flush()
            else:
                # Promote any pre-heading content to its own untitled section.
                pre = _clean("\n".join(p for p in preamble if p))
                if pre:
                    sections.append(LegacyUnit(kind="section", title="", text=pre))
            saw_heading = True
            cur_title = para.strip()
            cur_parts = []
        elif saw_heading:
            if para.strip():
                cur_parts.append(para.strip())
        else:
            if para.strip():
                preamble.append(para.strip())

    if saw_heading:
        flush()
        units = [s for s in sections if s.text.strip() or s.title]
        return LegacyDoc(source_type=source_type, units=units)

    # No headings at all → a single block of everything.
    body = _clean("\n".join(p for p in preamble if p))
    units = [LegacyUnit(kind="block", text=body)] if body else []
    return LegacyDoc(source_type=source_type, units=units)


def _iter_docx_blocks(document: Any) -> Any:
    """Yield body blocks in order, tagged: ``("para", text, style_lower)`` /
    ``("table", text)``."""
    from docx.oxml.table import CT_Tbl
    from docx.oxml.text.paragraph import CT_P
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    for child in document.element.body.iterchildren():
        if isinstance(child, CT_P):
            para = Paragraph(child, document)
            style = (para.style.name if para.style is not None else "") or ""
            yield ("para", para.text, style.lower())
        elif isinstance(child, CT_Tbl):
            yield ("table", _table_text(Table(child, document)))


@register(".doc")
def _extract_doc(path: Path, source_type: str) -> LegacyDoc:
    """Legacy binary .doc → convert to docx via LibreOffice, then extract."""
    return _convert_then(path, source_type, "docx", _parse_docx_file)


@register(".rtf")
def _extract_rtf(path: Path, source_type: str) -> LegacyDoc:
    """.rtf → plain text via striprtf; if absent, convert to docx via LibreOffice."""
    try:
        from striprtf.striprtf import rtf_to_text  # type: ignore[import-not-found]
    except ImportError:
        return _convert_then(path, source_type, "docx", _parse_docx_file)

    raw = path.read_text(encoding="utf-8", errors="replace")
    text = _clean(rtf_to_text(raw))
    units = [LegacyUnit(kind="block", text=text)] if text else []
    return LegacyDoc(source_type=source_type, units=units)


# --------------------------------------------------------------------------- #
# Excel                                                                        #
# --------------------------------------------------------------------------- #
@register(".xlsx", ".xlsm")
def _extract_xlsx(path: Path, source_type: str) -> LegacyDoc:
    """xlsx → sheets; a non-OOXML/old-binary file falls back to conversion."""
    try:
        return _parse_xlsx_file(path, source_type)
    except Exception as exc:
        if _is_package_error(exc):
            return _convert_then(path, source_type, "xlsx", _parse_xlsx_file)
        raise


def _parse_xlsx_file(path: Path, source_type: str) -> LegacyDoc:
    """xlsx → one unit per worksheet; rows as tab-joined text, capped per sheet."""
    import openpyxl

    cap = legacy_xlsx_cell_cap()
    wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
    units: list[LegacyUnit] = []
    truncated_sheets: list[str] = []
    sheet_titles = [ws.title for ws in wb.worksheets]  # capture before close
    try:
        for idx, ws in enumerate(wb.worksheets, start=1):
            lines: list[str] = []
            cells_seen = 0
            truncated = False
            for row in ws.iter_rows(values_only=True):
                values = [
                    str(c).strip() for c in row if c is not None and str(c).strip()
                ]
                if not values:
                    continue
                cells_seen += len(values)
                lines.append("\t".join(values))
                if cells_seen >= cap:
                    truncated = True
                    break
            if truncated:
                truncated_sheets.append(ws.title)
            body = _clean("\n".join(lines))
            if body:
                units.append(
                    LegacyUnit(kind="sheet", no=idx, title=ws.title, text=body)
                )
    finally:
        wb.close()
    meta: dict[str, Any] = {"sheets": sheet_titles}
    if truncated_sheets:
        meta["truncated_sheets"] = truncated_sheets
        meta["cell_cap"] = cap
    return LegacyDoc(source_type=source_type, units=units, meta=meta)


@register(".xls")
def _extract_xls(path: Path, source_type: str) -> LegacyDoc:
    """Legacy binary .xls → one unit per worksheet via xlrd (openpyxl can't read .xls)."""
    try:
        import xlrd  # type: ignore[import-not-found]
    except ImportError:
        return LegacyDoc(
            source_type=source_type,
            status=STATUS_ERROR,
            error="xlrd not installed (uv sync --extra parsers) — .xls unsupported",
        )

    cap = legacy_xlsx_cell_cap()
    book = xlrd.open_workbook(str(path))
    sheet_names = [book.sheet_by_index(i).name for i in range(book.nsheets)]
    units: list[LegacyUnit] = []
    truncated_sheets: list[str] = []
    for idx in range(book.nsheets):
        sheet = book.sheet_by_index(idx)
        lines: list[str] = []
        cells_seen = 0
        truncated = False
        for r in range(sheet.nrows):
            values = [
                str(v).strip() for v in sheet.row_values(r) if str(v).strip()
            ]
            if not values:
                continue
            cells_seen += len(values)
            lines.append("\t".join(values))
            if cells_seen >= cap:
                truncated = True
                break
        if truncated:
            truncated_sheets.append(sheet.name)
        body = _clean("\n".join(lines))
        if body:
            units.append(
                LegacyUnit(kind="sheet", no=idx + 1, title=sheet.name, text=body)
            )
    meta: dict[str, Any] = {"sheets": sheet_names}
    if truncated_sheets:
        meta["truncated_sheets"] = truncated_sheets
        meta["cell_cap"] = cap
    return LegacyDoc(source_type=source_type, units=units, meta=meta)


@register(".xlsb")
def _extract_xlsb(path: Path, source_type: str) -> LegacyDoc:
    """Binary .xlsb → one unit per worksheet via pyxlsb; unsupported if pyxlsb absent."""
    try:
        import pyxlsb  # type: ignore[import-not-found]
    except ImportError:
        return LegacyDoc(
            source_type=source_type,
            status=STATUS_SKIPPED,
            skip_reason="unsupported:xlsb",
        )

    cap = legacy_xlsx_cell_cap()
    units: list[LegacyUnit] = []
    truncated_sheets: list[str] = []
    with pyxlsb.open_workbook(str(path)) as wb:
        sheet_names = list(wb.sheets)
        for idx, name in enumerate(sheet_names, start=1):
            lines: list[str] = []
            cells_seen = 0
            truncated = False
            with wb.get_sheet(name) as sheet:
                for row in sheet.rows():
                    values = [
                        str(c.v).strip()
                        for c in row
                        if c.v is not None and str(c.v).strip()
                    ]
                    if not values:
                        continue
                    cells_seen += len(values)
                    lines.append("\t".join(values))
                    if cells_seen >= cap:
                        truncated = True
                        break
            if truncated:
                truncated_sheets.append(name)
            body = _clean("\n".join(lines))
            if body:
                units.append(
                    LegacyUnit(kind="sheet", no=idx, title=name, text=body)
                )
    meta: dict[str, Any] = {"sheets": sheet_names}
    if truncated_sheets:
        meta["truncated_sheets"] = truncated_sheets
        meta["cell_cap"] = cap
    return LegacyDoc(source_type=source_type, units=units, meta=meta)
