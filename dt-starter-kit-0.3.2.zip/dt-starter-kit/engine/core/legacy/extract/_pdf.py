"""PDF extraction — one unit per page via pdfplumber (CODE-4).

Moved verbatim out of the pre-split ``core/legacy/extract.py``; self-registers
``.pdf`` on import. pdfplumber is lazy-imported inside the handler.

OCR-1: pdf без текстового слоя остается ``needs_ocr`` (L1-запись «скан» живет вечно, на ней
строится заглушка-заметка); если для байтов файла уже есть результат OCR (``.derived/ocr``), то
документ собирается из него: ``source_type=pdf-ocr``, единицы по страницам, метаданные движка.
Результат ``refused_text``/``empty`` текста не несет - документ остается сканом с пометкой.
"""

from __future__ import annotations

from pathlib import Path

from ._base import STATUS_SKIPPED, LegacyDoc, LegacyUnit, _clean, register


@register(".pdf")
def _extract_pdf(path: Path, source_type: str) -> LegacyDoc:
    """pdf → one unit per page (pdfplumber). No text anywhere → needs_ocr."""
    import pdfplumber

    pages: list[tuple[int, str]] = []
    with pdfplumber.open(str(path)) as pdf:
        page_count = len(pdf.pages)
        for i, page in enumerate(pdf.pages, start=1):
            text = page.extract_text() or ""
            pages.append((i, _clean(text)))

    units = [LegacyUnit(kind="page", no=i, text=t) for i, t in pages if t.strip()]
    if not units:
        # No extractable text layer → scanned/image-only: заметка-заглушка (OCR-1 п.1), текст
        # приходит отдельным контуром OCR (п.3-4).
        return _scan_doc(path, source_type, page_count)
    return LegacyDoc(source_type=source_type, units=units, meta={"pages": page_count})


def _scan_doc(path: Path, source_type: str, page_count: int) -> LegacyDoc:
    """Скан: результат OCR из кэша, если он есть, иначе заглушка (``needs_ocr``)."""
    from core.ocr.cache import STATE_DONE, lookup_for_file

    meta: dict[str, object] = {"pages": page_count}
    cached = lookup_for_file(path)
    if cached is not None:
        state = str(cached.get("state") or "")
        if state == STATE_DONE:
            ocr_units = [
                LegacyUnit(kind="page", no=int(p["no"]), text=_clean(str(p.get("text") or "")))
                for p in cached.get("pages") or []
            ]
            ocr_units = [u for u in ocr_units if u.text.strip()]
            if ocr_units:
                return LegacyDoc(
                    source_type="pdf-ocr", units=ocr_units,
                    meta={
                        **meta, "ocr_engine": cached.get("engine"),
                        "ocr_engine_version": cached.get("engine_version"),
                        "ocr_version": cached.get("version"), "ocr_lang": cached.get("lang"),
                        "ocr_confidence": cached.get("confidence"),
                    },
                )
            state = "empty"
        meta["ocr_state"] = state  # refused_text | empty: текста нет, заметка-заглушка с пометкой
    return LegacyDoc(
        source_type=source_type,
        status=STATUS_SKIPPED,
        needs_ocr=True,
        skip_reason="needs_ocr",
        meta=meta,
    )
