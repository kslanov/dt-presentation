"""Plain-text formats — txt/md/markdown/csv/tsv/log (CODE-4).

Binds the base text reader (:func:`core.legacy.extract._base._extract_text`, a
dependency-free UTF-8 reader) to its extensions. Importing this module is the
registration side-effect; the facade imports it so the exts are live.
"""

from __future__ import annotations

from ._base import _extract_text, register

register(".txt", ".md", ".markdown", ".csv", ".tsv", ".log")(_extract_text)
