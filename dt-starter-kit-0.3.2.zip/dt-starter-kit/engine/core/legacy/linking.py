"""Layer-B graph linking (ТЗ phase5, stage 5).

Three deterministic, LLM-free linkers that stitch the legacy corpus (layer B)
into the curated vault graph (layer A):

1. **Hub resolution helpers** — resolve a legacy note's ``client``/``section``
   against the entity-hub catalog (ids + aliases, incl. client name abbreviations and client name
   variants). No hub → no invented link. Since Phase 9 (этап 3) these are NOT
   applied at render time — per-note ``[[hub]]`` links are written only by the
   ``core/linking`` pass (deterministic-резолвер по сигналам frontmatter);
   ``resolve_hub_links`` remains as the shared resolution primitive.
2. **Folder MOCs** — a ``_index.md`` per ``_legacy/<…>/`` folder listing its notes
   and (when resolvable) the client hub.
3. **Curated back-links — conservative.** Only when a curated note's frontmatter
   ``source`` unambiguously names one ingested file do we append a
   ``## Связано (легаси)`` link. Never rewrites existing prose; idempotent.

(2) and (3) run as a post-pass of ``ingest_corpus``. Reuses
``core.ingest._entity_catalog``.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path

from core.ingest import EntityRef, _entity_catalog
from core.legacy.render import slugify
from core.vault import Note, iter_vault

__all__ = [
    "entity_catalog",
    "resolve_hub_links",
    "generate_mocs",
    "backlink_curated",
    "write_hub_candidates",
    "scaffold_hub",
    "BacklinkResult",
    "BACKLINK_HEADING",
    "CANDIDATES_NOTE",
    "hubs_for_labels",
]

BACKLINK_HEADING = "## Связано (легаси)"
_MOC_NAME = "_index.md"
CANDIDATES_NOTE = "_candidates-for-hub.md"
# Where stub hubs are scaffolded per entity (curated area). ``project`` gets a
# flat stub note under 03-projects — полноценное workspace (hub.md в папке)
# делает скилл new-project; для линковки type:hub-заглушки достаточно (HUB-1).
_HUB_FOLDERS = {
    "client": "04-clients",
    "product": "02-knowledge/products",
    "direction": "02-knowledge/directions",
    "industry": "02-knowledge/industries",
    "project": "03-projects",
}


def entity_catalog(vault_path: Path) -> list[EntityRef]:
    """Hub catalog (id + aliases) — thin reuse of core.ingest._entity_catalog."""
    return _entity_catalog(vault_path)


def _norm(text: str) -> str:
    return text.strip().lower()


def _match_hub(value: str, hubs: list[EntityRef], prefix: str) -> str | None:
    """Match a folder label to a hub by id/alias (case-insensitive) or id guess.

    The guess ``<prefix>-<slugify(value)>`` (e.g. ``client-hooli``) covers hubs
    that lack an explicit alias for the folder name. **Guard (ТЗ phase5 §6):** the
    guess only resolves against hubs *present in the catalog* (i.e. a hub note
    that actually exists in the vault) — ``hubs`` is built from on-disk hub notes,
    so a non-existent hub is never linked (no thousands of dangling ``[[…]]``).
    Returns the hub id or None.
    """
    nv = _norm(value)
    guess = f"{prefix}-{slugify(value)}"
    for hub in hubs:  # hubs == existing hub notes only → guess can't invent a link
        candidates = {_norm(hub.id)} | {_norm(a) for a in hub.aliases}
        if nv in candidates or hub.id == guess:
            return hub.id
    return None


def hubs_for_labels(
    labels: Iterable[str],
    catalog: list[EntityRef],
    *,
    entities: tuple[str, ...] = ("client", "product"),
) -> list[str]:
    """Существующие хабы по набору строк-ярлыков (например, сегментов пути).

    Тот же матчер, что у легаси-линковки (:func:`_match_hub`): id/алиас или догадка
    ``<prefix>-<slugify(ярлык)>``, и **только против хабов, которые реально есть в
    каталоге** — гард «не выдумывать ``[[…]]``» живёт в одном месте на всех
    потребителей. Порядок стабильный (по порядку ярлыков, внутри ярлыка — по
    ``entities``), дубли сняты.

    Потребитель сверх линковки — SRC-TRACE-2: секция «## Связано» выхода собирается
    из путей его источников, чтобы выход был виден со стороны клиента/продукта.
    """
    by_entity = {e: [c for c in catalog if c.entity == e] for e in entities}
    out: list[str] = []
    for label in labels:
        value = str(label or "").strip()
        if not value:
            continue
        for entity in entities:
            hid = _match_hub(value, by_entity[entity], entity)
            if hid and hid not in out:
                out.append(hid)
    return out


def resolve_hub_links(
    client: str, section: str, catalog: list[EntityRef]
) -> list[str]:
    """Resolve ``[[hub]]`` ids for a legacy note from its client/section.

    Client → a ``client`` hub; section → a ``direction`` or ``product`` hub. Only
    existing hubs are returned (deterministic, never invented), de-duplicated and
    order-stable (client first).
    """
    out: list[str] = []
    if client:
        hubs = [c for c in catalog if c.entity == "client"]
        hid = _match_hub(client, hubs, "client")
        if hid:
            out.append(hid)
    if section:
        for entity in ("direction", "product"):
            hubs = [c for c in catalog if c.entity == entity]
            hid = _match_hub(section, hubs, entity)
            if hid and hid not in out:
                out.append(hid)
    return out


# --------------------------------------------------------------------------- #
# Folder MOCs (_index.md)                                                     #
# --------------------------------------------------------------------------- #


def _legacy_source_notes(vault_path: Path) -> list[Note]:
    return [
        n
        for n in iter_vault(vault_path)
        if n.frontmatter.get("corpus") == "legacy" and n.type == "legacy-source"
    ]


def _moc_id(folder_rel: str) -> str:
    import hashlib

    return f"legacy-index-{hashlib.sha1(folder_rel.encode('utf-8')).hexdigest()[:12]}"  # noqa: S324 — content hash (identity/dedup), not security


def _render_moc(folder_rel: str, notes: list[Note], hub_id: str | None) -> str:
    fm_lines = [
        "---",
        f"id: {_moc_id(folder_rel)}",
        "type: legacy-index",
        "corpus: legacy",
        "curated: false",
        "status: raw",
        "tags: [legacy, moc]",
        "---",
        "",
        f"# {folder_rel}",
        "",
    ]
    if hub_id:
        fm_lines.append(f"Хаб: [[{hub_id}]]")
        fm_lines.append("")
    fm_lines.append("## Заметки")
    fm_lines.append("")
    for note in sorted(notes, key=lambda n: n.id):
        fm_lines.append(f"- [[{note.id}]]")
    return "\n".join(fm_lines) + "\n"


def generate_mocs(vault_path: Path, catalog: list[EntityRef]) -> list[Path]:
    """(Re)generate ``_index.md`` per legacy folder; drop stale MOCs. Idempotent."""
    vault_path = Path(vault_path)
    legacy_root = vault_path / "_legacy"
    if not legacy_root.is_dir():
        return []

    groups: dict[Path, list[Note]] = {}
    for note in _legacy_source_notes(vault_path):
        groups.setdefault(note.path.parent, []).append(note)

    client_hubs = [c for c in catalog if c.entity == "client"]
    written: list[Path] = []
    for folder, notes in sorted(groups.items(), key=lambda kv: str(kv[0])):
        folder_rel = folder.relative_to(vault_path).as_posix()
        client = next(
            (n.frontmatter.get("client") for n in notes if n.frontmatter.get("client")),
            "",
        )
        hub_id = _match_hub(str(client), client_hubs, "client") if client else None
        content = _render_moc(folder_rel, notes, hub_id)
        moc_path = folder / _MOC_NAME
        if not moc_path.is_file() or moc_path.read_text(encoding="utf-8") != content:
            moc_path.write_text(content, encoding="utf-8")
        written.append(moc_path)

    # Drop _index.md in folders that no longer hold any legacy-source note.
    keep = set(groups.keys())
    for moc in legacy_root.rglob(_MOC_NAME):
        if moc.parent not in keep:
            moc.unlink(missing_ok=True)
    return written


# --------------------------------------------------------------------------- #
# Curated back-links (conservative)                                           #
# --------------------------------------------------------------------------- #


@dataclass
class BacklinkResult:
    """Outcome of the curated back-link pass."""

    touched: list[str] = field(default_factory=list)  # curated note ids changed


def _legacy_index(vault_path: Path) -> tuple[dict[str, str], dict[str, list[str]]]:
    """Maps for resolving curated ``source`` → legacy note id.

    Returns ``(by_source_path, by_filename)``: exact source-path → id, and
    filename → list of ids (ambiguity guard).
    """
    by_path: dict[str, str] = {}
    by_fname: dict[str, list[str]] = {}
    for note in _legacy_source_notes(vault_path):
        sp = note.frontmatter.get("source_path")
        if not sp:
            continue
        by_path[str(sp)] = note.id
        by_fname.setdefault(Path(str(sp)).name, []).append(note.id)
    return by_path, by_fname


def _resolve_source(
    source: str, by_path: dict[str, str], by_fname: dict[str, list[str]]
) -> str | None:
    """Resolve a curated ``source`` to exactly one legacy note id, else None.

    Conservative: a folder-looking source (trailing slash / no extension) or any
    match that is not unambiguous is left unlinked.
    """
    s = source.strip()
    if not s or s.endswith(("/", "\\")):
        return None
    norm = s.replace("\\", "/").lstrip("/")

    if s in by_path:
        return by_path[s]
    tail_matches = {
        nid
        for sp, nid in by_path.items()
        if sp == norm or sp.endswith("/" + norm)
    }
    if len(tail_matches) == 1:
        return next(iter(tail_matches))
    if tail_matches:
        return None  # ambiguous → leave alone

    base = Path(norm).name
    if "." in base:  # looks like a file, not a folder
        ids = set(by_fname.get(base, []))
        if len(ids) == 1:
            return next(iter(ids))
    return None


def _append_backlink(path: Path, target_id: str) -> bool:
    """Append a ``[[target_id]]`` under the back-link heading; never edits prose.

    Returns True if the file was changed, False if the link was already present.
    """
    text = path.read_text(encoding="utf-8")
    link = f"[[{target_id}]]"
    if link in text:
        return False

    lines = text.split("\n")
    if BACKLINK_HEADING in lines:
        insert_at = lines.index(BACKLINK_HEADING) + 1
        if insert_at < len(lines) and lines[insert_at].strip() == "":
            insert_at += 1
        lines.insert(insert_at, f"- {link}")
        path.write_text("\n".join(lines), encoding="utf-8")
    else:
        path.write_text(
            text.rstrip() + f"\n\n{BACKLINK_HEADING}\n\n- {link}\n", encoding="utf-8"
        )
    return True


def backlink_curated(vault_path: Path) -> BacklinkResult:
    """Add legacy back-links to curated notes with an unambiguous ``source``."""
    vault_path = Path(vault_path)
    by_path, by_fname = _legacy_index(vault_path)
    result = BacklinkResult()
    if not by_path:
        return result

    for note in iter_vault(vault_path):
        if note.frontmatter.get("corpus") == "legacy":
            continue  # only curated (layer A) notes
        source = note.frontmatter.get("source")
        if not isinstance(source, str):
            continue
        # INGRESS-1 п.3: ``source: files|mail`` — метка семейства входа у notes ingest (corpus
        # current тоже), а не ссылка на легаси-источник curated-заметки: не резолвим как путь.
        if source in ("files", "mail"):
            continue
        target = _resolve_source(source, by_path, by_fname)
        if target is None:
            continue
        if _append_backlink(note.path, target):
            result.touched.append(note.id)
    return result


# --------------------------------------------------------------------------- #
# Hub candidates report                                                       #
# --------------------------------------------------------------------------- #


def write_hub_candidates(vault_path: Path, catalog: list[EntityRef]) -> Path | None:
    """Write ``_legacy/_candidates-for-hub.md``: clients with legacy material but
    no resolving hub (a hub-creation worklist). Idempotent; removed when empty.

    Returns the file path when written, else None (no candidates → file removed).
    """
    vault_path = Path(vault_path)
    legacy_root = vault_path / "_legacy"
    target = legacy_root / CANDIDATES_NOTE
    client_hubs = [c for c in catalog if c.entity == "client"]

    # client → (note count, set of sections)
    agg: dict[str, tuple[int, set[str]]] = {}
    for note in _legacy_source_notes(vault_path):
        client = str(note.frontmatter.get("client") or "").strip()
        if not client or _match_hub(client, client_hubs, "client") is not None:
            continue  # no client, or a hub already resolves → not a candidate
        count, sections = agg.get(client, (0, set()))
        section = str(note.frontmatter.get("section") or "").strip()
        if section:
            sections.add(section)
        agg[client] = (count + 1, sections)

    if not agg:
        target.unlink(missing_ok=True)
        return None

    rows = sorted(agg.items(), key=lambda kv: (-kv[1][0], kv[0]))
    lines = [
        "---",
        "id: legacy-candidates-for-hub",
        "type: legacy-index",
        "corpus: legacy",
        "curated: false",
        "status: raw",
        "tags: [legacy, hub-candidates]",
        "---",
        "",
        "# Кандидаты в хабы (клиенты без хаба, по объёму легаси)",
        "",
        "Клиенты с легаси-материалом, но без резолвящегося хаба. Создать stub: "
        "`dt_scaffold_hub.py --client \"<имя>\"`; следующий ingest проставит ссылки.",
        "",
        "| клиент | секции | легаси-заметок | предлагаемый id |",
        "| --- | --- | --- | --- |",
    ]
    for client, (count, sections) in rows:
        secs = ", ".join(sorted(sections)) or "—"
        lines.append(f"| {client} | {secs} | {count} | client-{slugify(client)} |")
    legacy_root.mkdir(parents=True, exist_ok=True)
    content = "\n".join(lines) + "\n"
    if not target.is_file() or target.read_text(encoding="utf-8") != content:
        target.write_text(content, encoding="utf-8")
    return target


# --------------------------------------------------------------------------- #
# Hub scaffolding (human-in-the-loop; NEVER run from ingest)                  #
# --------------------------------------------------------------------------- #


def _effective_track(track: str | None, *, entity: str, status: str) -> str | None:
    """Трек для нового хаба (TRACK-2): явный ``track`` → пресейл-статус → по entity.

    Приоритет: (1) явный валидный ``track`` из :data:`core.operational.tracks.TRACKS`
    (``presale``/``project``/``internal``); (2) presale-пресет (``status`` = пресейл)
    → ``presale``; (3) lead-хабы (``entity`` ``project``/``deal``) без иных сигналов
    → ``internal``. Прочие сущности (client/product/…) сделками не становятся
    (детектор их не смотрит) → ``None`` (поле не пишем). Значения-мусор в ``track``
    игнорируются (падают в пп.2–3); дефолты TRACK-1 не изменились.
    """
    from core.operational.tracks import TRACKS

    t = str(track or "").strip().lower()
    if t in TRACKS:
        return t
    if str(status or "").strip().lower() in {"presale", "pre-sale", "пресейл"}:
        return "presale"
    if entity in {"project", "deal"}:
        return "internal"
    return None


def scaffold_hub(
    vault_path: Path,
    name: str,
    *,
    entity: str = "client",
    created: str | None = None,
    status: str = "active",
    track: str | None = None,
) -> tuple[Path, bool]:
    """Create a minimal stub hub note for ``name``. Returns ``(path, created?)``.

    Idempotent and non-destructive: if the hub file already exists it is left
    untouched (``created=False``). The stub carries ``type: hub`` + ``entity`` +
    ``status`` (default ``active``; ``presale`` для пресейл-хабов) +
    ``aliases: [name]`` + ``created`` and empty body sections for the user to
    fill. Only ever invoked on explicit request (scaffold CLI / pult) — never
    from ingest.

    TRACK-1: lead-хабы (``project``/``deal``) получают явное поле ``track:
    presale|internal`` (:func:`_effective_track`) — чтобы детектор «дозревших»
    (``ripe_leads``) классифицировал их полем, а не эвристикой. ``track`` можно
    задать явно; иначе presale-пресет → ``presale``, прочие lead-хабы → ``internal``.
    """
    from datetime import date

    folder = _HUB_FOLDERS.get(entity, _HUB_FOLDERS["client"])
    hub_id = f"{entity}-{slugify(name)}"
    path = Path(vault_path) / folder / f"{hub_id}.md"
    if path.is_file():
        return path, False

    created = created or date.today().isoformat()
    eff_track = _effective_track(track, entity=entity, status=status)
    fm_lines = [
        "---",
        f"id: {hub_id}",
        "type: hub",
        f"entity: {entity}",
        f"status: {status}",
    ]
    if eff_track:
        fm_lines.append(f"track: {eff_track}")
    content = "\n".join(
        [
            *fm_lines,
            f"aliases: [{name}]",
            f"created: {created}",
            "---",
            "",
            f"# {name}",
            "",
            "## Обзор",
            "",
            "## Контекст",
            "",
            "## Связанное",
            "",
        ]
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path, True
