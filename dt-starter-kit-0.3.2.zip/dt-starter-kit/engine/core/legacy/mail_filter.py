"""MAIL-FILTER-1 — правила фильтра почты как ДАННЫЕ (``vault/_system/mail-filter.yaml``).

Раньше шум почты резали три списка в коде/env и подстрока без границ слова: ``закупк`` брало
«Закупка ПО для ЗДО» от живого человека, ``уведомлени`` - «Уведомление о расторжении договора»
от клиента, а роботы с обычным адресом (счета PBX, NDR Exchange, хостинг) проходили. Теперь
решение одно, объяснимое и правится текстом в Obsidian.

Типы правил (у каждого - ``reason`` журнала отказов INGRESS-1; имя правила ``<тип>/<значение>``):

* ``allow`` - белый список адресов/доменов; бьет ВСЕ остальное (только Inbox: в Sent отправитель
  - я);
* ``senders`` - адрес ЦЕЛИКОМ (glob по адресу: ``b2b_invoice@acme.kz``,
  ``microsoftexchange*@*``, ``noreply*@*``) или домен целиком (``@host.example``);
  не подстрока;
* ``subject_prefix`` - начало темы (авто-ответы, отзывы, NDR, ответы на встречи); ОБЕ папки;
* ``subject_regex`` - якорный regex по теме (``^\\d+\\.\\s*Закупки_\\d\\d\\.\\d\\d\\.\\d{4}$``);
* ``senders_weak`` + ``subject_word`` - ПАРА: общий токен отправителя (подстрока адреса: noreply,
  notification, mailer) И слово темы (целое слово; ``слов*`` - начало слова). По одному - нет.

Порядок и «первое сработавшее»: allow → senders → subject_prefix → subject_regex →
senders_weak+subject_word. Sent НЕ фильтруется по шуму (как всегда): только ``subject_prefix``.

Нет файла - запасной набор :data:`DEFAULT_YAML` (то же содержимое, что кладется в vault); пустой/
битый yaml - тот же запасной набор + warning с кодом ``store_unavailable`` (§9 п.22: не молча).
Env ``DT_MAIL_NOISE_*`` только РАСШИРЯЕТ набор. Парсинг кэшируется по ``mtime``+размеру файла.
``decide`` - чистая функция без сети: ``dt mail-filter explain`` и инжест вызывают одно и то же.
"""

from __future__ import annotations

import fnmatch
import logging
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from core.contract import CODE_STORE_UNAVAILABLE, warning
from core.legacy.discover import nfc

logger = logging.getLogger(__name__)

__all__ = [
    "DEFAULT_YAML",
    "Decision",
    "RefusedMemory",
    "Rule",
    "Rules",
    "decide",
    "decide_meta",
    "extract_address",
    "lint_file",
    "load_rules",
    "parse_rules",
]

REASONS_ALLOWED = ("noise_sender", "noise_subject", "meeting_response")
SECTIONS = ("allow", "senders", "subject_prefix", "subject_regex", "senders_weak", "subject_word")
_DEFAULT_REASON = {
    "senders": "noise_sender",
    "subject_prefix": "noise_subject",
    "subject_regex": "noise_subject",
    "subject_word": "noise_subject",
    "senders_weak": "noise_subject",  # причина берется у пары - у subject_word
}

# Запасной набор = начальный vault/_system/mail-filter.yaml (тест держит их равными).
DEFAULT_YAML = """\
# Правила фильтра почты (MAIL-FILTER-1). Читает core/legacy/mail_filter.py; правится текстом.
# Порядок решения: allow -> senders -> subject_prefix -> subject_regex -> senders_weak+subject_word.
# Проверка: `uv run python cli/dt.py mail-filter lint`; примерить письмо:
#   uv run python cli/dt.py mail-filter explain --from X --subject Y
# Sent шумом не режется (только subject_prefix). Это нейтральный образец: свои правила - ниже.
version: 1

# Белый список: адрес/домен, письма которого НИКОГДА не шум (бьет все правила ниже; только Inbox).
allow:
  - match: hr@example.com
    note: пример - живой человек, которого общий токен (например, `notification`) задел бы

# Роботы: локальная часть ЦЕЛИКОМ или домен ЦЕЛИКОМ (`@домен`), glob по адресу. Не подстрока.
senders:
  - match: "noreply*@*"
    note: по определению робот
  - match: "no-reply*@*"
  - match: "no_reply*@*"
  - match: "donotreply*@*"
  - match: "do-not-reply*@*"
  - match: "mailer-daemon@*"
  - match: "bounce*@*"
  - match: system@timetta.com
    note: уведомления Timetta (100); люди и support@ @timetta.com - НЕ шум, домен не режем
  - match: "microsoftexchange*@*"
    note: NDR Exchange
  - match: calendar@corp.mail.ru
    note: календарные уведомления (42); люди @corp.mail.ru - не шум
  - match: info@ps.kz
    note: хостинг ps.kz
  - match: support@ps.kz
  - match: info@idocs.kz
    note: подписание документов (idocs.kz)
  - match: news@1c-bitrix.ru
  - match: info@1c-bitrix.ru
  - match: info@mail.timepad.ru
  - match: info@cloud.vk.com
  - match: events@cloud.vk.com
  # Подтверждено К. 27.10 (замер по сайдкарам):
  - match: esf@kgd.minfin.gov.kz
    note: уведомления об ЭСФ от налоговой (390 тредов)
  - match: info@qazaq-profi.kz
    note: рассылка курсов (96)
  - match: media@astanahub.com
    note: рассылка Astana Hub (54)
  - match: webinars@e.lucid.co
    note: вебинары Lucid (23)
  - match: clickupdates@mail.clickup.com
    note: уведомления ClickUp (18)
  - match: sales@1c-bitrix.ru
    note: продажи Bitrix (8)
  #   support@timetta.com - НЕ робот: живой диалог с поддержкой Timetta (4 письма в треде)

# Авто-ответы и ответы на встречи: начало темы, ОБЕ папки (reason - в журнал отказов).
subject_prefix:
  - "Не удается доставить:"
  - "Undeliverable:"
  - "Отзыв:"
  - "Recall:"
  - "Автоматический ответ:"
  - "Automatic reply:"
  - match: "Accepted:"
    reason: meeting_response
  - match: "Declined:"
    reason: meeting_response
  - match: "Tentative:"
    reason: meeting_response
  - match: "Canceled:"
    reason: meeting_response
  - match: "Cancelled:"
    reason: meeting_response
  - match: "Принято:"
    reason: meeting_response
  - match: "Отклонено:"
    reason: meeting_response
  - match: "Отменено:"
    reason: meeting_response
  - match: "Предварительно:"
    reason: meeting_response
  - match: "Meeting Response"
    reason: meeting_response
  - match: "Ответ на приглашение"
    reason: meeting_response

# Якорные regex по теме (без учета регистра, поиск по всей теме - якоря ставит автор).
subject_regex:
  - match: '^\\d+\\.\\s*Digest_\\d\\d\\.\\d\\d\\.\\d{4}$'
    note: пример - нумерованная рассылка

# Пара: общий токен отправителя (подстрока адреса) И слово темы (целое слово). По одному - не шум.
senders_weak:
  - newsletter
  - mailer
  - mailing
  - notification
  - notifications
  - notify
  - noreply
  - no-reply
  - no_reply
  - donotreply
  - do-not-reply
subject_word:
  - "закупк*"
  - "рассылк*"
  - "уведомлени*"
  - "дайджест*"
  - digest
  - unsubscribe
  - отписаться
"""

_ADDR_RE = re.compile(r"[\w.+'-]+@[\w-]+(?:\.[\w-]+)*", re.UNICODE)
_TOKEN_RE = re.compile(r"[^\W_]+", re.UNICODE)


# --------------------------------------------------------------------------- #
# Модель                                                                       #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Rule:
    """Одно правило: раздел ``section``, шаблон ``match``, причина журнала ``reason``."""

    section: str
    match: str
    reason: str = "noise_subject"
    note: str = ""
    source: str = "file"  # file | env | default

    @property
    def name(self) -> str:
        """Имя в журнале/explain: ``senders/b2b_invoice@acme.kz``."""
        return f"{self.section}/{self.match}"


@dataclass(frozen=True)
class Decision:
    """Решение по письму: ``reason`` (причина журнала) или ``None`` = пропустить."""

    reason: str | None = None
    rule: str | None = None
    allowed: bool = False  # пропущено белым списком (rule = allow/…)

    @property
    def noise(self) -> bool:
        return self.reason is not None

    def render(self) -> str:
        """``noise_sender (rule: senders/…)`` / ``pass`` / ``pass (rule: allow/…)``."""
        if self.reason:
            return f"{self.reason} (rule: {self.rule})"
        return f"pass (rule: {self.rule})" if self.rule else "pass"


@dataclass
class Rules:
    """Разобранный набор правил + откуда он (``file``/``defaults``) и предупреждения."""

    allow: list[Rule] = field(default_factory=list)
    senders: list[Rule] = field(default_factory=list)
    subject_prefix: list[Rule] = field(default_factory=list)
    subject_regex: list[Rule] = field(default_factory=list)
    senders_weak: list[Rule] = field(default_factory=list)
    subject_word: list[Rule] = field(default_factory=list)
    source: str = "defaults"
    path: str = ""
    warnings: list[dict[str, Any]] = field(default_factory=list)
    _regex: dict[str, re.Pattern[str]] = field(default_factory=dict, repr=False)

    def total(self) -> int:
        return sum(len(getattr(self, s)) for s in SECTIONS)

    def regex_of(self, rule: Rule) -> re.Pattern[str] | None:
        return self._regex.get(rule.match)


# --------------------------------------------------------------------------- #
# Разбор                                                                       #
# --------------------------------------------------------------------------- #
class RulesError(ValueError):
    """Файл правил нельзя разобрать (причина - в тексте, для lint и warning)."""


def _entry(section: str, raw: Any) -> Rule:
    if isinstance(raw, str):
        match, reason, note = raw, "", ""
    elif isinstance(raw, Mapping):
        given = raw.get("match")
        if not isinstance(given, str):
            raise RulesError(f"{section}: у записи нет строки `match`: {raw!r}")
        match = given
        reason, note = str(raw.get("reason") or ""), str(raw.get("note") or "")
    else:
        raise RulesError(f"{section}: запись должна быть строкой или {{match: …}}: {raw!r}")
    match = nfc(match).strip()
    if not match:
        raise RulesError(f"{section}: пустое правило")
    reason = reason or _DEFAULT_REASON.get(section, "")
    if section != "allow" and reason not in REASONS_ALLOWED:
        raise RulesError(
            f"{section}/{match}: неизвестная reason {reason!r} (нужна: {REASONS_ALLOWED})"
        )
    return Rule(section=section, match=match, reason=reason, note=note)


def parse_rules(text: str, *, source: str = "file", path: str = "") -> Rules:
    """YAML-текст → :class:`Rules`. Ошибка структуры - :class:`RulesError` (не пустой набор)."""
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise RulesError(f"yaml не разбирается: {str(exc)[:160]}") from exc
    if not isinstance(data, dict):
        raise RulesError("в файле нет ни одного раздела правил (ожидается mapping)")
    unknown = sorted(set(data) - set(SECTIONS) - {"version"})
    if unknown:
        raise RulesError(f"неизвестные разделы: {', '.join(map(str, unknown))}")
    rules = Rules(source=source, path=path)
    for section in SECTIONS:
        items = data.get(section) or []
        if not isinstance(items, list):
            raise RulesError(f"{section}: ожидается список")
        out = getattr(rules, section)
        for raw in items:
            if section in ("senders_weak", "subject_word"):
                rule = _entry(section, raw)
                rule = Rule(section, rule.match.lower(), rule.reason, rule.note)
            else:
                rule = _entry(section, raw)
            if section == "subject_regex":
                try:
                    rules._regex[rule.match] = re.compile(rule.match, re.IGNORECASE | re.UNICODE)
                except re.error as exc:
                    raise RulesError(
                        f"subject_regex/{rule.match}: regex не компилируется: {exc}"
                    ) from exc
            out.append(rule)
    if not rules.total():
        raise RulesError("файл правил пуст (ни одного правила)")
    return rules


def _with_env(rules: Rules) -> Rules:
    """Env ``DT_MAIL_NOISE_*`` - РАСШИРЕНИЕ набора (никогда не сужает)."""
    from core.config import (
        mail_noise_meeting_subjects,
        mail_noise_senders,
        mail_noise_subjects,
    )

    def have(section: str, match: str) -> bool:
        return any(r.match.lower() == match.lower() for r in getattr(rules, section))

    for tok in mail_noise_senders():
        if not have("senders_weak", tok):
            rules.senders_weak.append(Rule("senders_weak", tok, source="env"))
    for tok in mail_noise_subjects():
        if not have("subject_word", tok):
            rules.subject_word.append(Rule("subject_word", tok, "noise_subject", source="env"))
    for tok in mail_noise_meeting_subjects():
        if not have("subject_prefix", tok):
            rules.subject_prefix.append(
                Rule("subject_prefix", tok, "meeting_response", source="env")
            )
    return rules


def _defaults(warnings_: list[dict[str, Any]] | None = None, path: str = "") -> Rules:
    rules = parse_rules(DEFAULT_YAML, source="defaults", path=path)
    rules.warnings = list(warnings_ or [])
    return rules


_CACHE: dict[str, tuple[int, int, Rules]] = {}


def load_rules(vault_path: Path | None = None, *, path: Path | None = None) -> Rules:
    """Набор правил: файл (кэш по mtime+размеру) → иначе запасной набор; плюс env-расширение.

    Нет файла → запасной набор (штатно, без предупреждения: машина без vault/тесты). Файл есть, но
    пустой/битый → запасной набор И ``warnings`` с кодом ``store_unavailable`` + запись в лог.
    """
    from core.config import mail_filter_path

    target = path if path is not None else mail_filter_path(vault_path)
    key = str(target)
    try:
        st = target.stat()
    except OSError:
        _CACHE.pop(key, None)
        return _with_env(_defaults(path=key))
    stamp = (st.st_mtime_ns, st.st_size)
    cached = _CACHE.get(key)
    if cached is not None and cached[:2] == stamp:
        base = cached[2]
    else:
        try:
            base = parse_rules(target.read_text(encoding="utf-8"), path=key)
        except (RulesError, OSError, UnicodeDecodeError) as exc:
            why = str(exc)[:200]
            logger.warning(
                "[mail-filter] %s: %s - работает запасной набор правил (%s)",
                target.name, why, CODE_STORE_UNAVAILABLE,
            )
            base = _defaults(
                [warning(CODE_STORE_UNAVAILABLE,
                         f"правила почты не прочитались ({target.name}: {why}); "
                         "работает запасной набор из кода",
                         path=key)],
                path=key,
            )
        _CACHE[key] = (stamp[0], stamp[1], base)
    # копия + env: кэш остается чистым файловым набором
    merged = Rules(
        allow=list(base.allow), senders=list(base.senders),
        subject_prefix=list(base.subject_prefix), subject_regex=list(base.subject_regex),
        senders_weak=list(base.senders_weak), subject_word=list(base.subject_word),
        source=base.source, path=base.path, warnings=list(base.warnings), _regex=dict(base._regex),
    )
    return _with_env(merged)


# --------------------------------------------------------------------------- #
# Матчер                                                                       #
# --------------------------------------------------------------------------- #
def extract_address(sender: Any) -> str:
    """Адрес отправителя в нижнем регистре из ``"Имя <a@b>"`` / ``"a@b"``; нет адреса → ``""``."""
    text = nfc(str(sender or ""))
    m = _ADDR_RE.search(text)
    return m.group(0).lower() if m else ""


def _norm_subject(subject: Any) -> str:
    return " ".join(nfc(str(subject or "")).split())


def _addr_matches(pattern: str, addr: str) -> bool:
    """``@домен`` - домен целиком; иначе glob по ВСЕМУ адресу (локальная часть целиком)."""
    if not addr:
        return False
    pat = pattern.lower()
    if pat.startswith("@"):
        return fnmatch.fnmatchcase(addr.rsplit("@", 1)[-1], pat[1:])
    return fnmatch.fnmatchcase(addr, pat)


def _word_hit(tokens: list[str], word: str) -> bool:
    if word.endswith("*"):
        stem = word[:-1]
        return bool(stem) and any(t.startswith(stem) for t in tokens)
    return word in tokens


def _subject_only(rules: Rules, subject: str) -> Decision | None:
    low = subject.casefold()
    for r in rules.subject_prefix:
        if low.startswith(nfc(r.match).casefold()):
            return Decision(r.reason, r.name)
    return None


def decide(
    message: Mapping[str, Any], *, inbox: bool = True, rules: Rules | None = None
) -> Decision:
    """Решение по письму: ``message`` несет ``subject`` и ``from``; ``inbox`` - папка Входящие.

    Входящие: allow → senders → subject_prefix → subject_regex → senders_weak+subject_word.
    Sent (``inbox=False``): ТОЛЬКО subject_prefix (шумом по отправителю/теме не режется).
    """
    rules = rules if rules is not None else load_rules()
    subject = _norm_subject(message.get("subject"))
    addr = extract_address(message.get("from"))
    if not inbox:
        return _subject_only(rules, subject) or Decision()
    for r in rules.allow:
        if _addr_matches(r.match, addr):
            return Decision(None, r.name, allowed=True)
    for r in rules.senders:
        if _addr_matches(r.match, addr):
            return Decision(r.reason, r.name)
    hit = _subject_only(rules, subject)
    if hit is not None:
        return hit
    for r in rules.subject_regex:
        rx = rules.regex_of(r)
        if rx is not None and rx.search(subject):
            return Decision(r.reason, r.name)
    if addr or message.get("from"):
        low_from = nfc(str(message.get("from") or "")).lower()
        weak = next((w for w in rules.senders_weak if w.match and w.match in low_from), None)
        if weak is not None:
            tokens = [t.casefold() for t in _TOKEN_RE.findall(subject)]
            for r in rules.subject_word:
                if _word_hit(tokens, nfc(r.match).casefold()):
                    return Decision(r.reason, f"{r.name}+{weak.match}")
    return Decision()


def decide_meta(subject: Any, *, inbox: bool, rules: Rules) -> Decision | None:
    """Дешевый срез ДО чтения тела: в метаданных нет отправителя.

    Sent: ``subject_prefix`` решает окончательно (allow там не действует). Входящие: темовое
    правило (prefix/regex) может быть перебито ``allow`` по отправителю, которого мы еще не знаем,
    поэтому срез срабатывает только при ПУСТОМ allow; иначе решение откладывается до чтения письма
    (``decide`` с отправителем) - «allow бьет все» не нарушается ради экономии одного fetch.
    """
    subj = _norm_subject(subject)
    if not inbox:
        return _subject_only(rules, subj)
    if rules.allow:
        return None
    hit = _subject_only(rules, subj)
    if hit is not None:
        return hit
    for r in rules.subject_regex:
        rx = rules.regex_of(r)
        if rx is not None and rx.search(subj):
            return Decision(r.reason, r.name)
    return None


# --------------------------------------------------------------------------- #
# lint                                                                         #
# --------------------------------------------------------------------------- #
def _overlap(a: str, b: str) -> bool:
    def glob(p: str) -> str:
        return ("*" + p) if p.startswith("@") else p

    ga, gb = glob(a.lower()), glob(b.lower())
    return fnmatch.fnmatchcase(ga, gb) or fnmatch.fnmatchcase(gb, ga)


def lint_file(path: Path) -> tuple[list[str], list[str]]:
    """Проверка файла: ``(ошибки, замечания)``. Нет ошибок - yaml валиден, правила не пустые,
    ``allow`` не пересекается с ``senders``, шаблоны адресов осмысленны."""
    errors: list[str] = []
    notes: list[str] = []
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        return [f"{path}: файл не читается: {exc}"], notes
    try:
        rules = parse_rules(text, path=str(path))
    except RulesError as exc:
        return [str(exc)], notes
    for section in ("allow", "senders"):
        for r in getattr(rules, section):
            if "@" not in r.match:
                errors.append(f"{r.name}: адрес без «@» - нужен адрес целиком или «@домен»")
            elif r.match.startswith("@") and r.match.count(".") == 0:
                errors.append(f"{r.name}: домен без точки режет слишком широко")
    for a in rules.allow:
        for s in rules.senders:
            if _overlap(a.match, s.match):
                errors.append(
                    f"allow/{a.match} пересекается с {s.name}: allow бьет senders - уберите одно"
                )
    for section in SECTIONS:
        seen: set[str] = set()
        for r in getattr(rules, section):
            if r.match.lower() in seen:
                notes.append(f"{r.name}: дубль")
            seen.add(r.match.lower())
    if bool(rules.senders_weak) != bool(rules.subject_word):
        notes.append(
            "senders_weak и subject_word работают только ПАРОЙ: заполнен один из двух - "
            "правило не срабатывает"
        )
    for r in rules.subject_word:
        if r.match.strip("*") == "":
            errors.append(f"{r.name}: пустое слово")
    return errors, notes


# --------------------------------------------------------------------------- #
# Память «отказано»                                                            #
# --------------------------------------------------------------------------- #
class RefusedMemory:
    """``{msg_id: {reason, rule, ts}}`` - сообщения, снятые фильтром (инжестом или ретро-проходом).

    Инкрементальный инжест пропускает их (как ``included``), поэтому снятое не возвращается, даже
    когда тред ушел из индекса целиком. Это ОПТИМИЗАЦИЯ и страховка, не источник правды: при
    ``scope=full`` решает текущий yaml. Нечитаемый файл не ломает инжест (``readonly``: память не
    пишется поверх, пока человек не разберет файл), ретро-проход нечитаемый файл не терпит.
    """

    def __init__(self, path: Path | None = None) -> None:
        from core.adapters import StoreUnavailableError, load_json_store
        from core.config import mail_refused_path

        self.path = path if path is not None else mail_refused_path()
        self.data: dict[str, dict[str, str]] = {}
        self.dirty = False
        self.error: str | None = None
        try:
            raw = load_json_store(self.path, adapter="mail_refused", expect=dict)
        except StoreUnavailableError as exc:
            self.error = str(exc)[:200]
            logger.error("[mail-filter] память отказов нечитаема: %s", exc)
            raw = None
        if isinstance(raw, dict):
            self.data = {str(k): v for k, v in raw.items() if isinstance(v, dict)}

    def __contains__(self, msg_id: object) -> bool:
        return str(msg_id) in self.data

    def __len__(self) -> int:
        return len(self.data)

    def add(self, msg_id: str, reason: str | None, rule: str | None, ts: str) -> None:
        if str(msg_id) not in self.data:
            self.data[str(msg_id)] = {
                "reason": str(reason or ""), "rule": str(rule or ""), "ts": ts,
            }
            self.dirty = True

    def save(self) -> None:
        if not self.dirty or self.error is not None:
            return
        import json

        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, sort_keys=True), encoding="utf-8")
        tmp.replace(self.path)
        self.dirty = False
