"""MAIL-GAP-1 п.2 — замер «дыры курсора» почты: сколько писем за N дней вне манифеста.

Дыра: письмо, появившееся в локальном Outlook ПОЗЖЕ более свежих (досинхронизация кусками,
перенос из подпапки, задержка сервера), имеет ``time received`` старше курсора, и курсор без
перекрытия отрезал его навсегда. Замер - сухой проход ``ingest_mail(since=сегодня − N,
dry_run=True)``: «добавилось бы» по папкам = писем окна, которых нет в манифесте (resumed - уже
там, шум по yaml снят до подсчета) МИНУС письма новее новейшего в манифесте папки: те пришли
после последней синхронизации и ждут ее (SMOKE-DRIFT-1), дырой курсора не являются. Тела не
читаются, в vault/манифест ничего не пишется.

Здесь же - ЕДИНСТВЕННЫЙ формат строки результата (``format_detail``) и ее разбор
(``parse_detail``): строку пишет смоук С-13 в свой лог, читает доктор «Вход: источники» - как
``core.smoke`` держит формат ``RESULT``, чтобы они не разъехались.

Известное ограничение: письма, снятые приватностью, в манифест не попадают и в сухом проходе
остаются «добавляемыми» - это фон замера (порог ``DT_MAIL_GAP_MAX``, дефолт 5), не дыра.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import mail_gap_max
from core.legacy.mail import MailBridge, ingest_mail

__all__ = [
    "GAP_DAYS",
    "GapReport",
    "format_detail",
    "measure_gap",
    "parse_detail",
]

GAP_DAYS = 90  # окно замера: «за 90 дн»
_DATES_SHOWN = 6  # сколько дат показывать в красной строке (самые свежие)
_DETAIL_RE = re.compile(r"дыра курсора за (\d+) дн: (\d+)")


@dataclass
class GapReport:
    """Итог замера: кандидаты на добавление по папкам и их даты (дни, новые первыми)."""

    days: int
    since: str
    threshold: int
    added_by_folder: dict[str, int] = field(default_factory=dict)
    dates_by_folder: dict[str, list[str]] = field(default_factory=dict)
    # Из ``added_by_folder``: письма новее новейшего в манифесте папки - очередь обычной
    # синхронизации (``sync.fast`` раз в 30 мин), а не письма, пропущенные курсором.
    after_cursor_by_folder: dict[str, int] = field(default_factory=dict)

    def gap_by_folder(self) -> dict[str, int]:
        """«Добавилось бы» минус «новее курсора» по папкам - собственно дыра."""
        return {
            f: max(0, n - self.after_cursor_by_folder.get(f, 0))
            for f, n in self.added_by_folder.items()
        }

    @property
    def after_cursor(self) -> int:
        return sum(self.after_cursor_by_folder.values())

    @property
    def total(self) -> int:
        return sum(self.gap_by_folder().values())

    @property
    def ok(self) -> bool:
        return self.total <= self.threshold

    def text(self) -> str:
        """``дыра курсора за 90 дн: 7 (порог 5) · inbox 7 (даты: …)`` - число и даты."""
        return format_detail(self)


def format_detail(report: GapReport) -> str:
    head = f"дыра курсора за {report.days} дн: {report.total} (порог {report.threshold})"
    parts = []
    gap = report.gap_by_folder()
    for folder in sorted(gap):
        n = gap[folder]
        if not n:
            continue
        days = sorted(report.dates_by_folder.get(folder, []), reverse=True)
        shown = ", ".join(days[:_DATES_SHOWN]) + ("…" if len(days) > _DATES_SHOWN else "")
        parts.append(f"{folder} {n}" + (f" (даты: {shown})" if shown else ""))
    waiting = ""
    if report.after_cursor:
        waiting = f" · новее курсора {report.after_cursor} (ждут синхронизации)"
    return head + (" · " + "; ".join(parts) if parts else "") + waiting + f" · с {report.since}"


def parse_detail(text: str) -> tuple[int, int] | None:
    """``(дней, писем)`` из строки результата (и из причины красного), иначе ``None``."""
    m = _DETAIL_RE.search(text or "")
    return (int(m.group(1)), int(m.group(2))) if m else None


def measure_gap(
    vault: Path,
    bridge: MailBridge,
    *,
    days: int = GAP_DAYS,
    folders: list[dict[str, str]] | None = None,
    today: datetime | None = None,
    on_progress: Callable[[str], None] | None = None,
) -> GapReport:
    """Сухой проход с ``since = сегодня − days``: сколько писем окна вне манифеста (по папкам).

    ``dry_run=True`` - тела не читаются, vault/манифест/память «отказано» не пишутся. Явный
    ``since`` делает замер независимым от курсора: он меряет ровно то, что курсор мог потерять.
    """
    now = (today or datetime.now(UTC)).astimezone(UTC)
    since = (now - timedelta(days=days)).date().isoformat()
    quiet: Callable[[str], None] = on_progress if on_progress is not None else (lambda _m: None)
    stats = ingest_mail(
        vault, bridge, folders=folders, since=since, dry_run=True, on_progress=quiet,
    )
    return GapReport(
        days=days,
        since=since,
        threshold=mail_gap_max(),
        added_by_folder=dict(stats.added_by_folder),
        dates_by_folder={k: list(v) for k, v in stats.added_dates.items()},
        after_cursor_by_folder=dict(stats.added_after_cursor_by_folder),
    )


def last_gap(log_lines: list[str], *, now: datetime | None = None) -> dict[str, Any] | None:
    """Результат ПОСЛЕДНЕГО сценария С-13 из лога смоука: ``{ts, days, added, ok, age_days}``.

    Блок прогона открывает ``=== <ts> смоук …``, строка сценария - ``[ ok ]|[FAIL] С-13 …``.
    Сценарий без числа (Outlook недоступен, не собрался) → ``None``: «не замерялась».
    """
    ts = ""
    found: dict[str, Any] | None = None
    for line in log_lines:
        if line.startswith("=== "):
            ts = line[4:].split(" ", 1)[0]
            continue
        if "С-13" not in line or not line.startswith(("[ ok ]", "[FAIL]")):
            continue
        parsed = parse_detail(line)
        found = None if parsed is None else {
            "ts": ts, "days": parsed[0], "added": parsed[1], "ok": line.startswith("[ ok ]"),
        }
    if found is None:
        return None
    try:
        when = datetime.fromisoformat(str(found["ts"]).replace("Z", "+00:00"))
        found["age_days"] = round(((now or datetime.now(UTC)) - when).total_seconds() / 86400, 1)
    except ValueError:
        found["age_days"] = None
    return found
