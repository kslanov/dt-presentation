"""MAIL-THREAD-1 P1 — целостность почтовых тредов (чистые функции, без I/O).

Три вещи, на которых держится структура корпуса почты:

* **Инвариант «сообщение принадлежит ровно одному треду»** (:func:`find_multi_thread`):
  ``msg_id`` в двух тредах — это не склейка Outlook, а след сдвига параллельных массивов
  моста (``outlook_bridge._meta_page``). Инжест такого не допускает
  (``mail.ingest_mail``), а ремонт корпуса (``mail_repair``) ищет именно это.
* **Нормализация темы** (:func:`normalize_subject`): без ``Re:``/``Fw:``/``Ответ:`` —
  по ней определяется «родной» тред письма.
* **Детект склейки** (:func:`detect_splices`) — гард второго уровня: смена нормализованной
  темы И Jaccard доменов контрагентов < 0.2 между соседними сообщениями треда. Только
  сигнал (warning), без автоматического разделения: причина склейки теперь известна и
  устранена на мосту, разделять тред автоматикой не нужно.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any

__all__ = [
    "normalize_subject",
    "message_domains",
    "jaccard",
    "detect_splices",
    "find_multi_thread",
    "subject_mismatches",
    "SPLICE_JACCARD",
]

# Порог Jaccard доменов: ниже — «другой круг участников».
SPLICE_JACCARD = 0.2

_PREFIX_RE = re.compile(
    r"^\s*(?:re|fw|fwd|ответ|отв|пересл|переслано)\s*(?:\[\d+\])?\s*:\s*",
    re.IGNORECASE,
)
_DOMAIN_RE = re.compile(r"@([A-Za-z0-9.-]+)")


def normalize_subject(subject: Any) -> str:
    """Тема без служебных префиксов, в нижнем регистре, пробелы схлопнуты.

    ``Re: RE: Ответ: Follow up`` → ``follow up``. Пустая тема → ``""``.
    """
    text = unicodedata.normalize("NFC", str(subject or ""))
    while True:
        stripped = _PREFIX_RE.sub("", text, count=1)
        if stripped == text:
            break
        text = stripped
    return re.sub(r"\s+", " ", text).strip().casefold()


def _is_owner_domain(domain: str, owner_domains: list[str]) -> bool:
    return any(domain == od or domain.endswith("." + od) for od in owner_domains)


def message_domains(message: dict[str, Any], owner_domains: list[str] | None = None) -> set[str]:
    """Домены участников сообщения (from/to/cc) БЕЗ собственных (``owner_domains``)."""
    owners = [d.lower() for d in (owner_domains or []) if d]
    found: set[str] = set()
    for key in ("from", "to", "cc"):
        for m in _DOMAIN_RE.finditer(str(message.get(key) or "")):
            dom = m.group(1).lower().rstrip(".")
            if dom and not _is_owner_domain(dom, owners):
                found.add(dom)
    return found


def jaccard(a: set[str], b: set[str]) -> float:
    """Jaccard двух множеств; обе пусты → 1.0 (нет свидетельства разности)."""
    if not a and not b:
        return 1.0
    return len(a & b) / len(a | b)


def detect_splices(
    messages: list[dict[str, Any]],
    owner_domains: list[str] | None = None,
    *,
    threshold: float = SPLICE_JACCARD,
) -> list[dict[str, Any]]:
    """Подозрения на склейку в треде: границы между соседними сообщениями.

    ``messages`` — в хронологическом порядке. Граница — пара соседних сообщений, у
    которых (а) обе темы известны и их нормализованные формы различаются И (б) Jaccard
    доменов контрагентов < ``threshold``. ``Re:``/``Fw:``-смена темы при тех же
    участниках — НЕ граница; смена круга участников при той же теме — тоже. Сообщения
    без сохранённой темы (корпус до MAIL-THREAD-1) границ не дают: нет свидетельства.

    Возвращает ``[{between: (i, j), jaccard, subjects: (a, b)}]`` (индексы 1-based).
    """
    out: list[dict[str, Any]] = []
    for i in range(1, len(messages)):
        prev, cur = messages[i - 1], messages[i]
        subj_a = normalize_subject(prev.get("subject"))
        subj_b = normalize_subject(cur.get("subject"))
        if not subj_a or not subj_b or subj_a == subj_b:
            continue
        score = jaccard(message_domains(prev, owner_domains), message_domains(cur, owner_domains))
        if score < threshold:
            out.append(
                {
                    "between": (i, i + 1),
                    "jaccard": round(score, 3),
                    "subjects": (str(prev.get("subject") or ""), str(cur.get("subject") or "")),
                }
            )
    return out


def find_multi_thread(index: dict[str, dict[str, Any]]) -> dict[str, list[str]]:
    """``msg_id → [thread_key, …]`` для сообщений, лежащих в БОЛЕЕ чем одном треде.

    ``index`` — лёгкий индекс манифеста (``thread_key → {msg_ids: […], …}``).
    Нарушение инварианта «msg_id принадлежит ровно одному треду».
    """
    owners: dict[str, list[str]] = {}
    for tkey, entry in index.items():
        for mid in entry.get("msg_ids") or []:
            owners.setdefault(str(mid), []).append(tkey)
    return {mid: tks for mid, tks in owners.items() if len(tks) > 1}


def subject_mismatches(rec: dict[str, Any]) -> tuple[int, list[str]]:
    """Согласие тем: ``(проверено, [msg_id с темой ≠ теме треда])`` (нормализованно).

    Проверяются только сообщения с сохранённой темой (записи до MAIL-THREAD-1 её не
    несут). Сигнал смоука С-9: чужое письмо в треде обычно приходит с чужой темой.
    """
    thread = normalize_subject(rec.get("subject"))
    checked = 0
    bad: list[str] = []
    for mid, m in (rec.get("messages") or {}).items():
        if not m.get("subject"):
            continue
        checked += 1
        if normalize_subject(m.get("subject")) != thread:
            bad.append(str(mid))
    return checked, bad
