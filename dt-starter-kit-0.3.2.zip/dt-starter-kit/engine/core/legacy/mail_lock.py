"""MAIL-LOCK-1 - лок писателей манифеста почты (одна точка для CLI и JOB-1).

Манифест ``outlook_ingest_manifest.json`` и сайдкары ``mail_threads/*.json`` пишут четыре
писателя (``ingest_mail``, ``--refilter``, ``mail_repair`` + ``mail_repair_post``), каждый -
полной перезаписью индекса из своей копии в памяти. Без общего лока последний пишущий затирает
чужое (29.10: 45 записей манифеста без сайдкара). Лок - ``dt-sync.lock`` (тот же flock, что у
``dt_sync fast``), взятие - :func:`core.runlock.hold`; здесь - дефолты ожидания и сообщения.
Лок берут ТОЧКИ ВХОДА (CLI, обработчик JOB-1), функции ``core`` - нет.
"""

from __future__ import annotations

import contextlib
import os
from collections.abc import Callable, Iterator
from typing import Any

from core import runlock

__all__ = ["WAIT_ENV", "default_wait_s", "mail_writer_lock", "resolve_wait_s"]

WAIT_ENV = "DT_MAIL_LOCK_WAIT_S"


def default_wait_s() -> float:
    """Сколько ждать занятый лок по умолчанию, секунды (``DT_MAIL_LOCK_WAIT_S``, дефолт 600)."""
    raw = (os.environ.get(WAIT_ENV) or "").strip()
    try:
        value = float(raw)
    except ValueError:
        return runlock.DEFAULT_WAIT_S
    return value if value >= 0 else runlock.DEFAULT_WAIT_S


def resolve_wait_s(wait: float | None, *, no_wait: bool = False) -> float:
    """``--no-wait`` → 0; явный ``--wait`` → он; иначе дефолт."""
    if no_wait:
        return 0.0
    return default_wait_s() if wait is None else max(0.0, float(wait))


def _holder_text(holder: dict[str, Any]) -> str:
    if not holder:
        return "держатель не определен"
    return (
        f"держит pid {holder.get('pid')} mode={holder.get('mode') or '?'} "
        f"step={holder.get('step') or '-'} с {holder.get('started') or '?'}"
    )


@contextlib.contextmanager
def mail_writer_lock(
    step: str,
    *,
    wait_s: float,
    echo: Callable[[str], None] = print,
) -> Iterator[runlock.HoldResult]:
    """Взять ``dt-sync.lock`` для писателя почты; печатает ожидание и «ждал лок N с».

    Занят и ``wait_s`` вышел (или ``0`` - ``--no-wait``) - :class:`core.runlock.RunLockBusy`
    (``code="sync_busy"``, имя держателя в сообщении). Внутри ``dt_sync fast`` (тот же поток) лок
    уже наш - проходим без ожидания.
    """
    from core.config import sync_lock_path

    def _on_wait(holder: dict[str, Any]) -> None:
        echo(f"[mail-lock] {step}: лок dt-sync занят ({_holder_text(holder)}) - ждем до "
             f"{wait_s:.0f} с")

    with runlock.hold(
        sync_lock_path(), mode="mail", step=step, wait_s=wait_s, on_wait=_on_wait
    ) as held:
        if held.waited_s:
            echo(f"[mail-lock] {step}: ждал лок {held.waited_s:.0f} с")
        yield held
