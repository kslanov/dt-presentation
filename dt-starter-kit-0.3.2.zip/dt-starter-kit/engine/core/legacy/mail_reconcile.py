"""MAIL-LOCK-1 п.6 - сверка индекса манифеста почты и сайдкаров тредов.

Индекс ``outlook_ingest_manifest.json`` и сайдкары ``mail_threads/<sha1(key)>.json`` обязаны быть
взаимно однозначны. Гонка писателей без общего лока (29.10) оставляла записи индекса без сайдкара
(refilter снял тред и удалил сайдкар, а ``ingest_mail`` сохранил свою копию индекса с ним). Здесь:

* :func:`find_orphans` - обе стороны расхождения (для доктора и отчета);
* :func:`reconcile_corpus` - снять сироты индекса, чьи ``msg_id`` ВСЕ в памяти «отказано» (их тред
  снял фильтр, запись - след гонки); остальные сироты - в отчет, не трогать; сайдкары без записи -
  только в отчет.

Пишет только индекс манифеста (атомарно), заметки и сайдкары не трогает. Вызывающий (CLI) держит
``dt-sync.lock`` при ``apply``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.config import outlook_ingest_manifest_path
from core.legacy.mail import _load_manifest, _save_manifest, _state_dir, _thread_file
from core.legacy.mail_filter import RefusedMemory

__all__ = ["Orphans", "ReconcileReport", "find_orphans", "reconcile_corpus"]

_EXAMPLES = 5


@dataclass
class Orphans:
    """Расхождение индекса и сайдкаров: ключи записей без сайдкара, имена сайдкаров без записи."""

    threads: int = 0
    entries_without_sidecar: list[str] = field(default_factory=list)
    sidecars_without_entry: list[str] = field(default_factory=list)


def find_orphans(manifest_path: Path | None = None) -> Orphans:
    """Сверить индекс (записи с ``msg_ids``) и каталог сайдкаров; ничего не пишет."""
    mpath = manifest_path if manifest_path is not None else outlook_ingest_manifest_path()
    index = {k: v for k, v in _load_manifest(mpath).items() if "msg_ids" in v}
    state_dir = _state_dir(mpath)
    on_disk: set[str] = set()
    if state_dir.is_dir():
        on_disk = {p.name for p in state_dir.iterdir() if p.suffix == ".json"}
    expected = {_thread_file(state_dir, k).name: k for k in index}
    return Orphans(
        threads=len(index),
        entries_without_sidecar=sorted(k for n, k in expected.items() if n not in on_disk),
        sidecars_without_entry=sorted(on_disk - set(expected)),
    )


@dataclass
class ReconcileReport:
    """Итог ``--reconcile``: сколько сирот снято/оставлено и примеры."""

    dry_run: bool = True
    threads: int = 0
    entries_without_sidecar: int = 0
    dropped: int = 0  # сироты, чьи msg_id все в «отказано»: сняты (или будут снимать)
    left: int = 0  # сироты с неотказанными msg_id: в отчет, не трогали
    sidecars_without_entry: int = 0
    dropped_examples: list[str] = field(default_factory=list)
    left_examples: list[dict[str, Any]] = field(default_factory=list)
    sidecar_examples: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


def reconcile_corpus(
    *,
    dry_run: bool = True,
    manifest_path: Path | None = None,
    memory: RefusedMemory | None = None,
) -> ReconcileReport:
    """Снять сироты индекса, у которых все ``msg_id`` уже в памяти «отказано».

    Остальные сироты (есть неотказанные сообщения - тред, возможно, еще нужен) остаются в отчете
    без правки. Нечитаемая память «отказано» - :class:`~core.adapters.StoreUnavailableError`
    (без нее нельзя доказать, что тред снят фильтром - не снимаем). Dry-run ничего не пишет.
    """
    from core.adapters import StoreUnavailableError

    mpath = manifest_path if manifest_path is not None else outlook_ingest_manifest_path()
    mem = memory if memory is not None else RefusedMemory()
    if mem.error is not None:
        raise StoreUnavailableError(
            f"память «отказано» нечитаема: {mem.error}", adapter="mail_refused", path=str(mem.path)
        )
    orphans = find_orphans(mpath)
    manifest = _load_manifest(mpath)
    report = ReconcileReport(
        dry_run=dry_run, threads=orphans.threads,
        entries_without_sidecar=len(orphans.entries_without_sidecar),
        sidecars_without_entry=len(orphans.sidecars_without_entry),
        sidecar_examples=orphans.sidecars_without_entry[:_EXAMPLES],
    )
    droppable: list[str] = []
    for key in orphans.entries_without_sidecar:
        msg_ids = [str(m) for m in (manifest.get(key, {}).get("msg_ids") or [])]
        unrefused = [m for m in msg_ids if m not in mem]
        if msg_ids and not unrefused:
            droppable.append(key)
            if len(report.dropped_examples) < _EXAMPLES:
                report.dropped_examples.append(key)
        else:
            report.left += 1
            if len(report.left_examples) < _EXAMPLES:
                report.left_examples.append(
                    {"thread": key, "msgs": len(msg_ids), "not_refused": len(unrefused)}
                )
    report.dropped = len(droppable)
    if droppable and not dry_run:
        for key in droppable:
            manifest.pop(key, None)
        _save_manifest(mpath, manifest)
    return report
