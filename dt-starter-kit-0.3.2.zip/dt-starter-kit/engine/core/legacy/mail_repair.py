"""MAIL-THREAD-1 (P0) — ремонт корпуса почты: вернуть сообщения в свои треды.

Контекст. Сдвиг параллельных массивов моста (``outlook_bridge._meta_page``) портил ВСЕ
поля страницы (``conv``, ``subject``, ``date``), а не только ``conversationId``: письмо
попадало в тред соседнего разговора (замер: 200 ``msg_id`` в >1 треде, 196 тредов).
Мост исправлен, инжест не кладёт ``msg_id`` во второй тред
(``mail.ingest_mail``) — **ремонт имеет смысл только после них**, иначе следующий инжест
засорит корпус снова; эта процедура разбирает уже накопленное.

Что делает :func:`repair_corpus` (контракт §9 п.11г: dry-run → отчёт → канарейка → полный):

1. **Источник правды о тредах** (``truth``) — исправленное чтение метаданных моста: по
   каждому ``msg_id`` его настоящий ``conversationId`` и тема. Сообщение, лежащее не в
   «своём» треде, — misplaced; лежащее в >1 треде — ещё и нарушает инвариант. Без
   ``truth`` (офлайн) остаётся запасное правило ТЗ п.7: родной тред — тот, чья тема после
   нормализации (``Re/Fw/Ответ``) совпала с темой самого письма; неоднозначные — в отчёт.
2. Из чужого треда сообщение **удаляется**; если в «своём» его ещё нет — **добавляется**
   (без нового чтения тела: запись переезжает из сайдкара).
3. Метаданные КАЖДОГО сообщения затронутого треда перечитываются из достоверного
   per-message чтения (``fetch``: ``fetch_by_ids`` по точному id) — не из страницы:
   ``date``/``from``/``to``/``cc``/``subject``. Тема треда, не совпадающая ни с одним его
   собственным сообщением, пересобирается; ``first_date``/``last_date``/участники/домены/
   ``message_count`` — по его собственным сообщениям. Заметка переписывается штатным
   рендером инжеста (не шелл); поменялась тема → поменялся слуг → старый файл заменяется
   новым (id заметки прежний, ссылки по id целы).
4. Тред, который опустел бы, не трогается (отчёт ``would_empty``); с ``drop_emptied=True``
   удаляется целиком (заметка, сайдкар, строка индекса) — только если всё его содержимое
   переехало в свои треды.
5. Неоднозначное и недостоверифицированное — в отчёт, не трогается.

Идемпотентно. ``dry_run=True`` (по умолчанию) пишет только отчёт (Outlook при этом
читается, он read-only). ``limit`` — канарейка: взять в работу первые N сообщений.

После ``apply`` — пересчёт потребителей (``mail_repair_post``): пере-линковка с отзывом
неверных связей, ``hub_scan``, список затронутых выходов; переиндекс затронутых заметок.
"""

from __future__ import annotations

import copy
import hashlib
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import (
    mail_owner_domains,
    outlook_folders,
    outlook_ingest_manifest_path,
    outlook_self_tokens,
)
from core.legacy.mail import (
    _index_entry,
    _load_manifest,
    _load_thread_rec,
    _render_thread,
    _save_manifest,
    _save_thread_rec,
    _sender_is_me,
    _sorted_messages,
    _state_dir,
    _thread_file,
    _thread_key,
    _thread_source_path,
)
from core.legacy.mail_integrity import find_multi_thread, normalize_subject
from core.legacy.render import legacy_note_id

logger = logging.getLogger(__name__)

__all__ = [
    "RepairReport",
    "AssignError",
    "repair_corpus",
    "bridge_truth",
    "bridge_fetch",
    "TruthLookup",
    "FetchLookup",
]

class AssignError(ValueError):
    """Явное решение ``--assign`` нельзя выполнить (неизвестный msg_id/тред): отказ, не молчание."""


def _norm_conv(value: str) -> str:
    """``209169`` / ``conv:209169`` → ключ треда ``conv:209169``."""
    text = str(value or "").strip()
    return text if text.startswith(("conv:", "msg:")) else f"conv:{text}"


# () -> {msg_id: {"conv": conversationId, "subject": тема}} — исправленный мост.
TruthLookup = Callable[[], dict[str, dict[str, str]]]
# [(bucket, msg_id)] -> {msg_id: полное сообщение (fetch_by_ids)}.
FetchLookup = Callable[[list[tuple[str, str]]], dict[str, dict[str, Any]]]

_REFRESH_FIELDS = ("date", "from", "to", "cc", "subject")


@dataclass
class RepairReport:
    """Итог прогона ремонта (JSON-сериализуемый через :meth:`to_dict`)."""

    dry_run: bool = True
    limit: int | None = None
    truth_source: str = "none"  # bridge | subject-heuristic | assign
    assigned: list[dict[str, Any]] = field(default_factory=list)  # явные решения (--assign)
    dup_messages: int = 0  # msg_id в >1 треде (нарушение инварианта)
    dup_threads: int = 0
    misplaced_total: int = 0  # сообщений не в «своём» треде по исправленному мосту
    unverifiable: int = 0  # сообщений корпуса, которых нет в чтении моста
    processed: int = 0
    resolved: list[dict[str, Any]] = field(default_factory=list)
    ambiguous: list[dict[str, Any]] = field(default_factory=list)
    would_empty: list[dict[str, Any]] = field(default_factory=list)
    rewritten: list[dict[str, Any]] = field(default_factory=list)
    dropped: list[str] = field(default_factory=list)
    renamed: list[dict[str, str]] = field(default_factory=list)
    refresh: dict[str, Any] = field(default_factory=dict)
    attention_delta: list[dict[str, Any]] = field(default_factory=list)
    affected: list[dict[str, str]] = field(default_factory=list)  # thread/note_path/note_id
    elapsed_s: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "dry_run": self.dry_run,
            "limit": self.limit,
            "truth_source": self.truth_source,
            "assigned": self.assigned,
            "dup_messages": self.dup_messages,
            "dup_threads": self.dup_threads,
            "misplaced_total": self.misplaced_total,
            "unverifiable": self.unverifiable,
            "processed": self.processed,
            "resolved_count": len(self.resolved),
            "ambiguous_count": len(self.ambiguous),
            "would_empty_count": len(self.would_empty),
            "rewritten_count": len(self.rewritten),
            "dropped_count": len(self.dropped),
            "renamed_count": len(self.renamed),
            "refresh": self.refresh,
            "elapsed_s": round(self.elapsed_s, 2),
            "resolved": self.resolved,
            "ambiguous": self.ambiguous,
            "would_empty": self.would_empty,
            "rewritten": self.rewritten,
            "dropped": self.dropped,
            "renamed": self.renamed,
            "attention_delta": self.attention_delta,
            "affected": self.affected,
        }


# --------------------------------------------------------------------------- #
# Провайдеры поверх read-only моста                                            #
# --------------------------------------------------------------------------- #
def bridge_truth(bridge: Any, folders: list[dict[str, str]] | None = None) -> TruthLookup:
    """``truth`` поверх ИСПРАВЛЕННОГО ``list_folder_meta`` (выровненные массивы)."""
    specs = folders if folders is not None else outlook_folders()

    def truth() -> dict[str, dict[str, str]]:
        out: dict[str, dict[str, str]] = {}
        for spec in specs:
            for row in bridge.list_folder_meta(spec["name"], None):
                eid = str(row.get("entryID") or "")
                if eid:
                    out.setdefault(
                        eid,
                        {
                            "conv": str(row.get("conversationId") or ""),
                            "subject": str(row.get("subject") or ""),
                            "bucket": spec["bucket"],
                        },
                    )
        return out

    return truth


def bridge_fetch(bridge: Any, folders: list[dict[str, str]] | None = None) -> FetchLookup:
    """``fetch`` поверх ``fetch_by_ids``: прямые id-запросы, по одному вызову на папку."""
    specs = folders if folders is not None else outlook_folders()
    name_by_bucket = {s["bucket"]: s["name"] for s in specs}

    def fetch(pairs: list[tuple[str, str]]) -> dict[str, dict[str, Any]]:
        by_folder: dict[str, list[str]] = {}
        for bucket, mid in pairs:
            name = name_by_bucket.get(bucket)
            if name:
                by_folder.setdefault(name, []).append(mid)
        out: dict[str, dict[str, Any]] = {}
        for name, ids in by_folder.items():
            for start in range(0, len(ids), 300):
                for msg in bridge.fetch_by_ids(name, ids[start : start + 300]):
                    out[str(msg.get("entryID") or "")] = msg
        return out

    return fetch


def _id_key(mid: str) -> tuple[int, str]:
    return (0, f"{int(mid):020d}") if mid.isdigit() else (1, mid)


def _attention_view(index_entry: dict[str, Any] | None, rec: dict[str, Any]) -> dict[str, Any]:
    msgs = _sorted_messages(rec) if rec.get("messages") else []
    return {
        "subject": (index_entry or {}).get("subject", rec.get("subject", "")),
        "last_date": (index_entry or {}).get("last_date", rec.get("last_date", "")),
        "count": len(rec.get("messages") or {}),
        "last_is_me": bool(msgs[-1].get("is_me")) if msgs else None,
        "domains": sorted(rec.get("counterparty_domains") or []),
    }


# --------------------------------------------------------------------------- #
# Ремонт                                                                       #
# --------------------------------------------------------------------------- #
class _Repair:
    """Состояние одного прогона ремонта (план → сборка на копиях → применение)."""

    def __init__(
        self,
        vault_path: Path,
        mpath: Path,
        owner_doms: list[str],
        selfs: list[str],
        report: RepairReport,
    ) -> None:
        self.vault = vault_path
        self.mpath = mpath
        self.state_dir = _state_dir(mpath)
        self.owner_doms = owner_doms
        self.selfs = selfs
        self.report = report
        self.index = {k: v for k, v in _load_manifest(mpath).items() if "msg_ids" in v}
        self.dups = find_multi_thread(self.index)
        self.holders: dict[str, list[str]] = {}
        for tkey, ent in self.index.items():
            for mid in ent.get("msg_ids") or []:
                self.holders.setdefault(str(mid), []).append(tkey)
        self._recs: dict[str, dict[str, Any]] = {}
        self.targets: dict[str, tuple[str, str]] = {}
        self.removals: dict[str, set[str]] = {}
        self.additions: dict[str, dict[str, dict[str, Any]]] = {}

    def rec_of(self, tkey: str) -> dict[str, Any]:
        if tkey not in self._recs:
            self._recs[tkey] = _load_thread_rec(self.state_dir, tkey)
        return self._recs[tkey]

    # -- 1. куда должно уйти каждое сообщение ----------------------------------
    def candidates_from_truth(self, truth_map: dict[str, dict[str, str]]) -> list[str]:
        out: list[str] = []
        for mid, hs in self.holders.items():
            info = truth_map.get(mid)
            if info is None:
                self.report.unverifiable += 1
                if len(hs) > 1:
                    out.append(mid)  # дубль без правды моста — запасным правилом
                continue
            want = _thread_key(info["conv"], mid)
            if hs == [want]:
                continue
            self.targets[mid] = (want, "bridge")
            out.append(mid)
        self.report.misplaced_total = len(self.targets)
        return out

    def heuristic_targets(self, mids: list[str], fetch: FetchLookup | None) -> None:
        """Запасное правило ТЗ п.7: родной тред — с темой письма после нормализации."""
        subjects: dict[str, str] = {}
        missing: list[tuple[str, str]] = []
        for mid in mids:
            sub, bucket = "", ""
            for tkey in self.holders[mid]:
                m = self.rec_of(tkey)["messages"].get(mid) or {}
                bucket = bucket or str(m.get("bucket") or "")
                sub = sub or str(m.get("subject") or "")
            if sub:
                subjects[mid] = sub
            else:
                missing.append((bucket, mid))
        if missing and fetch is not None:
            got = fetch(missing)
            for _b, mid in missing:
                if got.get(mid, {}).get("subject"):
                    subjects[mid] = str(got[mid]["subject"])
        for mid in mids:
            norm = normalize_subject(subjects.get(mid, ""))
            if not norm:
                self.report.ambiguous.append(
                    {"msg_id": mid, "threads": self.holders[mid], "reason": "no_subject"}
                )
                continue
            natives = [
                t for t in self.holders[mid]
                if normalize_subject(self.rec_of(t).get("subject")) == norm
            ]
            if len(natives) != 1:
                self.report.ambiguous.append(
                    {
                        "msg_id": mid,
                        "threads": self.holders[mid],
                        "subject": subjects[mid],
                        "reason": "no_match" if not natives else "multi_match",
                        "matched": natives,
                    }
                )
                continue
            self.targets[mid] = (natives[0], "subject-heuristic")

    def apply_assign(self, assign: dict[str, str]) -> list[str]:
        """Явные решения человека → цели переноса (с валидацией, без угадывания)."""
        mids: list[str] = []
        for raw_mid, raw_conv in assign.items():
            mid, want = str(raw_mid).strip(), _norm_conv(raw_conv)
            if mid not in self.holders:
                raise AssignError(f"msg_id {mid!r} нет в манифесте почты — назначать нечего")
            if want not in self.index:
                raise AssignError(
                    f"тред {want!r} нет в манифесте — --assign не создаёт тредов "
                    f"(письмо {mid} лежит в {self.holders[mid]})"
                )
            self.targets[mid] = (want, "assign")
            mids.append(mid)
        return mids

    def record_assignments(self, dry_run: bool) -> None:
        """Строка аудита по каждому явному решению (кто/что/куда) + событие в журнал."""
        import json as _json

        moved = {r["msg_id"]: r for r in self.report.resolved}
        rows: list[dict[str, Any]] = []
        for mid, (want, _how) in self.targets.items():
            if mid not in moved:
                rows.append({"msg_id": mid, "target": want, "by": "human",
                             "status": "already_assigned_or_refused"})
                continue
            rows.append({"msg_id": mid, "target": want, "by": "human", "status": "assigned",
                         "removed_from": moved[mid]["removed_from"],
                         "added_to_target": moved[mid]["added_to_native"]})
        self.report.assigned = rows
        if dry_run:
            return
        stamp = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        audit = self.mpath.parent / "mail_repair_audit.jsonl"
        audit.parent.mkdir(parents=True, exist_ok=True)
        with audit.open("a", encoding="utf-8") as fh:
            for r in rows:
                fh.write(_json.dumps({"ts": stamp, "action": "assign", **r}, ensure_ascii=False)
                         + "\n")
        _emit([{"stage": "ingest", "status": "mail_assigned", "detail": r} for r in rows
               if r["status"] == "assigned"])

    # -- 2. планы удаления/добавления ------------------------------------------
    def plan_moves(self, mids: list[str], drop_emptied: bool) -> None:
        for mid in mids:
            if mid not in self.targets:
                continue
            want, how = self.targets[mid]
            have = self.holders[mid]
            remove_from = [t for t in have if t != want]
            if not remove_from:
                continue
            emptied = [
                t for t in remove_from
                if len(self.rec_of(t)["messages"]) - len(self.removals.get(t, set()) | {mid}) <= 0
            ]
            if emptied and not drop_emptied:
                for t in emptied:
                    self.report.would_empty.append(
                        {"msg_id": mid, "thread": t, "reason": "would_empty_thread"}
                    )
                continue
            for t in remove_from:
                self.removals.setdefault(t, set()).add(mid)
            add_to = want not in have
            if add_to:
                src = self.rec_of(have[0])["messages"].get(mid)
                if src is not None:
                    self.additions.setdefault(want, {})[mid] = dict(src)
            self.report.resolved.append(
                {
                    "msg_id": mid,
                    "native": want,
                    "removed_from": remove_from,
                    "added_to_native": add_to,
                    "by": how,
                }
            )

    # -- 3. новые записи на копиях ----------------------------------------------
    def assemble(self) -> tuple[list[str], dict[str, dict[str, Any]]]:
        touched = sorted(set(self.removals) | set(self.additions))
        now: dict[str, dict[str, Any]] = {}
        for tkey in touched:
            rec = copy.deepcopy(self.rec_of(tkey))
            if tkey not in self.index:  # целевой тред ещё не существует — заводим
                rec.setdefault("conversationId", tkey[5:] if tkey.startswith("conv:") else "")
                rec.setdefault("subject", "")
            for mid in self.removals.get(tkey, set()):
                rec["messages"].pop(mid, None)
            for mid, m in self.additions.get(tkey, {}).items():
                rec["messages"][mid] = dict(m)
            now[tkey] = rec
        return touched, now

    def refresh(self, now: dict[str, dict[str, Any]], fetch: FetchLookup | None) -> None:
        """Метаданные КАЖДОГО сообщения затронутых тредов — из per-message чтения."""
        stat: dict[str, Any] = {
            "messages": 0, "verified": 0, "unverified": 0,
            "changed": dict.fromkeys(_REFRESH_FIELDS, 0),
            "source": "fetch_by_ids" if fetch is not None else "none (sidecar as is)",
        }
        stat["messages"] = sum(len(r["messages"]) for r in now.values())
        if fetch is not None and now:
            pairs = [
                (str(m.get("bucket") or ""), mid)
                for rec in now.values()
                for mid, m in rec["messages"].items()
            ]
            got = fetch(pairs)
            for rec in now.values():
                for mid, m in rec["messages"].items():
                    full = got.get(mid)
                    if full is None:
                        stat["unverified"] += 1
                        continue
                    stat["verified"] += 1
                    self._apply_fresh(m, full, stat["changed"])
        self.report.refresh = stat
        # Тема треда, не совпавшая ни с одним его сообщением, → тема последнего.
        for rec in now.values():
            msgs = _sorted_messages(rec)
            own = {normalize_subject(m.get("subject")) for m in msgs if m.get("subject")}
            if msgs and own and normalize_subject(rec.get("subject")) not in own:
                rec["subject"] = next(
                    (str(m["subject"]) for m in reversed(msgs) if m.get("subject")), ""
                )

    def _apply_fresh(
        self, m: dict[str, Any], full: dict[str, Any], changed: dict[str, int]
    ) -> None:
        for f in _REFRESH_FIELDS:
            if f not in full:
                continue
            new = str(full.get(f) or "")
            new = new.strip() if f == "subject" else new
            if f == "date" and not new:
                continue
            if str(m.get(f) or "") != new:
                changed[f] += 1
                m[f] = new
        m["is_me"] = _sender_is_me(str(m.get("from") or ""), self.selfs)
        m["hash"] = hashlib.sha1(  # noqa: S324 — content hash (identity/dedup), not security
            f"{m.get('date', '')}|{m.get('from', '')}|{m.get('text', '')}".encode()
        ).hexdigest()

    # -- 4. запись ----------------------------------------------------------------
    def commit(
        self, touched: list[str], now: dict[str, dict[str, Any]], dry_run: bool
    ) -> None:
        rep = self.report
        emitted: list[dict[str, Any]] = []
        for tkey in touched:
            rec = now[tkey]
            old_rel = str(
                self.rec_of(tkey).get("note_path")
                or self.index.get(tkey, {}).get("note_path") or ""
            )
            before = _attention_view(self.index.get(tkey), self.rec_of(tkey))
            row: dict[str, Any] = {
                "thread": tkey,
                "removed": sorted(self.removals.get(tkey, set())),
                "added": sorted(self.additions.get(tkey, {})),
                "count_after": len(rec["messages"]),
            }
            note_id = legacy_note_id(_thread_source_path(tkey))
            if not rec["messages"]:
                row["dropped"] = True
                rep.rewritten.append(row)
                rep.dropped.append(tkey)
                if not dry_run:
                    if old_rel and (self.vault / old_rel).is_file():
                        (self.vault / old_rel).unlink()
                    _thread_file(self.state_dir, tkey).unlink(missing_ok=True)
                    self.index.pop(tkey, None)
                continue
            if dry_run:
                row["dry_run"] = True
                rep.rewritten.append(row)
                rep.affected.append({"thread": tkey, "note_path": old_rel, "note_id": note_id})
                continue
            rel, chash = _render_thread(
                tkey, rec, self.vault,
                owner_domains=self.owner_doms, self_tokens=self.selfs, dry_run=False,
            )
            rec["note_path"], rec["content_hash"] = rel, chash
            if old_rel and old_rel != rel and (self.vault / old_rel).is_file():
                (self.vault / old_rel).unlink()  # слуг сменился: файл переезжает, id прежний
                rep.renamed.append({"thread": tkey, "from": old_rel, "to": rel})
            _save_thread_rec(self.state_dir, tkey, rec)
            self.index[tkey] = _index_entry(rec)
            row["note_path"] = rel
            rep.rewritten.append(row)
            rep.affected.append({"thread": tkey, "note_path": rel, "note_id": note_id})
            after = _attention_view(self.index[tkey], rec)
            if after != before:
                rep.attention_delta.append({"thread": tkey, "before": before, "after": after})
            emitted.append(
                {
                    "stage": "ingest", "status": "mail_repaired", "note_id": note_id,
                    "path": rel,
                    "detail": {
                        "thread": tkey, "removed": len(row["removed"]),
                        "added": len(row["added"]), "count_after": row["count_after"],
                    },
                }
            )
        if not dry_run and touched:
            _save_manifest(self.mpath, self.index)
            _emit(emitted)
            logger.info(
                "[mail_repair] переписано тредов: %d, убрано сообщений: %d, "
                "переименовано файлов: %d",
                len(rep.rewritten), sum(len(v) for v in self.removals.values()),
                len(rep.renamed),
            )


def repair_corpus(
    vault_path: Path,
    *,
    dry_run: bool = True,
    limit: int | None = None,
    truth: TruthLookup | None = None,
    fetch: FetchLookup | None = None,
    drop_emptied: bool = False,
    assign: dict[str, str] | None = None,
    manifest_path: Path | None = None,
    owner_domains: list[str] | None = None,
    self_tokens: list[str] | None = None,
) -> RepairReport:
    """Починить корпус почты (см. модульный докстринг).

    ``assign={msg_id: conv}`` — **явное решение человека** (OUT-COMPLETE-1 п.0): для писем,
    которых мост не подтверждает (удалены из Outlook, без темы) и которые ремонт честно
    пометил ``ambiguous``. Такое письмо остаётся ТОЛЬКО в указанном треде; из остальных
    удаляется; метаданные всех затронутых тредов пересобираются штатным рендером (как у
    обычного ремонта), решение пишется строкой аудита. Автоматика (``truth``/эвристика
    по теме) в этом режиме не запускается: человек решил. Неизвестный ``msg_id`` / тред вне
    манифеста → :class:`AssignError`.
    """
    start = time.perf_counter()
    mpath = manifest_path if manifest_path is not None else outlook_ingest_manifest_path()
    report = RepairReport(dry_run=dry_run, limit=limit)
    rep = _Repair(
        Path(vault_path), mpath,
        owner_domains if owner_domains is not None else mail_owner_domains(),
        self_tokens if self_tokens is not None else outlook_self_tokens(),
        report,
    )
    report.dup_messages = len(rep.dups)
    report.dup_threads = len({t for ts in rep.dups.values() for t in ts})

    if assign:
        report.truth_source = "assign"
        candidates = rep.apply_assign(assign)
    elif truth is not None:
        report.truth_source = "bridge"
        candidates = rep.candidates_from_truth(truth())
    else:
        report.truth_source = "subject-heuristic"
        candidates = list(rep.dups)
    todo = sorted(candidates, key=_id_key)
    if limit is not None:
        todo = todo[: max(0, int(limit))]
    report.processed = len(todo)
    if not assign:
        rep.heuristic_targets([m for m in todo if m not in rep.targets], fetch)
    rep.plan_moves(todo, drop_emptied)

    touched, now = rep.assemble()
    rep.refresh(now, fetch)
    rep.commit(touched, now, dry_run)
    if assign:
        rep.record_assignments(dry_run)
    report.elapsed_s = time.perf_counter() - start
    return report


def _emit(rows: list[dict[str, Any]]) -> None:
    try:
        from core.eventlog import emit_batch, new_run_id

        run_id = new_run_id()
        for r in rows:
            r["run_id"] = run_id
        emit_batch(rows)
    except Exception:  # noqa: BLE001 — журнал не критичный путь
        logger.debug("eventlog emit(mail_repaired) failed", exc_info=True)
