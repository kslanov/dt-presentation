"""MAIL-THREAD-1 (P0, «радиус поражения») — пересчёт потребителей после ремонта корпуса.

Ремонт (:mod:`core.legacy.mail_repair`) исправляет треды. Но замусоренные метаданные
(``counterparty_domains`` чужих проектов) уже успели стать входом для соседей:

* **Связи** (:func:`relink_threads`). Детерминированный линкер матчит ``counterparty_domains``
  → клиент-хабы, так что тред с чужими доменами был связан с чужими клиентами. Переписанная
  заметка потеряла ``## Связано`` (рендер инжеста), но очередь ``link_proposals.jsonl`` помнит
  статус ``applied`` и не даст предложить пару заново. Здесь: по ЧИСТЫМ метаданным заново
  считаются детерминированные связи; строки очереди, которых по чистым доменам быть не
  должно, получают ``revoked`` (+ запись в ``link_revoked.jsonl``), валидные — повторно
  применяются в заметку, недостающие — предлагаются и применяются. Семантические строки
  затронутых тредов (эмбеддинг считался по чужому тексту) отзываются и перечисляются в
  отчёте: пересчитать их — отдельным решением.
* **Кандидаты в хабы** (:func:`rescan_hubs`). ``hub_scan`` считался по грязным
  ``counterparties``: перезапускается; ``applied``-кандидаты, чьи источники — только
  затронутые треды, идут в отчёт К. и автоматически НЕ трогаются.
* **Выходы** (:func:`outputs_referencing`). Документы, чьи ``sources.md`` ссылаются на
  затронутые треды, — на ревизию К.: провенанс фиксирует использованное, а не то, что
  тред был замусорен.

Всё детерминированно, без сети и LLM.
"""

from __future__ import annotations

import json
import logging
import tempfile
from pathlib import Path
from typing import Any

from core.config import link_applied_path, link_proposals_path
from core.ingest import _entity_catalog
from core.linking.apply import apply_approved
from core.linking.candidates import existing_link_targets
from core.linking.deterministic import resolve_note
from core.linking.engine import (
    RESOLVER_DETERMINISTIC,
    _eligible_hub_targets,
    propose_deterministic,
)
from core.linking.propose import (
    STATUS_APPLIED,
    STATUS_APPROVED,
    STATUS_PENDING,
    STATUS_REVOKED,
    LinkProposalQueue,
)
from core.vault import read_note

logger = logging.getLogger(__name__)

__all__ = ["relink_threads", "rescan_hubs", "outputs_referencing", "revoked_journal_path"]


def revoked_journal_path() -> Path:
    """``link_revoked.jsonl`` рядом с журналом применённых связей (отдельный файл:
    читатели ``link_applied.jsonl`` берут любую запись с source/target за применённую)."""
    return link_applied_path().with_name("link_revoked.jsonl")


def relink_threads(
    vault_path: Path,
    affected: list[dict[str, str]],
    *,
    dry_run: bool = True,
    queue_path: Path | None = None,
    journal_path: Path | None = None,
    revoked_path: Path | None = None,
) -> dict[str, Any]:
    """Пере-линковка затронутых тредов с отзывом неверных связей (см. модульный докстринг).

    ``affected`` — ``[{thread, note_path, note_id}]`` из отчёта ремонта. Вызывать ПОСЛЕ
    ``apply`` ремонта: считается по чистым метаданным уже переписанных заметок.
    """
    vault_path = Path(vault_path)
    qpath = Path(queue_path) if queue_path is not None else link_proposals_path()
    queue = LinkProposalQueue.load(qpath)
    notes = {}
    for a in affected:
        rel = a.get("note_path") or ""
        if rel and (vault_path / rel).is_file():
            note = read_note(vault_path / rel)
            notes[note.id] = note
    ids = set(notes)

    catalog = _entity_catalog(vault_path)
    eligible = _eligible_hub_targets(vault_path)
    fresh: dict[str, set[str]] = {}
    for nid, note in notes.items():
        have = existing_link_targets(note)
        fresh[nid] = {
            dl.target for dl in resolve_note(note, catalog)
            if dl.target != nid and eligible.get(dl.target, False) and dl.target not in have
        }

    out: dict[str, Any] = {
        "dry_run": dry_run, "notes": len(notes), "revoked": [], "kept_reapplied": 0,
        "newly_proposed": 0, "applied": 0, "semantic_revoked": [],
    }
    revoked_rows: list[dict[str, str]] = []
    for p in list(queue.by_id.values()):
        if p.source_note not in ids or p.status not in (
            STATUS_APPLIED, STATUS_APPROVED, STATUS_PENDING
        ):
            continue
        valid = p.resolver == RESOLVER_DETERMINISTIC and p.target_note in fresh[p.source_note]
        if valid:
            if p.status == STATUS_APPLIED:
                p.status = STATUS_APPROVED  # заметка переписана: связь надо вернуть
                out["kept_reapplied"] += 1
            continue
        row = {
            "source": p.source_note, "target": p.target_note,
            "resolver": p.resolver, "was": p.status, "reason": "mail_repair",
        }
        p.status = STATUS_REVOKED
        revoked_rows.append(row)
        (out["semantic_revoked"] if p.resolver != RESOLVER_DETERMINISTIC
         else out["revoked"]).append(row)

    proposed = propose_deterministic(
        list(notes.values()), vault_path=vault_path, queue=queue, catalog=catalog
    )
    for prop in proposed.proposals:
        if prop.source_note in ids and prop.resolver == RESOLVER_DETERMINISTIC:
            prop.status = STATUS_APPROVED
    out["newly_proposed"] = proposed.added + proposed.upgraded

    # Применяем ТОЛЬКО строки затронутых источников (остальная очередь не трогается).
    sub = LinkProposalQueue(
        by_id={
            i: p for i, p in queue.by_id.items()
            if p.source_note in ids and p.status == STATUS_APPROVED
        },
        path=Path(tempfile.gettempdir()) / "dt_relink_sub.jsonl",
    )
    result = apply_approved(sub, vault_path, dry_run=dry_run, journal_path=journal_path)
    out["applied"] = result.applied
    out["already_present"] = result.already_present

    if not dry_run:
        queue.save(qpath)
        _write_revoked(revoked_rows, revoked_path)
        Path(tempfile.gettempdir(), "dt_relink_sub.jsonl").unlink(missing_ok=True)
    return out


def _write_revoked(rows: list[dict[str, str]], path: Path | None) -> None:
    if not rows:
        return
    target = Path(path) if path is not None else revoked_journal_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("a", encoding="utf-8") as fh:
        for r in rows:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")


def rescan_hubs(
    vault_path: Path,
    affected_paths: set[str],
    *,
    dry_run: bool = True,
    queue_path: Path | None = None,
    deals: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Перезапуск ``hub_scan`` + отчёт по ``applied``-кандидатам от затронутых тредов.

    Кандидаты считались по грязным ``counterparties``. Скан обновляет/снимает
    ``pending`` (сверка очереди — штатная). ``applied`` не трогается никогда: хаб,
    рождённый ТОЛЬКО затронутыми тредами (все ``sources`` ⊂ затронутые), и хаб, у
    которого затронутые треды лишь часть источников, перечисляются в отчёте для К.
    """
    from core.config import hub_candidates_path
    from core.linking.hub_candidates import (
        STATUS_APPLIED as HUB_APPLIED,
    )
    from core.linking.hub_candidates import (
        HubCandidateQueue,
        scan_hub_candidates,
    )

    qpath = Path(queue_path) if queue_path is not None else hub_candidates_path()
    queue = HubCandidateQueue.load(qpath)
    applied_only: list[dict[str, Any]] = []
    applied_partly: list[dict[str, Any]] = []
    for cand in queue.by_id.values():
        if cand.status != HUB_APPLIED or not cand.sources:
            continue
        hit = [s for s in cand.sources if s in affected_paths]
        if not hit:
            continue
        row = {
            "candidate": cand.name, "hub_id": cand.hub_id,
            "sources_total": len(cand.sources), "sources_affected": len(hit),
        }
        (applied_only if len(hit) == len(cand.sources) else applied_partly).append(row)
    out: dict[str, Any] = {
        "dry_run": dry_run,
        "applied_hubs_only_from_affected": applied_only,
        "applied_hubs_partly_from_affected": applied_partly,
    }
    if dry_run:
        return out
    result = scan_hub_candidates(Path(vault_path), queue=queue, deals=deals or [])
    out["scan"] = {
        "added": result.added, "updated": result.updated,
        "reconciled": result.reconciled, "revived": result.revived,
        "pruned": result.pruned,
    }
    return out


def outputs_referencing(vault_path: Path, affected: list[dict[str, str]]) -> list[dict[str, Any]]:
    """Выходы (``07-outputs``), чьи ``sources.md`` ссылаются на затронутые треды.

    Совпадение — по ключу треда (``correspondence/conv:<id>``), id заметки
    (``legacy-<hash>``) или имени файла заметки. Возвращает по выходу: папка и что
    именно совпало — список для ревизии К.
    """
    root = Path(vault_path) / "07-outputs"
    if not root.is_dir():
        return []
    needles: dict[str, str] = {}
    for a in affected:
        thread = a.get("thread", "")
        needles[f"correspondence/{thread}"] = thread
        if a.get("note_id"):
            needles[a["note_id"]] = thread
        if a.get("note_path"):
            needles[Path(a["note_path"]).name] = thread
    found: list[dict[str, Any]] = []
    for sources in sorted(root.rglob("sources.md")):
        try:
            text = sources.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        hits = sorted({thread for needle, thread in needles.items() if needle and needle in text})
        if hits:
            found.append({"output": str(sources.parent.relative_to(vault_path)), "threads": hits})
    return found
