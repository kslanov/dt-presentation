"""Legacy-doc normalization (ТЗ phase5, layer B, stage 3).

Turns an extracted :class:`~core.legacy.extract.LegacyDoc` into the normalized
markdown *body* that a layer-B note will carry: a provenance preamble
("Источник: …") followed by one ``##`` section per extraction unit (slide /
page / sheet / email / docx-section / block). The ``##`` headings are exactly
what the existing :func:`core.chunking._parse_sections` keys on, so the note
chunks per-unit natively — no separate chunker.

This module only builds the normalized structure/text; writing the actual
markdown note files is stage 4. Deterministic, no LLM.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from core.legacy.extract import LegacyDoc, LegacyUnit

__all__ = ["NormalizedDoc", "normalize", "build_preamble"]

# Collapse 3+ consecutive newlines down to a single blank line.
_BLANKS_RE = re.compile(r"\n{3,}")


@dataclass
class NormalizedDoc:
    """Normalized output for one source file.

    ``preamble`` is the provenance line; ``body`` is the full markdown body
    (preamble + ``##`` unit sections) ready to become a note body and to be
    content-hashed for dedup.
    """

    preamble: str
    body: str


def _collapse(text: str) -> str:
    """Trim trailing whitespace per line and squeeze blank runs."""
    text = "\n".join(line.rstrip() for line in text.splitlines())
    return _BLANKS_RE.sub("\n\n", text).strip()


def build_preamble(*, section: str, client: str, filename: str, era: str) -> str:
    """``"Источник: <section>/<client>/<filename> (<era>)"`` — empties dropped."""
    location = "/".join(part for part in (section, client, filename) if part)
    line = f"Источник: {location}" if location else "Источник:"
    if era:
        line += f" ({era})"
    return line


# PERSONAL-3: вид блока по его заголовку - рядом с ``_unit_heading``, который эти заголовки пишет
# (одно место: сменится формат заголовка - сменится и классификатор). ``block`` - безымянный блок
# («Содержимое»).
_UNIT_HEADING_RES: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("slide", re.compile(r"^Слайд \d+$")),
    ("page", re.compile(r"^(?:Стр\.|Страница) \d+$")),
    ("sheet", re.compile(r"^Лист «.*»$")),
    ("block", re.compile(r"^Содержимое$")),
)


def unit_kind_of_heading(heading: str) -> str:
    """``slide|page|sheet|block`` для заголовка единицы документа (или последнего сегмента
    ``heading_path`` через `` > ``), иначе ``""`` - обычный раздел заметки."""
    last = str(heading or "").split(" > ")[-1].lstrip("#").strip()
    for kind, pattern in _UNIT_HEADING_RES:
        if pattern.match(last):
            return kind
    return ""


def _unit_heading(unit: LegacyUnit) -> str:
    """The ``##`` heading carrying this unit's provenance into chunking."""
    if unit.kind == "slide":
        return f"## Слайд {unit.no}"
    if unit.kind == "page":
        return f"## Стр. {unit.no}"
    if unit.kind == "sheet":
        return f"## Лист «{unit.title}»"
    if unit.kind == "email":
        return "## Email"
    if unit.kind == "section":
        return f"## {unit.title}" if unit.title else "## Раздел"
    return "## Содержимое"  # block


def normalize(
    doc: LegacyDoc,
    *,
    section: str = "",
    client: str = "",
    filename: str = "",
    era: str = "",
) -> NormalizedDoc:
    """Build the normalized markdown body for ``doc`` with a provenance preamble.

    Units with empty text are dropped. The preamble sits before the first ``##``
    so it lands in its own (path-less) leading chunk; each unit becomes a ``##``
    section so chunking yields per-unit provenance.
    """
    preamble = build_preamble(
        section=section, client=client, filename=filename, era=era
    )
    parts: list[str] = [preamble]
    for unit in doc.units:
        text = unit.text.strip()
        if not text:
            continue
        parts.append(_unit_heading(unit))
        parts.append(text)
    body = _collapse("\n\n".join(parts))
    return NormalizedDoc(preamble=preamble, body=body)
