"""SRC-PATH-1 - источник заметки переезжает вместе с папкой.

Дефект (29.10): ``ingest_corpus`` при переезде файла (relocation по byte-hash) переставлял
запись МАНИФЕСТА на новый ``source_path`` и оставлял заметку «как есть» - frontmatter
``source_path``/``source_id`` оставались старыми, и ссылка заметки переставала резолвиться
(``lift_source``, ``find_latest``, ``get_facts``). Здесь:

* :func:`repoint_note` - хирургически переписать ``source_path`` (и ``source_id``, если он равен
  старому ``source_path``) заметки; тело и прочий frontmatter - байт-в-байт,
  ``source_content_hash`` не трогаем - он и есть тождество. Единый писатель полей -
  :func:`core.vault.set_frontmatter_fields_text`.
* :func:`manifest_keys_by_note` - обратная карта манифестов ``note_path → ключи`` (кэш по mtime) -
  для бэкфилла и последнего рубежа резолвера.
* :func:`repoint_sources` - бэкфилл ``dt_ingest --repoint-sources`` (dry-run по умолчанию).
* :func:`unresolved_file_notes` - чек доктора: файловые заметки, чей ``source_path`` не
  разрешается.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.vault import (
    FrontmatterError,
    RawYaml,
    read_frontmatter_fields_text,
    set_frontmatter_fields_text,
)

logger = logging.getLogger(__name__)

__all__ = [
    "RepointReport",
    "is_file_source",
    "manifest_keys_by_note",
    "repoint_note",
    "repoint_sources",
    "unresolved_file_notes",
]

CORPORA = ("current", "legacy")


def is_file_source(source_path: str) -> bool:
    """``source_path`` - файл, а не виртуальный источник почты (``correspondence/``, ``conv:``)."""
    sp = (source_path or "").strip()
    virtual = sp.startswith("correspondence/") or "conv:" in sp or "msg:" in sp
    return bool(sp) and not virtual


def _manifest_path(corpus: str) -> Path:
    from core.config import current_ingest_manifest_path, legacy_ingest_manifest_path

    return current_ingest_manifest_path() if corpus == "current" else legacy_ingest_manifest_path()


# --------------------------------------------------------------------------- #
# Запись в заметку                                                            #
# --------------------------------------------------------------------------- #


def repoint_note(
    vault_path: Path,
    note_rel: str,
    new_source_path: str,
    *,
    old_source_path: str | None = None,
    dry_run: bool = False,
) -> str:
    """Переписать ``source_path`` заметки на ``new_source_path``.

    ``source_id`` меняется, только если он равен прежнему ``source_path`` (из заметки или
    ``old_source_path``). Возвращает исход: ``rewritten`` / ``unchanged`` / ``no_note`` /
    ``no_frontmatter``. ``dry_run`` - ничего не пишет, но исход считает тот же. После записи -
    ``fm_cache.forget`` на заметку (следующий скан перечитает именно ее).
    """
    path = Path(vault_path) / note_rel
    if not path.is_file():
        return "no_note"
    with path.open(encoding="utf-8", newline="") as fh:
        text = fh.read()
    try:
        cur = read_frontmatter_fields_text(text, ("source_path", "source_id"))
        fields: dict[str, str | RawYaml] = {"source_path": new_source_path}
        if cur["source_id"] and cur["source_id"] in (cur["source_path"], old_source_path):
            fields["source_id"] = new_source_path
        new_text, _prev, changed = set_frontmatter_fields_text(text, fields)
    except FrontmatterError:
        return "no_frontmatter"
    if not changed:
        return "unchanged"
    if not dry_run:
        with path.open("w", encoding="utf-8", newline="") as fh:
            fh.write(new_text)
        from core.retrieval import fm_cache

        fm_cache.forget(Path(vault_path), [note_rel])
    return "rewritten"


# --------------------------------------------------------------------------- #
# Обратная карта манифестов                                                   #
# --------------------------------------------------------------------------- #

_KEYS_CACHE: dict[str, Any] = {"fingerprint": None, "map": None}


def _fingerprint(paths: list[Path]) -> tuple[tuple[str, float, int], ...]:
    out: list[tuple[str, float, int]] = []
    for p in paths:
        try:
            st = p.stat()
            out.append((str(p), st.st_mtime, st.st_size))
        except OSError:
            out.append((str(p), 0.0, -1))
    return tuple(out)


def manifest_keys_by_note(corpora: tuple[str, ...] = CORPORA) -> dict[str, list[str]]:
    """``note_path`` (vault-относительный) → ключи манифестов (``source_path``), по порядку слоев.

    Кэш на процесс, инвалидируется по ``mtime``/размеру файлов манифестов: резолвер зовется на
    каждый хит, а манифест - десятки мегабайт. Нет/битый манифест - карта беднее (не ошибка).
    """
    paths = [_manifest_path(c) for c in corpora]
    fp = _fingerprint(paths)
    if _KEYS_CACHE["fingerprint"] == fp and _KEYS_CACHE["map"] is not None:
        return _KEYS_CACHE["map"]  # type: ignore[no-any-return]
    out: dict[str, list[str]] = {}
    for p in paths:
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if not isinstance(data, dict):
            continue
        for key, rec in data.items():
            note = rec.get("note_path") if isinstance(rec, dict) else None
            if isinstance(note, str) and note:
                out.setdefault(note, []).append(str(key))
    _KEYS_CACHE["fingerprint"] = fp
    _KEYS_CACHE["map"] = out
    return out


def _vault_rel(note_path: str | Path, vault: Path) -> str:
    p = Path(str(note_path))
    if p.is_absolute():
        try:
            return p.resolve().relative_to(vault.resolve()).as_posix()
        except ValueError:
            return p.as_posix()
    return p.as_posix()


def resolve_via_manifest(
    note_path: str | Path, vault: Path, resolve_key: Any
) -> Path | None:
    """Последний рубеж резолвера: ключ манифеста по ``note_path`` заметки → живой файл.

    ``resolve_key`` - прежняя цепочка резолва (без этого рубежа), чтобы порядок не менялся.
    """
    for key in manifest_keys_by_note().get(_vault_rel(note_path, vault), ()):
        found = resolve_key(key)
        if found is not None:
            return found  # type: ignore[no-any-return]
    return None


# --------------------------------------------------------------------------- #
# Бэкфилл                                                                     #
# --------------------------------------------------------------------------- #


@dataclass
class RepointReport:
    """Итог ``--repoint-sources``: по слоям - сколько и примеры (пути относительные)."""

    apply: bool = False
    corpora: dict[str, dict[str, Any]] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {"apply": self.apply, "corpora": self.corpora}


def _snapshot_metas(vault: Path) -> list[Any]:
    """Срезы заметок из снимка ``frontmatter.json`` без обхода диска (и без записи кэша)."""
    from core.retrieval import fm_cache

    return fm_cache.peek_metas(vault)


def file_note_metas(vault: Path, corpus: str) -> list[Any]:
    """Заметки слоя ``corpus`` (current|legacy), чей ``source_path`` - файл (не почта)."""
    return [
        m for m in _snapshot_metas(vault)
        if m.corpus == corpus and m.note_type == "legacy-source" and is_file_source(m.source_path)
    ]


def _live_source_path(vault: Path, note_rel: str) -> str:
    """``source_path`` из самой заметки на диске (не из снимка); нет заметки/блока - ``""``."""
    path = vault / note_rel
    try:
        with path.open(encoding="utf-8", newline="") as fh:
            return read_frontmatter_fields_text(fh.read(), ("source_path",))["source_path"]
    except (OSError, FrontmatterError):
        return ""


def _resolves(raw: str, vault: Path) -> bool:
    from core.sources.resolver import resolve_source_path

    return resolve_source_path(raw, vault_path=vault) is not None


def repoint_sources(
    vault_path: Path,
    *,
    corpus: str = "both",
    apply: bool = False,
    limit: int | None = None,
    examples: int = 5,
) -> RepointReport:
    """Бэкфилл: заметки, чей ``source_path`` не разрешается, а ключ манифеста по ``note_path`` -
    да → переписать как при relocation. Исходы по слою: ``rewritten`` (переписано/будет),
    ``no_entry`` (в манифесте записи нет - файл исчез), ``dead_key`` (ключ тоже мертв),
    ``resolvable`` (заметка здорова). ``limit`` - канарейка (сколько ПЕРЕПИСАТЬ). Dry-run -
    ничего не пишет. Повтор после apply - 0 переписанных.
    """
    from core.sources.resolver import pinned_ingest_roots

    vault = Path(vault_path)
    layers = CORPORA if corpus == "both" else (corpus,)
    report = RepointReport(apply=apply)
    budget = limit
    with pinned_ingest_roots(vault):
        _repoint_layers(vault, layers, report, apply=apply, budget=budget, examples=examples)
    return report


def _repoint_layers(
    vault: Path,
    layers: tuple[str, ...],
    report: RepointReport,
    *,
    apply: bool,
    budget: int | None,
    examples: int,
) -> None:
    for layer in layers:
        by_note: dict[str, list[str]] = {}
        manifest = _load_manifest_json(_manifest_path(layer))
        for key, rec in manifest.items():
            note = rec.get("note_path") if isinstance(rec, dict) else None
            if isinstance(note, str) and note:
                by_note.setdefault(note, []).append(key)
        counts = {"notes": 0, "resolvable": 0, "rewritten": 0, "already": 0, "no_entry": 0,
                  "dead_key": 0, "skipped_limit": 0, "errors": 0}
        samples: dict[str, list[dict[str, str]]] = {"rewritten": [], "no_entry": [], "dead_key": []}
        for meta in sorted(file_note_metas(vault, layer), key=lambda m: m.path):
            counts["notes"] += 1
            if _resolves(meta.source_path, vault):
                counts["resolvable"] += 1
                continue
            # Снимок frontmatter.json отстает от диска до следующего скана (forget чистит только
            # память процесса): заметка, переписанная прошлым прогоном, в снимке все еще со старым
            # путем. Перечитываем ее саму - уже живой путь считаем «already», не ошибкой.
            live_now = _live_source_path(vault, meta.path)
            if live_now and live_now != meta.source_path and _resolves(live_now, vault):
                counts["already"] += 1
                continue
            keys = by_note.get(meta.path, [])
            if not keys:
                counts["no_entry"] += 1
                _sample(samples["no_entry"], examples, {"was": meta.source_path})
                continue
            live = next((k for k in keys if _resolves(k, vault)), None)
            if live is None:
                counts["dead_key"] += 1
                _sample(samples["dead_key"], examples, {"was": meta.source_path, "key": keys[0]})
                continue
            if budget is not None and counts["rewritten"] >= budget:
                counts["skipped_limit"] += 1
                continue
            outcome = repoint_note(
                vault, meta.path, live, old_source_path=meta.source_path, dry_run=not apply
            )
            if outcome == "rewritten":
                counts["rewritten"] += 1
                _sample(samples["rewritten"], examples, {"was": meta.source_path, "now": live})
            else:
                counts["errors"] += 1
                logger.warning("[repoint] %s: %s", meta.path, outcome)
        report.corpora[layer] = {**counts, "examples": samples}


def _sample(bucket: list[dict[str, str]], limit: int, item: dict[str, str]) -> None:
    if len(bucket) < limit:
        bucket.append(item)


def _load_manifest_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


# --------------------------------------------------------------------------- #
# Доктор                                                                      #
# --------------------------------------------------------------------------- #


def unresolved_file_notes(
    vault_path: Path, *, budget_s: float = 5.0
) -> dict[str, Any]:
    """Счетчики не разрешающихся ``source_path`` файловых заметок (по снимку ``frontmatter.json``).

    ``{total, checked, partial, unresolved, recoverable, no_entry, dead_key, folders}``:
    ``recoverable`` - ключ манифеста по ``note_path`` разрешается (чинит ``--repoint-sources``);
    ``no_entry``/``dead_key`` - файл исчез совсем (info: выполнимого действия нет); ``folders`` -
    папки ``recoverable`` по числу. Бюджет ``budget_s`` - при превышении идем по выборке
    (``partial``).
    """
    import time

    from core.sources.resolver import pinned_ingest_roots

    start = time.perf_counter()
    vault = Path(vault_path)
    metas = [m for layer in CORPORA for m in file_note_metas(vault, layer)]
    keyed = manifest_keys_by_note()
    checked = unresolved = no_entry = dead_key = 0
    folders: dict[str, int] = {}
    with pinned_ingest_roots(vault):
        for meta in sorted(metas, key=lambda m: m.path):
            if time.perf_counter() - start > budget_s:
                break
            checked += 1
            if _resolves(meta.source_path, vault):
                continue
            unresolved += 1
            keys = keyed.get(meta.path, [])
            if not keys:
                no_entry += 1
            elif any(_resolves(k, vault) for k in keys):
                folder = os.path.dirname(meta.source_path) or "."
                folders[folder] = folders.get(folder, 0) + 1
            else:
                dead_key += 1
    return {
        "total": len(metas),
        "checked": checked,
        "partial": checked < len(metas),
        "unresolved": unresolved,
        "recoverable": sum(folders.values()),
        "no_entry": no_entry,
        "dead_key": dead_key,
        "folders": sorted(folders.items(), key=lambda kv: (-kv[1], kv[0])),
    }
