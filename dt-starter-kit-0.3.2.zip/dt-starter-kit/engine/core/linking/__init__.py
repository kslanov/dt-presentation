"""Linking subpackage — the note-agnostic linking engine (Phase 6 + Phase 9).

Two resolver layers over the same vault graph:

* **deterministic** (Phase 9) — exact catalog matches (ids / aliases /
  counterparty domains) via :mod:`core.linking.signals` +
  :mod:`core.linking.deterministic`; high confidence, no index required.
* **semantic** (Phase 6) — embedding-similarity link *candidates* (reusing
  BGE-M3 / LanceDB), aggregated at the note level, for the human-in-the-loop
  review queue.

No links are written from candidate generation — proposals only.
"""

from core.linking.apply import ApplyLinksResult, apply_approved
from core.linking.candidates import (
    DEFAULT_MIN_SCORE,
    DEFAULT_TOPN,
    LinkCandidate,
    candidates_for_note,
    existing_link_targets,
)
from core.linking.deterministic import (
    MIN_TEXT_TOKEN,
    TEXT_ENTITIES,
    DeterministicLink,
    deterministic_links,
    resolve_note,
)
from core.linking.engine import (
    ALWAYS_EXCLUDED_DIRS,
    DETERMINISTIC_SCORE,
    RESOLVER_DETERMINISTIC,
    RESOLVER_SEMANTIC,
    TARGET_DIRS,
    DeterministicProposeResult,
    approve_pending,
    is_link_target,
    propose_deterministic,
    scan_deterministic,
    select_scope,
)
from core.linking.propose import (
    LinkProposal,
    LinkProposalQueue,
    ProposeResult,
    assemble_link_prompt,
    is_linkable_source,
    iter_isolates,
    propose_for_notes,
    select_sources,
)
from core.linking.signals import NoteSignals, signals_for_note

__all__ = [
    "LinkCandidate",
    "candidates_for_note",
    "existing_link_targets",
    "DEFAULT_MIN_SCORE",
    "DEFAULT_TOPN",
    "NoteSignals",
    "signals_for_note",
    "DeterministicLink",
    "deterministic_links",
    "resolve_note",
    "MIN_TEXT_TOKEN",
    "TEXT_ENTITIES",
    "RESOLVER_DETERMINISTIC",
    "RESOLVER_SEMANTIC",
    "ALWAYS_EXCLUDED_DIRS",
    "TARGET_DIRS",
    "DETERMINISTIC_SCORE",
    "DeterministicProposeResult",
    "is_link_target",
    "select_scope",
    "propose_deterministic",
    "scan_deterministic",
    "approve_pending",
    "LinkProposal",
    "LinkProposalQueue",
    "ProposeResult",
    "propose_for_notes",
    "iter_isolates",
    "is_linkable_source",
    "select_sources",
    "assemble_link_prompt",
    "ApplyLinksResult",
    "apply_approved",
]
