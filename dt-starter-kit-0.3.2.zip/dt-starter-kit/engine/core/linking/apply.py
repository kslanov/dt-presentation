"""Phase 6, stage 3 — apply approved semantic links into the source notes.

Takes the **approved** rows from the review queue
(:class:`~core.linking.propose.LinkProposalQueue`) and writes each ``[[target]]``
into the source note's ``## Связано`` section — creating the section if absent.
Strictly additive and idempotent: prose is never touched, an already-present link
is never duplicated, and a re-run with no new approvals is a no-op. Every applied
link is recorded in a journal (``.derived/link_applied.jsonl``).

Mirrors the conservative, append-only style of
:func:`core.legacy.linking._append_backlink` (Phase 5), but driven by the queue:
nothing is written for a ``pending`` / ``rejected`` proposal.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from core.config import link_applied_path
from core.linking.propose import (
    STATUS_APPLIED,
    STATUS_APPROVED,
    LinkProposal,
    LinkProposalQueue,
)
from core.linking.quiet import recently_modified
from core.metrics import record_event
from core.vault import iter_vault

__all__ = ["RELATED_HEADING", "ApplyLinksResult", "apply_approved"]

# The section approved semantic links are written under. Distinct from Phase 5's
# ``## Связано (легаси)`` curated back-link section — this is the source note's
# outgoing "related" list, created on first use.
RELATED_HEADING = "## Связано"


@dataclass
class ApplyLinksResult:
    """Summary of an :func:`apply_approved` run (counts + touched notes + journal)."""

    approved: int = 0  # approved proposals seen
    applied: int = 0  # links newly written into a note
    already_present: int = 0  # approved, but the link was already there (idempotent)
    missing_source: int = 0  # source note id not found in the vault
    deferred_recent: int = 0  # note changed < DT_LINK_QUIET_S ago — stays approved (п.4)
    touched_notes: list[str] = field(default_factory=list)  # source ids changed
    journal: list[dict] = field(default_factory=list)  # {source, target, score, rationale}


def _related_line(proposal: LinkProposal, *, include_rationale: bool) -> str:
    """``- [[target]]`` with an optional ``— rationale`` tail (single line)."""
    line = f"- [[{proposal.target_note}]]"
    if include_rationale and proposal.rationale:
        tail = proposal.rationale.strip().replace("\n", " ")
        line = f"{line} — {tail}"
    return line


def _insert_related(text: str, line: str, target: str) -> str | None:
    """Append ``line`` under :data:`RELATED_HEADING`; return new text or ``None``.

    ``None`` means the link (``[[target]]``) is already present — no change. Never
    edits existing prose: the line is inserted right after the heading (skipping a
    single blank line) when the section exists, else a fresh section is appended.
    """
    if f"[[{target}]]" in text:
        return None  # idempotent — already linked
    lines = text.split("\n")
    if RELATED_HEADING in lines:
        at = lines.index(RELATED_HEADING) + 1
        if at < len(lines) and lines[at].strip() == "":
            at += 1
        lines.insert(at, line)
        return "\n".join(lines)
    return text.rstrip() + f"\n\n{RELATED_HEADING}\n\n{line}\n"


def _source_paths(vault_path: Path, needed: set[str]) -> dict[str, Path]:
    """Map ``note_id → path`` for the source ids we need to edit (one vault walk)."""
    found: dict[str, Path] = {}
    if not needed:
        return found
    for note in iter_vault(vault_path):
        if note.id in needed:
            found[note.id] = note.path
            if len(found) == len(needed):
                break
    return found


def apply_approved(
    queue: LinkProposalQueue,
    vault_path: Path,
    *,
    dry_run: bool = True,
    include_rationale: bool = True,
    journal_path: Path | None = None,
) -> ApplyLinksResult:
    """Apply every ``approved`` proposal in ``queue`` into its source note.

    For each approved proposal the ``[[target]]`` is written under the source's
    ``## Связано`` section (created if absent), idempotently (an already-present
    link is left as-is and the proposal is still marked ``applied`` — the desired
    end state holds). The queue is saved with the new ``applied`` statuses and the
    journal is appended, unless ``dry_run`` (default) — then nothing is written and
    the result reports what *would* happen. Returns counts + touched note ids.
    """
    result = ApplyLinksResult()
    approved = [p for p in queue.by_id.values() if p.status == STATUS_APPROVED]
    result.approved = len(approved)
    if not approved:
        return result

    paths = _source_paths(vault_path, {p.source_note for p in approved})
    changed_files: dict[Path, str] = {}  # buffered writes (group by source note)
    applied_by_resolver: dict[str, int] = {}  # KPI-1: counts only, per resolver

    for proposal in approved:
        path = paths.get(proposal.source_note)
        if path is None:
            result.missing_source += 1
            continue
        # WAVE0-HYGIENE п.4: заметку только что писал параллельный fast-шаг (mail_ingest) —
        # не читаем-переписываем её (гонка read→write). Предложение остаётся approved.
        if path not in changed_files and recently_modified(path):
            result.deferred_recent += 1
            continue
        text = changed_files.get(path)
        if text is None:
            text = path.read_text(encoding="utf-8")
        new_text = _insert_related(
            text, _related_line(proposal, include_rationale=include_rationale),
            proposal.target_note,
        )
        if new_text is None:
            result.already_present += 1
        else:
            changed_files[path] = new_text
            result.applied += 1
            resolver = proposal.resolver or "semantic"
            applied_by_resolver[resolver] = applied_by_resolver.get(resolver, 0) + 1
            result.touched_notes.append(proposal.source_note)
            result.journal.append(
                {
                    "source": proposal.source_note,
                    "target": proposal.target_note,
                    "score": proposal.score,
                    "rationale": proposal.rationale,
                }
            )
        # Idempotent end state: approved + (now) present ⇒ applied.
        proposal.status = STATUS_APPLIED

    if dry_run:
        return result

    for path, new_text in changed_files.items():
        path.write_text(new_text, encoding="utf-8")
    queue.save()
    _append_journal(result.journal, journal_path)
    # KPI-1: только счётчики per resolver — без имён заметок/целей.
    for resolver, count in sorted(applied_by_resolver.items()):
        record_event("links_applied", count=count, resolver=resolver)
    # PULT-EVENTLOG: одно link-событие на заметку-источник (по note_id), пачкой
    # с общим run_id (bulk-apply → один прогон, не N транзакций). detail —
    # только счётчик ссылок этой заметки, без целей/текста.
    _emit_link_events(result.touched_notes)
    return result


def _emit_link_events(touched_notes: list[str]) -> None:
    """PULT-EVENTLOG for applied links — per source note_id, one batched run."""
    if not touched_notes:
        return
    from core.eventlog import emit_batch, new_run_id

    per_note: dict[str, int] = {}
    for nid in touched_notes:
        per_note[nid] = per_note.get(nid, 0) + 1
    run_id = new_run_id()
    emit_batch(
        [
            {
                "stage": "link", "status": "done", "note_id": nid,
                "run_id": run_id, "detail": {"links": n},
            }
            for nid, n in per_note.items()
        ]
    )


def _append_journal(entries: list[dict], journal_path: Path | None) -> None:
    """Append applied-link records to the journal (JSONL), one per line."""
    if not entries:
        return
    path = Path(journal_path) if journal_path is not None else link_applied_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        for entry in entries:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
