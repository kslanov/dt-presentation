"""Phase 6, stage 1 — semantic link candidate generation.

For a *source* note, find the nearest *other* notes by embedding similarity and
return them as :class:`LinkCandidate` suggestions. This is the deterministic,
LLM-free first stage of AI-semantic linking (Phase 6): it reuses the BGE-M3
vectors already in the LanceDB ``chunks`` table (built in Phase 5) and LanceDB's
cosine search — no external LLM call per pair, no writes to any note.

Design (ТЗ phase6 §Архитектура):

* **Note-level, not chunk-level.** The source note's chunk vectors are searched
  against the index; the resulting chunk hits are grouped by *target* note id and
  each target keeps its **maximum** chunk similarity. A note linked because one of
  its sections is on-topic shouldn't out-rank a note that is broadly on-topic just
  because it was split into more chunks — max is the note's best evidence.
* **Cosine threshold + top-N.** Similarity is cosine (``1 - cosine_distance``),
  directly comparable to an absolute threshold (``DT_LINK_MIN_SCORE``); the top
  ``DT_LINK_TOPN`` survivors per source are returned.
* **Exclusions.** The source note itself (self), any chunk of the *same source
  file* (same ``source_path``), and notes the source already links to
  (deterministic Phase-5 ``[[…]]`` in body/frontmatter) are dropped — we only ever
  *enrich* the graph, never re-propose what's already there.
* **Target filter / priority.** The semantic skeleton is the curated layer, so by
  default only curated notes (``curated = true`` — hubs *and* curated vault notes)
  are eligible *targets*; legacy notes participate only as *sources* (to pull
  isolates toward the skeleton). The filter is parametrized (``target_filter``);
  on a score tie, ``type: hub`` targets sort first (hub-then-curated priority).
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any

import lancedb

from core.config import lancedb_path
from core.retrieval.index import TABLE_NAME
from core.vault import Note

__all__ = [
    "LinkCandidate",
    "candidates_for_note",
    "existing_link_targets",
    "DEFAULT_MIN_SCORE",
    "DEFAULT_TOPN",
    "TARGET_FILTERS",
]

# Defaults are deliberately conservative: a high cosine floor keeps the review
# queue precise (better to miss a weak link than flood the human with noise), and
# a small top-N keeps each source's suggestions glanceable. Both overridable via
# env so the operator can widen recall during a curation sprint.
DEFAULT_MIN_SCORE = 0.55
DEFAULT_TOPN = 8

# Folders whose notes form the **semantic skeleton** (spine): durable knowledge
# (incl. industry/direction/product hubs + deep cases) and project hubs. Anything
# outside these (01-style samples, 06-templates, 07-outputs artifacts, _system
# config, _legacy raw corpus) is NOT a link target — those are inputs/outputs, not
# the graph we enrich. Matched against the indexed ``source_path`` (curated notes
# store their own path there).
SPINE_DIRS = ("02-knowledge", "03-projects")

# Client hubs live here. They are deliberately **excluded as semantic targets**
# (stage-2 review fix B): a note's client is resolved by the *deterministic* layer
# (Phase 5, exact catalog match); a *semantic* nearest-neighbour to someone else's
# client hub is noise (e.g. an HSBC proposal drifting to ``client-initech``). Own
# client is already linked deterministically; foreign clients must not be guessed.
_CLIENT_DIR = "04-clients"

# The spine ``where``: a hub that is NOT a client hub (industry/direction/product/
# project hubs), OR any note living in a spine folder (knowledge/cases/projects).
_SPINE_WHERE = " OR ".join(
    [f"(type = 'hub' AND source_path NOT LIKE '%/{_CLIENT_DIR}/%')"]
    + [f"source_path LIKE '%/{d}/%'" for d in SPINE_DIRS]
)

# Named target-eligibility filters → a LanceDB ``where`` predicate (or ``None`` for
# "no restriction"). ``spine`` (default) is the semantic skeleton — non-client hubs
# + 02-knowledge / 03-projects notes, excluding client hubs / style / templates /
# outputs / system / legacy (stage-2 review fixes). ``curated`` is the broader
# curated layer (hubs + any ``curated = true`` note, clients included); ``hub``
# narrows to entity hubs only; ``all`` admits everything (legacy included) for
# isolate sweeps. Legacy is never a target under ``spine`` — only a *source*.
TARGET_FILTERS: dict[str, str | None] = {
    "spine": _SPINE_WHERE,
    "curated": "curated = true",
    "hub": "type = 'hub'",
    "all": None,
}

# Note-id prefixes of high-value targets — deep cases and reusable solutions — that
# get the same ranking priority as hubs. They carry ``type: note`` (the type alone
# can't distinguish them), so they're recognised by id convention (``case-…`` /
# ``solution-…``).
HIGH_VALUE_PREFIXES = ("case-", "solution-")

# Ranking nudge added to a hub / case / solution target's cosine score for
# *ordering only* (the reported ``score`` stays the raw cosine). Small by design:
# it reorders near-ties so the skeleton's anchors lead, but a clearly-more-similar
# plain knowledge note still ranks above a barely-related hub. Override via
# ``DT_LINK_PRIORITY_BONUS``.
DEFAULT_PRIORITY_BONUS = 0.05

# Matches [[target]] / [[target|display]] in a note body or a frontmatter string.
_WIKILINK_RE = re.compile(r"\[\[([^\[\]|]+?)(?:\|[^\]]*)?\]\]")


@dataclass
class LinkCandidate:
    """A suggested semantic link from ``source_note`` to ``target_note``.

    ``score`` is the note-level cosine similarity (max over the source's chunk
    hits into the target). ``evidence_snippet`` is the target chunk text that
    produced that best score — the "why" shown to the reviewer. ``target_type`` is
    the target's frontmatter ``type`` (e.g. ``hub``), carried for stage-2 priority.
    """

    source_note: str
    target_note: str
    score: float
    evidence_snippet: str
    target_type: str = ""


def _env_float(name: str, default: float) -> float:
    raw = os.environ.get(name)
    if raw and raw.strip():
        try:
            return float(raw.strip())
        except ValueError:
            return default
    return default


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw and raw.strip().lstrip("-").isdigit():
        value = int(raw.strip())
        if value > 0:
            return value
    return default


def _sql_quote(value: str) -> str:
    """Quote a string for a LanceDB SQL filter (single-quote, doubling escapes)."""
    return "'" + value.replace("'", "''") + "'"


def priority_bonus(target_type: str, target_note: str, bonus: float) -> float:
    """Ranking nudge for high-value targets (hubs + ``case-``/``solution-`` notes).

    Returns ``bonus`` for a hub or a high-value-prefixed note id, else ``0``. Used
    only to order near-ties (see :data:`DEFAULT_PRIORITY_BONUS`) — never to clear
    the threshold.
    """
    if target_type == "hub" or target_note.startswith(HIGH_VALUE_PREFIXES):
        return bonus
    return 0.0


def existing_link_targets(note: Note) -> set[str]:
    """Ids the source note already links to (Phase-5 deterministic links).

    Union of ``[[…]]`` wikilink targets found in the note body and in its
    frontmatter ``links`` field (a single value or a list; bare ids or wikilink
    syntax both accepted). These are excluded from candidates so an already-linked
    hub is never re-proposed — keeping the queue to *new* connections only.
    """
    targets: set[str] = {m.group(1).strip() for m in _WIKILINK_RE.finditer(note.body)}

    raw_links = note.frontmatter.get("links")
    values = raw_links if isinstance(raw_links, list) else [raw_links]
    for value in values:
        if not isinstance(value, str):
            continue
        match = _WIKILINK_RE.search(value)
        targets.add(match.group(1).strip() if match else value.strip())

    targets.discard("")
    return targets


def aggregate_chunk_hits(
    *,
    source_note: str,
    source_path: str,
    hits: list[dict[str, Any]],
    existing: set[str],
    min_score: float,
    topn: int,
    bonus: float = DEFAULT_PRIORITY_BONUS,
) -> list[LinkCandidate]:
    """Group chunk hits by target note (max score), apply exclusions/threshold/top-N.

    Pure (no I/O) so the candidate logic is unit-testable without an index. Each
    hit is ``{note_id, source_path, score, text, type}`` where ``score`` is cosine
    similarity. Exclusions: self (same ``note_id``), same source file (same
    non-empty ``source_path``), and any ``existing`` link target. For each
    surviving target the best (max-score) chunk wins.

    Ranking adds a small :func:`priority_bonus` (hubs + ``case-``/``solution-``
    notes) to the cosine score for *ordering only* — the reported ``score`` stays
    raw — so the skeleton's anchors lead at near-ties; then truncates to ``topn``.
    The threshold is applied to the raw cosine, never the boosted value.
    """
    best: dict[str, LinkCandidate] = {}
    for hit in hits:
        target = str(hit.get("note_id") or "")
        if not target or target == source_note:
            continue  # self
        hit_path = str(hit.get("source_path") or "")
        if source_path and hit_path == source_path:
            continue  # a chunk of the same source file
        if target in existing:
            continue  # already linked (Phase 5)
        score = float(hit.get("score", 0.0))
        if score < min_score:
            continue
        current = best.get(target)
        if current is None or score > current.score:
            best[target] = LinkCandidate(
                source_note=source_note,
                target_note=target,
                score=score,
                evidence_snippet=str(hit.get("text") or ""),
                target_type=str(hit.get("type") or ""),
            )

    ranked = sorted(
        best.values(),
        key=lambda c: c.score + priority_bonus(c.target_type, c.target_note, bonus),
        reverse=True,
    )
    return ranked[:topn]


def _open_table(table: Any | None) -> Any:
    if table is not None:
        return table
    db = lancedb.connect(str(lancedb_path()))
    return db.open_table(TABLE_NAME)


def _source_rows(table: Any, source_note: str) -> list[dict[str, Any]]:
    """The source note's indexed chunk rows (vectors + source_path), or ``[]``."""
    return (
        table.search()
        .where(f"note_id = {_sql_quote(source_note)}")
        .limit(10_000)
        .to_list()
    )


def candidates_for_note(
    note: Note,
    *,
    min_score: float | None = None,
    topn: int | None = None,
    target_filter: str = "spine",
    pool_per_chunk: int = 20,
    exact: bool = True,
    table: Any | None = None,
) -> list[LinkCandidate]:
    """Semantic link candidates for ``note`` — nearest *other* notes by embedding.

    Reuses the source note's BGE-M3 chunk vectors already in the LanceDB index
    (Phase 5): each chunk vector is cosine-searched against the table (restricted
    to eligible targets via ``target_filter``), hits are aggregated to the note
    level (:func:`aggregate_chunk_hits`), and self / same-file / already-linked
    targets are dropped. Returns up to ``topn`` candidates above ``min_score``.

    ``min_score``/``topn`` default to ``DT_LINK_MIN_SCORE``/``DT_LINK_TOPN`` (env)
    then :data:`DEFAULT_MIN_SCORE`/:data:`DEFAULT_TOPN`. ``target_filter`` is one of
    :data:`TARGET_FILTERS` (default ``spine`` — the semantic skeleton; legacy /
    style / templates / outputs excluded as targets). ``exact`` bypasses the ANN
    index for brute-force cosine (accurate thresholds on a large index; the
    candidate-generation step is offline, not latency-bound). If the source note
    has no rows in the index, returns ``[]`` (reindex first).
    """
    if min_score is None:
        min_score = _env_float("DT_LINK_MIN_SCORE", DEFAULT_MIN_SCORE)
    if topn is None:
        topn = _env_int("DT_LINK_TOPN", DEFAULT_TOPN)
    bonus = _env_float("DT_LINK_PRIORITY_BONUS", DEFAULT_PRIORITY_BONUS)
    if target_filter not in TARGET_FILTERS:
        raise ValueError(
            f"unknown target_filter {target_filter!r}; "
            f"expected one of {sorted(TARGET_FILTERS)}"
        )
    where = TARGET_FILTERS[target_filter]

    table = _open_table(table)
    src_rows = _source_rows(table, note.id)
    if not src_rows:
        return []
    source_path = str(src_rows[0].get("source_path") or "")
    existing = existing_link_targets(note)

    hits: list[dict[str, Any]] = []
    for row in src_rows:
        vector = row.get("vector")
        if vector is None:
            continue
        query = table.search(list(vector)).metric("cosine")
        if exact:
            query = query.bypass_vector_index()
        if where:
            query = query.where(where, prefilter=True)
        for res in query.limit(pool_per_chunk).to_list():
            distance = res.get("_distance")
            if distance is None:
                continue
            hits.append(
                {
                    "note_id": res.get("note_id"),
                    "source_path": res.get("source_path"),
                    "score": 1.0 - float(distance),
                    "text": res.get("text"),
                    "type": res.get("type"),
                }
            )

    return aggregate_chunk_hits(
        source_note=note.id,
        source_path=source_path,
        hits=hits,
        existing=existing,
        min_score=min_score,
        topn=topn,
        bonus=bonus,
    )
