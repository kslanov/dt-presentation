"""Решение по одному link-предложению с пульта (ТЗ pult_link_decide).

Серая зона semantic-очереди (0.75–0.85) разбирается по одной карточке кнопками:

* **approve** — пометить ``approved`` и СРАЗУ применить **существующим**
  :func:`core.linking.apply.apply_approved` (та же идемпотентная вставка в
  «## Связано» + журнал, никакого второго пути записи в заметки);
* **reject** — статус ``rejected`` навсегда. Осознанно: по правилу этапа 2
  (``LinkProposalQueue.add`` не трогает существующий id) rejected-пара никогда
  не будет предложена снова — для явного человеческого «нет» это желаемое
  поведение, в отличие от прунинга (физическое удаление, пара может вернуться).

Исходы — applied / rejected / stale / failed с человекочитаемым пояснением;
неизвестный id — понятная :class:`ValueError`. Каждый вызов журналируется в
аудит пульта (``pult-actions.log`` — ts, tool, id, decision, исход; evidence-
текст туда не попадает) и, когда решение состоялось, в metrics отдельным kind
``link_decision`` (decision + resolver) — чтобы не смешивать ручные решения с
массовыми ``links_applied``-прогонами.

Инвариант: ``core/`` ⊥ mcp/cli — server.py лишь тонкая обёртка над
:func:`decide_link`.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.linking.apply import apply_approved
from core.linking.propose import (
    STATUS_APPLIED,
    STATUS_APPROVED,
    STATUS_PENDING,
    STATUS_REJECTED,
    LinkProposal,
    LinkProposalQueue,
)
from core.metrics import record_event
from core.operational.pult import record_action

__all__ = ["decide_link"]

_TOOL = "pult_link_decide"


def _brief(p: LinkProposal) -> dict[str, Any]:
    """Общие поля ответа — карточке хватает пары + score/resolver (без evidence)."""
    return {
        "proposal_id": p.id,
        "source": p.source_note,
        "target": p.target_note,
        "score": p.score,
        "resolver": p.resolver,
    }


def decide_link(
    *,
    proposal_id: str,
    decision: str,
    queue: LinkProposalQueue,
    vault_path: Path,
    journal_path: Path | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Решить судьбу одного link-предложения. См. док модуля.

    Решению подлежат строки в статусе ``pending`` (и ``approved`` — одобренная,
    но не применённая строка достижима повторной кнопкой). Уже ``applied`` /
    ``rejected`` → ``stale`` (пульт перерисует ленту). Approve зовёт
    :func:`apply_approved` на живой очереди: если в ней остались другие
    ``approved``-строки (одобрены человеком ранее, но не применены), они
    доводятся до своего конечного состояния тем же проходом — это семантика
    очереди, не побочный эффект. ``failed`` (заметка-источник исчезла) оставляет
    строку ``approved`` — следующий approve её дотянет.
    """
    if decision not in ("approve", "reject"):
        raise ValueError(
            f"unsupported decision {decision!r}; use 'approve' or 'reject'"
        )
    audit_params = {"proposal_id": proposal_id, "decision": decision}

    p = queue.by_id.get(proposal_id)
    if p is None:
        record_action(_TOOL, audit_params, "not_found", now=now)
        raise ValueError(
            f"Link-предложение …{proposal_id[-4:]} не найдено в очереди."
        )
    if p.status not in (STATUS_PENDING, STATUS_APPROVED):
        record_action(_TOOL, audit_params, "stale", now=now)
        settled = "применено" if p.status == STATUS_APPLIED else "отклонено"
        return {
            **_brief(p),
            "outcome": "stale",
            "explanation": f"Предложение уже {settled} ранее — решение не требуется.",
        }

    if decision == "reject":
        p.status = STATUS_REJECTED
        queue.save()
        record_event("link_decision", decision="rejected", resolver=p.resolver)
        record_action(_TOOL, audit_params, "rejected", now=now)
        return {
            **_brief(p),
            "outcome": "rejected",
            "explanation": (
                "Отклонено навсегда — эта пара больше никогда не будет "
                "предложена (правило этапа 2)."
            ),
        }

    # --- approve → тот же apply-путь, что apply_links -----------------------
    p.status = STATUS_APPROVED
    result = apply_approved(
        queue, vault_path, dry_run=False, journal_path=journal_path
    )
    if p.status != STATUS_APPLIED:
        # apply_approved не тронул статус ⇒ источник не найден в vault; строка
        # осталась approved в сохранённой очереди (retry следующим approve).
        record_action(_TOOL, audit_params, "failed", now=now)
        return {
            **_brief(p),
            "outcome": "failed",
            "explanation": (
                f"Ссылка не вставлена: заметка-источник «{p.source_note}» "
                "не найдена в vault (предложение осталось approved — можно "
                "повторить после починки заметки)."
            ),
        }

    newly_written = any(
        e.get("source") == p.source_note and e.get("target") == p.target_note
        for e in result.journal
    )
    record_event("link_decision", decision="approved", resolver=p.resolver)
    record_action(_TOOL, audit_params, "applied", now=now)
    return {
        **_brief(p),
        "outcome": "applied",
        "already_present": not newly_written,
        "explanation": (
            "Ссылка вставлена в «## Связано» заметки-источника."
            if newly_written
            else "Ссылка уже была в заметке — идемпотентно помечено applied."
        ),
    }
