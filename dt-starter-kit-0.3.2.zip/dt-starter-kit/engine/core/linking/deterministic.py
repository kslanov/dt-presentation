"""Phase 9, stage 1 — deterministic (catalog-based) link resolver.

Matches the entity-hub catalog (``core.ingest._entity_catalog``: ids + aliases
for clients / products / projects / directions) against a note's
:class:`~core.linking.signals.NoteSignals`. This is the exact, high-confidence
layer of the linking engine — no embeddings, no LLM.

Rules (ТЗ phase9 §Резолверы):

* **NFC normalization of both sides.** macOS file paths and pasted text arrive
  NFD-decomposed; catalog aliases are NFC. Every comparison funnels both sides
  through NFC first (matching would silently fail for Cyrillic otherwise).
* **Word boundaries.** Free-text matches require a standalone token —
  ``(?<!\\w)…(?!\\w)`` — so an alias never fires as a substring inside a longer
  word (``ЦД`` must not hit ``ЦДС``, ``Вонка`` must not hit ``ВОНКОВСКИЙ``).
* **Min length for free text.** Short/ambiguous tokens (< ``MIN_TEXT_TOKEN``
  chars, e.g. ``ЦД``) are matched in title/body only when they are an *explicit
  catalog alias* and appear as an exact, case-preserving standalone token —
  never via the hub id or case-folded, which would fire on unrelated prose.
  Structured frontmatter fields (client/section/product/tags/…) are exact whole
  -value comparisons, so the length guard does not apply there.
* **Existing hubs only.** The catalog is built from hub notes present on disk
  (``_entity_catalog`` walks the vault), so a link can never be invented — no
  hub note, no entry to match, no ``[[…]]``.
* **Mail:** ``counterparty_domains`` resolve to client hubs by the full domain
  or its second-level label (``mail.hooli.ru`` → ``hooli``) against id/aliases.

Invariant: ``core/`` depends on neither MCP nor CLI; no LLM calls here.
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable
from dataclasses import dataclass

from core.ingest import EntityRef
from core.legacy.render import slugify
from core.linking.signals import NoteSignals, signals_for_note
from core.vault import Note

__all__ = [
    "DeterministicLink",
    "MIN_TEXT_TOKEN",
    "TEXT_ENTITIES",
    "deterministic_links",
    "resolve_note",
]

# Free-text tokens shorter than this (after NFC) take the strict short-token
# path: explicit alias only, exact case, standalone. 4 keeps 2–3-char acronyms
# (ЦД, ЭК, ГП) out of the fuzzy case-insensitive scan while real names
# (Хули, Т-Акс, AIMS) match normally.
MIN_TEXT_TOKEN = 4

# Catalog entities the deterministic resolver links (ТЗ phase9 п.1). ``industry``
# hubs stay semantic-only — industry mentions in prose are too generic.
TEXT_ENTITIES: tuple[str, ...] = ("client", "product", "project", "direction")


@dataclass
class DeterministicLink:
    """One resolved link: an existing hub plus the signal that produced it.

    ``signal`` names the :class:`NoteSignals` field that matched (``client``,
    ``section``, ``product``, ``counterparty``, ``domain``, ``tag``, ``title``,
    ``body``); ``evidence`` is the matched value/token — the "why" for the
    journal and for review UIs. Deterministic matches are exact ⇒ high
    confidence by construction.
    """

    target: str
    entity: str
    signal: str
    evidence: str


def _nfc(text: str) -> str:
    return unicodedata.normalize("NFC", str(text))


def _fold(text: str) -> str:
    """NFC + casefold + strip — the canonical form for exact comparisons."""
    return _nfc(text).casefold().strip()


def _standalone(token: str, haystack: str) -> bool:
    """``token`` occurs in ``haystack`` as a whole word (never a substring)."""
    if not token:
        return False
    return (
        re.search(rf"(?<!\w){re.escape(token)}(?!\w)", haystack) is not None
    )


def _field_match(value: str, hubs: Iterable[EntityRef], prefix: str) -> str | None:
    """Exact whole-value match of a frontmatter field against id/alias/id-guess.

    Mirrors the legacy ``_match_hub`` semantics: the value equals the hub id or
    one of its aliases (NFC, case-insensitive), or the id-guess
    ``<prefix>-<slugify(value)>`` names the hub. ``hubs`` holds only on-disk hub
    notes, so the guess can never invent a link. Returns the hub id or None.
    """
    fv = _fold(value)
    if not fv:
        return None
    guess = f"{prefix}-{slugify(_nfc(value))}"
    for hub in hubs:
        if fv == _fold(hub.id) or hub.id == guess:
            return hub.id
        if any(fv == _fold(a) for a in hub.aliases):
            return hub.id
    return None


def _domain_label(domain: str) -> str:
    """Second-level label of a domain (``mail.hooli.ru`` → ``hooli``)."""
    parts = [p for p in _fold(domain).split(".") if p]
    if len(parts) >= 2:
        return parts[-2]
    return parts[0] if parts else ""


def _text_targets(
    haystack_nfc: str, haystack_fold: str, hubs: Iterable[EntityRef]
) -> Iterable[tuple[EntityRef, str]]:
    """Yield ``(hub, matched_token)`` for hubs mentioned in free text.

    Long tokens (id + aliases, ≥ :data:`MIN_TEXT_TOKEN`) match case-insensitively
    on the folded haystack; short tokens only as an explicit alias, exact case,
    on the NFC haystack. Both paths require word boundaries (не подстрокой).
    """
    for hub in hubs:
        for token, explicit_alias in [(hub.id, False)] + [
            (a, True) for a in hub.aliases
        ]:
            token = _nfc(str(token)).strip()
            if not token:
                continue
            if len(token) >= MIN_TEXT_TOKEN:
                if _standalone(_fold(token), haystack_fold):
                    yield hub, token
                    break
            elif explicit_alias and _standalone(token, haystack_nfc):
                yield hub, token
                break


def deterministic_links(
    signals: NoteSignals, catalog: list[EntityRef]
) -> list[DeterministicLink]:
    """Resolve ``signals`` against the hub ``catalog`` → exact-match links.

    Structured signals are checked first (they are the strongest evidence), the
    free-text scan last; the result is de-duplicated by target keeping the first
    (strongest) signal, order-stable. Only hubs present in ``catalog`` — i.e.
    hub notes that exist in the vault — can ever be returned.
    """
    by_entity: dict[str, list[EntityRef]] = {}
    for ref in catalog:
        if ref.entity in TEXT_ENTITIES:
            by_entity.setdefault(ref.entity, []).append(ref)
    clients = by_entity.get("client", [])

    out: list[DeterministicLink] = []
    seen: set[str] = set()

    def add(target: str | None, entity: str, signal: str, evidence: str) -> None:
        if target and target not in seen:
            seen.add(target)
            out.append(
                DeterministicLink(
                    target=target, entity=entity, signal=signal, evidence=evidence
                )
            )

    if signals.client:
        add(_field_match(signals.client, clients, "client"), "client", "client",
            signals.client)

    if signals.section:
        for entity in ("direction", "product"):
            hid = _field_match(signals.section, by_entity.get(entity, []), entity)
            add(hid, entity, "section", signals.section)

    for product in signals.products:
        hid = _field_match(product, by_entity.get("product", []), "product")
        add(hid, "product", "product", product)

    for cp in signals.counterparties:
        name = _nfc(cp).split("<", 1)[0].strip()  # display name before <addr>
        if name:
            add(_field_match(name, clients, "client"), "client", "counterparty", cp)

    for domain in signals.counterparty_domains:
        hid = _field_match(domain, clients, "client")
        if hid is None:
            label = _domain_label(domain)
            if label:
                hid = _field_match(label, clients, "client")
        add(hid, "client", "domain", domain)

    for tag in signals.tags:
        for entity in TEXT_ENTITIES:
            add(_field_match(tag, by_entity.get(entity, []), entity), entity,
                "tag", tag)

    for signal, text in (("title", signals.title), ("body", signals.body)):
        if not text:
            continue
        haystack_nfc = _nfc(text)
        haystack_fold = haystack_nfc.casefold()
        for entity in TEXT_ENTITIES:
            for hub, token in _text_targets(
                haystack_nfc, haystack_fold, by_entity.get(entity, [])
            ):
                add(hub.id, entity, signal, token)

    return out


def resolve_note(note: Note, catalog: list[EntityRef]) -> list[DeterministicLink]:
    """Convenience: :func:`signals_for_note` + :func:`deterministic_links`."""
    return deterministic_links(signals_for_note(note), catalog)
