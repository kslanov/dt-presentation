"""Phase 9, stage 2 — unified targets / scope / application over Phase 6.

One place that decides, for *any* note type, (a) which notes a linking pass may
run over (:func:`select_scope`), (b) which hubs/notes are legal link **targets**
per resolver (:func:`is_link_target`), and (c) how deterministic matches flow
into the existing Phase-6 review queue + apply machinery
(:func:`propose_deterministic`, :func:`approve_pending` →
:func:`core.linking.apply.apply_approved`). No note is ever written here —
application stays in the Phase-6 apply step, additive and idempotent.

Targets (ТЗ phase9 §Цели): ``type: hub`` + ``02-knowledge/**`` +
``03-projects/**`` + ``04-clients/**``. Client hubs are legal *deterministic*
targets (an explicit client mention / counterparty domain); for *semantic* they
stay excluded exactly as in Phase 6 (the LanceDB ``spine`` filter — a semantic
nearest-neighbour to someone else's client hub is noise). Always excluded:
``01-style/**``, ``06-templates/**``, ``07-outputs/**``, ``_system/**``.

Application (ТЗ phase9 §Применение): deterministic exact matches are enqueued
at ``score=1.0`` and either auto-approved (a CLI decision — ``--auto``, not a
config knob) or left ``pending`` for a threshold approve; semantic rows keep the
human-in-the-loop flow. The queue (``.derived/link_proposals.jsonl``) is the
shared journal for both resolvers — deterministic rows carry the
:class:`~core.linking.deterministic.DeterministicLink` evidence.

Invariant: ``core/`` depends on neither MCP nor CLI; no LLM calls here.
"""

from __future__ import annotations

import json
import time
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from pathlib import Path

from core.ingest import EntityRef, _entity_catalog
from core.linking.candidates import existing_link_targets
from core.linking.deterministic import DeterministicLink, resolve_note
from core.linking.propose import (
    STATUS_APPROVED,
    STATUS_PENDING,
    LinkProposal,
    LinkProposalQueue,
    _append_proposal,
    is_linkable_source,
    proposal_id,
)
from core.linking.quiet import recently_modified
from core.progress import ProgressBeacon
from core.vault import Note, iter_vault, iter_vault_paths, read_note

__all__ = [
    "RESOLVER_DETERMINISTIC",
    "RESOLVER_SEMANTIC",
    "ALWAYS_EXCLUDED_DIRS",
    "TARGET_DIRS",
    "DETERMINISTIC_SCORE",
    "DeterministicProposeResult",
    "is_link_target",
    "select_scope",
    "propose_deterministic",
    "scan_deterministic",
    "approve_pending",
]

RESOLVER_DETERMINISTIC = "deterministic"
RESOLVER_SEMANTIC = "semantic"

# Vault top-level folders that are NEVER link targets (ТЗ phase9 §Цели): style
# samples, templates, generated artifacts and system config are inputs/outputs
# of the engine, not the knowledge graph being enriched.
ALWAYS_EXCLUDED_DIRS: frozenset[str] = frozenset(
    {"01-style", "06-templates", "07-outputs", "_system"}
)

# Folders whose notes are eligible targets (besides ``type: hub`` anywhere
# outside the excluded set): durable knowledge, project hubs, client hubs.
TARGET_DIRS: frozenset[str] = frozenset({"02-knowledge", "03-projects", "04-clients"})

# Client hubs live here — legal deterministic targets, excluded for semantic
# (mirrors ``core.linking.candidates._CLIENT_DIR`` / the ``spine`` filter).
_CLIENT_DIR = "04-clients"

# Deterministic matches are exact catalog hits — high confidence by
# construction, so they enter the shared queue at the maximum score.
DETERMINISTIC_SCORE = 1.0

# Named scope selectors (plus ``<note-id>`` and ``<folder>`` free forms).
_LAYER_SCOPES = ("all", "legacy", "correspondence", "curated")


def _top_dir(note: Note, vault_path: Path) -> str:
    """The note's top-level vault folder (``""`` when outside the vault)."""
    try:
        rel = note.path.relative_to(vault_path)
    except ValueError:
        return ""
    return rel.parts[0] if len(rel.parts) > 1 else ""


def is_link_target(note: Note, vault_path: Path, *, resolver: str) -> bool:
    """Whether ``note`` may be a link **target** for ``resolver`` (ТЗ §Цели).

    Excluded folders always lose; a client hub is a valid deterministic target
    but never a semantic one; otherwise any hub, or any note under a target
    folder, is eligible.
    """
    top = _top_dir(note, Path(vault_path))
    if top in ALWAYS_EXCLUDED_DIRS:
        return False
    if resolver == RESOLVER_SEMANTIC and top == _CLIENT_DIR:
        return False
    if note.type == "hub":
        return True
    return top in TARGET_DIRS


def _is_correspondence(note: Note) -> bool:
    """Mail-thread notes: the ``section``/``source_type`` the mail render writes."""
    fm = note.frontmatter
    return (
        str(fm.get("section") or "") == "correspondence"
        or str(fm.get("source_type") or "") == "email-thread"
    )


def select_scope(vault_path: Path, scope: str = "all") -> list[Note]:
    """Resolve a ``--scope`` value to the notes a linking pass runs over.

    ``all`` — every vault note; ``legacy`` — the legacy corpus; ``correspondence``
    — mail-thread notes; ``curated`` — everything outside the legacy corpus.
    Anything else is first tried as an exact note id, then as a vault-relative
    folder prefix (e.g. ``_legacy/correspondence`` or ``02-knowledge``). Unlike
    the Phase-6 ``select_sources`` (isolates only — kept as-is for the semantic
    propose CLI), a scope selects notes *directly*: the pass is idempotent, so
    re-running over already-linked notes only ever adds what is missing.
    """
    vault_path = Path(vault_path)
    scope = (scope or "all").strip().strip("/")
    notes = list(iter_vault(vault_path))
    if scope == "all":
        return notes
    if scope == "legacy":
        return [n for n in notes if n.frontmatter.get("corpus") == "legacy"]
    if scope == "correspondence":
        return [n for n in notes if _is_correspondence(n)]
    if scope == "curated":
        return [n for n in notes if n.frontmatter.get("corpus") != "legacy"]

    by_id = [n for n in notes if n.id == scope]
    if by_id:
        return by_id
    return [
        n
        for n in notes
        if n.path.is_relative_to(vault_path)
        and n.path.relative_to(vault_path).as_posix().startswith(scope + "/")
    ]


# --------------------------------------------------------------------------- #
# Deterministic propose — exact matches into the shared Phase-6 queue          #
# --------------------------------------------------------------------------- #


@dataclass
class DeterministicProposeResult:
    """Summary of a :func:`propose_deterministic` / :func:`scan_deterministic` run."""

    sources: int = 0  # notes actually resolved
    skipped_sources: int = 0  # meta/index notes skipped (Phase-6 fix A)
    skipped_unchanged: int = 0  # scan only: fingerprint unchanged → not re-read
    skipped_recent: int = 0  # scan only: changed < DT_LINK_QUIET_S ago (fast just wrote it)
    parse_errors: int = 0  # scan only: unreadable notes (skipped, run continues)
    matched: int = 0  # catalog matches found (before guards)
    already_linked: int = 0  # match dropped: the note already links the target
    skipped_targets: int = 0  # match dropped: target not eligible (excluded dir)
    added: int = 0  # new proposals enqueued
    upgraded: int = 0  # pending semantic rows upgraded to deterministic
    duplicates: int = 0  # pair already queued (status preserved, idempotent)
    stopped: bool = False  # scan only: interrupted (SIGINT/SIGTERM) — resume later
    proposals: list[LinkProposal] = field(default_factory=list)  # added + upgraded


def deterministic_rationale(link: DeterministicLink) -> str:
    """Provenance line for the queue/journal: what matched and from which signal."""
    return (
        f"детерминированный матч ({link.entity}): «{link.evidence}» — "
        f"сигнал {link.signal}"
    )


def _eligible_hub_targets(vault_path: Path) -> dict[str, bool]:
    """``hub_id → eligible-as-deterministic-target`` for every on-disk hub note."""
    return {
        note.id: is_link_target(note, vault_path, resolver=RESOLVER_DETERMINISTIC)
        for note in iter_vault(vault_path)
        if note.type == "hub"
    }


def propose_deterministic(
    notes: Iterable[Note],
    *,
    vault_path: Path,
    queue: LinkProposalQueue,
    catalog: list[EntityRef] | None = None,
) -> DeterministicProposeResult:
    """Resolve ``notes`` deterministically and enqueue the matches (score 1.0).

    Guards, in order: meta/index notes are never sources; a self-match (a hub
    mentioning its own alias) is dropped; a target the note already links
    (body or frontmatter ``links``) is dropped — the dedup that keeps re-runs
    from proposing what is already applied; a target outside the eligible set
    (:func:`is_link_target`) is dropped. A pair already queued is left untouched
    (its review status is never clobbered) — except a still-``pending``
    *semantic* row for the same pair, which is **upgraded** in place to the
    deterministic row (same id, score 1.0, exact-match evidence): the exact
    match supersedes the similarity guess, which un-blocks threshold approves.
    """
    vault_path = Path(vault_path)
    if catalog is None:
        catalog = _entity_catalog(vault_path)
    eligible = _eligible_hub_targets(vault_path)

    result = DeterministicProposeResult()
    for note in notes:
        if not is_linkable_source(note):
            result.skipped_sources += 1
            continue
        result.sources += 1
        _propose_note(
            note, catalog=catalog, eligible=eligible, queue=queue, result=result
        )
    return result


def _propose_note(
    note: Note,
    *,
    catalog: list[EntityRef],
    eligible: dict[str, bool],
    queue: LinkProposalQueue,
    result: DeterministicProposeResult,
    append_path: Path | None = None,
) -> None:
    """Resolve ONE note into the queue (shared by propose/scan; see the guards
    documented on :func:`propose_deterministic`). With ``append_path``, every
    new/upgraded row is also appended as JSONL immediately — crash-durable
    persistence for the schedulable scan (later ``load`` dedups by id, an
    upgraded pair's later line wins)."""
    links = resolve_note(note, catalog)
    if not links:
        return
    existing = existing_link_targets(note)
    for dl in links:
        if dl.target == note.id:
            continue  # a hub matching itself
        result.matched += 1
        if dl.target in existing:
            result.already_linked += 1
            continue
        if not eligible.get(dl.target, False):
            result.skipped_targets += 1
            continue
        proposal = LinkProposal(
            id=proposal_id(note.id, dl.target),
            source_note=note.id,
            target_note=dl.target,
            score=DETERMINISTIC_SCORE,
            target_type="hub",
            evidence_snippet=f"{dl.signal}: {dl.evidence}",
            rationale=deterministic_rationale(dl),
            resolver=RESOLVER_DETERMINISTIC,
        )
        if queue.add(proposal):
            result.added += 1
            result.proposals.append(proposal)
        else:
            current = queue.by_id[proposal.id]
            if (
                current.status == STATUS_PENDING
                and current.resolver != RESOLVER_DETERMINISTIC
            ):
                queue.by_id[proposal.id] = proposal
                result.upgraded += 1
                result.proposals.append(proposal)
            else:
                result.duplicates += 1
                continue
        if append_path is not None:
            _append_proposal(append_path, proposal)


# --------------------------------------------------------------------------- #
# Schedulable scan (Phase 9 этап 4, принцип 11) — checkpoint / resume / stop   #
# --------------------------------------------------------------------------- #


def _load_scan_manifest(path: Path | None) -> dict[str, list[float]]:
    """``rel-path → [mtime, size]`` of the last scan; ``{}`` when missing/broken."""
    if path is None or not Path(path).is_file():
        return {}
    try:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}  # rebuildable — a lost manifest just means one full rescan
    return raw if isinstance(raw, dict) else {}


def _save_scan_manifest(path: Path, manifest: dict[str, list[float]]) -> None:
    """Persist the scan checkpoint atomically (write-temp-then-replace)."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(json.dumps(manifest, ensure_ascii=False, sort_keys=True),
                   encoding="utf-8")
    tmp.replace(target)


def _fingerprint(path: Path) -> list[float]:
    st = path.stat()
    return [st.st_mtime, float(st.st_size)]


def _matches_layer(note: Note, scope: str) -> bool:
    if scope == "all":
        return True
    if scope == "legacy":
        return note.frontmatter.get("corpus") == "legacy"
    if scope == "correspondence":
        return _is_correspondence(note)
    if scope == "curated":
        return note.frontmatter.get("corpus") != "legacy"
    return True  # folder scopes are filtered at the path level


def _curated_hubs(vault_path: Path) -> list[Note]:
    """Hub notes, parsing only the curated subtree (hubs never live in _legacy).

    On steady-state the legacy corpus dominates the vault by an order of
    magnitude; skipping it keeps the per-run catalog build cheap (принцип 11:
    the scheduled pass must not re-read the whole vault)."""
    hubs: list[Note] = []
    for path in iter_vault_paths(vault_path):
        if "_legacy" in path.relative_to(vault_path).parts:
            continue
        try:
            note = read_note(path)
        except Exception:  # noqa: BLE001, S112 — a broken note must not kill the scan
            continue
        if note.type == "hub":
            hubs.append(note)
    return hubs


def _catalog_and_targets(
    vault_path: Path,
) -> tuple[list[EntityRef], dict[str, bool]]:
    """Deterministic catalog + target-eligibility from one cheap curated walk.

    Mirrors ``core.ingest._entity_catalog`` for the entities the deterministic
    resolver matches (:data:`~core.linking.deterministic.TEXT_ENTITIES`), sorted
    (entity, id) for stable output.
    """
    from core.linking.deterministic import TEXT_ENTITIES

    order = {name: i for i, name in enumerate(TEXT_ENTITIES)}
    catalog: list[EntityRef] = []
    eligible: dict[str, bool] = {}
    for note in _curated_hubs(vault_path):
        eligible[note.id] = is_link_target(
            note, vault_path, resolver=RESOLVER_DETERMINISTIC
        )
        entity = note.frontmatter.get("entity")
        if entity in order:
            aliases = [str(a) for a in (note.frontmatter.get("aliases") or [])]
            catalog.append(EntityRef(entity=entity, id=note.id, aliases=aliases))
    catalog.sort(key=lambda r: (order[r.entity], r.id))
    return catalog, eligible


def _scan_progress(seen: int, total: int, proposed: int, start: float) -> str:
    elapsed = time.perf_counter() - start
    eta = ""
    if total and seen and elapsed > 0:
        rate = seen / elapsed
        if rate > 0:
            eta = f" | ~{int((total - seen) / rate)}s eta"
    return f"[link] {seen}/{total} | proposed {proposed} | applied 0{eta}"


def scan_deterministic(
    vault_path: Path,
    *,
    queue: LinkProposalQueue,
    scope: str = "all",
    manifest_path: Path | None = None,
    save_manifest: bool = True,
    rescan: bool = False,
    append_path: Path | None = None,
    checkpoint_every: int = 200,
    log: Callable[[str], None] | None = None,
    progress_every: int = 200,
    should_stop: Callable[[], bool] | None = None,
) -> DeterministicProposeResult:
    """Schedulable deterministic pass over the vault (принцип 11, арх. §9.11).

    Walks note *paths* (no parsing) and stat-compares each against the scan
    manifest (``rel-path → [mtime, size]``): unchanged notes are skipped without
    being read, so a steady-state scheduled run does not re-read the vault. Only
    new/changed notes are parsed, scope-filtered (layer scopes; folder scopes
    are applied to the path prefix; an explicit note id is NOT supported here —
    use :func:`select_scope` + :func:`propose_deterministic`) and resolved into
    the shared queue via the same guards as :func:`propose_deterministic`.

    Принцип 11: a progress line every ``progress_every`` paths; the manifest is
    checkpointed every ``checkpoint_every`` processed notes (and rows are
    appended to ``append_path`` as produced), so an interrupted run **resumes**
    instead of restarting; ``should_stop`` is polled per note — on True the
    checkpoint is flushed and the result returns ``stopped=True`` (graceful
    SIGINT/SIGTERM). ``save_manifest=False`` (dry-run) reads the manifest for a
    realistic plan but never advances it; ``rescan=True`` ignores fingerprints
    (still refreshing them on save).
    """
    vault_path = Path(vault_path)
    log = log or (lambda _msg: None)
    scope = (scope or "all").strip().strip("/")
    manifest = {} if rescan else _load_scan_manifest(manifest_path)
    fresh: dict[str, list[float]] = dict(manifest)

    paths: list[Path] = []
    for path in iter_vault_paths(vault_path):
        rel = path.relative_to(vault_path).as_posix()
        if scope not in _LAYER_SCOPES and not rel.startswith(scope + "/"):
            continue  # folder scope — path-prefix filter, no parsing needed
        paths.append(path)
    total = len(paths)

    catalog, eligible = _catalog_and_targets(vault_path)
    result = DeterministicProposeResult()
    start = time.perf_counter()
    seen = processed = 0
    # ACT-1: маяк для pult_activity — только счётчики (scope/пути не пишем).
    beacon = ProgressBeacon("link", total, emit=log)

    def proposed() -> int:
        return result.added + result.upgraded

    def checkpoint() -> None:
        if save_manifest and manifest_path is not None:
            _save_scan_manifest(manifest_path, fresh)

    for path in paths:
        if should_stop is not None and should_stop():
            result.stopped = True
            break
        seen += 1
        if progress_every and seen % progress_every == 0:
            beacon.update(
                seen,
                {"proposed": proposed()},
                line=_scan_progress(seen, total, proposed(), start),
            )
        rel = path.relative_to(vault_path).as_posix()
        try:
            fp = _fingerprint(path)
        except OSError:
            result.parse_errors += 1
            continue
        if manifest.get(rel) == fp:
            result.skipped_unchanged += 1
            continue
        # WAVE0-HYGIENE п.4: fast (mail_ingest) и index идут параллельно — только что
        # записанную заметку не читаем (не в манифест: следующий проход её подхватит).
        if recently_modified(path):
            result.skipped_recent += 1
            continue
        try:
            note = read_note(path)
        except Exception:  # noqa: BLE001 — one broken note must not kill the run
            result.parse_errors += 1
            log(f"[link] parse error, пропущено: {rel}")
            continue
        if not _matches_layer(note, scope):
            continue  # вне scope — НЕ отмечаем в манифесте (не сканирована)
        if not is_linkable_source(note):
            result.skipped_sources += 1
        else:
            result.sources += 1
            _propose_note(
                note, catalog=catalog, eligible=eligible, queue=queue,
                result=result, append_path=append_path,
            )
        fresh[rel] = fp
        processed += 1
        if checkpoint_every and processed % checkpoint_every == 0:
            checkpoint()

    checkpoint()
    tail = " | interrupted — resume on next run" if result.stopped else " | done"
    beacon.update(
        seen, {"proposed": proposed()},
        line=_scan_progress(seen, total, proposed(), start) + tail,
    )
    # Graceful stop оставляет маяк незавершённым — pult_activity покажет
    # interrupted («продолжится от чекпойнта»), что фактически и произойдёт.
    if not result.stopped:
        beacon.done(f"scanned {seen}/{total}, proposed {proposed()}")
    return result


def approve_pending(
    queue: LinkProposalQueue,
    *,
    resolver: str | None = None,
    min_score: float | None = None,
) -> list[str]:
    """Mark matching ``pending`` proposals approved (in memory); return their ids.

    ``resolver`` narrows to one layer (``--auto`` approves only deterministic
    rows); ``min_score`` is the threshold approve. With neither filter no row is
    touched — approving *everything* must be an explicit choice, not a default.
    """
    if resolver is None and min_score is None:
        return []
    approved: list[str] = []
    for p in queue.by_id.values():
        if p.status != STATUS_PENDING:
            continue
        if resolver is not None and p.resolver != resolver:
            continue
        if min_score is not None and p.score < min_score:
            continue
        p.status = STATUS_APPROVED
        approved.append(p.id)
    return approved
