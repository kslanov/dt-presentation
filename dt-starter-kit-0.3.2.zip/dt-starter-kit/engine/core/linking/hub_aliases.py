"""HUB-ALIAS-1 п.3 - алиасы хабов КАК ПРЕДЛОЖЕНИЕ: детектор, очередь, решение с пульта.

Решение К. №6 аудита C: «движок предлагает, К. подтверждает». У 16 из 79 боевых хабов нет
``aliases`` (клиентских - 7), имя живет только в H1; единый каталог имен
(:func:`core.retrieval.hubcat.hub_catalog`) его уже читает, а вот как ЯВНЫЙ алиас (короткие
аббревиатуры, дубли, ярлыки папок) его пишет только человек. Детектор собирает кандидатов из ЧЕТЫРЕХ
источников, каждый с меткой и счетчиком подтверждений:

* ``h1`` - фрагменты H1 хаба («…», (…)); для хаба без явных алиасов;
* ``mirror`` - организации сделок зеркала Timetta, относящихся к хабу (сделка по ``timetta_id``
  хаба / проекта хаба, либо организация названа так же, как хаб): имя без юрформы и ее ``code``;
* ``domain`` - второй уровень ``counterparty_domains`` почтовых тредов, привязанных к хабу
  (``acme.kz`` → ``acme``); только если хаб - основной адресат домена и тредов не меньше
  :data:`MIN_DOMAIN_THREADS`;
* ``folder`` - имя клиентской папки легаси (``2023-2026/Kazakhstan/Acme/…`` → ``Acme``) у
  привязанных заметок, не меньше :data:`MIN_FOLDER_NOTES`.

Одно имя из нескольких источников - ОДНО предложение с несколькими метками (``Acme``: H1 + зеркало
+ домен). Отсев: персоны (адрес в имени), бесплатная почта, домены владельца, стоп-слова и ОПФ
отдельно («АО/ПАО/ООО/ТОО» - только вместе с именем, поэтому из H1 берутся фрагменты, а не
заголовок целиком), для хаба с явными алиасами - имена, которые у него уже есть. Имя, совпавшее с
именем ДРУГОГО хаба, остается в карточке с пометкой ``conflict`` (по умолчанию не отмечено).

Очередь ``.derived/hub_alias_candidates.jsonl`` по образцу ``HubCandidateQueue``: строка = ХАБ (id =
hub_id), идемпотентно, сверка: хаб получил алиасы руками и предлагать больше нечего → ``resolved``;
``rejected`` - навсегда (стоп-журнал), ``snoozed`` - до даты. Запись во frontmatter - ТОЛЬКО по
решению с пульта (:func:`decide_hub_alias` → :func:`core.operational.hub_link.set_hub_aliases`,
байт-в-байт по остальному); автозаписи нет. В очереди - id хабов, имена-кандидаты, метки источников
и счетчики (домены/организации - сущности, не персоны), текстов писем нет.

Инвариант: ``core/`` ⊥ mcp/cli; ни сети, ни LLM (зеркало передает вызывающий).
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.linking.hub_candidates import STOP_WORDS, _is_free_mail, _stopped
from core.retrieval.hubcat import HubEntry, h1_alias_names, hub_catalog
from core.retrieval.notemeta import NoteMeta, fold_plain, owner_ids
from core.text.stem import key_tokens

__all__ = [
    "MIN_DOMAIN_THREADS",
    "MIN_FOLDER_NOTES",
    "SNOOZE_DAYS",
    "SOURCES",
    "STATUS_APPLIED",
    "STATUS_PENDING",
    "STATUS_REJECTED",
    "STATUS_RESOLVED",
    "STATUS_SNOOZED",
    "AliasCandidate",
    "AliasQueue",
    "AliasScanResult",
    "decide_hub_alias",
    "scan_alias_candidates",
]

# Порядок = приоритет текста при слиянии одного имени из нескольких источников.
SOURCES: tuple[str, ...] = ("h1", "mirror", "folder", "domain")
MIN_DOMAIN_THREADS = 2  # тредов домена, привязанных к хабу
DOMAIN_DOMINANCE = 0.5  # доля тредов домена в ЭТОМ хабе должна быть БОЛЬШЕ (ничья - домен «общий»)
MIN_FOLDER_NOTES = 2  # заметок легаси с этим именем папки
SNOOZE_DAYS = 7
EXTRA_MAX_CHARS = 48  # свой вариант алиаса: не длиннее (SURFACE-HYGIENE-1 п.9)

STATUS_PENDING = "pending"
STATUS_APPLIED = "applied"
STATUS_REJECTED = "rejected"  # навсегда: стоп-журнал детектора
STATUS_SNOOZED = "snoozed"
STATUS_RESOLVED = "resolved"  # снят сверкой: предлагать больше нечего / хаба нет

_ERA_RE = re.compile(r"^\d{4}-\d{4}$")
_QUOTED_RE = re.compile(r"[«\"“]([^»\"”]{2,})[»\"”]")
_OPF_ONLY = frozenset(STOP_WORDS) | {"клиентский", "хаб", "клиент"}


def _key(text: str) -> tuple[str, ...]:
    """Стем-ключ имени (как у каталога хабов); без ключей - свернутый текст."""
    keys = tuple(key_tokens(text))
    return keys or (fold_plain(text),)


def _domain_label(domain: str) -> str:
    parts = [p for p in str(domain).casefold().strip(".").split(".") if p]
    return parts[-2] if len(parts) >= 2 else (parts[0] if parts else "")


def _org_names(name: str) -> list[str]:
    """Имена организации зеркала: фрагменты в кавычках; нет - без юрформы."""
    text = str(name or "").strip()
    quoted = [m.group(1).strip() for m in _QUOTED_RE.finditer(text)]
    if quoted:
        return list(dict.fromkeys(quoted))
    plain = re.sub(r"\b(?:ООО|АО|ПАО|ЗАО|ОАО|НПО|ГК|ТОО|LLC|JSC|Ltd)\b\.?", " ", text, flags=re.I)
    plain = " ".join(plain.replace("«", " ").replace("»", " ").split())
    return [plain] if plain else []


def _translit_forms(entry: HubEntry) -> set[str]:
    """Латинские формы имен хаба (слаг id и транслит имен) без дефисов - для сверки с доменом."""
    from core.legacy.render import slugify

    forms: set[str] = set()
    for n in entry.names:
        slug = slugify(n.text).replace("-", "")
        if len(slug) >= 3:
            forms.add(slug)
    return forms


def _usable(name: str) -> bool:
    """Годится ли строка как имя-алиас: не персона, не стоп-слово/ОПФ/год/число."""
    text = str(name or "").strip().strip("«»\"'“”")
    if len(text) < 2 or "@" in text or _stopped(text):
        return False
    return text.casefold() not in _OPF_ONLY


# --------------------------------------------------------------------------- #
# Модель очереди                                                               #
# --------------------------------------------------------------------------- #
@dataclass
class AliasCandidate:
    """Строка очереди: один хаб и его предложения имен."""

    hub_id: str
    entity: str = ""
    status: str = STATUS_PENDING
    suggestions: list[dict[str, Any]] = field(default_factory=list)
    created: str | None = None
    decided_at: str | None = None
    snooze_until: str | None = None
    aliases_set: list[str] = field(default_factory=list)

    @property
    def id(self) -> str:
        return self.hub_id

    def to_row(self) -> dict[str, Any]:
        row: dict[str, Any] = {
            "id": self.hub_id, "hub_id": self.hub_id, "entity": self.entity,
            "status": self.status, "suggestions": self.suggestions,
        }
        for key in ("created", "decided_at", "snooze_until"):
            if getattr(self, key):
                row[key] = getattr(self, key)
        if self.aliases_set:
            row["aliases_set"] = self.aliases_set
        return row

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> AliasCandidate:
        return cls(
            hub_id=str(row.get("hub_id") or row.get("id") or ""),
            entity=str(row.get("entity") or ""),
            status=str(row.get("status") or STATUS_PENDING),
            suggestions=[s for s in (row.get("suggestions") or []) if isinstance(s, dict)],
            created=row.get("created"),
            decided_at=row.get("decided_at"),
            snooze_until=row.get("snooze_until"),
            aliases_set=[str(a) for a in (row.get("aliases_set") or [])],
        )


@dataclass
class AliasQueue:
    """Очередь ``.derived/hub_alias_candidates.jsonl`` (ключ - id хаба; без сети)."""

    by_id: dict[str, AliasCandidate] = field(default_factory=dict)
    path: Path | None = None

    @classmethod
    def load(cls, path: Path) -> AliasQueue:
        path = Path(path)
        by_id: dict[str, AliasCandidate] = {}
        if path.is_file():
            for line in path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue  # поврежденная строка - очередь перестраиваемая
                if isinstance(row, dict) and (row.get("hub_id") or row.get("id")):
                    cand = AliasCandidate.from_row(row)
                    by_id[cand.hub_id] = cand
        return cls(by_id=by_id, path=path)

    def pending(self, now: datetime | None = None) -> list[AliasCandidate]:
        """Ждут решения: ``pending`` и ``snoozed``, у которых «позже» уже наступило."""
        stamp = (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ")
        return [
            c for c in self.by_id.values()
            if c.status == STATUS_PENDING
            or (c.status == STATUS_SNOOZED and (c.snooze_until or "") <= stamp)
        ]

    def save(self, path: Path | None = None) -> Path:
        chosen = Path(path or self.path or "")
        if not str(chosen):
            raise ValueError("AliasQueue.save needs a path")
        chosen.parent.mkdir(parents=True, exist_ok=True)
        rows = sorted(self.by_id.values(), key=lambda c: (c.created or "", c.hub_id))
        body = "\n".join(json.dumps(c.to_row(), ensure_ascii=False) for c in rows)
        tmp = chosen.with_suffix(chosen.suffix + ".tmp")
        tmp.write_text(body + ("\n" if body else ""), encoding="utf-8")
        tmp.replace(chosen)
        return chosen


@dataclass
class AliasScanResult:
    """Анонимная сводка прогона - только счетчики."""

    hubs: int = 0
    hubs_without_aliases: int = 0
    with_suggestions: int = 0
    added: int = 0
    updated: int = 0
    revived: int = 0
    resolved: int = 0
    skipped_rejected: int = 0
    snoozed: int = 0
    conflicts: int = 0
    by_source: dict[str, int] = field(default_factory=dict)


# --------------------------------------------------------------------------- #
# Детектор                                                                     #
# --------------------------------------------------------------------------- #
def _hub_frontmatter(vault: Path, entry: HubEntry) -> dict[str, Any]:
    from core.vault import read_note

    try:
        return dict(read_note(vault / entry.path, vault).frontmatter)
    except Exception:  # noqa: BLE001 — нечитаемый хаб: без timetta_id, остальное работает
        return {}


def _evidence(metas: list[NoteMeta], client_ids: set[str]) -> tuple[
    dict[str, dict[str, int]], dict[str, dict[str, int]]
]:
    """Один проход по срезам: ``домен → {хаб: тредов}`` и ``хаб → {папка легаси: заметок}``."""
    domains: dict[str, dict[str, int]] = {}
    folders: dict[str, dict[str, int]] = {}
    for meta in metas:
        if meta.note_type == "hub":
            continue
        owners = owner_ids(meta) & client_ids
        if not owners:
            continue
        raw_domains = meta.texts(("counterparty_domains",))
        for domain in dict.fromkeys(d.casefold().strip(".") for d in raw_domains):
            if domain:
                for hub in owners:
                    domains.setdefault(domain, {})[hub] = domains.get(domain, {}).get(hub, 0) + 1
        parts = [p for p in str(meta.source_path or "").replace("\\", "/").split("/") if p]
        if len(parts) >= 4 and _ERA_RE.match(parts[0]):
            for hub in owners:
                bucket = folders.setdefault(hub, {})
                bucket[parts[2]] = bucket.get(parts[2], 0) + 1
    return domains, folders


def _mirror_orgs(
    entry: HubEntry, fm: dict[str, Any], hub_names: set[tuple[str, ...]],
    deals: list[dict[str, Any]], orgs_by_id: dict[str, dict[str, Any]],
    project_deals: dict[str, set[str]],
) -> dict[str, dict[str, Any]]:
    """Организации зеркала, относящиеся к клиентскому хабу: ``org_id → {name, code, deals}``."""
    own_guids = {str(fm.get("timetta_id") or "").strip().lower()} | project_deals.get(
        entry.note_id, set()
    )
    own_guids.discard("")
    found: dict[str, dict[str, Any]] = {}
    for deal in deals:
        org_id = str(deal.get("organization_id") or deal.get("organization_name") or "")
        org_name = str(deal.get("organization_name") or "")
        if not org_name:
            continue
        by_guid = str(deal.get("id") or "").strip().lower() in own_guids
        by_name = any(_key(n) in hub_names for n in _org_names(org_name) if _usable(n))
        if not (by_guid or by_name):
            continue
        row = found.setdefault(org_id, {"name": org_name, "deals": 0, "code": ""})
        row["deals"] += 1
        org = orgs_by_id.get(str(deal.get("organization_id") or ""))
        if org and org.get("code"):
            row["code"] = str(org["code"])
    return found


def scan_alias_candidates(
    vault_path: Path,
    *,
    queue: AliasQueue,
    deals: list[dict[str, Any]] | None = None,
    organizations: list[dict[str, Any]] | None = None,
    owner_domains: list[str] | None = None,
    now: datetime | None = None,
) -> AliasScanResult:
    """Собрать предложения алиасов для хабов и обновить очередь (одним ``save()``). См. модуль."""
    from core.config import mail_owner_domains
    from core.retrieval.fm_cache import load_metas_cached

    vault = Path(vault_path)
    now_dt = now or datetime.now(UTC)
    stamp = now_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    own_domains = {d.casefold() for d in (owner_domains if owner_domains is not None
                                           else mail_owner_domains())}
    catalog = hub_catalog(vault, None)
    metas, _warnings = load_metas_cached(vault)
    result = AliasScanResult(hubs=len(catalog))
    hubs_by_id = {e.note_id: e for e in catalog}
    client_ids = {e.note_id for e in catalog if e.entity == "client"}

    # имя (стем-ключ) → хабы, которые его уже носят (любой источник): конфликт имен
    holders: dict[tuple[str, ...], set[str]] = {}
    for e in catalog:
        for n in e.names:
            holders.setdefault(n.keys, set()).add(e.note_id)

    domains, folders = _evidence(metas, client_ids)
    orgs_by_id = {str(o.get("id")): o for o in (organizations or []) if o.get("id")}
    active_deals = [d for d in (deals or []) if isinstance(d, dict)]
    fms = {e.note_id: _hub_frontmatter(vault, e) for e in catalog
           if e.entity in ("client", "project")}
    project_deals: dict[str, set[str]] = {}  # клиентский хаб → guid'ы сделок его проектов
    for meta in metas:
        if meta.note_type == "hub" and meta.entity == "project":
            guid = str(fms.get(meta.id, {}).get("timetta_id") or "").strip().lower()
            for owner in owner_ids(meta) & client_ids:
                if guid:
                    project_deals.setdefault(owner, set()).add(guid)

    scanned: dict[str, list[dict[str, Any]]] = {}
    for entry in catalog:
        has_alias = any(n.source == "alias" for n in entry.names)
        if not has_alias:
            result.hubs_without_aliases += 1
        known = {n.keys for n in entry.names}
        translit = _translit_forms(entry)
        cands: dict[tuple[str, ...], dict[str, Any]] = {}

        def add(text: str, source: str, count: int, detail: str,
                entry: HubEntry = entry, has_alias: bool = has_alias,
                known: set[tuple[str, ...]] = known,
                cands: dict[tuple[str, ...], dict[str, Any]] = cands) -> None:
            clean = str(text or "").strip()
            if not _usable(clean):
                return
            key = _key(clean)
            if has_alias and key in known:
                return  # у хаба с явными алиасами это имя уже есть
            row = cands.setdefault(key, {"texts": {}, "sources": []})
            row["texts"].setdefault(source, clean)
            row["sources"].append({"source": source, "count": int(count), "detail": detail})

        if not has_alias:
            for name in h1_alias_names(entry.h1):
                add(name, "h1", 1, "H1 хаба")
        if entry.entity == "client":
            if deals is not None:
                orgs = _mirror_orgs(entry, fms.get(entry.note_id, {}), known, active_deals,
                                    orgs_by_id, project_deals)
                for org in orgs.values():
                    for name in _org_names(org["name"]):
                        add(name, "mirror", org["deals"], f"организация сделок: {org['name']}")
                    if org["code"]:
                        add(org["code"], "mirror", org["deals"],
                            f"код организации: {org['code']}")
            for domain, per_hub in domains.items():
                mine = per_hub.get(entry.note_id, 0)
                total = sum(per_hub.values())
                label = _domain_label(domain)
                # домен - ДОВОД, а не генератор имен: метка домена предлагается, только если
                # совпала с латинской формой имени хаба («acme.kz» ↔ «Акме»/Acme). Иначе домены
                # собеседников (подрядчики, группа компаний) засорили бы карточку клиента.
                if (mine < MIN_DOMAIN_THREADS or mine / total <= DOMAIN_DOMINANCE
                        or len(label) < 3 or _is_free_mail(domain)
                        or label.replace("-", "") not in translit
                        or any(domain == d or domain.endswith("." + d) for d in own_domains)):
                    continue
                add(label, "domain", mine, domain)
            for label, count in folders.get(entry.note_id, {}).items():
                if count >= MIN_FOLDER_NOTES:
                    add(label, "folder", count, "папка легаси")

        suggestions: list[dict[str, Any]] = []
        for key, row in cands.items():
            text = next(row["texts"][s] for s in SOURCES if s in row["texts"])
            other = sorted(holders.get(key, set()) - {entry.note_id})
            suggestions.append({
                "name": text,
                "sources": sorted(row["sources"], key=lambda s: SOURCES.index(s["source"])),
                "conflict": other[0] if other else None,
            })
        suggestions.sort(key=lambda s: (s["conflict"] is not None, -len(s["sources"]),
                                        s["name"].casefold()))
        if suggestions:
            scanned[entry.note_id] = suggestions

    # -- upsert в очередь ------------------------------------------------------------------
    for hub_id, suggestions in scanned.items():
        entry = hubs_by_id[hub_id]
        result.with_suggestions += 1
        result.conflicts += sum(1 for s in suggestions if s["conflict"])
        for s in suggestions:
            for src in s["sources"]:
                result.by_source[src["source"]] = result.by_source.get(src["source"], 0) + 1
        known_row = queue.by_id.get(hub_id)
        if known_row is None:
            queue.by_id[hub_id] = AliasCandidate(
                hub_id=hub_id, entity=entry.entity, suggestions=suggestions, created=stamp
            )
            result.added += 1
            continue
        if known_row.status == STATUS_REJECTED:
            result.skipped_rejected += 1  # стоп-журнал: отклоненное не воскресает
            continue
        if known_row.status == STATUS_SNOOZED and (known_row.snooze_until or "") > stamp:
            result.snoozed += 1
            known_row.suggestions = suggestions  # держим свежим, статус не трогаем
            continue
        known_row.suggestions = suggestions
        known_row.entity = entry.entity
        if known_row.status in (STATUS_APPLIED, STATUS_RESOLVED, STATUS_SNOOZED):
            known_row.status = STATUS_PENDING  # дорос новый сигнал / «позже» наступило
            known_row.decided_at = None
            known_row.snooze_until = None
            result.revived += 1
        result.updated += 1

    # сверка: предлагать больше нечего (хаб получил алиасы руками / хаба нет) → resolved
    for hub_id, queued in queue.by_id.items():
        if queued.status in (STATUS_PENDING, STATUS_SNOOZED) and hub_id not in scanned:
            queued.status = STATUS_RESOLVED
            queued.decided_at = stamp
            queued.snooze_until = None
            result.resolved += 1
    if result.added or result.updated or result.revived or result.resolved or result.snoozed:
        queue.save()
    return result


# --------------------------------------------------------------------------- #
# Решение с пульта                                                             #
# --------------------------------------------------------------------------- #
def normalize_extra(extra: Any) -> list[str]:
    """Свои варианты алиасов: строка через запятую/``;``/перевод строки либо список → чистый список.

    trim и схлопывание пробелов, дедуп без регистра (первый вариант побеждает), пустые пропускаются;
    вариант длиннее :data:`EXTRA_MAX_CHARS` - ``ValueError`` с его именем (не молча обрезаем)."""
    if extra is None:
        return []
    raw = re.split(r"[,;\n]", extra) if isinstance(extra, str) else list(extra)
    out: list[str] = []
    seen: set[str] = set()
    for item in raw:
        name = " ".join(str(item).split())
        if not name or name.casefold() in seen:
            continue
        if len(name) > EXTRA_MAX_CHARS:
            raise ValueError(
                f"свой вариант {name[:40]!r}… длиннее {EXTRA_MAX_CHARS} символов - сократи")
        seen.add(name.casefold())
        out.append(name)
    return out


def _check_extra_conflicts(hub_id: str, extras: list[str], vault_path: Path) -> None:
    """Свой вариант не должен совпасть с именем/алиасом ДРУГОГО хаба (та же сверка по стем-ключу,
    что у конфликтов предложений) или с названием самого хаба (title/H1/слаг: это и так его имя)."""
    catalog = hub_catalog(Path(vault_path), None)
    holders: dict[tuple[str, ...], set[str]] = {}
    own_names: set[tuple[str, ...]] = set()
    for entry in catalog:
        for n in entry.names:
            holders.setdefault(n.keys, set()).add(entry.note_id)
            if entry.note_id == hub_id and n.source != "alias":
                own_names.add(n.keys)
    for name in extras:
        key = _key(name)
        others = sorted(holders.get(key, set()) - {hub_id})
        if others:
            raise ValueError(f"свой вариант {name!r} уже носит другой хаб: {others[0]}")
        if key in own_names:
            raise ValueError(f"свой вариант {name!r} совпадает с названием самого хаба")


def decide_hub_alias(
    hub_id: str,
    decision: str,
    aliases: list[str] | None = None,
    *,
    queue: AliasQueue,
    vault_path: Path,
    now: str | None = None,
    extra: Any = None,
) -> dict[str, Any]:
    """Решение по алиасам хаба: ``approve`` пишет ВЫБРАННОЕ подмножество, ``reject`` - навсегда,
    ``snooze`` - на :data:`SNOOZE_DAYS` дней.

    ``approve``: ``aliases=None`` - все предложения без конфликта; иначе только имена ИЗ
    предложений строки (свободный текст через этот путь не пишется), сверка по стем-ключу.
    Запись - :func:`core.operational.hub_link.set_hub_aliases` (хирургически, существующие
    алиасы целы, дубли по ``_fold`` не пишутся). Аудит - ``pult-actions.log`` (хаб и число имен,
    без текстов), событие ``hub/aliases_set`` (новой метрики нет). Повторное решение по
    уже решенной строке - ``stale``, не ошибка.

    ``extra`` (SURFACE-HYGIENE-1 п.9) - СВОИ варианты (строка через запятую или список): имя,
    которого детектор не видел («СУПР» у «Система управления проектами»).
    Нормализуются (:func:`normalize_extra`), не должны совпасть с именем/алиасом другого хаба или
    названием самого хаба (иначе ``ValueError`` с именем варианта). Карточка без отмеченных
    предложений, но с ``extra`` - валидное решение (при ``aliases=None`` и непустом ``extra``
    пишутся ТОЛЬКО свои). Запись - тем же ``set_hub_aliases``; в ответе ``extra_added``; в аудите
    ``extra_count``. Записанный свой алиас попадает в каталог имен хаба (``source: alias``) -
    детектор его больше не предлагает.
    """
    from core.operational.pult import record_action

    if decision not in ("approve", "reject", "snooze"):
        raise ValueError(
            f"unsupported decision {decision!r}; use 'approve', 'reject' or 'snooze'"
        )
    audit: dict[str, Any] = {"hub_id": hub_id, "decision": decision}
    row = queue.by_id.get(str(hub_id))
    if row is None:
        record_action("pult_hub_alias_decide", audit, "not_found", now=now)
        raise ValueError(f"Хаб {hub_id} не найден в очереди алиасов.")
    visible = {c.hub_id for c in queue.pending(_parse_stamp(now))}
    if row.hub_id not in visible:
        record_action("pult_hub_alias_decide", audit, "stale", now=now)
        why = ("снята сверкой (предлагать больше нечего)" if row.status == STATUS_RESOLVED
               else f"уже решена ({row.status})")
        return {"outcome": "stale", "hub_id": row.hub_id,
                "explanation": f"Строка алиасов {why} - повторное решение не требуется."}

    stamp = now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    if decision == "reject":
        row.status = STATUS_REJECTED
        row.decided_at = stamp
        queue.save()
        record_action("pult_hub_alias_decide", audit, "rejected", now=now)
        return {"outcome": "rejected", "hub_id": row.hub_id,
                "explanation": "Отклонено навсегда - детектор больше не предложит алиасы хаба."}
    if decision == "snooze":
        until = (_parse_stamp(now) + timedelta(days=SNOOZE_DAYS)).strftime("%Y-%m-%dT%H:%M:%SZ")
        row.status = STATUS_SNOOZED
        row.decided_at = stamp
        row.snooze_until = until
        queue.save()
        record_action("pult_hub_alias_decide", audit, "snoozed", now=now)
        return {"outcome": "snoozed", "hub_id": row.hub_id, "snooze_until": until}

    # -- approve ------------------------------------------------------------------------------
    try:
        extras = normalize_extra(extra)
        if extras:
            _check_extra_conflicts(row.hub_id, extras, Path(vault_path))
    except ValueError:
        record_action("pult_hub_alias_decide", audit, "invalid", now=now)
        raise
    if extras:
        audit["extra_count"] = len(extras)
    by_key = {_key(s["name"]): s["name"] for s in row.suggestions}
    if aliases is None:
        chosen = ([] if extras
                  else [s["name"] for s in row.suggestions if not s.get("conflict")])
    else:
        chosen = []
        for raw in aliases:
            name = by_key.get(_key(str(raw)))
            if name is None:
                record_action("pult_hub_alias_decide", audit, "invalid", now=now)
                raise ValueError(
                    f"имя {str(raw)[:40]!r} не из предложений детектора для {row.hub_id}"
                )
            if name not in chosen:
                chosen.append(name)
    chosen_keys = {_key(c) for c in chosen}
    chosen += [e for e in extras if _key(e) not in chosen_keys]
    if not chosen:
        record_action("pult_hub_alias_decide", audit, "empty", now=now)
        raise ValueError("нечего записывать: нет ни выбранных предложений, ни своих вариантов")

    from core.operational.hub_link import HubLinkError, set_hub_aliases

    try:
        written = set_hub_aliases(row.hub_id, chosen, vault_path=Path(vault_path))
    except HubLinkError as exc:
        record_action("pult_hub_alias_decide", audit, "error", now=now)
        raise ValueError(f"алиасы не записаны: {exc}") from exc
    row.status = STATUS_APPLIED
    row.decided_at = stamp
    row.aliases_set = written["added"] or chosen
    queue.save()
    audit["count"] = len(written["added"])
    outcome = "set" if written["changed"] else "exists"
    record_action("pult_hub_alias_decide", audit, outcome, now=now)
    _emit_aliases_set(row.hub_id, written, now)
    extra_keys = {_key(e) for e in extras}
    return {
        "outcome": outcome,
        "hub_id": row.hub_id,
        "extra_added": [n for n in written["added"] if _key(n) in extra_keys],
        "added": written["added"],
        "aliases": written["aliases"],
        "changed": written["changed"],
        "path": written["path"],
    }


def _parse_stamp(value: str | None) -> datetime:
    if value:
        try:
            return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
        except ValueError:
            pass
    return datetime.now(UTC)


def _emit_aliases_set(hub_id: str, written: dict[str, Any], now: str | None) -> None:
    """Событие ``hub/aliases_set`` в журнале стадий (best-effort; в detail - только счетчик)."""
    try:
        from core.eventlog import emit

        emit("hub", "aliases_set", note_id=hub_id, path=Path(written["path"]).name,
             detail={"added": len(written["added"]), "changed": bool(written["changed"])},
             now=now)
    except Exception:  # noqa: BLE001, S110 — журнал не критичный путь
        pass
