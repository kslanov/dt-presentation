"""HUB-1 — детектор кандидатов в хабы + согласование с пульта.

Основание — D7-кейс «Надым»: пресейл шёл два месяца без хаба, сущность была
невидима для линковки и client_context. Разовая логика ``_candidates-for-hub``
(Phase 5) развёрнута в перезапускаемый анализ: детектор собирает кандидатов в
очередь, человек решает кнопкой на пульте, approve создаёт хаб существующей
scaffold-механикой. Кандидат ≠ автоматический хаб — только через решение К.

Источники сигналов (:func:`scan_hub_candidates`; только СВЕЖИЕ заметки —
mtime за последние N дней; correspondence в приоритете — новые сущности
появляются раньше всего в почте):

* частотные нерезолвящиеся имена: ``counterparties`` фронтматтера, фразы
  «Пресейл. X» и аббревиатуры из title (порог :data:`MIN_MENTIONS` упоминаний);
* ``counterparty_domains`` без клиентского хаба — ОБЫЧНЫЙ сигнал: порог
  :data:`MIN_MENTIONS` И минимум :data:`MIN_DOMAIN_DAYS` разных дней (волна
  одного треда сущности не рождает; HUB-CAND-1);
* сделки Timetta-зеркала без хаба с их ``timetta_id`` — сильный сигнал ТОЛЬКО для сделок кольца
  ``mine`` и «слежу» (SURFACE-HYGIENE-1, R4): сделка без хаба у своего ведущего - дыра в контуре.
  Сделка кольца ``unit`` (чужая в моем подразделении) идет обычным порогом
  :func:`_qualifies` по упоминаниям в
  заметках/почте (сама сделка упоминанием не считается), причина - в ``signals.ring``. Раньше любая
  видимая сделка была strong: 34 pending из 34 - чужие, точность решений 9%.

Персона кандидатом не бывает никогда (решение К., HUB-CAND-1): контрагент с
e-mail в строке — это человек, а не клиент; его упоминание уходит в счётчик
кандидата-ДОМЕНА его организации (три письма людей с ``@1c-perspective.ru`` —
один кандидат ``1c-perspective.ru``). Важные контакты К. заводит руками
(скилл ``new-entity-hub``). Фри-почта (:data:`FREE_MAIL_DOMAINS`) не кандидат
и не агрегат для персон.

Фильтры: существующий каталог (id + aliases кураторских хабов), стоп-лист
(разбор 2026-07-04: годы, орг-шум, re/fw-мусор), ранее отклонённые кандидаты —
``rejected``-строки очереди и есть стоп-журнал детектора, они не воскрешаются.
Сверка очереди (HUB-CAND-1): pending-строка, которая по нынешним правилам в
очередь бы не попала (персона, фри-почта, домен ниже порога или одного дня),
снимается статусом ``resolved`` на ближайшем скане. ``resolved`` ≠ ``rejected``:
это снятие сверкой, и если сигнал дорастёт до порога — строка вернётся в
``pending``. ``applied`` и ``rejected`` сверка не трогает.
Очередь ``.derived/hub_candidates.jsonl`` идемпотентна по детерминированному id
(sha1 от нормализованного имени): повторный прогон обновляет сигналы pending-
строки, а не плодит дубли — «не чаще раза в сутки» выполняется по построению.

Privacy: в сигналах — счётчики, даты и источники-ПУТИ (rel-path заметки /
``timetta:deal:<code>``), тексты писем в очередь не пишутся; имя кандидата —
сама предлагаемая сущность, это и есть карточка.

Инвариант: ``core/`` ⊥ mcp/cli; сети и LLM здесь нет (сделки зеркала передаёт
вызывающий). ``pult_hub_candidates`` / ``pult_hub_decide`` в server.py — тонкие
обёртки; шаг ``hub_scan`` в dt-sync full зовёт CLI ``dt_hub_scan``.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any

from core.legacy.linking import scaffold_hub
from core.legacy.render import slugify
from core.linking.engine import _curated_hubs
from core.linking.signals import signals_for_note
from core.metrics import record_event
from core.operational import orbit
from core.progress import ProgressBeacon
from core.vault import iter_vault_paths, read_note

__all__ = [
    "MIN_MENTIONS",
    "MIN_DOMAIN_DAYS",
    "FREE_MAIL_DOMAINS",
    "FRESH_DAYS",
    "HUB_ENTITIES",
    "STATUS_PENDING",
    "STATUS_APPLIED",
    "STATUS_REJECTED",
    "STATUS_RESOLVED",
    "REASON_RING_UNIT",
    "HubCandidate",
    "HubCandidateQueue",
    "HubScanResult",
    "candidate_id",
    "scan_hub_candidates",
    "decide_hub_candidate",
]

# Обычный кандидат (counterparty/фраза/аббревиатура/домен) попадает в очередь
# после стольких упоминаний в свежих заметках; сильный сигнал (сделка зеркала
# без хаба) порог обходит — ему хватает одного.
MIN_MENTIONS = 3

# Домену вдобавок нужно столько РАЗНЫХ дней упоминаний (HUB-CAND-1): десяток
# писем одного треда за час — это тред, а не новая сущность в контуре.
MIN_DOMAIN_DAYS = 2

# «Свежие» заметки: mtime за последние N дней.
FRESH_DAYS = 14

# Сущности, которые пульт может выбрать при approve (папка скаффолда — в
# core.legacy.linking._HUB_FOLDERS).
HUB_ENTITIES = ("client", "product", "project", "direction", "industry")

STATUS_PENDING = "pending"
STATUS_APPLIED = "applied"
STATUS_REJECTED = "rejected"
# Снят сверкой очереди (HUB-CAND-1): по нынешним правилам кандидатом не был бы.
# Не стоп-журнал — доросший до порога сигнал возвращает строку в pending.
STATUS_RESOLVED = "resolved"
# Причина снятия сверкой «чужая сделка кольца unit без упоминаний» (SURFACE-HYGIENE-1): К. её не
# решал, строка обратима (сигнал дорос - вернется в pending).
REASON_RING_UNIT = "ring_unit"

# Стоп-лист из разбора кандидатов 2026-07-04: организационно-правовой шум,
# re/fw-мусор тем, частые аббревиатуры-неструктуры. Сравнение по casefold.
STOP_WORDS = frozenset({
    "ооо", "ао", "пао", "зао", "оао", "нко", "гк", "ип", "тоо",
    "ltd", "llc", "inc", "gmbh", "co", "jsc",
    "re", "fw", "fwd", "тз", "кп", "ндс", "рф", "спб", "мск", "фио",
})
_YEAR_RE = re.compile(r"^(19|20)\d{2}$")

# Фри-почта: домен публичного почтовика — не организация. Кандидатом не бывает
# и агрегатом упоминаний персон тоже (иначе «gmail.com» соберёт полкорпуса).
# Правится в коде — это канон, а не настройка (ТЗ HUB-CAND-1, «не входит»).
FREE_MAIL_DOMAINS = frozenset({
    "gmail.com", "googlemail.com",
    "mail.ru", "inbox.ru", "bk.ru", "list.ru", "internet.ru",
    "yandex.ru", "yandex.com", "ya.ru", "yandex.kz",
    "outlook.com", "hotmail.com", "live.com", "msn.com",
    "icloud.com", "me.com", "mac.com",
    "yahoo.com", "proton.me", "protonmail.com", "aol.com",
    "rambler.ru", "qq.com", "163.com",
})

# Домен-имя: «b5g.ru», «1c-perspective.ru» (латиница/цифры, точка, TLD).
# Кириллица и пробелы не проходят — «ЦД Надым» доменом не считается.
_DOMAIN_RE = re.compile(
    r"^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9-]+)*\.[a-z]{2,}$"
)

# Домен e-mail'а из строки контрагента («Имя <a@dom.ru>» / «a@dom.ru»).
_EMAIL_DOMAIN_RE = re.compile(r"@([A-Za-z0-9.-]+)")

# «Пресейл. X» / «Пресейл: X» / «Presale — X» в заголовке (X — имя кандидата).
_PRESALE_RE = re.compile(r"(?:пресейл|presale)\s*[.:—–-]\s*(.{2,60})", re.IGNORECASE)

# Аббревиатуры в заголовке: 2–6 заглавных (кириллица/латиница), опц. -суффикс.
_ABBR_RE = re.compile(r"(?<!\w)[А-ЯЁA-Z]{2,6}(?:-[А-ЯЁA-Z\d]{1,6})?(?!\w)")

# Ведущий орг-префикс контрагента («ООО "Ромашка"» → «Ромашка»).
_ORG_PREFIX_RE = re.compile(
    r"^(?:ооо|ао|пао|зао|оао|нко|гк|ип|тоо)\s+", re.IGNORECASE
)


def _fold(text: str) -> str:
    return str(text).casefold().strip()


def candidate_id(name: str) -> str:
    """Детерминированный 12-hex id по нормализованному имени (без часов/random)."""
    return hashlib.sha1(  # noqa: S324 — id, not crypto
        f"hub:{_fold(name)}".encode()
    ).hexdigest()[:12]


@dataclass
class HubCandidate:
    """Одна строка очереди кандидатов (см. форму в ТЗ HUB-1)."""

    id: str
    name: str
    suggested_hub_id: str
    entity_guess: str
    mentions: int = 0
    days_active: int = 0
    sources: list[str] = field(default_factory=list)
    status: str = STATUS_PENDING
    created: str | None = None
    decided_at: str | None = None
    hub_id: str | None = None  # фактический id созданного хаба (approve)
    # SURFACE-HYGIENE-1: кольцо и ведущий сделки-источника (None - кандидат не от сделки) и причина
    # снятия сверкой (``ring_unit``); в строке очереди ``ring``/``leader`` лежат в ``signals``.
    ring: str | None = None
    leader: str | None = None
    reason: str | None = None

    def to_row(self) -> dict[str, Any]:
        row = asdict(self)
        # ТЗ-форма: сигналы — вложенным объектом.
        row["signals"] = {
            "mentions": row.pop("mentions"),
            "days_active": row.pop("days_active"),
            "sources": row.pop("sources"),
        }
        for key in ("ring", "leader"):
            value = row.pop(key)
            if value is not None:
                row["signals"][key] = value
        return {k: v for k, v in row.items() if v is not None}

    @classmethod
    def from_row(cls, row: dict[str, Any]) -> HubCandidate:
        signals = row.get("signals") or {}
        return cls(
            id=str(row.get("id") or ""),
            name=str(row.get("name") or ""),
            suggested_hub_id=str(row.get("suggested_hub_id") or ""),
            entity_guess=str(row.get("entity_guess") or "client"),
            mentions=int(signals.get("mentions") or 0),
            days_active=int(signals.get("days_active") or 0),
            sources=[str(s) for s in (signals.get("sources") or [])],
            status=str(row.get("status") or STATUS_PENDING),
            created=row.get("created"),
            decided_at=row.get("decided_at"),
            hub_id=row.get("hub_id"),
            ring=(str(signals["ring"]) if signals.get("ring") else None),
            leader=(str(signals["leader"]) if signals.get("leader") else None),
            reason=(str(row["reason"]) if row.get("reason") else None),
        )


@dataclass
class HubCandidateQueue:
    """Очередь ``.derived/hub_candidates.jsonl``, keyed by id (без сети)."""

    by_id: dict[str, HubCandidate] = field(default_factory=dict)
    path: Path | None = None

    @classmethod
    def load(cls, path: Path) -> HubCandidateQueue:
        path = Path(path)
        by_id: dict[str, HubCandidate] = {}
        if path.is_file():
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue  # повреждённая строка — очередь перестраиваемая
                if isinstance(row, dict) and row.get("id"):
                    cand = HubCandidate.from_row(row)
                    by_id[cand.id] = cand
        return cls(by_id=by_id, path=path)

    def pending(self) -> list[HubCandidate]:
        return [c for c in self.by_id.values() if c.status == STATUS_PENDING]

    def save(self, path: Path | None = None) -> Path:
        chosen = Path(path or self.path or "")
        if not str(chosen):
            raise ValueError("HubCandidateQueue.save needs a path")
        chosen.parent.mkdir(parents=True, exist_ok=True)
        rows = sorted(self.by_id.values(), key=lambda c: (c.created or "", c.id))
        body = "\n".join(json.dumps(c.to_row(), ensure_ascii=False) for c in rows)
        tmp = chosen.with_suffix(chosen.suffix + ".tmp")
        tmp.write_text(body + ("\n" if body else ""), encoding="utf-8")
        tmp.replace(chosen)
        return chosen


@dataclass
class HubScanResult:
    """Анонимная сводка прогона детектора — только счётчики."""

    fresh_notes: int = 0
    skipped_stale: int = 0  # заметка свежая по mtime, но авторская дата старая (mtime-trap)
    raw_names: int = 0  # извлечённых имён до фильтров
    skipped_catalog: int = 0
    skipped_stopped: int = 0  # стоп-лист/годы/мусор
    skipped_rejected: int = 0  # ранее отклонённые (стоп-журнал очереди)
    skipped_person: int = 0  # контрагент-человек — в агрегат домена, не в очередь
    skipped_free_mail: int = 0  # gmail/mail.ru и прочая фри-почта
    below_threshold: int = 0
    deals_without_hub: int = 0
    added: int = 0
    updated: int = 0
    revived: int = 0  # снятый сверкой дорос до порога — вернулся в pending
    reconciled: int = 0  # pending, не проходящий нынешние правила — снят (resolved)
    pruned: int = 0  # pending, не найденные в этом полнокорпусном прогоне — сняты
    deals_strong: int = 0  # сделки без хаба кольца mine/«слежу»: strong, порогов не знают
    deals_ring_unit: int = 0  # сделки без хаба кольца unit/group: обычный порог (R4)
    ring_unit_resolved: int = 0  # pending от чужой сделки без упоминаний → resolved/ring_unit


# Авторская дата заметки (когда создан её смысл), устойчивая к правкам «## Связано».
# mtime не годится: линковочная волна переписывает хвост во ВСЕХ заметках → все
# «свежие», и детектор сканирует весь корпус (mtime-trap, 1000+ ложных кандидатов).
_DATE_KEYS = ("created", "date", "last_date", "captured")
_FN_DATE_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})")


def _parse_day(value: Any) -> date | None:
    s = str(value or "").strip()[:10]
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        return None


def _authored_date(note: Any, path: Path) -> date | None:
    """Дата создания смысла заметки: frontmatter (created/date/…) или префикс имени."""
    fm = getattr(note, "frontmatter", None) or {}
    for k in _DATE_KEYS:
        d = _parse_day(fm.get(k))
        if d is not None:
            return d
    m = _FN_DATE_RE.match(path.stem)
    return _parse_day(m.group(1)) if m else None


def _stopped(name: str) -> bool:
    folded = _fold(name)
    if len(folded) < 2 or folded.isdigit() or _YEAR_RE.match(folded):
        return True
    return folded in STOP_WORDS


def _is_person(raw: str) -> bool:
    """Контрагент-ЧЕЛОВЕК: в строке есть e-mail («Anton O. <a@dom.ru>»).

    Решение К. (HUB-CAND-1): персона кандидатом в хабы не бывает ни при каком
    числе упоминаний — важные контакты заводятся руками. Упоминание такой
    строки уходит в счётчик домена её организации (:func:`_email_domain`).
    """
    return "@" in str(raw or "")


def _email_domain(raw: str) -> str:
    """Домен организации из строки контрагента; пусто — если адреса нет."""
    m = _EMAIL_DOMAIN_RE.search(str(raw or ""))
    return m.group(1).casefold().strip(".") if m else ""


def _is_domain(name: str) -> bool:
    """Имя кандидата — это домен (к нему применяется порог по дням)."""
    return bool(_DOMAIN_RE.match(_fold(name)))


def _is_free_mail(domain: str) -> bool:
    """Домен публичного почтовика (сам или его поддомен) — не сущность."""
    dom = _fold(domain)
    return any(dom == f or dom.endswith("." + f) for f in FREE_MAIL_DOMAINS)


def _qualifies(name: str, mentions: int, days: int) -> bool:
    """Проходит ли ОБЫЧНЫЙ (не-strong) сигнал в очередь.

    Текстовое имя — по :data:`MIN_MENTIONS`; домен — ещё и по
    :data:`MIN_DOMAIN_DAYS` разным дням (волна одного треда хаб не рождает).
    """
    if mentions < MIN_MENTIONS:
        return False
    return days >= MIN_DOMAIN_DAYS if _is_domain(name) else True


def _clean_counterparty(raw: str) -> str:
    """«ООО "Ромашка"» → «Ромашка»: орг-префикс и кавычки — не часть имени."""
    name = str(raw).strip().strip("«»\"'“”")
    name = _ORG_PREFIX_RE.sub("", name).strip().strip("«»\"'“”")
    return name


def _title_names(title: str) -> list[tuple[str, str]]:
    """(имя, entity_guess) из заголовка: пресейл-фразы + аббревиатуры.

    Аббревиатура, входящая в уже извлечённую пресейл-фразу, не считается
    отдельно («Пресейл. ЦД Надым» — один кандидат «ЦД Надым», не два).
    """
    out: list[tuple[str, str]] = []
    phrases: list[str] = []
    for m in _PRESALE_RE.finditer(title or ""):
        phrase = m.group(1).strip().strip(".,;:!?«»\"'")
        if phrase:
            phrases.append(phrase)
            out.append((phrase, "project"))
    for m in _ABBR_RE.finditer(title or ""):
        token = m.group(0)
        if any(token in phrase for phrase in phrases):
            continue
        out.append((token, "client"))
    return out


def _reconcile_pending(queue: HubCandidateQueue, stamp: str) -> int:
    """Снять pending-строки, не проходящие нынешние правила. Возвращает число снятых.

    Кейс скриншота К. (HUB-CAND-1): в «Требуют решения» висят персональные
    адреса и голые домены с одним упоминанием, заведённые прежними правилами.
    Правила поменялись — очередь должна это увидеть сама, без ручной чистки.
    Снимаются только персоны, фри-почта и домены ниже порога/одного дня;
    кандидат от сделки зеркала (сильный сигнал) неприкосновенен, как и
    ``applied``/``rejected``.
    """
    swept = 0
    for row in queue.by_id.values():
        if row.status != STATUS_PENDING:
            continue
        if any(s.startswith("timetta:deal:") for s in row.sources):
            continue  # сделка без хаба — сильный сигнал, порогов не знает
        if _is_person(row.name):
            stale = True
        elif _is_domain(row.name):
            stale = _is_free_mail(row.name) or not _qualifies(
                row.name, row.mentions, row.days_active
            )
        else:
            stale = False  # текстовые имена правилами HUB-CAND-1 не тронуты
        if stale:
            row.status = STATUS_RESOLVED
            row.decided_at = stamp
            swept += 1
    return swept


def _deal_hit(
    deal: Any, timetta_ids: set[str], today: str, hit: Any, result: HubScanResult
) -> None:
    """Сделка зеркала без хаба → сигнал. R4: strong - только свои сделки и «слежу»; чужая (unit) -
    обычный порог по упоминаниям (сама сделка упоминанием не считается: ``weight=0``)."""
    if not isinstance(deal, dict) or not deal.get("is_active", True):
        return
    guid = _fold(str(deal.get("id") or ""))
    name = str(deal.get("name") or "").strip()
    if not name or (guid and guid in timetta_ids):
        return
    result.deals_without_hub += 1
    code = str(deal.get("code") or "")[:24]
    strong = orbit.ring(deal) == orbit.RING_MINE or orbit.is_watched(deal)
    if strong:
        result.deals_strong += 1
    else:
        result.deals_ring_unit += 1
    hit(name, "project", f"timetta:deal:{code}", today, strong=strong,
        weight=1 if strong else 0, deal=deal)


def _resolve_ring_unit(
    queue: HubCandidateQueue, agg: dict[str, Any], stamp: str, seen_cids: set[str],
    result: HubScanResult,
) -> None:
    """Миграция R4: висящий pending от чужой сделки без упоминаний - снять сверкой.

    ``resolved`` + ``reason: ring_unit`` (не ``rejected``: К. не решал; сигнал дорастет - строка
    вернется в pending). Принятое/отклоненное не трогается; снятая в самоочистку не попадает."""
    prev = queue.by_id.get(candidate_id(agg["name"]))
    if prev is None:
        return
    seen_cids.add(prev.id)
    if prev.status == STATUS_PENDING:
        prev.status = STATUS_RESOLVED
        prev.reason = REASON_RING_UNIT
        prev.decided_at = stamp
        prev.ring, prev.leader = agg["ring"], agg["leader"]
        result.ring_unit_resolved += 1


def scan_hub_candidates(
    vault_path: Path,
    *,
    queue: HubCandidateQueue,
    deals: list[dict[str, Any]] | None = None,
    days: int = FRESH_DAYS,
    now: datetime | None = None,
) -> HubScanResult:
    """Собрать кандидатов в хабы из свежих заметок + сделок зеркала. См. док.

    Лёгкий по построению: пути обходятся stat'ом, парсятся ТОЛЬКО свежие
    заметки (mtime в окне ``days``) и кураторские хабы (каталог). Ведёт маяк
    ACT-1 (``hub_scan``). Очередь мутируется in-memory и сохраняется одним
    save() в конце (upsert по id; rejected/applied не трогаются). В конце —
    сверка pending по нынешним правилам (:func:`_reconcile_pending`).
    """
    vault_path = Path(vault_path)
    now_dt = now or datetime.now(UTC)
    cutoff = (now_dt - timedelta(days=max(1, days))).timestamp()
    cutoff_date = (now_dt - timedelta(days=max(1, days))).date()
    result = HubScanResult()

    fresh: list[tuple[Path, float]] = []
    for path in iter_vault_paths(vault_path):
        try:
            mtime = path.stat().st_mtime
        except OSError:
            continue
        if mtime >= cutoff:
            fresh.append((path, mtime))
    result.fresh_notes = len(fresh)

    beacon = ProgressBeacon("hub_scan", len(fresh), emit=lambda _l: None)
    beacon.phase("scan")

    # Каталог: id + aliases кураторских хабов (хабы не живут в _legacy) + их
    # timetta_id — для проверки «у сделки уже есть хаб».
    known: set[str] = set()
    timetta_ids: set[str] = set()
    for hub in _curated_hubs(vault_path):
        known.add(_fold(hub.id))
        for alias in hub.frontmatter.get("aliases") or []:
            known.add(_fold(alias))
        tid = hub.frontmatter.get("timetta_id")
        if isinstance(tid, str) and tid.strip():
            timetta_ids.add(_fold(tid))

    # folded-имя → агрегат сигналов этого прогона.
    seen: dict[str, dict[str, Any]] = {}

    def _hit(
        raw_name: str, guess: str, source: str, day: str, *, strong: bool,
        weight: int = 1, deal: dict[str, Any] | None = None,
    ) -> None:
        result.raw_names += 1
        name = raw_name.strip()
        if _stopped(name):
            result.skipped_stopped += 1
            return
        key = _fold(name)
        if key in known:
            result.skipped_catalog += 1
            return
        agg = seen.setdefault(
            key,
            {"name": name, "guess": guess, "mentions": 0, "days": set(),
             "sources": [], "strong": False, "ring": None, "leader": None, "from_deal": False},
        )
        # weight=0: чужая сделка (unit) - источник и кольцо учитываем, упоминанием не считаем
        agg["mentions"] += weight
        if weight:
            agg["days"].add(day)
        if source not in agg["sources"]:
            agg["sources"].append(source)
        agg["strong"] = agg["strong"] or strong
        if deal is not None:
            agg["from_deal"] = True
            agg["ring"] = orbit.ring(deal)
            badge = orbit.leader_badge(deal)
            agg["leader"] = (badge or {}).get("leader") or agg["leader"]

    for done, (path, mtime) in enumerate(fresh):
        beacon.update(done)
        try:
            note = read_note(path)
        except Exception:  # noqa: BLE001, S112 — битая заметка не роняет скан
            continue
        if note.type == "hub":
            continue
        # Свежесть по АВТОРСКОЙ дате, а не mtime: у заметки с известной датой
        # старше окна кандидатов не берём (иначе линковочная волна тащит весь
        # корпус). Датированности нет → доверяем mtime-гейту (заметка уже прошла).
        adate = _authored_date(note, path)
        if adate is not None and adate < cutoff_date:
            result.skipped_stale += 1
            continue
        rel = path.relative_to(vault_path).as_posix()
        day = adate.isoformat() if adate is not None else datetime.fromtimestamp(
            mtime, UTC
        ).strftime("%Y-%m-%d")
        sig = signals_for_note(note)
        # Домены заметки собираем в один набор: и объявленные
        # ``counterparty_domains``, и домены персон-контрагентов. Набор, а не
        # список: пять человек из одной компании в одном письме — ОДНО
        # упоминание домена, иначе заголовок карточки врёт (ТЗ п.5).
        raw_domains: list[str] = []
        for cp in sig.counterparties:
            if _is_person(cp):
                # Решение К.: персона в очередь не попадает никогда — её
                # упоминание идёт в счётчик домена организации.
                result.raw_names += 1
                result.skipped_person += 1
                raw_domains.append(_email_domain(cp))
                continue
            _hit(_clean_counterparty(cp), "client", rel, day, strong=False)
        for name, guess in _title_names(sig.title):
            _hit(name, guess, rel, day, strong=False)
        raw_domains.extend(_fold(d) for d in sig.counterparty_domains)
        note_domains: list[str] = []
        for dom in raw_domains:
            if dom and dom not in note_domains:
                note_domains.append(dom)
        for dom in note_domains:
            if _is_free_mail(dom):
                result.raw_names += 1
                result.skipped_free_mail += 1
                continue
            # Домен — обычный сигнал: порог по упоминаниям И по дням.
            _hit(dom, "client", rel, day, strong=False)

    today = now_dt.strftime("%Y-%m-%d")
    for deal in deals or []:
        _deal_hit(deal, timetta_ids, today, _hit, result)

    stamp = now_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    seen_cids: set[str] = set()
    for agg in seen.values():
        if not agg["strong"] and not _qualifies(
            agg["name"], agg["mentions"], len(agg["days"])
        ):
            result.below_threshold += 1
            if agg["from_deal"]:
                _resolve_ring_unit(queue, agg, stamp, seen_cids, result)
            continue
        cid = candidate_id(agg["name"])
        seen_cids.add(cid)
        existing = queue.by_id.get(cid)
        if existing is not None and existing.status == STATUS_REJECTED:
            result.skipped_rejected += 1  # стоп-журнал: отклонённое не воскресает
            continue
        if existing is not None and existing.status == STATUS_APPLIED:
            continue  # хаб уже создан этим механизмом
        if existing is None:
            queue.by_id[cid] = HubCandidate(
                id=cid,
                name=agg["name"],
                suggested_hub_id=f"{agg['guess']}-{slugify(agg['name'])}",
                entity_guess=agg["guess"],
                mentions=agg["mentions"],
                days_active=len(agg["days"]),
                sources=agg["sources"][:10],
                created=stamp,
                ring=agg["ring"],
                leader=agg["leader"],
            )
            result.added += 1
        else:
            existing.mentions = agg["mentions"]
            existing.days_active = len(agg["days"])
            existing.sources = agg["sources"][:10]
            if agg["from_deal"]:
                existing.ring, existing.leader = agg["ring"], agg["leader"]
            if existing.status == STATUS_RESOLVED:
                # Снятое сверкой — не отклонённое: сигнал дорос, строка
                # возвращается человеку на решение.
                existing.status = STATUS_PENDING
                existing.decided_at = None
                existing.reason = None
                result.revived += 1
            result.updated += 1

    # Сверка очереди по нынешним правилам (HUB-CAND-1): висящий pending, который
    # сегодня кандидатом бы не стал (персона, фри-почта, домен ниже порога или
    # одного дня), снимается статусом resolved. Идёт ПОСЛЕ upsert — чтобы судить
    # по свежим счётчикам, а не по вчерашним. Rejected/applied не трогаем.
    result.reconciled = _reconcile_pending(queue, stamp)

    # Самоочистка: pending-кандидат, не найденный в этом (полнокорпусном) прогоне,
    # устарел — снимаем. Только если прогон реально что-то отсканировал (fresh>0),
    # чтобы пустой/сбойный проход не обнулил очередь. Rejected/applied не трогаем.
    if result.fresh_notes:
        for pid in [
            c.id for c in queue.by_id.values()
            if c.status == STATUS_PENDING and c.id not in seen_cids
        ]:
            del queue.by_id[pid]
            result.pruned += 1
    if (result.added or result.updated or result.pruned or result.reconciled
            or result.ring_unit_resolved):
        queue.save()
    beacon.update(
        len(fresh),
        {"added": result.added, "updated": result.updated,
         "reconciled": result.reconciled, "pruned": result.pruned},
    )
    beacon.done(
        f"fresh {result.fresh_notes}, added {result.added}, updated {result.updated}"
    )
    return result


# --------------------------------------------------------------------------- #
# Решение с пульта                                                             #
# --------------------------------------------------------------------------- #
_RESCAN_REMINDER = (
    "Новый хаб станет виден линковке после rescan: "
    "uv run python cli/dt_link.py --resolver deterministic --scope all "
    "--rescan --auto --apply (steady-state link_auto без rescan его не увидит)."
)


def decide_hub_candidate(
    cid: str,
    decision: str,
    entity: str | None = None,
    *,
    queue: HubCandidateQueue,
    vault_path: Path,
    now: str | None = None,
) -> dict[str, Any]:
    """Решение по кандидату: approve → хаб скаффолдом, reject → навсегда.

    approve создаёт хаб существующей scaffold-механикой
    (:func:`core.legacy.linking.scaffold_hub` — правильный frontmatter
    ``type: hub`` + ``entity`` из решения + имя кандидата как alias);
    существующий файл не трогается (идемпотентно). reject помечает строку
    ``rejected`` — это стоп-журнал детектора, кандидат больше не предлагается.
    Аудит в pult-actions.log (имя/entity — сама сущность решения, тексты
    заметок не пишутся); metrics — kind ``hub_decision``.
    """
    from core.operational.pult import record_action

    if decision not in ("approve", "reject"):
        raise ValueError(
            f"unsupported decision {decision!r}; use 'approve' or 'reject'"
        )
    audit_params: dict[str, Any] = {"candidate_id": cid, "decision": decision}

    row = queue.by_id.get(cid)
    if row is None:
        record_action("pult_hub_decide", audit_params, "not_found", now=now)
        raise ValueError(f"Кандидат …{cid[-4:]} не найден в очереди кандидатов.")
    if row.status != STATUS_PENDING:
        record_action("pult_hub_decide", audit_params, "stale", now=now)
        why = (
            "снят сверкой очереди (нынешним правилам не отвечает)"
            if row.status == STATUS_RESOLVED
            else f"уже решён ({row.status})"
        )
        return {
            "outcome": "stale",
            "candidate_id": cid,
            "explanation": f"Кандидат {why} — повторное решение не требуется.",
        }

    stamp = now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")

    if decision == "reject":
        row.status = STATUS_REJECTED
        row.decided_at = stamp
        queue.save()
        record_event("hub_decision", decision="rejected", entity=row.entity_guess)
        record_action("pult_hub_decide", audit_params, "rejected", now=now)
        return {
            "outcome": "rejected",
            "candidate_id": cid,
            "name": row.name,
            "explanation": "Отклонено навсегда — детектор больше не предложит "
            "этого кандидата (стоп-журнал).",
        }

    ent = (entity or row.entity_guess or "client").strip()
    if ent not in HUB_ENTITIES:
        raise ValueError(
            f"unsupported entity {ent!r}; use {' | '.join(HUB_ENTITIES)}"
        )
    audit_params["entity"] = ent
    path, created = scaffold_hub(Path(vault_path), row.name, entity=ent)
    hub_id = f"{ent}-{slugify(row.name)}"
    row.status = STATUS_APPLIED
    row.decided_at = stamp
    row.hub_id = hub_id
    queue.save()
    record_event("hub_decision", decision="approved", entity=ent)
    record_action(
        "pult_hub_decide", audit_params, "created" if created else "exists", now=now
    )
    return {
        "outcome": "created" if created else "exists",
        "candidate_id": cid,
        "name": row.name,
        "entity": ent,
        "hub_id": hub_id,
        "hub_path": str(path),
        "reminder": _RESCAN_REMINDER,
    }
