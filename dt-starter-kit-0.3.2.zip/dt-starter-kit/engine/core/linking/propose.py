"""Phase 6, stage 2 — semantic link proposals + review queue.

Turns the deterministic candidates from :mod:`core.linking.candidates` into
durable, deduplicated :class:`LinkProposal` rows in a human-in-the-loop review
queue (``.derived/link_proposals.jsonl``). Nothing is written into any note here
— a proposal is *applied* only after review (stage 3).

Three pieces:

* :class:`LinkProposal` — one suggested ``source → target`` link, with the cosine
  ``score``, the target's ``type``, the ``evidence_snippet`` that justified it, and
  an optional ``rationale`` (a deterministic one by default; an LLM-written one if
  the assemble-only path below is used).
* :class:`LinkProposalQueue` — the JSONL store, keyed by a deterministic
  ``source → target`` id so re-proposing the same pair never duplicates a row
  (idempotent read/write).
* :func:`propose_for_notes` — generate candidates for source notes and enqueue the
  new ones, dropping any that are already linked (handled upstream in
  :func:`~core.linking.candidates.candidates_for_note`) or already proposed.

Optional LLM ranking is **assemble-only** (like :mod:`core.generation`): this
module can *build* a "is A→B a meaningful link?" prompt, but the engine never
calls an LLM — the call happens in Cowork (Path B) and the verdict is fed back as
a ``rationale`` / a reject. Off by default; deterministic candidates suffice.
"""

from __future__ import annotations

import hashlib
import json
import time
from collections.abc import Callable, Iterable
from dataclasses import asdict, dataclass, field
from pathlib import Path

from core.config import link_proposals_path
from core.linking.candidates import LinkCandidate, candidates_for_note, existing_link_targets
from core.vault import Note, iter_vault

__all__ = [
    "STATUS_PENDING",
    "STATUS_APPROVED",
    "STATUS_APPLIED",
    "STATUS_REJECTED",
    "STATUS_STALE",
    "STATUS_REVOKED",
    "LinkProposal",
    "LinkProposalQueue",
    "ProposeResult",
    "proposal_id",
    "propose_for_notes",
    "iter_isolates",
    "is_linkable_source",
    "select_sources",
    "assemble_link_prompt",
]

STATUS_PENDING = "pending"
STATUS_APPROVED = "approved"
STATUS_APPLIED = "applied"
STATUS_REJECTED = "rejected"
# RECONCILE-1: pending-предложение, чья заметка source/target удалена из vault →
# снимается из ленты этим статусом (лента показывает только pending). Отличается
# от rejected (осознанное «нет» человека): stale = «источник исчез». Не
# hard-delete — строка остаётся для аудита.
STATUS_STALE = "stale"
# MAIL-THREAD-1: связь отозвана — выведена из замусоренных метаданных треда (сдвиг
# массивов моста), которые ремонт корпуса исправил; по чистым доменам её быть не должно.
# Отличается от rejected (решение человека) и stale (источник исчез). Строка остаётся.
STATUS_REVOKED = "revoked"

# Meta / navigation notes that are never linking *sources* (stage-2 review fix A):
# the generated folder MOCs (``type: legacy-index`` — our ``_index.md``) and the
# hub-candidates report are navigation scaffolding, not content, so their nearest
# neighbours are noise. They remain valid *targets* if curated; only excluded as
# sources.
_META_SOURCE_TYPES = frozenset({"legacy-index"})
_META_SOURCE_IDS = frozenset({"legacy-candidates-for-hub"})


def is_linkable_source(note: Note) -> bool:
    """Whether ``note`` may be a linking *source* (excludes meta/index notes).

    The folder MOCs (``type: legacy-index``) and the hub-candidates report are
    navigation, not content — linking *from* them produces noise (stage-2 fix A).
    """
    return note.type not in _META_SOURCE_TYPES and note.id not in _META_SOURCE_IDS


def proposal_id(source_note: str, target_note: str) -> str:
    """Deterministic 12-hex id for a ``source → target`` link pair.

    Deterministic so re-proposing the same pair yields the same id — the queue is
    then naturally idempotent (same row, no clock/random needed for tests).
    """
    seed = f"{source_note.strip()}→{target_note.strip()}"
    return hashlib.sha1(seed.encode("utf-8")).hexdigest()[:12]  # noqa: S324 — id, not crypto


@dataclass
class LinkProposal:
    """One suggested link, awaiting review.

    ``resolver`` names the layer that produced the row (Phase 9): ``semantic``
    (embedding similarity, the Phase-6 default — pre-Phase-9 queue rows carry no
    field and load as such) or ``deterministic`` (exact catalog match, score 1.0
    by construction). Review tooling filters/thresholds per resolver.
    """

    id: str
    source_note: str
    target_note: str
    score: float
    target_type: str
    evidence_snippet: str
    rationale: str = ""
    status: str = STATUS_PENDING
    resolver: str = "semantic"

    @classmethod
    def from_candidate(cls, candidate: LinkCandidate, *, rationale: str = "") -> LinkProposal:
        return cls(
            id=proposal_id(candidate.source_note, candidate.target_note),
            source_note=candidate.source_note,
            target_note=candidate.target_note,
            score=round(float(candidate.score), 6),
            target_type=candidate.target_type,
            evidence_snippet=candidate.evidence_snippet,
            rationale=rationale,
        )


def default_rationale(candidate: LinkCandidate) -> str:
    """A deterministic, LLM-free rationale (provenance: similarity + evidence)."""
    kind = candidate.target_type or "note"
    snippet = candidate.evidence_snippet.strip().replace("\n", " ")
    if len(snippet) > 160:
        snippet = snippet[:157].rstrip() + "…"
    return f"семантическая близость {candidate.score:.2f} ({kind}); фрагмент цели: «{snippet}»"


# --------------------------------------------------------------------------- #
# Queue — .derived/link_proposals.jsonl                                        #
# --------------------------------------------------------------------------- #


@dataclass
class LinkProposalQueue:
    """The ``link_proposals.jsonl`` store, keyed by ``id`` (no network, no LLM).

    One JSON object per line. Loaded into an id-keyed dict so :meth:`add` is
    idempotent (a pair already present is left untouched, preserving its status),
    and :meth:`save` rewrites the file deduplicated and order-stable.
    """

    by_id: dict[str, LinkProposal] = field(default_factory=dict)
    path: Path | None = None

    @classmethod
    def load(cls, path: Path | None = None) -> LinkProposalQueue:
        path = Path(path) if path is not None else link_proposals_path()
        by_id: dict[str, LinkProposal] = {}
        if path.is_file():
            for line in path.read_text(encoding="utf-8").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue  # tolerate a partial/corrupt line — rebuildable cache
                if not isinstance(row, dict) or "id" not in row:
                    continue
                proposal = LinkProposal(
                    id=str(row["id"]),
                    source_note=str(row.get("source_note", row.get("source", ""))),
                    target_note=str(row.get("target_note", row.get("target", ""))),
                    score=float(row.get("score", 0.0)),
                    target_type=str(row.get("target_type", "")),
                    evidence_snippet=str(row.get("evidence_snippet", row.get("evidence", ""))),
                    rationale=str(row.get("rationale", "")),
                    status=str(row.get("status", STATUS_PENDING)),
                    resolver=str(row.get("resolver", "semantic")),
                )
                by_id[proposal.id] = proposal
        return cls(by_id=by_id, path=path)

    def add(self, proposal: LinkProposal) -> bool:
        """Insert a proposal if its pair is new. Returns ``True`` iff it was added.

        An existing id (same ``source → target``) is left untouched — its status
        (incl. an earlier approve/reject) is never clobbered by a re-propose.
        """
        if proposal.id in self.by_id:
            return False
        self.by_id[proposal.id] = proposal
        return True

    def pending(self) -> list[LinkProposal]:
        return [p for p in self.by_id.values() if p.status == STATUS_PENDING]

    def save(self, path: Path | None = None) -> Path:
        chosen = path if path is not None else self.path
        if chosen is None:
            raise ValueError("LinkProposalQueue.save needs a path")
        chosen = Path(chosen)
        chosen.parent.mkdir(parents=True, exist_ok=True)
        # Stable order (source, then target) so diffs are reviewable; atomic write.
        rows = sorted(self.by_id.values(), key=lambda p: (p.source_note, p.target_note))
        body = "\n".join(json.dumps(asdict(p), ensure_ascii=False) for p in rows)
        tmp = chosen.with_suffix(chosen.suffix + ".tmp")
        tmp.write_text(body + ("\n" if body else ""), encoding="utf-8")
        tmp.replace(chosen)
        return chosen


# --------------------------------------------------------------------------- #
# Propose                                                                      #
# --------------------------------------------------------------------------- #


@dataclass
class ProposeResult:
    """Summary of a :func:`propose_for_notes` run (counts + the new proposals)."""

    sources: int = 0  # source notes actually processed (candidates generated)
    skipped_sources: int = 0  # meta/index notes skipped as sources (fix A)
    resumed_skipped: int = 0  # sources already in the queue, skipped on resume
    candidates: int = 0  # candidates generated across all sources
    added: int = 0  # new proposals enqueued
    duplicates: int = 0  # candidates already in the queue (skipped, idempotent)
    proposals: list[LinkProposal] = field(default_factory=list)  # the newly added ones


def _append_proposal(path: Path, proposal: LinkProposal) -> None:
    """Append one proposal as a JSONL line — incremental, crash-durable persistence.

    Writes *as the run proceeds* (per new proposal) rather than one dump at the end,
    so a long propose survives a kill/sleep with every completed isolate retained.
    The line format matches :meth:`LinkProposalQueue.save`, so a later ``load`` (with
    its id-dedup) reads an append-grown file identically to a saved one.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(asdict(proposal), ensure_ascii=False) + "\n")


def _progress_line(seen: int, total: int, proposals: int, start: float) -> str:
    """A single ``tail -f``-friendly progress line with a rough ETA."""
    elapsed = time.perf_counter() - start
    where = f"{seen}/{total}" if total else f"{seen}"
    eta = ""
    if total and seen and elapsed > 0:
        rate = seen / elapsed
        if rate > 0:
            eta = f" | ~{int((total - seen) / rate)}s eta"
    return (
        f"[propose] {where} isolates | {proposals} proposals | "
        f"{int(elapsed)}s elapsed{eta}"
    )


def propose_for_notes(
    notes: Iterable[Note],
    *,
    queue: LinkProposalQueue,
    min_score: float | None = None,
    topn: int | None = None,
    target_filter: str = "spine",
    rationale: bool = True,
    table: object | None = None,
    resume: bool = False,
    append_path: Path | None = None,
    log: Callable[[str], None] | None = None,
    progress_every: int = 50,
    total: int | None = None,
) -> ProposeResult:
    """Generate candidates for ``notes`` and enqueue the new proposals.

    For each source note, :func:`~core.linking.candidates.candidates_for_note`
    yields note-level candidates already filtered of self / same-file / *existing*
    links (the dedup-against-existing-links requirement). Each candidate becomes a
    :class:`LinkProposal`; :meth:`LinkProposalQueue.add` drops any pair already in
    the queue (the dedup-against-previously-proposed requirement).

    Observability (opt-in; defaults preserve the original behaviour):

    * ``append_path`` — append each *new* proposal to this JSONL file **as it is
      produced** (incremental, crash-durable persistence), rather than relying on a
      single :meth:`LinkProposalQueue.save` at the end.
    * ``resume`` — skip source notes that already have a proposal in the queue (by
      ``source_note``), so a re-run continues where a killed run stopped instead of
      restarting from zero.
    * ``log`` / ``progress_every`` / ``total`` — emit a progress line every
      ``progress_every`` sources seen (``total`` is the scope size for the ``X/TOTAL``
      counter; defaults to ``len(notes)``).
    """
    result = ProposeResult()
    notes = list(notes)
    if total is None:
        total = len(notes)
    # Resume set: sources that already have ≥1 proposal in the (loaded) queue.
    already_sourced = (
        {p.source_note for p in queue.by_id.values()} if resume else set()
    )
    start = time.perf_counter()
    seen = 0
    for note in notes:
        seen += 1
        if log is not None and progress_every and seen % progress_every == 0:
            log(_progress_line(seen, total, result.added, start))
        if not is_linkable_source(note):
            result.skipped_sources += 1
            continue
        if resume and note.id in already_sourced:
            result.resumed_skipped += 1
            continue
        result.sources += 1
        for candidate in candidates_for_note(
            note,
            min_score=min_score,
            topn=topn,
            target_filter=target_filter,
            table=table,
        ):
            result.candidates += 1
            text = default_rationale(candidate) if rationale else ""
            proposal = LinkProposal.from_candidate(candidate, rationale=text)
            if queue.add(proposal):
                result.added += 1
                result.proposals.append(proposal)
                if append_path is not None:
                    _append_proposal(append_path, proposal)
            else:
                result.duplicates += 1
    if log is not None:
        log(_progress_line(seen, total, result.added, start) + " | done")
    return result


def iter_isolates(vault_path: Path, *, include_curated: bool = True) -> list[Note]:
    """Notes with **no outgoing** ``[[links]]`` — the prime linking sources.

    A semantic link is most valuable where the deterministic pass (Phase 5) left a
    note unconnected. Isolates are detected via
    :func:`~core.linking.candidates.existing_link_targets` (empty ⇒ isolate).
    Legacy isolates are always included (pulling raw material toward the skeleton);
    curated isolates are included unless ``include_curated=False``.
    """
    isolates: list[Note] = []
    for note in iter_vault(vault_path):
        if not is_linkable_source(note):
            continue  # meta/index notes are navigation, never linking sources (fix A)
        if existing_link_targets(note):
            continue
        is_legacy = note.frontmatter.get("corpus") == "legacy"
        if is_legacy or include_curated:
            isolates.append(note)
    return isolates


def select_sources(vault_path: Path, scope: str = "all") -> list[Note]:
    """Resolve a CLI ``--scope`` to the source notes to propose from.

    ``all`` / ``legacy`` / ``curated`` select **isolates** (the prime targets —
    notes the deterministic pass left unlinked) of that layer; a bare ``<note-id>``
    selects that one note regardless of isolate status (an explicit, on-demand
    request). Meta/index notes are excluded from the layer scopes (fix A) but an
    explicit id is honoured as given.
    """
    scope = (scope or "all").strip()
    if scope == "all":
        return iter_isolates(vault_path, include_curated=True)
    if scope == "legacy":
        return iter_isolates(vault_path, include_curated=False)
    if scope == "curated":
        return [
            n
            for n in iter_isolates(vault_path, include_curated=True)
            if n.frontmatter.get("corpus") != "legacy"
        ]
    # Otherwise the scope is a reference to ONE note. CONTRACT-1 ФП-1 (Д10): любая
    # форма ссылки через единую точку резолва (путь / id / имя файла / source_path) —
    # раньше принимался только frontmatter id, и путь из выдачи ``find_notes`` давал
    # молчаливый «0 источников». Обход по id остаётся вторым шагом (заметка вне
    # манифестов).
    from core.privacy import is_nda
    from core.vault import read_note, resolve_note_path

    resolved = resolve_note_path(scope, vault_path=vault_path)
    # NDA-1: ``iter_vault`` NDA-заметки отфильтровывал, единый резолвер дотягивается до
    # них по пути — гард обязан стоять здесь, иначе evidence NDA-заметки уехал бы в очередь.
    if resolved is not None and not is_nda(str(resolved)):
        return [read_note(resolved)]
    for note in iter_vault(vault_path):
        if note.id == scope:
            return [note]
    return []


# --------------------------------------------------------------------------- #
# Optional LLM ranking — assemble-only (Path B / Cowork), never called in core #
# --------------------------------------------------------------------------- #

_LLM_INSTRUCTION = (
    "Ты оцениваешь осмысленность семантической связи между двумя заметками базы "
    "знаний. Вопрос: уместна ли ссылка ИСТОЧНИК → ЦЕЛЬ — относятся ли они к одной "
    "теме/проекту/решению так, что связь поможет навигации и переиспользованию? "
    "Ответь строго JSON: {\"link\": true|false, \"rationale\": \"<краткое "
    "обоснование на русском, 1–2 предложения>\"}. Если связь натянута — link=false."
)


def assemble_link_prompt(
    proposal: LinkProposal,
    *,
    source_excerpt: str = "",
    target_excerpt: str = "",
) -> str:
    """Build the (assemble-only) LLM prompt judging whether ``proposal`` is real.

    Mirrors :mod:`core.generation`: the engine composes the prompt and records it;
    the LLM call itself happens in Cowork (Path B). The returned text names both
    notes, the cosine score, and the matched evidence so the judge has the "why".
    No network, no LLM call here — off the hot path by construction.
    """
    src = (source_excerpt or "").strip()
    tgt = (target_excerpt or proposal.evidence_snippet or "").strip()
    parts = [
        _LLM_INSTRUCTION,
        "",
        f"ИСТОЧНИК: [[{proposal.source_note}]]",
        f"Фрагмент источника: {src or '—'}",
        "",
        f"ЦЕЛЬ: [[{proposal.target_note}]] (тип: {proposal.target_type or 'note'})",
        f"Фрагмент цели: {tgt or '—'}",
        "",
        f"Косинусная близость: {proposal.score:.2f}",
    ]
    return "\n".join(parts)
