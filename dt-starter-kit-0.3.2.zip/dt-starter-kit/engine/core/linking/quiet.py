"""WAVE0-HYGIENE п.4 — «тихое окно» заметки: не трогать только что записанное другим шагом.

Fast (mail_ingest, ...) и index (link_auto, hub_scan) теперь идут параллельно — у каждого
свой lock (:func:`core.runlock.index_sync_lock`). Общий vault они делят без взаимной
блокировки, поэтому конфликт решается на уровне шага: линковка не читает-не переписывает
заметку, изменённую менее ``DT_LINK_QUIET_S`` (60 с) назад — её только что писал почтовый
ингест. Пропущенное не теряется: заметка не отмечается просканированной / предложение
остаётся ``approved``, следующий проход подхватит.
"""

from __future__ import annotations

import os
import time
from pathlib import Path

__all__ = ["DEFAULT_QUIET_S", "quiet_seconds", "recently_modified"]

DEFAULT_QUIET_S = 60.0


def quiet_seconds() -> float:
    """Окно тишины, с (``DT_LINK_QUIET_S``, дефолт 60; 0 — выключено)."""
    raw = (os.environ.get("DT_LINK_QUIET_S") or "").strip()
    try:
        value = float(raw)
    except ValueError:
        return DEFAULT_QUIET_S
    return value if value >= 0 else DEFAULT_QUIET_S


def recently_modified(path: Path, *, now: float | None = None) -> bool:
    """True, если файл менялся менее :func:`quiet_seconds` назад (нет файла → False)."""
    window = quiet_seconds()
    if window <= 0:
        return False
    try:
        mtime = Path(path).stat().st_mtime
    except OSError:
        return False
    return ((now if now is not None else time.time()) - mtime) < window
