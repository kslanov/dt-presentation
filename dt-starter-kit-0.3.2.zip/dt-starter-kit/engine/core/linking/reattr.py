"""REATTR-1 — перенос файла между сущностными каталогами → предложение переатрибуции.

Кейс К. 14.08: файл переложили из ``…/Russia/BS/…`` в ``…/Russia/Initech/651/…``.
Инжест это ВИДИТ (ветка ``relocated``: те же байты по новому пути — заметка
сохраняется, путь перецепляется) и молчит, а атрибуция заметки (``client:`` во
frontmatter, по которому фильтрует ретривал) остаётся прежней. Человек сообщил
движку факт о мире — движок его потерял.

Здесь — сторона ПРЕДЛОЖЕНИЯ: детектор и persist-очередь. Решение (перевесить или
отклонить) — :mod:`core.linking.reattr_decide`, сверка с vault —
:mod:`core.linking.reconcile_reattr`. Разделение то же, что у link-очереди, и по
той же причине: предложение живёт дольше прогона, а применяет его человек.

Три правила детектора:

* **Хабы только существующие.** Сущность из сегмента пути достаёт общий матчер
  :func:`core.legacy.linking.hubs_for_labels` (id / алиас / догадка
  ``<prefix>-<slugify>`` — и всё это ПРОТИВ каталога хабов на диске). Нет хаба —
  нет предложения: движок не выдумывает сущность из имени папки.
* **Разошлись — событие, совпали — нет.** Переезд внутри одной сущности
  (``Initech/650`` → ``Initech/651``) и переезд между «несущностными» папками
  (уборка, архив) не порождают ничего: карточка, которая приходит на каждую
  перекладку файлов, будет отклоняться не глядя.
* **Идемпотентность по ``note_id`` + ``to_hubs``.** Повторный инжест того же
  переноса даёт тот же ``id`` → строка не дублируется, а её статус (в том числе
  человеческое ``rejected``) не перетирается. Это же и делает ``reject``
  терминальным: тот же перенос больше не воскресает.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path, PurePath
from typing import Any

from core.config import reattr_proposals_path
from core.ingest import EntityRef
from core.legacy.linking import hubs_for_labels

__all__ = [
    "REATTR_ENTITIES",
    "STATUS_PENDING",
    "STATUS_APPLIED",
    "STATUS_REJECTED",
    "STATUS_RESOLVED",
    "ReattrProposal",
    "ReattrQueue",
    "detect_reattribution",
    "path_labels",
    "propose_reattributions",
    "reattr_proposal_id",
]

STATUS_PENDING = "pending"
STATUS_APPLIED = "applied"
# Терминально по решению человека: та же пара (заметка, целевые хабы) больше не
# предлагается — ``ReattrQueue.add`` не трогает существующий id (см. док модуля).
STATUS_REJECTED = "rejected"
# RECONCILE-1: предложение перестало быть оправданным ИСТОЧНИКОМ (заметка исчезла,
# атрибуцию сменили руками, файл уехал дальше) → снимается этим статусом. Не
# hard-delete: строка остаётся для аудита и не предлагается заново.
STATUS_RESOLVED = "resolved"

# Сущности, чьи каталоги считаем «сущностными» для переатрибуции. Пока ровно одна —
# ``client``: перевешивание делает :func:`core.operational.attribute.attribute_note_client`,
# то есть поле ``client:``, по которому фильтрует политика ретривала (RETR-LINK).
# Расширение на product/direction требует apply, умеющего писать их поля, — иначе
# карточка предлагала бы то, чего движок выполнить не может.
REATTR_ENTITIES: tuple[str, ...] = ("client",)


def reattr_proposal_id(note_id: str, to_hubs: list[str]) -> str:
    """Детерминированный id предложения по ``note_id`` + целевым хабам.

    Ключ идемпотентности из ТЗ: повторный инжест того же переноса обязан дать ту
    же строку. Целевые хабы входят в ключ, а исходные — нет: если файл переложат
    ещё раз и цель сменится, это ДРУГОЕ предложение (и оно должно появиться).
    """
    seed = f"{note_id.strip()}→{','.join(sorted(h.strip() for h in to_hubs))}"
    return hashlib.sha1(seed.encode("utf-8")).hexdigest()[:12]  # noqa: S324 — id, не крипто


@dataclass
class ReattrProposal:
    """Одно предложение переатрибуции, ждущее решения человека."""

    id: str
    note_id: str
    old_path: str
    new_path: str
    from_hubs: list[str] = field(default_factory=list)
    to_hubs: list[str] = field(default_factory=list)
    detected_at: str = ""
    status: str = STATUS_PENDING


def path_labels(path: str) -> list[str]:
    """Сегменты-папки пути (без имени файла) — кандидаты в ярлыки сущности.

    Имя файла НЕ берём: «Initech_отчёт.xlsx» в папке чужого клиента — не признак
    принадлежности, а признак того, что документ ПРО другого клиента.
    """
    parts = [p for p in PurePath(str(path or "")).parts if p not in ("/", "\\")]
    return [p for p in parts[:-1] if p.strip()]


def _hubs_of(path: str, catalog: list[EntityRef]) -> list[str]:
    """Существующие сущностные хабы по сегментам пути (порядок стабильный)."""
    return hubs_for_labels(path_labels(path), catalog, entities=REATTR_ENTITIES)


def detect_reattribution(
    *,
    note_id: str,
    old_path: str,
    new_path: str,
    catalog: list[EntityRef],
    now: str | None = None,
) -> ReattrProposal | None:
    """Предложение переатрибуции для одного переноса, либо ``None``.

    ``None`` — когда предлагать нечего: у нового пути нет сущностных хабов
    (переезд в «несущностную» папку — уборка, архив, разбор) ИЛИ множества
    старого и нового путей совпали (переезд внутри одной сущности). Пустой
    ``from_hubs`` при непустом ``to_hubs`` — законное предложение: файл лежал в
    ничьей папке и попал в клиентскую, это ровно то, что стоит перевесить.
    """
    to_hubs = _hubs_of(new_path, catalog)
    if not to_hubs:
        return None
    from_hubs = _hubs_of(old_path, catalog)
    if set(from_hubs) == set(to_hubs):
        return None
    return ReattrProposal(
        id=reattr_proposal_id(note_id, to_hubs),
        note_id=note_id,
        old_path=str(old_path),
        new_path=str(new_path),
        from_hubs=from_hubs,
        to_hubs=to_hubs,
        detected_at=now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    )


@dataclass
class ReattrQueue:
    """Очередь ``.derived/reattr_proposals.jsonl``, ключ — ``id`` (JSONL, без сети).

    ``read_error`` — почему очередь прочиталась пустой, когда файл ЕСТЬ (канон §9
    п.22: «пусто» и «не прочиталось» — разные ответы; витрина обязана их различать,
    иначе недоступный стор выглядит как «предложений нет»).
    """

    by_id: dict[str, ReattrProposal] = field(default_factory=dict)
    path: Path | None = None
    read_error: str = ""

    @classmethod
    def load(cls, path: Path | None = None) -> ReattrQueue:
        target = Path(path) if path is not None else reattr_proposals_path()
        by_id: dict[str, ReattrProposal] = {}
        read_error = ""
        if target.is_file():
            try:
                lines = target.read_text(encoding="utf-8").splitlines()
            except OSError as exc:
                return cls(by_id={}, path=target, read_error=str(exc))
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue  # битую строку терпим — файл производный, пересобираемый
                if not isinstance(row, dict) or "id" not in row:
                    continue
                proposal = ReattrProposal(
                    id=str(row["id"]),
                    note_id=str(row.get("note_id", "")),
                    old_path=str(row.get("old_path", "")),
                    new_path=str(row.get("new_path", "")),
                    from_hubs=[str(h) for h in (row.get("from_hubs") or [])],
                    to_hubs=[str(h) for h in (row.get("to_hubs") or [])],
                    detected_at=str(row.get("detected_at", "")),
                    status=str(row.get("status", STATUS_PENDING)),
                )
                by_id[proposal.id] = proposal
        return cls(by_id=by_id, path=target, read_error=read_error)

    def add(self, proposal: ReattrProposal) -> bool:
        """Вставить, если такого id ещё нет. ``True`` — вставили.

        Существующий id остаётся КАК ЕСТЬ: повторный инжест не воскрешает
        отклонённое и не сбрасывает уже применённое.
        """
        if proposal.id in self.by_id:
            return False
        self.by_id[proposal.id] = proposal
        return True

    def pending(self) -> list[ReattrProposal]:
        return [p for p in self.by_id.values() if p.status == STATUS_PENDING]

    def save(self, path: Path | None = None) -> Path:
        chosen = path if path is not None else self.path
        if chosen is None:
            raise ValueError("ReattrQueue.save needs a path")
        chosen = Path(chosen)
        chosen.parent.mkdir(parents=True, exist_ok=True)
        rows = sorted(self.by_id.values(), key=lambda p: (p.detected_at, p.id))
        body = "\n".join(json.dumps(asdict(p), ensure_ascii=False) for p in rows)
        tmp = chosen.with_suffix(chosen.suffix + ".tmp")
        tmp.write_text(body + ("\n" if body else ""), encoding="utf-8")
        tmp.replace(chosen)
        return chosen


def propose_reattributions(
    relocations: list[dict[str, Any]],
    *,
    catalog: list[EntityRef],
    queue_path: Path | None = None,
    now: str | None = None,
) -> list[ReattrProposal]:
    """Прогнать переносы прогона через детектор и добавить новые в очередь.

    ``relocations`` — ``[{note_id, old_path, new_path}, …]`` (инжест знает всё три).
    Возвращает ТОЛЬКО реально добавленные строки; очередь читается и пишется один
    раз на прогон. Пусто → файл не трогаем вовсе (пустой прогон не должен
    переписывать очередь и менять её mtime).
    """
    detected = [
        p
        for row in relocations
        if (
            p := detect_reattribution(
                note_id=str(row.get("note_id") or ""),
                old_path=str(row.get("old_path") or ""),
                new_path=str(row.get("new_path") or ""),
                catalog=catalog,
                now=now,
            )
        )
        is not None
    ]
    if not detected:
        return []
    queue = ReattrQueue.load(queue_path)
    added = [p for p in detected if queue.add(p)]
    if added:
        queue.save()
    return added
