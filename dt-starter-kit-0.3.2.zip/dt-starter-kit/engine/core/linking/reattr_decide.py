"""REATTR-1 — решение по одному предложению переатрибуции (кнопка пульта).

Пара к :mod:`core.linking.reattr` (детектор и очередь): здесь принимается решение
человека и, если это «Применить», выполняется перевешивание.

Три правила:

* **Апплай — реюз, а не второй путь записи.** Атрибуцию перевешивает
  :func:`core.operational.attribute.attribute_note_client` — та же хирургическая
  правка ``client:`` во frontmatter, что и у ``attribute_note``. Второй писатель
  того же поля означал бы вторую семантику «что такое привязка заметки».
* **Никакой авто-переатрибуции.** Движок только предлагает: перенос файла — это
  сигнал, а не команда (папку двигают и по ошибке, и на время). Применить может
  только человек, кнопкой.
* **Reject терминален.** Строка получает ``rejected``, а ``ReattrQueue.add`` не
  трогает существующий id — тот же перенос не воскресит карточку.

Исходы: ``applied`` / ``rejected`` / ``stale`` (решение уже принято раньше) /
``failed`` (заметка не нашлась — строка остаётся pending, чинится и повторяется).
Деградации несут машинный ``code`` конверта CONTRACT-2. Каждый вызов оставляет
аудит-строку пульта (id + решение + исход, без содержимого заметок) и событие
стадии (``link``/``reattributed``) — «путь заметки по стадиям» должен видеть смену
хозяина.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.contract import (
    CODE_ITEM_NOT_FOUND,
    CODE_SKIPPED,
    CODE_UNRESOLVED_REF,
    add_warning,
)
from core.linking.reattr import (
    STATUS_APPLIED,
    STATUS_PENDING,
    STATUS_REJECTED,
    ReattrProposal,
    ReattrQueue,
)
from core.operational.attribute import AttributionError, attribute_note_client
from core.operational.pult import record_action

__all__ = ["decide_reattr"]

_TOOL = "pult_reattr_decide"


def _brief(p: ReattrProposal) -> dict[str, Any]:
    """Общие поля ответа — карточке хватает заметки, путей и хабов."""
    return {
        "proposal_id": p.id,
        "note_id": p.note_id,
        "old_path": p.old_path,
        "new_path": p.new_path,
        "from_hubs": list(p.from_hubs),
        "to_hubs": list(p.to_hubs),
        "status": p.status,
    }


def decide_reattr(
    *,
    proposal_id: str,
    decision: str,
    queue: ReattrQueue,
    vault_path: Path,
    now: str | None = None,
) -> dict[str, Any]:
    """Решить судьбу одного предложения переатрибуции. См. док модуля.

    ``decision`` — ``apply`` (перевесить атрибуцию) либо ``reject`` (навсегда).
    Неизвестный id — не исключение, а конверт ``item_not_found``: решение по
    опечатке молча не принимается, но и падать инструменту незачем (CONTRACT-2:
    отказ пересекает границу как ДАННЫЕ).
    """
    if decision not in ("apply", "reject"):
        raise ValueError(
            f"unsupported decision {decision!r}; use 'apply' or 'reject'"
        )
    audit = {"proposal_id": proposal_id, "decision": decision}

    p = queue.by_id.get(proposal_id)
    if p is None:
        record_action(_TOOL, audit, "not_found", now=now)
        out: dict[str, Any] = {
            "ok": False, "refused": True, "code": CODE_ITEM_NOT_FOUND,
            "proposal_id": proposal_id, "outcome": "not_found",
        }
        return add_warning(
            out, CODE_ITEM_NOT_FOUND,
            f"предложение переатрибуции {proposal_id!r} не найдено в очереди — "
            "ничего не изменено (лента могла обновиться: перечитай список)",
            proposal_id=proposal_id,
        )

    if p.status != STATUS_PENDING:
        record_action(_TOOL, audit, "stale", now=now)
        settled = "применено" if p.status == STATUS_APPLIED else (
            "отклонено" if p.status == STATUS_REJECTED else "снято сверкой"
        )
        return {
            **_brief(p),
            "outcome": "stale",
            "explanation": f"Предложение уже {settled} ранее — решение не требуется.",
        }

    if decision == "reject":
        p.status = STATUS_REJECTED
        queue.save()
        record_action(_TOOL, audit, "rejected", now=now)
        return {
            **_brief(p),
            "outcome": "rejected",
            "explanation": (
                "Отклонено навсегда — тот же перенос больше не предложит "
                "переатрибуцию (ключ очереди: заметка + целевые хабы)."
            ),
        }

    # --- apply → тот же путь записи, что у attribute_note --------------------
    if not p.to_hubs:
        # Защита от строки, пришедшей из будущего формата/ручной правки файла.
        record_action(_TOOL, audit, "failed", now=now)
        return add_warning(
            {**_brief(p), "outcome": "failed"}, CODE_SKIPPED,
            "в предложении нет целевых хабов — перевешивать не на что",
        )
    target = p.to_hubs[0]
    try:
        result = attribute_note_client(p.note_id, target, vault_path=vault_path)
    except AttributionError as exc:
        record_action(_TOOL, audit, "failed", now=now)
        return add_warning(
            {**_brief(p), "outcome": "failed"}, CODE_UNRESOLVED_REF,
            f"заметка «{p.note_id}» не перевешена: {exc} — предложение осталось "
            "pending (почини заметку и повтори)",
            note_id=p.note_id,
        )

    p.status = STATUS_APPLIED
    queue.save()
    _emit_stage_event(p, result, now=now)
    record_action(_TOOL, audit, "applied", now=now)

    out = {
        **_brief(p),
        "status": STATUS_APPLIED,
        "outcome": "applied",
        "client": result.get("client"),
        "previous": result.get("previous"),
        "changed": bool(result.get("changed")),
        "note_path": result.get("path"),
        "needs_reindex": bool(result.get("changed")),
        "explanation": (
            f"Атрибуция заметки перевешена на «{target}»"
            + ("" if result.get("changed") else " (уже была такой — файл не тронут)")
            + "; в индекс попадёт ближайшим reindex."
        ),
    }
    if len(p.to_hubs) > 1:
        # Честнее сказать вслух, чем тихо перевесить на первый: несколько
        # клиентских хабов в пути — редкость, но «применено» не должно означать
        # «часть работы пропущена» без следа (канон §9 п.22).
        add_warning(
            out, CODE_SKIPPED,
            "в пути найдено несколько клиентских хабов — атрибуция поставлена на "
            f"«{target}», остальные не записаны (поле client одно): "
            + ", ".join(p.to_hubs[1:]),
            skipped_hubs=p.to_hubs[1:],
        )
    return out


def _emit_stage_event(
    p: ReattrProposal, result: dict[str, Any], *, now: str | None = None
) -> None:
    """Событие стадии «сменился хозяин заметки» (best-effort внутри eventlog).

    Privacy: id заметки, хабы и относительный путь — ни тела, ни текстов.
    """
    from core.eventlog import emit

    emit(
        "link",
        "reattributed",
        note_id=p.note_id,
        path=str(result.get("path") or ""),
        detail={
            "from_hubs": list(p.from_hubs),
            "to_hubs": list(p.to_hubs),
            "changed": bool(result.get("changed")),
        },
        now=now,
    )
