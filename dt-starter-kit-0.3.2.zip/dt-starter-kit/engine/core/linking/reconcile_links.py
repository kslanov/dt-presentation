"""RECONCILE-1 — адаптер №2: сверка очереди link-предложений с vault.

Гап (анализ 2026-07-10): pending-предложение семантической ссылки
(``.derived/link_proposals.jsonl``) переживает удаление заметки-источника или
цели — ``stale`` в :mod:`core.linking.decide` выставляется только при
approve/reject-конфликте, но не когда заметка исчезла из vault. Такое
предложение висит в ленте ``pult_link_decide`` навсегда.

:class:`LinkProposalsReconcilable` закрывает гап через общий контур
:mod:`core.operational.reconcile`: ``read_source`` = множество note-id живого
vault (дешёвый обход ``iter_vault``), ``stale_items`` = pending-предложения, чьи
``source``/``target`` отсутствуют, ``resolve`` = статус
:data:`~core.linking.propose.STATUS_STALE` (лента фильтрует по ``pending`` → строка
исчезает). Пустой/ошибочный обход → ``None`` (общий гард движка пропустит сверку —
на транзиентном сбое очередь не обнуляется). Ничего не пишет в заметки; только
статус в персист-очереди. Не hard-delete.

Инвариант: ``core/`` ⊥ MCP/CLI; Path B — обход vault, без сети и LLM.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from core.linking.propose import STATUS_PENDING, STATUS_STALE, LinkProposalQueue
from core.vault import iter_vault

__all__ = ["LinkProposalsReconcilable"]


@dataclass
class LinkProposalsReconcilable:
    """:class:`~core.operational.reconcile.Reconcilable` для link-очереди.

    ``vault_path`` — корень vault (источник истины о существовании заметок);
    ``queue_path`` — ``link_proposals.jsonl`` (``None`` → дефолт из конфига).
    """

    vault_path: Path
    queue_path: Path | None = None
    name: str = field(default="link_proposals")

    def read_source(self) -> set[str] | None:
        """Множество note-id живого vault; пустой обход/ошибка → ``None`` (гард).

        Пустой набор трактуется как «читать нельзя» (битый путь vault, гонка на
        обходе) — движок пропустит сверку, а не снесёт всю очередь: реальный vault
        никогда не пуст.
        """
        try:
            ids = {note.id for note in iter_vault(self.vault_path) if note.id}
        except Exception:  # noqa: BLE001 — сбой обхода = «не читать», не «пусто»
            return None
        return ids or None

    def stale_items(self, source: set[str]) -> list[str]:
        """id pending-предложений, чья source- или target-заметка исчезла из vault."""
        queue = LinkProposalQueue.load(self.queue_path)
        return [
            p.id
            for p in queue.by_id.values()
            if p.status == STATUS_PENDING
            and (p.source_note not in source or p.target_note not in source)
        ]

    def resolve(self, item: str) -> None:
        """Пометить предложение ``stale`` (перепроверив, что оно ещё pending)."""
        queue = LinkProposalQueue.load(self.queue_path)
        proposal = queue.by_id.get(item)
        if proposal is None or proposal.status != STATUS_PENDING:
            return  # уже решено/снято — идемпотентно ничего
        proposal.status = STATUS_STALE
        queue.save()
