"""REATTR-1 — адаптер сверки очереди переатрибуции с vault (принцип §9 №13).

Предложение переатрибуции — производная persist-очередь: оно ПОМНИТ факт («файл
переехал из BS в Initech»), а мир после этого живёт дальше. Три способа, которыми
предложение перестаёт быть оправданным источником, и все три обязаны снимать
карточку, иначе она висит в «Требуют решения» вечно:

* заметка исчезла из vault (источник удалили/выпал из инжеста);
* атрибуцию уже поставили руками — ``client`` заметки совпал с ``to_hubs``
  (человек сделал то же самое сам, кнопка больше не нужна);
* файл уехал дальше или обратно — ``source_path`` заметки больше не тот
  ``new_path``, под который предложение выписано.

Снятие — статусом :data:`~core.linking.reattr.STATUS_RESOLVED`, НЕ hard-delete
(строка остаётся аудитом и, благодаря ключу очереди, не предлагается заново).
Общий гард от ложного снятия (пустое/ошибочное чтение источника → прогон
пропускается) живёт в :func:`core.operational.reconcile.reconcile_all`.

``core`` ⊥ mcp/cli; Path B — обход vault, без сети и LLM.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.linking.reattr import STATUS_PENDING, STATUS_RESOLVED, ReattrQueue
from core.vault import iter_vault

__all__ = ["ReattrProposalsReconcilable"]


def _hub_ids(value: Any) -> set[str]:
    """``client``-поле заметки → множество id хабов (строка или список).

    ``core.vault`` уже нормализует ``[[client-x]]`` → ``client-x``; здесь только
    приводим одиночное значение и список к одному виду.
    """
    if isinstance(value, list):
        return {str(v).strip() for v in value if str(v).strip()}
    text = str(value or "").strip()
    return {text} if text else set()


@dataclass
class ReattrProposalsReconcilable:
    """:class:`~core.operational.reconcile.Reconcilable` для очереди переатрибуции.

    ``vault_path`` — корень vault (источник истины о заметках); ``queue_path`` —
    ``reattr_proposals.jsonl`` (``None`` → дефолт из конфига).
    """

    vault_path: Path
    queue_path: Path | None = None
    name: str = field(default="reattr_proposals")

    def read_source(self) -> dict[str, dict[str, Any]] | None:
        """``{note_id: {client, source_path}}`` живого vault; пусто/ошибка → ``None``.

        Пустой обход считаем «читать нельзя» (битый путь, гонка), а не «заметок нет»:
        иначе одна неудачная сверка сняла бы всю очередь — ровно то ложное снятие,
        от которого стоит общий гард движка.
        """
        try:
            notes = {
                note.id: {
                    "client": _hub_ids(note.frontmatter.get("client")),
                    "source_path": str(note.frontmatter.get("source_path") or ""),
                }
                for note in iter_vault(self.vault_path)
                if note.id
            }
        except Exception:  # noqa: BLE001 — сбой обхода = «не читать», не «пусто»
            return None
        return notes or None

    def stale_items(self, source: dict[str, dict[str, Any]]) -> list[str]:
        """id pending-предложений, которых vault больше не оправдывает."""
        queue = ReattrQueue.load(self.queue_path)
        stale: list[str] = []
        for p in queue.by_id.values():
            if p.status != STATUS_PENDING:
                continue
            note = source.get(p.note_id)
            if note is None:
                stale.append(p.id)  # заметка исчезла
                continue
            if p.to_hubs and set(p.to_hubs) & note["client"]:
                stale.append(p.id)  # атрибуцию уже поставили руками
                continue
            current = note["source_path"]
            if current and p.new_path and not _same_source(current, p.new_path):
                stale.append(p.id)  # файл уехал дальше/обратно
        return stale

    def resolve(self, item: str) -> None:
        """Снять предложение статусом ``resolved`` (перепроверив, что оно pending)."""
        queue = ReattrQueue.load(self.queue_path)
        proposal = queue.by_id.get(item)
        if proposal is None or proposal.status != STATUS_PENDING:
            return  # уже решено/снято — идемпотентно ничего
        proposal.status = STATUS_RESOLVED
        queue.save()


def _same_source(note_source_path: str, proposal_new_path: str) -> bool:
    """Указывают ли обе строки на один файл (сравнение хвостом пути).

    ``source_path`` заметки бывает абсолютным (оперативное хранилище) или
    относительным корню (легаси), а очередь помнит ключ инжеста — относительный.
    Сравниваем нормализованными «/» с проверкой на суффикс по границе сегмента:
    строгое равенство здесь дало бы ложное «файл уехал» на каждой карточке.
    """
    a = str(note_source_path).replace("\\", "/").strip("/")
    b = str(proposal_new_path).replace("\\", "/").strip("/")
    if not a or not b:
        return True  # нечего сравнивать — не выдумываем переезд
    return a == b or a.endswith("/" + b) or b.endswith("/" + a)
