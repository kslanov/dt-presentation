"""Phase 9, stage 1 — note-agnostic "linkable signals" extraction.

One mechanism for every card type (curated, legacy files, correspondence, hubs,
projects): the *type* of a note only changes **where the signals come from**,
never how linking works. :func:`signals_for_note` reads whatever a note carries
and returns a flat :class:`NoteSignals` — missing fields are simply empty, so
downstream resolvers (``core/linking/deterministic.py``, semantic, LLM) never
branch on the note type.

Signals per ТЗ phase9:

* common: title (``subject`` frontmatter or the first markdown ``#`` heading)
  and the note body;
* frontmatter: ``client``, ``section``, ``counterparties``,
  ``counterparty_domains``, ``product``, ``tags``;
* legacy files additionally: ``source_path`` (section/client are encoded in the
  original path).

Invariant: ``core/`` depends on neither MCP nor CLI; no LLM calls here.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from core.vault import Note

__all__ = ["NoteSignals", "signals_for_note"]

# First markdown H1 in a body — the note's own title when there is no subject.
_H1_RE = re.compile(r"^#\s+(.+?)\s*$", re.MULTILINE)


@dataclass
class NoteSignals:
    """Flat, note-agnostic bundle of everything a linker may match on.

    All fields are always present; a note that lacks a signal contributes an
    empty string/list. ``title`` is the e-mail ``subject`` for correspondence
    notes and the first ``#`` heading otherwise; ``source_path`` is non-empty
    only for legacy-corpus notes (provenance path, carries section/client).
    """

    note_id: str
    title: str = ""
    body: str = ""
    client: str = ""
    section: str = ""
    counterparties: list[str] = field(default_factory=list)
    counterparty_domains: list[str] = field(default_factory=list)
    products: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    source_path: str = ""


def _as_str(value: Any) -> str:
    """A frontmatter scalar as a stripped string (lists take the first item)."""
    if isinstance(value, list):
        value = value[0] if value else ""
    return str(value).strip() if value is not None else ""


def _as_list(value: Any) -> list[str]:
    """A frontmatter value as a list of non-empty strings (scalar → 1-элемент)."""
    if value is None:
        return []
    items = value if isinstance(value, list) else [value]
    return [s for s in (str(item).strip() for item in items) if s]


def signals_for_note(note: Note) -> NoteSignals:
    """Collect the linkable signals of ``note``, regardless of its type.

    Reads only what the note already carries (frontmatter + body) — rendering
    passes are expected to have written the *data* (client, section,
    counterparties, domains); this function never derives new facts and never
    touches the filesystem beyond the already-parsed note.
    """
    fm = note.frontmatter

    title = _as_str(fm.get("subject"))
    if not title:
        match = _H1_RE.search(note.body)
        title = match.group(1).strip() if match else ""

    return NoteSignals(
        note_id=note.id,
        title=title,
        body=note.body,
        client=_as_str(fm.get("client")),
        section=_as_str(fm.get("section")),
        counterparties=_as_list(fm.get("counterparties")),
        counterparty_domains=_as_list(fm.get("counterparty_domains")),
        products=_as_list(fm.get("product")),
        tags=_as_list(fm.get("tags")),
        source_path=_as_str(fm.get("source_path")),
    )
