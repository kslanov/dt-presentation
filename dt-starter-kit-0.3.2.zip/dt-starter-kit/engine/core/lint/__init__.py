"""KNOWLEDGE-LINT-1 - линт знаний: детекторы -> находки -> карточки -> хирургические правки.

Третья базовая операция вики (после ingest и запроса): движок ДЕТЕРМИНИРОВАННО (без LLM) находит
противоречия фактов, устаревшие хабы, заметки-сироты и дубли, кладет находки в
``.derived/lint_findings.jsonl`` и показывает их карточками вида ``lint`` в очереди решений. В vault
и стор фактов пишет ТОЛЬКО действие карточки (решение человека), хирургически, с аудитом.

* :mod:`core.lint.registry` - реестр правил; :mod:`core.lint.detectors` - четыре детектора;
* :mod:`core.lint.store` - стор находок (upsert по стабильному id, ``resolved``, стопы);
* :mod:`core.lint.run` - прогон с бюджетом и честным ``partial``;
* :mod:`core.lint.actions` - решения по карточкам (запись + аудит + событие);
* :mod:`core.lint.claims` - модельный проход по хабу (правило ``claim``, только по кнопке).
"""

from __future__ import annotations

from core.lint.env import DetectResult, LintEnv
from core.lint.registry import Rule, get_rule, rule_names
from core.lint.store import LintStore, finding_id

__all__ = [
    "DetectResult",
    "LintEnv",
    "LintStore",
    "Rule",
    "finding_id",
    "get_rule",
    "rule_names",
]
