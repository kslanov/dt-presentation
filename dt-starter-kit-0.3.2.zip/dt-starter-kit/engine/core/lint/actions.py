"""Решения по карточкам ``lint`` (KNOWLEDGE-LINT-1): единственное место, где линт что-то пишет.

Пишет только по действию человека (карточка в очереди), хирургически, с аудитом ``record_action``
и событием ``lint/<правило>_applied``:

* ``keep_a`` / ``keep_b`` (``fact_conflict``) - проигравшему факту ``valid_to`` = сегодня,
  ``superseded_at`` = сейчас, ``superseded_by`` = победитель (причина - ``lint``, в аудите и стороне
  находки); остальные факты стора не трогаются;
* ``attach`` (``orphan``) - поле frontmatter ``client``/``project``/``links`` заметки
  (:func:`core.operational.hub_notes.attach_note_to_hub`), остальной файл байт-в-байт;
* ``mark`` (``duplicate``) - ``duplicate_of: <id старой>`` в более новой заметке;
* ``synth`` (``hub_stale``) - при включенном слое ИИ ``hub_synth.run_ai`` (тот же путь, что
  ``pult_ai(hub_synth)``): появляется карточка ``synth``; без провайдера - отказ-подсказка «собери
  состояние скиллом hub-synth» и НИКАКОЙ записи;
* ``note`` (``claim``) - строка под ``## Проверить (линт ДАТА)`` в хабе;
* ``snooze`` / ``dismiss`` - стоп находки (``DT_LINT_SNOOZE_DAYS`` у ``dismiss``).

Повтор по решенной находке - ``stale``. Слияния, удаления и автоправок здесь нет.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any

from core.lint import settings
from core.lint.env import LintEnv
from core.lint.store import (
    STATUS_APPLIED,
    STATUS_DISMISSED,
    STATUS_PENDING,
    STATUS_SNOOZED,
    LintStore,
    stamp,
)

logger = logging.getLogger(__name__)

__all__ = ["apply_card", "explain_card", "SNOOZE_CHOICES"]

SNOOZE_CHOICES = (3, 7, 14)
_HINT_SKILL = (
    "Слой ИИ не включен (pult.yaml: ai): попросите ассистента «собери состояние хаба {hub}» "
    "(скилл hub-synth) - текст в хаб попадет только по вашему approve карточки «Состояние хаба?»."
)


def _refused(code: str, detail: str) -> dict[str, Any]:
    return {"outcome": "refused", "code": code, "detail": detail}


def _audit(rule: str, action: str, row: dict[str, Any], outcome: str, **extra: Any) -> None:
    """Аудит ``record_action`` (id, без текстов) + событие ``lint/<правило>_applied``."""
    from core.eventlog import emit
    from core.operational.pult import record_action

    params = {"rule": rule, "action": action, "card": row["id"], **extra}
    record_action(f"lint_{action}", params, outcome)
    if outcome == "applied":
        emit("lint", f"{rule}_applied", note_id=str(row.get("subject") or ""),
             detail={"card": row["id"], "action": action, **extra})


def _facts_db(env: LintEnv) -> Path:
    from core.config import facts_db_path

    return Path(env.facts_db) if env.facts_db else facts_db_path()


# --------------------------------------------------------------------------- #
# fact_conflict                                                                 #
# --------------------------------------------------------------------------- #
def _supersede(
    db: Path, winner: str, loser: str, *, day: str, now_iso: str
) -> tuple[bool, str]:
    """Вытеснить ``loser`` фактом ``winner`` (``valid_to`` = ``day``). ``(ok, причина отказа)``.

    Перед записью обе строки перечитываются: изменившееся с момента находки - ``stale``."""
    from core.db import connect

    conn = connect(db)
    try:
        rows = {r["fact_id"]: r for r in conn.execute(
            "SELECT fact_id, valid_to, superseded_by FROM facts WHERE fact_id IN (?, ?)",
            (winner, loser))}
        if winner not in rows or loser not in rows:
            return False, "факт исчез из стора (источник переизвлечен)"
        for fid in (winner, loser):
            r = rows[fid]
            if r["superseded_by"] or (r["valid_to"] and str(r["valid_to"]) <= day):
                return False, "факт уже вытеснен или истек - противоречие снято без вас"
        with conn:
            conn.execute(
                "UPDATE facts SET valid_to=?, superseded_at=?, superseded_by=? WHERE fact_id=?",
                (day, now_iso, winner, loser))
        return True, ""
    finally:
        conn.close()


def _keep(row: dict[str, Any], action: str, store: LintStore, env: LintEnv,
          cur: datetime) -> dict[str, Any]:
    from core.facts.versions import contradiction_groups

    meta = row.get("meta") or {}
    winner, loser = (meta["a"], meta["b"]) if action == "keep_a" else (meta["b"], meta["a"])
    ok, why = _supersede(_facts_db(env), winner, loser, day=env.today(), now_iso=stamp(cur))
    if not ok:
        return {"outcome": "stale", "detail": why}
    left = [g for g in (contradiction_groups(_facts_db(env), today=env.today()) or [])
            if g and g[0]["fact_key"] == meta.get("fact_key")]
    if left:  # остались другие значения того же показателя: находка живет, данные обновим
        row["evidence"] = [e for e in row["evidence"] if e["fact_id"] != loser]
        effects = [f"факт {loser[:8]} вытеснен {winner[:8]} (valid_to {env.today()})",
                   "у показателя остались другие значения - находка открыта"]
    else:
        store.decide(row["id"], STATUS_APPLIED, cur, reason=f"lint:{action}")
        effects = [f"факт {loser[:8]} вытеснен {winner[:8]} "
                   f"(valid_to {env.today()}, причина lint)"]
    _audit("fact_conflict", action, row, "applied", winner=winner[:12], loser=loser[:12])
    return {"outcome": "applied", "detail": "Выбрано значение, второе вытеснено",
            "effects": effects}


# --------------------------------------------------------------------------- #
# orphan / duplicate / claim                                                    #
# --------------------------------------------------------------------------- #
def _attach(row: dict[str, Any], params: dict[str, Any], store: LintStore, env: LintEnv,
            cur: datetime) -> dict[str, Any]:
    from core.operational.hub_notes import HubNoteError, attach_note_to_hub
    from core.vault import read_note, resolve_note_path

    hub_id = str(params.get("hub_id") or "").strip()
    if not hub_id:
        raise ValueError("hub_id: выберите хаб из кандидатов или введите id")
    vault = env.vault_path()
    hub_path = resolve_note_path(hub_id, vault_path=vault)
    hub = read_note(hub_path) if hub_path is not None else None
    if hub is None or str(getattr(hub, "type", "") or "") != "hub":
        return _refused("hub_not_found", f"{hub_id!r} не хаб (type: hub) - проверьте id")
    try:
        res = attach_note_to_hub(
            str((row.get("meta") or {}).get("path") or row["subject"]), hub.id,
            entity=str(hub.frontmatter.get("entity") or ""), vault_path=vault)
    except HubNoteError as exc:
        return _refused("write_failed", str(exc))
    store.decide(row["id"], STATUS_APPLIED, cur, reason=f"attach:{hub.id}")
    _audit("orphan", "attach", row, "applied", hub=hub.id, field=res["field"],
           changed=bool(res["changed"]))
    effects = ([f"поле {res['field']} заметки {res['path']} -> [[{hub.id}]]"]
               if res["changed"] else [])
    return {"outcome": "applied",
            "detail": "Заметка привязана к хабу" if res["changed"] else "Привязка уже была",
            "effects": effects}


def _mark(row: dict[str, Any], store: LintStore, env: LintEnv, cur: datetime) -> dict[str, Any]:
    from core.operational.hub_notes import HubNoteError, set_note_field
    from core.vault import resolve_note_path

    meta = row.get("meta") or {}
    newer, older = str(meta.get("newer") or ""), str(meta.get("older") or "")
    vault = env.vault_path()
    if resolve_note_path(older, vault_path=vault) is None \
            or resolve_note_path(newer, vault_path=vault) is None:
        return {"outcome": "stale", "detail": "одной из заметок пары больше нет"}
    try:
        res = set_note_field(newer, "duplicate_of", older, vault_path=vault)
    except HubNoteError as exc:
        return _refused("write_failed", str(exc))
    prev = str(res["previous"] or "").strip().strip("'\"")
    if res["changed"] and prev and prev != older:
        # чужая пометка затёрта быть не должна: возвращаем как было и отказываем
        set_note_field(newer, "duplicate_of", prev, vault_path=vault)
        return _refused("already_marked", f"у заметки уже duplicate_of: {prev}")
    store.decide(row["id"], STATUS_APPLIED, cur, reason=f"mark:{older}")
    _audit("duplicate", "mark", row, "applied", newer=newer, older=older,
           changed=bool(res["changed"]))
    return {"outcome": "applied",
            "detail": "Пометка duplicate_of проставлена" if res["changed"] else "Пометка уже была",
            "effects": [f"{res['path']}: duplicate_of: {older}"] if res["changed"] else []}


def _note_claim(row: dict[str, Any], store: LintStore, env: LintEnv,
                cur: datetime) -> dict[str, Any]:
    from core.operational.hub_notes import HubNoteError, append_section_lines

    meta = row.get("meta") or {}
    heading = f"## Проверить (линт {cur:%d.%m.%Y})"
    locs = ", ".join(f"[{x}]" for x in meta.get("locators") or [])
    line = f"- {meta.get('claim')}" + (f" {locs}" if locs else "")
    try:
        res = append_section_lines(str(meta.get("hub_id")), heading, [line],
                                   vault_path=env.vault_path())
    except HubNoteError as exc:
        return _refused("write_failed", str(exc))
    store.decide(row["id"], STATUS_APPLIED, cur, reason="note")
    _audit("claim", "note", row, "applied", hub=str(meta.get("hub_id")),
           changed=bool(res["changed"]))
    return {"outcome": "applied",
            "detail": "Пункт дописан в хаб" if res["changed"] else "Такой пункт уже в хабе",
            "effects": [f"{res['path']}: {heading}"] if res["changed"] else []}


# --------------------------------------------------------------------------- #
# hub_stale -> synth                                                            #
# --------------------------------------------------------------------------- #
def _synth(row: dict[str, Any], store: LintStore, env: LintEnv, cur: datetime,
           synthesize: Callable[..., dict[str, Any]] | None,
           ai_settings: dict[str, Any] | None) -> dict[str, Any]:
    from core.operational import ai_gateway as gateway
    from core.operational import ai_layer, hub_synth

    meta = row.get("meta") or {}
    hub_id = str(meta.get("hub_id") or row["subject"])
    if meta.get("entity") != "client":
        return _refused("unsupported_entity",
                        "синтез состояния пока только для хабов-клиентов "
                        f"(entity={meta.get('entity') or '-'}): обновите хаб вручную")
    try:  # GATEWAY-1: сторона синтеза - по маршруту класса synth, не по одному флагу
        side = gateway.resolve("hub_synth", ai_settings or ai_layer.get_settings()).side
    except ai_layer.SettingsError as exc:
        return _refused(exc.code, _HINT_SKILL.format(hub=hub_id))
    if side != "daemon":
        return _refused("ai_host_side" if side == "host" else "ai_disabled",
                        _HINT_SKILL.format(hub=hub_id))
    res = hub_synth.run_ai(
        hub_id, synthesize or ai_layer.synthesize, since=meta.get("last_edit") or None,
        vault_path=env.vault_path(), mirror_path=env.mirror, now=cur)
    proposal = res.get("proposal")
    if not proposal:
        return _refused(str(res.get("code") or "ai_failed"),
                        str(res.get("error") or "провайдер не вернул пригодный текст"))
    days = settings.snooze_days()
    store.decide(row["id"], STATUS_SNOOZED, cur, reason=f"synth:{proposal['card_id']}", days=days)
    card = str(proposal["card_id"])
    _audit("hub_stale", "synth", row, "applied", hub=hub_id, synth_card=card)
    return {"outcome": "routed",
            "detail": "Предложение состояния поставлено карточкой «Состояние хаба?»",
            "effects": [f"карточка {card} - решите ее отдельно",
                        f"находка отложена на {days} дн. (вернется, если хаб не обновят)"]}


# --------------------------------------------------------------------------- #
# диспетчер                                                                     #
# --------------------------------------------------------------------------- #
def apply_card(
    native_id: str, action: str, params: dict[str, Any] | None = None, *,
    env: LintEnv | None = None, store_file: Path | None = None,
    synthesize: Callable[..., dict[str, Any]] | None = None,
    ai_settings: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Решение человека по находке ``native_id`` (id без префикса ``lint:``).

    Исход вида ``{outcome: applied|rejected|snoozed|routed|stale|refused, detail, effects,
    code?}``; неизвестная находка - ``ValueError('... не найдена')`` (диспетчер реестра делает из
    нее ``unknown_card``), неверный параметр - ``ValueError`` (``invalid_params``)."""
    from core.lint.registry import get_rule

    params = dict(params or {})
    env = env or LintEnv()
    cur = env.utcnow()
    store = LintStore.load(store_file)
    fid = native_id.split(":", 1)[1] if native_id.startswith("lint:") else native_id
    row = store.rows.get(fid)
    if row is None:
        raise ValueError(f"карточка {fid!r} не найдена")
    if row.get("status") != STATUS_PENDING:
        return {"outcome": "stale", "detail": f"находка уже решена ({row.get('status')})"}
    rule = get_rule(str(row.get("rule")))
    if rule is None or action not in rule.actions:
        raise ValueError(f"у правила {row.get('rule')!r} нет действия {action!r}")

    if action == "dismiss":
        days = settings.snooze_days()
        reason = str(params.get("reason") or "").strip()
        store.decide(fid, STATUS_DISMISSED, cur, reason=reason or "dismiss", days=days)
        out = {"outcome": "rejected", "detail": reason or "не проблема",
               "effects": [f"находка не вернется {days} дн."]}
        _audit(rule.name, "dismiss", row, "rejected")
    elif action == "snooze":
        days = int(float(params.get("days") or 7))
        store.decide(fid, STATUS_SNOOZED, cur, reason="snooze", days=days)
        out = {"outcome": "snoozed", "detail": f"Вернется через {days} дн.",
               "effects": [f"находка отложена на {days} дн."]}
        _audit(rule.name, "snooze", row, "snoozed", days=days)
    elif action in ("keep_a", "keep_b"):
        out = _keep(row, action, store, env, cur)
    elif action == "attach":
        out = _attach(row, params, store, env, cur)
    elif action == "mark":
        out = _mark(row, store, env, cur)
    elif action == "synth":
        out = _synth(row, store, env, cur, synthesize, ai_settings)
    elif action == "note":
        out = _note_claim(row, store, env, cur)
    else:  # pragma: no cover - реестр правил и ветки обязаны совпадать
        raise ValueError(f"неизвестное действие {action!r}")
    if out["outcome"] not in ("stale", "refused"):
        store.save()
    return out


# --------------------------------------------------------------------------- #
# explain                                                                       #
# --------------------------------------------------------------------------- #
def explain_card(row: dict[str, Any]) -> dict[str, Any]:
    """«Почему» по находке: правило, формула находки и доказательства с локаторами."""
    rule = str(row.get("rule"))
    meta = row.get("meta") or {}
    out: dict[str, Any] = {"rule": rule, "subject": row.get("subject"),
                           "status": row.get("status"), "since": row.get("created"),
                           "evidence": row.get("evidence") or []}
    if rule == "fact_conflict":
        out["why"] = ("два актуальных факта с одним ключом показателя (подпись, раздел, единица) "
                      "из РАЗНЫХ семейств версий документа имеют разные значения; вытесненные и "
                      "черновые факты в счет не входят")
        out["facts"] = [{
            "role": ("А" if e["fact_id"] == meta.get("a") else
                     "Б" if e["fact_id"] == meta.get("b") else "ещё"),
            "source": e["source_path"], "locator": f"{e['source_path']}#{e['locator']}",
            "label": e["label"], "value": e["value_raw"], "valid_from": e["valid_from"],
            "known_at": e["known_at"],
        } for e in out["evidence"]]
        out["choose"] = ("keep_a - оставить А (новее по дате документа), Б вытесняется; "
                         "keep_b - наоборот; вытесненному ставится valid_to = сегодня")
    elif rule == "orphan":
        out["why"] = ("заметка знаний без client/project и без ссылок на хабы (ни своих, ни из "
                      "тела хабов) старше порога; кандидаты - хабы, чьи имена/алиасы встретились "
                      "в заголовке, пути или тексте")
        out["candidates"] = row.get("candidates") or []
    elif rule == "duplicate":
        out["why"] = ("одинаковый hash индекса либо semantic-близость note→note выше порога при "
                      "том же стеме заголовка; версии одного файла и выходы дублями не считаются")
        out["via"] = meta.get("via")
        out["mark_effect"] = f"duplicate_of: {meta.get('older')} в более новой заметке"
    elif rule == "hub_stale":
        out["why"] = (f"хаб без правок {meta.get('age_days')} дн. при {meta.get('delta')} новых "
                      "элементах дельты (сборщики hub_synth: сделки, почта, выходы, заметки, "
                      "файлы, факты)")
        out["counts"] = meta.get("counts") or {}
    elif rule == "claim":
        out["why"] = ("утверждение текущего состояния хаба, которое дельта опровергает или "
                      "устаревает (модельный проход по кнопке, локатор обязателен)")
    return out
