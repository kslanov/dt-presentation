"""Модельный проход по хабу (R7б, P1): ``pult_ai(kind="hub_lint", payload={hub_id})``.

Единственное место линта, где участвует модель, и только по кнопке при включенном слое ИИ
(``pult.yaml: ai`` != none). Промпт - досье :func:`core.operational.hub_synth.context` (нынешнее
состояние + дельта) с заданием «назови утверждения хаба, которые дельта опровергает или
устаревает, каждое с локатором». Ответ проходит ту же проверку локаторов, что у синтеза: пункт без
локатора или с локатором вне досье отбрасывается (не находка), остальные становятся находками
правила ``claim`` в сторе линта; в хаб они попадают только действием ``note`` карточки
(``## Проверить (линт ДАТА)``). Без провайдера входа нет - остальной линт работает как раньше.
"""

from __future__ import annotations

import hashlib
import re
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any

from core.lint.store import LintStore, finding_id
from core.operational import hub_synth

__all__ = ["build_prompt", "parse_claims", "run_ai", "TASK"]

TASK = (
    "Назови утверждения из [Current state], которые свежие элементы [Delta] опровергают или "
    "делают устаревшими. Требования:\n"
    "- каждое утверждение - отдельная строка, начинающаяся с «- »: само утверждение (кратко, по "
    "тексту [Current state]) и в конце локатор в квадратных скобках ровно из блока [Delta] - того "
    "элемента, который его опровергает; несколько локаторов - через «; »; квадратные скобки больше "
    "ни для чего не используй;\n"
    "- не выдумывай: нет локатора из [Delta] - нет строки;\n"
    "- если таких утверждений нет, верни одну строку «Нет»;\n"
    "- верни только список; в хаб ничего не записывается, решит человек."
)
_NONE_RE = re.compile(r"^\W*нет\b", re.IGNORECASE)
_HUB_LINT_KIND = "hub_lint"


def build_prompt(ctx: dict[str, Any]) -> str:
    """Промпт досье синтеза с заменой блока ``[Task]`` на задание линта."""
    prompt = str(ctx["prompt"])
    head, sep, _task = prompt.rpartition("\n\n[Task]\n")
    return (head if sep else prompt) + f"\n\n[Task]\n{TASK}"


def parse_claims(text: str, known: set[str]) -> dict[str, Any]:
    """Разобрать ответ: ``{claims: [{claim, locators}], dropped: n, none: bool}``.

    Строка без локатора или с локатором вне ``known`` (досье) отбрасывается и считается в
    ``dropped``; «Нет» - ``none``."""
    parsed = hub_synth.parse_section(text, known)
    claims: list[dict[str, Any]] = []
    dropped = 0
    said_none = False
    for item in parsed["items"]:
        body = item["text"]
        if not item["locators"] and _NONE_RE.match(body):
            said_none = True
            continue
        locs = list(dict.fromkeys(item["locators"]))
        if not locs or any(loc not in known for loc in locs):
            dropped += 1
            continue
        claim = " ".join(re.sub(r"\[[^\[\]\n]+\]", "", body).split()).strip(" -;")
        if not claim:
            dropped += 1
            continue
        claims.append({"claim": claim, "locators": locs})
    return {"claims": claims, "dropped": dropped, "none": said_none and not claims}


def _claim_id(hub_id: str, claim: str) -> str:
    digest = hashlib.sha1(" ".join(claim.casefold().split()).encode()).hexdigest()[:10]  # noqa: S324
    return finding_id("claim", f"{hub_id}|{digest}")


def _evidence(ctx: dict[str, Any], locs: list[str]) -> list[dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    for kind in hub_synth.KINDS:
        for e in ctx["delta"].get(kind, []):
            if e["loc"] in locs and e["loc"] not in rows:
                rows[e["loc"]] = {"kind": kind, "loc": e["loc"], "date": e.get("date"),
                                  "line": hub_synth._line(kind, e)}
    return [rows[loc] for loc in locs if loc in rows]


def run_ai(
    hub_id: str,
    synthesize: Callable[[str, dict[str, Any]], dict[str, Any]],
    *,
    store_file: Path | None = None,
    now: datetime | None = None,
    **context_kwargs: Any,
) -> dict[str, Any]:
    """Проход по хабу: досье -> провайдер слоя ИИ -> проверка локаторов -> находки ``claim``.

    ``synthesize`` - :func:`core.operational.ai_layer.synthesize` (инъекция: провайдер, ключ, кэш и
    аудит там). Возврат как у остальных видов слоя ИИ: ``{ok, kind, text, provider, model, ...}`` +
    ``findings: [{id, claim, locators, state}]``, ``dropped``; отказ - ``{ok: false, code}``
    (``hub_not_found``, ``unsupported_entity``, ``no_state``, ``no_delta``, ``ai_disabled``,
    ``timeout`` ...). Находка, уже решенная человеком (стоп), заново не открывается."""
    try:
        ctx = hub_synth.context(hub_id, now=now, **context_kwargs)
    except hub_synth.SynthError as exc:
        return {"ok": False, "kind": _HUB_LINT_KIND, "code": exc.code, "text": None,
                "error": str(exc)}
    state = ctx["hub"]["current_state"]
    if not state:
        return {"ok": False, "kind": _HUB_LINT_KIND, "code": "no_state", "text": None,
                "error": "у хаба нет секции «Состояние»: проверять нечего"}
    if not any(ctx["limits"]["counts"].values()):
        return {"ok": False, "kind": _HUB_LINT_KIND, "code": "no_delta", "text": None,
                "error": "за период нет новых элементов: опровергать нечем"}
    res = synthesize(_HUB_LINT_KIND, {"hub_id": ctx["hub"]["id"], "prompt": build_prompt(ctx),
                                      "as_of": ctx["as_of"]})
    if not res.get("ok"):
        return res
    parsed = parse_claims(str(res.get("text") or ""), set(ctx["locators"]))
    cur = hub_synth._now(now)
    store = LintStore.load(store_file)
    findings: list[dict[str, Any]] = []
    title = ctx["hub"]["title"]
    for c in parsed["claims"]:
        fid = _claim_id(ctx["hub"]["id"], c["claim"])
        found = {
            "id": fid, "rule": "claim", "subject": ctx["hub"]["id"],
            "title": f"Проверить утверждение? {title}: {hub_synth._cut(c['claim'], 60)}",
            "reason": f"дельта хаба с {ctx['since']} опровергает: "
                      f"«{hub_synth._cut(c['claim'], 140)}» ({', '.join(c['locators'])})",
            "evidence": _evidence(ctx, c["locators"]),
            "meta": {"hub_id": ctx["hub"]["id"], "claim": c["claim"], "locators": c["locators"],
                     "model": res.get("model") or None, "since": ctx["since"]},
        }
        outcome = store.upsert(found, cur)
        findings.append({"id": fid, "claim": c["claim"], "locators": c["locators"],
                         "state": outcome})
    if findings:
        store.save()
    return {**res, "findings": findings, "dropped": parsed["dropped"], "none": parsed["none"]}
