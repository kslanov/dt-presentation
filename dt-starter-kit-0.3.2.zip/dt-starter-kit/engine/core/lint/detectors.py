"""Четыре детектора линта знаний (KNOWLEDGE-LINT-1): детерминированно, без LLM, только чтение.

Каждый берет :class:`~core.lint.env.LintEnv` и отдает :class:`~core.lint.env.DetectResult`:
находки (``id`` стабилен по правилу и ключу, повтор не плодит дубли) и честный ``partial``, если
бюджет прогона вышел раньше конца обхода (бегун тогда не снимает «исчезнувшие» находки правила).

* ``fact_conflict`` - тот же счет, что у доктора «Факты: время» (:func:`core.facts.versions.
  contradiction_groups`): актуальные факты одного ``fact_key`` из разных семейств версий с разными
  значениями; вытесненный факт и одно семейство противоречием не считаются;
* ``hub_stale`` - хаб без правок дольше ``DT_LINT_HUB_STALE_DAYS`` при дельте >= 3 элементов с датой
  (сборщики :mod:`core.operational.hub_synth` - не второй раз);
* ``orphan`` - заметка знаний без хаба и ссылок старше ``DT_LINT_ORPHAN_DAYS``; кандидаты - хабы
  по алиасам в заголовке/пути/тексте;
* ``duplicate`` - одинаковый ``hash`` индекс-манифеста либо ``semantic`` note→note из
  ``link_proposals`` со ``score >= DT_LINT_DUP_SCORE`` и тем же стемом заголовка; семейства версий
  одного файла и выходы (``07-outputs``/``type: output``) дублями не считаются.
"""

from __future__ import annotations

import logging
import re
import unicodedata
from datetime import date
from pathlib import Path
from typing import Any

from core.lint import settings
from core.lint.env import DetectResult, LintEnv
from core.lint.store import finding_id

logger = logging.getLogger(__name__)

__all__ = [
    "KNOWLEDGE_DIRS",
    "TITLES",
    "detect_duplicate",
    "detect_fact_conflict",
    "detect_hub_stale",
    "detect_orphan",
    "title_stem",
]

TITLES = {
    "fact_conflict": "Противоречие фактов?",
    "hub_stale": "Хаб устарел?",
    "orphan": "Заметка без хаба?",
    "duplicate": "Дубль?",
}
KNOWLEDGE_DIRS = ("02-knowledge/", "03-projects/")
_NOT_KNOWLEDGE_TYPES = ("hub", "output", "output-sources")
_HUB_DELTA_MIN = 3        # как STALE_MIN_DELTA у доктора «Синтез хабов»
_CANDIDATES_MAX = 3
_EVIDENCE_MAX = 10


def _cut(text: Any, n: int) -> str:
    s = " ".join(str(text or "").split())
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"


def _day(value: Any) -> str:
    """``YYYY-MM-DD`` из ISO-подобной строки; нет даты - пусто."""
    m = re.match(r"\s*(\d{4}-\d{2}-\d{2})", str(value or ""))
    return m.group(1) if m else ""


def _age_days(day: str, today: str) -> int | None:
    try:
        return (date.fromisoformat(today) - date.fromisoformat(day)).days
    except ValueError:
        return None


def _meta_day(meta: Any, vault: Path) -> str:
    """Дата заметки: frontmatter (``last_date``/``modified``/``created``), иначе mtime файла."""
    day = _day(getattr(meta, "date", ""))
    if day:
        return day
    try:
        stamp = (vault / meta.path).stat().st_mtime
    except OSError:
        return ""
    from datetime import UTC, datetime

    return datetime.fromtimestamp(stamp, UTC).date().isoformat()


def _is_knowledge_note(meta: Any) -> bool:
    """Заметка знаний: ``02-knowledge``/``03-projects``, не хаб и не выход, не служебный каталог."""
    path = str(getattr(meta, "path", "") or "")
    if not path.startswith(KNOWLEDGE_DIRS):
        return False
    if getattr(meta, "note_type", "") in _NOT_KNOWLEDGE_TYPES:
        return False
    from core.retrieval.notemeta import is_quarantined

    if is_quarantined(meta):  # EVAL-HYGIENE-1: прогон eval/selftest - не знание (orphan/duplicate)
        return False
    return not any(part.startswith("_") for part in path.split("/"))


def _hubs(metas: list[Any]) -> list[Any]:
    return sorted((m for m in metas if getattr(m, "note_type", "") == "hub"), key=lambda m: m.id)


# --------------------------------------------------------------------------- #
# fact_conflict                                                                 #
# --------------------------------------------------------------------------- #
def _fact_view(f: dict[str, Any]) -> dict[str, Any]:
    return {
        "fact_id": f["fact_id"], "source_path": f["source_path"], "locator": f["locator"],
        "label": f["label"], "section": f["section"], "value_raw": f["value_raw"],
        "value_num": f["value_num"], "unit": f["unit"], "currency": f["currency"],
        "valid_from": f["valid_from"], "known_at": f["known_at"],
    }


def detect_fact_conflict(env: LintEnv) -> DetectResult:
    from core.facts.versions import contradiction_groups

    res = DetectResult()
    try:
        groups = contradiction_groups(env.facts_db, today=env.today())
    except Exception as exc:  # noqa: BLE001 - стор фактов нечитаем: правило молчит с причиной
        res.note = f"стор фактов не прочитан: {type(exc).__name__}"
        res.skipped = True
        return res
    if groups is None:
        res.note = "схема стора старше v4 (нет осей времени)"
        res.skipped = True
        return res
    res.scanned = len(groups)
    for facts in groups:
        a, b = facts[0], facts[1]
        label = _cut(a["label"], 70)
        vals = "; ".join(
            f"{f['value_raw']} ({Path(str(f['source_path'])).name}, {f['locator']})"
            for f in facts[:4])
        fams = len({f["source_path"] for f in facts})
        res.findings.append({
            "id": finding_id("fact_conflict", str(a["fact_key"])),
            "rule": "fact_conflict", "subject": str(a["fact_key"]),
            "title": f"{TITLES['fact_conflict']} {label}",
            "reason": f"{len(facts)} актуальных значения одного показателя из {fams} документов: "
                      f"{vals}",
            "evidence": [_fact_view(f) for f in facts],
            "meta": {"fact_key": a["fact_key"], "a": a["fact_id"], "b": b["fact_id"],
                     "label": a["label"], "n": len(facts)},
        })
    return res


# --------------------------------------------------------------------------- #
# hub_stale                                                                     #
# --------------------------------------------------------------------------- #
def detect_hub_stale(env: LintEnv) -> DetectResult:
    from core.operational import hub_synth

    res = DetectResult()
    vault = env.vault_path()
    metas = env.metas()
    today = env.today()
    limit = settings.hub_stale_days()
    cached: tuple[list[Any], list[Any]] = (metas, [])
    for meta in _hubs(metas):
        if env.expired():
            res.partial = True
            res.note = "бюджет вышел: часть хабов не проверена"
            break
        last = _meta_day(meta, vault)
        age = _age_days(last, today) if last else None
        if age is None or age <= limit:
            continue
        res.scanned += 1
        try:
            got = hub_synth.delta_of(
                meta.id, last, vault_path=vault, mirror_path=env.mirror, now=env.utcnow(),
                facts_fn=env.facts_fn, load_metas=lambda _v: cached)
        except hub_synth.SynthError:
            continue  # хаб не разрешился (нет файла/NDA): линту нечего сказать
        except Exception as exc:  # noqa: BLE001 - сбой одного хаба не роняет правило
            logger.warning("[lint] hub_stale %s: дельта не собрана: %s", meta.id, exc)
            continue
        counts = got["counts"]
        total = sum(counts.values())
        if total < _HUB_DELTA_MIN:
            continue
        evidence: list[dict[str, Any]] = []
        for kind in hub_synth.KINDS:
            for e in got["delta"].get(kind, []):
                if len(evidence) >= _EVIDENCE_MAX:
                    break
                try:
                    line = hub_synth._line(kind, e)
                except Exception:  # noqa: BLE001 - строка для показа, не критична
                    line = str(e.get("loc") or "")
                evidence.append({"kind": kind, "loc": e.get("loc"), "date": e.get("date"),
                                 "line": line})
        shown = ", ".join(f"{k} {n}" for k, n in counts.items() if n)
        title = meta.h1 or meta.title or meta.id
        res.findings.append({
            "id": finding_id("hub_stale", meta.id), "rule": "hub_stale", "subject": meta.id,
            "title": f"{TITLES['hub_stale']} {_cut(title, 70)}",
            "reason": f"без правок {age} дн. (с {last}); новых элементов {total}: {shown}",
            "evidence": evidence,
            "meta": {"hub_id": meta.id, "entity": meta.entity, "last_edit": last, "age_days": age,
                     "delta": total, "counts": {k: n for k, n in counts.items() if n}},
        })
    return res


# --------------------------------------------------------------------------- #
# orphan                                                                        #
# --------------------------------------------------------------------------- #
_WIKI_RE = re.compile(r"\[\[([^\[\]|#]+?)(?:[|#][^\]]*)?\]\]")


def _hub_inbound(hubs: list[Any], vault: Path) -> set[str]:
    """Id заметок, на которые ссылается тело какого-либо хаба (``[[id]]``): такая не сирота."""
    out: set[str] = set()
    for hub in hubs:
        try:
            text = (vault / hub.path).read_text(encoding="utf-8")
        except OSError:
            continue
        out.update(m.group(1).strip() for m in _WIKI_RE.finditer(text))
    return out


def _hub_patterns(hubs: list[Any]) -> list[tuple[Any, re.Pattern[str]]]:
    """Регулярка по алиасам для каждого хаба (``_alias_pattern`` сборщиков ``hub_synth``)."""
    from core.operational.hub_synth import _alias_pattern

    out: list[tuple[Any, re.Pattern[str]]] = []
    for hub in hubs:
        pat = _alias_pattern({"aliases": list(hub.aliases), "title": hub.h1 or hub.title})
        if pat is not None:
            out.append((hub, pat))
    return out


def _orphan_candidates(
    meta: Any, body: str, patterns: list[tuple[Any, re.Pattern[str]]]
) -> list[dict[str, Any]]:
    head = f"{meta.title or ''}\n{meta.path}"
    out: list[dict[str, Any]] = []
    for hub, pat in patterns:
        if hub.id == meta.id:
            continue
        in_head = pat.findall(head)
        in_body = pat.findall(body)
        score = 3 * len(in_head) + len(in_body)
        if not score:
            continue
        found = pat.search(head) or pat.search(body)
        out.append({
            "hub_id": hub.id, "title": hub.h1 or hub.title or hub.id, "entity": hub.entity,
            "hits": score, "matched": found.group(0) if found else "",
            "where": "заголовок/путь" if in_head else "текст",
        })
    out.sort(key=lambda c: (-c["hits"], c["hub_id"]))
    return out[:_CANDIDATES_MAX]


def detect_orphan(env: LintEnv) -> DetectResult:
    from core.retrieval.notemeta import owner_ids

    res = DetectResult()
    vault = env.vault_path()
    metas = env.metas()
    hubs = _hubs(metas)
    hub_ids = {h.id for h in hubs}
    inbound = _hub_inbound(hubs, vault)
    patterns = _hub_patterns(hubs)
    today = env.today()
    limit = settings.orphan_days()
    for meta in sorted(metas, key=lambda m: m.path):
        if not _is_knowledge_note(meta):
            continue
        if env.expired():
            res.partial = True
            res.note = "бюджет вышел: часть заметок не проверена"
            break
        res.scanned += 1
        if owner_ids(meta) & hub_ids or meta.id in inbound:
            continue
        day = _meta_day(meta, vault)
        age = _age_days(day, today) if day else None
        if age is None or age <= limit:
            continue
        try:
            body = (vault / meta.path).read_text(encoding="utf-8")
        except OSError:
            body = ""
        cands = _orphan_candidates(meta, body, patterns)
        title = meta.title or meta.h1 or meta.id
        tail = (f"; кандидатов по алиасам: {len(cands)} ({cands[0]['hub_id']}"
                f"{'…' if len(cands) > 1 else ''})") if cands else "; кандидатов по алиасам нет"
        res.findings.append({
            "id": finding_id("orphan", meta.id), "rule": "orphan", "subject": meta.id,
            "title": f"{TITLES['orphan']} {_cut(title, 70)}",
            "reason": f"нет client/project и ссылок на хабы, заметке {age} дн. ({meta.path})"
                      + tail,
            "evidence": [{"loc": meta.id, "path": meta.path, "date": day, "title": meta.title}],
            "candidates": cands,
            "meta": {"note_id": meta.id, "path": meta.path, "age_days": age},
        })
    return res


# --------------------------------------------------------------------------- #
# duplicate                                                                     #
# --------------------------------------------------------------------------- #
_STEM_DROP = re.compile(
    r"\b(?:v|ver|rev|в|версия|version)\s*\.?\s*\d+(?:\.\d+)*\b"
    r"|\b\d{4}[-./]\d{2}[-./]\d{2}\b|\b\d{2}[-./]\d{2}[-./]\d{4}\b|\b(?:19|20)\d{2}\b"
    r"|\b(?:черновик|draft|финал|final|копия|copy|архив)\b",
    re.IGNORECASE,
)
_NON_WORD = re.compile(r"[^\w]+", re.UNICODE)


def title_stem(title: str) -> str:
    """Стем заголовка: NFC, регистр и ё свернуты, без дат/версий/пометок «черновик/финал/копия»."""
    text = unicodedata.normalize("NFC", str(title or "")).casefold().replace("ё", "е")
    text = _STEM_DROP.sub(" ", text)
    return " ".join(_NON_WORD.sub(" ", text).split())


def _real_source(meta: Any, vault: Path) -> str:
    """Файловый ``source_path`` заметки; у курированной (без него) NoteMeta несет путь заметки."""
    src = str(getattr(meta, "source_path", "") or "")
    if not src or src == str(vault / meta.path) or src == meta.path:
        return ""
    return src


def _same_family(a: Any, b: Any, vault: Path) -> bool:
    """Заметки порождены файлами ОДНОГО семейства версий (папка, похожие имена, класс файла)."""
    from core.sources.freshness import compatible_kinds, similar_names

    sa, sb = _real_source(a, vault), _real_source(b, vault)
    if not sa or not sb:
        return False
    pa, pb = Path(sa), Path(sb)
    return pa.parent == pb.parent and compatible_kinds(sa, sb) and similar_names(pa.name, pb.name)


def _already_marked(meta: Any, vault: Path) -> bool:
    from core.vault import FrontmatterError, read_frontmatter_fields_text

    try:
        text = (vault / meta.path).read_text(encoding="utf-8")
        return bool(read_frontmatter_fields_text(text, ("duplicate_of",))["duplicate_of"])
    except (OSError, FrontmatterError):
        return False


def _order(a: Any, b: Any, vault: Path) -> tuple[Any, Any]:
    """``(более новая, более старая)``: по дате заметки, затем по пути (детерминированно)."""
    ka = (_meta_day(a, vault), a.path)
    kb = (_meta_day(b, vault), b.path)
    return (a, b) if ka > kb else (b, a)


def detect_duplicate(env: LintEnv) -> DetectResult:
    res = DetectResult()
    vault = env.vault_path()
    scope: dict[str, Any] = {}
    for m in env.metas():
        if _is_knowledge_note(m):
            scope.setdefault(m.id, m)
    pairs: dict[tuple[str, str], dict[str, Any]] = {}

    def add(x: Any, y: Any, via: str, **extra: Any) -> None:
        if _same_family(x, y, vault):
            return  # версии одного файла - не дубли
        newer, older = _order(x, y, vault)
        key = (newer.id, older.id)
        slot = pairs.setdefault(key, {"newer": newer, "older": older, "via": [], "extra": {}})
        if via not in slot["via"]:
            slot["via"].append(via)
        slot["extra"].update(extra)

    # --- точные дубли: один hash в манифесте индекса ------------------------------------------
    manifest = _load_manifest(env.index_manifest)
    by_hash: dict[str, list[Any]] = {}
    for nid, entry in manifest.items():
        digest = str((entry or {}).get("hash") or "")
        if digest and nid in scope:
            by_hash.setdefault(digest, []).append(scope[nid])
    for digest, notes in sorted(by_hash.items()):
        if len(notes) < 2:
            continue
        ordered = sorted(notes, key=lambda m: (_meta_day(m, vault), m.path))
        base = ordered[0]  # самая старая - эталон; остальные - ее копии
        for other in ordered[1:]:
            add(other, base, "hash", hash=digest[:12])
    res.scanned = len(scope)

    # --- семантические: link_proposals note→note, score >= порога, тот же стем заголовка --------
    threshold = settings.dup_score()
    for row in _semantic_rows(env.link_proposals):
        if env.expired():
            res.partial = True
            res.note = "бюджет вышел: часть предложений ссылок не проверена"
            break
        if row.score < threshold or row.target_type == "hub":
            continue
        x, y = scope.get(row.source_note), scope.get(row.target_note)
        if x is None or y is None or x.id == y.id:
            continue
        sx = title_stem(x.title or x.h1 or x.id)
        if not sx or sx != title_stem(y.title or y.h1 or y.id):
            continue
        add(x, y, "semantic", score=round(row.score, 4))

    for (newer_id, older_id), slot in sorted(pairs.items()):
        newer, older = slot["newer"], slot["older"]
        if _already_marked(newer, vault):
            continue
        how = "+".join(slot["via"])
        extra = slot["extra"]
        proof = (f"одинаковый hash {extra['hash']}" if "hash" in extra
                 else f"semantic {extra.get('score')} и тот же заголовок")
        res.findings.append({
            "id": finding_id("duplicate", f"{newer_id}|{older_id}"),
            "rule": "duplicate", "subject": newer_id,
            "title": f"{TITLES['duplicate']} {_cut(newer.title or newer.id, 70)}",
            "reason": f"{proof}: «{_cut(newer.title or newer.id, 50)}» ({newer.path}) копия "
                      f"«{_cut(older.title or older.id, 50)}» ({older.path})",
            "evidence": [
                {"loc": newer_id, "path": newer.path, "date": _meta_day(newer, vault),
                 "role": "новая"},
                {"loc": older_id, "path": older.path, "date": _meta_day(older, vault),
                 "role": "старая"},
            ],
            "meta": {"newer": newer_id, "older": older_id, "via": how, **extra},
        })
    return res


def _load_manifest(path: Path | None) -> dict[str, dict[str, Any]]:
    """Манифест индекса ``{note_id: {hash, path, …}}`` (пусто, если его нет или он нечитаем)."""
    from core.config import index_manifest_path
    from core.retrieval.index import _load_manifest as load

    p = Path(path) if path else index_manifest_path()
    try:
        return load(p) if p.is_file() else {}
    except Exception as exc:  # noqa: BLE001 - манифест - производный: нет его - нет точных дублей
        logger.warning("[lint] манифест индекса не прочитан: %s", exc)
        return {}


def _semantic_rows(path: Path | None) -> list[Any]:
    from core.linking.propose import LinkProposalQueue

    try:
        queue = LinkProposalQueue.load(path)
    except OSError:
        return []
    return sorted((p for p in queue.by_id.values() if p.resolver == "semantic"),
                  key=lambda p: (-p.score, p.id))
