"""Окружение прогона линта: пути сторов, «сейчас», бюджет и инъекции (KNOWLEDGE-LINT-1).

Пусто - боевые значения из ``core.config``; тесты подставляют tmp-пути. Детекторы ничего не знают
о конфигурации - только о :class:`LintEnv`."""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

__all__ = ["DetectResult", "LintEnv"]


@dataclass
class DetectResult:
    """Итог одного детектора: находки + честная неполнота (бюджет вышел до конца обхода)."""

    findings: list[dict[str, Any]] = field(default_factory=list)
    partial: bool = False
    skipped: bool = False  # источник не прочитан: правило молчит, «исчезнувшее» НЕ снимается
    scanned: int = 0
    note: str = ""        # почему пусто/неполно (стор недоступен, бюджет)


@dataclass
class LintEnv:
    vault: Path | None = None
    facts_db: Path | None = None
    link_proposals: Path | None = None
    index_manifest: Path | None = None
    mirror: Path | None = None
    now: datetime | None = None
    budget_s: float | None = None          # бюджет ВСЕГО прогона, с; ``None`` - без предела
    load_metas: Callable[[Path], tuple[list[Any], list[Any]]] | None = None
    facts_fn: Callable[[str, str], list[Any]] | None = None
    _deadline: float | None = field(default=None, repr=False)

    def start(self) -> None:
        """Запустить часы бюджета (зовет бегун перед первым детектором)."""
        self._deadline = (time.monotonic() + self.budget_s) if self.budget_s else None

    def expired(self) -> bool:
        return self._deadline is not None and time.monotonic() > self._deadline

    def vault_path(self) -> Path:
        from core.config import default_vault_path

        return Path(self.vault) if self.vault else default_vault_path()

    def utcnow(self) -> datetime:
        cur = self.now or datetime.now(UTC)
        return cur.astimezone(UTC) if cur.tzinfo else cur.replace(tzinfo=UTC)

    def today(self) -> str:
        return self.utcnow().date().isoformat()

    def metas(self) -> list[Any]:
        """Срезы frontmatter всех заметок vault (кэш find_notes, NDA исключены)."""
        loader = self.load_metas
        if loader is None:
            from core.retrieval.fm_cache import load_metas_cached

            loader = load_metas_cached
        return list(loader(self.vault_path())[0])
