"""Реестр правил линта (KNOWLEDGE-LINT-1): один список, по которому идут прогон, доктор и карточки.

Правило - имя, подпись чипа, префикс заголовка карточки, детектор и имена действий. Новое правило =
новая запись здесь + (если нужны действия) ветка в :mod:`core.lint.actions`; контракт карточек и
виды очереди не меняются. Правило без детектора (``claim``) наполняется извне: модельным проходом
``pult_ai(kind="hub_lint")`` по кнопке, не ночным шагом.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from core.lint.env import DetectResult, LintEnv

__all__ = ["Rule", "RULES", "get_rule", "rule_names", "detector_rule_names"]


@dataclass(frozen=True)
class Rule:
    name: str
    label: str                 # чип правила в карточке пульта
    title: str                 # префикс заголовка карточки («Дубль?»)
    actions: tuple[str, ...]   # допустимые действия карточки
    detect: Callable[[LintEnv], DetectResult] | None = None


def _build() -> dict[str, Rule]:
    from core.lint import detectors as d

    rules = [
        Rule("fact_conflict", "Противоречие", "Противоречие фактов?",
             ("keep_a", "keep_b", "snooze", "dismiss"), d.detect_fact_conflict),
        Rule("hub_stale", "Хаб устарел", "Хаб устарел?",
             ("synth", "snooze", "dismiss"), d.detect_hub_stale),
        Rule("orphan", "Без хаба", "Заметка без хаба?",
             ("attach", "dismiss"), d.detect_orphan),
        Rule("duplicate", "Дубль", "Дубль?",
             ("mark", "dismiss"), d.detect_duplicate),
        Rule("claim", "Утверждение хаба", "Проверить утверждение?",
             ("note", "dismiss"), None),
    ]
    return {r.name: r for r in rules}


_RULES: dict[str, Rule] | None = None


def RULES() -> dict[str, Rule]:
    global _RULES
    if _RULES is None:
        _RULES = _build()
    return _RULES


def get_rule(name: str) -> Rule | None:
    return RULES().get(name)


def rule_names() -> tuple[str, ...]:
    return tuple(RULES())


def detector_rule_names() -> tuple[str, ...]:
    """Правила с детектором (их гонит ночной шаг); ``claim`` - только по кнопке."""
    return tuple(n for n, r in RULES().items() if r.detect is not None)
