"""Прогон линта: детекторы -> upsert в стор находок -> снятие исчезнувших (KNOWLEDGE-LINT-1).

Бюджет ``DT_LINT_BUDGET_S`` делится на весь прогон: правила идут от дешевых к дорогим
(``hub_stale`` собирает дельту хабов - самое долгое), вышел бюджет - правило честно ``partial``
(находки, успевшие появиться, сохраняются; «исчезнувшие» по такому правилу НЕ снимаются, потому что
обход был неполным). ``dry_run`` ничего не пишет: ни стор, ни сводку. Сбой одного правила не роняет
остальные и шаг цепочки.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any

from core.lint import settings
from core.lint.env import DetectResult, LintEnv
from core.lint.registry import RULES, detector_rule_names
from core.lint.store import LintStore, stamp, write_last_run

logger = logging.getLogger(__name__)

__all__ = ["RUN_ORDER", "pending_by_rule", "run_lint"]

# от дешевого к дорогому: бюджет не должен целиком уйти на дельты хабов
RUN_ORDER = ("fact_conflict", "orphan", "duplicate", "hub_stale")


def pending_by_rule(store: LintStore) -> dict[str, int]:
    out: dict[str, int] = {}
    for row in store.pending():
        out[str(row.get("rule"))] = out.get(str(row.get("rule")), 0) + 1
    return out


def _ordered(rules: list[str] | None) -> list[str]:
    known = detector_rule_names()
    wanted = [r for r in (rules or known) if r in known]
    return sorted(wanted, key=lambda r: RUN_ORDER.index(r) if r in RUN_ORDER else len(RUN_ORDER))


def run_lint(
    env: LintEnv | None = None,
    *,
    rules: list[str] | None = None,
    dry_run: bool = False,
    store_file: Path | None = None,
    last_file: Path | None = None,
) -> dict[str, Any]:
    """Прогнать детекторы ``rules`` (по умолчанию все с детектором) и обновить стор.

    Возвращает ``{ts, dry_run, partial, elapsed_s, rules: {имя: {found, new, updated, stopped,
    kept, resolved, partial, skipped, scanned, note, elapsed_s}}, pending: {правило: n},
    findings: [...]}``. Неизвестное правило в ``rules`` отбрасывается (``unknown_rules``)."""
    env = env or LintEnv()
    if env.budget_s is None:
        env.budget_s = settings.budget_s()
    now = env.utcnow()
    store = LintStore.load(store_file)
    known = set(detector_rule_names())
    unknown = [r for r in (rules or []) if r not in known]
    started = time.monotonic()
    env.start()
    report: dict[str, dict[str, Any]] = {}
    findings: list[dict[str, Any]] = []
    for name in _ordered(rules):
        rule = RULES()[name]
        assert rule.detect is not None  # noqa: S101 - detector_rule_names() отдает только такие
        t0 = time.monotonic()
        entry: dict[str, Any] = {"found": 0, "new": 0, "updated": 0, "stopped": 0, "kept": 0,
                                 "resolved": 0, "partial": False, "skipped": False,
                                 "scanned": 0, "note": "", "elapsed_s": 0.0}
        if env.expired():
            result = DetectResult(partial=True, note="бюджет вышел до старта правила")
        else:
            try:
                result = rule.detect(env)
            except Exception as exc:  # noqa: BLE001 - сбой правила не роняет остальные и шаг
                logger.warning("[lint] правило %s упало: %s", name, exc)
                result = DetectResult(skipped=True, note=f"{type(exc).__name__}: {str(exc)[:120]}")
        entry.update(found=len(result.findings), partial=result.partial, skipped=result.skipped,
                     scanned=result.scanned, note=result.note)
        for found in result.findings:
            outcome = store.upsert(found, now)
            entry[outcome if outcome in entry else "updated"] += 1
            findings.append(found)
        if not result.partial and not result.skipped:
            entry["resolved"] = store.resolve_missing(
                name, {f["id"] for f in result.findings}, now)
        entry["elapsed_s"] = round(time.monotonic() - t0, 3)
        report[name] = entry
    summary: dict[str, Any] = {
        "ts": stamp(now), "dry_run": dry_run,
        "partial": any(e["partial"] for e in report.values()),
        "elapsed_s": round(time.monotonic() - started, 3), "rules": report,
        "pending": pending_by_rule(store), "findings": findings,
    }
    if unknown:
        summary["unknown_rules"] = unknown
    if dry_run:
        # ничего не пишем: сводка показывает, что ПОЯВИЛОСЬ БЫ (new/updated - относительно стора)
        return summary
    store.save()
    summary["pending"] = pending_by_rule(store)
    write_last_run({k: v for k, v in summary.items() if k != "findings"}, last_file)
    return summary
