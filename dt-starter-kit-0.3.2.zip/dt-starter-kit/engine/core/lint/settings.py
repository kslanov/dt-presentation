"""KNOWLEDGE-LINT-1: пороги линта из ``DT_LINT_*`` (читаются при вызове, дефолты - в knobs)."""

from __future__ import annotations

import os

__all__ = [
    "BUDGET_ENV",
    "DUP_SCORE_ENV",
    "HUB_STALE_DAYS_ENV",
    "ORPHAN_DAYS_ENV",
    "PENDING_WARN_DAYS",
    "SNOOZE_DAYS_ENV",
    "budget_s",
    "dup_score",
    "hub_stale_days",
    "orphan_days",
    "snooze_days",
]

HUB_STALE_DAYS_ENV = "DT_LINT_HUB_STALE_DAYS"
ORPHAN_DAYS_ENV = "DT_LINT_ORPHAN_DAYS"
DUP_SCORE_ENV = "DT_LINT_DUP_SCORE"
SNOOZE_DAYS_ENV = "DT_LINT_SNOOZE_DAYS"
BUDGET_ENV = "DT_LINT_BUDGET_S"

# Находка старше стольких дней без решения - ``warn`` доктора «Линт знаний».
PENDING_WARN_DAYS = 30


def _num(name: str, default: float) -> float:
    raw = os.environ.get(name, "").strip()
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if value > 0 else default


def hub_stale_days() -> int:
    return int(_num(HUB_STALE_DAYS_ENV, 60))


def orphan_days() -> int:
    return int(_num(ORPHAN_DAYS_ENV, 14))


def dup_score() -> float:
    return _num(DUP_SCORE_ENV, 0.97)


def snooze_days() -> int:
    return int(_num(SNOOZE_DAYS_ENV, 30))


def budget_s() -> float:
    return _num(BUDGET_ENV, 120.0)
