"""Стор находок линта ``.derived/lint_findings.jsonl`` + сводка последнего прогона (LINT-1).

Находка - строка ``{id, rule, subject, title, reason, evidence[], candidates?, meta, created,
updated, status, decided_at, reason_decided, until}``. ``id`` стабилен по правилу и ключу
(:func:`finding_id`), поэтому повтор детектора - upsert по id, а не новая строка. Статусы:

* ``pending`` - ждет решения (в очереди карточек);
* ``snoozed`` / ``dismissed`` - стоп до ``until``; после срока находка, если причина жива, снова
  ``pending``;
* ``applied`` - решение выполнено (запись сделана); находка остается журналом и заново не
  открывается, пока она жива в детекторе;
* ``resolved`` - причина исчезла (хаб поправили, сирота получила хаб, факт вытеснен).

Стор производный и перестраиваемый: детекторы восстановят открытые находки за один прогон.
"""

from __future__ import annotations

import hashlib
import json
import os
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

__all__ = [
    "LintStore",
    "STATUSES",
    "STATUS_APPLIED",
    "STATUS_DISMISSED",
    "STATUS_PENDING",
    "STATUS_RESOLVED",
    "STATUS_SNOOZED",
    "finding_id",
    "read_last_run",
    "stamp",
    "write_last_run",
]

STATUS_PENDING = "pending"
STATUS_SNOOZED = "snoozed"
STATUS_DISMISSED = "dismissed"
STATUS_APPLIED = "applied"
STATUS_RESOLVED = "resolved"
STATUSES = (STATUS_PENDING, STATUS_SNOOZED, STATUS_DISMISSED, STATUS_APPLIED, STATUS_RESOLVED)
_STOPPED = (STATUS_SNOOZED, STATUS_DISMISSED)


def stamp(dt: datetime) -> str:
    dt = dt.astimezone(UTC) if dt.tzinfo else dt.replace(tzinfo=UTC)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def finding_id(rule: str, key: str) -> str:
    """Стабильный id находки: ``<правило>-<12 hex от правила и ключа>`` (ключ - предмет находки)."""
    digest = hashlib.sha1(f"{rule}|{key}".encode()).hexdigest()  # noqa: S324 - id, не защита
    return f"{rule}-{digest[:12]}"


class LintStore:
    """Строки находок по ``id``; ``save`` переписывает файл атомарно и в стабильном порядке."""

    def __init__(self, path: Path, rows: dict[str, dict[str, Any]] | None = None) -> None:
        self.path = Path(path)
        self.rows: dict[str, dict[str, Any]] = rows if rows is not None else {}

    @classmethod
    def load(cls, path: Path | None = None) -> LintStore:
        if path is None:
            from core.config import lint_findings_path

            path = lint_findings_path()
        rows: dict[str, dict[str, Any]] = {}
        p = Path(path)
        if p.is_file():
            for line in p.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue  # битая строка - стор производный: детектор пересоберет
                if isinstance(row, dict) and row.get("id"):
                    rows[str(row["id"])] = row
        return cls(p, rows)

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        ordered = sorted(self.rows.values(), key=lambda r: (str(r.get("created") or ""), r["id"]))
        body = "\n".join(json.dumps(r, ensure_ascii=False) for r in ordered)
        tmp = self.path.with_suffix(self.path.suffix + f".{os.getpid()}.tmp")
        tmp.write_text(body + ("\n" if body else ""), encoding="utf-8")
        tmp.replace(self.path)

    def pending(self, rule: str | None = None) -> list[dict[str, Any]]:
        """Ждут решения: статус ``pending`` (снятые стопы возвращает прогон детектора)."""
        rows = [r for r in self.rows.values()
                if r.get("status") == STATUS_PENDING and (rule is None or r.get("rule") == rule)]
        rows.sort(key=lambda r: (str(r.get("created") or ""), r["id"]))
        return rows

    def upsert(self, found: dict[str, Any], now: datetime) -> str:
        """Положить находку детектора: ``new`` | ``updated`` | ``stopped`` | ``kept``.

        Новый id - ``pending``. Живой ``pending`` - обновляются данные. Стоп (``snoozed``/
        ``dismissed``) до ``until`` не трогается; истекший - снова ``pending``. ``applied``
        остается журналом. ``resolved``, чья причина вернулась, - снова ``pending``."""
        cur = stamp(now)
        row = self.rows.get(found["id"])
        data = {k: found[k] for k in ("rule", "subject", "title", "reason", "evidence",
                                      "candidates", "meta") if k in found}
        if row is None:
            self.rows[found["id"]] = {
                "id": found["id"], **data, "status": STATUS_PENDING, "created": cur,
                "updated": cur, "decided_at": None, "reason_decided": "", "until": None,
            }
            return "new"
        status = row.get("status")
        if status in _STOPPED:
            if str(row.get("until") or "") > cur:
                return "stopped"
            row.update(data, status=STATUS_PENDING, updated=cur, until=None)
            return "updated"
        if status == STATUS_APPLIED:
            return "kept"
        if status == STATUS_RESOLVED:
            row.update(data, status=STATUS_PENDING, updated=cur, decided_at=None,
                       reason_decided="", until=None)
            return "new"
        row.update(data, updated=cur)
        return "updated"

    def resolve_missing(self, rule: str, live_ids: set[str], now: datetime) -> int:
        """Причина исчезла: ``pending``/``snoozed``/``dismissed`` правила, которых нет среди живых,
        становятся ``resolved``. Возвращает сколько снято. ``applied``/``resolved`` не трогаем."""
        cur = stamp(now)
        n = 0
        for row in self.rows.values():
            if row.get("rule") != rule or row["id"] in live_ids:
                continue
            if row.get("status") in (STATUS_PENDING, *_STOPPED):
                row.update(status=STATUS_RESOLVED, decided_at=cur, updated=cur,
                           reason_decided="причина исчезла", until=None)
                n += 1
        return n

    def decide(self, fid: str, status: str, now: datetime, *, reason: str = "",
               days: int | None = None) -> dict[str, Any]:
        """Решение по находке: статус, время, причина; для стопа - ``until`` через ``days``."""
        row = self.rows[fid]
        cur = stamp(now)
        row.update(status=status, decided_at=cur, updated=cur, reason_decided=reason[:500])
        row["until"] = stamp(now + timedelta(days=days)) if days else None
        return row


# --------------------------------------------------------------------------- #
# Сводка последнего прогона                                                     #
# --------------------------------------------------------------------------- #
def write_last_run(summary: dict[str, Any], path: Path | None = None) -> None:
    if path is None:
        from core.config import lint_last_path

        path = lint_last_path()
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(summary, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def read_last_run(path: Path | None = None) -> dict[str, Any] | None:
    if path is None:
        from core.config import lint_last_path

        path = lint_last_path()
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None
