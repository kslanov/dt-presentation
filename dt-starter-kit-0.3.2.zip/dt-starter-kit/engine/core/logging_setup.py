"""CODE-5-1 — единый логгер + correlation-id + токен-скраб (наблюдаемость, фаза 1).

Одна точка настройки логирования для всех CLI (и, позже, MCP). Инициализируется в
общей CLI-точке входа :func:`cli._env.load_env`, чтобы каждый CLI писал единообразно,
а не заводил свой handler (раньше это делал только ``cli/dt_sync``).

Ключевое решение (принцип 14): **лог остаётся человекочитаемым**, НЕ JSON —
пультовые текст-парсеры (``core.operational.pult.log_tail``/``sync_status``) читают
``dt-sync.log`` подстроками (`` ERROR ``/`` WARNING ``, «=== dt-sync … done …»).
Структуру для наблюдаемости кладём в ``core.eventlog``/``core.metrics`` (JSON), а не
в лог-файл. Формат строки::

    %(asctime)s %(levelname)s [%(corr_id)s] %(name)s: %(message)s

Содержит `` ERROR ``/`` WARNING `` (пульт-совместимо) и ``[run-xxxxxxxx]`` для сшивки
строк одного прогона (тот же ``corr_id`` уходит и в eventlog/metrics-события).

Инварианты: ``core`` ⊥ mcp/cli; best-effort (настройка лога не роняет CLI);
токен-скраб как defense-in-depth — секрет из ``.env`` не утечёт в лог ни из какого CLI.
"""

from __future__ import annotations

import contextlib
import logging
import os
import sys
import uuid
from contextvars import ContextVar
from logging.handlers import RotatingFileHandler
from pathlib import Path

__all__ = [
    "LOG_FORMAT",
    "get_corr_id",
    "new_corr_id",
    "register_secret",
    "reset_logging",
    "scrub_secrets",
    "set_corr_id",
    "setup_logging",
]

LOG_FORMAT = "%(asctime)s %(levelname)s [%(corr_id)s] %(name)s: %(message)s"
LOG_MAX_BYTES = 1_000_000  # rotate at ~1 MB (как было в dt_sync)
LOG_BACKUPS = 5

# Env-имена токенов, которые НИКОГДА не должны попасть в лог (скраб). Читаем
# значения лениво на каждую строку — токены грузятся из .env в load_env().
_SECRET_ENV_NAMES = ("TICKTICK_ACCESS_TOKEN", "TIMETTA_API_TOKEN", "DT_WEB_TOKEN")

# SEC-5: значения секретов, добытые НЕ из окружения (Keychain через
# :func:`core.secrets.get_secret`). После миграции секрета в Keychain + prune из
# ``.env`` его больше нет в ``os.environ`` — чтобы скраб-фильтр остался цел (не
# перестал маскировать этот токен), ``get_secret`` регистрирует добытое значение
# здесь. Множество, не лог: сами значения никогда не печатаются.
_registered_secrets: set[str] = set()

# correlation-id одного CLI-запуска / MCP-вызова. Пустая строка = не задан.
_corr_id: ContextVar[str] = ContextVar("dt_corr_id", default="")

# Шумные сторонние логгеры — глушим до WARNING, чтобы per-request INFO (httpx и
# т.п.) не забивал человекочитаемый dt-sync.log.
_NOISY_LOGGERS = ("httpx", "httpcore", "urllib3", "asyncio")


# --------------------------------------------------------------------------- #
# correlation-id                                                              #
# --------------------------------------------------------------------------- #
def new_corr_id() -> str:
    """Сгенерировать и установить свежий ``run-<8hex>`` для текущего прогона."""
    cid = f"run-{uuid.uuid4().hex[:8]}"
    _corr_id.set(cid)
    return cid


def set_corr_id(value: str) -> None:
    """Установить corr_id явно (``""`` — сбросить; для тестовой изоляции)."""
    _corr_id.set(value or "")


def get_corr_id() -> str:
    """Текущий corr_id (``""`` если не задан). eventlog/metrics шьют его только
    когда он реально установлен; лог-фильтр показывает ``-`` вместо пустого."""
    return _corr_id.get()


# --------------------------------------------------------------------------- #
# токен-скраб                                                                 #
# --------------------------------------------------------------------------- #
def register_secret(value: str | None) -> None:
    """Зарегистрировать секретное значение для скраба (SEC-5).

    Вызывается :func:`core.secrets.get_secret`, когда секрет добыт из Keychain
    (или из env). Так скраб-фильтр маскирует токен, даже если его уже нет в
    ``os.environ`` (мигрирован в Keychain + вырезан из ``.env``). Пустые/короткие
    значения игнорируем (защита от маскировки шума). Само значение не логируется.
    """
    if value and len(value) >= 8:
        _registered_secrets.add(value)


def _secret_values() -> list[str]:
    """Живые значения токенов для маскировки: из окружения + из Keychain (SEC-5)."""
    from_env = [v for n in _SECRET_ENV_NAMES if (v := os.environ.get(n))]
    return from_env + list(_registered_secrets)


def scrub_secrets(text: str) -> str:
    """Замаскировать любые токены из ``.env`` в тексте (``→ ***``).

    Общий скраб: используется formatter'ом лога (любая строка любого CLI) и
    напрямую (``cli/dt_sync`` чистит перехваченный stdout шага перед эхом)."""
    for secret in _secret_values():
        if secret:
            text = text.replace(secret, "***")
    return text


# --------------------------------------------------------------------------- #
# handlers / filters / formatter                                              #
# --------------------------------------------------------------------------- #
class _CorrIdFilter(logging.Filter):
    """Проставляет ``record.corr_id`` каждой записи (иначе ``%(corr_id)s``
    упал бы на записи стороннего логгера). Фильтр на handler'е → срабатывает для
    любой обрабатываемой записи независимо от логгера-источника."""

    def filter(self, record: logging.LogRecord) -> bool:
        record.corr_id = get_corr_id() or "-"
        return True


class _ScrubbingFormatter(logging.Formatter):
    """Человекочитаемый formatter, маскирующий токены во всей готовой строке
    (message + args) — defense-in-depth поверх точечного скраба в CLI."""

    def format(self, record: logging.LogRecord) -> str:
        return scrub_secrets(super().format(record))


def reset_logging() -> None:
    """Снять и закрыть наши handlers с root (идемпотентность + тестовая изоляция).

    Трогает ТОЛЬКО помеченные ``_dt_managed`` — сторонние (напр. caplog pytest)
    не задеваются. Также сбрасывает Keychain-регистрированные секреты (SEC-5) —
    тестовая изоляция: значение одного теста не «протекает» в скраб другого."""
    _registered_secrets.clear()
    root = logging.getLogger()
    for h in list(root.handlers):
        if getattr(h, "_dt_managed", False):
            root.removeHandler(h)
            with contextlib.suppress(Exception):
                h.close()


def setup_logging(
    *, log_path: Path | None = None, level: int = logging.INFO, console: bool = True
) -> None:
    """Настроить единый логгер на root: RotatingFile(``dt-sync.log``) + stderr.

    Идемпотентно (снимает свои прежние handlers) — безопасно звать из каждого
    ``load_env`` и из ``dt_sync.run`` с явным ``log_path``. Best-effort: сбой
    настройки лога никогда не роняет CLI. Формат — :data:`LOG_FORMAT`
    (человекочитаемый, пульт-совместимый); токен-скраб и corr_id — на каждом
    handler'е.
    """
    try:
        from core.config import sync_log_path

        path = Path(log_path) if log_path is not None else sync_log_path()
        path.parent.mkdir(parents=True, exist_ok=True)

        reset_logging()
        root = logging.getLogger()
        root.setLevel(level)

        formatter = _ScrubbingFormatter(LOG_FORMAT)
        corr_filter = _CorrIdFilter()

        handlers: list[logging.Handler] = [
            RotatingFileHandler(
                path, maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUPS, encoding="utf-8"
            )
        ]
        if console:
            handlers.append(logging.StreamHandler(sys.stderr))
        for h in handlers:
            h.setLevel(level)
            h.setFormatter(formatter)
            h.addFilter(corr_filter)
            h._dt_managed = True  # type: ignore[attr-defined]  # снимаем в reset_logging
            root.addHandler(h)

        for noisy in _NOISY_LOGGERS:
            logging.getLogger(noisy).setLevel(logging.WARNING)
    except Exception:  # noqa: BLE001, S110 — настройка лога не должна ронять CLI
        pass
