"""HOSTS-ATTACH-1 п.3 - байт-точный редактор ОДНОГО члена ``mcpServers`` в JSON-конфиге хоста.

Вынесен из ``core/kimi_install.py`` (KIMI-INSTALL-2) и обобщен: им пишут свою запись
``digital-twin`` в ``mcp.json`` агента Kimi, ``claude_desktop_config.json`` и
``~/.cursor/mcp.json``. Инварианты:

* правится ТОЛЬКО значение нашего члена (``mcpServers.<key>``) либо вставляется один член; все
  остальные байты файла (чужие серверы, неизвестные ключи, пробелы, переносы, CRLF, конец файла,
  порядок) остаются как были - итог сверяется с ожидаемым документом, при расхождении - полная
  перезапись в формате файла (отступ, конец строки);
* поля записи, которыми владеем (``owned``: ``command/args/env/cwd/url/headers/type``), заменяются
  целиком (смена stdio -> url не оставляет «гибрида»), чужие поля записи (``timeout``, ``disabled``)
  сохраняются;
* битый JSON / не-объект ``mcpServers`` - отказ ``invalid_json`` БЕЗ записи; нет файла - создается;
* запись - temp+rename с правами прежнего файла; перед заменой существующего файла - бэкап
  ``<файл>.bak-<время>`` рядом (:func:`backup_file`), идемпотентный повтор файл не трогает вовсе.

Чистая работа с файлом и текстом: ``core`` не зависит от CLI/MCP; токены (``headers.Authorization``)
здесь ничего не логируется и не печатается - редактор их только переносит как значения.
"""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

__all__ = [
    "OWNED_FIELDS",
    "McpJsonError",
    "EditResult",
    "backup_file",
    "install_member",
    "plan_member",
    "read_config",
    "remove_member",
    "write_text_atomic",
]

# Поля записи, которыми владеет генератор: меняются/снимаются целиком при смене формы записи.
OWNED_FIELDS = ("command", "args", "env", "cwd", "url", "headers", "type")
SERVERS_KEY = "mcpServers"


class McpJsonError(Exception):
    """Отказ редактора с машинным кодом (``invalid_json``)."""

    def __init__(self, code: str, reason: str) -> None:
        super().__init__(f"{code}: {reason}")
        self.code, self.reason = code, reason


@dataclass(frozen=True)
class EditResult:
    """Итог :func:`install_member`: ``outcome`` created|added|updated|unchanged, бэкап."""

    outcome: str
    path: Path
    backup: Path | None


# --- хирургическая правка текста: меняется только наш член ---------------------------------- #
# Файл уже проверен ``json.loads`` (комментариев и мусора нет), поэтому сканеру хватает строк,
# скобок и скаляров.

def _skip_ws(t: str, i: int) -> int:
    while i < len(t) and t[i] in " \t\r\n":
        i += 1
    return i


def _end_string(t: str, i: int) -> int:
    i += 1
    while t[i] != '"':
        i += 2 if t[i] == "\\" else 1
    return i + 1


def _end_value(t: str, i: int) -> int:
    if t[i] == '"':
        return _end_string(t, i)
    if t[i] in "{[":
        depth = 0
        while True:
            c = t[i]
            if c == '"':
                i = _end_string(t, i)
                continue
            if c in "{[":
                depth += 1
            elif c in "}]":
                depth -= 1
                if depth == 0:
                    return i + 1
            i += 1
    while i < len(t) and t[i] not in ",}] \t\r\n":
        i += 1
    return i


def _members(t: str, open_idx: int) -> tuple[list[tuple[str, int, int, int]], int]:
    """Члены объекта, открытого в ``open_idx``: ``[(ключ, начало_ключа, начало_значения,
    конец_значения)]`` и индекс закрывающей ``}``."""
    out: list[tuple[str, int, int, int]] = []
    i = _skip_ws(t, open_idx + 1)
    while t[i] != "}":
        ks = i
        ke = _end_string(t, i)
        i = _skip_ws(t, ke)  # двоеточие
        vs = _skip_ws(t, i + 1)
        ve = _end_value(t, vs)
        out.append((json.loads(t[ks:ke]), ks, vs, ve))
        i = _skip_ws(t, ve)
        if t[i] == ",":
            i = _skip_ws(t, i + 1)
    return out, i


def _line_lead(t: str, pos: int) -> str:
    """Пробельный отступ строки с ``pos`` (пусто, если до ``pos`` на строке есть не-пробелы)."""
    lead = t[t.rfind("\n", 0, pos) + 1:pos]
    return lead if not lead.strip() else ""


def _unit(t: str) -> str | None:
    """Единица отступа файла (``'    '``, ``'\\t'``); ``None`` - файл в одну строку."""
    if "\n" not in t.strip():
        return None
    for line in t.splitlines():
        stripped = line.lstrip(" \t")
        if stripped and stripped != line:
            return line[: len(line) - len(stripped)]
    return "  "


def _dump(value: Any, unit: str | None, indent: str, nl: str) -> str:
    text = json.dumps(value, ensure_ascii=False, indent=unit)
    return text.replace("\n", nl + indent) if unit is not None else text


def _member(key: str, value: Any, unit: str | None, indent: str, nl: str) -> str:
    return f"{json.dumps(key, ensure_ascii=False)}: {_dump(value, unit, indent, nl)}"


def _add_member(
    t: str, open_idx: int, key: str, value: Any, unit: str | None, nl: str, *, key_lead: str,
) -> str:
    """Вставить член ``key`` в объект, открытый в ``open_idx``; остальной текст не меняется."""
    members, close = _members(t, open_idx)
    if members:
        _, ks, _, ve = members[-1]
        indent = _line_lead(t, ks) or ((key_lead + unit) if unit else "")
        sep = (nl + indent) if unit is not None else " "
        return t[:ve] + "," + sep + _member(key, value, unit, indent, nl) + t[ve:]
    indent = key_lead + (unit or "")
    if unit is None:
        return t[:open_idx] + "{" + _member(key, value, unit, indent, nl) + "}" + t[close + 1:]
    body = nl + indent + _member(key, value, unit, indent, nl) + nl + key_lead + "}"
    return t[:open_idx] + "{" + body + t[close + 1:]


def _splice(text: str, key: str, block: dict[str, Any], entry: dict[str, Any] | None) -> str:
    """Новый текст (``text`` валиден и объект): член ``key`` добавлен либо его значение заменено на
    ``entry``; всё остальное - байт-в-байт."""
    unit = _unit(text)
    nl = "\r\n" if "\r\n" in text else "\n"
    root_open = _skip_ws(text, 0)
    members, _ = _members(text, root_open)
    servers = next((m for m in members if m[0] == SERVERS_KEY), None)
    if servers is None:  # нет mcpServers: добавить его членом корня (с нашей записью внутри)
        return _add_member(text, root_open, SERVERS_KEY, {key: block}, unit, nl, key_lead="")
    _, ks, vs, _ = servers
    own, _ = _members(text, vs)
    mine = next((m for m in own if m[0] == key), None)
    if mine is None:
        return _add_member(text, vs, key, block, unit, nl, key_lead=_line_lead(text, ks))
    _, mks, mvs, mve = mine
    indent = _line_lead(text, mks)
    return text[:mvs] + _dump(entry, unit, indent, nl) + text[mve:]


def read_config(path: Path) -> tuple[dict[str, Any] | None, str | None, str | None]:
    """``(документ | None, текст | None, ошибка)``: нет файла -> ``(None, None, None)``.

    Байты читаются как есть (CRLF не нормализуем). Не JSON / не объект / ``mcpServers`` не объект -
    ошибка с путем и причиной (текст ошибки не содержит содержимого файла: там бывают токены)."""
    path = Path(path)
    if not path.is_file():
        return None, None, None
    try:
        text = path.read_bytes().decode("utf-8")
        data = json.loads(text)
    except (OSError, UnicodeDecodeError) as exc:
        return None, None, f"{path}: {type(exc).__name__}"
    except json.JSONDecodeError as exc:
        return None, None, f"{path}: не JSON (строка {exc.lineno}, столбец {exc.colno})"
    servers = data.get(SERVERS_KEY) if isinstance(data, dict) else None
    if not isinstance(data, dict) or (SERVERS_KEY in data and not isinstance(servers, dict)):
        return None, None, f"{path}: нет объекта {SERVERS_KEY}"
    return data, text, None


def write_text_atomic(path: Path, text: str) -> None:
    """Целиком, temp+rename, права как у прежнего файла."""
    path = Path(path)
    tmp = path.parent / f".{path.name}.dt-tmp-{os.getpid()}"
    try:
        tmp.write_bytes(text.encode("utf-8"))
        if path.exists():
            shutil.copymode(path, tmp)
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def backup_file(path: Path, now: datetime | None = None) -> Path:
    """Копия ``<файл>.bak-<YYYYmmddTHHMMSS>`` рядом (``copy2``: права и время); при коллизии имени -
    суффикс ``-2``, ``-3``…. Возвращает путь копии."""
    path = Path(path)
    stamp = (now or datetime.now()).strftime("%Y%m%dT%H%M%S")
    target = path.with_name(f"{path.name}.bak-{stamp}")
    n = 1
    while target.exists():
        n += 1
        target = path.with_name(f"{path.name}.bak-{stamp}-{n}")
    shutil.copy2(path, target)
    return target


def _merge(
    data: dict[str, Any] | None, key: str, block: dict[str, Any], owned: tuple[str, ...]
) -> tuple[dict[str, Any], str]:
    """Ожидаемый документ и исход: ``created`` | ``added`` | ``updated`` | ``unchanged``.

    Владеемые поля (``owned``) записи заменяются блоком целиком; прочие поля нашей записи
    сохраняются. Документ ``data`` не мутируется."""
    if data is None:
        return {SERVERS_KEY: {key: dict(block)}}, "created"
    doc = json.loads(json.dumps(data))  # глубокая копия
    servers = doc.get(SERVERS_KEY)
    if not isinstance(servers, dict):
        doc[SERVERS_KEY] = servers = {}
    current = servers.get(key)
    if isinstance(current, dict):
        merged = dict(block)
        merged.update({k: v for k, v in current.items() if k not in owned and k not in block})
        if merged == current:
            return doc, "unchanged"
        servers[key] = merged
        return doc, "updated"
    servers[key] = dict(block)
    return doc, "added"


def plan_member(
    text: str | None, doc: dict[str, Any] | None, key: str, block: dict[str, Any],
    *, owned: tuple[str, ...] = OWNED_FIELDS,
) -> tuple[str | None, str]:
    """``(новый текст | None если менять нечего, исход)`` для члена ``mcpServers.<key>``.

    Правка точечная (:func:`_splice`); результат сверяется с ожидаемым документом, при расхождении -
    полная перезапись в формате файла (отступ, конец строки), чужие данные сохраняются по
    значению."""
    expected, outcome = _merge(doc, key, block, owned)
    if outcome == "unchanged":
        return None, outcome
    if text is None:
        return json.dumps(expected, ensure_ascii=False, indent=2) + "\n", outcome
    entry = expected[SERVERS_KEY][key]
    try:
        spliced = _splice(text, key, block, entry)
        if json.loads(spliced) == expected:
            return spliced, outcome
    except (ValueError, IndexError):
        pass
    unit = _unit(text)
    full = json.dumps(expected, ensure_ascii=False, indent=unit)
    return full + ("\n" if text.endswith("\n") else ""), outcome


def install_member(
    path: Path, key: str, block: dict[str, Any], *, owned: tuple[str, ...] = OWNED_FIELDS,
    backup: bool = True, now: datetime | None = None,
) -> EditResult:
    """Записать член ``mcpServers.<key>`` в конфиг ``path`` (нет файла - создать).

    Битый JSON - :class:`McpJsonError` ``invalid_json`` без записи. Существующий файл перед
    заменой копируется в ``<файл>.bak-<время>``; ``unchanged`` - ни бэкапа, ни записи."""
    path = Path(path)
    doc, text, error = read_config(path)
    if error:
        raise McpJsonError("invalid_json", f"{error}; не перезаписываю")
    new_text, outcome = plan_member(text, doc, key, block, owned=owned)
    if new_text is None:
        return EditResult(outcome, path, None)
    saved = backup_file(path, now) if backup and path.is_file() else None
    path.parent.mkdir(parents=True, exist_ok=True)
    write_text_atomic(path, new_text)
    return EditResult(outcome, path, saved)


def _cut_member(text: str, key: str) -> str | None:
    """Текст без члена ``mcpServers.<key>`` (запятая и отступы соседей приводятся в порядок);
    ``None`` - такого члена нет. Остальные байты файла не меняются."""
    root_open = _skip_ws(text, 0)
    members, _ = _members(text, root_open)
    servers = next((m for m in members if m[0] == SERVERS_KEY), None)
    if servers is None:
        return None
    _, _ks, vs, _ve = servers
    own, close = _members(text, vs)
    names = [m[0] for m in own]
    if key not in names:
        return None
    i = names.index(key)
    _, mks, _mvs, mve = own[i]
    if len(own) == 1:
        return text[:vs] + "{}" + text[close + 1:]
    if i < len(own) - 1:
        return text[:mks] + text[own[i + 1][1]:]  # наш член вместе с запятой и отступом после него
    return text[:own[i - 1][3]] + text[mve:]  # последний: с запятой и отступом ПЕРЕД ним


def remove_member(
    path: Path, key: str, *, backup: bool = True, now: datetime | None = None,
) -> EditResult:
    """Снять член ``mcpServers.<key>`` (``dt uninstall``): исход ``removed`` | ``absent``.

    Те же гарантии, что у :func:`install_member`: битый JSON - отказ без записи; перед правкой
    бэкап ``<файл>.bak-<время>``; нет файла/члена - файл не трогается; итог сверяется с ожидаемым
    документом (при расхождении правка отменяется, а не «почти»)."""
    path = Path(path)
    doc, text, error = read_config(path)
    if error:
        raise McpJsonError("invalid_json", f"{error}; не перезаписываю")
    if doc is None or text is None:
        return EditResult("absent", path, None)
    new_text = _cut_member(text, key)
    if new_text is None:
        return EditResult("absent", path, None)
    want = {k: v for k, v in doc.items() if k != SERVERS_KEY}
    servers = {k: v for k, v in (doc.get(SERVERS_KEY) or {}).items() if k != key}
    if SERVERS_KEY in doc:
        want[SERVERS_KEY] = servers
    try:
        ok = json.loads(new_text) == {k: want[k] for k in doc if k in want}
    except ValueError:
        ok = False
    if not ok:
        unit = _unit(text)
        nl = "\r\n" if "\r\n" in text else "\n"
        new_text = json.dumps({k: want[k] for k in doc if k in want}, ensure_ascii=False,
                              indent=unit) + (nl if text.endswith(("\n", "\r\n")) else "")
    saved = backup_file(path, now) if backup else None
    write_text_atomic(path, new_text)
    return EditResult("removed", path, saved)
