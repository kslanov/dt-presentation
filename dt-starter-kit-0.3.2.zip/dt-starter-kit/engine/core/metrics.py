"""KPI-1 — журнал событий метрик когнитивной нагрузки (roadmap §4a, v1).

The honest data layer under the question «стал ли автор меньше помнить/делать
руками»: an append-only JSONL journal of *events* (``.derived/metrics/
events.jsonl``); interpretation and thresholds come later (``dt-kpi`` renders
the v1 summary). Instrumented points write one line each: inbox refinement
applied, a queue decision settled (incl. AUTON-1 auto-applies), links applied,
a retrieval policy run.

Rules:

* **Best-effort, never in the way.** :func:`record_event` swallows every
  exception — a metrics failure must NEVER break the operation being measured.
* **Privacy.** No client names, deal names, amounts or note texts in events —
  only kinds, counters, top-level folders and generic use-case ids (the same
  discipline as the dt-sync logs).
* **Path is a function** (TEST-SANDBOX-1): :func:`core.config.events_path`, read at
  call time from ``DT_DERIVED_ROOT``. Tests isolate via that ONE env var (an autouse
  fixture in ``tests/conftest.py``) — it is inherited by subprocesses, unlike a
  ``monkeypatch`` of a module attribute — so no test ever writes the real journal.

Invariant: ``core/`` depends on neither MCP nor CLI; no network, no LLM here.
"""

from __future__ import annotations

import json
from collections.abc import Iterable
from contextvars import ContextVar
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import events_path

__all__ = [
    "DEGRADATION_KIND",
    "record_event",
    "read_events",
    "summarize",
    "degradation_summary",
    "TOOL_CALL_KIND",
    "UI_TABS",
    "UI_SECTIONS",
    "UI_PREFIX",
    "valid_ui_name",
    "usage_summary",
    "count_tool_calls",
    "note_call_detail",
    "read_tool_calls",
    "take_call_detail",
    "RERANK_DETAIL_KEYS",
]

# Append-only event journal: путь — функция ``core.config.events_path()`` (TEST-SANDBOX-1:
# корень производных данных читается в момент вызова из ``DT_DERIVED_ROOT``, не при импорте).

# FAIL-TELEMETRY-1 — вид события «инструмент деградировал/отказал». Константа здесь,
# а не у писателя (граница MCP): пишущий и читающий обязаны звать одну строку, иначе
# телеметрия молча считает пустоту.
DEGRADATION_KIND = "tool_degradation"

# WAVE1-MEASURE п.2 (аудит A1) — вид события «инструмент вызван»: ``{tool, ok, ms}`` и
# ничего больше (ни аргументов, ни текстов — только имя, исход и длительность). Пишет
# граница MCP одной точкой (``guarded_tool``); те же события несут открытия поверхностей
# пульта под именем ``ui:<tab|sec>:<имя>`` (одна запись на вкладку/секцию).
# VENDOR-HYGIENE-1 п.3: + ``host`` (имя из handshake / ``webpult`` / ``cli``) и ``surface``
# (``mcp`` | ``webpult`` | ``cli``) — те же поля, никаких новых данных о пользователе.
TOOL_CALL_KIND = "tool_call"
UI_PREFIX = "ui:"

# RETR-RERANK-1 п.2: ``find_notes`` докладывает итоги второго этапа В ТО ЖЕ событие ``tool_call``
# (новые поля detail, не новая метрика): ``rerank_ms`` (время этапа), ``rerank_pool`` (сколько
# кандидатов переоценено), ``rerank_device`` (mps|cpu|…). Только числа и имя устройства.
# Канал от инструмента к границе MCP — контекстная переменная: событие пишет ОДНА точка.
RERANK_DETAIL_KEYS: tuple[str, ...] = ("rerank_ms", "rerank_pool", "rerank_device")
_CALL_DETAIL: ContextVar[dict[str, Any] | None] = ContextVar("dt_call_detail", default=None)


def note_call_detail(**fields: Any) -> None:
    """Поля в detail СВОЕГО ``tool_call`` инструмента (только ключи :data:`RERANK_DETAIL_KEYS`)."""
    kept = {k: v for k, v in fields.items() if k in RERANK_DETAIL_KEYS and v is not None}
    if kept:
        cur = dict(_CALL_DETAIL.get() or {})
        cur.update(kept)
        _CALL_DETAIL.set(cur)


def take_call_detail() -> dict[str, Any]:
    """Забрать и сбросить накопленные поля (границa MCP, один раз на вызов)."""
    cur = _CALL_DETAIL.get()
    if cur:
        _CALL_DETAIL.set(None)
        return cur
    return {}

# Закрытый словарь поверхностей пульта: вкладки и секции (``data-help`` у ``.sechead``). Закрытый —
# чтобы в журнал нельзя было записать произвольную строку с клиента (privacy), и чтобы «секции без
# открытий» было с чем сравнивать. Дрейф от ``webpult/pult.html`` стережёт
# ``tests/test_usage_telemetry.py``. ``personal`` - не вкладка, а РЕЖИМ пульта «Личное»
# (PERSONAL-2): отмечается при открытии пульта в нем.
UI_TABS: tuple[str, ...] = ("work", "twin", "mon", "set", "personal")
UI_SECTIONS: tuple[str, ...] = (
    "ai-synth", "connectors", "create", "doctor", "eval-quality", "function", "hosts", "inbox",
    "links", "log", "monitor", "owner", "queue", "ripe", "services", "store-actions",
    "store-journal", "store-paths", "store-refusals", "store-sources", "store-trace",
    "trend",
    "webpult", "work-attention", "work-meetings", "work-resurface", "work-stale",
    # PERSONAL-2: секции режима «Личное»
    "pers-today", "pers-recall", "pers-bridge", "pers-bridge-settings", "pers-folders",
)


def valid_ui_name(name: str) -> bool:
    """``tab:<вкладка>`` / ``sec:<секция>`` из закрытого словаря (без префикса ``ui:``)."""
    kind, _, key = str(name).partition(":")
    return (kind == "tab" and key in UI_TABS) or (kind == "sec" and key in UI_SECTIONS)


def record_event(kind: str, **fields: Any) -> None:
    """Append one ``{ts, kind, **fields}`` line — best-effort, never raises.

    ``ts`` is stamped automatically (UTC, ISO-8601). Any failure (unwritable
    path, non-serializable field, full disk) is swallowed: metrics observe the
    engine, they never get to break it.
    """
    try:
        event = {
            "ts": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "kind": str(kind),
            **fields,
        }
        # CODE-5-1: сшивка с логом — corr_id только когда реально задан (CLI-запуск
        # /MCP-вызов); прямые вызовы/тесты без прогона событие не меняют.
        if "corr_id" not in event:
            try:
                from core.logging_setup import get_corr_id

                if cid := get_corr_id():
                    event["corr_id"] = cid
            except Exception:  # noqa: BLE001, S110 — corr_id опционален
                pass
        line = json.dumps(event, ensure_ascii=False, default=str)
        target = events_path()
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:  # noqa: BLE001, S110 — метрики никогда не ломают операцию
        pass


def _parse_ts(value: Any) -> datetime | None:
    """Tolerant ISO-8601 → aware UTC datetime, else None."""
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def _read_lines(target: Path) -> list[str] | None:
    """Строки журнала; ``None`` — файл ЕСТЬ, но не прочитался (стор недоступен).

    Отличать «журнала нет / он пуст» от «журнал не прочитался» приходится ровно
    там, где по счётчикам делают вывод: :func:`degradation_summary` обязана сказать
    «стор недоступен», а не показать честный на вид ноль (канон §9 п.22 — на себе).
    :func:`read_events` этой разницей не пользуется и продолжает отдавать ``[]``.
    """
    if not target.is_file():
        return []
    try:
        return target.read_text(encoding="utf-8").splitlines()
    except OSError:
        return None


def read_events(
    since: datetime | str | None = None, *, path: Path | None = None
) -> list[dict[str, Any]]:
    """Read journal events (oldest first), optionally only those at/after ``since``.

    Missing file → ``[]``; corrupt lines and events without a parseable ``ts``
    (when a ``since`` filter is active) are skipped — the journal is derived,
    rebuildable data, never a reason to fail.
    """
    target = Path(path) if path is not None else events_path()
    cutoff = _parse_ts(since) if not isinstance(since, datetime) else since
    if isinstance(cutoff, datetime) and cutoff.tzinfo is None:
        cutoff = cutoff.replace(tzinfo=UTC)

    lines = _read_lines(target)
    return [] if lines is None else _events_from_lines(lines, cutoff)


def _read_events_skip_tool_calls(
    since: datetime, *, path: Path | None = None
) -> list[dict[str, Any]]:
    """События окна БЕЗ ``tool_call`` (их разбор — только в :func:`usage_summary`)."""
    target = Path(path) if path is not None else events_path()
    lines = _read_lines(target)
    return [] if lines is None else _events_from_lines(lines, since, skip_tool_calls=True)


# Подстрока, по которой строку tool_call можно отбросить БЕЗ json-разбора: их в журнале на
# порядок больше всех остальных видов (каждый вызов инструмента), а ``summarize`` их не читает.
_TOOL_CALL_MARK = f'"kind": "{TOOL_CALL_KIND}"'


def _events_from_lines(
    lines: list[str], cutoff: datetime | None, *, skip_tool_calls: bool = False
) -> list[dict[str, Any]]:
    """Строки журнала → события окна (битые строки и события без ``ts`` пропускаем)."""
    events: list[dict[str, Any]] = []
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if skip_tool_calls and _TOOL_CALL_MARK in line:
            continue
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(event, dict):
            continue
        if cutoff is not None:
            ts = _parse_ts(event.get("ts"))
            if ts is None or ts < cutoff:
                continue
        events.append(event)
    return events


def read_tool_calls(
    since: datetime, *, path: Path | None = None
) -> list[dict[str, Any]] | None:
    """События ``tool_call`` окна ``[since ..]`` (DAEMON-1: сессии по хостам для доктора).

    ``None`` - журнал есть, но не прочитался (как у :func:`count_tool_calls`: неизвестно ≠ 0)."""
    target = Path(path) if path is not None else events_path()
    lines = _read_lines(target)
    if lines is None:
        return None
    return _events_from_lines([ln for ln in lines if _TOOL_CALL_MARK in ln], since)


def _share(part: int, total: int) -> float | None:
    """Доля 0..1 (None при пустом знаменателе — «сигнала нет», не 0%)."""
    return round(part / total, 4) if total else None


def summarize(
    days: int = 7, *, now: datetime | None = None, path: Path | None = None
) -> dict[str, Any]:
    """Сводка метрик 1–3 за окно ``days`` — данные, не текст (ADMIN-1 v2A).

    Единственный источник цифр для обоих потребителей: ``cli/dt_kpi.py`` рендерит
    из этого dict плоский текст, MCP-инструмент ``pult_kpi`` отдаёт его как есть —
    сводка не дублируется. Счётчики и доли (метрики 1–3 v1: применённые разметки
    инбокса, retrieval-прогоны с наполненностью, решения очереди) плюс ``daily`` —
    ряд по дням окна (старые → новые) для тренда на пульте. Privacy как в журнале:
    только счётчики/типы, без имён и сумм.
    """
    days = max(1, days)
    now_dt = now or datetime.now(UTC)
    since = now_dt - timedelta(days=days)
    events = _read_events_skip_tool_calls(since, path=path)

    inbox = [e for e in events if e.get("kind") == "inbox_applied"]
    retrievals = [e for e in events if e.get("kind") == "retrieval_run"]
    decisions = [e for e in events if e.get("kind") == "queue_decision"]
    links = [e for e in events if e.get("kind") == "links_applied"]

    with_hits = sum(1 for e in retrievals if int(e.get("hits") or 0) > 0)

    by_decision: dict[str, int] = {}
    for e in decisions:
        d = str(e.get("decision") or "?")
        by_decision[d] = by_decision.get(d, 0) + 1
    ok = by_decision.get("approved", 0) + by_decision.get("auto", 0)

    links_by_resolver: dict[str, int] = {}
    for e in links:
        r = str(e.get("resolver") or "?")
        links_by_resolver[r] = links_by_resolver.get(r, 0) + int(e.get("count") or 0)

    # Ряд по дням окна (UTC-даты, старые → новые); дни без событий — нули,
    # чтобы тренд на пульте не «схлопывал» тихие дни.
    day_keys = [
        (now_dt - timedelta(days=offset)).strftime("%Y-%m-%d")
        for offset in range(days - 1, -1, -1)
    ]
    daily: dict[str, dict[str, int]] = {
        day: {"inbox_applied": 0, "retrieval_runs": 0, "queue_decisions": 0,
              "links_applied": 0}
        for day in day_keys
    }
    per_kind = (
        ("inbox_applied", inbox),
        ("retrieval_runs", retrievals),
        ("queue_decisions", decisions),
    )
    for field_name, rows in per_kind:
        for e in rows:
            ts = _parse_ts(e.get("ts"))
            day = ts.strftime("%Y-%m-%d") if ts else None
            if day in daily:
                daily[day][field_name] += 1
    for e in links:
        ts = _parse_ts(e.get("ts"))
        day = ts.strftime("%Y-%m-%d") if ts else None
        if day in daily:
            daily[day]["links_applied"] += int(e.get("count") or 0)

    return {
        "days": days,
        "journal": str(path or events_path()),
        "events": len(events),
        "inbox": {"applied": len(inbox)},
        "retrieval": {
            "runs": len(retrievals),
            "with_hits": with_hits,
            "share_with_hits": _share(with_hits, len(retrievals)),
        },
        "queue": {
            "decisions": len(decisions),
            "approved": by_decision.get("approved", 0),
            "auto": by_decision.get("auto", 0),
            "rejected": by_decision.get("rejected", 0),
            "no_reject_share": _share(ok, len(decisions)),
        },
        "links": {"applied_by_resolver": links_by_resolver},
        "daily": [{"date": day, **counts} for day, counts in daily.items()],
    }


def degradation_summary(
    days: int = 7, *, now: datetime | None = None, path: Path | None = None
) -> dict[str, Any]:
    """FAIL-TELEMETRY-1 — счётчики отказов инструментов ``tool × code`` за окно.

    Читает СВОЙ журнал (события :data:`DEGRADATION_KIND`, которые пишет граница MCP)
    и складывает их в пары «инструмент : код», от частых к редким. Никакого нового
    стейта: стор — тот же ``events.jsonl``, окно — то же, что у :func:`summarize`.

    Отвечает ``{days, journal, total, counters:[{tool, code, count}], warning?}``.
    Журнал не прочитался → ``total: 0`` И конверт ``store_unavailable`` (канон §9
    п.22 применённый к самой телеметрии: молчаливый ноль здесь означал бы «агенты не
    спотыкались», то есть ровно ту ложь, которую эта телеметрия и ловит).
    """
    days = max(1, days)
    now_dt = now or datetime.now(UTC)
    target = Path(path) if path is not None else events_path()
    out: dict[str, Any] = {
        "days": days,
        "journal": str(target),
        "total": 0,
        "counters": [],
    }

    lines = _read_lines(target)
    if lines is None:
        from core.contract import CODE_STORE_UNAVAILABLE, add_warning

        return add_warning(
            out, CODE_STORE_UNAVAILABLE,
            f"журнал метрик не прочитался: {target} — счётчики отказов НЕ собраны "
            "(ноль здесь означал бы «отказов не было»)",
            journal=str(target),
        )

    events = [
        e
        for e in _events_from_lines(lines, now_dt - timedelta(days=days))
        if e.get("kind") == DEGRADATION_KIND
    ]
    pairs: dict[tuple[str, str], int] = {}
    for e in events:
        key = (str(e.get("tool") or "?"), str(e.get("code") or "?"))
        pairs[key] = pairs.get(key, 0) + 1

    out["total"] = len(events)
    out["counters"] = [
        {"tool": tool, "code": code, "count": count}
        # частые вперёд; при равенстве — по имени, чтобы порядок был устойчив
        for (tool, code), count in sorted(pairs.items(), key=lambda kv: (-kv[1], kv[0]))
    ]
    return out


def count_tool_calls(
    since: datetime,
    until: datetime | None = None,
    *,
    host: str | None = None,
    exclude: Iterable[str] = (),
    path: Path | None = None,
) -> int | None:
    """Число ``tool_call`` в окне ``[since .. until]`` (VENDOR-HYGIENE-1 п.2: ``engine_calls``).

    ``host`` — считать только вызовы этого хоста (журнал общий для всех процессов: чужой хост
    или веб-пульт в том же окне — не работа этого выхода); ``exclude`` — имена инструментов,
    которые не считаются (контур выхода сам). Поверхностные события ``ui:…`` не считаются.
    Журнал не прочитался → ``None`` («неизвестно» — не 0: ноль означает «без вызовов DT»).
    """
    target = Path(path) if path is not None else events_path()
    lines = _read_lines(target)
    if lines is None:
        return None
    skip = set(exclude)
    n = 0
    for e in _events_from_lines([ln for ln in lines if _TOOL_CALL_MARK in ln], since):
        ts = _parse_ts(e.get("ts"))
        if ts is None or (until is not None and ts > until):
            continue
        name = str(e.get("tool") or "")
        if name.startswith(UI_PREFIX) or name in skip:
            continue
        if host is not None and str(e.get("host") or "unknown") != host:
            continue
        n += 1
    return n


RERANK_WINDOW_DAYS = 7


def rerank_latency(now_dt: datetime, events: Iterable[dict[str, Any]]) -> dict[str, Any]:
    """p50/p95 ``rerank_ms`` за 7 дней по событиям ``tool_call`` (пусто — реранкер не работал).

    ``{days, calls, p50_ms, p95_ms, pool_p50, device}`` (``device`` — последнее записанное).
    """
    cutoff = now_dt - timedelta(days=RERANK_WINDOW_DAYS)
    ms: list[int] = []
    pools: list[int] = []
    device = ""
    for e in events:
        ts = _parse_ts(e.get("ts"))
        raw = e.get("rerank_ms")
        if ts is None or ts < cutoff or not isinstance(raw, (int, float)):
            continue
        ms.append(int(raw))
        if isinstance(e.get("rerank_pool"), (int, float)):
            pools.append(int(e["rerank_pool"]))
        device = str(e.get("rerank_device") or device)
    if not ms:
        return {}
    ms.sort()
    pools.sort()
    return {
        "days": RERANK_WINDOW_DAYS, "calls": len(ms), "p50_ms": _percentile(ms, 0.5),
        "p95_ms": _percentile(ms, 0.95),
        "pool_p50": _percentile(pools, 0.5) if pools else None, "device": device,
    }


def _percentile(sorted_values: list[int], q: float) -> int:
    """Ближайший ранг; список непуст."""
    index = min(len(sorted_values) - 1, max(0, round(q * (len(sorted_values) - 1))))
    return sorted_values[index]


def usage_summary(
    days: int = 30,
    *,
    known_tools: Iterable[str] | None = None,
    now: datetime | None = None,
    path: Path | None = None,
) -> dict[str, Any]:
    """WAVE1-MEASURE п.2 — употребление поверхности за окно: что вызывали и что молчит.

    Данные ``tool_call`` (инструменты: ``{tool, ok, ms}``) и ``ui:…`` (открытия вкладок/
    секций пульта). Privacy журнала: только имена, счётчики и длительности.

    ``{days, journal, calls, ui_opens, observed_since, coverage_days, tools:[{tool, calls,
    errors, p50_ms, max_ms, last_ts}], hosts:[{host, surface, calls, errors, last_ts}],
    ui:[{name, opens}], unused_tools?, unused_ui, surfaces, tools_by_surface}``. ``hosts`` —
    VENDOR-HYGIENE-1 п.3: вызовы по хостам (``unknown`` — события до учета хостов).
    PULT-STANDALONE-1 п.6: ``surfaces`` — разрез по поверхности (``mcp`` = артефакт и MCP-хосты,
    ``webpult``, ``cli``, ``unknown`` = до разметки): ``[{surface, calls, pult_calls, ui_opens,
    last_ui_ts, last_ts}]`` (``pult_calls`` — вызовы ``pult_*``/``work_*``); ``tools_by_surface`` —
    ``{surface: [имена вызванных инструментов]}`` (для «без вызовов» по поверхности).
    ``unused_tools`` — только если передан реестр ``known_tools`` (core не знает MCP-слоя).

    ``coverage_days`` — сколько дней телеметрия вообще копится (от самого раннего
    события вызова): без него «0 вызовов за 30 дн» в первую неделю после включения
    выдавало бы за «не используется» то, что просто ещё не измерялось (канон §9 п.22
    на самой телеметрии). Журнал не прочитался → конверт ``store_unavailable``.
    """
    days = max(1, days)
    now_dt = now or datetime.now(UTC)
    target = Path(path) if path is not None else events_path()
    out: dict[str, Any] = {
        "days": days, "journal": str(target), "calls": 0, "ui_opens": 0,
        "observed_since": None, "coverage_days": 0.0, "tools": [], "ui": [],
        "unused_ui": [], "hosts": [], "surfaces": [], "tools_by_surface": {},
    }
    lines = _read_lines(target)
    if lines is None:
        from core.contract import CODE_STORE_UNAVAILABLE, add_warning

        return add_warning(
            out, CODE_STORE_UNAVAILABLE,
            f"журнал метрик не прочитался: {target} — употребление НЕ посчитано",
            journal=str(target),
        )
    # Покрытие считаем по ВСЕМУ журналу (не по окну): окно режет и самое раннее событие.
    all_calls = [
        e for e in _events_from_lines(
            [ln for ln in lines if _TOOL_CALL_MARK in ln], None
        )
    ]
    first = min((t for t in (_parse_ts(e.get("ts")) for e in all_calls) if t), default=None)
    if first is not None:
        out["observed_since"] = first.strftime("%Y-%m-%dT%H:%M:%SZ")
        out["coverage_days"] = round((now_dt - first).total_seconds() / 86400.0, 1)

    cutoff = now_dt - timedelta(days=days)
    per_tool: dict[str, dict[str, Any]] = {}
    per_host: dict[tuple[str, str], dict[str, Any]] = {}
    per_surface: dict[str, dict[str, Any]] = {}
    surface_tools: dict[str, set[str]] = {}
    ui_counts: dict[str, int] = {}

    def _surface_row(e: dict[str, Any]) -> dict[str, Any]:
        key = str(e.get("surface") or "unknown")
        return per_surface.setdefault(
            key, {"surface": key, "calls": 0, "pult_calls": 0, "ui_opens": 0,
                  "last_ui_ts": "", "last_ts": ""})

    for e in all_calls:
        ts = _parse_ts(e.get("ts"))
        if ts is None or ts < cutoff:
            continue
        name = str(e.get("tool") or "?")
        srow = _surface_row(e)
        srow["last_ts"] = max(srow["last_ts"], str(e.get("ts") or ""))
        if name.startswith(UI_PREFIX):
            key = name[len(UI_PREFIX):]
            ui_counts[key] = ui_counts.get(key, 0) + 1
            srow["ui_opens"] += 1
            srow["last_ui_ts"] = max(srow["last_ui_ts"], str(e.get("ts") or ""))
            continue
        srow["calls"] += 1
        if name.startswith(("pult_", "work_")):
            srow["pult_calls"] += 1
        surface_tools.setdefault(str(srow["surface"]), set()).add(name)
        row = per_tool.setdefault(
            name, {"tool": name, "calls": 0, "errors": 0, "ms": [], "last_ts": ""}
        )
        row["calls"] += 1
        if e.get("ok") is False:
            row["errors"] += 1
        # VENDOR-HYGIENE-1 п.3: разрез по хостам. События до учета хостов (нет ``host``) —
        # ``unknown``: честнее, чем приписывать их какому-то хосту.
        hkey = (str(e.get("host") or "unknown"), str(e.get("surface") or "unknown"))
        hrow = per_host.setdefault(
            hkey, {"host": hkey[0], "surface": hkey[1], "calls": 0, "errors": 0, "last_ts": ""}
        )
        hrow["calls"] += 1
        if e.get("ok") is False:
            hrow["errors"] += 1
        hrow["last_ts"] = max(hrow["last_ts"], str(e.get("ts") or ""))
        raw_ms = e.get("ms")
        if isinstance(raw_ms, (int, float)):
            row["ms"].append(int(raw_ms))
        rr_ms = e.get("rerank_ms")
        if isinstance(rr_ms, (int, float)):
            row.setdefault("rerank", []).append(int(rr_ms))
        row["last_ts"] = max(row["last_ts"], str(e.get("ts") or ""))

    tools = []
    for row in sorted(per_tool.values(), key=lambda r: (-r["calls"], r["tool"])):
        ms = sorted(row.pop("ms"))
        row["p50_ms"] = _percentile(ms, 0.5) if ms else None
        row["max_ms"] = ms[-1] if ms else None
        rr_ms = sorted(row.pop("rerank", []))
        if rr_ms:  # RETR-RERANK-1: p50/p95 реранкера (только у инструментов, что его писали)
            row["rerank_p50_ms"] = _percentile(rr_ms, 0.5)
            row["rerank_p95_ms"] = _percentile(rr_ms, 0.95)
        tools.append(row)
    out["tools"] = tools
    rerank = rerank_latency(now_dt, all_calls)
    if rerank:
        out["rerank"] = rerank
    out["calls"] = sum(r["calls"] for r in tools)
    out["hosts"] = sorted(per_host.values(), key=lambda r: (-r["calls"], r["host"], r["surface"]))
    out["ui"] = [
        {"name": n, "opens": c}
        for n, c in sorted(ui_counts.items(), key=lambda kv: (-kv[1], kv[0]))
    ]
    out["ui_opens"] = sum(ui_counts.values())
    out["surfaces"] = sorted(per_surface.values(), key=lambda r: (-r["calls"], r["surface"]))
    out["tools_by_surface"] = {k: sorted(v) for k, v in sorted(surface_tools.items())}
    if known_tools is not None:
        called = set(per_tool)
        out["unused_tools"] = sorted(t for t in known_tools if t not in called)
        out["tools_total"] = len(set(known_tools))
    surfaces = [f"tab:{t}" for t in UI_TABS] + [f"sec:{s}" for s in UI_SECTIONS]
    out["unused_ui"] = [n for n in surfaces if n not in ui_counts]
    out["ui_total"] = len(surfaces)
    return out
