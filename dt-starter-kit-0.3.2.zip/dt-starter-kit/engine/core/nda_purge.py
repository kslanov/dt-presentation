"""NDA trace scan + sweep over every derived surface (NDA-1, расширено NDA-2).

Единственное место, которое ИЩЕТ и (по команде) снимает следы NDA-документов в
производном слое. Реюзает один предикат :func:`core.privacy.is_nda` — второго
определения NDA в движке нет.

**Почему поверхностей много (NDA-2, инцидент 16.08).** Барьер пропустил каталог
``x_nda/`` — и след одного документа оказался сразу в нескольких сторах: запись в
манифесте инжеста, заметка в vault, чанки в LanceDB, строка реестра источников,
запись L2-кэша, факты, события журнала стадий. Починить предикат мало: пока след
лежит хоть в одном сторе, документ находится поиском и поднимается lift'ом. Поэтому
sweep обходит ВСЕ поверхности разом и по одному правилу.

Что где ищем (и по КАКИМ путям — у заметки их два, см. :func:`core.privacy.any_nda`):

* **манифесты инжеста** (легаси + текущие знания) — ключ (``source_path`` файла) и
  ``note_path`` записи;
* **индекс** — манифест индекса (``path`` + ``source_path``) плюс чтение заметки,
  когда в записи ``source_path`` ещё нет (старые записи): слуг легаси-заметки маркер
  теряет, и без чтения такой документ не отличить от чистого. Снимаются чанки
  LanceDB по ``note_id`` и запись манифеста;
* **реестр источников + L2-кэш лифта** (``sources`` в ``dt.db`` + файлы записей);
* **факты** (``facts.source_path``);
* **журнал стадий** — события ПОМЕЧАЮТСЯ (``detail.nda = true``), а не переписываются:
  история о том, что документ проходил через движок, — это факт, и стирать его
  значит терять след инцидента.

Заметки vault sweep НЕ трогает: карантин — решение человека (принцип «не удаляем
контент за пользователя»). Их находит doctor-гард «Заметки под NDA-путями».

:func:`scan_nda_traces` — read-only (годится для витрины/доктора и dry-run),
:func:`purge_nda_traces` — снимает найденное, идемпотентно, с необязательным
``limit`` (канарейка §9 п.11г: сначала одна-две записи, потом остальное).

Path B: без сети и LLM. ``core/`` не зависит ни от MCP, ни от CLI.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

__all__ = ["scan_nda_traces", "purge_nda_traces", "SURFACES"]

# Поверхности следа — порядок стабильный (отчёт читают глазами).
SURFACES = (
    "sources",       # реестр источников + записи L2-кэша
    "facts",         # строки фактов по NDA-источнику
    "manifests",     # манифесты инжеста (легаси + текущие знания)
    "index",         # манифест индекса + чанки LanceDB
    "events",        # журнал стадий — ПОМЕТИТЬ, не удалять
)


# --------------------------------------------------------------------------- #
# Реестр источников + L2-кэш (NDA-1)                                           #
# --------------------------------------------------------------------------- #


def _scan_sources() -> list[tuple[str, list[str]]]:
    """(content_hash, nda_paths) for each registry entry with any NDA path."""
    from core.privacy import is_nda
    from core.sources import cache as sources_cache

    hits: list[tuple[str, list[str]]] = []
    for content_hash, entry in sources_cache.load_index().items():
        if not isinstance(entry, dict):
            continue
        paths = [p for p in entry.get("paths", []) if isinstance(p, str)]
        nda_paths = [p for p in paths if is_nda(p)]
        if nda_paths:
            hits.append((content_hash, nda_paths))
    return hits


# --------------------------------------------------------------------------- #
# Факты                                                                        #
# --------------------------------------------------------------------------- #


def _scan_facts() -> list[str]:
    """Distinct NDA-marked ``source_path`` values present in the facts store."""
    from core.config import facts_db_path
    from core.privacy import is_nda

    db = facts_db_path()
    if not db.is_file():
        return []
    conn = sqlite3.connect(str(db))
    try:
        rows = conn.execute("SELECT DISTINCT source_path FROM facts").fetchall()
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()
    return [r[0] for r in rows if r[0] and is_nda(r[0])]


def _purge_facts(source_paths: list[str]) -> int:
    from core.config import facts_db_path

    db = facts_db_path()
    if not db.is_file() or not source_paths:
        return 0
    conn = sqlite3.connect(str(db))
    try:
        cur = conn.executemany(
            "DELETE FROM facts WHERE source_path = ?", [(p,) for p in source_paths]
        )
        conn.commit()
        return cur.rowcount if cur.rowcount and cur.rowcount > 0 else len(source_paths)
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# Манифесты инжеста (NDA-2)                                                    #
# --------------------------------------------------------------------------- #


def _manifest_paths() -> list[tuple[str, Path]]:
    from core.config import current_ingest_manifest_path, legacy_ingest_manifest_path

    return [
        ("legacy", legacy_ingest_manifest_path()),
        ("current", current_ingest_manifest_path()),
    ]


def _load_json(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def _scan_manifests() -> list[dict[str, str]]:
    """Записи манифестов инжеста, чей источник или заметка под барьером."""
    from core.privacy import any_nda

    hits: list[dict[str, str]] = []
    for layer, path in _manifest_paths():
        for source_path, entry in _load_json(path).items():
            note_path = str((entry or {}).get("note_path") or "")
            if any_nda(source_path, note_path):
                hits.append({
                    "layer": layer, "manifest": str(path),
                    "source_path": source_path, "note_path": note_path,
                })
    return hits


def _purge_manifests(hits: list[dict[str, str]]) -> int:
    """Убрать записи из манифестов (заметку на диске НЕ трогаем)."""
    removed = 0
    by_manifest: dict[str, list[str]] = {}
    for hit in hits:
        by_manifest.setdefault(hit["manifest"], []).append(hit["source_path"])
    for manifest, keys in by_manifest.items():
        path = Path(manifest)
        data = _load_json(path)
        gone = [k for k in keys if k in data]
        if not gone:
            continue
        for key in gone:
            del data[key]
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(
            json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        tmp.replace(path)
        removed += len(gone)
    return removed


# --------------------------------------------------------------------------- #
# Индекс: манифест + чанки LanceDB (NDA-2)                                     #
# --------------------------------------------------------------------------- #


def _note_source_of(vault: Path, rel_path: str) -> str:
    """``source_path`` заметки из её frontmatter (пусто, если нечего читать).

    Читаем ТОЛЬКО когда в записи манифеста поля нет: у старых записей его не было,
    а именно в нём и живёт NDA-ность легаси-заметки (слуг маркер теряет).
    """
    if not rel_path:
        return ""
    path = vault / rel_path
    if not path.is_file():
        return ""
    try:
        from core.vault import read_note

        value = read_note(path).frontmatter.get("source_path")
    except (OSError, ValueError):
        return ""
    if isinstance(value, list):
        value = value[0] if value else ""
    return str(value or "").strip()


def _scan_index() -> list[dict[str, Any]]:
    """Записи индекс-манифеста + осиротевшие чанки таблицы, попавшие под барьер.

    Два прохода, потому что у следа в индексе две независимые половины:

    * **манифест** — полный проход (не сэмпл: требование ТЗ), с чтением заметки там,
      где в записи нет ``source_path`` (у старых записей его не было, а NDA-ность
      легаси-заметки живёт именно в нём);
    * **сама таблица** — ``note_id``/``source_path`` каждой строки. Запись манифеста
      можно потерять (снесли/переписали), а чанки останутся: тогда документ
      по-прежнему находится поиском, а «по манифесту» его не видно. Проверка по
      манифесту такую сироту пропустила бы — здесь она находится.
    """
    from core.config import default_vault_path, index_manifest_path
    from core.privacy import any_nda, is_nda

    vault = default_vault_path()
    hits: list[dict[str, Any]] = []
    for note_id, entry in _load_json(index_manifest_path()).items():
        if not isinstance(entry, dict):
            continue
        rel = str(entry.get("path") or "")
        source = str(entry.get("source_path") or "")
        if not source:
            source = _note_source_of(vault, rel)
        if any_nda(rel, source):
            hits.append({
                "note_id": note_id, "path": rel, "source_path": source,
                "chunks": len(entry.get("chunk_ids") or []),
            })

    known = {hit["note_id"] for hit in hits}
    for note_id, source, chunks in _orphan_chunks():
        if note_id in known or not is_nda(source):
            continue
        known.add(note_id)
        hits.append({"note_id": note_id, "path": "", "source_path": source,
                     "chunks": chunks, "orphan": True})
    return hits


def _orphan_chunks() -> list[tuple[str, str, int]]:
    """``(note_id, source_path, chunks)`` по строкам таблицы; сбой чтения → пусто."""
    try:
        from core.retrieval.index import open_chunks_table

        table = open_chunks_table()
        if table is None:
            return []
        rows = (
            table.search()
            .select(["note_id", "source_path"])
            .limit(max(1, table.count_rows()))
            .to_list()
        )
    except Exception:  # noqa: BLE001 — индекса может не быть; остальные поверхности важнее
        return []
    by_note: dict[str, list[str]] = {}
    for row in rows:
        by_note.setdefault(str(row.get("note_id") or ""), []).append(
            str(row.get("source_path") or "")
        )
    return [
        (note_id, sources[0], len(sources))
        for note_id, sources in by_note.items()
        if note_id
    ]


def _purge_index(hits: list[dict[str, Any]]) -> dict[str, int]:
    """Снять чанки LanceDB по ``note_id`` и записи из манифеста индекса."""
    from core.config import index_manifest_path

    if not hits:
        return {"chunks": 0, "manifest_entries": 0}

    chunks = 0
    try:
        from core.retrieval.index import _sql_quote, open_chunks_table

        table = open_chunks_table()
        if table is not None:
            for hit in hits:
                table.delete(f"note_id = {_sql_quote(hit['note_id'])}")
                chunks += int(hit.get("chunks") or 0)
    except Exception:  # noqa: BLE001 — индекса может не быть; манифест всё равно чистим
        chunks = 0

    manifest_path = index_manifest_path()
    data = _load_json(manifest_path)
    gone = [h["note_id"] for h in hits if h["note_id"] in data]
    for note_id in gone:
        del data[note_id]
    if gone:
        tmp = manifest_path.with_suffix(manifest_path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True),
                       encoding="utf-8")
        tmp.replace(manifest_path)
    return {"chunks": chunks, "manifest_entries": len(gone)}


# --------------------------------------------------------------------------- #
# Журнал стадий: пометить, не переписывать (NDA-2)                             #
# --------------------------------------------------------------------------- #


def _events_conn() -> sqlite3.Connection | None:
    from core.config import dt_db_path

    path = dt_db_path()
    if not path.is_file():
        return None
    return sqlite3.connect(str(path))


def _scan_events() -> list[dict[str, Any]]:
    """События журнала стадий с NDA-путём, ещё НЕ помеченные."""
    from core.privacy import is_nda

    conn = _events_conn()
    if conn is None:
        return []
    try:
        rows = conn.execute(
            "SELECT event_id, note_id, path, stage, status, detail FROM events"
        ).fetchall()
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()

    hits: list[dict[str, Any]] = []
    for event_id, note_id, path, stage, status, detail in rows:
        if not is_nda(path):
            continue
        try:
            payload = json.loads(detail) if detail else {}
        except json.JSONDecodeError:
            payload = {}
        if isinstance(payload, dict) and payload.get("nda") is True:
            continue  # уже помечено — идемпотентность
        hits.append({
            "event_id": event_id, "note_id": note_id, "path": path,
            "stage": stage, "status": status,
        })
    return hits


def _mark_events(hits: list[dict[str, Any]]) -> int:
    """Пометить события ``detail.nda = true`` (историю НЕ переписываем)."""
    if not hits:
        return 0
    conn = _events_conn()
    if conn is None:
        return 0
    marked = 0
    try:
        for hit in hits:
            row = conn.execute(
                "SELECT detail FROM events WHERE event_id = ?", (hit["event_id"],)
            ).fetchone()
            if row is None:
                continue
            try:
                payload = json.loads(row[0]) if row[0] else {}
            except json.JSONDecodeError:
                payload = {}
            if not isinstance(payload, dict):
                payload = {"detail": str(payload)}
            payload["nda"] = True
            conn.execute(
                "UPDATE events SET detail = ? WHERE event_id = ?",
                (json.dumps(payload, ensure_ascii=False), hit["event_id"]),
            )
            marked += 1
        conn.commit()
    finally:
        conn.close()
    return marked


# --------------------------------------------------------------------------- #
# Публичный контур                                                             #
# --------------------------------------------------------------------------- #


def scan_nda_traces() -> dict[str, Any]:
    """Read-only скан следов NDA во ВСЕХ производных сторах.

    ``{sources, facts, manifests, index, events, source_count, facts_count,
    manifest_count, index_count, event_count, total}``. Ничего не пишет — годится
    для витрины, доктора и dry-run перед правкой. Ключи ``sources``/``facts`` и их
    счётчики сохранены с NDA-1 (их читают виджет здоровья хранилища и storage_action).
    """
    src_hits = _scan_sources()
    fact_paths = _scan_facts()
    manifest_hits = _scan_manifests()
    index_hits = _scan_index()
    event_hits = _scan_events()
    return {
        "sources": src_hits,
        "facts": fact_paths,
        "manifests": manifest_hits,
        "index": index_hits,
        "events": event_hits,
        "source_count": len(src_hits),
        "facts_count": len(fact_paths),
        "manifest_count": len(manifest_hits),
        "index_count": len(index_hits),
        "event_count": len(event_hits),
        "total": (
            len(src_hits) + len(fact_paths) + len(manifest_hits)
            + len(index_hits) + len(event_hits)
        ),
    }


def purge_nda_traces(*, limit: int | None = None) -> dict[str, int]:
    """Снять следы NDA во всех сторах. Идемпотентно; ``limit`` — канарейка.

    ``limit`` ограничивает число записей НА КАЖДОЙ поверхности (§9 п.11г: сначала
    одна-две, посмотреть результат, потом остальное). Удаляются только производные
    артефакты — заметки vault не трогаются НИКОГДА; события журнала помечаются.
    """
    from core.sources import cache as sources_cache

    scan = scan_nda_traces()

    def _cap(items: list[Any]) -> list[Any]:
        return items if limit is None else items[: max(0, int(limit))]

    removed_records = 0
    src_hits = _cap(scan["sources"])
    for content_hash, _paths in src_hits:
        rec = sources_cache.cache_record_path(content_hash)
        if rec.is_file():
            rec.unlink()
            removed_records += 1
        sources_cache.forget_source(content_hash)

    removed_facts = _purge_facts(_cap(scan["facts"]))
    removed_manifest = _purge_manifests(_cap(scan["manifests"]))
    index_removed = _purge_index(_cap(scan["index"]))
    marked_events = _mark_events(_cap(scan["events"]))

    return {
        "cache_records": removed_records,
        "registry_entries": len(src_hits),
        "facts_rows": removed_facts,
        "manifest_entries": removed_manifest,
        "index_chunks": index_removed["chunks"],
        "index_entries": index_removed["manifest_entries"],
        "events_marked": marked_events,
    }
