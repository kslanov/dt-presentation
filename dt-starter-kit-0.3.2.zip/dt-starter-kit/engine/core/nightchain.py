"""NIGHT-CHAIN-1 — время ночной цепочки по шагам: ОДНА функция чтения для доктора и пульта.

``cli/dt_sync.py`` пишет в маяк ``.derived/status/dt-sync-index.json`` (``fast`` — ``dt-sync.json``)
раздел ``steps: {имя: {started, finished, elapsed_s, exit[, device, fallback]}}``. Здесь он читается
в :class:`NightChain`, считаются общее время и самые долгие шаги, и выносится вердикт
(:func:`verdict`): доктор «Ночная цепочка» и строка сервиса ``sync.index`` в мониторинге берут
цифры из одного места, а не парсят лог каждый по-своему.

Только чтение и арифметика: ни сети, ни моделей, ничего не пишется (инвариант ``core`` ⊥ mcp/cli).
В маяке нет ни имён клиентов, ни путей, ни текстов - только имена шагов и секунды.
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import status_dir

__all__ = [
    "DEFAULT_MAX_H",
    "OCR_BUDGET_FACTOR",
    "NightChain",
    "Step",
    "beacon_name",
    "brief",
    "format_duration",
    "max_hours",
    "read_chain",
    "summary",
    "verdict",
]

DEFAULT_MAX_H = 3.0  # дольше - warn «Ночная цепочка»
OCR_BUDGET_FACTOR = 1.5  # шаг ocr дольше бюджета × 1.5 - warn (бюджет обрывает по страницам)

_BEACON = {"index": "dt-sync-index", "fast": "dt-sync", "full": "dt-sync"}


def beacon_name(mode: str) -> str:
    """Имя маяка режима (``dt-sync-index`` для index; fast/full пишут в ``dt-sync``)."""
    return _BEACON.get(mode, "dt-sync")


def max_hours() -> float:
    """``DT_NIGHT_CHAIN_MAX_H`` - порог общего времени цепочки, ч (дефолт 3; мусор - дефолт)."""
    raw = (os.environ.get("DT_NIGHT_CHAIN_MAX_H") or "").strip()
    try:
        value = float(raw) if raw else DEFAULT_MAX_H
    except ValueError:
        return DEFAULT_MAX_H
    return value if value > 0 else DEFAULT_MAX_H


@dataclass
class Step:
    name: str
    elapsed_s: float = 0.0
    exit: int | None = None  # None - шаг идет прямо сейчас
    started: str = ""
    finished: str = ""
    extra: dict[str, Any] = field(default_factory=dict)  # device/fallback у reindex_inc

    @property
    def running(self) -> bool:
        return self.exit is None

    @property
    def ok(self) -> bool:
        return self.exit == 0


@dataclass
class NightChain:
    mode: str
    started: str
    updated: str
    finished: bool
    total_s: float
    steps: list[Step]
    summary: str = ""
    partial: bool = False  # ``dt_sync --steps ...``: часть шагов, общее время несравнимо с порогом

    def step(self, name: str) -> Step | None:
        return next((s for s in self.steps if s.name == name), None)

    def top(self, n: int = 3) -> list[Step]:
        """``n`` самых долгих шагов (по убыванию длительности)."""
        return sorted(self.steps, key=lambda s: -s.elapsed_s)[:n]

    @property
    def failed(self) -> list[str]:
        return [s.name for s in self.steps if s.exit not in (None, 0)]


def _parse(ts: Any) -> float | None:
    try:
        return datetime.strptime(str(ts), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC).timestamp()
    except ValueError:
        return None


def format_duration(seconds: float) -> str:
    """``3 ч 54 мин`` / ``40 мин`` / ``20 с`` - для строк доктора и мониторинга."""
    s = max(0, round(seconds))
    if s < 90:
        return f"{s} с"
    minutes = round(s / 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours} ч {minutes} мин" if hours else f"{minutes} мин"


def read_chain(
    mode: str = "index", *, path: Path | None = None, now: float | None = None
) -> NightChain | None:
    """Последний прогон режима из маяка; ``None`` - маяка нет, нечитаем либо без раздела ``steps``
    (прогон старой версией: у него нечего показать, доктор честно говорит «нет данных»)."""
    target = path or (status_dir() / f"{beacon_name(mode)}.json")
    try:
        body = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    raw = body.get("steps") if isinstance(body, dict) else None
    if not isinstance(raw, dict) or not raw:
        return None
    steps: list[Step] = []
    for name, rec in raw.items():
        if not isinstance(rec, dict):
            continue
        extra = {k: v for k, v in rec.items()
                 if k not in {"started", "finished", "elapsed_s", "exit"}}
        code = rec.get("exit")
        steps.append(Step(
            name=str(name), elapsed_s=float(rec.get("elapsed_s") or 0.0),
            exit=int(code) if isinstance(code, int) and not isinstance(code, bool) else None,
            started=str(rec.get("started") or ""), finished=str(rec.get("finished") or ""),
            extra=extra,
        ))
    if not steps:
        return None
    finished = bool(body.get("finished"))
    t0 = _parse(body.get("started"))
    if finished:
        ends = [_parse(s.finished) for s in steps if s.finished]
        t1 = max((e for e in ends if e is not None), default=_parse(body.get("updated")))
    else:
        t1 = now if now is not None else time.time()
    total = (t1 - t0) if (t0 is not None and t1 is not None) else sum(s.elapsed_s for s in steps)
    return NightChain(
        mode=mode, started=str(body.get("started") or ""), updated=str(body.get("updated") or ""),
        finished=finished, total_s=max(0.0, total), steps=steps,
        summary=str(body.get("summary") or ""),
        partial=bool((body.get("extra") or {}).get("partial")),
    )


def verdict(
    chain: NightChain, *, max_h: float | None = None, ocr_budget_s: float | None = None,
    forced_cpu: bool = False,
) -> tuple[str, list[str]]:
    """``("ok"|"warn", причины)``: общее время > порога; ``ocr`` > бюджета × 1.5; ``reindex_inc`` на
    CPU (если CPU не выбран явно ``DT_EMBED_DEVICE=cpu``). Идущий прогон оценивается по тому, что
    уже накопилось."""
    limit_h = max_hours() if max_h is None else max_h
    reasons: list[str] = []
    if not chain.partial and chain.total_s > limit_h * 3600:
        reasons.append(
            f"общее время {format_duration(chain.total_s)} > порога {limit_h:g} ч "
            "(DT_NIGHT_CHAIN_MAX_H)"
        )
    ocr = chain.step("ocr")
    if ocr is not None and ocr_budget_s and ocr.elapsed_s > ocr_budget_s * OCR_BUDGET_FACTOR:
        reasons.append(
            f"ocr {format_duration(ocr.elapsed_s)} > бюджета {format_duration(ocr_budget_s)} × "
            f"{OCR_BUDGET_FACTOR:g}"
        )
    reindex = chain.step("reindex_inc")
    if reindex is not None and str(reindex.extra.get("device") or "") == "cpu" and not forced_cpu:
        why = str(reindex.extra.get("fallback") or "")
        reasons.append("reindex_inc шел на CPU" + (f" ({why[:120]})" if why else ""))
    return ("warn" if reasons else "ok"), reasons


def brief(chain: NightChain | None = None, *, mode: str = "index") -> dict[str, Any] | None:
    """Сводка для мониторинга/``pult_services``: ``{mode, finished, total_s, total, top:[{step,
    elapsed_s, text}], failed, started}``; ``None`` - данных нет. Те же цифры, что в докторе."""
    chain = chain or read_chain(mode)
    if chain is None:
        return None
    return {
        "mode": chain.mode,
        "started": chain.started,
        "finished": chain.finished,
        "total_s": round(chain.total_s),
        "total": format_duration(chain.total_s),
        "top": [{"step": s.name, "elapsed_s": round(s.elapsed_s, 1),
                 "text": format_duration(s.elapsed_s)} for s in chain.top(3)],
        "failed": chain.failed,
    }


def summary(chain: NightChain | None = None, *, mode: str = "index") -> dict[str, Any] | None:
    """:func:`brief` + вердикт доктора: ``{..., status: ok|warn, warnings: [причины], partial}``.

    Один набор порогов с доктором «Ночная цепочка» (общее время, бюджет OCR, CPU вместо MPS) -
    карточка мониторинга и доктор показывают одно и то же. ``None`` - данных нет."""
    chain = chain or read_chain(mode)
    if chain is None:
        return None
    from core.ocr.settings import budget_s

    forced_cpu = (os.environ.get("DT_EMBED_DEVICE") or "").strip().lower() == "cpu"
    status, reasons = verdict(chain, ocr_budget_s=budget_s(), forced_cpu=forced_cpu)
    out = brief(chain) or {}
    out.update(status=status, warnings=reasons, partial=chain.partial)
    return out
