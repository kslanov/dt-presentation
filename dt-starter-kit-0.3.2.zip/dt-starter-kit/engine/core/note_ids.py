"""WAVE0-HYGIENE п.2 — инвариант уникальности ``note_id`` (аудит B2/C3).

Три вещи вокруг одного инварианта «у каждой заметки свой id»:

* :func:`scan_collisions` — поиск повторных id по vault (doctor «коллизии note_id»);
* :func:`output_note_fields` / :func:`frontmatter_block` — frontmatter для файлов контура
  выхода (``output.md``/``sources.md``/``prompt.md``: ``id: <stem>-<папка>``), который
  пишут ``save_output``/``output_begin``;
* :func:`plan_backfill` / :func:`apply_backfill` — разовый бэкфилл id для уже лежащих
  заметок без frontmatter id (07-outputs и проектные PROGRESS/plan/hub): dry-run по
  умолчанию, ``limit`` для канарейки (3 → все), атомарная запись, отчёт.

Заметка без frontmatter id получает идентичность «vault-путь без ``.md``»
(:func:`core.vault.note_id_from_path`), поэтому дубли не затирают друг друга и сейчас;
бэкфилл нужен, чтобы выходам вернуть короткий стабильный id (ссылки/линковка/провенанс).
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import re
import unicodedata
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

logger = logging.getLogger(__name__)

__all__ = [
    "BackfillItem",
    "apply_backfill",
    "frontmatter_block",
    "insert_frontmatter_fields",
    "output_note_fields",
    "plan_backfill",
    "related_from_body",
    "scan_collisions",
    "split_frontmatter",
]

# Файлы контура выхода → (type заметки, префикс id, префикс title).
OUTPUT_FILE_KINDS: dict[str, tuple[str, str]] = {
    "output.md": ("output", ""),
    "sources.md": ("output-sources", "Sources"),
    "prompt.md": ("output-prompt", "Prompt"),
}
_PROJECT_DOC_STEMS = ("PROGRESS", "plan", "hub")
_RELATED_HEADING = "## Связано"
_WIKILINK_RE = re.compile(r"\[\[([^\[\]|]+?)(?:\|[^\]]*)?\]\]")
_H1_RE = re.compile(r"^#\s+(.+?)\s*$", re.MULTILINE)
_HUB_FIELD_PREFIXES = (("client-", "client"), ("project-", "project"), ("deal-", "deal"))


# --------------------------------------------------------------------------- #
# Коллизии                                                                      #
# --------------------------------------------------------------------------- #
def scan_collisions(
    vault_path: Path, *, include_legacy: bool = False
) -> dict[str, list[str]]:
    """id → vault-пути, если у ≥2 заметок один id (пусто — инвариант цел).

    ``_legacy`` по умолчанию вне скана (17 тыс. файлов; их id — ``legacy-<hash>``, а повторы
    по ходу индексации ловит сам индексатор и кладёт в отчёт). Остальной vault — сотни
    файлов, frontmatter-only чтение.
    """
    from core.vault import iter_vault_paths, read_note

    vault_path = Path(vault_path)
    owners: dict[str, list[str]] = {}
    for path in iter_vault_paths(vault_path):
        rel = path.relative_to(vault_path).as_posix()
        if not include_legacy and rel.startswith("_legacy/"):
            continue
        try:
            note_id = read_note(path, vault_path).id
        except Exception:  # noqa: BLE001, S112 — нечитаемую заметку ловят другие гарды
            continue
        owners.setdefault(note_id, []).append(rel)
    return {nid: paths for nid, paths in owners.items() if len(paths) > 1}


# --------------------------------------------------------------------------- #
# Frontmatter выхода                                                            #
# --------------------------------------------------------------------------- #
def frontmatter_block(fields: dict[str, Any]) -> str:
    """YAML-блок ``---…---`` + пустая строка (пустые значения опускаются)."""
    clean = {k: v for k, v in fields.items() if v not in (None, "", [])}
    body = yaml.safe_dump(clean, allow_unicode=True, sort_keys=False, width=10_000)
    return f"---\n{body.rstrip()}\n---\n\n"


def _read_yaml(path: Path) -> dict[str, Any]:
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return {}
    return data if isinstance(data, dict) else {}


def _hub_fields(hub_ids: list[str] | None) -> dict[str, str]:
    """``[client-x, project-y]`` → ``{client: client-x, project: project-y}`` (первый по роли)."""
    out: dict[str, str] = {}
    for hub in hub_ids or []:
        hub = str(hub).strip()
        for prefix, field_name in _HUB_FIELD_PREFIXES:
            if hub.startswith(prefix) and field_name not in out:
                out[field_name] = hub
    return out


def related_from_body(text: str) -> list[str]:
    """Хабы из секции «## Связано» готового ``output.md`` (для бэкфилла)."""
    lines = text.splitlines()
    hubs: list[str] = []
    in_section = False
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("## "):
            in_section = stripped == _RELATED_HEADING
            continue
        if in_section:
            hubs.extend(m.group(1).strip() for m in _WIKILINK_RE.finditer(stripped))
    return hubs


def output_note_fields(
    out_dir: Path,
    filename: str,
    *,
    body: str = "",
    related: list[str] | None = None,
    title: str | None = None,
) -> dict[str, Any]:
    """Поля frontmatter файла контура выхода (``output.md``/``sources.md``/``prompt.md``).

    ``id`` = ``<stem>-<имя папки>`` (имя папки уникально: дата + слаг + суффикс коллизии);
    ``type`` — ``output``/``output-sources``/``output-prompt``; ``title``/``created`` — из
    ``meta.yaml`` папки (иначе первый H1 тела / mtime папки); ``client``/``project``/``deal``
    — из хабов «Связано». Детерминированно по содержимому папки: повторная запись того же
    выхода даёт тот же блок (``created`` не «уезжает»).
    """
    out_dir = Path(out_dir)
    kind, title_prefix = OUTPUT_FILE_KINDS[filename]
    stem = filename[: -len(".md")]
    meta = _read_yaml(out_dir / "meta.yaml")
    title = str(title or meta.get("title") or "").strip()
    if not title:
        match = _H1_RE.search(body)
        title = match.group(1).strip() if match else out_dir.name
    created = meta.get("created")
    if not created:
        with contextlib.suppress(OSError):
            created = datetime.fromtimestamp(out_dir.stat().st_mtime).isoformat(
                timespec="seconds"
            )
    fields: dict[str, Any] = {
        "id": f"{stem}-{out_dir.name}",
        "type": kind,
        "title": f"{title_prefix} — {title}" if title_prefix else title,
        "created": str(created) if created else "",
    }
    if kind == "output":
        # RETR-CHUNK-1 п.10: готовый выход — ``final``; без ``status`` он выпадал из поиска
        fields["status"] = "final"
    # EVAL-HYGIENE-1: прогон eval/selftest несет назначение в frontmatter каждого файла выхода
    # (индекс хранит его в метаданных заметки, фильтр - одно поле); у рабочего выхода ключей нет.
    purpose = str(meta.get("purpose") or "").strip()
    if purpose and purpose != "work":
        fields["purpose"] = purpose
        if meta.get("eval_task"):
            fields["eval_task"] = str(meta["eval_task"])
    fields.update(_hub_fields(related))
    return fields


_FM_RE = re.compile(r"\A---\r?\n(.*?)\r?\n---[ \t]*(?:\r?\n|\Z)", re.DOTALL)


def split_frontmatter(text: str) -> tuple[dict[str, Any], str]:
    """Текст → (frontmatter-словарь, тело без блока и без ведущей пустой строки).

    Нет блока / битый YAML → ``({}, text)`` без изменений.
    """
    match = _FM_RE.match(text)
    if match is None:
        return {}, text
    try:
        data = yaml.safe_load(match.group(1)) or {}
    except yaml.YAMLError:
        return {}, text
    if not isinstance(data, dict):
        return {}, text
    return data, text[match.end():].lstrip("\r\n")


def insert_frontmatter_fields(text: str, fields: dict[str, Any]) -> str:
    """Дописать в начало текста недостающие ``fields`` (существующие ключи НЕ трогаем).

    Нет frontmatter → новый блок. Есть блок без ``id`` → недостающие ключи вставляются
    строками сразу после открывающего ``---`` (остальной текст байт-в-байт).
    """
    match = re.match(r"\A---\r?\n(.*?)\r?\n---[ \t]*(?:\r?\n|\Z)", text, re.DOTALL)
    if match is None:
        return frontmatter_block(fields) + text
    try:
        existing = yaml.safe_load(match.group(1)) or {}
    except yaml.YAMLError:
        existing = {}
    if not isinstance(existing, dict):
        existing = {}
    missing = {k: v for k, v in fields.items() if k not in existing}
    if not missing:
        return text
    add = yaml.safe_dump(
        {k: v for k, v in missing.items() if v not in (None, "", [])},
        allow_unicode=True, sort_keys=False, width=10_000,
    )
    head_end = text.index("\n") + 1
    return text[:head_end] + add + text[head_end:]


# --------------------------------------------------------------------------- #
# Бэкфилл                                                                       #
# --------------------------------------------------------------------------- #
@dataclass
class BackfillItem:
    """Одна запланированная вставка id (``path`` — vault-относительный)."""

    path: str
    new_id: str
    type: str
    fields: dict[str, Any] = field(default_factory=dict)
    status: str = "planned"  # planned | written | skipped | error
    error: str = ""


def _has_frontmatter_id(text: str) -> bool:
    match = re.match(r"\A---\r?\n(.*?)\r?\n---", text, re.DOTALL)
    if match is None:
        return False
    try:
        data = yaml.safe_load(match.group(1)) or {}
    except yaml.YAMLError:
        return False
    return isinstance(data, dict) and bool(data.get("id"))


def plan_backfill(vault_path: Path) -> list[BackfillItem]:
    """Заметки без frontmatter id в контуре выхода и проектных доках → план вставки.

    * ``07-outputs/**/{output,sources,prompt}.md`` → ``<stem>-<папка>`` + поля выхода;
    * ``03-projects/<проект>/{PROGRESS,plan,hub}.md`` → ``<stem в нижнем регистре>-<проект>``.

    Уже имеющие id пропускаются — повторный запуск пуст (идемпотентно).
    """
    vault_path = Path(vault_path)
    items: list[BackfillItem] = []
    outputs = vault_path / "07-outputs"
    if outputs.is_dir():
        for path in sorted(outputs.rglob("*.md")):
            if path.name not in OUTPUT_FILE_KINDS:
                continue
            text = path.read_text(encoding="utf-8")
            if _has_frontmatter_id(text):
                continue
            sibling = path.parent / "output.md"
            body = sibling.read_text(encoding="utf-8") if sibling.is_file() else text
            fields = output_note_fields(
                path.parent, path.name, body=body, related=related_from_body(body)
            )
            items.append(BackfillItem(
                path=path.relative_to(vault_path).as_posix(),
                new_id=str(fields["id"]), type=str(fields["type"]), fields=fields,
            ))
    projects = vault_path / "03-projects"
    if projects.is_dir():
        for project in sorted(p for p in projects.iterdir() if p.is_dir()):
            for stem in _PROJECT_DOC_STEMS:
                path = project / f"{stem}.md"
                if not path.is_file() or _has_frontmatter_id(path.read_text(encoding="utf-8")):
                    continue
                new_id = unicodedata.normalize("NFC", f"{stem.lower()}-{project.name}")
                items.append(BackfillItem(
                    path=path.relative_to(vault_path).as_posix(), new_id=new_id,
                    type="", fields={"id": new_id},
                ))
    return items


def _atomic_write(path: Path, text: str) -> None:
    tmp = path.with_name(path.name + ".tmp-backfill")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def apply_backfill(
    vault_path: Path,
    items: list[BackfillItem],
    *,
    dry_run: bool = True,
    limit: int | None = None,
    report_path: Path | None = None,
) -> dict[str, Any]:
    """Применить план. ``dry_run`` (дефолт) ничего не пишет; ``limit`` — канарейка (3 → все).

    Каждая запись атомарна (tmp → replace), после неё id перечитывается штатным
    ``read_note`` и сверяется — расхождение → ``error`` (файл при этом уже записан, но
    отчёт скажет). Заметка, получившая id, при следующем reindex перепланируется (mtime
    изменился): старые чанки схлопнутых ``output``/``sources``/``prompt`` снимает «исчезнувший
    id», новые — эмбеддятся под своими id.
    """
    from core.vault import read_note

    vault_path = Path(vault_path)
    chosen = items if limit is None else items[: max(0, limit)]
    for item in chosen:
        path = vault_path / item.path
        try:
            text = path.read_text(encoding="utf-8")
            if _has_frontmatter_id(text):
                item.status = "skipped"
                continue
            if dry_run:
                continue
            _atomic_write(path, insert_frontmatter_fields(text, item.fields))
            got = read_note(path, vault_path).id
            if got != item.new_id:
                item.status = "error"
                item.error = f"после записи id={got!r}, ожидали {item.new_id!r}"
            else:
                item.status = "written"
        except Exception as exc:  # noqa: BLE001 — один файл не валит весь бэкфилл
            item.status = "error"
            item.error = f"{type(exc).__name__}: {exc}"[:200]
            logger.warning("[backfill] %s: %s", item.path, item.error)
    counts: dict[str, int] = {}
    for item in chosen:
        counts[item.status] = counts.get(item.status, 0) + 1
    report: dict[str, Any] = {
        "dry_run": dry_run,
        "planned_total": len(items),
        "processed": len(chosen),
        "counts": counts,
        "items": [asdict(i) | {"fields": None} for i in chosen],
    }
    if not dry_run:
        _write_report(report, report_path)
    return report


def _write_report(report: dict[str, Any], path: Path | None) -> None:
    if path is None:
        from core.config import index_report_path

        path = index_report_path().parent / "note_id_backfill_report.json"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError as exc:
        logger.warning("[backfill] отчёт %s не записан: %s", path, exc)
