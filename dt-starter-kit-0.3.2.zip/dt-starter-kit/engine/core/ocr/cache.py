"""OCR-1 п.3 — кэш результатов распознавания по БАЙТОВОМУ хэшу файла + журнал прогонов.

``.derived/ocr/<byte_hash>.json`` - страницы ``[{no, text, conf}]``, средняя уверенность, движок,
версия, языки и :data:`core.ocr.engine.OCR_VERSION`. Запись кэша - это и есть чекпойнт документа:
повторный прогон пропускает документ с валидной записью. Смена ``OCR_VERSION`` обесценивает
записи (читаются как отсутствующие). Для приватного результата (``refused_text``) в записи НЕТ
текста: только состояние, число страниц с находкой и имена правил.

Журнал ``journal.jsonl`` - по строке на документ: ``ts``, непрозрачный ``doc`` (12 символов
байтового хэша), ``state``, ``pages``, ``conf``, ``engine``. Ни путей, ни текста: приватному там
делать нечего. Сводка за 7 дней для доктора считается по нему.
"""

from __future__ import annotations

import contextlib
import json
import os
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.ocr.engine import OCR_VERSION
from core.ocr.settings import journal_path, last_run_path, ocr_dir, partial_dir

__all__ = [
    "STATE_DONE",
    "STATE_EMPTY",
    "STATE_REFUSED_TEXT",
    "append_journal",
    "append_partial",
    "drop_partial",
    "journal_summary",
    "load_result",
    "lookup_for_file",
    "open_partial",
    "partial_path",
    "prune_partials",
    "read_last_run",
    "result_path",
    "save_result",
    "write_last_run",
]

STATE_DONE = "done"
STATE_REFUSED_TEXT = "refused_text"
STATE_EMPTY = "empty"  # распознано, но слов нет (пустой лист/мусор) - повторять незачем


def result_path(byte_hash: str) -> Path:
    return ocr_dir() / f"{byte_hash}.json"


def load_result(byte_hash: str) -> dict[str, Any] | None:
    """Запись кэша, если она читается и ее версия == :data:`OCR_VERSION`; иначе ``None``."""
    path = result_path(byte_hash)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or str(data.get("version")) != OCR_VERSION:
        return None
    return data


def save_result(byte_hash: str, record: dict[str, Any]) -> Path:
    """Атомарно записать результат (``version``/``cached_at`` проставляются здесь)."""
    path = result_path(byte_hash)
    path.parent.mkdir(parents=True, exist_ok=True)
    body = {
        **record, "byte_hash": byte_hash, "version": OCR_VERSION,
        "cached_at": datetime.now(UTC).isoformat(timespec="seconds"),
    }
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(body, ensure_ascii=False, indent=1, sort_keys=True), encoding="utf-8")
    os.replace(tmp, path)
    return path


def lookup_for_file(path: Path) -> dict[str, Any] | None:
    """Результат OCR для файла по байтовому хэшу; нет каталога кэша/записи -> ``None`` (дешево).

    Хэш считается только если каталог ``.derived/ocr`` существует и в нем есть записи: обычный
    прогон без OCR файл лишний раз не читает."""
    d = ocr_dir()
    try:
        if not d.is_dir() or not any(d.glob("*.json")):
            return None
    except OSError:
        return None
    from core.sources.cache import file_content_hash

    try:
        digest = file_content_hash(Path(path))
    except OSError:
        return None
    return load_result(digest)


def append_journal(
    byte_hash: str, state: str, *, pages: int = 0, conf: float | None = None,
    engine: str = "", now: datetime | None = None,
) -> None:
    """Строка журнала (best-effort: журнал наблюдает, а не ломает прогон)."""
    row: dict[str, Any] = {
        "ts": (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "doc": byte_hash[:12], "state": state, "pages": pages,
    }
    if conf is not None:
        row["conf"] = round(conf, 3)
    if engine:
        row["engine"] = engine
    try:
        path = journal_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    except OSError:
        pass


def journal_summary(days: int = 7, *, now: datetime | None = None) -> dict[str, int]:
    """``{docs, pages, done, low, refused_text, empty}`` за ``days`` журнал (нет файла - нули)."""
    out = {"docs": 0, "pages": 0, "done": 0, "low": 0, "refused_text": 0, "empty": 0}
    try:
        lines = journal_path().read_text(encoding="utf-8").splitlines()
    except OSError:
        return out
    cutoff = (now or datetime.now(UTC)) - timedelta(days=days)
    for line in lines:
        try:
            row = json.loads(line)
            ts = datetime.strptime(row["ts"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
        except (ValueError, KeyError, TypeError):
            continue
        if ts < cutoff:
            continue
        out["docs"] += 1
        out["pages"] += int(row.get("pages") or 0)
        state = str(row.get("state") or "")
        if state in out:
            out[state] += 1
    return out


# --------------------------------------------------------------------------- #
# Чекпойнт страниц недораспознанного документа (NIGHT-CHAIN-1)                  #
# --------------------------------------------------------------------------- #
# ``partial/<byte_hash>.jsonl``: первая строка - ``{"meta": {version, engine, lang, page_count}}``,
# далее
# по строке на страницу ``{no, text, conf}``. Дописывается ПОСТРАНИЧНО (append: прерывание бюджетом,
# SIGTERM, сон, kill не теряют сделанное), читается с терпимостью к оборванной последней строке.
# В файл попадают только страницы, прошедшие текстовый гард (:func:`core.ocr.privacy.text_guard`):
# приватному тексту на диске делать нечего. Итог документа (``save_result``) снимает чекпойнт.
def partial_path(byte_hash: str) -> Path:
    return partial_dir() / f"{byte_hash}.jsonl"


def open_partial(
    byte_hash: str, *, engine: str, lang: str, page_count: int
) -> list[dict[str, Any]]:
    """Страницы валидного чекпойнта (``[{no, text, conf}]``, по возрастанию ``no``) или ``[]``.

    Чекпойнт валиден, если версия контура, движок, языки и число страниц совпадают с текущими
    (иначе распознавание документа начинается заново, старый файл заменяется). Заодно готовит файл к
    дозаписи: заголовок пишется, если валидного чекпойнта нет."""
    meta = {"version": OCR_VERSION, "engine": engine, "lang": lang, "page_count": int(page_count)}
    path = partial_path(byte_hash)
    pages: dict[int, dict[str, Any]] = {}
    valid = False
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        lines = []
    for i, line in enumerate(lines):
        try:
            row = json.loads(line)
        except ValueError:
            continue  # оборванная запись последней страницы
        if not isinstance(row, dict):
            continue
        if i == 0:
            valid = row.get("meta") == meta
            if not valid:
                break
            continue
        try:
            pages[int(row["no"])] = {"no": int(row["no"]), "text": str(row.get("text") or ""),
                                     "conf": float(row.get("conf") or 0.0)}
        except (KeyError, TypeError, ValueError):
            continue
    if valid:
        return [pages[n] for n in sorted(pages)]
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"meta": meta}, ensure_ascii=False) + "\n", encoding="utf-8")
    except OSError:
        pass
    return []


def append_partial(byte_hash: str, no: int, text: str, conf: float) -> None:
    """Дописать страницу в чекпойнт (best-effort: сбой записи - документ просто начнется заново)."""
    try:
        with partial_path(byte_hash).open("a", encoding="utf-8") as fh:
            fh.write(json.dumps({"no": int(no), "text": text, "conf": round(float(conf), 4)},
                                ensure_ascii=False) + "\n")
    except OSError:
        pass


def drop_partial(byte_hash: str) -> None:
    with contextlib.suppress(OSError):
        partial_path(byte_hash).unlink()


def prune_partials(max_age_days: int = 30, *, now: float | None = None) -> int:
    """Убрать чекпойнты, которые не трогали дольше ``max_age_days`` (файл удален/заменен: хэш
    байтов уже не придет). Возвращает число убранных."""
    cutoff = (now if now is not None else time.time()) - max_age_days * 86400
    removed = 0
    try:
        files = list(partial_dir().glob("*.jsonl"))
    except OSError:
        return 0
    for f in files:
        with contextlib.suppress(OSError):
            if f.stat().st_mtime < cutoff:
                f.unlink()
                removed += 1
    return removed


def write_last_run(body: dict[str, Any]) -> None:
    """Итог последнего прогона шага (``runs/last.json``) - читает доктор «OCR». Best-effort."""
    try:
        path = last_run_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(body, ensure_ascii=False, indent=1, sort_keys=True),
                       encoding="utf-8")
        os.replace(tmp, path)
    except OSError:
        pass


def read_last_run() -> dict[str, Any] | None:
    try:
        data = json.loads(last_run_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None
