"""OCR-1 п.3 — движок распознавания: один интерфейс, результат одного вида.

``OcrEngine.recognize_pdf(path, pages=None)`` отдает :class:`OcrResult` — список страниц
``(no, text, conf)`` (``conf`` 0..1, средняя по словам) + ``engine``/``version``/``lang``/``ms``.
Движки:

* ``tesseract`` (дефолт) - ``gs`` рендерит страницу в ``pnggray`` 300 dpi, ``tesseract -l rus+eng
  --psm 3 tsv`` дает слова и уверенность за один проход. Детерминированный, офлайн, brew;
* ``vision`` - Apple Vision (``pyobjc-framework-Vision``), только если пакет установлен. НЕ
  зависимость проекта: нет пакета -> :class:`OcrUnavailable` с кодом, а не ImportError.

Временные файлы рендера - под ``.derived/ocr/tmp`` (в песочнице ``/tmp`` недоступен для
``ocrmypdf``/``gs`` из-под MCP-шелла) и удаляются после страницы. Исходный pdf только читается.
"""

from __future__ import annotations

import contextlib
import os
import shutil
import subprocess
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

from core.config import derived_root

__all__ = [
    "DEFAULT_LANGS",
    "OCR_VERSION",
    "OcrEngine",
    "OcrInterrupted",
    "OcrPage",
    "OcrResult",
    "OcrUnavailable",
    "TesseractEngine",
    "VisionEngine",
    "get_engine",
    "ocr_langs",
    "pdf_page_count",
    "tmp_dir",
]

# Версия контура распознавания: смена (движок/рендер/сборка текста) обесценивает кэш результатов.
OCR_VERSION = "1"
DEFAULT_LANGS = "rus+eng"
_RENDER_DPI = 300
_PAGE_TIMEOUT_S = 180.0


class OcrInterrupted(RuntimeError):
    """Прогон остановлен между страницами (SIGTERM/отмена JOB): документ не сохраняется -
    «целиком или ничего»."""


class OcrUnavailable(RuntimeError):
    """Движка нет на машине (нет бинаря/пакета): шаг честно ``unavailable``, заглушки остаются."""

    code = "ocr_unavailable"

    def __init__(self, reason: str, *, what: str = "") -> None:
        self.reason = reason
        self.what = what
        super().__init__(reason)


@dataclass
class OcrPage:
    no: int
    text: str
    conf: float  # 0..1, средняя по словам; 0.0 - слов нет


@dataclass
class OcrResult:
    pages: list[OcrPage]
    engine: str
    version: str
    lang: str
    ms: int = 0
    meta: dict[str, object] = field(default_factory=dict)

    @property
    def words(self) -> int:
        return sum(len(p.text.split()) for p in self.pages)

    @property
    def confidence(self) -> float:
        """Средняя уверенность по документу, взвешенная числом слов (0..1)."""
        total = sum(len(p.text.split()) for p in self.pages)
        if not total:
            return 0.0
        return sum(p.conf * len(p.text.split()) for p in self.pages) / total


class OcrEngine(Protocol):
    name: str

    def version(self) -> str: ...

    def recognize_pdf(
        self, path: Path, pages: list[int] | None = None, *, page_count: int | None = None,
        should_stop: Callable[[], bool] | None = None,
        on_page: Callable[[OcrPage], None] | None = None,
    ) -> OcrResult: ...


def ocr_langs() -> str:
    """Языки распознавания (``DT_OCR_LANGS``, дефолт ``rus+eng``; ``+kaz`` - по желанию)."""
    raw = (os.environ.get("DT_OCR_LANGS") or "").strip().replace(",", "+").replace(" ", "")
    return raw or DEFAULT_LANGS


def tmp_dir() -> Path:
    """``.derived/ocr/tmp`` - рабочие файлы рендера (не ``/tmp``: sandbox мака)."""
    p = derived_root() / "ocr" / "tmp"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _bin(name: str) -> str | None:
    return shutil.which(name)


def _pdf_page_count(path: Path) -> int | None:
    try:
        import pdfplumber

        with pdfplumber.open(str(path)) as pdf:
            return len(pdf.pages)
    except Exception:  # noqa: BLE001 — число страниц - подсказка; без него считаем по рендеру
        return None


pdf_page_count = _pdf_page_count  # публичное имя для чекпойнта страниц (core.ocr.run)


def _run(cmd: list[str], *, timeout: float) -> subprocess.CompletedProcess[str]:
    return subprocess.run(  # noqa: S603 — аргументы собраны из наших путей/констант
        cmd, capture_output=True, text=True, timeout=timeout, check=False,
    )


def _render_page(pdf: Path, page_no: int, out_png: Path) -> bool:
    """Одна страница pdf -> серый png 300 dpi через ``gs``; ``False`` - не отрендерилось."""
    gs = _bin("gs")
    if gs is None:
        return False
    cmd = [
        gs, "-q", "-dNOPAUSE", "-dBATCH", "-dSAFER", "-sDEVICE=pnggray", f"-r{_RENDER_DPI}",
        f"-dFirstPage={page_no}", f"-dLastPage={page_no}", f"-sOutputFile={out_png}", str(pdf),
    ]
    try:
        proc = _run(cmd, timeout=_PAGE_TIMEOUT_S)
    except subprocess.TimeoutExpired:
        return False
    return proc.returncode == 0 and out_png.is_file() and out_png.stat().st_size > 0


def parse_tsv(tsv: str) -> tuple[str, float]:
    """Вывод ``tesseract ... tsv`` -> ``(текст построчно, средняя уверенность 0..1)``.

    Строки собираются по ``(block, par, line)``; пустые слова и ``conf < 0`` (служебные
    уровни) в среднее не идут. Чистая функция: тестируется без бинаря.
    """
    lines: dict[tuple[int, int, int], list[str]] = {}
    confs: list[float] = []
    for row in tsv.splitlines()[1:]:
        cols = row.split("\t")
        if len(cols) < 12:
            continue
        text = cols[11].strip()
        try:
            conf = float(cols[10])
            key = (int(cols[2]), int(cols[3]), int(cols[4]))
        except ValueError:
            continue
        if not text or conf < 0:
            continue
        lines.setdefault(key, []).append(text)
        confs.append(conf)
    body = "\n".join(" ".join(words) for _k, words in sorted(lines.items()))
    return body, (sum(confs) / len(confs) / 100.0 if confs else 0.0)


class TesseractEngine:
    """``gs`` + ``tesseract`` (brew). Нет любого из двух -> :class:`OcrUnavailable`."""

    name = "tesseract"

    def __init__(self, langs: str | None = None, *, psm: int = 3) -> None:
        self.langs = langs or ocr_langs()
        self.psm = psm

    def _require(self) -> str:
        tess = _bin("tesseract")
        if tess is None:
            raise OcrUnavailable(
                "tesseract не найден в PATH (brew install tesseract tesseract-lang)",
                what="tesseract",
            )
        if _bin("gs") is None:
            raise OcrUnavailable("gs (ghostscript) не найден в PATH (brew install ghostscript)",
                                 what="gs")
        return tess

    def version(self) -> str:
        tess = self._require()
        try:
            out = _run([tess, "--version"], timeout=20).stdout or ""
        except (subprocess.TimeoutExpired, OSError):
            return "unknown"
        for line in (out + "\n").splitlines():
            if line.lower().startswith("tesseract"):
                return line.split()[-1]
        return "unknown"

    def recognize_page(self, pdf: Path, page_no: int) -> OcrPage:
        tess = self._require()
        png = tmp_dir() / f"{uuid.uuid4().hex}.png"
        try:
            if not _render_page(pdf, page_no, png):
                return OcrPage(page_no, "", 0.0)
            proc = _run(
                [tess, str(png), "stdout", "-l", self.langs, "--psm", str(self.psm), "tsv"],
                timeout=_PAGE_TIMEOUT_S,
            )
        except subprocess.TimeoutExpired:
            return OcrPage(page_no, "", 0.0)
        finally:
            with contextlib.suppress(OSError):
                png.unlink()
        if proc.returncode != 0:
            return OcrPage(page_no, "", 0.0)
        text, conf = parse_tsv(proc.stdout)
        return OcrPage(page_no, text, conf)

    def recognize_pdf(
        self, path: Path, pages: list[int] | None = None, *, page_count: int | None = None,
        should_stop: Callable[[], bool] | None = None,
        on_page: Callable[[OcrPage], None] | None = None,
    ) -> OcrResult:
        self._require()
        started = time.monotonic()
        if pages is None:
            n = page_count or _pdf_page_count(path) or 0
            pages = list(range(1, n + 1))
        out: list[OcrPage] = []
        for no in pages:
            if should_stop is not None and should_stop():
                raise OcrInterrupted(f"остановлено на странице {no}")
            page = self.recognize_page(path, no)
            out.append(page)
            if on_page is not None:
                on_page(page)  # чекпойнт страницы (NIGHT-CHAIN-1): прерывание не теряет сделанное
        return OcrResult(
            pages=out, engine=self.name, version=self.version(), lang=self.langs,
            ms=int((time.monotonic() - started) * 1000),
        )


class VisionEngine:
    """Apple Vision через ``pyobjc-framework-Vision`` - опционально (не зависимость проекта)."""

    name = "vision"

    def __init__(self, langs: str | None = None) -> None:
        self.langs = langs or ocr_langs()

    @staticmethod
    def _import():  # type: ignore[no-untyped-def]
        try:
            import Quartz  # type: ignore[import-not-found,import-untyped]  # noqa: F401
            import Vision  # type: ignore[import-not-found,import-untyped]
            from Foundation import NSURL  # type: ignore[import-not-found,import-untyped]
        except ImportError as exc:
            raise OcrUnavailable(
                "pyobjc-framework-Vision не установлен (необязательный движок: "
                "uv pip install pyobjc-framework-Vision pyobjc-framework-Quartz)",
                what="vision",
            ) from exc
        return Vision, NSURL

    def version(self) -> str:
        self._import()
        import platform

        return f"macos-{platform.mac_ver()[0] or 'unknown'}"

    def _vision_langs(self) -> list[str]:
        table = {"rus": "ru-RU", "eng": "en-US", "kaz": "kk-KZ"}
        return [table[x] for x in self.langs.split("+") if x in table] or ["ru-RU", "en-US"]

    def recognize_page(self, pdf: Path, page_no: int) -> OcrPage:
        vision, nsurl = self._import()
        png = tmp_dir() / f"{uuid.uuid4().hex}.png"
        try:
            if not _render_page(pdf, page_no, png):
                return OcrPage(page_no, "", 0.0)
            handler = vision.VNImageRequestHandler.alloc().initWithURL_options_(
                nsurl.fileURLWithPath_(str(png)), None
            )
            request = vision.VNRecognizeTextRequest.alloc().init()
            request.setRecognitionLevel_(vision.VNRequestTextRecognitionLevelAccurate)
            request.setRecognitionLanguages_(self._vision_langs())
            request.setUsesLanguageCorrection_(True)
            ok, _err = handler.performRequests_error_([request], None)
            if not ok:
                return OcrPage(page_no, "", 0.0)
            lines: list[str] = []
            confs: list[float] = []
            for obs in request.results() or []:
                cand = obs.topCandidates_(1)
                if not cand:
                    continue
                text = str(cand[0].string()).strip()
                if text:
                    lines.append(text)
                    confs.extend([float(cand[0].confidence())] * max(1, len(text.split())))
            return OcrPage(page_no, "\n".join(lines),
                           sum(confs) / len(confs) if confs else 0.0)
        finally:
            with contextlib.suppress(OSError):
                png.unlink()

    def recognize_pdf(
        self, path: Path, pages: list[int] | None = None, *, page_count: int | None = None,
        should_stop: Callable[[], bool] | None = None,
        on_page: Callable[[OcrPage], None] | None = None,
    ) -> OcrResult:
        self._import()
        if _bin("gs") is None:
            raise OcrUnavailable("gs (ghostscript) не найден в PATH", what="gs")
        started = time.monotonic()
        if pages is None:
            pages = list(range(1, (page_count or _pdf_page_count(path) or 0) + 1))
        out: list[OcrPage] = []
        for no in pages:
            if should_stop is not None and should_stop():
                raise OcrInterrupted(f"остановлено на странице {no}")
            page = self.recognize_page(path, no)
            out.append(page)
            if on_page is not None:
                on_page(page)  # чекпойнт страницы (NIGHT-CHAIN-1): прерывание не теряет сделанное
        return OcrResult(
            pages=out, engine=self.name, version=self.version(), lang=self.langs,
            ms=int((time.monotonic() - started) * 1000),
        )


_ENGINES: dict[str, type] = {"tesseract": TesseractEngine, "vision": VisionEngine}


def get_engine(name: str | None = None) -> OcrEngine:
    """Движок по имени (``DT_OCR_ENGINE``, дефолт ``tesseract``); неизвестный - ошибка с кодом."""
    key = (name or os.environ.get("DT_OCR_ENGINE") or "tesseract").strip().lower()
    cls = _ENGINES.get(key)
    if cls is None:
        raise OcrUnavailable(
            f"неизвестный движок OCR {key!r}; допустимо: {', '.join(sorted(_ENGINES))}",
            what=key,
        )
    return cls()  # type: ignore[no-any-return]
