"""OCR-1 п.2 — приватность ДО и ПОСЛЕ распознавания.

OCR делает из картинки текст, а текст попадает в индекс. HR-согласия, листы согласования,
удостоверения лежат сканами без имени-маркера (``Яковлева.pdf``), и ``discover.privacy_reason``
(A1/A2 по имени) их не ловит. Поэтому два барьера:

1. **До** (:func:`path_reason`): путь/имя под правилами ``discover.privacy_reason`` + NDA-барьер
   **плюс** набор OCR-1 (словарь ``vault/_system/ocr-privacy.yaml``, дефолты - в коде, как у
   ``mail-filter.yaml``). Попавшее - ``ocr: refused``: страницу не рендерим и не распознаем вовсе.
2. **После** (:func:`text_guard`): распознанный текст проверяется на персональные данные - ИИН
   (12 цифр: дата рождения + разряд + контрольная сумма; БИН организации под правило не
   подпадает), номер паспорта/удостоверения, пара «серия/номер», дата рождения рядом с ФИО. Любая
   страница с находкой - весь документ ``refused_text``: **текст не сохраняется** ни в кэш, ни в
   заметку, ни в журнал (в итоге остается только счетчик страниц).

Причины - имена правил (``privacy-term:согласи``), а не содержимое документов. Словарь
расширяется текстом в vault; битый/пустой yaml - дефолты + предупреждение ``store_unavailable``
(§9 п.22: не молча). Чистые функции, без сети.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from core.contract import CODE_STORE_UNAVAILABLE, warning
from core.legacy.discover import _term_hits, _tokens, nfc, privacy_reason

logger = logging.getLogger(__name__)

__all__ = [
    "DEFAULT_YAML",
    "OcrPrivacyRules",
    "TextVerdict",
    "iin_valid",
    "load_rules",
    "ocr_privacy_path",
    "parse_rules",
    "path_reason",
    "reason_category",
    "text_guard",
]

DEFAULT_TERMS: tuple[str, ...] = (
    "согласи", "паспорт", "удостоверен", "иин", "снилс", "анкет", "трудов", "личн",
    "персональн", "биометр", "медицин",
)
DEFAULT_FOLDERS: tuple[str, ...] = ("HR", "Кадры", "Согласия")

# Запасной набор = начальный vault/_system/ocr-privacy.yaml (тест держит их равными).
DEFAULT_YAML = """\
# Приватность OCR (OCR-1 п.2). Читает core/ocr/privacy.py; правится текстом.
# До распознавания: путь/имя под словарем -> `ocr: refused` (страницы не рендерятся и не
# распознаются). К этому добавляются правила discover.privacy_reason и NDA-барьер.
# Слово до 3 букв - целиком (`иин`), длиннее - как основа (`согласи` -> «Согласие»).
version: 1

# Основы слов в пути/имени файла.
terms:
  - согласи
  - паспорт
  - удостоверен
  - иин
  - снилс
  - анкет
  - трудов
  - личн
  - персональн
  - биометр
  - медицин

# Папки целиком (сегмент пути - слово целиком, без регистра).
folders:
  - HR
  - Кадры
  - Согласия
"""


class RulesError(ValueError):
    """Файл правил не разобрался (в сообщении - что именно)."""


@dataclass
class OcrPrivacyRules:
    terms: list[str] = field(default_factory=lambda: list(DEFAULT_TERMS))
    folders: list[str] = field(default_factory=lambda: list(DEFAULT_FOLDERS))
    source: str = "defaults"  # file | defaults
    path: str = ""
    warnings: list[dict[str, Any]] = field(default_factory=list)


def ocr_privacy_path(vault_path: Path | None = None) -> Path:
    from core.config import vault_system_path

    return vault_system_path(vault_path) / "ocr-privacy.yaml"


def _str_list(value: Any, what: str) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list) or not all(isinstance(x, str) for x in value):
        raise RulesError(f"{what}: ожидается список строк")
    return [nfc(x).strip().lower() for x in value if x.strip()]


def parse_rules(text: str, *, path: str = "") -> OcrPrivacyRules:
    """yaml -> правила. Пустые списки, не-словарь, битый yaml -> :class:`RulesError`."""
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise RulesError(f"yaml не разобран: {str(exc)[:120]}") from exc
    if not isinstance(data, dict):
        raise RulesError("корень файла - не словарь")
    terms = _str_list(data.get("terms"), "terms")
    folders = _str_list(data.get("folders"), "folders")
    if not terms and not folders:
        raise RulesError("оба списка (terms, folders) пусты")
    return OcrPrivacyRules(terms=terms, folders=folders, source="file", path=path)


_CACHE: dict[str, tuple[float, int, OcrPrivacyRules]] = {}


def load_rules(vault_path: Path | None = None, *, path: Path | None = None) -> OcrPrivacyRules:
    """Правила из vault; нет файла - дефолты; битый - дефолты + ``store_unavailable``.

    Дефолты ВСЕГДА входят в набор поверх файла (приватность - набор только растет: файл не может
    убрать ``согласи``). Кэш по ``mtime``+размеру."""
    target = path if path is not None else ocr_privacy_path(vault_path)
    key = str(target)
    try:
        st = target.stat()
        stamp: tuple[float, int] | None = (st.st_mtime, st.st_size)
    except OSError:
        stamp = None
    hit = _CACHE.get(key)
    if hit is not None and stamp is not None and (hit[0], hit[1]) == stamp:
        return hit[2]
    if stamp is None:
        rules = OcrPrivacyRules(path=key)
    else:
        try:
            parsed = parse_rules(target.read_text(encoding="utf-8"), path=key)
            rules = OcrPrivacyRules(
                terms=list(dict.fromkeys([*DEFAULT_TERMS, *parsed.terms])),
                folders=list(dict.fromkeys(
                    [*(f.lower() for f in DEFAULT_FOLDERS), *parsed.folders])),
                source="file", path=key,
            )
        except (RulesError, OSError, UnicodeDecodeError) as exc:
            logger.warning("ocr-privacy: %s не прочитан (%s) - работают дефолты из кода",
                           target.name, exc)
            rules = OcrPrivacyRules(
                path=key,
                warnings=[warning(CODE_STORE_UNAVAILABLE,
                                  f"правила приватности OCR не прочитались ({target.name}: {exc}); "
                                  "работает запасной набор из кода", path=key)],
            )
        _CACHE[key] = (stamp[0], stamp[1], rules)
    return rules


# --------------------------------------------------------------------------- #
# До распознавания                                                            #
# --------------------------------------------------------------------------- #
def path_reason(source_path: str, rules: OcrPrivacyRules | None = None) -> str | None:
    """Причина отказа по пути/имени (``privacy-…`` / ``nda`` / ``ocr-term:…`` / ``ocr-folder:…``)
    либо ``None``. Порядок: NDA -> ``discover.privacy_reason`` -> набор OCR-1."""
    from core.privacy import is_nda

    if is_nda(source_path):
        return "nda"
    base = privacy_reason(source_path)
    if base is not None:
        return base
    rules = rules if rules is not None else load_rules()
    norm = nfc(source_path)
    segments = [s for s in norm.split("/") if s]
    tokens = _tokens(norm)
    for term in rules.terms:
        if _term_hits(tokens, term):
            return f"ocr-term:{term}"
    folder_set = {f.lower() for f in rules.folders}
    for seg in segments[:-1]:
        hit = next((tok for tok in _tokens(seg) if tok in folder_set), None)
        if hit is not None:
            return f"ocr-folder:{hit}"
    return None


def reason_category(reason: str) -> str:
    """Причина для отчетов/сводок БЕЗ значений, которые могут оказаться именами людей.

    ``privacy-name:<фамилия>`` и ``privacy-glob:<шаблон>`` сворачиваются в категорию; остальные -
    имена правил из словарей (``ocr-term:согласи``, ``privacy-term:оклад``) - общие слова."""
    head, _sep, tail = reason.partition(":")
    if head in ("privacy-name", "privacy-glob"):
        return head
    return f"{head}:{tail}" if tail else head


# --------------------------------------------------------------------------- #
# После распознавания                                                         #
# --------------------------------------------------------------------------- #
def iin_valid(digits: str) -> bool:
    """ИИН РК: 12 цифр, ``ГГММДД`` (валидные месяц/день), 7-я цифра 1..6, контрольная сумма.

    БИН организации (5-я цифра 4/5/6, то есть «день» ≥ 40) под это не подпадает - реквизиты
    клиента в обычном письме не повод для отказа."""
    if len(digits) != 12 or not digits.isdigit():
        return False
    mm, dd = int(digits[2:4]), int(digits[4:6])
    if not (1 <= mm <= 12 and 1 <= dd <= 31) or digits[6] not in "123456":
        return False
    d = [int(c) for c in digits]
    s = sum(d[i] * (i + 1) for i in range(11)) % 11
    if s == 10:  # вторая раскладка весов: 3,4,5,6,7,8,9,10,11,1,2
        s = sum(d[i] * w for i, w in enumerate((3, 4, 5, 6, 7, 8, 9, 10, 11, 1, 2))) % 11
        if s == 10:
            return False
    return s == d[11]


_IIN_RE = re.compile(r"(?<!\d)(\d{6}[\s-]?\d{6})(?!\d)")
_ID_DOC_RE = re.compile(
    r"(паспорт|удостоверени[ея]\s+личности|жеке\s+куәлік|identity\s+card|passport)"
    r"[^\n]{0,50}?(?<![\d])\d{7,10}(?!\d)",
    re.IGNORECASE,
)
_SERIES_NUMBER_RE = re.compile(
    r"серия\s*[A-Za-zА-Яа-я0-9]{0,4}\s*(?:№|N|номер)\s*\d{4,}", re.IGNORECASE
)
_DOB_RE = re.compile(
    r"(дата\s+рождения|д\.\s?р\.|родил(?:ся|ась)|date\s+of\s+birth)"
    r"[^\n]{0,30}?\d{1,2}[./]\d{1,2}[./]\d{2,4}",
    re.IGNORECASE,
)
_FIO_RE = re.compile(
    r"[А-ЯЁ][а-яё]{2,}\s+[А-ЯЁ][а-яё]{2,}\s+[А-ЯЁ][а-яё]{2,}(?:ич|на|оглы|кызы|улы|қызы)\b"
)


@dataclass
class TextVerdict:
    refused: bool = False
    reasons: list[str] = field(default_factory=list)  # имена правил, без содержимого
    pages: int = 0  # страниц с находкой


def _page_hits(text: str) -> list[str]:
    hits: list[str] = []
    for m in _IIN_RE.finditer(text):
        if iin_valid(re.sub(r"\D", "", m.group(1))):
            hits.append("iin")
            break
    if _ID_DOC_RE.search(text):
        hits.append("id_document_number")
    if _SERIES_NUMBER_RE.search(text):
        hits.append("series_number")
    if _DOB_RE.search(text) and _FIO_RE.search(text):
        hits.append("birth_date_with_name")
    return hits


def text_guard(pages: list[str]) -> TextVerdict:
    """Проверка распознанных страниц. Находка на любой странице -> ``refused`` для ВСЕГО документа.

    Возвращает только имена правил и число страниц - ни фрагмента текста."""
    verdict = TextVerdict()
    reasons: list[str] = []
    for text in pages:
        hits = _page_hits(text)
        if hits:
            verdict.pages += 1
            for h in hits:
                if h not in reasons:
                    reasons.append(h)
    verdict.reasons = reasons
    verdict.refused = verdict.pages > 0
    return verdict
