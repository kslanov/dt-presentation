"""OCR-1 п.3-4 — очередь сканов и прогон распознавания с бюджетом.

Очередь - записи L1-кэша (``.derived/legacy_extracted``) с ``needs_ocr``; из нее исключены
документы, чьи путь/имя под приватностью (:func:`core.ocr.privacy.path_reason` - они остаются
заглушками ``ocr: refused`` и НЕ рендерятся), и документы с итогом без текста (``refused_text``,
``empty``). Порядок детерминирован: новее по ``mtime``, затем меньше страниц, затем путь.

Прогон (:func:`run_ocr`): на каждый документ - рендер ``gs`` постранично, движок
(:mod:`core.ocr.engine`), текстовый гард приватности (:func:`core.ocr.privacy.text_guard`),
запись кэша (чекпойнт документа) и применение к корпусу: L1-запись пересобирается
(``extract_cached(force=True)`` -> pdf-обработчик видит кэш OCR -> ``pdf-ocr``), запись манифеста
помечается ``ocr_refresh`` - следующий ingest перерисует заметку (``ocr: done`` с телом).

Бюджет ``DT_OCR_BUDGET_S`` (дефолт 1800 с) проверяется между документами И между страницами
(NIGHT-CHAIN-1: один скан на сотни страниц уводил шаг на часы). ``should_stop`` (SIGTERM/отмена
JOB) - там же. Страницы недоделанного документа уходят в чекпойнт
``.derived/ocr/partial/<хэш>.jsonl`` ПОСТРАНИЧНО (после текстового гарда), итог документа в кэш
``<хэш>.json`` пишется только целиком; следующий прогон продолжает с первой нераспознанной
страницы. Источники только читаются. Текст приватных
документов не попадает ни в кэш, ни в чекпойнт, ни в заметку, ни в журнал.
"""

from __future__ import annotations

import json
import logging
import mimetypes
import re
import time
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core import runlock
from core.config import legacy_extracted_path, legacy_roots
from core.fsguard import is_dataless
from core.ocr import cache as ocr_cache
from core.ocr.engine import (
    OcrEngine,
    OcrInterrupted,
    OcrPage,
    OcrResult,
    OcrUnavailable,
    get_engine,
    pdf_page_count,
)
from core.ocr.privacy import load_rules, path_reason, reason_category, text_guard
from core.ocr.settings import budget_s, min_conf, queue_snapshot_path

logger = logging.getLogger(__name__)

__all__ = [
    "OcrStats",
    "QueueItem",
    "build_queue",
    "ocr_pdf",
    "run_ocr",
]

_ERA_RE = re.compile(r"^\d{4}-\d{4}$")
_EST_S_PER_PAGE = 2.0  # оценка для dry-run, если журнал еще пуст (замер спайка: 0,8-4 с)
_LOG_EVERY_PAGES = 25  # строка ``[ocr]`` в dt-sync.log раз в столько страниц (шаг шел молча)
_PARTIAL_TTL_DAYS = 30
_monotonic = time.monotonic  # инъекция для тестов бюджета (как ``dt_sync._sleep``)


@dataclass
class QueueItem:
    source_path: str
    pages: int
    mtime: float
    size: int
    path: Path | None = None  # абсолютный путь на этом устройстве (None - файла нет)
    refused: str | None = None  # причина отказа по пути (правило, не содержимое)


@dataclass
class OcrStats:
    dry_run: bool = True
    queue_docs: int = 0
    queue_pages: int = 0
    processed: int = 0  # документов распознано в этом прогоне
    pages_done: int = 0
    done: int = 0
    low: int = 0
    refused_path: int = 0  # в очереди: путь/имя под приватностью (не распознавались)
    refused_text: int = 0  # распознано, текст приватный -> не сохранен
    empty: int = 0
    resumed: int = 0  # кэш уже был (чекпойнт прежнего прогона) - только применено к корпусу
    missing: int = 0  # файла нет на устройстве
    not_local: int = 0  # iCloud dataless: пропущено с причиной source_not_local (повторит прогон)
    failed: int = 0
    interrupted: bool = False
    budget_hit: bool = False  # бюджет исчерпан: стоп между документами либо на странице документа
    docs_partial: int = 0  # документов остановлено посреди (страницы в чекпойнте, продолжит повтор)
    pages_resumed: int = 0  # страниц взято из чекпойнта прежнего прогона (не распознавались заново)
    partial_doc: str = ""  # непрозрачный id (12 симв. хэша) документа, остановленного посреди
    partial_pages_done: int = 0
    partial_pages_total: int = 0
    budget_s: float = 0.0
    elapsed_s: float = 0.0
    est_s: float = 0.0  # dry-run: оценка секунд на всю очередь
    engine: str = ""
    engine_version: str = ""
    lang: str = ""
    unavailable: str = ""  # код, если движка нет (``ocr_unavailable``)
    unavailable_reason: str = ""
    refreshed: int = 0  # записей манифеста помечено на перерисовку
    refused_reasons: dict[str, int] = field(default_factory=dict)  # правило -> документов

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------- #
# Пути                                                                         #
# --------------------------------------------------------------------------- #
def _bases(roots: list[Path] | None = None) -> list[Path]:
    """Корни, от которых ``source_path`` L1-записей относителен (как у ``file_metadata``)."""
    candidates: list[Path] = list(roots) if roots is not None else list(legacy_roots())
    if roots is None:
        try:
            from core.file_ingest import load_ingest_roots

            candidates += [r.path for r in load_ingest_roots() if r.route == "knowledge"]
        except Exception as exc:  # noqa: BLE001 — нет ingest-roots: остаются legacy-корни
            logger.debug("ocr: ingest-roots не прочитаны (%s)", exc)
    out: list[Path] = []
    for root in candidates:
        base = root.parent if _ERA_RE.match(root.name) else root
        if base not in out:
            out.append(base)
    return out


def _resolve(source_path: str, bases: list[Path]) -> Path | None:
    for base in bases:
        candidate = base / source_path
        try:
            if candidate.is_file():
                return candidate
        except OSError:
            continue
    return None


def _legacy_file(path: Path, source_path: str) -> Any:
    """:class:`LegacyFile` по ``source_path`` и абсолютному пути - так же, как ``file_metadata``
    (era - первый сегмент вида ``YYYY-YYYY``; section/client - папки под корнем)."""
    from core.legacy.discover import LegacyFile, _section_of, nfc

    parts = source_path.split("/")
    era = parts[0] if parts and _ERA_RE.match(parts[0]) else ""
    inner = parts[1:] if era else parts
    dirs = inner[:-1]
    stat = path.stat()
    return LegacyFile(
        path=path, source_path=source_path, filename=nfc(path.name), ext=path.suffix.lower(),
        size=stat.st_size, mtime=stat.st_mtime, era=era,
        section=_section_of(dirs[0]) if dirs else "",
        client=nfc(dirs[1]) if len(dirs) >= 2 else "",
        mime=mimetypes.guess_type(path.name)[0] or "",
    )


# --------------------------------------------------------------------------- #
# Очередь                                                                      #
# --------------------------------------------------------------------------- #
def _l1_scans() -> list[dict[str, Any]]:
    """Записи L1-кэша со сканом. Быстрый отсев подстрокой ``"needs_ocr": true`` до разбора json."""
    out: list[dict[str, Any]] = []
    root = legacy_extracted_path()
    if not root.is_dir():
        return out
    for f in sorted(root.glob("*.json")):
        try:
            text = f.read_text(encoding="utf-8")
        except OSError:
            continue
        if '"needs_ocr": true' not in text:
            continue
        try:
            rec = json.loads(text)
        except ValueError:
            continue
        if isinstance(rec, dict) and rec.get("needs_ocr") and rec.get("status") == "skipped":
            out.append(rec)
    return out


def build_queue(
    *, path_scope: str | None = None, roots: list[Path] | None = None, write_snapshot: bool = True,
) -> list[QueueItem]:
    """Очередь OCR (включая отказанных по пути - они помечены ``refused``, в прогон не идут).

    Исключены записи с итогом без текста (``meta.ocr_state``: ``refused_text``/``empty``).
    Снимок очереди (``.derived/ocr/queue.json``) - для доктора/пульта: счетчики, без путей."""
    from core.legacy.ingest import _under_scope

    bases = _bases(roots)
    rules = load_rules()
    prefix = (path_scope or "").strip("/").replace("\\", "/")
    items: list[QueueItem] = []
    for rec in _l1_scans():
        meta = rec.get("meta") or {}
        if meta.get("ocr_state"):
            continue  # терминальный итог OCR: текста нет, повторять незачем
        sp = str(rec.get("source_path") or "")
        if not sp or (prefix and not _under_scope(sp, prefix)):
            continue
        items.append(QueueItem(
            source_path=sp, pages=int(meta.get("pages") or 0), mtime=float(rec.get("mtime") or 0),
            size=int(rec.get("size") or 0), path=_resolve(sp, bases),
            refused=path_reason(sp, rules),
        ))
    items.sort(key=lambda i: (-i.mtime, i.pages, i.source_path))
    if write_snapshot:
        _write_snapshot(items, scoped=bool(prefix))
    return items


def _write_snapshot(items: list[QueueItem], *, scoped: bool) -> None:
    if scoped:
        return  # срез по папке не перезаписывает общий снимок
    live = [i for i in items if not i.refused]
    snap = {
        "at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "docs": len(live), "pages": sum(i.pages for i in live),
        "refused": len(items) - len(live),
        "missing": sum(1 for i in live if i.path is None),
    }
    try:
        path = queue_snapshot_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(snap, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
    except OSError:
        pass


# --------------------------------------------------------------------------- #
# Распознавание одного документа                                                #
# --------------------------------------------------------------------------- #
def ocr_pdf(
    path: Path, *, engine: OcrEngine | None = None, page_count: int | None = None,
    should_stop: Callable[[], bool] | None = None,
) -> OcrResult:
    """Распознать pdf целиком (``OcrResult``: страницы ``(no, text, conf)``, движок/версия/язык)."""
    return (engine or get_engine()).recognize_pdf(
        Path(path), page_count=page_count, should_stop=should_stop
    )


def _record_from(result: OcrResult, *, low_conf: float) -> tuple[dict[str, Any], str]:
    """Запись кэша + итоговое состояние (done | refused_text | empty). Гард - ДО записи."""
    verdict = text_guard([p.text for p in result.pages])
    base: dict[str, Any] = {
        "engine": result.engine, "engine_version": result.version, "lang": result.lang,
        "ms": result.ms, "page_count": len(result.pages),
    }
    if verdict.refused:
        return {**base, "state": ocr_cache.STATE_REFUSED_TEXT, "refused_pages": verdict.pages,
                "reasons": verdict.reasons}, ocr_cache.STATE_REFUSED_TEXT
    if not result.words:
        return {**base, "state": ocr_cache.STATE_EMPTY, "pages": []}, ocr_cache.STATE_EMPTY
    conf = result.confidence
    return {
        **base, "state": ocr_cache.STATE_DONE, "confidence": round(conf, 4),
        "low": conf < low_conf,
        "pages": [{"no": p.no, "text": p.text, "conf": round(p.conf, 4)} for p in result.pages],
    }, ocr_cache.STATE_DONE


def _apply(item: QueueItem, refresh: list[str]) -> bool:
    """Результат -> корпус: пересобрать L1-запись (pdf-обработчик подхватит кэш OCR)."""
    from core.legacy.cache import extract_cached

    if item.path is None:
        return False
    try:
        extract_cached(_legacy_file(item.path, item.source_path), force=True)
    except Exception as exc:  # noqa: BLE001 — сбой одного документа не валит прогон
        logger.warning("[ocr] L1 не пересобран (%s): %s", type(exc).__name__, str(exc)[:120])
        return False
    refresh.append(item.source_path)
    return True


class _PrivatePage(Exception):
    """Страница не прошла текстовый гард: документ закрывается как ``refused_text`` (дальше читать
    приватное незачем), текст страницы нигде не сохраняется."""

    def __init__(self, reasons: list[str]) -> None:
        self.reasons = reasons
        super().__init__("private text")


@dataclass
class _DocProgress:
    doc: str
    total: int
    done: int = 0  # страниц документа, лежащих в чекпойнте (прежних + этого прогона)


def _recognize_doc(
    item: QueueItem, digest: str, eng: OcrEngine, progress: _DocProgress, *,
    stop: Callable[[], bool], stats: OcrStats, started: float,
) -> OcrResult:
    """Распознать документ с чекпойнтом: продолжить с первой страницы, которой нет в чекпойнте.

    Каждая новая страница проходит текстовый гард и дописывается в ``partial/<хэш>.jsonl``; сбой
    движка/остановка оставляют сделанное на диске. ``OcrInterrupted``/``_PrivatePage`` летят
    вызывающему. Число страниц неизвестно (нет в L1, pdf не читается) - чекпойнта нет."""
    if item.path is None:  # вызывающий уже отсеял; для типизации
        raise ValueError("нет пути файла")
    total = progress.total
    lang = str(getattr(eng, "langs", "") or "")
    prior: list[OcrPage] = []
    remaining: list[int] | None = None
    if total > 0:
        prior = [OcrPage(p["no"], p["text"], p["conf"]) for p in ocr_cache.open_partial(
            digest, engine=eng.name, lang=lang, page_count=total) if 1 <= p["no"] <= total]
        have = {p.no for p in prior}
        remaining = [n for n in range(1, total + 1) if n not in have]
        progress.done = len(prior)
        stats.pages_resumed += len(prior)
        if prior:
            logger.info("[ocr] doc=%s: продолжаю со страницы %d (в чекпойнте %d из %d)",
                        progress.doc, remaining[0] if remaining else total, len(prior), total)

    def on_page(page: OcrPage) -> None:
        verdict = text_guard([page.text])
        if verdict.refused:
            raise _PrivatePage(verdict.reasons)
        if total > 0:
            ocr_cache.append_partial(digest, page.no, page.text, page.conf)
        progress.done += 1
        stats.pages_done += 1
        if stats.pages_done % _LOG_EVERY_PAGES == 0:
            logger.info("[ocr] страниц за прогон %d | doc=%s %d/%d | %.0f с из %.0f с бюджета",
                        stats.pages_done, progress.doc, progress.done, total or progress.done,
                        _monotonic() - started, stats.budget_s)

    if remaining == []:  # все страницы уже в чекпойнте (оборвались перед записью итога)
        return OcrResult(pages=sorted(prior, key=lambda p: p.no), engine=eng.name,
                         version=eng.version(), lang=lang, ms=0)
    fresh = eng.recognize_pdf(item.path, pages=remaining, page_count=total or None,
                              should_stop=stop, on_page=on_page)
    if not prior:
        return fresh
    return OcrResult(
        pages=sorted([*prior, *fresh.pages], key=lambda p: p.no), engine=fresh.engine,
        version=fresh.version, lang=fresh.lang, ms=fresh.ms, meta=fresh.meta,
    )


# --------------------------------------------------------------------------- #
# Прогон                                                                       #
# --------------------------------------------------------------------------- #
def run_ocr(
    *,
    dry_run: bool = True,
    limit: int | None = None,
    budget: float | None = None,
    should_stop: Callable[[], bool] | None = None,
    on_progress: Callable[[str], None] | None = None,
    path_scope: str | None = None,
    engine: OcrEngine | None = None,
    roots: list[Path] | None = None,
) -> OcrStats:
    """Очередь -> распознавание -> корпус; ``dry_run`` - только очередь и оценка (OCR не идет)."""
    started = _monotonic()
    log = on_progress or (lambda _m: None)
    stop = should_stop or (lambda: False)
    stats = OcrStats(dry_run=dry_run, budget_s=budget if budget is not None else budget_s())
    items = build_queue(path_scope=path_scope, roots=roots)
    live = [i for i in items if not i.refused]
    stats.queue_docs = len(live)
    stats.queue_pages = sum(i.pages for i in live)
    stats.refused_path = len(items) - len(live)
    for it in items:
        if it.refused:
            key = reason_category(it.refused)
            stats.refused_reasons[key] = stats.refused_reasons.get(key, 0) + 1
    stats.missing = sum(1 for i in live if i.path is None)

    try:
        eng = engine or get_engine()
        stats.engine, stats.engine_version = eng.name, eng.version()
        stats.lang = getattr(eng, "langs", "")
    except OcrUnavailable as exc:
        stats.unavailable, stats.unavailable_reason = exc.code, exc.reason
        logger.warning("[ocr] движок недоступен: %s (заглушки остаются)", exc.reason)
        stats.elapsed_s = _monotonic() - started
        return stats

    # приватность по пути: только счетчик (counter-политика журнала отказов, без hint)
    from core.ingress.refusals import refuse_many

    refuse_many("ocr", "privacy_probe", [(None, None)] * stats.refused_path)

    if dry_run:
        per_page = _observed_s_per_page()
        stats.est_s = round(stats.queue_pages * per_page, 1)
        stats.elapsed_s = _monotonic() - started
        return stats

    budget_flag = {"hit": False}

    def page_stop() -> bool:
        """Остановка между страницами: внешний стоп (SIGTERM/отмена JOB) ИЛИ дедлайн бюджета."""
        runlock.beat()  # heartbeat на страницу: сторож видит прогресс долгого документа
        if stop():
            return True
        if _monotonic() - started >= stats.budget_s:
            budget_flag["hit"] = True
            return True
        return False

    refresh: list[str] = []
    from core.sources.cache import file_content_hash

    logger.info("[ocr] старт: очередь %d док. / %d стр., бюджет %.0f с, движок %s",
                stats.queue_docs, stats.queue_pages, stats.budget_s, stats.engine)
    ocr_cache.prune_partials(_PARTIAL_TTL_DAYS)
    try:
        for item in live:
            runlock.beat()
            if stop():
                stats.interrupted = True
                break
            if _monotonic() - started >= stats.budget_s:
                stats.budget_hit = True
                break
            if limit is not None and stats.processed >= limit:
                break
            if item.path is None:
                continue
            if is_dataless(item.path):
                # SRC-ICLOUD-1: заглушку не читаем (блок/EDEADLK) - пропуск с причиной, не падение
                stats.not_local += 1
                log(f"[ocr] doc={item.path.name[:24]} | skip: source_not_local")
                continue
            try:
                digest = file_content_hash(item.path)
            except OSError:
                stats.failed += 1
                continue
            doc = digest[:12]
            cached = ocr_cache.load_result(digest)
            if cached is not None:
                # чекпойнт прежнего прогона: распознавать не надо - только довести до корпуса
                if _apply(item, refresh):
                    stats.resumed += 1
                    log(f"[ocr] doc={doc} | resumed")
                ocr_cache.drop_partial(digest)
                continue
            progress = _DocProgress(doc, item.pages or pdf_page_count(item.path) or 0)
            try:
                result = _recognize_doc(item, digest, eng, progress, stop=page_stop,
                                        stats=stats, started=started)
                record, state = _record_from(result, low_conf=min_conf())
                n_pages = len(result.pages)
            except _PrivatePage as private:
                # гард сработал на странице: итог как у полного прогона (текста нет нигде)
                record = {"engine": eng.name, "engine_version": stats.engine_version,
                          "lang": stats.lang, "ms": 0, "page_count": progress.done,
                          "state": ocr_cache.STATE_REFUSED_TEXT, "refused_pages": 1,
                          "reasons": private.reasons}
                state, n_pages = ocr_cache.STATE_REFUSED_TEXT, progress.done
                result = None
            except OcrInterrupted:
                if budget_flag["hit"]:
                    stats.budget_hit = True
                else:
                    stats.interrupted = True
                if progress.total and 0 < progress.done < progress.total:
                    stats.docs_partial += 1
                    stats.partial_doc = doc
                    stats.partial_pages_done, stats.partial_pages_total = (
                        progress.done, progress.total)
                break
            except OcrUnavailable as exc:
                stats.unavailable, stats.unavailable_reason = exc.code, exc.reason
                break
            except Exception as exc:  # noqa: BLE001 — битый pdf: документ пропущен, прогон идет
                stats.failed += 1
                logger.warning("[ocr] doc=%s: %s", doc, type(exc).__name__)
                continue
            ocr_cache.save_result(digest, record)  # итог документа
            ocr_cache.drop_partial(digest)
            ocr_cache.append_journal(
                digest, "low" if state == ocr_cache.STATE_DONE and record.get("low") else state,
                pages=n_pages, conf=record.get("confidence"), engine=eng.name,
            )
            stats.processed += 1
            if state == ocr_cache.STATE_DONE:
                stats.done += 1
                if record.get("low"):
                    stats.low += 1
            elif state == ocr_cache.STATE_REFUSED_TEXT:
                stats.refused_text += 1
            else:
                stats.empty += 1
            _apply(item, refresh)
            took = f"{result.ms / 1000:.1f} с" if result is not None else "-"
            log(f"[ocr] {stats.processed} | doc={doc} | {state} | {n_pages} стр. | {took}")
    finally:
        if refresh:
            try:
                from core.legacy.ingest import mark_ocr_refresh

                stats.refreshed = mark_ocr_refresh(refresh)
            except Exception as exc:  # noqa: BLE001 — заметки перерисуются позже: L1 уже с текстом
                logger.warning("[ocr] манифесты не помечены (%s): %s", type(exc).__name__,
                               str(exc)[:120])
        stats.elapsed_s = _monotonic() - started
        _finish(stats)
    return stats


def _finish(stats: OcrStats) -> None:
    """Итог шага: строка ``[ocr]`` в журнал (документов/страниц/секунд/бюджет) и ``runs/last.json``
    для доктора «OCR» (на каком документе кончился бюджет и сколько страниц сделано)."""
    tail = ""
    if stats.budget_hit:
        tail = " | бюджет исчерпан"
        if stats.partial_doc:
            tail += (f" на документе {stats.partial_doc}, страниц {stats.partial_pages_done}/"
                     f"{stats.partial_pages_total} (продолжит следующий прогон)")
    elif stats.interrupted:
        tail = " | остановлен по сигналу"
    logger.info(
        "[ocr] итог: документов %d, страниц %d (из чекпойнта %d), %.0f с (бюджет %.0f с), "
        "частично %d, из кэша %d, сбоев %d%s",
        stats.processed, stats.pages_done, stats.pages_resumed, stats.elapsed_s, stats.budget_s,
        stats.docs_partial, stats.resumed, stats.failed, tail,
    )
    ocr_cache.write_last_run({
        "at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "budget_hit": stats.budget_hit, "interrupted": stats.interrupted,
        "budget_s": stats.budget_s, "elapsed_s": round(stats.elapsed_s, 1),
        "docs": stats.processed, "pages": stats.pages_done,
        "pages_resumed": stats.pages_resumed, "docs_partial": stats.docs_partial,
        "partial": ({"doc": stats.partial_doc, "pages_done": stats.partial_pages_done,
                     "pages_total": stats.partial_pages_total} if stats.partial_doc else None),
    })


def _observed_s_per_page() -> float:
    """Оценка секунд на страницу для dry-run (замер спайка 29.10: tesseract ~3,7, Vision ~0,8)."""
    return _EST_S_PER_PAGE
