"""OCR-1: ручки контура (``DT_OCR_*``) и пути кэша. Читаются в момент вызова, не при импорте."""

from __future__ import annotations

import os
from pathlib import Path

from core.config import derived_root

__all__ = [
    "DEFAULT_BUDGET_S",
    "DEFAULT_MIN_CONF",
    "budget_s",
    "journal_path",
    "last_run_path",
    "min_conf",
    "ocr_dir",
    "partial_dir",
    "queue_snapshot_path",
]

DEFAULT_BUDGET_S = 1800.0  # 30 минут на прогон
DEFAULT_MIN_CONF = 0.6  # ниже - заметка с телом, но ``ocr: low`` + предупреждение в журнале


def _float_env(name: str, default: float, *, minimum: float = 0.0) -> float:
    raw = (os.environ.get(name) or "").strip()
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if value >= minimum else default


def budget_s() -> float:
    """``DT_OCR_BUDGET_S`` - секунд на прогон (дефолт 1800); обрыв между документами."""
    value = _float_env("DT_OCR_BUDGET_S", DEFAULT_BUDGET_S)
    return value if value > 0 else DEFAULT_BUDGET_S


def min_conf() -> float:
    """``DT_OCR_MIN_CONF`` - порог средней уверенности 0..1 (дефолт 0,6)."""
    value = _float_env("DT_OCR_MIN_CONF", DEFAULT_MIN_CONF)
    return value if 0.0 <= value <= 1.0 else DEFAULT_MIN_CONF


def ocr_dir() -> Path:
    """``.derived/ocr/``: кэш результатов (``<hash>.json``), журнал, снимок очереди, ``tmp/``."""
    return derived_root() / "ocr"


def journal_path() -> Path:
    return ocr_dir() / "journal.jsonl"


def queue_snapshot_path() -> Path:
    return ocr_dir() / "queue.json"


def partial_dir() -> Path:
    """``.derived/ocr/partial/``: чекпойнт страниц недораспознанных документов (NIGHT-CHAIN-1)."""
    return ocr_dir() / "partial"


def last_run_path() -> Path:
    """``.derived/ocr/runs/last.json``: итог последнего прогона шага (для доктора «OCR»).

    Отдельный подкаталог: в ``ocr/`` лежат только результаты ``<хэш>.json`` и ``queue.json``."""
    return ocr_dir() / "runs" / "last.json"
