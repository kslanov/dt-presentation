"""OCR-1: состояние скана для заметки и сводка для доктора/пульта.

* :func:`stub_state` - ``ocr:`` заглушки: ``refused`` (путь/имя под приватностью, ДО распознавания),
  ``refused_text`` / ``empty`` (итог OCR без текста), иначе ``pending``;
* :func:`stub_body` - единственная строка тела заглушки;
* :func:`summary` - очередь/сделано/низкая уверенность/отказано/движок для ``dt doctor`` и
  ``pult_ingest_sources`` (из манифестов ingest и журнала OCR; ничего не распознает, не читает
  pdf, не трогает индекс).
"""

from __future__ import annotations

import json
from typing import Any

from core.ocr import cache
from core.ocr.settings import queue_snapshot_path

__all__ = [
    "STATES",
    "STUB_STATES",
    "is_ocr_source",
    "manifest_counts",
    "source_row",
    "stub_body",
    "stub_state",
    "summary",
]

STUB_STATES = ("pending", "refused", "refused_text", "empty")
STATES = (*STUB_STATES, "done", "low")


def stub_state(source_path: str, meta: dict[str, Any] | None) -> str:
    """``ocr:`` заглушки: итог OCR из L1 (``ocr_state``) важнее пути; затем приватность."""
    ocr_state = str((meta or {}).get("ocr_state") or "")
    if ocr_state in (cache.STATE_REFUSED_TEXT, cache.STATE_EMPTY):
        return ocr_state
    from core.ocr.privacy import path_reason

    return "refused" if path_reason(source_path) is not None else "pending"


def stub_body(pages: int | None, state: str) -> str:
    n = f"{pages} " if pages else ""
    word = _pages_word(pages)
    head = f"Скан без текстового слоя, {n}{word}".replace("  ", " ").rstrip()
    tail = {
        "pending": "OCR в очереди",
        "refused": "OCR не выполняется (приватность по пути/имени)",
        "refused_text": "OCR выполнен, текст не сохранен (приватность по содержимому)",
        "empty": "OCR выполнен, текста на страницах не найдено",
    }.get(state, "OCR в очереди")
    return f"{head}; {tail}."


def _pages_word(pages: int | None) -> str:
    if not pages:
        return "страниц"
    n = abs(int(pages)) % 100
    if 11 <= n <= 14:
        return "страниц"
    return {1: "страница", 2: "страницы", 3: "страницы", 4: "страницы"}.get(n % 10, "страниц")


def is_ocr_source(path: str | None, content_hash: str | None) -> bool:
    """Источник - pdf, чей текст получен распознаванием (есть запись OCR для его байтов).

    Скан БЕЗ результата тоже не даст фактов (текста нет), но это обычный пустой ответ; конверт
    ``facts_not_from_ocr`` - про случай, когда текст в корпусе есть, а доверия ему нет."""
    if not path or not str(path).lower().endswith(".pdf") or not content_hash:
        return False
    return cache.load_result(str(content_hash)) is not None


def manifest_counts(layer: str | None = None) -> dict[str, Any] | None:
    """``{state: n, pages_pending: M}`` по записям манифестов ingest (поле ``ocr``).

    ``layer``: ``legacy`` | ``current`` | ``None`` (оба). Манифест не прочитался -> ``None``
    (не «ноль»: §9 п.22)."""
    from core.config import current_ingest_manifest_path, legacy_ingest_manifest_path
    from core.legacy.ingest import _load_manifest

    paths = {"legacy": [legacy_ingest_manifest_path()],
             "current": [current_ingest_manifest_path()]}.get(
        layer or "", [legacy_ingest_manifest_path(), current_ingest_manifest_path()])
    counts: dict[str, Any] = dict.fromkeys(STATES, 0)
    counts["pages_pending"] = 0
    try:
        for path in paths:
            for entry in _load_manifest(path).values():
                state = entry.get("ocr")
                if state in counts:
                    counts[state] += 1
                    if state == "pending":
                        counts["pages_pending"] += int(entry.get("pages") or 0)
    except Exception:  # noqa: BLE001 — манифест нечитаем: сводка честно «не знаем»
        return None
    return counts


def source_row(layer: str) -> dict[str, Any] | None:
    """``ocr: {pending, done, low, refused}`` для строки источника панели «Хранилище».

    ``refused`` = отказ по пути + приватный текст (оба - «текста нет по приватности»)."""
    counts = manifest_counts(layer)
    if counts is None:
        return None
    return {
        "pending": counts["pending"], "done": counts["done"], "low": counts["low"],
        "refused": counts["refused"] + counts["refused_text"],
    }


def _snapshot() -> dict[str, Any] | None:
    try:
        data = json.loads(queue_snapshot_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def summary() -> dict[str, Any]:
    """Сводка для доктора/пульта. Не падает: движок/манифест/снимок деградируют каждый сам."""
    from core.ocr.engine import OcrUnavailable, get_engine, ocr_langs

    out: dict[str, Any] = {"langs": ocr_langs()}
    try:
        eng = get_engine()
        out.update(engine=eng.name, engine_version=eng.version(), available=True)
    except OcrUnavailable as exc:
        out.update(engine=None, engine_version=None, available=False, reason=exc.reason,
                   code=exc.code)
    counts = manifest_counts()
    snap = _snapshot()
    out["notes"] = counts
    if snap is not None:
        out["queue"] = {"docs": int(snap.get("docs") or 0), "pages": int(snap.get("pages") or 0),
                        "at": snap.get("at"), "source": "snapshot"}
    elif counts is not None:
        out["queue"] = {"docs": counts["pending"], "pages": counts["pages_pending"], "at": None,
                        "source": "manifest"}
    else:
        out["queue"] = None
    out["week"] = cache.journal_summary(7)
    out["last_run"] = cache.read_last_run()  # NIGHT-CHAIN-1: итог последнего прогона шага
    # приватность: по снимку очереди (включает заглушки, еще не нарисованные) либо по манифестам
    refused_path = (int(snap.get("refused") or 0) if snap is not None
                    else (counts["refused"] if counts is not None else None))
    out["refused"] = {
        "path": refused_path,
        "text": counts["refused_text"] if counts is not None else None,
    }
    return out
