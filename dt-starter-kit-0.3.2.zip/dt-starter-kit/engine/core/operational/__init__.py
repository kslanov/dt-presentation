"""Operational contour (architecture §7) — pluggable per-instance connector.

This is the one place in ``core/`` allowed to make **network calls** (to the
operational system of record, e.g. Timetta). The invariant still holds:

* ``core/`` does not import ``mcp-server/`` or ``cli/``;
* there are **no network LLM calls** anywhere in ``core/`` — the only egress
  here is the read/write API of the operational connector, isolated under
  ``core/operational/``.

The provider-neutral contract lives in :mod:`core.operational.connector`; the
Timetta read-side implementation lives in :mod:`core.operational.timetta`.
"""
