"""GATEWAY-1 п.1 - шлюз моделей: контракт «класс задачи -> профиль модели» поверх слоя синтезов.

Слой синтезов (:mod:`core.operational.ai_layer`) делает пять видов синтеза. Раньше конфиг ``ai`` был
один на все виды: одна модель и для рекомендации лейна (1,5 КБ входа), и для синтеза хаба (80 КБ).
Этот модуль - ЧИСТЫЙ контракт без сети и без ключей (HTTP-адаптеры и файлы ключей остаются в
``ai_layer``; гард-тест Пути B проверяет, что провайдерских вызовов нет нигде, кроме них):

* **класс задачи** (``CLASSES``): ``triage`` (``brief``, ``lane``), ``synth`` (``hub_synth``,
  ``hub_lint``), ``draft`` (``draft``); таблица вид -> класс одна (``KIND_CLASS``), новый вид
  синтеза обязан объявить класс;
* **профиль** - именованный набор ``provider/url/model/key_file/timeout_s/max_chars/
  max_calls_per_hour`` (имена свободные: ``cheap``, ``strong``, ``local``);
* **маршрут** - класс -> имя профиля | ``host`` (синтез делает хост через askClaude) | ``none``.

Форма настроек - раздел ``ai`` файла ``vault/_system/pult.yaml``::

    ai:
      profiles:
        cheap:  {provider: openai, url: https://api.moonshot.ai/v1, model: ...,
                 key_file: pult_ai_key-cheap}
        strong: {provider: anthropic, model: ...}
        local:  {provider: openai, url: http://localhost:11434/v1, model: ...}
      routes: {triage: cheap, synth: strong, draft: host}

Плоская форма (``ai: {provider, url, model, ...}``, PULT-STANDALONE-1) читается как профиль
``default`` + все маршруты на него (миграция на чтении, ``legacy_flat: true``): файл на диске
остается как есть до ``dt ai migrate`` или первой записи настроек.
"""

from __future__ import annotations

import ipaddress
import os
import re
from copy import deepcopy
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

__all__ = [
    "CLASSES",
    "DEFAULT_PROFILE",
    "KIND_CLASS",
    "PROVIDERS",
    "Limits",
    "Profile",
    "Resolved",
    "Route",
    "SettingsError",
    "apply_patch",
    "class_kinds",
    "normalize",
    "overview",
    "resolve",
    "resolve_class",
]

CLASSES = ("triage", "synth", "draft")
KIND_CLASS: dict[str, str] = {
    "brief": "triage", "lane": "triage",
    "hub_synth": "synth", "hub_lint": "synth",
    "draft": "draft",
}
PROVIDERS = ("none", "host", "openai", "anthropic")
DEFAULT_PROFILE = "default"
ROUTE_HOST = "host"
ROUTE_NONE = "none"
RESERVED_NAMES = (ROUTE_HOST, ROUTE_NONE)  # имена маршрутов: профилем быть не могут
KEY_FILE_DEFAULT = "pult_ai_key"
ANTHROPIC_HOST_URL = "https://api.anthropic.com"  # пустой url у anthropic = внешний провайдер

DEFAULTS: dict[str, Any] = {
    "provider": "none", "url": "", "model": "", "key_file": KEY_FILE_DEFAULT,
    "timeout_s": 20, "max_chars": 2000, "max_calls_per_hour": None,
}
# Поля, которые принимает ИНСТРУМЕНТ настроек (``pult_settings_set``). ``key_file`` - только CLI:
# указатель на файл тоже путь к секрету, веб-токен не должен им управлять.
TOOL_FIELDS = ("provider", "url", "model", "timeout_s", "max_chars", "max_calls_per_hour")
PROFILE_FIELDS = (*TOOL_FIELDS, "key_file")
_SECRET_WORDS = re.compile(r"key|token|secret|password|authorization|bearer", re.IGNORECASE)
_KEY_FILE_RE = re.compile(r"^pult_ai_key[\w.-]{0,40}$")
_NAME_RE = re.compile(r"^[a-z][a-z0-9_-]{0,31}$")
_MAX_CALLS_ENV = "DT_AI_MAX_CALLS_PER_HOUR"
_DEFAULT_MAX_CALLS = 120


class SettingsError(ValueError):
    """Отказ валидации настроек: ``code`` машиночитаем (``key_not_here``, ``bad_url``...)."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


# --------------------------------------------------------------------------- #
# Контракт: профиль, маршрут, результат разрешения                              #
# --------------------------------------------------------------------------- #
def default_max_calls() -> int:
    """Дефолт профиля: ``DT_AI_MAX_CALLS_PER_HOUR`` (120), если у профиля свой потолок не задан."""
    try:
        return max(1, int(os.environ.get(_MAX_CALLS_ENV, "") or _DEFAULT_MAX_CALLS))
    except ValueError:
        return _DEFAULT_MAX_CALLS


def default_key_file(name: str) -> str:
    """Файл ключа профиля в ``.secrets/``: ``default`` - ``pult_ai_key``, прочие - с суффиксом."""
    return KEY_FILE_DEFAULT if name == DEFAULT_PROFILE else f"{KEY_FILE_DEFAULT}-{name}"


@dataclass(frozen=True)
class Limits:
    timeout_s: int
    max_chars: int
    max_calls_per_hour: int


@dataclass(frozen=True)
class Profile:
    """Профиль модели: провайдер + url + модель + файл ключа + лимиты."""

    name: str
    provider: str = "none"
    url: str = ""
    model: str = ""
    key_file: str = KEY_FILE_DEFAULT
    timeout_s: int = 20
    max_chars: int = 2000
    max_calls_per_hour: int | None = None

    @classmethod
    def from_dict(cls, name: str, raw: dict[str, Any]) -> Profile:
        return cls(name=name, **{k: raw[k] for k in PROFILE_FIELDS if k in raw})

    @property
    def calls_per_hour(self) -> int:
        return self.max_calls_per_hour or default_max_calls()

    @property
    def limits(self) -> Limits:
        return Limits(self.timeout_s, self.max_chars, self.calls_per_hour)


@dataclass(frozen=True)
class Route:
    """Куда идет класс: профиль (по имени), ``host`` или ``none``."""

    target: str

    @property
    def is_host(self) -> bool:
        return self.target == ROUTE_HOST

    @property
    def is_none(self) -> bool:
        return self.target == ROUTE_NONE

    @property
    def profile_name(self) -> str | None:
        return None if self.is_host or self.is_none else self.target


@dataclass(frozen=True)
class Resolved:
    """Результат :func:`resolve`: класс, маршрут, профиль и действующий провайдер.

    ``provider`` - действующий: ``none``/``host`` у маршрута ``none``/``host`` (и у профиля с таким
    провайдером - совместимость плоской формы), иначе провайдер профиля. ``side``: ``none`` (синтеза
    нет), ``host`` (делает хост), ``daemon`` (вызов делает демон)."""

    task_class: str
    route: str
    profile: str | None
    provider: str
    model: str
    url: str
    key_file: str
    limits: Limits
    kind: str | None = None

    @property
    def side(self) -> str:
        if self.provider == "host":
            return "host"
        return "daemon" if self.provider in ("openai", "anthropic") else "none"

    def public(self) -> dict[str, Any]:
        """``{class, route, profile}`` - что уходит в ответы, аудит и события метрик."""
        return {"class": self.task_class, "route": self.route, "profile": self.profile}


# --------------------------------------------------------------------------- #
# Валидация полей                                                               #
# --------------------------------------------------------------------------- #
def _is_local_http(host: str) -> bool:
    if host in ("localhost",) or host.endswith((".local", ".lan", ".localhost")):
        return True
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        return False
    return addr.is_loopback or addr.is_private


def url_is_local(url: str) -> bool:
    """URL - localhost или локальная сеть (данные не уходят наружу)."""
    host = urlparse(url or "").hostname
    return bool(host) and _is_local_http(str(host))


def validate_url(url: str, provider: str) -> str:
    """Нормализованный базовый URL или :class:`SettingsError`."""
    url = (url or "").strip()
    if not url:
        if provider == "openai":
            raise SettingsError("url_required", "для openai нужен url (например https://api.moonshot.ai/v1)")
        return ""
    parts = urlparse(url)
    if parts.scheme not in ("http", "https") or not parts.hostname:
        raise SettingsError("bad_url", "url должен быть http(s)://хост[/путь]")
    if parts.username or parts.password or parts.query or parts.fragment or len(url) > 300:
        raise SettingsError(
            "bad_url", "в url нельзя логин, пароль, query и фрагмент (ключ - только файлом)")
    if parts.scheme == "http" and not _is_local_http(parts.hostname):
        raise SettingsError("url_insecure", "http допустим только для localhost и локальной сети; "
                            "внешний провайдер - только https")
    return url.rstrip("/")


def validate_name(name: str) -> str:
    """Имя профиля: ``[a-z][a-z0-9_-]{0,31}``, не ``host``/``none`` (имена маршрутов)."""
    if not isinstance(name, str) or not _NAME_RE.match(name) or name in RESERVED_NAMES:
        raise SettingsError(
            "bad_profile_name",
            f"имя профиля {name!r}: [a-z][a-z0-9_-]{{0,31}}, не host/none")
    return name


def validate_fields(values: dict[str, Any], *, allow_key_file: bool = False) -> dict[str, Any]:
    """Проверить ЧАСТИЧНЫЙ набор полей профиля; вернуть нормализованные значения или отказ."""
    if not isinstance(values, dict):
        raise SettingsError("bad_values", "values - объект {поле: значение}")
    clean: dict[str, Any] = {}
    for name, value in values.items():
        if name == "key_file" and allow_key_file:
            pass
        elif name in TOOL_FIELDS:
            pass
        elif _SECRET_WORDS.search(str(name)):
            raise SettingsError(
                "key_not_here",
                "ключ провайдера через этот инструмент не принимается: `dt ai set-key` "
                "(файл в .secrets/, права 600)",
            )
        else:
            raise SettingsError("unknown_field", f"неизвестное поле {name!r}: допустимы "
                                f"{', '.join(TOOL_FIELDS)}")
        clean[name] = value
    if "provider" in clean and clean["provider"] not in PROVIDERS:
        raise SettingsError("bad_provider", f"provider: {', '.join(PROVIDERS)}")
    if "model" in clean:
        model = str(clean["model"] or "").strip()
        if len(model) > 120 or any(ch.isspace() for ch in model):
            raise SettingsError("bad_model", "model: до 120 знаков без пробелов")
        clean["model"] = model
    for name, lo, hi in (("timeout_s", 1, 120), ("max_chars", 200, 20000),
                         ("max_calls_per_hour", 1, 100000)):
        if name in clean:
            v = clean[name]
            if name == "max_calls_per_hour" and v is None:
                continue  # None - вернуть дефолт (DT_AI_MAX_CALLS_PER_HOUR)
            if isinstance(v, bool) or not isinstance(v, int) or not lo <= v <= hi:
                raise SettingsError(f"bad_{name}", f"{name}: целое {lo}..{hi}")
    if "key_file" in clean:
        name = str(clean["key_file"] or "").strip()
        if not _KEY_FILE_RE.match(name):
            raise SettingsError("bad_key_file",
                                "key_file: имя файла pult_ai_key* в .secrets/ (без путей)")
        clean["key_file"] = name
    if "url" in clean:
        clean["url"] = str(clean["url"] or "").strip()
    return clean


def key_file_ok(name: str) -> bool:
    return bool(_KEY_FILE_RE.match(name or ""))


# --------------------------------------------------------------------------- #
# Нормализация: плоская форма -> профили, мусор -> дефолты                       #
# --------------------------------------------------------------------------- #
def _coerce_profile(name: str, raw: Any) -> dict[str, Any]:
    src = raw if isinstance(raw, dict) else {}
    out = dict(DEFAULTS)
    out["key_file"] = default_key_file(name)
    for field in ("provider", "url", "model", "key_file"):
        if isinstance(src.get(field), str):
            out[field] = src[field].strip()
    for field in ("timeout_s", "max_chars", "max_calls_per_hour"):
        v = src.get(field)
        floor = 1 if field == "max_calls_per_hour" else None
        if isinstance(v, int) and not isinstance(v, bool) and (floor is None or v >= floor):
            out[field] = v
    if out["provider"] not in PROVIDERS:
        out["provider"] = "none"
    if not _KEY_FILE_RE.match(out["key_file"]):
        out["key_file"] = default_key_file(name)
    return out


def normalize(raw: Any) -> dict[str, Any]:
    """Раздел ``ai`` (любой формы) -> ``{profiles, routes, legacy_flat}`` с дефолтами.

    Плоская форма = профиль ``default`` + маршруты всех классов на него. Пустой/отсутствующий
    раздел - профиль ``default`` с провайдером ``none`` (``legacy_flat: false``: мигрировать
    нечего).
    Идемпотентна: уже нормализованный словарь возвращается тем же по смыслу."""
    src = raw if isinstance(raw, dict) else {}
    profiles_raw, routes_raw = src.get("profiles"), src.get("routes")
    if isinstance(profiles_raw, dict) or isinstance(routes_raw, dict):
        profiles = {str(n): _coerce_profile(str(n), p)
                    for n, p in (profiles_raw if isinstance(profiles_raw, dict) else {}).items()
                    if isinstance(n, str) and _NAME_RE.match(n) and n not in RESERVED_NAMES}
        fallback = DEFAULT_PROFILE if DEFAULT_PROFILE in profiles else ROUTE_NONE
        routes_src: dict[str, Any] = routes_raw if isinstance(routes_raw, dict) else {}
        routes = {c: (routes_src[c].strip() if isinstance(routes_src.get(c), str)
                      and routes_src[c].strip() else fallback) for c in CLASSES}
        # legacy_flat - признак чтения плоской формы: нормализованный словарь несет его дальше
        return {"profiles": profiles, "routes": routes,
                "legacy_flat": src.get("legacy_flat") is True}
    flat = _coerce_profile(DEFAULT_PROFILE, src)
    legacy = any(f in src for f in PROFILE_FIELDS)
    return {"profiles": {DEFAULT_PROFILE: flat},
            "routes": dict.fromkeys(CLASSES, DEFAULT_PROFILE), "legacy_flat": legacy}


def class_kinds() -> dict[str, list[str]]:
    """``{класс: [виды]}`` по таблице :data:`KIND_CLASS`."""
    out: dict[str, list[str]] = {c: [] for c in CLASSES}
    for kind, cls in KIND_CLASS.items():
        out[cls].append(kind)
    return out


# --------------------------------------------------------------------------- #
# Разрешение: вид/класс -> профиль и лимиты                                      #
# --------------------------------------------------------------------------- #
def resolve_class(task_class: str, settings: Any, *, kind: str | None = None) -> Resolved:
    """Класс -> :class:`Resolved` по маршруту. Отказы: ``unknown_class``, ``unknown_profile``."""
    if task_class not in CLASSES:
        raise SettingsError("unknown_class", f"класс {task_class!r}: {', '.join(CLASSES)}")
    cfg = normalize(settings)
    route = Route(cfg["routes"][task_class])
    base = DEFAULTS
    if route.is_none or route.is_host:
        return Resolved(task_class, route.target, None, route.target, "", "", KEY_FILE_DEFAULT,
                        Limits(base["timeout_s"], base["max_chars"], default_max_calls()), kind)
    prof_raw = cfg["profiles"].get(route.target)
    if prof_raw is None:
        raise SettingsError("unknown_profile",
                            f"маршрут {task_class} -> {route.target!r}: такого профиля нет")
    prof = Profile.from_dict(route.target, prof_raw)
    return Resolved(task_class, route.target, prof.name, prof.provider, prof.model, prof.url,
                    prof.key_file, prof.limits, kind)


def resolve(kind: str, settings: Any) -> Resolved:
    """Вид синтеза -> :class:`Resolved`. Отказы: ``bad_kind``, ``unknown_profile``."""
    if kind not in KIND_CLASS:
        raise SettingsError("bad_kind", f"вид {kind!r}: {', '.join(KIND_CLASS)}")
    return resolve_class(KIND_CLASS[kind], settings, kind=kind)


def sends_data_out(res: Resolved) -> bool:
    """Данные уходят за пределы машины/локальной сети: вызов делает демон и url не локальный."""
    if res.side != "daemon":
        return False
    if not res.url:
        return res.provider == "anthropic"  # пустой url у anthropic - api.anthropic.com
    return not url_is_local(res.url)


def overview(settings: Any) -> dict[str, Any]:
    """Витрина маршрутов БЕЗ ключей: профили, маршруты, классы, ``sides``, ``sends_data_out``.

    ``sides`` - кто синтезирует класс (``none|host|daemon``); маршрут на несуществующий профиль -
    ``none`` (синтеза нет) и ``route_errors``."""
    cfg = normalize(settings)
    profiles: dict[str, Any] = {}
    for name, raw in cfg["profiles"].items():
        prof = Profile.from_dict(name, raw)
        profiles[name] = {"provider": prof.provider, "url": prof.url, "model": prof.model,
                          "timeout_s": prof.timeout_s, "max_chars": prof.max_chars,
                          "max_calls_per_hour": prof.calls_per_hour,
                          "max_calls_explicit": prof.max_calls_per_hour is not None,
                          "key_file": prof.key_file,
                          "local": url_is_local(prof.url) if prof.url else False}
    sides: dict[str, str] = {}
    leaves: dict[str, bool] = {}
    errors: dict[str, str] = {}
    for cls in CLASSES:
        try:
            res = resolve_class(cls, cfg)
        except SettingsError as exc:
            sides[cls], leaves[cls], errors[cls] = "none", False, exc.code
            continue
        sides[cls], leaves[cls] = res.side, sends_data_out(res)
    return {"profiles": profiles, "routes": dict(cfg["routes"]), "classes": class_kinds(),
            "sides": sides, "sends_data_out": leaves, "route_errors": errors,
            "legacy_flat": cfg["legacy_flat"]}


# --------------------------------------------------------------------------- #
# Правка: частичный набор -> новая нормализованная настройка                     #
# --------------------------------------------------------------------------- #
def _flatten(values: dict[str, Any]) -> list[tuple[tuple[str, ...], Any]]:
    """``{"routes.triage": x, "profiles": {"cheap": {"model": y}}, "provider": z}`` -> пути."""
    out: list[tuple[tuple[str, ...], Any]] = []
    for key, value in values.items():
        key = str(key)
        if key in ("routes", "profiles") and isinstance(value, dict):
            for sub, subv in value.items():
                if key == "profiles" and isinstance(subv, dict):
                    out.extend(((key, str(sub), str(f)), fv) for f, fv in subv.items())
                else:
                    out.append(((key, str(sub)), subv))
        else:
            out.append((tuple(key.split(".")), value))
    return out


def _guard_secret(path: tuple[str, ...], allow_key_file: bool) -> None:
    leaf = path[-1]
    if leaf == "key_file" and allow_key_file:
        return
    if _SECRET_WORDS.search(leaf):
        raise SettingsError(
            "key_not_here",
            "ключ провайдера через этот инструмент не принимается: `dt ai set-key` "
            "(файл в .secrets/, права 600)")


def apply_patch(
    current: Any, values: dict[str, Any], *, allow_key_file: bool = False
) -> dict[str, Any]:
    """Применить правку к настройкам; вернуть НОВУЮ нормализованную настройку или отказ.

    Ключи ``values``: ``routes.<класс>`` (профиль | ``host`` | ``none``), ``profiles.<имя>.<поле>``,
    ``profiles.<имя>: null`` (удалить профиль; ``profile_in_use``, если на него есть маршрут),
    а также вложенные формы тех же ключей и ПЛОСКИЕ поля (``provider``, ``url``... - на профиль
    ``default``, совместимость с PULT-STANDALONE-1). Ключ/токен/секрет/``key_file`` - отказ
    ``key_not_here``. Профиль, которого нет, создается. Итоговая комбинация изменённых профилей
    проверяется целиком (``openai`` без модели/url - отказ). ``current`` не меняется."""
    if not isinstance(values, dict):
        raise SettingsError("bad_values", "values - объект {поле: значение}")
    cfg = deepcopy(normalize(current))
    cfg["legacy_flat"] = False
    profiles: dict[str, dict[str, Any]] = cfg["profiles"]
    routes: dict[str, str] = cfg["routes"]
    touched: set[str] = set()
    touched_routes: set[str] = set()
    deleted: set[str] = set()
    for path, value in _flatten(values):
        if len(path) == 1 or path[0] == "routes" or len(path) == 3:
            _guard_secret(path, allow_key_file)
        if len(path) == 1:  # плоское поле -> профиль default
            profile, field = DEFAULT_PROFILE, path[0]
            _set_field(profiles, profile, field, value, allow_key_file)
            touched.add(profile)
        elif path[0] == "routes" and len(path) == 2:
            if path[1] not in CLASSES:
                raise SettingsError("unknown_class", f"класс {path[1]!r}: {', '.join(CLASSES)}")
            if not isinstance(value, str) or not value.strip():
                raise SettingsError("bad_route", "маршрут: имя профиля, host или none")
            routes[path[1]] = value.strip()
            touched_routes.add(path[1])
        elif path[0] == "profiles" and len(path) == 2 and value is None:
            validate_name(path[1])
            if path[1] in profiles:
                del profiles[path[1]]
                deleted.add(path[1])
                touched.discard(path[1])
        elif path[0] == "profiles" and len(path) == 3:
            validate_name(path[1])
            _set_field(profiles, path[1], path[2], value, allow_key_file)
            touched.add(path[1])
            deleted.discard(path[1])
        else:
            raise SettingsError(
                "unknown_field", f"неизвестное поле {'.'.join(path)!r}: routes.<класс>, "
                "profiles.<имя>.<поле>, profiles.<имя>: null")
    for name in sorted(touched):
        prof = profiles[name]
        prof["url"] = validate_url(prof["url"], prof["provider"])
        if prof["provider"] in ("openai", "anthropic") and not prof["model"]:
            raise SettingsError("model_required", f"для {prof['provider']} нужна model "
                                f"(профиль {name})")
    for cls in sorted(touched_routes):
        if routes[cls] not in (ROUTE_HOST, ROUTE_NONE) and routes[cls] not in profiles:
            raise SettingsError("unknown_profile",
                                f"маршрут {cls} -> {routes[cls]!r}: такого профиля нет")
    for name in sorted(deleted):
        users = [c for c in CLASSES if routes.get(c) == name]
        if users:
            raise SettingsError("profile_in_use", f"профиль {name!r} в маршрутах: "
                                f"{', '.join(users)}; сначала смените маршрут")
    return cfg


def _set_field(profiles: dict[str, dict[str, Any]], name: str, field: str, value: Any,
               allow_key_file: bool) -> None:
    clean = validate_fields({field: value}, allow_key_file=allow_key_file)
    prof = profiles.setdefault(name, _coerce_profile(name, {}))
    prof.update(clean)
