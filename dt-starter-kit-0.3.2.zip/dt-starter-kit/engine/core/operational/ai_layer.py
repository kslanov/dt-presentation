"""PULT-STANDALONE-1 п.2 - настраиваемый слой ИИ-синтезов пульта (``pult_ai``).

База пульта - детерминированные сводки движка (:mod:`core.operational.brief`,
:mod:`core.operational.capture_lane`): она рисуется всегда. Этот слой стоит ПОВЕРХ нее и делает
пять видов синтеза с ФИКСИРОВАННЫМИ шаблонами промптов (никаких свободных вызовов модели -
Путь B: артефакты движок не пишет, модель пишет хост или провайдер, выбранный пользователем):

* ``brief`` - переформулировать детерминированный бриф (вход: ``brief`` + ``summary``; 2-3 фразы);
* ``lane`` - рекомендация лейна захвата (вход: ``text`` + ``suggested_lane``; ответ
  ``LANE|причина``);
* ``draft`` - черновик по промпту ``generate`` (вход: ``prompt``);
* ``hub_synth`` - HUB-SYNTH-1: секция «Состояние» хаба по досье (вход: ``prompt`` досье; ответ
  идет в :func:`core.operational.hub_synth.propose` теми же проверками, что у сессии);
* ``hub_lint`` - KNOWLEDGE-LINT-1: проход по хабу - утверждения нынешнего состояния, которые
  дельта опровергает (вход: ``prompt`` досье; ответ идет в :func:`core.lint.claims.run_ai`,
  находки правила ``claim``, только с локаторами из досье).

Настройка - раздел ``ai`` файла ``vault/_system/pult.yaml`` (GATEWAY-1: профили моделей и маршруты
«класс задачи -> профиль», контракт - :mod:`core.operational.ai_gateway`)::

    ai:
      profiles:
        cheap:  {provider: openai, url: https://api.moonshot.ai/v1, model: kimi-k2...,
                 key_file: pult_ai_key-cheap, timeout_s: 20, max_chars: 2000}
        strong: {provider: anthropic, model: ...}
      routes: {triage: cheap, synth: strong, draft: host}     # профиль | host | none

Плоская форма PULT-STANDALONE-1 (``ai: {provider, url, model, ...}``) читается как профиль
``default`` + маршруты всех классов на него; файл остается как есть до ``dt ai migrate`` или первой
записи настроек.

Семантика: ``none`` (дефолт) - база без синтезов; ``host`` - синтез делает хост через
``window.cowork.askClaude`` (движок не зовет никого); ``openai``/``anthropic`` - вызов делает ДЕМОН:
ключ профиля не покидает ``.secrets``, не едет в браузер и в артефакт, текст одинаков на всех
поверхностях. Данные уходят провайдеру только при маршруте на профиль ``openai|anthropic`` - это
решение пользователя, доктор его показывает.

Инварианты: ключ нигде не печатается, не логируется, не попадает в ответ, аудит и ``pult.yaml``
(видны только последние 4 символа); отказ провайдера/таймаут - ``{ok: false, code, text: null}``, а
не исключение; кэш на день по ``(kind, sha(payload), профиль, provider, model)``; аудит
``ai_synthesis`` без текста и без ключа. ``core`` ⊥ MCP/CLI: HTTP - только стандартная библиотека.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import shutil
import threading
import time
import urllib.error
import urllib.request
from collections import deque
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]  # стаб-гэп PyYAML - как в style_markers

from core import web_tokens
from core.config import derived_root, pult_settings_path
from core.operational import ai_gateway as gw
from core.operational.ai_gateway import (  # noqa: F401 - реэкспорт: слой синтезов - прежняя точка входа
    DEFAULT_PROFILE,
    DEFAULTS,
    KEY_FILE_DEFAULT,
    PROVIDERS,
    TOOL_FIELDS,
    SettingsError,
    validate_url,
)

__all__ = [
    "AI_KINDS",
    "PROVIDERS",
    "SettingsError",
    "KEY_FILE_DEFAULT",
    "get_settings",
    "key_status",
    "key_statuses",
    "last_call",
    "migrate",
    "save_settings",
    "set_key",
    "settings_view",
    "synthesize",
    "usage",
]

log = logging.getLogger(__name__)

AI_KINDS = ("brief", "lane", "draft", "hub_synth", "hub_lint")
ANTHROPIC_URL = gw.ANTHROPIC_HOST_URL
ANTHROPIC_VERSION = "2023-06-01"

# Предел размера выхода ответа: ``max_chars`` x множитель вида (черновик - документ, не фраза).
_OUT_FACTOR = {"brief": 1, "lane": 1, "draft": 10, "hub_synth": 3, "hub_lint": 3}
_IN_CAP = {"brief": 8000, "lane": 1500, "draft": 60000, "hub_synth": 80000, "hub_lint": 80000}

_LANE_ANSWER_RE = re.compile(
    r"\b(knowledge|assignment|task)\b\s*[|:\-]?\s*(.*)", re.IGNORECASE | re.DOTALL)
_TYPO = str.maketrans({"—": "-", "–": "-", "ё": "е", "Ё": "Е"})

SYSTEM_PROMPTS: dict[str, str] = {
    "brief": (
        "Ты - ассистент рабочего дашборда специалиста по продажам ИТ-решений. По данным дня "
        "переформулируй утренний бриф: 2-3 коротких предложения на русском, только самое важное - "
        "что горит и на что обратить внимание сегодня. Используй только факты и числа из данных, "
        "ничего не выдумывай. Без вступлений и списков, живым деловым тоном, без длинных тире и "
        "буквы ё."
    ),
    "lane": (
        "Классифицируй захват личной рабочей системы. Ответь СТРОГО в формате: LANE|причина "
        "(5-8 слов). LANE одно из: knowledge (знание/идея/заметка в базу), assignment (поручение "
        "администратору CRM: задача/пункт по рабочей сделке или проекту), task (личная бытовая "
        "задача-напоминание)."
    ),
    "draft": (
        "Ты пишешь черновик по промпту, который подготовил движок Digital Twin (контекст, стиль "
        "автора, образцы). Следуй промпту дословно, верни только текст черновика."
    ),
    "hub_synth": (
        "Ты собираешь секцию «Состояние» хаба клиента по досье, которое подготовил движок Digital "
        "Twin. Следуй промпту дословно: только факты из блока [Delta] и [Current state], у каждого "
        "пункта локатор в квадратных скобках из досье, отдельной строкой «Не покрыто: …». Верни "
        "только текст секции."
    ),
    "hub_lint": (
        "Ты проверяешь состояние хаба клиента по досье, которое подготовил движок Digital Twin. "
        "Следуй промпту дословно: назови утверждения блока [Current state], которые элементы "
        "[Delta] опровергают или делают устаревшими; у каждого локатор из [Delta] в квадратных "
        "скобках; ничего не выдумывай. Верни только список строк «- утверждение [локатор]» либо "
        "одну строку «Нет»."
    ),
}


# --------------------------------------------------------------------------- #
# Настройки: vault/_system/pult.yaml, раздел ai                                  #
# --------------------------------------------------------------------------- #
def settings_path() -> Path:
    """``vault/_system/pult.yaml`` (переопределение ``DT_PULT_SETTINGS_PATH`` - см. core.config)."""
    return pult_settings_path()


def cache_path() -> Path:
    """``.derived/pult/ai_cache.json`` - кэш синтезов на день (производные данные)."""
    return derived_root() / "pult" / "ai_cache.json"


def _secrets_dir() -> Path:
    return web_tokens.secrets_dir()


def _read_yaml() -> dict[str, Any]:
    try:
        data = yaml.safe_load(settings_path().read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return {}
    return data if isinstance(data, dict) else {}


def get_settings() -> dict[str, Any]:
    """Действующие настройки ``ai`` (без ключей): ``{profiles, routes, legacy_flat}``.

    Плоский раздел на диске мигрируется НА ЧТЕНИИ (профиль ``default`` + маршруты на него): файл не
    меняется до ``dt ai migrate`` или первой записи через :func:`save_settings`."""
    return gw.normalize(_read_yaml().get("ai"))


def _serialize(cfg: dict[str, Any]) -> dict[str, Any]:
    """Нормализованные настройки -> раздел ``ai`` файла (``max_calls_per_hour`` - если задан)."""
    profiles: dict[str, Any] = {}
    for name, prof in cfg["profiles"].items():
        row = {k: prof[k] for k in ("provider", "url", "model", "key_file", "timeout_s",
                                    "max_chars")}
        if prof.get("max_calls_per_hour") is not None:
            row["max_calls_per_hour"] = prof["max_calls_per_hour"]
        profiles[name] = row
    return {"profiles": profiles, "routes": dict(cfg["routes"])}


def _write_ai(doc: dict[str, Any], cfg: dict[str, Any], *, backup: bool) -> str | None:
    """Записать раздел ``ai`` (прочие разделы сохраняются); вернуть путь бэкапа или ``None``."""
    path = settings_path()
    saved: str | None = None
    if backup and path.is_file():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        bak = path.with_name(f"{path.name}.bak-{stamp}")
        n = 1
        while bak.exists():  # две миграции в одну секунду не затирают друг друга
            bak = path.with_name(f"{path.name}.bak-{stamp}-{n}")
            n += 1
        shutil.copy2(path, bak)
        saved = str(bak)
    doc["ai"] = _serialize(cfg)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(yaml.safe_dump(doc, allow_unicode=True, sort_keys=False), encoding="utf-8")
    os.replace(tmp, path)
    return saved


def save_settings(values: dict[str, Any], *, allow_key_file: bool = False) -> dict[str, Any]:
    """Записать частичный набор полей в ``pult.yaml`` (прочие разделы файла сохраняются).

    Ключи ``values``: ``routes.<класс>``, ``profiles.<имя>.<поле>``, ``profiles.<имя>: null`` и
    плоские поля (на профиль ``default``) - см. :func:`core.operational.ai_gateway.apply_patch`.
    Итоговая комбинация проверяется целиком. Плоский файл первой записью переписывается в форму
    профилей (бэкап ``pult.yaml.bak-<время>`` рядом). Возвращает действующие настройки. Ключ сюда не
    попадает никогда."""
    current = get_settings()
    new = gw.apply_patch(current, values, allow_key_file=allow_key_file)
    _write_ai(_read_yaml(), new, backup=bool(current["legacy_flat"]))
    return get_settings()


def migrate() -> dict[str, Any]:
    """``dt ai migrate``: плоский ``ai:`` -> профили и маршруты; ``{migrated, backup, settings}``.

    Нет раздела ``ai`` или он уже в форме профилей - ничего не пишется (``migrated: false``).
    Перед записью рядом кладется копия ``pult.yaml.bak-<время>``."""
    current = get_settings()
    if not current["legacy_flat"]:
        return {"migrated": False, "backup": None, "settings": current}
    backup = _write_ai(_read_yaml(), current, backup=True)
    return {"migrated": True, "backup": backup, "settings": get_settings()}


# --------------------------------------------------------------------------- #
# Ключ: только файл в .secrets/ (по профилю)                                     #
# --------------------------------------------------------------------------- #
def _profile_cfg(profile: str, settings: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = gw.normalize(settings) if settings is not None else get_settings()
    found = cfg["profiles"].get(profile)
    if found is None:
        if profile == DEFAULT_PROFILE:  # виртуальный профиль плоской/пустой настройки
            return {"key_file": gw.default_key_file(DEFAULT_PROFILE)}
        raise SettingsError("unknown_profile", f"профиля {profile!r} нет")
    return found


def _key_path(key_file: str) -> Path | None:
    if not gw.key_file_ok(str(key_file or "")):
        return None
    return _secrets_dir() / str(key_file)


def _read_key(key_file: str) -> str:
    path = _key_path(key_file)
    if path is None:
        return ""
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def _status_of(key_file: str) -> dict[str, Any]:
    path = _key_path(key_file)
    out: dict[str, Any] = {"configured": False, "tail": "", "file": key_file, "mode_ok": True}
    key = _read_key(key_file)
    if key and path is not None:
        out["configured"] = True
        out["tail"] = web_tokens.tail(key)
        try:
            out["mode_ok"] = (path.stat().st_mode & 0o077) == 0
        except OSError:
            out["mode_ok"] = False
    return out


def key_status(profile: str = DEFAULT_PROFILE, *, settings: dict[str, Any] | None = None
               ) -> dict[str, Any]:
    """``{configured, tail, file, mode_ok}``: статус ключа профиля БЕЗ ключа (хвост 4 символа)."""
    return _status_of(str(_profile_cfg(profile, settings)["key_file"]))


def key_statuses(settings: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    """Статус ключа каждого профиля: ``{имя: {configured, tail, file, mode_ok}}``."""
    cfg = gw.normalize(settings) if settings is not None else get_settings()
    return {name: _status_of(str(p["key_file"])) for name, p in cfg["profiles"].items()}


def set_key(value: str, *, profile: str = DEFAULT_PROFILE, key_file: str | None = None
            ) -> dict[str, Any]:
    """Положить ключ профиля в ``.secrets/<key_file>`` (0600, атомарно); вернуть статус без ключа.

    ``key_file`` - явное имя файла (иначе файл профиля из настроек)."""
    value = (value or "").strip()
    if not value or any(ch.isspace() for ch in value):
        raise SettingsError("bad_key", "ключ пуст или содержит пробелы")
    name = (key_file or str(_profile_cfg(profile)["key_file"])).strip()
    if not gw.key_file_ok(name):
        raise SettingsError("bad_key_file", "key_file: имя файла pult_ai_key* в .secrets/")
    web_tokens._write_secret(_secrets_dir() / name, value)  # писатель секретов веб-токенов
    return _status_of(name)


def settings_view(settings: dict[str, Any] | None = None) -> dict[str, Any]:
    """Настройки для ответов инструментов: :func:`ai_gateway.overview` + статус ключа по профилям.

    Ключ - ТОЛЬКО статус (``configured``, ``tail`` - 4 символа, ``file``, ``mode_ok``)."""
    cfg = gw.normalize(settings) if settings is not None else get_settings()
    view = gw.overview(cfg)
    statuses = key_statuses(cfg)
    for name, row in view["profiles"].items():
        row["key"] = statuses[name]
    return view


# --------------------------------------------------------------------------- #
# Кэш на день и локальный потолок вызовов (по профилю)                           #
# --------------------------------------------------------------------------- #
_LOCK = threading.Lock()
_CALLS: dict[str, deque[float]] = {}


def _day() -> str:
    return datetime.now().date().isoformat()


def _cache_key(kind: str, payload: dict[str, Any], profile: str, provider: str, model: str) -> str:
    blob = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    digest = hashlib.sha256(blob.encode("utf-8")).hexdigest()
    return hashlib.sha256(f"{kind}|{digest}|{profile}|{provider}|{model}".encode()).hexdigest()


def _cache_load() -> dict[str, str]:
    try:
        data = json.loads(cache_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict) or data.get("day") != _day():
        return {}
    entries = data.get("entries")
    if not isinstance(entries, dict):
        return {}
    return {k: v for k, v in entries.items() if isinstance(v, str)}


def _cache_store(entries: dict[str, str]) -> None:
    try:
        path = cache_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + ".tmp")
        tmp.write_text(json.dumps({"day": _day(), "entries": entries}, ensure_ascii=False),
                       encoding="utf-8")
        os.replace(tmp, path)
    except OSError:  # кэш - оптимизация, не обязанность
        pass


def _take_slot(profile: str, limit: int) -> bool:
    """Локальный потолок реальных вызовов профиля за час (деньги/лавина из read-ссылки)."""
    now = time.monotonic()
    with _LOCK:
        calls = _CALLS.setdefault(profile, deque())
        while calls and now - calls[0] > 3600:
            calls.popleft()
        if len(calls) >= limit:
            return False
        calls.append(now)
        return True


# --------------------------------------------------------------------------- #
# Шаблоны и провайдеры                                                           #
# --------------------------------------------------------------------------- #
def _clip(value: Any, limit: int) -> str:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
    return text[:limit]


def _build_user_message(kind: str, payload: dict[str, Any]) -> str | None:
    """Пользовательская часть промпта по виду; ``None`` - вход не годится для вида."""
    cap = _IN_CAP[kind]
    if kind == "brief":
        brief = payload.get("brief")
        text = brief.get("text") if isinstance(brief, dict) else brief
        if not isinstance(text, str) or not text.strip():
            return None
        summary = payload.get("summary")
        body = f"Детерминированный бриф:\n{text.strip()}"
        if summary:
            body += "\n\nДанные дня (JSON):\n" + _clip(summary, cap)
        return body[:cap]
    if kind == "lane":
        text = payload.get("text")
        if not isinstance(text, str) or not text.strip():
            return None
        hint = payload.get("suggested_lane")
        body = f"Текст захвата:\n{text.strip()[:cap]}"
        if isinstance(hint, str) and hint in ("knowledge", "assignment", "task"):
            body += f"\n\nПодсказка правил (может быть неверной): {hint}"
        return body
    prompt = payload.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        return None
    return prompt if len(prompt) <= cap else ""  # "" - слишком длинный: отказ, не усечение


class _ProviderFailure(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


def _post(
    url: str, headers: dict[str, str], body: dict[str, Any], timeout: float
) -> dict[str, Any]:
    """POST JSON; сбои -> :class:`_ProviderFailure` с кодом (тело ответа наружу не едет)."""
    req = urllib.request.Request(  # noqa: S310 - схема проверена validate_url (http/https)
        url, data=json.dumps(body).encode("utf-8"), method="POST",
        headers={"Content-Type": "application/json", **headers},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
            raw = resp.read(2_000_000)
    except urllib.error.HTTPError as exc:
        if exc.code == 429:
            raise _ProviderFailure("rate_limited") from None
        if exc.code in (401, 403):
            raise _ProviderFailure("auth") from None
        raise _ProviderFailure("provider_error" if exc.code >= 500 else "bad_request") from None
    except TimeoutError:
        raise _ProviderFailure("timeout") from None
    except urllib.error.URLError as exc:
        reason = getattr(exc, "reason", None)
        timed_out = isinstance(reason, TimeoutError)
        raise _ProviderFailure("timeout" if timed_out else "network") from None
    except OSError:
        raise _ProviderFailure("network") from None
    try:
        data = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise _ProviderFailure("bad_response") from None
    if not isinstance(data, dict):
        raise _ProviderFailure("bad_response")
    return data


def _call_openai(cfg: dict[str, Any], key: str, system: str, user: str, max_tokens: int) -> str:
    base = cfg["url"]
    url = base if base.endswith("/chat/completions") else f"{base}/chat/completions"
    data = _post(
        url, {"Authorization": f"Bearer {key}"},
        {"model": cfg["model"], "max_tokens": max_tokens,
         "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]},
        float(cfg["timeout_s"]),
    )
    try:
        text = data["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError):
        raise _ProviderFailure("bad_response") from None
    return text if isinstance(text, str) else ""


def _call_anthropic(cfg: dict[str, Any], key: str, system: str, user: str, max_tokens: int) -> str:
    base = cfg["url"] or ANTHROPIC_URL
    url = base if base.endswith("/v1/messages") else f"{base}/v1/messages"
    data = _post(
        url, {"x-api-key": key, "anthropic-version": ANTHROPIC_VERSION},
        {"model": cfg["model"], "max_tokens": max_tokens, "system": system,
         "messages": [{"role": "user", "content": user}]},
        float(cfg["timeout_s"]),
    )
    try:
        blocks = data["content"]
        text = "".join(b.get("text", "") for b in blocks if isinstance(b, dict))
    except (KeyError, TypeError):
        raise _ProviderFailure("bad_response") from None
    return text


def _finish(kind: str, text: str, out_cap: int) -> dict[str, Any] | None:
    """Привести ответ провайдера к виду; ``None`` - формат не тот (``bad_format``)."""
    text = (text or "").strip()
    if not text:
        return None
    if kind == "lane":
        m = _LANE_ANSWER_RE.search(text)
        if not m:
            return None
        lane = m.group(1).lower()
        reason = " ".join(m.group(2).translate(_TYPO).split())[:120]
        return {"text": f"{lane}|{reason}", "lane": lane, "reason": reason}
    if kind == "brief":
        text = text.translate(_TYPO)
    return {"text": text[:out_cap]}


def _audit_and_event(
    kind: str, res: gw.Resolved, ms: int, chars: int, ok: bool, code: str | None, cached: bool
) -> None:
    """Событие метрик (всегда) и аудит ``ai_synthesis`` (реальные вызовы): без текста и ключа.

    GATEWAY-1: и событие, и аудит несут ``class``, ``profile``, ``route``."""
    from core.metrics import record_event
    from core.operational.pult import record_action

    # ``kind`` занят видом события метрик - вид синтеза едет полем ``synth``
    where = {"class": res.task_class, "profile": res.profile or "-", "route": res.route}
    fields: dict[str, Any] = {"provider": res.provider, "model": res.model, "synth": kind,
                              "ms": ms, "chars": chars, "ok": ok, "cached": cached, **where}
    if code:
        fields["code"] = code
    record_event("ai_synthesis", **fields)
    if not cached:
        params: dict[str, Any] = {"provider": res.provider, "model": res.model or "-",
                                  "kind": kind, "ms": ms, "chars": chars, **where}
        if code:
            params["code"] = code
        record_action("ai_synthesis", params, "ok" if ok else "error")


def synthesize(
    kind: str,
    payload: dict[str, Any] | None,
    *,
    settings: dict[str, Any] | None = None,
    use_cache: bool = True,
) -> dict[str, Any]:
    """Один синтез ``kind``: ``{ok, kind, class, route, profile, text, provider, model, cached, ms,
    code?}``.

    GATEWAY-1: профиль и лимиты берутся по маршруту КЛАССА вида (:func:`ai_gateway.resolve`);
    провайдерские адаптеры те же. Никогда не бросает: отказ - ``{ok: false, code, text: null}``
    (``ai_disabled`` для маршрута ``none``/профиля ``none``, ``ai_host_side`` для ``host``,
    ``unknown_profile`` для маршрута на несуществующий профиль, ``bad_kind``, ``bad_payload``,
    ``payload_too_large``, ``no_key``, ``rate_limited_local`` и коды провайдера: ``rate_limited``,
    ``auth``, ``timeout``, ``network``, ``provider_error``, ``bad_request``, ``bad_response``,
    ``bad_format``). Сети нет при ``none``/``host``, при отказе валидации и при попадании в кэш.
    ``use_cache=False`` - не читать кэш (``dt ai test`` обязан дойти до провайдера), результат все
    равно кладется в кэш. ``settings`` - инжекция (плоская или новая форма).
    """
    cfg = gw.normalize(settings) if settings is not None else get_settings()
    base: dict[str, Any] = {"kind": kind, "class": gw.KIND_CLASS.get(kind), "route": None,
                            "profile": None, "provider": "none", "model": "", "cached": False,
                            "ms": 0}

    def refuse(code: str) -> dict[str, Any]:
        return {**base, "ok": False, "code": code, "text": None}

    if kind not in AI_KINDS:
        return refuse("bad_kind")
    try:
        res = gw.resolve(kind, cfg)
    except SettingsError as exc:
        return refuse(exc.code)
    base.update({**res.public(), "provider": res.provider, "model": res.model})
    provider = res.provider
    if provider == "none":
        return refuse("ai_disabled")
    if provider == "host":
        return refuse("ai_host_side")
    data = payload if isinstance(payload, dict) else {}
    user = _build_user_message(kind, data)
    if user is None:
        return refuse("bad_payload")
    if user == "":
        return refuse("payload_too_large")

    profile = str(res.profile)
    ckey = _cache_key(kind, data, profile, provider, res.model)
    with _LOCK:
        hit = _cache_load().get(ckey) if use_cache else None
    if hit is not None:
        _audit_and_event(kind, res, 0, len(hit), True, None, True)
        again = _finish(kind, hit, 10**6) or {"text": hit}
        return {**base, "ok": True, "cached": True, **again}

    key = _read_key(res.key_file)
    if not key:
        return refuse("no_key")
    if not _take_slot(profile, res.limits.max_calls_per_hour):
        _audit_and_event(kind, res, 0, 0, False, "rate_limited_local", False)
        return refuse("rate_limited_local")

    out_cap = res.limits.max_chars * _OUT_FACTOR[kind]
    max_tokens = max(256, out_cap // 2)
    adapter_cfg = {"url": res.url, "model": res.model, "timeout_s": res.limits.timeout_s}
    started = time.monotonic()
    code: str | None = None
    parsed: dict[str, Any] | None = None
    try:
        call = _call_openai if provider == "openai" else _call_anthropic
        raw = call(adapter_cfg, key, SYSTEM_PROMPTS[kind], user, max_tokens)
        parsed = _finish(kind, raw, out_cap)
        if parsed is None:
            code = "bad_format"
    except _ProviderFailure as exc:
        code = exc.code
    except Exception:  # noqa: BLE001 - слой подсказки не должен ронять пульт
        code = "provider_error"
    ms = round((time.monotonic() - started) * 1000)
    if parsed is None:
        _audit_and_event(kind, res, ms, 0, False, code, False)
        log.warning("ai_synthesis %s/%s/%s kind=%s отказ: %s", profile, provider, res.model, kind,
                    code)
        return {**refuse(code or "provider_error"), "ms": ms}
    with _LOCK:
        entries = _cache_load()
        entries[ckey] = parsed["text"]
        _cache_store(entries)
    _audit_and_event(kind, res, ms, len(parsed["text"]), True, None, False)
    return {**base, "ok": True, "ms": ms, **parsed}


# --------------------------------------------------------------------------- #
# Витрина: последний вызов (из аудита) и сводка за окно (из метрик)               #
# --------------------------------------------------------------------------- #
def last_call(days: int = 30, *, profile: str | None = None) -> dict[str, Any] | None:
    """Последний ``ai_synthesis`` из аудита: ``{at, ok, kind, class, profile, provider, model, ms,
    code?}``.

    ``profile`` - разрез: последний вызов именно этого профиля (записи до GATEWAY-1 - профиль
    ``default``)."""
    from core.operational.pult import read_actions

    since = datetime.now(UTC) - timedelta(days=days)
    rows = read_actions(tools=("ai_synthesis",), since=since)
    if profile is not None:
        rows = [r for r in rows if str(r.args.get("profile") or DEFAULT_PROFILE) == profile]
    if not rows:
        return None
    a = rows[-1]
    out: dict[str, Any] = {
        "at": a.at.strftime("%Y-%m-%dT%H:%M:%SZ"), "ok": a.outcome == "ok",
        "kind": a.args.get("kind"), "class": a.args.get("class"),
        "profile": a.args.get("profile") or DEFAULT_PROFILE,
        "provider": a.args.get("provider"), "model": a.args.get("model"), "ms": a.args.get("ms"),
    }
    if a.args.get("code"):
        out["code"] = a.args["code"]
    return out


def usage(days: int = 7, *, now: datetime | None = None, events: list[dict[str, Any]] | None = None
          ) -> dict[str, Any]:
    """``{days, calls, errors, cache_hits, by_profile}`` по событиям ``ai_synthesis`` за окно.

    ``calls`` - реальные вызовы провайдеру (без кэша), ``errors`` - из них неудачные,
    ``cache_hits`` - попадания в кэш дня; ``by_profile`` - то же в разрезе профиля (события до
    GATEWAY-1 без поля ``profile`` - профиль ``default``). ``events`` - инжекция для тестов.
    """
    from core.metrics import _parse_ts, read_events

    now_dt = now or datetime.now(UTC)
    since = now_dt - timedelta(days=days)
    rows = events if events is not None else read_events(since)
    calls = errors = hits = 0
    by_profile: dict[str, dict[str, int]] = {}
    for e in rows:
        if e.get("kind") != "ai_synthesis":
            continue
        ts = _parse_ts(e.get("ts"))
        if ts is not None and ts < since:
            continue
        row = by_profile.setdefault(str(e.get("profile") or DEFAULT_PROFILE),
                                    {"calls": 0, "errors": 0, "cache_hits": 0})
        if e.get("cached"):
            hits += 1
            row["cache_hits"] += 1
            continue
        calls += 1
        row["calls"] += 1
        if e.get("ok") is False:
            errors += 1
            row["errors"] += 1
    return {"days": days, "calls": calls, "errors": errors, "cache_hits": hits,
            "by_profile": by_profile}
