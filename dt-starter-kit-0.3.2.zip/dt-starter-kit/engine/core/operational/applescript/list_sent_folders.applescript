-- list_sent_folders — read-only diagnostic: enumerate every Sent-looking folder
-- across ALL accounts with its path and per-date-field counts.
-- argv: [] (none)
-- Output: JSON array of {name, path, total, by_time_sent, by_time_received}
--          (or {"error": …}).
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.
--
-- Purpose: `resolveFolder("Sent")` matched an EMPTY decoy folder named "Sent";
-- the real account sent folder is elsewhere (account-nested, possibly a
-- different name). This lists all candidates so we can target the right one and
-- see which date field actually populates it. Read-only.

on walkSentCandidates(folderList, prefix, cutoff, outArr, depth)
	if depth > 8 then return
	tell application "Microsoft Outlook"
		repeat with f in folderList
			set nm to ""
			try
				set nm to (name of f) as text
			end try
			set p to prefix & "/" & nm
			if my looksSent(nm) then
				set totalN to 0
				try
					set totalN to (count of messages of f)
				end try
				set sentN to 0
				try
					set sentN to (count of (messages of f whose time sent > cutoff))
				end try
				set recvN to 0
				try
					set recvN to (count of (messages of f whose time received > cutoff))
				end try
				set d to current application's NSMutableDictionary's dictionary()
				(d's setObject:nm forKey:"name")
				(d's setObject:p forKey:"path")
				(d's setObject:totalN forKey:"total")
				(d's setObject:sentN forKey:"by_time_sent")
				(d's setObject:recvN forKey:"by_time_received")
				(outArr's addObject:d)
			end if
			try
				set subs to mail folders of f
				if (count subs) > 0 then my walkSentCandidates(subs, p, cutoff, outArr, depth + 1)
			end try
		end repeat
	end tell
end walkSentCandidates

on run argv
	try
		with timeout of kDTTimeout seconds
		if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."
		set cutoff to (current date) - 30 * days
		set outArr to current application's NSMutableArray's array()
		tell application "Microsoft Outlook" to set topFolders to mail folders
		my walkSentCandidates(topFolders, "", cutoff, outArr, 0)
		my emitJSON(outArr)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run
