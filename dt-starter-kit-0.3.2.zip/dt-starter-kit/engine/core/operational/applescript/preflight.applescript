-- preflight — cheap, bounded reachability probe for Classic Outlook (JOB-1, R5).
-- argv: [] (none)
-- Output: JSON {"running": true, "scriptable": true, "accounts": N} on success,
--         or {"error": …} when Outlook is stopped or the non-scriptable New Outlook.
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.
--
-- The bridge runs this under a SHORT timeout (preflight_timeout) BEFORE any heavy
-- read, so a stopped / New Outlook fails fast (seconds) instead of stalling a
-- multi-minute meta/read call — the R5 «4-minute timeout» failure. It never opens
-- a folder or reads a message: it only asks whether Outlook is scriptable at all.

on run argv
	try
		with timeout of kDTTimeout seconds
			if not my isOutlookRunning() then
				error "Microsoft Outlook is not running — open Classic Outlook and retry."
			end if
			-- Scriptability probe: Classic Outlook answers `mail folders` (the
			-- very terminology every read depends on via resolveFolder); the New
			-- Outlook is not scriptable and errors here — surfaced as «switch to
			-- Classic». `count` is O(1) on the top-level collection (cheap).
			set folderCount to 0
			tell application "Microsoft Outlook"
				set folderCount to (count of mail folders)
			end tell
			set d to current application's NSMutableDictionary's dictionary()
			(d's setObject:true forKey:"running")
			(d's setObject:true forKey:"scriptable")
			(d's setObject:folderCount forKey:"folders")
			my emitJSON(d)
		end timeout
	on error errMsg
		my emitError("Outlook preflight failed: " & errMsg & " — Outlook may be the non-scriptable New Outlook (switch to Classic) or is not responding.")
	end try
end run
