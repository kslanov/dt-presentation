-- read_calendar — read-only pull of Outlook calendar events in a time window,
-- on the AppleScript engine. READ-ONLY: never mutates Outlook.
-- argv: [startISO, endISO]   (window = start ≥ startISO and < endISO)
-- Output: JSON array of event objects, or {"error": …}. Each event:
--   {entryID, subject, start, end, location, allDay, attendees[]}.
--   Concatenated after _lib.applescript by outlook_bridge.py.
--
-- Recurrence: Outlook for Mac stores a recurring SERIES as one master whose
-- `start time` is the FIRST occurrence and exposes NO occurrence expansion, so a
-- plain window filter misses future instances of old series. We therefore:
--   (A) pull NON-recurring events whose start time is in the window, and
--   (B) BULK-read every recurring master's rule (`recurrence` record) and EXPAND
--       weekly/daily rules into concrete occurrences inside the window.
--
-- Performance: everything is fetched with a handful of BULK gets (one `get` per
-- field over the whose-set, not per event). Heavy per-attendee reads happen ONLY
-- for masters that actually land an occurrence in the window. `body` is not read
-- (the feed never uses it). This keeps the whole call well under the MCP timeout.
--
-- MEET-FIX-2: каждое событие несёт ПАПКУ (`calendar`) и АККАУНТ (`account`). Outlook
-- перечисляет `calendar events` по ВСЕМ календарным папкам, включая смонтированные
-- PST-архивы (у К. это `backup_21-23 PST` на 978 событий и два `archive PST`) —
-- оттуда и приходили «фантомные» встречи. У архивных/локальных папок `account of
-- calendar` бросает ошибку, поэтому account = "" — по нему мост и отсекает архивы
-- (решение и env-ручки — на стороне Python, скрипт только отдаёт факты). Карта
-- календарей (id → имя+аккаунт) снимается ОДИН раз, а привязка события к папке —
-- одним bulk-get `id of calendar of (…)`: стоимость не зависит от числа событий.

on run argv
	try
		with timeout of kDTTimeout seconds
			set startISO to ""
			if (count argv) ≥ 1 then set startISO to (item 1 of argv) as text
			set endISO to ""
			if (count argv) ≥ 2 then set endISO to (item 2 of argv) as text
			if startISO is "" or endISO is "" then
				my emitError("read_calendar needs [startISO, endISO].")
				return
			end if
			if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."

			set d1 to my parseISO(startISO)
			set d2 to my parseISO(endISO)
			set winDays to ((d2 - d1) / days) as integer
			if winDays < 1 then set winDays to 1
			set outArr to current application's NSMutableArray's array()

			-- ============ (0) Карта календарей: id → имя + аккаунт ============
			-- Один проход по папкам (их единицы). Пустой account = локальная/PST-папка
			-- (`account of calendar` там бросает ошибку) — фильтрует Python-сторона.
			set cIds to {}
			set cNames to {}
			set cAccts to {}
			tell application "Microsoft Outlook"
				repeat with c in calendars
					set cid to -1
					try
						set cid to (id of c) as integer
					end try
					set cnm to ""
					try
						set cnm to (name of c) as text
					end try
					set cac to ""
					try
						set cac to (name of account of c) as text
					end try
					set end of cIds to cid
					set end of cNames to cnm
					set end of cAccts to cac
				end repeat
			end tell

			-- ============ (A) Non-recurring events in [d1, d2) ============
			set aStart to {}
			set aId to {}
			set aSubj to {}
			set aEnd to {}
			set aLoc to {}
			set aAllDay to {}
			set aAtt to {}
			set aCalId to {}
			tell application "Microsoft Outlook"
				try
					set aStart to start time of (calendar events whose start time is greater than or equal to d1 and start time is less than d2 and is recurring is false)
				end try
				try
					set aId to id of (calendar events whose start time is greater than or equal to d1 and start time is less than d2 and is recurring is false)
				end try
				try
					set aSubj to subject of (calendar events whose start time is greater than or equal to d1 and start time is less than d2 and is recurring is false)
				end try
				try
					set aEnd to end time of (calendar events whose start time is greater than or equal to d1 and start time is less than d2 and is recurring is false)
				end try
				try
					set aLoc to location of (calendar events whose start time is greater than or equal to d1 and start time is less than d2 and is recurring is false)
				end try
				try
					set aAllDay to all day flag of (calendar events whose start time is greater than or equal to d1 and start time is less than d2 and is recurring is false)
				end try
				try
					set aAtt to attendees of (calendar events whose start time is greater than or equal to d1 and start time is less than d2 and is recurring is false)
				end try
				try
					set aCalId to id of calendar of (calendar events whose start time is greater than or equal to d1 and start time is less than d2 and is recurring is false)
				end try
			end tell
			set nA to (count of aStart)
			-- Выровненность параллельных списков (ADAPTER-HONEST-1): без неё `nth(aSubj, i)`
			-- подставил бы тему/время/место СОСЕДНЕЙ встречи.
			my assertAligned("calendar:events", nA, {count of aId, count of aSubj}, {count of aEnd, count of aLoc, count of aAllDay, count of aAtt, count of aCalId})
			repeat with i from 1 to nA
				set theSubj to my nth(aSubj, i, "")
				if not my isCanceled(theSubj) then
					set attArr to current application's NSMutableArray's array()
					if i ≤ (count of aAtt) then set attArr to my formatAttendees(item i of aAtt)
					set isAllDay to false
					try
						set isAllDay to (my nth(aAllDay, i, false)) as boolean
					end try
					set calIdx to my idxOf(my nth(aCalId, i, -1), cIds)
					(outArr's addObject:(my eventDict(my nth(aId, i, ""), theSubj, my isoUTC(item i of aStart), my isoUTC(my nth(aEnd, i, item i of aStart)), my nth(aLoc, i, ""), isAllDay, attArr, my nth(cNames, calIdx, ""), my nth(cAccts, calIdx, ""))))
				end if
			end repeat

			-- ============ (B) Recurring masters → expand (bulk-read, pure loop) ============
			set mId to {}
			set mSubj to {}
			set mStart to {}
			set mCalId to {}
			-- Per-master recurrence scalars (extracted from the bulk-fetched records
			-- INSIDE the tell — pure record access, no per-event Outlook round-trips).
			set rTypes to {}
			set rInts to {}
			set rMon to {}
			set rTue to {}
			set rWed to {}
			set rThu to {}
			set rFri to {}
			set rSat to {}
			set rSun to {}
			set rSStart to {}
			set rHasEnd to {}
			set rEndD to {}
			tell application "Microsoft Outlook"
				try
					set mId to id of (calendar events whose is recurring is true)
				end try
				try
					set mSubj to subject of (calendar events whose is recurring is true)
				end try
				try
					set mStart to start time of (calendar events whose is recurring is true)
				end try
				try
					set mCalId to id of calendar of (calendar events whose is recurring is true)
				end try
				set recs to {}
				try
					set recs to recurrence of (calendar events whose is recurring is true)
				end try
				repeat with rec in recs
					set tt to ""
					try
						set tt to (recurrence type of rec) as string
					end try
					set end of rTypes to tt
					set iv to 1
					try
						set iv to (occurrence interval of rec) as integer
					end try
					set end of rInts to iv
					set wkMon to false
					set wkTue to false
					set wkWed to false
					set wkThu to false
					set wkFri to false
					set wkSat to false
					set wkSun to false
					try
						set dw to days of week of rec
						set wkMon to (monday of dw) as boolean
						set wkTue to (tuesday of dw) as boolean
						set wkWed to (wednesday of dw) as boolean
						set wkThu to (thursday of dw) as boolean
						set wkFri to (friday of dw) as boolean
						set wkSat to (saturday of dw) as boolean
						set wkSun to (sunday of dw) as boolean
					end try
					set end of rMon to wkMon
					set end of rTue to wkTue
					set end of rWed to wkWed
					set end of rThu to wkThu
					set end of rFri to wkFri
					set end of rSat to wkSat
					set end of rSun to wkSun
					set ss to missing value
					try
						set ss to (start date of rec)
					end try
					set end of rSStart to ss
					set he to false
					set edv to missing value
					try
						set ed to end date of rec
						if ((end type of ed) as string) contains "end date" then
							set he to true
							set edv to (data of ed)
						end if
					end try
					set end of rHasEnd to he
					set end of rEndD to edv
				end repeat
			end tell

			set nM to (count of mStart)
			my assertAligned("calendar:masters", nM, {count of mId, count of mSubj, count of rTypes}, {count of mCalId})
			repeat with i from 1 to nM
				set theSubj to my nth(mSubj, i, "")
				set rtype to my nth(rTypes, i, "")
				if (rtype is "weekly" or rtype is "daily") and not my isCanceled(theSubj) then
					set evStart to item i of mStart
					set sStart to my nth(rSStart, i, evStart)
					set hasEnd to my nth(rHasEnd, i, false)
					set endD to my nth(rEndD, i, missing value)
					set rint to my nth(rInts, i, 1)
					if rint < 1 then set rint to 1
					set dowList to {my nth(rMon, i, false), my nth(rTue, i, false), my nth(rWed, i, false), my nth(rThu, i, false), my nth(rFri, i, false), my nth(rSat, i, false), my nth(rSun, i, false)}
					set todSec to (evStart - (date (date string of evStart)))
					set sMid to sStart

					set occs to {}
					repeat with dayOffset from 0 to (winDays - 1)
						set D to d1 + dayOffset * days
						set dayDiff to ((D - sMid) / days) as integer
						if dayDiff ≥ 0 and (not hasEnd or D ≤ endD) then
							set emit to false
							if rtype is "weekly" then
								if my weekdayOnList(D, dowList) and (((dayDiff div 7) mod rint) is 0) then set emit to true
							else if rtype is "daily" then
								if (dayDiff mod rint) is 0 then set emit to true
							end if
							if emit then set end of occs to (D + todSec)
						end if
					end repeat

					if (count of occs) > 0 then
						-- Only NOW (this series lands in the window) read the heavy
						-- per-event fields, by resolving the master by id.
						set theID to my nth(mId, i, "")
						set locStr to ""
						set durSec to 3600
						set attRefs to {}
						try
							tell application "Microsoft Outlook"
								set em to calendar event id theID
								try
									set durSec to ((end time of em) - evStart)
								end try
								try
									set locStr to (location of em) as text
								end try
								try
									set attRefs to attendees of em
								end try
							end tell
						end try
						set attArr to my formatAttendees(attRefs)
						set mIdx to my idxOf(my nth(mCalId, i, -1), cIds)
						set mCalNm to my nth(cNames, mIdx, "")
						set mCalAc to my nth(cAccts, mIdx, "")
						repeat with occStart in occs
							set os to occStart as date
							(outArr's addObject:(my eventDict(theID, theSubj, my isoUTC(os), my isoUTC(os + durSec), locStr, false, attArr, mCalNm, mCalAc)))
						end repeat
					end if
				end if
			end repeat

			my emitJSON(outArr)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run

-- Safe list access: item i of lst, or dflt when i is out of range.
on nth(lst, i, dflt)
	if i ≥ 1 and i ≤ (count of lst) then return item i of lst
	return dflt
end nth

-- Subject looks like a cancelled meeting?
on isCanceled(s)
	set t to s as text
	if t starts with "Canceled:" then return true
	if t starts with "Отменено" then return true
	return false
end isCanceled

-- Build one event NSDictionary in the bridge's neutral shape (no body — unused).
-- MEET-FIX-2: + calendar/account (папка и аккаунт события; account = "" у локальных
-- и PST-архивов — по нему Python-сторона их отсекает).
on eventDict(theID, theSubj, startStr, endStr, locStr, isAllDay, attArr, calNm, calAc)
	set d to current application's NSMutableDictionary's dictionary()
	(d's setObject:(theID as text) forKey:"entryID")
	(d's setObject:(theSubj as text) forKey:"subject")
	(d's setObject:startStr forKey:"start")
	(d's setObject:endStr forKey:"end")
	(d's setObject:(locStr as text) forKey:"location")
	(d's setObject:isAllDay forKey:"allDay")
	(d's setObject:attArr forKey:"attendees")
	(d's setObject:(calNm as text) forKey:"calendar")
	(d's setObject:(calAc as text) forKey:"account")
	return d
end eventDict

-- Индекс значения в списке (1-based), 0 если нет: карта календарей мала (единицы
-- папок), поэтому линейный поиск дешевле любой структуры.
on idxOf(needle, lst)
	repeat with i from 1 to (count of lst)
		if (item i of lst) is needle then return i
	end repeat
	return 0
end idxOf

-- Does date D's weekday fall on a TRUE entry of a {mon,tue,…,sun} boolean list?
on weekdayOnList(D, L)
	set wd to weekday of D
	if wd is Monday then return item 1 of L
	if wd is Tuesday then return item 2 of L
	if wd is Wednesday then return item 3 of L
	if wd is Thursday then return item 4 of L
	if wd is Friday then return item 5 of L
	if wd is Saturday then return item 6 of L
	if wd is Sunday then return item 7 of L
	return false
end weekdayOnList

-- Attendees → NSArray of "Name <addr>" strings (best-effort; degrades to []).
-- App-aware terms MUST live inside a `tell application "Microsoft Outlook"` block.
on formatAttendees(attRefs)
	set parts to {}
	tell application "Microsoft Outlook"
		repeat with att in attRefs
			try
				set ea to email address of att
				set one to my formatOneAddr(name of ea, address of ea)
				if one is not "" then set end of parts to one
			end try
		end repeat
	end tell
	set arr to current application's NSMutableArray's array()
	repeat with p in parts
		(arr's addObject:(p as text))
	end repeat
	return arr
end formatAttendees
