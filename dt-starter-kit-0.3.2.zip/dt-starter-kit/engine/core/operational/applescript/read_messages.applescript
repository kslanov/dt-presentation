-- read_messages — read-only pull of one Outlook folder's messages, on the
-- AppleScript engine (NOT JXA: only AppleScript pushes `whose <date>` into
-- Outlook as an indexed query instead of scanning the whole 15k-message folder).
-- argv: [folderName, sinceISO|"", limit]
-- Output: JSON array of message objects, newest first (or {"error": …}).
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.
--
-- Strategy — TWO-PHASE INLINE BULK (принцип 11):
--   The first ingest has no cursor, so the window is a whole year → thousands of
--   matches. Fetching every body over that window (then limiting the output) is
--   what timed out. So we split:
--     PHASE 1 (cheap): one `get` of just the DATE list over the window. Sort it
--       in code and find the date of the limit-th-newest message = the cutoff.
--     PHASE 2 (heavy, BOUNDED): bulk-`get` the real fields only over the narrow
--       `whose <date> ≥ cutoff` set (~limit messages), so bodies/recipients are
--       fetched for at most ~limit messages, never the whole year.
--   Each `get` is one indexed Apple Event over the whose EXPRESSION itself — we
--   avoid the lazy reference form (re-scans → hang), storing the set then bulk
--   reading its id (throws on a list), and per-message id loops (round-trips).

on run argv
	try
		with timeout of kDTTimeout seconds
		set folderName to (item 1 of argv) as text
		set sinceISO to ""
		if (count argv) ≥ 2 then set sinceISO to (item 2 of argv) as text
		set lim to 500
		if (count argv) ≥ 3 then
			try
				set lim to (item 3 of argv) as integer
			end try
		end if
		if lim ≤ 0 then set lim to 500
		set wantSent to my isSentFolderName(folderName)
		set hasSince to (sinceISO is not "")

		if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."

		set theFolder to my resolveFolder(folderName)
		if theFolder is missing value then
			my emitError("Outlook folder not found: " & folderName)
			return
		end if
		-- Window start: the cursor date, or ~a century back when unbounded.
		if hasSince then
			set threshDate to my parseISO(sinceISO)
		else
			set threshDate to (current date) - 36500 * days
		end if

		-- PHASE 1 — one cheap get of just the dates over the window.
		set dateAll to {}
		tell application "Microsoft Outlook"
			tell theFolder
				if wantSent then
					set dateAll to time sent of (messages whose time sent > threshDate)
				else
					set dateAll to time received of (messages whose time received > threshDate)
				end if
			end tell
		end tell
		set nAll to (count of dateAll)
		if nAll is 0 then
			my emitJSON(current application's NSMutableArray's array())
			return
		end if

		-- Cutoff = the date of the limit-th-newest message (or the oldest, when the
		-- window already has ≤ limit). Everything ≥ cutoff is the survivor set.
		set ref0 to (current date)
		set keysAll to {}
		repeat with i from 1 to nAll
			try
				set end of keysAll to ((item i of dateAll) - ref0)
			on error
				set end of keysAll to -1.0E+12
			end try
		end repeat
		set orderAll to my sortIndicesByKeyDesc(keysAll)
		set mm to lim
		if mm > nAll then set mm to nAll
		set cutoffIdx to (item mm of orderAll)
		set cutoffDate to ref0 + ((item cutoffIdx of keysAll) as integer)

		-- PHASE 2 — heavy fields, BOUNDED to the ~limit newest via `≥ cutoffDate`.
		-- Each field is one inline get over the whose expression (parallel lists).
		set idList to {}
		set subjList to {}
		set bodyList to {}
		set dateList to {}
		set senderRefs to {}
		set toRefsList to {}
		set ccRefsList to {}
		set attRefsList to {}
		tell application "Microsoft Outlook"
			tell theFolder
				if wantSent then
					set idList to id of (messages whose time sent ≥ cutoffDate)
					set subjList to subject of (messages whose time sent ≥ cutoffDate)
					set bodyList to plain text content of (messages whose time sent ≥ cutoffDate)
					set dateList to time sent of (messages whose time sent ≥ cutoffDate)
					try
						set senderRefs to sender of (messages whose time sent ≥ cutoffDate)
					end try
					try
						set toRefsList to to recipients of (messages whose time sent ≥ cutoffDate)
					end try
					try
						set ccRefsList to cc recipients of (messages whose time sent ≥ cutoffDate)
					end try
					try
						set attRefsList to attachments of (messages whose time sent ≥ cutoffDate)
					end try
				else
					set idList to id of (messages whose time received ≥ cutoffDate)
					set subjList to subject of (messages whose time received ≥ cutoffDate)
					set bodyList to plain text content of (messages whose time received ≥ cutoffDate)
					set dateList to time received of (messages whose time received ≥ cutoffDate)
					try
						set senderRefs to sender of (messages whose time received ≥ cutoffDate)
					end try
					try
						set toRefsList to to recipients of (messages whose time received ≥ cutoffDate)
					end try
					try
						set ccRefsList to cc recipients of (messages whose time received ≥ cutoffDate)
					end try
					try
						set attRefsList to attachments of (messages whose time received ≥ cutoffDate)
					end try
				end if
			end tell
		end tell

		set n to (count of idList)
		if n is 0 then
			my emitJSON(current application's NSMutableArray's array())
			return
		end if

		-- Выровненность параллельных списков (ADAPTER-HONEST-1): `i ≤ nSender` ниже иначе
		-- приписал бы письму отправителя/получателей СОСЕДНЕГО письма.
		my assertAligned("messages", n, {count of subjList, count of bodyList, count of dateList}, {count of senderRefs, count of toRefsList, count of ccRefsList, count of attRefsList})

		-- Sort the (already-narrow) phase-2 set newest-first and cap to `limit`.
		set keys to {}
		repeat with i from 1 to n
			try
				set end of keys to ((item i of dateList) - ref0)
			on error
				set end of keys to -1.0E+12
			end try
		end repeat
		set order to my topIndicesByKeyDesc(keys, lim)

		set nSender to (count of senderRefs)
		set nTo to (count of toRefsList)
		set nCc to (count of ccRefsList)
		set nAtt to (count of attRefsList)

		set outArr to current application's NSMutableArray's array()
		repeat with idxRef in order
			set i to idxRef as integer

			set theID to (item i of idList) as text
			set theSubj to ""
			try
				set theSubj to (item i of subjList) as text
			end try
			set theBody to ""
			try
				set theBody to (item i of bodyList) as text
			end try
			set theDate to my isoUTC(item i of dateList)

			set fromStr to ""
			if i ≤ nSender then set fromStr to my formatSenderRef(item i of senderRefs)
			set toStr to ""
			if i ≤ nTo then set toStr to my formatRecipRefs(item i of toRefsList)
			set ccStr to ""
			if i ≤ nCc then set ccStr to my formatRecipRefs(item i of ccRefsList)
			if i ≤ nAtt then
				set attArr to my attNamesNSFromRefs(item i of attRefsList)
			else
				set attArr to current application's NSMutableArray's array()
			end if

			set d to current application's NSMutableDictionary's dictionary()
			(d's setObject:theID forKey:"entryID")
			(d's setObject:theSubj forKey:"subject")
			(d's setObject:fromStr forKey:"from")
			(d's setObject:toStr forKey:"to")
			(d's setObject:ccStr forKey:"cc")
			(d's setObject:theDate forKey:"date")
			(d's setObject:theBody forKey:"body")
			(d's setObject:folderName forKey:"folder")
			(d's setObject:"" forKey:"conversationId")
			(d's setObject:attArr forKey:"attachments")
			(outArr's addObject:d)
		end repeat

		my emitJSON(outArr)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run
