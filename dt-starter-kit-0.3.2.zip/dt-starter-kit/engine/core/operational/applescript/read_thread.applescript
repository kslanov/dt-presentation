-- read_thread — read-only fetch of one message (and its conversation, when
-- Outlook exposes one) by entryID, on the AppleScript engine.
-- argv: [entryID]
-- Output: JSON array of message objects (or {"error": …}). Best-effort: with no
-- conversation grouping we return the single matched message.
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.
--
-- Low-volume path (one id → one thread), so fields are read per message rather
-- than bulk-collected. Lookups use `whose id = …` (indexed), never a full scan.

-- Locate the message with `id = idNum`, returning {msg, folderName} or missing.
on findById(folderList, idNum, depth)
	if depth > 8 then return missing value
	tell application "Microsoft Outlook"
		repeat with f in folderList
			try
				set hits to (messages of f whose id = idNum)
				if (count hits) > 0 then return {msg:(item 1 of hits), folderName:(name of f)}
			end try
			try
				set subs to mail folders of f
				if (count subs) > 0 then
					set r to my findById(subs, idNum, depth + 1)
					if r is not missing value then return r
				end if
			end try
		end repeat
	end tell
	return missing value
end findById

-- Fetch scalars for one message inline, then delegate to the shared builder.
on dictForMessage(m, folderName)
	tell application "Microsoft Outlook"
		set theID to ""
		try
			set theID to id of m
		end try
		set theSubj to ""
		try
			set theSubj to subject of m
		end try
		set theWhen to missing value
		try
			set theWhen to time received of m
		end try
		if theWhen is missing value then
			try
				set theWhen to time sent of m
			end try
		end if
	end tell
	return my messageToDict(m, theID, theSubj, theWhen, folderName)
end dictForMessage

-- Gather every message in `convId`'s conversation across the folder tree.
on collectConversation(folderList, convId, outArr, depth)
	if depth > 8 then return
	tell application "Microsoft Outlook"
		repeat with f in folderList
			set fname to (name of f)
			try
				set hits to (messages of f whose conversation id is convId)
				repeat with hm in hits
					(outArr's addObject:(my dictForMessage(hm, fname)))
				end repeat
			end try
			try
				set subs to mail folders of f
				if (count subs) > 0 then my collectConversation(subs, convId, outArr, depth + 1)
			end try
		end repeat
	end tell
end collectConversation

on run argv
	try
		with timeout of kDTTimeout seconds
		set entryId to ""
		if (count argv) ≥ 1 then set entryId to (item 1 of argv) as text
		set idNum to missing value
		try
			set idNum to entryId as integer
		end try
		if idNum is missing value then
			my emitError("Invalid message id: " & entryId)
			return
		end if

		if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."

		set hit to missing value
		tell application "Microsoft Outlook"
			try
				set hits to (messages of inbox whose id = idNum)
				if (count hits) > 0 then set hit to {msg:(item 1 of hits), folderName:(name of inbox)}
			end try
		end tell
		if hit is missing value then
			tell application "Microsoft Outlook" to set topFolders to mail folders
			set hit to my findById(topFolders, idNum, 0)
		end if
		if hit is missing value then
			my emitError("Message not found: " & entryId)
			return
		end if

		set hitMsg to msg of hit
		set hitFolder to folderName of hit

		-- Try a conversation grouping; fall back to the single message.
		set convId to ""
		tell application "Microsoft Outlook"
			try
				set convId to (conversation id of hitMsg) as text
			end try
		end tell

		set outArr to current application's NSMutableArray's array()
		if convId is not "" then
			tell application "Microsoft Outlook" to set topFolders to mail folders
			my collectConversation(topFolders, convId, outArr, 0)
		end if
		if (outArr's |count|()) is 0 then
			(outArr's addObject:(my dictForMessage(hitMsg, hitFolder)))
		end if

		my emitJSON(outArr)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run
