"""RETIRE-WRITE-1 п.4 — карточка «Поручение администратору CRM» (лейн ``#поручение``).

Решение К. 2026-10-19: контур записи в Timetta выведен из эксплуатации — CRM организационно
ведёт администратор. Принцип 5 («человек — последняя инстанция») не меняется, меняется адресат
записи: захват с тегом ``поручение`` (``тиметта`` принимается переходно) становится **черновиком
поручения**, который К. отправляет администратору САМ.

Движок собирает черновик детерминированно (без LLM, без сети; Path B):

* **сделка** — из орбиты зеркала (кольца 1–2: ``mine``, ``unit``) по совпадению кода/названия/
  клиента с текстом захвата; однозначного совпадения нет → ``needs_deal`` и список кандидатов;
* **текст** захвата (без провенанс-футера) и **предлагаемая формулировка** пункта чек-листа;
* **срок** — если он есть в тексте (``2026-11-03`` / ``03.11.2026`` / ``до 03.11``);
* **письмо** — ``mailto:`` на ``DT_CRM_ADMIN_EMAIL`` с темой и телом. Движок письмо НЕ
  отправляет: К. нажимает «открыть письмо» и отправляет из почтового клиента сам.

Действия карточки: «скопировать» и «открыть письмо» — на стороне пульта (данные уже в карточке);
**«отправлено»** → терминальный статус захвата ``routed_assignment`` (+ архив inbox-заметки, не
удаление), **«отклонить»** → ``dropped``. Reconcile (RECONCILE-1/2) работает как у остальных
захватов: задача закрыта в TickTick → ``resolved_external`` и карточка уходит сама.

``core`` ⊥ mcp/cli; здесь нет ни сети, ни LLM, ни записи во внешние системы.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

from core.operational import orbit
from core.operational.ticktick.capture import (
    _TERMINAL_STATUSES,
    ASSIGNMENT_LANES,
    STATUS_ASSIGNMENT_SENT,
    STATUS_UNTRIAGED,
    _archive_inbox_note,
    _inbox_notes,
    _load_state,
    _save_state,
)

__all__ = [
    "ASSIGNMENT_RINGS",
    "DECISIONS",
    "build_draft",
    "build_mailto",
    "decide_assignment",
    "extract_due",
    "list_assignments",
    "orbit_deals",
    "rank_deals",
    "strip_footer",
    "suggest_title",
]

# Кольца 1–2 (как раньше классификация захвата в Timetta-интент): свои сделки и «моя дочка».
ASSIGNMENT_RINGS: tuple[str, ...] = (orbit.RING_MINE, orbit.RING_UNIT)

DECISIONS = ("sent", "reject")

_TOP_CANDIDATES = 5
_TEXT_CAP = 800        # символов текста захвата в карточке
_BODY_CAP = 1500       # символов тела письма (mailto-ссылка должна оставаться короткой)
_TITLE_CAP = 120
# Очки: код сделки в тексте решает сразу; клиент и слова названия — по числу совпавших слов.
_SCORE_CODE, _SCORE_ORG, _SCORE_NAME = 10, 3, 2
_MIN_SCORE = 3

_FOOTER_RE = re.compile(r"\n---\nисточник: ticktick\n", re.IGNORECASE)
_LANE_RE = re.compile(r"^lane:\s*(.+?)\s*$", re.IGNORECASE | re.MULTILINE)
_WORD_RE = re.compile(r"[a-zа-яё0-9]+", re.IGNORECASE)
_STOP = frozenset({
    "сделка", "сделки", "сделку", "проект", "проекта", "проекту", "компания", "компании",
    "для", "при", "над", "под", "что", "как", "это", "или", "нужно", "надо", "прошу",
    "тоо", "ооо", "оао", "зао", "llc", "ltd", "inc", "group", "группа",
})


# --------------------------------------------------------------------------- #
# Разбор захвата                                                                 #
# --------------------------------------------------------------------------- #
def strip_footer(text: str) -> tuple[str, str | None]:
    """``(текст без провенанс-футера, тег лейна)`` из inbox-заметки захвата."""
    match = _FOOTER_RE.search(text)
    if match is None:
        return text.strip(), None
    footer = text[match.start():]
    lane = _LANE_RE.search(footer)
    return text[: match.start()].strip(), (lane.group(1) if lane else None)


def suggest_title(text: str) -> str:
    """Формулировка пункта: первая содержательная строка захвата (без маркеров/тегов)."""
    for raw in text.splitlines():
        line = re.sub(r"^(?:[\s>*\-•#✓☐☑]+|\[[ xX]?\])+", "", raw).strip()
        line = re.sub(r"(?:\s+#[\w-]+)+\s*$", "", line).strip()
        if line:
            return line[:_TITLE_CAP].rstrip()
    return ""


def extract_due(text: str, *, today: date | None = None) -> str | None:
    """Срок из текста (ISO ``YYYY-MM-DD``) или ``None``.

    Понимает ``2026-11-03``, ``03.11.2026``, ``03.11.26`` и ``до 03.11`` (год — ближайший
    будущий). Невозможная дата (``31.02``) — не срок. Движок срок не угадывает: нет даты в
    тексте — нет и срока."""
    now = today or datetime.now(UTC).date()
    for m in re.finditer(r"\b(\d{4})-(\d{2})-(\d{2})\b", text):
        found = _safe_date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        if found:
            return found.isoformat()
    for m in re.finditer(r"\b(\d{1,2})\.(\d{1,2})\.(\d{4}|\d{2})\b", text):
        year = int(m.group(3))
        year += 2000 if year < 100 else 0
        found = _safe_date(year, int(m.group(2)), int(m.group(1)))
        if found:
            return found.isoformat()
    for m in re.finditer(r"\bдо\s+(\d{1,2})\.(\d{1,2})\b(?!\.\d)", text, re.IGNORECASE):
        found = _safe_date(now.year, int(m.group(2)), int(m.group(1)))
        if found and found < now:
            found = _safe_date(now.year + 1, int(m.group(2)), int(m.group(1)))
        if found:
            return found.isoformat()
    return None


def _safe_date(year: int, month: int, day: int) -> date | None:
    try:
        return date(year, month, day)
    except ValueError:
        return None


# --------------------------------------------------------------------------- #
# Сделки орбиты                                                                  #
# --------------------------------------------------------------------------- #
def orbit_deals(store: Any, rings: Any = None) -> list[dict[str, Any]]:
    """Активные сделки колец 1–2 из зеркала: ``{guid, code, name, organization, ring, leader}``.

    Единственная точка чтения — :func:`core.operational.orbit.visible` (удалённые сверкой
    скрыты, кольца пересекаются с ``DT_ORBIT_RINGS``). Нет сети; суммы/вероятность — не отдаём."""
    rows = orbit.visible(store.all("deals"), rings if rings is not None else ASSIGNMENT_RINGS)
    out = []
    for d in rows:
        if not d.get("id") or d.get("is_active") is False:
            continue
        out.append({
            "guid": str(d["id"]),
            "code": d.get("code"),
            "name": d.get("name"),
            "organization": d.get("organization_name"),
            "ring": orbit.ring(d),
            "leader": d.get("manager_name") if orbit.ring(d) != orbit.RING_MINE else None,
        })
    out.sort(key=lambda r: (str(r["code"] or ""), str(r["name"] or "")))
    return out


def _stems(value: str | None) -> list[str]:
    """Значимые основы слов (≥4 симв., без стоп-слов; окончание срезано для морфологии)."""
    out = []
    for word in _WORD_RE.findall((value or "").lower()):
        if len(word) < 4 or word in _STOP or word.isdigit():
            continue
        out.append(word[: max(4, len(word) - 2)])
    return out


def _code_digits(code: str | None) -> str | None:
    m = re.search(r"(\d+)\s*$", str(code or ""))
    return str(int(m.group(1))) if m else None


def _hits(value: str | None, words: list[str]) -> int:
    """Сколько значимых слов ``value`` встретилось в тексте (по основе — морфология)."""
    return sum(1 for stem in set(_stems(value)) if any(w.startswith(stem) for w in words))


def rank_deals(text: str, deals: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Сделки орбиты по убыванию совпадения с текстом; несовпавшие (счёт 0) отброшены.

    Счёт: код сделки (``DEAL-12`` в любом написании) — 10; слово клиента — 3; слово названия — 2.
    Детерминированно и объяснимо (``score`` и ``why`` — в выдаче); морфология — срез окончания."""
    lowered = text.lower()
    words = _WORD_RE.findall(lowered)
    ranked = []
    for deal in deals:
        score, why = 0, []
        digits = _code_digits(deal.get("code"))
        if digits and re.search(rf"\bdeal[-\s_]*0*{digits}\b", lowered):
            score += _SCORE_CODE
            why.append("код")
        org = _hits(deal.get("organization"), words)
        name = _hits(deal.get("name"), words)
        if org:
            score += _SCORE_ORG * org
            why.append("клиент")
        if name:
            score += _SCORE_NAME * name
            why.append("название")
        if score:
            ranked.append({**deal, "score": score, "why": why})
    ranked.sort(key=lambda r: (-r["score"], str(r.get("code") or "")))
    return ranked


def _pick(ranked: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Предлагаемая сделка: лидер со счётом ≥ порога и строго выше второго, иначе ``None``."""
    if not ranked or ranked[0]["score"] < _MIN_SCORE:
        return None
    if len(ranked) > 1 and ranked[1]["score"] >= ranked[0]["score"]:
        return None
    return ranked[0]


# --------------------------------------------------------------------------- #
# Черновик и письмо                                                              #
# --------------------------------------------------------------------------- #
def build_mailto(email: str | None, subject: str, body: str) -> str:
    """``mailto:`` с темой и телом. Адресата нет → ``mailto:?…`` (К. впишет сам).

    Процентное кодирование, переводы строк — CRLF (так их ждут почтовые клиенты)."""
    to = quote((email or "").strip(), safe="@+._-")
    crlf = body.replace("\n", "\r\n")
    return f"mailto:{to}?subject={quote(subject, safe='')}&body={quote(crlf, safe='')}"


def _deal_label(deal: dict[str, Any]) -> str:
    code = f"{deal['code']} " if deal.get("code") else ""
    return f"{code}«{deal.get('name') or deal['guid']}»".strip()


def build_draft(
    text: str,
    deal: dict[str, Any] | None,
    *,
    due: str | None,
    admin_email: str | None,
    title: str | None = None,
) -> dict[str, Any]:
    """Формулировка, тема, тело и ``mailto`` для выбранной (или ещё не выбранной) сделки."""
    item = title if title is not None else suggest_title(text)
    where = f"в сделку {_deal_label(deal)}" if deal else "в нужную сделку CRM"
    formulation = f"Прошу добавить {where} пункт чек-листа: «{item}»"
    if due:
        formulation += f" (срок {_ru_date(due)})"
    formulation += "."
    subject = f"Поручение по сделке {_deal_label(deal)}" if deal else "Поручение по CRM"
    lines = ["Здравствуйте!", "", formulation, ""]
    if deal:
        org = f", клиент {deal['organization']}" if deal.get("organization") else ""
        lines += [f"Сделка: {_deal_label(deal)}{org}"]
    if due:
        lines += [f"Срок: {_ru_date(due)}"]
    context = text.strip()
    if context and context != item:
        lines += ["", "Контекст:", context[:_TEXT_CAP]]
    body = "\n".join(lines)[:_BODY_CAP].rstrip()
    return {
        "formulation": formulation,
        "subject": subject,
        "body": body,
        "mailto": build_mailto(admin_email, subject, body),
    }


def _ru_date(iso: str) -> str:
    y, m, d = iso.split("-")
    return f"{d}.{m}.{y}"


# --------------------------------------------------------------------------- #
# Карточки                                                                       #
# --------------------------------------------------------------------------- #
@dataclass
class _Item:
    capture_id: str
    entry: dict[str, Any]
    note: Path


def _live_items(state_path: Path, inbox_dir: Path) -> list[_Item]:
    """Захваты лейна поручения, ещё не закрытые, с живой inbox-заметкой (она держит карточку)."""
    items = []
    for task_id, entry in _load_state(Path(state_path)).items():
        if not isinstance(entry, dict) or entry.get("lane") not in ASSIGNMENT_LANES:
            continue
        status = entry.get("status")
        if status == STATUS_UNTRIAGED or status in _TERMINAL_STATUSES:
            continue
        notes = _inbox_notes(Path(inbox_dir), task_id)
        if notes:
            items.append(_Item(task_id, entry, notes[0]))
    items.sort(key=lambda i: (str(i.entry.get("pulled_at") or ""), i.capture_id))
    return items


def _card(
    item: _Item,
    deals: list[dict[str, Any]],
    admin_email: str | None,
    *,
    deal_guid: str | None,
    today: date | None,
) -> dict[str, Any]:
    raw = item.note.read_text(encoding="utf-8", errors="replace")
    text, lane_tag = strip_footer(raw)
    ranked = rank_deals(text, deals)
    chosen: dict[str, Any] | None
    if deal_guid:
        chosen = next((d for d in deals if d["guid"].lower() == deal_guid.strip().lower()), None)
        suggested = False
    else:
        chosen = _pick(ranked)
        suggested = chosen is not None
    due = extract_due(text, today=today)
    draft = build_draft(text, chosen, due=due, admin_email=admin_email)
    card: dict[str, Any] = {
        "capture_id": item.capture_id,
        "title": suggest_title(text),
        "text": text[:_TEXT_CAP],
        "captured": item.entry.get("pulled_at"),
        "lane_tag": lane_tag,
        "deal": (
            {k: chosen.get(k) for k in ("guid", "code", "name", "organization", "ring", "leader")}
            if chosen else None
        ),
        "deal_suggested": suggested,
        "needs_deal": chosen is None,
        "candidates": [
            {k: r.get(k) for k in ("guid", "code", "name", "organization", "ring", "score", "why")}
            for r in ranked[:_TOP_CANDIDATES]
        ],
        "due": due,
        "admin_email": admin_email,
        **draft,
    }
    return card


def list_assignments(
    *,
    state_path: Path,
    inbox_dir: Path,
    deals: list[dict[str, Any]],
    admin_email: str | None,
    capture_id: str | None = None,
    deal_guid: str | None = None,
    today: date | None = None,
) -> dict[str, Any]:
    """Карточки поручений: ``{cards, deals, admin_email}``.

    ``capture_id`` (+ ``deal_guid``) — пересобрать черновик ОДНОЙ карточки под выбранную сделку
    (пульт зовёт при смене сделки в карточке). ``deals`` — орбита колец 1–2 для выбора сделки.
    Только чтение: ни манифест, ни inbox не меняются."""
    items = _live_items(state_path, inbox_dir)
    if capture_id is not None:
        items = [i for i in items if i.capture_id == capture_id]
    cards = [
        _card(i, deals, admin_email, deal_guid=deal_guid if capture_id else None, today=today)
        for i in items
    ]
    return {"cards": cards, "deals": deals, "admin_email": admin_email}


# --------------------------------------------------------------------------- #
# Решение                                                                        #
# --------------------------------------------------------------------------- #
def decide_assignment(
    capture_id: str,
    decision: str,
    *,
    deal_guid: str | None = None,
    state_path: Path,
    inbox_dir: Path,
    now: str | None = None,
) -> dict[str, Any]:
    """«отправлено» (``sent``) → ``routed_assignment``; «отклонить» (``reject``) → ``dropped``.

    Оба решения терминальны: pull такую запись не воскрешает (даже при изменённом
    ``modified``), inbox-заметка уходит в ``_staging/inbox/_done`` (архив, не удаление).
    Идемпотентно: уже закрытый захват → ``stale`` без повторной записи. Тег в TickTick не
    правится. Аудит — только id, решение и «была ли сделка» (без текста поручения)."""
    from core.operational.pult import record_action

    if decision not in DECISIONS:
        raise ValueError(f"unsupported decision {decision!r}; use {' | '.join(DECISIONS)}")
    audit: dict[str, Any] = {
        "capture_id": capture_id, "decision": decision, "deal": "yes" if deal_guid else "no",
    }
    state_path = Path(state_path)
    state = _load_state(state_path)
    entry = state.get(capture_id)
    if not isinstance(entry, dict) or entry.get("lane") not in ASSIGNMENT_LANES:
        record_action("pult_assignment_decide", audit, "not_found", now=now)
        raise ValueError(f"Поручение {capture_id!r} не найдено в манифесте захвата.")
    status = entry.get("status")
    if status == STATUS_UNTRIAGED or status in _TERMINAL_STATUSES:
        record_action("pult_assignment_decide", audit, "stale", now=now)
        return {
            "outcome": "stale", "capture_id": capture_id, "decision": decision,
            "explanation": f"Поручение уже закрыто ({status}) — повторное решение не требуется.",
        }

    at = now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    if decision == "sent":
        entry["status"] = STATUS_ASSIGNMENT_SENT
        entry["sent_at"] = at
        if deal_guid:
            entry["deal_guid"] = deal_guid.strip()
        outcome = "sent"
    else:
        entry["status"] = "dropped"
        entry["rejected_at"] = at
        outcome = "rejected"
    state[capture_id] = entry
    _save_state(state_path, state)
    archived = _archive_inbox_note(Path(inbox_dir), capture_id)
    record_action("pult_assignment_decide", audit, outcome, now=now)
    return {
        "outcome": outcome, "capture_id": capture_id, "decision": decision,
        "status": entry["status"], "archived": str(archived) if archived else None,
    }
