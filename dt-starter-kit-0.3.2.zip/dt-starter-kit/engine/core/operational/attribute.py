"""RETR-LINK — атрибуция заметки к клиент-хабу (системная коррекция ретривала).

Политика ``client_correspondence`` фильтрует знаниевые слайсы по frontmatter-полю
``client`` (vault.py нормализует ``[[client-x]]`` → ``client-x``; индекс матчит по
нему). Если нужная заметка не подтягивается — её надо привязать к клиенту: этот
модуль ПРОСТАВЛЯЕТ ``client: "[[<hub>]]"`` во frontmatter заметки, после чего
инкрементальный reindex делает её видимой слайсу ``client_context``.

Правка ХИРУРГИЧЕСКАЯ: меняется/добавляется только строка ``client:`` внутри
YAML-блока, остальной frontmatter и тело — байт-в-байт (round-trip через YAML-
либу переписал бы форматирование и потерял бы ``[[…]]``-форму). Идемпотентно.
Containment-guard: путь обязан лежать внутри vault. Reindex — отдельным шагом
(вызывающая сторона), чтобы прогресс был виден в пульте.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from core.config import default_vault_path
from core.vault import (
    FrontmatterError,
    RawYaml,
    resolve_note_path,
    set_frontmatter_fields_text,
)

__all__ = ["attribute_note_client", "AttributionError"]


class AttributionError(RuntimeError):
    """Не удалось привязать заметку (нет файла/frontmatter, путь вне vault)."""


def _canon_client(client_id: str) -> str:
    """Голый id хаба: ``[[client-x]]`` / ``client-x`` → ``client-x``."""
    s = str(client_id or "").strip()
    m = re.search(r"\[\[([^\]|]+)", s)
    if m:
        s = m.group(1)
    return s.strip()


def attribute_note_client(
    path: str, client_id: str, *, vault_path: Path | None = None
) -> dict[str, Any]:
    """Проставить ``client: "[[<client_id>]]"`` во frontmatter заметки по ссылке ``path``.

    Возвращает ``{path, note_id, client, changed, previous}``. ``changed=False``,
    если поле уже равно нужному хабу. Бросает :class:`AttributionError` при
    отсутствии заметки/frontmatter или выходе за пределы vault.

    **CONTRACT-1 ФП-1 (Д4).** Ссылка резолвится единой точкой
    :func:`core.vault.resolve_note_path` — путь (vault-относительный ИЛИ абсолютный),
    frontmatter ``id``, имя файла, ``source_path``. Раньше здесь стоял
    ``Path(path).resolve()``, то есть относительный путь резолвился **от CWD процесса**:
    строка ``03-projects/x.md``, которую отдаёт эхом сам ``read_note``, отбивалась как
    «путь вне vault» (round-trip рвался на ровном месте). Containment не ослаблен:
    резолвер возвращает только пути внутри vault.
    """
    vault = (vault_path or default_vault_path()).resolve()
    p = resolve_note_path(path, vault_path=vault)
    if p is None:
        raw = Path(str(path)).expanduser()
        if raw.is_absolute() and not str(raw.resolve()).startswith(str(vault)):
            raise AttributionError(f"путь вне vault: {raw}")
        raise AttributionError(f"заметка не найдена: {path}")

    client = _canon_client(client_id)
    if not client:
        raise AttributionError("пустой client_id")

    with p.open(encoding="utf-8", newline="") as fh:
        text = fh.read()
    try:
        new_text, prev, _ = set_frontmatter_fields_text(
            text, {"client": RawYaml(f'"[[{client}]]"')}, insert_missing=True
        )
    except FrontmatterError as exc:
        raise AttributionError("во frontmatter нет YAML-блока — заметку не трогаю") from exc
    previous = prev["client"]
    if previous and _canon_client(previous) == client:  # то же значение, иная запись - не трогаем
        return {
            "path": str(p), "note_id": _note_id(text, p), "client": client,
            "changed": False, "previous": previous,
        }
    changed = new_text != text
    if changed:
        with p.open("w", encoding="utf-8", newline="") as fh:
            fh.write(new_text)
    return {
        "path": str(p), "note_id": _note_id(new_text, p),
        "client": client, "changed": changed, "previous": previous,
    }


def _note_id(text: str, path: Path) -> str:
    """``id:`` из frontmatter (блок до второго ``---``), иначе имя файла."""
    for ln in text.splitlines()[1:]:
        if ln.rstrip() == "---":
            break
        if ln.startswith("id:"):
            return ln[len("id:"):].strip().strip('"').strip("'")
    return path.stem
