"""PULT-STANDALONE-1 п.1 — детерминированный утренний бриф из ленты ``work_feed``.

База, которая рисуется ВСЕГДА и на обеих поверхностях пульта (артефакт, веб-пульт), без модели и
без сети: 2-4 предложения по фиксированным правилам. ИИ-синтез (``core.operational.ai_layer``)
может переформулировать этот текст, но не заменяет его: нет провайдера, отказ, таймаут - остается
база.

Правила текста:

* (а) счетчики ленты (``counts``): сделки, пресейлы, просроченные и недельные задачи, письма;
* (б) главное внимание - до трех пунктов ``attention`` по приоритету ``просрочено > срок
  сегодня/завтра > письмо без ответа > остальное`` (название сделки и дни);
* (в) дельты: что изменилось за окно ``deltas`` и строка коллег ORBIT-3 («изменили N сделок, из
  них моих M»);
* (г) нет ни счетчиков, ни внимания, ни дельт - честное «событий нет».

Текст проходит канон ИИ-маркеров (``vault/_system/style-guides/ai-markers.yaml``): типографика из
данных (длинное тире, ``ё``) нормализуется здесь же, чтобы название сделки из Timetta не сделало
бриф «ИИшным». Чистая функция: ``core`` ⊥ MCP/CLI, ни сети, ни LLM, ни диска.
"""

from __future__ import annotations

from typing import Any

__all__ = ["MAX_CHIPS", "build_brief"]

MAX_CHIPS = 3          # пунктов «главного» (и чипов под текстом)
_TITLE_CAP = 48        # символов названия в предложении

_OVERDUE_TYPES = frozenset({"checklist_overdue", "issue_overdue", "hub_deadline_overdue"})
_SOON_TYPES = frozenset({"checklist_due_soon", "hub_deadline_soon"})
_MAIL_TYPE = "mail_unanswered"

_TYPO = str.maketrans({"—": "-", "–": "-", "ё": "е", "Ё": "Е"})


def _clean(value: Any) -> str:
    """Строка из данных без типографики, запрещенной каноном (длинное тире, ``ё``)."""
    return " ".join(str(value or "").translate(_TYPO).split())


def _cut(value: Any, limit: int = _TITLE_CAP) -> str:
    text = _clean(value)
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def _plural(n: int, one: str, few: str, many: str) -> str:
    n = abs(int(n))
    if n % 10 == 1 and n % 100 != 11:
        return one
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return few
    return many


def _days(n: Any) -> str:
    k = round(float(n or 0))
    return f"{k} {_plural(k, 'день', 'дня', 'дней')}"


def _int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _chip_title(item: dict[str, Any]) -> str:
    """Подпись чипа: код/название сделки, иначе название пункта (как делал пульт до брифа)."""
    deal = item.get("deal") if isinstance(item.get("deal"), dict) else None
    project = item.get("project") if isinstance(item.get("project"), dict) else None
    ref = deal or project
    named = (ref.get("code") or ref.get("name")) if ref else None
    return _cut(named or item.get("title"), 30)


def _where(item: dict[str, Any]) -> str:
    """Где пункт: «(сделка)» или «(проект)»; нет ни того ни другого - пусто."""
    for key in ("deal", "project"):
        ref = item.get(key)
        if isinstance(ref, dict):
            name = ref.get("name") or ref.get("code")
            if name:
                return f" ({_cut(name, 32)})"
    return ""


def _rank(item: dict[str, Any]) -> tuple[int, float]:
    """Приоритет пункта: меньше - важнее. Внутри класса - по сроку/давности."""
    kind = str(item.get("type") or "")
    if kind in _OVERDUE_TYPES:
        return (0, -float(item.get("days_overdue") or 0))
    if kind in _SOON_TYPES and float(item.get("days_until") or 0) <= 1:
        return (1, float(item.get("days_until") or 0))
    if kind == _MAIL_TYPE:
        return (2, -float(item.get("silent_days") or 0))
    if kind in _SOON_TYPES:
        return (3, float(item.get("days_until") or 0))
    return (4, 0.0)


def _phrase(item: dict[str, Any]) -> str:
    kind = str(item.get("type") or "")
    title = _cut(item.get("title"))
    if kind in _OVERDUE_TYPES:
        return f"{title}{_where(item)}, просрочено на {_days(item.get('days_overdue'))}"
    if kind in _SOON_TYPES:
        until = round(float(item.get("days_until") or 0))
        when = "срок сегодня" if until <= 0 else "срок завтра" if until == 1 else \
            f"срок через {_days(until)}"
        return f"{title}{_where(item)}, {when}"
    if kind == _MAIL_TYPE:
        return f"письмо «{title}» без ответа {_days(item.get('silent_days'))}"
    if kind == "orphan_note":
        return f"заметка «{title}» без привязки"
    return title


def _counts_sentence(c: dict[str, Any]) -> str:
    n = {k: _int(c.get(k)) for k in (
        "deals_active", "presales", "tasks_overdue", "tasks_due_week", "unanswered_mail")}
    return (
        f"Активных сделок {n['deals_active']}, из них пресейлов {n['presales']}; "
        f"просрочено задач {n['tasks_overdue']}, на неделю {n['tasks_due_week']}; "
        f"писем без ответа {n['unanswered_mail']}."
    )


def _deltas_sentence(deltas: list[dict[str, Any]]) -> str:
    kinds = {"deal": 0, "project": 0, "issue": 0, "mail": 0}
    for d in deltas:
        if isinstance(d, dict) and str(d.get("type")) in kinds:
            kinds[str(d["type"])] += 1
    forms = {
        "deal": ("сделка", "сделки", "сделок"),
        "project": ("проект", "проекта", "проектов"),
        "mail": ("новое письмо", "новых письма", "новых писем"),
    }
    parts = []
    for kind in ("deal", "project", "issue", "mail"):
        n = kinds[kind]
        if n:
            parts.append(f"{n} {_plural(n, *forms[kind])}" if kind in forms else f"{n} issue")
    return ("Изменилось за последние дни: " + ", ".join(parts) + ".") if parts else ""


def _colleagues_sentence(col: Any) -> str:
    if not isinstance(col, dict) or not _int(col.get("entries")):
        return ""
    n, mine, days = _int(col.get("changed_deals")), _int(col.get("mine")), _int(col.get("days"))
    return (
        f"Коллеги изменили {n} {_plural(n, 'сделку', 'сделки', 'сделок')} за {_days(days)}, "
        f"из них моих {mine}."
    )


def build_brief(feed: dict[str, Any]) -> dict[str, Any]:
    """``{text, items: [{kind, title, ref}], as_of}`` по ленте ``work_feed`` (без модели).

    ``items`` - те же пункты, что названы в тексте «главным» (до :data:`MAX_CHIPS`), они же чипы
    под текстом брифа в пульте: ``kind`` - тип пункта ленты, ``title`` - подпись чипа, ``ref`` -
    id пункта ленты (для открытия досье). Пустая лента - ``text`` «Событий нет...», ``items: []``.
    """
    counts: dict[str, Any] = feed["counts"] if isinstance(feed.get("counts"), dict) else {}
    attention = [a for a in (feed.get("attention") or []) if isinstance(a, dict)]
    deltas = [d for d in (feed.get("deltas") or []) if isinstance(d, dict)]
    ranked = sorted(attention, key=_rank)[:MAX_CHIPS]
    items = [
        {"kind": str(a.get("type") or ""), "title": _chip_title(a), "ref": a.get("id")}
        for a in ranked
    ]
    colleagues = _colleagues_sentence(feed.get("colleagues"))
    deltas_s = _deltas_sentence(deltas)
    has_counts = any(_int(v) for v in counts.values())

    sentences: list[str] = []
    if not (has_counts or ranked or deltas_s or colleagues):
        sentences.append("Событий нет: активных сделок, срочных пунктов и новых писем не найдено.")
    else:
        if has_counts:
            sentences.append(_counts_sentence(counts))
        if ranked:
            sentences.append("Главное: " + "; ".join(_phrase(a) for a in ranked) + ".")
        else:
            sentences.append("Срочного нет.")
        if deltas_s:
            sentences.append(deltas_s)
        if colleagues:
            sentences.append(colleagues)
    return {
        "text": " ".join(sentences),
        "items": items,
        "as_of": feed.get("now"),
    }
