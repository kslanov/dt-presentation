"""PULT-STANDALONE-1 п.1 — детерминированная подсказка лейна для untriaged-захвата.

До этого рекомендацию ``LANE|причина`` давала только модель хоста (``askClaude``): без Desktop
захваты оставались без подсказки, а ``pult_route(capture_id, lane)`` ждал лейн от человека. Здесь
правила по признакам текста, без модели и сети:

* ``assignment`` - **глагол поручения** (подготовить, отправить, согласовать, поручить...) в строке
  действия + **адресат** (``@имя``, роль, имя после «у/для/от/с/поручить…») или **срок** (дата из
  текста). Лейн и срок - те же, что у карточки «Поручение администратору CRM»
  (:mod:`core.operational.assignment`): срок читает :func:`assignment.extract_due`, имя лейна -
  :data:`capture.LANE_ASSIGNMENT` (один источник правды, не вторая копия);
* ``task`` - действие свое без адресата (напомнить, проверить, купить, обсудить...; любая строка,
  что начинается с инфинитива) либо дата/время без клиента;
* ``knowledge`` - заметка: список из трех и более пунктов, длинный текст, вопрос или идея, при этом
  строки действия нет;
* признаков нет - ``None`` (кнопка лейна не подсвечивается: молчание честнее выдумки).

``reason`` - 5-8 слов с названием признака. Действие ищется только в НАЧАЛЕ строки (или после
«нужно/надо/прошу»): глагол в середине заметки («датчики будут, проходят сертификацию») лейна не
задает. Чистые функции: ``core`` ⊥ MCP/CLI, ни сети, ни LLM, ни диска.
"""

from __future__ import annotations

import re
from datetime import date
from typing import Any

from core.operational.assignment import extract_due, strip_footer
from core.operational.ticktick.capture import (
    LANE_ASSIGNMENT,
    LANE_KNOWLEDGE,
    TAG_ASSIGNMENT,
    TAG_TIMETTA,
)

__all__ = [
    "LANE_TASK",
    "annotate",
    "suggest_lane",
]

LANE_TASK = "task"

# Инфинитивы поручения: действие, которое обычно делает ДРУГОЙ (адресат/срок решает лейн).
_DELEGATE = frozenset({
    "поручить", "попросить", "запросить", "подготовить", "отправить", "согласовать", "направить",
    "передать", "оформить", "провести", "организовать", "внести", "добавить", "обновить",
    "составить", "подписать", "прислать", "скинуть", "выставить", "завести", "разослать",
    "уведомить", "сообщить", "подтвердить", "утвердить", "предоставить", "обеспечить", "сделать",
    "выдать", "оплатить", "закрыть", "собрать", "выслать", "подать", "подключить", "сдать",
})
# Личные действия: разговор, проверка, покупка - исполнитель сам автор захвата.
_SELF = frozenset({
    "напомнить", "проверить", "купить", "позвонить", "обсудить", "поговорить", "созвониться",
    "встретиться", "посмотреть", "почитать", "прочитать", "подумать", "записаться",
    "забронировать", "изучить", "узнать", "разобраться", "записать", "найти", "закинуть",
    "пробить", "уточнить", "выяснить", "попробовать", "понять", "оценить", "поискать", "написать",
    "решить", "продумать", "вспомнить", "получить",
})
# Существительные на «-ть», которые выглядят как инфинитив в начале строки.
_NOT_VERB = frozenset({"область", "власть", "часть", "честь", "страсть", "сеть", "пять"})

_LIST_MARK = r"[\s>*\-•#✓☐☑]+|\[[ xX]?\]|\d+[.)]"
_LINE_HEAD_RE = re.compile(rf"^(?:{_LIST_MARK})+")
_TAGS_TAIL_RE = re.compile(r"(?:\s+#[\w-]+)+\s*$")
_FIRST_WORD_RE = re.compile(r"^([А-Яа-яЁё]+)")
_INFINITIVE_RE = re.compile(r"^[а-яё]{4,}(?:ть|ться|ти|тись|чь)$")
_NEED_RE = re.compile(
    r"(?:нужно|надо|необходимо|прошу|просьба)\s+(?:[а-яё]+\s+){0,2}?([а-яё]+(?:ть|ться|ти|чь))",
    re.IGNORECASE,
)
_LIST_LINE_RE = re.compile(r"^\s*(?:[-*•]|\d+[.)]|\[[ xX]?\])\s+\S")

_HANDLE_RE = re.compile(r"@[\w.]{2,}")
_ROLE_RE = re.compile(
    r"\b(?:администратор|менеджер|юрист|бухгалтер|коллег|команд|отдел|помощник|секретар|"
    r"руководител|директор|партнер|партнёр)[а-яё]*",
    re.IGNORECASE,
)
# Имя после предлога/глагола адресации: «у Черникова», «Поручить Кате», «для Марины».
_NAME_RE = re.compile(
    r"(?i:\b(?:у|для|от|с|к|поручить|попросить|передать|направить|написать|сообщить|скинуть|"
    r"прислать|отправить|запросить|согласовать|уточнить))\s+([А-ЯЁ][а-яё]{2,})"
)
_RELATIVE_TIME_RE = re.compile(
    r"\b(?:сегодня|завтра|послезавтра|на\s+этой\s+неделе|на\s+следующей\s+неделе|"
    r"до\s+конца\s+(?:недели|месяца|дня)|(?:в|до|к)\s+"
    r"(?:понедельник|вторник|среду|пятниц\w+|четверг|субботу|воскресенье)\w*)\b",
    re.IGNORECASE,
)
_QUESTION_RE = re.compile(
    r"\?|\b(?:идея|мысль|гипотеза|можно\s+сделать|как\s+бы)\b", re.IGNORECASE
)

_LONG_TEXT = 160   # знаков: заметка, а не напоминание
_MIN_LIST = 3      # пунктов списка: заметка-конспект
_SHORT_LINE_WORDS = 12   # короткая строка: известный глагол действия считается и не в начале
_MEMO_LINES = 6          # от стольких строк захват - конспект...
_MEMO_ACTION_SHARE = 0.3  # ...если действий в нем реже, чем в каждой третьей строке


def _lines(text: str) -> list[str]:
    """Строки захвата без футера провенанса, маркеров списка и хвоста тегов."""
    body, _ = strip_footer(text or "")
    out: list[str] = []
    for raw in body.splitlines():
        line = _LINE_HEAD_RE.sub("", raw).strip()
        line = _TAGS_TAIL_RE.sub("", line).strip()
        if line:
            out.append(line)
    return out


def _verb_of(line: str) -> tuple[str, str] | None:
    """``(инфинитив, класс)`` действия строки или ``None``; класс - ``delegate`` | ``self``."""
    head = _FIRST_WORD_RE.match(line)
    candidates: list[str] = []
    if head:
        candidates.append(head.group(1).lower())
    need = _NEED_RE.search(line)
    if need:
        candidates.append(need.group(1).lower())
    for word in candidates:
        if word in _DELEGATE:
            return word, "delegate"
        if word in _SELF:
            return word, "self"
    for word in candidates:
        if len(word) >= 6 and word not in _NOT_VERB and _INFINITIVE_RE.match(word):
            return word, "self"
    # Короткая строка без вопроса: известный глагол списка и не в начале («Астана Хаб сдать отчет»,
    # «от Славы получить КП»). В длинной строке-абзаце глагол лейна не задает.
    words = [w.lower() for w in re.findall(r"[А-Яа-яЁё]+", line)]
    if len(words) <= _SHORT_LINE_WORDS and not _QUESTION_RE.search(line):
        for word in words:
            if word in _DELEGATE:
                return word, "delegate"
            if word in _SELF:
                return word, "self"
    return None


def _addressee(line: str) -> str | None:
    for rx in (_HANDLE_RE, _ROLE_RE):
        m = rx.search(line)
        if m:
            return m.group(0)
    m = _NAME_RE.search(line)
    return m.group(1) if m else None


def _due_label(text: str, today: date | None) -> str | None:
    """Срок: дата из текста (тот же детектор, что у карточки поручения) или «завтра/в пятницу»."""
    iso = extract_due(text, today=today)
    if iso:
        return iso
    m = _RELATIVE_TIME_RE.search(text)
    return m.group(0).lower() if m else None


def suggest_lane(text: str, *, today: date | None = None) -> dict[str, str] | None:
    """``{lane, reason}`` для захвата или ``None``, если признаков нет."""
    lines = _lines(text)
    if not lines:
        return None
    actions = [(ln, v) for ln in lines if (v := _verb_of(ln))]
    if len(lines) >= _MEMO_LINES and len(actions) / len(lines) < _MEMO_ACTION_SHARE:
        actions = []  # конспект: редкая строка с глаголом - не задача захвата
    due = _due_label("\n".join(lines), today)

    delegating = [(ln, v) for ln, v in actions if v[1] == "delegate"]
    for line, (verb, _cls) in delegating:
        who = _addressee(line)
        if who:
            return {"lane": LANE_ASSIGNMENT, "reason": f"глагол «{verb}» и адресат {who}"}
        if due:
            return {"lane": LANE_ASSIGNMENT, "reason": f"глагол «{verb}» и срок {due}"}
    if actions:
        line, (verb, cls) = actions[0]
        if cls == "self" and _addressee(line):
            return {"lane": LANE_TASK, "reason": f"личное действие «{verb}», а не поручение"}
        return {"lane": LANE_TASK, "reason": f"действие «{verb}» без адресата и срока"}
    if due:
        return {"lane": LANE_TASK, "reason": f"дата или время без клиента: {due}"}

    joined = "\n".join(lines)
    items = sum(1 for ln in (strip_footer(text)[0]).splitlines() if _LIST_LINE_RE.match(ln))
    if items >= _MIN_LIST:
        reason = f"заметка: список из {items} пунктов, действий нет"
        return {"lane": LANE_KNOWLEDGE, "reason": reason}
    if _QUESTION_RE.search(joined):
        return {"lane": LANE_KNOWLEDGE, "reason": "вопрос или идея, глагола действия нет"}
    if len(joined) >= _LONG_TEXT:
        return {"lane": LANE_KNOWLEDGE, "reason": "длинный текст, глагола действия нет"}
    return None


def annotate(rows: list[dict[str, Any]], *, today: date | None = None) -> list[dict[str, Any]]:
    """Дописать ``suggested_lane``/``suggested_reason`` (``None``, если признаков нет) карточкам.

    Текст - из ``text`` (в манифесте он уже начинается с заголовка задачи), иначе из ``title``.
    Исходные поля не меняются; тег ``поручение``/``тиметта`` у untriaged не бывает (иначе захват не
    попал бы в untriaged), но если он есть - лейн поручения очевиден и без правил.
    """
    out: list[dict[str, Any]] = []
    for row in rows:
        tags = {str(t).lower() for t in (row.get("tags") or [])}
        if tags & {TAG_ASSIGNMENT, TAG_TIMETTA}:
            hit: dict[str, str] | None = {
                "lane": LANE_ASSIGNMENT, "reason": "тег поручение стоит на захвате",
            }
        else:
            hit = suggest_lane(str(row.get("text") or row.get("title") or ""), today=today)
        out.append({
            **row,
            "suggested_lane": hit["lane"] if hit else None,
            "suggested_reason": hit["reason"] if hit else None,
        })
    return out
