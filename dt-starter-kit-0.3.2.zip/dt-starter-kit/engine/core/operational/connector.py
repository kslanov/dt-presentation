"""Provider-neutral operational connector contract (architecture §7).

The connector is the pluggable boundary between the engine and the operational
system of record. The work-instance implementation is Timetta
(:mod:`core.operational.timetta`); a future personal instance would be TickTick.
Keeping the contract and the data shapes neutral here is what lets the instance
swap without rewriting the engine.

**Scope of B1 (this layer):** read only. ``pull_changes`` is implemented by the
Timetta connector; ``propose_write`` / ``apply_write`` are deliberate stubs
(write-back is Track B3). The dataclasses carry only the minimal fields the
engine needs for ``dt-status`` and the future ``operational_context`` slice.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "Cursor",
    "OperationalEntity",
    "Deal",
    "Project",
    "Issue",
    "Organization",
    "ChangeSet",
    "OperationalState",
    "StateFilter",
    "OperationalConnector",
]


@dataclass
class Cursor:
    """Per-entity sync watermark.

    Maps an entity-set name (e.g. ``"Deals"``) to the highest ``modified``
    literal pulled so far. The delta filter for the next pull is
    ``modified gt <watermark>`` — strict ``gt`` is what makes an unchanged
    re-pull a no-op (idempotency, §7 "sync-курсор").

    A ``None`` cursor (or a missing entity key) means "first run → full orbit".
    """

    per_entity: dict[str, str] = field(default_factory=dict)

    def for_entity(self, entity_set: str) -> str | None:
        return self.per_entity.get(entity_set)

    def to_dict(self) -> dict[str, str]:
        return dict(self.per_entity)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> Cursor:
        if not data:
            return cls()
        return cls(per_entity={str(k): str(v) for k, v in data.items() if v})


@dataclass
class OperationalEntity:
    """Common fields shared by every mirrored Timetta object."""

    id: str
    name: str | None = None
    code: str | None = None
    is_active: bool = True
    created: str | None = None
    modified: str | None = None
    # ORBIT-2 п.3: метка сверки удалений — записи нет в Timetta (id-список источника).
    # НЕ удаляем из зеркала (история), но потребители её не видят (``orbit.visible``).
    deleted_at: str | None = None


@dataclass
class Deal(OperationalEntity):
    """A CRM deal/lead — Timetta ``Deals`` (architecture §1, §7 mapping)."""

    organization_id: str | None = None
    organization_name: str | None = None
    manager_id: str | None = None
    manager_name: str | None = None
    project_id: str | None = None
    amount: float | None = None
    probability: float | None = None
    state_id: str | None = None
    # When the deal last entered its current stage (Timetta ``stateEntered``). A
    # ``WP.SetState`` move bumps this even when ``modified`` lags, so the delta
    # pull keys on it too (see ``mapping.DELTA_FIELDS`` / ``mirror._advance``).
    state_entered: str | None = None
    state_name: str | None = None
    # Lightweight lead-owner tasks living *on the deal* (B3a). Each item is a
    # neutral dict ``{title, performer_id, deadline, fulfilled}`` mapped from the
    # Timetta ``WP.CheckListItem`` value type (which has no per-item id, B3-0).
    check_list: list[dict[str, Any]] = field(default_factory=list)
    # --- ORBIT-2: кольцо орбиты (ключи только добавляются) ---
    # Юрлицо СДЕЛКИ (``Deal.legalEntityId``; бывает пусто — 17 из 47) и разрешённое
    # «юрлицо сделки → иначе юрлицо ведущего» (``unit_*``, считает ``orbit.recompute``).
    legal_entity_id: str | None = None
    legal_entity_name: str | None = None
    unit_id: str | None = None
    unit_name: str | None = None
    # Авторство: ``createdBy`` — только факт (НЕ участие: след передачи сделки);
    # ``last_change_*`` — последний редактор (``modifiedBy``/``modified``).
    created_by_id: str | None = None
    created_by_name: str | None = None
    last_change_by_id: str | None = None
    last_change_by_name: str | None = None
    last_change_at: str | None = None
    # Явные участники (guid): исполнители пунктов чек-листа и связанных задач.
    participants: list[str] = field(default_factory=list)
    # ``mine | unit | group`` — производное (``orbit.ring_of``), пересчёт в конце pull.
    ring: str | None = None


@dataclass
class Project(OperationalEntity):
    """A project — Timetta ``Projects``."""

    organization_id: str | None = None
    organization_name: str | None = None
    manager_id: str | None = None
    manager_name: str | None = None
    start_date: str | None = None
    end_date: str | None = None
    state_id: str | None = None
    state_name: str | None = None


@dataclass
class Issue(OperationalEntity):
    """A task/issue — Timetta ``Issues``."""

    assigned_id: str | None = None
    assigned_name: str | None = None
    project_id: str | None = None
    # Project name/code carried on the issue itself via ``$expand=project`` (spike
    # 2026-07-08). The projects orbit is narrower than the deals orbit, so an
    # issue's project may be absent from ``projects.json`` — expanding here makes
    # the human distinguisher (project name) available regardless (see
    # ``work._attention``: two same-named issues differ by project, not by code).
    project_name: str | None = None
    project_code: str | None = None
    project_task_id: str | None = None
    deal_id: str | None = None
    priority_id: str | None = None
    state_id: str | None = None
    # See :class:`Deal.state_entered` — keyed on by the delta pull so an external
    # status change (incl. a close → inactive) is not dropped.
    state_entered: str | None = None
    state_name: str | None = None
    # Timetta ``resolutionId``/``resolutionComment`` (WorkPackage closure, spike
    # 2026-07-08). Closing an issue in the UI sets ``stateId → Closed`` *and*
    # stamps a resolution — so a non-null ``resolution_id`` is a durable terminal
    # signal even if the state code lags (defensive, see ``work._is_active``).
    resolution_id: str | None = None
    resolution_comment: str | None = None
    due_date: str | None = None
    parent_id: str | None = None


@dataclass
class Organization(OperationalEntity):
    """A client organization — Timetta ``Organizations``."""

    manager_id: str | None = None
    manager_name: str | None = None


@dataclass
class ChangeSet:
    """What a delta pull changed, plus the advanced cursor.

    ``created`` / ``updated`` are per-entity-set counts (new Guid vs. an upsert
    over a Guid already in the mirror); the lists carry the actual changed
    objects so callers can render "what moved" without re-reading the mirror.
    """

    cursor: Cursor
    deals: list[Deal] = field(default_factory=list)
    projects: list[Project] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)
    organizations: list[Organization] = field(default_factory=list)
    created: dict[str, int] = field(default_factory=dict)
    updated: dict[str, int] = field(default_factory=dict)
    # ORBIT-3: анонимная сводка шага ленты изменений коллег (счётчики вызовов/записей); пусто,
    # если шаг не запускался. Не входит в ``total_changed`` — это не изменение зеркала.
    history: dict[str, Any] = field(default_factory=dict)

    @property
    def total_changed(self) -> int:
        return sum(self.created.values()) + sum(self.updated.values())

    def is_empty(self) -> bool:
        return self.total_changed == 0


@dataclass
class StateFilter:
    """Narrowing filter for :meth:`OperationalConnector.get_state` / dt-status.

    Each field is matched case-insensitively against an entity's name **or**
    code **or** id (substring), so ``--client``/``--project``/``--deal`` accept
    a human name, a Timetta code, or a Guid interchangeably.
    """

    client: str | None = None
    project: str | None = None
    deal: str | None = None
    # ORBIT-2: кольца орбиты (``"mine,unit"``/список/``None`` = ``mine``): чьи сделки в срезе.
    rings: Any = None

    def is_empty(self) -> bool:
        return not (self.client or self.project or self.deal)


@dataclass
class OperationalState:
    """A read slice assembled from the mirror for ``dt-status`` (no network)."""

    deals: list[Deal] = field(default_factory=list)
    projects: list[Project] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)
    organizations: list[Organization] = field(default_factory=list)


class OperationalConnector(ABC):
    """Pluggable per-instance operational connector (§7)."""

    @abstractmethod
    def pull_changes(self, cursor: Cursor | None) -> ChangeSet:
        """Delta-read the orbit since ``cursor`` → update mirror, return changes."""
        raise NotImplementedError

    @abstractmethod
    def get_state(self, state_filter: StateFilter | None = None) -> OperationalState:
        """Assemble an operational slice from the local mirror (no network)."""
        raise NotImplementedError

    # --- write-back: Track B3, intentionally not implemented here -------------

    def propose_write(self, change: Any) -> Any:
        """Form a proposed change to the system of record (no apply). **B3.**"""
        raise NotImplementedError("write-back is Track B3 (not implemented in B1)")

    def apply_write(self, change: Any) -> Any:
        """Apply a confirmed change to the system of record.

        RETIRE-WRITE-1: :class:`~core.operational.timetta.connector.TimettaConnector` is
        read-only — Timetta writes were retired (branch ``archive/timetta-write``).
        """
        raise NotImplementedError("apply_write: this connector handles no write kinds")
