"""``operational_context`` — a live-status block for generation (ТЗ B4, §7).

Assembles a compact, Russian-language snapshot of the author's operational
state (client → active deals → projects → my open issues) from the **local
Timetta mirror** (B1, ``.derived/timetta/``) and hands it to prompt assembly as
one more locally-built section. The artifact-generation path is offline by
contract, so this layer is read-only over the mirror and the vault — **no
network, no LLM** (the mirror is refreshed separately by ``dt-status --refresh``
/ sync).

Mapping vault → Timetta (per id in scope):

1. **By ``timetta_id``** in the vault hub's frontmatter, when present and known
   to the mirror.
2. **Fallback by name/aliases** — the hub's aliases / title / H1 matched against
   the mirror's ``organizations`` / ``projects`` / ``deals``. The crosswalk may
   not be filled in yet, so the fallback is mandatory.

**Privacy (commercial secret):** deal ``amount`` and ``probability`` are **never
rendered** into the block — it flows into the prompt/inference. Only name, code,
status/stage, dates and task statuses are surfaced.

No match / no mirror → ``None`` (generation proceeds without the section).

Invariant: ``core/`` depends on neither MCP nor CLI.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from core.operational import orbit
from core.operational.connector import Deal, Issue, Organization, Project
from core.operational.timetta import mapping as m
from core.operational.timetta.mirror import MirrorStore

__all__ = ["build_operational_context"]

_HEADER = "[Операционный контекст — из Timetta, зеркало на {freshness}]"
_H1_RE = re.compile(r"^#\s+(.+)$", re.MULTILINE)


# --- vault hub resolution (no network) ---------------------------------------


def _find_hubs(vault_path: Path | None, ids: set[str]) -> dict[str, Any]:
    """Return ``{hub_id: Note}`` for the requested ids in a single vault walk."""
    if not ids:
        return {}
    # Imported lazily so the operational layer doesn't pull the vault stack
    # unless a caller actually needs hub resolution.
    from core.config import default_vault_path
    from core.vault import iter_vault

    root = vault_path or default_vault_path()
    if not Path(root).is_dir():
        return {}
    found: dict[str, Any] = {}
    for note in iter_vault(root):
        if note.id in ids:
            found[note.id] = note
            if len(found) == len(ids):
                break
    return found


def _hub_names(note: Any) -> set[str]:
    """Candidate human names of a hub: aliases + title + first H1, lowercased."""
    names: set[str] = set()
    aliases = note.frontmatter.get("aliases")
    if isinstance(aliases, str):
        names.add(aliases)
    elif isinstance(aliases, list):
        names.update(str(a) for a in aliases)
    title = note.frontmatter.get("title")
    if title:
        names.add(str(title))
    h1 = _H1_RE.search(note.body or "")
    if h1:
        names.add(h1.group(1))
    return {n.strip().lower() for n in names if n and n.strip()}


def _entity_matches(names: set[str], obj: dict[str, Any]) -> bool:
    """Match hub names against an entity's ``name``/``code`` (case-insensitive)."""
    fields = [
        str(obj[k]).strip().lower()
        for k in ("name", "code")
        if isinstance(obj.get(k), str) and str(obj[k]).strip()
    ]
    for n in names:
        for f in fields:
            if n == f or n in f or f in n:
                return True
    return False


def _resolve_guid(note: Any | None, table: dict[str, dict[str, Any]]) -> str | None:
    """Resolve a hub to a Timetta Guid: ``timetta_id`` first, then name/aliases."""
    if note is None:
        return None
    tid = note.frontmatter.get("timetta_id")
    if isinstance(tid, str) and tid.strip():
        guid = tid.strip()
        if guid in table or any(str(o.get("id")) == guid for o in table.values()):
            return guid
    names = _hub_names(note)
    if names:
        for guid, obj in table.items():
            if _entity_matches(names, obj):
                return str(obj.get("id", guid))
    return None


# --- freshness ---------------------------------------------------------------


def _freshness(store: MirrorStore, *objs: list[Any]) -> str:
    """Latest ``modified`` from the cursor (else from the mirrored objects)."""
    cursor = store.load_cursor()
    latest = m.max_modified(list(cursor.per_entity.values()))
    if not latest:
        mods: list[str | None] = []
        for group in objs:
            mods.extend(getattr(o, "modified", None) for o in group)
        latest = m.max_modified(mods)
    if not latest:
        return "—"
    return latest[:16].replace("T", " ")


# --- rendering ---------------------------------------------------------------


def _status(state_name: str | None) -> str:
    return f" — статус: «{state_name}»" if state_name else ""


def _deal_line(d: Deal) -> str:
    code = f"[{d.code}] " if d.code else ""
    # ORBIT-2: сделка не из кольца ``mine`` — с ведущим («сделка Любы»); у своих строка прежняя.
    lead = ""
    if (d.ring or orbit.RING_MINE) != orbit.RING_MINE and d.manager_name:
        lead = f" (ведёт: {d.manager_name})"
    return f"  - {code}{d.name or '(без названия)'}{lead}{_status(d.state_name)}"


def _project_line(p: Project) -> str:
    code = f"[{p.code}] " if p.code else ""
    dates = ""
    if p.start_date or p.end_date:
        dates = f" ({p.start_date or '…'}–{p.end_date or '…'})"
    return f"  - {code}{p.name or '(без названия)'}{_status(p.state_name)}{dates}"


def _issue_line(i: Issue) -> str:
    due = f" — срок {i.due_date}" if i.due_date else ""
    return f"  - {i.name or '(без названия)'}{_status(i.state_name)}{due}"


def build_operational_context(
    *,
    client_id: str | None = None,
    project_id: str | None = None,
    deal_id: str | None = None,
    mirror_path: Path | None = None,
    vault_path: Path | None = None,
) -> str | None:
    """Build the live-status block for the entities in scope, or ``None``.

    Reads only the local Timetta mirror and the vault (no network, no LLM).
    Returns ``None`` when the mirror is absent/empty or nothing in scope can be
    mapped to a Timetta object.
    """
    if not (client_id or project_id or deal_id):
        return None

    from core.config import timetta_mirror_path

    store = MirrorStore(mirror_path or timetta_mirror_path())

    orgs_tbl = store.load("organizations")
    projects_tbl = store.load("projects")
    # ORBIT-2: таблица сделок для резолва хаба → guid — только видимые кольца, без удалённых.
    deals_tbl = {
        str(d["id"]): d for d in orbit.visible(store.all("deals"), orbit.enabled_rings())
        if d.get("id")
    }
    if not (orgs_tbl or projects_tbl or deals_tbl):
        return None

    requested = {i for i in (client_id, project_id, deal_id) if i}
    hubs = _find_hubs(vault_path, requested)

    org_guid = _resolve_guid(hubs.get(client_id), orgs_tbl) if client_id else None
    project_guid = (
        _resolve_guid(hubs.get(project_id), projects_tbl) if project_id else None
    )
    deal_guid = _resolve_guid(hubs.get(deal_id), deals_tbl) if deal_id else None

    if not (org_guid or project_guid or deal_guid):
        return None

    # ORBIT-2: сделки клиента из ВСЕХ видимых колец (DT_ORBIT_RINGS), каждая с ведущим
    # (``_deal_line``); удалённые в Timetta не показываются. Единая точка — ``orbit_slice``.
    sl = orbit.orbit_slice(store, orbit.enabled_rings())
    deals = [Deal(**d) for d in sl["deals"] if d.get("is_active", True)]
    projects = [Project(**p) for p in sl["projects"] if p.get("is_active", True)]
    issues = [Issue(**i) for i in sl["issues"] if i.get("is_active", True)]
    orgs = {str(o["id"]): Organization(**o) for o in store.all("organizations")}

    client_org: Organization | None = None
    if org_guid:
        deals = [d for d in deals if d.organization_id == org_guid]
        projects = [p for p in projects if p.organization_id == org_guid]
        client_org = orgs.get(org_guid)
    if deal_guid:
        deals = [d for d in deals if d.id == deal_guid]
    if project_guid:
        projects = [p for p in projects if p.id == project_guid]

    deal_ids = {d.id for d in deals}
    project_ids = {p.id for p in projects}
    issues = [
        i for i in issues if i.deal_id in deal_ids or i.project_id in project_ids
    ]

    if not (deals or projects or issues):
        return None

    deals.sort(key=lambda d: (d.modified or ""), reverse=True)
    projects.sort(key=lambda p: (p.name or "").lower())
    issues.sort(key=lambda i: (i.due_date or "9999"))

    client_name = None
    if client_org is not None:
        client_name = client_org.name
    if not client_name and deals:
        client_name = deals[0].organization_name
    if not client_name and projects:
        client_name = projects[0].organization_name

    lines = [_HEADER.format(freshness=_freshness(store, deals, projects, issues))]
    if client_name:
        lines.append(f"Клиент: {client_name}")
    if deals:
        lines.append("Активные сделки:")
        lines.extend(_deal_line(d) for d in deals)
    if projects:
        lines.append("Проекты:")
        lines.extend(_project_line(p) for p in projects)
    if issues:
        lines.append("Открытые задачи:")
        lines.extend(_issue_line(i) for i in issues)

    return "\n".join(lines)
