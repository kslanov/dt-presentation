"""Three-way crosswalk: Timetta Guid ↔ TickTick id ↔ vault ``timetta_id`` (§7).

RETIRE-WRITE-1: the reflector is retired (branch ``archive/timetta-write``) — the crosswalk is
**mirror-only** now: a read-only Guid↔TickTick map kept for context and the deletion reconcile.
Nothing writes new rows any more.

Two durable anchors keep the reflection (B2b) idempotent and self-healing:

* a **marker** ``⟦tt:<kind>:<guid>⟧`` written into a TickTick task's ``content``.
  It survives a rebuild of the derived JSON *and* a delete+recreate of the task
  (transfer), so the Timetta↔TickTick link can always be recovered by scanning;
* ``.derived/operational/crosswalk.json`` — the fast two-way map
  ``{ "<timetta_guid>": {kind, ticktick_id, ticktick_project_id, marker,
  synced_at, completed} }``. Rebuildable from the markers if lost.

:func:`resolve_or_scan` is the lookup the reflector uses to decide *create vs.
update*: crosswalk first, then a marker scan of the target list, else "not found
→ create a new object" (never adopt an unmarked/foreign task — see the scope
guard in ``core.operational.reflect``).

Pure data + filesystem only — **no network, no LLM** (architecture invariant).
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from core.adapters import load_json_store

__all__ = [
    "KIND_DEAL",
    "KIND_PROJECT",
    "KIND_ISSUE",
    "KIND_LIST",
    "KIND_CHECKITEM",
    "KIND_PROPOSAL",
    "format_marker",
    "parse_markers",
    "has_marker",
    "has_any_marker",
    "scan_for_marker",
    "deal_code",
    "list_anchor",
    "normalize_title",
    "checkitem_id",
    "checkitem_guid",
    "format_checkitem_marker",
    "parse_checkitem_markers",
    "CrosswalkEntry",
    "Crosswalk",
    "resolve_or_scan",
    "resolve_list_or_scan",
    "resolve_checkitem_or_anchor",
]

KIND_DEAL = "deal"
KIND_PROJECT = "project"
KIND_ISSUE = "issue"
# B3b (retired by RETIRE-WRITE-1; kept so old markers still parse): a TickTick task in the
# «На подтверждение» queue carrying an engine proposal. The marker ``⟦tt:proposal:<id>⟧`` linked
# the queue task to its row in ``proposals.json`` (queue code: branch ``archive/timetta-write``).
KIND_PROPOSAL = "proposal"
# Legacy (B2b): a TickTick list the engine created *per client*. B2c remaps the
# mirror so a deal/project **is** the list — KIND_LIST is no longer produced, but
# the constant and teardown still recognise pre-B2c rows during migration.
KIND_LIST = "list"
# B3a: a TickTick task mirroring one ``Deal.checkList`` item. A checklist item
# has **no stable id** in Timetta (B3-0 findings), so its identity is its
# normalised title hashed into a stable token — the marker therefore carries
# *two* colon-separated parts: ``⟦tt:checkitem:<dealGuid>:<itemId>⟧``.
KIND_CHECKITEM = "checkitem"

# ⟦…⟧ are U+27E6 / U+27E7 — chosen to be vanishingly unlikely in user text. The
# guid segment allows ``:`` (so a checkitem can carry ``<dealGuid>:<itemId>``);
# ``⟧`` still terminates the marker, so deal/issue/project markers (whose guid
# has no colon) parse exactly as before.
_MARKER_RE = re.compile(r"⟦tt:([a-z]+):([^⟧]+)⟧")
# Timetta deal codes already carry a ``DEAL-``/``DEAL `` head (e.g. ``DEAL-2``).
# The engine wraps the code in ``[DEAL-…]``, so the raw head must be stripped to
# avoid a doubled ``[DEAL-DEAL-2]`` (B2d fix 1). Case-insensitive, leading only.
_DEAL_CODE_HEAD_RE = re.compile(r"(?i)^deal[-\s]+")


def deal_code(code: str | None) -> str:
    """Normalise a Timetta deal ``code`` for the ``[DEAL-<code>]`` name prefix.

    Strips a leading ``DEAL-``/``DEAL `` (case-insensitive) so ``"DEAL-2"`` and
    ``"DEAL 2"`` both become ``"2"`` → ``[DEAL-2]`` (not ``[DEAL-DEAL-2]``). A
    code without that head (e.g. ``"S-1"``) is returned unchanged; ``None`` →
    ``""``. Idempotent. Used by both :func:`list_anchor` (the scan anchor) and
    ``reflect.deal_list_name`` (the displayed name) so they stay consistent.
    """
    return _DEAL_CODE_HEAD_RE.sub("", (code or "").strip()).strip()


def format_marker(kind: str, guid: str) -> str:
    """``("deal", "<guid>") -> "⟦tt:deal:<guid>⟧"``."""
    return f"⟦tt:{kind}:{guid}⟧"


# --- checklist-item identity (B3a) ------------------------------------------
# A ``Deal.checkList`` item has no stable id in Timetta (B3-0): the collection is
# a value type edited as a whole array. So an item's identity is its **normalised
# title**, hashed into a short stable token. This is the anchor for both the
# marker (``⟦tt:checkitem:<dealGuid>:<itemId>⟧``) and the synthetic crosswalk key.


def normalize_title(title: str | None) -> str:
    """Casefold + collapse internal whitespace + strip — the item's anchor key."""
    return " ".join((title or "").split()).strip().casefold()


def checkitem_id(title: str | None) -> str:
    """Stable 12-hex token derived from a checklist item's normalised title.

    Two items with the same normalised title collapse to one id (intended: a
    deal cannot meaningfully carry two identical checklist lines, and it keeps
    the round-trip idempotent). Pure (sha1 of the normalised title).
    """
    norm = normalize_title(title)
    return hashlib.sha1(norm.encode("utf-8")).hexdigest()[:12]  # noqa: S324 — id, not crypto


def checkitem_guid(deal_guid: str, title: str | None) -> str:
    """Synthetic crosswalk key for a checklist item: ``<dealGuid>:<itemId>``.

    Lower-cased so it matches the crosswalk's normalised deal-guid keys. Also the
    guid segment embedded in the ``checkitem`` marker.
    """
    return f"{deal_guid.strip().lower()}:{checkitem_id(title)}"


def format_checkitem_marker(deal_guid: str, title: str | None) -> str:
    """``⟦tt:checkitem:<dealGuid>:<itemId>⟧`` for a deal's checklist item."""
    return format_marker(KIND_CHECKITEM, checkitem_guid(deal_guid, title))


def parse_checkitem_markers(text: str | None) -> list[tuple[str, str]]:
    """Every ``(deal_guid, item_id)`` checkitem marker in ``text``.

    The guid segment is ``<dealGuid>:<itemId>``; the deal guid is itself colon-
    free, the item id is hex, so a single ``rsplit(':', 1)`` separates them.
    """
    out: list[tuple[str, str]] = []
    for kind, seg in parse_markers(text):
        if kind != KIND_CHECKITEM or ":" not in seg:
            continue
        deal_guid, item_id = seg.rsplit(":", 1)
        out.append((deal_guid, item_id))
    return out


def parse_markers(text: str | None) -> list[tuple[str, str]]:
    """Extract every ``(kind, guid)`` marker from a blob of task text."""
    if not text:
        return []
    return [(k, g) for k, g in _MARKER_RE.findall(text)]


def _task_text(task: dict[str, Any]) -> str:
    """All the fields a marker might live in (we write it into ``content``)."""
    return " ".join(
        str(task.get(key) or "") for key in ("content", "desc", "title")
    )


def has_marker(task: dict[str, Any], kind: str, guid: str) -> bool:
    """True iff ``task`` carries exactly this engine marker (scope-guard helper)."""
    return (kind, guid) in parse_markers(_task_text(task))


def has_any_marker(task: dict[str, Any]) -> bool:
    """True iff ``task`` carries *any* engine ``⟦tt:…⟧`` marker.

    Used by the checklist anchor (B3a): an unmarked task whose title matches a
    Timetta checklist item is adopted; a task already carrying *some* marker (an
    issue, or another checkitem) is never adopted by title (scope guard).
    """
    return bool(parse_markers(_task_text(task)))


def scan_for_marker(
    tasks: list[dict[str, Any]], kind: str, guid: str
) -> dict[str, Any] | None:
    """First task in ``tasks`` carrying ``⟦tt:kind:guid⟧``, else ``None``."""
    for task in tasks:
        if isinstance(task, dict) and has_marker(task, kind, guid):
            return task
    return None


@dataclass
class CrosswalkEntry:
    """One Timetta-Guid row of the crosswalk."""

    kind: str
    ticktick_id: str = ""
    ticktick_project_id: str | None = None
    marker: str | None = None
    synced_at: str | None = None
    completed: bool = False
    # The Timetta Guid of the parent the subtask currently hangs under (issues
    # only). A change here means the issue was re-parented (deal/project/client
    # moved) → transfer = delete+recreate, since V1 cannot move a task (B0).
    parent_guid: str | None = None
    # The full desired list name the engine last applied (lists only, B2d). The
    # rename decision compares the new desired name against THIS, not a live
    # read-back: TickTick truncates list names to ~64 chars, so a long live name
    # never equals the full desired one → without this the list renamed forever.
    applied_name: str | None = None
    # Applied snapshot of a checklist item (checkitems only, B3a). Write-back is
    # Timetta-wins: a TickTick edit is pushed to Timetta only when the Timetta
    # side still equals this snapshot (i.e. it did not change since the last
    # sync); compared like ``applied_name`` — against the snapshot, not live.
    applied_title: str | None = None
    applied_due: str | None = None
    applied_done: bool | None = None
    # ORBIT-2: объект исчез в Timetta (сверка удалений нашла его id-списком в отсутствующих).
    # Строка НЕ удаляется (карточка/список в TickTick и связь с хабом остаются как были), но
    # запись/каскад в эту цель прекращены. Меняется только сверкой; ключ в JSON — лишь при True.
    resolved_external: bool = False


@dataclass
class Crosswalk:
    """The ``crosswalk.json`` map, keyed by Timetta Guid (lower-cased)."""

    entries: dict[str, CrosswalkEntry] = field(default_factory=dict)
    path: Path | None = None

    @staticmethod
    def _norm(guid: str) -> str:
        return str(guid).strip().lower()

    @classmethod
    def load(cls, path: Path) -> Crosswalk:
        path = Path(path)
        # Нет файла → пустая карта (первый запуск). Файл есть, но битый →
        # StoreUnavailableError (ADAPTER-HONEST-1): пустой crosswalk = «ничего в TickTick
        # не заведено», и следующий reflect ЗАНОВО создал бы все проекты и задачи во
        # внешней системе — дубли. Это единственный стор, чья потеря бьёт наружу.
        raw = load_json_store(path, adapter="crosswalk", expect=dict)
        if raw is None:
            return cls(entries={}, path=path)
        entries: dict[str, CrosswalkEntry] = {}
        if isinstance(raw, dict):
            for guid, val in raw.items():
                # A row is kept if it anchors a TickTick object (ticktick_id); rows without one
                # are junk (incl. pre-RETIRE-WRITE-1 vault-only rows, whose ``vault_id`` side
                # had no readers) and are dropped.
                if isinstance(val, dict) and val.get("ticktick_id"):
                    entries[cls._norm(guid)] = CrosswalkEntry(
                        kind=str(val.get("kind", "")),
                        ticktick_id=str(val.get("ticktick_id") or ""),
                        ticktick_project_id=val.get("ticktick_project_id"),
                        marker=val.get("marker"),
                        synced_at=val.get("synced_at"),
                        completed=bool(val.get("completed", False)),
                        parent_guid=val.get("parent_guid"),
                        applied_name=val.get("applied_name"),
                        applied_title=val.get("applied_title"),
                        applied_due=val.get("applied_due"),
                        applied_done=val.get("applied_done"),
                        resolved_external=bool(val.get("resolved_external", False)),
                    )
        return cls(entries=entries, path=path)

    def save(self, path: Path | None = None) -> None:
        chosen = path or self.path
        if chosen is None:
            raise ValueError("Crosswalk.save needs a path")
        target = Path(chosen)
        target.parent.mkdir(parents=True, exist_ok=True)
        body = {
            guid: {
                k: v
                for k, v in asdict(e).items()
                if (v is not None or k == "completed")
                and not (k == "resolved_external" and not v)
            }
            for guid, e in sorted(self.entries.items())
        }
        target.write_text(
            json.dumps(body, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    # -- lookups (both directions) -------------------------------------------

    def get(self, guid: str) -> CrosswalkEntry | None:
        return self.entries.get(self._norm(guid))

    def by_ticktick_id(self, ticktick_id: str) -> tuple[str, CrosswalkEntry] | None:
        for guid, entry in self.entries.items():
            if entry.ticktick_id == ticktick_id:
                return (guid, entry)
        return None

    def put(self, guid: str, entry: CrosswalkEntry) -> None:
        self.entries[self._norm(guid)] = entry

    def remove(self, guid: str) -> None:
        self.entries.pop(self._norm(guid), None)


def list_anchor(kind: str, *, code: str | None, name: str) -> str:
    """The stable, status-independent prefix of an engine-created list name.

    B2c lists carry no description (V1 list form has no ``content`` field), so a
    ``⟦tt:…⟧`` marker cannot live on them. Ownership of a list is recorded in the
    crosswalk; the **name prefix** is the human-readable anchor used to recover a
    list when the crosswalk is lost. The anchor is the part of the name that does
    **not** move when the deal/project status changes:

    * deal with a Timetta ``code`` → ``[DEAL-<code>]`` (the code is unique; a
      leading ``DEAL-``/``DEAL `` head is stripped first — see :func:`deal_code`);
    * deal without a code → ``[DEAL] <name>``;
    * project → ``[Проект] <name>``.

    Only a list whose name starts with this anchor is ever re-adopted — the
    ``[DEAL-…]``/``[Проект]`` shape is the engine's signature, so a user's own
    list (no such prefix) is never adopted (scope guard).
    """
    nm = (name or "").strip()
    if kind == KIND_DEAL:
        code_s = deal_code(code)
        return f"[DEAL-{code_s}]" if code_s else f"[DEAL] {nm}".strip()
    if kind == KIND_PROJECT:
        return f"[Проект] {nm}".strip()
    return nm


def resolve_list_or_scan(
    crosswalk: Crosswalk,
    *,
    guid: str,
    anchor: str,
    projects: list[dict[str, Any]],
) -> tuple[str, dict[str, Any] | None]:
    """Find the TickTick **list** mirroring a Timetta deal/project.

    Mirror of :func:`resolve_or_scan` for lists (which have no marker):

    * ``"crosswalk"`` — the recorded list id is still present among ``projects``;
    * ``"scan"`` — recovered by matching the engine's name :func:`list_anchor`
      (crosswalk was stale/empty) → caller re-anchors the crosswalk to it;
    * ``"none"`` — no engine-owned list exists → the caller must **create** one.

    A list is matched on scan only if its name equals the anchor or begins with
    ``anchor + " "`` — i.e. it carries the engine's own ``[DEAL-…]``/``[Проект]``
    signature. Arbitrary/foreign lists are never adopted.
    """
    by_id = {str(p.get("id")): p for p in projects if isinstance(p, dict)}
    entry = crosswalk.get(guid)
    if entry is not None and entry.ticktick_project_id and entry.ticktick_project_id in by_id:
        return ("crosswalk", by_id[entry.ticktick_project_id])
    for project in projects:
        if not isinstance(project, dict):
            continue
        name = str(project.get("name") or "")
        if name == anchor or name.startswith(anchor + " "):
            return ("scan", project)
    return ("none", None)


def resolve_or_scan(
    crosswalk: Crosswalk,
    *,
    guid: str,
    kind: str,
    tasks: list[dict[str, Any]],
) -> tuple[str, dict[str, Any] | None]:
    """Find the TickTick counterpart of a Timetta entity.

    Returns ``(source, task)`` where ``source`` is:

    * ``"crosswalk"`` — id known and the task is still present in ``tasks``;
    * ``"scan"`` — recovered by marker scan (crosswalk was stale/empty);
    * ``"none"`` — no marked counterpart exists → the caller must **create** one
      (never adopt an unmarked or foreign task).

    ``task`` is the live task dict for crosswalk/scan hits (``None`` for
    ``"none"``). A crosswalk id that no longer appears among ``tasks`` falls
    through to a marker scan, then to ``"none"`` — so a manually-deleted mirror
    task is recreated rather than silently lost.
    """
    by_id = {str(t.get("id")): t for t in tasks if isinstance(t, dict)}
    entry = crosswalk.get(guid)
    if entry is not None and entry.ticktick_id in by_id:
        return ("crosswalk", by_id[entry.ticktick_id])
    scanned = scan_for_marker(tasks, kind, guid)
    if scanned is not None:
        return ("scan", scanned)
    return ("none", None)


def resolve_checkitem_or_anchor(
    crosswalk: Crosswalk,
    *,
    deal_guid: str,
    title: str | None,
    tasks: list[dict[str, Any]],
) -> tuple[str, dict[str, Any] | None]:
    """Find the TickTick task mirroring one ``Deal.checkList`` item.

    Like :func:`resolve_or_scan`, but a checklist item has no per-item id so the
    fallback is a **title anchor** (B3a). In order:

    * ``"crosswalk"`` — the recorded task id is present *and* still carries our
      ``checkitem`` marker (else the scope guard demotes it);
    * ``"scan"`` — recovered by the ``⟦tt:checkitem:<dealGuid>:<itemId>⟧`` marker;
    * ``"anchor"`` — an **unmarked** task whose normalised title equals the
      item's (a user task that *is* this item, created in TickTick before it was
      linked) → adopt it, do not create a duplicate (loop-avoidance);
    * ``"none"`` — nothing matches → the caller must **create** a fresh task.
    """
    seg = checkitem_guid(deal_guid, title)
    by_id = {str(t.get("id")): t for t in tasks if isinstance(t, dict)}
    entry = crosswalk.get(seg)
    if entry is not None and entry.ticktick_id in by_id:
        live = by_id[entry.ticktick_id]
        if has_marker(live, KIND_CHECKITEM, seg):
            return ("crosswalk", live)
    scanned = scan_for_marker(tasks, KIND_CHECKITEM, seg)
    if scanned is not None:
        return ("scan", scanned)
    target = normalize_title(title)
    if target:
        for task in tasks:
            if not isinstance(task, dict) or has_any_marker(task):
                continue
            if normalize_title(task.get("title")) == target:
                return ("anchor", task)
    return ("none", None)
