"""Доставка текстового артефакта файлом в рабочую папку — ФТ-4 (FT-4).

Суть требования: когда адресат известен ДО генерации, содержимое едет через мост
**один раз** — текстом, существующим каналом ``save_output``. Раньше сохранение
файлового deliverable стоило второй проход тем же содержимым в base64 (21 КБ .docx →
28 КБ base64 → минуты генерации; инцидент 04.08.2026, ФТ п. 1.2), не добавляя ни
байта информации. Здесь второй проход устранён целиком: целевой формат собирается
**локально на машине пользователя**, бинарное содержимое через мост не передаётся
вовсе (приёмочная проверка ФТ №11 — по конструкции: в вызове только текст).

Поток (:func:`deliver_text`):

1. текст → выбранный формат ``md`` | ``docx`` | ``pdf``;
2. ``md`` пишется как есть (UTF-8); ``docx``/``pdf`` — **pandoc** во временной папке
   (``tempfile``, НЕ в клиентской папке), вызов списком аргументов без ``shell``, со
   ``stdin=DEVNULL`` и таймаутом (уроки инцидентов с шелл-пайпами: base64 через пайпы
   дважды побил .docx в кейсе «Эмба»);
3. байты → под ingest-корень через общий write-слой
   (:func:`core.file_ingest.write_target.write_atomic`): те же гарды и та же семантика
   идемпотентности, что у ``store_file``/``place_download``.

**Нет pandoc или нет pdf-движка → не отказ**, а сохранение исходника в ``md`` +
явное предупреждение в ответе (прямое требование ФТ: «Отсутствие локального
конвертера → сохранение исходника в md и явное предупреждение, а не отказ операции»).
Так же обрабатывается сбой/таймаут конвертации: артефакт всё равно доезжает до папки,
человек видит, почему в другом формате.

``core`` ⊥ mcp/cli: сеть не используется, LLM не вызывается; аудит эмитит вызывающий
(MCP-обёртка ``save_output`` — одна аудит-строка на вызов инструмента).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from collections.abc import Callable
from pathlib import Path
from typing import Any

from core.file_ingest.write_target import (
    DEFAULT_ROOT_NAME,
    WriteTarget,
    WriteTargetError,
    resolve_dest_target,
    sha256_file,
    write_atomic,
)
from core.privacy import is_nda

__all__ = [
    "DeliverError",
    "deliver_text",
    "deliver_text_to_output_dir",
    "FORMATS",
    "FORMAT_MD",
    "PDF_ENGINES",
    "pandoc_path",
    "pdf_engine",
    "pandoc_timeout_s",
]

FORMAT_MD = "md"
FORMAT_DOCX = "docx"
FORMAT_PDF = "pdf"
# Форматы из ФТ-4. Дефолт — ``md`` (как сейчас: текст сохраняется как текст).
FORMATS = (FORMAT_MD, FORMAT_DOCX, FORMAT_PDF)

# pandoc сам PDF не рисует — ему нужен движок. Проверяем доступность ДО вызова
# (ФТ-4: «md → pdf только при наличии pdf-движка»), иначе отказ вылезал бы как
# невнятная ошибка pandoc. Порядок — от самого частого на macOS.
PDF_ENGINES = ("tectonic", "xelatex", "lualatex", "pdflatex", "typst", "weasyprint",
               "wkhtmltopdf", "prince", "context")

_PANDOC_TIMEOUT_ENV = "DT_PANDOC_TIMEOUT_S"
DEFAULT_PANDOC_TIMEOUT_S = 60.0

# Имя временного исходника для pandoc. Вход отдаём файлом, а не через stdin:
# ``stdin=DEVNULL`` — сознательное решение (процесс не может подвиснуть в ожидании
# ввода, как это случилось с шелл-пайпами в инцидентах).
_SRC_NAME = "source.md"


class DeliverError(RuntimeError):
    """Отказ доставки. ``code`` — машиночитаемая причина (NFR «диагностируемость»);
    ``details`` (DELIVER-2) - поля, с которыми клиент продолжает работу (sha диска и нашей
    доставки)."""

    def __init__(
        self, message: str, code: str = "refused", details: dict[str, Any] | None = None
    ) -> None:
        super().__init__(message)
        self.code = code
        self.details = dict(details or {})


def pandoc_timeout_s() -> float:
    """Бюджет одного вызова pandoc, сек (env ``DT_PANDOC_TIMEOUT_S``, дефолт 60)."""
    raw = os.environ.get(_PANDOC_TIMEOUT_ENV, "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_PANDOC_TIMEOUT_S
    return value if value > 0 else DEFAULT_PANDOC_TIMEOUT_S


def pandoc_path() -> str | None:
    """Путь к ``pandoc`` на машине пользователя, либо ``None`` (тогда — md+warning)."""
    return shutil.which("pandoc")


def pdf_engine() -> str | None:
    """Первый доступный pdf-движок из :data:`PDF_ENGINES`, либо ``None``."""
    for engine in PDF_ENGINES:
        found = shutil.which(engine)
        if found:
            return engine
    return None


def _normalize_format(value: str | None) -> str:
    fmt = str(value or FORMAT_MD).strip().lower().lstrip(".")
    if fmt not in FORMATS:
        raise DeliverError(
            f"неизвестный формат {value!r} — допустимы {', '.join(FORMATS)}", "bad_format"
        )
    return fmt


def _base_name(name: str, fmt: str) -> str:
    """Имя файла без пути: чужие расширения не трогаем, своё — не дублируем."""
    raw = str(name or "").strip()
    if not raw or raw in {".", ".."} or "/" in raw or "\\" in raw:
        raise DeliverError(
            f"имя файла должно быть именем без путей: {name!r}", "bad_file_name"
        )
    stem = raw[: -(len(fmt) + 1)] if raw.lower().endswith("." + fmt) else raw
    return f"{stem}.{fmt}"


def _run_pandoc(args: list[str], *, timeout_s: float) -> tuple[bool, str]:
    """Запустить pandoc списком аргументов. ``(успех, причина неуспеха)``.

    Без ``shell``, со ``stdin=DEVNULL`` и таймаутом; stdout/stderr перехватываются и
    в ответ попадает только короткая причина — не «простыня» вывода конвертера.
    """
    try:
        proc = subprocess.run(  # noqa: S603 — список аргументов, без shell; пути наши
            args,
            capture_output=True,
            stdin=subprocess.DEVNULL,
            timeout=timeout_s,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return False, f"pandoc не ответил за {timeout_s:g} с (таймаут)"
    except (OSError, subprocess.SubprocessError) as exc:
        return False, f"pandoc не запустился: {exc}"
    if proc.returncode != 0:
        tail = (proc.stderr or b"").decode("utf-8", errors="replace").strip()
        first = tail.splitlines()[-1] if tail else f"код возврата {proc.returncode}"
        return False, f"pandoc не смог сконвертировать: {first[:200]}"
    return True, ""


def _convert(text: str, fmt: str) -> tuple[bytes, str, str]:
    """Текст → ``(байты, фактический формат, предупреждение)``.

    Фактический формат может «съехать» на ``md``: нет pandoc, нет pdf-движка, сбой
    или таймаут конвертации. Это НЕ отказ (требование ФТ) — артефакт доезжает до
    папки, а предупреждение объясняет, почему формат другой.
    """
    md_bytes = text.encode("utf-8")
    if fmt == FORMAT_MD:
        return md_bytes, FORMAT_MD, ""

    pandoc = pandoc_path()
    if not pandoc:
        return md_bytes, FORMAT_MD, (
            f"pandoc не найден на машине — сохранён .md вместо .{fmt} "
            "(установка: brew install pandoc)"
        )
    engine = None
    if fmt == FORMAT_PDF:
        engine = pdf_engine()
        if not engine:
            return md_bytes, FORMAT_MD, (
                "нет pdf-движка для pandoc (искали: "
                f"{', '.join(PDF_ENGINES[:4])}…) — сохранён .md вместо .pdf"
            )

    with tempfile.TemporaryDirectory(prefix="dt-deliver-") as tmpdir:
        # Сборка идёт в системном временном каталоге, НЕ в клиентской папке: в целевую
        # папку попадают только готовые проверенные байты.
        src = Path(tmpdir) / _SRC_NAME
        src.write_text(text, encoding="utf-8")
        out = Path(tmpdir) / f"out.{fmt}"
        args = [pandoc, str(src), "-f", "markdown", "-o", str(out)]
        if engine:
            args += ["--pdf-engine", engine]
        ok, reason = _run_pandoc(args, timeout_s=pandoc_timeout_s())
        if not ok:
            return md_bytes, FORMAT_MD, f"{reason} — сохранён .md вместо .{fmt}"
        try:
            data = out.read_bytes()
        except OSError as exc:
            return md_bytes, FORMAT_MD, (
                f"pandoc не оставил файл ({exc}) — сохранён .md вместо .{fmt}"
            )
    if not data:
        return md_bytes, FORMAT_MD, f"pandoc вернул пустой файл — сохранён .md вместо .{fmt}"
    return data, fmt, ""


# Известный sha по адресу: ``(root_name, rel_path) -> sha256 нашей последней доставки | None``.
KnownSha = Callable[[str, str], str | None]


def _result(
    written: dict[str, Any], target: WriteTarget, *, used: str, requested: str, warning: str,
    alias: str | None, outcome: str, **extra: Any,
) -> dict[str, Any]:
    return {
        "ok": True,
        "path": written["path"],
        "abs_path": written["abs_path"],  # CONTRACT-1 ФП-7 (Д12) — форма для lift_source
        "root_name": target.root_name,
        "size": written["size"],
        "sha256": written["sha256"],
        "format_used": used,
        "requested_format": requested,
        "existed": written["existed"],
        "overwritten": written["overwritten"],
        "outcome": outcome,
        "alias": alias,
        "warning": warning,
        **extra,
    }


def _write_owned(
    target: WriteTarget, data: bytes, *, overwrite: bool, known_sha: KnownSha | None,
) -> tuple[dict[str, Any], str]:
    """Запись с правом на СВОЙ файл (DELIVER-2 п.1): ``(результат write_atomic, outcome)``.

    ``outcome``: ``created`` (файла не было) | ``existed`` (байт-идентичный, не переписан) |
    ``updated`` (на диске ровно та версия, что мы доставили в прошлый раз - наш файл, перезапись без
    ``overwrite``) | ``overwritten`` (отличающийся файл затерт явным ``overwrite=True``).

    Файл с другим sha (правили снаружи либо он вообще чужой) без ``overwrite=True`` -
    ``exists_differs``; если по этому адресу у нас есть своя запись, ответ говорит, что sha
    разошелся с нашей доставкой (``ours_sha256``/``disk_sha256``), иначе - что файл чужой."""
    disk_sha = sha256_file(target.path) if target.path.is_file() else None
    ours = known_sha(target.root_name, target.rel_path) if known_sha else None
    own_file = bool(ours and disk_sha and disk_sha == ours)
    try:
        written = write_atomic(target, data, overwrite=overwrite or own_file)
    except WriteTargetError as exc:
        if exc.code != "exists_differs":
            raise
        details: dict[str, Any] = {"path": target.rel_path, "root_name": target.root_name,
                                   "disk_sha256": disk_sha, "ours_sha256": ours}
        if ours:
            message = (
                f"файл существует и отличается: {target.rel_path} - sha на диске "
                f"{(disk_sha or '')[:12]} разошелся с нашей доставкой {ours[:12]} (файл правили "
                "снаружи); overwrite=True затрет эти правки"
            )
        else:
            message = (
                f"файл существует и отличается: {target.rel_path} - это не наша доставка "
                "(в мете выхода записи о нем нет); нужен overwrite=True"
            )
        raise DeliverError(message, "exists_differs", details) from exc
    if not written["overwritten"]:
        outcome = "existed" if written["existed"] else "created"
    else:
        outcome = "updated" if own_file and not overwrite else "overwritten"
    return written, outcome


def deliver_text(
    text: str,
    dest: str,
    *,
    file_name: str,
    format: str | None = FORMAT_MD,  # имя параметра — из контракта ФТ-4 (не builtins)
    root_name: str = DEFAULT_ROOT_NAME,
    overwrite: bool = False,
    vault_path: Path | None = None,
    known_sha: KnownSha | None = None,
) -> dict[str, Any]:
    """Собрать файл из ``text`` локально и положить в папку ``dest`` под ingest-корнем.

    ``dest`` — алиас папки (ФТ-2) либо путь относительно ``root_name``; ``file_name`` —
    имя без пути (расширение подставляется по фактическому формату); ``format`` ∈
    :data:`FORMATS`. Гарды и семантика перезаписи — общий write-слой (containment/NDA/
    байт-идентичный ``existed``/отличающийся требует ``overwrite``).

    **DELIVER-2.** ``known_sha(root_name, rel_path)`` - sha256 нашей прошлой доставки по этому
    адресу (из ``meta.yaml: delivered`` выхода): файл на диске с таким sha - СВОЙ, он
    перезаписывается без ``overwrite`` (``outcome: updated``); с другим - отказ
    ``exists_differs`` как раньше, но с причиной (sha разошелся с нашей доставкой / файл чужой).

    Возврат ``{ok, path, abs_path, root_name, size, sha256, format_used, requested_format, existed,
    overwritten, outcome, alias, warning}`` (``path`` — относительный корню, posix; ``warning`` —
    пустая строка, если формат собрался как просили). Отказ — :class:`DeliverError` с ``code``.
    """
    if not text or not str(text).strip():
        raise DeliverError("нечего доставлять: пустой текст", "empty_text")
    requested = _normalize_format(format)
    data, used, warning = _convert(text, requested)
    try:
        target, alias = resolve_dest_target(
            dest, _base_name(file_name, used), root_name=root_name, vault_path=vault_path
        )
        written, outcome = _write_owned(target, data, overwrite=overwrite, known_sha=known_sha)
    except WriteTargetError as exc:
        raise DeliverError(str(exc), exc.code) from exc
    return _result(written, target, used=used, requested=requested, warning=warning,
                   alias=alias, outcome=outcome)


def deliver_text_to_output_dir(
    text: str,
    out_dir: Path,
    *,
    file_name: str,
    vault_root: Path,
    format: str | None = FORMAT_DOCX,  # имя параметра — из контракта ФТ-4 (не builtins)
    overwrite: bool = False,
    known_sha: KnownSha | None = None,
) -> dict[str, Any]:
    """DELIVER-2 п.3: «файл в чате» - собрать формат из ``text`` и положить В ПАПКУ ВЫХОДА.

    ``format`` без ``dest``: хост получает файл, не собирая его своим инструментом, а он сразу
    оказывается рядом с провенансом (``07-outputs/<месяц>/<task>/<task>.<fmt>``). Гард - только эта
    папка: цель ``(out_dir / имя).resolve()`` обязана лежать под ``out_dir`` (имя - без путей), не
    ``_nda``; ingest-корни не затрагиваются. Семантика перезаписи - как у :func:`deliver_text`.

    ``md`` (и откат на ``md``: нет pandoc/pdf-движка/сбой) отдельным файлом НЕ пишется:
    ``output.md`` уже есть, а второй ``.md`` без frontmatter попал бы в индекс дублем - ответ
    указывает на ``output.md`` (``format_used: md``, ``warning`` при откате). Возврат - как у
    :func:`deliver_text` + ``in_output_dir: True``; ``root_name`` - ``vault``, ``path`` - от
    корня vault."""
    from core.output import VAULT_ROOT_NAME

    if not text or not str(text).strip():
        raise DeliverError("нечего доставлять: пустой текст", "empty_text")
    requested = _normalize_format(format)
    data, used, warning = _convert(text, requested)
    out_dir = Path(out_dir).resolve()
    vault_root = Path(vault_root).resolve()
    if used == FORMAT_MD:
        note = out_dir / "output.md"
        return {
            "ok": True, "path": note.relative_to(vault_root).as_posix() if note.is_relative_to(
                vault_root) else str(note),
            "abs_path": str(note), "root_name": VAULT_ROOT_NAME, "size": len(data),
            "sha256": "", "format_used": FORMAT_MD, "requested_format": requested,
            "existed": True, "overwritten": False, "outcome": "existed", "alias": None,
            "warning": warning, "in_output_dir": True, "file_written": False,
        }
    name = _base_name(file_name, used)
    target_path = (out_dir / name).resolve()
    if target_path.parent != out_dir or is_nda(target_path):
        raise DeliverError(f"цель вне папки выхода или NDA: {name!r}", "containment")
    if not target_path.is_relative_to(vault_root):
        raise DeliverError("папка выхода вне vault - запись запрещена", "containment")
    target = WriteTarget(
        root_name=VAULT_ROOT_NAME, root_dir=vault_root, path=target_path,
        rel_path=target_path.relative_to(vault_root).as_posix(),
    )
    try:
        written, outcome = _write_owned(target, data, overwrite=overwrite, known_sha=known_sha)
    except WriteTargetError as exc:
        raise DeliverError(str(exc), exc.code) from exc
    return _result(written, target, used=used, requested=requested, warning=warning,
                   alias=None, outcome=outcome, in_output_dir=True, file_written=True)
