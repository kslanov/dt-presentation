"""DEV-1D-DETECT — два детерминированных детектора в ленту «Требует внимания».

Оба сигнала не покрыты ничем существующим (проверено по коду, ТЗ §Анализ):

* **«заметка-сирота»** (:func:`orphan_notes`) — свежая заметка vault, которая не
  привязана ни к чему: не лежит в папке хаба, не ссылается на хаб и не имеет секции
  «## Связано». Такая заметка выпадает из всех остальных контуров: `attention` смотрит
  Timetta и почту, `stale` — остывание сущностей, `hub_candidates` — сделки без хаба,
  `ripe_leads` — зрелость хабов. Заметка без связей просто тихо лежит и не находится;
* **«дедлайн хаба»** (:func:`hub_deadlines`) — поле ``deadline:`` во frontmatter
  workspace-хабов ``03-projects``. Сегодня оно читается ТОЛЬКО в ``ripe_leads`` как
  один из сигналов зрелости лида, то есть срок по проекту, у которого уже есть хаб, в
  «Внимание» не попадает вообще. Парсинг даты и обход хабов взяты из общего
  :mod:`core.operational.hub_meta` — второй копии парсера нет (требование ТЗ).

Оба возвращают пункты в **той же форме**, что остальные пункты attention-ленты
(``{type, id, title, as_of, …}``), поэтому dismiss/snooze работают штатным
:func:`core.operational.work.record_dismissal`, а сортировку/потолок делает
``work._attention`` — фронт ничего не считает (принцип 14).

Пороги — env-ручки: ``DT_ORPHAN_DAYS`` (7), ``DT_ORPHAN_MAX`` (5),
``DT_DEADLINE_WARN_DAYS`` (7), ``DT_DEADLINE_MAX`` (5). Read-only, без сети/LLM;
``core`` ⊥ mcp/cli.
"""

from __future__ import annotations

import os
import re
from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import default_vault_path
from core.operational.hub_meta import HUB_DIR, as_datetime, first_present, hub_deadline
from core.vault import read_note

__all__ = [
    "TYPE_ORPHAN",
    "TYPE_DEADLINE_SOON",
    "TYPE_DEADLINE_OVERDUE",
    "ORPHAN_DAYS",
    "ORPHAN_MAX",
    "DEADLINE_WARN_DAYS",
    "DEADLINE_MAX",
    "orphan_notes",
    "hub_deadlines",
    "SKIP_DIRS",
]

TYPE_ORPHAN = "orphan_note"
TYPE_DEADLINE_SOON = "hub_deadline_soon"
TYPE_DEADLINE_OVERDUE = "hub_deadline_overdue"

ORPHAN_DAYS = 7.0
ORPHAN_MAX = 5
DEADLINE_WARN_DAYS = 7.0
DEADLINE_MAX = 5

# Ветки vault, которые сиротами быть не могут by design: легаси-корпус (там заметки
# живут пачками и связываются отдельным проходом linking), системные файлы, папки
# генераций и эталоны стиля. Иначе детектор утонул бы в 12k легаси-заметок.
SKIP_DIRS: frozenset[str] = frozenset({"_legacy", "_system", "07-outputs", "01-style",
                                       "_staging", ".obsidian", ".git"})

# Поля frontmatter, любое непустое из которых означает «заметка к чему-то привязана»
# (клиент/хаб/сделка/направление/продукт — в vault это ссылки на хабы).
_HUB_FIELDS = ("client", "hub", "project", "deal", "direction", "product", "entity_ref")

# Секция связей, которую проставляет linking (наличие = заметка вписана в граф).
_LINKS_HEADING_RE = re.compile(r"^##\s+Связано\s*$", re.MULTILINE)
# Викилинк в теле — тоже привязка (человек связал руками, до прохода linking).
_WIKILINK_RE = re.compile(r"\[\[([^\]]+)\]\]")


def _env_float(name: str, default: float) -> float:
    raw = (os.environ.get(name) or "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


def _env_int(name: str, default: int) -> int:
    raw = (os.environ.get(name) or "").strip()
    return int(raw) if raw.isdigit() and int(raw) > 0 else default


def _iso_z(dt: datetime) -> str:
    return dt.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _days(later: datetime, earlier: datetime) -> float:
    return max(0.0, (later - earlier).total_seconds()) / 86400


def _note_time(fm: dict[str, Any], path: Path) -> datetime | None:
    """Время заметки: frontmatter ``modified``/``created``/``date`` → иначе mtime файла."""
    dt = as_datetime(first_present(fm, "modified", "created", "date"))
    if dt is not None:
        return dt
    try:
        return datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
    except OSError:
        return None


def _folder_has_hub(folder: Path, cache: dict[Path, bool]) -> bool:
    """Есть ли в папке (или выше, до 2 уровней) файл-хаб — «заметка внутри хаба».

    Хаб-заметка кладётся в корень папки рабочего пространства, а материалы — рядом
    и в подпапках, поэтому смотрим на папку заметки и двух её родителей. Результат
    кэшируется: у одной папки обычно много заметок.
    """
    for level, candidate in enumerate([folder, folder.parent, folder.parent.parent]):
        if level and candidate == folder:  # корень vault — дальше не идём
            break
        if candidate in cache:
            if cache[candidate]:
                return True
            continue
        found = False
        try:
            for md in candidate.glob("*.md"):
                try:
                    if read_note(md).frontmatter.get("type") == "hub":
                        found = True
                        break
                except (OSError, ValueError):
                    continue
        except OSError:
            found = False
        cache[candidate] = found
        if found:
            return True
    return False


def _is_linked(fm: dict[str, Any], body: str) -> bool:
    """Привязана ли заметка: поле-хаб во frontmatter, «## Связано» или викилинк."""
    for field in _HUB_FIELDS:
        value = fm.get(field)
        if isinstance(value, (list, tuple)):
            if any(str(v).strip() for v in value):
                return True
        elif str(value or "").strip():
            return True
    if _LINKS_HEADING_RE.search(body):
        return True
    return bool(_WIKILINK_RE.search(body))


def _candidate_notes(vault: Path) -> Iterator[Path]:
    """Заметки vault ВНЕ служебных ветвей — обходя :data:`SKIP_DIRS` целиком.

    Важно не «отфильтровать после rglob», а не заходить внутрь: в ``_legacy`` лежат
    12,6k заметок, и один их обход стоил 360 мс на КАЖДОМ рендере «Работы» (замер на
    живом хранилище) — тот самый класс, который PERF-3 убирал с рендер-пути. Обход по
    верхним каталогам вместо ``vault.rglob`` возвращает стоимость к десяткам мс.
    """
    yield from sorted(vault.glob("*.md"))  # заметки в корне vault
    for top in sorted(vault.iterdir()):
        if not top.is_dir() or top.name in SKIP_DIRS:
            continue
        yield from sorted(top.rglob("*.md"))


def orphan_notes(
    *,
    vault_path: Path | None = None,
    now: datetime | None = None,
    max_items: int | None = None,
) -> list[dict[str, Any]]:
    """Свежие заметки vault без хаба и без связей → пункты attention-ленты.

    Свежесть — ``modified``/``created`` (иначе mtime файла) не старше
    ``DT_ORPHAN_DAYS`` (7). Пропускаются служебные ветки (:data:`SKIP_DIRS`) и сами
    хабы. Возврат — не больше ``DT_ORPHAN_MAX`` (5) пунктов, самые свежие первыми:
    порог шума важнее полноты, лента должна оставаться читаемой.

    Пункт: ``{type: "orphan_note", id: "orphan:<vault-путь>", title, note_path,
    note_name, as_of, age_days}`` — ``id`` стабилен (путь), поэтому «привязал →
    ушла» и dismiss работают без нового стейта.
    """
    now = now or datetime.now(UTC)
    vault = Path(vault_path) if vault_path else default_vault_path()
    window = _env_float("DT_ORPHAN_DAYS", ORPHAN_DAYS)
    cap = max_items if max_items is not None else _env_int("DT_ORPHAN_MAX", ORPHAN_MAX)
    if not vault.is_dir():
        return []

    hub_cache: dict[Path, bool] = {}
    found: list[tuple[float, dict[str, Any]]] = []
    for path in _candidate_notes(vault):
        rel = path.relative_to(vault)
        # Дешёвый префильтр по mtime ДО парсинга: детектор смотрит только свежие
        # заметки, а ``read_note`` (чтение + YAML) в разы дороже ``stat``. Иначе скан
        # рос бы линейно по всему курируемому vault на КАЖДОМ рендере «Работы» — тот
        # самый класс, что PERF-3 убирал с рендер-пути (замер: 360 мс → десятки).
        # Правка frontmatter меняет mtime файла, поэтому «свежее по mtime» —
        # надмножество «свежего по датам frontmatter»: точное решение ниже.
        try:
            if _days(now, datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)) > window:
                continue
        except OSError:
            continue
        try:
            note = read_note(path)
        except (OSError, ValueError):
            continue
        fm = note.frontmatter
        if fm.get("type") == "hub":
            continue  # хаб сам по себе не сирота — он и есть точка привязки
        when = _note_time(fm, path)
        if when is None or _days(now, when) > window:
            continue
        if _is_linked(fm, note.body or ""):
            continue
        if _folder_has_hub(path.parent, hub_cache):
            continue
        title = str(fm.get("title") or "").strip() or path.stem
        found.append((
            when.timestamp(),
            {
                "type": TYPE_ORPHAN,
                "id": f"orphan:{rel.as_posix()}",
                "title": title,
                "note_path": rel.as_posix(),
                "note_name": path.stem,
                "as_of": _iso_z(when),
                "age_days": round(_days(now, when), 1),
            },
        ))

    found.sort(key=lambda pair: pair[0], reverse=True)
    return [item for _, item in found[:cap]]


def hub_deadlines(
    *,
    vault_path: Path | None = None,
    now: datetime | None = None,
    max_items: int | None = None,
) -> list[dict[str, Any]]:
    """Дедлайны workspace-хабов (``03-projects``) → пункты attention-ленты.

    ``deadline:``/``due:`` во frontmatter хаба: просрочен → ``hub_deadline_overdue``
    (с ``days_overdue``), в пределах ``DT_DEADLINE_WARN_DAYS`` (7) →
    ``hub_deadline_soon`` (с ``days_until``). Дальше окна и без поля — молчим.
    Потолок ``DT_DEADLINE_MAX`` (5): сначала просроченные, потом ближайшие.

    Пункт: ``{type, id: "hub_deadline:<id хаба>", title, hub: {id, name}, due,
    as_of, days_overdue|days_until, note_path}``. ``as_of`` = дата дедлайна, поэтому
    ack держится до её сдвига (перенесли срок → пункт вернётся).
    """
    now = now or datetime.now(UTC)
    vault = Path(vault_path) if vault_path else default_vault_path()
    window = _env_float("DT_DEADLINE_WARN_DAYS", DEADLINE_WARN_DAYS)
    cap = max_items if max_items is not None else _env_int("DT_DEADLINE_MAX", DEADLINE_MAX)

    from core.operational.hub_meta import iter_hubs

    items: list[dict[str, Any]] = []
    for path, note in iter_hubs(vault, subdir=HUB_DIR):
        fm = note.frontmatter
        due = hub_deadline(fm)
        if due is None:
            continue
        hub_id = str(fm.get("id") or path.stem)
        aliases = fm.get("aliases") or []
        if isinstance(aliases, str):
            aliases = [aliases]
        name = str(aliases[0]) if aliases else hub_id
        try:
            rel = path.relative_to(vault).as_posix()
        except ValueError:  # pragma: no cover
            rel = path.name
        base = {
            "id": f"hub_deadline:{hub_id}",
            "title": name,
            "hub": {"id": hub_id, "name": name},
            "due": _iso_z(due),
            "as_of": _iso_z(due),
            "note_path": rel,
        }
        if due < now:
            items.append({**base, "type": TYPE_DEADLINE_OVERDUE,
                          "days_overdue": round(_days(now, due))})
        elif _days(due, now) <= window:
            items.append({**base, "type": TYPE_DEADLINE_SOON,
                          "days_until": round(_days(due, now))})

    def _key(item: dict[str, Any]) -> tuple[int, float]:
        if item["type"] == TYPE_DEADLINE_OVERDUE:
            return (0, -float(item.get("days_overdue", 0)))
        return (1, float(item.get("days_until", 0)))

    items.sort(key=_key)
    return items[:cap]
