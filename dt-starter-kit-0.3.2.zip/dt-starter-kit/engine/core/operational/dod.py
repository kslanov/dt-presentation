"""DOD-1 — видимость незакрытого контура: файл в хранилище без output-заметки.

Кейс (2026-08-04): чат работал с движком сырыми MCP-инструментами, положил в
хранилище артефакты и **не вернул результат в vault** — заметки-output не появилось.
Никто бы этого не заметил: файлы легли штатно, аудит записал запись, а отсутствие
закрывающего шага не оставляет следа вовсе. Третий слой разбора кейса именно про это:
**нарушение правила невидимо**, а невидимое нарушение не лечится напоминаниями.

Здесь — дешёвая проверка «контур не закрыт»: из аудит-лога берутся доставки файлов за
окно (env ``DT_DOD_WINDOW_H``, дефолт 48 ч) и сверяются с секцией «## Файлы» заметок
``07-outputs/**/output.md``. Не упомянут — значит файл лежит, а output-заметки с ним
нет. :mod:`core.diagnostics` показывает это одной строкой ``doctor``.

Сознательные решения:

* это **warning-nudge, а не fail**: файл, положенный без генерации (пришёл от клиента,
  сложили в папку) — легитимный случай, и ложные срабатывания здесь дешевле пропусков;
* окно ограничивает и объём работы, и «вечный» укор за старое: 48 ч — это про «закрой
  то, что делаешь сейчас»;
* заметки сканируются только те, что менялись в окне. Регистрация файла происходит
  ПОСЛЕ его доставки (``save_output(file_refs=…)`` перезаписывает заметку), поэтому
  mtime упоминающей заметки не может быть раньше начала окна — скан остаётся дешёвым
  и не зависит от того, сколько всего папок накопилось в ``07-outputs``.

**DOD-2** (фейлкейс 2026-08-11, 3-е повторение класса) добавляет второй слепой угол
того же контура: папку выхода, которая **начата и не закрыта** — нет ``output.md`` или
мета всё ещё ``status: draft``. Такая полу-папка «выглядит оформленной», поэтому её
никто не замечает; :func:`draft_outputs` показывает её доктору через сутки (env
``DT_OUTPUT_DRAFT_WARN_H``).

Read-only и без сети; ``core`` ⊥ mcp/cli.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

from core.config import outputs_path
from core.operational.pult import actions_log_path

__all__ = [
    "Delivery",
    "DELIVERY_TOOLS",
    "DEFAULT_WINDOW_H",
    "window_hours",
    "recent_deliveries",
    "unregistered_deliveries",
    "DraftOutput",
    "DEFAULT_DRAFT_WARN_H",
    "draft_warn_hours",
    "draft_outputs",
    "outputs_without_sources",
]

# Инструменты, чья аудит-строка означает «файл лёг в рабочую папку»: base64-канал
# (ФТ-5 ``store_file_commit`` — тот же класс, порционно), перенос скачанного (ФТ-1) и
# одиночный ``store_file``. ``save_output(dest=…)`` (ФТ-4) сюда НЕ входит: он сам
# прописывает путь в ``file_refs``, то есть закрывает контур в том же вызове (и его
# аудит-строка несёт ``dest=``, а не ``rel_path=``).
DELIVERY_TOOLS = ("store_file", "place_download", "store_file_commit")

# Исходы, при которых файл действительно оказался в хранилище (``existed`` — повтор с
# теми же байтами: файл там есть, регистрации это не отменяет).
_DELIVERED_OUTCOMES = ("stored", "overwritten", "placed", "existed")

DEFAULT_WINDOW_H = 48.0
_WINDOW_ENV = "DT_DOD_WINDOW_H"

# DOD-2 — сколько часов папке выхода можно простоять недооформленной, прежде чем
# доктор про неё скажет. Сутки: за это время сессия либо закрыла контур, либо уже не
# закроет сама (и о ней надо знать, пока провенанс ещё восстановим).
DEFAULT_DRAFT_WARN_H = 24.0
_DRAFT_WARN_ENV = "DT_OUTPUT_DRAFT_WARN_H"

# Аудит-строка: ``<ts> <tool> k=v k=v … outcome=…``. Значение может содержать пробелы
# (кириллические пути «Подводные технологии/КП.docx»), поэтому берём его до следующего
# ``ключ=`` — не по простому split.
_ARG_RE = re.compile(r"(\w+)=(.*?)(?=\s+\w+=|$)")

# Сколько последних строк аудита разбирать (потолок от разрастания лога; при одной
# строке на привилегированное действие этого хватает на месяцы).
_TAIL_LINES = 5000


@dataclass(frozen=True)
class Delivery:
    """Одна доставка файла из аудита: инструмент, корень, путь, время, размер."""

    tool: str
    root: str
    rel_path: str
    at: datetime
    size: int = 0

    @property
    def label(self) -> str:
        """Человекочитаемый адрес файла (``корень/путь``) — как в ``file_refs``."""
        return f"{self.root}/{self.rel_path}" if self.root else self.rel_path


def window_hours() -> float:
    """Окно проверки, часы (env ``DT_DOD_WINDOW_H``, дефолт 48; мусор → дефолт)."""
    raw = os.environ.get(_WINDOW_ENV, "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_WINDOW_H
    return value if value > 0 else DEFAULT_WINDOW_H


def _parse_ts(token: str) -> datetime | None:
    try:
        return datetime.strptime(token, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    except (ValueError, TypeError):
        return None


def _parse_line(line: str) -> Delivery | None:
    """Аудит-строка → :class:`Delivery`, либо ``None`` (не про доставку файла)."""
    parts = line.strip().split(" ", 2)
    if len(parts) < 3:
        return None
    at = _parse_ts(parts[0])
    tool = parts[1]
    if at is None or tool not in DELIVERY_TOOLS:
        return None
    args = {k: v.strip() for k, v in _ARG_RE.findall(parts[2])}
    if args.get("outcome") not in _DELIVERED_OUTCOMES:
        return None
    rel_path = args.get("rel_path", "")
    if not rel_path:
        return None
    from core.privacy import is_eval

    if is_eval(rel_path):  # EVAL-HYGIENE-1: доставка прогона в карантин - не «незакрытый контур»
        return None
    size_raw = args.get("size", "0")
    return Delivery(
        tool=tool,
        root=args.get("root", ""),
        rel_path=rel_path,
        at=at,
        size=int(size_raw) if size_raw.isdigit() else 0,
    )


def recent_deliveries(
    *, now: datetime | None = None, window_h: float | None = None
) -> list[Delivery]:
    """Доставки файлов из аудита за окно — новые сверху, дубли по пути сняты."""
    path = actions_log_path()
    if not path.is_file():
        return []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    hours = window_h if window_h is not None and window_h > 0 else window_hours()
    cutoff = (now or datetime.now(UTC)) - timedelta(hours=hours)
    out: list[Delivery] = []
    seen: set[str] = set()
    for line in reversed(lines[-_TAIL_LINES:]):
        item = _parse_line(line)
        if item is None:
            continue
        if item.at < cutoff:
            break  # лог хронологический: дальше только старее
        if item.label in seen:
            continue
        seen.add(item.label)
        out.append(item)
    return out


def _registration_text(
    *, vault_path: Path | None = None, now: datetime | None = None,
    window_h: float | None = None,
) -> str:
    """Слитый текст ``output.md``-заметок, менявшихся в окне (где живут ``file_refs``).

    Заметки старше окна не читаем: регистрация файла (перезапись заметки с секцией
    «## Файлы») всегда происходит ПОСЛЕ доставки, значит упоминание доставки из окна
    может лежать только в заметке, тронутой в этом же окне.
    """
    root = outputs_path(vault_path)
    if not root.is_dir():
        return ""
    hours = window_h if window_h is not None and window_h > 0 else window_hours()
    cutoff = ((now or datetime.now(UTC)) - timedelta(hours=hours)).timestamp()
    chunks: list[str] = []
    for note in root.rglob("output.md"):
        try:
            if note.stat().st_mtime < cutoff:
                continue
            chunks.append(note.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            continue
    return "\n".join(chunks)


def unregistered_deliveries(
    *, vault_path: Path | None = None, now: datetime | None = None,
    window_h: float | None = None,
) -> list[Delivery]:
    """Файлы, доставленные за окно и НЕ упомянутые ни в одной заметке-output.

    Совпадение ищется по подстроке пути: ``file_refs`` может быть как
    ``корень/путь``, так и просто путём — обе формы содержат ``rel_path``.
    Пусто → контур закрыт (или доставок в окне не было).
    """
    deliveries = recent_deliveries(now=now, window_h=window_h)
    if not deliveries:
        return []
    text = _registration_text(vault_path=vault_path, now=now, window_h=window_h)
    return [d for d in deliveries if d.rel_path not in text]


# --------------------------------------------------------------------------- #
# DOD-2 — недооформленный выход (битый контур виден за сутки)                  #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class DraftOutput:
    """Папка выхода, оставшаяся недооформленной: адрес, возраст, чего не хватает."""

    rel_path: str  # ``YYYY-MM/<task-id>`` — как в 07-outputs
    age_h: float
    reason: str

    @property
    def label(self) -> str:
        return f"{self.rel_path} ({self.age_h:.0f} ч, {self.reason})"


def draft_warn_hours() -> float:
    """Порог «недооформлено», часы (env ``DT_OUTPUT_DRAFT_WARN_H``, дефолт 24)."""
    raw = os.environ.get(_DRAFT_WARN_ENV, "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_DRAFT_WARN_H
    return value if value > 0 else DEFAULT_DRAFT_WARN_H


def _is_run(task_dir: Path) -> bool:
    """EVAL-HYGIENE-1: папка - прогон eval/selftest (``purpose != work``), не «незакрытый» выход."""
    from core.output import read_meta
    from core.purpose import is_quarantined

    return is_quarantined(read_meta(task_dir / "meta.yaml"))


def _meta_status_and_created(task_dir: Path) -> tuple[str, float | None]:
    """``meta.yaml`` папки → (status, время заявки как timestamp).

    Нет меты / битая YAML / нет ``created`` → ``("", None)``: возраст берётся по
    mtime папки. Читаем только мету (килобайты), не ``output.md`` и не ``prompt.md``;
    парсер один и тот же с записью контура (:func:`core.output.read_meta`).
    """
    from core.output import read_meta

    data = read_meta(task_dir / "meta.yaml")
    if not data:
        return "", None
    status = str(data.get("status") or "").strip().lower()
    raw_created = str(data.get("created") or "").strip()
    try:
        created = datetime.fromisoformat(raw_created).timestamp() if raw_created else None
    except ValueError:
        created = None
    return status, created


def draft_outputs(
    *, vault_path: Path | None = None, now: datetime | None = None,
    warn_h: float | None = None,
) -> list[DraftOutput]:
    """Папки ``07-outputs/**``, где контур начат и не закрыт дольше порога.

    Недооформлено = нет ``output.md`` (работа не вернулась) ИЛИ ``meta.yaml`` всё ещё
    ``status: draft`` (:func:`core.output.finalize_output` не вызывался). Свежие не
    показываем: папка в работе — норма, ругаться на неё значило бы приучить пропускать
    предупреждение. Возраст — от ``created`` из меты (устойчиво к линковке/переиндексу),
    без него — от mtime папки.

    Старейшие сверху. Read-only: листинг двух уровней каталогов + ``meta.yaml``.
    """
    root = outputs_path(vault_path)
    if not root.is_dir():
        return []
    hours = warn_h if warn_h is not None and warn_h > 0 else draft_warn_hours()
    stamp = (now or datetime.now(UTC)).timestamp()
    out: list[DraftOutput] = []
    for month_dir in sorted(root.iterdir()):
        if not month_dir.is_dir():
            continue
        for task_dir in sorted(month_dir.iterdir()):
            if not task_dir.is_dir() or _is_run(task_dir):
                continue
            has_output = (task_dir / "output.md").is_file()
            status, created = _meta_status_and_created(task_dir)
            if has_output and status != "draft":
                continue  # закрытый выход (или папка, у которой статуса нет вовсе)
            if created is None:
                try:
                    created = task_dir.stat().st_mtime
                except OSError:
                    continue
            age_h = (stamp - created) / 3600.0
            if age_h < hours:
                continue  # ещё в работе — не шумим
            reason = "нет output.md" if not has_output else "status: draft"
            out.append(
                DraftOutput(
                    rel_path=f"{month_dir.name}/{task_dir.name}",
                    age_h=age_h,
                    reason=reason,
                )
            )
    return sorted(out, key=lambda d: d.age_h, reverse=True)


def outputs_without_sources(
    *, vault_path: Path | None = None, now: datetime | None = None,
    warn_h: float | None = None,
) -> list[DraftOutput]:
    """Закрытые ad-hoc-выходы БЕЗ ``sources.md`` (SRC-TRACE-2), старше порога.

    Третий слепой угол того же контура. Дефект 2 фейлкейса 2026-08-11: ad-hoc-выход с
    16 первоисточниками получил ноль машиночитаемого провенанса — и это не было видно
    НИГДЕ (выход выглядел оформленным: мета, постановка, текст на месте). Инверсия
    против движкового пути, где ``sources.md`` пишется всегда.

    Считаем недотрассированным выход, у которого: есть ``output.md`` (работа
    вернулась — незакрытые показывает :func:`draft_outputs`, дублировать не нужно),
    мета говорит ``engine_run: false`` (движок подбора не участвовал ⇒ sources.md
    должен собраться телеметрией/руками), а ``sources.md`` отсутствует или пуст.
    Папки от ``generate`` (без ``engine_run``) сюда не попадают by design.

    Порог и механика — те же, что у draft-гарда (``DT_OUTPUT_DRAFT_WARN_H``): свежий
    выход в работе не шумит. Старейшие сверху. Read-only.
    """
    from core.output import read_meta

    root = outputs_path(vault_path)
    if not root.is_dir():
        return []
    hours = warn_h if warn_h is not None and warn_h > 0 else draft_warn_hours()
    stamp = (now or datetime.now(UTC)).timestamp()
    out: list[DraftOutput] = []
    for month_dir in sorted(root.iterdir()):
        if not month_dir.is_dir():
            continue
        for task_dir in sorted(month_dir.iterdir()):
            if not task_dir.is_dir() or not (task_dir / "output.md").is_file():
                continue
            meta = read_meta(task_dir / "meta.yaml")
            if meta.get("engine_run") is not False:
                continue  # движковый выход (или мета без пометки) — не наш случай
            if _is_run(task_dir):
                continue  # прогон eval/selftest: провенанс источников от него не требуется
            sources = task_dir / "sources.md"
            try:
                has_sources = sources.is_file() and sources.stat().st_size > 0
            except OSError:
                has_sources = False
            if has_sources:
                continue
            _status, created = _meta_status_and_created(task_dir)
            if created is None:
                try:
                    created = task_dir.stat().st_mtime
                except OSError:
                    continue
            age_h = (stamp - created) / 3600.0
            if age_h < hours:
                continue
            out.append(
                DraftOutput(
                    rel_path=f"{month_dir.name}/{task_dir.name}",
                    age_h=age_h,
                    reason="нет sources.md",
                )
            )
    return sorted(out, key=lambda d: d.age_h, reverse=True)
