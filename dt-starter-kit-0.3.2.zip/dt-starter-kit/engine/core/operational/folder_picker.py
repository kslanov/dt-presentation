"""Native Finder folder picker via ``osascript`` (PULT-FOLDER-PICKER PART-1).

A browser / Cowork artifact cannot open a native Finder and return an absolute
path (JS sandbox; ``<input webkitdirectory>`` yields relative file names, not the
folder path). The only real folder chooser is the host's
``osascript 'choose folder'`` — the same host-AppleScript pattern the Outlook
bridge already uses (:func:`core.operational.outlook_bridge._run_applescript`:
subprocess + timeout, graceful on non-macOS).

This is a **UI helper**, not Path-B inference: it returns a path the user picked
and writes nothing. Graceful by contract — dialog cancelled, ``osascript`` absent,
non-macOS, or a timeout all return ``None`` (never a crash). :func:`picker_available`
tells the caller whether a native picker is even possible (so a phone / web-pult /
non-macOS front-end can fall back to manual entry instead of a dead button).

Invariant: ``core/operational/folder_picker`` imports neither MCP nor CLI.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from collections.abc import Callable

from core.adapters import AdapterUnavailable

__all__ = ["choose_folder", "picker_available"]

# Bound the dialog wait so a forgotten-open picker never wedges the caller. The
# user has to actually click through Finder, so this is generous (not a fast op).
_DEFAULT_TIMEOUT = 120.0

# (cmd, timeout) -> (returncode, stdout, stderr). Injectable for tests.
Runner = Callable[[list[str], float], "tuple[int, str, str]"]


def _default_runner(cmd: list[str], timeout: float) -> tuple[int, str, str]:
    """Run ``cmd`` via subprocess, returning (returncode, stdout, stderr).

    Mirrors :func:`core.operational.outlook_bridge._default_runner` — one small
    subprocess wrapper, so tests inject a fake and the real path stays trivial.
    """
    proc = subprocess.run(  # noqa: S603 — cmd is a fixed osascript invocation
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _sanitize_prompt(prompt: str) -> str:
    """Make ``prompt`` safe to embed inside the AppleScript string literal.

    Escapes backslash and double-quote and drops control chars/newlines so the
    prompt cannot break out of the ``"…"`` literal or inject AppleScript.
    """
    text = str(prompt or "").replace("\\", "\\\\").replace('"', '\\"')
    return "".join(ch for ch in text if ch >= " ")[:200] or "Выберите папку"


def picker_available(*, runner: Runner | None = None) -> bool:
    """Whether a native Finder picker is possible here (macOS + ``osascript``).

    A cheap, read-only capability check (no dialog): ``osascript`` on ``PATH`` and
    a Darwin host. The front-end uses this to show the "Выбрать папку…" button only
    where it can work, and fall back to manual entry otherwise. ``runner`` is
    accepted for signature symmetry / future probes; the check itself opens nothing.
    """
    if sys.platform != "darwin":
        return False
    return shutil.which("osascript") is not None


def choose_folder(
    prompt: str = "Выберите папку",
    *,
    timeout: float = _DEFAULT_TIMEOUT,
    runner: Runner | None = None,
) -> str | None:
    """Open the native Finder folder chooser; return the POSIX path, or ``None``.

    Runs ``osascript -e 'POSIX path of (choose folder with prompt "…")'``. Returns
    the absolute path the user picked. Returns ``None`` for every non-selection:
    the user cancelled (``osascript`` exits non-zero, error ``-128``), ``osascript``
    is absent / this is not macOS (``FileNotFoundError``), the dialog timed out, or
    the output was empty. Другая ошибка AppleScript — :class:`~core.adapters.AdapterUnavailable`
    (не «отмена»). **Read-only** — it only reports a path, writes nothing.
    """
    run = runner or _default_runner
    script = f'POSIX path of (choose folder with prompt "{_sanitize_prompt(prompt)}")'
    try:
        code, stdout, stderr = run(["osascript", "-e", script], timeout)
    except FileNotFoundError:
        return None  # osascript absent (non-macOS / CI) — graceful, no crash
    except (subprocess.TimeoutExpired, OSError):
        return None
    if code != 0:
        # Отмена диалога (-128 / «User canceled») — штатное «ничего не выбрано». Любая ДРУГАЯ
        # ошибка AppleScript — сбой адаптера, а не «пользователь отменил» (ADAPTER-HONEST-1):
        # фронт должен увидеть причину, а не молча упасть на ручной ввод.
        low = (stderr or "").lower()
        if "-128" in low or "user canceled" in low or "user cancelled" in low:
            return None
        raise AdapterUnavailable(
            f"osascript choose folder: {(stderr or '').strip()[:160] or f'код {code}'}",
            adapter="folder_picker",
        )
    path = (stdout or "").strip()
    if not path:
        return None
    # `POSIX path of` a folder yields a trailing "/" — drop it for a tidy, dedup-
    # friendly path (but keep the filesystem root "/" itself).
    return path.rstrip("/") or "/"
