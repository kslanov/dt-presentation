"""FRESH-1 — монитор актуальности данных по источникам (пульт).

Основание — инцидент D7 «Надым»: письмо собиралось на данных «по 19.06», хотя
корпус содержал почту по 04.07, и отставание ниоткуда не было видно. Этот модуль
отвечает на «данные на момент X, отставание Y, последний прогон Z» по шести
источникам — читая ТОЛЬКО манифесты/курсоры/лог (без сети, без LLM и без
сканов тяжёлых директорий; бюджет выдачи < 200 мс):

* **mail** — max из последнего успешного прогона ``mail_ingest`` и ``max
  last_date`` манифеста (как ticktick: свежесть = ВРЕМЯ ОБНОВЛЕНИЯ, а не возраст
  самого свежего письма — иначе тихий день красил бы плитку при исправном
  ingest; прогон, недавний, доминирует над датой письма);
* **timetta** — mtime курсора зеркала (``.derived/timetta/cursor.json``
  переписывается каждым успешным pull — это «состояние сервера известно на»);
* **ticktick** — max из ``pulled_at`` dedup-state захвата и последнего
  успешного прогона ``pull_capture`` (state пишется только при НОВЫХ захватах,
  поэтому тихая неделя без захватов — не «протухшие данные»: пустой успешный
  pull тоже подтверждает состояние очереди);
* **index** — mtime манифеста индекса (7.8MB json НЕ парсится) + дельта:
  сколько заметок vault новее манифеста (быстрый scandir-обход, один stat на
  файл, те же правила обхода, что ``iter_vault_paths``);
* **linking** — mtime scan-манифеста линковки (``link_scan.json``);
* **files:knowledge** (WAVE1-MEASURE п.4) — ПОСЛЕДНИЙ ЗАВЕРШЁННЫЙ полный скан знаниевого
  корня (аудит-строка ``ingest_scan`` с ``outcome=ok``, не dry-run): шаг в dt-sync-логе
  отчитывается ``ok`` и после снятия сторожем (скан ловит SIGTERM и выходит с кодом 0), поэтому
  по нему «захват файлов стоит 4 дня» (аудит C10) был невидим. Рядом — ``pending_download``
  (dataless iCloud, последний проход) и число прогонов, снятых сторожем за 7 дн.

Последний прогон каждого шага (mail_ingest / refresh / pull_capture /
reindex_inc / link_auto) берётся из хвоста ``dt-sync.log`` — той же строки
``step <name>: ok|FAILED``, что пишет оркестратор.

Отсутствующий источник — честные ``null`` (``data_as_of``/``lag_h``/``stale``),
никогда не исключение: пульту нужна плитка «нет данных», а не стектрейс.
Stale-пороги — константы модуля (:data:`STALE_AFTER_H`, «протух, если не
обновлялся сутки+»).

Инвариант: ``core/`` ⊥ mcp/cli — ``pult_freshness`` в server.py лишь тонкая
обёртка над :func:`snapshot`.
"""

from __future__ import annotations

import json
import os
import re
import time
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import (
    index_manifest_path,
    link_scan_manifest_path,
    outlook_ingest_manifest_path,
    sync_log_path,
    ticktick_state_path,
    timetta_mirror_path,
)
from core.operational.synclog import iter_step_lines
from core.vault import INDEXED_UNDERSCORE_DIRS

__all__ = [
    "STALE_AFTER_H", "SOURCE_STEPS", "SOURCE_SYNC", "snapshot", "files_knowledge_state",
    "files_knowledge_row",
]

# INGRESS-1 п.1: таблицы свежести ПРОИЗВОДЯТСЯ из реестра адаптеров ``core.ingress.registry``
# (``freshness_key``/``stale_after_h``/``step``/``sync_steps``/``mode``) — отдельной копии списка
# источников входа здесь больше нет. Остаются только НЕ-входные источники ``index``/``linking``.
#
#   * ``STALE_AFTER_H`` — порог «протухания» per источник, часов: сутки + люфт на сдвиг
#     launchd-прогона; знаниевый скан (``files:knowledge``) идёт раз в сутки ночью и спокойно
#     пропускает ночь-две (сон ноутбука, снятый прогон) — красим после двух суток (48);
#   * ``SOURCE_STEPS`` — источник → шаг dt-sync, чей последний прогон показываем рядом;
#   * ``SOURCE_SYNC`` — «источник → (режим, шаги)» для точечной кнопки «обновить» на строке виджета
#     (``pult_run_sync(mode, steps=…)``): пульт берет карту из выдачи ``pult_freshness`` (поле
#     ``sync``), а не держит свою копию. Имена шагов сверяет с ``dt_sync.MODES``
#     ``tests/test_sync_steps.py``.
STALE_AFTER_H: dict[str, float] = {}
SOURCE_STEPS: dict[str, str] = {}
SOURCE_SYNC: dict[str, tuple[str, tuple[str, ...]]] = {}

# PERSONAL-3: источники вне реестра входа (индекс, линковка, мост) - в ``core.surface.manifest.
# STATIC_SOURCES`; таблицы ниже собираются ПО РОЛИ процесса (адаптеры по ``roles`` + статические).
# Порядок строк выдачи (то, что видит пульт): ``fresh_order`` адаптеров + статические.
SOURCE_ORDER: list[str] = []


def _rebuild_tables() -> None:
    """Пересобрать таблицы из реестра ПО РОЛИ процесса (на месте: ссылки остаются живыми)."""
    from core.ingress import registry
    from core.instance import instance_role
    from core.surface.manifest import STATIC_SOURCES

    role = instance_role()
    rows: list[tuple[int, str, float, str, tuple[str, tuple[str, ...]]]] = []
    for a in registry.adapters(role=role):
        if a.freshness_key and a.stale_after_h is not None and a.step:
            rows.append((a.fresh_order, a.freshness_key, a.stale_after_h, a.step,
                         (a.mode, a.sync_steps or (a.step,))))
    for key, order, hours, step, sync, roles in STATIC_SOURCES:
        if role in roles:
            rows.append((order, key, hours, step, sync))
    rows.sort(key=lambda r: r[0])
    for table in (STALE_AFTER_H, SOURCE_STEPS, SOURCE_SYNC):
        table.clear()
    SOURCE_ORDER[:] = [r[1] for r in rows]
    for _order, key, hours, step, sync in rows:
        STALE_AFTER_H[key] = hours
        SOURCE_STEPS[key] = step
        SOURCE_SYNC[key] = sync


# Окно подсчёта прогонов, снятых сторожем, и порог «размера» знаниевого прохода для старых
# аудит-строк без ``route`` (оперативный корень — десятки файлов, знаниевый — тысячи).
WATCHDOG_WINDOW_DAYS = 7
_LEGACY_KNOWLEDGE_MIN_SEEN = 500
_KILL_RE = re.compile(
    r"^(?P<ts>\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\S* .*\[runwatch\].*step=file_ingest_knowledge"
    r".*без прогресса (?P<min>\d+) мин"
)


def _to_utc(dt: datetime) -> datetime:
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)


def _iso_z(dt: datetime) -> str:
    return _to_utc(dt).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_iso(value: Any) -> datetime | None:
    """Толерантный ISO-8601 (``Z``/offset/naive→UTC) → aware datetime, else None."""
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        return _to_utc(datetime.fromisoformat(text))
    except ValueError:
        return None


def _mtime_utc(path: Path) -> datetime | None:
    """mtime файла как aware-UTC datetime; None, если файла нет/не читается."""
    try:
        return datetime.fromtimestamp(path.stat().st_mtime, UTC)
    except OSError:
        return None


def _load_json(path: Path) -> Any | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


# --------------------------------------------------------------------------- #
# Свежесть per источник (каждая функция: отсутствие данных → None)             #
# --------------------------------------------------------------------------- #
def _mail_data_as_of(manifest_path: Path) -> datetime | None:
    """max ``last_date`` по манифесту outlook-ingest (индекс тредов, не файлы)."""
    data = _load_json(manifest_path)
    if not isinstance(data, dict) or not data:
        return None
    latest: datetime | None = None
    for entry in data.values():
        if not isinstance(entry, dict):
            continue
        ts = _parse_iso(entry.get("last_date"))
        if ts is not None and (latest is None or ts > latest):
            latest = ts
    return latest


def _ticktick_data_as_of(state_path: Path) -> datetime | None:
    """max ``pulled_at`` по dedup-state захвата; fallback — mtime файла."""
    data = _load_json(state_path)
    if not isinstance(data, dict) or not data:
        return None
    latest: datetime | None = None
    for entry in data.values():
        if not isinstance(entry, dict):
            continue
        ts = _parse_iso(entry.get("pulled_at"))
        if ts is not None and (latest is None or ts > latest):
            latest = ts
    return latest or _mtime_utc(state_path)


def _count_notes_newer(vault_path: Path, ref_epoch: float) -> int | None:
    """Заметки vault новее ``ref_epoch`` — один scandir-проход, один stat на файл.

    Те же правила обхода, что ``iter_vault_paths`` (``_``/``.``-папки мимо,
    :data:`~core.vault.INDEXED_UNDERSCORE_DIRS` внутри), но без Path-обвязки и
    второго stat — на 12k заметок укладывается в десятки миллисекунд.
    """
    root = Path(vault_path)
    if not root.is_dir():
        return None
    newer = 0
    stack: list[str] = [str(root)]
    while stack:
        current = stack.pop()
        try:
            with os.scandir(current) as it:
                for entry in it:
                    name = entry.name
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            if name in INDEXED_UNDERSCORE_DIRS or not (
                                name.startswith("_") or name.startswith(".")
                            ):
                                stack.append(entry.path)
                        elif name.endswith(".md") and entry.stat().st_mtime > ref_epoch:
                            newer += 1
                    except OSError:
                        continue  # файл исчез между readdir и stat — не повод падать
        except OSError:
            continue
    return newer


def _log_ts_utc(ts: str) -> datetime | None:
    """Локальный asctime dt-sync-лога (``2026-07-04 20:47:25``) → aware UTC."""
    try:
        return datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").astimezone(UTC)
    except ValueError:
        return None


def _last_runs(log_path: Path) -> dict[str, dict[str, Any]]:
    """Последняя строка ``step <name>: …`` per шаг из текущего dt-sync-лога.

    Разбор через единый контракт :func:`core.operational.synclog.iter_step_lines`
    (толерантен к обоим форматам лога — старому и CODE-5-1 с corr-id; один источник
    правды для step-regex, FRESH-PARSE-1). Разбирается весь текущий файл (ротация
    держит его ≤ ~1MB, это единицы миллисекунд) — жёсткий хвост в N строк
    вытеснялся бы прогресс-строками идущего reindex и терял шаги последнего
    full-прогона. Порядок строк сохранён → последний прогон шага побеждает (новый
    ``ok`` перекрывает старый ``FAILED``).
    """
    try:
        lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return {}
    runs: dict[str, dict[str, Any]] = {}
    for ts, name, ok in iter_step_lines(lines):
        runs[name] = {"ts": ts, "ok": ok}
    return runs


def _scan_is_knowledge(args: dict[str, str]) -> bool:
    route = args.get("route")
    if route:
        return route in ("knowledge", "all")
    try:  # строка без маршрута (до WAVE1-MEASURE): знаниевый проход — тысячи файлов
        return int(args.get("new", 0)) + int(args.get("unchanged", 0)) >= _LEGACY_KNOWLEDGE_MIN_SEEN
    except ValueError:
        return False


def _watchdog_kills(log_path: Path, since: datetime) -> list[tuple[datetime, int]]:
    """Снятия сторожем шага ``file_ingest_knowledge`` из dt-sync-лога и его ротаций.

    ``[(ts_utc, минут без прогресса)]``, старые сверху. Ротации (``.1``–``.5``) — потому что
    журнал ~1 МБ, а снятий в неделю единицы: без них неделя «обнулялась» бы ротацией.
    """
    kills: list[tuple[datetime, int]] = []
    for path in [log_path, *(log_path.with_name(f"{log_path.name}.{i}") for i in range(1, 6))]:
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            if "runwatch" not in line or "file_ingest_knowledge" not in line:
                continue
            m = _KILL_RE.match(line)
            ts = _log_ts_utc(m.group("ts")) if m else None
            if m and ts is not None and ts >= since:
                kills.append((ts, int(m.group("min"))))
    kills.sort()
    return kills


def files_knowledge_state(
    *,
    now: datetime | None = None,
    actions_path: Path | None = None,
    log_path: Path | None = None,
) -> dict[str, Any]:
    """Состояние захвата знаниевых файлов (аудит C10): последний ЗАВЕРШЁННЫЙ скан и тормоза.

    ``{last_full_scan: iso|None, last_scan: {ts, outcome, pending_download, seen}|None,
    pending_download: int|None, watchdog_kills: n, last_watchdog_kill: iso|None,
    watchdog_minutes: [..]}``. Источники — аудит-журнал ``ingest_scan`` и dt-sync-лог; ни сети,
    ни обхода корней (бюджет < 200 мс).
    """
    from core.operational.pult import read_actions

    now_dt = _to_utc(now) if now is not None else datetime.now(UTC)
    scans = [
        a for a in read_actions(
            tools=("ingest_scan",), since=now_dt - timedelta(days=60), path=actions_path
        )
        if a.args.get("dry_run") != "True" and _scan_is_knowledge(a.args)
    ]
    full = [a for a in scans if a.outcome == "ok"]
    last = scans[-1] if scans else None
    kills = _watchdog_kills(
        log_path or sync_log_path(), now_dt - timedelta(days=WATCHDOG_WINDOW_DAYS)
    )
    def _int(value: str | None) -> int | None:
        try:
            return int(value) if value is not None else None
        except ValueError:
            return None

    return {
        "last_full_scan": _iso_z(full[-1].at) if full else None,
        "last_scan": (
            {
                "ts": _iso_z(last.at), "outcome": last.outcome,
                "pending_download": _int(last.args.get("pending")),
                "seen": _int(last.args.get("seen")),
            }
            if last else None
        ),
        "pending_download": _int(last.args.get("pending")) if last else None,
        "watchdog_kills": len(kills),
        "last_watchdog_kill": _iso_z(kills[-1][0]) if kills else None,
        "watchdog_minutes": [m for _, m in kills],
    }


def files_knowledge_row(
    *,
    now: datetime | None = None,
    actions_path: Path | None = None,
    log_path: Path | None = None,
    last_run: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Строка источника ``files:knowledge`` (та же форма, что у остальных пяти)."""
    now_dt = _to_utc(now) if now is not None else datetime.now(UTC)
    state = files_knowledge_state(now=now_dt, actions_path=actions_path, log_path=log_path)
    return _source_row(
        "files:knowledge", _parse_iso(state["last_full_scan"]), last_run, now=now_dt,
        pending_download=state["pending_download"],
        watchdog_kills=state["watchdog_kills"],
        last_watchdog_kill=state["last_watchdog_kill"],
        last_scan=state["last_scan"],
    )


def _source_row(
    source: str,
    data_as_of: datetime | None,
    last_run: dict[str, Any] | None,
    *,
    now: datetime,
    **detail: Any,
) -> dict[str, Any]:
    """Одна строка выдачи; нет данных → честные null (lag/stale неизвестны)."""
    lag_h: float | None = None
    stale: bool | None = None
    if data_as_of is not None:
        lag_h = round(max(0.0, (now - data_as_of).total_seconds()) / 3600, 1)
        stale = lag_h > STALE_AFTER_H[source]
    mode, steps = SOURCE_SYNC[source]
    return {
        "source": source,
        "sync": {"mode": mode, "steps": list(steps)},
        "data_as_of": _iso_z(data_as_of) if data_as_of is not None else None,
        "lag_h": lag_h,
        "stale": stale,
        "stale_after_h": STALE_AFTER_H[source],
        "last_run": last_run,
        **detail,
    }


def snapshot(
    *,
    vault_path: Path | None = None,
    mail_manifest: Path | None = None,
    timetta_cursor: Path | None = None,
    ticktick_state: Path | None = None,
    index_manifest: Path | None = None,
    link_scan: Path | None = None,
    log_path: Path | None = None,
    actions_path: Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Свежесть шести источников + последний прогон их шагов. См. док модуля.

    Все пути инжектируются тестами; по умолчанию — живые из ``core.config``.
    ``vault_path=None`` → дефолтный vault (для дельты «заметок новее индекса»).
    """
    from core.config import default_vault_path

    started = time.perf_counter()
    _rebuild_tables()  # роль процесса могла определиться после импорта (слои env)
    now_dt = _to_utc(now) if now is not None else datetime.now(UTC)
    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    runs = _last_runs(log_path or sync_log_path())

    def run_of(source: str) -> dict[str, Any] | None:
        return runs.get(SOURCE_STEPS[source]) if source in SOURCE_STEPS else None

    # timetta: курсор переписывается каждым успешным pull — mtime и есть
    # «состояние сервера известно на» (сам курсор хранит max modified сущностей
    # и при пустой дельте не двигается — поэтому именно mtime, не содержимое).
    cursor_path = (
        timetta_cursor
        if timetta_cursor is not None
        else timetta_mirror_path() / "cursor.json"
    )
    # ticktick: dedup-state лежит в каталоге ticktick-состояния.
    state_path = (
        ticktick_state
        if ticktick_state is not None
        else ticktick_state_path() / "capture_state.json"
    )
    index_path = index_manifest if index_manifest is not None else index_manifest_path()

    index_as_of = _mtime_utc(index_path)

    def _ticktick_row() -> dict[str, Any]:
        # ticktick: state двигается только при НОВЫХ захватах — пустой успешный pull тоже «данные
        # подтверждены на момент прогона», иначе тихая неделя красила бы плитку в оранжевый при
        # исправно ходящем pull_capture.
        candidates = [_ticktick_data_as_of(state_path)]
        tt_run = run_of("ticktick")
        if tt_run and tt_run.get("ok"):
            candidates.append(_log_ts_utc(str(tt_run.get("ts"))))
        as_of = max((ts for ts in candidates if ts is not None), default=None)
        return _source_row("ticktick", as_of, run_of("ticktick"), now=now_dt)

    def _index_row() -> dict[str, Any]:
        newer = (_count_notes_newer(vault, index_as_of.timestamp())
                 if index_as_of is not None else None)
        return _source_row("index", index_as_of, run_of("index"), now=now_dt, notes_newer=newer)

    def _mail_row() -> dict[str, Any]:
        # mail: как и ticktick — свежесть = ВРЕМЯ ПОСЛЕДНЕГО УСПЕШНОГО ingest, а не дата самого
        # свежего письма (иначе тихий день красил бы плитку, хотя mail_ingest исправно ходит). Берём
        # max(newest_email, last_run) — прогон (недавний) доминирует над контентом (в прошлом).
        candidates = [_mail_data_as_of(mail_manifest or outlook_ingest_manifest_path())]
        mail_run = run_of("mail")
        if mail_run and mail_run.get("ok"):
            candidates.append(_log_ts_utc(str(mail_run.get("ts"))))
        as_of = max((ts for ts in candidates if ts is not None), default=None)
        return _source_row("mail", as_of, run_of("mail"), now=now_dt)

    # PERSONAL-3: строка считается только для источника, который есть у роли (таблицы - по роли)
    builders: dict[str, Callable[[], dict[str, Any]]] = {
        "mail": _mail_row,
        "timetta": lambda: _source_row("timetta", _mtime_utc(cursor_path), run_of("timetta"),
                                       now=now_dt),
        "ticktick": _ticktick_row,
        "index": _index_row,
        "linking": lambda: _source_row(
            "linking",
            _mtime_utc(link_scan if link_scan is not None else link_scan_manifest_path()),
            run_of("linking"), now=now_dt),
        "files:knowledge": lambda: files_knowledge_row(
            now=now_dt, actions_path=actions_path, log_path=log_path or sync_log_path(),
            last_run=run_of("files:knowledge")),
    }
    by_key: dict[str, dict[str, Any]] = {
        key: build() for key, build in builders.items() if key in STALE_AFTER_H}
    # INGRESS-1: адаптер из реестра без собственного калькулятора (новый вход) — общая строка:
    # «данные на момент» = самый свежий mtime его state_paths, прогон — из dt-sync-лога.
    from core.ingress import registry
    from core.instance import instance_role

    _role = instance_role()
    for adapter in registry.adapters(role=_role):
        key = adapter.freshness_key
        if key and key in STALE_AFTER_H and key not in by_key:
            as_of = max(
                (m for m in (_mtime_utc(p()) for p in adapter.state_paths) if m is not None),
                default=None,
            )
            by_key[key] = _source_row(key, as_of, run_of(key), now=now_dt)
    if "bridge" in SOURCE_ORDER:  # PERSONAL-3: последний скан моста (строка есть только у личной)
        from core.bridge.store import last_path

        by_key["bridge"] = _source_row("bridge", _mtime_utc(last_path()), run_of("bridge"),
                                       now=now_dt)
    from core.surface import manifest as _surface

    # без ingest-корней личная не показывает files:knowledge
    keep = set(_surface.freshness_sources())
    sources = [by_key[k] for k in SOURCE_ORDER if k in by_key and k in keep]
    return {
        "sources": sources,
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 1),
    }


def _subscribe_registry() -> None:
    from core.ingress import registry

    registry.subscribe(_rebuild_tables)
    _rebuild_tables()


_subscribe_registry()
