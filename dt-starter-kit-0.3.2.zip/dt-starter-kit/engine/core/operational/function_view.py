"""ORBIT-3 п.2 — виджет «Функция»: надзор над сделками всех колец (read-only, без сети, без сумм).

К. как держатель функции видит не только свои сделки (спайк ORBIT-2: 47 сделок 4 ведущих).
Виджет отвечает на вопросы надзора, а не операционки:

* **воронка** — стадии × кольцо (``mine``/``unit``/``group``) × ведущий: сколько сделок
  где и у кого;
* **давно без движения** — те же правила и порог (``STALE_MIN_DAYS``), что у «Забытых тем», но по
  ВСЕМ видимым кольцам, а не только по моему;
* **без юрлица** — сделки, у которых поле юрлица не заполнено (подразделение берётся у ведущего);
* **последние изменения коллег** — лента ``history_feed`` (ORBIT-3 п.1) порциями.

Источник — зеркало Timetta + ``history_feed``; кольца — через единый фильтр ``orbit.visible``
(запрошенные ∩ ``DT_ORBIT_RINGS``; по умолчанию — ВСЕ включённые, надзор шире «моего»).
Privacy: суммы и вероятности в выдачу не попадают (как во всём зеркале-фиде).
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.adapters import StoreUnavailableError
from core.config import timetta_mirror_path, timetta_user_id
from core.operational import orbit
from core.operational.timetta import history
from core.operational.timetta.mirror import MirrorStore
from core.operational.work import (
    STALE_MIN_DAYS,
    TERMINAL_STATE_CODES,
    _days_between,
    _is_active,
    _iso_z,
    _parse_iso,
    _state_code_map,
    _to_utc,
)

__all__ = ["function_view", "IDLE_TOP", "RECENT_LIMIT"]

IDLE_TOP = 10  # сколько «давно без движения» показывать списком (счётчики — по всем)
RECENT_LIMIT = 50  # лента изменений в выдаче; пульт режет порциями по 5


def _by_ring(deals: list[dict[str, Any]]) -> dict[str, int]:
    out = dict.fromkeys(orbit.RINGS, 0)
    for d in deals:
        out[orbit.ring(d)] += 1
    return out


def _funnel(deals: list[dict[str, Any]], code_by_id: dict[str, str]) -> list[dict[str, Any]]:
    stages: dict[str, dict[str, Any]] = {}
    for d in deals:
        name = str(d.get("state_name") or "без стадии")
        row = stages.setdefault(name, {
            "stage": name,
            "terminal": code_by_id.get(str(d.get("state_id"))) in TERMINAL_STATE_CODES,
            "total": 0, "by_ring": dict.fromkeys(orbit.RINGS, 0), "_leaders": {},
        })
        row["total"] += 1
        row["by_ring"][orbit.ring(d)] += 1
        leader = str(d.get("manager_name") or "без ведущего")
        row["_leaders"][leader] = row["_leaders"].get(leader, 0) + 1
    rows = []
    for row in stages.values():
        leaders = row.pop("_leaders")
        row["by_leader"] = [
            {"leader": n, "n": c} for n, c in sorted(leaders.items(), key=lambda x: (-x[1], x[0]))
        ]
        rows.append(row)
    # Живые стадии сверху по числу сделок, терминальные (WON/Closed) — внизу.
    rows.sort(key=lambda r: (r["terminal"], -r["total"], r["stage"]))
    return rows


def _leaders(deals: list[dict[str, Any]]) -> list[dict[str, Any]]:
    acc: dict[str, dict[str, Any]] = {}
    for d in deals:
        name = str(d.get("manager_name") or "без ведущего")
        row = acc.setdefault(
            name, {"leader": name, "n": 0, "by_ring": dict.fromkeys(orbit.RINGS, 0)}
        )
        row["n"] += 1
        row["by_ring"][orbit.ring(d)] += 1
    return sorted(acc.values(), key=lambda r: (-r["n"], r["leader"]))


def _idle(
    deals: list[dict[str, Any]], code_by_id: dict[str, str], *, now: datetime
) -> dict[str, Any]:
    rows: list[tuple[float, dict[str, Any]]] = []
    by_ring = dict.fromkeys(orbit.RINGS, 0)
    for d in deals:
        if not _is_active(d, code_by_id):
            continue
        modified = _parse_iso(d.get("modified"))
        if modified is None:
            continue
        silent = _days_between(now, modified)
        if silent < STALE_MIN_DAYS:
            continue
        by_ring[orbit.ring(d)] += 1
        item = {
            "guid": d.get("id"), "code": d.get("code"), "name": d.get("name"),
            "stage": d.get("state_name"), "ring": orbit.ring(d),
            "leader": d.get("manager_name"), "watched": orbit.is_watched(d),
            "silent_days": round(silent), "last_activity": _iso_z(modified),
        }
        rows.append((silent, item))
    rows.sort(key=lambda r: r[0], reverse=True)
    return {
        "threshold_days": STALE_MIN_DAYS,
        "total": sum(by_ring.values()),
        "by_ring": by_ring,
        "items": [it for _, it in rows[:IDLE_TOP]],
    }


def _window_rings(rings: Any) -> Any:
    """Надзорный дефолт: ВСЕ включённые кольца (``DT_ORBIT_RINGS``), а не только ``mine``."""
    return list(orbit.enabled_rings()) if rings is None else rings


def function_view(
    *,
    mirror_path: Path | None = None,
    rings: Any = None,
    now: datetime | None = None,
    limit: int = RECENT_LIMIT,
) -> dict[str, Any]:
    """Данные виджета «Функция». ``rings`` — ``None`` (все включённые) | ``"mine,unit"`` | список.

    Неизвестное кольцо → :class:`~core.operational.orbit.OrbitError` (отказ, не тихий дефолт).
    Битое зеркало → пустые срезы + конверт ``store_unavailable`` (ошибка ≠ «сделок нет»).
    """
    now = _to_utc(now) if now is not None else datetime.now(UTC)
    store = MirrorStore(mirror_path or timetta_mirror_path())
    errors: list[StoreUnavailableError] = []
    try:
        all_deals = list(orbit.lookup(store).values())  # сырая карта → ниже orbit.visible
        code_by_id = _state_code_map(store)
    except StoreUnavailableError as exc:
        errors.append(exc)
        all_deals, code_by_id = [], {}
    view = orbit.visible(all_deals, _window_rings(rings))
    me = timetta_user_id()
    days = history.history_days()
    try:
        feed = history.feed_rows(store, me, rings=_window_rings(rings), days=days, now=now)
    except StoreUnavailableError as exc:
        errors.append(exc)
        feed = []
    no_le = [d for d in view if not d.get("legal_entity_id")]
    result: dict[str, Any] = {
        "now": _iso_z(now),
        "rings": list(orbit.effective_rings(_window_rings(rings))),
        "counts": {
            "deals": len(view), "by_ring": _by_ring(view),
            "watched": sum(1 for d in view if orbit.is_watched(d)),
        },
        "funnel": _funnel(view, code_by_id),
        "leaders": _leaders(view),
        "idle": _idle(view, code_by_id, now=now),
        "no_legal_entity": {"total": len(no_le), "by_ring": _by_ring(no_le)},
        "recent": {
            "total": len(feed),
            "items": feed[: max(0, limit)],
            "summary": history.feed_summary(feed, days=days),
        },
    }
    for err in errors:
        err.add_to(result)
    return result
