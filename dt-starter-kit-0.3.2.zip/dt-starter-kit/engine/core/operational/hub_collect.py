"""Общие сборщики «клиент/хаб» для досье: встреча (``meeting_prep``) и синтез хаба (``hub_synth``).

Вынесено из :mod:`core.operational.meeting_prep` (HUB-SYNTH-1 п.1) без изменения поведения:
активные сделки клиента из зеркала, внешняя переписка по доменам, релевантные заметки,
различимые термины темы.
У ``meeting_prep`` остаются резолв сущности встречи и сборка ``prepare``; прежние приватные имена
сохранены там алиасами. Path B: ``core/`` ⊥ mcp/cli, без сети и LLM; ``find_notes`` инъектируется.
Privacy как в ``work.py``: наружу только code/name/state_name/темы/домены/даты/ссылки на заметки,
сумм и вероятностей сделок нет.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from core.operational import meetings, orbit, work

__all__ = [
    "active_client_deals",
    "clients_of",
    "date_only",
    "deal_view",
    "iso_z",
    "mail_for",
    "mail_threads_for",
    "mail_view",
    "notes_for",
    "orbit_records",
    "salient_terms",
    "term_hit",
    "to_utc",
]

# Служебные слова встреч — выкидываются из темы, чтобы остался различимый термин
# («Еженедельный ОС по ГП Альфа» → «Альфа»). Префиксы («оператив*», «еженедель*»)
# ловятся отдельно ниже.
STOP_WORDS: frozenset[str] = frozenset({
    "ос", "совет", "советы", "статус", "статусный", "синхронизация", "синхрон",
    "встреча", "встречи", "звонок", "созвон", "обсуждение", "совещание", "планёрка",
    "планерка", "летучка", "митинг", "апдейт", "апдейты", "разговор", "беседа",
    "weekly", "sync", "call", "standup", "meeting", "update", "catchup", "checkin",
    "daily", "по", "и", "с", "о", "об", "на", "для", "к", "от",
})
STOP_PREFIXES: tuple[str, ...] = ("оператив", "еженедель", "ежедневн")
# Токен темы короче — не различимый (служебные аббревиатуры «ОС»/«ЦД» и предлоги).
MIN_TERM_LEN = 3
TERM_RE = re.compile(r"[0-9a-zA-Zа-яёА-ЯЁ]+")

def to_utc(dt: datetime) -> datetime:
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)


def iso_z(dt: datetime) -> str:
    return to_utc(dt).strftime("%Y-%m-%dT%H:%M:%SZ")


def date_only(value: Any) -> str | None:
    """ISO-строку/дату из зеркала → ``YYYY-MM-DD`` (или ``None``)."""
    dt = work._parse_iso(value)
    return dt.date().isoformat() if dt is not None else None


def salient_terms(subject: str) -> list[str]:
    """Различимые термины темы: токены без служебных слов встреч и коротышей (FIX-2).

    «Еженедельный ОС по ГП Альфа» → ``["альфа"]`` («еженедельный»/«ОС»/«по»/«ГП»
    отсеяны). Порядок сохраняется, дедуп. Служит и ретривал-запросу, и резолву
    сущности (:func:`resolve_entities`)."""
    out: list[str] = []
    seen: set[str] = set()
    for raw in TERM_RE.findall(subject or ""):
        tok = raw.lower()
        if len(tok) < MIN_TERM_LEN or tok in STOP_WORDS or tok in seen:
            continue
        if any(tok.startswith(p) for p in STOP_PREFIXES):
            continue
        seen.add(tok)
        out.append(tok)
    return out

def clients_of(text: str, hubs: list[dict[str, Any]]) -> set[str]:
    """Множество id клиент-хабов, к которым относится текст (имя сделки/орг.).

    Инвертирует резолвер встреч: ``_resolve_clients`` матчит slug/alias хаба по
    подстроке — тем же путём, что ``work._resolve_item_clients`` привязывает
    пункт фида к клиенту. Доменов у сделки нет, поэтому только текстовое совпадение.
    """
    return {c["id"] for c in meetings._resolve_clients([], text or "", hubs)}


def orbit_records(store: Any, coll: str) -> list[dict[str, Any]]:
    """Записи ``deals``/``projects`` в видимых кольцах (ORBIT-2): досье к встрече — по сделкам
    всех видимых колец (``DT_ORBIT_RINGS``), с ведущим; удалённые в Timetta скрыты."""
    return orbit.orbit_slice(store, orbit.enabled_rings())[coll]


def deal_view(deal: dict[str, Any]) -> dict[str, Any]:
    """Приватный срез сделки для досье: стадия/открытые/ближайший дедлайн (без сумм)."""
    open_items = 0
    nearest: datetime | None = None
    for entry in deal.get("check_list") or []:
        if not isinstance(entry, dict) or entry.get("fulfilled"):
            continue
        open_items += 1
        due = work._parse_iso(entry.get("deadline"))
        if due is not None and (nearest is None or due < nearest):
            nearest = due
    badge = orbit.leader_badge(deal)  # ORBIT-2: чужая сделка — с ведущим; у своих ключей нет
    return {
        **({"ring": badge["ring"], "leader": badge["leader"]} if badge else {}),
        "code": deal.get("code"),
        "name": deal.get("name"),
        "stage": deal.get("state_name"),
        "open_items": open_items,
        "nearest_due": nearest.date().isoformat() if nearest is not None else None,
        "last_activity": date_only(deal.get("modified")),
    }


def active_client_deals(
    client_id: str,
    deals: list[dict[str, Any]],
    code_by_id: dict[str, str],
    hubs: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Активные сделки клиента из зеркала (терминальные скрыты), свежие сначала."""
    out: list[dict[str, Any]] = []
    for deal in deals:
        if not work._is_active(deal, code_by_id):
            continue
        text = f"{deal.get('organization_name') or ''} {deal.get('name') or ''}"
        if client_id not in clients_of(text, hubs):
            continue
        out.append(deal)
    out.sort(key=lambda d: date_only(d.get("modified")) or "", reverse=True)
    return out

def term_hit(text: str, terms: list[str]) -> bool:
    low = (text or "").lower()
    return any(t in low for t in terms)

def mail_view(thread: dict[str, Any]) -> dict[str, Any]:
    """Тред → ``{subject, date, from, direction}`` (тексты писем не тянем)."""
    last_is_me = thread.get("last_is_me")
    direction = None if last_is_me is None else ("outbound" if last_is_me else "inbound")
    return {
        "subject": thread.get("subject"),
        "date": date_only(thread.get("last")),
        "from": thread.get("domain"),
        "direction": direction,
    }


def mail_threads_for(
    client_id: str,
    recent: list[dict[str, Any]],
    hubs: list[dict[str, Any]],
    *,
    counterparty_domains: list[str],
    entity: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Внешние треды клиента (FIX-1), свежие сначала: тред попадает ТОЛЬКО если его домен
    (а) резолвится в этого клиента через хаб ИЛИ (б) входит в ``counterparty_domains``
    ИМЕННО этой встречи. Никакой над-атрибуции «единственному клиенту» по всему пулу.

    При скоупе к сущности (FIX-3) дополнительно оставляем треды, чья тема совпала с
    термином сущности (если такие есть — иначе клиентский срез целиком)."""
    cds = {d.lower() for d in counterparty_domains if d}
    base: list[dict[str, Any]] = []
    for thread in recent:
        if not thread.get("external"):
            continue
        domain = (thread.get("domain") or "").lower()
        ids = {
            c["id"]
            for c in meetings._resolve_clients(
                [domain] if domain else [], str(thread.get("subject") or ""), hubs
            )
        }
        if client_id in ids or (domain and domain in cds):
            base.append(thread)
    if entity is not None:
        eterms = salient_terms(str(entity.get("name") or ""))
        scoped = [t for t in base if term_hit(str(t.get("subject") or ""), eterms)]
        base = scoped or base
    base.sort(
        key=lambda t: work._parse_iso(t.get("last")) or datetime.min.replace(tzinfo=UTC),
        reverse=True,
    )
    return base


def mail_for(
    client_id: str,
    recent: list[dict[str, Any]],
    hubs: list[dict[str, Any]],
    *,
    counterparty_domains: list[str],
    max_mail: int,
    entity: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Недавние внешние треды клиента (FIX-1/FIX-3) в виде ``{subject, date, from, direction}``."""
    base = mail_threads_for(
        client_id, recent, hubs, counterparty_domains=counterparty_domains, entity=entity
    )
    return [mail_view(t) for t in base[:max_mail]]


def notes_for(
    client_name: str,
    subject: str,
    find_notes: Callable[..., dict[str, Any]] | None,
    *,
    max_notes: int,
    entity_name: str | None = None,
) -> list[dict[str, Any]]:
    """Топ-N релевантных заметок через инъектированный ``find_notes`` (FIX-2).

    Запрос ведёт РАЗЛИЧИМЫЙ термин: имя сущности (если досье скоуплено, FIX-3) либо
    различимые термины темы (иначе), плюс имя клиента как контекст — чтобы поднимать
    профильные/проектные заметки, а не тонуть в клиентских. Дедуп по ``note_id``.
    Хелпер не задан или упал → пустой срез (не исключение)."""
    if find_notes is None:
        return []
    if entity_name:
        term_str = entity_name
    else:
        terms = salient_terms(subject)
        term_str = " ".join(terms) if terms else subject
    query = f"{client_name} {term_str}".strip()
    if not query:
        return []
    try:
        res = find_notes(query, limit=max_notes)
    except Exception:  # noqa: BLE001 — best-effort; must not break the caller
        return []
    notes: list[dict[str, Any]] = []
    seen: set[str] = set()
    for hit in (res or {}).get("notes", []) if isinstance(res, dict) else []:
        if not isinstance(hit, dict):
            continue
        nid = hit.get("note_id")
        if not nid or nid in seen:
            continue
        seen.add(nid)
        notes.append(
            {
                "note_id": nid,
                "title": hit.get("title") or nid,
                "path": hit.get("source_path") or hit.get("path"),
            }
        )
        if len(notes) >= max_notes:
            break
    return notes
