"""HUB-DEAL-LINK — связать vault-хаб с СУЩЕСТВУЮЩЕЙ сделкой Timetta (без создания).

Реальный кейс, который не покрывал детектор «дозревших» (`ripe_leads` умеет только
завести НОВУЮ сделку): хаб уже соответствует сделке, которая **в Timetta есть** —
её надо не создавать, а **связать** (проставить `timetta_id`/crosswalk).

Запись ТОЛЬКО в vault: frontmatter хаба (`timetta_id: <deal_guid>`) + трёхсторонний
crosswalk (vault↔Guid, :class:`~core.operational.crosswalk.Crosswalk`). В Timetta
НЕ пишем — **ни одной сетевой операции**: и список сделок для пикера
(:func:`deals_for_picker`), и валидация guid идут из локального зеркала
(`.derived/timetta/`, Path B). После связывания операционный контекст хаба
подтягивается сам через :func:`core.operational.context.build_operational_context`
по свежему `timetta_id` — доп. работы нет.

Правка frontmatter — ХИРУРГИЧЕСКАЯ (образец
:func:`core.operational.attribute.attribute_note_client` /
`corpus.migrate._retag_frontmatter`): меняется/добавляется только строка
`timetta_id:` внутри YAML-блока, остальной frontmatter и тело — байт-в-байт (round-
trip через YAML-либу переписал бы форматирование и `[[…]]`-ссылки). Идемпотентно
(повтор той же связи → `changed=False`). Containment-guard: путь хаба обязан лежать
внутри vault; hub_id сверяется по NFC. Автосвязывания нет — только явный выбор
пользователя (принцип 10): связь ставит вызывающий с конкретным `deal_guid`.

Инвариант: `core/` не импортирует mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import re
import unicodedata
from pathlib import Path
from typing import Any

from core.operational import orbit
from core.operational.tracks import TRACKS
from core.vault import FrontmatterError, RawYaml, set_frontmatter_fields_text

__all__ = [
    "TRACKS",
    "HubLinkError",
    "deals_for_picker",
    "deals_for_picker_cached",
    "link_hub_to_deal",
    "set_hub_aliases",
    "set_track",
    "unlink_hub_from_deal",
]

_FM_RE = re.compile(r"^---\r?\n(.*?)\r?\n---\r?\n?", re.DOTALL)

# Допустимые треки хаба — единый источник :data:`core.operational.tracks.TRACKS`
# (``presale``/``project``/``internal``). Ре-экспортируем под прежним именем
# ``hub_link.TRACKS`` для обратной совместимости импортов/тестов.


class HubLinkError(RuntimeError):
    """Операция над хабом невозможна (нет guid в зеркале / нет хаба / путь вне
    vault / невалидное значение поля)."""


def _nfc(s: str) -> str:
    return unicodedata.normalize("NFC", str(s or "")).strip()


# --------------------------------------------------------------------------- #
# read: список сделок зеркала для пикера (Path B, без сети)
# --------------------------------------------------------------------------- #


def _linked_hubs_by_guid(vault: Path) -> dict[str, str]:
    """Один проход по vault → ``{timetta_id.lower(): hub_id}`` для отметки linked_hub.

    Собирает все хабы, чей frontmatter уже указывает `timetta_id` на какую-то
    сделку, чтобы пикер не предлагал занятую сделку молча. Read-only.
    """
    from core.vault import iter_vault

    out: dict[str, str] = {}
    if not vault.is_dir():
        return out
    for note in iter_vault(vault):
        tid = note.frontmatter.get("timetta_id")
        if isinstance(tid, str) and tid.strip():
            out[tid.strip().lower()] = note.id
    return out


def _match(needle: str, *fields: str | None) -> bool:
    """Case-insensitive substring match хотя бы по одному непустому полю."""
    n = needle.strip().lower()
    if not n:
        return True
    for f in fields:
        if isinstance(f, str) and f.strip() and n in f.strip().lower():
            return True
    return False


def deals_for_picker(
    *,
    client: str | None = None,
    mirror_path: Path | None = None,
    vault_path: Path | None = None,
    rings: Any = None,
) -> list[dict[str, Any]]:
    """Активные сделки зеркала для пикера «связать с CRM» (read-only, без сети).

    ``rings`` (ORBIT-2): кольца орбиты (``"mine,unit"``/список/``None``); ``None`` = ``mine``
    (прежний пикер). У сделки НЕ из кольца ``mine`` в строке появляются ``ring``/``leader``/
    ``unit`` — бейдж ведущего; у своих форма строки прежняя.

    Возвращает ``[{guid, code, name, stage, client, linked_hub}]`` — где
    ``stage`` = ``state_name`` сделки, ``client`` = имя организации, ``linked_hub``
    = id хаба, если чей-то frontmatter уже указывает `timetta_id` на эту сделку
    (иначе ``None``). Суммы/вероятность в выдачу НЕ попадают (коммерческая тайна).
    ``client`` (если задан) — подстрочный фильтр по имени/коду/id организации.
    Сортировка: свободные раньше связанных, затем по свежести (`modified`).
    """
    from core.config import default_vault_path, timetta_mirror_path
    from core.operational.timetta.mirror import MirrorStore

    store = MirrorStore(mirror_path or timetta_mirror_path())
    vault = Path(vault_path) if vault_path else default_vault_path()
    linked = _linked_hubs_by_guid(vault)

    rows: list[dict[str, Any]] = []
    for d in orbit.visible(store.all("deals"), rings):
        if not isinstance(d, dict) or not d.get("is_active", True):
            continue
        guid = str(d.get("id") or "")
        if not guid:
            continue
        if client and not _match(client, d.get("organization_name"), d.get("code"), guid):
            continue
        row = {
            "guid": guid,
            "code": d.get("code"),
            "name": d.get("name"),
            "stage": d.get("state_name"),
            "client": d.get("organization_name"),
            "linked_hub": linked.get(guid.lower()),
            "modified": d.get("modified"),
        }
        badge = orbit.leader_badge(d)
        if badge:  # бейдж ведущего — только у чужих колец (форма «своих» прежняя)
            row.update(ring=badge["ring"], leader=badge["leader"], unit=badge["unit"])
        rows.append(row)
    # Два стабильных прохода: сначала по свежести (новые раньше), затем свободные
    # раньше связанных — стабильность сохраняет порядок по свежести внутри групп.
    rows.sort(key=lambda r: (r.get("modified") or ""), reverse=True)
    rows.sort(key=lambda r: r["linked_hub"] is not None)
    for r in rows:
        r.pop("modified", None)
    return rows


DEALS_TTL_ENV = "DT_PULT_DEALS_TTL_S"
_DEALS_PREFIX = "deals-"


def _deals_stamp(mirror_path: Path | None) -> list[float]:
    """Токен свежести снимка: mtime файлов зеркала (сделки/орбита); обновили зеркало - пересчет."""
    from core.config import timetta_mirror_path

    root = Path(mirror_path or timetta_mirror_path())
    stamp: list[float] = []
    for name in ("deals.json", "orbit.json"):
        try:
            stamp.append((root / name).stat().st_mtime)
        except OSError:
            stamp.append(0.0)
    return stamp


def deals_for_picker_cached(
    *,
    client: str | None = None,
    rings: Any = None,
    refresh: bool = False,
    mirror_path: Path | None = None,
    vault_path: Path | None = None,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """:func:`deals_for_picker` из снимка (PULT-SURFACE-2): ``(строки, meta{as_of, cached, ...})``.

    Дорогое тут - ``_linked_hubs_by_guid`` (обход frontmatter vault, ~5 с). Снимок живет
    ``DT_PULT_DEALS_TTL_S`` (300 с) и протухает раньше, если обновилось зеркало Timetta (mtime
    ``deals.json``/``orbit.json``) либо связали/развязали хаб (:func:`link_hub_to_deal` сбрасывает).
    Ключ - от ``client``/``rings``: разные выборки не мешают друг другу."""
    import hashlib

    from core.operational.snapshot import cached_read, ttl_from_env

    key = _DEALS_PREFIX + hashlib.sha256(
        f"{client or ''}|{rings if isinstance(rings, str | type(None)) else list(rings)}".encode()
    ).hexdigest()[:12]
    kwargs: dict[str, Any] = {"client": client, "rings": rings}
    if mirror_path is not None:
        kwargs["mirror_path"] = mirror_path
    if vault_path is not None:
        kwargs["vault_path"] = vault_path
    return cached_read(
        key, ttl_from_env(DEALS_TTL_ENV, 300), lambda: deals_for_picker(**kwargs),
        refresh=refresh, stamp=_deals_stamp(mirror_path),
    )


def _drop_deals_cache() -> None:
    """Связь хаба со сделкой изменилась - снимки пикера (``linked_hub``) устарели."""
    try:
        from core.operational.snapshot import invalidate

        invalidate(_DEALS_PREFIX)
    except Exception:  # noqa: BLE001, S110 - сброс снимка не должен ломать запись связи
        pass


# --------------------------------------------------------------------------- #
# write: связать / снять связь (только vault; в Timetta не пишем)
# --------------------------------------------------------------------------- #


def _resolve_hub(hub_id: str, vault: Path) -> Any:
    """Найти заметку-хаб по ссылке ЛЮБОЙ формы. Нет → :class:`HubLinkError`.

    **CONTRACT-1 ФП-1 (Д6).** Сначала единая точка резолва
    (:func:`core.vault.resolve_note_path`: путь vault-относительный/абсолютный, id через
    манифест, имя файла, ``source_path``) — так принимается и **путь**, который отдают
    ``pult_create_hub.path``/``pult_ripe_leads[].path`` (раньше здесь был только
    frontmatter ``id``, и путь из своей же выдачи отбивался как «хаб не найден»).
    Обход vault со сверкой ``id`` по NFC остаётся ПОСЛЕДНИМ шагом: он покрывает хаб,
    которого нет в манифестах (создан только что, reindex ещё не проходил) и NFD-форму
    имени от macOS.
    """
    from core.vault import iter_vault, read_note, resolve_note_path

    if not vault.is_dir():
        raise HubLinkError(f"vault не найден: {vault}")
    target = _nfc(hub_id)
    if not target:
        raise HubLinkError("пустой hub_id")
    resolved = resolve_note_path(str(hub_id), vault_path=vault)
    if resolved is not None:
        return read_note(resolved)
    for note in iter_vault(vault):
        if _nfc(note.id) == target:
            return note
    raise HubLinkError(f"хаб не найден в vault: {hub_id}")


def _guarded_path(note: Any, vault: Path) -> Path:
    """Containment-guard: путь заметки обязан лежать внутри vault."""
    p = Path(note.path).resolve()
    try:
        p.relative_to(vault.resolve())
    except ValueError as exc:
        raise HubLinkError(f"путь вне vault: {p}") from exc
    return p


def _set_frontmatter_field(
    text: str, field: str, value: str, *, insert_missing: bool = True
) -> tuple[str, str, bool]:
    """Хирургически проставить/сменить ``<field>: <value>`` во frontmatter хаба.

    Тонкая обертка над единым писателем :func:`core.vault.set_frontmatter_fields_text`
    (SRC-PATH-1: вместо трех регексов-копий). Меняет ТОЛЬКО строку ``<field>:`` (или вставляет ее
    после ``id:``), остальной frontmatter и тело - байт-в-байт. Возвращает
    ``(new_text, previous, changed)``; идемпотентно. Нет YAML-блока → :class:`HubLinkError`.
    ``field``/``value`` - из фиксированного словаря вызывающего, пишутся как есть.
    """
    try:
        new_text, previous, changed = set_frontmatter_fields_text(
            text, {field: RawYaml(value)}, insert_missing=insert_missing
        )
    except FrontmatterError as exc:
        raise HubLinkError("во frontmatter нет YAML-блока — хаб не трогаю") from exc
    return (new_text, previous[field], changed)


def _set_frontmatter_timetta_id(text: str, guid: str) -> tuple[str, str, bool]:
    """Проставить/сменить ``timetta_id: <guid>`` (частный случай :func:`_set_frontmatter_field`)."""
    return _set_frontmatter_field(text, "timetta_id", guid)


_YAML_SPECIAL_RE = re.compile(r"[:#,\[\]{}&*!|>'\"%@`]|^[-?\s]|\s$|^\s*$")
_YAML_WORDS = frozenset({"true", "false", "null", "yes", "no", "on", "off", "~"})


def _yaml_item(value: str) -> str:
    """Элемент списка frontmatter: простой текст как есть, иначе в двойных кавычках.

    Кавычки/запятые/двоеточия в имени («Инитех, нефть», ``АО "Х"``) не ломают YAML: такое имя
    уходит как ``"АО \\"Х\\""``. Число, ``true``/``null`` тоже квотируются (иначе - не строка).
    """
    text = unicodedata.normalize("NFC", str(value)).strip()
    plain = (
        not _YAML_SPECIAL_RE.search(text)
        and text.casefold() not in _YAML_WORDS
        and not re.fullmatch(r"[-+]?[\d.,_:]+(?:e[-+]?\d+)?", text, re.IGNORECASE)
    )
    if plain:
        return text
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _alias_fold(text: str) -> str:
    """Ключ дедупликации алиасов: NFC + ``casefold`` + ё→е (как ``hubcat.fold_plain``)."""
    return unicodedata.normalize("NFC", str(text)).casefold().replace("ё", "е").strip()


def _set_frontmatter_aliases(text: str, new: list[str]) -> tuple[str, list[str], bool]:
    """Хирургически дописать имена в ``aliases:`` во frontmatter хаба (СПИСОК, не скаляр).

    Обобщение :func:`_set_frontmatter_field` на ``aliases: [a, b]``. Существующие алиасы сохраняются
    как есть (их текст не переписывается), новые дописываются БЕЗ дублей по :func:`_alias_fold` -
    и относительно существующих, и между собой. Три формы записи на входе: flow
    (``aliases: [a, "b"]``, в т.ч. пустой ``[]``) - дописываем в скобки; block
    (``aliases:`` + ``  - a``) - дописываем элементы тем же отступом; пусто/скаляр - заменяем
    строкой-flow. Поля нет - вставляем ``aliases: [..]`` после ``id:``. Остальной frontmatter и тело
    - байт-в-байт, окончания строк сохраняются. Возвращает ``(new_text, added, changed)``; ничего
    нового → ``(text, [], False)``. Нет YAML-блока → :class:`HubLinkError`.
    """
    import yaml  # type: ignore[import-untyped]

    m = _FM_RE.match(text)
    if not m:
        raise HubLinkError("во frontmatter нет YAML-блока — хаб не трогаю")
    fm = m.group(1)
    eol = "\r\n" if "\r\n" in text[: m.end()] else "\n"
    lines = fm.split(eol) if eol == "\r\n" else fm.split("\n")

    start = next((i for i, ln in enumerate(lines) if re.match(r"aliases:(?:\s|$)", ln)), None)
    existing: list[str] = []
    end = start or 0  # индекс последней строки блока aliases (без блока не используется)
    if start is not None:
        end = start
        while end + 1 < len(lines) and re.match(r"(?:\s+\S|\s*-\s)", lines[end + 1]):
            end += 1
        try:
            loaded = yaml.safe_load(eol.join(lines[start : end + 1]))
        except yaml.YAMLError as exc:
            raise HubLinkError(f"aliases во frontmatter не разбирается: {exc}") from exc
        value = (loaded or {}).get("aliases") if isinstance(loaded, dict) else None
        if isinstance(value, list):
            existing = [str(v) for v in value if v is not None]
        elif value not in (None, ""):
            existing = [str(value)]

    seen = {_alias_fold(a) for a in existing}
    added: list[str] = []
    for name in new:
        clean = unicodedata.normalize("NFC", str(name)).strip()
        key = _alias_fold(clean)
        if clean and key not in seen:
            seen.add(key)
            added.append(clean)
    if not added:
        return (text, [], False)
    items = [_yaml_item(a) for a in added]

    if start is None:
        id_idx = next((i for i, ln in enumerate(lines) if re.match(r"id:", ln)), None)
        line = "aliases: [" + ", ".join(items) + "]"
        if id_idx is None:
            lines.append(line)
        else:
            lines.insert(id_idx + 1, line)
    else:
        head = lines[start]
        flow = re.match(r"^(aliases:\s*)\[(.*)\](\s*(?:#.*)?)$", head)
        block_items = [ln for ln in lines[start + 1 : end + 1] if re.match(r"\s*-\s", ln)]
        if flow:
            inner = flow.group(2)
            joined = (inner.rstrip() + ", " if inner.strip() else "") + ", ".join(items)
            lines[start] = f"{flow.group(1)}[{joined}]{flow.group(3)}"
        elif block_items:
            indent = re.match(r"(\s*)-", block_items[0]).group(1)  # type: ignore[union-attr]
            lines[end + 1 : end + 1] = [f"{indent}- {it}" for it in items]
        else:
            # пусто (``aliases:``/``aliases: null``) или скаляр - строка-flow со старым значением
            keep = [_yaml_item(a) for a in existing]
            lines[start : end + 1] = ["aliases: [" + ", ".join(keep + items) + "]"]
    new_fm = eol.join(lines)
    return (text[: m.start(1)] + new_fm + text[m.end(1):], added, True)


def set_hub_aliases(
    hub_id: str,
    aliases: list[str],
    *,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Дописать ``aliases`` хабу ``hub_id`` (только vault; решение человека - вызывающий).

    Резолв по id/NFC, containment-guard, ``type: hub`` обязателен (в обычную заметку алиасы не
    пишем), запись хирургическая (:func:`_set_frontmatter_aliases`), идемпотентно. После записи
    единый каталог имен хабов сбрасывается точечно
    (:func:`core.retrieval.hubcat.invalidate_hub_catalog`). Аудит/события - у вызывающего
    (решение с пульта: ``core.linking.hub_aliases.decide_hub_alias``). Возвращает
    ``{ok, hub_id, added, aliases, changed, path}``.
    """
    from core.config import default_vault_path
    from core.retrieval.hubcat import invalidate_hub_catalog

    vault = (Path(vault_path) if vault_path else default_vault_path()).resolve()
    note = _resolve_hub(hub_id, vault)
    if str(getattr(note, "type", "") or "") != "hub":
        raise HubLinkError(f"{note.id} не хаб (type: hub) — алиасы пишутся только хабам")
    path = _guarded_path(note, vault)
    text = path.read_text(encoding="utf-8")
    new_text, added, changed = _set_frontmatter_aliases(text, list(aliases))
    if changed:
        path.write_text(new_text, encoding="utf-8")
        invalidate_hub_catalog(vault, [path])
    import yaml  # type: ignore[import-untyped]

    fm_match = _FM_RE.match(new_text if changed else text)
    after: list[str] = []
    if fm_match:
        loaded = yaml.safe_load(fm_match.group(1)) or {}
        raw = loaded.get("aliases") if isinstance(loaded, dict) else None
        after = [str(v) for v in raw] if isinstance(raw, list) else ([str(raw)] if raw else [])
    return {"ok": True, "hub_id": note.id, "added": added, "aliases": after,
            "changed": changed, "path": str(path)}


def set_track(
    hub_id: str,
    track: str,
    *,
    vault_path: Path | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Сменить трек хаба ``hub_id`` → ``track ∈ {presale, project, internal}`` (только vault).

    Хирургически пишет ``track:`` во frontmatter хаба (образец
    :func:`link_hub_to_deal`: резолв по ``id``/NFC, containment-guard, остальной
    frontmatter+тело байт-в-байт). Валидирует ``track`` (иначе :class:`HubLinkError`),
    идемпотентно (тот же трек → ``changed=False``, без записи). Меняет
    классификацию детектора «дозревших» (:func:`core.operational.ripe_leads`) —
    поле читается с приоритетом над эвристикой. В Timetta ничего не пишет.
    Возвращает ``{ok, hub_id, track, previous, changed, path}``. Аудит —
    ``record_action`` (id+track, без контента).
    """
    from core.config import default_vault_path
    from core.operational.pult import record_action

    t = _nfc(track).lower()
    if t not in TRACKS:
        raise HubLinkError(
            f"недопустимый track {track!r}; допустимо: {', '.join(sorted(TRACKS))}"
        )

    vault = (Path(vault_path) if vault_path else default_vault_path()).resolve()
    note = _resolve_hub(hub_id, vault)
    path = _guarded_path(note, vault)

    text = path.read_text(encoding="utf-8")
    new_text, previous, changed = _set_frontmatter_field(text, "track", t)
    if changed:
        path.write_text(new_text, encoding="utf-8")

    record_action(
        "pult_set_track",
        {"hub_id": note.id, "track": t, "changed": changed},
        "set",
        now=now,
    )
    return {
        "ok": True,
        "hub_id": note.id,
        "track": t,
        "previous": previous,
        "changed": changed,
        "path": str(path),
    }


def _find_deal(store: Any, deal_guid: str) -> dict[str, Any]:
    """Достать сделку из зеркала по guid (точное совпадение, затем без регистра).

    ORBIT-2: сделка обязана быть ВИДИМОЙ (кольцо из ``DT_ORBIT_RINGS``) и не помеченной
    удалённой в Timetta — связать хаб с исчезнувшей/невидимой сделкой нельзя (отказ с
    причиной, а не ссылка в никуда). Связывание пишет только vault."""
    deals = orbit.lookup(store)  # сырая карта: видимость/удаление проверяются ниже
    found: dict[str, Any] | None = deals.get(deal_guid)
    if found is None:
        target = deal_guid.strip().lower()
        for key, val in deals.items():
            if str(key).strip().lower() == target and isinstance(val, dict):
                found = val
                break
    if found is None:
        raise HubLinkError(f"сделка не найдена в зеркале Timetta: {deal_guid}")
    if orbit.is_deleted(found):
        raise HubLinkError(f"сделка удалена в Timetta (метка сверки): {deal_guid}")
    if not orbit.visible([found], orbit.enabled_rings()):
        raise HubLinkError(
            f"сделка вне видимых колец орбиты ({orbit.ring(found)}; DT_ORBIT_RINGS): {deal_guid}"
        )
    return found


def link_hub_to_deal(
    hub_id: str,
    deal_guid: str,
    *,
    vault_path: Path | None = None,
    mirror_path: Path | None = None,
) -> dict[str, Any]:
    """Связать хаб `hub_id` с существующей сделкой `deal_guid` Timetta (только vault).

    Валидирует ``deal_guid ∈ зеркало deals`` (иначе :class:`HubLinkError`);
    хирургически пишет ``timetta_id: <deal_guid>`` во frontmatter хаба (это и есть
    долговечный якорь vault→Guid). Идемпотентно. В Timetta ничего не пишет (нет сетевых
    вызовов). RETIRE-WRITE-1: обратную сторону Guid→хаб в crosswalk (``vault_id``) не
    ведём — читателей у неё не было, а единственный писатель (reflect) ушёл в архив.
    Возвращает ``{ok, hub_id, deal:{code,name}, timetta_id, changed, path}``.
    Аудит — ``record_action``.
    """
    from core.config import (
        default_vault_path,
        timetta_mirror_path,
    )
    from core.operational.pult import record_action
    from core.operational.timetta.mirror import MirrorStore

    vault = (Path(vault_path) if vault_path else default_vault_path()).resolve()
    guid = str(deal_guid or "").strip()
    if not guid:
        raise HubLinkError("пустой deal_guid")

    store = MirrorStore(mirror_path or timetta_mirror_path())
    deal = _find_deal(store, guid)  # validates guid ∈ mirror

    note = _resolve_hub(hub_id, vault)
    path = _guarded_path(note, vault)

    text = path.read_text(encoding="utf-8")
    new_text, _prev, changed = _set_frontmatter_timetta_id(text, guid)
    if changed:
        path.write_text(new_text, encoding="utf-8")

    result = {
        "ok": True,
        "hub_id": note.id,
        "deal": {"code": deal.get("code"), "name": deal.get("name")},
        "timetta_id": guid,
        "changed": changed,
        "path": str(path),
    }
    record_action(
        "pult_hub_link_deal",
        {"hub_id": note.id, "deal_guid": guid, "changed": changed},
        "linked",
    )
    if changed:
        _drop_deals_cache()
    return result


def unlink_hub_from_deal(
    hub_id: str,
    *,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Снять связь хаба со сделкой: очистить `timetta_id` во frontmatter.

    Обратная к :func:`link_hub_to_deal`. Хирургически обнуляет строку
    ``timetta_id:`` (шаблонная пустая форма — хаб снова считается «дозревшим
    лидом»). Идемпотентно. Только vault. Возвращает
    ``{ok, hub_id, changed, previous}``. Аудит — ``record_action``.
    """
    from core.config import default_vault_path
    from core.operational.pult import record_action

    vault = (Path(vault_path) if vault_path else default_vault_path()).resolve()
    note = _resolve_hub(hub_id, vault)
    path = _guarded_path(note, vault)

    text = path.read_text(encoding="utf-8")
    new_text, previous, changed = _set_frontmatter_field(
        text, "timetta_id", "", insert_missing=False
    )
    if changed:
        path.write_text(new_text, encoding="utf-8")

    record_action(
        "pult_hub_unlink_deal",
        {"hub_id": note.id, "changed": changed},
        "unlinked",
    )
    if changed:
        _drop_deals_cache()
    return {"ok": True, "hub_id": note.id, "changed": changed, "previous": previous}
