"""Общий разбор frontmatter хабов: даты, дедлайн, обход хабовой ветки (DEV-1D-DETECT).

Разбор ``created``/``deadline`` и обход ``03-projects`` жили внутри
:mod:`core.operational.ripe_leads` приватными хелперами. Детектору «дедлайн хаба»
(DEV-1d PART-3) нужно ровно то же — и ТЗ прямо требует не заводить вторую копию
парсинга. Поэтому общее вынесено сюда, а ``ripe_leads`` импортирует его отсюда:
одна семантика даты и один обход на оба детектора.

Read-only, без сети; ``core`` ⊥ mcp/cli.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, date, datetime
from pathlib import Path
from typing import Any

from core.vault import Note, read_note

__all__ = [
    "HUB_DIR",
    "as_datetime",
    "first_present",
    "hub_created",
    "hub_deadline",
    "iter_hubs",
    "to_utc",
]

# Где живут workspace-хабы (пресейлы/проекты) — их кладут туда new-project/
# new-presale. Скан ограничен этой ветвью: read_note по всему vault — секунды.
HUB_DIR = "03-projects"


def to_utc(dt: datetime) -> datetime:
    return dt if dt.tzinfo else dt.replace(tzinfo=UTC)


def as_datetime(value: Any) -> datetime | None:
    """frontmatter ``created``/``deadline`` → aware datetime (date|datetime|ISO-строка).

    YAML отдаёт ``date`` для ``2026-08-14``, ``datetime`` для полной метки и строку,
    если значение в кавычках — все три формы должны читаться одинаково, иначе дедлайн
    «то виден, то нет» в зависимости от того, как его набрали руками.
    """
    if isinstance(value, datetime):
        return to_utc(value)
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day, tzinfo=UTC)
    if isinstance(value, str) and value.strip():
        try:
            return to_utc(datetime.fromisoformat(value.strip().replace("Z", "+00:00")))
        except ValueError:
            return None
    return None


def first_present(fm: dict[str, Any], *keys: str) -> Any:
    """Первое непустое значение из ``keys`` (синонимы полей frontmatter)."""
    for key in keys:
        if fm.get(key) not in (None, ""):
            return fm.get(key)
    return None


def hub_created(fm: dict[str, Any]) -> datetime | None:
    """Дата создания хаба/заметки: ``created`` → ``date``."""
    return as_datetime(first_present(fm, "created", "date"))


def hub_deadline(fm: dict[str, Any]) -> datetime | None:
    """Дедлайн хаба: ``deadline`` → ``due`` (синонимы, как их пишут руками)."""
    return as_datetime(first_present(fm, "deadline", "due"))


def iter_hubs(
    vault_path: Path, *, subdir: str = HUB_DIR, entities: frozenset[str] | None = None
) -> Iterator[tuple[Path, Note]]:
    """Пройти хабы (``type: hub``) в ``<vault>/<subdir>`` — по одному ``read_note``.

    ``entities`` — фильтр по ``entity`` (напр. ``{"project", "deal"}``); ``None`` —
    любые хабы. Нечитаемые файлы пропускаются молча: детектор не должен падать из-за
    одной битой заметки.
    """
    root = Path(vault_path) / subdir
    if not root.is_dir():
        return
    for path in sorted(root.rglob("*.md")):
        try:
            note = read_note(path)
        except (OSError, ValueError):
            continue
        fm = note.frontmatter
        if fm.get("type") != "hub":
            continue
        if entities is not None and str(fm.get("entity") or "") not in entities:
            continue
        yield path, note
