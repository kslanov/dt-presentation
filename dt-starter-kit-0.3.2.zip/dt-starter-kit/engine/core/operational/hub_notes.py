"""Дописать строку-ссылку в заметку хаба (Слой 1: «Задача + в существующий хаб»).

Детерминированная запись из пульта: добавляет строку под секцию ``## Связанное``
(создаёт, если её нет). Containment-guard — только внутрь vault; идемпотентно
(точная строка не дублируется). Ничего не удаляет, frontmatter не трогает.

HUB-SYNTH-1: :func:`upsert_section` - единственный хирургический писатель СЕКЦИИ хаба (замена
«## Состояние (на …)» с переносом прежней под «## Архив состояний»). Пишет только по решению
человека (approve карточки ``synth``), остальной файл байт-в-байт.
"""

from __future__ import annotations

import os
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

__all__ = [
    "ARCHIVE_HEADING",
    "HubNoteError",
    "SECTION_PREFIX",
    "LEGACY_SECTION_PREFIXES",
    "append_reference",
    "append_section_lines",
    "attach_note_to_hub",
    "read_section",
    "set_note_field",
    "upsert_section",
]

SECTION_PREFIX = "## Состояние (на "
# Ручная секция К. («## Текущее взаимодействие (на 30.09.2026)») - ее синтез заменяет, прежняя
# уходит в архив, а не пропадает.
LEGACY_SECTION_PREFIXES = ("## Текущее взаимодействие (на",)
ARCHIVE_HEADING = "## Архив состояний"

# Существующие хабы используют разные формы («## Связано» / «## Связанное») —
# дописываем под любую найденную; если секции нет — создаём _SECTION_NEW.
_SECTION_RE = re.compile(r"(?m)^##\s+Связан\w*\s*$")
_SECTION_NEW = "## Связанное"


class HubNoteError(ValueError):
    """Некорректный путь/пустой текст/нет заметки."""


def append_reference(
    note_path: str | Path,
    text: str,
    *,
    vault_path: str | Path,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Добавить ``- <дата> — <text>`` в заметку хаба по ссылке ``note_path``.

    Возвращает ``{added, path, line}``. ``added=False`` — строка уже была.

    **CONTRACT-1 ФП-1 (Д5).** Ссылка резолвится единой точкой
    :func:`core.vault.resolve_note_path`, поэтому принимается и **id хаба** — та самая
    форма, которую отдают ``pult_create_hub``/``pult_ripe_leads``/детектор кандидатов
    (раньше здесь был только путь, и `pult_hub_add_note("client-acme")` отвечал
    «no such note» на свежесозданный хаб). Containment не ослаблен: резолвер возвращает
    только пути внутри vault.
    """
    now = now or datetime.now(UTC)
    vault = Path(vault_path).resolve()
    raw = Path(str(note_path)).expanduser()
    candidate = (vault / raw if not raw.is_absolute() else raw).resolve()
    if raw.is_absolute() and candidate != vault and vault not in candidate.parents:
        raise HubNoteError("path escapes vault")
    from core.vault import resolve_note_path

    resolved = resolve_note_path(str(note_path), vault_path=vault)
    if resolved is None:
        raise HubNoteError(f"no such note: {note_path}")
    p = resolved

    text = " ".join((text or "").split()).strip()
    if not text:
        raise HubNoteError("empty text")
    line = f"- {now:%Y-%m-%d} — {text}"

    body = p.read_text(encoding="utf-8")
    if line in body:
        return {"added": False, "path": str(p.relative_to(vault)), "line": line}

    m = _SECTION_RE.search(body)
    if m:
        head_end = body.find("\n", m.start())
        insert_at = head_end + 1 if head_end != -1 else len(body)
        new = body[:insert_at] + line + "\n" + body[insert_at:]
    else:
        sep = "" if body.endswith("\n") else "\n"
        new = f"{body}{sep}\n{_SECTION_NEW}\n{line}\n"
    p.write_text(new, encoding="utf-8")
    rel = str(p.relative_to(vault))
    # PULT-EVENTLOG: заметка положена в хаб (стадия hub). CONTRACT-1 ФП-3 (Д8):
    # ``note_id`` — frontmatter id хаба (как у стадий index/link), путь живёт в ``path``.
    # Раньше сюда писался путь, и таймлайн артефакта расщеплялся на две половины: по id
    # не было hub-события, по пути — index/link. Текст ссылки в лог НЕ пишем
    # (приватность). Best-effort — не ломает запись.
    from core.eventlog import emit
    from core.vault import read_note

    try:
        hub_note_id = read_note(p).id or rel
    except (OSError, ValueError):
        hub_note_id = rel
    emit("hub", "added", note_id=hub_note_id, path=rel, detail={"section": "Связанное"})
    return {"added": True, "path": rel, "line": line}


# --------------------------------------------------------------------------- #
# HUB-SYNTH-1: секция хаба (чтение / замена с архивом)
# --------------------------------------------------------------------------- #
_H12_RE = re.compile(r"^#{1,2}\s")
_FENCE_RE = re.compile(r"^\s*(```|~~~)")
_AS_OF_RE = re.compile(r"\(на\s+(\d{2})\.(\d{2})\.(\d{4})\)")


def _h2_spans(lines: list[str]) -> list[tuple[int, int, str]]:
    """``[(начало, конец, текст заголовка)]`` секций уровня H2 (конец - индекс следующего H1/H2).

    Заголовки внутри ограждённых блоков кода не считаются."""
    heads: list[tuple[int, str]] = []
    fenced = False
    for i, ln in enumerate(lines):
        if _FENCE_RE.match(ln):
            fenced = not fenced
            continue
        if not fenced and _H12_RE.match(ln):
            heads.append((i, ln.rstrip("\r")))
    spans: list[tuple[int, int, str]] = []
    for n, (start, head) in enumerate(heads):
        if not head.startswith("## "):
            continue
        end = heads[n + 1][0] if n + 1 < len(heads) else len(lines)
        spans.append((start, end, head))
    return spans


def _find_span(
    spans: list[tuple[int, int, str]], prefix: str, legacy: tuple[str, ...]
) -> tuple[tuple[int, int, str], str] | None:
    for span in spans:
        if span[2].startswith(prefix):
            return span, "section"
    for span in spans:
        if any(span[2].startswith(p) for p in legacy):
            return span, "legacy"
    return None


def as_of_date(heading: str) -> str | None:
    """``## Состояние (на 30.09.2026)`` -> ``2026-09-30`` (нет даты - ``None``)."""
    m = _AS_OF_RE.search(heading)
    return f"{m.group(3)}-{m.group(2)}-{m.group(1)}" if m else None


def read_section(
    text: str, prefix: str = SECTION_PREFIX, legacy_prefixes: tuple[str, ...] = ()
) -> dict[str, Any] | None:
    """Секция хаба по префиксу заголовка: ``{heading, text, as_of, source: section|legacy}``.

    Ищет ``prefix`` (живая секция синтеза), затем ``legacy_prefixes`` (ручная секция К.).
    ``text`` - тело без строки заголовка. Нет секции - ``None``. Только чтение."""
    lines = text.split("\n")
    found = _find_span(_h2_spans(lines), prefix, legacy_prefixes)
    if found is None:
        return None
    (start, end, head), source = found
    body = "\n".join(ln.rstrip("\r") for ln in lines[start + 1 : end]).strip("\n")
    return {"heading": head, "text": body, "as_of": as_of_date(head), "source": source}


def _archive_entry(heading: str, body: str, now: datetime) -> str:
    title = heading[3:].strip()
    return (
        f"<details>\n<summary>{title} · архивировано {now:%d.%m.%Y}</summary>\n\n"
        f"{body.strip(chr(10))}\n\n</details>"
    )


def _put_in_archive(text: str, archive_heading: str, entry: str) -> str:
    """Положить запись архива первой под ``archive_heading`` (создать секцию в конце, если нет)."""
    lines = text.split("\n")
    for start, _end, head in _h2_spans(lines):
        if head.strip() == archive_heading.strip():
            head_part = "\n".join(lines[: start + 1])
            rest = "\n".join(lines[start + 1 :]).lstrip("\n")
            return f"{head_part}\n\n{entry}\n" + (f"\n{rest}" if rest else "")
    sep = "" if text.endswith("\n") or not text else "\n"
    return f"{text}{sep}\n{archive_heading}\n\n{entry}\n"


def upsert_section(
    note_path: str | Path,
    heading_prefix: str,
    body: str,
    *,
    archive_heading: str,
    vault_path: str | Path,
    legacy_prefixes: tuple[str, ...] = (),
    frontmatter: dict[str, str] | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Заменить секцию хаба ``heading_prefix`` на ``body``, прежнюю унести под ``archive_heading``.

    ``body`` - вся новая секция, ПЕРВАЯ строка - ее заголовок (обязан начинаться с
    ``heading_prefix``). Прежняя секция - первая H2 с этим префиксом, иначе первая с одним из
    ``legacy_prefixes`` (ручная секция К. после первого синтеза уходит в архив). Нет прежней -
    новая встает перед первой H2 (иначе в конец файла), архив не создается. Прежняя секция
    уходит в сворачиваемый ``<details>`` под ``archive_heading`` (секция создается в конце файла,
    если ее нет; свежая запись - первой). ``frontmatter`` (``{поле: готовый YAML-скаляр}``) -
    строки ``modified``/``synth_at`` обновляются на месте.

    Остальной файл байт-в-байт (файл целиком в CRLF остается в CRLF), containment-guard как у
    :func:`append_reference`, запись атомарна. Идемпотентно: секция с тем же телом -
    ``changed=False``, ничего не пишется и не архивируется. Возвращает ``{changed, path,
    replaced: section|legacy|None, archived: {heading, as_of} | None}``. Решение человека - у
    вызывающего (approve карточки).
    """
    from core.vault import (
        FrontmatterError,
        RawYaml,
        resolve_note_path,
        set_frontmatter_fields_text,
    )

    now = now or datetime.now(UTC)
    vault = Path(vault_path).resolve()
    raw = Path(str(note_path)).expanduser()
    candidate = (vault / raw if not raw.is_absolute() else raw).resolve()
    if raw.is_absolute() and candidate != vault and vault not in candidate.parents:
        raise HubNoteError("path escapes vault")
    p = resolve_note_path(str(note_path), vault_path=vault)
    if p is None:
        raise HubNoteError(f"no such note: {note_path}")
    new_body = (body or "").replace("\r\n", "\n").strip("\n")
    if not new_body or not new_body.split("\n", 1)[0].strip().startswith(heading_prefix):
        raise HubNoteError(f"секция должна начинаться с заголовка «{heading_prefix}…»")

    original = p.read_bytes().decode("utf-8")
    crlf = original.count("\r\n") == original.count("\n") > 0
    text = original.replace("\r\n", "\n") if crlf else original
    lines = text.split("\n")
    spans = _h2_spans(lines)
    found = _find_span(spans, heading_prefix, legacy_prefixes)
    out: dict[str, Any] = {
        "changed": False, "path": str(p.relative_to(vault)), "replaced": None, "archived": None,
    }

    if found is None:
        if not spans:
            sep = "" if text.endswith("\n") or not text else "\n"
            new_text = f"{text}{sep}\n{new_body}\n"
        else:
            at = spans[0][0]
            head = "\n".join(lines[:at])
            tail = "\n".join(lines[at:])
            new_text = f"{head}\n{new_body}\n\n{tail}"
    else:
        (start, end, old_head), kind = found
        old_block = "\n".join(lines[start:end])
        content = old_block.rstrip()
        trailing = old_block[len(content):]
        if kind == "section" and content == new_body:
            return out
        old_body = "\n".join(lines[start + 1 : end]).strip("\n")
        pre = "\n".join(lines[:start]) + "\n" if start > 0 else ""
        # трейлинг (пустые строки до следующего заголовка) и хвост файла - как были
        new_text = f"{pre}{new_body}{trailing}" + (
            "\n" + "\n".join(lines[end:]) if end < len(lines) else "")
        entry = _archive_entry(old_head, old_body, now)
        new_text = _put_in_archive(new_text, archive_heading, entry)
        out["replaced"] = kind
        out["archived"] = {"heading": old_head[3:].strip(), "as_of": as_of_date(old_head)}
    if frontmatter:
        try:
            new_text, _prev, _changed = set_frontmatter_fields_text(
                new_text, {k: RawYaml(v) for k, v in frontmatter.items()})
        except FrontmatterError as exc:
            raise HubNoteError("во frontmatter нет YAML-блока - хаб не трогаю") from exc
    if crlf:
        new_text = new_text.replace("\n", "\r\n")
    tmp = p.with_name(p.name + ".synth-tmp")
    tmp.write_bytes(new_text.encode("utf-8"))
    os.replace(tmp, p)
    out["changed"] = True
    return out


# --------------------------------------------------------------------------- #
# KNOWLEDGE-LINT-1: хирургические писатели поля frontmatter и строк секции
# --------------------------------------------------------------------------- #
def _resolve_inside(note_path: str | Path, vault_path: str | Path) -> tuple[Path, Path]:
    """``(vault, файл заметки)`` с containment-guard как у :func:`upsert_section`."""
    from core.vault import resolve_note_path

    vault = Path(vault_path).resolve()
    raw = Path(str(note_path)).expanduser()
    candidate = (vault / raw if not raw.is_absolute() else raw).resolve()
    if raw.is_absolute() and candidate != vault and vault not in candidate.parents:
        raise HubNoteError("path escapes vault")
    p = resolve_note_path(str(note_path), vault_path=vault)
    if p is None:
        raise HubNoteError(f"no such note: {note_path}")
    return vault, p


def _write_text_atomic(p: Path, text: str, *, crlf: bool, suffix: str) -> None:
    out = text.replace("\n", "\r\n") if crlf else text
    tmp = p.with_name(p.name + suffix)
    tmp.write_bytes(out.encode("utf-8"))
    os.replace(tmp, p)


def set_note_field(
    note_path: str | Path, field: str, value: Any, *, vault_path: str | Path,
    raw_yaml: bool = False,
) -> dict[str, Any]:
    """Проставить ОДНО поле frontmatter заметки; остальной файл байт-в-байт (CRLF сохраняется).

    ``value`` - строка (кодируется как у ``write_note``) либо, при ``raw_yaml``, готовый
    YAML-скаляр/список. Нет поля - вставка после ``id:``; то же значение - ``changed=False``,
    файл не пишется. Запись атомарна. Возвращает ``{changed, path, field, previous}``.
    Решение человека - у вызывающего (карточка ``lint``: ``attach``/``mark``)."""
    from core.vault import FrontmatterError, RawYaml, set_frontmatter_fields_text

    vault, p = _resolve_inside(note_path, vault_path)
    original = p.read_bytes().decode("utf-8")
    crlf = original.count("\r\n") == original.count("\n") > 0
    text = original.replace("\r\n", "\n") if crlf else original
    new_value: str | RawYaml = RawYaml(str(value)) if raw_yaml else str(value)
    try:
        new_text, previous, changed = set_frontmatter_fields_text(text, {field: new_value})
    except FrontmatterError as exc:
        raise HubNoteError("во frontmatter нет YAML-блока - заметку не трогаю") from exc
    out = {"changed": changed, "path": str(p.relative_to(vault)), "field": field,
           "previous": previous.get(field, "")}
    if changed:
        _write_text_atomic(p, new_text, crlf=crlf, suffix=".lint-tmp")
    return out


def attach_note_to_hub(
    note_path: str | Path, hub_id: str, *, entity: str = "", vault_path: str | Path
) -> dict[str, Any]:
    """Привязать заметку к хабу ``hub_id`` полем frontmatter (хирургически, идемпотентно).

    ``entity`` хаба задает поле: ``client`` -> ``client: "[[hub]]"``, ``project`` -> ``project:
    "[[hub]]"`` (если поле пусто); иначе (и если ``client``/``project`` уже заняты) - дописывает
    ``[[hub]]`` в список ``links`` (существующие ссылки целы, дубль не пишется). Возвращает
    ``{changed, path, field, previous}``."""
    import json as _json

    import yaml  # type: ignore[import-untyped]

    from core.vault import _FM_BLOCK_RE, FrontmatterError, read_frontmatter_fields_text

    token = f"[[{str(hub_id).strip()}]]"
    vault, p = _resolve_inside(note_path, vault_path)
    text = p.read_bytes().decode("utf-8")
    m = _FM_BLOCK_RE.match(text.replace("\r\n", "\n"))
    if not m:
        raise HubNoteError("во frontmatter нет YAML-блока - заметку не трогаю")
    field = entity if entity in ("client", "project") else "links"
    if field != "links":
        try:
            current = read_frontmatter_fields_text(text, (field,))[field]
        except FrontmatterError as exc:
            raise HubNoteError("во frontmatter нет YAML-блока - заметку не трогаю") from exc
        if current.strip().strip("'\"") == token:
            return {"changed": False, "path": str(p.relative_to(vault)), "field": field,
                    "previous": current}
        if current.strip().strip("'\""):
            field = "links"  # поле занято чужим значением: не затираем, ссылка уходит в links
    if field != "links":
        return set_note_field(note_path, field, _json.dumps(token, ensure_ascii=False),
                              vault_path=vault_path, raw_yaml=True)
    try:
        loaded = yaml.safe_load(m.group(1)) or {}
    except yaml.YAMLError as exc:
        raise HubNoteError("frontmatter не разобран - заметку не трогаю") from exc
    raw = loaded.get("links") if isinstance(loaded, dict) else None
    links = [str(x) for x in raw] if isinstance(raw, list) else ([str(raw)] if raw else [])
    if token in links or str(hub_id).strip() in links:
        return {"changed": False, "path": str(p.relative_to(vault)), "field": "links",
                "previous": _json.dumps(links, ensure_ascii=False)}
    merged = [*links, token]
    return set_note_field(note_path, "links", _json.dumps(merged, ensure_ascii=False),
                          vault_path=vault_path, raw_yaml=True)


def append_section_lines(
    note_path: str | Path, heading: str, lines: list[str], *, vault_path: str | Path
) -> dict[str, Any]:
    """Дописать строки под H2 ``heading`` (создать секцию в конце файла, если ее нет).

    Строки, уже стоящие в секции, не дублируются (идемпотентно); остальной файл байт-в-байт, CRLF
    сохраняется, запись атомарна. ``heading`` - полная строка заголовка (``## Проверить (линт
    31.10.2026)``). Возвращает ``{changed, path, added}``; пустой список - ``HubNoteError``."""
    vault, p = _resolve_inside(note_path, vault_path)
    wanted = [" ".join(str(x).split()) for x in lines if str(x).strip()]
    if not wanted:
        raise HubNoteError("empty text")
    original = p.read_bytes().decode("utf-8")
    crlf = original.count("\r\n") == original.count("\n") > 0
    text = original.replace("\r\n", "\n") if crlf else original
    src = text.split("\n")
    out: dict[str, Any] = {"changed": False, "path": str(p.relative_to(vault)), "added": 0}
    span = next((sp for sp in _h2_spans(src) if sp[2].strip() == heading.strip()), None)
    if span is None:
        sep = "" if text.endswith("\n") or not text else "\n"
        new_text = f"{text}{sep}\n{heading}\n\n" + "\n".join(wanted) + "\n"
        out.update(changed=True, added=len(wanted))
    else:
        start, end, _head = span
        present = {ln.strip() for ln in src[start + 1 : end]}
        fresh = [w for w in wanted if w not in present]
        if not fresh:
            return out
        last = end
        while last > start + 1 and not src[last - 1].strip():
            last -= 1  # вставка сразу после последней непустой строки секции
        new_lines = [*src[:last], *fresh, *src[last:]]
        new_text = "\n".join(new_lines)
        out.update(changed=True, added=len(fresh))
    _write_text_atomic(p, new_text, crlf=crlf, suffix=".lint-tmp")
    return out
