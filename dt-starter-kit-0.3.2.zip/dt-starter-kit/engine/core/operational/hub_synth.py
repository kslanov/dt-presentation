"""HUB-SYNTH-1 - «Состояние хаба на дату» как ПРЕДЛОЖЕНИЕ: досье, проверка, карточка, запись.

Движок текст синтеза НЕ пишет (без LLM в ``core``): он собирает досье с локаторами и провенансом
(:func:`context`), проверяет присланный сессией текст детерминированно (:func:`propose`) и
кладет его в стор ``.derived/hub_synth.jsonl`` карточкой вида ``synth``; в хаб текст попадает
только по approve карточки (:func:`apply_card` →
:func:`core.operational.hub_notes.upsert_section`: хирургически, прежняя секция уходит в
«## Архив состояний»). Слой ИИ пульта (``pult_ai(kind="hub_synth")``) - тот же путь: промпт
досье -> провайдер -> :func:`propose`, никакого второго пути записи.

Досье (:func:`context`) переиспользует сборщики встречи
(:mod:`core.operational.hub_collect`): сделки зеркала, внешняя переписка по доменам,
заметки/файлы хаба из frontmatter-срезов, выходы 07-outputs с ``client`` в ``meta.yaml``,
факты стора. Каждый элемент дельты - с ЛОКАТОРОМ (``note_id`` / путь / ``deal:<код>`` /
ключ треда ``conv:…``), датой и 1-2 строками; NDA-пути в досье не попадают (тот же барьер, что
у индекса и ``find_notes``: :func:`core.privacy.any_nda`), почта уже прошла фильтры
приватности на инжесте. Только чтение, без сети.

Проверки :func:`propose` (до постановки в очередь): каждая строка-пункт несет >=1 локатор в
квадратных скобках, все локаторы входят в локаторы досье (иначе ``ungrounded`` с номерами пунктов),
``sources`` ⊆ локаторов, длина <= ``DT_SYNTH_MAX_CHARS``, нет путей с NDA-маркером (``privacy``),
стоп-период после отказа по хабу (``snoozed``); канон ИИ-маркеров - предупреждение, не отказ.
"""

from __future__ import annotations

import difflib
import hashlib
import json
import logging
import os
import re
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "ARCHIVE_HEADING",
    "CONTEXT_CHARS_ENV",
    "MAX_CHARS_ENV",
    "SECTION_PREFIX",
    "SNOOZE_DAYS_ENV",
    "STALE_DAYS_ENV",
    "SynthError",
    "SynthStore",
    "apply_card",
    "context",
    "delta_of",
    "parse_section",
    "propose",
    "run_ai",
    "stats",
    "store_path",
]

SECTION_PREFIX = "## Состояние (на "
ARCHIVE_HEADING = "## Архив состояний"
LEGACY_PREFIXES = ("## Текущее взаимодействие (на",)

CONTEXT_CHARS_ENV = "DT_SYNTH_CONTEXT_CHARS"
MAX_CHARS_ENV = "DT_SYNTH_MAX_CHARS"
SNOOZE_DAYS_ENV = "DT_SYNTH_SNOOZE_DAYS"
STALE_DAYS_ENV = "DT_SYNTH_STALE_DAYS"
DEFAULT_CONTEXT_CHARS = 40_000
DEFAULT_MAX_CHARS = 6_000
DEFAULT_SNOOZE_DAYS = 14
DEFAULT_STALE_DAYS = 60
DEFAULT_WINDOW_DAYS = 90
STALE_MIN_DELTA = 3  # хаб «просит сводку»: дельта не меньше стольких элементов

STATUS_PENDING = "pending"
STATUS_APPLIED = "applied"
STATUS_REJECTED = "rejected"
STATUS_SNOOZED = "snoozed"
STATUSES = (STATUS_PENDING, STATUS_APPLIED, STATUS_REJECTED, STATUS_SNOOZED)

# Порядок видов дельты в досье и в бюджете символов: что важнее для «состояния» - первым.
KINDS = ("deals", "mail", "outputs", "notes", "files", "facts")
_KIND_CAP = {"deals": 15, "mail": 30, "outputs": 15, "notes": 40, "files": 40, "facts": 30}
_LINE_CAP = 220
_SNIPPET_CAP = 200
_NOTE_SKIP_SOURCES = ("correspondence/", "conv:", "msg:")
_THREAD_KEY_RE = re.compile(r"(?:conv|msg):[^\s/]+")
_FACT_MIN_CONFIDENCE = 0.5

_GROUP_RE = re.compile(r"(?<!\[)\[([^\[\]\n]+)\](?![\]\(])")
_ITEM_PREFIX_RE = re.compile(r"^\s*(?:[-*•]|\d+[.)])\s+")
_UNCOVERED_RE = re.compile(r"^\W*не\s+покрыто\b", re.IGNORECASE)
_PATHLIKE_RE = re.compile(r"[^\s`'\"<>()\[\]{},;]*/[^\s`'\"<>()\[\]{},;]+")


class SynthError(ValueError):
    """Отказ синтеза: ``code`` машиночитаем (``hub_not_found``, ``ungrounded``, ``snoozed`` ...)."""

    def __init__(self, code: str, message: str, **extra: Any) -> None:
        super().__init__(message)
        self.code = code
        self.extra = extra


# --------------------------------------------------------------------------- #
# Настройки и пути                                                              #
# --------------------------------------------------------------------------- #
def _int_env(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    try:
        value = int(raw)
    except ValueError:
        return default
    return value if value > 0 else default


def context_chars() -> int:
    return _int_env(CONTEXT_CHARS_ENV, DEFAULT_CONTEXT_CHARS)


def max_chars() -> int:
    return _int_env(MAX_CHARS_ENV, DEFAULT_MAX_CHARS)


def snooze_days() -> int:
    return _int_env(SNOOZE_DAYS_ENV, DEFAULT_SNOOZE_DAYS)


def stale_days() -> int:
    return _int_env(STALE_DAYS_ENV, DEFAULT_STALE_DAYS)


def store_path() -> Path:
    from core.config import hub_synth_path

    return hub_synth_path()


def _now(now: datetime | None) -> datetime:
    if now is None:
        return datetime.now(UTC)
    return now.astimezone(UTC) if now.tzinfo else now.replace(tzinfo=UTC)


def _stamp(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _day(value: Any) -> str:
    """Дата ``YYYY-MM-DD`` из ISO-подобной строки (нет/мусор - пусто)."""
    from core.operational import work

    dt = work._parse_iso(value)
    return dt.date().isoformat() if dt is not None else ""


def _ru_date(day: str) -> str:
    return f"{day[8:10]}.{day[5:7]}.{day[0:4]}" if len(day) == 10 else day


def _cut(text: Any, n: int) -> str:
    s = " ".join(str(text or "").split())
    return s if len(s) <= n else s[: n - 1].rstrip() + "…"


# --------------------------------------------------------------------------- #
# Хаб                                                                          #
# --------------------------------------------------------------------------- #
def _vault(vault_path: Path | None) -> Path:
    from core.config import default_vault_path

    return Path(vault_path) if vault_path else default_vault_path()


def _load_hub(hub_id: str, vault: Path, *, any_entity: bool = False) -> dict[str, Any]:
    """Хаб-клиент: ``{id, title, entity, aliases, timetta_id, domains, path, text, meta}``.

    Нет хаба - ``hub_not_found``; не клиент - ``unsupported_entity`` (синтез пока только клиентам).
    ``any_entity`` (KNOWLEDGE-LINT-1: дельта для линта считается у любого хаба) снимает только
    эту проверку.
    """
    from core.operational import meetings
    from core.operational.hub_link import HubLinkError, _resolve_hub

    try:
        note = _resolve_hub(str(hub_id or "").strip(), vault)
    except HubLinkError as exc:
        raise SynthError("hub_not_found", str(exc)) from exc
    if str(getattr(note, "type", "") or "") != "hub":
        raise SynthError("hub_not_found", f"{note.id} не хаб (type: hub)")
    fm = dict(note.frontmatter)
    entity = str(fm.get("entity") or "")
    if entity != "client" and not any_entity:
        raise SynthError(
            "unsupported_entity",
            f"синтез состояния пока только для хабов-клиентов (entity={entity or '-'})",
        )
    path = Path(note.path)
    meta = meetings._read_hub(path) or {"id": note.id, "slug": note.id, "name": note.id,
                                        "aliases": []}

    def _list(value: Any) -> list[str]:
        if isinstance(value, list):
            return [str(v) for v in value if v]
        return [str(value)] if value else []

    title = next((ln[2:].strip() for ln in note.body.splitlines() if ln.startswith("# ")), "")
    return {
        "id": note.id,
        "title": title or str(meta.get("name") or note.id),
        "entity": entity,
        "aliases": _list(fm.get("aliases")),
        "timetta_id": str(fm.get("timetta_id") or "").strip(),
        "domains": [d.lower().strip() for d in
                    _list(fm.get("domains")) + _list(fm.get("counterparty_domains")) if d],
        "synth_at": _day(fm.get("synth_at")),
        "path": path,
        "rel": str(path.resolve().relative_to(vault.resolve())),
        "text": path.read_text(encoding="utf-8"),
        "meta": meta,
    }


def _current_state(text: str) -> dict[str, Any] | None:
    from core.operational.hub_notes import read_section

    found = read_section(text, SECTION_PREFIX, LEGACY_PREFIXES)
    if found is None:
        return None
    return {"text": found["text"], "as_of": found["as_of"], "heading": found["heading"],
            "source": "synth" if found["source"] == "section" else "manual"}


_REF_RES = (
    re.compile(r"legacy-[0-9a-f]{8,}"),
    re.compile(r"\b(?:conv|msg):[\w.\-@=+/]+"),
)
_BACKTICK_RE = re.compile(r"`([^`\n]+)`")


def _own_refs(section_text: str) -> list[str]:
    """Ссылки, которые К. уже поставил в нынешней секции (id заметок, ``conv:…``, пути в бэктиках):
    их можно переносить в новую секцию - они сами курируемые."""
    out: list[str] = []
    for rx in _REF_RES:
        out.extend(m.group(0) for m in rx.finditer(section_text))
    for m in _BACKTICK_RE.finditer(section_text):
        token = m.group(1).strip()
        if "/" in token and "…" not in token and not token.startswith("..."):
            out.append(token)
    return list(dict.fromkeys(out))


# --------------------------------------------------------------------------- #
# Сборщики дельты                                                               #
# --------------------------------------------------------------------------- #
def _in_window(day: str, since: str) -> bool:
    return bool(day) and day >= since


def _collect_deals(
    hub: dict[str, Any], since: str, mirror_path: Path | None
) -> list[dict[str, Any]]:
    from core.config import timetta_mirror_path
    from core.operational import hub_collect, work
    from core.operational.timetta.mirror import MirrorStore

    store = MirrorStore(mirror_path or timetta_mirror_path())
    try:
        deals = hub_collect.orbit_records(store, "deals")
    except (OSError, ValueError):
        return []
    code_by_id = work._state_code_map(store)
    hubs = [hub["meta"]]
    out: list[dict[str, Any]] = []
    for deal in deals:
        text = f"{deal.get('organization_name') or ''} {deal.get('name') or ''}"
        by_org = bool(hub["timetta_id"]) and str(deal.get("organization_id") or "") == hub[
            "timetta_id"]
        if hub["id"] not in hub_collect.clients_of(text, hubs) and not by_org:
            continue
        day = hub_collect.date_only(deal.get("modified")) or ""
        if not _in_window(day, since) or not deal.get("code"):
            continue
        view = hub_collect.deal_view(deal)
        out.append({
            "loc": f"deal:{view['code']}", "code": view["code"], "name": view["name"],
            "stage": view["stage"], "active": work._is_active(deal, code_by_id),
            "open_items": view["open_items"], "nearest_due": view["nearest_due"], "date": day,
        })
    out.sort(key=lambda d: d["date"], reverse=True)
    return out


def _last_inbound(threads_dir: Path | None, key: str) -> dict[str, str] | None:
    from core.operational import work

    sidecar = work._load_sidecar(threads_dir, key)
    if not isinstance(sidecar, dict):
        return None
    msgs = [m for m in (sidecar.get("messages") or {}).values()
            if isinstance(m, dict) and not m.get("is_me")]
    msgs.sort(key=lambda m: str(m.get("date") or ""))
    if not msgs:
        return None
    last = msgs[-1]
    line = ""
    for raw in str(last.get("text") or "").splitlines():
        s = raw.strip()
        if s and not s.startswith(">"):
            line = _cut(s, _SNIPPET_CAP)
            break
    return {"date": _day(last.get("date")), "line": line}


def _collect_mail(
    hub: dict[str, Any], since: str, now: datetime, mail_manifest: Path | None,
    threads_dir: Path | None,
) -> list[dict[str, Any]]:
    from core.config import outlook_ingest_manifest_path
    from core.operational import hub_collect, work
    from core.privacy import any_nda

    mail_path = mail_manifest or outlook_ingest_manifest_path()
    manifest = work._load_json(Path(mail_path))
    manifest = manifest if isinstance(manifest, dict) else None
    tdir = threads_dir or (Path(mail_path).parent / "mail_threads")
    since_dt = work._parse_iso(since) or now
    horizon = max(1, (now - since_dt).days + 1)
    recent = work._recent_external_mail(
        manifest, tdir, now=now, horizon_days=horizon, include_key=True)
    threads = hub_collect.mail_threads_for(
        hub["id"], recent, [hub["meta"]], counterparty_domains=hub["domains"])
    out: list[dict[str, Any]] = []
    for thread in threads:
        day = hub_collect.date_only(thread.get("last")) or ""
        if not _in_window(day, since) or not thread.get("key"):
            continue
        if any_nda(thread.get("note_path") or None):
            continue
        view = hub_collect.mail_view(thread)
        item: dict[str, Any] = {
            "loc": thread["key"], "subject": view["subject"], "date": day,
            "from": view["from"], "direction": view["direction"],
        }
        inbound = _last_inbound(tdir, thread["key"])
        if inbound:
            item["last_inbound"] = inbound
        out.append(item)
    return out


def _alias_pattern(hub: dict[str, Any]) -> re.Pattern[str] | None:
    """Регулярка по алиасам хаба (и заголовку) целым словом, без регистра; ``None`` - алиасов нет.

    Короткие (< 3 символов) и слишком общие (одно слово короче 4 символов латиницей) не берем:
    «ГП» или «ITH» как часть другого слова дали бы ложные попадания."""
    names = [str(a).strip() for a in (hub.get("aliases") or []) if str(a).strip()]
    title = str(hub.get("title") or "").strip()
    if title:
        names.append(title)
    names = [n for n in names if len(n) >= 3]
    if not names:
        return None
    alts = sorted({re.escape(n) for n in names}, key=len, reverse=True)
    body = "|".join(alts)
    return re.compile(rf"(?<![\w])(?:{body})(?![\w])", re.IGNORECASE)


def _collect_notes_files(
    hub: dict[str, Any], since: str, vault: Path,
    load_metas: Callable[[Path], tuple[list[Any], list[Any]]] | None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], int]:
    """Заметки хаба (corpus vault), файлы-источники (current/legacy) и треды, привязанные к хабу
    полями ``client``/``project``/``links`` заметки-треда (атрибуция), по frontmatter-срезам."""
    from core.privacy import any_nda
    from core.retrieval.notemeta import is_quarantined, owner_ids

    if load_metas is None:
        from core.retrieval.fm_cache import load_metas_cached

        load_metas = load_metas_cached
    metas, _warnings = load_metas(vault)
    notes: list[dict[str, Any]] = []
    files: list[dict[str, Any]] = []
    threads: list[dict[str, Any]] = []
    undated = 0
    # Приемка 31.10 (канарейка дочернего клиента): файлы дочернего клиента атрибутируются папкой на
    # родительский хаб (CDT_Internal/Russia/Initech/ITH → client-initech), и досье по атрибуции
    # было пустым (notes 0, files 0) при 10+ свежих заметках с «ИТХ» в заголовке/пути. Второй
    # признак - алиас хаба (>= 3 символов, целым словом) в заголовке или пути источника.
    alias_re = _alias_pattern(hub)
    for meta in metas:
        if meta.id == hub["id"] or meta.note_type in ("hub", "output", "output-sources"):
            continue
        if meta.path.startswith("07-outputs/"):
            continue
        if is_quarantined(meta):  # EVAL-HYGIENE-1: прогоны eval/selftest и файлы _eval - не знание
            continue
        if hub["id"] not in owner_ids(meta):
            probe = f"{meta.title or ''} {meta.source_path or ''} {meta.path or ''}"
            if alias_re is None or not alias_re.search(probe):
                continue
        source = str(meta.source_path or "")
        if any_nda(meta.path, source):
            continue
        day = _day(meta.date)
        if not day:
            undated += 1
            continue
        if day < since:
            continue
        if source.startswith(_NOTE_SKIP_SOURCES):
            key = _THREAD_KEY_RE.search(source)
            if key:  # почтовый тред, привязанный к хабу атрибуцией: идет в «mail», не в заметки
                threads.append({"loc": key.group(0), "subject": _cut(meta.title or meta.id, 120),
                                "date": day})
            continue
        if meta.corpus in ("current", "legacy"):
            files.append({"loc": source or meta.path, "title": _cut(meta.title or meta.id, 120),
                          "date": day, "note_id": meta.id})
        else:
            notes.append({"loc": meta.id, "title": _cut(meta.title or meta.id, 120),
                          "date": day, "path": meta.path})
    notes.sort(key=lambda n: n["date"], reverse=True)
    files.sort(key=lambda n: n["date"], reverse=True)
    return notes, files, threads, undated


def _merge_linked_mail(
    mail: list[dict[str, Any]], linked: list[dict[str, Any]], mail_manifest: Path | None,
    threads_dir: Path | None,
) -> list[dict[str, Any]]:
    """К тредам по доменам добавить треды, привязанные к хабу в vault (без дублей по ключу)."""
    from core.config import outlook_ingest_manifest_path

    have = {m["loc"] for m in mail}
    tdir = threads_dir or (Path(mail_manifest or outlook_ingest_manifest_path()).parent
                           / "mail_threads")
    out = list(mail)
    for t in linked:
        if t["loc"] in have:
            continue
        item: dict[str, Any] = {"loc": t["loc"], "subject": t["subject"], "date": t["date"],
                                "from": None, "direction": None, "linked": True}
        inbound = _last_inbound(tdir, t["loc"])
        if inbound:
            item["last_inbound"] = inbound
        out.append(item)
        have.add(t["loc"])
    out.sort(key=lambda m: m["date"], reverse=True)
    return out


def _read_yaml(path: Path) -> dict[str, Any]:
    import yaml  # type: ignore[import-untyped]

    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return {}
    return data if isinstance(data, dict) else {}


def _collect_outputs(hub: dict[str, Any], since: str, vault: Path) -> list[dict[str, Any]]:
    """Выходы ``07-outputs`` хаба: ``client`` в ``meta.yaml`` либо ``[[<хаб>]]`` в ``output.md``."""
    from core.privacy import any_nda
    from core.purpose import is_quarantined

    base = vault / "07-outputs"
    out: list[dict[str, Any]] = []
    if not base.is_dir():
        return out
    for meta_path in sorted(base.glob("*/*/meta.yaml")):
        folder = meta_path.parent
        rel = folder.relative_to(vault).as_posix()
        if any_nda(rel):
            continue
        meta = _read_yaml(meta_path)
        if is_quarantined(meta):  # EVAL-HYGIENE-1: прогон eval/selftest - не событие по клиенту
            continue
        day = _day(meta.get("finalized") or meta.get("created"))
        if not _in_window(day, since):
            continue
        raw_params = meta.get("params")
        params: dict[str, Any] = raw_params if isinstance(raw_params, dict) else {}
        owners = {str(meta.get("client") or ""), str(meta.get("client_id") or ""),
                  str(params.get("client_id") or ""), str(params.get("client") or "")}
        owners = {o.strip().strip("[]") for o in owners}
        mine = hub["id"] in owners
        if not mine:
            try:
                head = (folder / "output.md").read_text(encoding="utf-8")[:20000]
            except OSError:
                head = ""
            mine = f"[[{hub['id']}" in head
        if not mine:
            continue
        out.append({"loc": rel, "title": _cut(meta.get("title") or folder.name, 120),
                    "date": day, "status": str(meta.get("status") or ""),
                    "channel": str(meta.get("channel") or "")})
    out.sort(key=lambda o: o["date"], reverse=True)
    return out


def _default_facts(entity_ref: str, since_iso: str) -> list[Any]:
    from core.facts import get_facts

    return list(get_facts(entity_ref=entity_ref, fresher_than=since_iso,
                          min_confidence=_FACT_MIN_CONFIDENCE))


def _collect_facts(
    hub: dict[str, Any], since: str, facts_fn: Callable[[str, str], list[Any]] | None,
) -> list[dict[str, Any]]:
    from core.privacy import any_eval, any_nda

    fn = facts_fn or _default_facts
    try:
        rows = fn(hub["id"], since)
    except Exception as exc:  # noqa: BLE001 - нечитаемый стор фактов не роняет досье
        logger.warning("hub_synth: стор фактов не прочитан: %s", exc)
        return []
    previous = _previous_facts(rows)
    out: list[dict[str, Any]] = []
    for f in rows:
        source = str(getattr(f, "source_path", "") or "")
        if not source or any_nda(source) or any_eval(source):
            continue
        item: dict[str, Any] = {
            "loc": source, "kind": getattr(f, "kind", ""),
            "label": _cut(getattr(f, "label", ""), 80),
            "value": _cut(getattr(f, "value_raw", ""), 60),
            "unit": getattr(f, "unit", None) or getattr(f, "currency", None) or "",
            # FACTS-BITEMPORAL-1: «узнали» (known_at), а не момент подъема
            "date": _day(getattr(f, "known_at", None) or getattr(f, "extracted_at", "")),
        }
        prev = previous.get(str(getattr(f, "prev_fact_id", "") or ""))
        if prev is not None and not any_nda(str(getattr(prev, "source_path", "") or "")) and (
            getattr(prev, "value_raw", None) != getattr(f, "value_raw", None)
        ):
            item["changed_from"] = _cut(getattr(prev, "value_raw", ""), 60)  # факт вытеснил прежний
        out.append(item)
    out.sort(key=lambda f: f["date"], reverse=True)
    return out


def _previous_facts(rows: list[Any]) -> dict[str, Any]:
    """Предшественники фактов дельты по ``prev_fact_id`` (стор; сбой - без ``changed_from``)."""
    ids = [str(getattr(f, "prev_fact_id", "") or "") for f in rows]
    ids = [i for i in ids if i]
    if not ids:
        return {}
    try:
        from core.facts.store import facts_by_ids

        return facts_by_ids(ids)
    except Exception:  # noqa: BLE001 - история фактов не условие досье
        return {}


# --------------------------------------------------------------------------- #
# Строки досье и бюджет                                                         #
# --------------------------------------------------------------------------- #
def _line(kind: str, e: dict[str, Any]) -> str:
    """Одна строка дельты для промпта: ``[локатор] дата · суть`` (<= ~220 символов)."""
    loc, date_ = e["loc"], e.get("date") or "-"
    if kind == "deals":
        body = (f"сделка {e['code']} «{e['name']}», стадия {e['stage'] or '-'}"
                f"{'' if e['active'] else ' (закрыта)'}, открытых пунктов {e['open_items']}"
                + (f", ближайший срок {e['nearest_due']}" if e.get("nearest_due") else ""))
    elif kind == "mail":
        body = f"письмо «{e['subject']}» ({e.get('from') or '-'}, {e.get('direction') or '?'})"
        inbound = e.get("last_inbound")
        if inbound and inbound.get("line"):
            body += f"; последний входящий {inbound['date']}: {inbound['line']}"
    elif kind == "outputs":
        body = f"выход «{e['title']}» ({e.get('status') or '-'}, {e.get('channel') or '-'})"
    elif kind == "facts":
        body = f"факт {e['kind']}: {e['label']} = {e['value']} {e['unit']}".strip()
        if e.get("changed_from"):
            body += f" (было {e['changed_from']})"
    else:
        body = f"{'файл' if kind == 'files' else 'заметка'} «{e['title']}»"
    return _cut(f"[{loc}] {date_} · {body}", _LINE_CAP + len(loc))


def _budget(delta: dict[str, list[dict[str, Any]]], budget: int) -> tuple[
    dict[str, list[dict[str, Any]]], dict[str, int], int
]:
    """Поровну по видам, новое первым, пока влезает в ``budget`` символов строк досье.

    Возвращает ``(усеченная дельта, сколько отброшено по видам, использовано символов)``."""
    kept: dict[str, list[dict[str, Any]]] = {k: [] for k in KINDS}
    used = 0
    cursor = dict.fromkeys(KINDS, 0)
    progressed = True
    while progressed:
        progressed = False
        for kind in KINDS:
            items = delta[kind]
            i = cursor[kind]
            if i >= len(items):
                continue
            cost = len(_line(kind, items[i])) + 1
            if used + cost > budget:
                cursor[kind] = len(items)  # дальше этого вида - вне бюджета (свежее уже взято)
                continue
            kept[kind].append(items[i])
            cursor[kind] = i + 1
            used += cost
            progressed = True
    dropped = {k: len(delta[k]) - len(kept[k]) for k in KINDS if len(delta[k]) > len(kept[k])}
    return kept, dropped, used


# --------------------------------------------------------------------------- #
# Промпт                                                                        #
# --------------------------------------------------------------------------- #
def _style_text(vault: Path | None = None) -> tuple[str, str]:
    """``(текст раздела [Style guide], причина недоступности)`` из канона ``ai-markers``."""
    from core.config import ai_markers_path
    from core.style_markers import CanonUnavailable, load_canon

    try:
        canon = load_canon(ai_markers_path(vault) if vault else None)
    except CanonUnavailable as exc:
        return "(канон ИИ-маркеров недоступен: пиши сухо, по-деловому, без штампов)", str(exc)
    parts = ["Деловой русский текст без ИИ-штампов. Правила канона ai-markers:"]
    if canon.ban_typography:
        parts.append("- не используй: " + " ".join(canon.ban_typography))
    if canon.ban_phrases:
        parts.append("- запрещенные фразы: " + "; ".join(canon.ban_phrases[:40]))
    if canon.ban_emoji:
        parts.append("- без эмодзи")
    if canon.density_phrases:
        parts.append("- редко и только по делу связки: " + "; ".join(canon.density_phrases[:25]))
    if canon.calques:
        parts.append("- кальки (вместо -> как правильно): " + "; ".join(
            f"{a} -> {b}" for a, b in canon.calques[:15] if b))
    if canon.question_headings:
        parts.append("- без вопросительных заголовков")
    if canon.triads:
        parts.append("- без механических триад («быстро, надежно, масштабируемо»)")
    return "\n".join(parts), ""


def _task_text(as_of: str) -> str:
    return (
        f"Собери секцию хаба «## Состояние (на {_ru_date(as_of)})». Требования:\n"
        "- 5-12 пунктов, каждый - отдельная строка, начинающаяся с «- »;\n"
        "- в конце КАЖДОГО пункта локатор в квадратных скобках ровно из блока [Delta] "
        "(например [legacy-1234abcd5678] или [deal:D-9]); несколько локаторов - через «; »; "
        "квадратные скобки больше ни для чего не используй;\n"
        "- пиши только то, что есть в [Delta] и в [Current state]; никаких выводов сверх "
        "источников, оценок и догадок; суммы и даты - дословно из строк досье;\n"
        "- пункт из [Current state] переноси, только если подтверждает свежий элемент [Delta] "
        "(с его локатором); то, что в [Current state] устарело или опровергнуто, пометь в пункте "
        "словом «устарело:» с локатором того, что это показывает;\n"
        "- последним блоком - строка «Не покрыто: …» (что важно для состояния клиента, но в "
        "[Delta] отсутствует; негативный провенанс), без локаторов;\n"
        "- верни только текст секции, начиная с заголовка; в хаб текст не записывается, его "
        "решит человек карточкой."
    )


def _render_delta(delta: dict[str, list[dict[str, Any]]]) -> str:
    titles = {"deals": "Сделки (Timetta)", "mail": "Переписка", "outputs": "Выходы (07-outputs)",
              "notes": "Заметки хаба", "files": "Файлы-источники", "facts": "Факты"}
    blocks: list[str] = []
    for kind in KINDS:
        if delta[kind]:
            blocks.append(f"## {titles[kind]}\n" + "\n".join(_line(kind, e) for e in delta[kind]))
    return "\n\n".join(blocks) if blocks else "(новых элементов за период нет)"


def _build_prompt(
    *, hub: dict[str, Any], since: str, as_of: str, current: dict[str, Any] | None,
    delta: dict[str, list[dict[str, Any]]], vault: Path,
) -> tuple[str, str]:
    from core.config import user_display_name
    from core.owner import load_profile

    owner = load_profile(vault)
    style, style_error = _style_text(vault)
    sections = [f"[System] You are assisting {user_display_name(vault)}. Write in their voice."]
    if owner.about:
        sections.append(f"[Owner]\n{owner.about}")
    sections.append(f"[Style guide]\n{style}")
    if current:
        label = "ручная секция владельца" if current["source"] == "manual" else "секция синтеза"
        sections.append(
            f"[Current state]\n({label} «{current['heading'][3:]}»)\n{current['text']}")
    else:
        sections.append("[Current state]\n(секции состояния в хабе еще нет)")
    sections.append(
        f"[Delta]\nХаб {hub['id']} «{hub['title']}», период с {_ru_date(since)} "
        f"по {_ru_date(as_of)}. Локатор - в квадратных скобках в начале строки.\n\n"
        + _render_delta(delta))
    sections.append(f"[Task]\n{_task_text(as_of)}")
    return "\n\n".join(sections), style_error


# --------------------------------------------------------------------------- #
# Досье                                                                         #
# --------------------------------------------------------------------------- #
def _resolve_since(since: str | None, hub: dict[str, Any], now: datetime) -> tuple[str, str]:
    if since:
        day = _day(since)
        if not day:
            raise SynthError("bad_since", f"since: ожидается дата ГГГГ-ММ-ДД, получено {since!r}")
        return day, "param"
    if hub["synth_at"]:
        return hub["synth_at"], "synth_at"
    return (now - timedelta(days=DEFAULT_WINDOW_DAYS)).date().isoformat(), "default"


def _collect_delta(
    hub: dict[str, Any], since_day: str, cur: datetime, vault: Path, *,
    mirror_path: Path | None = None, mail_manifest: Path | None = None,
    mail_threads_dir: Path | None = None,
    facts_fn: Callable[[str, str], list[Any]] | None = None,
    load_metas: Callable[[Path], tuple[list[Any], list[Any]]] | None = None,
) -> tuple[dict[str, list[dict[str, Any]]], int]:
    """Дельта хаба по видам (все сборщики, без обрезки бюджетом) и число недатированных заметок.

    Один набор сборщиков для досье (:func:`context`) и линта (:func:`delta_of`)."""
    delta_all: dict[str, list[dict[str, Any]]] = {
        "deals": _collect_deals(hub, since_day, mirror_path),
        "mail": _collect_mail(hub, since_day, cur, mail_manifest, mail_threads_dir),
        "outputs": _collect_outputs(hub, since_day, vault),
    }
    notes, files, linked, undated = _collect_notes_files(hub, since_day, vault, load_metas)
    delta_all["notes"], delta_all["files"] = notes, files
    delta_all["mail"] = _merge_linked_mail(delta_all["mail"], linked, mail_manifest,
                                           mail_threads_dir)
    delta_all["facts"] = _collect_facts(hub, since_day, facts_fn)
    return delta_all, undated


def delta_of(
    hub_id: str, since: str, *, vault_path: Path | None = None, mirror_path: Path | None = None,
    mail_manifest: Path | None = None, mail_threads_dir: Path | None = None,
    now: datetime | None = None,
    facts_fn: Callable[[str, str], list[Any]] | None = None,
    load_metas: Callable[[Path], tuple[list[Any], list[Any]]] | None = None,
) -> dict[str, Any]:
    """Дельта ЛЮБОГО хаба с даты ``since`` для линта: ``{hub, since, counts, delta}``.

    Те же сборщики, что у :func:`context` (не второй раз), но без промпта/бюджета и без ограничения
    «только клиент». Отказ - :class:`SynthError` (``hub_not_found``)."""
    cur = _now(now)
    vault = _vault(vault_path)
    hub = _load_hub(hub_id, vault, any_entity=True)
    since_day = _day(since)
    if not since_day:
        raise SynthError("bad_since", f"since: ожидается дата ГГГГ-ММ-ДД, получено {since!r}")
    delta, _undated = _collect_delta(
        hub, since_day, cur, vault, mirror_path=mirror_path, mail_manifest=mail_manifest,
        mail_threads_dir=mail_threads_dir, facts_fn=facts_fn, load_metas=load_metas)
    return {"hub": {"id": hub["id"], "title": hub["title"], "entity": hub["entity"],
                    "path": hub["rel"]},
            "since": since_day, "counts": {k: len(v) for k, v in delta.items()}, "delta": delta}


def context(
    hub_id: str,
    since: str | None = None,
    *,
    vault_path: Path | None = None,
    mirror_path: Path | None = None,
    mail_manifest: Path | None = None,
    mail_threads_dir: Path | None = None,
    now: datetime | None = None,
    budget_chars: int | None = None,
    facts_fn: Callable[[str, str], list[Any]] | None = None,
    load_metas: Callable[[Path], tuple[list[Any], list[Any]]] | None = None,
) -> dict[str, Any]:
    """Досье для синтеза состояния хаба ``hub_id`` (read-only, без сети и LLM).

    ``{hub: {id, title, entity, aliases, current_state: {text, as_of, source} | null, synth_at},
    since, since_source, as_of, delta: {deals, mail, outputs, notes, files, facts}, locators,
    prompt, limits: {budget_chars, used_chars, truncated, dropped, counts}}`` + конверт
    ``warning`` (хаб без ``timetta_id``/доменов; канон стиля недоступен). ``since``: параметр, иначе
    ``synth_at`` из frontmatter, иначе 90 дней. Бюджет ``DT_SYNTH_CONTEXT_CHARS`` режет дельту
    поровну по видам, новое первым; урезание - в ``limits`` (честный ``truncated``).
    Отказ - :class:`SynthError` (``hub_not_found`` | ``unsupported_entity`` | ``bad_since``)."""
    from core.contract import add_warning

    cur = _now(now)
    vault = _vault(vault_path)
    hub = _load_hub(hub_id, vault)
    since_day, since_source = _resolve_since(since, hub, cur)
    as_of = cur.date().isoformat()

    delta_all, undated = _collect_delta(
        hub, since_day, cur, vault, mirror_path=mirror_path, mail_manifest=mail_manifest,
        mail_threads_dir=mail_threads_dir, facts_fn=facts_fn, load_metas=load_metas)
    counts = {k: len(v) for k, v in delta_all.items()}
    capped = {k: v[: _KIND_CAP[k]] for k, v in delta_all.items()}
    capped_off = {k: counts[k] - len(capped[k]) for k in KINDS if counts[k] > len(capped[k])}

    budget = budget_chars if budget_chars is not None else context_chars()
    delta, dropped, used = _budget(capped, budget)
    for k, n in capped_off.items():
        dropped[k] = dropped.get(k, 0) + n

    current = _current_state(hub["text"])
    locators = [e["loc"] for k in KINDS for e in delta[k]]
    own = [r for r in (_own_refs(current["text"]) if current else [])
           if r not in locators]
    from core.privacy import any_nda

    own = [r for r in own if not any_nda(r)]
    prompt, style_error = _build_prompt(
        hub=hub, since=since_day, as_of=as_of, current=current, delta=delta, vault=vault)
    out: dict[str, Any] = {
        "hub": {
            "id": hub["id"], "title": hub["title"], "entity": hub["entity"],
            "aliases": hub["aliases"], "current_state": current,
            "synth_at": hub["synth_at"] or None, "path": hub["rel"],
        },
        "since": since_day, "since_source": since_source, "as_of": as_of,
        "delta": delta,
        "locators": list(dict.fromkeys(locators + own)),
        "current_refs": own,
        "prompt": prompt,
        "limits": {
            "budget_chars": budget, "used_chars": used, "truncated": bool(dropped),
            "dropped": dropped, "counts": counts, "undated_skipped": undated,
            "max_chars": max_chars(),
        },
    }
    if not hub["timetta_id"] and not hub["domains"]:
        add_warning(
            out, "partial",
            f"у хаба {hub['id']} нет timetta_id и доменов: сделки подбираются по имени клиента, "
            "переписка - по имени в теме; досье опирается на заметки, выходы и файлы",
            hub_id=hub["id"],
        )
    if style_error:
        add_warning(out, "store_unavailable", style_error + " - в промпт ушло краткое правило",
                    component="ai_markers")
    if not any(counts.values()):
        add_warning(out, "partial", "за период нет ни одного нового элемента: синтезировать нечего",
                    since=since_day)
    return out


# --------------------------------------------------------------------------- #
# Разбор и проверка текста                                                      #
# --------------------------------------------------------------------------- #
def _split_group(group: str, known: set[str]) -> list[str]:
    g = group.strip()
    if g in known:
        return [g]
    for sep in (";", ","):
        parts = [p.strip() for p in g.split(sep) if p.strip()]
        if len(parts) > 1:
            return parts
    return [g]


def parse_section(text: str, known: set[str] | None = None) -> dict[str, Any]:
    """Разобрать присланную секцию: ``{heading, items: [{n, text, locators}], uncovered, body}``.

    Пункт - любая непустая строка основной части (не заголовок, не HTML-комментарий, не
    «Источники:», не блок «Не покрыто»); отступные строки продолжают предыдущий пункт. Локаторы -
    группы в одиночных квадратных скобках (не ``[[вики]]`` и не ``[текст](ссылка)``)."""
    known = known or set()
    raw_lines = (text or "").replace("\r\n", "\n").strip("\n").split("\n")
    heading = ""
    items: list[dict[str, Any]] = []
    uncovered: list[str] = []
    in_uncovered = False
    body_lines: list[str] = []
    for raw in raw_lines:
        stripped = raw.strip()
        if not heading and stripped.startswith("## "):
            heading = stripped
            continue
        body_lines.append(raw)
        if not stripped or stripped.startswith("<!--") or stripped.lower().startswith("источники:"):
            continue
        if stripped.startswith("#"):
            continue
        if _UNCOVERED_RE.match(stripped):
            in_uncovered = True
            uncovered.append(stripped)
            continue
        if in_uncovered:
            uncovered.append(stripped)
            continue
        indented = raw[:1] in (" ", "\t") and not _ITEM_PREFIX_RE.match(raw)
        content = _ITEM_PREFIX_RE.sub("", raw).strip()
        if indented and items:
            items[-1]["text"] += " " + content
            continue
        items.append({"n": len(items) + 1, "text": content, "locators": [], "foreign": []})
    for item in items:
        for m in _GROUP_RE.finditer(item["text"]):
            for piece in _split_group(m.group(1), known):
                item["locators"].append(piece)
    return {"heading": heading, "items": items, "uncovered": uncovered,
            "body": "\n".join(body_lines).strip("\n")}


def _line_diff(old: str, new_lines: list[str]) -> dict[str, Any]:
    old_lines = [ln.strip() for ln in old.splitlines() if ln.strip()]
    new_clean = [ln.strip() for ln in new_lines if ln.strip()]
    sm = difflib.SequenceMatcher(None, old_lines, new_clean, autojunk=False)
    added = changed = removed = 0
    lines: list[dict[str, str]] = []
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            continue
        if op == "delete":
            removed += i2 - i1
        elif op == "insert":
            added += j2 - j1
        else:
            changed += max(i2 - i1, j2 - j1)
        for ln in old_lines[i1:i2]:
            lines.append({"op": "-", "text": _cut(ln, 300)})
        for ln in new_clean[j1:j2]:
            lines.append({"op": "+", "text": _cut(ln, 300)})
    return {"added": added, "changed": changed, "removed": removed, "lines": lines[:80]}


def _check_privacy(text: str) -> list[str]:
    from core.privacy import is_nda

    bad: list[str] = []
    for m in _PATHLIKE_RE.finditer(text):
        token = m.group(0).rstrip(".:!?")
        if is_nda(token):
            bad.append(token)
    return list(dict.fromkeys(bad))


# --------------------------------------------------------------------------- #
# Стор карточек                                                                 #
# --------------------------------------------------------------------------- #
class SynthStore:
    """``.derived/hub_synth.jsonl`` - одна строка на карточку (производные, пересобираемо)."""

    def __init__(self, path: Path, rows: dict[str, dict[str, Any]] | None = None) -> None:
        self.path = Path(path)
        self.rows: dict[str, dict[str, Any]] = rows or {}

    @classmethod
    def load(cls, path: Path) -> SynthStore:
        rows: dict[str, dict[str, Any]] = {}
        p = Path(path)
        if p.is_file():
            for line in p.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(row, dict) and row.get("id"):
                    rows[str(row["id"])] = row
        return cls(p, rows)

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        ordered = sorted(self.rows.values(), key=lambda r: (str(r.get("created") or ""), r["id"]))
        body = "\n".join(json.dumps(r, ensure_ascii=False) for r in ordered)
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(body + ("\n" if body else ""), encoding="utf-8")
        tmp.replace(self.path)

    def pending(self, now: datetime | None = None) -> list[dict[str, Any]]:
        """Ждут решения: ``pending`` и ``snoozed``, чье «позже» уже наступило."""
        stamp = _stamp(_now(now))
        rows = [r for r in self.rows.values() if r.get("status") == STATUS_PENDING or (
            r.get("status") == STATUS_SNOOZED and str(r.get("snooze_until") or "") <= stamp)]
        rows.sort(key=lambda r: (str(r.get("created") or ""), r["id"]))
        return rows

    def stop_until(self, hub_id: str, now: datetime | None = None) -> str | None:
        """Когда кончается стоп по хабу после отказа (``None`` - стопа нет)."""
        cur = _now(now)
        latest: str | None = None
        for row in self.rows.values():
            if row.get("hub_id") != hub_id or row.get("status") != STATUS_REJECTED:
                continue
            until = str(row.get("stop_until") or "")
            if until > _stamp(cur) and (latest is None or until > latest):
                latest = until
        return latest


def _store(path: Path | None) -> SynthStore:
    return SynthStore.load(path or store_path())


def _card_id(hub_id: str, created: str, text: str) -> str:
    digest = hashlib.sha1(f"{hub_id}|{created}|{text}".encode()).hexdigest()  # noqa: S324 - id, не защита
    return "s-" + digest[:10]


# --------------------------------------------------------------------------- #
# Предложение                                                                   #
# --------------------------------------------------------------------------- #
def propose(
    hub_id: str,
    text: str,
    sources: list[str] | None = None,
    covered_until: str | None = None,
    *,
    since: str | None = None,
    model: str | None = None,
    store_file: Path | None = None,
    now: datetime | None = None,
    dossier: dict[str, Any] | None = None,
    vault_path: Path | None = None,
    **context_kwargs: Any,
) -> dict[str, Any]:
    """Проверить присланный текст секции и поставить карточку ``synth`` в очередь решений.

    Проверки (детерминированные, до записи в стор): непусто; длина <= ``DT_SYNTH_MAX_CHARS``;
    нет путей с NDA-маркером (``privacy``); каждый пункт с >=1 локатором и все локаторы ⊆ локаторов
    досье (``ungrounded`` с номерами пунктов / списком чужих); ``sources`` ⊆ локаторов
    (``bad_sources``); стоп по хабу после отказа (``snoozed``). Канон ИИ-маркеров - предупреждение
    ``style_markers`` в ответе (текст принят). Досье пересобирается тем же :func:`context`
    (``since`` - как при сборке досье; ``dossier`` - готовое досье, если вызывающий его уже держит).
    Прежняя неснятая карточка того же хаба заменяется новой. Возвращает ``{ok, card_id, hub_id,
    items, sources, diff, uncovered, replaced?, warning?}``; отказ - :class:`SynthError`."""
    from core.contract import add_warning
    from core.host import current_host
    from core.style_markers import check_text

    cur = _now(now)
    body = (text or "").strip()
    if not body:
        raise SynthError("empty", "пустой текст секции")
    limit = max_chars()
    if len(body) > limit:
        raise SynthError(
            "too_long", f"текст {len(body)} симв. > предела {limit} (DT_SYNTH_MAX_CHARS)",
            length=len(body), limit=limit)
    bad_paths = _check_privacy(body)
    if bad_paths:
        raise SynthError("privacy", "в тексте пути из приватных (NDA) источников: "
                         + ", ".join(bad_paths[:5]), paths=bad_paths[:10])

    ctx = dossier or context(hub_id, since, now=cur, vault_path=vault_path, **context_kwargs)
    hub_real = ctx["hub"]["id"]
    store = _store(store_file)
    until = store.stop_until(hub_real, cur)
    if until:
        raise SynthError("snoozed", f"по хабу {hub_real} недавно отказано: новое предложение "
                         f"после {until}", until=until)

    known = set(ctx["locators"])
    parsed = parse_section(body, known)
    items = parsed["items"]
    if not items:
        raise SynthError("empty", "в секции нет ни одного пункта")
    missing = [it["n"] for it in items if not it["locators"]]
    foreign = [{"item": it["n"], "locator": loc}
               for it in items for loc in it["locators"] if loc not in known]
    if missing or foreign:
        detail = []
        if missing:
            detail.append("пункты без локатора: " + ", ".join(map(str, missing)))
        if foreign:
            detail.append("локаторы вне досье: " + ", ".join(
                f"п.{f['item']} [{_cut(f['locator'], 60)}]" for f in foreign[:8]))
        raise SynthError("ungrounded", "; ".join(detail), items=missing, foreign=foreign)
    src = list(dict.fromkeys(str(s).strip() for s in (sources or []) if str(s).strip()))
    if not src:
        src = list(dict.fromkeys(loc for it in items for loc in it["locators"]))
    stray = [s for s in src if s not in known]
    if stray:
        raise SynthError("bad_sources", "sources вне локаторов досье: "
                         + ", ".join(_cut(s, 60) for s in stray[:8]), sources=stray)
    cov = _day(covered_until) if covered_until else ctx["as_of"]
    if not cov:
        raise SynthError(
            "bad_covered_until", f"covered_until: ожидается ГГГГ-ММ-ДД ({covered_until!r})")

    current = ctx["hub"]["current_state"]
    new_lines = [it["text"] for it in items] + parsed["uncovered"]
    diff = _line_diff(current["text"] if current else "", new_lines)
    source_meta = _source_meta(ctx, src)
    host = current_host()
    created = _stamp(cur)
    card = _card_id(hub_real, created, body)
    from core.config import ai_markers_path

    report = check_text(body, canon_path=ai_markers_path(_vault(vault_path)))
    row: dict[str, Any] = {
        "id": card, "hub_id": hub_real, "title": ctx["hub"]["title"], "text": body,
        "sources": src, "covered_until": cov, "created": created, "host": host.get("name"),
        "model": model or host.get("model"), "status": STATUS_PENDING, "diff": diff,
        "uncovered": parsed["uncovered"], "items": len(items), "source_meta": source_meta,
        "current_as_of": current["as_of"] if current else None,
        "current_source": current["source"] if current else None,
        "style": report.to_dict() if report.has_findings() else None,
    }
    replaced = [rid for rid, r in store.rows.items()
                if r.get("hub_id") == hub_real
                and r.get("status") in (STATUS_PENDING, STATUS_SNOOZED)]
    for rid in replaced:
        del store.rows[rid]
    store.rows[card] = row
    store.save()
    out: dict[str, Any] = {
        "ok": True, "card_id": f"synth:{card}", "hub_id": hub_real, "items": len(items),
        "sources": len(src), "diff": {k: diff[k] for k in ("added", "changed", "removed")},
        "uncovered": parsed["uncovered"], "covered_until": cov,
        "next": "решение - карточкой «Состояние хаба?» в пульте (Двойник → Требуют решения) "
                "или pult_card_decide по явному слову К.",
    }
    if replaced:
        out["replaced"] = [f"synth:{r}" for r in replaced]
    if report.unavailable:
        add_warning(out, "store_unavailable", report.unavailable
                    + " - проверка ИИ-маркеров НЕ выполнена (это не «текст чист»)")
    elif report.has_findings():
        out["style_markers"] = report.to_dict()
        if report.warns():
            add_warning(out, "style_markers", report.reason(), ban=len(report.ban),
                        density_per_1000=report.density.get("per_1000_words"))
    return out


def _source_meta(ctx: dict[str, Any], used: list[str]) -> dict[str, dict[str, str]]:
    """``{локатор: {kind, title, date}}`` по досье - для «почему» карточки."""
    by_loc: dict[str, dict[str, str]] = {}
    for kind in KINDS:
        for e in ctx["delta"][kind]:
            title = e.get("title") or e.get("subject") or e.get("name") or e.get("label") or ""
            by_loc.setdefault(e["loc"], {"kind": kind, "title": _cut(title, 100),
                                         "date": e.get("date") or ""})
    for ref in ctx.get("current_refs") or []:
        by_loc.setdefault(ref, {"kind": "current", "title": "ссылка из нынешней секции хаба",
                                "date": ""})
    return {loc: by_loc.get(loc, {"kind": "?", "title": "", "date": ""}) for loc in used}


# --------------------------------------------------------------------------- #
# Решение по карточке                                                           #
# --------------------------------------------------------------------------- #
def _final_section(row: dict[str, Any], vault: Path, now: datetime) -> str:
    """Секция к записи: заголовок с датой данных, пункты как присланы, провенанс-подвал."""
    parsed = parse_section(row["text"])
    heading = f"{SECTION_PREFIX}{_ru_date(row['covered_until'])})"
    body = parsed["body"].strip("\n")
    sources = row.get("sources") or []
    wiki: list[str] = []
    for loc in sources:
        simple = bool(re.fullmatch(r"[\w.\-]+", loc)) and not loc.startswith(("deal:",))
        wiki.append(f"[[{loc}]]" if simple else f"`{loc}`")
    who = "/".join(x for x in (row.get("host"), row.get("model")) if x) or "-"
    footer = (f"<!-- synth: {now.date().isoformat()} · карточка {row['id']} · источников "
              f"{len(sources)} · {who} -->")
    lines = [heading, "", body, "", footer]
    if wiki:
        lines.append("Источники: " + ", ".join(wiki))
    return "\n".join(lines)


def apply_card(
    card_id: str, action: str, params: dict[str, Any] | None = None, *,
    store_file: Path | None = None, vault_path: Path | None = None, now: datetime | None = None,
) -> dict[str, Any]:
    """Решение человека по карточке (``approve`` | ``reject`` | ``snooze``).

    Исход вида ``{outcome: applied|rejected|snoozed|stale, detail, effects}``; неизвестная
    карточка - ``ValueError('... не найдена')`` (диспетчер реестра делает из нее ``unknown_card``).
    ``approve`` - ЕДИНСТВЕННОЕ место, где текст синтеза попадает в хаб: через
    :func:`core.operational.hub_notes.upsert_section` (хирургически, прежняя секция - в архив),
    аудит ``record_action`` и событие ``hub/synth_applied``. ``reject`` - причина в стор и стоп по
    хабу на ``DT_SYNTH_SNOOZE_DAYS``. Повтор по закрытой карточке - ``stale``."""
    params = dict(params or {})
    cur = _now(now)
    store = _store(store_file)
    native = card_id.split(":", 1)[1] if card_id.startswith("synth:") else card_id
    row = store.rows.get(native)
    if row is None:
        raise ValueError(f"карточка {native!r} не найдена")
    if row.get("status") not in (STATUS_PENDING, STATUS_SNOOZED):
        return {"outcome": "stale", "detail": f"карточка уже решена ({row.get('status')})"}

    if action == "reject":
        reason = str(params.get("reason") or "").strip()[:500]
        days = snooze_days()
        row.update(status=STATUS_REJECTED, reason=reason, decided_at=_stamp(cur),
                   stop_until=_stamp(cur + timedelta(days=days)))
        store.save()
        return {"outcome": "rejected", "detail": reason or "отклонено",
                "effects": [f"новое предложение по хабу {row['hub_id']} - не раньше чем через "
                            f"{days} дн."]}
    if action == "snooze":
        days = int(float(params.get("days") or 7))
        until = _stamp(cur + timedelta(days=days))
        row.update(status=STATUS_SNOOZED, snooze_until=until, decided_at=_stamp(cur))
        store.save()
        return {"outcome": "snoozed", "detail": f"Вернется {until}",
                "effects": [f"карточка отложена на {days} дн."]}
    if action != "approve":
        raise ValueError(f"неизвестное действие {action!r}")

    from core.eventlog import emit
    from core.operational.hub_notes import HubNoteError, upsert_section
    from core.operational.pult import record_action

    vault = _vault(vault_path)
    hub = _load_hub(row["hub_id"], vault)
    body = _final_section(row, vault, cur)
    try:
        res = upsert_section(
            hub["rel"], SECTION_PREFIX, body, archive_heading=ARCHIVE_HEADING,
            vault_path=vault, legacy_prefixes=LEGACY_PREFIXES, now=cur,
            frontmatter={"synth_at": row["covered_until"], "modified": cur.date().isoformat()},
        )
    except HubNoteError as exc:
        raise SynthError("write_failed", str(exc)) from exc
    row.update(status=STATUS_APPLIED, decided_at=_stamp(cur))
    store.save()
    effects = ["секция записана"]
    archived = res.get("archived")
    if archived:
        effects.append(f"архивирована прежняя ({archived.get('as_of') or archived['heading']})")
    record_action(
        "hub_synth_apply",
        {"hub_id": row["hub_id"], "card": row["id"], "items": row.get("items", 0),
         "sources": len(row.get("sources") or []), "changed": bool(res["changed"]),
         "archived": bool(archived)},
        "applied",
    )
    emit("hub", "synth_applied", note_id=row["hub_id"], path=res["path"],
         detail={"card": row["id"], "items": row.get("items", 0),
                 "sources": len(row.get("sources") or []), "archived": bool(archived)})
    return {"outcome": "applied",
            "detail": "Секция записана в хаб" if res["changed"] else "Такая секция уже в хабе",
            "effects": effects}


# --------------------------------------------------------------------------- #
# Слой ИИ: тот же путь propose                                                   #
# --------------------------------------------------------------------------- #
def run_ai(
    hub_id: str, synthesize: Callable[[str, dict[str, Any]], dict[str, Any]], **kwargs: Any,
) -> dict[str, Any]:
    """``pult_ai(kind="hub_synth")``: промпт досье -> провайдер слоя ИИ -> :func:`propose`.

    ``synthesize`` - :func:`core.operational.ai_layer.synthesize` (инъекция: провайдер, ключ, кэш и
    аудит - там). Нет провайдера/отказ - ``{ok: false, code}`` как у остальных видов слоя ИИ; текст
    провайдера проходит ровно те же проверки, что присланный сессией (``ungrounded`` и т.д.)."""
    try:
        ctx = context(hub_id, **kwargs)
    except SynthError as exc:
        return {"ok": False, "kind": "hub_synth", "code": exc.code, "text": None, "error": str(exc)}
    res = synthesize("hub_synth", {"hub_id": ctx["hub"]["id"], "prompt": ctx["prompt"],
                                   "as_of": ctx["as_of"]})
    if not res.get("ok"):
        return res
    try:
        proposal = propose(ctx["hub"]["id"], str(res.get("text") or ""), None, ctx["as_of"],
                           model=res.get("model") or None, dossier=ctx,
                           vault_path=kwargs.get("vault_path"))
    except SynthError as exc:
        return {**res, "ok": False, "code": exc.code, "error": str(exc), "text": res.get("text")}
    return {**res, "proposal": proposal}


# --------------------------------------------------------------------------- #
# Доктор                                                                        #
# --------------------------------------------------------------------------- #
def stats(
    *, vault_path: Path | None = None, store_file: Path | None = None, now: datetime | None = None,
    **context_kwargs: Any,
) -> dict[str, Any]:
    """Для доктора: ``{pending, last_applied, stale: [{hub_id, since, delta}], hubs_with_state}``.

    ``stale`` - хабы-клиенты с секцией «Состояние»/``synth_at`` старше ``DT_SYNTH_STALE_DAYS``,
    у которых набралось >= 3 новых элементов дельты (зерно KNOWLEDGE-LINT-1). Только чтение; дельта
    считается лишь для устаревших хабов (у хаба без синтеза «устаревать» нечему)."""
    from core.operational.hub_notes import read_section

    cur = _now(now)
    vault = _vault(vault_path)
    store = _store(store_file)
    applied = sorted((str(r.get("decided_at") or "") for r in store.rows.values()
                      if r.get("status") == STATUS_APPLIED), reverse=True)
    out: dict[str, Any] = {
        "pending": len(store.pending(cur)), "last_applied": applied[0] if applied else None,
        "stale": [], "hubs_with_state": 0,
    }
    limit = (cur - timedelta(days=stale_days())).date().isoformat()
    for path in sorted((vault / "04-clients").glob("*.md")):
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        section = read_section(text, SECTION_PREFIX)
        synth_at = ""
        m = re.search(r"(?m)^synth_at:\s*['\"]?(\d{4}-\d{2}-\d{2})", text)
        if m:
            synth_at = m.group(1)
        if section is None and not synth_at:
            continue
        out["hubs_with_state"] += 1
        as_of = synth_at or (section or {}).get("as_of") or ""
        if as_of and as_of > limit:
            continue
        try:
            ctx = context(path.stem, as_of or None, vault_path=vault, now=cur, **context_kwargs)
        except SynthError:
            continue
        total = sum(ctx["limits"]["counts"].values())
        if total >= STALE_MIN_DELTA:
            out["stale"].append({"hub_id": ctx["hub"]["id"], "since": ctx["since"], "delta": total})
    return out

