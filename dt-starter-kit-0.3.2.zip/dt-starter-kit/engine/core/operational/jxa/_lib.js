// Shared JXA helpers for the read-only Classic Outlook for Mac bridge
// (ТЗ phase5, stage 8). These run under `osascript -l JavaScript`. They are
// READ-ONLY: nothing here ever mutates Outlook state.
//
// Robustness contract (mirrored by core/operational/outlook_bridge.py):
//   * If Outlook is not running, we do NOT launch it — we return
//     {"error": "..."} so the caller degrades gracefully.
//   * If Outlook is the New Outlook (no AppleScript dictionary), probing a
//     standard property throws; we catch it and return a clear {"error": ...}.
//   * Every optional message field is read inside try/catch → "" on failure,
//     so one odd message never aborts a batch.

'use strict';

function isProcessRunning(name) {
  // Use System Events so we never auto-launch Outlook just to read it.
  try {
    var se = Application('System Events');
    return se.processes.whose({ name: name }).length > 0;
  } catch (e) {
    return false;
  }
}

// Return the live Classic-Outlook application, or throw a tagged error the
// caller turns into {"error": ...}. Distinguishes "not running" from "New
// Outlook / not scriptable".
function outlookApp() {
  if (!isProcessRunning('Microsoft Outlook')) {
    throw new Error(
      'Microsoft Outlook is not running — open Classic Outlook and retry.'
    );
  }
  var app = Application('Microsoft Outlook');
  try {
    // Touch a standard property; New Outlook lacks the dictionary and throws.
    app.inbox.name();
  } catch (e) {
    throw new Error(
      'Outlook is not scriptable (New Outlook?) — switch to Classic Outlook ' +
        'for the read bridge. (' + String(e) + ')'
    );
  }
  return app;
}

function safe(fn, fallback) {
  try {
    var v = fn();
    return v === undefined || v === null ? fallback : v;
  } catch (e) {
    return fallback;
  }
}

// Depth-first walk of a folder and its sub-folders, capped to avoid runaway
// trees. `visit(folder)` is called for each.
function walkFolders(folders, visit, depth) {
  if (!folders || depth > 8) return;
  for (var i = 0; i < folders.length; i++) {
    var f = folders[i];
    visit(f);
    var subs = safe(function () { return f.mailFolders(); }, null);
    if (subs && subs.length) walkFolders(subs, visit, depth + 1);
  }
}
