// list_folders — read-only enumeration of Classic Outlook mail folders.
// Output: JSON array of {name, path, count} (or {"error": ...} on failure).
// Concatenated after _lib.js by core/operational/outlook_bridge.py.

function run(argv) {
  try {
    var app = outlookApp();
    var out = [];
    // ADAPTER-HONEST-1: корневое перечисление НЕ глотает сбой (раньше safe(..., []) отдавал
    // «папок нет»); ошибка уходит в catch ниже → {"error": ...} → отказ моста.
    walkFolders(app.mailFolders(), function (f) {
      var name = safe(function () { return f.name(); }, '');
      if (!name) return;
      out.push({
        name: name,
        // unreadCount is cheap; total message count can be costly, so skip it.
        unread: safe(function () { return f.unreadCount(); }, null),
      });
    }, 0);
    return JSON.stringify(out);
  } catch (err) {
    return JSON.stringify({ error: String(err && err.message ? err.message : err) });
  }
}
