"""DEV-1b — pre-meeting контекст (досье к встрече) для пульта.

По ближайшей встрече собирает **фактический** контекст ПЕРЕД разговором,
детерминированно и без модели: с кем встреча (клиент(ы) DT), в какой стадии их
активные сделки, что открыто (пункты чек-листа), ближайший дедлайн, недавняя
переписка по доменам клиента и релевантные заметки vault. Отличие от «Подготовиться»
(`work_meetings` → generate) — тот генерит ПОВЕСТКУ моделью; :func:`prepare` даёт
голые факты, которыми повестку можно и напитать.

Path B: ``core/`` ⊥ mcp/cli — модуль НЕ ходит в сеть и НЕ зовёт LLM. Данные —
из локального зеркала Timetta (:class:`MirrorStore`), манифеста почты + сайдкаров и
каталога хабов vault. Переиспользует уже готовое:

* :func:`meetings._client_hubs` / :func:`meetings._resolve_clients` — резолв клиента
  по доменам контрагента + теме встречи (тот же кэш каталога, что у виджета встреч);
* :func:`work._state_code_map` / :func:`work._is_active` — стадии и отсев терминальных
  (выигранных/закрытых) сделок;
* :func:`work._recent_external_mail` — недавние ВНЕШНИЕ треды из манифеста+сайдкаров.

Заметки берутся через инъекцию ``find_notes`` (MCP-хелпер) — так ``core/`` не тянет
слой ретривала/BGE напрямую и остаётся тестируемым без сети (в тестах — заглушка).

Релевантность (приёмка Cowork 2026-07-06, `docs/tz/dev-1b-relevance-fixes.md`):

* **FIX-1** — переписка приписывается клиенту ТОЛЬКО если домен треда резолвится в
  него через хаб ИЛИ входит в ``counterparty_domains`` ИМЕННО этой встречи (без
  над-атрибуции «единственному клиенту» по всему пулу);
* **FIX-2** — ретривал заметок и порядок сделок ведёт различимый термин темы
  (:func:`_salient_terms` выкидывает служебные слова встреч); сделки со совпадением
  темы — вперёд, прочие сворачиваются в ``other_deals``;
* **FIX-3** — :func:`resolve_entities` распознаёт КОНКРЕТНУЮ сущность встречи
  (сделка/проект зеркала, project-хаб vault) по термину темы; ``prepare`` скоупит
  досье к ней (или к явному ``entity_id``), а при неоднозначности возвращает
  ``needs_clarification`` + ``entity_candidates`` для уточнения на пульте.

Read-only: ничего не пишет ни во внешние системы, ни в vault. Privacy — как в
``work.py``: наружу только ``code``/``name``/``state_name``/темы писем/домены/даты/
имена/ссылки на заметки; сумм и вероятностей сделок в выдаче НЕТ.

Устойчивость: пустое/битое зеркало/манифест и нераспознанный клиент → пустые срезы,
никогда не исключение.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import (
    default_vault_path,
    outlook_ingest_manifest_path,
    timetta_mirror_path,
)
from core.operational import meetings, work
from core.operational.hub_collect import (  # HUB-SYNTH-1: сборщики вынесены в общий модуль
    STOP_PREFIXES as _STOP_PREFIXES,  # noqa: F401 - прежнее имя для внешних читателей
)
from core.operational.hub_collect import (
    STOP_WORDS as _STOP_WORDS,  # noqa: F401
)
from core.operational.hub_collect import (
    active_client_deals as _active_client_deals,
)
from core.operational.hub_collect import (
    clients_of as _clients_of,
)
from core.operational.hub_collect import (
    date_only as _date_only,  # noqa: F401
)
from core.operational.hub_collect import (
    deal_view as _deal_view,
)
from core.operational.hub_collect import (
    iso_z as _iso_z,
)
from core.operational.hub_collect import (
    mail_for as _mail_for,
)
from core.operational.hub_collect import (
    mail_view as _mail_view,  # noqa: F401
)
from core.operational.hub_collect import (
    notes_for as _notes_for,
)
from core.operational.hub_collect import (
    orbit_records as _orbit_records,
)
from core.operational.hub_collect import (
    salient_terms as _salient_terms,
)
from core.operational.hub_collect import (
    term_hit as _term_hit,
)
from core.operational.hub_collect import (
    to_utc as _to_utc,
)
from core.operational.timetta.mirror import MirrorStore

__all__ = [
    "MAX_MAIL",
    "MAX_NOTES",
    "MAX_DEALS",
    "MATCH_MIN",
    "prepare",
    "resolve_entities",
]

# Мягкие капы на длину срезов досье (переопределяются аргументами).
MAX_MAIL = 6
MAX_NOTES = 6
# Кап на число показываемых сделок (прочие активные клиентские → ``other_deals``).
MAX_DEALS = 5
# Порог совпадения термина темы с сущностью, ниже — не кандидат (FIX-3).
MATCH_MIN = 0.5


def _deals_slice(
    active: list[dict[str, Any]],
    terms: list[str],
    *,
    entity: dict[str, Any] | None,
    max_deals: int,
) -> tuple[list[dict[str, Any]], int]:
    """Срез сделок для досье (FIX-2/FIX-3): совпавшие с темой/сущностью — вперёд,
    прочие активные клиентские сворачиваются в счётчик ``other_deals``.

    * ``entity`` (скоуп FIX-3): сделка → ровно эта сделка; проект/хаб → активные
      клиентские сделки, чьё имя совпало с термином сущности.
    * иначе (FIX-2): сделки со совпадением темы вперёд; нет совпадений → топ по
      свежести. В обоих случаях показ капается ``max_deals``, остаток → ``other_deals``.
    """
    if entity is not None:
        if entity.get("kind") == "deal":
            eid = str(entity.get("id"))
            focus = [d for d in active
                     if str(d.get("code")) == eid or str(d.get("id")) == eid]
        else:
            eterms = _salient_terms(str(entity.get("name") or ""))
            focus = [d for d in active if _term_hit(str(d.get("name") or ""), eterms)]
        shown = focus[:max_deals]
    else:
        matched = [d for d in active if terms and _term_hit(str(d.get("name") or ""), terms)]
        shown = (matched or active)[:max_deals]
    views = [_deal_view(d) for d in shown]
    return views, max(0, len(active) - len(shown))



def _resolve_meeting_clients(
    subject: str,
    domains: list[str],
    client_ids: list[str] | None,
    hubs: list[dict[str, Any]],
) -> list[dict[str, str]]:
    """Клиент(ы) встречи: явные ``client_ids`` (имя из каталога) либо резолв по
    доменам+теме (реюз резолвера встреч)."""
    if client_ids:
        by_id = {h["id"]: h for h in hubs}
        out: list[dict[str, str]] = []
        seen: set[str] = set()
        for cid in client_ids:
            if not cid or cid in seen:
                continue
            seen.add(cid)
            hub = by_id.get(cid)
            # CONTRACT-2 С11: хаба нет — это НЕ клиент с именем-идентификатором.
            # Такой «клиент» давал пустое досье, неотличимое от «у клиента ничего нет».
            # Помечаем ``unresolved``; вызывающий выносит его в конверт и НЕ строит
            # по нему срезы.
            out.append(
                {"id": cid, "name": hub["name"]} if hub
                else {"id": cid, "name": cid, "unresolved": "no_hub"}
            )
        return out
    return meetings._resolve_clients(domains, subject, hubs)


# --------------------------------------------------------------------------- #
# FIX-3 — резолв конкретной сущности встречи (сделка/проект/хаб)               #
# --------------------------------------------------------------------------- #
def _read_entity_client(path: Path) -> tuple[str, str]:
    """``entity`` и id клиента (из ``client: "[[client-…]]"``) из frontmatter хаба."""
    entity = ""
    client_id = ""
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return "", ""
    in_fm = False
    for line in text.splitlines():
        s = line.strip()
        if s == "---":
            if in_fm:
                break
            in_fm = True
            continue
        if not in_fm:
            continue
        if s.startswith("entity:"):
            entity = s[len("entity:"):].strip().strip('"').strip("'")
        elif s.startswith("client:"):
            body = s[len("client:"):]
            m = re.search(r"\[\[([^\]]+)\]\]", body)
            client_id = (m.group(1) if m else body.strip().strip('"').strip("'")).strip()
            # Пустая шаблонная ссылка (``client: "[[]]"``/``client:``) — это ОТСУТСТВИЕ
            # клиента, а не клиент с именем «[[]]». У внутреннего проекта клиента нет
            # штатно, и без этой нормализации он засеивал досье мусорной сущностью.
            client_id = client_id.strip("[]").strip()
    return entity, client_id


def _project_hubs(vault_path: Path | None = None) -> list[dict[str, Any]]:
    """Project/deal-хабы vault (``03-projects``): ``{id, name, aliases, entity,
    client_id}``. И одиночные ``*.md``, и папочные ``*/hub.md``. Не кэшируется —
    папка мелкая, чтение на клик дёшево; любой сбой → ``[]`` (не исключение)."""
    base = Path(vault_path or default_vault_path()) / "03-projects"
    out: list[dict[str, Any]] = []
    try:
        paths = list(base.glob("*.md"))
        paths += [d / "hub.md" for d in sorted(base.glob("*/")) if (d / "hub.md").is_file()]
        for p in sorted(paths):
            entity, client_id = _read_entity_client(p)
            if entity not in ("project", "deal"):
                continue
            h = meetings._read_hub(p)
            out.append({
                "id": h["id"],
                "name": h["name"],
                "aliases": h.get("aliases", []),
                "entity": entity,
                "client_id": client_id,
            })
    except OSError:
        return []
    return out


def _name_score(
    name: str | None, aliases: list[str], terms: list[str], subject_low: str
) -> float:
    """Насколько имя/алиасы сущности отвечают теме встречи (0..1, детерминированно).

    Алиас-фраза целиком в теме → сильный сигнал (0.9); иначе — доля различимых
    терминов темы, найденных в имени/алиасах."""
    targets = [t.lower() for t in ([name, *aliases]) if t]
    score = 0.0
    for t in targets:
        if len(t) >= 4 and t in subject_low:
            score = max(score, 0.9)
    matched = sum(1 for term in terms if any(term in t for t in targets))
    if matched:
        score = max(score, min(0.85, 0.5 + 0.2 * matched))
    return score


def _seed_clients_from_hubs(
    subject: str, hubs: list[dict[str, Any]], vault_path: Path | None
) -> list[dict[str, str]]:
    """Клиент(ы) по совпадению темы с project-хабом, когда напрямую не резолвнулись.

    Реальный кейс приёмки: тема «Еженедельный ОС по ГП Альфа» не содержит имени
    клиента (только алиас проекта), а домены — партнёрские. Хаб проекта знает своего
    клиента (frontmatter ``client``) — им и засеваем, чтобы FIX-3 мог заскоупить."""
    terms = _salient_terms(subject)
    if not terms:
        return []
    subj = subject.lower()
    by_id = {h["id"]: h for h in hubs}
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    for ph in _project_hubs(vault_path):
        cid = ph.get("client_id")
        if not cid or cid in seen:
            continue
        if _name_score(ph["name"], ph.get("aliases", []), terms, subj) < MATCH_MIN:
            continue
        seen.add(cid)
        hub = by_id.get(cid)
        out.append({"id": cid, "name": hub["name"] if hub else cid})
    return out


def resolve_entities(
    subject: str,
    clients: list[dict[str, Any]],
    *,
    store: MirrorStore,
    hubs: list[dict[str, Any]],
    vault_path: Path | None = None,
    code_by_id: dict[str, str] | None = None,
    any_client: bool = False,
) -> list[dict[str, Any]]:
    """Кандидаты специфической сущности встречи по различимым терминам темы (FIX-3).

    Ищет среди активных сделок/проектов зеркала (по name/alias, в пределах клиента(ов))
    и project/deal-хабов vault (``03-projects``, тоже в пределах клиента). Каждый
    кандидат: ``{kind: deal|project|hub, id, name, score, client_id}``, отсортированы
    по убыванию score. Нет различимых терминов/клиентов → ``[]``.

    ``any_client=True`` (WORK-TUNE-1) снимает скоуп по клиенту: тема ищется по ВСЕМ
    активным сделкам/проектам и project-хабам. Нужен для **внутренней** встречи — у неё
    нет внешних доменов, клиента резолвить не из чего, и без этого режима подготовиться
    нельзя ни к одной внутренней теме. Скоринг тот же (``_name_score``, порог
    ``MATCH_MIN``) — второй копии матчера нет.
    """
    terms = _salient_terms(subject)
    if not terms or (not clients and not any_client):
        return []
    client_ids = {c["id"] for c in clients}
    if code_by_id is None:
        code_by_id = work._state_code_map(store)
    subj = (subject or "").lower()
    cands: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    def _add(kind: str, ident: Any, name: Any, score: float, client_id: str) -> None:
        key = (kind, str(ident))
        if score < MATCH_MIN or key in seen:
            return
        seen.add(key)
        cands.append({"kind": kind, "id": ident, "name": name,
                      "score": round(score, 2), "client_id": client_id})

    for kind, coll in (("deal", "deals"), ("project", "projects")):
        try:
            records = _orbit_records(store, coll)
        except (OSError, ValueError):
            records = []
        for rec in records:
            if not work._is_active(rec, code_by_id):
                continue
            text = f"{rec.get('organization_name') or ''} {rec.get('name') or ''}"
            rcl = _clients_of(text, hubs) & client_ids
            if not rcl and not any_client:
                continue
            owner_id = next(iter(rcl)) if rcl else ""
            _add(kind, rec.get("code") or rec.get("id"), rec.get("name"),
                 _name_score(rec.get("name"), [], terms, subj), owner_id)

    for ph in _project_hubs(vault_path):
        cid = ph.get("client_id") or ""
        if cid and cid not in client_ids and not any_client:
            continue
        owner = cid or (next(iter(client_ids)) if len(client_ids) == 1 else "")
        _add("hub", ph["id"], ph["name"],
             _name_score(ph["name"], ph.get("aliases", []), terms, subj), owner)

    cands.sort(key=lambda c: c["score"], reverse=True)
    return cands


def _entity_by_id(
    entity_id: str,
    store: MirrorStore,
    code_by_id: dict[str, str],
    hubs: list[dict[str, Any]],
    vault_path: Path | None,
    client_ids: set[str],
) -> dict[str, Any] | None:
    """Явно выбранная на пульте сущность по её id (сделка code/guid, project code,
    hub id) — досье скоупится к ней даже без совпадения с темой."""
    ref = str(entity_id or "").strip()
    if not ref:
        return None
    for kind, coll in (("deal", "deals"), ("project", "projects")):
        try:
            records = _orbit_records(store, coll)
        except (OSError, ValueError):
            records = []
        for rec in records:
            if str(rec.get("code")) == ref or str(rec.get("id")) == ref:
                text = f"{rec.get('organization_name') or ''} {rec.get('name') or ''}"
                rcl = _clients_of(text, hubs) & client_ids
                owner = next(iter(rcl)) if rcl else (
                    next(iter(client_ids)) if len(client_ids) == 1 else "")
                return {"kind": kind, "id": rec.get("code") or rec.get("id"),
                        "name": rec.get("name"), "score": 1.0, "client_id": owner}
    for ph in _project_hubs(vault_path):
        if ph["id"] == ref:
            cid = ph.get("client_id") or ""
            owner = cid if cid in client_ids else (
                next(iter(client_ids)) if len(client_ids) == 1 else "")
            return {"kind": "hub", "id": ph["id"], "name": ph["name"],
                    "score": 1.0, "client_id": owner}
    return None


def prepare(
    *,
    subject: str,
    counterparty_domains: list[str],
    client_ids: list[str] | None = None,
    entity_id: str | None = None,
    mirror_path: Path | None = None,
    mail_manifest: Path | None = None,
    vault_path: Path | None = None,
    now: datetime | None = None,
    max_mail: int = MAX_MAIL,
    max_notes: int = MAX_NOTES,
    max_deals: int = MAX_DEALS,
    mail_threads_dir: Path | None = None,
    find_notes: Callable[..., dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Собрать досье к встрече (read-only, без сети/LLM). См. док модуля.

    Все пути — именованные kwargs с ``None``-дефолтом (реальные из config-аксессоров);
    тесты инжектят tmp и заглушку ``find_notes``. Клиент не распознан → пустой
    ``clients`` (внутренняя встреча). Пустое/битое зеркало/манифест → пустые срезы.

    Скоуп сущности (FIX-3): ``entity_id`` задан → досье к этой сущности; иначе один
    уверенный кандидат из темы → авто-скоуп; несколько/ноль (при различимой теме) →
    клиентское досье + ``needs_clarification=True`` и ``entity_candidates``.
    """
    now = _to_utc(now) if now is not None else datetime.now(UTC)
    domains = [d for d in (counterparty_domains or []) if d]
    subject = subject or ""

    hubs = meetings._client_hubs(vault_path)
    clients = _resolve_meeting_clients(subject, domains, client_ids, hubs)
    # CONTRACT-2 С11: явные client_id без хаба в досье не идут — идут в конверт.
    unresolved_clients = [c["id"] for c in clients if c.get("unresolved")]
    clients = [c for c in clients if not c.get("unresolved")]
    # Тема называет проект, но не клиента (партнёрские домены) → засеять клиента по
    # хабу проекта, чтобы досье скоупилось на проект, а не осталось пустым.
    if not clients and not client_ids:
        clients = _seed_clients_from_hubs(subject, hubs, vault_path)

    # Домены без собственного хаба (label ≠ ни один slug каталога) — на пульт строкой.
    all_slugs = {h["slug"] for h in hubs}
    unresolved: list[str] = []
    for d in domains:
        if meetings._domain_label(d) not in all_slugs and d not in unresolved:
            unresolved.append(d)

    # Зеркало сделок + справочник стадий (пусто/битое → пустые списки, не исключение).
    store = MirrorStore(mirror_path or timetta_mirror_path())
    try:
        deals = _orbit_records(store, "deals")
    except (OSError, ValueError):
        deals = []
    code_by_id = work._state_code_map(store)

    # Недавняя внешняя переписка (треды из манифеста+сайдкаров) — общий пул.
    mail_path = mail_manifest or outlook_ingest_manifest_path()
    manifest = work._load_json(mail_path)
    manifest = manifest if isinstance(manifest, dict) else None
    threads_dir = mail_threads_dir or (Path(mail_path).parent / "mail_threads")
    recent = work._recent_external_mail(manifest, threads_dir, now=now)

    # FIX-3 — резолв конкретной сущности встречи.
    salient = _salient_terms(subject)
    client_id_set = {c["id"] for c in clients}
    # WORK-TUNE-1: клиента нет вовсе (внутренняя встреча — нет внешних доменов) →
    # ищем сущность по ТЕМЕ, без скоупа по клиенту. Внешний путь не меняется.
    by_subject = not clients
    candidates = resolve_entities(
        subject, clients, store=store, hubs=hubs,
        vault_path=vault_path, code_by_id=code_by_id, any_client=by_subject,
    ) if (clients or by_subject) else []
    entity: dict[str, Any] | None = None
    needs_clarification = False
    unresolved_entity = ""
    if entity_id:
        entity = _entity_by_id(
            str(entity_id), store, code_by_id, hubs, vault_path, client_id_set
        )
        if entity is None:
            # CONTRACT-2 С11: явный скоуп молча игнорировался — досье собиралось по
            # всему клиенту и выглядело как заказанное.
            unresolved_entity = str(entity_id)
    elif len(candidates) == 1:
        entity = candidates[0]
    elif salient and (clients or candidates):
        # несколько уверенных при различимой теме → спросить пользователя. У внутренней
        # встречи спрашиваем только когда кандидаты ЕСТЬ: ноль кандидатов — это не
        # неоднозначность, а «по теме ничего нет», и об этом говорит hint.
        needs_clarification = True

    out_clients: list[dict[str, Any]] = []
    for client in clients:
        cid = client["id"]
        c_entity = entity if (entity and entity.get("client_id") == cid) else None
        active = _active_client_deals(cid, deals, code_by_id, hubs)
        deal_views, other = _deals_slice(
            active, salient, entity=c_entity, max_deals=max_deals
        )
        entry: dict[str, Any] = {
            "id": cid,
            "name": client.get("name"),
            "deals": deal_views,
            "other_deals": other,
            "recent_mail": _mail_for(
                cid, recent, hubs, counterparty_domains=domains,
                max_mail=max_mail, entity=c_entity,
            ),
            "notes": _notes_for(
                str(client.get("name") or ""), subject, find_notes,
                max_notes=max_notes,
                entity_name=(str(c_entity.get("name")) if c_entity else None),
            ),
        }
        if c_entity is not None:
            entry["entity"] = {
                "kind": c_entity["kind"], "id": c_entity["id"], "name": c_entity["name"]
            }
        out_clients.append(entry)

    out: dict[str, Any] = {
        "generated_at": _iso_z(now),
        "meeting": {"subject": subject, "domains": domains},
        "clients": out_clients,
        "unresolved_domains": unresolved,
        "entities": [
            {"kind": entity["kind"], "id": entity["id"], "name": entity["name"],
             "client_id": entity.get("client_id")}
        ] if entity else [],
        "entity_candidates": candidates if needs_clarification else [],
        "needs_clarification": needs_clarification,
    }
    if unresolved_clients or unresolved_entity:
        from core.contract import CODE_UNRESOLVED_REF, add_warning

        if unresolved_clients:
            add_warning(
                out, CODE_UNRESOLVED_REF,
                "клиент-хаб не найден: " + ", ".join(unresolved_clients)
                + " — досье по нему НЕ собрано (пустой срез был бы неотличим от "
                "«у клиента ничего нет»)",
                client_ids=unresolved_clients,
            )
        if unresolved_entity:
            add_warning(
                out, CODE_UNRESOLVED_REF,
                f"entity_id {unresolved_entity!r} не найден ни в зеркале, ни среди "
                "project-хабов — досье НЕ заскоуплено к нему",
                entity_id=unresolved_entity, param="entity_id",
            )
    if by_subject:
        # WORK-TUNE-1 — внутренняя встреча: контекст собран по НАЗВАНИЮ, а не по
        # клиенту. Провенанс сигнала виден в ответе (``matched_by``), заметки лежат на
        # верхнем уровне: клиента, внутри которого им место, у такой встречи нет.
        out["matched_by"] = "subject"
        out["notes"] = _notes_for(
            "", subject, find_notes, max_notes=max_notes,
            entity_name=(str(entity.get("name")) if entity else None),
        )
        if not entity and not candidates and not out["notes"]:
            out["hint"] = (
                "по теме встречи ничего не нашлось: ни проекта/сделки, ни заметок. "
                "Заведи хаб проекта (кнопка «завести хаб проекта») или назови встречу "
                "так, чтобы в теме было имя проекта/клиента"
            )
    return out
