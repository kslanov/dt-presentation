"""Мониторинг одной карточкой (PULT-SURFACE-2 п.3, MONITOR-CARD-1): ``pult_monitor()``.

Вкладка «Мониторинг» раньше платила шестью секциями и восемью вызовами. Теперь - один read-вызов из
СНИМКОВ и статусов, которые и так лежат на диске: ничего тяжелого не считается (ни доктор, ни скан
NDA-следов, ни реранкер) - у кого снимка нет, блок честно говорит ``{available: false}``.

Блоки: ``health`` (снимок доктора), ``night_chain`` (маяк ``dt-sync-index``), ``services``,
``sync``, ``jobs``, ``activity``, ``freshness``, ``storage`` (снимок хранилища). Сбой блока -
``{error}``, остальные отдаются («ошибка ≠ пусто»). ``as_of`` - время данных по блокам,
``timings`` - сколько мс занял блок.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)

__all__ = ["BLOCKS", "HEALTH_ITEMS", "MONITOR_TTL_ENV", "compact_jobs", "monitor"]

BLOCKS = (
    "health", "night_chain", "services", "sync", "jobs", "activity", "freshness", "storage",
)
HEALTH_ITEMS = 5  # сколько первых warn/fail несет блок health (полный список - doctor() из снимка)
_STAMP = "%Y-%m-%dT%H:%M:%SZ"

# Читатель возвращает ``payload`` либо ``(payload, as_of)``, если знает время своих данных.
Reader = Callable[[], Any]


def _now() -> str:
    return datetime.now(UTC).strftime(_STAMP)


def compact_jobs(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Компактная строка задания для UI (общая для ``job_list`` и блока ``jobs``)."""
    return [
        {
            "job_id": r.get("job_id"),
            "op": r.get("op"),
            "state": r.get("state"),
            "phase": r.get("phase"),
            "current": r.get("current"),
            "total": r.get("total"),
            "cancel_requested": bool(r.get("cancel_requested")),
            "created_at": r.get("created_at"),
            "updated_at": r.get("updated_at"),
        }
        for r in rows
    ]


def _problems(checks: list[dict[str, Any]]) -> list[dict[str, str]]:
    bad = [c for c in checks if c.get("status") in ("fail", "warn")]
    bad.sort(key=lambda c: 0 if c.get("status") == "fail" else 1)
    return [{"name": str(c.get("name", "")), "status": str(c.get("status")),
             "detail": str(c.get("detail", ""))} for c in bad]


def _read_health() -> tuple[dict[str, Any], str | None]:
    """Здоровье из СНИМКА: полный ответ доктора (``status/cache``) либо короткий ``doctor_last``."""
    from core.diagnostics import snapshot_state
    from core.operational.snapshot import read_cached

    candidates: list[tuple[str, dict[str, Any], str]] = []
    cached = read_cached("doctor")
    if cached is not None:
        payload, meta = cached
        probs = _problems(payload.get("checks") or [])
        candidates.append((meta["as_of"], {
            "oks": payload.get("oks", 0), "warns": payload.get("warns", 0),
            "fails": payload.get("fails", 0), "problems": len(probs),
            "items": probs[:HEALTH_ITEMS], "source": "doctor",
        }, meta["as_of"]))
    snap, _err = snapshot_state()
    if snap is not None:
        probs = _problems(snap.get("items") or [])
        candidates.append((str(snap["ts"]), {
            "oks": snap["oks"], "warns": snap["warns"], "fails": snap["fails"],
            "problems": len(probs), "items": probs[:HEALTH_ITEMS], "source": "doctor_last",
            "stale": bool(snap.get("stale")),
        }, str(snap["ts"])))
    if not candidates:
        return {"available": False}, None
    as_of, block, _ = max(candidates, key=lambda c: c[0])
    block["worst"] = "fail" if block["fails"] else ("warn" if block["warns"] else "ok")
    block["available"] = True
    return block, as_of


def _read_night_chain() -> tuple[dict[str, Any], str | None]:
    from core import nightchain as nc

    chain = nc.read_chain("index")
    brief = nc.summary(chain) if chain is not None else None
    if chain is None or brief is None:
        return {"available": False}, None
    return {"available": True, **brief}, chain.updated or None


MONITOR_TTL_ENV = "DT_PULT_MONITOR_TTL_S"


def _snapshot(key: str, compute: Reader) -> tuple[Any, str]:
    """Блок из снимка (SURFACE-HYGIENE-1 п.3; тот же ``cached_read``, что у PULT-SURFACE-2):
    ``launchctl`` (services ~80 мс) и freshness (~170 мс) не звать на каждый показ - TTL 60 с."""
    from core.operational.snapshot import cached_read, ttl_from_env

    payload, meta = cached_read(f"monitor-{key}", ttl_from_env(MONITOR_TTL_ENV, 60), compute)
    return payload, str(meta["as_of"])


def _read_services() -> Any:
    from core.operational.services import service_status

    return _snapshot("services", lambda: service_status("all"))


def _read_sync() -> Any:
    from core.operational.pult import sync_status

    return sync_status()


def _read_jobs() -> Any:
    from core.orchestration.jobs import list_jobs

    return compact_jobs(list_jobs(limit=12))


def _read_activity() -> Any:
    from core.operational.pult import activity

    return activity()


def _read_freshness() -> Any:
    from core.operational.freshness import snapshot

    return _snapshot("freshness", snapshot)


def _read_storage() -> tuple[dict[str, Any], str | None]:
    from core.operational.snapshot import read_cached

    cached = read_cached("storage")
    if cached is None:
        return {"available": False}, None
    payload, meta = cached
    return {"available": True, **payload}, meta["as_of"]


_READERS: dict[str, Reader] = {
    "health": _read_health,
    "night_chain": _read_night_chain,
    "services": _read_services,
    "sync": _read_sync,
    "jobs": _read_jobs,
    "activity": _read_activity,
    "freshness": _read_freshness,
    "storage": _read_storage,
}


# блок ответа -> ключ манифеста (сервисы входят в блок «Синхронизация и сервисы»)
_MANIFEST_KEY = {"services": "sync"}


def monitor(readers: dict[str, Reader] | None = None) -> dict[str, Any]:
    """Карточка «Движок» одним вызовом: ``{<блок>: …, as_of: {блок: время}, timings: {блок: мс}}``.

    ``readers`` - подмена читателей блоков (тесты: инжектированные статусы). Блок, упавший при
    чтении, - ``{error: "..."}`` и ``as_of[блок] = None``; прочие блоки отдаются как есть."""
    from core.surface import manifest

    table = {**_READERS, **(readers or {})}
    out: dict[str, Any] = {}
    as_of: dict[str, str | None] = {}
    timings: dict[str, int] = {}
    # PERSONAL-3: блоки роли (хранилище - не у личной)
    declared = set(manifest.surface().monitor_blocks)
    for name in BLOCKS:
        if _MANIFEST_KEY.get(name, name) not in declared:
            continue
        started = time.perf_counter()
        try:
            got = table[name]()
            payload, stamp = got if (isinstance(got, tuple) and len(got) == 2) else (got, _now())
            out[name] = payload
            as_of[name] = stamp
        except Exception as exc:  # noqa: BLE001 - сбой блока не роняет карточку
            logger.warning("блок мониторинга %s не прочитан: %s", name, exc)
            out[name] = {"error": f"{type(exc).__name__}: {str(exc)[:160]}"}
            as_of[name] = None
        timings[name] = int((time.perf_counter() - started) * 1000)
    out["as_of"] = as_of
    out["timings"] = timings
    return out
