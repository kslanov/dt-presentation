"""ORBIT-2 — три кольца орбиты Timetta и ЕДИНЫЙ фильтр потребителей.

В Timetta выходит CRM-менеджер, далее другие дочки группы; К. как держатель функции видит
все сделки (спайк ``docs/findings/orbit-2.md``: токен отдаёт 47 сделок 4 ведущих, а не 19
«своих»). Посылка «все сделки зеркала — мои» ложна, поэтому у каждой сделки зеркала есть
**кольцо**:

* ``mine``  — ведущий я, ЛИБО я явный участник (исполнитель пункта чек-листа / связанной
  задачи; список ``participants``). ``createdBy`` участием НЕ считается: К. создал 16 чужих
  сделок и передал их — это след передачи (риск §7.5);
* ``unit``  — «моя дочка»: юрлицо сделки (иначе юрлицо ведущего) входит в мои юрлица
  (то, где я ``LegalEntity.managerId`` + моё собственное: юрлица одной компании —
  одно кольцо);
* ``group`` — всё остальное.

**«Слежу» (ORBIT-3).** Сделка кольца 2/3 в ручном списке ``watchlist`` помечается флагом
``watched`` и для ВНИМАНИЯ (:func:`visible`: лента «Работа», дайджест) ведёт себя как кольцо 1,
но её РЕАЛЬНОЕ кольцо (``ring``) не меняется.

**RETIRE-WRITE-1:** записи в Timetta нет, поэтому гейта записи (``DT_ORBIT_WRITE_RINGS``,
``can_write``) больше нет — кольца остались только для ЧТЕНИЯ (что видно/что в фокусе).

Модуль чистый (без сети): :func:`ring_of`/:func:`resolve_unit` считают кольцо,
:func:`recompute` пишет его в зеркало (вызывается в конце ``pull``), а потребители
читают сделки ТОЛЬКО через :func:`visible` (и :func:`visible_issues`/:func:`visible_projects`).
Тест-гард ``tests/test_orbit_guard.py`` падает на прямое ``store.all("deals")`` мимо хелпера.

Конфиг: ``DT_ORBIT_RINGS`` (дефолт ``mine,unit``) — какие кольца **видимы** вообще. Потребитель
по умолчанию просит кольцо ``mine`` → нулевая регрессия при выключенных кольцах; запрошенное
кольцо вне ``DT_ORBIT_RINGS`` отбрасывается (пересечение), а не расширяет выдачу.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Iterable
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "RING_MINE",
    "RING_UNIT",
    "RING_GROUP",
    "RINGS",
    "DEFAULT_VIEW",
    "OrbitError",
    "parse_rings",
    "enabled_rings",
    "unit_extra",
    "ring",
    "ring_of",
    "resolve_unit",
    "my_units",
    "recompute",
    "visible",
    "visible_ids",
    "visible_issues",
    "visible_projects",
    "orbit_slice",
    "lookup",
    "find",
    "find_ref",
    "leader_badge",
    "ring_counts",
    "is_deleted",
    "is_watched",
    "view_ring",
    "effective_rings",
]

RING_MINE = "mine"
RING_UNIT = "unit"
RING_GROUP = "group"
RINGS: tuple[str, ...] = (RING_MINE, RING_UNIT, RING_GROUP)

# Что просит потребитель, если не сказал иначе («Требует внимания» = только кольцо 1).
DEFAULT_VIEW: tuple[str, ...] = (RING_MINE,)
_DEFAULT_ENABLED: tuple[str, ...] = (RING_MINE, RING_UNIT)

ENV_RINGS = "DT_ORBIT_RINGS"
# Явная добавка к «моим юрлицам» (id или имя через запятую) — на случай, когда
# ``LegalEntity.managerId`` не отражает «мою дочку».
ENV_UNITS = "DT_ORBIT_UNIT_ENTITIES"


class OrbitError(ValueError):
    """Неверное значение колец (``bad_rings``): отказ с причиной, а не тихое расширение."""

    code = "bad_rings"


def parse_rings(value: Any, *, default: tuple[str, ...] | None = None) -> tuple[str, ...]:
    """Нормализовать «кольца»: ``"mine,unit"`` | ``["mine"]`` | ``None`` → кортеж.

    ``None``/пусто → ``default`` (если задан) либо ``()``. Неизвестное имя —
    :class:`OrbitError` (опечатка ``mien`` не должна молча превратиться в «ничего»/«всё»).
    Порядок канонический (``mine, unit, group``), дубли схлопнуты.
    """
    if value is None or value == "" or value == [] or value == ():
        return default if default is not None else ()
    items = value.split(",") if isinstance(value, str) else list(value)
    names = [str(x).strip().lower() for x in items if str(x).strip()]
    bad = [n for n in names if n not in RINGS]
    if bad:
        raise OrbitError(f"неизвестное кольцо {bad[0]!r}: допустимо {', '.join(RINGS)}")
    return tuple(r for r in RINGS if r in names)


def _env_rings(name: str, default: tuple[str, ...]) -> tuple[str, ...]:
    raw = (os.environ.get(name) or "").strip()
    if not raw:
        return default
    try:
        return parse_rings(raw, default=default)
    except OrbitError as exc:
        # Битая настройка не должна ронять фид, но и не молчит: дефолт + громкий лог.
        logger.warning("[orbit] %s=%r: %s — использую дефолт %s", name, raw, exc, default)
        return default


def enabled_rings() -> tuple[str, ...]:
    """Кольца, видимые вообще (``DT_ORBIT_RINGS``, дефолт ``mine,unit``)."""
    return _env_rings(ENV_RINGS, _DEFAULT_ENABLED)


def unit_extra() -> frozenset[str]:
    """Явно заданные «мои юрлица» (``DT_ORBIT_UNIT_ENTITIES``: id/имена через запятую)."""
    raw = os.environ.get(ENV_UNITS) or ""
    return frozenset(x.strip().lower() for x in raw.split(",") if x.strip())


# --- кольцо одной сделки -----------------------------------------------------


def is_deleted(rec: dict[str, Any]) -> bool:
    """Сверка удалений (ORBIT-2 п.3): запись помечена ``deleted_at`` — в Timetta её нет."""
    return bool(rec.get("deleted_at"))


def ring(rec: dict[str, Any]) -> str:
    """Кольцо записи. Запись зеркала ДО ORBIT-2 колец не несёт и содержит только свои
    сделки (выборка была ``managerId == me``) — для неё ``mine`` верно по построению."""
    value = str(rec.get("ring") or "").strip().lower()
    return value if value in RINGS else RING_MINE


def is_watched(rec: dict[str, Any]) -> bool:
    """Сделка в ручном списке «слежу» (ORBIT-3): флаг ставит :func:`recompute`."""
    return bool(rec.get("watched"))


def view_ring(rec: dict[str, Any]) -> str:
    """Кольцо ДЛЯ ВНИМАНИЯ: ``mine`` у наблюдаемой сделки, иначе реальное кольцо.

    Реальное кольцо (:func:`ring`) решает, куда можно ПИСАТЬ (гейт), а ``view_ring`` — что
    показывать в «мои». Две разные величины — намеренно: «слежу» ≠ «веду»."""
    if is_watched(rec) and not is_deleted(rec):
        return RING_MINE
    return ring(rec)


def resolve_unit(
    deal: dict[str, Any],
    users: dict[str, dict[str, Any]],
    legal_entities: dict[str, dict[str, Any]],
) -> tuple[str | None, str | None]:
    """Юрлицо сделки: ``deal.legalEntityId`` → иначе юрлицо ведущего → ``(None, None)``."""
    le_id = deal.get("legal_entity_id") or None
    if not le_id:
        manager = users.get(str(deal.get("manager_id") or ""), {})
        le_id = manager.get("legal_entity_id") or None
    if not le_id:
        return None, None
    le_id = str(le_id)
    name = (legal_entities.get(le_id) or {}).get("name") or deal.get("legal_entity_name")
    return le_id, name


def my_units(
    legal_entities: dict[str, dict[str, Any]],
    me: str,
    *,
    my_legal_entity_id: str | None = None,
    extra: Iterable[str] = (),
) -> frozenset[str]:
    """Мои юрлица: где я ``LegalEntity.managerId`` + моё собственное + явная добавка."""
    me_l = str(me or "").lower()
    units: set[str] = set()
    if my_legal_entity_id:
        units.add(str(my_legal_entity_id))
    extras = {str(x).strip().lower() for x in extra if str(x).strip()}
    for le_id, le in legal_entities.items():
        if me_l and str(le.get("manager_id") or "").lower() == me_l:
            units.add(str(le_id))
        if str(le_id).lower() in extras or str(le.get("name") or "").strip().lower() in extras:
            units.add(str(le_id))
    return frozenset(units)


def ring_of(
    deal: dict[str, Any],
    me: str,
    units: Iterable[str],
) -> str:
    """РЕАЛЬНОЕ кольцо сделки: ``mine`` / ``unit`` / ``group`` (правило — модульный докстринг).

    ``deal`` — запись зеркала; ``unit_id`` в ней уже разрешён (:func:`resolve_unit`).
    Неизвестное юрлицо (``unit_id`` пуст и у сделки, и у ведущего) → ``group``:
    консервативно — такое кольцо по умолчанию не видно, а doctor считает сделки без юрлица.
    Ручной watchlist кольцо НЕ меняет (ORBIT-3: «слежу» — это :func:`view_ring`, не право записи).
    """
    me_l = str(me or "").lower()
    if me_l and str(deal.get("manager_id") or "").lower() == me_l:
        return RING_MINE
    if me_l and me_l in {str(p).lower() for p in (deal.get("participants") or [])}:
        return RING_MINE
    unit_id = deal.get("unit_id")
    if unit_id and str(unit_id) in {str(u) for u in units}:
        return RING_UNIT
    return RING_GROUP


def _participants(deal: dict[str, Any], issues_by_deal: dict[str, set[str]]) -> list[str]:
    """Явные сигналы участия: исполнители пунктов чек-листа и связанных задач.
    Ведущий и ``createdBy`` в список НЕ входят."""
    manager = str(deal.get("manager_id") or "").lower()
    found: dict[str, str] = {}
    for item in deal.get("check_list") or []:
        pid = item.get("performer_id") if isinstance(item, dict) else None
        if pid:
            found[str(pid).lower()] = str(pid)
    for pid in issues_by_deal.get(str(deal.get("id")), ()):
        found[str(pid).lower()] = str(pid)
    return sorted(v for k, v in found.items() if k != manager)


def recompute(
    store: Any,
    me: str,
    *,
    watchlist: Iterable[str] = (),
    my_legal_entity_id: str | None = None,
) -> dict[str, int]:
    """Пересчитать ``unit_*``/``participants``/``ring`` у ВСЕХ сделок зеркала (дёшево).

    Вызывается в конце ``pull`` (кольцо — функция от «меня», юрлиц и задач, а не от одной
    сделки: смена настроек не должна ждать, пока сделка изменится в Timetta). Пишет файл,
    только если что-то изменилось (идемпотентно). Возвращает счётчики по кольцам.
    """
    deals = store.load("deals")
    if not deals:
        return {}
    users = store.load("users")
    legal = store.load("legal_entities")
    issues_by_deal: dict[str, set[str]] = {}
    for issue in store.all("issues"):
        if issue.get("deal_id") and issue.get("assigned_id") and not is_deleted(issue):
            issues_by_deal.setdefault(str(issue["deal_id"]), set()).add(str(issue["assigned_id"]))
    watched = {str(w).lower() for w in watchlist}
    my_le = my_legal_entity_id or (users.get(str(me)) or {}).get("legal_entity_id")
    units = my_units(legal, me, my_legal_entity_id=my_le, extra=unit_extra())
    counts: dict[str, int] = {}
    changed = False
    for guid, deal in deals.items():
        unit_id, unit_name = resolve_unit(deal, users, legal)
        new = dict(deal)
        new["unit_id"], new["unit_name"] = unit_id, unit_name
        new["participants"] = _participants(deal, issues_by_deal)
        new["ring"] = ring_of(new, me, units)
        # «слежу» (ORBIT-3): ключ только у наблюдаемых — зеркало без watchlist не меняется
        if str(guid).lower() in watched:
            new["watched"] = True
        else:
            new.pop("watched", None)
        if new != deal:
            deals[guid] = new
            changed = True
        counts[new["ring"]] = counts.get(new["ring"], 0) + 1
    if changed:
        store._write("deals", deals)
    return counts


# --- ЕДИНЫЙ фильтр потребителей ----------------------------------------------


def _effective(rings: Any, enabled: tuple[str, ...] | None) -> tuple[str, ...]:
    requested = parse_rings(rings, default=DEFAULT_VIEW)
    allowed = enabled if enabled is not None else enabled_rings()
    return tuple(r for r in requested if r in allowed)


def effective_rings(rings: Any = None, enabled: tuple[str, ...] | None = None) -> tuple[str, ...]:
    """Эффективные кольца запроса: запрошенные (дефолт ``mine``) ∩ ``DT_ORBIT_RINGS``."""
    return _effective(rings, enabled)


def visible(
    deals: Iterable[dict[str, Any]],
    rings: Any = None,
    *,
    include_deleted: bool = False,
    enabled: tuple[str, ...] | None = None,
) -> list[dict[str, Any]]:
    """Сделки зеркала в запрошенных кольцах — ЕДИНСТВЕННАЯ точка чтения для потребителей.

    ``rings`` — ``None`` (дефолт ``mine``), строка ``"mine,unit"`` или список. Эффективный
    набор = запрошенное ∩ ``DT_ORBIT_RINGS``; пустое пересечение → ``[]`` (не «всё»).
    Помеченные ``deleted_at`` (исчезли в Timetta) скрыты, если не ``include_deleted``.
    Неизвестное кольцо → :class:`OrbitError` (отказ, а не молчаливое ``mine``).
    """
    eff = _effective(rings, enabled)
    return [
        d for d in deals
        if isinstance(d, dict) and view_ring(d) in eff and (include_deleted or not is_deleted(d))
    ]


def visible_ids(deals: Iterable[dict[str, Any]], rings: Any = None, **kw: Any) -> set[str]:
    """Guid'ы видимых сделок (для джойна задач/проектов)."""
    return {str(d.get("id")) for d in visible(deals, rings, **kw) if d.get("id")}


def visible_issues(
    issues: Iterable[dict[str, Any]],
    deal_ids: set[str],
    *,
    me: str | None = None,
) -> list[dict[str, Any]]:
    """Задачи орбиты: назначены мне ИЛИ связаны с видимой сделкой (как до ORBIT-2)."""
    me_l = str(me or "").lower()
    if not me_l:
        # «Я» неизвестен (``DT_TIMETTA_USER_ID`` не задан): орбиту вычислить нечем — как до
        # ORBIT-2, всё, что лежит в зеркале, считается орбитой (без помеченного удалённым).
        return [i for i in issues if isinstance(i, dict) and not is_deleted(i)]
    return [
        i for i in issues
        if isinstance(i, dict) and not is_deleted(i)
        and (str(i.get("assigned_id") or "").lower() == me_l
             or str(i.get("deal_id") or "") in deal_ids)
    ]


def visible_projects(
    projects: Iterable[dict[str, Any]],
    deals: Iterable[dict[str, Any]],
    *,
    me: str | None = None,
) -> list[dict[str, Any]]:
    """Проекты орбиты: я ведущий ИЛИ это проект ЧУЖОЙ видимой сделки (кольца ``unit``/``group``).

    ``deals`` — уже отфильтрованные :func:`visible`. Проект СВОЕЙ сделки отдельным пунктом не
    идёт: он часть сделки (в зеркало подтягивается ради контекста), а до ORBIT-2 такие проекты
    в ленте «Работа» не появлялись — нулевая регрессия кольца ``mine``.
    """
    me_l = str(me or "").lower()
    if not me_l:
        return [p for p in projects if isinstance(p, dict) and not is_deleted(p)]
    foreign = {
        str(d.get("project_id")) for d in deals
        if d.get("project_id") and ring(d) != RING_MINE
    }
    return [
        p for p in projects
        if isinstance(p, dict) and not is_deleted(p)
        and ((me_l and str(p.get("manager_id") or "").lower() == me_l)
             or str(p.get("id")) in foreign)
    ]


def lookup(store: Any) -> dict[str, dict[str, Any]]:
    """СЫРАЯ карта ``{guid: сделка}`` — все кольца и удалённые. Только для ПОИСКА по id (карточка
    очереди, проверка цели записи), НЕ для показа: показ идёт через :func:`visible`."""
    return {str(g): d for g, d in store.load("deals").items() if isinstance(d, dict)}


def find(store: Any, guid: str) -> dict[str, Any] | None:
    """Сырая запись сделки по guid (без учёта регистра; все кольца, вкл. удалённые)."""
    target = str(guid or "").strip().lower()
    if not target:
        return None
    for key, deal in lookup(store).items():
        if str(deal.get("id", key)).strip().lower() == target:
            return deal
    return None


def find_ref(store: Any, ref: str) -> dict[str, Any] | None:
    """Сырая запись сделки по guid ИЛИ коду (``DEAL-41``), все кольца, вкл. удалённые."""
    found = find(store, ref)
    if found is not None:
        return found
    want = str(ref or "").strip().lower()
    if not want:
        return None
    for rec in lookup(store).values():
        if str(rec.get("code") or "").strip().lower() == want:
            return rec
    return None


def orbit_slice(
    store: Any,
    rings: Any = None,
    *,
    me: str | None = None,
    include_deleted: bool = False,
) -> dict[str, list[dict[str, Any]]]:
    """``{deals, issues, projects}`` зеркала в запрошенных кольцах — для потребителей,
    которым нужны сразу три таблицы (digest, reflect, контекст). ``store`` — ``MirrorStore``."""
    me = me if me is not None else _my_id()
    all_deals = store.all("deals")
    deals = visible(all_deals, rings, include_deleted=include_deleted)
    ids = {str(d.get("id")) for d in deals if d.get("id")}
    return {
        "deals": deals,
        "issues": visible_issues(store.all("issues"), ids, me=me),
        "projects": visible_projects(store.all("projects"), deals, me=me),
    }


def _my_id() -> str | None:
    from core.config import timetta_user_id

    return timetta_user_id()


# --- представление и запись --------------------------------------------------


def leader_badge(deal: dict[str, Any]) -> dict[str, Any] | None:
    """Бейдж ведущего для карточек: ``None`` у кольца ``mine`` (форма «своих» не меняется)."""
    r = ring(deal)
    if r == RING_MINE:
        return None
    badge = {"ring": r, "leader": deal.get("manager_name") or None,
             "unit": deal.get("unit_name") or None}
    if is_watched(deal):
        badge["watched"] = True
    return badge


def ring_counts(deals: Iterable[dict[str, Any]]) -> dict[str, int]:
    """``{mine, unit, group}`` по неудалённым сделкам (для doctor/пульта)."""
    out = dict.fromkeys(RINGS, 0)
    for d in deals:
        if isinstance(d, dict) and not is_deleted(d):
            out[ring(d)] += 1
    return out
