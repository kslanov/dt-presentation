"""Read-only JXA bridge to Classic Outlook for Mac (ТЗ phase5, stage 8).

A thin, **read-only** bridge — *not* a third-party MCP — that drives Classic
Outlook for Mac through its AppleScript dictionary via JavaScript for Automation
(``osascript -l JavaScript``). It exposes three operations:

* :meth:`OutlookBridge.list_folders` — enumerate mail folders;
* :meth:`OutlookBridge.read_messages` — pull a folder's messages since a date;
* :meth:`OutlookBridge.read_thread` — fetch one message (and its conversation
  when Outlook groups one) by entryID.

Each message dict carries ``subject``, ``from``/``to``/``cc``, ``date`` (ISO
8601), ``body`` (plain text), ``entryID``, ``folder``, ``conversationId`` and
``attachments``. The bridge **never writes** to Outlook.

Engine split: the two **reads** (:meth:`read_messages`, :meth:`read_thread`) run
on the **AppleScript** engine, not JXA. JXA's ``whose`` on a date property does
not push the filter into Outlook — it materialises the whole folder (15k+
messages) and hangs; AppleScript sends ``messages whose time received > d`` as an
indexed query that returns only the in-window set in seconds. Those scripts live
in ``applescript/`` (``_lib.applescript`` concatenated ahead of the op). Folder
enumeration (:meth:`list_folders`) stays on JXA in ``jxa/`` — it has no date
filter to push down. Both engines take ``argv`` from a single ``osascript``
file invocation and print a JSON payload (AppleScript writes UTF-8 bytes via
Foundation so Cyrillic is byte-correct).

Graceful degradation is the contract: if Outlook is not running (we never
auto-launch it), is the non-scriptable New Outlook, times out, or ``osascript``
is absent (non-macOS / CI), the operation raises :class:`OutlookUnavailableError`
with a clear, human-readable message instead of crashing. No LLM.
"""

from __future__ import annotations

import json
import logging
import os
import re
import signal
import subprocess
import tempfile
import time
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core import runlock
from core.adapters import (
    AdapterInterrupted,
    AdapterMisaligned,
    AdapterUnavailable,
    expect_shape,
)

__all__ = [
    "OutlookBridge",
    "OutlookUnavailableError",
    "OutlookInterruptedError",
    "BridgeMisalignedError",
    "JXA_DIR",
    "APPLESCRIPT_DIR",
    "normalize_calendar_event",
    "clean_bridge_field",
    "include_local_calendars",
    "excluded_calendars",
]

logger = logging.getLogger(__name__)

JXA_DIR = Path(__file__).resolve().parent / "jxa"
APPLESCRIPT_DIR = Path(__file__).resolve().parent / "applescript"

# A runner returns (returncode, stdout, stderr); injectable for tests so the
# scripts can be contract-tested without a real Outlook (or even macOS).
Runner = Callable[[list[str], float], "tuple[int, str, str]"]


class OutlookUnavailableError(AdapterUnavailable):
    """Outlook could not be read (not running, New Outlook, timeout, no osascript).

    Always carries a human-readable reason — callers surface it to the user and
    degrade gracefully rather than treating it as a crash. Член семейства
    :class:`core.adapters.AdapterError` (ADAPTER-HONEST-1): отказ моста — исключение с
    машинным ``code``, а не пустой результат.
    """

    default_adapter = "outlook"


class OutlookInterruptedError(AdapterInterrupted, OutlookUnavailableError):
    """Вызов моста прерван: таймаут уровня вызова или сон машины посреди него.

    Остаётся ``OutlookUnavailableError`` (существующие обработчики ловят его как раньше),
    но несёт код ``adapter_interrupted``: после пробуждения незавершённый вызов —
    отказ, а не вечное ожидание (инцидент 2026-10-13).
    """


class BridgeMisalignedError(AdapterMisaligned, OutlookUnavailableError):
    """Массивы ``list_folder_meta`` разошлись по длине — зипать их нельзя (MAIL-THREAD-1).

    Мост получает от AppleScript ПАРАЛЛЕЛЬНЫЕ массивы (``ids``/``subjects``/``epochs``/
    ``convs``): per-message dict'ы на 15k строк не укладывались в таймаут. Если у одного
    письма свойство не отдалось, соответствующий массив короче на 1, и зип по индексу
    молча сдвигает ВСЕ последующие значения на соседа (письмо получало ``conversationId``
    чужого разговора → 200 сообщений в двух тредах, 196 затронутых тредов). Это
    отказ с машиночитаемым конвертом (:meth:`envelope`, код ``bridge_misaligned``).
    Вызывающий (``OutlookBridge.list_folder_meta``) перечитывает страницу мельче, пока
    расхождение не локализуется до одного письма. Подкласс ``OutlookUnavailableError``:
    нелокализуемое расхождение для обработчиков моста — тот же «мост не отдал данные».
    """

    def __init__(
        self,
        *,
        folder: str,
        page: int,
        start: int | None = None,
        count: int | None = None,
        lengths: dict[str, int] | None = None,
        what: str = "meta",
    ) -> None:
        self.folder = folder
        self.page = page
        self.start = start
        self.count = count
        self.lengths = dict(lengths or {})
        super().__init__(
            f"bridge_misaligned: {what} folder={folder!r} page={page} start={start} "
            f"count={count} lengths={self.lengths}",
            folder=folder, page=page, start=start, count=count, lengths=self.lengths,
        )


# Realistic per-call ceiling (JOB-1, R5): a wedged/slow Outlook must not block
# for minutes. Genuinely long reads go through the async path (submit_job) rather
# than raising this. Kept in sync with :data:`core.config.DEFAULT_OUTLOOK_TIMEOUT`.
DEFAULT_TIMEOUT = 120.0

# The property line the AppleScript ops read for their `with timeout of …` cap.
# The bridge rewrites its NUMERIC value per call (see :meth:`_apply_timeout`);
# matching the whole `property kDTTimeout : <int>` shape (not a fixed literal)
# means the substitution can't silently no-op if the baked-in default ever drifts.
_KDTTIMEOUT_RE = re.compile(r"property kDTTimeout : \d+")


def _default_timeout() -> float:
    """Per-call ceiling from ``DT_OUTLOOK_TIMEOUT`` (default **120s**), used for
    BOTH the ``osascript`` subprocess AND the AppleScript ``with timeout`` inside
    the ops. A realistic ceiling against a wedged Outlook: bounded meta/heavy reads
    fit under it, and genuinely long reads go async (``submit_job``) instead of
    raising it. Mirrors :func:`core.config.outlook_timeout`; read from env to stay
    import-cycle free.
    """
    raw = (os.environ.get("DT_OUTLOOK_TIMEOUT") or "").strip()
    if raw:
        try:
            value = float(raw)
        except ValueError:
            return DEFAULT_TIMEOUT
        if value > 0:
            return value
    return DEFAULT_TIMEOUT


def _default_preflight_timeout() -> float:
    """Short ceiling for the cheap preflight probe (``DT_OUTLOOK_PREFLIGHT_TIMEOUT``,
    default 20s). Preflight must fail fast and must NOT inherit the heavy ceiling —
    a wedged/New Outlook would otherwise stall the probe for minutes (the R5 bug).
    """
    raw = (os.environ.get("DT_OUTLOOK_PREFLIGHT_TIMEOUT") or "").strip()
    if raw:
        try:
            value = float(raw)
        except ValueError:
            return 20.0
        if value > 0:
            return value
    return 20.0


def _emit_misaligned(envelope: dict[str, Any]) -> None:
    """Событие ``bridge_misaligned`` в журнал стадий (best-effort, без тем/адресов)."""
    try:
        from core.eventlog import emit

        emit("ingest", "bridge_misaligned", detail=envelope)
    except Exception:  # noqa: BLE001 — журнал не критичный путь
        logger.debug("eventlog emit(bridge_misaligned) failed", exc_info=True)


def _env_int(name: str, default: int) -> int:
    """Positive int from env ``name``, else ``default``."""
    raw = (os.environ.get(name) or "").strip()
    if raw.lstrip("-").isdigit():
        value = int(raw)
        if value > 0:
            return value
    return default


def _filter_since(
    rows: list[dict[str, Any]], since: str | None
) -> list[dict[str, Any]]:
    """Keep rows dated on/after ``since`` (``YYYY-MM-DD`` or ISO). Undated rows are
    kept (can't be excluded). No ``since`` → rows unchanged."""
    if not since:
        return rows
    text = since.strip()
    if len(text) == 10:  # bare date → start of day, UTC
        text += "T00:00:00+00:00"
    elif text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        cutoff = datetime.fromisoformat(text)
    except ValueError as exc:
        # Раньше нечитаемый ``since`` молча отдавал ВСЕ строки (окно расширялось до
        # всей папки). Некорректный вход — отказ, а не тихое расширение выборки.
        raise ValueError(f"since: ожидалась дата YYYY-MM-DD или ISO, получено {since!r}") from exc
    if cutoff.tzinfo is None:
        cutoff = cutoff.replace(tzinfo=UTC)

    kept: list[dict[str, Any]] = []
    for row in rows:
        d = row.get("date") or ""
        if not d:
            kept.append(row)  # undated → keep (can't compare)
            continue
        try:
            dt = datetime.fromisoformat(d)
        except ValueError:
            kept.append(row)
            continue
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        if dt >= cutoff:
            kept.append(row)
    return kept


# MEET-FIX-1 — нормализация полей календаря в ОДНОМ месте (здесь, в парсере моста).
#
# AppleScript на пустое поле отдаёт `missing value`, а `missing value as text` даёт
# строковый ЛИТЕРАЛ «missing value» — он и утёк в UI пульта как адрес переговорной
# (баг К. со скриншота: «missing value» под темой встречи). Чинить это в UI нельзя:
# литерал протёк бы в любого следующего потребителя моста. Поэтому мусорные значения
# гасятся здесь, один раз, для всех полей события — вниз идёт либо содержательная
# строка, либо ``None``.
_APPLESCRIPT_MISSING = frozenset({"missing value", "msng", "missing_value", "«class msng»"})

# Пустая запись участника, которую отдаёт мост, когда у attendee нет ни имени, ни
# адреса (``formatOneAddr`` собрал « <> »): числа участников такая запись не даёт —
# только врёт им.
_EMPTY_ATTENDEE = frozenset({"", "<>", "< >", "\"\" <>"})


def clean_bridge_field(value: Any) -> str | None:
    """Строка поля моста → содержательная строка либо ``None`` (см. комментарий выше).

    Публичная: тем же правилом читатель кэша (:func:`core.operational.meetings.cached`)
    гасит литерал в СТАРЫХ снапшотах, снятых до этого фикса — правило по-прежнему
    описано здесь одним местом, а не продублировано.
    """
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.casefold() in _APPLESCRIPT_MISSING:
        return None
    return text


def _clean_attendees(value: Any) -> list[str]:
    """Список участников: без ``missing value`` и без пустых « <> »-записей."""
    if not isinstance(value, (list, tuple)):
        return []
    out: list[str] = []
    for item in value:
        text = clean_bridge_field(item)
        if text is None or text in _EMPTY_ATTENDEE:
            continue
        out.append(text)
    return out


# MEET-FIX-2 — фильтр календарных папок.
#
# Диагноз (живой пробой 2026-08-07): Outlook перечисляет ``calendar events`` по ВСЕМ
# календарным папкам, включая смонтированные PST-архивы. У К. это 14 папок, из них 4
# БЕЗ аккаунта: локальный ``Calendar``, два ``Календарь (archive PST)`` (189 событий
# каждый) и ``Календарь (только этот компьютер) (backup_21-23 PST)`` — 978 событий.
# Именно оттуда приходила «Энерджи :: Mail.Ru :: Пресейлы», которую К. не находил в
# календаре: серия реальна как объект, но папка — архивный бэкап.
#
# Дефолт: **событие без аккаунта в выдачу не идёт**. Архив по определению не расписание
# «на сегодня», а видимость в живых календарях этим не меняется (перечень живых папок
# не трогаем — это отдельное решение владельца).
_INCLUDE_LOCAL_ENV = "DT_OUTLOOK_INCLUDE_LOCAL_CALENDARS"
_CALENDAR_EXCLUDE_ENV = "DT_OUTLOOK_CALENDAR_EXCLUDE"


def include_local_calendars() -> bool:
    """Возвращать ли события папок без аккаунта (``DT_OUTLOOK_INCLUDE_LOCAL_CALENDARS``).

    Дефолт — ``False`` (архивы/локальные папки скрыты). ``1``/``true``/``yes``/``on``
    возвращают прежнее поведение моста целиком, без правки кода.
    """
    raw = (os.environ.get(_INCLUDE_LOCAL_ENV) or "").strip().lower()
    return raw in {"1", "true", "yes", "on", "да"}


def excluded_calendars() -> set[str]:
    """Имена календарей, которые гасим точечно (``DT_OUTLOOK_CALENDAR_EXCLUDE``).

    Список через запятую, регистронезависимо, NFC (кириллические имена папок). Дефолт
    ПУСТОЙ: видимость живых календарей (дни рождения/праздники) без решения владельца
    не меняем — ручка на случай, если начнут шуметь.
    """
    raw = os.environ.get(_CALENDAR_EXCLUDE_ENV) or ""
    return {
        unicodedata.normalize("NFC", part).strip().casefold()
        for part in raw.split(",")
        if part.strip()
    }


def _calendar_allowed(
    ev: dict[str, Any], *, include_local: bool, excluded: set[str]
) -> bool:
    """Пускать ли событие: есть аккаунт (или разрешены локальные) и папка не в exclude."""
    if not include_local and not ev.get("account"):
        return False
    name = ev.get("calendar")
    if name and excluded:
        return unicodedata.normalize("NFC", str(name)).strip().casefold() not in excluded
    return True


def normalize_calendar_event(ev: Any) -> dict[str, Any] | None:
    """Событие моста → нормализованный dict (``None`` для мусорной записи).

    Ключи сохраняются (потребители читают их по имени), но пустые/`missing value`
    поля становятся ``None``: ``location=None`` значит «места нет», а не «место
    называется missing value». ``allDay`` приводится к bool, участники чистятся.
    """
    if not isinstance(ev, dict):
        return None
    return {
        "entryID": clean_bridge_field(ev.get("entryID")) or "",
        "subject": clean_bridge_field(ev.get("subject")),
        "start": clean_bridge_field(ev.get("start")),
        "end": clean_bridge_field(ev.get("end")),
        "location": clean_bridge_field(ev.get("location")),
        "allDay": bool(ev.get("allDay")),
        "attendees": _clean_attendees(ev.get("attendees")),
        # MEET-FIX-2: откуда событие — папка календаря и её аккаунт. ``account=None``
        # означает локальную/PST-папку (у неё нет аккаунта) — по этому признаку
        # :meth:`OutlookBridge.read_calendar_events` отсекает архивы.
        "calendar": clean_bridge_field(ev.get("calendar")),
        "account": clean_bridge_field(ev.get("account")),
    }


def _meta_single_max() -> int:
    """Folder size (messages) up to which meta uses one plain pass; above it,
    index paging kicks in. ``DT_MAIL_META_SINGLE_MAX`` (default 60000 — a plain
    pass at ~2.2 ms/msg stays well under the 180s ceiling there)."""
    return _env_int("DT_MAIL_META_SINGLE_MAX", 60000)


def _meta_page_size() -> int:
    """Index-page size (messages) for the large-folder meta fallback.
    ``DT_MAIL_META_PAGE`` (default 10000 — one page's four gets stays < ~120s)."""
    return _env_int("DT_MAIL_META_PAGE", 10000)


def _sleep_gap_s() -> float:
    """Порог «машина спала посреди вызова», секунды (``DT_OUTLOOK_SLEEP_GAP_S``, 30)."""
    raw = (os.environ.get("DT_OUTLOOK_SLEEP_GAP_S") or "").strip()
    try:
        value = float(raw)
    except ValueError:
        return 30.0
    return value if value > 0 else 30.0


def _kill_group(proc: subprocess.Popen[str]) -> None:
    """Убить процесс osascript вместе с его группой; не ждать вечно.

    ``wait`` ограничен: зависший в ядре процесс, не реагирующий на SIGKILL, не должен
    утащить за собой вызывающего — иначе «прерванный» вызов всё равно висит.
    """
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError, OSError):
        try:
            proc.kill()
        except OSError:
            pass
    try:
        proc.communicate(timeout=5)
    except (subprocess.TimeoutExpired, OSError, ValueError):
        logger.warning(
            "[outlook] osascript pid=%s не завершился после SIGKILL — оставлен", proc.pid
        )


def _default_runner(
    cmd: list[str],
    timeout: float,
    *,
    _wall: Any = time.time,
    _mono: Any = time.monotonic,
    _tick: float = 0.5,
) -> tuple[int, str, str]:
    """Run ``cmd`` via subprocess → ``(returncode, stdout, stderr)``, с таймаутом
    **уровня вызова** и защитой от сна машины (ADAPTER-HONEST-1 п.6).

    Прежний ``subprocess.run(timeout=…)`` считал время монотонными часами, которые на
    macOS НЕ идут во сне: вызов, заснувший с машиной, просыпался «с целым бюджетом» —
    а Apple Event, ответа на который уже не будет, пережил сон как вечное ожидание
    (инцидент 2026-10-13: ночной index простоял 10 часов). Здесь вызов опрашивается
    короткими тиками и меряется ДВУМЯ часами — настенными и монотонными: их расхождение
    больше :func:`_sleep_gap_s` означает, что машина спала посреди вызова. Тогда
    незавершённый вызов — отказ (:class:`OutlookInterruptedError`), процесс убивается,
    шаг синка перезапустится на следующем проходе, а не провисит. Таймаут по настенным
    часам — тоже отказ (``subprocess.TimeoutExpired`` → тот же класс на уровне ``_exec``).
    ``_wall``/``_mono``/``_tick`` — инъекция для тестов (без реального сна).
    """
    proc = subprocess.Popen(  # noqa: S603 — cmd is built from our own script paths
        cmd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    wall0, mono0 = _wall(), _mono()
    gap = _sleep_gap_s()
    while True:
        try:
            out, err = proc.communicate(timeout=_tick)
            return proc.returncode, out, err
        except subprocess.TimeoutExpired:
            pass
        wall, mono = _wall() - wall0, _mono() - mono0
        if wall - mono > gap:
            _kill_group(proc)
            raise OutlookInterruptedError(
                f"вызов Outlook прерван: машина спала посреди вызова (~{wall - mono:.0f}с); "
                "незавершённый вызов после пробуждения — отказ, не ожидание",
                kind="sleep",
            )
        if wall > timeout or mono > timeout:
            _kill_group(proc)
            raise subprocess.TimeoutExpired(cmd, timeout)


@dataclass
class OutlookBridge:
    """Read-only handle to Classic Outlook.

    ``timeout`` bounds each ``osascript`` call (seconds); it defaults from
    ``DT_OUTLOOK_TIMEOUT`` (**120s**) so a wedged Outlook can't hang the ingest for
    minutes. ``runner`` is the subprocess shim — overridden in tests to feed canned
    JSON/errors without a real Outlook. ``scripts_dir`` holds the JXA folder
    enumerator; ``applescript_dir`` holds the AppleScript readers (see the
    module docstring for why the reads are on AppleScript, not JXA).

    ``require_preflight=True`` gates every heavy read behind one cheap probe
    (:meth:`preflight`, bounded by ``preflight_timeout``): if Outlook is not
    running or is the non-scriptable New Outlook, the read raises
    :class:`OutlookUnavailableError` *fast* instead of waiting out the full heavy
    ceiling (R5). It defaults off so the op methods stay pure for contract tests;
    real callers (meetings / mail ingest / the async job worker) opt in.
    """

    timeout: float = field(default_factory=_default_timeout)
    runner: Runner | None = None
    scripts_dir: Path = field(default_factory=lambda: JXA_DIR)
    applescript_dir: Path = field(default_factory=lambda: APPLESCRIPT_DIR)
    require_preflight: bool = False
    preflight_timeout: float = field(default_factory=_default_preflight_timeout)
    _preflight_ok: bool = field(default=False, init=False, repr=False)
    # MAIL-THREAD-1: конверты ``bridge_misaligned`` этого экземпляра (для статистики
    # инжеста/отчёта); каждый — событие, не тихая подмена.
    misaligned: list[dict[str, Any]] = field(default_factory=list, init=False, repr=False)

    # ------------------------------------------------------------------ #
    # Operations                                                         #
    # ------------------------------------------------------------------ #

    def list_folders(self) -> list[dict[str, Any]]:
        """Enumerate mail folders → ``[{name, unread}, ...]`` (read-only, JXA)."""
        data = self._run_jxa("list_folders.js", [])
        return list(
            expect_shape(
                data, list, adapter="outlook", op="list_folders", exc=OutlookUnavailableError
            )
        )

    def read_messages(
        self, folder: str, since: str | None = None, limit: int = 500
    ) -> list[dict[str, Any]]:
        """Pull ``folder``'s messages dated on/after ``since`` (ISO/empty), newest
        first, capped at ``limit``. Returns a list of message dicts.

        Runs on the AppleScript engine so the ``since`` filter is pushed into
        Outlook as an indexed query (JXA would scan the whole folder)."""
        self._ensure_preflight()
        args = [str(folder), since or "", str(int(limit))]
        data = self._run_applescript("read_messages.applescript", args)
        return list(expect_shape(
            data, list, adapter="outlook", op="read_messages", exc=OutlookUnavailableError
        ))

    def read_thread(self, entry_id: str) -> list[dict[str, Any]]:
        """Fetch the message ``entry_id`` (plus its conversation when available)."""
        self._ensure_preflight()
        data = self._run_applescript("read_thread.applescript", [str(entry_id)])
        return list(expect_shape(
            data, list, adapter="outlook", op="read_thread", exc=OutlookUnavailableError
        ))

    def read_calendar_events(
        self, start: str, end: str
    ) -> list[dict[str, Any]]:
        """Read-only pull of calendar events with ``start ≤ start time < end``
        (both ISO ``YYYY-MM-DD`` or full ISO), soonest first. Returns event dicts:
        ``{entryID, subject, start, end, location, body, attendees[], allDay}``.

        Runs on the AppleScript engine so the window filter is pushed into Outlook
        as an indexed query. Same graceful-degradation contract as the mail reads:
        raises :class:`OutlookUnavailableError` when Outlook can't be read.

        MEET-FIX-1: поля прогоняются через :func:`normalize_calendar_event` — здесь
        единственное место, где гасятся AppleScript-литералы ``missing value`` и
        пустые записи участников (иначе они текут в кэш и в UI).

        MEET-FIX-2: **события папок БЕЗ аккаунта (локальные/PST-архивы) по умолчанию
        отфильтрованы** — Outlook перечисляет и смонтированные бэкапы, и оттуда лезли
        «фантомные» встречи. Вернуть прежнее поведение —
        ``DT_OUTLOOK_INCLUDE_LOCAL_CALENDARS=1``; погасить конкретные папки живых
        аккаунтов — ``DT_OUTLOOK_CALENDAR_EXCLUDE`` (имена через запятую). Каждое
        событие несёт ``calendar``/``account`` — «откуда это» видно без osascript."""
        self._ensure_preflight()
        data = self._read_calendar_window(str(start), str(end))
        include_local = include_local_calendars()
        excluded = excluded_calendars()
        out: list[dict[str, Any]] = []
        for ev in data:
            norm = normalize_calendar_event(ev)
            if norm is None:
                # Не-словарь внутри массива событий — сбой формы ответа, а не «событие
                # без данных»: молча пропущенная запись = пропавшая встреча.
                raise OutlookUnavailableError(
                    f"outlook/read_calendar: элемент ответа не событие ({type(ev).__name__})",
                    adapter="outlook", op="read_calendar",
                )
            if not _calendar_allowed(norm, include_local=include_local, excluded=excluded):
                continue
            out.append(norm)
        return out

    def _read_calendar_window(self, start: str, end: str) -> list[Any]:
        """Один вызов ``read_calendar`` с локализацией расхождения массивов.

        Скрипт сверяет длины параллельных списков свойств события и отказывается
        (``bridge_misaligned``), а не сдвигает значения на соседа (тема/время чужой
        встречи — тот же дефект, что был у почты). Здесь окно перечитывается половинами
        по дням, пока расхождение не локализуется; на окне в сутки расхождение —
        отказ наружу (конверт, не неверные встречи).
        """
        try:
            data = self._run_applescript("read_calendar.applescript", [start, end])
            return list(expect_shape(
            data, list, adapter="outlook", op="read_calendar", exc=OutlookUnavailableError
        ))
        except BridgeMisalignedError as exc:
            self.misaligned.append(exc.envelope())
            _emit_misaligned(exc.envelope())
            try:
                d1 = datetime.fromisoformat(start[:10]).date()
                d2 = datetime.fromisoformat(end[:10]).date()
            except ValueError:
                raise exc from None
            days = (d2 - d1).days
            if days <= 1:
                raise
            mid = (d1 + timedelta(days=days // 2)).isoformat()
            return self._read_calendar_window(start, mid) + self._read_calendar_window(
                mid, end
            )

    def list_folder_meta(
        self, folder: str, since: str | None = None
    ) -> list[dict[str, Any]]:
        """CHEAP metadata for every message in ``folder`` (bodies excluded) →
        ``[{entryID, subject, date, conversationId}, ...]``. ``since`` (ISO/empty)
        keeps only messages on/after that date; empty = the whole folder.

        Sizing (принцип 11 — bounded per call regardless of folder OR window):
          * folder ≤ ``DT_MAIL_META_SINGLE_MAX`` (60k) → one fast plain
            ``messages`` pass (measured ~35s for 15.8k).
          * larger → paginate by MESSAGE INDEX in ``DT_MAIL_META_PAGE`` (10k)
            chunks so no single ``osascript`` call can time out; deduped by entryID.

        ``since`` is applied in Python here, NOT as a folder ``whose``: a 2-year
        ``whose`` over a big folder overruns even a raised Apple Event ceiling. The
        plain/index scan is fast and bounded; we just drop rows before the cutoff."""
        self._ensure_preflight()
        count = self._count_messages(folder)
        if count <= 0:
            return []
        if count <= _meta_single_max():
            rows = self._meta_resolve(folder, None, None, total=count, page=1)
        else:
            # Large folder → bounded index pages, deduped by entryID (indices can
            # shift if mail moves mid-scan; a one-time archival read tolerates it).
            page = _meta_page_size()
            rows = []
            seen: set[str] = set()
            start = 1
            page_no = 0
            while start <= count:
                page_no += 1
                for row in self._meta_resolve(
                    folder, start, page, total=count, page=page_no
                ):
                    eid = row.get("entryID") or ""
                    if eid and eid not in seen:
                        seen.add(eid)
                        rows.append(row)
                start += page
        return _filter_since(rows, since)

    def _count_messages(self, folder: str) -> int:
        """Message count for ``folder`` (O(1) in Outlook) → int. Ответ без числового
        ``count`` — отказ адаптера (не 0: «0 писем» было бы тихой подменой сбоя)."""
        data = self._run_applescript("count_messages.applescript", [str(folder)])
        data = expect_shape(
            data, dict, adapter="outlook", op="count_messages", exc=OutlookUnavailableError
        )
        try:
            return int(data["count"])
        except (KeyError, TypeError, ValueError) as exc:
            # «0 писем» из-за непонятного ответа — не «папка пуста», а отказ.
            raise OutlookUnavailableError(
                f"outlook/count_messages: нет числового count в ответе ({data!r:.80})",
                adapter="outlook", op="count_messages",
            ) from exc

    def _meta_resolve(
        self,
        folder: str,
        start: int | None,
        count: int | None,
        *,
        total: int,
        page: int,
    ) -> list[dict[str, Any]]:
        """:meth:`_meta_page` с локализацией расхождения массивов (MAIL-THREAD-1).

        Страница, чьи массивы разошлись по длине, НЕ зипуется: фиксируется конверт
        ``bridge_misaligned`` (с номером страницы) и диапазон перечитывается двумя
        половинами, рекурсивно, пока расхождение не сойдётся к одному письму — там
        массив пуст целиком (``missing value`` у единственного письма) и это честный
        sentinel ``""``, а не сдвиг соседей. Сдвинутая запись не возвращается никогда.
        """
        try:
            return self._meta_page(folder, start, count, page=page)
        except BridgeMisalignedError as exc:
            envelope = exc.envelope()
            self.misaligned.append(envelope)
            logger.warning(
                "[outlook] bridge_misaligned folder=%r page=%d start=%s count=%s "
                "lengths=%s — перечитываю мельче",
                folder, page, start, count, exc.lengths,
            )
            _emit_misaligned(envelope)
            first = start if start else 1
            size = count if count else total
            if size <= 1:
                raise  # на одном письме расходиться нечему — это уже сбой моста
            left = size // 2
            return self._meta_resolve(
                folder, first, left, total=total, page=page
            ) + self._meta_resolve(
                folder, first + left, size - left, total=total, page=page
            )

    def _meta_page(
        self,
        folder: str,
        start: int | None,
        count: int | None,
        *,
        page: int = 1,
    ) -> list[dict[str, Any]]:
        """One metadata call → list of dicts. The op returns PARALLEL ARRAYS
        (``{ids, subjects, epochs, convs}``) — building per-message dicts in
        AppleScript over 15k rows timed out — which we zip + convert epoch→ISO in
        fast Python. ``start``/``count`` (1-based) request an index page; without
        them it's a plain full pass (date filtering is done by the caller).

        **Выровненность (MAIL-THREAD-1).** Зип по индексу допустим только если каждый
        массив той же длины, что ``ids``, либо пуст целиком (свойство недоступно у всей
        страницы — сдвинуть нечего, значения ``""``). Любая другая длина — свойство
        отдалось не у всех писем, и зип молча сдвинул бы последующие значения на
        соседа: :class:`BridgeMisalignedError`."""
        args = [
            str(folder),
            "",  # no folder-side `whose` — the since filter is applied in Python
            "" if start is None else str(start),
            "" if count is None else str(count),
        ]
        data = self._run_applescript("list_folder_meta.applescript", args)
        data = expect_shape(
            data, dict, adapter="outlook", op="list_folder_meta", exc=OutlookUnavailableError
        )
        if data and "ids" not in data:
            raise OutlookUnavailableError(
                f"outlook/list_folder_meta: в ответе нет ids (ключи: {sorted(data)[:6]})",
                adapter="outlook", op="list_folder_meta",
            )
        ids = data.get("ids") or []
        subjects = data.get("subjects") or []
        epochs = data.get("epochs") or []
        convs = data.get("convs") or []

        n = len(ids)
        lengths = {
            "ids": n,
            "subjects": len(subjects),
            "epochs": len(epochs),
            "convs": len(convs),
        }
        for length in lengths.values():
            if length not in (n, 0):
                raise BridgeMisalignedError(
                    folder=str(folder), page=page, start=start, count=count, lengths=lengths
                )
        for name, length in lengths.items():
            if name != "ids" and n > 1 and length == 0:
                logger.warning(
                    "[outlook] bridge: массив %r пуст на странице из %d писем "
                    "(folder=%r page=%d) — свойство недоступно, значения пустые",
                    name, n, folder, page,
                )

        def _iso(epoch: Any) -> str:
            try:
                return datetime.fromtimestamp(float(epoch), UTC).isoformat()
            except (TypeError, ValueError, OSError, OverflowError) as exc:
                # Пусто («нет даты») — sentinel выше, в вызывающем; а ЗНАЧЕНИЕ, которое
                # не разобралось, — порча данных моста, не «дата неизвестна».
                raise OutlookUnavailableError(
                    f"outlook/list_folder_meta: epoch не число ({epoch!r:.40})",
                    adapter="outlook", op="list_folder_meta",
                ) from exc

        out: list[dict[str, Any]] = []
        for i, mid in enumerate(ids):
            subj = subjects[i] if subjects else ""
            epoch = epochs[i] if epochs else None
            conv = convs[i] if convs else ""
            out.append(
                {
                    "entryID": "" if mid is None else str(mid),
                    "subject": "" if subj is None else str(subj),
                    "date": _iso(epoch) if epoch not in (None, "") else "",
                    "conversationId": "" if conv is None else str(conv),
                }
            )
        return out

    def fetch_by_ids(
        self, folder: str, ids: list[str]
    ) -> list[dict[str, Any]]:
        """HEAVY full message objects for an EXACT id batch. Each id is fetched by
        ``message id X of <folder>`` — a direct hash lookup (~0s, no scan) — so
        only the batch's messages are pulled, never a whole date span (the old
        date-range fetch dragged in months of bodies on sparse resumes and
        stalled/errored). Empty ``ids`` → ``[]`` with no Outlook call."""
        if not ids:
            return []
        self._ensure_preflight()
        args = [str(folder), *[str(i) for i in ids]]
        data = self._run_applescript("fetch_by_ids.applescript", args)
        return list(expect_shape(
            data, list, adapter="outlook", op="fetch_by_ids", exc=OutlookUnavailableError
        ))

    def probe_folder(self, folder: str) -> dict[str, Any]:
        """Read-only diagnostic for ``folder`` → ``{total, by_time_sent,
        by_time_received, newest{class,time_sent,time_received}}``.

        Resolves the folder via the same ``resolveFolder`` as the reader (so
        account-nested Sent folders are found) and reports message counts by each
        date field over a 30-day window — used to determine which field actually
        filters a folder. Never writes."""
        data = self._run_applescript("probe_folder.applescript", [str(folder)])
        return dict(expect_shape(
            data, dict, adapter="outlook", op="probe_folder", exc=OutlookUnavailableError
        ))

    def list_sent_folders(self) -> list[dict[str, Any]]:
        """Read-only diagnostic: every Sent-looking folder across all accounts →
        ``[{name, path, total, by_time_sent, by_time_received}, ...]``.

        Reveals which folder actually holds sent mail (``resolveFolder`` can match
        an empty decoy named ``Sent``) and which date field populates it."""
        data = self._run_applescript("list_sent_folders.applescript", [])
        return list(expect_shape(
            data, list, adapter="outlook", op="list_sent_folders", exc=OutlookUnavailableError
        ))

    # ------------------------------------------------------------------ #
    # Preflight (cheap gate against a stopped / New Outlook)             #
    # ------------------------------------------------------------------ #

    def preflight(self) -> dict[str, Any]:
        """Cheap, bounded check that **Classic** Outlook is reachable (R5).

        Runs ``preflight.applescript`` under the short :attr:`preflight_timeout`
        (never the heavy ceiling): it confirms Outlook is running (via System
        Events, no auto-launch) and is *scriptable* — the non-scriptable New
        Outlook fails the Outlook-specific probe. On any failure it raises
        :class:`OutlookUnavailableError` with a clear reason **fast**, so a caller
        never waits out a multi-minute heavy call against an Outlook that can't be
        read. Returns the probe payload on success.
        """
        data = self._run_applescript(
            "preflight.applescript", [], timeout=self.preflight_timeout
        )
        return dict(expect_shape(
            data, dict, adapter="outlook", op="preflight", exc=OutlookUnavailableError
        ))

    def _ensure_preflight(self) -> None:
        """Run :meth:`preflight` once per instance when ``preflight`` is enabled.

        No-op when the flag is off (op methods stay pure for contract tests) or
        after a first success (repeated ops on one bridge don't re-probe).
        """
        if not self.require_preflight or self._preflight_ok:
            return
        self.preflight()
        self._preflight_ok = True

    # ------------------------------------------------------------------ #
    # osascript plumbing                                                 #
    # ------------------------------------------------------------------ #

    def _concat_source(self, base_dir: Path, lib_name: str, op_script: str) -> str:
        """``<lib>`` (shared helpers) + the chosen op script, from ``base_dir``."""
        lib = base_dir / lib_name
        op = base_dir / op_script
        if not lib.is_file() or not op.is_file():
            raise OutlookUnavailableError(
                f"Outlook scripts missing under {base_dir}"
            )
        return lib.read_text(encoding="utf-8") + "\n" + op.read_text(encoding="utf-8")

    def _apply_timeout(self, source: str, timeout: float) -> str:
        """Rewrite the ``kDTTimeout`` property to ``timeout`` (whole seconds).

        Robust substitution (R5): matches the whole ``property kDTTimeout : <int>``
        line by regex — not a fixed literal — and **asserts exactly one match**. If
        the property is absent or renamed (a lib refactor / literal drift) the
        substitution has NOT taken effect, so we raise
        :class:`OutlookUnavailableError` rather than silently running under the
        script's baked-in default (a wedged Outlook could then hang far past our
        intended ceiling — the exact failure this replaces).
        """
        new_source, n = _KDTTIMEOUT_RE.subn(
            f"property kDTTimeout : {max(1, int(timeout))}", source, count=1
        )
        if n != 1:
            raise OutlookUnavailableError(
                "Outlook bridge misconfigured: the `kDTTimeout` property was not "
                "found in _lib.applescript, so the Apple Event timeout could not "
                "be applied — refusing to run under an unbounded/default ceiling."
            )
        return new_source

    def _run_jxa(self, op_script: str, args: list[str]) -> Any:
        """Run a JXA op (``osascript -l JavaScript``) and parse its JSON."""
        source = self._concat_source(self.scripts_dir, "_lib.js", op_script)
        # A real file invocation (vs -e) reliably forwards argv to run().
        return self._exec(source, ".js", ["-l", "JavaScript"], args, self.timeout)

    def _run_applescript(
        self, op_script: str, args: list[str], *, timeout: float | None = None
    ) -> Any:
        """Run an AppleScript op (default engine — NOT ``-l JavaScript``) and parse
        its JSON. The script's ``on run argv`` receives ``args``. ``timeout``
        overrides the per-call ceiling (preflight uses a short one)."""
        effective = self.timeout if timeout is None else timeout
        source = self._concat_source(
            self.applescript_dir, "_lib.applescript", op_script
        )
        # Lift the ~120s Apple Event cap to our own ceiling: the ops wrap their
        # body in `with timeout of kDTTimeout seconds`; substitute the value
        # robustly (raises if the property drifted — never a silent default).
        source = self._apply_timeout(source, effective)
        return self._exec(source, ".applescript", [], args, effective)

    def _exec(
        self,
        source: str,
        suffix: str,
        lang_flags: list[str],
        args: list[str],
        timeout: float,
    ) -> Any:
        """Write ``source`` to a temp script, run it under ``osascript`` with the
        given language flags + ``args``, and parse the JSON it prints.

        Raises :class:`OutlookUnavailableError` for every failure mode (missing
        osascript, non-zero exit, empty/garbage output, or a ``{"error": ...}``
        envelope emitted by the script when Outlook is unavailable).
        """
        runner = self.runner or _default_runner
        with tempfile.NamedTemporaryFile(
            "w", suffix=suffix, encoding="utf-8", delete=True
        ) as fh:
            fh.write(source)
            fh.flush()
            cmd = ["osascript", *lang_flags, fh.name, *args]
            try:
                code, stdout, stderr = runner(cmd, timeout)
            except FileNotFoundError as exc:  # osascript absent (non-macOS / CI)
                raise OutlookUnavailableError(
                    "osascript not found — the Outlook bridge requires macOS."
                ) from exc
            except subprocess.TimeoutExpired as exc:
                raise OutlookInterruptedError(
                    f"Outlook did not respond within {timeout:.0f}s.", kind="timeout"
                ) from exc

        if code != 0:
            detail = (stderr or "").strip() or f"osascript exited with {code}"
            raise OutlookUnavailableError(f"Outlook bridge failed: {detail}")

        out = (stdout or "").strip()
        if not out:
            raise OutlookUnavailableError("Outlook bridge returned no output.")
        try:
            data = json.loads(out)
        except json.JSONDecodeError as exc:
            raise OutlookUnavailableError(
                "Outlook bridge returned non-JSON output."
            ) from exc
        if isinstance(data, dict) and data.get("error"):
            message = str(data["error"])
            if message.startswith("bridge_misaligned"):
                # Сам скрипт заметил расхождение параллельных списков (ADAPTER-HONEST-1 п.3).
                raise BridgeMisalignedError(
                    folder=str(args[0]) if args else "", page=1, what=message[:200]
                )
            raise OutlookUnavailableError(message)
        runlock.beat()  # завершённый вызов моста — прогресс (heartbeat lock'а прогона)
        return data
