"""``place_download`` — доставка ЛОКАЛЬНОГО файла в рабочую папку (ФТ-1, FILE-LOCAL-1).

Принцип ФТ (не нарушать): **мост MCP — управляющий канал, байты доставляет
браузер**. ``store_file`` тащит содержимое файла через параметр MCP в base64 —
21 КБ .docx → 28 КБ base64 → минуты последовательной генерации текста, а инцидент
04.08.2026 показал, что одно тяжёлое сообщение обесточивает мост целиком (отвалился
и непричастный MacOS-MCP). Здесь через мост идёт только команда (порядка 60 байт):
файл уже лежит в ``~/Downloads``, скачанный браузером напрямую, а движок делает
локальный ``rename`` — единицы миллисекунд вместо минут, без риска искажения.

Два адреса источника, взаимоисключимых by design:

* ``match`` — поиск в каталогах загрузок (браузер только что скачал файл);
* ``source_path`` — ЯВНЫЙ абсолютный путь к файлу на диске (FILE-LOCAL-1, фейлкейс
  17.08): Cowork-маунт, ``~/Downloads`` мимо шаблона, любой локальный путь. Фильтр
  возраста здесь НЕ применяется — явный путь это выбор человека, а не догадка.

Чего этот инструмент НЕ умеет (и что вместо него): файла из ПЕСОЧНИЦЫ чата на диске
мака нет вовсе — документ, собранный ИЗ ТЕКСТА, доставляет ``save_output(dest,
format)`` (pandoc локально, без base64), истинный бинарь из чата — ``store_file`` /
chunked через мост с хэш-гардами. Развилка держится в описаниях инструментов и в
handshake-контракте: 17.08 механизм был, а маршрут агент выбрал не тот.

Поведение (ФТ-1):

* кандидаты — файлы каталогов загрузок (env ``DT_DOWNLOADS_DIRS``, дефолт
  ``~/Downloads``; без рекурсии), фильтр по ``match`` (glob **или** подстрока,
  регистронезависимо) и ``max_age_minutes``; недокачанные ``*.crdownload``/
  ``*.part``/``*.download`` и точечные файлы кандидатами не считаются;
* **0 кандидатов** → отказ + 5 последних файлов каталога (диагностика шаблона);
* **>1 кандидата** → отказ + ``candidates`` (имя, размер, mtime). Автовыбор «самого
  свежего» ЗАПРЕЩЁН ФТ: цена ошибочной записи в клиентскую папку выше цены
  повторного уточняющего вызова;
* ``dest`` — алиас папки (ФТ-2) либо путь относительно корня; имя файла берётся из
  ``new_name`` либо из источника;
* **iCloud dataless источник** — материализация ``brctl download`` (реюз паттерна
  :mod:`core.file_ingest.scan`, бюджет ``DT_INGEST_MATERIALIZE_TIMEOUT``); не
  материализовался → явный отказ ``not_materialized``. Нулевой/частичный файл в
  целевой папке не появляется никогда;
* перенос атомарный: в пределах тома — ``os.rename``; между томами — копия в
  ``.tmp`` рядом с целью + ``fsync`` + ``os.replace`` (частичный файл под целевым
  именем не наблюдаем ни в один момент), затем источник удаляется, если не
  ``keep_source``;
* гарды — те же, что у ``store_file``, поведением идентичные (общий слой
  :mod:`core.file_ingest.write_target`): containment по ``resolve``, NDA **на цели И
  на источнике** (перенос под чистый корень «отмыл» бы маркер пути), существующий
  байт-идентичный → ``existed`` без перезаписи (mtime цел), отличающийся → отказ без
  ``overwrite=True``;
* аудит ``record_action`` — источник, целевой путь, размер, sha256(12), результат;
  **содержимое не логируется**.

Перф: один ``rename`` + один потоковый sha256 (50 МБ ≈ 0,2 с) — требование ФТ «≤2 с
для 50 МБ» выполняется с запасом.

Отказы — :class:`PlaceDownloadError` с ``code`` (машиночитаемая причина, NFR
«диагностируемость») и ``details`` (кандидаты / последние файлы). MCP-обёртка
разворачивает их в ``{ok:false, refused, code, error, …}``; ``core`` ⊥ mcp/cli.
"""

from __future__ import annotations

import errno
import fnmatch
import os
import stat as stat_mod
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.config import ingest_materialize_timeout
from core.file_ingest.write_target import (
    ABSENT,
    DEFAULT_ROOT_NAME,
    IDENTICAL,
    WriteTarget,
    WriteTargetError,
    existing_disposition,
    resolve_dest_target,
    sha256_file,
)
from core.privacy import is_nda

__all__ = [
    "PlaceDownloadError",
    "Candidate",
    "VIA_MATCH",
    "VIA_PATH",
    "place_download",
    "downloads_dirs",
    "DEFAULT_DOWNLOADS_DIR",
    "DEFAULT_MAX_AGE_MINUTES",
    "DOWNLOADS_DIRS_ENV",
]

# Каталог загрузок по умолчанию + env-override (ФТ, открытый вопрос №1: каталог
# браузера может быть не один — список настраиваемый, разделитель ``os.pathsep``).
DEFAULT_DOWNLOADS_DIR = "~/Downloads"
DOWNLOADS_DIRS_ENV = "DT_DOWNLOADS_DIRS"

# Возраст кандидата по умолчанию (ФТ-1): файл скачан «только что» под текущую
# команду. ``max_age_minutes<=0`` — без ограничения по возрасту.
DEFAULT_MAX_AGE_MINUTES = 60

# Незавершённые загрузки браузеров: под этими именами лежит ЧАСТИЧНЫЙ файл —
# кандидатом быть не может (иначе перенесём огрызок в клиентскую папку).
_PARTIAL_SUFFIXES = (".crdownload", ".part", ".download", ".partial", ".tmp")

# Сколько последних файлов каталога показать, когда шаблон не дал кандидатов.
_RECENT_LIMIT = 5

# Суффикс временного файла cross-volume копии (в папке цели — ``replace`` атомарен
# только в пределах одной ФС).
_TMP_SUFFIX = ".dt-place.tmp"


class PlaceDownloadError(RuntimeError):
    """Отказ ``place_download``: ``code`` — машинная причина, ``details`` — payload."""

    def __init__(self, message: str, code: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.details: dict[str, Any] = details or {}


@dataclass(frozen=True)
class Candidate:
    """Файл-кандидат каталога загрузок (без чтения содержимого)."""

    path: Path
    size: int
    mtime: float

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.path.name,
            "dir": str(self.path.parent),
            "size": self.size,
            "mtime": _iso(self.mtime),
        }


def _iso(ts: float) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(ts))


def _nfc(text: str) -> str:
    return unicodedata.normalize("NFC", str(text or ""))


def downloads_dirs() -> list[Path]:
    """Каталоги загрузок: ``DT_DOWNLOADS_DIRS`` (через ``os.pathsep``) или ``~/Downloads``.

    ``~`` и ``${VAR}`` разворачиваются; порядок сохраняется, дубли снимаются.
    Несуществующие пути не отбрасываются здесь — их видит вызывающий (диагностика
    «каталог не найден» полезнее молчаливого пропуска).
    """
    raw = os.environ.get(DOWNLOADS_DIRS_ENV, "").strip() or DEFAULT_DOWNLOADS_DIR
    out: list[Path] = []
    seen: set[str] = set()
    for chunk in raw.split(os.pathsep):
        item = chunk.strip()
        if not item:
            continue
        path = Path(os.path.expanduser(os.path.expandvars(item)))
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        out.append(path)
    return out


def _is_partial(name: str) -> bool:
    lower = name.lower()
    return name.startswith(".") or lower.endswith(_PARTIAL_SUFFIXES)


def _name_matches(name: str, pattern: str) -> bool:
    """``match`` — glob ИЛИ подстрока, регистронезависимо, NFC (кириллица в именах).

    Оба режима проверяются без «угадывания» режима по метасимволам: ``*.docx``
    подстрокой не совпадёт ни с чем, «отчет» глобом не совпадёт ни с чем — режимы
    не конфликтуют, а вызывающему не нужно помнить синтаксис.
    """
    hay = _nfc(name).casefold()
    pat = _nfc(pattern).strip().casefold()
    if not pat:
        return False
    return fnmatch.fnmatchcase(hay, pat) or pat in hay


def _scan_dir(directory: Path) -> list[Candidate]:
    """Файлы каталога (без рекурсии, без частичных загрузок), новые сверху."""
    try:
        entries = list(directory.iterdir())
    except OSError:
        return []
    out: list[Candidate] = []
    for entry in entries:
        if _is_partial(entry.name):
            continue
        try:
            st = entry.lstat()
        except OSError:
            continue
        # ``lstat`` + S_ISREG: только обычные файлы, БЕЗ следования симлинкам (иначе
        # ссылка из каталога загрузок стала бы кандидатом и переехала бы вместо файла)
        if not stat_mod.S_ISREG(st.st_mode):
            continue
        out.append(Candidate(path=entry, size=st.st_size, mtime=st.st_mtime))
    return sorted(out, key=lambda c: c.mtime, reverse=True)


def _collect(match: str, max_age_minutes: int) -> tuple[list[Candidate], list[Candidate]]:
    """(кандидаты по ``match``+возрасту, последние файлы каталогов) — один скан ФС.

    ``lstat`` вместо ``stat`` осознанно: dataless-плейсхолдер iCloud не должен
    скачиваться при простом перечислении (материализуем ровно один выбранный файл).
    """
    now = time.time()
    cutoff = now - max_age_minutes * 60 if max_age_minutes > 0 else None
    matched: list[Candidate] = []
    recent: list[Candidate] = []
    for directory in downloads_dirs():
        found = _scan_dir(directory)
        recent.extend(found)
        for cand in found:
            if not _name_matches(cand.path.name, match):
                continue
            if cutoff is not None and cand.mtime < cutoff:
                continue
            matched.append(cand)
    matched.sort(key=lambda c: c.mtime, reverse=True)
    recent.sort(key=lambda c: c.mtime, reverse=True)
    return matched, recent[:_RECENT_LIMIT]


def _materialize_source(path: Path) -> None:
    """Материализовать dataless-источник iCloud или отказать (частичный файл — нет).

    Реюз паттерна :mod:`core.file_ingest.scan` (``brctl download`` + polling до
    ``DT_INGEST_MATERIALIZE_TIMEOUT``): состояние ``pending_download`` там —
    признанный класс, и переносить плейсхолдер вместо файла нельзя.
    """
    from core.file_ingest.scan import is_dataless, materialize

    if not is_dataless(path):
        return
    if materialize(path, timeout_s=ingest_materialize_timeout()):
        return
    raise PlaceDownloadError(
        f"источник не материализован из iCloud (dataless): {path.name} — "
        "файл не перенесён (частичный файл не создаётся); дождитесь загрузки и повторите",
        "not_materialized",
        {"source": str(path)},
    )


def _resolve_dest(
    dest: str, root_name: str, filename: str, vault_path: Path | None
) -> tuple[WriteTarget, str | None]:
    """``dest`` (алиас ФТ-2 либо root-относительный путь) + имя файла → цель записи.

    Семантика адресации и гарды — общий слой :func:`resolve_dest_target` (тот же, что
    у ``save_output(dest=…)``, FT-4); здесь только перевод отказа в
    :class:`PlaceDownloadError` с сохранением текста и ``code``.
    """
    try:
        return resolve_dest_target(
            dest, filename, root_name=root_name, vault_path=vault_path
        )
    except WriteTargetError as exc:
        raise PlaceDownloadError(
            str(exc), exc.code, {"dest": dest, "root_name": root_name}
        ) from exc


def _move_same_volume(src: Path, target: Path) -> bool:
    """``os.rename`` в пределах тома. ``False`` — цель на другом томе (EXDEV)."""
    try:
        os.rename(src, target)
    except OSError as exc:
        if exc.errno == errno.EXDEV:
            return False
        raise PlaceDownloadError(
            f"ошибка переноса: {exc}", "move_failed", {"source": str(src)}
        ) from exc
    return True


def _copy_atomic(src: Path, target: Path, sha256_hex: str, *, size: int) -> None:
    """Cross-volume: копия в ``.tmp`` рядом с целью + ``fsync`` + ``replace``.

    Сверка sha256 идёт по ``.tmp`` ДО подмены: не сошлось → ``.tmp`` удаляется, цель
    (и источник) целы. Под целевым именем частичный файл не наблюдаем ни в один
    момент — ``replace`` атомарен в пределах ФС.
    """
    tmp = target.with_name(target.name + _TMP_SUFFIX)
    try:
        with src.open("rb") as fsrc, tmp.open("wb") as fdst:
            while True:
                block = fsrc.read(1024 * 1024)
                if not block:
                    break
                fdst.write(block)
            fdst.flush()
            os.fsync(fdst.fileno())
        if sha256_file(tmp) != sha256_hex or tmp.stat().st_size != size:
            raise PlaceDownloadError(
                "повреждение при копировании (tmp не сошёлся) — файл не перенесён",
                "verify_failed",
                {"source": str(src)},
            )
        os.replace(tmp, target)
    except PlaceDownloadError:
        tmp.unlink(missing_ok=True)
        raise
    except OSError as exc:
        tmp.unlink(missing_ok=True)
        raise PlaceDownloadError(
            f"ошибка копирования: {exc}", "move_failed", {"source": str(src)}
        ) from exc


VIA_MATCH = "match"
VIA_PATH = "source_path"


def _source_by_path(raw: str) -> Path:
    """Файл по ЯВНОМУ абсолютному пути (FILE-LOCAL-1) — с гардами, но без поиска.

    Фейлкейс 17.08: файл был готов и лежал на диске, а доставить его «по пути» было
    нечем — ``place_download`` умел только искать в ``DT_DOWNLOADS_DIRS`` (glob, ≤60
    мин), и агент ушёл в base64 через мост. Здесь путь принимается как есть, и
    ``max_age_minutes`` НЕ применяется: явный путь — намеренный выбор человека или
    агента, а не догадка по шаблону («файл старше часа» тут не дефект).

    Требуем АБСОЛЮТНЫЙ путь: относительный резолвился бы от CWD процесса-сервера,
    то есть от каталога, о котором вызывающий ничего не знает (класс дефекта
    CONTRACT-1 Д4 — там же на этом спотыкался ``attribute_note``). ``~`` и
    ``${VAR}`` разворачиваем: их пишет человек, и это тот же явный путь.
    """
    text = _nfc(raw).strip()
    if not text:
        raise PlaceDownloadError("пустой source_path", "bad_source_path")
    path = Path(os.path.expanduser(os.path.expandvars(text)))
    if not path.is_absolute():
        raise PlaceDownloadError(
            f"source_path должен быть абсолютным путём: {text!r} — относительный "
            "разрешался бы от рабочего каталога сервера, а не от вашего",
            "bad_source_path",
            {"source_path": text},
        )
    if path.is_dir():
        raise PlaceDownloadError(
            f"source_path — каталог, а не файл: {path} (рекурсивная доставка каталогов "
            "не поддерживается — укажите файл)",
            "source_is_dir",
            {"source_path": str(path)},
        )
    if not path.exists():
        raise PlaceDownloadError(
            f"файла нет: {path} — проверьте путь (файл из песочницы чата на диске мака "
            "не существует: документ ИЗ ТЕКСТА доставляет save_output(dest, format), "
            "истинный бинарь — store_file/chunked)",
            "source_not_found",
            {"source_path": str(path)},
        )
    if not path.is_file():
        raise PlaceDownloadError(
            f"source_path не обычный файл: {path}", "bad_source_path",
            {"source_path": str(path)},
        )
    if is_nda(path):
        # NDA-2: маркер на источнике — та же граница, что на цели. Перенос под чистый
        # корень «отмыл» бы путь: файл лёг бы туда, где барьер его больше не узнаёт.
        raise PlaceDownloadError(
            f"источник под NDA-барьером: {path.name} — доставка запрещена "
            "(перенос снял бы маркер пути, и файл попал бы в индекс)",
            "nda",
            {"source_path": str(path)},
        )
    return path


def _pick_source(
    match: str, source_path: str | None, max_age_minutes: int
) -> tuple[Path, str]:
    """Источник доставки: явный путь ЛИБО единственный кандидат каталогов загрузок.

    Взаимоисключимы by design: два адреса одного файла в одном вызове — это
    неоднозначность, а цена ошибочной записи в клиентскую папку выше цены повторного
    вызова (то же правило, что у ``>1 кандидата`` ниже).
    """
    has_match = bool(str(match or "").strip())
    has_path = bool(str(source_path or "").strip())
    if has_match and has_path:
        raise PlaceDownloadError(
            "match и source_path взаимоисключимы: либо поиск в каталогах загрузок, "
            "либо явный путь к файлу — выберите одно",
            "both_sources",
            {"match": match, "source_path": source_path},
        )
    if has_path:
        return _source_by_path(str(source_path)), VIA_PATH
    if source_path is not None and not has_match:
        # Параметр передан, но пустой: точный код лучше общего «ничего не задано» —
        # вызывающий уже выбрал ветку, ошибка в значении.
        return _source_by_path(str(source_path)), VIA_PATH
    if not has_match:
        raise PlaceDownloadError(
            "не задан ни match (поиск в каталогах загрузок), ни source_path "
            "(явный путь к файлу на диске)",
            "bad_match",
        )

    matched, recent = _collect(match, max_age_minutes)
    dirs = [str(d) for d in downloads_dirs()]
    if not matched:
        age = f"возраст ≤ {max_age_minutes} мин" if max_age_minutes > 0 else "без фильтра возраста"
        raise PlaceDownloadError(
            f"не найдено файлов по шаблону {match!r} "
            f"(каталоги: {', '.join(dirs)}; {age})",
            "no_candidates",
            {"match": match, "recent": [c.to_dict() for c in recent], "dirs": dirs},
        )
    if len(matched) > 1:
        raise PlaceDownloadError(
            f"шаблону {match!r} соответствует файлов: {len(matched)} — уточните шаблон "
            "(автовыбор самого свежего запрещён: ошибочная запись в клиентскую папку "
            "дороже повторного вызова)",
            "ambiguous",
            {"match": match, "candidates": [c.to_dict() for c in matched]},
        )
    if is_nda(matched[0].path):
        raise PlaceDownloadError(
            f"источник под NDA-барьером: {matched[0].path.name} — доставка запрещена",
            "nda",
            {"source": str(matched[0].path)},
        )
    return matched[0].path, VIA_MATCH


def place_download(
    match: str = "",
    dest: str = "",
    *,
    source_path: str | None = None,
    root_name: str = DEFAULT_ROOT_NAME,
    new_name: str | None = None,
    overwrite: bool = False,
    max_age_minutes: int = DEFAULT_MAX_AGE_MINUTES,
    keep_source: bool = False,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Доставить один локальный файл в папку ``dest``: по ``match`` ИЛИ ``source_path``.

    См. док модуля. Возврат ``{ok, path, abs_path, size, sha256, matched_name, moved,
    copied, existed, overwritten, alias, root_name, source, via}`` (``path`` —
    относительный корню, posix; ``via`` — ``match``/``source_path``, откуда взят
    источник). Любой отказ — :class:`PlaceDownloadError` (``code``/``details``).
    """
    from core.operational.pult import record_action

    # --- 1. источник: явный путь ЛИБО поиск в каталогах загрузок --------------
    source, via = _pick_source(match, source_path, max_age_minutes)

    # --- 2. имя файла в цели + гарды записи (общий слой со store_file) --------
    filename = _nfc(new_name).strip() if new_name else source.name
    if not filename or filename in {".", ".."} or "/" in filename or "\\" in filename:
        raise PlaceDownloadError(
            f"new_name должен быть именем файла без путей: {new_name!r}", "bad_new_name"
        )
    target, alias_name = _resolve_dest(dest, root_name, filename, vault_path)

    # --- 3. iCloud dataless: материализовать или отказать ---------------------
    _materialize_source(source)

    # --- 4. sha256 источника + диспозиция цели -------------------------------
    sha = sha256_file(source)
    size = source.stat().st_size
    try:
        disposition = existing_disposition(target.path, sha, label=target.rel_path)
    except WriteTargetError as exc:
        raise PlaceDownloadError(str(exc), exc.code, {"path": target.rel_path}) from exc
    if disposition == IDENTICAL:
        # Идемпотентность: те же байты уже в папке — не переписываем (mtime цел) и
        # НЕ удаляем источник (байты не должны исчезать там, где записи не было).
        record_action(
            "place_download",
            {"source": str(source), "via": via, "root": target.root_name,
             "rel_path": target.rel_path, "size": size, "sha256": sha[:12]},
            "existed",
        )
        return {
            "ok": True, "path": target.rel_path, "abs_path": str(target.path),
            "size": size, "sha256": sha,
            "matched_name": source.name, "moved": False, "copied": False,
            "existed": True, "overwritten": False, "alias": alias_name,
            "root_name": target.root_name, "source": str(source), "via": via,
        }
    overwritten = disposition != ABSENT
    if overwritten and not overwrite:
        raise PlaceDownloadError(
            f"файл существует и отличается: {target.rel_path} — нужен overwrite=True",
            "exists_differs",
            {"path": target.rel_path, "root_name": target.root_name},
        )

    # --- 5. атомарный перенос: rename в пределах тома, иначе copy+fsync+replace -
    target.path.parent.mkdir(parents=True, exist_ok=True)
    copied = keep_source or not _move_same_volume(source, target.path)
    if copied:
        # keep_source — копия по требованию; иначе это cross-volume ветка (EXDEV),
        # где источник снимается после успешной подмены цели.
        _copy_atomic(source, target.path, sha, size=size)
        if not keep_source:
            source.unlink(missing_ok=True)
    # rename байты не перезаписывает (тот же inode), поэтому пересверка sha после
    # него ничего не проверяет; в copy-ветке сверка уже прошла по .tmp до подмены.

    record_action(
        "place_download",
        {"source": str(source), "via": via, "root": target.root_name,
         "rel_path": target.rel_path, "size": size, "sha256": sha[:12],
         "mode": "copied" if copied else "moved", "overwritten": overwritten},
        "overwritten" if overwritten else "placed",
    )
    return {
        # ``abs_path`` — CONTRACT-1 ФП-7 (Д12): форма, которую принимает ``lift_source``.
        "ok": True, "path": target.rel_path, "abs_path": str(target.path),
        "size": size, "sha256": sha,
        "matched_name": source.name, "moved": not copied, "copied": copied,
        "existed": overwritten, "overwritten": overwritten, "alias": alias_name,
        "root_name": target.root_name, "source": str(source), "via": via,
    }
