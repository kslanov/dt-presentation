"""ADMIN-1 v2A — core-логика пульта (sync-здоровье/аудит/активность).

Всё, что нужно MCP-инструментам ``pult_*``, живёт здесь — ``mcp-server/server.py`` остаётся
тонкой обёрткой (инвариант ``core/`` ⊥ mcp/cli).

RETIRE-WRITE-1 (решение К. 2026-10-19): контур записи в Timetta выведен из эксплуатации —
очередь подтверждений (``queue_pending``/``decide``), лестница автономии и [pult]-строки
дайджеста ушли в архивную ветку ``archive/timetta-write``. Здесь остаётся:

* :func:`sync_status` / :func:`log_tail` — разбор хвоста ``dt-sync.log``
  (строки уже отскраблены при записи) + running-статус по flock-локу;
* :func:`start_sync` — fire-and-forget detached-запуск ``dt_sync`` (только
  fast|index|full; дубль гасится существующим flock внутри dt_sync);
* :func:`record_action` / :func:`read_actions` — аудит привилегированных вызовов в
  ``.derived/logs/pult-actions.log`` (ts, tool, аргументы БЕЗ содержимого, исход);
* :func:`activity` — прогресс-маяки долгих операций.

Инвариант: ``core/`` не импортирует mcp/cli; среда инжектируется вызывающим — здесь нет ни
сети, ни LLM. Запуск dt_sync — spawn отдельного процесса по пути, не импорт CLI-модуля.
"""

from __future__ import annotations

import contextlib
import fcntl
import json
import os
import re
import subprocess
from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import (
    ENGINE_ROOT,
    logs_path,
    sync_lock_path,
    sync_log_path,
)
from core.operational import synclog

__all__ = [
    "SYNC_MODES",
    "SYNC_STEPS",
    "sync_steps",
    "actions_log_path",
    "record_action",
    "Action",
    "parse_action_line",
    "clean_actions_log",
    "read_actions",
    "sync_status",
    "log_tail",
    "start_sync",
    "activity",
]

# Единственные режимы, которые пульт может запустить (гард ТЗ: никаких
# произвольных аргументов в detached-процесс).
SYNC_MODES = ("fast", "index", "full")

# RETIRE-WRITE-1 п.7: шаги режимов для точечного запуска (``pult_run_sync(mode, steps=[…])``).
# PERSONAL-3: шаги ПРОИЗВОДНЫЕ от манифеста роли - входы из реестра адаптеров (по ``roles``), прочие
# из ``core.surface.manifest.STATIC_STEPS``; своих списков здесь нет. ``SYNC_STEPS`` - шаги РАБОЧЕЙ
# роли (как были; дрейф с ``cli/dt_sync.MODES`` стережет ``tests/test_sync_steps.py``), для роли
# процесса - :func:`sync_steps`.
class _SyncSteps(Mapping[str, tuple[str, ...]]):
    """``{fast, index, full}`` шагов РАБОЧЕЙ роли, считаемые при обращении: DEV-3-CORE - набор шагов
    зависит от коннекторов (``DT_CONNECTORS`` читается после ``load_env``), снимок на импорте
    устарел бы."""

    def _now(self) -> dict[str, tuple[str, ...]]:
        from core.surface import manifest

        return manifest.sync_steps("work")

    def __getitem__(self, key: str) -> tuple[str, ...]:
        return self._now()[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._now())

    def __len__(self) -> int:
        return len(self._now())


SYNC_STEPS: Mapping[str, tuple[str, ...]] = _SyncSteps()


def sync_steps(mode: str) -> tuple[str, ...]:
    """Шаги режима ДЛЯ ЭТОГО процесса: по манифесту роли (рабочий - прежние ``SYNC_STEPS``)."""
    from core.surface import manifest

    return manifest.sync_steps()[mode]


# Максимум строк, отдаваемых log_tail за раз (лог ротируется на ~1MB, но
# отдавать мегабайты в MCP-ответ незачем).
_TAIL_CAP = 1000

# SYNC-OFFLINE-1: running-маяк, не обновлявшийся дольше этого, считаем зависшим —
# показываем «завис?» вместо ETA из замороженного прогресса (инцидент: «осталось
# ~3с» при 36ч висящем прогоне). Маяк троттлится на ~секунды, поэтому 15м —
# заведомо аномалия, а не нормальная пауза между апдейтами.
STALE_BEACON_MIN = 15


def _now_iso(now: str | None) -> str:
    return now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def actions_log_path() -> Path:
    """Аудит привилегированных pult-вызовов: ``.derived/logs/pult-actions.log``."""
    return logs_path() / "pult-actions.log"


def record_action(
    tool: str,
    params: dict[str, Any],
    outcome: str,
    *,
    now: str | None = None,
    path: Path | None = None,
) -> None:
    """Одна аудит-строка: ``ts tool k=v … outcome=…`` — best-effort, не бросает.

    ``params`` — только идентификаторы/флаги (proposal_id, decision, kind, mode);
    содержимое (тексты, комментарии, названия) сюда не передаётся by design.
    """
    try:
        target = path or actions_log_path()
        target.parent.mkdir(parents=True, exist_ok=True)
        # WEBPULT-ACCESS-1 п.3: вызов из веб-пульта несет surface/auth/хвост токена/peer (кто).
        from core.host import current_host, request_fields

        web = request_fields()
        if web:
            params = {**params, "surface": current_host()["surface"], **web}
        # MODEL-1 п.B: каждая аудит-строка MCP-хоста несёт ``host=`` (два хоста на одном vault -
        # кто сделал запись). Один писатель для всех WRITE_TOOLS: инструмент не обязан помнить.
        # CLI/тесты (surface cli) строку не меняют; явный ``host`` в params не дублируем.
        if "host" not in params:
            who = current_host()
            if who["surface"] != "cli":
                params = {**params, "host": who["name"]}
        args = " ".join(f"{k}={v}" for k, v in params.items())
        line = f"{_now_iso(now)} {tool} {args} outcome={outcome}".rstrip()
        with target.open("a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except Exception:  # noqa: BLE001, S110 — аудит не ломает привилегированную операцию
        pass


@dataclass(frozen=True)
class Action:
    """Одна разобранная аудит-строка: инструмент, время, аргументы, исход.

    Обратная сторона :func:`record_action`: журнал пишется как «что сделал
    инструмент и когда», и это единственная телеметрия с ВРЕМЕНЕМ на уровне вызова
    (реестр источников времени лифта не хранит вовсе — там ``last_lift`` это путь,
    а ``mtime`` — дата файла). Читатель живёт рядом с писателем, чтобы формат
    строки был описан в одном месте.
    """

    tool: str
    at: datetime
    args: dict[str, str]
    outcome: str


_ACTION_TS_FMT = "%Y-%m-%dT%H:%M:%SZ"


def parse_action_line(line: str) -> Action | None:
    """Одна строка журнала → :class:`Action`; ``None`` - строка ЯВНО отброшена.

    Отбрасываются: строка короче ``ts инструмент аргументы`` и строка с невалидным ``ts`` (например
    ``T pult_x …`` из тестовых записей июля, SURFACE-HYGIENE-1): время - единственная причина
    держать строку в журнале, без него она не попадает ни в провенанс, ни в окно."""
    parts = line.strip().split(" ", 2)
    if len(parts) < 3:
        return None
    try:
        at = datetime.strptime(parts[0], _ACTION_TS_FMT).replace(tzinfo=UTC)
    except (ValueError, TypeError):
        return None
    args = {k: v.strip() for k, v in _ACTION_ARG_RE.findall(parts[2])}
    outcome = args.pop("outcome", "")
    return Action(tool=parts[1], at=at, args=args, outcome=outcome)


def clean_actions_log(path: Path | None = None, *, apply: bool = False) -> dict[str, Any]:
    """Разовая чистка журнала от строк с невалидным ``ts`` (``cli/_oneoff/dt_clean_actions_log``).

    ``{lines, kept, dropped, dropped_lines, backup}``. Без ``apply`` - только счет. С ``apply``:
    СНАЧАЛА бэкап ``<журнал>.bak-<UTC-метка>``, затем атомарная перезапись без отброшенных
    строк. Пустые строки сохраняются как есть (это не мусор журнала)."""
    target = path or actions_log_path()
    out: dict[str, Any] = {"lines": 0, "kept": 0, "dropped": 0, "dropped_lines": [], "backup": None}
    if not target.is_file():
        return out
    raw = target.read_text(encoding="utf-8", errors="replace").splitlines()
    keep: list[str] = []
    for line in raw:
        if line.strip() and parse_action_line(line) is None:
            out["dropped_lines"].append(line[:80])
        else:
            keep.append(line)
    out.update(lines=len(raw), kept=len(keep), dropped=len(raw) - len(keep))
    if apply and out["dropped"]:
        stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        backup = target.with_name(f"{target.name}.bak-{stamp}")
        backup.write_bytes(target.read_bytes())
        tmp = target.with_suffix(target.suffix + ".tmp")
        tmp.write_text("\n".join(keep) + ("\n" if keep else ""), encoding="utf-8")
        tmp.replace(target)
        out["backup"] = str(backup)
    return out


# Значение аргумента может содержать пробелы (кириллические пути «Подводные
# технологии/КП.docx»), поэтому берём его ДО следующего ``ключ=`` — не по split.
_ACTION_ARG_RE = re.compile(r"(\w+)=(.*?)(?=\s+\w+=|$)")
# Потолок разбора: лог ротируется, а окно провенанса — часы, не месяцы.
_ACTION_TAIL_LINES = 5000


def read_actions(
    *,
    tools: tuple[str, ...] | frozenset[str],
    since: datetime,
    until: datetime | None = None,
    outcomes: tuple[str, ...] | None = None,
    path: Path | None = None,
) -> list[Action]:
    """Аудит-строки перечисленных ``tools`` за окно ``[since, until]`` — старые сверху.

    Разбирается хвост журнала (:data:`_ACTION_TAIL_LINES` строк); строки вне окна
    пропускаются, а не обрывают скан: файл всё равно читается целиком, поэтому ранний
    выход не экономил бы ввод-вывод, зато вносил бы допущение «журнал строго
    хронологичен» — а перевод часов или дописанная задним числом строка молча
    урезали бы провенанс. Битые строки пропускаются: журнал — телеметрия, а не
    источник истины, и один сбойный байт не должен ронять чтение.
    """
    target = path or actions_log_path()
    if not target.is_file():
        return []
    try:
        lines = target.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    wanted = set(tools)
    out: list[Action] = []
    for line in lines[-_ACTION_TAIL_LINES:]:  # вперёд: у равных секунд порядок дописи
        action = parse_action_line(line)  # невалидный ts - строка отброшена явно (None)
        if action is None:
            continue
        if action.at < since or action.tool not in wanted:
            continue
        if until is not None and action.at > until:
            continue
        if outcomes is not None and action.outcome not in outcomes:
            continue
        out.append(action)
    out.sort(key=lambda a: a.at)  # хронологический порядок: как происходило
    return out


# --------------------------------------------------------------------------- #
# Здоровье sync — разбор хвоста лога + flock-статус + запуск
# --------------------------------------------------------------------------- #
# Финальная строка прогона dt_sync (см. cli/dt_sync.py::run):
#   2026-07-03 08:00:01,123 INFO === dt-sync fast: done ok ===
#   2026-07-03 20:00:09,456 WARNING === dt-sync full: done WITH ERRORS (steps: refresh) ===
# Контракт формата (в т.ч. опциональный CODE-5-1 "[corr-id] logger: "-сегмент)
# живёт в core.operational.synclog — один источник правды (FRESH-PARSE-1).
_DONE_RE = synclog.DONE_RE


def _tail_lines(log_path: Path, count: int) -> list[str]:
    """Последние ``count`` строк лога как текст (лог ротируется на ~1MB).

    Отсутствие/нечитаемость лога фиксируется в :func:`_log_present` — «лога нет» и
    «лог пуст» больше не одно и то же (CONTRACT-2 С16).
    """
    if not log_path.is_file():
        return []
    try:
        text = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    return text.splitlines()[-count:]


def _log_present(log_path: Path) -> bool:
    """Существует ли и читается ли лог (для честного ``log_present``)."""
    try:
        return log_path.is_file() and os.access(log_path, os.R_OK)
    except OSError:
        return False


def _sync_running(lock_path: Path) -> bool:
    """True, если flock-лок dt-sync сейчас удерживается другим процессом."""
    if not lock_path.exists():
        return False
    try:
        # «r», не «w»: lock-файл несёт heartbeat-информацию держателя ({pid, mode, step}) —
        # усечение при каждом опросе стирало бы её (flock на read-only дескрипторе работает).
        fh = open(lock_path)
    except OSError:
        return False
    try:
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return True
        with contextlib.suppress(Exception):
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        return False
    finally:
        fh.close()


def sync_status(
    *, log_path: Path | None = None, lock_path: Path | None = None
) -> dict[str, Any]:
    """Здоровье оперативного контура для админ-вкладки пульта.

    Разбирает хвост ``dt-sync.log`` (последний завершившийся прогон per режим:
    ts, ok, failed_steps) и пробует flock-лок — удерживается ⇒ прогон идёт
    прямо сейчас. Только чтение; сеть не нужна.
    """
    log_path = log_path or sync_log_path()
    lock_path = lock_path or sync_lock_path()

    last: dict[str, dict[str, Any] | None] = {"fast": None, "index": None, "full": None}
    for line in _tail_lines(log_path, _TAIL_CAP):
        m = _DONE_RE.match(line)
        if not m or m.group("mode") not in last:
            continue
        steps_raw = m.group("steps")
        last[m.group("mode")] = {
            "ts": m.group("ts"),
            "ok": steps_raw is None,
            "failed_steps": (
                [s.strip() for s in steps_raw.split(",") if s.strip()]
                if steps_raw
                else []
            ),
        }
    from core import runlock

    running_fast = _sync_running(lock_path)
    running_index = _sync_running(runlock.index_sync_lock(lock_path))
    return {
        "last_fast": last["fast"],
        "last_index": last["index"],
        "last_full": last["full"],
        # WAVE0-HYGIENE п.4: у fast и index свои lock'и → «идёт» — любой из них.
        "running": running_fast or running_index,
        "running_fast": running_fast,
        "running_index": running_index,
        "log_path": str(log_path),
        # CONTRACT-2 С16: сплошные null означают либо «прогонов не было», либо
        # «лога нет вовсе» — раньше это было неразличимо.
        "log_present": _log_present(log_path),
    }


def log_tail(
    lines: int = 80,
    errors_only: bool = False,
    *,
    log_path: Path | None = None,
) -> dict[str, Any]:
    """Хвост ``dt-sync.log`` для пульта — только текст, только последние строки.

    Строки уже отскраблены при записи (dt_sync подчищает токены) — дополнительная
    фильтрация не нужна; сырые байты не отдаются (decode errors="replace").
    ``errors_only`` оставляет ERROR/WARNING (упавшие шаги и итог «WITH ERRORS»).
    """
    count = max(1, min(int(lines), _TAIL_CAP))
    log_path = log_path or sync_log_path()
    rows = _tail_lines(log_path, _TAIL_CAP)
    if errors_only:
        rows = [r for r in rows if " ERROR " in r or " WARNING " in r]
    return {
        "path": str(log_path),
        "lines": rows[-count:],
        "log_present": _log_present(log_path),  # CONTRACT-2 С16
    }


# --------------------------------------------------------------------------- #
# Активные процессы — маяки ACT-1 + живость pid + load/swap
# --------------------------------------------------------------------------- #
def _pid_alive(pid: Any) -> bool:
    """kill-0-проверка: жив ли процесс (PermissionError = жив, но чужой)."""
    try:
        pid_int = int(pid)
    except (TypeError, ValueError):
        return False
    if pid_int <= 0:
        return False
    try:
        os.kill(pid_int, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _parse_iso_utc(value: Any) -> datetime | None:
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


# vm.swapusage: "total = 2048.00M  used = 1234.56M  free = 813.44M  (encrypted)"
_SWAP_RE = re.compile(r"(total|used|free)\s*=\s*([\d.]+)([KMG])")
_SWAP_UNIT_MB = {"K": 1 / 1024, "M": 1.0, "G": 1024.0}


def _swap_usage() -> dict[str, float] | None:
    """Swap из ``sysctl vm.swapusage`` в MB; None при любом сбое (не macOS и т.п.)."""
    try:
        out = subprocess.run(
            ["/usr/sbin/sysctl", "-n", "vm.swapusage"],
            capture_output=True, text=True, timeout=2, check=False,
        )
        found = {
            key: round(float(num) * _SWAP_UNIT_MB[unit], 2)
            for key, num, unit in _SWAP_RE.findall(out.stdout or "")
        }
        if {"total", "used", "free"} <= set(found):
            return {
                "total_mb": found["total"],
                "used_mb": found["used"],
                "free_mb": found["free"],
            }
        return None
    except Exception:  # noqa: BLE001 — плитка без чисел лучше упавшего инструмента
        return None


def _beacon_entry(row: dict[str, Any], *, now: datetime) -> dict[str, Any]:
    """Один маяк → строка активности: статус по finished-флагу и живости pid."""
    if row.get("finished") is True:
        status = "finished"
    elif _pid_alive(row.get("pid")):
        status = "running"
    else:
        # Маяк без finished и с мёртвым pid: процесс прерван (kill/sleep/crash).
        # index/link/mail resumable — следующий запуск продолжит от чекпойнта.
        status = "interrupted"
    started = _parse_iso_utc(row.get("started"))
    uptime_s = (
        max(0, int((now - started).total_seconds()))
        if status == "running" and started is not None
        else None
    )
    # SYNC-OFFLINE-1: running, но маяк давно не обновлялся → прогон завис. Не
    # показываем ETA из замороженного прогресса (вводит в заблуждение) — фронт
    # рисует «завис? маяк не обновлялся Xм». Свежий running — как раньше.
    updated = _parse_iso_utc(row.get("updated"))
    stale = False
    stale_min: int | None = None
    if status == "running" and updated is not None:
        age_min = int((now - updated).total_seconds() // 60)
        if age_min >= STALE_BEACON_MIN:
            stale = True
            stale_min = max(0, age_min)
    eta_s = None if stale else row.get("eta_s")
    return {
        "proc": row.get("proc"),
        "status": status,
        "phase": row.get("phase"),
        "current": row.get("current"),
        "total": row.get("total"),
        "eta_s": eta_s,
        "extra": row.get("extra") or {},
        "pid": row.get("pid"),
        "started": row.get("started"),
        "updated": row.get("updated"),
        "uptime_s": uptime_s,
        "stale": stale,
        "stale_min": stale_min,
        "summary": row.get("summary"),
    }


def activity(
    *, status_dir: Path | None = None, now: datetime | None = None
) -> dict[str, Any]:
    """Что сейчас работает (ACT-1) — маяки процессов + load/swap. Read-only.

    По каждому маяку из ``.derived/status/``: ``running`` (pid жив, kill-0) /
    ``finished`` / ``interrupted`` (pid мёртв, finished≠true — прерван,
    продолжится от чекпойнта) + прогресс/eta/фаза/аптайм. ``system`` — числа
    для плитки «ноут раскочегарен»: load average, ядра, swap (null при сбое
    sysctl). Сеть не нужна; битые маяки молча пропускаются.
    """
    from core.config import status_dir as _default_status_dir

    directory = status_dir or _default_status_dir()
    now_dt = now or datetime.now(UTC)

    processes: list[dict[str, Any]] = []
    skipped: list[str] = []
    if directory.is_dir():
        for path in sorted(directory.glob("*.json")):
            try:
                row = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                # CONTRACT-2 С9: битый маяк молча пропадал — вместе с процессом,
                # который он описывает. Витрина показывала «ничего не работает».
                skipped.append(path.name)
                continue
            if isinstance(row, dict):
                processes.append(_beacon_entry(row, now=now_dt))
            else:
                skipped.append(path.name)

    try:
        load_1m: float | None = round(os.getloadavg()[0], 2)
    except OSError:
        load_1m = None
    out: dict[str, Any] = {
        "processes": processes,
        # CONTRACT-2 С9: сколько маяков не прочиталось (0 на здоровом пути).
        "skipped_beacons": len(skipped),
        "system": {
            "load_avg_1m": load_1m,
            "cpu_count": os.cpu_count(),
            "swap": _swap_usage(),
        },
    }
    if skipped:
        from core.contract import CODE_PARTIAL, add_warning

        add_warning(
            out, CODE_PARTIAL,
            "маяки не прочитались: " + ", ".join(sorted(skipped)[:5])
            + " — процессы за ними в витрине НЕ видны (это не «ничего не работает»)",
            skipped=len(skipped),
        )
    return out


def _mode_locks(mode: str) -> list[Path]:
    """Lock'и, которые берёт режим: fast → свой, index → свой, full → оба (WAVE0 п.4)."""
    from core import runlock

    fast = sync_lock_path()
    index = runlock.index_sync_lock(fast)
    return {"fast": [fast], "index": [index], "full": [fast, index]}[mode]


def running_sync(mode: str) -> dict[str, Any] | None:
    """Идущий прогон, мешающий запуску ``mode``: ``{mode, step, pid, started, lock}`` или ``None``.

    Имя прогона и шаг — из heartbeat-информации в самом lock-файле (:mod:`core.runlock`):
    честный ответ «занято: index · link_auto», а не «погаснет на локе»."""
    from core import runlock

    for lock in _mode_locks(mode):
        if _sync_running(lock):
            info = runlock.read_info(lock)
            return {
                "mode": info.get("mode") or ("index" if lock.stem.endswith("-index") else "fast"),
                "step": info.get("step") or None,
                "pid": info.get("pid"),
                "started": info.get("started"),
                "lock": lock.name,
            }
    return None


def start_sync(
    mode: str,
    *,
    steps: list[str] | tuple[str, ...] | None = None,
    engine_root: Path | None = None,
    popen: Any | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Кнопка «sync сейчас» — fire-and-forget detached-запуск ``dt_sync``.

    Режимы fast|index|full (никаких произвольных аргументов — гард ТЗ). ``steps`` —
    подмножество шагов режима (RETIRE-WRITE-1 п.7: «кликаю почту — запускается всё»):
    имена проверяются по :data:`SYNC_STEPS`, неизвестное → отказ с конвертом ``bad_steps``
    (ничего не запущено). Процесс отвязывается (``start_new_session``; stdio → devnull) и НЕ
    ожидается: MCP-вызов возвращается сразу.

    **Занято → честный ответ, без запуска.** Режим уже идёт (flock-лок держится) →
    ``{started: False, already_running: True, running: {mode, step, pid, started}}`` +
    конверт ``skipped`` с именем идущего прогона и ШАГА; дубль-процесс не плодим (раньше он
    стартовал и тихо гас на локе). ``popen`` инжектируется тестами.
    """
    if mode not in SYNC_MODES:
        raise ValueError(
            f"unsupported mode {mode!r}; use {' | '.join(SYNC_MODES)}"
        )
    chosen = [str(x).strip() for x in (steps or []) if str(x).strip()]
    allowed = sync_steps(mode)
    unknown = [x for x in chosen if x not in allowed]
    if unknown:
        from core.contract import CODE_BAD_STEPS, add_warning

        refusal: dict[str, Any] = {"started": False, "mode": mode, "pid": None, "steps": chosen}
        record_action(
            "pult_run_sync", {"mode": mode, "steps": ",".join(chosen)}, "bad_steps", now=now
        )
        return add_warning(
            refusal, CODE_BAD_STEPS,
            f"неизвестные шаги режима {mode}: {', '.join(unknown)} — допустимо: "
            f"{', '.join(allowed)}; ничего не запущено",
            mode=mode, unknown=unknown,
        )
    root = Path(engine_root) if engine_root is not None else ENGINE_ROOT
    busy = running_sync(mode)
    audit: dict[str, Any] = {"mode": mode, "already_running": busy is not None}
    if chosen:
        audit["steps"] = ",".join(chosen)
    if busy is not None:
        from core.contract import CODE_SKIPPED, add_warning

        record_action("pult_run_sync", audit, "busy", now=now)
        out_busy: dict[str, Any] = {
            "started": False, "mode": mode, "pid": None, "already_running": True,
            "running": busy, "steps": chosen,
        }
        what = f"{busy['mode']}" + (f" · шаг {busy['step']}" if busy.get("step") else "")
        return add_warning(
            out_busy, CODE_SKIPPED,
            f"прогон dt-sync уже идёт ({what}) — новый НЕ запущен; дождись текущего",
            mode=mode, running=busy["mode"], step=busy.get("step"),
        )
    cmd = [
        "uv", "run", "--extra", "operational", "python", "cli/dt_sync.py", mode,
    ]
    if chosen:
        cmd += ["--steps", ",".join(chosen)]
    opener = popen or subprocess.Popen
    proc = opener(
        cmd,
        cwd=str(root),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    record_action("pult_run_sync", audit, "started", now=now)
    return {
        "started": True, "mode": mode, "pid": getattr(proc, "pid", None),
        "already_running": False, "steps": chosen,
    }
