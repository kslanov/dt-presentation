"""RECONCILE-1 — общий контур сверки производных persist-очередей с источником.

Класс багов (анализ 2026-07-10): производная **persist-очередь**, построенная из
внешнего источника, не сверяется, когда элемент разрешается в источнике
(completed / deleted / answered / исчез) → элемент вечно висит в DT. Live-запросы
и пересчёты-из-зеркала этим не болеют (они переспрашивают источник каждый раз);
уязвимы именно очереди, которые что-то ЗАПОМНИЛИ.

Этот модуль — тонкий контур (не тяжёлый плагин-реестр): протокол
:class:`Reconcilable` (один объект = одна очередь) + движок :func:`reconcile_all`,
который держит **общий гард от ложного снятия ОДИН раз**: сверка выполняется
ТОЛЬКО при успешном непустом чтении источника; ``read_source() -> None`` (пусто
или ошибка) → очередь пропускается с WARNING, ``resolve`` НЕ зовётся (транзиентная
ошибка ≠ «в источнике всё исчезло, снести очередь»).

Инвариант: ``core/`` ⊥ MCP/CLI; Path B — здесь нет ни сети, ни LLM (сеть/чтение
источника инкапсулированы в адаптерах, которым клиент/vault инжектируются извне).
Адаптеры (captures, link-proposals) живут рядом со своими данными
(``core.operational.ticktick.capture``, ``core.linking.reconcile_links``) и лишь
реализуют этот протокол.

Принцип §9 №13: любая производная persist-очередь ОБЯЗАНА реализовать
``Reconcilable`` и сверяться на sync — с этим гардом.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable
from typing import Any, Protocol, runtime_checkable

__all__ = ["Reconcilable", "reconcile_all"]

logger = logging.getLogger(__name__)


@runtime_checkable
class Reconcilable(Protocol):
    """Одна производная persist-очередь, умеющая сверяться с источником.

    Контракт (реализуют адаптеры):

    * ``name`` — стабильное имя для логов/счётчиков (``"captures"`` / ``"link_proposals"``);
    * ``read_source()`` — прочитать актуальное состояние источника (live-набор
      taskId, множество note-id vault, …). **Возврат ``None`` = сигнал «не читать,
      пропустить»**: пустой ответ из-за 401/429/сетевого сбоя или ошибки обхода —
      это НЕ «источник пуст», а «читать нельзя»; движок такой прогон пропускает
      (гард от ложного снятия). Адаптер сам решает, что считать «нельзя читать»
      (обычно: исключение или пустой набор), и возвращает ``None``;
    * ``stale_items(source)`` — persist-элементы, которых источник больше НЕ
      оправдывает (разрешены/исчезли: completed/deleted/answered/отсутствуют);
    * ``resolve(item)`` — разрешить элемент **не теряя данные**: статус
      (``resolved_external`` / ``stale``) и/или архив, НИКОГДА не hard-delete.
    """

    name: str

    def read_source(self) -> Any | None: ...

    def stale_items(self, source: Any) -> list[Any]: ...

    def resolve(self, item: Any) -> None: ...


def reconcile_all(
    reconcilables: Iterable[Reconcilable], *, now: str | None = None
) -> dict[str, int]:
    """Свести каждую очередь с её источником; вернуть ``{name: resolved_n}``.

    По каждому ``Reconcilable``:

    1. ``read_source()`` — **общий гард**: если вернулось ``None`` (пусто/ошибка)
       или чтение бросило исключение → очередь пропускается с WARNING, ``resolve``
       НЕ вызывается (счётчик 0). Так транзиентный сбой источника не обнуляет
       очередь — это единственное место, где живёт защита от ложного снятия.
    2. Иначе — ``stale_items(source)`` → ``resolve`` по каждому; считаем снятые.

    ``now`` — метка прогона для аудита/лога (адаптеры получают свою метку времени
    при конструировании). Движок сам ничего во внешние системы не пишет и не
    вызывает LLM; вся работа — в инжектированных адаптерах.
    """
    counts: dict[str, int] = {}
    for rec in reconcilables:
        name = getattr(rec, "name", rec.__class__.__name__)
        try:
            source = rec.read_source()
        except Exception as exc:  # noqa: BLE001 — гард: сбой чтения ≠ «всё исчезло»
            logger.warning(
                "reconcile %s: чтение источника упало (%s) — пропуск (гард)",
                name,
                type(exc).__name__,
            )
            counts[name] = 0
            continue

        if source is None:
            logger.warning(
                "reconcile %s: источник недоступен/пуст — пропуск (гард от ложного снятия)",
                name,
            )
            counts[name] = 0
            continue

        resolved = 0
        for item in rec.stale_items(source):
            rec.resolve(item)
            resolved += 1
        counts[name] = resolved
        if resolved:
            logger.info("reconcile %s: снято устаревших: %d", name, resolved)

    logger.debug("reconcile: проход завершён %s (now=%s)", counts, now)
    return counts
