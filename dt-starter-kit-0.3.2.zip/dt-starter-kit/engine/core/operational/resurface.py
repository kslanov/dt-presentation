"""DEV-1d — resurfacing по связям: «новое легло рядом с тем, что ты знал».

Это НЕ ещё один детектор остывания. «Забытые темы» (:func:`core.operational.work._stale`)
показывают, что тихо умирает; здесь — обратное: свежая заметка **связалась** со старой,
и старую стоит вспомнить именно сейчас. Пара «тихо умирает / всплыло по связи».

Сигнал берётся из уже существующих следов применения связей (нового стейта нет):

* **eventlog** (``stage=link``) — КОГДА связи применились и к какой заметке-источнику
  (``note_id``); только он даёт время;
* **журнал применённых связей** ``.derived/link_applied.jsonl`` — ЧТО с чем связали
  (``source``/``target``/``score``/``rationale``); времени в нём нет, поэтому читаем
  хвост и джойним по ``source`` с событиями окна;
* **index_manifest** — бесплатная карта ``note_id → путь заметки`` (иначе пришлось бы
  обходить vault ради каждой пары).

Правило пары (ТЗ): источник — СВЕЖАЯ заметка (``created`` ≤ ``DT_RESURFACE_DAYS``, 7),
цель — СТАРАЯ (``created`` > ``DT_RESURFACE_OLD_DAYS``, 30). Дедуп по паре, максимум
:data:`MAX_PAIRS` (10). На практике целями оказываются хабы сущностей — детерминированный
линкер связывает заметку с клиентом/направлением/продуктом, и «вспомнить» здесь значит
«вот с каким твоим контекстом это состыковалось».

Скрытие пунктов — штатным :func:`core.operational.work.record_dismissal` по стабильному
``id`` (``resurface:<source>:<target>``), без собственного стора.

Read-only, без сети/LLM; ``core`` ⊥ mcp/cli.
"""

from __future__ import annotations

import json
import os
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import (
    default_vault_path,
    index_manifest_path,
    link_applied_path,
)
from core.operational.hub_meta import as_datetime, first_present
from core.vault import read_note

__all__ = [
    "WINDOW_DAYS",
    "OLD_DAYS",
    "MAX_PAIRS",
    "resurfaced",
]

WINDOW_DAYS = 7.0      # env DT_RESURFACE_DAYS — «свежая» заметка и окно связей
OLD_DAYS = 30.0        # env DT_RESURFACE_OLD_DAYS — с какого возраста цель «старая»
MAX_PAIRS = 10         # потолок карточек: это напоминание, не отчёт

# Сколько последних строк журнала связей читать. Журнал append-only и растёт годами
# (на живых данных ~25k строк / 6 МБ); окно интереса — последние дни, поэтому хвоста
# заведомо достаточно, а чтение остаётся дешёвым.
_JOURNAL_TAIL_LINES = 4000


def _env_float(name: str, default: float) -> float:
    raw = (os.environ.get(name) or "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


def _iso_z(dt: datetime) -> str:
    return dt.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _days(later: datetime, earlier: datetime) -> float:
    return max(0.0, (later - earlier).total_seconds()) / 86400


def _note_paths(manifest_path: Path | None = None) -> dict[str, str]:
    """``note_id → vault-относительный путь`` из индекс-манифеста (бесплатная карта)."""
    path = manifest_path or index_manifest_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(data, dict):
        return {}
    out: dict[str, str] = {}
    for note_id, rec in data.items():
        if isinstance(rec, dict) and isinstance(rec.get("path"), str):
            out[str(note_id)] = rec["path"]
    return out


def _journal_tail(path: Path, *, lines: int = _JOURNAL_TAIL_LINES) -> list[dict[str, Any]]:
    """Хвост журнала применённых связей как список записей (битые строки пропускаем)."""
    try:
        raw = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    out: list[dict[str, Any]] = []
    for line in raw[-lines:]:
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(rec, dict) and rec.get("source") and rec.get("target"):
            out.append(rec)
    return out


def _link_events(
    since: datetime, *, db_path: Path | None = None
) -> dict[str, datetime]:
    """``source note_id → время последнего применения связей`` за окно (eventlog)."""
    try:
        from core.eventlog import recent_events

        events = recent_events(
            limit=2000, stage="link", since=_iso_z(since), db_path=db_path
        )
    except Exception:  # noqa: BLE001 — журнал стадий недоступен → просто нет сигнала
        return {}
    out: dict[str, datetime] = {}
    for ev in events:
        note_id = getattr(ev, "note_id", None)
        ts = as_datetime(getattr(ev, "ts", None))
        if not note_id or ts is None:
            continue
        prev = out.get(str(note_id))
        if prev is None or ts > prev:
            out[str(note_id)] = ts
    return out


def _created(vault: Path, rel_path: str | None) -> datetime | None:
    """Дата создания заметки: frontmatter ``created``/``date`` → иначе mtime файла."""
    if not rel_path:
        return None
    path = vault / rel_path
    try:
        note = read_note(path)
    except (OSError, ValueError):
        try:
            return datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
        except OSError:
            return None
    dt = as_datetime(first_present(note.frontmatter, "created", "date"))
    if dt is not None:
        return dt
    try:
        return datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
    except OSError:
        return None


def _title(vault: Path, rel_path: str | None, fallback: str) -> str:
    """Человекочитаемое имя заметки: alias/title из frontmatter → имя файла → id."""
    if not rel_path:
        return fallback
    try:
        note = read_note(vault / rel_path)
    except (OSError, ValueError):
        return Path(rel_path).stem or fallback
    fm = note.frontmatter
    aliases = fm.get("aliases") or []
    if isinstance(aliases, str):
        aliases = [aliases]
    if aliases and str(aliases[0]).strip():
        return str(aliases[0]).strip()
    title = str(fm.get("title") or "").strip()
    return title or Path(rel_path).stem or fallback


def _hub_ids(vault: Path) -> set[str]:
    """id хабов vault (каталог имен любых сущностей); не прочитался - пусто (лента прежняя)."""
    try:
        from core.retrieval.hubcat import hub_catalog

        return {e.note_id for e in hub_catalog(vault, None)}
    except Exception:  # noqa: BLE001 - фильтр хабов не должен ронять ленту
        return set()


def _quarantined_ids(vault: Path) -> set[str]:
    """EVAL-HYGIENE-1: id заметок-прогонов eval/selftest (frontmatter-снимок); сбой - пусто."""
    try:
        from core.retrieval.fm_cache import peek_metas
        from core.retrieval.notemeta import is_quarantined

        return {m.id for m in peek_metas(vault) if is_quarantined(m)}
    except Exception:  # noqa: BLE001 - фильтр прогонов не должен ронять ленту
        return set()


def resurfaced(
    *,
    vault_path: Path | None = None,
    now: datetime | None = None,
    dismiss_path: Path | None = None,
    journal_path: Path | None = None,
    index_path: Path | None = None,
    db_path: Path | None = None,
    limit: int = MAX_PAIRS,
) -> dict[str, Any]:
    """Пары «свежая заметка ↔ старая заметка», связанные за последние дни.

    Возврат ``{now, window_days, old_days, pairs, total}``; пара —
    ``{id, new_note: {id, title, path}, old_note: {id, title, path}, resolver, score,
    rationale, when, as_of, new_age_days, old_age_days}``. Снятые через
    ``work_dismiss`` пункты не показываются (тот же предикат, что у ленты «Внимание»).
    Пары, где старая заметка - хаб, не показываются (R8: это дубль линковки).
    Пустые/отсутствующие журналы → пустой список, не исключение.
    """
    now = now or datetime.now(UTC)
    vault = Path(vault_path) if vault_path else default_vault_path()
    window = _env_float("DT_RESURFACE_DAYS", WINDOW_DAYS)
    old_days = _env_float("DT_RESURFACE_OLD_DAYS", OLD_DAYS)
    since = now - timedelta(days=window)

    recent = _link_events(since, db_path=db_path)
    result: dict[str, Any] = {
        "now": _iso_z(now),
        "window_days": window,
        "old_days": old_days,
        "pairs": [],
        "total": 0,
    }
    if not recent:
        return result

    journal = _journal_tail(journal_path or link_applied_path())
    if not journal:
        return result
    paths = _note_paths(index_path)

    # dismiss — реюз серверного решения ленты «Внимание» (своего стора не заводим)
    from core.operational.work import _dismiss_path, _hidden_predicate, _load_json

    dismissals = _load_json(_dismiss_path(dismiss_path))
    hidden = _hidden_predicate(dismissals if isinstance(dismissals, dict) else {}, now=now)

    # R8 (SURFACE-HYGIENE-1): «старая заметка - хаб» - это дубль линковки (хаб и так показан в
    # «Связано» заметки), а не «всплыло»; в ленту идут пары, где старая заметка НЕ хаб
    hub_ids = _hub_ids(vault)
    run_ids = _quarantined_ids(vault)  # EVAL-HYGIENE-1: прогоны eval/selftest - не «всплыло»
    created_cache: dict[str, datetime | None] = {}

    def created(note_id: str) -> datetime | None:
        if note_id not in created_cache:
            created_cache[note_id] = _created(vault, paths.get(note_id))
        return created_cache[note_id]

    pairs: list[tuple[datetime, dict[str, Any]]] = []
    seen: set[tuple[str, str]] = set()
    for rec in reversed(journal):  # свежие записи журнала — в конце файла
        source = str(rec.get("source") or "")
        target = str(rec.get("target") or "")
        when = recent.get(source)
        if when is None or source == target:
            continue
        key = (source, target)
        if key in seen or target in hub_ids or source in run_ids or target in run_ids:
            continue
        new_created = created(source)
        old_created = created(target)
        if new_created is None or old_created is None:
            continue  # без обеих дат правило «свежая→старая» не проверить
        new_age = _days(now, new_created)
        old_age = _days(now, old_created)
        if new_age > window or old_age <= old_days:
            continue
        seen.add(key)
        item = {
            "id": f"resurface:{source}:{target}",
            "new_note": {"id": source, "title": _title(vault, paths.get(source), source),
                         "path": paths.get(source)},
            "old_note": {"id": target, "title": _title(vault, paths.get(target), target),
                         "path": paths.get(target)},
            "resolver": str(rec.get("resolver") or "").strip() or None,
            "score": rec.get("score"),
            "rationale": str(rec.get("rationale") or "").strip() or None,
            "when": _iso_z(when),
            "as_of": _iso_z(when),
            "new_age_days": round(new_age, 1),
            "old_age_days": round(old_age),
        }
        if hidden(item):
            continue
        pairs.append((when, item))

    pairs.sort(key=lambda p: p[0], reverse=True)
    limit = max(1, min(int(limit or MAX_PAIRS), MAX_PAIRS))
    result["pairs"] = [item for _, item in pairs[:limit]]
    result["total"] = len(pairs)
    return result
