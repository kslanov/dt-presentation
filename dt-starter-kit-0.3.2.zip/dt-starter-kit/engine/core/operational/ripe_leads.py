"""LEAD-2 — детектор «созревших» vault-хабов, которых ещё нет в Timetta.

Обратная сторона `hub_scan` (тот ищет, где нужен хаб): здесь ищем хабы-лиды,
которые уже живут в vault, набрали материал и **пора заводить сделку в Timetta**.

Read-only, без сети (как :mod:`core.operational.freshness` / `hub_scan`): сканит
vault на хабы с ``entity ∈ {project, deal}`` и пустым ``timetta_id`` (живут
только в vault) и считает сигналы зрелости — сколько заметок в папке хаба, когда
последняя активность, возраст, помечен ли ``presale``. Флаг ``ripe`` = набрано
достаточно материала, чтобы вести дальше. Ничего не пишет; решение и промоут в
Timetta — не движок: пульт предлагает «поручить» (карточка поручения администратору CRM) и
«связать с хабом»; сделку в Timetta заводит администратор CRM.

Каждый хаб несёт ``track`` (:data:`core.operational.tracks.TRACKS`): ``presale``
(sales-лид → сделка Timetta), ``project`` (коммерческий проект — клиентская работа
в исполнении) или ``internal`` (внутренний проект, свой жизненный цикл). Все треки
ведём одинаково (детектор + промоут), различается только цель/ярлык.

Трек берётся из **явного поля ``track: presale|project|internal``** во frontmatter
хаба (:func:`_track`) — оно имеет приоритет над эвристикой. Нет поля / мусорное
значение → откат к **двузначной** эвристике :func:`_is_presale` (``status``/тег
``presale``; ``project`` только явным полем) — обратная совместимость. Так
классификация меняется одной строкой во frontmatter (или кнопкой пульта →
:func:`core.operational.hub_link.set_track`).

Снуз («отложить») хранится в ``.derived/operational/ripe_snooze.json`` (по образцу
work-dismissals): пока ``now < until`` — лид не показывается.
"""

from __future__ import annotations

import json
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import default_vault_path, operational_derived_path
from core.operational.hub_meta import HUB_DIR as LEAD_DIR
from core.operational.hub_meta import (
    as_datetime as _as_datetime,
)
from core.operational.hub_meta import (
    first_present as _first_present,
)
from core.operational.hub_meta import (
    iter_hubs,
    to_utc,
)
from core.operational.tracks import TRACKS

__all__ = [
    "DEADLINE_SOON_DAYS",
    "LEAD_ENTITIES",
    "RIPE_MIN_AGE_DAYS",
    "RIPE_MIN_NOTES",
    "reject_lead",
    "ripe_leads",
    "snooze_lead",
]

# Сущности, которые могут стать сделкой Timetta (лид / пресейл / проект). Хабы
# клиента/продукта/отрасли сами сделками не становятся — их не трогаем.
LEAD_ENTITIES: frozenset[str] = frozenset({"project", "deal"})

# Где живут хабы-лиды — общий с детектором дедлайнов ``hub_meta.HUB_DIR``
# (импортирован как ``LEAD_DIR``: имя в этом модуле историческое, значение одно).

RIPE_MIN_NOTES = 3          # ≥ столько .md в папке хаба — набрал материал
RIPE_MIN_AGE_DAYS = 3       # совсем свежие хабы (< 3 дней) не дёргаем
DEADLINE_SOON_DAYS = 21     # дедлайн ближе этого — сильный сигнал «пора»


def _snooze_path(explicit: Path | None) -> Path:
    return Path(explicit) if explicit else operational_derived_path() / "ripe_snooze.json"


def _load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def _is_presale(fm: dict[str, Any]) -> bool:
    status = str(fm.get("status") or "").strip().lower()
    if status in {"presale", "pre-sale", "пресейл"}:
        return True
    tags = fm.get("tags") or []
    if isinstance(tags, str):
        tags = [tags]
    return any(str(t).strip().lower() in {"presale", "pre-sale", "пресейл"} for t in tags)


def _track(fm: dict[str, Any]) -> str:
    """Трек хаба: явное поле ``track:`` (приоритет) → иначе эвристика ``_is_presale``.

    ``track ∈`` :data:`core.operational.tracks.TRACKS` (``presale``/``project``/
    ``internal``) из frontmatter имеет приоритет над эвристикой (фикс бага
    «клиентский хаб показан внутренним проектом»). Пустое/мусорное значение поля
    игнорируется → откат к **двузначной** эвристике (``project`` эвристикой не
    определяется — только явным полем; обратная совместимость с хабами без поля).
    Возвращает ``"presale"`` | ``"project"`` | ``"internal"``.
    """
    explicit = str(fm.get("track") or "").strip().lower()
    if explicit in TRACKS:
        return explicit
    return "presale" if _is_presale(fm) else "internal"


def _folder_activity(folder: Path) -> tuple[int, datetime | None]:
    """Сколько .md в папке хаба и время самого свежего изменения (рекурсивно)."""
    count = 0
    latest: float | None = None
    for md in folder.rglob("*.md"):
        count += 1
        try:
            mt = md.stat().st_mtime
        except OSError:
            continue
        if latest is None or mt > latest:
            latest = mt
    latest_dt = datetime.fromtimestamp(latest, tz=UTC) if latest is not None else None
    return count, latest_dt


def _days(a: datetime, b: datetime) -> int:
    return int((a - b).total_seconds() // 86400)


def ripe_leads(
    *,
    vault_path: Path | None = None,
    snooze_path: Path | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Vault-хабы-лиды без пары в Timetta + сигналы зрелости.

    Возвращает ``{now, leads:[…], counts:{total,ripe,snoozed}, elapsed_ms}``.
    ``leads`` не содержит снуженные; отсортирован ripe-first, затем по свежести
    активности. Пустой/битый vault → пустой список, не исключение.
    """
    started = time.perf_counter()
    now = to_utc(now) if now is not None else datetime.now(UTC)
    vault = Path(vault_path) if vault_path else default_vault_path()
    snooze = _load_json(_snooze_path(snooze_path))

    leads: list[dict[str, Any]] = []
    snoozed_n = 0
    for path, note in iter_hubs(vault, subdir=LEAD_DIR, entities=LEAD_ENTITIES):
        fm = note.frontmatter
        if str(fm.get("timetta_id") or "").strip():
            continue  # уже связан со сделкой Timetta — не лид
        if str(fm.get("timetta_sync") or "own").strip().lower() == "monitor":
            continue  # зеркало-владелец, не создаём

        # отказ навсегда (не станет сделкой) / снуз по времени?
        s = snooze.get(note.id)
        if isinstance(s, dict):
            if s.get("rejected"):
                continue  # «отказать» — навсегда убран из детектора
            until = _as_datetime(s.get("until"))
            if until is not None and now < until:
                snoozed_n += 1
                continue

        notes, last_act = _folder_activity(path.parent)
        created = _as_datetime(_first_present(fm, "created", "date"))
        deadline = _as_datetime(_first_present(fm, "deadline", "due"))
        age_days = _days(now, created) if created else None
        activity_days = _days(now, last_act) if last_act else None
        deadline_days = _days(deadline, now) if deadline else None
        deadline_soon = deadline_days is not None and 0 <= deadline_days <= DEADLINE_SOON_DAYS

        reasons: list[str] = []
        if notes >= RIPE_MIN_NOTES:
            reasons.append(f"{notes} заметок в хабе")
        if deadline_soon:
            reasons.append(f"дедлайн через {deadline_days} дн.")
        old_enough = age_days is None or age_days >= RIPE_MIN_AGE_DAYS
        ripe = old_enough and bool(reasons)

        aliases = fm.get("aliases") or []
        if isinstance(aliases, str):
            aliases = [aliases]
        name = str(aliases[0]) if aliases else note.id

        # Явное поле track: (приоритет) → иначе эвристика; presale-флаг производен
        # от трека, чтобы выдача была консистентной.
        track = _track(fm)
        presale = track == "presale"
        leads.append({
            "id": note.id,
            "name": name,
            "entity": str(fm.get("entity") or ""),
            "status": str(fm.get("status") or ""),
            "presale": presale,
            # Оба трека ведём одинаково (детектор + промоут), но у каждого свой
            # жизненный цикл: presale-лид → сделка Timetta; internal — проект,
            # который К. курирует (свой промоут/стадии).
            "track": track,
            "client": str(fm.get("client") or "") or None,
            "path": str(path.relative_to(vault)),
            "notes": notes,
            "age_days": age_days,
            "activity_days": activity_days,
            "deadline_days": deadline_days,
            "ripe": ripe,
            "reasons": reasons,
        })

    leads.sort(
        key=lambda x: (not x["ripe"], x["activity_days"] if x["activity_days"] is not None else 1e9)
    )
    return {
        "now": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "leads": leads,
        "counts": {
            "total": len(leads),
            "ripe": sum(1 for x in leads if x["ripe"]),
            "snoozed": snoozed_n,
        },
        "elapsed_ms": round((time.perf_counter() - started) * 1000, 1),
    }


def _nfc(value: Any) -> str:
    """NFC-нормализация ссылки (macOS отдаёт имена в NFD)."""
    import unicodedata

    return unicodedata.normalize("NFC", str(value or "").strip())


def _unknown_hub(hub_id: str, action: str) -> dict[str, Any]:
    """Отказ по неизвестной ссылке на хаб (CONTRACT-1 ФП-4) — без записи в стор."""
    return {
        "ok": False,
        "refused": True,
        "code": "unknown_item",
        "hub_id": hub_id,
        "action": action,
        "error": (
            f"хаб {hub_id!r} не найден в vault — решение не записано (ссылка "
            "принимается в любой форме: id хаба, путь заметки, имя файла)"
        ),
    }


def _hub_exists(hub_id: str, vault_path: Path | None = None) -> bool:
    """Есть ли такой хаб-лид (CONTRACT-1 ФП-4: ссылка решения обязана быть проверяемой).

    Проверяем ТЕМ ЖЕ обходом, которым детектор строит саму ленту (:func:`iter_hubs` по
    ``LEAD_DIR``/``LEAD_ENTITIES``) — сверка по ``id`` хаба, NFC. Почему не одним
    ``resolve_note_path``: у хаба-лида ``id`` (``project-snz``) штатно не совпадает с
    именем файла (``hub.md``), а свежесозданного хаба ещё нет в индекс-манифесте —
    единая точка резолва вернула бы ``None``, и законное решение получило бы ложный
    отказ. Единая точка остаётся вторым шагом: она принимает путь/имя файла.
    """
    from core.vault import resolve_note_path

    ref = _nfc(hub_id)
    if not ref:
        return False
    root = Path(vault_path) if vault_path is not None else default_vault_path()
    for _path, note in iter_hubs(root, subdir=LEAD_DIR, entities=LEAD_ENTITIES):
        if _nfc(note.id) == ref:
            return True
    return resolve_note_path(str(hub_id).strip(), vault_path=root) is not None


def snooze_lead(
    hub_id: str,
    days: float = 14.0,
    *,
    snooze_path: Path | None = None,
    now: datetime | None = None,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Отложить лид на ``days`` дней (не показывать, пока ``now < until``).

    **CONTRACT-1 ФП-4 (Д11).** Неизвестная ссылка на хаб → ``{ok: false, refused: true,
    code: "unknown_item"}`` и **ничего не пишется**: до фикса опечатка в id создавала
    «решение» по несуществующему хабу и отвечала успехом.
    """
    if not _hub_exists(hub_id, vault_path):
        return _unknown_hub(hub_id, "snooze")
    now = to_utc(now) if now is not None else datetime.now(UTC)
    path = _snooze_path(snooze_path)
    store = _load_json(path)
    until = now + timedelta(days=float(days))
    store[hub_id] = {
        "until": until.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"snoozed": hub_id, "until": store[hub_id]["until"], "days": float(days)}


def reject_lead(
    hub_id: str,
    *,
    snooze_path: Path | None = None,
    now: datetime | None = None,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """«Отказать» — навсегда убрать хаб из детектора (сделкой не станет).

    В отличие от снуза не имеет срока; хаб больше не показывается, пока запись
    не удалят руками. Хранится в том же store, что и снуз. Неизвестная ссылка на хаб →
    отказ ``unknown_item`` без записи (CONTRACT-1 ФП-4).
    """
    if not _hub_exists(hub_id, vault_path):
        return _unknown_hub(hub_id, "reject")
    now = to_utc(now) if now is not None else datetime.now(UTC)
    path = _snooze_path(snooze_path)
    store = _load_json(path)
    store[hub_id] = {"rejected": True, "at": now.strftime("%Y-%m-%dT%H:%M:%SZ")}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"rejected": hub_id}
