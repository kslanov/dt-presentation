"""ADAPTER-HONEST-1 п.5 — сторож зависших прогонов (liveness по прогрессу).

Читает lock'и прогонов (``dt-sync.lock``, ``index.lock``) и их heartbeat
(:mod:`core.runlock`): lock **удерживается** flock'ом, а его mtime не двигался дольше
``DT_RUN_STALL_MIN`` (дефолт 60 мин) — прогон без прогресса. Такой прогон снимается:
SIGTERM → пауза → SIGKILL процессу-держателю (pid берётся из самого lock-файла, иначе
из ``lsof``; перед убийством проверяется, что это наш процесс — ``dt_sync``/``dt_index``,
а не переиспользованный pid), lock-файл удаляется, событие пишется в журнал (лог,
журнал стадий). Следующий плановый fast/index стартует с
чистого lock'а — «шаг перезапускается, а не висит».

**Сон ноутбука не считается простоем** (WAVE0-HYGIENE п.8, аудит B8): возраст heartbeat —
настенные часы (mtime), и после ночи сна живой прогон выглядел «без прогресса 362 мин» и
снимался (10-17). Теперь, если машина просыпалась ПОСЛЕ последнего heartbeat
(``kern.waketime`` > mtime, сон ≥ ``DT_RUN_SLEEP_MIN_S``), возраст считается от пробуждения —
прогону даётся тот же порог, чтобы ожить, а lock помечается «пережил сон». Страховка от вечной
отсрочки (hourly DarkWake): сырой возраст ≥ ``DT_RUN_STALL_MAX_H`` (36 ч) снимает прогон
независимо от сна. Нет данных о пробуждении (не macOS) — прежнее поведение.

Чего здесь нет намеренно: **живой, но медленный** прогон (heartbeat свежий) не трогается —
сторож судит по прогрессу, а не по длительности. Lock без держателя (файл остался, flock
свободен) — безобидный остаток, не шумим.

Вызывается планово (``cli/dt_run_watchdog.py`` ← launchd ``com.dt.run.watchdog``), а
doctor использует тот же :func:`scan` для warn. ``core`` ⊥ mcp/cli; сети и LLM нет.
"""

from __future__ import annotations

import contextlib
import fcntl
import logging
import os
import re
import signal
import subprocess
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core import runlock

logger = logging.getLogger(__name__)

__all__ = [
    "LockState",
    "last_wake_epoch",
    "lock_targets",
    "inspect_lock",
    "scan",
    "reap",
    "run_watchdog",
]

# Командная строка убиваемого процесса обязана содержать один из маркеров — защита от
# переиспользованного pid (сторож не должен убить чужой процесс).
_OUR_MARKERS = ("dt_sync", "dt_index", "dt-sync", "dt-index")
_TERM_GRACE_S = 10.0


@dataclass
class LockState:
    """Состояние одного lock'а прогона."""

    label: str
    path: Path
    held: bool  # flock удерживается процессом
    pid: int | None
    mode: str
    step: str
    age_min: float | None  # минут простоя: с последнего heartbeat, но не раньше пробуждения
    stalled: bool  # удерживается И простой (без сна) старше порога
    slept: bool = False  # машина просыпалась после последнего heartbeat (п.8)
    age_raw_min: float | None = None  # минут с последнего heartbeat по настенным часам

    def to_dict(self) -> dict[str, Any]:
        return {
            "label": self.label, "path": str(self.path), "held": self.held, "pid": self.pid,
            "mode": self.mode, "step": self.step,
            "age_min": None if self.age_min is None else round(self.age_min, 1),
            "age_raw_min": None if self.age_raw_min is None else round(self.age_raw_min, 1),
            "slept": self.slept,
            "stalled": self.stalled,
        }


_SYSCTL = "/usr/sbin/sysctl"
_SYSCTL_RE = re.compile(r"sec\s*=\s*(\d+)")
DEFAULT_MIN_SLEEP_S = 120.0
DEFAULT_STALL_MAX_H = 36.0


def _sysctl_epoch(name: str) -> float | None:
    """``sysctl -n kern.waketime`` → epoch-секунды (``{ sec = N, usec = M } …``) | ``None``."""
    try:
        proc = subprocess.run(  # noqa: S603 — фиксированный argv, без shell
            [_SYSCTL, "-n", name], capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    match = _SYSCTL_RE.search(proc.stdout)
    return float(match.group(1)) if match else None


def last_wake_epoch() -> tuple[float, float] | None:
    """``(начало, конец)`` последнего сна машины по ``kern.sleeptime``/``kern.waketime``.

    Конец — момент последнего пробуждения (включая DarkWake). ``None`` — не macOS /
    sysctl недоступен / машина ещё не спала с загрузки (``waketime`` = 0).
    """
    wake = _sysctl_epoch("kern.waketime")
    sleep = _sysctl_epoch("kern.sleeptime")
    if not wake or not sleep or wake < sleep:
        return None
    return sleep, wake


def _env_float(name: str, default: float) -> float:
    try:
        value = float((os.environ.get(name) or "").strip())
    except ValueError:
        return default
    return value if value > 0 else default


def lock_targets() -> list[tuple[str, Path]]:
    """Известные lock'и прогонов: ``[(метка, путь)]``."""
    from core.config import index_lock_path, sync_lock_path

    return [
        ("dt-sync.lock", sync_lock_path()),
        ("dt-sync-index.lock", runlock.index_sync_lock(sync_lock_path())),
        ("index.lock", index_lock_path()),
    ]


def _lock_held(path: Path) -> bool:
    """True, если flock ``path`` удерживается процессом (неблокирующая проба)."""
    try:
        fh = open(path, "a")
    except OSError:
        return False
    try:
        try:
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return True
        with contextlib.suppress(Exception):
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        return False
    finally:
        fh.close()


def inspect_lock(
    label: str,
    path: Path,
    *,
    now: float | None = None,
    stall_min: float | None = None,
    wake_info: Callable[[], tuple[float, float] | None] | None = None,
) -> LockState | None:
    """Состояние lock'а или ``None`` (файла нет).

    Возраст простоя не включает сон (п.8): если машина просыпалась после последнего
    heartbeat (сон ≥ ``DT_RUN_SLEEP_MIN_S``, 120 с), возраст считается от пробуждения —
    ``slept=True``, прогон не снимается, пока не пройдёт порог уже ПОСЛЕ пробуждения.
    Сырой возраст ≥ ``DT_RUN_STALL_MAX_H`` (36 ч) — стоп-кран от вечной отсрочки.
    """
    p = Path(path)
    if not p.is_file():
        return None
    limit = stall_min if stall_min is not None else runlock.stall_minutes()
    now_ts = now if now is not None else time.time()
    raw_age = runlock.heartbeat_age_min(p, now=now_ts)
    held = _lock_held(p)
    info = runlock.read_info(p)
    pid = info.get("pid")

    age = raw_age
    slept = False
    if raw_age is not None:
        mtime = now_ts - raw_age * 60.0
        wake = (wake_info or last_wake_epoch)()
        if wake is not None:
            sleep_start, wake_ts = wake
            if (
                mtime < wake_ts <= now_ts
                and wake_ts - sleep_start >= _env_float("DT_RUN_SLEEP_MIN_S", DEFAULT_MIN_SLEEP_S)
            ):
                slept = True
                age = max(0.0, (now_ts - wake_ts) / 60.0)
    max_raw_min = _env_float("DT_RUN_STALL_MAX_H", DEFAULT_STALL_MAX_H) * 60
    hard_stall = bool(raw_age is not None and raw_age >= max_raw_min)
    return LockState(
        label=label, path=p, held=held,
        pid=int(pid) if isinstance(pid, int) else None,
        mode=str(info.get("mode") or ""), step=str(info.get("step") or ""),
        age_min=age, stalled=bool(held and age is not None and (age >= limit or hard_stall)),
        slept=slept, age_raw_min=raw_age,
    )


def scan(
    *,
    targets: list[tuple[str, Path]] | None = None,
    now: float | None = None,
    stall_min: float | None = None,
    wake_info: Callable[[], tuple[float, float] | None] | None = None,
) -> list[LockState]:
    """Состояния всех известных lock'ов (только существующие файлы)."""
    out: list[LockState] = []
    for label, path in targets if targets is not None else lock_targets():
        state = inspect_lock(label, path, now=now, stall_min=stall_min, wake_info=wake_info)
        if state is not None:
            out.append(state)
    return out


def _holder_pid(state: LockState) -> int | None:
    """pid держателя: из lock-файла, иначе ``lsof -t`` (lock старого формата)."""
    if state.pid:
        return state.pid
    try:
        proc = subprocess.run(  # noqa: S603 — фиксированный argv, без shell
            ["/usr/sbin/lsof", "-t", str(state.path)],
            capture_output=True, text=True, timeout=10, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    for tok in proc.stdout.split():
        if tok.isdigit() and int(tok) != os.getpid():
            return int(tok)
    return None


def _command_of(pid: int) -> str:
    try:
        proc = subprocess.run(  # noqa: S603 — фиксированный argv, без shell
            ["/bin/ps", "-p", str(pid), "-o", "command="],
            capture_output=True, text=True, timeout=10, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return proc.stdout.strip()


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def reap(
    state: LockState,
    *,
    kill: Callable[[int, int], None] = os.kill,
    command_of: Callable[[int], str] = _command_of,
    sleep: Callable[[float], None] = time.sleep,
    grace_s: float = _TERM_GRACE_S,
) -> dict[str, Any]:
    """Снять прогон без прогресса: SIGTERM → SIGKILL держателю, удалить lock, залогировать.

    Чужой/неопознанный процесс не убивается (``killed=False``, причина в ``reason``) — но
    lock в этом случае НЕ удаляется: снять lock под живым неопознанным процессом значило бы
    пустить второй прогон параллельно.
    """
    pid = _holder_pid(state)
    result: dict[str, Any] = {**state.to_dict(), "killed": False, "reason": ""}
    if pid is None:
        result["reason"] = "держатель не найден (pid неизвестен)"
        logger.warning("[runwatch] %s без прогресса %.0f мин, но держатель не найден",
                       state.label, state.age_min or 0)
        return result
    cmd = command_of(pid)
    if not any(m in cmd for m in _OUR_MARKERS):
        result["reason"] = f"pid {pid} — не наш процесс ({cmd[:60] or 'нет в ps'}); не трогаю"
        logger.warning("[runwatch] %s: %s", state.label, result["reason"])
        return result
    logger.warning(
        "[runwatch] %s: прогон pid=%s (mode=%s step=%s) без прогресса %.0f мин — снимаю",
        state.label, pid, state.mode, state.step, state.age_min or 0,
    )
    with contextlib.suppress(ProcessLookupError, PermissionError):
        kill(pid, signal.SIGTERM)
    waited = 0.0
    while waited < grace_s and _alive(pid):
        sleep(0.5)
        waited += 0.5
    if _alive(pid):
        with contextlib.suppress(ProcessLookupError, PermissionError):
            kill(pid, signal.SIGKILL)
    result["killed"] = True
    with contextlib.suppress(OSError):
        state.path.unlink()
    _journal(result)
    return result


def _journal(result: dict[str, Any]) -> None:
    """Событие снятия — в журнал стадий (best-effort, без путей/текстов). Метрик-точку
    (``record_event``) не заводим: храповик ``test_metrics_call_sites_not_grown`` и ТЗ
    («новых точек учёта не заводить») — снятие видно в логе и ленте событий."""
    detail = {k: result[k] for k in ("label", "pid", "mode", "step", "age_min")}
    try:
        from core.eventlog import emit

        emit("sync", "stalled_killed", detail=detail)
    except Exception:  # noqa: BLE001 — журнал не критичный путь
        logger.debug("eventlog emit failed", exc_info=True)


def run_watchdog(
    *,
    targets: list[tuple[str, Path]] | None = None,
    now: float | None = None,
    stall_min: float | None = None,
    dry_run: bool = False,
    wake_info: Callable[[], tuple[float, float] | None] | None = None,
    **reap_kwargs: Any,
) -> list[dict[str, Any]]:
    """Один проход сторожа: найти зависшие прогоны и снять их (если не ``dry_run``)."""
    out: list[dict[str, Any]] = []
    for state in scan(targets=targets, now=now, stall_min=stall_min, wake_info=wake_info):
        if not state.stalled:
            continue
        if dry_run:
            out.append({**state.to_dict(), "killed": False, "reason": "dry-run"})
        else:
            out.append(reap(state, **reap_kwargs))
    return out
