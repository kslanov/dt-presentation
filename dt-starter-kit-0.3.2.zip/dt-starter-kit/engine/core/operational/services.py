"""PULT-ENGINE — единый service-DAO контура «Движок» (сервисы движка).

Один декларативный реестр сервисов + два read/act-примитива, поверх которых
живут MCP-инструменты ``pult_services`` / ``pult_service_control`` (см.
``docs/tz/pult-engine-service-control.md``). ``mcp-server/server.py`` остаётся
тонкой обёрткой — инвариант ``core/`` ⊥ mcp/cli держится (этот модуль импортирует
только stdlib + ``core.operational.pult.record_action`` для аудита).

Модель (принцип 12 — не плодим второй способ):

* три launchd-демона (``com.dt.sync.fast`` / ``com.dt.sync.index`` /
  ``com.dt.server``, ``ops/launchd/*.plist``) управляются ``launchctl`` — тем же
  паттерном, что ``mcp-server`` :func:`pult_web_restart` (``kickstart -k``).
  DAEMON-1: ``com.dt.server`` - демон движка (пульт + MCP на одном порту), он заменил
  ``com.dt.webpult``; прежний ключ реестра ``webpult`` принимается как алиас ``server``;
* PERSONAL-2: у экземпляра (``DT_INSTANCE=<имя>``) реестр тот же по ключам, но метки launchd -
  ``com.dt.*-<имя>`` (:func:`registry`): ``pult_services``/``pult_service_control`` на порту
  экземпляра управляют ЕГО службами и не могут тронуть рабочие (``com.dt.server`` и т.д.);
* MCP-сервер запущен под MCP-хостом (не launchd) → сам себя не рестартит:
  ``control="status_only"``, мутация → внятный отказ (полный ребут = рестарт
  хоста, это ограничение, не баг).

Детерминизм и тестопригодность: весь ввод/вывод ``launchctl`` идёт через
инжектируемый :data:`Runner` (тесты подставляют мок — реальный ``launchctl`` в
тестах не зовётся). Read-only статус свободно; мутации (start/stop/restart) —
за явным ``action`` (гард) и с аудитом :func:`~core.operational.pult.record_action`.
"""

from __future__ import annotations

import os
import re
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.operational.pult import record_action

__all__ = [
    "CONTROL_FULL",
    "CONTROL_STATUS_ONLY",
    "KIND_LAUNCHD",
    "KIND_MCP",
    "SERVICE_ACTIONS",
    "SERVICES",
    "SERVICES_BY_KEY",
    "SERVICE_ALIASES",
    "registry",
    "RunResult",
    "Runner",
    "ServiceControlError",
    "ServiceSpec",
    "launchagents_dir",
    "service_status",
    "service_control",
]

CONTROL_FULL = "full"
CONTROL_STATUS_ONLY = "status_only"
KIND_LAUNCHD = "launchd"
KIND_MCP = "mcp"

# Единственные действия, которые пульт может послать сервису (гард ТЗ: никаких
# произвольных launchctl-глаголов).
SERVICE_ACTIONS = ("start", "stop", "restart")


@dataclass(frozen=True)
class ServiceSpec:
    """Один сервис движка в реестре.

    ``key`` — стабильный идентификатор для пульта/MCP (``sync.fast`` …); ``label``
    — человекочитаемое имя карточки; ``kind`` — ``launchd`` | ``mcp``;
    ``plist_label`` — launchd-Label (``com.dt.*``) или ``None`` для mcp;
    ``control`` — ``full`` (start/stop/restart) | ``status_only``.
    """

    key: str
    label: str
    kind: str
    plist_label: str | None
    control: str


# Декларативный реестр — единственный источник правды о сервисах движка.
SERVICES: tuple[ServiceSpec, ...] = (
    ServiceSpec(
        "sync.fast", "Оборот (fast)", KIND_LAUNCHD, "com.dt.sync.fast", CONTROL_FULL
    ),
    ServiceSpec(
        "sync.index", "Индексация (index)", KIND_LAUNCHD, "com.dt.sync.index", CONTROL_FULL
    ),
    ServiceSpec(
        "server", "Движок DT: пульт + MCP", KIND_LAUNCHD, "com.dt.server", CONTROL_FULL
    ),
    ServiceSpec("mcp", "MCP-сервер", KIND_MCP, None, CONTROL_STATUS_ONLY),
)
SERVICES_BY_KEY: dict[str, ServiceSpec] = {s.key: s for s in SERVICES}


def registry() -> tuple[tuple[ServiceSpec, ...], dict[str, ServiceSpec]]:
    """Реестр ЭТОГО процесса: без экземпляра - :data:`SERVICES` как есть (байт в байт); с
    ``DT_INSTANCE`` - те же ключи, метки ``<plist_label>-<имя>`` и подпись «(<имя>)»."""
    from core.instance import instance_name

    name = instance_name()
    if not name:
        return SERVICES, SERVICES_BY_KEY
    specs = tuple(
        s if s.plist_label is None else ServiceSpec(
            s.key, f"{s.label} ({name})", s.kind, f"{s.plist_label}-{name}", s.control)
        for s in SERVICES)
    return specs, {s.key: s for s in specs}
# DAEMON-1: прежние ключи, принимаемые как алиас (пульт/хосты со старым ``webpult``).
SERVICE_ALIASES: dict[str, str] = {"webpult": "server"}


def _spec(key: str) -> ServiceSpec | None:
    """Спецификация по ключу или алиасу (``None`` - неизвестный ключ); реестр - :func:`registry`."""
    return registry()[1].get(SERVICE_ALIASES.get(key, key))


class ServiceControlError(RuntimeError):
    """Мутация запрошена там, где она невозможна (status_only) — внятный отказ."""


@dataclass(frozen=True)
class RunResult:
    """Результат одного ``launchctl``-вызова (или мока в тестах)."""

    returncode: int
    stdout: str
    stderr: str


# Инжектируемый исполнитель команд — по умолчанию :func:`_default_runner`; тесты
# подставляют мок, чтобы реальный launchctl не звался.
Runner = Callable[[list[str]], RunResult]


# Код, которым :func:`_default_runner` помечает «команда не выполнилась вовсе» (нет
# бинаря/таймаут). Отличается от кодов самого launchctl — по нему статус становится
# ``unknown``, а не ``stopped`` (CONTRACT-2 С6).
_RC_SPAWN_FAILED = 127


def _default_runner(argv: list[str], *, timeout: float = 6.0) -> RunResult:
    """Реальный ``launchctl`` через :mod:`subprocess`; сбой запуска → :data:`_RC_SPAWN_FAILED`."""
    try:
        proc = subprocess.run(  # noqa: S603 — фиксированный argv, без shell
            argv, capture_output=True, text=True, timeout=timeout, check=False
        )
        return RunResult(proc.returncode, proc.stdout or "", proc.stderr or "")
    except (OSError, subprocess.SubprocessError) as exc:
        return RunResult(127, "", str(exc))


def launchagents_dir() -> Path:
    """Каталог установленных launchd-плистов (``ops/install_launchd.sh``)."""
    return Path.home() / "Library" / "LaunchAgents"


def _plist_path(spec: ServiceSpec) -> Path:
    """Путь установленного плиста сервиса (для ``bootstrap`` при старте)."""
    return launchagents_dir() / f"{spec.plist_label}.plist"


# launchctl list <label> печатает plist-подобный словарь; нам нужны PID (жив?) и
# LastExitStatus (код прошлого прогона). Отсутствие сервиса → ненулевой код.
_PID_RE = re.compile(r'"PID"\s*=\s*(\d+)\s*;')
_EXIT_RE = re.compile(r'"LastExitStatus"\s*=\s*(-?\d+)\s*;')


def _launchd_status(spec: ServiceSpec, runner: Runner) -> dict[str, Any]:
    """Статус launchd-сервиса из ``launchctl list <label>`` (мок в тестах).

    ``returncode != 0`` ⇒ сервис не загружен (``stopped``); **сбой самой команды**
    (:data:`_RC_SPAWN_FAILED`) ⇒ ``status: "unknown"`` + ``reason`` — «не смог узнать»
    не выдаётся за «выключено» (CONTRACT-2 С6). Загружен + есть ``PID`` ⇒ ``running``
    (+pid); загружен без ``PID`` ⇒ ``loaded`` (ждёт своего слота).
    ``last_exit_code`` — из ``LastExitStatus`` (код прошлого прогона).
    """
    result = runner(["launchctl", "list", spec.plist_label or ""])
    if result.returncode != 0:
        # CONTRACT-2 С6: «launchctl не смог ответить» ≠ «сервис остановлен».
        # ``_default_runner`` отдаёт 127 и на OSError (нет бинаря, таймаут) — раньше
        # это подавалось как ``stopped``, и витрина «Движок» показывала работающий
        # демон остановленным. Различаем: 113 «не загружен» — это ответ launchctl,
        # 127/сбой запуска — неизвестность.
        if result.returncode == _RC_SPAWN_FAILED:
            return {
                "loaded": None,
                "running": None,
                "status": "unknown",
                "pid": None,
                "last_exit_code": None,
                "reason": (
                    "launchctl не выполнился: "
                    + (result.stderr or "нет вывода").strip()[:160]
                ),
            }
        return {
            "loaded": False,
            "running": False,
            "status": "stopped",
            "pid": None,
            "last_exit_code": None,
        }
    pid_m = _PID_RE.search(result.stdout)
    exit_m = _EXIT_RE.search(result.stdout)
    pid = int(pid_m.group(1)) if pid_m else None
    return {
        "loaded": True,
        "running": pid is not None,
        "status": "running" if pid is not None else "loaded",
        "pid": pid,
        "last_exit_code": int(exit_m.group(1)) if exit_m else None,
    }


def _status_row(spec: ServiceSpec, runner: Runner) -> dict[str, Any]:
    """Одна строка статуса сервиса (launchd — по launchctl; mcp — эвристикой)."""
    row: dict[str, Any] = {
        "key": spec.key,
        "label": spec.label,
        "kind": spec.kind,
        "control": spec.control,
        "plist_label": spec.plist_label,
    }
    if spec.kind == KIND_MCP:
        # Вызов пришёл в этот процесс → сервер жив. Код кэшируется до рестарта
        # хоста — честная подпись, а не фейковая кнопка рестарта.
        row.update(
            {
                "loaded": None,
                "running": True,
                "status": "running",
                "pid": None,
                "last_exit_code": None,
                "note": (
                    f"MCP-сервер управляется {_host_phrase()} — статус только; "
                    "полный ребут = рестарт хоста"
                ),
            }
        )
        return row
    row.update(_launchd_status(spec, runner))
    row["note"] = None
    if spec.key == "sync.index":
        row["last_run"] = _night_chain_brief()
    return row


def _night_chain_brief() -> dict[str, Any] | None:
    """NIGHT-CHAIN-1: время последнего ночного прогона по шагам - та же функция чтения, что у
    доктора «Ночная цепочка» (:mod:`core.nightchain`); нет данных/сбой чтения - ``None``."""
    try:
        from core import nightchain

        return nightchain.brief(mode="index")
    except Exception:  # noqa: BLE001 — мониторинг не падает из-за маяка
        return None


def _host_phrase() -> str:
    """«MCP-хостом» либо «MCP-хостом <имя>» — имя берется из handshake, а не зашито в код."""
    from core.host import SURFACE_MCP, UNKNOWN_HOST, current_host

    h = current_host()
    if h["surface"] == SURFACE_MCP and h["name"] != UNKNOWN_HOST:
        return f"MCP-хостом ({h['name']})"
    return "MCP-хостом"


def service_status(
    key: str = "all", *, runner: Runner | None = None
) -> list[dict[str, Any]] | dict[str, Any]:
    """Статус одного сервиса или всех (``key="all"``). Read-only, без гарда.

    ``key="all"`` → список строк в порядке :data:`SERVICES`; конкретный ключ →
    одна строка (неизвестный ключ → :class:`ValueError`). Каждая строка:
    ``{key, label, kind, control, plist_label, loaded, running, status
    (running|loaded|stopped), pid, last_exit_code, note}``. launchd читается
    ``launchctl list`` (через инжектируемый ``runner``); mcp — эвристикой живости.
    """
    run = runner or _default_runner
    specs, by_key = registry()
    if key == "all":
        return [_status_row(spec, run) for spec in specs]
    spec = _spec(key)
    if spec is None:
        raise ValueError(f"unknown service {key!r}; known: {', '.join(by_key)}")
    return _status_row(spec, run)


def _control_argv(spec: ServiceSpec, action: str, uid: int) -> list[str]:
    """``launchctl``-argv для мутации launchd-сервиса (тот же паттерн, что
    ``pult_web_restart`` для restart).

    start → ``bootstrap gui/<uid> <plist>``; stop → ``bootout gui/<uid>/<label>``;
    restart → ``kickstart -k gui/<uid>/<label>`` (``-k`` = kill+restart).
    """
    domain = f"gui/{uid}"
    target = f"{domain}/{spec.plist_label}"
    if action == "start":
        return ["launchctl", "bootstrap", domain, str(_plist_path(spec))]
    if action == "stop":
        return ["launchctl", "bootout", target]
    # restart
    return ["launchctl", "kickstart", "-k", target]


def _drop_monitor_snapshot() -> None:
    """Статус сервисов в ``pult_monitor`` живет в снимке (TTL 60 с): после start/stop сбросить."""
    try:
        from core.operational.snapshot import invalidate

        invalidate("monitor-services")
    except Exception:  # noqa: BLE001, S110 - сброс снимка не должен ломать управление сервисом
        pass


def service_control(
    key: str,
    action: str,
    *,
    runner: Runner | None = None,
    uid: int | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Мутация сервиса — start/stop/restart. Явный ``action`` = гард; аудит всегда.

    launchd (``control="full"``) → строит верный ``launchctl`` и зовёт через
    ``runner``; ``status_only`` (mcp) → :class:`ServiceControlError` («управляется
    MCP-хостом»), никакой команды не выполняется. Возврат
    ``{ok, key, action, cmd, returncode, error?}``. Любая мутация журналируется в
    ``pult-actions.log`` (только ключ+действие+исход, без содержимого).
    """
    if action not in SERVICE_ACTIONS:
        raise ValueError(
            f"unsupported action {action!r}; use {' | '.join(SERVICE_ACTIONS)}"
        )
    spec = _spec(key)
    if spec is None:
        raise ValueError(f"unknown service {key!r}; known: {', '.join(registry()[1])}")

    audit = {"key": spec.key, "action": action}  # алиас в аудит приходит каноническим ключом
    if spec.control != CONTROL_FULL:
        record_action("pult_service_control", audit, "refused", now=now)
        raise ServiceControlError(
            f"Сервис «{spec.label}» управляется {_host_phrase()} — start/stop/restart "
            "кнопкой невозможен (полный ребут = рестарт хоста). Доступен только статус."
        )

    run = runner or _default_runner
    resolved_uid = uid if uid is not None else os.getuid()
    cmd = _control_argv(spec, action, resolved_uid)
    result = run(cmd)
    ok = result.returncode == 0
    record_action("pult_service_control", audit, "ok" if ok else "error", now=now)
    _drop_monitor_snapshot()  # карточка «Движок» (pult_monitor) не должна показывать прежний статус
    out: dict[str, Any] = {
        "ok": ok,
        "key": spec.key,
        "action": action,
        "cmd": cmd,
        "returncode": result.returncode,
    }
    if not ok:
        out["error"] = (
            result.stderr.strip()[:200]
            or f"launchctl {action} завершился кодом {result.returncode}"
        )
    return out
