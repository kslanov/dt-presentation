"""Снимки тяжёлых чтений пульта (PULT-SURFACE-2 п.1) — один механизм «читаем файл, считаем редко».

Принцип (``docs/02-architecture.md`` §10a): read-инструмент пульта НЕ считает тяжёлое (доктор, скан
NDA-следов по ``.derived``, реранкер, обход vault) на каждый показ — он читает снимок. Расчёт делает
ночная цепочка, явный ``refresh=True`` (кнопка «Проверить живьём») либо истёкший TTL.

``cached_read(key, ttl_s, compute, refresh=…) -> (payload, meta)``: файл
``.derived/status/cache/<key>.json`` = ``{as_of, elapsed_ms, stamp?, payload}``. Расчёт под локом
(поток + flock): параллельные вызовы дают ОДИН расчёт, остальные берут свежий файл. Битый/чужой
файл — пересчёт без падения; сбой записи снимка не роняет ответ (``cached: false``, расчёт отдан).
"""

from __future__ import annotations

import fcntl
import json
import logging
import os
import threading
import time
from collections.abc import Callable
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "cache_dir", "cache_path", "cached_read", "read_cached", "write_cache", "invalidate",
    "ttl_from_env", "Meta",
]

Meta = dict[str, Any]
_STAMP_FMT = "%Y-%m-%dT%H:%M:%SZ"
_LOCKS: dict[str, threading.Lock] = {}
_LOCKS_GUARD = threading.Lock()


def cache_dir() -> Path:
    """``.derived/status/cache/`` (следует за ``DT_STATUS_DIR``/``DT_DERIVED_ROOT``)."""
    from core.config import status_dir

    return status_dir() / "cache"


def _safe(key: str) -> str:
    return "".join(c if (c.isalnum() or c in "-_.") else "_" for c in str(key)) or "_"


def cache_path(key: str) -> Path:
    return cache_dir() / f"{_safe(key)}.json"


def ttl_from_env(var: str, default: int) -> int:
    """TTL из окружения, секунды; мусор/неположительное → ``default``."""
    raw = (os.environ.get(var) or "").strip()
    return int(raw) if raw.isdigit() and int(raw) > 0 else default


def _now_stamp(now: datetime | None = None) -> str:
    return (now or datetime.now(UTC)).strftime(_STAMP_FMT)


def _parse(ts: Any) -> float | None:
    try:
        return datetime.strptime(str(ts), _STAMP_FMT).replace(tzinfo=UTC).timestamp()
    except ValueError:
        return None


def _load(key: str) -> dict[str, Any] | None:
    """Снимок как есть или ``None`` (нет файла / битый / без ``as_of``/``payload``)."""
    try:
        body = json.loads(cache_path(key).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(body, dict) or "payload" not in body or _parse(body.get("as_of")) is None:
        return None
    return body


def _meta(body: dict[str, Any], *, cached: bool, now: float | None = None) -> Meta:
    ts = _parse(body.get("as_of"))
    age = max(0.0, (now if now is not None else time.time()) - ts) if ts is not None else None
    return {"as_of": body["as_of"], "cached": cached,
            "elapsed_ms": int(body.get("elapsed_ms") or 0),
            "age_s": None if age is None else round(age)}


def read_cached(key: str) -> tuple[Any, Meta] | None:
    """Последний снимок БЕЗ расчёта: ``(payload, meta)`` либо ``None`` (снимка нет/битый).

    Для read-инструментов, которым нельзя считать ничего (``pult_monitor``): «нет данных» — честный
    ответ вызывающему, а не повод запустить доктор."""
    body = _load(key)
    return None if body is None else (body["payload"], _meta(body, cached=True))


def write_cache(
    key: str, payload: Any, *, elapsed_ms: int = 0, stamp: Any = None, now: datetime | None = None
) -> bool:
    """Записать снимок атомарно (tmp + replace). ``False`` — не записался (в лог, не наружу)."""
    target = cache_path(key)
    body: dict[str, Any] = {"as_of": _now_stamp(now), "elapsed_ms": int(elapsed_ms)}
    if stamp is not None:
        body["stamp"] = stamp
    body["payload"] = payload
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_suffix(f".{os.getpid()}.{threading.get_ident()}.tmp")
        tmp.write_text(json.dumps(body, ensure_ascii=False, default=str), encoding="utf-8")
        tmp.replace(target)
    except (OSError, TypeError, ValueError) as exc:
        logger.warning("снимок %s не записан: %s", key, exc)
        return False
    return True


def invalidate(prefix: str) -> int:
    """Удалить снимки, чей ключ начинается с ``prefix`` (после действия, меняющего данные)."""
    removed = 0
    try:
        files = list(cache_dir().glob(f"{_safe(prefix)}*.json"))
    except OSError:
        return 0
    for path in files:
        try:
            path.unlink()
            removed += 1
        except OSError:
            continue
    return removed


@contextmanager
def _lock(key: str):
    with _LOCKS_GUARD:
        guard = _LOCKS.setdefault(_safe(key), threading.Lock())
    with guard:
        handle = None
        try:
            cache_dir().mkdir(parents=True, exist_ok=True)
            handle = open(cache_dir() / f"{_safe(key)}.lock", "w")
            fcntl.flock(handle, fcntl.LOCK_EX)
        except OSError:
            handle = None  # без межпроцессного лока: поточный уже держим
        try:
            yield
        finally:
            if handle is not None:
                try:
                    fcntl.flock(handle, fcntl.LOCK_UN)
                finally:
                    handle.close()


def _fresh(body: dict[str, Any] | None, ttl_s: float, stamp: Any, now: float) -> bool:
    if body is None or ttl_s <= 0:
        return False
    if stamp is not None and body.get("stamp") != stamp:
        return False
    ts = _parse(body.get("as_of"))
    return ts is not None and 0 <= now - ts < ttl_s


def cached_read(
    key: str,
    ttl_s: float,
    compute: Callable[[], Any],
    *,
    refresh: bool = False,
    stamp: Any = None,
) -> tuple[Any, Meta]:
    """``(payload, meta)``: снимок в пределах TTL, иначе (или при ``refresh``) пересчёт и запись.

    ``stamp`` — токен «от чего зависит снимок» (например, mtime файла-источника): отличается от
    записанного → снимок устарел раньше TTL. ``meta = {as_of, cached, elapsed_ms, age_s}``.
    Исключение ``compute`` уходит наружу (снимок не затирается мусором)."""
    if not refresh and _fresh(_load(key), ttl_s, stamp, time.time()):
        body = _load(key)
        if body is not None:
            return body["payload"], _meta(body, cached=True)
    with _lock(key):
        # Двойная проверка: пока ждали лок, другой вызов мог уже посчитать.
        if not refresh:
            body = _load(key)
            if _fresh(body, ttl_s, stamp, time.time()) and body is not None:
                return body["payload"], _meta(body, cached=True)
        started = time.perf_counter()
        payload = compute()
        elapsed_ms = int((time.perf_counter() - started) * 1000)
        now = datetime.now(UTC)
        write_cache(key, payload, elapsed_ms=elapsed_ms, stamp=stamp, now=now)
        return payload, {"as_of": _now_stamp(now), "cached": False, "elapsed_ms": elapsed_ms,
                         "age_s": 0}
