"""PULT-STORAGE — контур «Хранилище»: источники ingest, здоровье БД/NDA, действия, пути.

Тонкий core-слой (принцип 12 — реюз, не дублирование) под MCP-инструменты
``pult_ingest_sources`` / ``pult_storage_status`` / ``pult_storage_action`` /
``pult_paths_get`` / ``pult_paths_set`` (ТЗ ``docs/tz/pult-storage-contour.md``).
``mcp-server`` остаётся тонкой обёрткой — инвариант ``core/`` ⊥ mcp/cli держится
(этот модуль импортирует только ``core`` + stdlib/yaml).

Реюз:

* ingest идёт через **JOB-1** (``core.orchestration.jobs`` ``ingest_*`` ops) —
  здесь только СПИСОК источников со статусом (конфиг + существование пути);
* здоровье — те же вызовы, что ``core.diagnostics`` (``core.db`` schema/counts,
  NDA-маркеры, INGEST-DEDUP byte-hash coverage) + ``core.eventlog.stage_counts``;
* действия — деструктив (rebuild-db/purge-nda) за ``confirm`` + аудит
  ``record_action``; превью/скан read-only свободно; backfill-hashes — через JOB-1;
* пути — ``ingest-roots.yaml`` (``.bak`` + валидация) и **только** ключ
  ``DT_LEGACY_ROOTS`` в ``engine/.env`` (прочие секреты не трогаем), за веб-токеном.

Path B: без сети/LLM (кроме того, что делает сам ingest-воркер JOB-1). Детерминизм.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

__all__ = [
    "DESTRUCTIVE_ACTIONS",
    "INGEST_OPS",
    "STORAGE_ACTIONS",
    "PathsError",
    "StorageActionError",
    "ingest_sources",
    "paths_get",
    "paths_set",
    "storage_action",
    "storage_status",
]

# Источник ingest → JOB-1 op (submit_job этим op'ом с {mode: light|full}). INGRESS-1 п.1: таблица
# ПРОИЗВОДНАЯ от реестра адаптеров (``core.ingress.registry``), отдельной копии здесь нет.
INGEST_OPS: dict[str, str] = {}


def _rebuild_ops() -> None:
    from core.ingress import registry

    INGEST_OPS.clear()
    INGEST_OPS.update(registry.ingest_ops())


def _subscribe_registry() -> None:
    from core.ingress import registry

    registry.subscribe(_rebuild_ops)
    _rebuild_ops()


_subscribe_registry()


def _last_ingest_ts() -> str | None:
    """ts последнего ingest-события (PULT-EVENTLOG), None при отсутствии/сбое."""
    try:
        from core.eventlog import recent_events

        rows = recent_events(limit=1, stage="ingest")
        return rows[0].ts if rows else None
    except Exception:  # noqa: BLE001 — витрина не критична
        return None


def _refusals_summary() -> dict[str, Any] | None:
    """Сводка журнала отказов за 7 дн; нечитаемый журнал → ``None`` (честно «неизвестно»)."""
    try:
        from core.contract import CODE_STORE_UNAVAILABLE, has_warning
        from core.ingress.refusals import refusals_summary

        out = refusals_summary(7)
        return None if has_warning(out, CODE_STORE_UNAVAILABLE) else out
    except Exception:  # noqa: BLE001 — витрина не критична
        return None


def _attach_ocr(sources: list[dict[str, Any]]) -> None:
    """OCR-1: ``ocr`` строкам файловых источников (знаниевые корни -> current, легаси -> legacy).

    Манифест не прочитался -> ``null`` («не знаем» ≠ «сканов нет»)."""
    try:
        from core.ocr.state import source_row
    except Exception:  # noqa: BLE001 — сводка OCR не ломает панель
        return
    cache: dict[str, dict[str, Any] | None] = {}
    for row in sources:
        layer = ("current" if row.get("adapter") == "files:knowledge"
                 else "legacy" if row.get("adapter") == "legacy" else "")
        if not layer:
            continue
        if layer not in cache:
            cache[layer] = source_row(layer)
        row["ocr"] = cache[layer]


def _attach_refusals(row: dict[str, Any], summary: dict[str, Any] | None) -> None:
    adapter = row.get("adapter")
    if summary is None:
        row["refused_7d"] = None
        row["refused_last"] = None
        return
    row["refused_7d"] = dict(summary["by_adapter"].get(adapter, {}))
    row["refused_last"] = list(summary["last_by_adapter"].get(adapter, []))


def ingest_sources(vault_path: Path | None = None) -> list[dict[str, Any]]:
    """Список источников ingest со статусом для панели «Хранилище» (PART-1).

    Собирает: сконфигурированные ingest-roots (operational/knowledge из
    ``ingest-roots.yaml``) + фиксированные источники legacy/mail/capture. По
    каждому — ``{key, kind, label, op, path?/roots?, exists, include?, exclude?}``.
    ``op`` — какой JOB-1 op запускает источник (``submit_job(op, {mode, root?})``).
    ``exists`` — существует ли путь на этом устройстве (iCloud dataless → путь есть,
    но dataless; полноценный dataless/pending считает light-скан). Read-only.
    """
    from core.file_ingest import load_ingest_roots
    from core.ingress import registry
    from core.instance import instance_role

    role = instance_role()  # PERSONAL-3: источники по роли экземпляра (реестр адаптеров)
    allowed = {a.key for a in registry.adapters(role=role)}
    last_ingest = _last_ingest_ts()
    sources: list[dict[str, Any]] = []
    summary = _refusals_summary()

    for root in load_ingest_roots(vault_path):
        if f"files:{root.route}" not in allowed:
            continue
        sources.append(
            {
                "key": f"root:{root.name}",
                "kind": root.route,  # operational | knowledge
                "label": root.name,
                "op": INGEST_OPS[root.route],
                "root": root.name,
                "path": str(root.path),
                "exists": root.path.exists(),
                "include": list(root.include),
                "exclude": list(root.exclude),
                "last_ingest": last_ingest,
                "adapter": f"files:{root.route}",
            }
        )

    # Фиксированные источники (легаси / почта / захваты / новые адаптеры) — из РЕЕСТРА адаптеров.
    fixed = sorted(
        (a for a in registry.adapters(role=role) if a.storage_row and a.ingest_key and a.op),
        key=lambda a: (a.storage_order, a.key),
    )
    for adapter in fixed:
        row: dict[str, Any] = {
            "key": adapter.ingest_key,
            "kind": adapter.ingest_key,
            "label": adapter.label,
            "op": adapter.op,
        }
        extra = adapter.storage_extra() if adapter.storage_extra else {"exists": True}
        row.update(extra)  # мост/OAuth проверяются при запуске: ``exists: True`` по умолчанию
        row["last_ingest"] = last_ingest
        row["adapter"] = adapter.key
        sources.append(row)
    # OCR-1 п.5: строки файловых источников += ocr {pending, done, low, refused} (из манифестов).
    _attach_ocr(sources)
    # INGRESS-1 п.4: отказы входа за 7 дн на источник. Счетчики — по АДАПТЕРУ (корни одного
    # маршрута делят адаптер и повторяют его цифры); журнал не прочитался → ``null``, не ``{}``.
    for row in sources:
        _attach_refusals(row, summary)
    return sources


def storage_status() -> dict[str, Any]:
    """Здоровье хранилища одним вызовом для виджета «Хранилище» (PART-2).

    Read-only, реюз тех же источников, что ``dt doctor``:

    * ``db`` — DB-1: ``schema_version`` + счётчики facts/sources/jobs/events;
    * ``nda`` — NDA-1: маркеры + сколько NDA-следов сейчас в derived (что отсёк бы
      purge) — по одному скану ``core.nda_purge.scan_nda_traces`` (read-only);
    * ``dedup`` — INGEST-DEDUP: byte-hash coverage ``with_hash/total`` легаси-манифеста;
    * ``eventlog`` — PULT-EVENTLOG: счётчики событий по стадиям;
    * ``lance`` — WAVE0-HYGIENE: версии/фрагменты/ГБ каталога LanceDB + статус по порогам.

    Любой блок деградирует в ``{error: …}`` вместо падения (виджет частичен, не пуст).
    """
    return {
        "db": _db_block(),
        "nda": _nda_block(),
        "dedup": _dedup_block(),
        "eventlog": _eventlog_block(),
        "lance": _lance_block(),
    }


def _lance_block() -> dict[str, Any]:
    """WAVE0-HYGIENE п.1: плитка «LanceDB» — версии/фрагменты/ГБ + вердикт по порогам."""
    try:
        from core.retrieval.lance_health import (
            lance_health,
            lance_health_verdict,
            warn_thresholds,
        )

        health = lance_health()
        status, detail = lance_health_verdict(health)
        max_versions, max_gb = warn_thresholds()
        return {
            "exists": health["exists"],
            "versions": health["versions"],
            "fragments": health["fragments"],
            "versions_gb": health["versions_gb"],
            "data_gb": health["data_gb"],
            "indices": health["indices"],
            "total_gb": health["total_gb"],
            "status": status,
            "detail": detail,
            "warn_versions": max_versions,
            "warn_versions_gb": max_gb,
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:200]}


def _db_block() -> dict[str, Any]:
    try:
        from core.config import dt_db_path
        from core.db import schema_version, table_counts
        from core.eventlog import stage_counts

        path = dt_db_path()
        counts = table_counts(path)
        stages = stage_counts()
        block = {
            "schema_version": schema_version(path),
            "facts": counts.get("facts", 0),
            "sources": counts.get("sources", 0),
            "jobs": counts.get("jobs", 0),
            "events": stages.get("total", 0),
            "path": str(path),
            "exists": path.is_file(),
        }
        # CONTRACT-2 С20: ноль событий внутри «успешного» блока врал, что их нет —
        # сбой чтения журнала обязан быть виден так же, как ошибки соседних блоков.
        if stages.get("error"):
            block["events"] = None
            block["events_error"] = str(stages["error"])[:200]
        return block
    except Exception as exc:  # noqa: BLE001 — витрина не падает
        return {"error": str(exc)[:200]}


def _nda_block() -> dict[str, Any]:
    try:
        from core.config import nda_markers
        from core.nda_purge import scan_nda_traces

        scan = scan_nda_traces()
        return {
            "markers": nda_markers(),
            "sources_flagged": scan["source_count"],
            "facts_flagged": scan["facts_count"],
        }
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:200]}


def _dedup_block() -> dict[str, Any]:
    try:
        from core.legacy.ingest import manifest_hash_coverage

        # DOCTOR-HONEST-1: покрытие считается по ЖИВЫМ исходникам; исчезнувшие с диска
        # идут отдельным числом (недостижимый backfill — не дыра в покрытии).
        with_hash, total, missing = manifest_hash_coverage()
        pct = round(100 * with_hash / total) if total else 100
        return {"with_hash": with_hash, "total": total, "coverage_pct": pct,
                "missing_sources": missing}
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:200]}


def _eventlog_block() -> dict[str, Any]:
    try:
        from core.eventlog import stage_counts

        return stage_counts()
    except Exception as exc:  # noqa: BLE001
        return {"error": str(exc)[:200]}


# --------------------------------------------------------------------------- #
# PART-3 — действия хранилища (gated, деструктив за confirm + аудит)           #
# --------------------------------------------------------------------------- #
STORAGE_ACTIONS = ("rebuild-db", "purge-nda", "backfill-hashes")
DESTRUCTIVE_ACTIONS = ("rebuild-db", "purge-nda")


class StorageActionError(RuntimeError):
    """Некорректное действие/аргумент действия хранилища."""


def _db_files() -> list[Path]:
    """Файлы единой БД (``dt.db`` + WAL/SHM) — что снесёт rebuild-db."""
    from core.config import dt_db_path

    base = dt_db_path()
    return [base, Path(str(base) + "-wal"), Path(str(base) + "-shm")]


def storage_action(
    action: str,
    *,
    confirm: bool = False,
    submit: Any | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Действие над хранилищем — gated (PART-3).

    * ``rebuild-db`` / ``purge-nda`` — **деструктив**: без ``confirm`` возвращают
      read-only **превью** (что будет удалено; ничего не трогают — это и есть отказ
      мутации); с ``confirm=True`` выполняют и пишут аудит ``record_action``.
    * ``backfill-hashes`` — долгое, уходит в **JOB-1** (``submit_job`` через
      инжектируемый ``submit``), возвращает ``job_id``; аудит пишется.

    Неизвестное действие → :class:`StorageActionError`.
    """
    if action not in STORAGE_ACTIONS:
        raise StorageActionError(
            f"unknown action {action!r}; use {' | '.join(STORAGE_ACTIONS)}"
        )
    if action == "rebuild-db":
        return _action_rebuild_db(confirm=confirm, now=now)
    if action == "purge-nda":
        return _action_purge_nda(confirm=confirm, now=now)
    return _action_backfill_hashes(submit=submit, now=now)


def _action_rebuild_db(*, confirm: bool, now: str | None) -> dict[str, Any]:
    files = [f for f in _db_files() if f.is_file()]
    if not confirm:
        return {
            "action": "rebuild-db",
            "confirm_required": True,
            "destructive": True,
            "preview": {"files": [str(f) for f in files]},
            "note": "Снесёт dt.db (+WAL/SHM) — пересоберётся при первом обращении "
                    "(facts/sources/jobs/events derivable). Подтверди confirm=True.",
        }
    from core.operational.pult import record_action

    removed: list[str] = []
    failed: list[dict[str, str]] = []
    for f in files:
        try:
            f.unlink()
            removed.append(str(f))
        except OSError as exc:
            # CONTRACT-2 С10: не удалившийся файл молча выпадал, а ответ говорил
            # ok:true — «БД пересобрана» при живой заблокированной БД.
            failed.append({"path": str(f), "error": str(exc)[:160]})
    record_action(
        "pult_storage_action",
        {"action": "rebuild-db", "removed": len(removed), "failed": len(failed)},
        "partial" if failed else "ok", now=now,
    )
    out: dict[str, Any] = {
        "action": "rebuild-db", "ok": not failed, "removed": removed,
    }
    if failed:
        from core.contract import CODE_PARTIAL, add_warning

        out["failed"] = failed
        add_warning(
            out, CODE_PARTIAL,
            "не удалось удалить: "
            + ", ".join(f"{f['path']} ({f['error']})" for f in failed[:3])
            + " — БД пересобрана НЕ полностью (файл занят? останови службы движка)",
            failed=len(failed),
        )
    return out


def _action_purge_nda(*, confirm: bool, now: str | None) -> dict[str, Any]:
    from core.nda_purge import purge_nda_traces, scan_nda_traces

    if not confirm:
        scan = scan_nda_traces()
        return {
            "action": "purge-nda",
            "confirm_required": True,
            "destructive": True,
            "preview": {
                "source_count": scan["source_count"],
                "facts_count": scan["facts_count"],
            },
            "note": "Удалит NDA-следы из derived (кэш/реестр/facts) — vault не "
                    "трогается. Подтверди confirm=True.",
        }
    from core.operational.pult import record_action

    removed = purge_nda_traces()
    record_action("pult_storage_action", {"action": "purge-nda"}, "ok", now=now)
    return {"action": "purge-nda", "ok": True, "removed": removed}


def _action_backfill_hashes(*, submit: Any | None, now: str | None) -> dict[str, Any]:
    from core.operational.pult import record_action

    submitter: Any = submit
    if submitter is None:
        from core.orchestration.jobs import submit as _submit

        submitter = _submit
    job_id = submitter("backfill_hashes", {})
    record_action("pult_storage_action", {"action": "backfill-hashes"}, "submitted", now=now)
    return {
        "action": "backfill-hashes",
        "job_id": job_id,
        "op": "backfill_hashes",
        "state": "queued",
    }


# --------------------------------------------------------------------------- #
# PART-4 — настройки путей (editable, за веб-токеном + .bak + валидация)        #
# --------------------------------------------------------------------------- #
class PathsError(ValueError):
    """Невалидная схема путей / отказ по токену при записи конфига."""


def paths_get(vault_path: Path | None = None) -> dict[str, Any]:
    """Текущие корни ingest + legacy для редактора путей (read-only, PART-4).

    ``{roots: [{name, path (resolved per-device), route, include, exclude,
    note_type, entity_hint}], legacy_roots: [str], roots_yaml: str,
    editable: bool}``. ``editable`` всегда ``True`` (PULT-TOKEN-UX): это локальный
    пульт владельца; авторизация — на границе транспорта (сетевой веб-пульт гейтит
    HTTP-токеном в ``webpult/server.py::_authorized``; доверенный десктопный
    MCP-транспорт её не дублирует). Резолв путей per-device уже применён
    (``DT_INGEST_ROOT_<NAME>``-оверрайды учтены в ``path``).
    """
    from core.config import ingest_roots_path, legacy_roots
    from core.file_ingest import load_ingest_roots
    from core.instance import is_personal

    roots = [r.to_dict() for r in load_ingest_roots(vault_path)]
    return {
        "roots": roots,
        # PERSONAL-2: legacy-корни - ключ РАБОЧЕГО engine/.env; у личного экземпляра их нет
        "legacy_roots": [] if is_personal() else [str(p) for p in legacy_roots()],
        "roots_yaml": str(ingest_roots_path(vault_path)),
        "editable": True,
    }


def _validate_roots(roots: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Проверить схему корней (name/route∈ROUTES/globs). Невалидное → PathsError."""
    from core.file_ingest.config import ROUTES

    cleaned: list[dict[str, Any]] = []
    seen: set[str] = set()
    for i, entry in enumerate(roots):
        if not isinstance(entry, dict):
            raise PathsError(f"root #{i}: должен быть объектом")
        name = str(entry.get("name", "")).strip()
        path = str(entry.get("path", "")).strip()
        route = str(entry.get("route", "")).strip().lower()
        if not name:
            raise PathsError(f"root #{i}: пустой name")
        if name in seen:
            raise PathsError(f"root {name!r}: дублирующееся имя")
        seen.add(name)
        if not path:
            raise PathsError(f"root {name!r}: пустой path")
        if route not in ROUTES:
            raise PathsError(
                f"root {name!r}: route {route!r} не из {sorted(ROUTES)}"
            )
        item: dict[str, Any] = {"name": name, "path": path, "route": route}
        for key in ("include", "exclude"):
            val = entry.get(key)
            if val is None:
                continue
            if not isinstance(val, list) or not all(isinstance(g, str) for g in val):
                raise PathsError(f"root {name!r}: {key} должен быть списком строк (globs)")
            if val:
                item[key] = val
        for key in ("note_type", "entity_hint"):
            if entry.get(key):
                item[key] = str(entry[key]).strip()
        cleaned.append(item)
    return cleaned


def _write_roots_yaml(roots: list[dict[str, Any]], vault_path: Path | None) -> str:
    """Записать ``ingest-roots.yaml`` с ``.bak`` предыдущего. Возврат — путь."""
    import yaml  # type: ignore[import-untyped]

    from core.config import ingest_roots_path

    target = ingest_roots_path(vault_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file():
        bak = target.with_name(target.name + ".bak")
        bak.write_text(target.read_text(encoding="utf-8"), encoding="utf-8")
    target.write_text(
        yaml.safe_dump({"roots": roots}, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    return str(target)


def _set_env_key(key: str, value: str) -> None:
    """Обновить/добавить ОДИН ключ в ``engine/.env``, не трогая прочие байты файла.

    CONFIG-1: единственный писатель ``.env`` - :mod:`core.config.env_file` (комментарии и прочие
    ключи как есть, бэкап ``.env.bak-<ts>`` только при изменении, права 600, повтор - без записи).
    """
    from core.config import engine_env_path
    from core.config import env_file as _env_file

    _env_file.set_key(engine_env_path(), key, value)


def paths_set(
    *,
    roots: list[dict[str, Any]] | None = None,
    legacy_roots: list[str] | None = None,
    token: str | None = None,
    vault_path: Path | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Записать конфиг путей (PART-4; PULT-TOKEN-UX — без токен-гейта). Только конфиг.

    Авторизация — на **границе транспорта**, не здесь: сетевой веб-пульт гейтит
    каждый ``POST /api/`` HTTP-токеном (``webpult/server.py::_authorized``);
    доверенный десктопный MCP-транспорт её не дублирует. Поэтому собственного
    токен-гейта у инструмента больше нет (снят ложный барьер, дававший трение на
    десктопе). ``token`` принимается для обратной совместимости старых вызовов и
    **игнорируется**. Затем:

    * ``roots`` (если задан) — валидация схемы (name/route∈{operational,knowledge}/
      globs; невалидное → :class:`PathsError`), запись ``ingest-roots.yaml`` с
      ``.bak``; несуществующий путь — **warning**, не отказ (iCloud dataless);
    * ``legacy_roots`` (если задан) — правит **только** ключ ``DT_LEGACY_ROOTS`` в
      ``engine/.env`` (``:``-joined), прочие строки/секреты целы, бэкап ``.env.bak-<ts>``.

    Пишет ``record_action``. В vault-контент не пишет никогда. Возврат —
    ``{ok, roots_written?, roots_yaml?, legacy_written?, warnings}``.
    """
    from core.instance import is_personal
    from core.operational.pult import record_action

    if legacy_roots is not None and is_personal():
        raise PathsError("legacy_roots - ключ рабочего engine/.env: у личного экземпляра не "
                         "правится (корни личного vault - roots)")
    out: dict[str, Any] = {"ok": True, "warnings": []}
    if roots is not None:
        cleaned = _validate_roots(roots)
        out["roots_yaml"] = _write_roots_yaml(cleaned, vault_path)
        out["roots_written"] = len(cleaned)
        for item in cleaned:
            resolved = Path(os.path.expanduser(os.path.expandvars(item["path"])))
            if not resolved.exists():
                out["warnings"].append(
                    f"root {item['name']!r}: путь не существует сейчас "
                    f"({item['path']}) — iCloud dataless? записано всё равно"
                )
    if legacy_roots is not None:
        _set_env_key("DT_LEGACY_ROOTS", ":".join(str(p) for p in legacy_roots))
        # чтобы последующий legacy_roots() в этом же процессе увидел новое значение
        os.environ["DT_LEGACY_ROOTS"] = ":".join(str(p) for p in legacy_roots)
        out["legacy_written"] = len(legacy_roots)

    record_action(
        "pult_paths_set",
        {
            "roots": out.get("roots_written", 0),
            "legacy": out.get("legacy_written", 0),
        },
        "ok",
        now=now,
    )
    return out
