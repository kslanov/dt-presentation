"""Порционная запись файла — ФТ-5 (FT-5): бинарь частями ниже порога отказов моста.

**Только для файлов без текстового источника** — xlsx с формулами, заполненный PDF,
изображения, произвольные бинарные вложения. У остального есть каналы дешевле:
скачал браузером → ``place_download`` (ФТ-1), текст есть → ``save_output(dest=…)``
собирает формат локально (ФТ-4). Обычный ``store_file`` остаётся для мелочи, которая
проходит одним параметром.

Ожидание по производительности из ФТ прямое: «быстро не станет». Цель — **предсказуемость
и отсутствие падений**: каждая часть заведомо меньше зоны отказов моста (29–39 КБ,
инцидент 04.08.2026), поэтому вместо одного сообщения, которое кладёт канал на минуты,
идёт N мелких, каждое из которых либо доехало, либо честно отказало.

Протокол (сессия живёт на диске, поэтому переживает рестарт сервера):

* :func:`begin` — **все гарды цели проверяются здесь** (корень/containment/NDA/
  существующий файл): fail-fast ДО передачи хоть одной части, чтобы не гонять
  мегабайты в папку, куда писать нельзя. Байт-идентичный файл уже на месте → сразу
  ``existed``, сессия не открывается вовсе. ``begin`` идемпотентен: повторный вызов с
  той же целью и тем же ``final_sha256`` возвращает **ту же** сессию с её прогрессом
  (id детерминирован) — так возобновление работает даже если ``session_id`` потерян;
* :func:`append` — части строго по порядку, каждая ≤ :func:`chunk_limit`
  (env ``DT_CHUNK_LIMIT``, дефолт 16 КБ). Часть не по порядку → отказ с
  ``expected_next``/``bytes_done``: **это и есть resume-протокол** (клиент узнаёт, с
  чего продолжать, из самого отказа). Каждая часть дописывается в ``.part`` с
  ``fsync`` — обрыв не теряет принятого;
* :func:`status` — принятые части и ожидаемое смещение (возобновление после обрыва);
* :func:`commit` — sha256 собранного файла сверяется с заявленным ``final_sha256``, и
  только потом атомарная подмена цели через общий write-слой. Не сошлось → ``.part``
  удаляется, цели не появляется вовсе;
* :func:`abort` + TTL незавершённых (env ``DT_CHUNK_SESSION_TTL_H``, дефолт 24 ч;
  чистка ленивая — на ``begin``/``status``/``list_sessions``, плюс строка в ``doctor``).

Сборка идёт в ``.derived/chunked/`` (:func:`core.config.chunk_sessions_dir`), **не в
клиентской папке**: недособранный файл там не должен быть виден ни секунды. В файле
состояния — только цель, смещения и размеры частей; **контента там нет** (данные — в
``.part``). Аудит: ``begin``/``commit``/``abort`` — по одной строке с метаданными;
``append`` не аудитится (см. решение в MCP-обёртке: он пишет только наш scratch, а
тысяча строк на одну доставку убила бы сигнал аудита).

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import json
import os
import re
import time
from pathlib import Path
from typing import Any

from core.config import chunk_sessions_dir
from core.file_ingest.write_target import (
    ABSENT,
    IDENTICAL,
    WriteTargetError,
    existing_disposition,
    resolve_write_target,
    sha256_file,
    write_atomic_stream,
)

__all__ = [
    "ChunkedStoreError",
    "begin",
    "append",
    "status",
    "commit",
    "abort",
    "list_sessions",
    "sweep_expired",
    "chunk_limit",
    "session_ttl_seconds",
    "DEFAULT_CHUNK_LIMIT",
    "DEFAULT_SESSION_TTL_H",
]

# Размер части по умолчанию: 16 КБ (в base64 ≈ 21,8 КБ строки) — заведомо ниже
# эмпирической зоны отказов моста 29–39 КБ И ниже порога диагностики FT-3 (32 КБ),
# так что штатная порционная доставка не сыплет предупреждениями «зона риска».
DEFAULT_CHUNK_LIMIT = 16 * 1024
_CHUNK_LIMIT_ENV = "DT_CHUNK_LIMIT"

# TTL незавершённой сессии: сутки. Дольше — это не «продолжу завтра», а мусор,
# занимающий место в .derived (чистится лениво, без отдельного демона).
DEFAULT_SESSION_TTL_H = 24.0
_TTL_ENV = "DT_CHUNK_SESSION_TTL_H"

_SHA_RE = re.compile(r"^[0-9a-f]{64}$")
_STATE_SUFFIX = ".json"
_DATA_SUFFIX = ".part"


class ChunkedStoreError(RuntimeError):
    """Отказ порционной записи: ``code`` — машинная причина, ``details`` — payload.

    В ``details`` кладём то, что нужно клиенту для продолжения (``expected_next``,
    ``bytes_done``, ``limit``) — отказ обязан быть действием, а не просто «нельзя».
    """

    def __init__(self, message: str, code: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.details: dict[str, Any] = details or {}


# --------------------------------------------------------------------------- #
# Конфигурация                                                                 #
# --------------------------------------------------------------------------- #


def chunk_limit() -> int:
    """Потолок размера одной части, байт (env ``DT_CHUNK_LIMIT``, дефолт 16 КБ)."""
    raw = os.environ.get(_CHUNK_LIMIT_ENV, "").strip()
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    return DEFAULT_CHUNK_LIMIT


def session_ttl_seconds() -> float:
    """TTL незавершённой сессии, сек (env ``DT_CHUNK_SESSION_TTL_H``, дефолт 24 ч)."""
    raw = os.environ.get(_TTL_ENV, "").strip()
    try:
        hours = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_SESSION_TTL_H * 3600.0
    return hours * 3600.0 if hours > 0 else DEFAULT_SESSION_TTL_H * 3600.0


# --------------------------------------------------------------------------- #
# Состояние сессии на диске (json + .part)                                     #
# --------------------------------------------------------------------------- #


def _session_id(root_name: str, rel_path: str, final_sha256: str) -> str:
    """Детерминированный id: (корень, путь, итоговый sha) → 16 hex.

    Детерминизм — не косметика: он делает ``begin`` идемпотентным и позволяет
    возобновить доставку, даже если ``session_id`` из ответа потерялся (чат оборвался).
    """
    key = f"{root_name}\0{rel_path}\0{final_sha256}".encode()
    return hashlib.sha256(key).hexdigest()[:16]


def _state_path(session_id: str) -> Path:
    return chunk_sessions_dir() / f"{session_id}{_STATE_SUFFIX}"


def _data_path(session_id: str) -> Path:
    return chunk_sessions_dir() / f"{session_id}{_DATA_SUFFIX}"


def _load_state(session_id: str) -> dict[str, Any] | None:
    path = _state_path(session_id)
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def _save_state(state: dict[str, Any]) -> None:
    """Атомарная запись состояния (обрыв на записи json не рушит сессию)."""
    path = _state_path(state["session_id"])
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _drop_session(session_id: str) -> None:
    _state_path(session_id).unlink(missing_ok=True)
    _data_path(session_id).unlink(missing_ok=True)


def _expired(state: dict[str, Any], *, now: float | None = None) -> bool:
    updated = float(state.get("updated") or 0.0)
    return (now or time.time()) - updated > session_ttl_seconds()


def _view(state: dict[str, Any], *, now: float | None = None) -> dict[str, Any]:
    """Публичный вид сессии: принятые части, ожидаемое смещение, остаток. Без контента."""
    parts = state.get("parts") or []
    bytes_done = int(state.get("bytes_done") or 0)
    total = int(state.get("total_size") or 0)
    ttl = session_ttl_seconds()
    return {
        "ok": True,
        "session_id": state["session_id"],
        "root_name": state["root_name"],
        "path": state["rel_path"],
        "received": len(parts),
        "expected_next": len(parts),
        # «ожидаемое смещение» из ФТ — сколько байт уже принято, с этого места продолжать
        "expected_offset": bytes_done,
        "bytes_done": bytes_done,
        "total_size": total,
        "remaining": max(0, total - bytes_done),
        "complete": bytes_done == total and total > 0,
        "chunk_limit": chunk_limit(),
        "final_sha256": state["final_sha256"],
        "overwrite": bool(state.get("overwrite")),
        "created": float(state.get("created") or 0.0),
        "updated": float(state.get("updated") or 0.0),
        "expires_in_s": max(0.0, float(state.get("updated") or 0.0) + ttl - (now or time.time())),
    }


def sweep_expired(*, now: float | None = None) -> int:
    """Удалить сессии, к которым не прикасались дольше TTL. Возвращает их число.

    Ленивая чистка (зовётся из :func:`begin`/:func:`status`/:func:`list_sessions`) —
    отдельный демон под это заводить не за что. Best-effort: сбой чистки не должен
    ломать текущую доставку.
    """
    directory = chunk_sessions_dir()
    if not directory.is_dir():
        return 0
    removed = 0
    for path in sorted(directory.glob(f"*{_STATE_SUFFIX}")):
        try:
            state = _load_state(path.stem)
        except OSError:  # pragma: no cover — glob дал путь, чтение упало
            continue
        if state is None:
            # битый/чужой json: считаем мусором, но данные не трогаем без состояния
            path.unlink(missing_ok=True)
            removed += 1
            continue
        if _expired(state, now=now):
            _drop_session(state.get("session_id", path.stem))
            removed += 1
    return removed


def list_sessions(*, now: float | None = None) -> list[dict[str, Any]]:
    """Все живые сессии (для ``doctor``/диагностики), свежие сверху. Без контента."""
    sweep_expired(now=now)
    directory = chunk_sessions_dir()
    if not directory.is_dir():
        return []
    out: list[dict[str, Any]] = []
    for path in directory.glob(f"*{_STATE_SUFFIX}"):
        state = _load_state(path.stem)
        if state is not None:
            out.append(_view(state, now=now))
    return sorted(out, key=lambda s: s["updated"], reverse=True)


# --------------------------------------------------------------------------- #
# Протокол                                                                     #
# --------------------------------------------------------------------------- #


def _require_session(session_id: str) -> dict[str, Any]:
    sid = str(session_id or "").strip()
    state = _load_state(sid) if sid else None
    if state is None:
        raise ChunkedStoreError(
            f"сессия не найдена: {session_id!r} — начните заново через store_file_begin",
            "unknown_session",
        )
    if _expired(state):
        _drop_session(sid)
        raise ChunkedStoreError(
            f"сессия истекла (TTL {session_ttl_seconds() / 3600:g} ч) и удалена: {sid} — "
            "начните заново через store_file_begin",
            "expired_session",
        )
    return state


def begin(
    root_name: str,
    rel_path: str,
    final_sha256: str,
    total_size: int,
    *,
    overwrite: bool = False,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Открыть (или возобновить) сессию порционной записи. Все гарды цели — здесь.

    Возврат: ``{ok, session_id, chunk_limit, expected_next, expected_offset, bytes_done,
    total_size, path, root_name, existed, resumed, …}``. Байт-идентичный файл уже на
    месте → ``{ok, existed: True, session_id: None}`` (передавать нечего). Отказ —
    :class:`ChunkedStoreError` (``bad_sha256``/``bad_total_size``/``unknown_root``/
    ``containment``/``nda``/``exists_differs``…).
    """
    from core.operational.pult import record_action

    sha = str(final_sha256 or "").strip().lower()
    if not _SHA_RE.match(sha):
        raise ChunkedStoreError(
            "final_sha256 должен быть 64 hex-символами (sha256 итогового файла)",
            "bad_sha256",
        )
    try:
        total = int(total_size)
    except (TypeError, ValueError):
        total = -1
    if total <= 0:
        raise ChunkedStoreError(
            f"total_size должен быть положительным числом байт: {total_size!r}",
            "bad_total_size",
        )

    # --- гарды цели ДО передачи частей (fail-fast) ----------------------------
    try:
        target = resolve_write_target(root_name, rel_path, vault_path=vault_path)
        disposition = existing_disposition(target.path, sha, label=target.rel_path)
    except WriteTargetError as exc:
        raise ChunkedStoreError(str(exc), exc.code, {"root_name": root_name}) from exc
    if disposition == IDENTICAL:
        # Идемпотентность: те же байты уже лежат — ни сессии, ни передачи (mtime цел).
        record_action(
            "store_file_begin",
            {"root": target.root_name, "rel_path": target.rel_path, "size": total,
             "sha256": sha[:12]},
            "existed",
        )
        return {
            "ok": True, "existed": True, "session_id": None,
            "path": target.rel_path, "root_name": target.root_name,
            "size": target.path.stat().st_size, "sha256": sha,
            "chunk_limit": chunk_limit(),
        }
    if disposition != ABSENT and not overwrite:
        raise ChunkedStoreError(
            f"файл существует и отличается: {target.rel_path} — нужен overwrite=True",
            "exists_differs",
            {"path": target.rel_path, "root_name": target.root_name},
        )

    sweep_expired()
    sid = _session_id(target.root_name, target.rel_path, sha)
    existing = _load_state(sid)
    if existing is not None and not _expired(existing):
        # Повторный begin той же цели — возобновление, а не сброс прогресса.
        # Право на перезапись берём из ТЕКУЩЕГО вызова (он и есть точка авторизации:
        # выше уже проверено, что при отличающейся цели без overwrite сюда не дойти).
        if bool(existing.get("overwrite")) != bool(overwrite):
            existing["overwrite"] = bool(overwrite)
            _save_state(existing)
        view = _view(existing)
        view["resumed"] = True
        view["existed"] = False
        return view

    _drop_session(sid)
    now = time.time()
    state = {
        "session_id": sid,
        "root_name": target.root_name,
        "rel_path": target.rel_path,
        "final_sha256": sha,
        "total_size": total,
        "overwrite": bool(overwrite),
        "parts": [],  # только индексы и размеры — контента в состоянии нет
        "bytes_done": 0,
        "created": now,
        "updated": now,
    }
    _data_path(sid).parent.mkdir(parents=True, exist_ok=True)
    _data_path(sid).write_bytes(b"")
    _save_state(state)
    record_action(
        "store_file_begin",
        {"root": target.root_name, "rel_path": target.rel_path, "size": total,
         "sha256": sha[:12], "session": sid},
        "opened",
    )
    view = _view(state, now=now)
    view["resumed"] = False
    view["existed"] = False
    return view


def append(session_id: str, part_index: int, content_b64: str) -> dict[str, Any]:
    """Принять часть ``part_index`` (base64) — строго следующую по порядку.

    Возврат ``{ok, session_id, received, expected_next, expected_offset, bytes_done,
    remaining, complete}``. Часть не по порядку → :class:`ChunkedStoreError`
    ``out_of_order`` c ``expected_next``/``bytes_done`` в ``details`` (клиент
    продолжает с нужного места — это и есть resume). Часть больше лимита →
    ``chunk_too_large``. Аудита здесь нет by design (пишем только свой scratch).
    """
    state = _require_session(session_id)
    try:
        index = int(part_index)
    except (TypeError, ValueError):
        index = -1
    expected = len(state.get("parts") or [])
    bytes_done = int(state.get("bytes_done") or 0)
    if index != expected:
        raise ChunkedStoreError(
            f"часть {part_index!r} не по порядку — ожидается {expected} "
            f"(принято байт: {bytes_done})",
            "out_of_order",
            {"expected_next": expected, "expected_offset": bytes_done,
             "bytes_done": bytes_done, "received": expected},
        )
    try:
        data = base64.b64decode("".join(str(content_b64).split()), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ChunkedStoreError(f"невалидный base64: {exc}", "bad_base64") from exc
    if not data:
        raise ChunkedStoreError("пустая часть — нечего дописывать", "empty_chunk")
    limit = chunk_limit()
    if len(data) > limit:
        raise ChunkedStoreError(
            f"часть больше лимита ({len(data)} > {limit} байт, env {_CHUNK_LIMIT_ENV})",
            "chunk_too_large",
            {"limit": limit, "size": len(data), "expected_next": expected},
        )
    total = int(state["total_size"])
    if bytes_done + len(data) > total:
        raise ChunkedStoreError(
            f"часть выходит за заявленный total_size ({bytes_done + len(data)} > {total})",
            "over_declared_size",
            {"expected_next": expected, "bytes_done": bytes_done, "total_size": total},
        )

    data_path = _data_path(state["session_id"])
    try:
        with data_path.open("ab") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())  # обрыв не должен терять принятое
    except OSError as exc:
        raise ChunkedStoreError(f"ошибка записи части: {exc}", "write_failed") from exc

    state["parts"] = [*(state.get("parts") or []), {"index": index, "size": len(data)}]
    state["bytes_done"] = bytes_done + len(data)
    state["updated"] = time.time()
    _save_state(state)
    view = _view(state)
    return {k: view[k] for k in ("ok", "session_id", "received", "expected_next",
                                 "expected_offset", "bytes_done", "remaining", "complete")}


def status(session_id: str) -> dict[str, Any]:
    """Состояние сессии: принятые части и ожидаемое смещение (возобновление, ФТ-5)."""
    sweep_expired()
    return _view(_require_session(session_id))


def commit(session_id: str, *, vault_path: Path | None = None) -> dict[str, Any]:
    """Сверить sha256 собранного файла и атомарно положить его в цель.

    Не сошлось (или собрано не всё) → :class:`ChunkedStoreError`, ``.part`` удаляется,
    в целевой папке не появляется ничего. Успех → ``{ok, path, root_name, size, sha256,
    parts, existed, overwritten}``, сессия закрыта.
    """
    from core.operational.pult import record_action

    state = _require_session(session_id)
    sid = state["session_id"]
    total = int(state["total_size"])
    bytes_done = int(state.get("bytes_done") or 0)
    parts = len(state.get("parts") or [])
    if bytes_done != total:
        raise ChunkedStoreError(
            f"собрано {bytes_done} из {total} байт — сессия не завершена",
            "incomplete",
            {"expected_next": parts, "bytes_done": bytes_done, "remaining": total - bytes_done},
        )
    data_path = _data_path(sid)
    if not data_path.is_file():
        _drop_session(sid)
        raise ChunkedStoreError(
            f"данные сессии {sid} исчезли с диска — начните заново", "data_missing"
        )
    actual = sha256_file(data_path)
    if actual != state["final_sha256"]:
        _drop_session(sid)  # tmp удалён, цель не тронута
        record_action(
            "store_file_commit",
            {"root": state["root_name"], "rel_path": state["rel_path"],
             "size": bytes_done, "parts": parts, "sha256": actual[:12]},
            "sha_mismatch",
        )
        raise ChunkedStoreError(
            f"sha256 собранного файла не совпал (заявлен {state['final_sha256'][:12]}…, "
            f"фактический {actual[:12]}…) — файл не записан, части удалены",
            "sha_mismatch",
            {"path": state["rel_path"]},
        )
    # Гарды перепроверяются на commit: между begin и commit цель могла появиться.
    try:
        target = resolve_write_target(
            state["root_name"], state["rel_path"], vault_path=vault_path
        )
        written = write_atomic_stream(
            target, data_path, overwrite=bool(state.get("overwrite")), sha256_hex=actual
        )
    except WriteTargetError as exc:
        raise ChunkedStoreError(str(exc), exc.code, {"path": state["rel_path"]}) from exc
    _drop_session(sid)
    record_action(
        "store_file_commit",
        {"root": target.root_name, "rel_path": written["path"], "size": written["size"],
         "parts": parts, "sha256": actual[:12], "overwritten": written["overwritten"]},
        "overwritten" if written["overwritten"] else "stored",
    )
    return {
        "ok": True,
        "path": written["path"],
        "abs_path": written["abs_path"],  # CONTRACT-1 ФП-7 (Д12) — форма для lift_source
        "root_name": target.root_name,
        "size": written["size"],
        "sha256": written["sha256"],
        "parts": parts,
        "existed": written["existed"],
        "overwritten": written["overwritten"],
    }


def abort(session_id: str) -> dict[str, Any]:
    """Снять незавершённую сессию: состояние и накопленные части удаляются.

    Идемпотентно: неизвестная/уже снятая сессия → ``{ok: true, removed: false}``
    (отказывать не за что, результат тот же — сессии нет).
    """
    from core.operational.pult import record_action

    sid = str(session_id or "").strip()
    state = _load_state(sid) if sid else None
    bytes_done = int((state or {}).get("bytes_done") or 0)
    _drop_session(sid)
    record_action(
        "store_file_abort",
        {"session": sid or "—", "root": (state or {}).get("root_name", "—"),
         "rel_path": (state or {}).get("rel_path", "—"), "size": bytes_done},
        "aborted" if state is not None else "absent",
    )
    return {"ok": True, "session_id": sid, "removed": state is not None,
            "discarded_bytes": bytes_done}
