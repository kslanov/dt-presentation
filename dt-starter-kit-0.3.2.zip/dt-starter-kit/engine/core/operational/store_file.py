"""OUT-FILE-1 — канал доставки файлового deliverable в оперативное хранилище.

Продакшн-кейс: чат Desktop собрал .docx-записку для клиентской папки, но у движка
не было канала записи файла — обходной путь через shell+base64-пайпы дважды побил
файл (checksum mismatch), битый docx остался лежать под видом записки. MCP-канал
передаёт base64 в параметре инструмента надёжно (JSON, без шелл-пайпов и проблем
кириллических путей); фикс в движке делает доставку рабочей из ЛЮБОГО чата.

Канал открыт **узко** (принцип 14 — граница безопасности): запись только под
настроенные ingest-корни (`ingest-roots.yaml`, operational/knowledge) — рабочие
папки, которые DT и так сканирует. Гарды (каждый — отказ, не тихий обход):

* **containment** — ``resolve()`` итогового пути обязан лежать под корнем
  (``../``/абсолютные/симлинк-эскейп — отказ); запись в vault/систему/произвольные
  пути невозможна (корни — только operational/knowledge);
* **NDA** — ``_nda``-сегмент в пути (:func:`core.privacy.is_nda`) → отказ;
* **size-cap** — :data:`DEFAULT_MAX_BYTES` (env-override ``DT_STORE_FILE_MAX_BYTES``);
* **sha256 ДО записи** — заявленный клиентом хэш обязан совпасть с фактическим
  декодированным (иначе не пишем вовсе);
* **sha256 ПОСЛЕ записи** — файл перечитывается с диска (tmp до rename и итог после)
  и сверяется снова; не сошлось → удалить, ошибка (битому файлу взяться неоткуда);
* **безопасность перезаписи** — существующий байт-идентичный файл → идемпотентный
  ``existed`` без перезаписи (mtime цел); существующий ОТЛИЧАЮЩИЙСЯ → отказ без
  ``overwrite=True`` (клиентские файлы молча не затираем).

Запись атомарна (tmp+rename). Аудит ``record_action`` — root/rel_path/size/sha256,
без контента. Path B: ни сети, ни LLM. Инвариант ``core`` ⊥ mcp/cli — MCP-обёртка
в ``server.py`` лишь ловит :class:`StoreFileError` в ``{ok:false, refused, error}``.

FT-12: гарды корня/NDA/containment и диспозиция существующего файла вынесены в
:mod:`core.file_ingest.write_target` — общий слой с ``place_download`` (ФТ-1) и
реестром алиасов (ФТ-2), чтобы правила были одни, а не три копии. Контракт и
тексты отказов ``store_file`` при этом не изменились.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import os
from pathlib import Path
from typing import Any

__all__ = ["StoreFileError", "DEFAULT_MAX_BYTES", "store_file"]

# Потолок размера одного deliverable. Крупнее — отказ (deliverable-записки/КП, не
# датасеты). Override через env для нештатных случаев.
DEFAULT_MAX_BYTES = 25 * 1024 * 1024
_MAX_BYTES_ENV = "DT_STORE_FILE_MAX_BYTES"

# Суффикс временного файла атомарной записи (в той же папке — rename атомарен
# только в пределах одной ФС).
_TMP_SUFFIX = ".dt-store.tmp"


class StoreFileError(RuntimeError):
    """Запись файла отклонена гардом (корень/containment/NDA/size/sha/overwrite)."""


def _max_bytes() -> int:
    raw = os.environ.get(_MAX_BYTES_ENV, "").strip()
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    return DEFAULT_MAX_BYTES


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _write_bytes(path: Path, data: bytes) -> None:
    """Запись байтов в файл (вынесено точкой инъекции для теста повреждения)."""
    path.write_bytes(data)


def store_file(
    root_name: str,
    rel_path: str,
    content_b64: str,
    *,
    sha256: str,
    overwrite: bool = False,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Записать файл (base64) под ingest-корень ``root_name`` с полной верификацией.

    См. док модуля. Возвращает ``{ok, path, size, sha256, existed, overwritten}``
    (``path`` — относительный корню, posix). Любой отказ гарда — :class:`StoreFileError`.
    """
    from core.file_ingest.write_target import (
        ABSENT,
        IDENTICAL,
        WriteTargetError,
        existing_disposition,
        resolve_write_target,
    )
    from core.operational.pult import record_action

    # --- 1-3. корень / NDA / containment — общий слой FT-12 -------------------
    try:
        resolved = resolve_write_target(root_name, rel_path, vault_path=vault_path)
    except WriteTargetError as exc:
        raise StoreFileError(str(exc)) from exc
    target, rel_out = resolved.path, resolved.rel_path

    # --- 4. decode base64 + size-cap + sha256 ДО записи ----------------------
    try:
        content = base64.b64decode("".join(str(content_b64).split()), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise StoreFileError(f"невалидный base64: {exc}") from exc
    cap = _max_bytes()
    if len(content) > cap:
        raise StoreFileError(f"файл больше лимита ({len(content)} > {cap} байт)")
    claimed = str(sha256).strip().lower()
    actual = _sha256(content)
    if not claimed:
        raise StoreFileError("не задан заявленный sha256")
    if actual != claimed:
        raise StoreFileError(
            f"sha256 не совпал ДО записи (заявлен {claimed[:12]}…, "
            f"фактический {actual[:12]}…) — файл не записан"
        )

    # --- 5. безопасность перезаписи (диспозиция — общий слой FT-12) ----------
    try:
        disposition = existing_disposition(target, actual, label=rel_out)
    except WriteTargetError as exc:
        raise StoreFileError(str(exc)) from exc
    existed = disposition != ABSENT
    overwritten = False
    if existed:
        if disposition == IDENTICAL:
            # Идемпотентность: те же байты уже лежат — не переписываем (mtime цел).
            record_action(
                "store_file",
                {"root": root_name, "rel_path": rel_out, "size": len(content),
                 "sha256": actual[:12]},
                "existed",
            )
            return {
                "ok": True, "path": rel_out, "abs_path": str(target),
                "size": len(content), "sha256": actual, "existed": True,
                "overwritten": False,
            }
        if not overwrite:
            raise StoreFileError(
                f"файл существует и отличается: {rel_out} — нужен overwrite=True"
            )
        overwritten = True

    # --- 6. атомарная запись tmp + верификация ПОСЛЕ (перечитать с диска) -----
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + _TMP_SUFFIX)
    try:
        _write_bytes(tmp, content)
        # перечитать tmp с диска — не сошлось → удалить tmp, ошибка (существующий
        # файл ещё не тронут: rename не делали, клиентский файл не побит).
        if _sha256(tmp.read_bytes()) != actual:
            raise StoreFileError("повреждение при записи (tmp не сошёлся) — файл не записан")
        os.replace(tmp, target)
    except StoreFileError:
        tmp.unlink(missing_ok=True)
        raise
    except OSError as exc:
        tmp.unlink(missing_ok=True)
        raise StoreFileError(f"ошибка записи: {exc}") from exc

    # финальная сверка итогового файла с диска — не сошлось → удалить, ошибка.
    if _sha256(target.read_bytes()) != actual:
        target.unlink(missing_ok=True)
        raise StoreFileError("повреждение при записи (итог не сошёлся) — файл удалён")

    record_action(
        "store_file",
        {"root": root_name, "rel_path": rel_out, "size": len(content),
         "sha256": actual[:12], "overwritten": overwritten},
        "overwritten" if overwritten else "stored",
    )
    return {
        # ``abs_path`` (CONTRACT-1 ФП-7, Д12): доставленный файл этой формой принимает
        # ``lift_source`` — root-относительный путь резолвился лишь эвристикой хвоста.
        "ok": True, "path": rel_out, "abs_path": str(target),
        "size": len(content), "sha256": actual, "existed": existed,
        "overwritten": overwritten,
    }
