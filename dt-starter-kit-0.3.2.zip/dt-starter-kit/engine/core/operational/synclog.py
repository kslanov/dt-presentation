"""SYNCLOG — единый контракт разбора строк ``dt-sync.log`` (FRESH-PARSE-1).

Формат строки лога живёт в ОДНОМ месте. CODE-5-1 сменил формат: между уровнем и
сообщением встал сегмент ``[<corr-id>] <logger>: `` (см.
:data:`core.logging_setup.LOG_FORMAT`)::

    было:  2026-07-03 08:00:02,000 INFO step pull_capture: ok
    стало: 2026-07-21 09:57:00,123 INFO [run-abc12345] dt_sync: step pull_capture: ok

Контракт был продублирован в двух regex (``freshness._STEP_RE`` и
``pult._DONE_RE``); CODE-5-1 обновил только один → freshness пять дней не видел
новых строк и держал плитку на транзиентном FAILED. Класс-фикс (принцип 14): один
источник правды. :data:`LOG_PREFIX` — единственное место, знающее про
опциональный CODE-5-1-сегмент; :data:`STEP_RE` (+ :func:`iter_step_lines`) и
:data:`DONE_RE` строятся на нём и толерантны к ОБОИМ форматам (старые строки живут
в логе во время ротации).

Чистые данные + regex — ни сети, ни LLM (инвариант ``core`` ⊥ mcp/cli).
"""

from __future__ import annotations

import re
from collections.abc import Iterable, Iterator

__all__ = ["LOG_PREFIX", "STEP_RE", "DONE_RE", "iter_step_lines"]

# Общий префикс любой строки dt-sync.log: ``<asctime>,<ms> <LEVEL> `` и далее
# ОПЦИОНАЛЬНЫЙ CODE-5-1-сегмент ``[<corr-id>] <logger>: `` (в старом формате его
# нет — сообщение шло сразу после уровня). Единственное место, кодирующее этот
# сегмент; и STEP_RE, и DONE_RE наследуют его → формат живёт в одном regex.
LOG_PREFIX = (
    r"^(?P<ts>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}),\d+ \S+ "
    r"(?:\[[^\]]*\] \S+: )?"
)

# Строка шага (cli/dt_sync.py::_run_step_once) в обоих форматах::
#   … INFO step pull_capture: ok
#   … INFO [run-…] dt_sync: step refresh: FAILED (exit 1)
#   … WARNING [run-…] dt_sync: step refresh: failed (will retry) …
STEP_RE = re.compile(LOG_PREFIX + r"step (?P<name>\w+): (?P<res>ok|FAILED|failed)\b")

# Итоговая строка прогона (cli/dt_sync.py::run) — другой контракт, но тот же
# префикс::
#   … INFO === dt-sync fast: done ok ===
#   … WARNING === dt-sync full: done WITH ERRORS (steps: refresh) ===
DONE_RE = re.compile(
    LOG_PREFIX
    + r"=== dt-sync (?P<mode>fast|index|full): done"
    r"(?: ok| WITH ERRORS \(steps: (?P<steps>[^)]*)\)) ==="
)


def iter_step_lines(lines: Iterable[str]) -> Iterator[tuple[str, str, bool]]:
    """Разобрать строки лога в ``(ts, step_name, ok)`` для каждой step-строки.

    ``ts`` — локальный asctime без миллисекунд (``2026-07-21 09:57:00``);
    ``ok`` = результат ``ok`` (FAILED/failed → False). Порядок сохраняется —
    вызывающий может брать «последний прогон побеждает» простым перезаписыванием
    по ключу (новый ok перекрывает старый FAILED).
    """
    for line in lines:
        m = STEP_RE.match(line)
        if m:
            yield m.group("ts"), m.group("name"), m.group("res") == "ok"
