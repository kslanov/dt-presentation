"""TickTick capture connector (architecture §7, ТЗ B2a).

Open API V1, base ``https://api.ticktick.com/open/v1``, OAuth Bearer. Read-only
in B2a — capture from a dedicated TickTick project into the vault inbox by tag,
deduped by a local state file. No writes to TickTick (Timetta→TickTick
reflection is B2b; back-write is B3).

Probe-confirmed contract (live V1, 2026-06-22):

* auth header ``Authorization: Bearer <TICKTICK_ACCESS_TOKEN>``;
* ``GET /project`` → list of ``{id, name, kind, color, sortOrder, viewMode}``
  (``groupId`` only when the project sits in a folder; Inbox is NOT listed);
* ``GET /project/{id}/data`` → ``{project, tasks:[...], columns:[...]}``; a task
  carries ``tags: list[str]`` (round-trips), ``title``, ``content``/``desc``,
  optional checklist ``items[]``, ``modifiedTime`` (the dedup watermark);
* no documented rate limits seen on a 20-request burst → conservative backoff.
"""

from core.operational.ticktick.connector import TickTickConnector

__all__ = ["TickTickConnector"]
