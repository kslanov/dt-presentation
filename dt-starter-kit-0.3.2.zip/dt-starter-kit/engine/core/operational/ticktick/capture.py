"""TickTick → inbox capture by tags (architecture §7, ТЗ B2a).

Reads a dedicated TickTick *capture project* whole and routes its tasks into the
vault inbox (``_staging/inbox/``) by tag, so the existing ``dt-refine-inbox``
(D6) can place them. **Read-only to TickTick**: nothing is created, completed,
tagged or moved there; "processed" is tracked only in a local dedup state.

Routing (tags matched case-insensitively; ``#`` is display-only — the API tag is
the bare word, e.g. ``"знание"``):

* ``личное`` / ``дневник`` / ``контент`` → **dropped before any save** (PERSONAL-1: все три личных
  тега; раньше дневник/контент без рабочего тега попадали в ``untriaged`` рабочего контура).
  Privacy filter on pull: neither the title/content nor even the id is written to inbox, state,
  log or summary.
* ``поручение`` / ``тиметта`` → pulled, lane = ``assignment``: карточка «Поручение администратору
  CRM» (RETIRE-WRITE-1, ``core.operational.assignment``). ``тиметта`` принимается переходно.
* ``знание``   → pulled, lane = ``knowledge``.
* ``оператив`` → skipped (stays a TickTick task).
* (no work tag) → **untriaged** (TRIAGE-1): записывается в манифест захвата со
  статусом ``untriaged`` (id, текст, теги, created/modified) и ждёт микрорешения
  кнопкой на пульте (``pult_untriaged`` / ``pult_route``) — тег из обязательного
  правила становится подсказкой-ускорителем.

Priority on multiple tags: личные теги > ``поручение``/``тиметта`` > ``знание`` > ``оператив``.
Privacy-приоритет действует ДО untriaged-учёта: задача с личным тегом не попадает
в манифест ни при каких прочих тегах.

PERSONAL-1 (``role="personal"``, экземпляр личного контура; тот же проект захвата, свой dedup-стейт
в своем ``.derived``): ``дневник`` → заметка дня ``05-journal/ГГГГ-ММ-ДД.md`` (секция ``## ЧЧ:ММ``
с футером), ``контент`` → inbox ``lane: content``, ``личное`` → inbox ``lane: personal``;
рабочие теги и задачи без тега личный контур пропускает БЕЗ записи (их берет рабочий; триаж
остается рабочим).

Dedup state ``.derived/ticktick/capture_state.json`` keyed by ``taskId`` with the
last seen ``modified`` — a re-pull with the same ``modified`` is a no-op; a
changed ``modified`` re-pulls. ``личное`` tasks are never recorded (privacy).
Маршрутизированные с пульта записи (``routed_*`` / ``dropped``) — терминальные:
pull их не воскрешает даже при изменённом ``modified``.

TRIAGE-1 (:func:`route_capture`): локальный override маршрута — семантика РОВНО
как если бы на захвате стоял правильный тег. ``knowledge``/``assignment`` пишут
штатный inbox-файл с тем же provenance-футером, что и pull (дальше обычный
поток D6 / карточка поручения); ``task`` оставляет задачу TickTick; ``drop`` удаляет
текст из манифеста («личное задним числом»). Тег в TickTick НЕ правится — read-only
к TickTick сохраняется. Терминальный статус поручения — ``routed_assignment``
(кнопка «отправлено», :mod:`core.operational.assignment`).

Invariant: ``core/`` depends on neither MCP nor CLI; the only network here is to
TickTick (via the injected client). No LLM calls.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, tzinfo
from pathlib import Path
from typing import Any, Protocol

from core.metrics import record_event

__all__ = [
    "PERSONAL_TAGS",
    "TAG_DIARY",
    "TAG_CONTENT",
    "LANE_JOURNAL",
    "LANE_CONTENT",
    "LANE_PERSONAL",
    "PERSONAL_LANES",
    "TAG_PERSONAL",
    "TAG_OPERATIVE",
    "TAG_KNOWLEDGE",
    "TAG_TIMETTA",
    "TAG_ASSIGNMENT",
    "ASSIGNMENT_TAGS",
    "LANE_ASSIGNMENT",
    "ASSIGNMENT_LANES",
    "STATUS_ASSIGNMENT_SENT",
    "STATUS_UNTRIAGED",
    "STATUS_RESOLVED_EXTERNAL",
    "ROUTE_LANES",
    "Route",
    "route_task",
    "CaptureResult",
    "pull_capture",
    "list_untriaged",
    "route_capture",
    "CapturesReconcilable",
]

# API tag words (bare, no leading '#'), matched case-insensitively.
TAG_PERSONAL = "личное"
TAG_OPERATIVE = "оператив"
TAG_KNOWLEDGE = "знание"
TAG_TIMETTA = "тиметта"  # переходно: то же, что «поручение» (RETIRE-WRITE-1)
TAG_ASSIGNMENT = "поручение"
ASSIGNMENT_TAGS = (TAG_ASSIGNMENT, TAG_TIMETTA)
# PERSONAL-1: личные теги. Рабочий контур отбрасывает ВСЕ ДО записи; личный контур маршрутизирует.
TAG_DIARY = "дневник"
TAG_CONTENT = "контент"
PERSONAL_TAGS = (TAG_PERSONAL, TAG_DIARY, TAG_CONTENT)

# Canonical lane labels used in the summary counters.
LANE_KNOWLEDGE = "knowledge"
LANE_ASSIGNMENT = "assignment"
# PERSONAL-1: лейны личного контура (только у ``role="personal"``).
LANE_JOURNAL = "journal"
LANE_CONTENT = "content"
LANE_PERSONAL = "personal"
PERSONAL_LANES = (LANE_JOURNAL, LANE_CONTENT, LANE_PERSONAL)
_PERSONAL_LANE_BY_TAG = {TAG_DIARY: LANE_JOURNAL, TAG_CONTENT: LANE_CONTENT,
                         TAG_PERSONAL: LANE_PERSONAL}
# Прежнее имя того же лейна (записи манифеста до RETIRE-WRITE-1): читается как assignment.
LANE_OPERATIONAL = "operational"
ASSIGNMENT_LANES = (LANE_ASSIGNMENT, LANE_OPERATIONAL)

# TRIAGE-1 — статусы записей манифеста захвата. Отсутствие "status" = обычная
# pulled-запись B2a (обратная совместимость со старыми манифестами).
STATUS_UNTRIAGED = "untriaged"
STATUS_ROUTED = {
    "knowledge": "routed_knowledge",
    "assignment": "routed_assignment",
    "task": "routed_task",
    "drop": "dropped",
}
# RETIRE-WRITE-1: «отправлено» по карточке поручения — терминальный статус.
STATUS_ASSIGNMENT_SENT = STATUS_ROUTED["assignment"]
# Статус старого маршрута «в Timetta» (до вывода контура) остаётся терминальным в манифесте.
_LEGACY_STATUS_OPERATIONAL = "routed_operational"
# RECONCILE-1: захват был untriaged, но задача пропала из живого фида
# захват-проекта (пользователь завершил/удалил её в TickTick) → снимаем из
# «Требуют решения» этим статусом (архив inbox-заметки, НЕ hard-delete).
STATUS_RESOLVED_EXTERNAL = "resolved_external"
# Терминальные статусы: pull такие записи не воскрешает, route их не переиграет.
_TERMINAL_STATUSES = frozenset(
    {*STATUS_ROUTED.values(), _LEGACY_STATUS_OPERATIONAL, STATUS_RESOLVED_EXTERNAL}
)

# Терминальные по РЕШЕНИЮ: pull их не воскрешает; ``resolved_external`` — воскресает (задачу снова
# открыли в TickTick).
_NO_RESURRECT = _TERMINAL_STATUSES - {STATUS_RESOLVED_EXTERNAL}

# Допустимые маршруты pult_route (``operational`` — прежнее имя ``assignment``, принимается).
ROUTE_LANES = (*STATUS_ROUTED, LANE_OPERATIONAL)

# lane → тег провенанс-футера inbox-файла (тот же, что писал бы pull по тегу).
_LANE_FOOTER_TAG = {"knowledge": TAG_KNOWLEDGE, "assignment": TAG_ASSIGNMENT}


class _ProjectReader(Protocol):
    """The slice of the TickTick client that capture needs (read-only)."""

    def get_project_data(self, project_id: str) -> dict[str, Any]: ...


@dataclass
class Route:
    """The routing decision for one task, derived purely from its tags."""

    action: str  # "pull" | "skip"
    reason: str  # "pulled" | "personal" | "operative" | "untagged" | "work_tag"
    tag: str | None = None  # the tag that matched (знание | поручение | тиметта | дневник | …)
    lane: str | None = None  # knowledge | assignment | journal | content | personal


_LANE_TAG = {lane: tag for tag, lane in _PERSONAL_LANE_BY_TAG.items()}


def route_task(
    tags: list[str] | None, role: str = "work", untagged_lane: str = "skip"
) -> Route:
    """Map a task's ``tags`` to a routing decision (case-insensitive, priority).

    Рабочая роль: любой личный тег (``личное``/``дневник``/``контент``) выигрывает безусловно
    (privacy skip, no save); затем ``поручение``/``тиметта``, ``знание``, ``оператив``; прочее (или
    без тега) ждет триажа. Личная роль (PERSONAL-1): ``дневник`` > ``контент`` > ``личное`` -
    маршрут в личный контур; рабочие теги (``reason="work_tag"``) и задачи без тега
    (``untagged``) - пропуск без записи (их берет рабочий контур). PERSONAL-3: ``untagged_lane``
    (``personal``/``journal``/``content``) отправляет задачи БЕЗ тега в эту полосу
    (``reason="untagged_lane"``) - ручка допустима только при отдельном списке личного.
    """
    lowered = {str(t).strip().lower() for t in (tags or []) if str(t).strip()}
    if role == "personal":
        for tag in (TAG_DIARY, TAG_CONTENT, TAG_PERSONAL):
            if tag in lowered:
                return Route(action="pull", reason="pulled", tag=tag,
                             lane=_PERSONAL_LANE_BY_TAG[tag])
        if lowered & {*ASSIGNMENT_TAGS, TAG_KNOWLEDGE, TAG_OPERATIVE}:
            return Route(action="skip", reason="work_tag")
        if untagged_lane in _LANE_TAG:
            return Route(action="pull", reason="untagged_lane", tag=_LANE_TAG[untagged_lane],
                         lane=untagged_lane)
        return Route(action="skip", reason="untagged")
    if lowered & set(PERSONAL_TAGS):
        return Route(action="skip", reason="personal")
    for tag in ASSIGNMENT_TAGS:
        if tag in lowered:
            return Route(action="pull", reason="pulled", tag=tag, lane=LANE_ASSIGNMENT)
    if TAG_KNOWLEDGE in lowered:
        return Route(action="pull", reason="pulled", tag=TAG_KNOWLEDGE, lane=LANE_KNOWLEDGE)
    if TAG_OPERATIVE in lowered:
        return Route(action="skip", reason="operative")
    return Route(action="skip", reason="untagged")


@dataclass
class CaptureResult:
    """Anonymized capture summary — counts only, never task text/ids in logs."""

    pulled: dict[str, int] = field(
        default_factory=lambda: {LANE_KNOWLEDGE: 0, LANE_ASSIGNMENT: 0}
    )
    skipped_personal: int = 0
    skipped_operative: int = 0
    skipped_untagged: int = 0
    skipped_work_tag: int = 0  # PERSONAL-1: личный контур пропустил рабочий тег (берет рабочий)
    skipped_dedup: int = 0
    untriaged_recorded: int = 0  # TRIAGE-1: новых/обновлённых untriaged-записей
    # Paths of inbox files written this run (filename carries only the taskId,
    # not personal content). Empty on --dry-run.
    written: list[Path] = field(default_factory=list)
    dry_run: bool = False

    @property
    def total_pulled(self) -> int:
        return sum(self.pulled.values())


def _checkbox(status: Any) -> str:
    """TickTick item status: 0 = open, non-zero = done."""
    try:
        return "[x]" if int(status) != 0 else "[ ]"
    except (TypeError, ValueError):
        return "[ ]"


def _filename_date(modified: str | None) -> str:
    """``YYYYMMDD`` from a task's ``modifiedTime`` (date portion), else today."""
    if modified and len(modified) >= 10 and modified[4] == "-" and modified[7] == "-":
        return modified[:10].replace("-", "")
    return datetime.now(UTC).strftime("%Y%m%d")


def _task_text(task: dict[str, Any]) -> str:
    """Текст задачи для inbox/манифеста: title + content/desc + чек-лист."""
    lines: list[str] = []
    title = str(task.get("title") or "").strip()
    lines.append(title or "(без названия)")

    detail = str(task.get("content") or task.get("desc") or "").strip()
    if detail:
        lines.append("")
        lines.append(detail)

    items = task.get("items")
    if isinstance(items, list) and items:
        lines.append("")
        for it in items:
            if not isinstance(it, dict):
                continue
            text = str(it.get("title") or "").strip()
            lines.append(f"- {_checkbox(it.get('status'))} {text}")
    return "\n".join(lines)


def _footer(lane_tag: str, task_id: str, captured_at: str, modified: str) -> str:
    """Provenance-футер inbox-файла — единый для pull- и route-путей."""
    return "\n".join([
        "",
        "---",
        "источник: ticktick",
        f"lane: {lane_tag}",
        f"taskId: {task_id}",
        f"captured: {captured_at}",
        f"modified: {modified}",
    ])


def _compose_body(task: dict[str, Any], route: Route, *, captured_at: str) -> str:
    """Inbox-file body (whole file = item text for D6).

    Title + content/desc + checklist ``items[]`` + a short provenance footer
    whose ``lane:`` carries the routing tag so refinement knows the addressee.
    """
    assert route.tag is not None  # noqa: S101 — type-narrowing assert; non-None guaranteed above
    return (
        _task_text(task)
        + _footer(
            route.tag, str(task.get("id")), captured_at,
            str(task.get("modifiedTime") or ""),
        )
        + "\n"
    )


# CONTRACT-2 (ФП-6): причина последнего сбоя чтения манифеста захвата. Битый файл
# выглядел как «захватов нет» — то есть как норма; лента пустела молча.
_LAST_STATE_ERROR: dict[str, str] = {"reason": ""}


def last_state_error() -> str:
    """Причина последнего сбоя чтения манифеста захвата (``""`` — сбоя не было)."""
    return _LAST_STATE_ERROR["reason"]


def _load_state(state_path: Path) -> dict[str, dict[str, Any]]:
    _LAST_STATE_ERROR["reason"] = ""
    if not state_path.is_file():
        return {}
    try:
        data = json.loads(state_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        _LAST_STATE_ERROR["reason"] = str(exc)[:200]
        return {}
    if not isinstance(data, dict):
        _LAST_STATE_ERROR["reason"] = "манифест захвата не словарь"
        return {}
    return data


def _save_state(state_path: Path, state: dict[str, dict[str, Any]]) -> None:
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(
        json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )


def _emit_capture_events(events: list[dict[str, Any]]) -> None:
    """INGRESS-1 п.5: ``ingest``-события захватов одной пачкой на прогон (best-effort).

    ``note_id=None`` (inbox-файл ещё не заметка), ``path`` — ``inbox/<файл>`` относительный;
    ``run_id`` — общий с итогом прогона (``core.ingress.run``), иначе свежий.
    """
    try:
        from core.eventlog import emit_batch, new_run_id
        from core.ingress.run import current_run

        run = current_run()
        run_id = run.run_id if run is not None else new_run_id()
        emit_batch([{**e, "run_id": run_id} for e in events])
    except Exception:  # noqa: BLE001, S110 — лента событий не критичный путь
        pass


_URL_RE = re.compile(r"https?://[^\s<>\"')\]]+")


def _content_hints(text: str) -> list[str]:
    """Строки футера ``контент``-захвата: ``type: content`` и, если в тексте есть ссылка, ``url`` и
    ``source`` (хост) - подсказка Пути B при размещении заметки (``type: content``)."""
    lines = ["type: content"]
    m = _URL_RE.search(text)
    if m:
        from urllib.parse import urlparse

        url = m.group(0).rstrip(".,;:")
        lines.append(f"url: {url}")
        host = (urlparse(url).hostname or "").removeprefix("www.")
        if host:
            lines.append(f"source: {host}")
    return lines


def _pull_personal(
    client: _ProjectReader,
    *,
    project_id: str,
    inbox_dir: Path,
    state_path: Path,
    vault_path: Path,
    dry_run: bool,
    tz: tzinfo | None,
) -> CaptureResult:
    """Личный контур (PERSONAL-1): ``дневник`` → заметка дня, ``контент``/``личное`` → inbox.

    Рабочие теги и задачи без тега пропускаются БЕЗ следа (ни id, ни текста в стейте/журнале -
    только счетчик): их берет рабочий контур. Стейт - свой (``.derived`` экземпляра), ключ - taskId,
    значение - последний ``modified``; изменение задачи обновляет СВОЮ секцию заметки дня или
    inbox-файл.
    """
    from core.instance import personal_ideas_dir
    from core.personal.ideas import write_idea
    from core.personal.journal import day_path, entry_time, upsert_entry

    ideas_dir = personal_ideas_dir()  # PERSONAL-2: есть ручка - #личное пишется заметкой идеи
    from core.instance import untagged_lane

    untagged = untagged_lane()  # PERSONAL-3: полоса для задач без тега (по умолчанию - пропуск)

    result = CaptureResult(dry_run=dry_run)
    inbox_dir = Path(inbox_dir)
    state = _load_state(Path(state_path))
    captured_at = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    state_dirty = False
    events: list[dict[str, Any]] = []
    tasks = client.get_project_data(project_id).get("tasks") or []

    for task in tasks:
        if not isinstance(task, dict):
            continue
        route = route_task(task.get("tags"), role="personal", untagged_lane=untagged)
        if route.reason == "work_tag":
            result.skipped_work_tag += 1
            continue
        if route.reason == "untagged":
            result.skipped_untagged += 1
            continue
        task_id = str(task.get("id") or "")
        modified = str(task.get("modifiedTime") or "")
        if not task_id:
            continue
        prior = state.get(task_id)
        if prior is not None and prior.get("modified") == modified:
            result.skipped_dedup += 1
            continue
        lane = route.lane
        assert lane is not None  # noqa: S101 - сужение типа: pull всегда с лейном
        entry: dict[str, Any] = {"modified": modified, "lane": lane, "pulled_at": captured_at}
        if lane == LANE_JOURNAL:
            when = entry_time(task, tz)
            target = (Path(vault_path) / str(prior["journal"])
                      if prior and prior.get("journal") else day_path(vault_path, when))
            if not dry_run:
                wrote = upsert_entry(
                    vault_path, when, _task_text(task), task_id=task_id, modified=modified,
                    captured_at=captured_at, target=target)
                entry["journal"] = wrote.path.relative_to(vault_path).as_posix()
                result.written.append(wrote.path)
                disposition = "changed" if wrote.replaced else "new"
                events.append({
                    "stage": "ingest", "status": "done", "note_id": None,
                    "path": entry["journal"],
                    "detail": {"route": "capture", "lane": lane, "disposition": disposition}})
        elif lane == LANE_PERSONAL and ideas_dir:
            when = entry_time(task, tz)
            prior_rel = str((prior or {}).get("idea") or "")
            if prior_rel and (Path(vault_path) / prior_rel).is_file():
                entry["idea"] = prior_rel  # заметкой владеет человек: не переписываем
            elif not dry_run:
                wrote_idea = write_idea(
                    vault_path, ideas_dir, when, _task_text(task), task_id=task_id,
                    modified=modified, captured_at=captured_at)
                entry["idea"] = wrote_idea.path.relative_to(vault_path).as_posix()
                result.written.append(wrote_idea.path)
                events.append({
                    "stage": "ingest", "status": "done", "note_id": None, "path": entry["idea"],
                    "detail": {"route": "capture", "lane": lane, "disposition": "new"}})
        else:
            if not dry_run:
                text = _task_text(task)
                inbox_dir.mkdir(parents=True, exist_ok=True)
                fname = f"ticktick-{task_id}-{_filename_date(modified)}.md"
                footer = _footer(lane, task_id, captured_at, modified)
                if lane == LANE_CONTENT:
                    footer += "\n" + "\n".join(_content_hints(text))
                target_file = inbox_dir / fname
                target_file.write_text(text + footer + "\n", encoding="utf-8")
                result.written.append(target_file)
                events.append({
                    "stage": "ingest", "status": "done", "note_id": None,
                    "path": f"inbox/{fname}",
                    "detail": {"route": "capture", "lane": lane,
                               "disposition": "new" if prior is None else "changed"}})
        if not dry_run:
            state[task_id] = entry
            state_dirty = True
        result.pulled[lane] = result.pulled.get(lane, 0) + 1

    if state_dirty:
        _save_state(Path(state_path), state)
    if events:
        _emit_capture_events(events)
    return result


def pull_capture(
    client: _ProjectReader,
    *,
    project_id: str,
    inbox_dir: Path,
    state_path: Path,
    dry_run: bool = False,
    role: str | None = None,
    vault_path: Path | None = None,
    tz: tzinfo | None = None,
) -> CaptureResult:
    """Read the capture project, route by tag, write новые/изменённые to inbox.

    Returns an anonymized :class:`CaptureResult` (counts only). Personal-tagged tasks
    (``личное``/``дневник``/``контент``) are dropped before any persistence — no inbox file, no
    state entry, nothing in the result beyond the privacy-skip counter.

    ``role`` (по умолчанию ``DT_INSTANCE_ROLE``; PERSONAL-1) - ``personal`` переключает на
    личный маршрут (:func:`_pull_personal`; нужен ``vault_path`` личного vault, ``tz`` -
    часовой пояс заметки дня, по умолчанию местный). Рабочая роль - прежний маршрут байт в байт.
    """
    if role is None:
        from core.instance import instance_role

        role = instance_role()
    if role == "personal":
        if vault_path is None:
            from core.config import default_vault_path

            vault_path = default_vault_path()
        return _pull_personal(
            client, project_id=project_id, inbox_dir=Path(inbox_dir), state_path=Path(state_path),
            vault_path=Path(vault_path), dry_run=dry_run, tz=tz)
    inbox_dir = Path(inbox_dir)
    state_path = Path(state_path)
    result = CaptureResult(dry_run=dry_run)
    # INGRESS-1 п.4/п.5: отказы идут в общий журнал (``refuse``), события — одной пачкой на прогон.
    from core.ingress.refusals import refuse

    events: list[dict[str, Any]] = []

    data = client.get_project_data(project_id)
    tasks = data.get("tasks") or []

    state = _load_state(state_path)
    captured_at = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    state_dirty = False

    for task in tasks:
        if not isinstance(task, dict):
            continue
        route = route_task(task.get("tags"))

        if route.reason == "personal":
            # Privacy filter: drop now, before reading/saving any field. Do NOT
            # record the id, modified, or any text anywhere.
            result.skipped_personal += 1
            refuse("capture", "privacy_personal")  # только счетчик: ни id, ни текста в журнал
            continue
        if route.reason == "operative":
            result.skipped_operative += 1
            refuse("capture", "operative_tag", source_id=str(task.get("id") or ""))
            continue
        if route.reason == "untagged":
            # TRIAGE-1: не молча мимо — записать в манифест как untriaged, чтобы
            # захват появился карточкой на пульте. Privacy-приоритет уже отработал:
            # ``личное`` отсечено ветками выше и сюда не доходит НИКОГДА.
            result.skipped_untagged += 1
            task_id = str(task.get("id") or "")
            refuse("capture", "untagged", source_id=task_id)  # id без заголовка/текста
            modified = str(task.get("modifiedTime") or "")
            prior = state.get(task_id)
            if not task_id:
                continue
            if prior is not None and prior.get("status") != STATUS_UNTRIAGED:
                continue  # pulled/routed/dropped ранее — не воскрешаем
            if prior is not None and prior.get("modified") == modified:
                continue  # уже учтён и не менялся
            if not dry_run:
                tags = [
                    str(t).strip() for t in (task.get("tags") or []) if str(t).strip()
                ]
                state[task_id] = {
                    "status": STATUS_UNTRIAGED,
                    "modified": modified,
                    "title": str(task.get("title") or "").strip(),
                    "text": _task_text(task),
                    "tags": tags,
                    "created": task.get("createdTime") or None,
                    "captured": captured_at,
                }
                state_dirty = True
                result.untriaged_recorded += 1
            continue

        # route.action == "pull"
        task_id = str(task.get("id") or "")
        modified = str(task.get("modifiedTime") or "")
        prior = state.get(task_id)
        if prior is not None and prior.get("modified") == modified:
            result.skipped_dedup += 1
            continue
        if prior is not None and prior.get("status") in _NO_RESURRECT:
            # Решение уже принято (routed_*/dropped — в т.ч. «отправлено» по карточке поручения):
            # правка задачи в TickTick не возвращает захват в инбокс. ``resolved_external``
            # (закрыли и открыли снова) — наоборот, воскресает: см. RECONCILE-2.
            result.skipped_dedup += 1
            continue

        assert route.lane is not None  # noqa: S101 — type-narrowing assert; non-None guaranteed above
        if not dry_run:
            inbox_dir.mkdir(parents=True, exist_ok=True)
            fname = f"ticktick-{task_id}-{_filename_date(modified)}.md"
            body = _compose_body(task, route, captured_at=captured_at)
            target = inbox_dir / fname
            target.write_text(body, encoding="utf-8")
            result.written.append(target)
            events.append({
                "stage": "ingest", "status": "done", "note_id": None, "path": f"inbox/{fname}",
                "detail": {"route": "capture", "lane": route.lane,
                           "disposition": "new" if prior is None else "changed"},
            })
            state[task_id] = {
                "modified": modified,
                "lane": route.lane,
                "pulled_at": captured_at,
            }
            state_dirty = True

        result.pulled[route.lane] += 1

    if state_dirty:
        _save_state(state_path, state)
    if events:
        _emit_capture_events(events)

    return result


# --------------------------------------------------------------------------- #
# TRIAGE-1 — триаж untriaged-захватов кнопками пульта                          #
# --------------------------------------------------------------------------- #
def list_untriaged(state_path: Path) -> list[dict[str, Any]]:
    """Untriaged-захваты из манифеста для карточек пульта. Read-only, без сети."""
    rows: list[dict[str, Any]] = []
    for task_id, entry in _load_state(Path(state_path)).items():
        if not isinstance(entry, dict) or entry.get("status") != STATUS_UNTRIAGED:
            continue
        rows.append(
            {
                "capture_id": task_id,
                "title": entry.get("title") or "",
                "text": entry.get("text") or "",
                "tags": entry.get("tags") or [],
                "captured": entry.get("captured"),
            }
        )
    rows.sort(key=lambda r: (r["captured"] or "", r["capture_id"]))
    return rows


def route_capture(
    capture_id: str,
    lane: str,
    *,
    state_path: Path,
    inbox_dir: Path,
    now: str | None = None,
) -> dict[str, Any]:
    """Маршрутизировать untriaged-захват — как если бы стоял правильный тег.

    * ``knowledge`` — штатный inbox-файл с тем же provenance-футером, что пишет pull
      (``lane: знание``) — дальше обычный поток D6; статус ``routed_knowledge``;
    * ``assignment`` (RETIRE-WRITE-1; прежнее имя ``operational`` принимается) — inbox-файл с
      футером ``lane: поручение`` и запись манифеста РОВНО как у захвата с тегом (``lane:
      assignment``, без статуса): захват становится карточкой «Поручение администратору CRM»
      (:mod:`core.operational.assignment`); терминальный статус придёт с «отправлено»;
    * ``task`` — остаётся задачей TickTick, больше не предлагается;
    * ``drop`` — текст/теги удаляются из манифеста («личное задним числом»).

    Идемпотентность по ``capture_id``: повторный route уже маршрутизированного
    захвата — ``stale`` без второго inbox-файла. Тег в TickTick не правится
    (read-only). Аудит в pult-actions.log — только id/lane, без текста захвата;
    metrics — kind ``capture_route`` (только lane).
    """
    from core.operational.pult import record_action

    if lane not in ROUTE_LANES:
        raise ValueError(
            f"unsupported lane {lane!r}; use {' | '.join(STATUS_ROUTED)}"
        )
    if lane == LANE_OPERATIONAL:
        lane = LANE_ASSIGNMENT
    audit_params: dict[str, Any] = {"capture_id": capture_id, "lane": lane}
    state_path = Path(state_path)
    state = _load_state(state_path)
    entry = state.get(capture_id)
    if not isinstance(entry, dict):
        record_action("pult_route", audit_params, "not_found", now=now)
        raise ValueError(f"Захват {capture_id!r} не найден в манифесте захвата.")

    status = entry.get("status")
    if status != STATUS_UNTRIAGED:
        record_action("pult_route", audit_params, "stale", now=now)
        settled = status if status in _TERMINAL_STATUSES else "обработан pull-путём"
        return {
            "outcome": "stale",
            "capture_id": capture_id,
            "lane": lane,
            "explanation": f"Захват уже маршрутизирован ({settled}) — "
            "повторное решение не требуется.",
        }

    captured_at = now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    modified = str(entry.get("modified") or "")
    result: dict[str, Any] = {"outcome": "routed", "capture_id": capture_id, "lane": lane}

    if lane in _LANE_FOOTER_TAG:
        inbox_dir = Path(inbox_dir)
        inbox_dir.mkdir(parents=True, exist_ok=True)
        body = (
            str(entry.get("text") or "")
            + _footer(_LANE_FOOTER_TAG[lane], capture_id, captured_at, modified)
            + "\n"
        )
        target = inbox_dir / f"ticktick-{capture_id}-{_filename_date(modified)}.md"
        target.write_text(body, encoding="utf-8")
        result["inbox_file"] = str(target)

    if lane == LANE_ASSIGNMENT:
        # Как будто захват пришёл с тегом: запись pulled-вида (без статуса) — её и читает
        # карточка поручения; терминальный статус поставит «отправлено»/«отклонить».
        entry = {"modified": modified, "lane": LANE_ASSIGNMENT, "pulled_at": captured_at}
    else:
        entry["status"] = STATUS_ROUTED[lane]
        entry["routed_at"] = captured_at
        if lane == "drop":
            # «Личное задним числом»: текст выбрасывается, остаётся только скелет
            # для идемпотентности/невоскрешения (id + modified + статус).
            for key in ("title", "text", "tags", "created"):
                entry.pop(key, None)
    state[capture_id] = entry
    _save_state(state_path, state)

    # Privacy: в метриках и аудите — только lane, никаких текстов.
    record_event("capture_route", lane=lane)
    record_action("pult_route", audit_params, "routed", now=now)
    return result


# --------------------------------------------------------------------------- #
# RECONCILE-1 — адаптер №1: сверка захватов с живым фидом TickTick             #
# --------------------------------------------------------------------------- #
def _inbox_notes(inbox_dir: Path, task_id: str) -> list[Path]:
    """Файлы захвата в инбоксе: ``ticktick-<taskId>-*.md`` (пусто — разобран/не писался).

    Одно место, где знание «как называется файл захвата» превращается в список путей:
    им живут и архивация, и признак «карточка ещё висит» (RECONCILE-2).
    """
    return [p for p in sorted(Path(inbox_dir).glob(f"ticktick-{task_id}-*.md")) if p.is_file()]


def _archive_inbox_note(inbox_dir: Path, task_id: str) -> Path | None:
    """Переместить inbox-заметку захвата в ``_staging/inbox/_done/`` (НЕ удалять).

    Untriaged-захват обычно живёт только записью в ``capture_state.json`` (pull
    не пишет для него inbox-файл), поэтому чаще это no-op — снятие из очереди даёт
    смена статуса. Для pulled-захвата (RECONCILE-2) файл как раз есть, и именно он
    держит карточку в «Инбоксах». Файл архивируется, а не теряется. Возвращает
    путь последнего перемещённого файла или ``None``.
    """
    inbox_dir = Path(inbox_dir)
    moved: Path | None = None
    for src in _inbox_notes(inbox_dir, task_id):
        done_dir = inbox_dir / "_done"
        done_dir.mkdir(parents=True, exist_ok=True)
        target = done_dir / src.name
        src.replace(target)  # move, not hard-delete — данные не теряем
        moved = target
    return moved


@dataclass
class CapturesReconcilable:
    """:class:`~core.operational.reconcile.Reconcilable` для TickTick-захватов.

    ``read_source`` = live-пул захват-проекта (набор живых ``taskId``); пустой
    список или ошибка чтения → ``None`` (общий гард движка пропустит сверку — не
    снесём очередь на 401/429/сетевом сбое). ``stale_items`` = записи
    ``capture_state.json``, чей ``taskId`` пропал из живого фида (завершены/удалены
    в TickTick): untriaged (RECONCILE-1) **и pulled-операционные** (RECONCILE-2).
    ``resolve`` = статус ``resolved_external`` + архив inbox-заметки.
    **Read-only к TickTick** — только ``get_project_data``.

    **RECONCILE-2** (живой кейс К. 2026-08-13: «Противопожарка · Назначить
    собеседования», закрыта в TickTick, карточка висела в «Инбоксах» 48 дней).
    RECONCILE-1 сверял только untriaged, а pulled-захват лежит в манифесте БЕЗ статуса
    (``{modified, lane, pulled_at}``) и держит карточку своим inbox-файлом — сверка на
    него не смотрела, и файл висел вечно. Теперь смотрит, но с двумя условиями:

    * **только лейн поручения (``assignment``; прежде ``operational``).** Закрытие
      ЗНАНИЕ-задачи в TickTick — штатная
      уборка после копирования текста, а заметка ещё ждёт refine: архивировать её
      значило бы молча потерять знание.
    * **только пока inbox-файл жив.** Файла нет ⇒ захват уже разобран, и вешать на
      него ``resolved_external`` («закрыт снаружи») было бы неверной подписью.
    """

    client: _ProjectReader
    project_id: str
    state_path: Path
    inbox_dir: Path
    now: str | None = None
    name: str = field(default="captures")

    def read_source(self) -> set[str] | None:
        """Живой набор ``taskId`` из захват-проекта; ошибка/пусто → ``None`` (гард)."""
        try:
            data = self.client.get_project_data(self.project_id)
        except Exception:  # noqa: BLE001 — сбой чтения = «не читать», не «пусто»
            return None
        tasks = data.get("tasks") if isinstance(data, dict) else None
        if not isinstance(tasks, list) or not tasks:
            # Пусто может быть транзиентным (завершили ВСЕ задачи — редкость против
            # частого «фид пуст из-за сбоя»); гард выбирает безопасность очереди.
            return None
        live = {
            str(t.get("id"))
            for t in tasks
            if isinstance(t, dict) and str(t.get("id") or "").strip()
        }
        return live or None

    def _reconcilable(
        self, entry: Any, task_id: str, *, require_note: bool = True
    ) -> bool:
        """Подлежит ли запись сверке: untriaged ИЛИ pulled-операционная.

        Один предикат на оба места — отбор (:meth:`stale_items`) и перепроверку перед
        записью (:meth:`resolve`), поэтому ``resolve`` не может снять то, чего отбор
        не выбрал бы. ``require_note`` разводит единственное различие между ними:
        отбору живой inbox-файл ОБЯЗАТЕЛЕН (нет файла ⇒ захват разобран, вешать
        «закрыт снаружи» неверно), а записи — нет (файл мог уехать в разбор между
        отбором и решением; статус всё равно надо поставить, и это не ошибка).
        """
        if not isinstance(entry, dict):
            return False
        status = entry.get("status")
        if status == STATUS_UNTRIAGED:
            return True
        if status in _TERMINAL_STATUSES:
            return False  # уже смаршрутизирован/снят — не наше дело
        # pulled-запись: статуса нет вовсе, есть lane. Знание не трогаем (см. докстроку).
        if entry.get("lane") not in ASSIGNMENT_LANES:
            return False
        return not require_note or bool(_inbox_notes(Path(self.inbox_dir), task_id))

    def stale_items(self, source: set[str]) -> list[str]:
        """Захваты, чей ``taskId`` больше не в живом наборе ``source``.

        Untriaged (RECONCILE-1) + pulled-операционные с живым inbox-файлом
        (RECONCILE-2) — критерий целиком в :meth:`_reconcilable`.
        """
        state = _load_state(Path(self.state_path))
        return [
            task_id
            for task_id, entry in state.items()
            if task_id not in source and self._reconcilable(entry, task_id)
        ]

    def resolve(self, item: str) -> None:
        """Пометить ``resolved_external`` + архивировать inbox-заметку (не удалять).

        Перечитывает и перепроверяет пригодность записи (не снимаем терминальные и
        знаниевые), пишет один раз. Файла уже нет (разобрали между отбором и
        решением) → просто статус, без ошибки. Аудит — только id (без текста
        захвата). К TickTick не обращаемся вовсе: завершение задач ТАМ — не наш
        контракт."""
        state_path = Path(self.state_path)
        state = _load_state(state_path)
        entry = state.get(item)
        if not self._reconcilable(entry, item, require_note=False):
            return  # уже снят/смаршрутизирован/знаниевый — идемпотентно ничего
        assert isinstance(entry, dict)  # noqa: S101 — сужение типа; гарантировано выше
        resolved_at = self.now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
        entry["status"] = STATUS_RESOLVED_EXTERNAL
        entry["resolved_at"] = resolved_at
        # Текст/теги — «личное задним числом» здесь не нужно: пользователь не
        # rout'ил, задача уже закрыта в TickTick; оставляем скелет для аудита.
        state[item] = entry
        _save_state(state_path, state)
        _archive_inbox_note(Path(self.inbox_dir), item)
        record_event("capture_reconciled", outcome=STATUS_RESOLVED_EXTERNAL)
