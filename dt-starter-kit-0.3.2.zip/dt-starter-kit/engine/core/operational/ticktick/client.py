"""Low-level TickTick Open API V1 client (architecture §7, B0/B2a/B2b).

Responsibilities, kept deliberately thin:

* **read** — ``GET /open/v1/project`` (list projects) and
  ``GET /open/v1/project/{id}/data`` (one project whole:
  ``{project, tasks:[...], columns:[...]}``, tags included);
* **write** (B2b reflection Timetta→TickTick, probe-confirmed forms) —
  ``POST /open/v1/project`` (create list, optional ``groupId`` to file it into an
  existing folder), ``POST /open/v1/project/{id}`` (update list — incl. re-filing
  into a folder by ``groupId``, B2b probe: works), ``POST /open/v1/task`` (create
  task, optional ``parentId`` → parent gains ``childIds``),
  ``POST /open/v1/task/{id}`` (update task),
  ``POST /open/v1/project/{pid}/task/{tid}/complete`` (complete — the task then
  drops out of ``/data``'s open list), ``DELETE /open/v1/project/{pid}/task/{tid}``,
  ``DELETE /open/v1/project/{id}`` (delete a mirror list — teardown/migration);
* exponential backoff on ``429`` / ``5xx`` honouring ``Retry-After`` (B0: no
  documented limits, so backoff is conservative insurance), shared by every verb;
* a hard stop on ``401`` (access token expired → the user must re-issue it;
  no ``refresh_token`` is stored, B0);
* sequential requests only, with a small inter-request pause.

**Scope discipline lives one layer up** (``core.operational.reflect``): this
client is a dumb transport — it will mutate whatever id it is handed. The
guarantee that the engine only ever writes/completes/deletes its *own* marked
objects is enforced by the reflector before it calls a mutating method here.

The token is read by the caller from the environment and passed in; it is
**never logged** and never appears in an exception message.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from typing import Any

import httpx

from core.adapters import AdapterUnavailable

__all__ = [
    "TickTickError",
    "TickTickAuthError",
    "TickTickClient",
    "DEFAULT_BASE_URL",
]

DEFAULT_BASE_URL = "https://api.ticktick.com/open/v1"


class TickTickError(AdapterUnavailable):
    """Any non-recoverable TickTick API error (no token ever in the message).

    Член семейства :class:`core.adapters.AdapterError` (ADAPTER-HONEST-1): код
    ``unavailable``, ``adapter="ticktick"`` — вызывающий слой переводит в конверт п.22."""

    default_adapter = "ticktick"


class TickTickAuthError(TickTickError):
    """HTTP 401 — the access token is missing/expired. Re-issue is on the user."""


class TickTickClient:
    """Sequential V1 client with backoff. Read + write (B2b) verbs.

    Mutating methods are a thin transport: scope-guarding (does the engine own
    this object?) is the reflector's responsibility, not the client's.
    """

    def __init__(
        self,
        token: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 5,
        backoff_base: float = 1.0,
        inter_request_pause: float = 0.2,
        transport: httpx.BaseTransport | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        if not token:
            raise TickTickError(
                "TICKTICK_ACCESS_TOKEN is not set (read it from .env)"
            )
        self.base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._backoff_base = backoff_base
        self._inter_request_pause = inter_request_pause
        self._sleep = sleep
        # Раздельные таймауты: короткий CONNECT (мёртвый/зависший TLS-хендшейк
        # падает быстро, а не висит все 30с — это и растягивало fast-sync до
        # минут при флапающем TickTick), щедрый READ на медленный ответ API.
        # ``timeout`` (число) задаёт read/write/pool; connect фиксируем 8с.
        http_timeout = httpx.Timeout(timeout, connect=min(8.0, timeout))
        # The token lives only in the default headers of the httpx client.
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
            },
            timeout=http_timeout,
            transport=transport,
        )

    def __enter__(self) -> TickTickClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    # -- public read API ------------------------------------------------------

    def list_projects(self) -> list[dict[str, Any]]:
        """``GET /project`` → list of project objects.

        Probe-confirmed shape: ``{id, name, kind, color, sortOrder, viewMode}``;
        ``groupId`` is present only when the project sits in a folder (the key is
        omitted, not null, otherwise).
        """
        data = self._get_json("/project")
        if not isinstance(data, list):
            raise TickTickError("TickTick /project did not return a list")
        return [p for p in data if isinstance(p, dict)]

    def get_project_data(self, project_id: str) -> dict[str, Any]:
        """``GET /project/{id}/data`` → ``{project, tasks:[...], columns:[...]}``.

        Reads the project whole, tasks with their ``tags`` included.
        """
        data = self._get_json(f"/project/{project_id}/data")
        if not isinstance(data, dict):
            raise TickTickError("TickTick /project/{id}/data did not return an object")
        return data

    # -- public write API (B2b reflection) ------------------------------------

    def create_project(
        self, name: str, *, group_id: str | None = None
    ) -> dict[str, Any]:
        """``POST /project`` → the created list object.

        ``group_id`` files the new list into an **existing** folder (B0: a real
        ``groupId`` is honoured on create; the engine never creates folders).
        """
        payload: dict[str, Any] = {"name": name}
        if group_id:
            payload["groupId"] = group_id
        return self._expect_dict(self._send_json("POST", "/project", payload), "create_project")

    def update_project(self, project_id: str, **fields: Any) -> dict[str, Any]:
        """``POST /project/{id}`` → updated list object.

        Used for self-heal re-filing: ``update_project(pid, groupId=...)`` moves
        an existing list into a folder (B2b probe: works on V1).
        """
        payload = {"id": project_id, **fields}
        return self._expect_dict(
            self._send_json("POST", f"/project/{project_id}", payload), "update_project"
        )

    def delete_project(self, project_id: str) -> None:
        """``DELETE /project/{id}`` — used only by teardown (``dt-reflect --reset``)
        to remove the engine's **own** mirror lists (recorded in the crosswalk).
        Scope-guarding (is this list ours?) is the caller's responsibility."""
        self._send_json("DELETE", f"/project/{project_id}", None)

    def create_task(
        self,
        project_id: str,
        title: str,
        *,
        content: str | None = None,
        parent_id: str | None = None,
        tags: list[str] | None = None,
    ) -> dict[str, Any]:
        """``POST /task`` → the created task object.

        ``parent_id`` makes a true subtask (B0: child create echoes no
        ``parentId`` but the parent gains ``childIds`` on re-read).
        """
        payload: dict[str, Any] = {"projectId": project_id, "title": title}
        if content is not None:
            payload["content"] = content
        if parent_id:
            payload["parentId"] = parent_id
        if tags:
            payload["tags"] = tags
        return self._expect_dict(self._send_json("POST", "/task", payload), "create_task")

    def update_task(self, task_id: str, **fields: Any) -> dict[str, Any]:
        """``POST /task/{id}`` → updated task object.

        The caller passes ``project_id=`` (V1 wants the task's project in the
        body) and whatever fields changed (``title``/``content``/...).
        """
        payload = {"id": task_id, **fields}
        return self._expect_dict(
            self._send_json("POST", f"/task/{task_id}", payload), "update_task"
        )

    def complete_task(self, project_id: str, task_id: str) -> None:
        """``POST /project/{pid}/task/{tid}/complete`` — mark a task done.

        After completion the task drops out of ``/project/{id}/data``'s open task
        list (B2b probe), so completion is tracked in the crosswalk, not by
        re-scanning open tasks.
        """
        self._send_json("POST", f"/project/{project_id}/task/{task_id}/complete", None)

    def delete_task(self, project_id: str, task_id: str) -> None:
        """``DELETE /project/{pid}/task/{tid}`` — used only for transfer
        (delete+recreate) of the engine's **own** reflected tasks."""
        self._send_json("DELETE", f"/project/{project_id}/task/{task_id}", None)

    # -- internals ------------------------------------------------------------

    @staticmethod
    def _expect_dict(body: Any, op: str) -> dict[str, Any]:
        if not isinstance(body, dict):
            raise TickTickError(f"TickTick {op} did not return an object")
        return body

    def _get_json(self, path: str) -> Any:
        return self._send_json("GET", path, None)

    def _send_json(self, method: str, path: str, payload: dict[str, Any] | None) -> Any:
        attempt = 0
        while True:
            if self._inter_request_pause:
                self._sleep(self._inter_request_pause)
            resp = self._client.request(method, path, json=payload)
            status = resp.status_code
            if 200 <= status < 300:
                text = resp.text
                if not text or not text.strip():
                    return None  # complete/delete return empty bodies
                try:
                    return resp.json()
                except ValueError as exc:
                    # 2xx с неразборчивым телом — не «пусто» и не голый ValueError:
                    # типизированный отказ адаптера (ADAPTER-HONEST-1).
                    raise TickTickError(
                        f"TickTick: ответ HTTP {status} — не JSON ({str(exc)[:80]})"
                    ) from exc
            if status == 401:
                raise TickTickAuthError(
                    "TickTick returned 401 Unauthorized — the access token is "
                    "missing or expired. Re-issue TICKTICK_ACCESS_TOKEN and "
                    "update .env (no refresh_token is stored; token never logged)."
                )
            if status == 429 or 500 <= status < 600:
                attempt += 1
                if attempt > self._max_retries:
                    raise TickTickError(
                        f"TickTick API gave up after {self._max_retries} retries "
                        f"(last status {status})."
                    )
                self._sleep(self._retry_delay(resp, attempt))
                continue
            raise TickTickError(f"TickTick API error: HTTP {status}")

    def _retry_delay(self, resp: httpx.Response, attempt: int) -> float:
        retry_after = resp.headers.get("Retry-After")
        if retry_after:
            try:
                return max(0.0, float(retry_after))
            except ValueError:
                pass  # HTTP-date form — fall through to exponential backoff.
        return self._backoff_base * (2 ** (attempt - 1))
