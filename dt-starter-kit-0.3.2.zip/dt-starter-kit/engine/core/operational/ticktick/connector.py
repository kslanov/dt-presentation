"""``TickTickConnector`` — TickTick capture connector (architecture §7, B2a).

Implements the **capture** role (role №1 of §7): read a dedicated TickTick
capture project and route its tasks into the vault inbox by tag, read-only to
TickTick. Conformant to the B1 :class:`OperationalConnector` contract.

What is *not* here:

* ``pull_changes`` / ``get_state`` — those serve the Timetta orbit mirror (B1);
  the TickTick connector captures via :meth:`pull_capture` instead, so they are
  explicit "not for TickTick" stubs.
* ``propose_write`` / ``apply_write`` — reflecting Timetta→TickTick structure
  (B2b) and write-back (B3) are stubbed; B2a writes nothing to TickTick.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from core.operational.connector import (
    ChangeSet,
    Cursor,
    OperationalConnector,
    OperationalState,
    StateFilter,
)
from core.operational.ticktick.capture import CaptureResult, pull_capture
from core.operational.ticktick.client import TickTickClient
from core.secrets import get_secret

__all__ = ["TickTickConnector"]


class TickTickConnector(OperationalConnector):
    """Personal-instance capture connector backed by TickTick V1 (read-only)."""

    def __init__(
        self,
        *,
        client: TickTickClient,
        project_id: str,
        inbox_dir: Path,
        state_path: Path,
    ) -> None:
        self.client = client
        self.project_id = project_id
        self.inbox_dir = inbox_dir
        self.state_path = state_path

    @classmethod
    def from_env(cls) -> TickTickConnector:
        """Build from config/env: token + capture-project resolution + paths."""
        from core.config import (
            staging_inbox_path,
            ticktick_capture_project,
            ticktick_state_path,
        )

        token = get_secret("TICKTICK_ACCESS_TOKEN")
        if not token:
            raise RuntimeError(
                "TICKTICK_ACCESS_TOKEN is not set in .env — cannot capture from "
                "TickTick (token never logged)."
            )
        client = TickTickClient(token)
        project_id = ticktick_capture_project(client)
        return cls(
            client=client,
            project_id=project_id,
            inbox_dir=staging_inbox_path(),
            state_path=ticktick_state_path() / "capture_state.json",
        )

    # -- capture (B2a) --------------------------------------------------------

    def pull_capture(self, *, dry_run: bool = False) -> CaptureResult:
        """Read the capture project → route by tag → write inbox files."""
        return pull_capture(
            self.client,
            project_id=self.project_id,
            inbox_dir=self.inbox_dir,
            state_path=self.state_path,
            dry_run=dry_run,
        )

    # -- orbit mirror: served by Timetta, not TickTick ------------------------

    def pull_changes(self, cursor: Cursor | None = None) -> ChangeSet:
        raise NotImplementedError(
            "TickTick captures via pull_capture(); the operational orbit mirror "
            "(pull_changes) is the Timetta connector's job."
        )

    def get_state(self, state_filter: StateFilter | None = None) -> OperationalState:
        raise NotImplementedError(
            "operational state comes from the Timetta mirror, not TickTick."
        )

    # -- write-back: B2b/B3, intentionally not implemented here ---------------

    def propose_write(self, change: Any) -> Any:
        raise NotImplementedError(
            "writing to TickTick (Timetta→TickTick reflection) is B2b; "
            "back-write is B3."
        )

    def apply_write(self, change: Any) -> Any:
        raise NotImplementedError(
            "writing to TickTick (Timetta→TickTick reflection) is B2b; "
            "back-write is B3."
        )
