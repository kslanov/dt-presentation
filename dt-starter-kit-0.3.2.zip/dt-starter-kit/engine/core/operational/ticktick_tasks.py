"""WORK-ATTN-TICKTICK — висящие «свои» задачи TickTick в «Требует внимания».

TickTick — **живой** внешний источник (как календарь Outlook в
:mod:`core.operational.meetings`), поэтому это отдельный live-инструмент, а не
часть :func:`core.operational.work.snapshot` (тот намеренно offline — читает
зеркала/манифест без сети). Свой опрос, своя graceful degradation; ``work_feed``
не трогаем и не замедляем.

:func:`attention` опрашивает **только курируемый capture-лист** ``DT.Захват``
(FIX-1, приёмка): его id резолвит :func:`core.config.ticktick_capture_project`
по ``DT_TICKTICK_CAPTURE_PROJECT_ID``/``…_NAME`` через инъектированный клиент,
дальше — ``get_project_data(pid)`` → открытые ``tasks``. Скан всех
``list_projects`` убран: он заваливал ленту мёртвыми личными списками 2018–2023
(Podcast notes / Ideas / Разное, ``silent_days`` 1200+). Внутри курируемого
списка ``stale`` осмыслен — это незатриаженный захват.

Отбор «висящих»:

* **overdue** — открытая задача с ``dueDate`` в прошлом;
* **stale** — без движения ``days`` дней по ``modifiedTime`` (порог — та же
  конвенция :data:`core.operational.work.STALE_MIN_DAYS`).

**Дедуп против Timetta.** В capture-листе Timetta-зеркал нет (фактически no-op),
но проверку сохраняем: задача с маркером ``⟦tt:…⟧`` (``crosswalk.has_any_marker``)
из «своих» выпадает — на случай, если зеркало туда всё же попало.

Снуз/ack — через тот же серверный механизм, что и ``work_feed``
(:func:`core.operational.work.record_dismissal`): id пункта стабильный
``ticktick:<taskId>``, ``as_of`` = ``modifiedTime`` (ack снимается, когда задачу
снова тронули). Read-only (никаких записей в TickTick). Privacy: наружу только
``title``/``list``/``due``/``silent_days`` — ни контента, ни тегов, ни заметок.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.contract import CODE_UNAVAILABLE, add_warning
from core.operational.crosswalk import has_any_marker
from core.operational.work import (
    STALE_MIN_DAYS,
    _dismiss_path,
    _hidden_predicate,
    _load_json,
)
from core.secrets import get_secret

__all__ = ["MAX_TASKS", "attention"]

# Мягкий кап на длину выдачи, чтобы живой опрос не раздувал ленту внимания.
MAX_TASKS = 40


def _parse_iso(value: Any) -> datetime | None:
    """Толерантный ISO-8601 (``Z``/offset/naive→UTC) → aware UTC, иначе ``None``."""
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)


def _iso_z(value: Any) -> str | None:
    """Нормализовать метку в ``…Z`` (для стабильного ``as_of``); иначе исходная/None."""
    dt = _parse_iso(value)
    if dt is None:
        return str(value) if value else None
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _is_open(task: dict[str, Any]) -> bool:
    """Открытая задача? Завершённые сами выпадают из ``/data``; ``status`` — страховка
    (TickTick: 0 — открыта, 2 — выполнена)."""
    status = task.get("status")
    return status in (None, 0)


def attention(
    *,
    days: int = STALE_MIN_DAYS,
    now: datetime | None = None,
    client: Any | None = None,
    dismiss_path: Path | None = None,
) -> dict[str, Any]:
    """Висящие «свои» задачи из capture-листа ``DT.Захват`` для «Требует внимания».

    Живой опрос через ``client`` (по умолчанию — реальный
    :class:`TickTickClient` на ``TICKTICK_ACCESS_TOKEN``; в тестах инъектируется
    фейковый, без сети). Скоуп — **только** capture-проект
    (:func:`core.config.ticktick_capture_project`, id по env через тот же
    клиент). Всегда возвращает словарь; нет токена / capture-проект не
    сконфигурирован/не резолвится / любой сбой опроса → ``{available: False,
    tasks: [], warning: [{code: "unavailable", reason: …}]}`` (не бросает). Причина
    машиночитаема (CONTRACT-2 С8): «нет токена», «клиент не поднялся» и «опрос упал»
    лечатся по-разному, а раньше были одним флагом.

    Возврат: ``{available, now, days, tasks: [{id, title, list, due, silent_days,
    type, as_of, url}]}`` где ``type`` ∈ ``{"task_overdue", "task_stale"}``.
    """
    now = now or datetime.now(UTC)
    try:
        days = int(days)
    except (TypeError, ValueError):
        days = STALE_MIN_DAYS
    if days < 1:
        days = 1
    now_z = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    def _unavailable(code: str, reason: str, **ctx: Any) -> dict[str, Any]:
        """CONTRACT-2 С8: ``available: false`` + машинная ПРИЧИНА.

        Три разных мира схлопывались в один флаг: токена нет (настроить), проект не
        сконфигурирован (настроить иначе), опрос упал (повторить). Лечится по-разному,
        а выглядело одинаково.
        """
        out = {"available": False, "now": now_z, "days": days, "tasks": []}
        add_warning(out, code, reason, **ctx)
        return out

    if client is None:
        token = get_secret("TICKTICK_ACCESS_TOKEN")
        if not token:
            return _unavailable(
                CODE_UNAVAILABLE,
                "TICKTICK_ACCESS_TOKEN не задан в .env — живой опрос задач невозможен "
                "(лента показывает Timetta и почту)",
                missing="TICKTICK_ACCESS_TOKEN",
            )
        try:
            from core.operational.ticktick.client import TickTickClient

            client = TickTickClient(token)
        except Exception as exc:  # noqa: BLE001 — best-effort; must not break the caller
            return _unavailable(
                CODE_UNAVAILABLE,
                f"клиент TickTick не поднялся: {str(exc)[:120]}",
            )

    try:
        tasks = _collect(client, now=now, days=days)
    except Exception as exc:  # noqa: BLE001 — best-effort; must not break the caller
        # Graceful degradation: недоступность/сеть/битый ответ /
        # capture-проект не сконфигурирован → лента без TickTick, но С ПРИЧИНОЙ.
        return _unavailable(
            CODE_UNAVAILABLE,
            f"опрос capture-листа не удался: {str(exc)[:160]} "
            "(проверь DT_TICKTICK_CAPTURE_PROJECT и доступность API)",
        )

    # Снуз/ack — тем же серверным механизмом, что и work_feed (id ticktick:<taskId>).
    dismissals = _load_json(_dismiss_path(dismiss_path))
    hidden = _hidden_predicate(dismissals if isinstance(dismissals, dict) else {}, now=now)
    tasks = [t for t in tasks if not hidden(t)]

    # Просроченные — вперёд (по глубине просрочки), затем самые «остывшие».
    tasks.sort(key=lambda t: (0 if t["type"] == "task_overdue" else 1, -t["silent_days"]))
    return {
        "available": True,
        "now": now_z,
        "days": days,
        "tasks": tasks[:MAX_TASKS],
    }


def _capture_list_name(client: Any, pid: str) -> str:
    """Имя capture-списка по id (для privacy-поля ``list``); id как фолбэк."""
    try:
        for project in client.list_projects():
            if isinstance(project, dict) and str(project.get("id")) == pid:
                return str(project.get("name") or pid)
    except Exception:  # noqa: BLE001, S110 — best-effort name lookup; fall back to the id
        pass
    return pid


def _collect(
    client: Any,
    *,
    now: datetime,
    days: int,
) -> list[dict[str, Any]]:
    """Висящие «свои» задачи из ОДНОГО capture-листа ``DT.Захват`` (без снуза).

    Только curated-лист (FIX-1): скан всех проектов убран — иначе мёртвые личные
    списки 2018–2023 заваливали ленту. ``ticktick_capture_project`` бросает, если
    capture-проект не сконфигурирован → перехват в :func:`attention` (available:false).
    """
    from core.config import ticktick_capture_project

    pid = ticktick_capture_project(client)
    list_name = _capture_list_name(client, pid)

    data = client.get_project_data(pid)
    if not isinstance(data, dict):
        return []
    out: list[dict[str, Any]] = []
    for task in data.get("tasks") or []:
        if not isinstance(task, dict) or not _is_open(task):
            continue
        # Дедуп против Timetta (в capture-листе зеркал нет — фактически no-op,
        # но задачу с маркером ⟦tt:…⟧ всё равно не показываем).
        if has_any_marker(task):
            continue
        item = _shape(task, list_name, now=now, days=days)
        if item is not None:
            out.append(item)
    return out


def _shape(
    task: dict[str, Any],
    list_name: str,
    *,
    now: datetime,
    days: int,
) -> dict[str, Any] | None:
    """Отобрать «висящую» задачу и привести к privacy-белому виду (иначе ``None``).

    overdue (``dueDate`` в прошлом) главнее stale; свежая без просрочки — не «висит».
    """
    due = _parse_iso(task.get("dueDate"))
    modified = _parse_iso(task.get("modifiedTime")) or _parse_iso(task.get("createdTime"))
    silent_days = 0
    if modified is not None:
        silent_days = round(max(0.0, (now - modified).total_seconds()) / 86400.0)

    if due is not None and due < now:
        kind = "task_overdue"
    elif silent_days >= days:
        kind = "task_stale"
    else:
        return None

    tid = str(task.get("id") or "")
    pid = str(task.get("projectId") or "")
    url = (
        f"https://ticktick.com/webapp/#p/{pid}/tasks/{tid}" if pid and tid else None
    )
    item: dict[str, Any] = {
        "id": f"ticktick:{tid}",
        "title": str(task.get("title") or "").strip() or "(без названия)",
        "list": list_name,
        "due": _iso_z(task.get("dueDate")),
        "silent_days": silent_days,
        "type": kind,
        "as_of": _iso_z(task.get("modifiedTime")) or now.strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    if url:
        item["url"] = url
    return item
