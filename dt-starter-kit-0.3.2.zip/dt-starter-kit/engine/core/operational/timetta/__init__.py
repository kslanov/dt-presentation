"""Timetta read-side connector (architecture §7).

Integration API, OData v4, base ``https://api.timetta.com/odata``. Read only in
B1 — delta-pull of the author's orbit into the derived mirror
(``.derived/timetta/``) and assembly of the ``dt-status`` slice. Write-back is
Track B3.

Probe-confirmed contract (live API, 2026-06-22):

* auth header ``Authorization: Bearer <TIMETTA_API_TOKEN>``;
* ``$select`` / ``$expand`` / ``$filter`` / ``$orderby`` / ``$top`` / ``$skip``
  all supported; pages of 500 with a **relative** ``@odata.nextLink``
  (``Entity?…&$skip=500``);
* delta literal is a bare ``DateTimeOffset``: ``modified gt 2026-01-01T00:00:00Z``
  (no ``datetimeoffset'…'`` wrapper);
* Guid filter literals are bare (``managerId eq <guid>``), string literals are
  single-quoted (``email eq 'a@b.c'``);
* the ``/States`` collection returns **empty** — state names are resolved via
  ``$expand=state($select=id,name,code)`` on the parent entity and cached.
"""

from core.operational.timetta.connector import TimettaConnector

__all__ = ["TimettaConnector"]
