"""Low-level Timetta OData **read-only** client (architecture §7; RETIRE-WRITE-1: записи нет).

Responsibilities, kept deliberately thin:

* GET a collection with ``$select``/``$filter``/``$expand``/``$orderby``/``$top``
  and follow ``@odata.nextLink`` until the collection is exhausted;
* exponential backoff on ``429`` / ``5xx`` honouring ``Retry-After``;
* a hard stop on ``401`` (token expired → the user must re-issue it);
* sequential requests only (no parallel fan-out) with a small inter-request
  pause as rate-limit insurance (≤ 500 req / 10 s tenant limit).

The token is read by the caller from the environment and passed in; it is
**never logged** and never appears in an exception message.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable, Iterator
from typing import Any

import httpx

from core.adapters import AdapterUnavailable

logger = logging.getLogger(__name__)

__all__ = [
    "TimettaError",
    "TimettaAuthError",
    "TimettaClient",
    "DEFAULT_BASE_URL",
    "PAGE_SIZE",
    "READ_ACTIONS",
]

DEFAULT_BASE_URL = "https://api.timetta.com/odata"
# RETIRE-WRITE-1: единственные bound-действия, которые клиент вообще шлёт (POST, но чтение).
READ_ACTIONS: frozenset[str] = frozenset({"GetHistoryFeed"})
PAGE_SIZE = 500  # tenant max page (probe-confirmed); server caps at this anyway.


class TimettaError(AdapterUnavailable):
    """Any non-recoverable Timetta API error (no token ever in the message).

    Член семейства :class:`core.adapters.AdapterError` (ADAPTER-HONEST-1): код
    ``unavailable``, ``adapter="timetta"``."""

    default_adapter = "timetta"


class TimettaNotFoundError(TimettaError):
    """HTTP 404 — сущности нет (``TmtEntityNotFoundException``): её удалили в Timetta.

    ORBIT-2 п.3: удалённая сделка — не «сбой, повторить через 30 минут», а ФАКТ; вызывающий
    слой снимает цель как ``resolved_external`` и не ретраит."""


class TimettaAuthError(TimettaError):
    """HTTP 401 — the API token is missing/expired. Re-issue is on the user."""


class TimettaClient:
    """Sequential, paginating OData read client with backoff."""

    def __init__(
        self,
        token: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        max_retries: int = 5,
        backoff_base: float = 1.0,
        inter_request_pause: float = 0.05,
        transport: httpx.BaseTransport | None = None,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        if not token:
            raise TimettaError("TIMETTA_API_TOKEN is not set (read it from .env)")
        self.base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._backoff_base = backoff_base
        self._inter_request_pause = inter_request_pause
        self._sleep = sleep
        # The token lives only in the default headers of the httpx client.
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
            },
            timeout=timeout,
            transport=transport,
        )

    def __enter__(self) -> TimettaClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    # -- public API -----------------------------------------------------------

    def get_collection(
        self,
        entity_set: str,
        *,
        select: str | None = None,
        filter: str | None = None,
        expand: str | None = None,
        order_by: str | None = None,
        top: int | None = None,
    ) -> Iterator[dict[str, Any]]:
        """Yield every object of ``entity_set`` matching the query.

        Follows ``@odata.nextLink`` transparently, so the caller sees one flat
        stream regardless of how many physical pages the server returned.
        """
        params: dict[str, Any] = {}
        if select:
            params["$select"] = select
        if filter:
            params["$filter"] = filter
        if expand:
            params["$expand"] = expand
        if order_by:
            params["$orderby"] = order_by
        if top is not None:
            params["$top"] = top

        url: str | None = f"/{entity_set}"
        first = True
        while url is not None:
            data = self._get_json(url, params if first else None)
            first = False
            # OData-коллекция ОБЯЗАНА нести ``value`` (список). Раньше отсутствие ключа
            # давало «0 элементов» — а вставленный в зеркало пустой набор выглядит как
            # «сделок нет». Ответ без value — отказ адаптера (ADAPTER-HONEST-1).
            if not isinstance(data, dict) or not isinstance(data.get("value"), list):
                raise TimettaError(
                    f"Timetta GET {entity_set}: в ответе нет списка value — "
                    "ответ неожиданной формы, это не пустая коллекция"
                )
            for item in data["value"]:
                if isinstance(item, dict):
                    yield item
            next_link = data.get("@odata.nextLink")
            url = self._absolute(next_link) if next_link else None

    def get_entity(
        self, entity_set: str, guid: str, *, select: str | None = None
    ) -> dict[str, Any]:
        """``GET /{Set}(<guid>)`` → one entity (B3a checklist read-modify-write).

        OData v4 keys are bare in the path (probe-confirmed). Used to read a
        deal's ``checkList`` immediately before a ``PATCH`` so the write merges
        onto the freshest array (Timetta-wins, minimal RMW window — B3-0).
        """
        params = {"$select": select} if select else None
        data = self._get_json(f"/{entity_set}({guid})", params)
        if not isinstance(data, dict):
            raise TimettaError(f"Timetta GET {entity_set}(<guid>) did not return an object")
        return data

    def call_action(
        self, entity_set: str, guid: str, action: str, payload: dict[str, Any]
    ) -> dict[str, Any] | None:
        """``POST /{Set}(<guid>)/WP.<action>`` — bound OData-действие, **только чтение**.

        RETIRE-WRITE-1: записи в Timetta нет. Здесь допустимы лишь действия из
        :data:`READ_ACTIONS` (``GetHistoryFeed`` — POST без побочных эффектов, лента изменений
        коллег, ORBIT-3). Любое другое (``SetState`` и пр.) — :class:`TimettaError` ДО сети:
        запись невозможна по построению, а не по договорённости. Мутирующих методов у клиента
        нет вовсе (``PATCH``/``POST /<Set>`` — в архивной ветке ``archive/timetta-write``).
        """
        if action not in READ_ACTIONS:
            raise TimettaError(
                f"Timetta write is disabled (RETIRE-WRITE-1): action {action!r} is not a "
                f"read action ({', '.join(sorted(READ_ACTIONS))})"
            )
        return self._send_json_action("POST", f"/{entity_set}({guid})/WP.{action}", payload)

    def call_function(
        self, entity_set: str, guid: str, function: str, args: str = ""
    ) -> Any:
        """``GET /{Set}(<guid>)/WP.<function>[(<args>)]`` — bound OData-**функция** (ORBIT-3).

        Только чтение: ``WP.GetStateHistory`` (переходы стадий), ``WP.GetActivityItems(
        showSystemEvents=false)`` (комментарии). Функции без параметров вызываются БЕЗ
        скобок (спайк ORBIT-2), с параметрами — ``args`` дословно внутри скобок. Ответ — тело
        как есть (``{"value": […]}`` или список/объект); 404 на исчезнувшей сделке →
        :class:`TimettaNotFoundError`.
        """
        tail = f"({args})" if args else ""
        return self._get_json(f"/{entity_set}({guid})/WP.{function}{tail}", None)

    # -- internals ------------------------------------------------------------

    def _send_json_action(
        self, method: str, url: str, payload: dict[str, Any] | None
    ) -> dict[str, Any] | None:
        """POST a bound read action (``GetHistoryFeed``) and parse its JSON body.

        Backoff on 429/5xx, 401 hard-stop and OData-error surfacing, as for GET.
        """
        attempt = 0
        while True:
            if self._inter_request_pause:
                self._sleep(self._inter_request_pause)
            resp = self._client.request(method, url, json=payload)
            status = resp.status_code
            if 200 <= status < 300:
                text = resp.text
                if not text or not text.strip():
                    return None
                try:
                    body = resp.json()
                except ValueError:
                    return None
                return body if isinstance(body, dict) else None
            if status == 404:
                raise TimettaNotFoundError(
                    f"Timetta API error: HTTP 404 — {self._error_detail(resp)}"
                )
            if status == 401:
                raise TimettaAuthError(
                    "Timetta returned 401 Unauthorized — the API token is "
                    "missing or expired. Re-issue TIMETTA_API_TOKEN and update "
                    ".env (token never logged)."
                )
            if status == 429 or 500 <= status < 600:
                attempt += 1
                if attempt > self._max_retries:
                    raise TimettaError(
                        f"Timetta API gave up after {self._max_retries} retries "
                        f"(last status {status}) — {self._error_detail(resp)}"
                    )
                self._sleep(self._retry_delay(resp, attempt))
                continue
            raise TimettaError(
                f"Timetta API error: HTTP {status} — {self._error_detail(resp)}"
            )

    def _absolute(self, next_link: str) -> str:
        """Resolve a (relative or absolute) ``@odata.nextLink`` to a full URL.

        Probe showed the link is relative without a leading slash
        (``Deals?…&$skip=500``); make it absolute deterministically rather than
        relying on httpx base-url join semantics.
        """
        if next_link.startswith(("http://", "https://")):
            return next_link
        return f"{self.base_url}/{next_link.lstrip('/')}"

    def _get_json(self, url: str, params: dict[str, Any] | None) -> dict[str, Any]:
        attempt = 0
        while True:
            if self._inter_request_pause:
                self._sleep(self._inter_request_pause)
            resp = self._client.get(url, params=params)
            status = resp.status_code
            if status == 200:
                try:
                    return resp.json()
                except ValueError as exc:
                    raise TimettaError(
                        f"Timetta: ответ HTTP 200 — не JSON ({str(exc)[:80]})"
                    ) from exc
            if status == 404:
                raise TimettaNotFoundError(
                    f"Timetta API error: HTTP 404 — {self._error_detail(resp)}"
                )
            if status == 401:
                raise TimettaAuthError(
                    "Timetta returned 401 Unauthorized — the API token is "
                    "missing or expired. Re-issue TIMETTA_API_TOKEN and update "
                    ".env (token never logged)."
                )
            if status == 429 or 500 <= status < 600:
                attempt += 1
                if attempt > self._max_retries:
                    raise TimettaError(
                        f"Timetta API gave up after {self._max_retries} retries "
                        f"(last status {status}) — {self._error_detail(resp)}"
                    )
                self._sleep(self._retry_delay(resp, attempt))
                continue
            raise TimettaError(
                f"Timetta API error: HTTP {status} — {self._error_detail(resp)}"
            )

    @staticmethod
    def _error_detail(resp: httpx.Response) -> str:
        """A short, safe snippet of the error body (OData ``error`` detail).

        The token lives in the request *headers*, never in the response body, so
        echoing the body leaks nothing. We surface it because a Timetta 4xx
        (esp. 400) carries the actual reason (rejected property, bad value) in
        ``{"error":{"message":…}}`` — without it a write bug is undebuggable.
        Truncated defensively.
        """
        try:
            body = resp.json()
            if isinstance(body, dict) and isinstance(body.get("error"), dict):
                err = body["error"]
                msg = err.get("message") or err.get("code") or ""
                target = err.get("target")
                detail = f"{msg} (target={target})" if target else str(msg)
            else:
                detail = str(body)
        except ValueError:
            detail = resp.text or ""
        detail = " ".join(detail.split())  # collapse whitespace/newlines
        return detail[:500]

    def _retry_delay(self, resp: httpx.Response, attempt: int) -> float:
        retry_after = resp.headers.get("Retry-After")
        if retry_after:
            try:
                return max(0.0, float(retry_after))
            except ValueError:
                pass  # HTTP-date form — fall through to exponential backoff.
        return self._backoff_base * (2 ** (attempt - 1))
