"""ORBIT-3 п.4 — комментарии сделки: ТОЛЬКО ЧТЕНИЕ (спайк ORBIT-2 §3.7).

``GET /Deals(id)/WP.GetActivityItems(showSystemEvents=false)`` — параметр ``showSystemEvents``
обязателен (без него 404). Возвращает последние N комментариев (автор, дата, текст — обрезан).

Живое чтение, НИЧЕГО не сохраняется (ни в зеркале, ни в ленте изменений): текст комментариев
виден только в момент раскрытия карточки. Запись (``AddComment``) намеренно НЕ внедрена — у неё
побочка (``mentionedUserIds`` шлёт уведомление), это P2.
"""

from __future__ import annotations

from typing import Any

from core.operational.timetta.client import TimettaError

__all__ = ["read_comments", "COMMENT_TEXT_CAP"]

COMMENT_TEXT_CAP = 400  # символов текста комментария в выдаче


def _cut(text: Any) -> str:
    s = " ".join(str(text or "").split())
    return s if len(s) <= COMMENT_TEXT_CAP else s[: COMMENT_TEXT_CAP - 1] + "…"


def read_comments(client: Any, deal_guid: str, *, limit: int = 5) -> list[dict[str, Any]]:
    """Последние ``limit`` комментариев сделки, свежие первыми: ``[{at, author, text}]``.

    Системные события не запрашиваются. Сбой API → исключение (``TimettaError``/
    ``TimettaNotFoundError``): решает вызывающий (конверт деградации на границе MCP).
    """
    if not hasattr(client, "call_function"):
        raise TimettaError("клиент Timetta не умеет читать комментарии (нет call_function)")
    raw = client.call_function("Deals", deal_guid, "GetActivityItems", "showSystemEvents=false")
    items = raw.get("value", []) if isinstance(raw, dict) else raw
    rows = []
    for it in items if isinstance(items, list) else []:
        if not isinstance(it, dict) or str(it.get("type") or "Comment") != "Comment":
            continue
        raw_author = it.get("createdBy")
        author: dict[str, Any] = raw_author if isinstance(raw_author, dict) else {}
        rows.append({
            "at": str(it.get("created") or ""),
            "author": author.get("name") or "коллега",
            "text": _cut(it.get("text")),
        })
    rows.sort(key=lambda r: r["at"], reverse=True)
    return rows[: max(0, limit)]
