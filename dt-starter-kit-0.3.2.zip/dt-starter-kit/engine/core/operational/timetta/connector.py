"""``TimettaConnector`` — read-only operational connector (architecture §7).

Implements :meth:`pull_changes` (delta-pull → mirror → ChangeSet) and
:meth:`get_state` (assemble a slice from the mirror, **no network**), plus two live READS
(:meth:`read_comments`, :meth:`read_checklist`).

**RETIRE-WRITE-1 (решение К. 2026-10-19): записи в Timetta нет.** Запись (``Deal.checkList``,
``WP.SetState``, ``POST /Issues``), гейт колец записи и очередь подтверждений уехали в архивную
ветку ``archive/timetta-write`` (тег ``archive-timetta-write-2026-10-20``). Адресат операционных
поручений — администратор CRM (``core.operational.assignment``). Статический гард
``tests/test_no_timetta_write.py`` держит это: в ``core``/``mcp-server``/``cli`` нет вызовов
записывающих методов клиента.
"""

from __future__ import annotations

from typing import Any

from core.operational import orbit as _orbit
from core.operational.connector import (
    ChangeSet,
    Cursor,
    Deal,
    Issue,
    OperationalConnector,
    OperationalState,
    Organization,
    Project,
    StateFilter,
)
from core.operational.timetta import mapping as _mapping
from core.operational.timetta import mirror as _mirror
from core.operational.timetta.client import TimettaClient
from core.operational.timetta.mirror import CollectionReader, MirrorStore
from core.secrets import get_secret

__all__ = ["TimettaConnector", "deal_presale_project", "discover_user_id"]


def deal_presale_project(deal: dict[str, Any]) -> str | None:
    """The deal's pre-sale project id (``Deal.projectId`` / nav ``project``), or ``None``.

    The pre-sale project is **where a project-Issue may be created** (B3b-4): the
    engine creates an Issue only in a deal's *existing* project and never creates
    the project itself (web Timetta only). Accepts either the neutral mirror shape
    (``project_id``) or a raw OData head (``projectId``); a blank/missing value →
    ``None`` (⇒ "no pre-sale project → notify, do not create").
    """
    raw = deal.get("project_id", deal.get("projectId"))
    pid = str(raw).strip() if raw else ""
    return pid or None


def _match(token: str, *fields: str | None) -> bool:
    """Case-insensitive substring match of ``token`` against any field."""
    needle = token.strip().lower()
    return any(needle in f.lower() for f in fields if f)


class TimettaConnector(OperationalConnector):
    """Work-instance operational connector backed by Timetta + a local mirror."""

    def __init__(
        self,
        store: MirrorStore,
        *,
        client: CollectionReader | None = None,
        user_id: str | None = None,
        watchlist_ids: list[str] | None = None,
    ) -> None:
        self.store = store
        self.client = client
        self.user_id = user_id
        self.watchlist_ids = watchlist_ids or []

    @classmethod
    def from_env(cls) -> TimettaConnector:
        """Build from config/env. Mirror always; client only if a token is set."""
        from core.config import timetta_mirror_path, timetta_user_id

        store = MirrorStore(timetta_mirror_path())
        from core.operational import watchlist

        token = get_secret("TIMETTA_API_TOKEN")
        client = TimettaClient(token) if token else None
        # ORBIT-3: ручное «слежу» с пульта доезжает до pull → recompute (флаг watched)
        return cls(store, client=client, user_id=timetta_user_id(),
                   watchlist_ids=watchlist.load_ids())

    # -- read (B1) ------------------------------------------------------------

    def pull_changes(self, cursor: Cursor | None = None) -> ChangeSet:
        """Delta-read the orbit (network) → update mirror → return ChangeSet.

        ``cursor`` is accepted for the interface; the authoritative cursor lives
        in the mirror (``cursor.json``) and is what :func:`mirror.pull` reads and
        advances, so re-pulls stay idempotent across process restarts.
        """
        if self.client is None:
            raise RuntimeError(
                "TIMETTA_API_TOKEN is not set — cannot pull (read-only view "
                "still works from the existing mirror)."
            )
        if not self.user_id:
            raise RuntimeError(
                "Timetta user id is unknown — set DT_TIMETTA_USER_ID (or run "
                "discovery via DT_TIMETTA_USER_EMAIL) so the orbit can be scoped."
            )
        return _mirror.pull(
            self.client,
            self.store,
            self.user_id,
            watchlist_ids=self.watchlist_ids,
        )

    def get_state(self, state_filter: StateFilter | None = None) -> OperationalState:
        """Assemble the operational slice from the mirror (no network)."""
        sf = state_filter or StateFilter()

        # ORBIT-2: сделки/задачи/проекты — только запрошенных колец (дефолт ``mine``).
        sl = _orbit.orbit_slice(self.store, sf.rings, me=self.user_id)
        deals = [Deal(**d) for d in sl["deals"] if d.get("is_active", True)]
        projects = [Project(**p) for p in sl["projects"] if p.get("is_active", True)]
        issues = [Issue(**i) for i in sl["issues"] if i.get("is_active", True)]
        orgs = [Organization(**o) for o in self.store.all("organizations")]

        if sf.client:
            deals = [d for d in deals if _match(sf.client, d.organization_name, d.organization_id)]
            projects = [
                p for p in projects if _match(sf.client, p.organization_name, p.organization_id)
            ]
            orgs = [o for o in orgs if _match(sf.client, o.name, o.code, o.id)]
        if sf.project:
            pmatch = {p.id for p in projects if _match(sf.project, p.name, p.code, p.id)}
            projects = [p for p in projects if p.id in pmatch]
            deals = [d for d in deals if d.project_id in pmatch]
            issues = [i for i in issues if i.project_id in pmatch]
        if sf.deal:
            dmatch = {d.id for d in deals if _match(sf.deal, d.name, d.code, d.id)}
            deals = [d for d in deals if d.id in dmatch]
            issues = [i for i in issues if i.deal_id in dmatch]

        deals.sort(key=lambda d: (d.modified or ""), reverse=True)
        issues.sort(key=lambda i: (i.due_date or "9999"))
        projects.sort(key=lambda p: (p.name or "").lower())
        return OperationalState(
            deals=deals, projects=projects, issues=issues, organizations=orgs
        )

    # -- live reads (no side effects) ------------------------------------------

    def _read_client(self) -> TimettaClient:
        """The client, asserted live (a real :class:`TimettaClient`) — for READS only."""
        client = self.client
        if not isinstance(client, TimettaClient):
            raise RuntimeError(
                "Timetta live read needs a client — set TIMETTA_API_TOKEN "
                "in .env (token never logged)."
            )
        return client

    def read_comments(self, deal_guid: str, limit: int = 5) -> list[dict[str, Any]]:
        """Последние комментарии сделки (ORBIT-3, живое чтение, без записи и без сохранения)."""
        from core.operational.timetta import comments as _comments

        return _comments.read_comments(self._read_client(), deal_guid, limit=limit)

    def read_checklist(self, deal_guid: str) -> list[dict[str, Any]]:
        """Read a deal's **live** ``Deal.checkList`` (neutral item shape). Read-only."""
        raw = self._read_client().get_entity("Deals", deal_guid, select="id,checkList")
        return _mapping.map_checklist(raw.get("checkList"))


def discover_user_id(client: CollectionReader, email: str) -> str | None:
    """Look up a user's Guid by email (one-off, for ``.env`` bootstrap).

    The string literal is single-quoted (probe-confirmed). Returns the Guid or
    ``None`` if no user matches.
    """
    safe = email.replace("'", "''")
    for raw in client.get_collection(
        "Users", select="id,name,email,isActive", filter=f"email eq '{safe}'"
    ):
        if raw.get("id"):
            return str(raw["id"])
    return None
