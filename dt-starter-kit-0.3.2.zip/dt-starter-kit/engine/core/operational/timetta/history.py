"""ORBIT-3 п.1 — лента «что изменили коллеги»: история сделок с автором, без текстов.

Дельта зеркала (``modified gt cursor``) видит ЧУЖИЕ правки, но не говорит, кто и что. Для
изменившихся с прошлого синка сделок (а не для всех 47 — бюджет вызовов) зовём:

* ``POST /Deals(id)/WP.GetHistoryFeed`` — автор + список изменённых полей (diff);
* ``GET  /Deals(id)/WP.GetStateHistory`` — переходы стадий (из → в, кто).

**Риск спайка §7.6:** история может не показывать правки ``Deal.checkList`` (вложенная коллекция).
Компенсация — сравнение снапшотов ``check_list`` ДО/ПОСЛЕ дельты зеркала (:func:`snapshot_entries`):
строка с пометкой источника ``snapshot`` (счётчики «+N / выполнено K», без заголовков пунктов).
Если история сама отдала правку чек-листа — снапшот-строку не дублируем.

**Privacy.** Стор ``history_feed.json`` хранит автора, дату, ИМЕНА изменённых полей и (у стадий)
названия стадий. Значения полей, свободный текст комментариев стадий/правок, заголовки пунктов
чек-листа и суммы не сохраняются никогда. Только записи ``actor != me`` (свои правки — не лента).

Best-effort: сбой истории не ломает pull (зеркало важнее ленты) — ошибка логируется, ``since`` не
сдвигается, следующий синк повторит окно (дубли гасит детерминированный ключ записи).
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.adapters import load_json_store
from core.operational import orbit
from core.operational.crosswalk import checkitem_id
from core.operational.timetta.client import TimettaAuthError, TimettaError, TimettaNotFoundError
from core.operational.timetta.mapping import parse_modified

__all__ = [
    "SRC_HISTORY",
    "SRC_STATE",
    "SRC_SNAPSHOT",
    "HistoryResult",
    "history_days",
    "snapshot_entries",
    "pull_history",
    "load_feed",
    "feed_rows",
    "feed_summary",
    "colleagues_summary",
    "describe",
    "parse_dt",
    "needs_backfill",
    "enabled",
    "HISTORY_FILE",
]

logger = logging.getLogger(__name__)

HISTORY_FILE = "history_feed"
_META_FILE = "history_meta.json"

SRC_HISTORY = "history"  # поля сделки из GetHistoryFeed
SRC_STATE = "history"  # переходы стадий — тоже история Timetta (метка источника одна)
SRC_SNAPSHOT = "snapshot"  # компенсация: сравнение check_list до/после

DEFAULT_DAYS = 14
RETAIN_DAYS = 120  # старше — вычищаем при записи
OVERLAP = timedelta(hours=2)  # нахлёст окна при повторе (дубли гасит ключ записи)
_PAGE_TAKE = 50
_MAX_PAGES = 5
# Поля, которые GetHistoryFeed дублирует про стадию/служебное: стадию даёт GetStateHistory.
_STATE_FIELDS = frozenset({"state", "stateentered", "stateid", "modified", "modifiedby"})
_LABELS = {
    "description": "описание", "manager": "ведущий", "project": "проект", "isactive": "активность",
    "organization": "организация", "legalentity": "юрлицо", "checklist": "чек-лист",
    "name": "название", "amount": "бюджет", "probability": "вероятность",
    "closedate": "срок закрытия", "enddate": "срок закрытия",
}


def history_days() -> int:
    """Окно ленты, дней (``DT_HISTORY_DAYS``, дефолт 14 — как в спайке)."""
    try:
        return max(1, int(os.environ.get("DT_HISTORY_DAYS", DEFAULT_DAYS)))
    except ValueError:
        return DEFAULT_DAYS


def enabled() -> bool:
    """``DT_HISTORY_FEED=0`` выключает ленту (pull не зовёт историю и не сравнивает снапшоты)."""
    return os.environ.get("DT_HISTORY_FEED", "1").strip().lower() not in {"0", "false", "no"}


def _iso(dt: datetime) -> str:
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return parse_modified(value)
    except ValueError:
        return None


def _key(deal_id: str, at: str, source: str, kind: str, detail: str, actor: str) -> str:
    raw = "|".join((deal_id.lower(), at, source, kind, detail, actor.lower()))
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]  # noqa: S324 — не крипто, ключ дедупа


@dataclass
class HistoryResult:
    """Анонимная сводка шага истории (счётчики — без имён/заголовков)."""

    deals_checked: int = 0  # сделок, по которым пошли вызовы API
    calls: int = 0  # вызовов API (бюджет)
    added: int = 0  # новых записей ленты (actor != me)
    skipped_me: int = 0  # собственные правки — не в ленту
    snapshot_added: int = 0  # записей-компенсаций по снапшоту check_list
    gone: int = 0  # сделка исчезла (404) — пропуск, сверка пометит
    errors: int = 0  # прочие сбои API (шаг продолжился)
    skipped: str | None = None  # причина, если шаг не запускался ("no_api"/"disabled")
    notes: list[str] = field(default_factory=list)


# --- стор ----------------------------------------------------------------------


def load_feed(root: Path) -> dict[str, dict[str, Any]]:
    """``{ключ: запись}``; нет файла → ``{}``. Битый файл — ``StoreUnavailableError``."""
    data = load_json_store(Path(root) / f"{HISTORY_FILE}.json", adapter="history_feed", expect=dict)
    return data if data is not None else {}


def _save_feed(root: Path, table: dict[str, dict[str, Any]], *, now: datetime) -> None:
    cutoff = now - timedelta(days=RETAIN_DAYS)
    table = {
        k: v for k, v in table.items()
        if (_parse(v.get("at")) or now) >= cutoff
    }
    Path(root).mkdir(parents=True, exist_ok=True)
    (Path(root) / f"{HISTORY_FILE}.json").write_text(
        json.dumps(table, ensure_ascii=False, indent=1, sort_keys=True), encoding="utf-8"
    )


def parse_dt(value: Any) -> datetime | None:
    """Публичный разбор ``DateTimeOffset`` (``None`` при мусоре) — для шага в ``mirror.pull``."""
    return _parse(value)


def needs_backfill(root: Path) -> bool:
    """Ленту ещё ни разу не снимали (нет ``history_meta.json``) — первое окно по зеркалу."""
    return _load_since(Path(root)) is None


def _load_since(root: Path) -> datetime | None:
    data = load_json_store(Path(root) / _META_FILE, adapter="history_feed", expect=dict)
    return _parse((data or {}).get("since"))


def _save_since(root: Path, since: datetime) -> None:
    Path(root).mkdir(parents=True, exist_ok=True)
    (Path(root) / _META_FILE).write_text(json.dumps({"since": _iso(since)}), encoding="utf-8")


# --- компенсация: снапшоты check_list --------------------------------------------


def _checklist_diff(old: list[Any], new: list[Any]) -> dict[str, int]:
    def by_id(items: list[Any]) -> dict[str, dict[str, Any]]:
        return {checkitem_id(i.get("title")): i for i in items if isinstance(i, dict)}

    before, after = by_id(old), by_id(new)
    added = len(after.keys() - before.keys())
    removed = len(before.keys() - after.keys())
    done = sum(
        1 for k, i in after.items()
        if k in before and i.get("fulfilled") and not before[k].get("fulfilled")
    )
    return {"added": added, "removed": removed, "done": done}


def snapshot_entries(
    old_deals: dict[str, dict[str, Any]],
    new_deals: list[dict[str, Any]],
    *,
    me: str | None,
) -> list[dict[str, Any]]:
    """Записи-компенсации по сравнению ``check_list`` ДО (зеркало) и ПОСЛЕ (дельта) — оффлайн.

    Только для сделок, которые уже были в зеркале (первичная загрузка — не «изменение»), и только
    если автор последней правки (``modifiedBy``) известен и не я. Хранятся счётчики, не заголовки.
    """
    me_l = str(me or "").lower()
    out: list[dict[str, Any]] = []
    for deal in new_deals:
        did = str(deal.get("id") or "")
        old = old_deals.get(did)
        if not did or old is None:
            continue
        diff = _checklist_diff(old.get("check_list") or [], deal.get("check_list") or [])
        if not any(diff.values()):
            continue
        actor_id = str(deal.get("last_change_by_id") or "")
        if not actor_id or actor_id.lower() == me_l:
            continue
        at = str(deal.get("last_change_at") or deal.get("modified") or "")
        out.append({
            "deal_id": did, "at": at, "actor_id": actor_id,
            "actor_name": deal.get("last_change_by_name"),
            "source": SRC_SNAPSHOT, "kind": "checklist", **{k: v for k, v in diff.items() if v},
        })
    return out


# --- вызовы API ----------------------------------------------------------------


def _items(body: Any) -> list[dict[str, Any]]:
    if isinstance(body, dict):
        body = body.get("value", body.get("items", []))
    return [i for i in body if isinstance(i, dict)] if isinstance(body, list) else []


def _feed_entries(
    client: Any, deal_id: str, since: datetime, res: HistoryResult
) -> list[dict[str, Any]]:
    """Записи из GetHistoryFeed (по страницам курсора, не больше ``_MAX_PAGES``)."""
    out: list[dict[str, Any]] = []
    body: dict[str, Any] = {"take": _PAGE_TAKE, "startDate": _iso(since)}
    for _ in range(_MAX_PAGES):
        res.calls += 1
        page = client.call_action("Deals", deal_id, "GetHistoryFeed", body)
        page = page if isinstance(page, dict) else {}
        for it in _items(page):
            raw_actor = it.get("actor")
            actor: dict[str, Any] = raw_actor if isinstance(raw_actor, dict) else {}
            names = [
                str(c.get("propertyName"))
                for c in it.get("changes") or []
                if isinstance(c, dict) and c.get("propertyName")
            ]
            fields = sorted({n for n in names if n.lower() not in _STATE_FIELDS})
            if not fields:
                continue  # чисто стадийная/служебная правка — её даёт GetStateHistory
            out.append({
                "deal_id": deal_id, "at": str(it.get("createdAt") or ""),
                "actor_id": str(actor.get("id") or ""), "actor_name": actor.get("name"),
                "source": SRC_HISTORY, "kind": "fields", "fields": fields,
            })
        cursor = page.get("nextCursor")
        if not (page.get("hasMore") and cursor):
            break
        body = {**body, "cursor": cursor}
    return out


def _state_entries(
    client: Any, deal_id: str, since: datetime, states: dict[str, dict[str, Any]],
    users: dict[str, dict[str, Any]], res: HistoryResult,
) -> list[dict[str, Any]]:
    res.calls += 1
    raw = client.call_function("Deals", deal_id, "GetStateHistory")
    out: list[dict[str, Any]] = []
    for it in _items(raw):
        at = _parse(it.get("created"))
        if at is None or at < since:
            continue
        actor_id = str(it.get("realPerformerId") or it.get("performerId") or "")
        name = (users.get(actor_id) or {}).get("name")
        out.append({
            "deal_id": deal_id, "at": _iso(at), "actor_id": actor_id, "actor_name": name,
            "source": SRC_STATE, "kind": "stage",
            "from_state": (states.get(str(it.get("fromStateId"))) or {}).get("name"),
            "to_state": (states.get(str(it.get("toStateId"))) or {}).get("name"),
        })
    return out


def pull_history(
    client: Any,
    root: Path,
    me: str | None,
    candidate_ids: list[str],
    *,
    states: dict[str, dict[str, Any]] | None = None,
    users: dict[str, dict[str, Any]] | None = None,
    extra: list[dict[str, Any]] | None = None,
    now: datetime | None = None,
) -> HistoryResult:
    """Шаг ленты: история изменившихся сделок + записи-компенсации ``extra`` → стор.

    ``candidate_ids`` — ТОЛЬКО сделки, изменившиеся с прошлого синка (дельта pull), либо при первом
    запуске — сделки зеркала, менявшиеся в окне ``DT_HISTORY_DAYS``. ``client`` без
    ``call_action``/``call_function`` (чтение-фейк) → API не зовём, снапшот-записи всё равно
    сохраняем (``skipped="no_api"``).
    """
    res = HistoryResult()
    now = now or datetime.now(UTC)
    since_prev = _load_since(root)
    since = (since_prev - OVERLAP) if since_prev else now - timedelta(days=history_days())
    states = states or {}
    users = users or {}
    me_l = str(me or "").lower()
    can_call = hasattr(client, "call_action") and hasattr(client, "call_function")
    if not can_call:
        res.skipped = "no_api"
    fetched: list[dict[str, Any]] = []
    ok = True
    if can_call:
        for did in dict.fromkeys(candidate_ids):  # дедуп с сохранением порядка
            res.deals_checked += 1
            try:
                fetched += _feed_entries(client, did, since, res)
                fetched += _state_entries(client, did, since, states, users, res)
            except TimettaNotFoundError:
                res.gone += 1  # сделки уже нет — сверка удалений пометит её
            except TimettaAuthError:
                res.errors += 1
                res.notes.append("auth")
                ok = False
                break  # токен не принят — остальные вызовы бессмысленны
            except TimettaError as exc:
                res.errors += 1
                ok = False
                logger.warning("history: %s — %s", did[-4:], type(exc).__name__)
    # снапшот-запись по сделке не нужна, если история сама отдала правку чек-листа
    covered = {e["deal_id"] for e in fetched if "CheckList" in (e.get("fields") or [])}
    snap = [e for e in (extra or []) if e["deal_id"] not in covered]
    table = load_feed(root)
    for e in fetched + snap:
        if str(e.get("actor_id") or "").lower() == me_l and me_l:
            res.skipped_me += 1
            continue
        detail = ",".join(e.get("fields") or []) or f"{e.get('from_state')}>{e.get('to_state')}"
        if e["source"] == SRC_SNAPSHOT:
            detail = f"{e.get('added', 0)}/{e.get('removed', 0)}/{e.get('done', 0)}"
        key = _key(e["deal_id"], e["at"], e["source"], e["kind"], detail, e.get("actor_id", ""))
        if key in table:
            continue
        table[key] = {"id": key, **e}
        res.added += 1
        res.snapshot_added += e["source"] == SRC_SNAPSHOT
    if res.added or table:
        _save_feed(root, table, now=now)
    if ok and can_call:
        _save_since(root, now)  # окно сдвигаем только после чистого прохода
    return res


# --- чтение ленты ---------------------------------------------------------------


def describe(entry: dict[str, Any]) -> str:
    """Человекочитаемая строка действия (без значений полей и заголовков пунктов)."""
    kind = entry.get("kind")
    if kind == "stage":
        a, b = entry.get("from_state"), entry.get("to_state")
        return f"стадия {a} → {b}" if a else f"стадия → {b}"
    if kind == "checklist":
        parts = []
        if entry.get("added"):
            parts.append(f"+{entry['added']}")
        if entry.get("removed"):
            parts.append(f"−{entry['removed']}")
        if entry.get("done"):
            parts.append(f"выполнено {entry['done']}")
        return "чек-лист: " + ", ".join(parts) if parts else "чек-лист изменён"
    labels = [_LABELS.get(str(f).lower(), str(f)) for f in entry.get("fields") or []]
    return "изменил(а): " + ", ".join(dict.fromkeys(labels)) if labels else "изменение"


def feed_rows(
    store: Any,
    me: str | None,
    *,
    rings: Any = None,
    days: int | None = None,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    """Строки ленты, свежие первыми: только видимые кольца (``orbit.visible``), без удалённых."""
    now = now or datetime.now(UTC)
    cutoff = now - timedelta(days=days if days is not None else history_days())
    deals = {str(d.get("id")): d for d in orbit.visible(store.all("deals"), rings)}
    me_l = str(me or "").lower()
    rows: list[dict[str, Any]] = []
    for e in load_feed(store.root).values():
        at = _parse(e.get("at"))
        deal = deals.get(str(e.get("deal_id")))
        if deal is None or at is None or at < cutoff:
            continue
        if me_l and str(e.get("actor_id") or "").lower() == me_l:
            continue  # на случай записи, сохранённой до смены «меня»
        ref: dict[str, Any] = {"guid": deal.get("id"), "code": deal.get("code"),
                               "name": deal.get("name"), "watched": orbit.is_watched(deal)}
        badge = orbit.leader_badge(deal)
        if badge:
            ref["ring"], ref["leader"] = badge["ring"], badge["leader"]
        rows.append({
            "at": _iso(at), "actor": e.get("actor_name") or "коллега", "deal": ref,
            "text": describe(e), "kind": e.get("kind"), "source": e.get("source"),
            "mine": orbit.view_ring(deal) == orbit.RING_MINE,
        })
    rows.sort(key=lambda r: r["at"], reverse=True)
    return rows


def feed_summary(rows: list[dict[str, Any]], *, days: int) -> dict[str, Any]:
    """Счётчики ленты: сделок затронуто, из них моих, правок всего, по авторам."""
    by_deal: dict[str, bool] = {}
    actors: dict[str, int] = {}
    for r in rows:
        key = str(r["deal"].get("code") or id(r))
        by_deal[key] = by_deal.get(key, False) or bool(r["mine"])
        actors[r["actor"]] = actors.get(r["actor"], 0) + 1
    return {
        "changed_deals": len(by_deal),
        "mine": sum(1 for v in by_deal.values() if v),
        "entries": len(rows),
        "days": days,
        "by_actor": [{"name": n, "n": c} for n, c in sorted(actors.items(), key=lambda x: -x[1])],
    }


def colleagues_summary(
    store: Any, *, me: str | None, now: datetime | None = None
) -> dict[str, Any]:
    """Строка брифа «коллеги изменили N сделок, из них моих M» (ORBIT-3 п.5).

    Окно ``DT_HISTORY_DAYS``, ВСЕ включённые кольца (надзор шире «моего»); ``mine`` — сколько из
    затронутых сделок для меня «свои» (мои + наблюдаемые). Пустая лента → нули."""
    days = history_days()
    rows = feed_rows(store, me, rings=list(orbit.enabled_rings()), days=days, now=now)
    summ = feed_summary(rows, days=days)
    return {k: summ[k] for k in ("changed_deals", "mine", "entries", "days")}
