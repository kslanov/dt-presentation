"""OData ⇄ dataclass mapping and ``$filter`` construction (architecture §7).

Pure functions only — no network, no I/O. Field names and the ``$select`` /
``$expand`` shapes are grounded in the real ``$metadata`` and verified against
the live API (see :mod:`core.operational.timetta`). State names come from the
expanded ``state`` nav property because the bulk ``/States`` collection is empty
on this tenant; organization / manager / assigned names likewise come from
expands and are harvested into the reference caches.
"""

from __future__ import annotations

import re
from datetime import UTC, datetime, timezone
from typing import Any

from core.operational.connector import Deal, Issue, Organization, Project

__all__ = [
    "DEAL_SELECT",
    "DEAL_EXPAND",
    "PROJECT_SELECT",
    "PROJECT_EXPAND",
    "ISSUE_SELECT",
    "ISSUE_EXPAND",
    "map_deal",
    "map_project",
    "map_issue",
    "map_organization",
    "map_legal_entity",
    "LEGAL_ENTITY_SELECT",
    "map_checklist",
    "ref_name",
    "extract_state",
    "extract_user",
    "extract_organization",
    "parse_modified",
    "max_modified",
    "guid_eq",
    "active_clause",
    "delta_clause",
    "deals_filter",
    "projects_filter",
    "issues_filter",
    "and_clauses",
]

# $select / $expand per entity — only the minimal fields the engine needs.
# ``state``/``organization``/``manager``/``assigned`` are expanded for human
# names (and to harvest the reference caches).
DEAL_SELECT = (
    "id,name,code,organizationId,managerId,projectId,amount,probability,"
    "stateId,stateEntered,isActive,created,modified,checkList,"
    "legalEntityId,createdById,modifiedById"
)
DEAL_EXPAND = (
    "state($select=id,name,code),organization($select=id,name,code),"
    "manager($select=id,name,email,legalEntityId,departmentId),"
    "legalEntity($select=id,name),createdBy($select=id,name),"
    "modifiedBy($select=id,name)"
)

PROJECT_SELECT = (
    "id,name,code,organizationId,managerId,startDate,endDate,"
    "stateId,isActive,created,modified"
)
PROJECT_EXPAND = (
    "state($select=id,name,code),organization($select=id,name,code),"
    "manager($select=id,name,email)"
)

ISSUE_SELECT = (
    "id,name,code,assignedId,projectId,projectTaskId,dealId,priorityId,"
    "stateId,stateEntered,resolutionId,resolutionComment,dueDate,parentId,"
    "isActive,created,modified"
)
ISSUE_EXPAND = (
    "state($select=id,name,code),assigned($select=id,name,email),"
    "project($select=id,name,code)"
)


# --- reference extraction ----------------------------------------------------


def ref_name(ref: Any) -> str | None:
    """Human label of an expanded ref dict: ``name`` else ``email`` else None."""
    if not isinstance(ref, dict):
        return None
    return ref.get("name") or ref.get("email") or None


def extract_state(raw: dict[str, Any]) -> tuple[str, dict[str, Any]] | None:
    """Return ``(state_id, {id,name,code})`` from an expanded ``state`` nav."""
    st = raw.get("state")
    if isinstance(st, dict) and st.get("id"):
        return str(st["id"]), {
            "id": str(st["id"]),
            "name": st.get("name"),
            "code": st.get("code"),
        }
    return None


def extract_project(raw: dict[str, Any]) -> tuple[str, dict[str, Any]] | None:
    """Return ``(project_id, {id,name,code})`` from an expanded ``project`` nav."""
    pr = raw.get("project")
    if isinstance(pr, dict) and pr.get("id"):
        return str(pr["id"]), {
            "id": str(pr["id"]),
            "name": pr.get("name"),
            "code": pr.get("code"),
        }
    return None


def extract_user(ref: Any) -> tuple[str, dict[str, Any]] | None:
    """Return ``(user_id, {id,name,email})`` from an expanded user nav."""
    if isinstance(ref, dict) and ref.get("id"):
        out = {
            "id": str(ref["id"]),
            "name": ref.get("name"),
            "email": ref.get("email"),
        }
        # ORBIT-2: юрлицо/отдел пользователя (ключи только добавляются, когда есть в expand).
        if ref.get("legalEntityId"):
            out["legal_entity_id"] = str(ref["legalEntityId"])
        if ref.get("departmentId"):
            out["department_id"] = str(ref["departmentId"])
        return str(ref["id"]), out
    return None


def extract_organization(raw: dict[str, Any]) -> tuple[str, dict[str, Any]] | None:
    """Return ``(org_id, {id,name,code})`` from an expanded ``organization`` nav."""
    org = raw.get("organization")
    if isinstance(org, dict) and org.get("id"):
        return str(org["id"]), {
            "id": str(org["id"]),
            "name": org.get("name"),
            "code": org.get("code"),
        }
    return None


# --- entity mappers ----------------------------------------------------------


def _f(v: Any) -> float | None:
    return None if v is None else float(v)


def map_checklist(raw: Any) -> list[dict[str, Any]]:
    """Map a Timetta ``Deal.checkList`` (``Collection(WP.CheckListItem)``) to the
    neutral ``{title, performer_id, deadline, fulfilled}`` shape (B3a).

    The item type has no per-item id (B3-0), so identity is derived downstream
    from the title (:func:`~core.operational.crosswalk.checkitem_id`). A missing
    / non-list value maps to ``[]``.
    """
    if not isinstance(raw, list):
        return []
    items: list[dict[str, Any]] = []
    for it in raw:
        if not isinstance(it, dict):
            continue
        items.append(
            {
                "title": it.get("title"),
                "performer_id": it.get("performerId"),
                "deadline": it.get("deadline"),
                "fulfilled": bool(it.get("fulfilled", False)),
            }
        )
    return items


def map_deal(raw: dict[str, Any]) -> Deal:
    st = extract_state(raw)
    return Deal(
        id=str(raw["id"]),
        name=raw.get("name"),
        code=raw.get("code"),
        is_active=bool(raw.get("isActive", True)),
        created=raw.get("created"),
        modified=raw.get("modified"),
        organization_id=raw.get("organizationId"),
        organization_name=ref_name(raw.get("organization")),
        manager_id=raw.get("managerId"),
        manager_name=ref_name(raw.get("manager")),
        project_id=raw.get("projectId"),
        amount=_f(raw.get("amount")),
        probability=_f(raw.get("probability")),
        state_id=raw.get("stateId"),
        state_entered=raw.get("stateEntered"),
        state_name=st[1]["name"] if st else None,
        check_list=map_checklist(raw.get("checkList")),
        legal_entity_id=raw.get("legalEntityId"),
        legal_entity_name=ref_name(raw.get("legalEntity")),
        created_by_id=raw.get("createdById"),
        created_by_name=ref_name(raw.get("createdBy")),
        last_change_by_id=raw.get("modifiedById"),
        last_change_by_name=ref_name(raw.get("modifiedBy")),
        last_change_at=raw.get("modified"),
    )


def map_project(raw: dict[str, Any]) -> Project:
    st = extract_state(raw)
    return Project(
        id=str(raw["id"]),
        name=raw.get("name"),
        code=raw.get("code"),
        is_active=bool(raw.get("isActive", True)),
        created=raw.get("created"),
        modified=raw.get("modified"),
        organization_id=raw.get("organizationId"),
        organization_name=ref_name(raw.get("organization")),
        manager_id=raw.get("managerId"),
        manager_name=ref_name(raw.get("manager")),
        start_date=raw.get("startDate"),
        end_date=raw.get("endDate"),
        state_id=raw.get("stateId"),
        state_name=st[1]["name"] if st else None,
    )


def map_issue(raw: dict[str, Any]) -> Issue:
    st = extract_state(raw)
    pr = extract_project(raw)
    return Issue(
        id=str(raw["id"]),
        name=raw.get("name"),
        code=raw.get("code"),
        is_active=bool(raw.get("isActive", True)),
        created=raw.get("created"),
        modified=raw.get("modified"),
        assigned_id=raw.get("assignedId"),
        assigned_name=ref_name(raw.get("assigned")),
        project_id=raw.get("projectId"),
        project_name=pr[1]["name"] if pr else None,
        project_code=pr[1]["code"] if pr else None,
        project_task_id=raw.get("projectTaskId"),
        deal_id=raw.get("dealId"),
        priority_id=raw.get("priorityId"),
        state_id=raw.get("stateId"),
        state_entered=raw.get("stateEntered"),
        state_name=st[1]["name"] if st else None,
        resolution_id=raw.get("resolutionId"),
        resolution_comment=raw.get("resolutionComment"),
        due_date=raw.get("dueDate"),
        parent_id=raw.get("parentId"),
    )


LEGAL_ENTITY_SELECT = "id,name,code,managerId,isDefault,isActive"


def map_legal_entity(raw: dict[str, Any]) -> dict[str, Any]:
    """``LegalEntity`` → запись справочника ``legal_entities`` (ORBIT-2: «дочки» группы)."""
    return {
        "id": str(raw["id"]),
        "name": raw.get("name"),
        "code": raw.get("code"),
        "manager_id": raw.get("managerId"),
        "is_default": bool(raw.get("isDefault", False)),
        "is_active": bool(raw.get("isActive", True)),
    }


def map_organization(raw: dict[str, Any]) -> Organization:
    return Organization(
        id=str(raw["id"]),
        name=raw.get("name"),
        code=raw.get("code"),
        is_active=bool(raw.get("isActive", True)),
        manager_id=raw.get("managerId"),
        manager_name=ref_name(raw.get("manager")),
    )


# --- modified / cursor helpers -----------------------------------------------

_DT_RE = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:?\d{2})?$"
)


def parse_modified(value: str) -> datetime:
    """Parse a Timetta ``DateTimeOffset`` to an aware UTC ``datetime``.

    Tolerates the variable fractional precision the API returns (e.g.
    ``…34.93629Z`` — 5 digits, which ``datetime.fromisoformat`` rejects on some
    versions) by normalising the fraction to microseconds. Used for picking the
    real maximum ``modified`` across a page (lexicographic max is unsafe when
    fractional widths differ).
    """
    m = _DT_RE.match(value.strip())
    if not m:
        raise ValueError(f"unparseable modified literal: {value!r}")
    year, mon, day, hh, mm, ss = (int(m.group(i)) for i in range(1, 7))
    frac = m.group(7) or ""
    micro = int((frac + "000000")[:6]) if frac else 0
    tz = m.group(8)
    if tz in (None, "Z"):
        offset = UTC
    else:
        sign = 1 if tz[0] == "+" else -1
        body = tz[1:].replace(":", "")
        offset = timezone(sign * _td(int(body[:2]), int(body[2:4])))
    return datetime(year, mon, day, hh, mm, ss, micro, tzinfo=offset).astimezone(UTC)


def _td(hours: int, minutes: int):
    from datetime import timedelta

    return timedelta(hours=hours, minutes=minutes)


def max_modified(values: list[str | None]) -> str | None:
    """Return the original literal of the latest ``modified`` in ``values``."""
    best: tuple[datetime, str] | None = None
    for v in values:
        if not v:
            continue
        try:
            dt = parse_modified(v)
        except ValueError:
            continue
        if best is None or dt > best[0]:
            best = (dt, v)
    return best[1] if best else None


# --- $filter builders --------------------------------------------------------


def guid_eq(field: str, guid: str) -> str:
    """``field eq <guid>`` — Guid literals are bare (probe-confirmed)."""
    return f"{field} eq {guid}"


def active_clause(active_only: bool = True) -> str | None:
    return "isActive eq true" if active_only else None


# Fields whose advance signals a deal/issue change worth pulling. A stage move
# via ``WP.SetState`` bumps ``stateEntered`` — and on a *terminal* stage (won /
# lost) flips ``isActive`` to false. A delta keyed on ``modified`` alone, AND-ed
# with ``isActive eq true``, therefore misses the very transition the digest
# exists to surface (live-confirmed on DT_TEST: a "won" deal left the active set
# and the delta dropped it). So the delta matches ``modified`` OR ``stateEntered``,
# and a delta run does **not** require ``isActive`` (only the first/full pull
# scopes to active). The cursor advances by max(modified, stateEntered) — see
# ``mirror._advance`` — so this neither skips nor loops.
DELTA_FIELDS = ("modified", "stateEntered")


def delta_clause(
    cursor_value: str | None, *, fields: tuple[str, ...] = ("modified",)
) -> str | None:
    """``<field> gt <literal>`` (OR-joined over ``fields``) — strict ``gt`` makes a
    no-change re-pull empty. Default is ``modified`` only; the deal/issue delta
    passes ``DELTA_FIELDS`` so a stage move that bumps only ``stateEntered`` is
    still caught."""
    if not cursor_value:
        return None
    return " or ".join(f"{f} gt {cursor_value}" for f in fields)


def and_clauses(*clauses: str | None) -> str | None:
    parts = [c for c in clauses if c]
    if not parts:
        return None
    return " and ".join(f"({c})" if " or " in c else c for c in parts)


def _or_guid(field: str, guids: list[str]) -> str | None:
    if not guids:
        return None
    return " or ".join(guid_eq(field, g) for g in guids)


def deals_filter(
    user_id: str,
    *,
    watchlist_ids: list[str] | None = None,
    active_only: bool = True,
    since: str | None = None,
    all_deals: bool = False,
) -> str | None:
    """Deals in the author's orbit: ``managerId == me`` (or in watchlist).

    **ORBIT-2:** ``all_deals=True`` — все сделки, видимые токену (токен держателя функции
    видит сделки всех ведущих и юрлиц; границу орбиты теперь задаёт КОЛЬЦО в зеркале, а не
    выборка). Остаются только ``isActive``-гейт первого пула и дельта.

    First/full pull (no ``since``) scopes to active deals; a delta pull drops the
    ``isActive`` gate and matches ``modified`` OR ``stateEntered`` (``DELTA_FIELDS``)
    so a deal whose stage moved — including one that just went terminal (won/lost
    → inactive) — is still caught (see ``DELTA_FIELDS``)."""
    active = active_clause(active_only) if since is None else None
    if all_deals:
        return and_clauses(active, delta_clause(since, fields=DELTA_FIELDS))
    owner = guid_eq("managerId", user_id)
    extra = _or_guid("id", watchlist_ids or [])
    orbit = f"{owner} or {extra}" if extra else owner
    return and_clauses(orbit, active, delta_clause(since, fields=DELTA_FIELDS))


def projects_filter(
    user_id: str,
    *,
    active_only: bool = True,
    since: str | None = None,
    project_ids: list[str] | None = None,
) -> str | None:
    """Projects in the orbit: ``managerId == me`` OR (ORBIT-2) ``id ∈ проекты сделок``.

    Проектов в тенанте 175 (ЭЛНА и учёт), зеркалим только свои и проекты сделок зеркала
    (``Deal.projectId``) — ~16, а не все."""
    parts = [guid_eq("managerId", user_id)]
    parts += [guid_eq("id", p) for p in (project_ids or [])]
    orbit = " or ".join(parts)
    return and_clauses(orbit, active_clause(active_only), delta_clause(since))


def issues_filter(
    user_id: str,
    *,
    deal_ids: list[str] | None = None,
    active_only: bool = True,
    since: str | None = None,
    linked_to_deals: bool = False,
) -> str | None:
    """Issues in the orbit: ``assignedId == me`` OR ``dealId ∈ my deals``.

    **ORBIT-2:** ``linked_to_deals=True`` — ``assignedId == me OR dealId ne null`` (все задачи,
    привязанные к сделкам: их 5 на 99; URL остаётся константным при росте числа сделок,
    в отличие от перечисления ``dealId eq …`` по 47+ сделкам).

    Like :func:`deals_filter`: a delta pull drops the ``isActive`` gate and matches
    ``modified`` OR ``stateEntered`` so an externally-changed status — including a
    task that was just closed (→ inactive) — is caught (see ``DELTA_FIELDS``)."""
    parts = [guid_eq("assignedId", user_id)]
    if linked_to_deals:
        parts.append("dealId ne null")
    else:
        parts += [guid_eq("dealId", d) for d in (deal_ids or [])]
    orbit = " or ".join(parts)
    active = active_clause(active_only) if since is None else None
    return and_clauses(orbit, active, delta_clause(since, fields=DELTA_FIELDS))
