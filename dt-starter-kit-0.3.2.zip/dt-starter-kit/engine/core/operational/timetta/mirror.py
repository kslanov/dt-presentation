"""Derived mirror, delta-pull, and orbit (architecture §7).

The mirror is a per-machine, untracked snapshot of the author's *orbit* of the
Timetta tenant — not the whole tenant. It lives in ``.derived/timetta/`` as flat
``{guid: object}`` JSON per entity type plus a per-entity ``cursor.json``.

Layering:

* :class:`MirrorStore` — pure filesystem read/write + cursor. No network.
* :func:`pull` — the only networked function: delta-reads the orbit through a
  :class:`~core.operational.timetta.client.TimettaClient`, upserts the store
  (**Timetta-wins** — remote overwrites local), advances the cursor, and returns
  a :class:`~core.operational.connector.ChangeSet`.

Reference names (state, organization, manager, assigned) are **harvested from
the expanded nav properties** of deals/projects/issues into the
``states``/``organizations``/``users`` caches — the bulk ``/States`` collection
is empty on this tenant, and orbit organizations are exactly "orgs with my
active deals", which the deal expands already carry.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Protocol

from core.adapters import load_json_store
from core.operational.connector import (
    ChangeSet,
    Cursor,
    Organization,
)
from core.operational.timetta import history as _history
from core.operational.timetta import mapping as m

logger = logging.getLogger(__name__)

__all__ = ["MirrorStore", "CollectionReader", "pull", "resolve_vault_hub"]

# Files keyed by guid -> object dict.
_ENTITY_FILES = (
    "deals", "projects", "issues", "organizations", "states", "users", "legal_entities",
)
_ORBIT_META_FILE = "orbit.json"
# Поля, которые считает не API, а ``orbit.recompute``: переносим со старой записи при upsert,
# чтобы неизменившаяся сделка не считалась «updated» на каждом pull.
_DERIVED_DEAL_FIELDS = ("unit_id", "unit_name", "participants", "ring", "watched")
_CURSOR_FILE = "cursor.json"


class CollectionReader(Protocol):
    """The slice of the client that :func:`pull` needs (eases testing)."""

    def get_collection(
        self,
        entity_set: str,
        *,
        select: str | None = ...,
        filter: str | None = ...,
        expand: str | None = ...,
        order_by: str | None = ...,
        top: int | None = ...,
    ) -> Any: ...


class MirrorStore:
    """Filesystem-backed mirror (no network)."""

    def __init__(self, root: Path) -> None:
        self.root = Path(root)

    def _path(self, name: str) -> Path:
        return self.root / f"{name}.json"

    def load(self, name: str) -> dict[str, dict[str, Any]]:
        # Нет файла → {} (зеркало ещё не снималось). Файл есть, но битый/не словарь →
        # StoreUnavailableError (ADAPTER-HONEST-1): раньше не-словарь молча давал {} —
        # «сделок нет», а битый JSON падал голым JSONDecodeError.
        data = load_json_store(self._path(name), adapter="timetta_mirror", expect=dict)
        return data if data is not None else {}

    def all(self, name: str) -> list[dict[str, Any]]:
        return list(self.load(name).values())

    def _write(self, name: str, table: dict[str, dict[str, Any]]) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        self._path(name).write_text(
            json.dumps(table, ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )

    def upsert(self, name: str, items: list[dict[str, Any]]) -> tuple[int, int]:
        """Merge ``items`` (keyed by ``id``) into ``name``; Timetta-wins.

        Returns ``(created, updated)`` — new Guid vs. a Guid already present.
        With nothing to write the file is left untouched (idempotency).
        """
        if not items:
            return (0, 0)
        table = self.load(name)
        created = updated = 0
        for item in items:
            key = str(item["id"])
            if key in table:
                updated += 1
            else:
                created += 1
            table[key] = item
        self._write(name, table)
        return (created, updated)

    def load_meta(self) -> dict[str, Any]:
        """Служебные отметки зеркала (``orbit.json``): ``{scope, version}``. Нет файла → ``{}``."""
        data = load_json_store(self.root / _ORBIT_META_FILE, adapter="timetta_mirror", expect=dict)
        return data if data is not None else {}

    def save_meta(self, meta: dict[str, Any]) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / _ORBIT_META_FILE).write_text(
            json.dumps(meta, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8"
        )

    def load_cursor(self) -> Cursor:
        path = self.root / _CURSOR_FILE
        if not path.is_file():
            return Cursor()
        return Cursor.from_dict(json.loads(path.read_text(encoding="utf-8")))

    def save_cursor(self, cursor: Cursor) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        (self.root / _CURSOR_FILE).write_text(
            json.dumps(cursor.to_dict(), ensure_ascii=False, indent=2, sort_keys=True),
            encoding="utf-8",
        )


def _advance(cursor: Cursor, entity_set: str, modifieds: list[str | None]) -> None:
    """Move the cursor forward to the latest ``modified`` seen (never back)."""
    latest = m.max_modified([*modifieds, cursor.for_entity(entity_set)])
    if latest:
        cursor.per_entity[entity_set] = latest


def _harvest(
    store: MirrorStore,
    raws: list[dict[str, Any]],
    *,
    states: dict[str, dict[str, Any]],
    users: dict[str, dict[str, Any]],
    orgs: dict[str, dict[str, Any]],
) -> None:
    """Collect reference objects from expanded nav properties (in place)."""
    for raw in raws:
        st = m.extract_state(raw)
        if st:
            states[st[0]] = st[1]
        org = m.extract_organization(raw)
        if org:
            orgs[org[0]] = {
                "id": org[0],
                "name": org[1].get("name"),
                "code": org[1].get("code"),
                "is_active": True,
                "created": None,
                "modified": None,
                "manager_id": None,
                "manager_name": None,
            }
        for key in ("manager", "assigned"):
            u = m.extract_user(raw.get(key))
            if u:
                users[u[0]] = u[1]


def _carry_derived(existing: dict[str, dict[str, Any]], items: list[dict[str, Any]]) -> None:
    """Перенести производные поля кольца со старой записи (идемпотентность счётчиков)."""
    for item in items:
        old = existing.get(str(item.get("id")))
        if old:
            for key in _DERIVED_DEAL_FIELDS:
                if key in old:
                    item[key] = old[key]


def pull(
    client: CollectionReader,
    store: MirrorStore,
    user_id: str,
    *,
    watchlist_ids: list[str] | None = None,
    active_only: bool = True,
    scope: str = "all",
    history: bool = True,
) -> ChangeSet:
    """Delta-pull the orbit, update the mirror, and return what changed.

    **ORBIT-2.** ``scope="all"`` (дефолт): все сделки, видимые токену, + справочник
    ``legal_entities`` + задачи, привязанные к сделкам, + проекты своих и сделочных; в конце
    пересчитывается кольцо (:func:`core.operational.orbit.recompute`). ``scope="mine"`` —
    прежняя выборка ``managerId == me``. Переход на ``all`` — один раз без курсора (иначе чужие
    сделки с ``modified`` старше курсора не подтянулись бы): отметка в ``orbit.json``.

    **ORBIT-3.** ``history=True`` (дефолт): по сделкам, изменившимся в этой дельте, зовётся история
    с автором (``GetHistoryFeed``/``GetStateHistory``), плюс компенсация по снапшотам ``check_list``
    → стор ``history_feed``; сбой шага ленты pull не роняет (см. :mod:`.history`).
    """
    from core.operational import orbit as _orbit

    all_scope = scope == "all"
    cursor = store.load_cursor()
    meta = store.load_meta()
    if all_scope and meta.get("scope") != "all":
        # Одноразовый backfill: старый курсор отсекал бы чужие сделки.
        cursor = Cursor()
    states: dict[str, dict[str, Any]] = {}
    users: dict[str, dict[str, Any]] = {}
    orgs: dict[str, dict[str, Any]] = {}
    created: dict[str, int] = {}
    updated: dict[str, int] = {}

    # --- Юрлица (справочник, 4 строки; без курсора) + я сам -----------------
    if all_scope:
        legal = [
            m.map_legal_entity(r)
            for r in client.get_collection("LegalEntities", select=m.LEGAL_ENTITY_SELECT)
        ]
        if legal:
            store.upsert("legal_entities", legal)
        for r in client.get_collection(
            "Users", select="id,name,email,legalEntityId,departmentId",
            filter=m.guid_eq("id", user_id),
        ):
            u = m.extract_user(r)
            if u:
                users[u[0]] = u[1]

    # --- Deals -------------------------------------------------------------
    deal_raws = list(
        client.get_collection(
            "Deals",
            select=m.DEAL_SELECT,
            expand=m.DEAL_EXPAND,
            filter=m.deals_filter(
                user_id, watchlist_ids=watchlist_ids, active_only=active_only,
                since=cursor.for_entity("Deals"), all_deals=all_scope,
            ),
        )
    )
    deals = [m.map_deal(r) for r in deal_raws]
    _harvest(store, deal_raws, states=states, users=users, orgs=orgs)
    deal_dicts = [asdict(d) for d in deals]
    old_deals = store.load("deals")
    # ORBIT-3: компенсация слепоты истории к правкам чек-листа — сравнение ДО upsert.
    snap_entries = (
        _history.snapshot_entries(old_deals, deal_dicts, me=user_id)
        if history and _history.enabled() else []
    )
    _carry_derived(old_deals, deal_dicts)
    created["Deals"], updated["Deals"] = store.upsert("deals", deal_dicts)
    # Advance by max(modified, stateEntered): a stage move bumps stateEntered, and
    # the delta filter matches it too (mapping.DELTA_FIELDS), so the cursor must
    # cover both or a stateEntered-only change would re-match forever (loop).
    _advance(
        cursor, "Deals",
        [d.modified for d in deals] + [d.state_entered for d in deals],
    )

    # --- Projects ----------------------------------------------------------
    deal_project_ids = sorted(
        {str(d.get("project_id")) for d in store.all("deals") if d.get("project_id")}
    ) if all_scope else []
    project_raws = list(
        client.get_collection(
            "Projects",
            select=m.PROJECT_SELECT,
            expand=m.PROJECT_EXPAND,
            filter=m.projects_filter(
                user_id, active_only=active_only, since=cursor.for_entity("Projects"),
                project_ids=deal_project_ids,
            ),
        )
    )
    projects = [m.map_project(r) for r in project_raws]
    _harvest(store, project_raws, states=states, users=users, orgs=orgs)
    created["Projects"], updated["Projects"] = store.upsert(
        "projects", [asdict(p) for p in projects]
    )
    _advance(cursor, "Projects", [p.modified for p in projects])

    # --- Issues (assignedId == me OR dealId ∈ сделки зеркала) --------------
    my_deal_ids = list(store.load("deals").keys())
    issue_raws = list(
        client.get_collection(
            "Issues",
            select=m.ISSUE_SELECT,
            expand=m.ISSUE_EXPAND,
            filter=m.issues_filter(
                user_id, deal_ids=my_deal_ids, active_only=active_only,
                since=cursor.for_entity("Issues"), linked_to_deals=all_scope,
            ),
        )
    )
    issues = [m.map_issue(r) for r in issue_raws]
    _harvest(store, issue_raws, states=states, users=users, orgs=orgs)
    created["Issues"], updated["Issues"] = store.upsert(
        "issues", [asdict(i) for i in issues]
    )
    _advance(
        cursor, "Issues",
        [i.modified for i in issues] + [i.state_entered for i in issues],
    )

    # --- reference caches (harvested from expands; no own cursor) ----------
    if orgs:
        store.upsert("organizations", list(orgs.values()))
    if states:
        store.upsert("states", list(states.values()))
    if users:
        store.upsert("users", list(users.values()))

    store.save_cursor(cursor)
    if all_scope:
        # Кольцо — функция от «меня», юрлиц, задач и участников: пересчёт по ВСЕМ сделкам.
        _orbit.recompute(store, user_id, watchlist=watchlist_ids or [])
        store.save_meta({"scope": "all", "version": 2})

    history_summary: dict[str, Any] = {}
    if history and _history.enabled():
        history_summary = _history_step(client, store, user_id, [d.id for d in deals], snap_entries)

    organizations = [Organization(**o) for o in orgs.values()]
    return ChangeSet(
        cursor=cursor,
        deals=deals,
        projects=projects,
        issues=issues,
        organizations=organizations,
        created=created,
        updated=updated,
        history=history_summary,
    )


def _history_step(
    client: CollectionReader,
    store: MirrorStore,
    user_id: str,
    changed_ids: list[str],
    snap_entries: list[dict[str, Any]],
) -> dict[str, Any]:
    """Шаг ленты изменений: best-effort — сбой логируется, pull продолжается (зеркало важнее)."""
    try:
        now = datetime.now(UTC)
        candidates = list(changed_ids)
        if _history.needs_backfill(store.root):
            # Первый запуск: «дельта» — это вся орбита (полный pull), поэтому берём не её, а
            # окно ``DT_HISTORY_DAYS`` по сделкам, менявшимся в нём (не все 47).
            candidates = []
            floor = now - timedelta(days=_history.history_days())
            for d in store.all("deals"):
                mod = _history.parse_dt(d.get("modified"))
                if d.get("id") and not d.get("deleted_at") and mod is not None and mod >= floor:
                    candidates.append(str(d["id"]))
        res = _history.pull_history(
            client, store.root, user_id, candidates,
            states=store.load("states"), users=store.load("users"), extra=snap_entries, now=now,
        )
        return asdict(res)
    except Exception as exc:  # noqa: BLE001 — лента не должна ронять синхронизацию зеркала
        logger.warning("history: шаг ленты пропущен — %s", type(exc).__name__)
        return {"skipped": "error", "errors": 1}


def resolve_vault_hub(guid: str, vault_path: Path | None = None) -> str | None:
    """Find a vault hub whose frontmatter ``timetta_id`` equals ``guid``.

    Returns the hub's ``id`` (or ``None``). This is the Timetta↔vault half of
    the crosswalk by Guid; the full three-way crosswalk (incl. TickTick) is B2.
    Reads the local vault only — no network.
    """
    # Imported lazily so the operational layer doesn't pull the vault stack
    # unless a caller actually needs hub resolution.
    from core.config import default_vault_path
    from core.vault import iter_vault

    root = vault_path or default_vault_path()
    if not Path(root).is_dir():
        return None
    target = guid.strip().lower()
    for note in iter_vault(root):
        tid = note.frontmatter.get("timetta_id")
        if isinstance(tid, str) and tid.strip().lower() == target:
            return note.id
    return None
