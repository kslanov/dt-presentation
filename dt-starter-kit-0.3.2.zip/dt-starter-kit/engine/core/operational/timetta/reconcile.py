"""ORBIT-2 п.3 — сверка удалений зеркала Timetta (``Reconcilable``, RECONCILE-1).

Зеркало растёт «только добавлением»: дельта-pull не видит исчезновения сущности (спайк
§3.8: удалённое → 404 ``TmtEntityNotFoundException``, а в выдаче просто нет). Раньше
исчезнувшая сделка вечно жила в зеркале, а записывающие шаги ходили к ней по API и
получали 404 каждый прогон (кейс DEAL-36/DEAL-37 → ``done WITH ERRORS`` в fast-синке).

Контур: читаем **id-списки** (``$select=id`` у Deals/Projects, ``id,isActive`` у Issues —
сделки 2,2 КБ/0,6 с) и сверяем с зеркалом. Пропавший id → **мягкая метка**
``deleted_at`` (запись НЕ удаляется — история, провенанс; ``orbit.visible`` её скрывает) +
каскад на производные очереди:

* ``watchlist`` (ORBIT-3) — сделка снимается с ручного наблюдения «слежу»;
* ``crosswalk`` — строка сделки и её подчинённые → ``resolved_external`` (TickTick-объекты
  остаются, запись в цель прекращена);
* потребители зеркала скрывают помеченное через ``orbit.visible``. (RETIRE-WRITE-1: очереди
  предложений Timetta больше нет — каскад на ``proposals.json`` ушёл в архивную ветку.)

Issue с ``isActive=false`` (деактивирована, но API её отдаёт) → ``is_active=false`` в
зеркале тем же проходом — не «удалённая», а «устаревшая» (счётчик ``K`` в doctor).

Гард (общий, в движке) + свой: пустой список сделок = сбой чтения → ``None`` (пропуск);
«исчезло больше половины живых сделок зеркала» → тоже ``None`` (массовое исчезновение —
почти наверняка сбой токена/фильтра, а не реальное удаление).

Путь B: ни LLM, ни записи в Timetta/TickTick — читаем только id-списки.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.operational.crosswalk import Crosswalk
from core.operational.timetta.mirror import CollectionReader, MirrorStore

__all__ = ["MirrorReconcilable", "MASS_GONE_FRACTION", "MASS_GONE_MIN"]

logger = logging.getLogger(__name__)

# Массовое исчезновение: при ≥ MASS_GONE_MIN живых сделок пропажа > доли — сбой, не удаление.
MASS_GONE_FRACTION = 0.5
MASS_GONE_MIN = 10

_KIND_DEAL = "deals"
_KIND_PROJECT = "projects"
_KIND_ISSUE = "issues"
_KIND_ISSUE_INACTIVE = "issues_inactive"


class MirrorReconcilable:
    """Сверка зеркала Timetta с источником по id-спискам (реализует ``Reconcilable``)."""

    name = "timetta_mirror"

    def __init__(
        self,
        *,
        client: CollectionReader,
        store: MirrorStore,
        crosswalk_path: Path | None = None,
        watchlist_path: Path | None = None,
        now: str | None = None,
    ) -> None:
        self._client = client
        self._store = store
        self._crosswalk_path = crosswalk_path
        self._watchlist_path = watchlist_path
        self._now = now

    # -- Reconcilable --------------------------------------------------------

    def read_source(self) -> dict[str, Any] | None:
        """``{deals, projects: {id}, issues: {id: is_active}}`` или ``None`` (пропуск)."""
        try:
            get = self._client.get_collection
            deals = {str(r["id"]).lower() for r in get("Deals", select="id")}
            projects = {str(r["id"]).lower() for r in get("Projects", select="id")}
            issues = {
                str(r["id"]).lower(): bool(r.get("isActive", True))
                for r in get("Issues", select="id,isActive")
            }
        except Exception as exc:  # noqa: BLE001 — сбой API ≠ «всё исчезло» (общий гард)
            logger.warning(
                "timetta_mirror: чтение id-списков упало (%s) — пропуск", type(exc).__name__
            )
            return None
        if not deals:
            return None
        live = [k for k, r in self._store.load("deals").items() if not r.get("deleted_at")]
        gone = [k for k in live if k.lower() not in deals]
        if len(live) >= MASS_GONE_MIN and len(gone) > len(live) * MASS_GONE_FRACTION:
            logger.warning(
                "timetta_mirror: пропало %d из %d сделок — массовое исчезновение, пропуск",
                len(gone),
                len(live),
            )
            return None
        return {"deals": deals, "projects": projects, "issues": issues}

    def stale_items(self, source: dict[str, Any]) -> list[tuple[str, str]]:
        """``[(вид, id)]``: пропавшие в источнике (мягкая метка) и деактивированные issue."""
        out: list[tuple[str, str]] = []
        for kind, key in ((_KIND_DEAL, "deals"), (_KIND_PROJECT, "projects")):
            for rid, rec in self._store.load(kind).items():
                if not rec.get("deleted_at") and rid.lower() not in source[key]:
                    out.append((kind, rid))
        for rid, rec in self._store.load(_KIND_ISSUE).items():
            if rec.get("deleted_at"):
                continue
            active = source["issues"].get(rid.lower())
            if active is None:
                out.append((_KIND_ISSUE, rid))
            elif not active and rec.get("is_active", True):
                out.append((_KIND_ISSUE_INACTIVE, rid))
        return out

    def resolve(self, item: tuple[str, str]) -> None:
        kind, rid = item
        stamp = self._now or datetime.now(UTC).isoformat(timespec="seconds")
        try:
            if kind != _KIND_ISSUE_INACTIVE:
                # Каскад ДО метки: упал каскад — запись не помечена и сверится в следующий проход.
                self._cascade(kind, rid)
            inactive = kind == _KIND_ISSUE_INACTIVE
            name = _KIND_ISSUE if inactive else kind  # вид «деактивирована» живёт в таблице issues
            table = self._store.load(name)
            rec = table.get(rid)
            if rec is None:
                return
            if inactive:
                rec["is_active"] = False
            else:
                rec["deleted_at"] = stamp
            self._store._write(name, table)
            if name == _KIND_DEAL and not inactive and self._watchlist_path is not None:
                # ORBIT-3: исчезнувшая сделка снимается с наблюдения («слежу» не висит вечно)
                from core.operational import watchlist

                watchlist.prune_deleted(self._store, self._watchlist_path)
        except Exception as exc:  # noqa: BLE001 — не рушим остальные очереди контура
            logger.warning(
                "timetta_mirror: %s не разрешён (%s) — повтор в след. проход",
                kind,
                type(exc).__name__,
            )

    # -- каскад --------------------------------------------------------------

    def _cascade(self, kind: str, rid: str) -> None:
        key = rid.lower()
        if self._crosswalk_path is not None:
            cw = Crosswalk.load(self._crosswalk_path)
            dirty = False
            for guid, entry in cw.entries.items():
                child = kind != _KIND_ISSUE and (entry.parent_guid or "").lower() == key
                if (guid == key or child) and not entry.resolved_external:
                    entry.resolved_external = True
                    dirty = True
            if dirty:
                cw.save()
