"""ORBIT-3 п.3 — ручной список «слежу»: сделки колец 2/3 на внимание, без права записи.

Участие по явным сигналам (исполнитель пункта чек-листа / связанной задачи → кольцо 1) уже
считает ``orbit.recompute``. Здесь — второй путь: К. сам ставит чужую сделку «на слежение» кнопкой
на карточке. Такая сделка получает флаг ``watched`` и для ВНИМАНИЯ (лента «Работа», дайджест)
ведёт себя как кольцо 1 (:func:`core.operational.orbit.view_ring`), но её реальное кольцо не
меняется. (RETIRE-WRITE-1: записи в Timetta нет — гейта записи по кольцам тоже.)

Хранилище — ``watchlist.json`` (``{guid: {"added": iso}}``) рядом с crosswalk: состояние
пользователя, из Timetta не пересобирается. Битый файл → ``StoreUnavailableError`` (а не молчаливо
пустой список: потерянное «слежу» — тихая порча). Reconcile: сверка удалений
(``MirrorReconcilable``) снимает с наблюдения исчезнувшую сделку (:func:`prune_deleted`).

Чистое ядро: сеть и LLM не нужны. ``core`` ⊥ mcp/cli.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.adapters import load_json_store
from core.contract import CODE_DEAL_DELETED, CODE_ITEM_NOT_FOUND, CODE_SKIPPED, warning
from core.operational import orbit
from core.operational.timetta.mirror import MirrorStore

__all__ = ["load_ids", "watch", "unwatch", "prune_deleted"]


def _path(path: Path | None) -> Path:
    if path is not None:
        return Path(path)
    from core.config import watchlist_path

    return watchlist_path()


def _load(path: Path | None) -> dict[str, dict[str, Any]]:
    data = load_json_store(_path(path), adapter="watchlist", expect=dict)
    return data if data is not None else {}


def _save(table: dict[str, dict[str, Any]], path: Path | None) -> None:
    target = _path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(table, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8"
    )


def load_ids(path: Path | None = None) -> list[str]:
    """Guid'ы наблюдаемых сделок (как записаны); нет файла → ``[]``."""
    return sorted(_load(path))


def _result(ok: bool, changed: bool, guid: str, **extra: Any) -> dict[str, Any]:
    return {"ok": ok, "changed": changed, "deal": guid, **extra}


def _refuse(guid: str, code: str, reason: str) -> dict[str, Any]:
    return _result(False, False, guid, code=code, warning=[warning(code, reason)])


def watch(
    store: MirrorStore,
    guid: str,
    *,
    me: str | None,
    path: Path | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Поставить сделку «на слежение». Отказы — конверт с кодом, не исключение.

    * нет в зеркале → ``item_not_found``; удалена в Timetta → ``deal_deleted``;
    * сделка и так моя (кольцо ``mine``) → ``skipped`` (следить не нужно, ничего не пишем).
    """
    deal = orbit.find_ref(store, guid)
    if deal is None:
        return _refuse(guid, CODE_ITEM_NOT_FOUND, "сделки нет в зеркале Timetta")
    key = str(deal.get("id"))
    if orbit.is_deleted(deal):
        return _refuse(key, CODE_DEAL_DELETED, "сделка удалена в Timetta — следить не за чем")
    if orbit.ring(deal) == orbit.RING_MINE:
        return _refuse(key, CODE_SKIPPED, "сделка уже в кольце «мои» — слежение не нужно")
    table = _load(path)
    changed = key not in table
    if changed:
        table[key] = {"added": now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")}
        _save(table, path)
    _refresh(store, me, table)
    return _result(True, changed, key, ring=orbit.ring(deal))


def unwatch(
    store: MirrorStore, guid: str, *, me: str | None, path: Path | None = None
) -> dict[str, Any]:
    """Снять слежение. Нет в списке → ``changed: false`` (идемпотентно, не ошибка)."""
    deal = orbit.find_ref(store, guid)
    key = str(deal.get("id")) if deal else str(guid)
    table = _load(path)
    hit = next((k for k in table if k.lower() == key.lower()), None)
    if hit is None:
        return _result(True, False, key)
    del table[hit]
    _save(table, path)
    _refresh(store, me, table)
    return _result(True, True, key)


def prune_deleted(store: MirrorStore, path: Path | None = None) -> list[str]:
    """Снять с наблюдения сделки, исчезнувшие в Timetta (метка ``deleted_at``). → снятые id."""
    table = _load(path)
    gone = []
    for key in list(table):
        deal = orbit.find(store, key)
        if deal is not None and orbit.is_deleted(deal):
            gone.append(key)
            del table[key]
    if gone:
        _save(table, path)
    return gone


def _refresh(store: MirrorStore, me: str | None, table: dict[str, Any]) -> None:
    """Пересчитать флаг ``watched`` в зеркале сразу (без ожидания ближайшего pull)."""
    if me:
        orbit.recompute(store, me, watchlist=list(table))
