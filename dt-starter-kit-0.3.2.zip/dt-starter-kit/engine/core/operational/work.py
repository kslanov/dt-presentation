"""WORK-1/WORK-2 — фид рабочего кокпита (пульт, вкладка «Работа»).

Отдаёт данные для рабочего дашборда, читая ТОЛЬКО локальные зеркала (без сети,
без LLM; ``core/`` ⊥ mcp/cli). Утренний бриф синтезирует уже потребитель
(артефакт через askClaude) поверх этого структурного среза — сам модуль текст не
генерирует.

Четыре среза (:func:`snapshot`):

* **attention** — что «горит» сейчас: просроченные и близкие пункты чек-листа
  сделок, просроченные project-issues, входящие письма без ответа (только
  ВНЕШНЯЯ переписка в свежем окне — внутренние/служебные треды отсекаются).
* **stale** — что «тихо остывает» (WORK-2, resurfacing): активные сделки /
  проекты / issues, по которым давно нет изменений, с плавным скором остывания
  ``cool`` (не жёсткий порог). Закрытые/выигранные — не показываются.
* **deltas** — что изменилось за последние сутки-двое (свежие правки зеркала +
  свежая внешняя почта) — питает ленту «что изменилось».
* **counts** — счётчики для плиток (активных сделок, пресейлов, задач на
  неделю / просроченных, писем без ответа).

Сигналы «тишины» берутся из ``modified`` зеркала Timetta и ``last_date``
манифеста почты — НЕ из mtime заметок vault (линковочная волна освежает mtime
почти всего vault; см. PERF-2/hub_candidates). Vault-хабы и темы-переписки как
остывающие сущности — follow-up (нужен контентный сигнал активности).

Шум писем чистится по контрагенту: у чисто внутренних тредов ``counterparty_
domains`` пуст — такие в attention/deltas не попадают; факт ответа определяется
по последнему сообщению треда (``is_me``) из сайдкара, а не по грубым
``bucket_dates``. Сайдкары открываются точечно (только свежие треды окна).

Privacy: наружу идут ``code``/``name``/``state_name``/темы писем/домены/даты/
счётчики — как в ``pult``-очереди; суммы и вероятности сделок (``amount``/
``probability``) в выдачу НЕ попадают. Инвариант: ``work_*`` в server.py — тонкие
обёртки.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.adapters import StoreUnavailableError, load_json_store
from core.config import (
    default_vault_path,
    mail_internal_domains,
    mail_owner_domains,
    operational_derived_path,
    outlook_ingest_manifest_path,
    timetta_mirror_path,
    timetta_user_id,
)
from core.operational import orbit
from core.operational.brief import build_brief
from core.operational.timetta import history as _history
from core.operational.timetta.mirror import MirrorStore
from core.vault import read_note, resolve_note_path

logger = logging.getLogger(__name__)

__all__ = [
    "TERMINAL_STATE_CODES",
    "PRESALE_STATE_CODES",
    "STALE_MIN_DAYS",
    "COOL_FULL_DAYS",
    "DUE_SOON_DAYS",
    "RECENT_MAIL_DAYS",
    "DELTA_DAYS",
    "MAX_PER_SECTION",
    "DISMISS_ACTIONS",
    "MAIL_UNANSWERED_MIN_DAYS",
    "mail_unanswered_min_days",
    "snapshot",
    "record_dismissal",
    "resolve_deal_guid",
    "context",
    "note_preview",
]

# Терминальные стадии сделки/issue — из активной работы выпадают (не «забыты»).
TERMINAL_STATE_CODES: frozenset[str] = frozenset({"WON", "Closed"})
# Пресейл в понимании владельца — и «Пресейл», и «Подготовка КП».
PRESALE_STATE_CODES: frozenset[str] = frozenset({"PRE-SALE", "PROPOSAL"})
# Служебные почтовые домены сверх owner-доменов - из профиля (``company.internal_domains``) и
# ``DT_MAIL_INTERNAL_DOMAINS`` (``core.config.mail_internal_domains``): их контрагентом не считаем
# (внутренняя инфраструктура/группа), чтобы уведомления не шли в attention. Только для фильтра фида;
# почтовый ingest (is_me) не трогается.

STALE_MIN_DAYS = 14  # меньше — ещё не «забытое», в stale не показываем
COOL_FULL_DAYS = 180.0  # тишина, при которой шкала остывания полная (cool == 1.0)
DUE_SOON_DAYS = 7  # пункт чек-листа с дедлайном в этом окне — «скоро»
RECENT_MAIL_DAYS = 30  # письмо без ответа старше — не тревожим (легаси-шум)
# WORK-TUNE-1 (решение К. 14.08): нижний порог молчания письма. Тред без ответа
# попадает в «Требует внимания» только когда молчит БОЛЬШЕ этого числа дней — «без
# ответа 0 дн» вытесняло из капнутой секции то, что реально залежалось.
MAIL_UNANSWERED_MIN_DAYS = 3.0
_MAIL_MIN_DAYS_ENV = "DT_MAIL_UNANSWERED_MIN_DAYS"
DELTA_DAYS = 2  # окно ленты «что изменилось»
MAX_PER_SECTION = 8  # мягкий кап на длину каждого среза

# Вес сущности при ранжировании остывания: активная сделка «остывает громче».
_TYPE_WEIGHT: dict[str, float] = {"deal": 1.0, "project": 0.8, "issue": 0.6}


# --------------------------------------------------------------------------- #
# Хелперы (нет данных → None/пропуск, никогда не исключение)                    #
# --------------------------------------------------------------------------- #
def _to_utc(dt: datetime) -> datetime:
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)


def _iso_z(dt: datetime) -> str:
    return _to_utc(dt).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_iso(value: Any) -> datetime | None:
    """Толерантный ISO-8601 (``Z``/offset/date-only/naive→UTC) → aware, иначе None."""
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        return _to_utc(datetime.fromisoformat(text))
    except ValueError:
        return None


def _load_json(path: Path) -> Any | None:
    """Толерантное чтение: ``None`` и для «нет файла», и для «файл битый».

    Для лент, где пустое молча = «ничего не происходит», используй :func:`_load_json_checked`
    (различает и сообщает). Здесь остаётся предупреждение в лог на битый файл — тихой
    деградации без следа нет (ADAPTER-HONEST-1)."""
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("[work] %s нечитаем (%s: %s) — считаю пустым", path.name,
                       type(exc).__name__, str(exc)[:80])
        return None


def _load_json_checked(
    path: Path, label: str, errors: list[StoreUnavailableError]
) -> Any | None:
    """Как :func:`_load_json`, но битый файл запоминается в ``errors`` (→ конверт п.22
    в ответе среза): ``None`` для «нет файла» остаётся честным пустым."""
    try:
        return load_json_store(path, adapter=label, expect=(dict, list))
    except StoreUnavailableError as exc:
        errors.append(exc)
        return None


def _days_between(later: datetime, earlier: datetime) -> float:
    return max(0.0, (later - earlier).total_seconds()) / 86400.0


def _cool(silent_days: float) -> float:
    """Скор остывания 0..1 (доля от :data:`COOL_FULL_DAYS`) для шкалы виджета."""
    return round(min(1.0, silent_days / COOL_FULL_DAYS), 2)


def _state_code_map(store: MirrorStore) -> dict[str, str]:
    """``state_id → code`` из справочника стадий зеркала."""
    out: dict[str, str] = {}
    for guid, rec in store.load("states").items():
        code = rec.get("code")
        if isinstance(code, str):
            out[guid] = code
    return out


def _is_active(rec: dict[str, Any], code_by_id: dict[str, str]) -> bool:
    if rec.get("is_active") is False:
        return False
    # Защитная терминальность по резолюции (спайк 2026-07-08): у issue закрытие
    # проставляет resolutionId вместе с state→Closed. Если код стадии отстал, но
    # резолюция уже есть — issue терминален. Для deal/project ключа нет → no-op.
    if rec.get("resolution_id") is not None:
        return False
    return code_by_id.get(str(rec.get("state_id"))) not in TERMINAL_STATE_CODES


def _deal_ref(deal: dict[str, Any]) -> dict[str, Any]:
    """Приватная ссылка на сделку: только code/name (без сумм/вероятности).

    ORBIT-2: у сделки НЕ из кольца ``mine`` добавляются ``ring``/``leader`` (бейдж ведущего
    — «сделка Любы»); у своих форма прежняя (нулевая регрессия)."""
    ref = {"code": deal.get("code"), "name": deal.get("name")}
    badge = orbit.leader_badge(deal)
    if badge:
        ref["ring"], ref["leader"] = badge["ring"], badge["leader"]
        ref["guid"] = deal.get("id")  # чужая сделка: пульту нужен guid для «следить»/«не следить»
        if badge.get("watched"):
            ref["watched"] = True  # ORBIT-3: сделка «слежу» — в внимании, но без права записи
    return ref


def _entity_ref(rec: dict[str, Any] | None) -> dict[str, Any] | None:
    """Приватная ссылка на проект/сделку: только code/name; ``None`` → ``None``."""
    if not isinstance(rec, dict):
        return None
    return {"code": rec.get("code"), "name": rec.get("name")}


# --------------------------------------------------------------------------- #
# Почта: свежие ВНЕШНИЕ треды из манифеста + сайдкаров                          #
# --------------------------------------------------------------------------- #
def _load_sidecar(threads_dir: Path | None, key: str) -> dict[str, Any] | None:
    """Сайдкар треда по ключу манифеста (имя файла = sha1(ключа))."""
    if threads_dir is None:
        return None
    name = hashlib.sha1(key.encode("utf-8")).hexdigest() + ".json"  # noqa: S324 — content hash (identity/dedup), not security
    data = _load_json(Path(threads_dir) / name)
    return data if isinstance(data, dict) else None


def _internal_domains() -> set[str]:
    """Свои домены (owner-домены + служебные домены профиля), lower-cased."""
    try:
        own = {d.lower() for d in mail_owner_domains() if d}
        own |= {d.lower() for d in mail_internal_domains() if d}
    except Exception:  # noqa: BLE001 — best-effort; must not break the caller
        own = set()
    return own


def _hash(value: Any) -> str:
    """Короткий стабильный хэш нормализованной строки — для id пунктов фида."""
    return hashlib.sha1(str(value or "").strip().lower().encode("utf-8")).hexdigest()[:10]  # noqa: S324 — content hash (identity/dedup), not security


def _recent_external_mail(
    manifest: dict[str, Any] | None,
    threads_dir: Path | None,
    *,
    now: datetime,
    horizon_days: int | None = None,
    include_key: bool = False,
) -> list[dict[str, Any]]:
    """Треды с активностью в окне; внутренние (без внешнего контрагента) отсеяны.

    Каждый элемент: ``{subject, last, last_is_me, external, domain}``. ``horizon_days`` -
    свое окно вместо ``max(RECENT_MAIL_DAYS, DELTA_DAYS)`` (синтез хаба смотрит на 90 дней);
    ``include_key=True`` добавляет ключ манифеста ``key`` (``conv:…``/``msg:…``) и ``counterparty_
    domains`` - по ним тред разрешается ``read_note``. Прежние вызовы не меняются. Факт
    ответа берётся из последнего сообщения сайдкара (``is_me``); при отсутствии
    сайдкара — грубый fallback по ``bucket_dates`` (external не фильтруется —
    информации нет). Открываются только свежие треды (окно), не все 5k+.
    """
    if not isinstance(manifest, dict):
        return []
    internal = _internal_domains()
    window = horizon_days if horizon_days is not None else max(RECENT_MAIL_DAYS, DELTA_DAYS)
    horizon = now - timedelta(days=window)
    out: list[dict[str, Any]] = []
    for key, entry in manifest.items():
        if not isinstance(entry, dict):
            continue
        last = _parse_iso(entry.get("last_date"))
        if last is None or last < horizon:
            continue
        sidecar = _load_sidecar(threads_dir, str(key))
        if isinstance(sidecar, dict):
            domains = [
                d for d in (sidecar.get("counterparty_domains") or [])
                if d and d.lower() not in internal
            ]
            external = bool(domains)
            msgs = [m for m in (sidecar.get("messages") or {}).values() if isinstance(m, dict)]
            msgs.sort(key=lambda m: _parse_iso(m.get("date")) or datetime.min.replace(tzinfo=UTC))
            last_is_me: bool | None = bool(msgs[-1].get("is_me")) if msgs else None
        else:
            # fallback только по манифесту (тесты/нет сайдкаров): не фильтруем external
            domains = []
            external = True
            bd = entry.get("bucket_dates") if isinstance(entry.get("bucket_dates"), dict) else {}
            inbox = _parse_iso(bd.get("inbox"))
            sent = _parse_iso(bd.get("sent"))
            last_is_me = sent is not None and (inbox is None or sent >= inbox)
        item: dict[str, Any] = {
            "subject": str(entry.get("subject") or "(без темы)").strip(),
            "last": last,
            "last_is_me": last_is_me,
            "external": external,
            "domain": domains[0] if domains else None,
        }
        if include_key:
            item["key"] = str(key)
            item["domains"] = list(domains)
            item["note_path"] = str(entry.get("note_path") or "")
        out.append(item)
    return out


def _resolve_item_clients(text: str, domains: list[str]) -> list[dict[str, str]]:
    """Клиент-хабы DT по тексту (тема/имя) + доменам — чтобы черновик из пульта
    генерился С клиентом (иначе client_correspondence тянет только стиль). Реюз
    каталога/резолвера встреч (кэш на процесс). Мягко: любой сбой → []."""
    try:
        from core.operational.meetings import _client_hubs, _resolve_clients

        return _resolve_clients([d for d in (domains or []) if d], text or "", _client_hubs())
    except Exception:  # noqa: BLE001 — best-effort; must not break the caller
        return []


def mail_unanswered_min_days() -> float:
    """Порог молчания, после которого письмо попадает в «Требует внимания».

    Env ``DT_MAIL_UNANSWERED_MIN_DAYS``, дефолт :data:`MAIL_UNANSWERED_MIN_DAYS` (3).
    Непарсящееся/неположительное значение — дефолт (ветка сбоя не открывает поток
    «без ответа 0 дн» молча).
    """
    raw = os.environ.get(_MAIL_MIN_DAYS_ENV, "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return MAIL_UNANSWERED_MIN_DAYS
    return value if value >= 0 else MAIL_UNANSWERED_MIN_DAYS


def _unanswered_mail(
    recent: list[dict[str, Any]],
    *,
    now: datetime,
    hidden: Callable[[dict[str, Any]], bool] = lambda it: False,
) -> list[dict[str, Any]]:
    """Внешние треды в окне, где последнее письмо — входящее (мы не ответили).

    **Порог молчания (WORK-TUNE-1, решение К. 14.08).** Тред показывается, когда
    ``silent_days > `` :func:`mail_unanswered_min_days` (дефолт 3). Причина: без порога
    в «Требует внимания» первыми строками стояли «без ответа 0 дн» — письмо, пришедшее
    час назад, ещё не требует внимания, а вытесняло то, что действительно залежалось
    (кап секции — :data:`MAX_PER_SECTION`). Порог сравнивается с тем же округлённым
    числом, которое видит человек в строке: подпись «4 дн» и попадание в список не
    расходятся.

    **Сортировка — по убыванию** молчания: самые залежавшиеся сверху (было по
    возрастанию, то есть свежайшие — и наименее срочные — первыми).

    Верхняя граница окна (:data:`RECENT_MAIL_DAYS`, 30 дн) не меняется: старше — уже
    не «требует внимания», а легаси-шум.
    """
    horizon = now - timedelta(days=RECENT_MAIL_DAYS)
    threshold = mail_unanswered_min_days()
    out: list[dict[str, Any]] = []
    for t in recent:
        if not t["external"] or t["last_is_me"] is not False or t["last"] < horizon:
            continue
        silent_days = round(_days_between(now, t["last"]))
        if silent_days <= threshold:
            continue  # ещё не залежалось — молчим (порог WORK-TUNE-1)
        item = {
            "type": "mail_unanswered",
            "id": f"mail:{_hash(t['subject'])}",
            "title": t["subject"],
            "last_inbound": _iso_z(t["last"]),
            "as_of": _iso_z(t["last"]),
            "silent_days": silent_days,
        }
        if t["domain"]:
            item["from"] = t["domain"]
        clients = _resolve_item_clients(t["subject"], [t.get("domain") or ""])
        if clients:
            item["clients"] = clients
        if hidden(item):
            continue
        out.append(item)
    out.sort(key=lambda it: it["silent_days"], reverse=True)
    return out[:MAX_PER_SECTION]


# --------------------------------------------------------------------------- #
# Срезы                                                                        #
# --------------------------------------------------------------------------- #
def _attention(
    deals: list[dict[str, Any]],
    issues: list[dict[str, Any]],
    code_by_id: dict[str, str],
    unanswered: list[dict[str, Any]],
    *,
    now: datetime,
    projects: list[dict[str, Any]] | None = None,
    hidden: Callable[[dict[str, Any]], bool] = lambda it: False,
    extra: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    # Для различимости одноимённых issue на карточке (спайк 2026-07-08): проект и
    # сделку резолвим по id из зеркала. Один issue-code НЕ уникален глобально —
    # человеку различитель даёт имя проекта, а не имя задачи.
    projects_by_id = {str(p.get("id")): p for p in (projects or []) if isinstance(p, dict)}
    deals_by_id = {str(d.get("id")): d for d in deals if isinstance(d, dict)}

    def _add(item: dict[str, Any]) -> None:
        if not hidden(item):
            items.append(item)

    for deal in deals:
        if not _is_active(deal, code_by_id):
            continue
        for entry in deal.get("check_list") or []:
            if not isinstance(entry, dict) or entry.get("fulfilled"):
                continue
            due = _parse_iso(entry.get("deadline"))
            if due is None:
                continue
            title = str(entry.get("title") or "").strip()
            cid = f"checklist:{deal.get('code')}:{_hash(title)}"
            dref = _deal_ref(deal)
            dcl = _resolve_item_clients(str(deal.get("name") or ""), [])
            if due < now:
                _add(
                    {
                        "type": "checklist_overdue",
                        "id": cid,
                        "title": title,
                        "deal": dref,
                        "due": _iso_z(due),
                        "as_of": _iso_z(due),
                        "days_overdue": round(_days_between(now, due)),
                        **({"clients": dcl} if dcl else {}),
                    }
                )
            elif due <= now + timedelta(days=DUE_SOON_DAYS):
                _add(
                    {
                        "type": "checklist_due_soon",
                        "id": cid,
                        "title": title,
                        "deal": dref,
                        "due": _iso_z(due),
                        "as_of": _iso_z(due),
                        "days_until": round(_days_between(due, now)),
                        **({"clients": dcl} if dcl else {}),
                    }
                )

    for issue in issues:
        if not _is_active(issue, code_by_id):
            continue
        due = _parse_iso(issue.get("due_date"))
        if due is not None and due < now:
            iname = str(issue.get("name") or issue.get("code") or "").strip()
            icl = _resolve_item_clients(iname, [])
            # Проект: сперва из зеркала projects; если его нет в орбите проектов
            # (она уже орбиты сделок), берём имя/код, приехавшие на самом issue
            # через $expand=project.
            project = _entity_ref(projects_by_id.get(str(issue.get("project_id"))))
            if project is None and (issue.get("project_name") or issue.get("project_code")):
                project = {"code": issue.get("project_code"), "name": issue.get("project_name")}
            deal = _entity_ref(deals_by_id.get(str(issue.get("deal_id"))))
            _add(
                {
                    "type": "issue_overdue",
                    "id": f"issue:{issue.get('code')}",
                    "title": iname,
                    "code": issue.get("code"),
                    "issue_id": issue.get("id"),
                    "due": _iso_z(due),
                    "as_of": _iso_z(due),
                    "days_overdue": round(_days_between(now, due)),
                    # Проект/сделка — различитель одноимённых issue; graceful,
                    # если сущности нет в зеркале (вне орбиты) → ключ опускаем.
                    **({"project": project} if project else {}),
                    **({"deal": deal} if deal else {}),
                    **({"clients": icl} if icl else {}),
                }
            )

    items.extend(unanswered)
    # DEV-1D-DETECT: пункты детекторов (сирота / дедлайн хаба) приходят готовыми —
    # здесь только общий фильтр решений, сортировка и кап (одно место на всю ленту).
    for item in extra or []:
        _add(item)

    def _key(it: dict[str, Any]) -> tuple[int, float]:
        if it["type"] in ("checklist_overdue", "issue_overdue", "hub_deadline_overdue"):
            return (0, -float(it.get("days_overdue", 0)))
        if it["type"] in ("checklist_due_soon", "hub_deadline_soon"):
            return (1, float(it.get("days_until", 0)))
        # Сирота — информационный сигнал: ниже срочного и почты, свежие первыми,
        # и первым же отсекается капом среза (шум не выдавливает просрочку).
        if it["type"] == "orphan_note":
            return (3, float(it.get("age_days", 0)))
        # Почта без ответа (WORK-TUNE-1): самые залежавшиеся СВЕРХУ — тот же порядок,
        # что задаёт ``_unanswered_mail``. Сортировка ленты общая, поэтому знак нужен
        # и здесь: иначе DESC-порядок среза молча переворачивался обратно в ASC.
        return (2, -float(it.get("silent_days", 0)))

    items.sort(key=_key)
    return items[:MAX_PER_SECTION]


def _stale(
    deals: list[dict[str, Any]],
    projects: list[dict[str, Any]],
    issues: list[dict[str, Any]],
    code_by_id: dict[str, str],
    *,
    now: datetime,
    hidden: Callable[[dict[str, Any]], bool] = lambda it: False,
) -> list[dict[str, Any]]:
    rows: list[tuple[float, dict[str, Any]]] = []

    def _consider(rec: dict[str, Any], kind: str, subtitle: str) -> None:
        if not _is_active(rec, code_by_id):
            return
        modified = _parse_iso(rec.get("modified"))
        if modified is None:
            return
        silent = _days_between(now, modified)
        if silent < STALE_MIN_DAYS:
            return
        title = str(rec.get("name") or rec.get("code") or "").strip()
        item = {
            "entity_type": kind,
            "id": f"{kind}:{rec.get('code') or _hash(title)}",
            "code": rec.get("code"),
            "title": title,
            "subtitle": subtitle,
            "last_activity": _iso_z(modified),
            "as_of": _iso_z(modified),
            "silent_days": round(silent),
            "cool": _cool(silent),
        }
        if hidden(item):
            return
        rows.append((silent * _TYPE_WEIGHT[kind], item))

    for deal in deals:
        _consider(deal, "deal", str(deal.get("state_name") or "сделка"))
    for project in projects:
        _consider(project, "project", str(project.get("state_name") or "проект"))
    for issue in issues:
        _consider(issue, "issue", "issue проекта")

    rows.sort(key=lambda r: r[0], reverse=True)
    return [row for _, row in rows[:MAX_PER_SECTION]]


def _deltas(
    deals: list[dict[str, Any]],
    projects: list[dict[str, Any]],
    issues: list[dict[str, Any]],
    recent_mail: list[dict[str, Any]],
    *,
    now: datetime,
) -> list[dict[str, Any]]:
    since = now - timedelta(days=DELTA_DAYS)
    out: list[tuple[datetime, dict[str, Any]]] = []

    def _consider(rec: dict[str, Any], kind: str, subtitle: str) -> None:
        modified = _parse_iso(rec.get("modified"))
        if modified is None or modified < since:
            return
        out.append(
            (
                modified,
                {
                    "type": kind,
                    "title": str(rec.get("name") or rec.get("code") or "").strip(),
                    "subtitle": subtitle,
                    "when": _iso_z(modified),
                },
            )
        )

    for deal in deals:
        _consider(deal, "deal", f"{deal.get('state_name') or 'сделка'} · обновлена")
    for project in projects:
        _consider(project, "project", "проект обновлён")
    for issue in issues:
        _consider(issue, "issue", "issue обновлён")

    for t in recent_mail:
        if not t["external"] or t["last"] < since:
            continue
        out.append(
            (
                t["last"],
                {
                    "type": "mail",
                    "title": t["subject"],
                    "subtitle": t["domain"] or "новое письмо",
                    "when": _iso_z(t["last"]),
                },
            )
        )

    out.sort(key=lambda r: r[0], reverse=True)
    return [row for _, row in out[:MAX_PER_SECTION]]


def _counts(
    deals: list[dict[str, Any]],
    code_by_id: dict[str, str],
    unanswered: list[dict[str, Any]],
    *,
    now: datetime,
) -> dict[str, int]:
    active = [d for d in deals if _is_active(d, code_by_id)]
    presales = sum(
        1 for d in active if code_by_id.get(str(d.get("state_id"))) in PRESALE_STATE_CODES
    )

    overdue = due_week = 0
    week = now + timedelta(days=7)
    for deal in active:
        for entry in deal.get("check_list") or []:
            if not isinstance(entry, dict) or entry.get("fulfilled"):
                continue
            due = _parse_iso(entry.get("deadline"))
            if due is None:
                continue
            if due < now:
                overdue += 1
            elif due <= week:
                due_week += 1

    return {
        "deals_active": len(active),
        "presales": presales,
        "tasks_overdue": overdue,
        "tasks_due_week": due_week,
        "unanswered_mail": len(unanswered),
    }


# --------------------------------------------------------------------------- #
# Публичный снапшот                                                            #
# --------------------------------------------------------------------------- #
def _dismiss_path(explicit: Path | None) -> Path:
    return Path(explicit) if explicit else operational_derived_path() / "work_dismissals.json"


def _hidden_predicate(
    dismissals: dict[str, Any], *, now: datetime
) -> Callable[[dict[str, Any]], bool]:
    """Скрыт ли пункт по серверному решению.

    ``snooze`` прячет по времени (пока ``now < until``); ``ack``/``dismiss``/
    ``done`` — пока не пришло новое событие (``as_of`` пункта > зафиксированного
    ``seen_as_of``); ``clear`` в сторе не хранится (см. :func:`record_dismissal`).
    """

    def _hidden(item: dict[str, Any]) -> bool:
        d = dismissals.get(item.get("id"))
        if not isinstance(d, dict):
            return False
        if d.get("action") == "snooze":
            until = _parse_iso(d.get("until"))
            return until is not None and now < until
        seen = _parse_iso(d.get("seen_as_of"))
        cur = _parse_iso(item.get("as_of"))
        if seen is None or cur is None:
            return True
        return cur <= seen

    return _hidden


def _detector_items(
    *, vault_path: Path | None = None, now: datetime
) -> list[dict[str, Any]]:
    """Пункты vault-детекторов (DEV-1D-DETECT): сирота + дедлайн хаба.

    Сканы vault изолированы: сбой любого детектора НЕ роняет весь фид (принцип
    «ошибка ≠ пусто» — Timetta-часть ленты приезжает как обычно).
    """
    items: list[dict[str, Any]] = []
    from core.operational.detectors import hub_deadlines, orphan_notes

    for detector in (hub_deadlines, orphan_notes):
        try:
            items.extend(detector(vault_path=vault_path, now=now))
        except Exception as exc:  # noqa: BLE001 — детектор не должен ронять кокпит
            logger.warning("детектор %s пропущен: %s", detector.__name__, exc)
    return items


def snapshot(
    *,
    mirror_path: Path | None = None,
    mail_manifest: Path | None = None,
    mail_threads_dir: Path | None = None,
    dismiss_path: Path | None = None,
    vault_path: Path | None = None,
    now: datetime | None = None,
    rings: Any = None,
) -> dict[str, Any]:
    """Структурный срез рабочего кокпита (read-only, без сети/LLM).

    ``rings`` (ORBIT-2) — кольца орбиты (``"mine,unit"`` | список | ``None``). ``None`` =
    ``mine``: «Требует внимания» показывает только кольцо 1, снапшот прежних полей не меняется;
    неизвестное кольцо → :class:`~core.operational.orbit.OrbitError` (отказ, не тихое ``mine``).

    Все пути — именованные kwargs с ``None``-дефолтом (реальные берутся из
    config-аксессоров); тесты инжектят tmp. Пустое/битое зеркало → пустые
    срезы и нулевые счётчики, не исключение. Пункты, снятые через
    :func:`record_dismissal` (snooze/ack/dismiss), не показываются, пока
    действует решение.
    """
    now = _to_utc(now) if now is not None else datetime.now(UTC)
    store = MirrorStore(mirror_path or timetta_mirror_path())
    mail_path = mail_manifest or outlook_ingest_manifest_path()
    store_errors: list[StoreUnavailableError] = []
    mail = _load_json_checked(mail_path, "mail_manifest", store_errors)
    mail_dict = mail if isinstance(mail, dict) else None
    threads_dir = mail_threads_dir or (Path(mail_path).parent / "mail_threads")
    dismissals = _load_json_checked(_dismiss_path(dismiss_path), "work_dismissals", store_errors)
    hidden = _hidden_predicate(dismissals if isinstance(dismissals, dict) else {}, now=now)

    def _table(name: str) -> list[dict[str, Any]]:
        # Битое зеркало ≠ «сделок нет»: пусто + конверт store_unavailable в ответе.
        try:
            return store.all(name)
        except (OSError, StoreUnavailableError) as exc:
            if isinstance(exc, StoreUnavailableError):
                store_errors.append(exc)
            else:
                store_errors.append(
                    StoreUnavailableError(f"зеркало {name}: {exc}", adapter="timetta_mirror")
                )
            return []

    # ORBIT-2: единая точка чтения сделок — ``orbit.visible`` (кольца ∩ DT_ORBIT_RINGS,
    # без помеченных удалёнными); задачи/проекты — по тем же сделкам.
    me = timetta_user_id()
    all_deals = _table("deals")
    deals = orbit.visible(all_deals, rings)
    issues = orbit.visible_issues(_table("issues"), orbit.visible_ids(all_deals, rings), me=me)
    projects = orbit.visible_projects(_table("projects"), deals, me=me)
    try:
        code_by_id = _state_code_map(store)
    except (OSError, StoreUnavailableError) as exc:
        store_errors.append(
            exc if isinstance(exc, StoreUnavailableError)
            else StoreUnavailableError(f"зеркало states: {exc}", adapter="timetta_mirror")
        )
        code_by_id = {}

    recent_mail = _recent_external_mail(mail_dict, threads_dir, now=now)
    unanswered = _unanswered_mail(recent_mail, now=now, hidden=hidden)
    attention = _attention(
        deals, issues, code_by_id, unanswered, now=now, projects=projects, hidden=hidden,
        extra=_detector_items(vault_path=vault_path, now=now),
    )
    result: dict[str, Any] = {
        "now": _iso_z(now),
        "attention": attention,
        "stale": _stale(deals, projects, issues, code_by_id, now=now, hidden=hidden),
        "deltas": _deltas(deals, projects, issues, recent_mail, now=now),
        "counts": _counts(deals, code_by_id, unanswered, now=now),
    }
    try:  # ORBIT-3 п.5: строка брифа «коллеги изменили N сделок, из них моих M»
        result["colleagues"] = _history.colleagues_summary(store, me=me, now=now)
    except StoreUnavailableError as exc:
        store_errors.append(exc)
        result["colleagues"] = {"changed_deals": 0, "mine": 0, "entries": 0,
                                "days": _history.history_days()}
    # PULT-STANDALONE-1 п.1: детерминированный бриф - база пульта на любой поверхности (без модели).
    result["brief"] = build_brief(result)
    seen_paths: set[str] = set()
    for err in store_errors:  # пустая лента из-за нечитаемого стора — не «всё тихо»
        path = str(err.context.get("path") or err.reason)
        if path not in seen_paths:
            seen_paths.add(path)
            err.add_to(result)
    return result


DISMISS_ACTIONS: frozenset[str] = frozenset({"snooze", "ack", "dismiss", "done", "clear"})

# Виды пунктов ленты «Работы» — префикс составного id (Ф13 в FINDINGS). Один список на
# всех: и читатель контекста (:func:`context`, ФП-8), и валидация решения (ФП-4).
FEED_KINDS: tuple[str, ...] = (
    "deal", "project", "issue", "checklist", "mail",
    "orphan", "hub_deadline", "resurface",
)


def _split_item_id(item_id: str) -> tuple[str, str]:
    """``"checklist:D-1:<hash>"`` → ``("checklist", "D-1:<hash>")`` (вид, остаток)."""
    text = str(item_id or "")
    kind, _, ref = text.partition(":")
    return kind, ref


def feed_item_exists(
    item_id: str,
    *,
    mirror_path: Path | None = None,
    mail_manifest: Path | None = None,
    vault_path: Path | None = None,
) -> bool:
    """Существует ли то, на что ссылается ``item_id`` пункта ленты (CONTRACT-1 ФП-4).

    Ссылка на пункт — такая же ссылка, как путь заметки, и её тоже нельзя принимать
    молча: до фикса ``work_dismiss("опечатка", "snooze")`` возвращал успех и писал
    решение по несуществующему пункту (Д11 — стор растёт мусором, обратной связи нет).

    Проверка **только по авторитетному локальному источнику** — каждая из того, что
    инструмент и так читает, без сети:

    * ``deal``/``checklist`` — сделка в орбите зеркала; ``project``/``issue`` — запись
      зеркала (тот же ``MirrorStore``, что строит ленту);
    * ``mail`` — хеш темы есть в манифесте почты (тот же манифест, что строит ленту);
    * ``orphan`` — детектор кладёт в ссылку vault-относительный путь заметки: проверяем
      файл на диске;
    * ``hub_deadline`` — id хаба: сверяем обходом хабов (тем же, которым идёт детектор),
      затем единой точкой резолва ФП-1;
    * ``resurface`` — проверяется только ФОРМА (``resurface:<src>:<tgt>``, обе части
      непусты). Пара рождается из журнала применённых связей, и её идентичность —
      ``note_id`` обоих концов; доказать существование дешёвым локальным чтением
      нельзя (нужен тот же индекс-манифест, что был у детектора), а **ложный отказ по
      догадке хуже пропущенной опечатки**: он ломает законное «убрать карточку».

    Неизвестный вид (или пустая ссылка) → ``False`` всегда: это и есть кейс опечатки.
    """
    kind, ref = _split_item_id(item_id)
    if kind not in FEED_KINDS or not ref:
        return False
    if kind in ("deal", "checklist", "project", "issue"):
        store = MirrorStore(mirror_path or timetta_mirror_path())
        head = ref.split(":")[0]
        if kind in ("deal", "checklist"):
            return _deal_by(store, head) is not None
        table = "projects" if kind == "project" else "issues"
        return any(
            str(rec.get("code")) == head or str(rec.get("id")) == head
            for rec in store.all(table)
        )
    if kind == "mail":
        mail_path = mail_manifest or outlook_ingest_manifest_path()
        manifest = _load_json(mail_path)
        if not isinstance(manifest, dict):
            return False
        return any(
            isinstance(entry, dict) and _hash(entry.get("subject")) == ref
            for entry in manifest.values()
        )
    if kind == "resurface":
        head, _, tail = ref.partition(":")
        return bool(head and tail)
    root = Path(vault_path or default_vault_path())
    return _resolve_note_ref(ref, root) is not None


def record_dismissal(
    item_id: str,
    action: str,
    *,
    as_of: str | None = None,
    until_days: float | None = None,
    dismiss_path: Path | None = None,
    mirror_path: Path | None = None,
    mail_manifest: Path | None = None,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Записать/снять решение по пункту фида (снуз/ack/dismiss/clear-undo).

    ``snooze`` прячет на ``until_days`` (по умолчанию 7); ``ack``/``dismiss``/
    ``done`` прячут до нового события (фиксируют ``as_of`` пункта); ``clear``
    удаляет решение (undo). Пишет в ``.derived/operational/work_dismissals.json``.

    **CONTRACT-1 ФП-4 (Д11).** Неизвестный ``item_id`` → ``{ok: false, refused: true,
    code: "unknown_item"}`` и **ничего не пишется**. ``clear`` (undo) разрешён по любому
    id, для которого решение уже лежит в сторе: снять своё старое решение можно, даже
    если сам пункт с тех пор исчез — иначе мусор было бы нечем убрать.
    """
    if action not in DISMISS_ACTIONS:
        raise ValueError(f"unknown action: {action!r} (ожидалось {sorted(DISMISS_ACTIONS)})")
    path = _dismiss_path(dismiss_path)
    raw = _load_json(path)
    store: dict[str, Any] = raw if isinstance(raw, dict) else {}
    now = datetime.now(UTC)

    known = item_id in store and action == "clear"
    if not known and not feed_item_exists(
        item_id, mirror_path=mirror_path, mail_manifest=mail_manifest,
        vault_path=vault_path,
    ):
        return {
            "ok": False,
            "refused": True,
            "code": "unknown_item",
            "item_id": item_id,
            "action": action,
            "error": (
                f"пункт {item_id!r} не найден: вид должен быть одним из "
                f"{', '.join(FEED_KINDS)}, а ссылка — существующей (сделка/проект/"
                "задача в зеркале, тред в манифесте почты, заметка в vault). "
                "Решение не записано"
            ),
        }

    if action == "clear":
        store.pop(item_id, None)
    else:
        entry: dict[str, Any] = {"action": action, "ts": _iso_z(now)}
        if action == "snooze":
            entry["until"] = _iso_z(now + timedelta(days=float(until_days or 7)))
        else:
            entry["seen_as_of"] = as_of or _iso_z(now)
        store[item_id] = entry

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")
    result = {"ok": True, "item_id": item_id, "action": action}
    if action == "snooze":
        result["until"] = store[item_id]["until"]
    return result


def resolve_deal_guid(store: MirrorStore, deal_ref: str) -> str | None:
    """Guid сделки по её guid или code из зеркала (scope-guard орбиты).

    ORBIT-2: ищет среди ВИДИМЫХ колец (``DT_ORBIT_RINGS``), без удалённых в Timetta; право
    (RETIRE-WRITE-1: записи в Timetta нет, гейта записи по кольцам тоже)."""
    ref = str(deal_ref or "").strip()
    for deal in orbit.visible(store.all("deals"), orbit.enabled_rings()):
        if str(deal.get("id")) == ref or str(deal.get("code")) == ref:
            return str(deal.get("id"))
    return None


# --------------------------------------------------------------------------- #
# Инлайн-контекст пункта (WORK-4) — детерминированно из зеркал, без модели/сети  #
# --------------------------------------------------------------------------- #
def _date(value: Any) -> str:
    dt = _parse_iso(value)
    return dt.date().isoformat() if dt else "—"


def _deal_by(store: MirrorStore, ref: str) -> dict[str, Any] | None:
    for deal in orbit.visible(store.all("deals"), orbit.enabled_rings()):
        if str(deal.get("code")) == ref or str(deal.get("id")) == ref:
            return deal
    return None


def _deal_changes(store: MirrorStore, deal: dict[str, Any], limit: int = 5) -> list[dict[str, Any]]:
    """Последние правки коллег по сделке из ``history_feed`` (оффлайн; сбой стора → пусто)."""
    try:
        rows = _history.feed_rows(
            store, timetta_user_id(), rings=list(orbit.enabled_rings()),
            days=_history.history_days(),
        )
    except StoreUnavailableError:
        return []
    code = deal.get("code")
    return [
        {"at": r["at"], "actor": r["actor"], "text": r["text"], "source": r["source"]}
        for r in rows if r["deal"].get("code") == code
    ][:limit]


def _deal_context(store: MirrorStore, ref: str) -> dict[str, Any]:
    deal = _deal_by(store, ref)
    if deal is None:
        return {"type": "deal", "title": ref, "found": False, "code": "item_not_found",
                "lines": ["сделка не найдена в зеркале"]}
    guid = str(deal.get("id"))
    lines = [f"Стадия: {deal.get('state_name') or '—'}"]
    if deal.get("manager_name"):
        lines.append(f"Менеджер: {deal['manager_name']}")
    if deal.get("organization_name"):
        lines.append(f"Клиент: {deal['organization_name']}")
    lines.append(f"Последнее изменение: {_date(deal.get('modified'))}")
    check = [c for c in (deal.get("check_list") or []) if isinstance(c, dict)]
    if check:
        done = sum(1 for c in check if c.get("fulfilled"))
        lines.append(f"Чек-лист: {len(check)} пунктов, выполнено {done}")
        for c in check[:6]:
            mark = "✓ " if c.get("fulfilled") else "• "
            due = _parse_iso(c.get("deadline"))
            lines.append(f"  {mark}{str(c.get('title') or '').strip()}"
                         + (f" · срок {due.date().isoformat()}" if due else ""))
    issues = [i for i in store.all("issues") if str(i.get("deal_id")) == guid]
    if issues:
        lines.append(f"Задачи проекта: {len(issues)}")
        for i in issues[:6]:
            due = _parse_iso(i.get("due_date"))
            lines.append(f"  • [{i.get('code')}] {str(i.get('name') or '').strip()} — "
                         f"{i.get('state_name') or '—'}"
                         + (f" · срок {due.date().isoformat()}" if due else ""))
    # ORBIT-3: что менял кто-то другой (лента изменений коллег: автор + суть, без значений).
    changes = _deal_changes(store, deal)
    if changes:
        lines.append("Изменения коллег:")
        lines += [f"  • {c['at'][:10]} {c['actor']}: {c['text']}" for c in changes]
    return {"type": "deal", "title": f"[{deal.get('code')}] {deal.get('name')}",
            "found": True, "lines": lines, "deal_guid": guid, "changes": changes}


def _project_context(store: MirrorStore, ref: str) -> dict[str, Any]:
    proj = next((p for p in store.all("projects")
                 if str(p.get("code")) == ref or str(p.get("id")) == ref), None)
    if proj is None:
        return {"type": "project", "title": ref, "found": False, "code": "item_not_found",
                "lines": ["проект не найден в зеркале"]}
    guid = str(proj.get("id"))
    lines = [f"Стадия: {proj.get('state_name') or '—'}"]
    if proj.get("organization_name"):
        lines.append(f"Клиент: {proj['organization_name']}")
    if proj.get("manager_name"):
        lines.append(f"Менеджер: {proj['manager_name']}")
    lines.append(f"Последнее изменение: {_date(proj.get('modified'))}")
    issues = [i for i in store.all("issues") if str(i.get("project_id")) == guid]
    if issues:
        lines.append(f"Задачи: {len(issues)}")
        for i in issues[:8]:
            lines.append(f"  • [{i.get('code')}] {str(i.get('name') or '').strip()} — "
                         f"{i.get('state_name') or '—'}")
    return {"type": "project", "title": f"[{proj.get('code')}] {proj.get('name')}",
            "found": True, "lines": lines}


def _issue_context(store: MirrorStore, ref: str) -> dict[str, Any]:
    issue = next((i for i in store.all("issues") if str(i.get("code")) == ref), None)
    if issue is None:
        return {"type": "issue", "title": ref, "found": False, "code": "item_not_found",
                "lines": ["задача не найдена в зеркале"]}
    lines = [f"Стадия: {issue.get('state_name') or '—'}", f"Срок: {_date(issue.get('due_date'))}"]
    if issue.get("assigned_name"):
        lines.append(f"Исполнитель: {issue['assigned_name']}")
    lines.append(f"Последнее изменение: {_date(issue.get('modified'))}")
    deal = _deal_by(store, str(issue.get("deal_id")))
    if deal is not None:
        lines.append(
            f"Сделка: [{deal.get('code')}] {deal.get('name')} — {deal.get('state_name') or '—'}"
        )
    return {"type": "issue", "title": f"[{issue.get('code')}] {issue.get('name')}",
            "found": True, "lines": lines}


def _mail_context(
    ref_hash: str, manifest_path: Path | None, threads_dir: Path | None
) -> dict[str, Any]:
    mail_path = manifest_path or outlook_ingest_manifest_path()
    manifest = _load_json(mail_path)
    if not isinstance(manifest, dict):
        return {"type": "mail", "title": "письмо", "found": False,
                "code": "store_unavailable", "lines": ["манифест почты недоступен"]}
    tdir = threads_dir or (Path(mail_path).parent / "mail_threads")
    for key, entry in manifest.items():
        if not isinstance(entry, dict) or _hash(entry.get("subject")) != ref_hash:
            continue
        lines = [f"Последнее письмо: {_date(entry.get('last_date'))}"]
        reply_to = ""
        sidecar = _load_sidecar(tdir, str(key))
        if isinstance(sidecar, dict):
            cps = [d for d in (sidecar.get("counterparty_domains") or []) if d]
            if cps:
                lines.append(f"Контрагенты: {', '.join(cps[:4])}")
            msgs = [m for m in (sidecar.get("messages") or {}).values() if isinstance(m, dict)]
            lines.append(f"Сообщений в треде: {len(msgs) or entry.get('count') or 0}")
            if msgs:
                _min = datetime.min.replace(tzinfo=UTC)
                msgs.sort(key=lambda m: _parse_iso(m.get("date")) or _min)
                last = msgs[-1]
                lines.append(f"Последнее — {'исходящее' if last.get('is_me') else 'входящее'}"
                             f" от {_date(last.get('date'))}")
                # Текст последнего ВХОДЯЩЕГО письма — то, на что отвечаем; в черновик.
                inbound = next((m for m in reversed(msgs) if not m.get("is_me")), None)
                if inbound:
                    reply_to = str(inbound.get("text") or "").strip()[:3000]
        out = {"type": "mail", "title": str(entry.get("subject") or "письмо"),
               "found": True, "lines": lines}
        if reply_to:
            out["reply_to"] = reply_to
        return out
    return {"type": "mail", "title": "письмо", "found": False, "code": "item_not_found",
            "lines": ["тред не найден в манифесте"]}


def _resolve_note_ref(ref: str, root: Path) -> Path | None:
    """Ссылка на заметку → путь: единая точка ФП-1, затем обход хабов по ``id``.

    Второй шаг нужен для хаба, у которого ``id`` ≠ имя файла (``03-projects/<slug>/hub.md``
    с ``id: project-<slug>``) и которого ещё нет в индекс-манифесте — то есть для только
    что созданного хаба. Без него законная карточка «дедлайн хаба» получила бы «заметка
    не найдена», хотя детектор её только что показал.
    """
    resolved = resolve_note_path(ref, vault_path=root)
    if resolved is not None:
        return resolved
    from core.operational.hub_meta import iter_hubs

    target = str(ref or "").strip()
    for path, note in iter_hubs(root):
        if note.id == target:
            return path
    return None


def _note_context(kind: str, ref: str, vault_path: Path | None) -> dict[str, Any]:
    """Контекст заметочного пункта ленты: сирота / дедлайн хаба (CONTRACT-1 ФП-8, Д9).

    Ссылку резолвит единая точка ФП-1, поэтому годится и путь (его кладёт детектор
    сирот), и id хаба (его кладёт детектор дедлайнов). ``found: false`` + ``code`` —
    машиночитаемо, а не только прозой в ``lines``.
    """
    root = Path(vault_path or default_vault_path())
    resolved = _resolve_note_ref(ref, root)
    if resolved is None:
        return {"type": kind, "title": ref, "found": False, "code": "note_not_found",
                "lines": ["заметка не найдена в vault"]}
    preview = note_preview(str(resolved), vault_path=root)
    try:
        rel = resolved.relative_to(root.resolve()).as_posix()
    except ValueError:
        rel = str(resolved)
    lines = [f"Заметка: {rel}"]
    fm = read_note(resolved).frontmatter
    for label, key in (("Заголовок", "title"), ("Тип", "type"), ("Сущность", "entity"),
                       ("Статус", "status"), ("Трек", "track"), ("Дедлайн", "deadline"),
                       ("Создана", "created")):
        value = fm.get(key)
        if value:
            lines.append(f"{label}: {value}")
    if preview.get("preview"):
        lines.append(str(preview["preview"]))
    # Заголовок карточки: ``# `` из тела (его берёт note_preview) → frontmatter title →
    # путь. У хабов и инжест-заметок заголовок живёт во frontmatter, а не в теле.
    title = str(preview.get("title") or fm.get("title") or "").strip() or rel
    return {"type": kind, "title": title, "found": True, "path": rel, "lines": lines}


def _resurface_context(ref: str, vault_path: Path | None) -> dict[str, Any]:
    """Контекст пары resurfacing (``resurface:<новая>:<старая>``) — ФП-8 (Д9)."""
    root = Path(vault_path or default_vault_path())
    new_ref, _, old_ref = ref.partition(":")
    lines: list[str] = []
    found_any = False
    for label, one in (("Свежая", new_ref), ("Старая", old_ref)):
        preview = note_preview(one, vault_path=root) if one else {"found": False}
        if preview.get("found"):
            found_any = True
            lines.append(f"{label}: {preview.get('title') or one}")
            if preview.get("preview"):
                lines.append(f"  {preview['preview']}")
        else:
            lines.append(f"{label}: {one or '—'} — заметка не найдена в vault")
    out: dict[str, Any] = {"type": "resurface", "title": f"{new_ref} ↔ {old_ref}",
                           "found": found_any, "lines": lines}
    if not found_any:
        out["code"] = "note_not_found"
    return out


def context(
    item_id: str,
    *,
    mirror_path: Path | None = None,
    mail_manifest: Path | None = None,
    mail_threads_dir: Path | None = None,
    vault_path: Path | None = None,
) -> dict[str, Any]:
    """Инлайн-сводка по пункту фида (WORK-4) — читабельные ``lines``, без сети/LLM.

    ``item_id`` из :func:`snapshot`/:func:`core.operational.resurface.resurfaced` — ВСЕ
    виды ленты: ``deal:``/``checklist:``/``project:``/``issue:``/``mail:`` (из зеркала и
    манифеста почты) и, с CONTRACT-1 ФП-8 (Д9), заметочные ``orphan:``/``hub_deadline:``/
    ``resurface:``. До фикса три последних формы — id из СВОЕЙ ЖЕ ленты — получали
    «нет контекста для этого типа»: фид их показывал, а раскрыть карточку было нечем.

    Privacy — как в фиде (без сумм). Неизвестный вид → заглушка с ``code``.
    """
    text = str(item_id or "")
    kind = text.split(":", 1)[0]
    ref = text.split(":", 1)[1] if ":" in text else ""
    if kind == "orphan":
        return _note_context("orphan", ref, vault_path)
    if kind == "hub_deadline":
        return _note_context("hub_deadline", ref, vault_path)
    if kind == "resurface":
        return _resurface_context(ref, vault_path)
    store = MirrorStore(mirror_path or timetta_mirror_path())
    if kind in ("deal", "checklist"):
        return _deal_context(store, ref.split(":")[0])
    if kind == "project":
        return _project_context(store, ref.split(":")[0])
    if kind == "issue":
        return _issue_context(store, ref)
    if kind == "mail":
        return _mail_context(ref, mail_manifest, mail_threads_dir)
    return {
        "type": "unknown", "title": text, "found": False, "code": "unknown_kind",
        "lines": [
            f"нет контекста для вида {kind!r}: известны " + ", ".join(FEED_KINDS),
        ],
    }


_FM_RE = re.compile(r"^---\n.*?\n---\n", re.DOTALL)
_LINK_LINE_RE = re.compile(r"^\s*(##\s*Связано|\[\[)", re.MULTILINE)


def note_preview(
    name: str, *, vault_path: Path | None = None, max_chars: int = 320
) -> dict[str, Any]:
    """Превью заметки vault по ссылке (WORK-5) — чтобы понять, о чём линковать.

    Срезает frontmatter и хвост «## Связано», отдаёт заголовок (первый ``# ``) и
    первые ``max_chars`` тела. Read-only, без сети/LLM. Не найдено →
    ``{found: false}``. Приватность: только имя/заголовок/фрагмент.

    **NOTE-ID-1.** Ссылка резолвится :func:`core.vault.resolve_note_path` — путь,
    имя файла ИЛИ frontmatter ``id`` (через индекс-манифест, O(1)). Кейс К. с пульта:
    карточка линк-предложения показывала «заметка не найдена в vault», потому что
    целью был id ``pak-a-zdo-overview``, а файл называется ``pak-a-overview.md``
    (легаси-форма ``legacy-<hash>`` разбирается там же — прежнее поведение цело).
    """
    slug = str(name or "").strip()
    if not slug:
        return {"name": name, "found": False, "code": "bad_ref",
                "preview": "пустое имя"}
    root = Path(vault_path or default_vault_path())
    found = resolve_note_path(slug, vault_path=root)
    if found is None:
        return {"name": name, "found": False, "code": "item_not_found",
                "preview": "заметка не найдена в vault"}
    try:
        raw = found.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {"name": name, "found": False, "code": "store_unavailable",
                "preview": "не удалось прочитать"}
    body = _FM_RE.sub("", raw, count=1)
    body = body.split("## Связано")[0]
    title = ""
    lines: list[str] = []
    for ln in body.splitlines():
        s = ln.strip()
        if not s:
            continue
        if s.startswith("# ") and not title:
            title = s.lstrip("# ").strip()
            continue
        if s.startswith("#"):
            continue
        lines.append(s)
    preview = " ".join(lines)
    preview = preview[:max_chars].rstrip() + ("…" if len(preview) > max_chars else "")
    out: dict[str, Any] = {
        "name": name,
        "found": True,
        "title": title or found.stem,
        "preview": preview or "(пусто)",
    }
    # MAIL-THREAD-1: у почтового треда — автор/дата последнего сообщения (frontmatter),
    # чтобы по превью было видно, чем тред кончился. У не-почты ключей нет.
    mail_tail = _mail_tail(raw)
    if mail_tail:
        out.update(mail_tail)
    return out


def _mail_tail(raw: str) -> dict[str, Any]:
    """``{last_from, last_date, last_from_me}`` для ``email-thread``; иначе ``{}``."""
    try:
        import frontmatter

        from core.retrieval.mail_read import EMAIL_THREAD, last_message_info, parse_thread

        post = frontmatter.loads(raw)
        fm, body = dict(post.metadata), post.content
    except Exception:  # noqa: BLE001 — превью best-effort
        return {}
    if fm.get("source_type") != EMAIL_THREAD:
        return {}
    last_from = str(fm.get("last_from") or "")
    last_date = str(fm.get("last_date") or "")
    from_me = fm.get("last_from_me")
    if not last_from:
        info = last_message_info(parse_thread(body))
        last_from, from_me = info["last_from"], info["last_from_me"]
        last_date = last_date or info["last_date"]
    if not last_from:
        return {}
    out: dict[str, Any] = {"last_from": last_from, "last_date": last_date, "last_from_me": from_me}
    # OUT-COMPLETE-1: превью почтового треда — касание треда; телеметрия покрытия
    # (граница MCP) привязывает событие к заметке по ``note_id``.
    if fm.get("id"):
        out["note_id"] = str(fm["id"])
    if fm.get("message_count"):
        out["message_count"] = fm["message_count"]
    return out
