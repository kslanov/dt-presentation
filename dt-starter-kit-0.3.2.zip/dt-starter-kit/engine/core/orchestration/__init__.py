"""Orchestration Plane — decision guards over the assembled prompt (§10a).

The plane that sits *after* retrieval/facts assembly and *before* the artifact is
produced. GATE-1 landed its first member: :mod:`core.orchestration.gate`, the
grounding gate that refuses to emit a prompt when a case's declared critical
resources are missing (honest stop + how-to, instead of a stub-filled draft).
PLAN-1 adds :mod:`core.orchestration.planner`, the deterministic task planner that
materialises a case's critical-resource plan and feeds its critical nodes to the
gate — so the decomposition is a visible checklist, not orchestration in the
user's head.

JOB-1 adds :mod:`core.orchestration.jobs`, the async job runner — a durable
``jobs.db`` + a detached worker that runs a long op (Outlook read / reindex / big
lift) off the MCP client's ceiling, reusing :class:`~core.progress.ProgressBeacon`
and the ``start_sync`` detached-spawn shape.

Invariants (``tests/test_invariant.py``): ``core/orchestration`` imports neither
MCP nor CLI; Path B — the gate is a pure deterministic function, the planner is
deterministic (templates, no LLM; probes reuse existing read-only resolvers), and
the job worker runs only the operation itself, never a model.
"""

from __future__ import annotations

from core.orchestration.gate import (
    DEFAULT_MIN_CONFIDENCE,
    GateVerdict,
    Missing,
    check_grounding,
)
from core.orchestration.jobs import (
    SUBMITTABLE_OPS,
    JobCancelled,
    JobError,
    cancel,
    list_jobs,
    run_job,
    status,
    submit,
)
from core.orchestration.planner import Node, Plan, plan, resolve_status

__all__ = [
    "GateVerdict",
    "Missing",
    "check_grounding",
    "DEFAULT_MIN_CONFIDENCE",
    "Node",
    "Plan",
    "plan",
    "resolve_status",
    "SUBMITTABLE_OPS",
    "JobCancelled",
    "JobError",
    "submit",
    "status",
    "cancel",
    "run_job",
    "list_jobs",
]
