"""Grounding gate — refuse to generate when critical resources are missing (GATE-1).

``generate`` (Path B) otherwise composes and returns a prompt regardless of
whether the critical facts actually lifted — on Acme that produced a draft with
empty component cells instead of an honest stop. This module is the guard: given
the facts and context an :class:`~core.generation.AssembledPrompt` resolved, plus
a case's *declared requirements*, decide ``ok`` vs ``blocked`` and, when blocked,
say exactly what is missing and how to obtain it (negative provenance).

``check_grounding`` is a **pure, deterministic function** (Path B): it reads only
the passed facts/context/declaration — no network, no LLM, no disk. Requirement
declaration is distinct from injection: ``structured_facts: true`` means "inject
facts if present"; ``required_facts: [money]`` means "**block** if absent" — the
gate acts only on the latter.

An ``exemplar`` requirement is now a checkable **resource** (TMPL-1): the caller
passes ``exemplar_present`` (whether ``assemble_prompt`` resolved a form-exemplar);
the requirement closes when it is present, blocks when the caller resolved none,
and stays pass-through only when presence is genuinely unknown (``None``). The task
planner is still PLAN-1.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "Missing",
    "GateVerdict",
    "check_grounding",
    "DEFAULT_MIN_CONFIDENCE",
    "HOW_HINTS",
    "CHECKABLE_KINDS",
    "CONTEXT_KIND",
    "EXEMPLAR_KIND",
    "how_hint",
    "what_label",
    "plan_inconsistencies",
]

# A fact must clear this confidence to *close* a requirement, so a
# confidence=0.15 "no-label" fact (FACT-1) never satisfies `required_facts`.
DEFAULT_MIN_CONFIDENCE = 0.5

# Fact kinds the gate can actually verify against `facts` (FACT-1 vocabulary).
# A requirement for anything else (a not-yet-modelled resource) is unverifiable →
# treated as pass-through, never blocks. `exemplar` is handled separately below
# (a resource verified via `exemplar_present`, not a fact kind).
_CHECKABLE_KINDS = frozenset(
    {"money", "quantity", "date", "rate", "requisite", "bin", "contact"}
)

# The synthetic requirement key for "retrieval must be non-empty".
_CONTEXT_KIND = "context"

# The resource requirement closed by TMPL-1's form-exemplar (via exemplar_present).
_EXEMPLAR_KIND = "exemplar"

# Public aliases so PLAN-1 (and any other caller) reuses the exact same kind
# vocabulary — one dictionary, no synonyms.
CHECKABLE_KINDS = _CHECKABLE_KINDS
CONTEXT_KIND = _CONTEXT_KIND
EXEMPLAR_KIND = _EXEMPLAR_KIND

# Deterministic how-to hints (negative provenance): what to run to obtain each
# missing resource. Constant — no model, no lookup.
HOW_HINTS: dict[str, str] = {
    "money": (
        "подними источник карточки: lift_source(note_id) → get_facts(kind='money')"
    ),
    "quantity": (
        "подними источник карточки: lift_source(note_id) → get_facts(kind='quantity')"
    ),
    "rate": "get_facts(kind='rate') — подними источник карточки, если пусто",
    "date": "get_facts(kind='date') — подними источник карточки, если пусто",
    "requisite": "get_facts(kind='requisite') или web-поиск реквизитов контрагента",
    "bin": "get_facts(kind='bin') или web-поиск БИН/ИИН контрагента",
    "contact": "get_facts(kind='contact') — подними карточку/подпись письма",
    _CONTEXT_KIND: (
        "уточни клиента/сущность (client_id/project_id/deal_id) "
        "или расширь corpus: generate(corpus='both'|'legacy')"
    ),
    _EXEMPLAR_KIND: (
        "найди образец: find_exemplar(genre, client) — или укажи exemplar_ref "
        "(note_id/путь) в generate"
    ),
}

# Human-readable label for a missing resource kind (the `what`).
_WHAT_LABELS: dict[str, str] = {
    "money": "денежные суммы",
    "quantity": "количественные показатели",
    "rate": "ставки/проценты",
    "date": "даты/сроки",
    "requisite": "реквизиты",
    "bin": "БИН/ИИН",
    "contact": "контакты",
    _CONTEXT_KIND: "релевантный контекст (ретривал пуст)",
    _EXEMPLAR_KIND: "образец оформления (форма прошлого документа)",
}


@dataclass
class Missing:
    """One unmet requirement: ``what`` (human), its ``kind``, ``how`` to obtain it."""

    what: str
    kind: str
    how: str

    def to_dict(self) -> dict[str, str]:
        return {"what": self.what, "kind": self.kind, "how": self.how}


@dataclass
class GateVerdict:
    """Outcome of a grounding check: ``status`` plus the unmet requirements."""

    status: str  # "ok" | "blocked"
    missing: list[Missing] = field(default_factory=list)

    @property
    def blocked(self) -> bool:
        return self.status == "blocked"

    @property
    def missing_kinds(self) -> list[str]:
        return [m.kind for m in self.missing]

    def to_dict(self) -> dict[str, Any]:
        return {"status": self.status, "missing": [m.to_dict() for m in self.missing]}


def _how(kind: str) -> str:
    return HOW_HINTS.get(kind, f"добудь ресурс типа {kind!r} и повтори генерацию")


def _what(kind: str) -> str:
    return _WHAT_LABELS.get(kind, kind)


def how_hint(kind: str) -> str:
    """Public: the deterministic how-to for a resource ``kind`` (PLAN-1 reuse)."""
    return _how(kind)


def what_label(kind: str) -> str:
    """Public: the human label for a resource ``kind`` (PLAN-1 reuse)."""
    return _what(kind)


def _normalize_requirement(req: Any) -> tuple[str, float] | None:
    """Normalize a requirement to ``(kind, min_confidence)``; ``None`` if malformed.

    Accepts a bare string (``"money"``) or the extended form
    (``{"kind": "money", "min_confidence": 0.7}``).
    """
    if isinstance(req, str):
        kind = req.strip()
        return (kind, DEFAULT_MIN_CONFIDENCE) if kind else None
    if isinstance(req, dict):
        kind = str(req.get("kind", "")).strip()
        if not kind:
            return None
        raw = req.get("min_confidence", DEFAULT_MIN_CONFIDENCE)
        try:
            min_conf = float(raw)
        except (TypeError, ValueError):
            min_conf = DEFAULT_MIN_CONFIDENCE
        return kind, min_conf
    return None


def requires_current(req: Any) -> bool:
    """FACTS-BITEMPORAL-1: требование ``{"kind": …, "current": true}`` - закрывается только
    актуальным фактом."""
    return isinstance(req, dict) and bool(req.get("current"))


def fact_is_current(fact: Any, *, today: str | None = None) -> bool:
    """Актуальный факт: не вытеснен более новой версией, не из черновика, ``valid_to`` пуст или
    впереди.

    Факт без временных полей (не из стора - свежеизвлеченный при генерации) считается актуальным:
    вытеснить его некому, пока цепочка его не накрыла."""
    if getattr(fact, "provisional", False) or getattr(fact, "superseded_by", None):
        return False
    valid_to = getattr(fact, "valid_to", None)
    if not valid_to:
        return True
    from datetime import UTC, datetime

    return str(valid_to) > (today or datetime.now(UTC).date().isoformat())


def check_grounding(
    *,
    facts: list[Any],
    context: list[Any],
    required_facts: list[Any] | None = None,
    required_context: bool = False,
    exemplar_present: bool | None = None,
) -> GateVerdict:
    """Decide ``ok``/``blocked`` for the declared requirements (pure, deterministic).

    A ``required_facts`` entry (``"money"`` or ``{"kind", "min_confidence"}``) is
    **closed** when ``facts`` holds ≥1 fact of that ``kind`` with ``confidence ≥``
    its threshold (default :data:`DEFAULT_MIN_CONFIDENCE`) — so a low-confidence,
    unlabeled fact never satisfies a requirement. ``"current": true`` (FACTS-BITEMPORAL-1)
    additionally demands a CURRENT fact (:func:`fact_is_current`): a fact displaced by a newer
    version of its source, or one lifted from a draft, does not close it.
    ``required_context=True`` is
    closed when ``context`` is non-empty.

    An ``exemplar`` entry is the TMPL-1 **resource** requirement: closed when
    ``exemplar_present`` is True, **blocked** when the caller resolved none
    (``False``), and passed through when presence is unknown (``None`` — e.g. a
    caller that never resolves exemplars). Any other unmodelled kind is passed
    through. No requirements ⇒ ``ok`` with empty ``missing`` (no-op, backward
    compatible).
    """
    missing: list[Missing] = []

    # Facts present per kind that clear their threshold. Computed lazily per
    # requirement so different thresholds are honored.
    for req in required_facts or []:
        norm = _normalize_requirement(req)
        if norm is None:
            continue
        kind, min_conf = norm
        # TMPL-1 resource: verified via exemplar_present, not against `facts`.
        if kind == _EXEMPLAR_KIND:
            if exemplar_present is False:
                missing.append(
                    Missing(what=_what(kind), kind=kind, how=_how(kind))
                )
            continue
        # Not-yet-modelled resource types are unverifiable now → do not block.
        if kind not in _CHECKABLE_KINDS:
            continue
        want_current = requires_current(req)
        satisfied = any(
            getattr(f, "kind", None) == kind
            and float(getattr(f, "confidence", 0.0) or 0.0) >= min_conf
            and (not want_current or fact_is_current(f))
            for f in facts
        )
        if not satisfied:
            missing.append(Missing(what=_what(kind), kind=kind, how=_how(kind)))

    if required_context and not context:
        missing.append(
            Missing(what=_what(_CONTEXT_KIND), kind=_CONTEXT_KIND, how=_how(_CONTEXT_KIND))
        )

    return GateVerdict(status="blocked" if missing else "ok", missing=missing)


def plan_inconsistencies(
    nodes: list[dict[str, Any]],
    *,
    facts: list[Any],
    context: list[Any],
    missing: list[Missing],
    exemplar_present: bool | None = None,
) -> list[dict[str, str]]:
    """Узлы плана, чей статус ``present`` противоречит собранному ответу (HUB-ALIAS-1 п.4).

    Проба плана смотрит в хранилище по сущности («факты вида money у клиента есть»), а гейт - в
    то, что реально собрано для этого вызова. Узел не может быть ``present``, когда собранных
    фактов его вида нет (для ``context`` - контекст пуст, для ``exemplar`` - образец не
    разрешился) И в ``missing`` ровно та же категория: иначе ответ говорит «есть» и «не хватает»
    про одно и то же. Возвращает ``[{name, kind, reason}]``; вызывающий понижает такой узел до
    ``partial`` и кладет конверт ``plan_inconsistent`` - блок гейта (``missing``) не ослабляется.
    Чистая функция, без диска и сети.
    """
    missing_kinds = {m.kind for m in missing}
    have_facts = {str(getattr(f, "kind", "")) for f in facts}
    out: list[dict[str, str]] = []
    for node in nodes:
        kind = str(node.get("kind") or "")
        if node.get("status") != "present" or kind not in missing_kinds:
            continue
        if kind in _CHECKABLE_KINDS:
            empty = kind not in have_facts
        elif kind == _CONTEXT_KIND:
            empty = not context
        elif kind == _EXEMPLAR_KIND:
            empty = exemplar_present is False
        else:
            continue
        if empty:
            out.append({
                "name": str(node.get("name") or kind), "kind": kind,
                "reason": f"узел «{kind}» помечен как имеющийся, но собранных данных нет, "
                          "а гейт считает их недостающими",
            })
    return out
