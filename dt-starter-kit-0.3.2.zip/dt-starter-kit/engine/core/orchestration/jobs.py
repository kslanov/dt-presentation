"""JOB-1 — async job runner (Orchestration Plane §10a, roadmap §7 Phase C).

Long operations — an Outlook-bridge read, a ``reindex``, a big-file ``lift`` —
are synchronous and can outlast the MCP client's per-tool ceiling (~minutes), so
the client gives up before the work finishes (the Acme «4-minute timeout»). This
module adds an **async path**: :func:`submit` records the job, spawns a *detached*
worker, and returns a ``job_id`` immediately; the chat polls :func:`status`. The
synchronous fast paths (``work_meetings`` &c.) are untouched — this is an extra
lane, not a replacement.

What we **reuse** (принцип 12 — no second implementations):

* :class:`~core.progress.ProgressBeacon` for live progress → ``pult_activity``
  sees a running job like any other long op;
* the ``start_sync`` detached-worker shape (``Popen`` + ``start_new_session`` +
  stdio→devnull, ``popen`` injectable for tests) — the worker is a spawned CLI
  (``cli/dt_job_worker.py``) by **path**, not an import (so ``core`` ⊥ cli holds);
* the ``facts.db`` SQLite shape (``sqlite3`` + ``_connect`` + ``init_db`` +
  ``meta.schema_version``) for the ``jobs`` table.

Durability (принцип 11): progress is written **as it happens** to both the beacon
and the durable ``jobs`` row (a job never «goes silent until the end»); the result
lands in ``.derived/jobs/<id>.json`` referenced by ``result_ref``, so a finished
job survives an MCP-server restart (it is never held only in memory). Jobs are
**interruptible**: :func:`cancel` flips a cooperative flag the worker checks at
every checkpoint (and best-effort SIGTERMs the worker), so a long job stops
gracefully at the next checkpoint as ``cancelled`` — never a half-written state.
Resumable ops (``reindex``) resume from their own checkpoint on the next run.

The ``jobs`` table lives in the shared ``dt.db`` (DB-1: one connection, one schema
version, one migration framework — :mod:`core.db`); it once had its own
``jobs.db``, migrated in on first open. Multi-process is real (cron sync + MCP
server + this worker) so WAL + ``busy_timeout`` are mandatory — both come from the
shared :func:`core.db.connect`. The DAO API is unchanged; only the backend moved.

Invariant (``tests/test_invariant.py``): this module imports neither ``cli`` nor
``mcp-server``. Path B — no LLM/inference here; the spawned worker only runs the
operation itself (bridge / reindex / lift), never a model.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import signal
import sqlite3
import subprocess
import uuid
from collections.abc import Callable, Iterator
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import ENGINE_ROOT, jobs_db_path, jobs_dir
from core.db import connect, schema_version

__all__ = [
    "SCHEMA_VERSION",
    "STATES",
    "SUBMITTABLE_OPS",
    "OpNotAvailable",
    "JobCancelled",
    "JobError",
    "JobProgress",
    "Handler",
    "init_db",
    "stored_schema_version",
    "create",
    "mark_running",
    "update_progress",
    "finish",
    "fail",
    "mark_cancelled",
    "cancel",
    "request_cancel",
    "is_cancel_requested",
    "get",
    "list_jobs",
    "submit",
    "status",
    "run_job",
]

SCHEMA_VERSION = 1

# Lifecycle states. A job is created ``queued``, the worker flips it ``running``,
# and it settles into exactly one terminal state.
STATE_QUEUED = "queued"
STATE_RUNNING = "running"
STATE_DONE = "done"
STATE_FAILED = "failed"
STATE_CANCELLED = "cancelled"
STATES = (STATE_QUEUED, STATE_RUNNING, STATE_DONE, STATE_FAILED, STATE_CANCELLED)
_TERMINAL = (STATE_DONE, STATE_FAILED, STATE_CANCELLED)


class OpNotAvailable(RuntimeError):
    """PERSONAL-3: ``op`` есть в белом списке, но не у роли этого экземпляра (манифест роли)."""

    def __init__(self, op: str, role: str, available: list[str]) -> None:
        super().__init__(f"op {op!r} недоступен роли {role!r}; доступны: {', '.join(available)}")
        self.op, self.role, self.available = op, role, available


class JobError(RuntimeError):
    """A job could not be submitted or run (e.g. an op outside the white list)."""


class JobCancelled(Exception):
    """Raised inside the worker to unwind a job to a graceful ``cancelled`` stop.

    Thrown by the cooperative cancel check at a checkpoint or by the SIGTERM
    handler — either way the worker settles the job as ``cancelled`` at the next
    checkpoint boundary, never mid-write.
    """


def _utc_iso(now: str | None = None) -> str:
    return now or datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


# --------------------------------------------------------------------------- #
# SQLite store — the ``jobs`` table in the shared dt.db (DB-1)                  #
# --------------------------------------------------------------------------- #
def _connect(db_path: Path | None = None) -> sqlite3.Connection:
    """Open the shared DB (WAL + busy_timeout + migrated ``jobs`` table)."""
    return connect(db_path or jobs_db_path())


def init_db(db_path: Path | None = None) -> None:
    """Ensure the shared DB (incl. the ``jobs`` table) exists and is migrated."""
    _connect(db_path).close()


def stored_schema_version(db_path: Path | None = None) -> int | None:
    """The DB schema version, or ``None`` if the DB doesn't exist yet.

    Now the unified DB-1 schema version (shared across facts/sources/jobs), not a
    jobs-only ``meta.schema_version``. Same signature/return contract as before.
    """
    return schema_version(db_path or jobs_db_path())


def _args_hash(op: str, args: dict[str, Any]) -> str:
    """Stable hash of (op, args) — for future dedup / DB-1; not a dedup key yet."""
    canonical = json.dumps({"op": op, "args": args}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def create(
    op: str,
    args: dict[str, Any] | None = None,
    *,
    db_path: Path | None = None,
    now: str | None = None,
) -> str:
    """Insert a ``queued`` job and return its fresh ``job_id`` (uuid4).

    Atomic single-row insert; ``args`` is stored as canonical JSON plus a hash.
    """
    init_db(db_path)
    args = dict(args or {})
    job_id = uuid.uuid4().hex
    stamp = _utc_iso(now)
    conn = _connect(db_path)
    try:
        conn.execute(
            "INSERT INTO jobs (job_id, op, args_hash, args_json, state, current, "
            "total, cancel_requested, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, 0, NULL, 0, ?, ?)",
            (
                job_id,
                op,
                _args_hash(op, args),
                json.dumps(args, ensure_ascii=False),
                STATE_QUEUED,
                stamp,
                stamp,
            ),
        )
        conn.commit()
    finally:
        conn.close()
    return job_id


def _update(
    job_id: str,
    fields: dict[str, Any],
    *,
    db_path: Path | None = None,
    now: str | None = None,
) -> None:
    """Atomic UPDATE of the given columns (+ ``updated_at``). Idempotent by design."""
    fields = {**fields, "updated_at": _utc_iso(now)}
    assignments = ", ".join(f"{col} = ?" for col in fields)
    conn = _connect(db_path)
    try:
        conn.execute(
            f"UPDATE jobs SET {assignments} WHERE job_id = ?",  # noqa: S608 — SQL from our own quoted identifiers, not user input
            (*fields.values(), job_id),
        )
        conn.commit()
    finally:
        conn.close()


def mark_running(
    job_id: str,
    *,
    worker_pid: int | None = None,
    db_path: Path | None = None,
    now: str | None = None,
) -> None:
    """Flip a job to ``running`` and record the worker pid (for a cancel SIGTERM)."""
    _update(
        job_id,
        {"state": STATE_RUNNING, "worker_pid": worker_pid},
        db_path=db_path,
        now=now,
    )


def update_progress(
    job_id: str,
    *,
    phase: str | None = None,
    current: int | None = None,
    total: int | None = None,
    checkpoint_path: str | None = None,
    db_path: Path | None = None,
    now: str | None = None,
) -> None:
    """Persist a durable progress checkpoint (only the given fields change)."""
    fields: dict[str, Any] = {}
    if phase is not None:
        fields["phase"] = phase
    if current is not None:
        fields["current"] = int(current)
    if total is not None:
        fields["total"] = int(total)
    if checkpoint_path is not None:
        fields["checkpoint_path"] = checkpoint_path
    if not fields:
        return
    _update(job_id, fields, db_path=db_path, now=now)


def finish(
    job_id: str,
    *,
    result_ref: str,
    db_path: Path | None = None,
    now: str | None = None,
) -> None:
    """Settle a job as ``done`` with a durable ``result_ref`` (a file path)."""
    _update(
        job_id,
        {"state": STATE_DONE, "result_ref": result_ref, "error": None},
        db_path=db_path,
        now=now,
    )


def fail(
    job_id: str,
    *,
    error: str,
    db_path: Path | None = None,
    now: str | None = None,
) -> None:
    """Settle a job as ``failed`` carrying a human-readable ``error``."""
    _update(job_id, {"state": STATE_FAILED, "error": str(error)}, db_path=db_path, now=now)


def mark_cancelled(
    job_id: str,
    *,
    db_path: Path | None = None,
    now: str | None = None,
) -> None:
    """Settle a job as ``cancelled`` (graceful stop at a checkpoint / on SIGTERM)."""
    _update(job_id, {"state": STATE_CANCELLED}, db_path=db_path, now=now)


def request_cancel(
    job_id: str,
    *,
    db_path: Path | None = None,
    now: str | None = None,
) -> None:
    """Set the cooperative cancel flag (the worker checks it at each checkpoint)."""
    _update(job_id, {"cancel_requested": 1}, db_path=db_path, now=now)


def is_cancel_requested(job_id: str, *, db_path: Path | None = None) -> bool:
    """True if a cancel was requested for this job (cooperative check)."""
    row = get(job_id, db_path=db_path)
    return bool(row and row.get("cancel_requested"))


# CONTRACT-2 С7 — причина последнего сбоя чтения ``jobs`` («» — сбоя не было).
_LAST_READ_ERROR: dict[str, str] = {"reason": ""}


def last_read_error() -> str:
    """Причина последнего сбоя чтения таблицы заданий (``""`` — читалось нормально).

    «Задания нет» и «БД не прочиталась» одинаково выглядели как ``state: unknown`` —
    первое лечится проверкой id, второе разблокировкой/пересборкой БД.
    """
    return _LAST_READ_ERROR["reason"]


def get(job_id: str, *, db_path: Path | None = None) -> dict[str, Any] | None:
    """The raw ``jobs`` row as a dict, or ``None`` if unknown."""
    _LAST_READ_ERROR["reason"] = ""
    path = db_path or jobs_db_path()
    if not path.is_file():
        return None
    try:
        # CONTRACT-2 С7: открытие БД внутри try — заблокированная база падала
        # исключением через границу инструмента.
        conn = _connect(db_path)
    except sqlite3.Error as exc:
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return None
    try:
        row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        return dict(row) if row else None
    except sqlite3.OperationalError as exc:
        _LAST_READ_ERROR["reason"] = str(exc)[:200]
        return None
    finally:
        conn.close()


def list_jobs(
    *, state: str | None = None, limit: int = 50, db_path: Path | None = None
) -> list[dict[str, Any]]:
    """Recent jobs (newest first), optionally filtered by ``state``."""
    path = db_path or jobs_db_path()
    if not path.is_file():
        return []
    conn = _connect(db_path)
    try:
        if state:
            rows = conn.execute(
                "SELECT * FROM jobs WHERE state = ? ORDER BY created_at DESC, job_id LIMIT ?",
                (state, int(limit)),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM jobs ORDER BY created_at DESC, job_id LIMIT ?",
                (int(limit),),
            ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        return []
    finally:
        conn.close()


# --------------------------------------------------------------------------- #
# Progress bridge — durable jobs row + live beacon + cooperative cancel        #
# --------------------------------------------------------------------------- #
def _beacon_proc(op: str, job_id: str) -> str:
    """Beacon file name for a job — ``pult_activity`` lists it like any long op."""
    return f"job-{op}-{job_id[:8]}"


class JobProgress:
    """Progress sink handed to a job handler — durable **and** live, cancellable.

    Every :meth:`phase` / :meth:`update` writes the durable ``jobs`` row (so a
    restart-surviving ``status`` reflects real progress, not silence) *and* the
    :class:`ProgressBeacon` (so ``pult_activity`` sees the running job). Both are
    best-effort on the beacon side (a beacon write never sinks the job). Each
    checkpoint also runs the cooperative cancel check — a requested cancel raises
    :class:`JobCancelled`, unwinding the handler to a graceful stop.
    """

    def __init__(
        self,
        job_id: str,
        op: str,
        *,
        total: int | None = None,
        db_path: Path | None = None,
        beacon: Any | None = None,
    ) -> None:
        self.job_id = job_id
        self.op = op
        self.db_path = db_path
        self._current = 0
        if beacon is not None:
            self._beacon = beacon
        else:
            from core.progress import ProgressBeacon

            self._beacon = ProgressBeacon(_beacon_proc(op, job_id), total=total)

    def raise_if_cancelled(self) -> None:
        """Raise :class:`JobCancelled` if a cancel was requested for this job."""
        if is_cancel_requested(self.job_id, db_path=self.db_path):
            raise JobCancelled(self.job_id)

    def phase(self, name: str) -> None:
        """Enter a phase — durable + beacon, and a cancel checkpoint."""
        self.raise_if_cancelled()
        update_progress(self.job_id, phase=name, db_path=self.db_path)
        self._beacon.phase(name)

    def update(
        self,
        current: int,
        total: int | None = None,
        *,
        line: str | None = None,
    ) -> None:
        """Advance progress — durable + beacon (with optional stdout ``line``)."""
        self.raise_if_cancelled()
        self._current = int(current)
        update_progress(
            self.job_id, current=current, total=total, db_path=self.db_path
        )
        self._beacon.update(current, line=line)

    def log(self, line: str) -> None:
        """Forward one progress line (handler ``on_progress``/``log`` callback).

        Bumps a monotonic checkpoint counter (durable) and mirrors the line to the
        beacon; also a cancel checkpoint, so a resumable op (reindex) stops between
        checkpoints on cancel and resumes from disk next run.
        """
        self.raise_if_cancelled()
        self._current += 1
        update_progress(self.job_id, current=self._current, db_path=self.db_path)
        self._beacon.update(self._current, line=line)

    def done(self, summary: str = "") -> None:
        """Final beacon (``finished: true``) — the durable terminal state is set
        by :func:`run_job` via :func:`finish`/:func:`fail`/:func:`mark_cancelled`."""
        self._beacon.done(summary)


# --------------------------------------------------------------------------- #
# Op registry (white list) — Path B: each handler runs a read/reindex/lift,    #
# never a model. Handlers live in core; the worker only dispatches.            #
# --------------------------------------------------------------------------- #
Handler = Callable[[dict[str, Any], JobProgress], dict[str, Any]]


def _op_reindex(args: dict[str, Any], progress: JobProgress) -> dict[str, Any]:
    """Rebuild the LanceDB index (SRC of the client-blocking `reindex`)."""
    from core.config import default_vault_path
    from core.retrieval.index import reindex as _reindex

    scope = str(args.get("scope") or "incremental")
    if scope not in ("incremental", "full"):
        raise JobError(f"unsupported reindex scope {scope!r}")
    progress.phase(f"reindex:{scope}")
    stats = _reindex(
        default_vault_path(), full=(scope == "full"), log=progress.log
    )
    return stats.report(scope)


@contextlib.contextmanager
def _mail_writer_hold(progress: JobProgress, step: str) -> Iterator[None]:
    """MAIL-LOCK-1: JOB-1 ops, пишущие манифест почты, берут тот же ``dt-sync.lock``, что CLI.

    Занят - ждет ``DT_MAIL_LOCK_WAIT_S`` (дефолт 600 с), в журнал задания идет «ждем»/«ждал лок
    N с»; не дождался - :class:`JobError` с кодом ``sync_busy`` и именем держателя.
    """
    from core.legacy.mail_lock import default_wait_s, mail_writer_lock
    from core.runlock import RunLockBusy

    try:
        with mail_writer_lock(step, wait_s=default_wait_s(), echo=progress.log):
            yield
    except RunLockBusy as exc:
        raise JobError(str(exc)) from exc


def _op_outlook_read(args: dict[str, Any], progress: JobProgress) -> dict[str, Any]:
    """Read the Outlook bridge async — meetings / ticktick / mail (R5 blockers)."""
    mode = str(args.get("mode") or "").strip().lower()
    if mode in ("meetings", "meeting", "calendar"):
        from core.operational.meetings import refresh

        # PERF-3: live-read → снапшот кэша (не только вернуть). On-demand «Обновить»
        # и плановый прогон идут этим путём; UI потом читает кэш мгновенно.
        progress.phase("outlook:meetings")
        return refresh(int(args.get("days") or 7))
    if mode in ("ticktick", "tasks"):
        from core.operational.ticktick_tasks import attention

        progress.phase("outlook:ticktick")
        return attention(days=int(args.get("days") or 14))
    if mode == "mail":
        from core.config import default_vault_path
        from core.legacy.mail import ingest_mail
        from core.operational.outlook_bridge import OutlookBridge

        progress.phase("outlook:mail")
        bridge = OutlookBridge(require_preflight=True)
        dry = bool(args.get("dry_run", False))
        with contextlib.ExitStack() as stack:
            if not dry:
                stack.enter_context(_mail_writer_hold(progress, "outlook_read:mail"))
            stats = ingest_mail(
                default_vault_path(),
                bridge,
                since=args.get("since") or None,
                scope=str(args.get("scope") or "incremental"),
                dry_run=dry,
                on_progress=progress.log,
                should_stop=lambda: is_cancel_requested(
                    progress.job_id, db_path=progress.db_path
                ),
            )
        return stats.to_dict() if hasattr(stats, "to_dict") else {"ok": True}
    raise JobError(
        f"unsupported outlook_read mode {mode!r}; use meetings | ticktick | mail"
    )


def _op_lift_source(args: dict[str, Any], progress: JobProgress) -> dict[str, Any]:
    """Lift a (possibly large) source file async — SRC-1 (big-file blocker)."""
    from core.sources import Budget, lift_from, slice_result

    progress.phase("lift")
    max_cells = args.get("max_cells")
    budget = (
        Budget(max_cells=int(max_cells)) if max_cells and int(max_cells) > 0 else Budget()
    )
    result = lift_from(
        note_id=args.get("note_id") or None,
        path=args.get("path") or None,
        budget=budget,
    )
    if args.get("sheet") or args.get("cell_range"):
        result = slice_result(
            result, sheet=args.get("sheet"), cell_range=args.get("cell_range")
        )
    progress.update(1, 1)
    out = result.to_dict()
    if args.get("max_chars") is not None:  # ARGS-STRICT-1: потолок текста - только по запросу
        from core.sources.cap import cap_lift_text, resolve_max_chars

        out = cap_lift_text(out, resolve_max_chars(args["max_chars"]) or 0)
    return out


# --------------------------------------------------------------------------- #
# Ingest ops (PULT-STORAGE) — the file/legacy/mail/capture ingest through JOB-1 #
# so the pult runs it async with progress/cancel for free. `mode` is the pult   #
# contract: light = dry-run (preview, writes nothing), full = apply. Each op is  #
# a thin reuse of the existing ingest logic (same code the CLIs call) — no new   #
# ingest mechanism; PULT-EVENTLOG events come from the reused врезки.            #
# --------------------------------------------------------------------------- #
_INGEST_MODE_DRY = {"light": True, "full": False}


def _ingest_dry_run(args: dict[str, Any]) -> bool:
    """Map the pult ``mode`` (light|full) to ``dry_run`` (True|False)."""
    mode = str(args.get("mode") or "light").strip().lower()
    if mode not in _INGEST_MODE_DRY:
        raise JobError(f"unsupported ingest mode {mode!r}; use light | full")
    return _INGEST_MODE_DRY[mode]


# INGRESS-1 п.1: пять обработчиков ``_op_ingest_*`` (у каждого был СВОЙ формат результата →
# панель заданий показывала разные поля) свернуты в обобщенный ``_ingest_handler(adapter)``:
# прогон — ``run`` адаптера из реестра ``core.ingress.registry``, результат — ОДНА форма для всех
# (``IngressStats.to_dict()`` + ``op_route``/``mode``). Имена ops (``ingest_*``) прежние.
_INGEST_ARG_KEYS = ("root", "scope", "since")
_INGEST_SCOPES = ("incremental", "full")


_INGEST_HANDLERS: dict[str, Handler] = {}


def _ingest_handler(adapter_key: str) -> Handler:
    """Обработчик JOB-1 для адаптера входа ``adapter_key`` (``mode`` = light|full → dry_run).

    Один объект на адаптер (``SUBMITTABLE_OPS[op]`` и прежнее имя ``_op_ingest_*`` — один и тот же).
    """
    if adapter_key in _INGEST_HANDLERS:
        return _INGEST_HANDLERS[adapter_key]

    def handler(args: dict[str, Any], progress: JobProgress) -> dict[str, Any]:
        from core.ingress import registry

        adapter = registry.get(adapter_key)
        if adapter.run is None:
            raise JobError(f"adapter {adapter_key!r} has no run() — op is not submittable")
        dry = _ingest_dry_run(args)
        kwargs: dict[str, Any] = {k: args[k] for k in _INGEST_ARG_KEYS if args.get(k)}
        scope = kwargs.get("scope")
        if scope is not None and str(scope) not in _INGEST_SCOPES:
            raise JobError(f"unsupported {adapter_key} scope {scope!r}; use incremental | full")
        route = (adapter.ingest_key or adapter.key).replace(":", "_")
        progress.phase(f"ingest:{route}:{'light' if dry else 'full'}")
        with contextlib.ExitStack() as stack:
            if adapter_key == "mail" and not dry:
                stack.enter_context(_mail_writer_hold(progress, "ingest_mail"))
            stats = adapter.run(
                dry_run=dry,
                on_progress=progress.log,
                should_stop=lambda: is_cancel_requested(
                    progress.job_id, db_path=progress.db_path
                ),
                **kwargs,
            )
        out = stats.to_dict()
        out.update({"op_route": route, "mode": "light" if dry else "full"})
        return out

    handler.__name__ = f"_op_ingest_{adapter_key.replace(':', '_')}"
    _INGEST_HANDLERS[adapter_key] = handler
    return handler


# Прежние имена обработчиков — тонкие ссылки на обобщенный (тесты/внешние вызовы их знают).
_op_ingest_operational = _ingest_handler("files:operational")
_op_ingest_knowledge = _ingest_handler("files:knowledge")
_op_ingest_legacy = _ingest_handler("legacy")
_op_ingest_mail = _ingest_handler("mail")
_op_ingest_capture = _ingest_handler("capture")


def _op_backfill_hashes(args: dict[str, Any], progress: JobProgress) -> dict[str, Any]:
    """Stamp byte-hashes onto legacy-manifest entries (INGEST-DEDUP) — long, JOB-1."""
    from core.legacy.ingest import backfill_hashes

    dry = _ingest_dry_run(args) if args.get("mode") else False
    progress.phase("backfill_hashes")
    counts = backfill_hashes(dry_run=dry, log=progress.log)
    return {"op_route": "backfill_hashes", "mode": "light" if dry else "full", **counts}


def _op_ocr(args: dict[str, Any], progress: JobProgress) -> dict[str, Any]:
    """OCR-1 п.5: сканы. ``mode`` light = очередь и оценка (OCR не запускается), full = прогон с
    бюджетом (``budget`` секунд, дефолт ``DT_OCR_BUDGET_S``; ``limit`` документов; ``path_scope``).
    Отмена JOB останавливает прогон между страницами - недоделанный документ не сохраняется."""
    from core.ocr.run import run_ocr

    dry = _ingest_dry_run(args)
    limit = args.get("limit")
    budget = args.get("budget")
    try:
        limit_n = int(str(limit)) if limit not in (None, "") else None
        budget_f = float(str(budget)) if budget not in (None, "") else None
    except (TypeError, ValueError) as exc:
        raise JobError(f"ocr: limit/budget должны быть числами ({exc})") from exc
    progress.phase(f"ocr:{'light' if dry else 'full'}")
    with contextlib.ExitStack() as stack:
        if not dry:
            from core import runlock
            from core.config import sync_lock_path

            try:
                stack.enter_context(runlock.hold(
                    runlock.index_sync_lock(sync_lock_path()), mode="job", step="ocr"))
            except runlock.RunLockBusy as exc:
                raise JobError(str(exc)) from exc
        stats = run_ocr(
            dry_run=dry, limit=limit_n, budget=budget_f, on_progress=progress.log,
            should_stop=lambda: is_cancel_requested(progress.job_id, db_path=progress.db_path),
            path_scope=str(args["path_scope"]) if args.get("path_scope") else None,
        )
    out = stats.to_dict()
    out.update({"op_route": "ocr", "mode": "light" if dry else "full"})
    return out


# The white list — only these ops may be submitted (extend here + README). INGRESS-1: ops входа
# (``ingest_*``) берутся из реестра адаптеров и обновляются на лету при его изменении; остальные —
# статические.
_STATIC_OPS: dict[str, Handler] = {
    "reindex": _op_reindex,
    "outlook_read": _op_outlook_read,
    "lift_source": _op_lift_source,
    "backfill_hashes": _op_backfill_hashes,
    "ocr": _op_ocr,
}
SUBMITTABLE_OPS: dict[str, Handler] = {}


def _rebuild_submittable_ops() -> None:
    from core.ingress import registry

    SUBMITTABLE_OPS.clear()
    SUBMITTABLE_OPS.update(_STATIC_OPS)
    for adapter in registry.adapters(enabled_only=False):
        if adapter.op and adapter.run is not None:
            SUBMITTABLE_OPS[adapter.op] = _ingest_handler(adapter.key)


def _subscribe_registry() -> None:
    from core.ingress import registry

    registry.subscribe(_rebuild_submittable_ops)
    _rebuild_submittable_ops()


_subscribe_registry()


# --------------------------------------------------------------------------- #
# Runner — submit (detached spawn) / run_job (worker entry) / status / cancel  #
# --------------------------------------------------------------------------- #
def _worker_cmd(job_id: str) -> list[str]:
    """The detached-worker command (spawned by PATH — not an import, so the
    ``core`` ⊥ cli invariant holds, exactly like ``pult.start_sync``).

    Extras cover every submittable op: ``operational`` (Outlook/TickTick reads),
    ``parsers`` (``lift_source`` extractors); ``reindex`` needs only base deps.
    """
    return [
        "uv", "run", "--extra", "operational", "--extra", "parsers",
        "python", "cli/dt_job_worker.py", "--job", job_id,
    ]


def submit(
    op: str,
    args: dict[str, Any] | None = None,
    *,
    ops: dict[str, Handler] | None = None,
    db_path: Path | None = None,
    engine_root: Path | None = None,
    popen: Any | None = None,
    now: str | None = None,
) -> str:
    """Validate ``op`` against the white list, record it ``queued``, spawn a
    detached worker, and return the ``job_id`` **immediately** (non-blocking).

    Invalid op → :class:`JobError` (nothing is recorded). The worker is detached
    (``start_new_session``; stdio → devnull) so it never holds the MCP process —
    the result outlives the server. ``popen`` is injected by tests (as in
    ``start_sync``) so no real subprocess spawns.
    """
    registry = ops if ops is not None else SUBMITTABLE_OPS
    if op not in registry:
        raise JobError(
            f"unsupported op {op!r}; submittable ops: {', '.join(sorted(registry))}"
        )
    if ops is None:  # PERSONAL-3: белый список - по роли экземпляра (манифест поверхности)
        from core.instance import instance_role
        from core.surface import manifest

        role = instance_role()
        if role not in manifest.op_roles(op):
            raise OpNotAvailable(op, role, sorted(
                o for o in registry if role in manifest.op_roles(o)))
        off = manifest.blocked("job_op", op)  # DEV-3-CORE: op выключенного коннектора
        if off:
            from core.connectors import ConnectorDisabled

            raise ConnectorDisabled(op, off)
    job_id = create(op, args or {}, db_path=db_path, now=now)

    root = Path(engine_root) if engine_root is not None else ENGINE_ROOT
    opener = popen or subprocess.Popen
    proc = opener(
        _worker_cmd(job_id),
        cwd=str(root),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    if hasattr(proc, "pid") and proc.pid is not None:
        _update(job_id, {"worker_pid": int(proc.pid)}, db_path=db_path, now=now)
    return job_id


def run_job(
    job_id: str,
    *,
    ops: dict[str, Handler] | None = None,
    db_path: Path | None = None,
    results_dir: Path | None = None,
    beacon: Any | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Execute a queued job to a terminal state — the detached-worker entry point.

    Marks ``running`` (recording the worker pid), installs a SIGTERM→graceful-
    cancel handler, dispatches to the op handler with a :class:`JobProgress`, and
    settles the job: ``done`` (result written to ``.derived/jobs/<id>.json``,
    ``result_ref`` set), ``cancelled`` (cooperative flag or SIGTERM), or ``failed``
    (any other exception, ``error`` recorded). Returns the terminal row.
    """
    registry = ops if ops is not None else SUBMITTABLE_OPS
    row = get(job_id, db_path=db_path)
    if row is None:
        raise JobError(f"unknown job {job_id}")
    # Already settled (e.g. cancel() ran on the still-queued job) → never run.
    if row.get("state") in _TERMINAL:
        return row

    op = str(row["op"])
    handler = registry.get(op)
    if handler is None:
        fail(job_id, error=f"unsupported op {op!r}", db_path=db_path, now=now)
        return get(job_id, db_path=db_path) or {}

    # A cancel arriving before the worker started → settle cancelled, never run.
    if row.get("cancel_requested"):
        mark_cancelled(job_id, db_path=db_path, now=now)
        return get(job_id, db_path=db_path) or {}

    args = json.loads(row.get("args_json") or "{}")
    mark_running(job_id, worker_pid=os.getpid(), db_path=db_path, now=now)

    # SIGTERM (from cancel's best-effort kill, or shutdown) → graceful cancel.
    previous = signal.getsignal(signal.SIGTERM)

    def _on_sigterm(_signum: int, _frame: Any) -> None:
        raise JobCancelled(job_id)

    installed = False
    try:
        signal.signal(signal.SIGTERM, _on_sigterm)
        installed = True
    except ValueError:
        # Not on the main thread (e.g. under a test harness) — the cooperative
        # flag still stops the job at the next checkpoint; skip the OS handler.
        pass

    progress = JobProgress(job_id, op, db_path=db_path, beacon=beacon)
    try:
        result = handler(args, progress)
        ref = _write_result(job_id, result, results_dir=results_dir)
        finish(job_id, result_ref=ref, db_path=db_path, now=now)
        progress.done("done")
    except JobCancelled:
        mark_cancelled(job_id, db_path=db_path, now=now)
        progress.done("cancelled")
    except Exception as exc:  # noqa: BLE001 — any op failure → durable `failed`
        fail(job_id, error=f"{type(exc).__name__}: {exc}", db_path=db_path, now=now)
        progress.done("failed")
    finally:
        if installed:
            signal.signal(signal.SIGTERM, previous)
    return get(job_id, db_path=db_path) or {}


def _write_result(
    job_id: str, result: dict[str, Any], *, results_dir: Path | None = None
) -> str:
    """Write a job's result JSON to ``.derived/jobs/<id>.json`` (durable) → path.

    Atomic (tmp + ``os.replace``) so a poll never reads a half-written file.
    """
    directory = results_dir or jobs_dir()
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / f"{job_id}.json"
    tmp = target.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, target)
    return str(target)


def _read_result(result_ref: str | None) -> Any | None:
    """Read a finished job's durable result payload (``None`` on any failure)."""
    if not result_ref:
        return None
    try:
        return json.loads(Path(result_ref).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def status(job_id: str, *, db_path: Path | None = None) -> dict[str, Any]:
    """Durable state + progress (+ result / error) for a job — restart-proof.

    Reads only the durable ``jobs`` row (progress is written there as the job
    runs, so this reflects real headway, not silence) and, for a ``done`` job, the
    ``result_ref`` payload from disk. Unknown id → ``{state: "unknown"}``.
    """
    row = get(job_id, db_path=db_path)
    if row is None:
        unknown: dict[str, Any] = {"job_id": job_id, "state": "unknown"}
        broken = last_read_error()
        if broken:
            # CONTRACT-2 С7: «нет такого задания» и «таблица не прочиталась» —
            # разные вещи, а ``state: unknown`` был один на оба случая.
            from core.contract import CODE_STORE_UNAVAILABLE, add_warning

            add_warning(
                unknown, CODE_STORE_UNAVAILABLE,
                f"таблица заданий не прочитана ({broken}) — состояние НЕизвестно, "
                "а не «задания нет»",
            )
        return unknown
    out: dict[str, Any] = {
        "job_id": job_id,
        "op": row.get("op"),
        "state": row.get("state"),
        "phase": row.get("phase"),
        "current": row.get("current"),
        "total": row.get("total"),
        "cancel_requested": bool(row.get("cancel_requested")),
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"),
    }
    if row.get("state") == STATE_DONE:
        out["result"] = _read_result(row.get("result_ref"))
        out["result_ref"] = row.get("result_ref")
    elif row.get("state") == STATE_FAILED:
        out["error"] = row.get("error")
    return out


def cancel(
    job_id: str,
    *,
    db_path: Path | None = None,
    kill: Callable[[int, int], None] | None = None,
    now: str | None = None,
) -> dict[str, Any]:
    """Request a graceful cancel — cooperative flag + best-effort worker SIGTERM.

    A ``queued`` job (no worker yet) is settled ``cancelled`` at once; a
    ``running`` job gets the cooperative flag set (the worker stops at its next
    checkpoint as ``cancelled``) plus a best-effort ``SIGTERM`` to the worker pid
    so a job blocked in a long osascript/reindex is nudged between checkpoints
    (hard-killing the osascript child is out of scope — worker timeout covers it).
    A terminal job is a no-op. ``kill`` is injected by tests. Returns the status.
    """
    row = get(job_id, db_path=db_path)
    if row is None:
        unknown: dict[str, Any] = {"job_id": job_id, "state": "unknown"}
        broken = last_read_error()
        if broken:
            # CONTRACT-2 С7: «нет такого задания» и «таблица не прочиталась» —
            # разные вещи, а ``state: unknown`` был один на оба случая.
            from core.contract import CODE_STORE_UNAVAILABLE, add_warning

            add_warning(
                unknown, CODE_STORE_UNAVAILABLE,
                f"таблица заданий не прочитана ({broken}) — состояние НЕизвестно, "
                "а не «задания нет»",
            )
        return unknown
    state = row.get("state")
    if state in _TERMINAL:
        return status(job_id, db_path=db_path)

    request_cancel(job_id, db_path=db_path, now=now)
    if state == STATE_QUEUED:
        # No worker has started; settle immediately (mark_running checks the flag).
        mark_cancelled(job_id, db_path=db_path, now=now)
    elif state == STATE_RUNNING:
        pid = row.get("worker_pid")
        if pid:
            killer = kill or os.kill
            try:
                killer(int(pid), signal.SIGTERM)
            except (OSError, ProcessLookupError, ValueError, PermissionError):
                pass  # best-effort — the cooperative flag still stops it
    return status(job_id, db_path=db_path)
