"""Task planner — materialise a case's plan of critical resources (PLAN-1).

On Acme the decomposition of "КП под подпись" — {lift the sums, find a form
exemplar, find the counterparty requisites, assemble} — lived only in the user's
head, so "найди образец" could be silently skipped: there was no checklist to
flag the node unclosed. Path B (the engine never calls an LLM) is right for style
and safety, but it meant the *plan* had no existence as an object with state.

This module gives it one, **deterministically** (templates, no LLM): for a use
case, :func:`plan` lays the task out as an ordered list of resource
:class:`Node`\\s with a criticality; :func:`resolve_status` **probes** what is
already there — reusing only the existing read-only resolvers
(:func:`core.facts.get_facts`, :func:`core.exemplars.find_exemplar`,
:func:`core.retrieval.policies.run_policy`) — and marks each ``present`` /
``missing`` / ``unknown``. The critical unclosed nodes then become the grounding
gate's requirements (GATE-1), so "найди образец" is a plan node, not a forgotten
line. The vocabulary of node ``kind``\\s is shared verbatim with the gate
(:data:`~core.orchestration.gate.HOW_HINTS`) — one dictionary, no synonyms.

Invariants: ``core/orchestration`` imports neither MCP nor CLI; Path B — the
planner is deterministic and offline (probes do no writes and add no network
beyond what the reused resolvers already do); a resolver that comes back
``unavailable`` (bridge/parser) maps to ``unknown``, never a crash.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.config import retrieval_policies_path
from core.exemplars import find_exemplar
from core.facts import get_facts
from core.orchestration.gate import (
    CHECKABLE_KINDS,
    CONTEXT_KIND,
    DEFAULT_MIN_CONFIDENCE,
    EXEMPLAR_KIND,
    how_hint,
    what_label,
)
from core.retrieval.policies import load_policy, run_policy

__all__ = [
    "Node",
    "Plan",
    "PLAN_TEMPLATES",
    "ASSEMBLE_KIND",
    "STATUS_PRESENT",
    "STATUS_MISSING",
    "STATUS_UNKNOWN",
    "STATUS_PENDING",
    "STATUS_PARTIAL",
    "plan",
    "resolve_status",
]

# The terminal "assemble the document" node — an action, not a probeable resource.
ASSEMBLE_KIND = "assemble"

# Node statuses. `pending` — not probed yet / terminal assemble node; the other
# three come from a probe (mirrors the gate: `unknown` never blocks).
STATUS_PRESENT = "present"
STATUS_MISSING = "missing"
STATUS_UNKNOWN = "unknown"
STATUS_PENDING = "pending"
# HUB-ALIAS-1 п.4: проба сказала «есть», а собранный ответ противоречит (фактов того же вида нет,
# а гейт требует их как недостающие) - узел не может остаться ``present``.
STATUS_PARTIAL = "partial"

# Fact-store kinds a node can probe via get_facts (the gate's checkable set).
_FACT_NODE_KINDS = CHECKABLE_KINDS

# How-to for the terminal assemble node (not a resource → not in HOW_HINTS).
_ASSEMBLE_HINT = (
    "собрать документ: generate(use_case_id, task, params) после закрытия "
    "критичных узлов выше"
)

# Entity params that scope a fact probe / exemplar client (first non-empty wins).
_ENTITY_PARAMS = ("client_id", "project_id", "deal_id")


@dataclass
class Node:
    """One planned resource (or the terminal assemble step).

    ``kind`` is drawn from the shared gate vocabulary
    (``money``/``requisite``/``bin``/``date``/… | ``context`` | ``exemplar`` |
    ``assemble``); ``critical`` marks a node whose absence must block generation;
    ``acquire_hint`` is the deterministic how-to (reused from the gate). ``status``
    is filled by :func:`resolve_status` (``pending`` until then; the terminal
    ``assemble`` node stays ``pending`` — it is never probed).
    """

    name: str
    kind: str
    critical: bool
    acquire_hint: str
    status: str = STATUS_PENDING

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "kind": self.kind,
            "critical": self.critical,
            "status": self.status,
            "how": self.acquire_hint,
        }


@dataclass
class Plan:
    """A case's ordered plan plus the gate wiring it implies (PLAN-1)."""

    use_case_id: str
    nodes: list[Node] = field(default_factory=list)

    @property
    def checklist(self) -> list[dict[str, Any]]:
        """Serialised nodes — ``[{name, kind, critical, status, how}]``."""
        return [n.to_dict() for n in self.nodes]

    def blocking(self) -> list[dict[str, str]]:
        """Critical nodes probed ``missing`` — in the gate's ``{what,kind,how}`` form.

        Only ``missing`` blocks (``unknown`` is pass-through, mirroring the gate);
        a node not yet probed (``pending``) is not reported as blocking.
        """
        out: list[dict[str, str]] = []
        for n in self.nodes:
            if n.critical and n.status == STATUS_MISSING:
                out.append(
                    {"what": what_label(n.kind), "kind": n.kind, "how": n.acquire_hint}
                )
        return out

    def gate_requirements(self) -> tuple[list[str], bool]:
        """Derive ``(required_facts, required_context)`` from the critical nodes.

        A critical fact-kind or ``exemplar`` node → a ``required_facts`` entry (the
        gate verifies ``exemplar`` via ``exemplar_present``); a critical ``context``
        node → ``required_context=True``. ``assemble`` and non-critical nodes are
        ignored. This is how a case's critical plan nodes auto-become grounding
        requirements without hand-authoring each policy.
        """
        req_facts: list[str] = []
        req_context = False
        for n in self.nodes:
            if not n.critical:
                continue
            if n.kind in _FACT_NODE_KINDS or n.kind == EXEMPLAR_KIND:
                req_facts.append(n.kind)
            elif n.kind == CONTEXT_KIND:
                req_context = True
        return list(dict.fromkeys(req_facts)), req_context

    def to_dict(self) -> dict[str, Any]:
        return {"use_case_id": self.use_case_id, "nodes": self.checklist}


# Deterministic per-case templates: ordered (name, kind, critical). The gate's
# `kind` vocabulary is reused verbatim (see the unified-vocabulary test). Unlisted
# cases fall back to `_DEFAULT_TEMPLATE` (minimal context → assemble).
PLAN_TEMPLATES: dict[str, tuple[tuple[str, str, bool], ...]] = {
    "commercial_offer": (
        ("Поднять суммы", "money", True),
        ("Найти образец оформления", EXEMPLAR_KIND, True),
        ("Реквизиты контрагента", "requisite", True),
        ("Контекст", CONTEXT_KIND, False),
        ("Собрать документ", ASSEMBLE_KIND, False),
    ),
    "client_correspondence": (
        ("Контекст", CONTEXT_KIND, True),
        ("Найти образец оформления", EXEMPLAR_KIND, False),
        ("Собрать документ", ASSEMBLE_KIND, False),
    ),
    "management_decision": (
        ("Контекст", CONTEXT_KIND, True),
        ("Поднять суммы", "money", False),
        ("Найти образец оформления", EXEMPLAR_KIND, False),
        ("Собрать документ", ASSEMBLE_KIND, False),
    ),
}

_DEFAULT_TEMPLATE: tuple[tuple[str, str, bool], ...] = (
    ("Контекст", CONTEXT_KIND, False),
    ("Собрать документ", ASSEMBLE_KIND, False),
)


def _hint(kind: str) -> str:
    return _ASSEMBLE_HINT if kind == ASSEMBLE_KIND else how_hint(kind)


def plan(use_case_id: str, params: dict[str, Any] | None = None) -> Plan:
    """Build the deterministic plan for a use case (PLAN-1 PART-1).

    Looks up the case's template (or the minimal ``context → assemble`` default),
    stamping each node's ``acquire_hint`` from the shared gate dictionary. No probe
    here — statuses stay ``pending`` until :func:`resolve_status`. ``params`` is
    accepted for symmetry/future per-param templating; it is not consulted yet.
    """
    specs = PLAN_TEMPLATES.get(use_case_id, _DEFAULT_TEMPLATE)
    nodes = [
        Node(name=name, kind=kind, critical=critical, acquire_hint=_hint(kind))
        for (name, kind, critical) in specs
    ]
    return Plan(use_case_id=use_case_id, nodes=nodes)


def _entity(params: dict[str, Any]) -> str | None:
    for key in _ENTITY_PARAMS:
        val = params.get(key)
        if val:
            return str(val)
    return None


def resolve_status(
    plan_obj: Plan,
    params: dict[str, Any] | None = None,
    *,
    vault_path: Path | None = None,
    query: str | None = None,
) -> Plan:
    """Probe each resource node's status read-only (PLAN-1 PART-2).

    For every non-``assemble`` node, mark ``present`` / ``missing`` / ``unknown``
    by reusing the existing resolvers — ``get_facts`` (fact kinds),
    ``find_exemplar`` (exemplar), ``run_policy`` (context) — with **no writes** and
    no LLM. Any resolver failure (a bridge/parser ``unavailable``, a missing index,
    a bad policy) is caught and mapped to ``unknown``, never a crash. Mutates and
    returns the same :class:`Plan`.
    """
    params = params or {}
    entity = _entity(params)
    for node in plan_obj.nodes:
        if node.kind == ASSEMBLE_KIND:
            continue
        node.status = _probe(
            node.kind, params, entity, plan_obj.use_case_id, vault_path, query
        )
    return plan_obj


def _probe(
    kind: str,
    params: dict[str, Any],
    entity: str | None,
    use_case_id: str,
    vault_path: Path | None,
    query: str | None,
) -> str:
    """Read-only status probe for one node kind; any failure → ``unknown``."""
    try:
        if kind in _FACT_NODE_KINDS:
            return _probe_fact(kind, entity)
        if kind == EXEMPLAR_KIND:
            return _probe_exemplar(params, use_case_id, vault_path)
        if kind == CONTEXT_KIND:
            return _probe_context(use_case_id, params, vault_path, query)
    except Exception:  # noqa: BLE001 — best-effort; must not break the caller
        return STATUS_UNKNOWN
    return STATUS_UNKNOWN


def _probe_fact(kind: str, entity: str | None) -> str:
    """`present` when ≥1 stored fact of ``kind`` clears the gate's threshold."""
    facts = get_facts(
        entity_ref=entity, kind=kind, min_confidence=DEFAULT_MIN_CONFIDENCE
    )
    return STATUS_PRESENT if facts else STATUS_MISSING


def _probe_exemplar(
    params: dict[str, Any], use_case_id: str, vault_path: Path | None
) -> str:
    """`present` when a form-exemplar of the case genre exists (TMPL-1)."""
    genre = _use_case_genre(use_case_id, vault_path)
    if not genre:
        return STATUS_UNKNOWN
    ex = find_exemplar(genre, client=params.get("client_id"), vault_path=vault_path)
    return STATUS_PRESENT if ex is not None else STATUS_MISSING


def _probe_context(
    use_case_id: str,
    params: dict[str, Any],
    vault_path: Path | None,
    query: str | None,
) -> str:
    """`present` when the case's retrieval policy returns any context."""
    result = run_policy(
        use_case_id,
        query or use_case_id,
        params,
        policies_dir=retrieval_policies_path(vault_path) if vault_path else None,
    )
    return STATUS_PRESENT if result.context else STATUS_MISSING


def _use_case_genre(use_case_id: str, vault_path: Path | None) -> str | None:
    """Genre for the exemplar probe: the policy's explicit ``exemplar_genre``, else
    its style-slice genre, else the ``style_guide`` id.

    Kept in step with generation's form-exemplar selection
    (:func:`core.generation._exemplar_form`), which prefers ``exemplar_genre`` when
    the form genre differs from the tone/style genre (e.g. commercial_offer draws КП
    form from ``genre: commercial_offer`` while its style samples stay letter-toned).
    A missing/unreadable policy yields ``None`` (probe → ``unknown``).
    """
    try:
        pol = load_policy(
            use_case_id,
            policies_dir=retrieval_policies_path(vault_path) if vault_path else None,
        )
    except (FileNotFoundError, OSError, ValueError):
        return None
    exemplar_genre = pol.get("exemplar_genre")
    if exemplar_genre:
        return str(exemplar_genre)
    for spec in pol.get("slices", []):
        flt = spec.get("filter", {})
        if flt.get("type") == "style-sample" and flt.get("genre"):
            return str(flt["genre"])
    guide = pol.get("style_guide")
    return str(guide) if guide else None
