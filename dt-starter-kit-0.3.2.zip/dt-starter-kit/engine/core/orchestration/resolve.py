"""Composite task runner — resolve a task end-to-end in one call (ORCH-RESOLVE).

The Acme re-run burned ~15 chat round-trips (``parse_task`` → ``plan_task`` →
``lift_source`` → ``job_status``×N → ``get_facts`` → ``find_exemplar`` →
``generate``), each a separate MCP call, hitting Claude Desktop's per-turn tool
cap. The client cap cannot be raised, so the lever is to **collapse the chain on
the backend** into one call.

:func:`resolve_task` is that one call — a **single orchestration path** reused by
both the MCP ``resolve`` surface and ``generate`` (no second orchestrator). It
composes only the *existing* primitives:

    (parse_task) → plan + probe → **close missing fact sources** (lift+extract,
    limited scope, big→JOB-1) → assemble_prompt → check_grounding → verdict

The expensive part it consolidates is the **source lift into facts.db** (SRC-1
``lift_from`` + FACT-1 ``extract``/``upsert``), which chat was doing step by step.
It returns a consolidated :class:`ResolveResult` **without a prompt** — prompt
assembly + provenance persistence stay in ``generate`` (Path B: the runner never
calls an LLM and never writes an artifact).

Invariants: ``core/orchestration`` imports neither MCP nor CLI; **Path B** — no
LLM, no artifact; the only writes are the derived caches SRC-1/FACT-1 already own
(facts.db / L2 lift cache / sources registry) — nothing to external systems or
hubs (принцип 10 untouched). The NDA-1 barrier is honored on every lift (reused
from ``lift_from``, which refuses NDA-marked paths itself).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.config import default_vault_path
from core.orchestration.gate import (
    CHECKABLE_KINDS,
    DEFAULT_MIN_CONFIDENCE,
    EXEMPLAR_KIND,
    fact_is_current,
    plan_inconsistencies,
    requires_current,
)
from core.orchestration.planner import STATUS_PARTIAL, STATUS_PRESENT, resolve_status
from core.orchestration.planner import plan as _plan

__all__ = ["ResolveBudget", "ResolveResult", "resolve_task"]

# Corpus flag → the layer scope `assemble_prompt`/retrieval expect (mirror of the
# server's `_CORPUS_SCOPE`; kept here so core doesn't import the MCP layer).
_CORPUS_SCOPE: dict[str, str | None] = {"both": None, "vault": "vault", "legacy": "legacy"}


@dataclass
class ResolveBudget:
    """Bounds the source-closure step (ORCH-RESOLVE PART-1 step 3).

    ``max_sync_bytes`` — a source larger than this is lifted **asynchronously**
    (JOB-1 ``submit``) instead of blocking the call; its ``job_id`` is returned so
    the chat polls once rather than the runner hanging on a big parse. ``cap`` —
    the maximum number of in-scope sources lifted per call (keeps the closure a
    *limited* scope, never a corpus-wide auto-lift).
    """

    max_sync_bytes: int = 4_000_000
    cap: int = 8


@dataclass
class ResolveResult:
    """Consolidated outcome of :func:`resolve_task` — everything but the prompt.

    ``status`` is the grounding verdict (``ok``/``blocked``); ``facts`` the used
    structured facts (FACT-1 ``Fact`` objects — the MCP layer whitelists them);
    ``exemplar`` the resolved form-exemplar (or ``None``); ``sources`` the deduped
    vault notes that fed assembly; ``missing`` the unmet requirements
    (``[{what,kind,how}]``); ``plan`` the serialized plan (with probed statuses);
    ``jobs`` any async lifts spun off for oversized sources; ``lifted_n`` how many
    sources the closure lifted (metric). ``assembled`` is the internal
    :class:`~core.generation.AssembledPrompt` (**not** serialized to the client) so
    ``generate`` can add prompt+persist on top without re-assembling.
    """

    status: str
    use_case_id: str
    params: dict[str, Any]
    facts: list[Any] = field(default_factory=list)
    exemplar: Any | None = None
    sources: list[dict[str, Any]] = field(default_factory=list)
    missing: list[dict[str, str]] = field(default_factory=list)
    plan: dict[str, Any] = field(default_factory=dict)
    jobs: list[dict[str, str]] = field(default_factory=list)
    lifted_n: int = 0
    # Relevance-ranked hub material files (RESOLVE-SCOPE-RANK), surfaced when the
    # caller gave a hub param but no explicit ``source_refs`` — so the chat/pult can
    # show "relevant materials" and disambiguate. Does not affect gate/facts.
    hub_materials: list[dict[str, Any]] = field(default_factory=list)
    # CONTRACT-2: ссылки, которые НЕ разрешились. ``unresolved_refs`` — явные
    # ``source_refs``/``params``-источники (С4), ``exemplar_unresolved`` — явный
    # ``exemplar_ref`` (С2). Пусты на здоровом пути; непустые обязаны уехать в конверт
    # деградации вызывающего: «поднято 0» без причины выглядит как «ничего и не было».
    unresolved_refs: list[dict[str, str]] = field(default_factory=list)
    exemplar_unresolved: str = ""
    # HUB-ALIAS-1 п.4: кейс требует клиента, а ``client_id`` не распознан - причина вместо молчания
    # (``{slices: [...], mentioned?: слово текста, похожее на хаб}``); ``None`` - здоровый путь.
    client_unresolved: dict[str, Any] | None = None
    # Узлы плана, чей ``present`` противоречит собранному ответу (понижены до ``partial``).
    plan_inconsistent: list[dict[str, str]] = field(default_factory=list)
    assembled: Any | None = None


def _is_path_like(ref: str) -> bool:
    """A ref that names a file (path separators / an extension) vs a note id."""
    return "/" in ref or "\\" in ref or bool(Path(ref).suffix)


def _unsatisfied_checkable(required_facts: list[Any], facts: list[Any]) -> set[str]:
    """Checkable fact-kinds required but not yet satisfied in ``facts`` (gate rule).

    Mirrors :func:`core.orchestration.gate.check_grounding`'s satisfied test so the
    closure lifts sources for exactly the kinds the gate would otherwise block on.
    ``exemplar`` and unmodelled kinds are excluded (not closable by a source lift).
    """
    need: set[str] = set()
    for req in required_facts:
        kind = req if isinstance(req, str) else str((req or {}).get("kind", ""))
        kind = kind.strip()
        if kind not in CHECKABLE_KINDS:
            continue
        want_current = requires_current(req)
        satisfied = any(
            getattr(f, "kind", None) == kind
            and float(getattr(f, "confidence", 0.0) or 0.0) >= DEFAULT_MIN_CONFIDENCE
            and (not want_current or fact_is_current(f))
            for f in facts
        )
        if not satisfied:
            need.add(kind)
    return need


def _hub_param(params: dict[str, Any]) -> tuple[str, str] | tuple[None, None]:
    """The hub entity id + its entity field name (``client``/``project``/``deal``).

    Mirrors :func:`_entity`, but also returns which frontmatter field a material
    note would carry to name this hub, so discovery can match on it. Returns
    ``(None, None)`` when no hub parameter is present.
    """
    for key, field_name in (
        ("client_id", "client"),
        ("project_id", "project"),
        ("deal_id", "deal"),
    ):
        val = params.get(key)
        if val:
            return str(val), field_name
    return None, None


# corpus layer → discovery priority (freshness/current above archive; ТЗ PART-1).
_CORPUS_RANK: dict[str, int] = {"current": 0, "vault": 1, "legacy": 2}

# How many ranked hub materials to surface for disambiguation (ResolveResult).
_HUB_SURFACE_N = 10


@dataclass
class HubMaterial:
    """One ranked material file of a hub (RESOLVE-SCOPE-RANK surfacing)."""

    note_id: str
    source_path: str
    score: float  # task-relevance (FTS/BM25); 0.0 when no relevance signal
    corpus: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "note_id": self.note_id,
            "source_path": self.source_path,
            "score": self.score,
            "corpus": self.corpus,
        }


def _relevance_scores(task: str, cap: int) -> dict[str, float]:
    """Per-note lexical relevance to ``task`` (note_id → BM25 score); ``{}`` if none.

    Reuses the existing retrieval — FTS only (:func:`core.retrieval.search.lexical_search`),
    which **never loads BGE** (Path B, deterministic) — and is post-filtered by the
    caller to the hub's candidate materials. Empty/whitespace ``task`` or a missing
    index (no table yet) yields ``{}`` → the caller falls back to freshness. The
    query is over the whole corpus (top-k); a candidate that doesn't surface simply
    has no relevance signal and sorts by the freshness tie-break.
    """
    if not task or not task.strip():
        return {}
    try:
        from core.retrieval.search import lexical_search

        hits = lexical_search(task, k=max(cap * 10, 100))
    except Exception:  # noqa: BLE001 — no index / FTS failure never breaks the runner
        return {}
    scores: dict[str, float] = {}
    for h in hits:
        if h.note_id and h.note_id not in scores:
            scores[h.note_id] = float(h.score)
    return scores


def _hub_materials(
    task: str, params: dict[str, Any], vault_path: Path | None, cap: int
) -> list[HubMaterial]:
    """The hub's material files, ranked by relevance to ``task`` (RESOLVE-SCOPE-RANK).

    ``resolve({client_id})`` retrieves the curated hub, not the client's material
    files. This discovers those materials and ranks them so the closure lifts the
    ones the task is actually about (RESOLVE-SCOPE-HUB sorted only by freshness, so a
    relevant-but-older calc file fell outside ``cap``).

    Grounded discovery, no new store: a single frontmatter pass over the vault
    (:func:`core.vault.iter_vault`, which already excludes NDA notes) — the same
    mechanism ``find_notes`` uses, run only when a hub parameter is present. A note is
    a material when it has a non-empty ``source_path`` **and** either (a) it
    backlinks the hub (``[[hub-id]]`` in ``links``/body — reusing
    :func:`core.linking.candidates.existing_link_targets`) or (b) its entity field
    (``client``/``project``/``deal``) equals the hub's id, name, or alias. NDA source
    paths are skipped (:func:`core.privacy.is_nda`).

    Ranking (ТЗ PART-1): **task-relevance first** (:func:`_relevance_scores` — FTS
    over the candidates), then layer (current > vault > legacy) and recency as the
    tie-break. No relevance signal (empty task / no index / no hit for any candidate)
    → the whole ordering degrades to the RESOLVE-SCOPE-HUB freshness order. Returns
    the full ranked list (caller caps for the closure / slices for surfacing).
    """
    entity_id, field_name = _hub_param(params)
    if not entity_id or not field_name:
        return []

    from core.linking.candidates import existing_link_targets
    from core.privacy import is_nda
    from core.vault import iter_vault

    vault = Path(vault_path) if vault_path is not None else default_vault_path()

    # hub_match: the identifiers a material's entity field may use to name the hub — its id plus
    # EVERY name of the single hub catalog (HUB-ALIAS-1: aliases, H1 of the hub body, id slug -
    # labels like "Acme" / "Акме"). No private vault walk and no non-existent name/title fields.
    from core.retrieval.hubcat import hub_entry

    hub_match: set[str] = {entity_id.strip().lower()}
    hub_row = hub_entry(vault, entity_id)
    if hub_row is not None:
        hub_match.update(n.text.strip().lower() for n in hub_row.names if n.text.strip())
    # (note_id, source_path, corpus, rank, date, field_val, linked) collected before
    # hub labels are fully known; the label match is resolved after the pass.
    raw: list[tuple[str, str, str, int, str, str, bool]] = []

    for note in iter_vault(vault):
        fm = note.frontmatter
        if note.id == entity_id:  # the hub itself — don't lift it
            if hub_row is None:  # not a ``type: hub`` note (not in the catalog): its aliases
                for alias in fm.get("aliases") or []:
                    if alias:
                        hub_match.add(str(alias).strip().lower())
            continue

        sp = fm.get("source_path")
        if not (isinstance(sp, str) and sp.strip()) or is_nda(sp):
            continue

        linked = entity_id in existing_link_targets(note)
        field_val = str(fm.get(field_name) or "").strip().lower()
        if not linked and not field_val:
            continue  # no possible signal — skip before the (deferred) label match

        corpus = str(fm.get("corpus") or "vault").strip().lower()
        rank = _CORPUS_RANK.get(corpus, 1)
        date = str(fm.get("modified") or fm.get("created") or "")
        raw.append((note.id, sp.strip(), corpus, rank, date, field_val, linked))

    scores = _relevance_scores(task, cap)
    materials: list[tuple[float, int, str, HubMaterial]] = []
    for note_id, sp, corpus, rank, date, field_val, linked in raw:
        if not (linked or field_val in hub_match):
            continue
        score = scores.get(note_id, 0.0)
        materials.append((score, rank, date, HubMaterial(note_id, sp, score, corpus)))
    # Stable multi-key sort (last sort is primary). Recency desc as the weakest
    # tie-break, then layer (current>vault>legacy), then relevance as primary.
    materials.sort(key=lambda t: t[2], reverse=True)  # date desc (missing → last)
    materials.sort(key=lambda t: t[1])  # current > vault > legacy
    materials.sort(key=lambda t: t[0], reverse=True)  # relevance first (score desc)
    return [m for _s, _r, _d, m in materials]


def _gather_scope(
    params: dict[str, Any],
    source_refs: list[str] | None,
    context: list[Any],
    cap: int,
    *,
    hub_material_paths: list[str] | None = None,
) -> list[str]:
    """The limited set of sources to close (ORCH-RESOLVE PART-1 step 3).

    Explicit ``source_refs`` + a ``note_id``/``source_path`` in ``params`` + **the
    hub's material files** (RESOLVE-SCOPE-RANK, relevance-ranked, passed in by the
    caller) + the ``source_path`` of the top-N retrieved notes (already surfaced by
    the first assembly — no extra retrieval). Explicit refs and hub materials come
    before generic retrieval hits so a limited ``cap`` spends on the client's own
    files. Deduped, capped at ``cap`` (never a corpus-wide auto-lift).

    **Explicit-source-wins** (ТЗ PART-2): hub materials are mixed in *only* when
    ``source_refs`` is empty — an explicit source is respected exactly and never
    diluted. The caller already gates this (it computes materials only for an empty
    ``source_refs``); the guard here makes it defensive. Without a hub parameter /
    materials this is unchanged (back-compatible).
    """
    scope: list[str] = []
    seen: set[str] = set()

    def _add(ref: str | None) -> None:
        if ref and ref not in seen:
            seen.add(ref)
            scope.append(ref)

    for ref in source_refs or []:
        _add(str(ref))
    _add(params.get("note_id"))
    _add(params.get("source_path"))
    raw_list = params.get("source_paths")
    if isinstance(raw_list, list):
        for item in raw_list:
            _add(str(item) if item else None)
    # Hub materials (relevance-ranked): only when no explicit source was given.
    if not source_refs:
        for material_sp in hub_material_paths or []:
            _add(material_sp)
    for chunk in context:
        result = getattr(chunk, "result", None)
        sp = getattr(result, "source_path", None)
        if sp:
            _add(str(sp))
    return scope[: max(0, cap)]


def _close_sources(
    scope: list[str],
    *,
    entity: str | None,
    vault_path: Path | None,
    budget: ResolveBudget,
    submit_fn: Callable[[str, dict[str, Any]], str],
) -> tuple[int, list[dict[str, str]], list[dict[str, str]]]:
    """Lift the in-scope sources and upsert their facts (reuse SRC-1/FACT-1).

    Read-only to source files; the only writes are the L2 lift cache + facts.db
    (idempotent: L2 ``cache_hit`` on repeat, ``upsert`` by ``fact_id``). NDA sources
    are refused by ``lift_from`` (``nda`` result) and skipped — never extracted.
    A source larger than ``budget.max_sync_bytes`` is offloaded to JOB-1 (``submit``)
    and its ``job_id`` returned instead of blocking the call. Returns
    ``(lifted_n, jobs, unresolved)``.

    **CONTRACT-2 С4.** Недостижимая ссылка больше не пропадает в ``continue``: каждая
    уходит в ``unresolved`` с причиной (``not_found``/``nda``/``lift_failed``). Раньше
    ``resolve(source_refs=["опечатка.xlsx"])`` возвращал ``lifted_n: 0`` и обычный
    вердикт — вызов выглядел успешным, хотя явный источник не читался вовсе.
    """
    from core.facts import ensure_facts
    from core.facts import get_facts as _core_get_facts
    from core.sources import NdaRefused, SourceNotLocal, SourceUnavailable, lift_from, resolve_ref

    lifted_n = 0
    jobs: list[dict[str, str]] = []
    unresolved: list[dict[str, str]] = []
    for ref in scope:
        as_path = _is_path_like(ref)
        note_id = None if as_path else ref
        path_arg = ref if as_path else None

        # Size pre-check for the budget/async decision. resolve_ref refuses NDA
        # (NdaRefused) and missing files (SourceUnavailable) without reading them.
        try:
            resolved = resolve_ref(note_id=note_id, path=path_arg, vault_path=vault_path)
        except NdaRefused:
            # Trigger the audited refusal (nda_refused, path-hash only) + skip.
            lift_from(note_id=note_id, path=path_arg, vault_path=vault_path)
            unresolved.append({"ref": ref, "reason": "nda"})
            continue
        except SourceNotLocal as exc:  # SRC-ICLOUD-1: единый код во всех подъемах
            unresolved.append({"ref": ref, "reason": str(exc)[:200], "code": exc.code})
            continue
        except SourceUnavailable as exc:
            unresolved.append({"ref": ref, "reason": str(exc)[:200]})
            continue

        try:
            too_big = resolved.path.stat().st_size > budget.max_sync_bytes
        except OSError:
            too_big = False
        if too_big:
            job_args = {"note_id": note_id} if note_id else {"path": path_arg}
            jobs.append({"job_id": submit_fn("lift_source", job_args), "op": "lift_source"})
            continue

        lifted = lift_from(path=str(resolved.path), vault_path=vault_path)
        if lifted.status != "ok" or lifted.nda:
            entry = {"ref": ref, "reason": lifted.reason or f"lift {lifted.status}"}
            if lifted.status == "not_local":
                entry["code"] = "source_not_local"
            unresolved.append(entry)
            continue
        # Idempotent: only extract+upsert when facts.db has none for this content.
        # FACTS-BITEMPORAL-1: вытесненные версии тоже «есть» (иначе старый источник переписывался
        # бы при каждом разрешении), запись - через ensure_facts (оси времени, цепочка, хаб).
        if not _core_get_facts(source_content_hash=lifted.content_hash, include_superseded=True):
            ensure_facts(lifted, entity_ref=entity or note_id)
        lifted_n += 1
    return lifted_n, jobs, unresolved


def _default_submit(op: str, args: dict[str, Any]) -> str:
    """Default async offload — core JOB-1 ``submit`` (injectable for tests)."""
    from core.orchestration.jobs import submit

    return submit(op, args)


def _entity(params: dict[str, Any]) -> str | None:
    for key in ("client_id", "project_id", "deal_id"):
        val = params.get(key)
        if val:
            return str(val)
    return None


def _client_unresolved(
    task: str, params: dict[str, Any], assembled: Any, vault_path: Path | None
) -> dict[str, Any] | None:
    """Кейс требует клиента (его слайсы политики ждут ``{client_id}``), а ``client_id`` нет.

    Требование берется из ПОЛИТИКИ кейса, а не из списка здесь: слайс, пропущенный как
    ``missing_param`` с параметром ``client_id``, - и есть «кейс требует клиента». Слово-подсказка
    (``mentioned``) - слово текста, похожее по префиксу на имя клиентского хаба единого каталога;
    нет похожего - ключа нет. Ошибка каталога подсказку не отменяет: причина важнее слова.
    """
    if params.get("client_id"):
        return None
    result = getattr(assembled, "policy_result", None)
    dropped = [
        s for s in getattr(result, "skipped_slices", []) or []
        if s.get("reason") == "missing_param" and s.get("param") == "client_id"
    ]
    if not dropped:
        return None
    out: dict[str, Any] = {"slices": [str(s.get("name")) for s in dropped]}
    try:
        from core.retrieval.hubcat import hub_catalog, similar_hub_word

        vault = Path(vault_path) if vault_path is not None else default_vault_path()
        word = similar_hub_word(task, hub_catalog(vault, ("client",)))
        if word:
            out["mentioned"] = word
    except Exception:  # noqa: BLE001, S110 — подсказка best-effort: причина уже известна
        pass
    return out


def resolve_task(
    use_case_id: str | None,
    task: str,
    params: dict[str, Any] | None = None,
    *,
    source_refs: list[str] | None = None,
    corpus: str = "both",
    lift: bool = True,
    use_plan: bool = True,
    probe_plan: bool = True,
    require_facts: list[str] | None = None,
    require_context: bool = False,
    exemplar: bool = False,
    exemplar_ref: str | None = None,
    budget: ResolveBudget | None = None,
    vault_path: Path | None = None,
    assemble_fn: Callable[..., Any] | None = None,
    submit_fn: Callable[[str, dict[str, Any]], str] | None = None,
) -> ResolveResult:
    """Resolve a task: (parse→) plan→probe→close sources→assemble→gate (no LLM).

    One deterministic pass that closes the missing fact sources and returns a
    grounding verdict + provenance, **without a prompt** (that's ``generate``).

    * ``use_case_id=None`` → :func:`core.parse_task.parse_task` supplies it; explicit
      ``params`` override the parsed ones.
    * ``lift`` (default True) enables the source-closure step (step 3); the scope is
      ``source_refs`` + a ``note_id``/``source_path`` in ``params`` + the top-N
      retrieved notes' source files, capped by ``budget.cap``. Oversized sources go
      to JOB-1; their ``job_id`` is in the result.
    * ``use_plan`` (default True) folds the case's critical plan nodes into the gate
      requirements (and drives which fact-kinds the closure lifts). ``probe_plan``
      (default True) probes node statuses for the returned ``plan`` — ``generate``
      passes ``False`` (it does not need statuses, and skips the extra retrieval).
    * ``assemble_fn`` / ``submit_fn`` are injection points (default the core
      ``assemble_prompt`` / JOB-1 ``submit``) so ``generate`` can route assembly
      through its own patchable reference and tests can stub the async offload.

    Returns a :class:`ResolveResult`. The gate verdict never fabricates: a missing
    critical resource → ``status="blocked"`` with ``missing:[{what,kind,how}]``.
    """
    from core.orchestration.gate import check_grounding

    assemble_fn = assemble_fn or _default_assemble
    submit_fn = submit_fn or _default_submit
    budget = budget or ResolveBudget()

    # 1. Parse the use case when not given (explicit params win).
    params = dict(params or {})
    if use_case_id is None:
        from core.parse_task import parse_task as _parse_task

        parsed = _parse_task(task, vault_path=vault_path)
        use_case_id = parsed.use_case_id
        params = {**parsed.params, **params}

    # 2. Plan (template) + the requirements its critical nodes imply (if use_plan).
    the_plan = _plan(use_case_id, params)
    plan_req_facts: list[str] = []
    plan_req_context = False
    if use_plan:
        plan_req_facts, plan_req_context = the_plan.gate_requirements()

    # Resolve a form-exemplar when asked or the plan makes it critical, so the gate's
    # exemplar check can close (mirrors generate).
    if exemplar or EXEMPLAR_KIND in plan_req_facts:
        params = {**params, "exemplar": True}

    corpus_scope = _CORPUS_SCOPE.get(corpus)

    # 4a. First assembly (retrieval + in-memory facts/exemplar). No source_refs on
    # this call — keeps the callable signature generate's fakes expect; the closure
    # re-assembles WITH the scope below when it actually lifts something.
    assembled = assemble_fn(
        use_case_id, task, params, corpus=corpus_scope, exemplar_ref=exemplar_ref
    )

    required_facts = list(
        dict.fromkeys(
            list(getattr(assembled.policy_result, "required_facts", []))
            + list(require_facts or [])
            + plan_req_facts
        )
    )
    required_context = bool(
        getattr(assembled.policy_result, "required_context", False)
        or require_context
        or plan_req_context
    )

    # Hub materials (RESOLVE-SCOPE-RANK): relevance-ranked client files, discovered
    # only when a hub param is present AND no explicit source was given (explicit
    # wins). Computed once — feeds both the closure scope and the surfaced list.
    hub_mats: list[HubMaterial] = []
    if not source_refs and _hub_param(params)[0]:
        hub_mats = _hub_materials(task, params, vault_path, budget.cap)

    # 3. Close missing fact sources (the round-trip saver): lift a limited scope +
    # extract/upsert into facts.db; oversized → JOB-1. Only when there is a checkable
    # fact-kind still unmet (or explicit refs were passed).
    lifted_n = 0
    jobs: list[dict[str, str]] = []
    unresolved_refs: list[dict[str, str]] = []
    if lift and (use_plan or source_refs):
        need = _unsatisfied_checkable(required_facts, assembled.facts)
        if need or source_refs:
            scope = _gather_scope(
                params, source_refs, assembled.context, budget.cap,
                hub_material_paths=[m.source_path for m in hub_mats],
            )
            if scope:
                lifted_n, jobs, unresolved_refs = _close_sources(
                    scope,
                    entity=_entity(params),
                    vault_path=vault_path,
                    budget=budget,
                    submit_fn=submit_fn,
                )
                if lifted_n:
                    # 4b. Re-assemble with the closed scope so its facts surface.
                    assembled = assemble_fn(
                        use_case_id, task, params,
                        corpus=corpus_scope, exemplar_ref=exemplar_ref,
                        source_refs=scope,
                    )

    # 4c. Probe node statuses for the returned plan (resolve surface only).
    if probe_plan:
        try:
            resolve_status(the_plan, params, vault_path=vault_path, query=task)
        except Exception:  # noqa: BLE001, S110 — probe display must never break the runner
            pass

    # 5. Grounding verdict on the (possibly re-assembled) facts/context/exemplar.
    verdict = check_grounding(
        facts=assembled.facts,
        context=assembled.context,
        required_facts=required_facts,
        required_context=required_context,
        exemplar_present=assembled.exemplar is not None,
    )

    # 5b. HUB-ALIAS-1 п.4: план не должен говорить «есть» там, где гейт говорит «нет» (узел →
    # ``partial`` + конверт ``plan_inconsistent``; блок гейта не ослабляется), а нераспознанный
    # клиент - не молчаливая пустота: причина и, если каталог нашел похожее по префиксу, слово.
    plan_inconsistent: list[dict[str, str]] = []
    plan_nodes = getattr(the_plan, "nodes", None)
    if probe_plan and isinstance(plan_nodes, list):  # план-заглушка без узлов - проверять нечего
        plan_inconsistent = plan_inconsistencies(
            [n.to_dict() for n in plan_nodes], facts=assembled.facts, context=assembled.context,
            missing=verdict.missing, exemplar_present=assembled.exemplar is not None,
        )
        bad_kinds = {i["kind"] for i in plan_inconsistent}
        for node in plan_nodes:
            if node.kind in bad_kinds and node.status == STATUS_PRESENT:
                node.status = STATUS_PARTIAL
    client_unresolved = _client_unresolved(task, params, assembled, vault_path)

    return ResolveResult(
        status=verdict.status,
        use_case_id=use_case_id,
        params=params,
        facts=list(assembled.facts),
        exemplar=assembled.exemplar,
        sources=_sources(assembled.context),
        missing=[m.to_dict() for m in verdict.missing],
        plan=the_plan.to_dict(),
        jobs=jobs,
        lifted_n=lifted_n,
        # CONTRACT-2 С4/С2 — что НЕ разрешилось (пусто на здоровом пути).
        unresolved_refs=unresolved_refs,
        exemplar_unresolved=getattr(assembled, "exemplar_unresolved", ""),
        client_unresolved=client_unresolved,
        plan_inconsistent=plan_inconsistent,
        hub_materials=[m.to_dict() for m in hub_mats[:_HUB_SURFACE_N]],
        assembled=assembled,
    )


def _default_assemble(*args: Any, **kwargs: Any) -> Any:
    """Default assembler — core :func:`core.generation.assemble_prompt`."""
    from core.generation import assemble_prompt

    return assemble_prompt(*args, **kwargs)


def _sources(context: list[Any]) -> list[dict[str, Any]]:
    """Deduped vault-note provenance from the retrieval context (as generate builds)."""
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for chunk in context:
        result = getattr(chunk, "result", None)
        if result is None:
            continue
        note_id = getattr(result, "note_id", "")
        if note_id in seen:
            continue
        seen.add(note_id)
        out.append(
            {
                "note_id": note_id,
                "source_path": getattr(result, "source_path", None),
                "heading_path": getattr(result, "heading_path", None),
                "slice": getattr(chunk, "slice", None),
            }
        )
    return out
