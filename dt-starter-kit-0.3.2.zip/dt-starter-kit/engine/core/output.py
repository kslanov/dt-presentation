"""Output + provenance for generated artifacts (architecture §5, ТЗ D5).

Every generation writes a self-contained folder under
``07-outputs/YYYY-MM/<task-id>-<short>/`` recording *exactly* what produced the
artifact:

  * ``prompt.md``   — the verbatim assembled prompt;
  * ``sources.md``  — every chunk that went into the prompt (note → file →
    slice → score → chunk_index);
  * ``policy.yaml`` — the retrieval policy used, copied verbatim;
  * ``meta.yaml``   — use case, model, timestamp, params;
  * ``output.md``   — the artifact text (written after Cowork generation).

Path B: the engine writes the prompt + provenance; the model that fills
``output.md`` is Claude in Cowork (``model: cowork/claude-desktop``).

Invariant: ``core/`` depends on neither MCP nor CLI.
"""

from __future__ import annotations

import os
import re
import unicodedata
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

import yaml

from core.config import default_vault_path, outputs_path
from core.generation import AssembledPrompt
from core.note_ids import (
    frontmatter_block,
    output_note_fields,
    split_frontmatter,
)
from core.provenance import (
    DEFAULT_ADHOC_SOURCES_H,
    ORIGIN_FACTS,
    ORIGIN_LIFT,
    ORIGIN_MANUAL,
    ORIGIN_READ,
    ORIGIN_TELEMETRY,
    SearchRow,
    SessionWindow,
    SourceRow,
    adhoc_sources_hours,
    collect_lift_sources,
    manual_sources,
    merge_sources,
    parse_manual_rows,
    render_search_lines,
    render_source_table,
    render_window_line,
)
from core.retrieval.search import SearchResult

__all__ = [
    "slugify",
    "create_output_dir",
    "create_adhoc_output_dir",
    "write_provenance",
    "save_artifact",
    "SOURCE_ADHOC",
    "read_meta",
    "OutputDraft",
    "begin_output",
    "apply_purpose",
    "refresh_purpose_frontmatter",
    "finalize_output",
    "CHANNELS",
    "STATUS_DRAFT",
    "STATUS_FINAL",
    "SourceRow",
    "DEFAULT_ADHOC_SOURCES_H",
    "ORIGIN_FACTS",
    "ORIGIN_LIFT",
    "ORIGIN_MANUAL",
    "ORIGIN_READ",
    "ORIGIN_TELEMETRY",
    "adhoc_sources_hours",
    "collect_lift_sources",
    "manual_sources",
    "merge_sources",
    "render_adhoc_sources",
    "write_adhoc_sources",
    "sources_window",
    "append_session_sections",
    "previous_manual_rows",
    "session_sections_text",
    "related_hubs",
    "MODEL_SOURCE_DECLARED",
    "MODEL_SOURCE_HOST",
    "MODEL_SOURCE_UNKNOWN",
    "provenance_fields",
    "model_source_of",
    "provenance_line",
    "stamp_engine_run",
    "DELIVERED_KEY",
    "VAULT_ROOT_NAME",
    "delivered_records",
    "delivery_ref",
    "latest_delivery",
    "record_delivery",
    "mark_replaced",
    "replaced_deliveries",
]

# VENDOR-HYGIENE-1 п.2: константа ``MODEL = "cowork/claude-desktop"`` удалена — модель в мете
# теперь объявленная (параметр ``model`` инструмента), хост — из handshake (``core.host``).
# Источник сведения о модели в ``meta.yaml``:
MODEL_SOURCE_DECLARED = "declared"  # передана параметром ``model`` (объявлено клиентом, не факт)
MODEL_SOURCE_HOST = "host"  # хост сам сообщил модель в ``clientInfo``
MODEL_SOURCE_UNKNOWN = "unknown"  # ничего не известно (или старый выход без поля)
_MODEL_MAX = 80
# Инструменты контура выхода не считаются «вызовами DT» окна: иначе ``engine_calls`` у выхода,
# собранного без обращений к корпусу, никогда не был бы 0 («без вызовов DT» — принцип 3 дизайна).
_CONTOUR_TOOLS = ("output_begin", "save_output")

# Провенанс папки, созданной БЕЗ ``generate`` (DOD-1): текст пришёл из ad-hoc чата,
# политики подбора/образца за ним не стояло — это видно по ``source: adhoc`` в
# ``meta.yaml`` и отличает такую папку от полноценной генерации.
SOURCE_ADHOC = "adhoc"

# DOD-2 — жизненный цикл папки выхода. ``draft`` ставит :func:`begin_output` (каркас
# создан, работа ещё не сделана), ``final`` — :func:`finalize_output` из ``save_output``.
# Разница видна доктору: draft-папка старше суток = битый контур, а не оформленный выход.
STATUS_DRAFT = "draft"
STATUS_FINAL = "final"

# Канал доставки — куда артефакт уходит. Формальный признак того самого триггера
# «выходит за пределы vault» (фейлкейс 2026-08-11 п. 5.3): ``vault`` — остался внутри,
# остальные четыре означают, что артефакт кто-то получил снаружи.
CHANNELS = ("vault", "storage", "external", "hr", "client")

# Каркас выхода собран в чате: политика подбора и образец за текстом НЕ стояли.
# Помета из канона выхода (прецедент 2026-07-29): по ней видно, что провенанс —
# постановка + источники, а не прогон движка.
ENGINE_RUN_ADHOC = False

# SRC-TRACE-2 / PROV-SESSION-1: окно, строки и сборщик источников живут в ``core.provenance``;
# здесь - реэкспорт (прежние импорты ``from core.output import SourceRow …`` работают) и запись.

# Keep Unicode letters/digits (the corpus uses Cyrillic filenames); collapse
# everything else to single hyphens.
_NON_WORD_RE = re.compile(r"[^\w]+", re.UNICODE)


def slugify(text: str, *, max_words: int = 6, max_len: int = 50) -> str:
    """Make a filesystem-friendly slug, preserving Unicode letters.

    Lowercases, drops punctuation, joins the first ``max_words`` words with
    hyphens and truncates to ``max_len``. Returns ``"untitled"`` for empty input.
    """
    text = unicodedata.normalize("NFC", text or "").strip().lower()
    cleaned = _NON_WORD_RE.sub("-", text).strip("-")
    if not cleaned:
        return "untitled"
    slug = "-".join(cleaned.split("-")[:max_words])[:max_len].strip("-")
    return slug or "untitled"


_HOST_TAG_MAX = 12


def host_tag(name: str | None = None) -> str:
    """Короткое имя хоста для суффикса папки выхода: ``kimi-work`` -> ``kimi``.

    Первое «слово» имени хоста (из handshake, уже очищенного ``core.host``), только
    ``[a-z0-9]``, до :data:`_HOST_TAG_MAX` знаков; пусто -> ``host``. Вендорных имен в коде нет:
    метка выводится из строки, которую хост прислал сам."""
    from core.host import current_host

    raw = (name if name is not None else current_host()["name"]).casefold()
    for word in re.split(r"[^a-z0-9]+", raw):
        if word:
            return word[:_HOST_TAG_MAX]
    return "host"


def _folder_host(folder: Path) -> str:
    """Имя хоста в ``meta.yaml`` папки; нет меты/поля -> пустая строка (владелец неизвестен)."""
    host = read_meta(folder / "meta.yaml").get("host")
    return str(host.get("name") or "").strip() if isinstance(host, dict) else ""


@contextmanager
def _claim_lock() -> Iterator[None]:
    """Короткий межпроцессный lock на выбор имени папки выхода (``.derived/outputs-claim.lock``).

    Два сервера (два хоста) на одном vault выбирают имя одновременно: без lock'а второй видел бы
    только что созданную папку ПЕРВОГО без меты и не мог узнать, чья она. Критическая секция -
    ``mkdir`` + штамп хоста (микросекунды); сбой самого lock'а (нет прав на ``.derived``) не
    блокирует работу - остаётся атомарный ``mkdir``."""
    import fcntl

    from core.config import derived_root

    fh = None
    try:
        path = derived_root() / "outputs-claim.lock"
        path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(path, "a+")
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
    except OSError:
        if fh is not None:
            fh.close()
        fh = None
    try:
        yield
    finally:
        if fh is not None:
            try:
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
            finally:
                fh.close()


def claim_output_dir(month_dir: Path, base: str, *, reuse_open: bool = False) -> tuple[Path, bool]:
    """Занять папку выхода под именем ``base`` -> ``(путь, created)``.

    MODEL-1 п.B (MULTI-HOST-1): две сессии (два хоста) на одном vault не перепутают выходы.
    Порядок имен: ``base`` -> если ее занял ДРУГОЙ хост, ``base-<хост>`` (``-kimi``, ``-claude``)
    -> счетчик ``-2``, ``-3``… (так же, как раньше, когда занята закрытым выходом/своей же папкой).
    ``reuse_open`` (``output_begin``) - попасть в свою незакрытую заявку (идемпотентность по title);
    чужую заявку (``meta.host`` другого хоста) не берем, закрытую (``output.md``) - тоже.
    Выбор имени, ``mkdir`` и штамп хоста в ``meta.yaml`` - под :func:`_claim_lock`: владелец
    свежей папки известен сразу, поэтому суффикс хоста детерминирован и без гонки. Штамп - только
    ключ ``host``; полную мету вызывающий пишет следом (``begin_output``/``write_provenance``)."""
    from core.host import current_host

    who = current_host()
    me = who["name"]
    tag = host_tag(me)
    with _claim_lock():
        month_dir.mkdir(parents=True, exist_ok=True)
        stem, n, tagged = base, 2, False
        candidate = month_dir / stem
        while True:
            try:
                candidate.mkdir()
            except FileExistsError:
                owner = _folder_host(candidate)
                closed = (candidate / "output.md").is_file()
                if reuse_open and not closed and (not owner or owner == me):
                    return candidate, False
                if not tagged and owner and owner != me:
                    stem, n, tagged = f"{stem}-{tag}", 2, True
                    candidate = month_dir / stem
                else:
                    candidate = month_dir / f"{stem}-{n}"
                    n += 1
                continue
            stamp = {"host": {"name": me, "version": who["version"]}}
            _write_meta(candidate / "meta.yaml", stamp)
            return candidate, True


def create_output_dir(
    use_case_id: str,
    short_desc: str,
    *,
    vault_path: Path | None = None,
    now: datetime | None = None,
) -> Path:
    """Create and return ``07-outputs/YYYY-MM/<date>-<short>/``.

    The task id is the date plus a slug of ``short_desc``. On a same-day name
    collision a ``-2``, ``-3``… suffix is appended so prior provenance is never
    clobbered (MODEL-1: if another HOST owns the colliding folder, ``-<host>`` first —
    see :func:`claim_output_dir`). ``now`` is injectable for deterministic tests.
    """
    now = now or datetime.now()
    month_dir = outputs_path(vault_path) / now.strftime("%Y-%m")
    task_id = f"{now.strftime('%Y-%m-%d')}-{slugify(short_desc)}"

    out_dir, _ = claim_output_dir(month_dir, task_id)
    return out_dir


def create_adhoc_output_dir(
    title: str,
    *,
    vault_path: Path | None = None,
    now: datetime | None = None,
    model: str | None = None,
    purpose: str | None = None,
) -> Path:
    """Создать папку output'а БЕЗ ``generate`` — ad-hoc режим (DOD-1).

    Кейс: чат работал с движком сырыми инструментами, произвёл результат и не вернул
    его в vault — потому что ``save_output`` требовал ``output_dir`` от ``generate``,
    и соблюсти правило одним вызовом было нельзя (правило, которое дорого соблюдать,
    не соблюдается). Здесь папка создаётся сама: тот же путь и тот же слаггер, что у
    :func:`create_output_dir` (``07-outputs/YYYY-MM/<дата>-<slug>/``), плюс
    ``meta.yaml`` с ``source: adhoc`` — по нему видно, что за текстом не стояло
    политики подбора и образца (в отличие от папки от ``generate``).

    Возвращает созданную папку; ``output.md`` в неё пишет :func:`save_artifact`.
    """
    now = now or datetime.now()
    out_dir = create_output_dir(SOURCE_ADHOC, title, vault_path=vault_path, now=now)
    meta = {
        "source": SOURCE_ADHOC,
        "title": str(title or "").strip(),
        **provenance_fields(model),
        "created": now.isoformat(timespec="seconds"),
    }
    meta.update(_purpose_meta(
        texts=(), title=str(title or "").strip(), meta=meta, explicit=purpose,
        vault_path=vault_path))
    (out_dir / "meta.yaml").write_text(
        yaml.safe_dump(meta, allow_unicode=True, sort_keys=False), encoding="utf-8"
    )
    return out_dir


@dataclass(frozen=True)
class OutputDraft:
    """Результат :func:`begin_output`: папка выхода и что с ней случилось.

    ``created`` = папку завели этим вызовом (``False`` — попали в уже существующую
    заявку того же дня, идемпотентность). ``warning`` непуст, если канал доставки
    назван не из :data:`CHANNELS` (записан как есть — см. :func:`begin_output`).
    """

    path: Path
    created: bool
    channel: str = ""
    warning: str = ""


def read_meta(path: Path) -> dict:
    """``meta.yaml`` → dict; нет файла/битой YAML/не-словарь → ``{}`` (не падаем).

    Единственная точка чтения меты выхода: ею живут и финализация, и doctor-скан
    (:func:`core.operational.dod.draft_outputs`) — контракт полей в одном месте.
    """
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_meta(path: Path, meta: dict) -> None:
    """``meta.yaml`` целиком и АТОМАРНО (temp + ``os.replace``): читатель никогда не видит
    усеченный/пустой файл. Раньше ``write_text`` обнулял файл на миг, и второй хост, выбирая имя
    папки (``claim_output_dir`` читает владельца из меты), видел «владельца нет» и брал чужую
    заявку: две сессии одного демона на одно ``title`` иногда получали одну папку (флейк
    ``test_two_sessions_one_process``)."""
    import threading

    text = yaml.safe_dump(meta, allow_unicode=True, sort_keys=False)
    tmp = path.with_name(f".{path.name}.dt-tmp-{os.getpid()}-{threading.get_ident()}")
    try:
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def provenance_fields(model: str | None = None, *, prev: dict | None = None) -> dict:
    """Кем собран выход → поля ``meta.yaml``: ``host``, ``model``, ``model_source``.

    ``host`` — из handshake (достоверно, ``core.host``); ``model`` — то, что объявил клиент
    параметром (``declared``; не проверяется — движок модель не видит), либо сообщил сам хост в
    ``clientInfo`` (``host``), иначе ``None`` и ``unknown``. ``prev`` — мета той же папки при
    повторном ``output_begin``: ранее объявленная модель не теряется, если новый вызов ее не
    передал.
    """
    from core.host import current_host

    h = current_host()
    declared = " ".join(str(model or "").split())[:_MODEL_MAX]
    if not declared and prev and prev.get("model_source") == MODEL_SOURCE_DECLARED:
        declared = str(prev.get("model") or "")
    if declared:
        value, source = declared, MODEL_SOURCE_DECLARED
    elif h.get("model"):
        value, source = h["model"], MODEL_SOURCE_HOST
    else:
        value, source = None, MODEL_SOURCE_UNKNOWN
    return {
        "host": {"name": h["name"], "version": h["version"]},
        "model": value,
        "model_source": source,
    }


def provenance_line(meta: dict) -> str:
    """Строка ``sources.md``: «собрано: хост / модель (источник сведения) / вызовов DT: N».

    Читает мету папки; старая мета без полей (нет ``host``/``model_source``/``engine_calls``)
    даёт честные «—»/``unknown``/«неизвестно» — ничего не додумываем.
    """
    host = meta.get("host") if isinstance(meta.get("host"), dict) else {}
    name = str(host.get("name") or "").strip()
    label = (f"{name}/{host['version']}" if host.get("version") else name) if name else "—"
    model = str(meta.get("model") or "").strip()
    calls = meta.get("engine_calls")
    calls_s = str(calls) if isinstance(calls, int) and not isinstance(calls, bool) else "неизвестно"
    return (
        f"собрано: {label} / модель: {model or '—'} ({model_source_of(meta)}) / "
        f"вызовов DT: {calls_s}"
    )


def model_source_of(meta: dict) -> str:
    """Источник сведения о модели в мете; у старых выходов поля нет → ``unknown``.

    Старые папки (константа ``cowork/claude-desktop`` без ``model_source``) не бэкфиллятся —
    нечем подтвердить, какая модель их писала: читаются как ``unknown``.
    """
    value = str(meta.get("model_source") or "").strip()
    if value in (MODEL_SOURCE_DECLARED, MODEL_SOURCE_HOST):
        return value
    return MODEL_SOURCE_UNKNOWN


ENGINE_CALLS_WINDOW_GENERATE = "generate"


def sources_window(
    out_dir: Path, *, now: datetime | None = None
) -> tuple[datetime, datetime, bool]:
    """Окно ``engine_calls`` ad-hoc-выхода → ``(since, until, from_begin)`` (SRC-TRACE-2).

    PROV-SESSION-1: окно СБОРА источников теперь :func:`core.provenance.session_window`; эта
    функция осталась только для ``engine_calls`` (``stamp_engine_run``), семантика прежняя.
    ``from_begin=True`` - начало из ``meta.created`` (каркас от ``output_begin``, ключ ``status``);
    ``False`` - приближение последними :func:`adhoc_sources_hours` часами.
    """
    until = now or datetime.now(UTC)
    meta = read_meta(Path(out_dir) / "meta.yaml")
    raw = str(meta.get("created") or "").strip() if meta.get("status") else ""
    if raw:
        try:
            started = datetime.fromisoformat(raw)
        except ValueError:
            started = None
        if started is not None:
            if started.tzinfo is None:
                started = started.astimezone()  # мета пишется в локальном времени
            return started, until, True
    return until - timedelta(hours=adhoc_sources_hours()), until, False


def _generate_window(
    meta: dict, now: datetime | None = None
) -> tuple[datetime, datetime] | None:
    """Окно счетчика вызовов для папки ``generate``: от ``meta.created`` (момент ``generate``) до
    сейчас. Назад НЕ расширяется: ``parse_task``/``retrieve`` до ``generate`` в счет не входят
    (расширить - снова приближение). Нет/битый ``created`` -> ``None`` (окна нет - не штампуем)."""
    raw = str(meta.get("created") or "").strip()
    if not raw:
        return None
    try:
        started = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if started.tzinfo is None:
        started = started.astimezone()  # мета пишется в локальном времени
    return started, now or datetime.now(UTC)


def stamp_engine_run(
    out_dir: Path, *, model: str | None = None, now: datetime | None = None
) -> dict | None:
    """``save_output`` -> в ``meta.yaml``: ``engine_calls`` (+ ``model`` и ``host``, если известны).

    ``engine_calls`` - сколько вызовов DT сделал ЭТОТ хост в окне выхода; сам контур выхода
    (``output_begin``/``save_output``) не считается. ``0`` = «собрано без вызовов DT»; ``None`` -
    журнал метрик не прочитался (неизвестно != ноль). Два вида папок:

    * **ad-hoc** (``output_begin`` и ``save_output(title=…)``, ``source: adhoc``): окно - то же, что
      у сбора источников (:func:`sources_window`: от ``output_begin`` до сохранения, а без него -
      приближение ``DT_ADHOC_SOURCES_H`` часов); метка ``engine_calls_window`` -
      ``begin``/``approx``;
    * **generate** (мета без ``source`` с ``use_case``, MODEL-1-STAMP): окно - **от ``meta.created``
      (момент ``generate``) до сохранения**, ``engine_calls_window: "generate"``. ``parse_task`` и
      ``retrieve`` ДО ``generate`` в счет не входят (назад окно не расширяем - иначе снова
      приближение). Снапшот DOD-1 - провенанс РЕТРИВАЛА на момент ``generate`` (ключи
      ``use_case``/``params``/``created``/``host``, их порядок и значения) - не трогается:
      дописываются только ``engine_calls``/``engine_calls_window`` в конец и, если объявлена,
      ``model``/``model_source`` (на месте; ключи ``write_provenance`` уже есть). Нет ``created`` -
      не штампуем.

    ``model`` перезаписывается только объявленной сейчас моделью (объявленная на ``generate``
    сохраняется), ``host`` дописывается, если его еще нет. Нет меты/чужая мета -> ``None``.
    """
    meta_path = Path(out_dir) / "meta.yaml"
    if not meta_path.is_file():
        return None
    from core.host import current_host
    from core.metrics import count_tool_calls

    meta = read_meta(meta_path)
    if meta.get("source") == SOURCE_ADHOC:
        since, until, from_begin = sources_window(out_dir, now=now)
        window_label = "begin" if from_begin else "approx"
    elif "source" not in meta and meta.get("use_case"):
        win = _generate_window(meta, now)
        if win is None:
            return None
        since, until = win
        window_label = ENGINE_CALLS_WINDOW_GENERATE
    else:
        return None  # чужая мета - не наша, не переписываем
    meta["engine_calls"] = count_tool_calls(
        since, until, host=current_host()["name"], exclude=_CONTOUR_TOOLS
    )
    meta["engine_calls_window"] = window_label
    fields = provenance_fields(model, prev=meta)
    if "host" not in meta:
        meta["host"] = fields["host"]
    if str(model or "").strip() or ("model_source" not in meta and "model" not in meta):
        meta["model"], meta["model_source"] = fields["model"], fields["model_source"]
    _write_meta(meta_path, meta)
    return meta


def _purpose_meta(
    *, texts: tuple[str, ...], title: str, meta: dict, explicit: str | None = None,
    vault_path: Path | None = None, prior: dict | None = None,
) -> dict:
    """EVAL-HYGIENE-1: ключи ``purpose``/``eval_task`` для меты (пусто у ``work``).

    Хост - из самой меты (``host.name``): одна функция и для живого выхода, и для ретро-пометки
    старых папок. Прежнее назначение (``prior.purpose``, по умолчанию - из ``meta``) не
    ослабляется."""
    from core import purpose as _purpose

    host = meta.get("host")
    name = str(host.get("name") or "") if isinstance(host, dict) else ""
    before = prior if prior is not None else meta
    res = _purpose.resolve(
        texts=texts, title=title, host=name, explicit=explicit,
        prior=_purpose.purpose_of(before) if before.get(_purpose.PURPOSE_KEY) else None,
        prior_eval_task=str(before.get(_purpose.EVAL_TASK_KEY) or "") or None, vault=vault_path,
    )
    if res.is_work:
        return {}
    out = {_purpose.PURPOSE_KEY: res.purpose}
    if res.eval_task:
        out[_purpose.EVAL_TASK_KEY] = res.eval_task
    return out


_PURPOSE_FM_KEYS = ("purpose", "eval_task")


def refresh_purpose_frontmatter(out_dir: Path) -> None:
    """Дописать/обновить ``purpose``/``eval_task`` во frontmatter файлов контура выхода
    (``output.md``/``sources.md``/``prompt.md``) по ``meta.yaml``; остальное не трогается."""
    out_dir = Path(out_dir)
    meta = read_meta(out_dir / "meta.yaml")
    want = {k: meta[k] for k in _PURPOSE_FM_KEYS if meta.get(k)}
    for name in ("output.md", "sources.md", "prompt.md"):
        path = out_dir / name
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            continue
        fm, body = split_frontmatter(text)
        if not fm or all(fm.get(k) == v for k, v in want.items()):
            continue
        for key in _PURPOSE_FM_KEYS:
            fm.pop(key, None)
        fm.update(want)
        path.write_text(frontmatter_block(fm) + body, encoding="utf-8")


def apply_purpose(
    out_dir: Path, explicit: str | None = None, *, vault_path: Path | None = None
) -> dict:
    """Свести назначение уже существующей папки выхода и записать в ``meta.yaml`` (EVAL-HYGIENE-1).

    Читает мету (хост, ``title``, ``task``), ``prompt.md`` (постановка / промпт ``generate``) и
    решает так же, как :func:`begin_output`; назначение только усиливается (``work`` → ``eval``/
    ``selftest``), обратно - никогда. Меняет файл лишь при изменении (рабочий выход остается
    байт-идентичным). Возвращает ``{purpose, eval_task, changed}``."""
    from core import purpose as _purpose

    out_dir = Path(out_dir)
    meta_path = out_dir / "meta.yaml"
    meta = read_meta(meta_path)
    if not meta:
        return {"purpose": _purpose.PURPOSE_WORK, "eval_task": None, "changed": False}
    prompt_path = out_dir / "prompt.md"
    try:
        prompt = split_frontmatter(prompt_path.read_text(encoding="utf-8"))[1]
    except OSError:
        prompt = ""
    found = _purpose_meta(
        texts=(str(meta.get("task") or ""), prompt), title=str(meta.get("title") or ""),
        meta=meta, explicit=explicit, vault_path=vault_path)
    before = {k: meta.get(k) for k in _PURPOSE_FM_KEYS}
    changed = bool(found) and any(before.get(k) != found.get(k) for k in found)
    if changed:
        for key in _PURPOSE_FM_KEYS:
            meta.pop(key, None)
        meta.update(found)
        _write_meta(meta_path, meta)
        refresh_purpose_frontmatter(out_dir)
    return {"purpose": _purpose.purpose_of(meta), "eval_task": meta.get("eval_task"),
            "changed": changed}


def _normalize_channel(value: str | None) -> tuple[str, str]:
    """Канал доставки → (значение, warning). Незнакомый НЕ отказ — записываем как есть.

    Отказать было бы хуже, чем принять незнакомую метку: контур выхода не должен
    падать из-за словаря (тот же принцип, что у ФТ-4 «нет pandoc → md + warning, а не
    отказ»). Пустой канал допустим — его дописывает факт доставки при финализации.
    """
    raw = " ".join(str(value or "").split()).lower()
    if not raw:
        return "", ""
    if raw in CHANNELS:
        return raw, ""
    return raw[:40], (
        f"канал {raw[:40]!r} не из набора {', '.join(CHANNELS)} — записан как есть"
    )


def begin_output(
    title: str,
    task: str,
    *,
    channel: str | None = None,
    vault_path: Path | None = None,
    now: datetime | None = None,
    model: str | None = None,
    purpose: str | None = None,
) -> OutputDraft:
    """DOD-2: завести папку выхода С ПОСТАНОВКОЙ **до** работы, а не после.

    Кейс 2026-08-11 (3-е повторение класса): контур собирался в конце сессии, жёсткий
    таймаут моста пришёлся на середину — в vault осталась полу-папка (``meta.yaml`` +
    ``policy.yaml`` без ``prompt.md`` и ``output.md``), которая «выглядит оформленной».
    Порядок перевёрнут: сначала ``meta.yaml`` (``status: draft`` + канал доставки) и
    ``prompt.md`` (постановка дословно), потом работа, потом
    :func:`finalize_output`/:func:`save_artifact`. Падение на любом шаге после begin
    оставляет **валидную заявку с зафиксированной постановкой**, а не мусор: провенанс
    постфактум невосстановим (по одному тексту уже не сказать, откуда взялась цифра).

    Путь и слаггер — те же, что у :func:`create_output_dir`
    (``07-outputs/YYYY-MM/<дата>-<slug>/``). **Идемпотентность по title в тот же день:**
    повторный вызов попадает в ту же папку (перезапись постановки — это тот же begin,
    а не второй выход), но папку с готовым ``output.md`` не трогает — там уже лежит
    закрытый выход, для него берётся суффикс ``-2``. ``created`` в ответе показывает,
    что именно случилось.

    ``channel`` ∈ :data:`CHANNELS`, опционально: незнакомая метка пишется как есть с
    ``warning`` (отказ здесь дороже неточной метки). Пустой ``title``/``task`` — отказ:
    папка без постановки и есть та самая «выглядит оформленной» полу-папка.

    ``purpose`` (EVAL-HYGIENE-1) - ``work`` | ``eval`` | ``selftest``; решает движок
    (:mod:`core.purpose`: фраза задачи golden-generation → ``eval``; тестовый хост →
    ``selftest``), явное значение сильнее только в сторону ``eval``/``selftest``. У ``work``
    ключа в мете нет (байт-в-байт прежнее).
    """
    now = now or datetime.now()
    title_s = str(title or "").strip()
    if not title_s:
        raise ValueError("нужен title — по нему строится имя папки выхода")
    task_s = str(task or "").strip()
    if not task_s:
        raise ValueError(
            "нужен task — постановка задачи дословно (она и есть смысл каркаса: "
            "провенанс постфактум невосстановим)"
        )
    channel_s, warning = _normalize_channel(channel)

    month_dir = outputs_path(vault_path) / now.strftime("%Y-%m")
    base = f"{now.strftime('%Y-%m-%d')}-{slugify(title_s)}"
    # закрытый выход и заявку ДРУГОГО хоста не перезаписываем (суффикс хоста, затем счетчик)
    out_dir, created = claim_output_dir(month_dir, base, reuse_open=True)

    prev = read_meta(out_dir / "meta.yaml")
    meta = {
        "source": SOURCE_ADHOC,
        "title": title_s,
        "status": STATUS_DRAFT,
        "engine_run": ENGINE_RUN_ADHOC,
        **provenance_fields(model, prev=prev),
        # при повторном begin время заявки — исходное (папка та же, заявка та же)
        "created": prev.get("created") or now.isoformat(timespec="seconds"),
    }
    channel_final = channel_s or str(prev.get("channel") or "")
    if channel_final:
        meta["channel"] = channel_final
    meta.update(_purpose_meta(
        texts=(task_s,), title=title_s, meta=meta, explicit=purpose, vault_path=vault_path,
        prior=prev))
    _write_meta(out_dir / "meta.yaml", meta)
    # WAVE0-HYGIENE п.2: у prompt.md свой frontmatter id (``prompt-<папка>``) — иначе все
    # промпты выходов делили бы один id ``prompt``. Постановка идёт ниже блока дословно.
    task_body = task_s if task_s.endswith("\n") else task_s + "\n"
    (out_dir / "prompt.md").write_text(
        frontmatter_block(output_note_fields(out_dir, "prompt.md", title=title_s))
        + task_body,
        encoding="utf-8",
    )
    return OutputDraft(
        path=out_dir, created=created, channel=channel_final, warning=warning
    )


def finalize_output(
    out_dir: Path, *, channel: str | None = None, now: datetime | None = None
) -> dict | None:
    """DOD-2: закрыть контур — ``status: draft`` → ``final`` (+ факт доставки в канал).

    Вызывается из ``save_output`` рядом с записью ``output.md``. Трогает **только**
    папки, заведённые :func:`begin_output`: признак — ключ ``status`` в ``meta.yaml``.
    Папки от ``generate`` и ad-hoc-папки DOD-1 остаются **байт-идентичными** (у них
    этого ключа нет вовсе) — старые пути и их снапшоты не меняются.

    Возвращает новую мету (что записали) либо ``None``, если финализировать нечего:
    меты нет, она нечитаема или папка уже ``final`` и канал не уточняется.
    """
    meta_path = Path(out_dir) / "meta.yaml"
    if not meta_path.is_file():
        return None
    meta = read_meta(meta_path)
    if not meta.get("status"):
        return None  # чужая мета (generate / DOD-1) — не наша, не переписываем
    channel_s, _ = _normalize_channel(channel)
    already_final = meta.get("status") == STATUS_FINAL
    if already_final and (not channel_s or meta.get("channel") == channel_s):
        return None
    meta["status"] = STATUS_FINAL
    meta["finalized"] = (now or datetime.now()).isoformat(timespec="seconds")
    if channel_s:
        meta["channel"] = channel_s  # факт доставки точнее заявленного намерения
    _write_meta(meta_path, meta)
    return meta


# --------------------------------------------------------------------------- #
# DELIVER-2 — что и куда доставлено: ``meta.yaml: delivered``                   #
# --------------------------------------------------------------------------- #
# Каждая доставка файла (``save_output(dest=…)`` в ingest-корень либо ``format`` без ``dest`` в
# папку выхода) оставляет в мете запись ``{root, rel_path, sha256, format, at}``. Это источник
# правды для двух вещей: (1) «свой файл» - файл с sha256 нашей последней доставки по тому же пути
# перезаписывается без ``overwrite`` (фейлкейс g1 30.10: правка текста три раза подряд упиралась в
# ``exists_differs`` на СОБСТВЕННЫЙ файл); (2) секция «## Файлы» перерисовывается из записей, а не
# теряется при повторном сохранении. Ключ дописывается в КОНЕЦ меты (как штампы MODEL-1-STAMP):
# снапшот-ключи generate-папки, их порядок и значения неизменны; у старых выходов ключа нет вовсе.
DELIVERED_KEY = "delivered"
# ``root`` записи о файле в папке выхода: «корень» - сам vault (путь ``07-outputs/…``).
VAULT_ROOT_NAME = "vault"
_VAULT_REF_PREFIX = "vault:"
_REPLACED_NOTE = "заменен снаружи"


def delivered_records(meta: dict) -> list[dict]:
    """Записи ``delivered`` меты (только словари с ``root``/``rel_path``); нет ключа - ``[]``."""
    raw = meta.get(DELIVERED_KEY) if isinstance(meta, dict) else None
    if not isinstance(raw, list):
        return []
    return [r for r in raw if isinstance(r, dict) and r.get("rel_path")]


def delivery_ref(record: dict) -> str:
    """Адрес записи в «## Файлы»: ``<root>/<rel_path>`` (ingest-корень) либо ``vault:<rel_path>``
    (файл в папке выхода, путь относительно vault)."""
    root = str(record.get("root") or "")
    rel = str(record.get("rel_path") or "")
    if root == VAULT_ROOT_NAME:
        return f"{_VAULT_REF_PREFIX}{rel}"
    return f"{root}/{rel}" if root else rel


def latest_delivery(meta: dict, root: str, rel_path: str) -> dict | None:
    """Действующая запись по пути: последняя в списке (история sha остается в мете)."""
    for rec in reversed(delivered_records(meta)):
        if str(rec.get("root") or "") == root and str(rec.get("rel_path") or "") == rel_path:
            return rec
    return None


def record_delivery(
    out_dir: Path, *, root: str, rel_path: str, sha256: str, fmt: str,
    at: datetime | None = None, intended_dest: str | None = None,
) -> dict | None:
    """Дописать доставку в ``meta.yaml: delivered`` (в конец меты). Возвращает новую запись.

    Повтор с тем же sha по тому же пути запись не плодит (``None``): «действующая» не меняется.
    Нет меты - заводим минимальную (``{delivered: […]}``): без записи собственный файл не
    перезапишется. Чужая/битая мета (не словарь) не трогается."""
    meta_path = Path(out_dir) / "meta.yaml"
    meta = read_meta(meta_path) if meta_path.is_file() else {}
    if meta_path.is_file() and not meta:
        return None  # битая/не-словарь: переписывать нечем и нечего
    last = latest_delivery(meta, root, rel_path)
    if last is not None and str(last.get("sha256") or "") == sha256:
        return None
    record = {
        "root": root, "rel_path": rel_path, "sha256": sha256, "format": fmt,
        "at": (at or datetime.now()).isoformat(timespec="seconds"),
    }
    if intended_dest:  # EVAL-HYGIENE-1: карантин - куда просили (ключа нет у обычной доставки)
        record["intended_dest"] = intended_dest
    records = delivered_records(meta)
    meta[DELIVERED_KEY] = [*records, record]
    _write_meta(meta_path, meta)
    return record


def _refresh_files_section(out_dir: Path) -> None:
    """Перерисовать «## Файлы» уже лежащего ``output.md`` из меты (текст автора не меняется)."""
    note = Path(out_dir) / "output.md"
    try:
        existing = note.read_text(encoding="utf-8")
    except OSError:
        return
    save_artifact(out_dir, existing)


def mark_replaced(
    root: str, rel_path: str, sha256: str, by_host: str, *,
    vault_path: Path | None = None, at: datetime | None = None,
) -> list[Path]:
    """DELIVER-2 п.4: файл по ``root/rel_path`` затерт СНАРУЖИ (``place_download``/``store_file``
    ``overwrite=True``) - пометить это в выходах, которые его доставляли.

    У каждой найденной папки выхода, где действующая запись ``delivered`` по пути несет ДРУГОЙ sha,
    в запись пишется ``replaced_by: <host>/<sha256>`` (+ ``replaced_at``) и перерисовывается
    «## Файлы» (подпись ссылки «заменен снаружи: host/sha»). Выходы, не доставлявшие этот путь,
    не меняются; повторная пометка тем же sha - no-op. Возвращает измененные папки выходов."""
    from core.config import outputs_path

    root_dir = outputs_path(vault_path)
    if not root_dir.is_dir():
        return []
    marked: list[Path] = []
    stamp = (at or datetime.now()).isoformat(timespec="seconds")
    by = f"{by_host or 'unknown'}/{sha256}"
    for meta_path in root_dir.rglob("meta.yaml"):
        try:
            if f"{DELIVERED_KEY}:" not in meta_path.read_text(encoding="utf-8"):
                continue  # дешевый префильтр: доставок нет - YAML не разбираем (путь не ищем:
                # YAML переносит длинные строки с пробелами, подстрока пути не надежна)
        except OSError:
            continue
        meta = read_meta(meta_path)
        records = delivered_records(meta)
        last = latest_delivery(meta, root, rel_path)
        if last is None or str(last.get("sha256") or "") == sha256:
            continue  # выход этот путь не доставлял либо файл ровно тот, что мы положили
        if str(last.get("replaced_by") or "") == by:
            continue
        last["replaced_by"], last["replaced_at"] = by, stamp
        meta[DELIVERED_KEY] = records
        _write_meta(meta_path, meta)
        _refresh_files_section(meta_path.parent)
        marked.append(meta_path.parent)
    return marked


def replaced_deliveries(
    *, vault_path: Path | None = None, now: datetime | None = None, window_h: float = 48.0,
) -> list[dict]:
    """Доставленные файлы, замененные снаружи за окно: ``[{output, ref, replaced_by, at}]``
    (доктор DOD: справка «доставленный файл заменен снаружи»). Читаются только меты, тронутые в
    окне (``replaced_at`` пишется вместе с записью меты - mtime не раньше начала окна)."""
    from core.config import outputs_path

    root_dir = outputs_path(vault_path)
    if not root_dir.is_dir():
        return []
    cutoff_dt = (now or datetime.now()) - timedelta(hours=window_h)
    out: list[dict] = []
    for meta_path in root_dir.rglob("meta.yaml"):
        try:
            if meta_path.stat().st_mtime < cutoff_dt.timestamp():
                continue
        except OSError:
            continue
        for rec in delivered_records(read_meta(meta_path)):
            by = str(rec.get("replaced_by") or "")
            try:
                at = datetime.fromisoformat(str(rec.get("replaced_at") or ""))
            except ValueError:
                continue
            if by and at >= cutoff_dt:
                out.append({"output": meta_path.parent.name, "ref": delivery_ref(rec),
                            "replaced_by": by, "at": at})
    return sorted(out, key=lambda r: r["at"], reverse=True)


def _sources_table(assembled: AssembledPrompt) -> str:
    """Markdown table of every chunk used in the prompt (exemplars + context).

    Carries the layer (``corpus``) and the legacy unit (``heading_path``: slide/
    page/sheet/email) so both layers cite correctly: curated by note id/path,
    legacy by ``source_path`` + unit (ТЗ phase5 §7).
    """
    header = (
        "| note_id | corpus | source_path | unit | slice | score | chunk_index |\n"
        "| --- | --- | --- | --- | --- | --- | --- |"
    )
    rows: list[str] = []

    def _row(r: SearchResult, slice_: str) -> str:
        ci = r.metadata.get("chunk_index")
        ci_s = "" if ci is None else str(ci)
        corpus = r.metadata.get("corpus", "vault")
        unit = (r.heading_path or "").strip()
        return (
            f"| {r.note_id} | {corpus} | {r.source_path} | {unit} | "
            f"{slice_} | {r.score:.4f} | {ci_s} |"
        )

    for ex in assembled.exemplars:
        rows.append(_row(ex, "exemplar"))
    for ch in assembled.context:
        rows.append(_row(ch.result, ch.slice))

    body = "\n".join(rows) if rows else "| (none) |  |  |  |  |  |  |"
    return f"{header}\n{body}\n"


def write_provenance(
    out_dir: Path,
    assembled: AssembledPrompt,
    *,
    now: datetime | None = None,
    model: str | None = None,
    purpose: str | None = None,
) -> None:
    """Write ``prompt.md``, ``sources.md``, ``policy.yaml`` and ``meta.yaml``."""
    now = now or datetime.now()
    out_dir = Path(out_dir)

    meta = {
        "use_case": assembled.use_case_id,
        **provenance_fields(model),
        "created": now.isoformat(timespec="seconds"),
        "params": assembled.params,
    }
    # EVAL-HYGIENE-1: постановка ``generate`` лежит в промпте; рабочий выход ключей не получает
    meta.update(_purpose_meta(texts=(assembled.prompt,), title="", meta=meta, explicit=purpose))
    # meta.yaml — ПЕРВЫМ: frontmatter prompt.md/sources.md берёт из неё ``created``.
    _write_meta(out_dir / "meta.yaml", meta)

    # WAVE0-HYGIENE п.2: frontmatter id у prompt.md/sources.md (``<stem>-<папка>``).
    title_hint = assembled.use_case_id
    (out_dir / "prompt.md").write_text(
        frontmatter_block(output_note_fields(out_dir, "prompt.md", title=title_hint))
        + assembled.prompt + "\n",
        encoding="utf-8",
    )

    sources_md = (
        f"# Sources — {assembled.use_case_id}\n\n"
        f"{provenance_line(meta)}\n\n"
        "Every chunk injected into the prompt (style exemplars + retrieved context).\n\n"
        f"{_sources_table(assembled)}"
    )
    (out_dir / "sources.md").write_text(
        frontmatter_block(output_note_fields(out_dir, "sources.md", title=title_hint))
        + sources_md,
        encoding="utf-8",
    )

    (out_dir / "policy.yaml").write_text(assembled.policy_yaml, encoding="utf-8")


def _files_section(file_refs: list[str], notes: dict[str, str] | None = None) -> str:
    """Секция «## Файлы» со ссылками на файловые deliverable (OUT-FILE-1).

    Каждый ref — путь (root-относительный или человекочитаемый). Угловые скобки
    вокруг цели ссылки допускают пробелы/кириллицу в пути. Пустые ref пропускаются.
    ``notes`` (DELIVER-2) - пометки ссылок ``ref -> текст`` (``заменен снаружи: host/sha``): идут в
    подпись ссылки, цель и разбор секции (:data:`_FILES_ITEM_RE`) не меняются.
    """
    lines = ["", "## Файлы", ""]
    for ref in file_refs:
        r = str(ref).strip()
        if not r:
            continue
        name = Path(r).name or r
        note = (notes or {}).get(r)
        label = f"{name} - {note}" if note else name
        lines.append(f"- [{label}](<{r}>)")
    lines.append("")
    return "\n".join(lines)


def _related_section(hub_ids: list[str]) -> str:
    """Секция «## Связано» с вики-ссылками на хабы (SRC-TRACE-2).

    Зачем в output.md, а не только в мете: ``[[client-x]]`` подхватывают линкер,
    поиск и обратные ссылки Obsidian — выход становится виден СО СТОРОНЫ клиента
    («что мы им отдавали»), а не только из папки ``07-outputs``.
    """
    lines = ["", "## Связано", ""]
    lines.extend(f"- [[{hub_id}]]" for hub_id in hub_ids if str(hub_id).strip())
    lines.append("")
    return "\n".join(lines)


# DOCTOR-HONEST-1 — автосекции детерминированы, значит их можно РАСПОЗНАТЬ в тексте.
# Кейс: повторный ``save_output`` на финализированном выходе (ретроактивный провенанс
# при ревизии) получал текст, УЖЕ содержащий «## Файлы»/«## Связано» — и секции
# доливались второй раз (задвоение убирали руками). Разбираем только СВОЙ формат
# строк; секция с прозой или чужой разметкой не наша — её не трогаем и не дублируем.
_FILES_HEADING = "## Файлы"
_RELATED_HEADING = "## Связано"
_FILES_ITEM_RE = re.compile(r"^-\s+\[[^\]]*\]\(<(?P<ref>.+)>\)\s*$")
_RELATED_ITEM_RE = re.compile(r"^-\s+\[\[(?P<slug>[^\]]+)\]\]\s*$")


def _parse_auto_section(
    lines: list[str], start: int, item_re: re.Pattern[str]
) -> tuple[list[str], int] | None:
    """Разобрать автосекцию с строки ``start`` (её заголовок) → (значения, конец).

    ``None`` — секция НЕ наша: внутри есть непустая строка, не подходящая под наш
    детерминированный формат (проза, чужая разметка). Такую секцию мы не переписываем.
    """
    values: list[str] = []
    i = start + 1
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if stripped.startswith("## "):
            break  # следующий заголовок — секция кончилась
        if not stripped:
            i += 1
            continue
        match = item_re.match(stripped)
        if match is None:
            return None  # не наш формат — не наша секция
        values.append(next(iter(match.groupdict().values())).strip())
        i += 1
    return values, i


def _split_auto_sections(text: str) -> tuple[str | None, list[str], list[str], bool]:
    """Текст → ``(тело | None, file_refs, related, foreign)``.

    ``тело is None`` — сливать нечего, текст идёт в файл как есть (первичный save:
    этот разбор для него no-op, байт-идентичность по построению). ``foreign`` — под
    нашим заголовком найдена ЧУЖАЯ секция (проза, своя разметка): такой документ мы не
    перестраиваем и второй секции с тем же заголовком не дописываем — иначе либо
    потеряли бы текст автора, либо получили два «## Связано».
    """
    lines = text.splitlines()
    body_end: int | None = None
    refs: list[str] = []
    hubs: list[str] = []
    i = 0
    while i < len(lines):
        stripped = lines[i].strip()
        item_re = (
            _FILES_ITEM_RE if stripped == _FILES_HEADING
            else _RELATED_ITEM_RE if stripped == _RELATED_HEADING
            else None
        )
        if item_re is None:
            i += 1
            continue
        parsed = _parse_auto_section(lines, i, item_re)
        if parsed is None:
            return None, [], [], True
        values, end = parsed
        (refs if stripped == _FILES_HEADING else hubs).extend(values)
        if body_end is None:
            body_end = i
        i = end
    if body_end is None:
        return None, [], [], False
    return "\n".join(lines[:body_end]).rstrip("\n") + "\n", refs, hubs, False


def _merge_keep_order(existing: list[str], incoming: list[str] | None) -> list[str]:
    """Существующие значения + новые, без дублей, порядок стабильный."""
    out = list(existing)
    seen = {v.strip() for v in out}
    for value in incoming or []:
        v = str(value).strip()
        if v and v not in seen:
            seen.add(v)
            out.append(v)
    return out


def _refs_on_disk(out_dir: Path) -> list[str]:
    """Ссылки секции «## Файлы» УЖЕ лежащего ``output.md`` (DELIVER-2 п.2); нет файла, нет секции
    либо секция чужая (проза/своя разметка) - ``[]``. Старые выходы без ``delivered`` читаются так
    же: их ссылки переживают повторное сохранение."""
    path = Path(out_dir) / "output.md"
    try:
        _fm, body = split_frontmatter(path.read_text(encoding="utf-8"))
    except OSError:
        return []
    _body, refs, _hubs, foreign = _split_auto_sections(body)
    return [] if foreign else refs


def _delivery_notes(meta: dict) -> dict[str, str]:
    """``ref -> пометка`` для доставленных файлов, которые заменили снаружи (``replaced_by``)."""
    notes: dict[str, str] = {}
    for rec in delivered_records(meta):
        by = str(rec.get("replaced_by") or "").strip()
        ref = delivery_ref(rec)
        if by:
            host, _, sha = by.partition("/")
            tail = f"{host}/{sha[:12]}" if sha else by
            notes[ref] = f"{_REPLACED_NOTE}: {tail}"
        else:
            notes.pop(ref, None)  # действующая запись по пути - последняя
    return notes


def save_artifact(
    out_dir: Path,
    text: str,
    file_refs: list[str] | None = None,
    related: list[str] | None = None,
) -> Path:
    """Write the generated artifact text to ``output.md`` (Path B, post-Cowork).

    ``file_refs`` (OUT-FILE-1) — опциональные пути к файловым deliverable,
    доставленным в хранилище (``store_file``); при наличии добавляется секция
    «## Файлы» со ссылками. ``related`` (SRC-TRACE-2) — id существующих хабов
    (:func:`related_hubs`) → секция «## Связано» с ``[[wiki]]``-ссылками. Без обоих
    параметров вывод **байт-идентичен** прежнему.

    **Идемпотентность по автосекциям (DOCTOR-HONEST-1).** Если во входном тексте эти
    секции УЖЕ есть (повторный ``save_output`` на финализированном выходе — например
    ретроактивный провенанс при ревизии), они не дублируются: значения сливаются
    (``related`` по slug, ``file_refs`` по пути, без дублей, новые дописываются в
    конец), а секции перевыпускаются один раз. Секция с прозой/чужой разметкой под тем
    же заголовком считается не нашей — текст остаётся как есть.
    """
    # WAVE0-HYGIENE п.2: текст может прийти уже с frontmatter (повторный save на
    # финализированном выходе, ретроактивный провенанс). Блок снимаем и собираем заново;
    # поля вызывающего (id/client/…) побеждают дефолты — id принадлежит тому, кто его задал.
    given_fm, text = split_frontmatter(text)
    parsed_body, prev_refs, prev_hubs, foreign = _split_auto_sections(text)
    # DELIVER-2 п.2: ссылки на файлы не теряются при повторном сохранении без ``file_refs`` -
    # к явным добавляются (без дублей, по порядку) ссылки уже лежащего ``output.md`` (в т.ч. старых
    # выходов без ``delivered``) и доставки из ``meta.yaml: delivered`` (источник правды).
    meta = read_meta(Path(out_dir) / "meta.yaml")
    carried = _merge_keep_order(
        _refs_on_disk(Path(out_dir)), [delivery_ref(r) for r in delivered_records(meta)]
    )
    if parsed_body is not None:
        body_text = parsed_body
        file_refs = _merge_keep_order(_merge_keep_order(prev_refs, carried), file_refs)
        related = _merge_keep_order(prev_hubs, related)
    else:
        body_text = text
        if foreign:
            # Документ ведёт секцию сам — не дублируем и не перестраиваем его.
            file_refs = related = None
        else:
            file_refs = _merge_keep_order(carried, file_refs)
    body = body_text if body_text.endswith("\n") else body_text + "\n"
    if file_refs:
        body += _files_section(file_refs, _delivery_notes(meta))
    if related:
        body += _related_section(related)
    path = Path(out_dir) / "output.md"
    fields = output_note_fields(Path(out_dir), "output.md", body=body, related=related)
    fields.update({k: v for k, v in given_fm.items() if v not in (None, "", [])})
    path.write_text(frontmatter_block(fields) + body, encoding="utf-8")
    return path


# --------------------------------------------------------------------------- #
# SRC-TRACE-2 — sources.md для ad-hoc-выхода: телеметрия окна + ручные строки   #
# --------------------------------------------------------------------------- #
# Дефект 2 фейлкейса 2026-08-11: ad-hoc-выход с 16 первоисточниками (включая два
# OCR-PDF) получил НОЛЬ машиночитаемого провенанса — инверсия против движкового пути,
# где sources.md пишется всегда. Причём срабатывает она на пути, который скилл
# санкционирует как допустимый минимум.
#
# Механизм. Провенанс не должен зависеть от того, вспомнил ли агент его задекларировать,
# поэтому источники берутся ТЕЛЕМЕТРИЕЙ: каждый ``lift_source`` пишет аудит-строку с
# путём, видом, префиксом хеша и ВРЕМЕНЕМ, а ``output_begin`` (DOD-2) фиксирует начало
# работы в ``meta.created``. Источники сессии = подъёмы в окне [начало работы .. сейчас].
#
# Автосекции сессионного провенанса (PROV-SESSION-1): те же правила, что у «## Файлы»/«## Связано» -
# детерминированный формат, по заголовку распознаются и пересобираются, чужой текст не трогается.
SESSION_READ_HEADING = "## Прочитано в сессии"
SESSION_SEARCH_HEADING = "## Поиск в сессии"
_ADHOC_MARKER = "Движок подбора не участвовал (`engine_run: false`)"
_SEARCH_NOTE = ("Это кандидаты, а не источники: что вернул поиск, не означает, что из этого "
                "что-то взято.")


def _search_section(searches: list[SearchRow]) -> str:
    if not searches:
        return ""
    return "\n".join([SESSION_SEARCH_HEADING, "", _SEARCH_NOTE, "",
                      *render_search_lines(searches)]) + "\n"


def render_adhoc_sources(
    rows: list[SourceRow],
    *,
    title: str = "",
    since: datetime | None = None,
    until: datetime | None = None,
    from_begin: bool = True,
    built_by: str = "",
    window: SessionWindow | None = None,
    searches: list[SearchRow] | None = None,
) -> str:
    """Markdown ``sources.md`` ad-hoc-выхода - форма движкового (таблица + шапка + поиск).

    Колонки: ``origin`` (read/lift/facts/manual и их сочетания), путь, вид, **дата источника**,
    префикс хеша, «взято», id заметки. Шапка честно говорит, откуда окно: сессия по журналу,
    постановка (``output_begin``), хост либо «окно, а не сессия». Поиски - отдельной секцией
    маркерами, НЕ таблицей (кандидаты, не источники).

    ``window`` - окно сессии (PROV-SESSION-1); без него работают прежние ``since``/``until``/
    ``from_begin`` (SRC-TRACE-2): совместимость для прямых вызовов.
    """
    if window is None and since is not None and until is not None:
        from core.provenance import KIND_BEGIN, KIND_HOURS

        window = SessionWindow(since, until, KIND_BEGIN if from_begin else KIND_HOURS)
    built = f"{built_by}\n\n" if built_by else ""
    search = _search_section(searches or [])
    return (
        f"# Sources — {title or 'ad-hoc'}\n\n"
        f"{built}"
        f"{_ADHOC_MARKER}: это НЕ чанки промпта, а "
        "первоисточники, которыми пользовалась работа - чтения (`read_note`), подъёмы файлов "
        "(`lift_source`), источники фактов (`get_facts`) сессии плюс объявленное вручную. Дата в "
        "каждой строке - дата самого источника: разрыв «источник 2023 года в документе 2026-го» "
        "виден сразу.\n\n"
        f"{render_window_line(window)}\n\n{render_source_table(rows)}\n"
        + (f"\n{search}" if search else "")
    )


def _own_adhoc_sources(target: Path) -> bool:
    """``sources.md`` написан САМИМ движком для ad-hoc-выхода в ТЕКУЩЕМ формате (а не чанки
    ``generate`` и не файл SRC-TRACE-2 без колонки ``note``: его строки ``telemetry`` пересборка
    потеряла бы - туда дописываются секции сессии, :func:`append_session_sections`)."""
    try:
        text = target.read_text(encoding="utf-8")
    except OSError:
        return False
    return _ADHOC_MARKER in text and "| взято | note |" in text


def write_adhoc_sources(
    out_dir: Path,
    rows: list[SourceRow],
    *,
    title: str = "",
    since: datetime | None = None,
    until: datetime | None = None,
    from_begin: bool = True,
    built_by: str = "",
    window: SessionWindow | None = None,
    searches: list[SearchRow] | None = None,
) -> Path | None:
    """Записать ``sources.md`` ad-hoc-выхода; ``None``, если писать нечего/нельзя.

    Гарды, оба про «не соврать и не затереть»:

    * **чужой ``sources.md`` не перетирается** - у папки от ``generate`` там лежат чанки
      промпта с политикой подбора (для них - :func:`append_session_sections`). Свой файл
      (ad-hoc, написанный движком) повторный ``save_output`` ПЕРЕСОБИРАЕТ; ручные строки
      прошлого вызова вызывающий переносит сам (:func:`previous_manual_rows`);
    * пустой список строк без поисков файла не создаёт - пустой ``sources.md`` выглядел бы как
      «источников не было», хотя мы просто ничего не знаем. Видимость этого - на ``warning``
      вызова и doctor-строке.
    """
    out_dir = Path(out_dir)
    target = out_dir / "sources.md"
    if target.exists() and not _own_adhoc_sources(target):
        return None
    if not rows and not searches:
        return None
    target.write_text(
        frontmatter_block(output_note_fields(out_dir, "sources.md", title=title or None))
        + render_adhoc_sources(
            rows, title=title, since=since, until=until, from_begin=from_begin,
            built_by=built_by, window=window, searches=searches,
        ),
        encoding="utf-8",
    )
    return target


def previous_manual_rows(out_dir: Path) -> list[SourceRow]:
    """Ручные строки (``sources=``) УЖЕ лежащего ``sources.md`` - повторный ``save_output`` их не
    теряет. Нет файла/нет таких строк - ``[]``; чанки ``generate`` под разбор не попадают."""
    try:
        text = (Path(out_dir) / "sources.md").read_text(encoding="utf-8")
    except OSError:
        return []
    return parse_manual_rows(text)


def session_sections_text(
    rows: list[SourceRow], searches: list[SearchRow], window: SessionWindow | None
) -> str:
    """Автосекции «## Прочитано в сессии» (+ «## Поиск в сессии») - ``""``, если нечего писать."""
    if not rows and not searches:
        return ""
    parts: list[str] = []
    if rows:
        window_line = render_window_line(window)
        parts.append("\n".join(
            [SESSION_READ_HEADING, "", *([window_line, ""] if window_line else []),
             render_source_table(rows)]) + "\n")
    search = _search_section(searches)
    if search:
        parts.append(search)
    return "\n".join(parts)


def _strip_session_sections(text: str) -> str:
    """Текст без наших автосекций сессии (заголовок … до следующего ``## ``)."""
    out: list[str] = []
    skipping = False
    for line in text.splitlines():
        stripped = line.strip()
        if stripped in (SESSION_READ_HEADING, SESSION_SEARCH_HEADING):
            skipping = True
            continue
        if skipping and stripped.startswith("## "):
            skipping = False
        if not skipping:
            out.append(line)
    return "\n".join(out).rstrip("\n") + "\n"


def append_session_sections(
    out_dir: Path,
    rows: list[SourceRow],
    searches: list[SearchRow],
    window: SessionWindow | None,
) -> Path | None:
    """Дописать автосекции сессии в УЖЕ лежащий ``sources.md`` (чанки промпта ``generate``).

    Движковый файл не перетирается - только свои секции в конец; повторный вызов пересобирает
    их (не дублирует). Читать было нечего (ни строк, ни поисков) - файл НЕ меняется (байт-
    идентично прежнему). Нет файла - не создаём (пустая таблица выглядела бы как «не было»).
    """
    target = Path(out_dir) / "sources.md"
    if not target.is_file():
        return None
    section = session_sections_text(rows, searches, window)
    if not section:
        return None
    current = target.read_text(encoding="utf-8")
    new = _strip_session_sections(current).rstrip("\n") + "\n\n" + section
    if new == current:
        return None
    target.write_text(new, encoding="utf-8")
    return target


def append_thread_coverage(out_dir: Path, lines: list[str]) -> Path | None:
    """OUT-COMPLETE-1: дописать в ``sources.md`` секцию полноты чтения почтовых тредов.

    Только по непустому списку (полностью прочитанный тред файл НЕ меняет — байт-идентично)
    и только в существующий ``sources.md``: файл, которого нет, не создаём из одной строки
    полноты (пустая таблица источников выглядела бы как «источников не было»).
    """
    target = Path(out_dir) / "sources.md"
    if not lines or not target.is_file():
        return None
    body = target.read_text(encoding="utf-8").rstrip("\n")
    section = "\n\n## Полнота чтения почтовых тредов\n\n" + "\n".join(f"- {ln}" for ln in lines)
    target.write_text(body + section + "\n", encoding="utf-8")
    return target


def missing_file_refs(
    file_refs: list[str] | None, *, vault_path: Path | None = None
) -> list[str]:
    """Какие ``file_refs`` НЕ находятся на диске (CONTRACT-1 ФП-7, С15).

    ``file_refs`` — ссылки на файловые deliverable, уже доставленные под ingest-корень:
    форма ``<root_name>/<rel>`` (её собирает ``save_output`` из ответа доставки),
    root-относительная или абсолютная. Проверка — по существованию файла: секция
    «## Файлы» в ``output.md`` не имеет права ссылаться в никуда, а узнать это через
    сутки по одному тексту уже нельзя.

    Это НЕ отказ (текст артефакта дороже подсказки) — вызывающий превращает результат в
    ``warning``. Ненастроенные корни / сбой конфига → ``[]`` (проверить нечем: молчим,
    а не выдумываем «файла нет»).
    """
    refs = [str(r).strip() for r in (file_refs or []) if str(r or "").strip()]
    if not refs:
        return []
    # DELIVER-2: ``vault:<путь от корня vault>`` - файл в папке выхода (``format`` без ``dest``).
    missing: list[str] = []
    ingest_refs: list[str] = []
    for ref in refs:
        if ref.startswith(_VAULT_REF_PREFIX):
            from core.config import default_vault_path

            base = Path(vault_path) if vault_path is not None else default_vault_path()
            if not (base / ref[len(_VAULT_REF_PREFIX):]).is_file():
                missing.append(ref)
        else:
            ingest_refs.append(ref)
    refs = ingest_refs
    if not refs:
        return missing
    try:
        from core.file_ingest.config import load_ingest_roots

        roots = {r.name: r.path for r in load_ingest_roots(vault_path)}
    except Exception:  # noqa: BLE001 — нет конфига → проверять нечем
        return missing
    if not roots:
        return missing

    for ref in refs:
        candidate = Path(ref).expanduser()
        if candidate.is_absolute():
            if not candidate.is_file():
                missing.append(ref)
            continue
        head, _, tail = ref.partition("/")
        found = False
        if tail and head in roots and (roots[head] / tail).is_file():
            found = True  # форма ``<root_name>/<rel>``
        if not found:
            found = any((root / ref).is_file() for root in roots.values())
        if not found:
            missing.append(ref)
    return missing


def related_hubs(paths: list[str], *, vault_path: Path | None = None) -> list[str]:
    """Существующие хабы клиентов/продуктов по сегментам путей источников.

    Пути хранилища структурированы (``…/Kazakhstan/Acme/КП.docx``), поэтому сегмент
    пути — это ярлык сущности. Реюз детерминированного матчинга линковки
    (:func:`core.legacy.linking.hubs_for_labels`): ``<prefix>-<slugify(сегмент)>`` и
    алиасы, но **только против существующих хаб-заметок** — выдуманных ``[[…]]`` не
    появляется by design. Порядок стабильный, дубли сняты.
    """
    labels: list[str] = []
    for raw in paths:
        p = Path(str(raw or ""))
        # имя файла не берём: сущность живёт в каталогах, а не в имени документа
        labels.extend(part for part in p.parent.parts if part not in ("/", ""))
    if not labels:
        return []
    try:
        from core.legacy.linking import entity_catalog, hubs_for_labels

        catalog = entity_catalog(vault_path or default_vault_path())
        return hubs_for_labels(labels, catalog)
    except Exception:  # noqa: BLE001 — связка не имеет права ронять сохранение выхода
        return []
