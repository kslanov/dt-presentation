"""EVAL-HYGIENE-1 п.4-5 - ретро-пометка прошлых выходов: ``dt outputs mark [--dry-run]``.

Прогоны golden-генерации и самопроверок за 29-31.10 лежат в ``07-outputs`` как обычные выходы, а
их docx - в живых папках клиентов. Здесь - тот же вывод, что у живого контура
(:func:`core.output.apply_purpose` - одна функция), по ПРОШЛЫМ папкам:

* ``eval`` - выход помечается (``purpose`` + ``eval_task`` в мете и frontmatter), доставленные
  файлы переезжают из папки клиента в ``<корень>/_eval/<ГГГГ-ММ>/<папка выхода>/``; запись
  ``meta.delivered`` получает новый путь и ``intended_dest`` (откуда). Выход НЕ удаляется:
  eval-история нужна (:func:`core.eval_generation.evaluate_generation` читает помеченные);
* ``selftest`` - мусор самопроверок, не знание: папка удаляется (с отчетом - что и откуда);
* ``work`` - не трогается.

Файл переносится, только если на диске ровно тот sha256, что записан в ``meta.delivered`` (наша
доставка; правленый снаружи/пропавший/dataless - пропуск с причиной, не потеря). Запись в vault -
только ``meta.yaml``/frontmatter движком и удаление selftest-папок (шеллом не пишем); файлы
клиента двигает ``shutil.move`` (iCloud: тот же том - rename) с отчетом «откуда → куда».
Идемпотентно: второй прогон ничего не находит. Отчет прогона пишется в
:func:`core.config.outputs_mark_path` (бэкап списка перед применением).

:func:`runs_status` - те же данные для доктора «Выходы: прогоны» (read-only).
"""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

from core import purpose as P
from core.config import default_vault_path, outputs_path
from core.privacy import is_eval

__all__ = ["MarkReport", "Move", "format_report", "plan", "run", "runs_status",
           "source_notes_index"]

logger = logging.getLogger(__name__)


@dataclass
class Move:
    root: str
    src: str  # rel_path у корня, откуда
    dst: str  # rel_path у корня, куда (под _eval)
    status: str = "planned"  # planned | moved | skipped
    reason: str = ""
    # Заметки vault (``source: files``), чей ``source_path`` - этот файл: ингест уже поднял docx
    # прогона как знание клиента, и без перевода ссылки досье/линт/поиск видят его дальше
    # (приемка 31.10: после переноса 2 docx в ``_eval`` досье ИТХ все еще несло 4 файла прогонов).
    notes: list[str] = field(default_factory=list)  # vault-относительные пути

    def to_dict(self) -> dict[str, Any]:
        return {"root": self.root, "from": self.src, "to": self.dst, "status": self.status,
                "reason": self.reason, "notes": list(self.notes)}


@dataclass
class Item:
    folder: str  # ГГГГ-ММ/<папка>
    purpose: str
    eval_task: str | None = None
    host: str = ""
    needs_mark: bool = False
    delete: bool = False
    moves: list[Move] = field(default_factory=list)
    files: list[str] = field(default_factory=list)  # что было в удаленной папке
    deleted: bool = False
    marked: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {"folder": self.folder, "purpose": self.purpose, "eval_task": self.eval_task,
                "host": self.host, "mark": self.needs_mark, "delete": self.delete,
                "deleted": self.deleted, "marked": self.marked,
                "moves": [m.to_dict() for m in self.moves], "files": self.files}


@dataclass
class MarkReport:
    dry_run: bool
    scanned: int = 0
    items: list[Item] = field(default_factory=list)
    problems: list[str] = field(default_factory=list)

    @property
    def counts(self) -> dict[str, int]:
        return {
            "eval": sum(1 for i in self.items if i.purpose == P.PURPOSE_EVAL),
            "selftest": sum(1 for i in self.items if i.purpose == P.PURPOSE_SELFTEST),
            "to_mark": sum(1 for i in self.items if i.needs_mark),
            "to_delete": sum(1 for i in self.items if i.delete),
            "files_to_move": sum(1 for i in self.items for m in i.moves
                                 if m.status in ("planned", "moved")),
            "files_skipped": sum(1 for i in self.items for m in i.moves
                                 if m.status == "skipped"),
        }

    def to_dict(self) -> dict[str, Any]:
        return {"dry_run": self.dry_run, "scanned": self.scanned, "counts": self.counts,
                "items": [i.to_dict() for i in self.items], "problems": self.problems}


def _root_dirs(vault: Path) -> dict[str, Path]:
    from core.file_ingest.config import load_ingest_roots

    return {r.name: Path(r.path) for r in load_ingest_roots(vault)}


def _prompt_body(folder: Path) -> str:
    from core.note_ids import split_frontmatter

    try:
        return split_frontmatter((folder / "prompt.md").read_text(encoding="utf-8"))[1]
    except OSError:
        return ""


def _sha_or_reason(path: Path) -> tuple[str | None, str]:
    """``(sha256, "")`` для локального файла; ``(None, причина)``: нет / не файл / dataless."""
    from core.file_ingest.write_target import sha256_file

    try:
        st = path.stat()
    except OSError:
        return None, "файла нет"
    if not path.is_file():
        return None, "не файл"
    if st.st_size > 0 and getattr(st, "st_blocks", 1) == 0:
        return None, "dataless (iCloud): сначала материализуйте файл"
    try:
        return sha256_file(path), ""
    except OSError as exc:
        return None, f"не читается: {exc}"


_SKIP_TOP = frozenset({".git", ".obsidian", "_system"})
_SOURCE_PATH_RE = re.compile(r"^source_path:[ \t]*(.+?)[ \t]*$", re.MULTILINE)
_SOURCE_INDEX: dict[str, dict[str, list[str]]] = {}


def source_notes_index(vault: Path) -> dict[str, list[str]]:
    """frontmatter ``source_path`` → vault-относительные пути заметок (один обход на процесс).

    Читается только шапка файла (первые 4 КБ): у заметок-источников frontmatter короткий, а
    тел тредов - мегабайты. Снимок ``fm_cache`` не используется: он отстает от диска, а ретро
    обязано видеть заметку, поднятую прошлой ночью."""
    key = str(vault)
    cached = _SOURCE_INDEX.get(key)
    if cached is not None:
        return cached
    index: dict[str, list[str]] = {}
    for path in sorted(vault.rglob("*.md")):
        rel = path.relative_to(vault).as_posix()
        if rel.split("/", 1)[0] in _SKIP_TOP:
            continue
        try:
            with path.open(encoding="utf-8", errors="replace") as fh:
                head = fh.read(4096)
        except OSError:
            continue
        if not head.startswith("---"):
            continue
        fm_end = head.find("\n---", 3)
        block = head[:fm_end] if fm_end > 0 else head
        m = _SOURCE_PATH_RE.search(block)
        if not m:
            continue
        raw = m.group(1).strip()
        if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in "'\"":
            raw = raw[1:-1]
        index.setdefault(raw.replace("\\", "/"), []).append(rel)
    _SOURCE_INDEX[key] = index
    return index


def _source_notes(vault: Path, rel_path: str) -> list[str]:
    return list(source_notes_index(vault).get(str(rel_path).replace("\\", "/"), []))


def _quarantine_source_notes(vault: Path, move: Move) -> None:
    """Заметки файла → ``source_path`` на адрес под ``_eval`` + ``purpose: eval`` (хирургически)."""
    from core.vault import set_frontmatter_fields

    for rel in move.notes:
        set_frontmatter_fields(
            vault / rel, {"source_path": move.dst, P.PURPOSE_KEY: P.PURPOSE_EVAL})


def _plan_moves(
    folder: Path, meta: dict, roots: dict[str, Path], month: str, vault: Path,
    *, force: bool = False,
) -> list[Move]:
    from core.output import VAULT_ROOT_NAME, delivered_records

    moves: list[Move] = []
    seen: set[tuple[str, str]] = set()
    for rec in delivered_records(meta):
        root, rel = str(rec.get("root") or ""), str(rec.get("rel_path") or "")
        if root == VAULT_ROOT_NAME or not root or is_eval(rel) or (root, rel) in seen:
            continue
        seen.add((root, rel))
        dst = f"_eval/{month}/{folder.name}/{Path(rel).name}"
        move = Move(root=root, src=rel, dst=dst, notes=_source_notes(vault, rel))
        base = roots.get(root)
        if base is None:
            move.status, move.reason = "skipped", f"корень {root!r} не найден в ingest-roots"
        else:
            sha, why = _sha_or_reason(base / rel)
            expected = str(rec.get("sha256") or "")
            if sha is None:
                move.status, move.reason = "skipped", why
            elif (base / dst).exists():
                move.status, move.reason = "skipped", "цель в _eval уже занята"
            elif expected and sha != expected and not force:
                move.status, move.reason = "skipped", "файл изменен после доставки (sha не наш)"
            elif expected and sha != expected:
                # Решение владельца: файл прогона правили снаружи, но это все равно прогон -
                # переносим, расхождение остается в отчете (и в delivered: sha доставки прежний).
                move.reason = "sha не наш - перенос по решению владельца (--force)"
        moves.append(move)
    return moves


def plan(vault_path: Path | None = None, *, force: bool = False) -> MarkReport:
    """Что нужно пометить/перенести/удалить - read-only (ничего не пишет).

    ``force`` - переносить и файлы с чужим sha (правлены после доставки): по решению владельца,
    когда прогон остается прогоном, как его ни правь; пропавшие/dataless - все равно пропуск."""
    from core.output import _purpose_meta, read_meta

    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    report = MarkReport(dry_run=True)
    base = outputs_path(vault)
    if not base.is_dir():
        return report
    roots = _root_dirs(vault)
    for month_dir in sorted(p for p in base.iterdir() if p.is_dir()):
        for folder in sorted(p for p in month_dir.iterdir() if p.is_dir()):
            meta = read_meta(folder / "meta.yaml")
            if not meta:
                continue
            report.scanned += 1
            found = _purpose_meta(
                texts=(str(meta.get("task") or ""), _prompt_body(folder)),
                title=str(meta.get("title") or ""), meta=meta, vault_path=vault)
            purpose = found.get(P.PURPOSE_KEY) or P.purpose_of(meta)
            if purpose == P.PURPOSE_WORK:
                continue
            raw_host = meta.get("host")
            item = Item(
                folder=f"{month_dir.name}/{folder.name}", purpose=purpose,
                eval_task=found.get(P.EVAL_TASK_KEY) or meta.get(P.EVAL_TASK_KEY),
                host=str(raw_host.get("name") or "") if isinstance(raw_host, dict) else "",
                needs_mark=any(meta.get(k) != v for k, v in found.items()),
                delete=purpose == P.PURPOSE_SELFTEST,
                moves=_plan_moves(folder, meta, roots, month_dir.name, vault, force=force),
            )
            if item.delete:
                item.files = sorted(str(p.relative_to(folder)) for p in folder.rglob("*")
                                    if p.is_file())
            report.items.append(item)
    return report


def _apply_move(folder: Path, root_dir: Path, move: Move, month: str, vault: Path) -> None:
    from core.output import _write_meta, delivered_records, read_meta

    src, dst = root_dir / move.src, root_dir / move.dst
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))
    move.status = "moved"
    _quarantine_source_notes(vault, move)
    meta = read_meta(folder / "meta.yaml")
    records = delivered_records(meta)
    old_ref = f"{move.root}/{move.src}"
    for rec in records:
        if rec.get("root") == move.root and rec.get("rel_path") == move.src:
            rec["rel_path"] = move.dst
            rec["intended_dest"] = f"{move.root}/{Path(move.src).parent.as_posix()}"
    meta["delivered"] = records
    _write_meta(folder / "meta.yaml", meta)
    note = folder / "output.md"
    try:
        text = note.read_text(encoding="utf-8")
    except OSError:
        return
    if old_ref in text:  # «## Файлы» указывает на фактический путь
        note.write_text(text.replace(old_ref, f"{move.root}/{move.dst}"), encoding="utf-8")


def run(vault_path: Path | None = None, *, dry_run: bool = False,
        now: datetime | None = None, force: bool = False) -> MarkReport:
    """Применить план (``dry_run`` - только план); отчет-бэкап списка - ``outputs_mark_path()``."""
    from core.output import apply_purpose

    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    report = plan(vault, force=force)
    report.dry_run = dry_run
    if dry_run:
        return report
    _write_report(report, now=now)  # список ДО изменений: потерянное восстанавливается по нему
    roots = _root_dirs(vault)
    base = outputs_path(vault)
    for item in report.items:
        month, name = item.folder.split("/", 1)
        folder = base / month / name
        try:
            if item.needs_mark:
                apply_purpose(folder, vault_path=vault)
                item.marked = True
            for move in item.moves:
                if move.status == "planned":
                    _apply_move(folder, roots[move.root], move, month, vault)
            if item.delete and all(m.status != "skipped" for m in item.moves):
                shutil.rmtree(folder)
                item.deleted = True
            elif item.delete:
                report.problems.append(
                    f"{item.folder}: selftest не удален - есть непереносимые файлы доставки")
        except Exception as exc:  # noqa: BLE001 - сбой одной папки не рвет остальные
            report.problems.append(f"{item.folder}: {exc}")
            logger.warning("[outputs mark] %s: %s", item.folder, exc)
    _write_report(report, now=now)
    return report


def _write_report(report: MarkReport, *, now: datetime | None = None) -> None:
    from core.config import outputs_mark_path

    path = outputs_mark_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"at": (now or datetime.now()).isoformat(timespec="seconds"),
                   **report.to_dict()}
        tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    except OSError as exc:  # отчет вторичен: перенос уже безопасен (sha-гард)
        logger.warning("[outputs mark] отчет не записан: %s", exc)


def format_report(report: MarkReport) -> str:
    c = report.counts
    head = "DRY-RUN (ничего не записано)" if report.dry_run else "применено"
    lines = [f"ВЫХОДЫ: ПРОГОНЫ ({head}) - просмотрено {report.scanned}, eval {c['eval']}, "
             f"selftest {c['selftest']}; пометить {c['to_mark']}, удалить {c['to_delete']}, "
             f"файлов перенести {c['files_to_move']} (пропущено {c['files_skipped']})"]
    for item in report.items:
        tag = item.purpose + (f"/{item.eval_task}" if item.eval_task else "")
        act = ("удалить" if item.delete else "") + (" пометить" if item.needs_mark else "")
        done = (" [удален]" if item.deleted else "") + (" [помечен]" if item.marked else "")
        lines.append(f"  {item.folder}  [{tag}] host={item.host or '-'}"
                     f"{' - ' + act.strip() if act.strip() else ''}{done}")
        for m in item.moves:
            arrow = f"{m.root}/{m.src}  ->  {m.root}/{m.dst}"
            lines.append(f"      {m.status:8} {arrow}" + (f"  ({m.reason})" if m.reason else ""))
            if m.notes:
                lines.append(f"      заметки файла → _eval ({len(m.notes)}): {', '.join(m.notes)}")
        if item.delete and item.files:
            lines.append(f"      файлы папки: {', '.join(item.files)}")
    lines.extend(f"  ! {p}" for p in report.problems)
    return "\n".join(lines)


def runs_status(vault_path: Path | None = None) -> dict[str, Any]:
    """Данные для доктора «Выходы: прогоны»: счета по назначению и что требует внимания.

    ``offside`` - прогоны с доставкой вне ``_eval`` (файл остался в папке клиента);
    ``selftest_folders`` - selftest-папки в ``07-outputs`` (мусор: ``dt outputs mark``);
    ``unmarked`` - папки, которые определяются как прогоны, но еще не помечены."""
    from core.output import delivered_records, read_meta

    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    rep = plan(vault)
    base = outputs_path(vault)
    offside: list[str] = []
    selftest_folders: list[str] = []
    counts = {P.PURPOSE_EVAL: 0, P.PURPOSE_SELFTEST: 0}
    unmarked: list[str] = []
    for item in rep.items:
        counts[item.purpose] = counts.get(item.purpose, 0) + 1
        if item.needs_mark:
            unmarked.append(item.folder)
        if item.purpose == P.PURPOSE_SELFTEST:
            selftest_folders.append(item.folder)
        meta = read_meta(base / item.folder / "meta.yaml")
        if any(r.get("root") != "vault" and not is_eval(str(r.get("rel_path") or ""))
               for r in delivered_records(meta)):
            offside.append(item.folder)
    return {"eval": counts[P.PURPOSE_EVAL], "selftest": counts[P.PURPOSE_SELFTEST],
            "offside": offside, "selftest_folders": selftest_folders, "unmarked": unmarked,
            "scanned": rep.scanned}
