"""PROV-SESSION-1 п.6 - ретро сессионного провенанса: ``dt outputs sources [--since] [--dry-run]``.

Выходы, сохраненные ДО PROV-SESSION-1, получили ``sources.md`` без чтений сессии (или вовсе без
него). Журнал запросов EVAL-2 ведется с 24.10 и хранит ``read``/``facts``/``search`` с ``host``
и временем: этого достаточно, чтобы восстановить сегмент сессии. ``sid`` у старых записей нет,
поэтому сегмент - по ``host`` + времени (:func:`core.provenance.session_window` в режиме
``by_host``), а границы соседних сохранений - по аудиту ``pult-actions.log`` (``save_output``).

Для каждого рабочего выхода, окно которого покрыто журналом, ДОПИСЫВАЮТСЯ автосекции
«## Прочитано в сессии»/«## Поиск в сессии» (ad-hoc-выход без ``sources.md`` получает файл
целиком). Пишет тот же движковый писатель, что и живой ``save_output``
(:func:`core.output.append_session_sections` / ``write_adhoc_sources``): в vault шеллом не пишем.
Идемпотентно: выход, у которого секции уже есть, во второй раз пропускается; нечего дописывать -
файл не меняется. Список ДО изменений и итог пишутся в :func:`core.config.outputs_sources_path`.

:func:`provenance_status` - данные для доктора «Выходы: провенанс» (read-only).
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.config import default_vault_path, outputs_path

__all__ = ["SourcesItem", "SourcesReport", "format_report", "plan", "provenance_status", "run"]

logger = logging.getLogger(__name__)

_REAL = ("read", "lift", "facts", "telemetry")  # происхождения, собранные движком (не руками)


@dataclass
class SourcesItem:
    folder: str  # ГГГГ-ММ/<папка>
    host: str = ""
    kind: str = ""  # вид окна: begin | host | hours
    since: str = ""
    until: str = ""
    read: int = 0
    lift: int = 0
    facts: int = 0
    searches: int = 0
    status: str = "planned"  # planned | written | already | skipped | nothing
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


@dataclass
class SourcesReport:
    dry_run: bool
    scanned: int = 0
    journal_since: str = ""
    items: list[SourcesItem] = field(default_factory=list)
    problems: list[str] = field(default_factory=list)

    @property
    def counts(self) -> dict[str, int]:
        def n(status: str) -> int:
            return sum(1 for i in self.items if i.status == status)

        return {"to_write": n("planned"), "written": n("written"), "already": n("already"),
                "skipped": n("skipped"), "nothing": n("nothing")}

    def to_dict(self) -> dict[str, Any]:
        return {"dry_run": self.dry_run, "scanned": self.scanned,
                "journal_since": self.journal_since, "counts": self.counts,
                "items": [i.to_dict() for i in self.items], "problems": self.problems}


def _local(raw: Any) -> datetime | None:
    """Метка меты (локальное время без пояса) → aware UTC."""
    try:
        value = datetime.fromisoformat(str(raw).strip())
    except ValueError:
        return None
    return (value.astimezone() if value.tzinfo is None else value).astimezone(UTC)


def _is_adhoc(meta: dict[str, Any]) -> bool:
    from core.output import SOURCE_ADHOC

    return meta.get("engine_run") is False or meta.get("source") == SOURCE_ADHOC


def _saved_at(folder: Path, meta: dict[str, Any],
              saves: dict[str, datetime]) -> datetime | None:
    """Когда выход СОХРАНЕН: аудит ``save_output`` (последнее по этой папке) → ``finalized`` →
    ``created`` (у ad-hoc DOD-1 это время сохранения) → mtime ``output.md``."""
    at = saves.get(str(folder))
    if at is not None:
        return at
    for key in ("finalized", "created"):
        when = _local(meta.get(key))
        if when is not None:
            return when
    try:
        return datetime.fromtimestamp((folder / "output.md").stat().st_mtime, UTC)
    except OSError:
        return None


def _saves_by_folder(since: datetime) -> dict[str, datetime]:
    from core.operational.pult import read_actions

    out: dict[str, datetime] = {}
    for action in read_actions(tools=("save_output",), since=since):
        p = action.args.get("path", "")
        if p.endswith("output.md"):
            out[str(Path(p).parent)] = action.at  # старые сверху: останется последнее
    return out


def _has_session_sections(text: str) -> bool:
    from core.output import SESSION_READ_HEADING, SESSION_SEARCH_HEADING

    heads = {ln.strip() for ln in text.splitlines()}
    return SESSION_READ_HEADING in heads or SESSION_SEARCH_HEADING in heads


def _journal_start() -> datetime | None:
    from core.eval_journal import read_events

    events = read_events(include_selftest=True)
    if not events:
        return None
    first = events[0]["ts"]
    return datetime.strptime(str(first), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)


def plan(vault_path: Path | None = None, *, since: str | None = None,
         now: datetime | None = None) -> SourcesReport:
    """Что дописать - read-only (ничего не пишет)."""
    from core.eval_journal import read_events
    from core.output import read_meta
    from core.provenance import collect_session_sources, session_window
    from core.purpose import is_quarantined

    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    report = SourcesReport(dry_run=True)
    base = outputs_path(vault)
    start = _journal_start()
    report.journal_since = start.strftime("%Y-%m-%d") if start else ""
    if not base.is_dir():
        return report
    floor = datetime.strptime(since, "%Y-%m-%d").replace(tzinfo=UTC) if since else None
    events = read_events()
    saves = _saves_by_folder(start or datetime(2000, 1, 1, tzinfo=UTC))
    for month_dir in sorted(p for p in base.iterdir() if p.is_dir()):
        for folder in sorted(p for p in month_dir.iterdir() if p.is_dir()):
            meta = read_meta(folder / "meta.yaml")
            if not meta or not (folder / "output.md").is_file() or is_quarantined(meta):
                continue
            report.scanned += 1
            raw_host = meta.get("host")
            host = str(raw_host.get("name") or "") if isinstance(raw_host, dict) else ""
            item = SourcesItem(folder=f"{month_dir.name}/{folder.name}", host=host)
            until = _saved_at(folder, meta, saves)
            if until is None or (floor is not None and until < floor):
                continue
            item.until = until.strftime("%Y-%m-%dT%H:%M:%SZ")
            sources = folder / "sources.md"
            text = sources.read_text(encoding="utf-8") if sources.is_file() else None
            if text is not None and _has_session_sections(text):
                item.status, item.reason = "already", "секции сессии уже есть"
            elif start is None or until < start:
                item.status = "skipped"
                item.reason = f"журнал запросов не покрывает ({report.journal_since or 'пуст'})"
            elif not host:
                item.status, item.reason = "skipped", "в мете нет host - сегмент не определить"
            elif text is None and not _is_adhoc(meta):
                item.status, item.reason = "skipped", "движковый выход без sources.md"
            else:
                window = session_window(folder, "", host, now=until, by_host=True, events=events)
                prov = collect_session_sources(folder, window, "", host, by_host=True,
                                               vault_path=vault, events=events)
                item.kind = window.kind
                item.since = window.since.strftime("%Y-%m-%dT%H:%M:%SZ")
                item.read, item.lift = prov.count("read"), prov.count("lift")
                item.facts, item.searches = prov.count("facts"), len(prov.searches)
                if not prov.rows and not prov.searches:
                    item.status, item.reason = "nothing", "в окне журнал пуст"
            report.items.append(item)
    return report


def _apply(vault: Path, item: SourcesItem, events: list[dict[str, Any]]) -> None:
    from core.output import (
        append_session_sections,
        provenance_line,
        read_meta,
        write_adhoc_sources,
    )
    from core.provenance import collect_session_sources, session_window

    month, name = item.folder.split("/", 1)
    folder = outputs_path(vault) / month / name
    meta = read_meta(folder / "meta.yaml")
    until = datetime.strptime(item.until, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)
    host = item.host
    window = session_window(folder, "", host, now=until, by_host=True, events=events)
    prov = collect_session_sources(folder, window, "", host, by_host=True, vault_path=vault,
                                   events=events)
    sources = folder / "sources.md"
    if sources.is_file():
        existing = sources.read_text(encoding="utf-8")
        rows = [r for r in prov.rows if r.path not in existing]  # уже в таблице выше
        written = append_session_sections(folder, rows, prov.searches, window)
    else:
        written = write_adhoc_sources(
            folder, prov.rows, title=str(meta.get("title") or ""), window=window,
            searches=prov.searches, built_by=provenance_line(meta))
    item.status = "written" if written is not None else "nothing"
    if written is None:
        item.reason = "нечего дописать"


def run(vault_path: Path | None = None, *, since: str | None = None, dry_run: bool = False,
        now: datetime | None = None) -> SourcesReport:
    """Применить план (``dry_run`` - только план); список/итог - ``outputs_sources_path()``."""
    from core.eval_journal import read_events

    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    report = plan(vault, since=since, now=now)
    report.dry_run = dry_run
    if dry_run:
        return report
    _write_report(report, now=now)  # список ДО изменений
    events = read_events()
    for item in report.items:
        if item.status != "planned":
            continue
        try:
            _apply(vault, item, events)
        except Exception as exc:  # noqa: BLE001 - сбой одной папки не рвет остальные
            item.status, item.reason = "skipped", f"ошибка: {exc}"
            report.problems.append(f"{item.folder}: {exc}")
            logger.warning("[outputs sources] %s: %s", item.folder, exc)
    _write_report(report, now=now)
    return report


def _write_report(report: SourcesReport, *, now: datetime | None = None) -> None:
    from core.config import outputs_sources_path

    path = outputs_sources_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"at": (now or datetime.now()).isoformat(timespec="seconds"),
                   **report.to_dict()}
        tmp = path.with_name(path.name + f".tmp-{os.getpid()}")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)
    except OSError as exc:  # отчет вторичен: дописывание только добавляет секции
        logger.warning("[outputs sources] отчет не записан: %s", exc)


def format_report(report: SourcesReport) -> str:
    c = report.counts
    head = "DRY-RUN (ничего не записано)" if report.dry_run else "применено"
    covered = [i for i in report.items if i.status in ("planned", "written", "already", "nothing")]
    lines = [f"ВЫХОДЫ: ПРОВЕНАНС СЕССИИ ({head}) - просмотрено {report.scanned}, журнал с "
             f"{report.journal_since or '-'}; покрыто журналом {len(covered)}; дописать "
             f"{c['to_write']}, дописано {c['written']}, уже есть {c['already']}, "
             f"нечего {c['nothing']}, пропущено {c['skipped']}"]
    for i in report.items:
        stats = f"read {i.read}, lift {i.lift}, facts {i.facts}, поисков {i.searches}"
        tail = f"  ({i.reason})" if i.reason else ""
        if i.status in ("planned", "written", "nothing", "already"):
            lines.append(f"  {i.status:8} {i.folder}  host={i.host or '-'} "
                         f"окно={i.kind or '-'}  {stats}{tail}")
        else:
            lines.append(f"  {i.status:8} {i.folder}{tail}")
    lines.extend(f"  ! {p}" for p in report.problems)
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# Доктор                                                                        #
# --------------------------------------------------------------------------- #
def _classify(sources: Path) -> str:
    """``telemetry`` | ``manual`` | ``none`` по таблицам ``sources.md`` ad-hoc-выхода."""
    try:
        text = sources.read_text(encoding="utf-8")
    except OSError:
        return "none"
    origins: set[str] = set()
    for line in text.splitlines():
        if not line.startswith("|"):
            continue
        cell = line.strip().strip("|").split("|", 1)[0].strip()
        if cell and set(cell) - set("-: ") and cell not in ("origin", "note_id") \
                and not cell.startswith("(none"):
            origins.update(cell.split("+"))
    if origins & set(_REAL) or "## Поиск в сессии" in text:
        return "telemetry"
    return "manual" if "manual" in origins else "none"


def provenance_status(vault_path: Path | None = None, *, now: datetime | None = None,
                      days: int = 30, recent_days: int = 7) -> dict[str, Any]:
    """Данные для доктора «Выходы: провенанс»: за ``days`` дн ad-hoc-выходы с телеметрией сессии
    / только руками / без провенанса; ``recent_none`` - без провенанса за ``recent_days``.
    Движковые (``generate``) выходы считаются отдельно - у них провенанс-чанки пишет движок."""
    from core.eval_journal import enabled
    from core.output import read_meta
    from core.purpose import is_quarantined

    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    stamp = now or datetime.now(UTC)
    base = outputs_path(vault)
    st: dict[str, Any] = {"total": 0, "telemetry": 0, "manual": 0, "none": 0, "engine": 0,
                          "recent_none": [], "journal_on": enabled()}
    if not base.is_dir():
        return st
    for month_dir in sorted(p for p in base.iterdir() if p.is_dir()):
        for folder in sorted(p for p in month_dir.iterdir() if p.is_dir()):
            meta = read_meta(folder / "meta.yaml")
            if not meta or not (folder / "output.md").is_file() or is_quarantined(meta):
                continue
            when = _saved_at(folder, meta, {})
            if when is None or when < stamp - timedelta(days=days):
                continue
            if not _is_adhoc(meta):
                st["engine"] += 1
                continue
            kind = _classify(folder / "sources.md")
            st["total"] += 1
            st[kind] += 1
            if kind == "none" and when >= stamp - timedelta(days=recent_days):
                st["recent_none"].append(f"{month_dir.name}/{folder.name}")
    return st
