"""PROFILE-1: профиль владельца в vault - один источник личности для генерации, приватности почты,
доктора и хостов (дизайн ``docs/design-profile-1-owner-boundary.md`` §2).

Именование: ``owner_*`` / ``core.owner`` - слово «профиль» в движке занято профилями инструментов
(``lean|pult|full``). Движок профиль только читает; создает один раз ``dt owner init``.
"""

from __future__ import annotations

from core.owner.schema import PLACEHOLDER_NAME, OwnerData, OwnerIssue, parse_owner_yaml
from core.owner.store import (
    ABOUT_FILE,
    OWNER_FILE,
    RULES_FILE,
    OwnerProfile,
    load_profile,
    meaningful,
    profile_dir,
    strip_hints,
)

__all__ = [
    "ABOUT_FILE",
    "OWNER_FILE",
    "OwnerData",
    "OwnerIssue",
    "OwnerProfile",
    "PLACEHOLDER_NAME",
    "RULES_FILE",
    "load_profile",
    "meaningful",
    "parse_owner_yaml",
    "profile_dir",
    "strip_hints",
]
