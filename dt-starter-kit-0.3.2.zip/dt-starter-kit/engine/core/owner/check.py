"""PROFILE-1: проверка профиля владельца - одна функция для ``dt owner check``, доктора
«Профиль владельца» и сводки пульта (``pult_settings_get.owner``).

``ok`` - ``owner.yaml`` валиден, есть ``name`` + хотя бы один вариант имени + хотя бы одна почта,
``about.md`` непустой, дублей с ``.env`` нет. ``warn`` - любое из: профиля нет; схема битая (есть
замечания); личность неполна; ``about.md`` пуст; дубль источника с ``.env``; в силе плейсхолдер
``the user`` (имя нигде не задано). Чистая функция от профиля и окружения: ничего не читает сама.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import datetime

from core.owner.domains import env_domain_list, owner_domains
from core.owner.schema import PLACEHOLDER_NAME
from core.owner.store import ABOUT_FILE, FILES, OwnerProfile

__all__ = ["OwnerStatus", "env_duplicates", "evaluate", "settings_view"]

# Переменные-«добавка», которые профиль заменяет: имя и токены личности.
_LEGACY_KEYS = ("DT_USER_NAME", "DT_OUTLOOK_SELF_TOKENS")


@dataclass(frozen=True)
class OwnerStatus:
    status: str  # ok | warn
    summary: str  # одна строка для доктора/пульта
    problems: list[str] = field(default_factory=list)
    hint: str = ""


def _json_list(raw: str | None) -> list[str]:
    if not raw or not raw.strip():
        return []
    try:
        data = json.loads(raw)
    except ValueError:
        return []
    return [str(x).strip() for x in data if str(x).strip()] if isinstance(data, list) else []


def env_duplicates(profile: OwnerProfile, environ: Mapping[str, str]) -> list[str]:
    """Ключи ``.env``, которые дублируют профиль или расходятся с ним (``[]`` - чисто).

    Только ИМЕНА ключей и характер замечания, без значений. Нет профиля - нечему дублироваться.
    ``DT_TIMETTA_USER_EMAIL`` не считается: он нужен Timetta независимо от профиля."""
    if not profile.exists:
        return []
    out: list[str] = []
    known = {t.lower() for t in profile.identity_tokens}
    user_name = (environ.get("DT_USER_NAME") or "").strip()
    if user_name and user_name.lower() != PLACEHOLDER_NAME and profile.name:
        if user_name.lower() in known:
            out.append("DT_USER_NAME: дубль имени из профиля")
        else:
            out.append("DT_USER_NAME: расходится с профилем (действует профиль)")
    tokens = _json_list(environ.get("DT_OUTLOOK_SELF_TOKENS"))
    same = [t for t in tokens if t.lower() in known]
    if same:
        out.append(f"DT_OUTLOOK_SELF_TOKENS: {len(same)} из {len(tokens)} токенов уже в профиле")
    return out


def mail_expected() -> bool:
    """Есть ли у экземпляра почта: роль объявляет коннектор Outlook и он включен."""
    from core import connectors
    from core.surface import manifest

    return "outlook" in manifest.surface().connectors and connectors.enabled("outlook")


def evaluate(
    profile: OwnerProfile, environ: Mapping[str, str], *, mail: bool | None = None,
) -> OwnerStatus:
    """Статус профиля; ``environ`` - действующее окружение (после ``load_env``). ``mail`` - есть ли
    у экземпляра почта (``None`` - по роли и коннектору Outlook): без нее домены не нужны."""
    mail = mail_expected() if mail is None else mail
    if not profile.exists:
        return OwnerStatus(
            "warn", "профиля нет", ["профиля нет"],
            "dt owner init - создать из текущих источников (_system/profile)")
    problems: list[str] = []
    hints: list[str] = []
    if profile.issues:
        problems.append("схема owner.yaml: " + "; ".join(str(i) for i in profile.issues[:3])
                        + (f" (+{len(profile.issues) - 3})" if len(profile.issues) > 3 else ""))
        hints.append("поправить owner.yaml в Obsidian, затем dt owner check")
    data = profile.data
    gaps = [label for label, ok in (("name", bool(data.name)),
                                    ("name_variants", bool(data.name_variants)),
                                    ("emails", bool(data.emails))) if not ok]
    if gaps:
        problems.append("личность неполна: нет " + ", ".join(gaps))
        hints.append("заполнить owner.yaml: name_variants вычитаются из пробы приватности почты")
    if mail and not owner_domains(profile) and not env_domain_list(
            environ.get("DT_MAIL_OWNER_DOMAINS")):
        problems.append("домены владельца не заданы: вся почта станет внешней")
        hints.append("owner.yaml: emails (домены берутся из адресов) или company.domains")
    if not profile.about:
        problems.append(f"{ABOUT_FILE} пуст")
        hints.append("about.md идет в промпт generate секцией [Owner]: 1-2 экрана о владельце")
    dups = env_duplicates(profile, environ)
    if dups:
        problems.append("дубль источника с .env (" + "; ".join(dups) + ")")
        hints.append("перенесите в профиль, уберите из .env: DT_USER_NAME / DT_OUTLOOK_SELF_TOKENS")
    env_name = (environ.get("DT_USER_NAME") or "").strip()
    if not data.name and (not env_name or env_name.lower() == PLACEHOLDER_NAME):
        problems.append(f"в силе плейсхолдер «{PLACEHOLDER_NAME}» (имя нигде не задано)")
    if problems:
        return OwnerStatus("warn", "; ".join(problems), problems, "; ".join(dict.fromkeys(hints)))
    rules = f"rules {len(profile.rules)} симв." if profile.rules else "rules.md пуст"
    summary = (f"{data.name}; вариантов {len(data.name_variants)}, почт {len(data.emails)}; "
               f"about {len(profile.about)} симв., {rules}; версия {profile.version}")
    return OwnerStatus("ok", summary)


def _updated(profile: OwnerProfile) -> str:
    """Дата обновления: ``updated`` из ``owner.yaml``, иначе самая свежая правка файлов профиля."""
    if profile.data.updated:
        return profile.data.updated[:10]
    stamps = []
    for name in FILES:
        try:
            stamps.append((profile.path / name).stat().st_mtime)
        except OSError:
            continue
    return datetime.fromtimestamp(max(stamps)).strftime("%Y-%m-%d") if stamps else ""


def settings_view(profile: OwnerProfile, environ: Mapping[str, str]) -> dict[str, object]:
    """Сводка для пульта (``pult_settings_get.owner``) - read-only, тем же ``evaluate``, что доктор.

    ``{exists, name, updated, version, status, summary, hint, missing}``: «Владелец: имя · профиль
    обновлен дата · статус доктора». Ни ``about``, ни ``rules`` сюда не идут (их отдает
    ``owner_profile``): пульт показывает состояние, а не содержимое."""
    res = evaluate(profile, environ)
    name = profile.name or (environ.get("DT_USER_NAME") or "").strip()
    return {
        "exists": profile.exists,
        "name": "" if name.lower() == PLACEHOLDER_NAME else name,
        "updated": _updated(profile) if profile.exists else "",
        "version": profile.version,
        "status": res.status,
        "summary": res.summary,
        "hint": res.hint,
        "missing": profile.missing,
    }
