"""DEV-3-CORE п.1: почтовые домены владельца - из профиля, не из кода.

* «свои» (участник с таким доменом - мы, остальные - контрагенты): домены адресов ``emails`` ∪
  ``company.domains`` профиля;
* «служебные» (инфраструктура/группа, не контрагенты для фида «Работа»):
  ``company.internal_domains``.

Дефолта в коде нет: пустой профиль - пустые списки (вся почта станет внешней; об этом предупреждают
``dt config check`` и доктор «Профиль владельца»). Env-добавки (``DT_MAIL_OWNER_DOMAINS``,
``DT_MAIL_INTERNAL_DOMAINS``) подмешивает ``core.config``; здесь - только профиль."""

from __future__ import annotations

import json

from core.owner.store import OwnerProfile

__all__ = ["email_domains", "env_domain_list", "internal_domains", "owner_domains"]


def env_domain_list(raw: str | None) -> list[str]:
    """Env-список доменов (``DT_MAIL_OWNER_DOMAINS`` и т.п.): JSON-массив либо через запятую."""
    if not raw or not raw.strip():
        return []
    text = raw.strip()
    items: list[str]
    if text.startswith("["):
        try:
            data = json.loads(text)
        except ValueError:
            return []
        items = [str(x) for x in data] if isinstance(data, list) else []
    else:
        items = text.split(",")
    return list(dict.fromkeys(i.strip().lower().lstrip("@") for i in items if i.strip()))


def email_domains(emails: tuple[str, ...] | list[str]) -> list[str]:
    """Домены адресов (нижний регистр, без повторов, порядок появления)."""
    out: list[str] = []
    for addr in emails:
        dom = addr.rsplit("@", 1)[-1].strip().lower() if "@" in addr else ""
        if dom and dom not in out:
            out.append(dom)
    return out


def owner_domains(profile: OwnerProfile) -> list[str]:
    """Свои домены профиля: домены ``emails`` ∪ ``company.domains``."""
    data = profile.data
    return list(dict.fromkeys([*email_domains(data.emails), *data.company_domains]))


def internal_domains(profile: OwnerProfile) -> list[str]:
    """Служебные домены профиля (``company.internal_domains``)."""
    return list(profile.data.company_internal_domains)
