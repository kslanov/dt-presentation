"""PROFILE-1 п.4: правила владельца - хостам: скилл ``dt-owner`` и markdown для вставки в память.

Один текст на оба выхода: ``rules.md`` + первый абзац ``about.md`` (≤ 600 символов, по границе
предложения - SURFACE-HYGIENE-1, раньше резало по 5 строкам посреди фразы) + шапка
«источник, версия, не править руками». Скилл ГЕНЕРИРУЕТСЯ при экспорте
(``dt skills export cowork|kimi|cherry``), в git его нет; профиля нет или ``rules.md`` пуст -
скилл не создается, причина идет в ``skipped``.

Экспорт не несет путей vault (линтер переносимости зеленый): шапка называет источник словами,
а не путем. Если текст профиля сам нарушает линтер (вендорное имя, путь vault, незнакомый
инструмент), скилл не создается и причина - нарушения линтера: правка в vault, а не в экспорте.
"""

from __future__ import annotations

import re
from collections.abc import Iterable
from pathlib import Path

import yaml  # type: ignore[import-untyped]  # стаб-гэп PyYAML - как в core.skills

from core.owner.store import OwnerProfile
from core.skills import LintIssue, Skill, lint_skills

__all__ = ["ABOUT_MAX_CHARS", "SKILL_NAME", "export_markdown", "owner_skill"]

SKILL_NAME = "dt-owner"
ABOUT_MAX_CHARS = 600  # потолок выдержки about.md в экспорте: первый абзац целиком, но не длиннее

_SOURCE_LINE = (
    "Источник: профиль владельца в vault (каталог _system/profile), версия {version}. "
    "Не править руками: правится в vault, затем `dt skills export`."
)
_FRESH_LINE = "Актуальные правила и сведения о владельце: инструмент `owner_profile()`."


_COMMENT_RE = re.compile(r"<!--.*?-->", re.S)
_SENTENCE_END_RE = re.compile(r"[.!?…](?=\s|$)")


def _about_lines(about: str) -> list[str]:
    """Выдержка ``about.md``: ПЕРВЫЙ абзац целиком (строки без заголовков; HTML-комментарии шаблона
    не в счет), не длиннее :data:`ABOUT_MAX_CHARS`. Длинный абзац режется по границе
    предложения (последний ``.!?…`` в пределах лимита); нет границы - по пробелу с «…». Фраза
    посередине не обрывается."""
    text = _COMMENT_RE.sub("", about)
    paragraph: list[str] = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            if paragraph:
                break  # заголовок закрывает абзац
            continue
        if not stripped:
            if paragraph:
                break
            continue
        paragraph.append(stripped)
    body = "\n".join(paragraph)
    if len(body) > ABOUT_MAX_CHARS:
        head = body[:ABOUT_MAX_CHARS]
        ends = [m.end() for m in _SENTENCE_END_RE.finditer(head)]
        if ends:
            body = head[: ends[-1]].rstrip()
        else:
            body = head[: head.rstrip().rfind(" ")].rstrip(" ,;:-") + "…"
    return body.split("\n") if body else []


def _without_h1(text: str) -> str:
    """Убрать ведущий ``# Заголовок`` rules.md: в экспорте над ним уже стоит ``## Правила``."""
    lines = text.splitlines()
    if lines and lines[0].startswith("# "):
        lines = lines[1:]
    return "\n".join(lines).strip()


def export_markdown(profile: OwnerProfile) -> tuple[str | None, str]:
    """``(текст, причина)``: текст для памяти клиента / тела скилла; ``None`` + причина.

    Нет профиля или пуст ``rules.md`` - выдавать нечего (правила и есть предмет экспорта)."""
    if not profile.exists:
        return None, "нет профиля владельца (dt owner init)"
    if not profile.rules:
        return None, "rules.md пуст (правила не заполнены)"
    title = "# Правила работы с владельцем" + (f": {profile.name}" if profile.name else "")
    parts = [title, "", _SOURCE_LINE.format(version=profile.version), ""]
    about = _about_lines(profile.about)
    if about:
        parts += ["## О владельце", "", *about, ""]
    parts += ["## Правила", "", _without_h1(profile.rules), "", _FRESH_LINE]
    return "\n".join(parts) + "\n", ""


def owner_skill(
    profile: OwnerProfile, tool_names: Iterable[str]
) -> tuple[Skill | None, str]:
    """Скилл ``dt-owner`` из профиля: ``(Skill, "")`` или ``(None, причина)``.

    ``tool_names`` - реестр инструментов (для линтера: вызовы ``имя(`` только из него)."""
    body, reason = export_markdown(profile)
    if body is None:
        return None, reason
    who = f" ({profile.name})" if profile.name else ""
    description = (
        f"Правила работы с владельцем{who}: что делать и чего не делать любому ассистенту "
        f"при работе с этим владельцем; из профиля владельца, версия {profile.version}."
    )
    header = yaml.safe_dump({"name": SKILL_NAME, "description": description},
                            allow_unicode=True, sort_keys=False, width=10**6).rstrip("\n")
    skill = Skill(name=SKILL_NAME, description=description, body=body,
                  text=f"---\n{header}\n---\n\n{body}", path=Path(SKILL_NAME) / "SKILL.md")
    issues: list[LintIssue] = lint_skills([skill], tool_names)
    if issues:
        found = "; ".join(f"[{i.code}] {i.message}" for i in issues[:3])
        return None, f"линтер переносимости: {found}"
    return skill, ""
