"""PROFILE-1: ``dt owner init`` - создать профиль владельца из текущих источников (один раз).

Источники: имя - ``DT_USER_NAME``; варианты имени и свои адреса - ``DT_OUTLOOK_SELF_TOKENS``
(токен с ``@`` - в ``emails``, остальное - в ``name_variants``); почта - ``DT_TIMETTA_USER_EMAIL``;
``privacy.people`` - ``DT_LEGACY_PRIVACY_NAMES`` плюс явный аргумент ``people`` (фамилии коллег
в коде движка больше не живут, взять их автоматически неоткуда); ``company.domains`` /
``company.internal_domains`` - добавки ``DT_MAIL_OWNER_DOMAINS`` / ``DT_MAIL_INTERNAL_DOMAINS``.
**Миграция формы (DEV-3-CORE):** существующий ``owner.yaml`` со строкой ``company: <название>``
переписывается в объект ``company: {name, domains, internal_domains}`` (бэкап ``.bak-<ts>``,
остальные строки и комментарии файла не трогаются; домены - из тех же env-добавок).
``about.md``/``rules.md`` - шаблоны:
заголовки и подсказки в HTML-комментариях, выдуманного текста нет (файл из одних подсказок считается
пустым - :func:`core.owner.store.meaningful`).

Секретов init не пишет: имя/варианты/почта - не секреты, токены доступа сюда не попадают. Повторный
запуск без ``force`` ничего не перезаписывает (файл за файлом: существующий пропускается); с
``force`` - перезапись с бэкапом ``<файл>.bak-<ts>``. Запись - атомарная (temp+rename, как правка
конфигов), каждый
вызов - аудит-строка ``owner_init`` (``record_action``: идентификаторы и счетчики, без содержимого).
"""

from __future__ import annotations

import json
import os
import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path

import yaml  # type: ignore[import-untyped]  # стаб-гэп PyYAML - как в core.skills

from core.mcp_json_edit import backup_file, write_text_atomic
from core.owner.domains import env_domain_list
from core.owner.schema import PLACEHOLDER_NAME, parse_owner_yaml
from core.owner.store import ABOUT_FILE, FILES, OWNER_FILE, RULES_FILE, profile_dir

__all__ = [
    "ABOUT_TEMPLATE", "InitResult", "RULES_TEMPLATE", "init_profile", "migrate_company_text",
    "render_owner_yaml",
]

ABOUT_TEMPLATE = """\
# О владельце

<!-- Этот файл целиком идет в промпт генерации (секция [Owner]): 1-2 экрана свободного текста.
     Пиши только рабочую персону; личное (семья, здоровье, финансы) сюда не пишем.
     Подсказки в комментариях в промпт не попадают; файл без текста, кроме заголовков, пуст. -->

## Кто я и чем занимаюсь

<!-- роль, компания, зона ответственности -->

## Орбита

<!-- направления, ключевые клиенты по именам хабов, продукты -->

## Для кого пишу и как получать результат

<!-- адресаты текстов, предпочтения по форме и длине -->
"""

RULES_TEMPLATE = """\
# Правила работы с владельцем

<!-- Процедурные правила для ЛЮБОГО ассистента/хоста: отдаются инструментом owner_profile и
     скиллом dt-owner. В промпт генерации не идут (стиль закрывает канон ai-markers).
     Один пункт - одно правило, коротко, с причиной при необходимости. -->

## Как работать

<!-- например: что не предлагать, что проверять до сдачи -->

## Тексты и стиль

<!-- ссылки на каноны стиля, самопроверка -->

## Границы

<!-- что ассистент не делает сам (отправка писем, запись в CRM...) -->
"""


@dataclass
class InitResult:
    directory: Path
    created: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)  # уже были, без --force не тронуты
    backups: list[str] = field(default_factory=list)
    migrated: list[str] = field(default_factory=list)  # старая форма owner.yaml переписана
    refilled: list[str] = field(default_factory=list)  # пустой owner.yaml шаблона vault дозаполнен
    sources: dict[str, int] = field(default_factory=dict)  # что нашли (счетчики, не значения)


def _json_list(raw: str | None) -> list[str]:
    if not raw or not raw.strip():
        return []
    try:
        data = json.loads(raw)
    except ValueError:
        return []
    return [str(x).strip() for x in data if str(x).strip()] if isinstance(data, list) else []


def _dedup(items: list[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        key = item.strip().lower()
        if key and key not in seen:
            seen.add(key)
            out.append(item.strip())
    return out


def _collect(
    environ: Mapping[str, str], people: list[str], *, name: str | None = None,
    emails: list[str] | None = None, company: str | None = None,
    domains: list[str] | None = None, internal_domains: list[str] | None = None,
) -> dict[str, object]:
    """Источники профиля: env (как раньше) + явные значения (DEV-3-KIT: флаги ``dt owner init``,
    мастер ``dt install``). Явные имя/компания перекрывают env; списки (почты, домены) дополняют."""
    name = (name or "").strip() or (environ.get("DT_USER_NAME") or "").strip()
    if name.lower() == PLACEHOLDER_NAME:
        name = ""
    tokens = _json_list(environ.get("DT_OUTLOOK_SELF_TOKENS"))
    email = (environ.get("DT_TIMETTA_USER_EMAIL") or "").strip()
    all_emails = _dedup([*(emails or []), *[t for t in tokens if "@" in t],
                         *([email] if email else [])])
    variants = _dedup([t for t in tokens if "@" not in t and t.lower() != name.lower()])
    privacy = _dedup([*_json_list(environ.get("DT_LEGACY_PRIVACY_NAMES")), *people])
    return {
        "name": name, "name_variants": variants, "emails": all_emails, "privacy": privacy,
        "company": (company or "").strip(),
        "domains": _dedup([*(d.strip().lower().lstrip("@") for d in domains or []),
                           *env_domain_list(environ.get("DT_MAIL_OWNER_DOMAINS"))]),
        "internal_domains": _dedup([
            *(d.strip().lower().lstrip("@") for d in internal_domains or []),
            *env_domain_list(environ.get("DT_MAIL_INTERNAL_DOMAINS"))]),
    }


def render_owner_yaml(
    *, name: str = "", name_variants: list[str] | None = None, emails: list[str] | None = None,
    people: list[str] | None = None, company: str = "", domains: list[str] | None = None,
    internal_domains: list[str] | None = None, role: str = "", locale: str = "ru",
    updated: date | None = None,
) -> str:
    """Текст ``owner.yaml`` с шапкой-комментарием (значения - через ``safe_dump``)."""

    def block(key: str, value: object) -> str:
        return yaml.safe_dump({key: value}, allow_unicode=True, sort_keys=False,
                              default_flow_style=False, width=10**6).rstrip("\n")

    day = (updated or date.today()).isoformat()
    privacy = yaml.safe_dump({"privacy": {"people": list(people or [])}}, allow_unicode=True,
                             sort_keys=False, default_flow_style=False, width=10**6).rstrip("\n")
    return "\n".join([
        "# Профиль владельца (PROFILE-1). Правит владелец руками (Obsidian); движок только читает.",
        "# Секретов здесь нет и быть не должно: пароли и токены - в Keychain / .secrets.",
        "# name_variants - одно слово (фамилия, форма имени): вычитаются из пробы приватности.",
        "# privacy.people - чьи ЛИЧНЫЕ документы не индексируем (в контексте зарплата/ГПХ/HR).",
        "# company.domains - почтовые домены компании (+ домены emails): с ними - «свои»;",
        "# company.internal_domains - служебные домены группы/инфраструктуры (не контрагенты).",
        block("name", name),
        block("name_variants", list(name_variants or [])),
        block("emails", list(emails or [])),
        block("company", {"name": company, "domains": list(domains or []),
                          "internal_domains": list(internal_domains or [])}),
        block("role", role),
        block("locale", locale),
        privacy,
        f"updated: {day}",
        "",
    ])


def init_profile(
    vault_path: Path | None = None, *, force: bool = False,
    environ: Mapping[str, str] | None = None, people: list[str] | None = None,
    today: date | None = None, name: str | None = None, emails: list[str] | None = None,
    company: str | None = None, domains: list[str] | None = None,
    internal_domains: list[str] | None = None,
) -> InitResult:
    """Создать ``_system/profile/{owner.yaml,about.md,rules.md}``; существующее - с ``force``.

    DEV-3-KIT: ``name``/``emails``/``company``/``domains``/``internal_domains`` - явные значения
    (флаги ``dt owner init``), чтобы новому человеку не требовались переменные чужого контура."""
    env = os.environ if environ is None else environ
    directory = profile_dir(vault_path)
    got = _collect(env, list(people or []), name=name, emails=emails, company=company,
                   domains=domains, internal_domains=internal_domains)
    result = InitResult(directory=directory, sources={
        k: (len(v) if isinstance(v, list) else int(bool(v))) for k, v in got.items()})
    texts = {
        OWNER_FILE: render_owner_yaml(
            name=str(got["name"]), name_variants=list(got["name_variants"]),  # type: ignore[call-overload]
            emails=list(got["emails"]), people=list(got["privacy"]),  # type: ignore[call-overload]
            company=str(got["company"]),
            domains=list(got["domains"]),  # type: ignore[call-overload]
            internal_domains=list(got["internal_domains"]),  # type: ignore[call-overload]
            updated=today),
        ABOUT_FILE: ABOUT_TEMPLATE,
        RULES_FILE: RULES_TEMPLATE,
    }
    directory.mkdir(parents=True, exist_ok=True)
    for name in FILES:
        target = directory / name
        if target.exists():
            if not force:
                if name == OWNER_FILE and _is_pristine(target):
                    # каркас ``dt vault init`` кладет пустой owner.yaml: в нем нечего терять
                    write_text_atomic(target, texts[name])
                    result.refilled.append(name)
                    result.created.append(name)
                    continue
                if name == OWNER_FILE and _migrate_company(target, got, result):
                    continue
                result.skipped.append(name)
                continue
            result.backups.append(backup_file(target).name)
        write_text_atomic(target, texts[name])
        result.created.append(name)
    _audit(result, force)
    return result


_COMPANY_SCALAR_RE = re.compile(r"^company:[ \t]*(?P<value>[^#\n]*?)[ \t]*(?P<tail>#.*)?$", re.M)


def _flow(items: list[str]) -> str:
    """Список строк одной строкой YAML (``[a.kz, b.kz]``)."""
    return yaml.safe_dump(list(items), allow_unicode=True, default_flow_style=True,
                          width=10**6).strip().removesuffix("...").strip()


def migrate_company_text(
    text: str, *, domains: list[str], internal_domains: list[str],
) -> str | None:
    """``owner.yaml`` со строкой ``company: <название>`` → объект ``company: {name, domains,
    internal_domains}``; ``None`` - миграция не нужна (уже объект либо ключа нет). Правка текстовая:
    остальные строки и комментарии файла сохраняются как есть."""
    match = _COMPANY_SCALAR_RE.search(text)
    if match is None:
        return None
    value = match.group("value")
    if not value and text[match.end():].lstrip("\n").startswith((" ", "\t")):
        return None  # ``company:`` с блоком под ним - уже объект
    tail = f" {match.group('tail')}" if match.group("tail") else ""
    name = value or '""'
    block = (f"company:{tail}\n  name: {name}\n  domains: {_flow(domains)}\n"
             f"  internal_domains: {_flow(internal_domains)}")
    return text[:match.start()] + block + text[match.end():]


def _is_pristine(target: Path) -> bool:
    """``owner.yaml`` без заполненных полей (шаблон vault): ни имени, ни почт, ни доменов."""
    try:
        data = parse_owner_yaml(target.read_text(encoding="utf-8"))
    except OSError:
        return False
    return not (data.name or data.name_variants or data.emails or data.company
                or data.company_domains or data.company_internal_domains or data.role
                or data.privacy_people) and not data.issues


def _migrate_company(target: Path, got: dict[str, object], result: InitResult) -> bool:
    """Мигрировать существующий ``owner.yaml`` со строковым ``company`` (с бэкапом); ``True`` -
    файл переписан."""
    try:
        text = target.read_text(encoding="utf-8")
    except OSError:
        return False
    new = migrate_company_text(
        text, domains=list(got["domains"]),  # type: ignore[call-overload]
        internal_domains=list(got["internal_domains"]))  # type: ignore[call-overload]
    if new is None:
        return False
    result.backups.append(backup_file(target).name)
    write_text_atomic(target, new)
    result.migrated.append(target.name)
    return True


def _audit(result: InitResult, force: bool) -> None:
    from core.operational.pult import record_action

    record_action(
        "owner_init",
        {"created": ",".join(result.created) or "-", "skipped": ",".join(result.skipped) or "-",
         "migrated": ",".join(result.migrated) or "-",
         "refilled": ",".join(result.refilled) or "-", "force": str(force).lower()},
        "ok" if (result.created or result.migrated) else "noop",
    )
