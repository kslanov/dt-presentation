"""KIT-PRIVACY-1: ОДИН сборщик приватных терминов - владелец + клиенты - для гарда тестов, шаблона
vault и стартового кита.

Источник приватности - vault, а не код (DEV-3-CORE п.1): что нельзя раздавать, записано в данных
владельца, и список терминов собирается из них, а не хранится в репозитории.

* **владелец** - ``_system/profile/owner.yaml``: имя, варианты имени, фамилии ``privacy.people``,
  название компании, ее домены (``company.domains``/``internal_domains``) и домены адресов; из
  домена берется и метка (``example.kz`` → ``example``), если она не короче 5;
* **клиенты** - хабы ``04-clients`` (``type: hub``, ``entity: client``): ``title``, ``aliases``,
  имена из H1 (целиком и фрагменты «…»/(…)), слаг id без ``client-`` целиком и его части длиной ≥ 5;
* **другие хабы** (``02-knowledge``, ``03-projects``) - только явные ``aliases`` (имена продуктов,
  направлений и проектов, которые тоже не для раздачи).

Хабы читает каталог имен :mod:`core.retrieval.hubcat` (``build_catalog``), срезы заметок -
:func:`core.retrieval.notemeta.meta_from_note`: своего парсера frontmatter здесь нет, снимок
``.derived`` НЕ пишется (читаются только папки хабов, vault не меняется).

Совпадение: минимальная длина термина 4, сравнение регистронезависимое, NFC и NFD, по границам
слова: рядом с термином нет буквы или цифры («Акме» не ловит «Акмеизм»). Дефис и подчеркивание
границей СЧИТАЮТСЯ (отступление от ТЗ, где ``\\w`` их исключал): иначе ``client-acme`` и имена
файлов вроде ``КП_Акме_Проект.pptx`` проходили бы мимо гарда. Файл исключений
``scripts/privacy-ignore.txt`` (по строке ``термин # причина``) - для общеупотребительных
совпадений, ТОЛЬКО по явному решению владельца, сам не растет; термин из файла, которого нет
в vault, - мусор: :attr:`PrivateTerms.stale`, сборка кита и гард тестов отказывают
(:meth:`PrivateTerms.require_clean_ignore`, :class:`PrivacyError`).
"""

from __future__ import annotations

import re
import unicodedata
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path

from core.config import ENGINE_ROOT

__all__ = [
    "DEFAULT_IGNORE", "HUB_DIRS", "Hit", "MIN_TERM", "PrivacyError", "PrivateTerms",
    "private_terms", "replace_terms", "scan_text",
]

MIN_TERM = 4
MIN_SLUG_PART = 5
MIN_DOMAIN_LABEL = 5
HUB_DIRS = ("04-clients", "02-knowledge", "03-projects")
DEFAULT_IGNORE = ENGINE_ROOT / "scripts" / "privacy-ignore.txt"
_PREFIX = re.compile(r"^(?:client|product|project|direction|deal|industry)-")


class PrivacyError(RuntimeError):
    """Список терминов собрать нельзя (битый игнор-список, мусор в нем)."""


@dataclass(frozen=True)
class Hit:
    """Совпадение: строка текста и сам термин."""

    line: int
    term: str


@dataclass(frozen=True)
class PrivateTerms:
    """Собранный список: владелец, клиенты, исключенные владельцем; ``all`` - то, что ищем."""

    owner: tuple[str, ...]
    clients: tuple[str, ...]
    ignored: tuple[str, ...] = ()
    others: tuple[str, ...] = ()  # алиасы продуктов/направлений/проектов (не клиенты)
    stale: tuple[str, ...] = ()  # исключения, которых нет среди терминов vault (мусор)

    def require_clean_ignore(self) -> None:
        """Мусор в игнор-списке - отказ: список исключений не копит несуществующее."""
        if self.stale:
            raise PrivacyError(
                f"в игнор-списке термины, которых нет в vault: {', '.join(self.stale)} - убери "
                "строки из scripts/privacy-ignore.txt")

    @property
    def all(self) -> list[str]:
        skip = {_fold(t) for t in self.ignored}
        pool = (*self.owner, *self.clients, *self.others)
        return sorted({t for t in pool if _fold(t) not in skip})

    def kind_of(self, term: str) -> str:
        folded = _fold(term)
        if folded in {_fold(t) for t in self.owner}:
            return "владелец"
        return "клиент"


def _fold(text: str) -> str:
    return unicodedata.normalize("NFC", text).casefold()


def _clean(raw: Iterable[object]) -> set[str]:
    out: set[str] = set()
    for item in raw:
        text = unicodedata.normalize("NFC", str(item or "")).strip()
        if len(text) >= MIN_TERM:
            out.add(text)
    return out


def _owner_terms(vault: Path) -> set[str]:
    from core.owner.store import load_profile

    data = load_profile(vault).data
    emails = [e.rsplit("@", 1)[-1] for e in data.emails if "@" in e]
    out = _clean([data.name, *data.name_variants, *data.privacy_people, data.company,
                  *data.company_domains, *data.company_internal_domains, *emails])
    out |= {t.split(".")[0] for t in list(out)
            if "." in t and len(t.split(".")[0]) >= MIN_DOMAIN_LABEL}
    return out


def _slug_terms(note_id: str) -> set[str]:
    slug = _PREFIX.sub("", note_id).strip()
    parts = [p for p in re.split(r"[-_\s]+", slug) if len(p) >= MIN_SLUG_PART]
    return _clean([slug, *parts])


def _hub_entries(vault: Path):
    """Каталог хабов ``02-knowledge``/``03-projects``/``04-clients`` (без записи кэша на диск)."""
    from core.retrieval.hubcat import build_catalog
    from core.retrieval.notemeta import meta_from_note
    from core.vault import read_note

    metas = []
    for folder in HUB_DIRS:
        base = vault / folder
        if not base.is_dir():
            continue
        for path in sorted(base.rglob("*.md")):
            try:
                metas.append(meta_from_note(read_note(path, vault), vault))
            except Exception:  # noqa: BLE001, S112 - битая заметка: терминов нет, сборка идет
                continue
    return build_catalog(metas, entities=None)


def _hub_terms(vault: Path) -> tuple[set[str], set[str]]:
    """``(термины клиентов, алиасы остальных хабов)``."""
    clients: set[str] = set()
    others: set[str] = set()
    for entry in _hub_entries(vault):
        if entry.entity == "client":
            clients |= _clean(n.text for n in entry.names)
            clients |= _slug_terms(entry.note_id)
            clients |= _clean([entry.note_id])  # ``client-<слаг>``: id целиком
        else:
            others |= _clean(n.text for n in entry.names if n.source == "alias")
    return clients, others


def read_ignore(path: Path | None) -> list[tuple[str, str]]:
    """``[(термин, причина)]`` из файла исключений; строка без причины - ошибка."""
    if path is None or not Path(path).is_file():
        return []
    rows: list[tuple[str, str]] = []
    for n, line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), 1):
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        term, sep, reason = text.partition("#")
        if not sep or not reason.strip() or not term.strip():
            raise PrivacyError(f"{path}:{n}: нужна строка «термин # причина» (причина обязательна)")
        rows.append((unicodedata.normalize("NFC", term.strip()), reason.strip()))
    return rows


def private_terms(vault: Path | None, *, ignore_file: Path | None = DEFAULT_IGNORE
                  ) -> PrivateTerms:
    """Список приватных терминов vault (владелец ∪ клиенты ∪ алиасы прочих хабов) минус исключения.

    Нет vault - пустой список (вызывающий решает, терпимо ли это). Исключение, которого нет среди
    найденных терминов, попадает в ``stale`` (кит и гард тестов на нем отказывают)."""
    if vault is None or not Path(vault).is_dir():
        return PrivateTerms((), ())
    vault = Path(vault)
    owner = _owner_terms(vault)
    clients, others = _hub_terms(vault)
    found = {_fold(t) for t in (*owner, *clients, *others)}
    ignored = read_ignore(ignore_file)
    stale = tuple(t for t, _why in ignored if _fold(t) not in found)
    return PrivateTerms(tuple(sorted(owner)), tuple(sorted(clients)),
                        tuple(t for t, _ in ignored if t not in stale), tuple(sorted(others)),
                        stale)


def _patterns(terms: Sequence[str]) -> list[tuple[str, re.Pattern[str]]]:
    out: list[tuple[str, re.Pattern[str]]] = []
    for term in terms:
        for form in ("NFC", "NFD"):
            body = re.escape(unicodedata.normalize(form, term))
            # ``[^\W_]`` - буква или цифра (юникод): ``_`` и ``-`` рядом с термином - граница
            out.append((term, re.compile(rf"(?<![^\W_]){body}(?![^\W_])", re.I)))
    return out


def replace_terms(text: str, terms: Sequence[str], replacement: str) -> str:
    """Текст, где каждое совпадение (те же границы слова, что у :func:`scan_text`) заменено на
    ``replacement``: генератор шаблона vault убирает приватные имена из данных, которые берет
    из боевого vault (тег корпоративной базы в политиках поиска)."""
    for _term, pat in sorted(_patterns(terms), key=lambda tp: -len(tp[0])):
        text = pat.sub(replacement, text)
    return text


def scan_text(text: str, terms: Sequence[str]) -> list[Hit]:
    """Совпадения терминов в тексте: ``[Hit(строка, термин)]`` по границам слова, без повторов."""
    patterns = _patterns(terms)
    hits: list[Hit] = []
    seen: set[tuple[int, str]] = set()
    for lineno, line in enumerate(text.splitlines(), 1):
        for term, pat in patterns:
            if pat.search(line) and (lineno, term) not in seen:
                seen.add((lineno, term))
                hits.append(Hit(lineno, term))
    return hits
