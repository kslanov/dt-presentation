"""PROFILE-1: схема ``owner.yaml`` - личность владельца, машиночитаемо.

Поля::

    name: <полное имя>              # [System] промпта generate, токен личности почты
    name_variants: [<слово>, ...]   # фамилия/формы имени, вычитаются из пробы приватности почты
    emails: [<адрес>, ...]          # свои адреса (не секрет; пароли/токены здесь не живут)
    company:                        # старая форма ``company: <название>`` читается как ``name``
      name: <компания>
      domains: [<домен>, ...]       # почтовые домены компании: участники с ними - «свои»
      internal_domains: [<домен>]   # служебные домены группы/инфраструктуры (не контрагенты)
    role: <роль>
    locale: <ru|en|...>
    privacy:
      people: [<фамилия>, ...]      # чьи ЛИЧНЫЕ документы не индексируем (зарплата/ГПХ/HR)
    updated: 2026-10-31

Ошибки формата - не исключение, а список :class:`OwnerIssue` (``code``, ``field``, ``message``):
кривое поле отбрасывается (остальное работает), потребитель видит причину в докторе /
``dt owner check`` / ``owner_profile``. Чистая функция: ни файлов, ни конфига.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

import yaml  # type: ignore[import-untyped]  # стаб-гэп PyYAML - как в core.skills

__all__ = [
    "FIELDS",
    "OwnerData",
    "OwnerIssue",
    "PLACEHOLDER_NAME",
    "parse_owner_yaml",
]

# Нейтральный плейсхолдер, когда владелец нигде не назван (прежний дефолт ``user_display_name``).
PLACEHOLDER_NAME = "the user"

FIELDS = (
    "name", "name_variants", "emails", "company", "role", "locale", "privacy", "updated",
)
_PRIVACY_FIELDS = ("people",)
_COMPANY_FIELDS = ("name", "domains", "internal_domains")
_DOMAIN_RE = re.compile(r"^[a-z0-9]([a-z0-9.-]*[a-z0-9])?$")
_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@dataclass(frozen=True)
class OwnerIssue:
    """Замечание к ``owner.yaml``: ``code`` и ``field`` - для машины, ``message`` - для человека.

    ``code``: ``missing_file`` | ``unreadable`` | ``yaml_error`` | ``not_mapping`` | ``bad_type`` |
    ``unknown_field`` | ``bad_email`` | ``bad_domain`` | ``bad_date``."""

    code: str
    field: str
    message: str

    def as_dict(self) -> dict[str, str]:
        return {"code": self.code, "field": self.field, "message": self.message}

    def __str__(self) -> str:
        return f"[{self.code}] {self.field}: {self.message}"


@dataclass(frozen=True)
class OwnerData:
    name: str = ""
    name_variants: tuple[str, ...] = ()
    emails: tuple[str, ...] = ()
    company: str = ""  # company.name (старая форма - строкой - читается сюда же)
    company_domains: tuple[str, ...] = ()
    company_internal_domains: tuple[str, ...] = ()
    role: str = ""
    locale: str = ""
    privacy_people: tuple[str, ...] = ()
    updated: str = ""
    issues: tuple[OwnerIssue, ...] = field(default_factory=tuple)


def _scalar(data: dict[str, Any], key: str, issues: list[OwnerIssue]) -> str:
    value = data.get(key)
    if value is None:
        return ""
    if isinstance(value, (str, int, float)) and not isinstance(value, bool):
        return str(value).strip()
    issues.append(OwnerIssue("bad_type", key, "ожидается строка"))
    return ""


def _str_list(value: Any, name: str, issues: list[OwnerIssue]) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list) or any(
        not isinstance(v, (str, int, float)) or isinstance(v, bool) for v in value
    ):
        issues.append(OwnerIssue("bad_type", name, "ожидается список строк"))
        return ()
    seen: set[str] = set()
    out: list[str] = []
    for item in value:
        text = str(item).strip()
        if text and text.lower() not in seen:
            seen.add(text.lower())
            out.append(text)
    return tuple(out)


def _domains(value: Any, name: str, issues: list[OwnerIssue]) -> tuple[str, ...]:
    """Список доменов: нижний регистр, без ``@``; не-домен - замечание, остальное живет."""
    good: list[str] = []
    for item in _str_list(value, name, issues):
        dom = item.lower().lstrip("@")
        if _DOMAIN_RE.match(dom) and "." in dom:
            good.append(dom)
        else:
            issues.append(OwnerIssue("bad_domain", name, f"не домен: {item[:40]!r}"))
    return tuple(dict.fromkeys(good))


def _company(value: Any, issues: list[OwnerIssue]) -> tuple[str, tuple[str, ...], tuple[str, ...]]:
    """``company``: объект ``{name, domains, internal_domains}`` либо старая строка (= ``name``)."""
    if value is None:
        return "", (), ()
    if isinstance(value, (str, int, float)) and not isinstance(value, bool):
        return str(value).strip(), (), ()
    if not isinstance(value, dict):
        issues.append(OwnerIssue("bad_type", "company", "ожидается строка или объект {name, ...}"))
        return "", (), ()
    for key in value:
        if key not in _COMPANY_FIELDS:
            issues.append(OwnerIssue(
                "unknown_field", f"company.{key}", "неизвестное поле (опечатка?)"))
    name = value.get("name")
    if name is None:
        name_text = ""
    elif isinstance(name, (str, int, float)) and not isinstance(name, bool):
        name_text = str(name).strip()
    else:
        issues.append(OwnerIssue("bad_type", "company.name", "ожидается строка"))
        name_text = ""
    return (name_text, _domains(value.get("domains"), "company.domains", issues),
            _domains(value.get("internal_domains"), "company.internal_domains", issues))


def parse_owner_yaml(text: str) -> OwnerData:
    """Текст ``owner.yaml`` → :class:`OwnerData` (+ ``issues``). Пустой файл - пустой профиль."""
    issues: list[OwnerIssue] = []
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        where = f" (строка {mark.line + 1})" if mark is not None else ""
        return OwnerData(issues=(OwnerIssue("yaml_error", "", f"YAML не разобран{where}"),))
    if data is None:
        return OwnerData()
    if not isinstance(data, dict):
        return OwnerData(issues=(OwnerIssue("not_mapping", "", "ожидается словарь полей"),))
    for key in data:
        if key not in FIELDS:
            issues.append(OwnerIssue("unknown_field", str(key), "неизвестное поле (опечатка?)"))
    emails = _str_list(data.get("emails"), "emails", issues)
    good_emails = []
    for addr in emails:
        if _EMAIL_RE.match(addr):
            good_emails.append(addr)
        else:
            issues.append(OwnerIssue("bad_email", "emails", f"не адрес: {addr[:40]!r}"))
    people: tuple[str, ...] = ()
    privacy = data.get("privacy")
    if privacy is not None:
        if not isinstance(privacy, dict):
            issues.append(OwnerIssue("bad_type", "privacy", "ожидается словарь {people: [...]}"))
        else:
            for key in privacy:
                if key not in _PRIVACY_FIELDS:
                    issues.append(OwnerIssue(
                        "unknown_field", f"privacy.{key}", "неизвестное поле (опечатка?)"))
            people = _str_list(privacy.get("people"), "privacy.people", issues)
    updated = data.get("updated")
    if isinstance(updated, (date, datetime)):
        updated_text = updated.isoformat()[:10]
    elif updated is None:
        updated_text = ""
    else:
        updated_text = str(updated).strip()
        if updated_text and not re.match(r"^\d{4}-\d{2}-\d{2}", updated_text):
            issues.append(OwnerIssue("bad_date", "updated", "ожидается дата ГГГГ-ММ-ДД"))
            updated_text = ""
    company, company_domains, company_internal = _company(data.get("company"), issues)
    return OwnerData(
        name=_scalar(data, "name", issues),
        name_variants=_str_list(data.get("name_variants"), "name_variants", issues),
        emails=tuple(good_emails),
        company=company,
        company_domains=company_domains,
        company_internal_domains=company_internal,
        role=_scalar(data, "role", issues),
        locale=_scalar(data, "locale", issues),
        privacy_people=people,
        updated=updated_text,
        issues=tuple(issues),
    )
