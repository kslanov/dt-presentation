"""PROFILE-1: чтение профиля владельца из ``vault/_system/profile/`` (три файла, кэш по mtime).

* ``owner.yaml`` - личность (:mod:`core.owner.schema`);
* ``about.md`` - семантический блок, ЕДИНСТВЕННЫЙ файл в промпте ``generate`` (``[Owner]``);
* ``rules.md`` - процедурный блок для хостов (``owner_profile``, скилл ``dt-owner``).

Движок профиль только ЧИТАЕТ (пишет К. руками или разовый ``dt owner init``). Читатель не падает:
нет файла / битый YAML / нечитаемый файл - пустое поле и :class:`~core.owner.schema.OwnerIssue`.
Кэш - по ``(путь, mtime_ns, размер)`` трех файлов: правка в Obsidian видна следующему вызову без
рестарта демона, а горячий путь (каждая сборка промпта) стоит три ``stat``.

Подсказки шаблонов (HTML-комментарии ``<!-- -->``) и пустые заголовки смыслом не считаются: файл,
который состоит только из них, - «пуст» (в промпт и хостам не идет).
"""

from __future__ import annotations

import hashlib
import re
import threading
from dataclasses import dataclass, field
from pathlib import Path

from core.config import vault_system_path
from core.owner.schema import PLACEHOLDER_NAME, OwnerData, OwnerIssue, parse_owner_yaml

__all__ = [
    "ABOUT_FILE",
    "OWNER_FILE",
    "OwnerProfile",
    "PROFILE_DIRNAME",
    "RULES_FILE",
    "load_profile",
    "meaningful",
    "profile_dir",
    "strip_hints",
]

PROFILE_DIRNAME = "profile"
OWNER_FILE = "owner.yaml"
ABOUT_FILE = "about.md"
RULES_FILE = "rules.md"
FILES = (OWNER_FILE, ABOUT_FILE, RULES_FILE)

_COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)


def profile_dir(vault_path: Path | None = None) -> Path:
    """``<vault>/_system/profile`` (без vault_path - vault по умолчанию, ``DT_VAULT_PATH``)."""
    return vault_system_path(vault_path) / PROFILE_DIRNAME


def strip_hints(text: str) -> str:
    """Текст без HTML-комментариев-подсказок, края обрезаны."""
    return _COMMENT_RE.sub("", text).strip()


def meaningful(text: str) -> bool:
    """Есть ли в markdown хоть одна содержательная строка (не заголовок, не подсказка, не пусто)."""
    for line in strip_hints(text).splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            return True
    return False


@dataclass(frozen=True)
class OwnerProfile:
    """Прочитанный профиль. ``exists`` - есть ли каталог/хоть один файл (иначе все поля пусты)."""

    path: Path
    exists: bool = False
    data: OwnerData = field(default_factory=OwnerData)
    about: str = ""  # без подсказок; пусто, если нет смысла
    rules: str = ""
    version: str = ""
    present: tuple[str, ...] = ()  # какие из трех файлов лежат на диске
    issues: tuple[OwnerIssue, ...] = ()

    @property
    def name(self) -> str:
        return self.data.name

    @property
    def missing(self) -> list[str]:
        """Файлы, которых нет на диске либо без содержания (``owner.yaml`` без ``name``)."""
        out: list[str] = []
        if OWNER_FILE not in self.present or not self.data.name:
            out.append(OWNER_FILE)
        if not self.about:
            out.append(ABOUT_FILE)
        if not self.rules:
            out.append(RULES_FILE)
        return out

    @property
    def identity_tokens(self) -> list[str]:
        """Имя + варианты + почты профиля (без плейсхолдера), без повторов (регистр не важен)."""
        seen: set[str] = set()
        out: list[str] = []
        for token in (self.data.name, *self.data.name_variants, *self.data.emails):
            key = token.strip().lower()
            if key and key != PLACEHOLDER_NAME and key not in seen:
                seen.add(key)
                out.append(token.strip())
        return out


_cache: dict[Path, tuple[tuple[tuple[int, int], ...], OwnerProfile]] = {}
_lock = threading.Lock()


def _stat_key(directory: Path) -> tuple[tuple[int, int], ...]:
    key: list[tuple[int, int]] = []
    for name in FILES:
        try:
            st = (directory / name).stat()
            key.append((st.st_mtime_ns, st.st_size))
        except OSError:
            key.append((-1, -1))
    return tuple(key)


def _version(raw: dict[str, bytes]) -> str:
    h = hashlib.sha256()
    for name in FILES:
        h.update(name.encode() + b"\0" + raw.get(name, b"") + b"\0")
    return h.hexdigest()[:12]


def _read(directory: Path) -> OwnerProfile:
    raw: dict[str, bytes] = {}
    issues: list[OwnerIssue] = []
    for name in FILES:
        path = directory / name
        if not path.is_file():
            continue
        try:
            raw[name] = path.read_bytes()
        except OSError as exc:
            issues.append(OwnerIssue("unreadable", name, type(exc).__name__))
    if not raw and not issues:
        return OwnerProfile(path=directory)

    def text(name: str) -> str:
        return raw.get(name, b"").decode("utf-8", errors="replace")

    data = parse_owner_yaml(text(OWNER_FILE)) if OWNER_FILE in raw else OwnerData()
    about_text = text(ABOUT_FILE)
    rules_text = text(RULES_FILE)
    return OwnerProfile(
        path=directory,
        exists=True,
        data=data,
        about=strip_hints(about_text) if meaningful(about_text) else "",
        rules=strip_hints(rules_text) if meaningful(rules_text) else "",
        version=_version(raw),
        present=tuple(n for n in FILES if n in raw),
        issues=(*data.issues, *issues),
    )


def load_profile(vault_path: Path | None = None) -> OwnerProfile:
    """Профиль владельца vault'а (по умолчанию - боевого). Кэш по mtime/размеру файлов."""
    directory = profile_dir(vault_path)
    key = _stat_key(directory)
    with _lock:
        hit = _cache.get(directory)
        if hit is not None and hit[0] == key:
            return hit[1]
    profile = _read(directory)
    with _lock:
        _cache[directory] = (key, profile)
    return profile
