"""Lightweight task parser (architecture §8 hybrid, ТЗ D5).

Turns a natural-language task into a ``(use_case_id, params, interpretation)``
triple by (1) a keyword heuristic for the use case and (2) matching entity hubs
mentioned in the text — by ALL names of the single hub catalog
(:func:`core.retrieval.hubcat.hub_catalog`, HUB-ALIAS-1: ``aliases``, H1 of the hub body, id
slug), the same names ``find_notes`` normalizes a client by — then filling related ids from
the matched hubs' own links (a client implies its industry, a project implies its client +
industry). A client named in the text always beats the client inferred from a project.

This produces an *interpretation* for the user/Cowork to confirm; the code does
not auto-run generation. Explicit ``params`` always override what was parsed.

Invariant: ``core/`` depends on neither MCP nor CLI.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.config import default_vault_path
from core.retrieval.hubcat import hub_catalog, match_hubs
from core.vault import read_note

__all__ = ["ParsedTask", "parse_task"]

DEFAULT_USE_CASE = "client_correspondence"

# Use-case heuristic: first matching keyword wins. More specific cases must come
# BEFORE broader ones — commercial_offer (a КП *is* a letter to the client) is
# listed ahead of client_correspondence so "КП по Acme" resolves to the offer,
# not generic correspondence (PART-3). Unrecognised text still falls through to
# DEFAULT_USE_CASE.
#
# TOOLS-PROFILES-1 п.0 (PARSE-TASK-2): все кейсы из политик ``retrieval-policies``, а не два.
# Якоря — фразы из скилла generate-artifact («сделай письмо/справку/отчёт/стратегию/доклад»,
# «напиши клиенту …») и из ТЗ. Порядок — от узких к широким: «доклад по стратегии» — доклад
# (речь), «стратегия по Acme» — стратегия; слово «презентация» слабее «стратегии» (стратегическая
# презентация — кейс 4), поэтому речь встречается дважды: сильные якоря до стратегии, слабый
# («презентаци») после. «письмо» перед «отчёт/обзор»: письмо с приложенным отчётом — письмо.
_USE_CASE_KEYWORDS: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        "commercial_offer",
        ("кп ", " кп", "кп_", "кп-", "коммерческое предложение",
         "коммерческого предложения", "commercial offer", "предложение по"),
    ),
    ("speech_presentation", (" доклад ", " доклада ", " докладе ", "докладу", "докладом",
                             "выступлени", "тезис", "speech", "keynote")),
    ("strategy", ("стратеги", "план развития", "плана развития", "strategy")),
    ("speech_presentation", ("презентаци", "слайд")),
    ("management_decision", ("справк", "докладн", "для решения", "управленческ", "орг-решени",
                             "management decision")),
    ("client_correspondence", ("письмо", "письме", "letter", "correspond", "ответ клиент",
                               "напиши клиент", "написать клиент", "напишите клиент")),
    ("rnd", ("исследовани", "обзор", "r&d", "r & d", "рнд", "отчёт", "отчет", "report")),
)

# Название кейса по-русски — в интерпретации, чтобы подтверждающий (человек или модель хоста)
# видел, КАКОЙ кейс распознан, а не только идентификатор политики.
_USE_CASE_LABELS = {
    "client_correspondence": "кейс 1: письмо клиенту",
    "rnd": "кейс 2: R&D-отчёт / исследование",
    "management_decision": "кейс 3: справка для управленческого решения",
    "strategy": "кейс 4: стратегия",
    "speech_presentation": "кейс 5: доклад / выступление / презентация",
    "commercial_offer": "коммерческое предложение (КП)",
}

# hub frontmatter ``entity`` → the param key it populates.
_ENTITY_TO_PARAM = {
    "client": "client_id",
    "industry": "industry_id",
    "project": "project_id",
    # TOOLS-PROFILES-1 п.0: политики кейсов 2-5 принимают продукт и сделку.
    "product": "product_id",
    "deal": "deal_ref",
}


@dataclass
class ParsedTask:
    use_case_id: str
    params: dict[str, Any] = field(default_factory=dict)
    interpretation: str = ""
    # CONTRACT-2 С12: кейс РАСПОЗНАН по тексту (True) или подставлен дефолтом (False).
    # Без флага дефолт неотличим от уверенного разбора — и уезжает дальше молча.
    detected: bool = True


def _detect_use_case(text: str) -> tuple[str, bool]:
    """``(use_case_id, распознан ли)``. Не распознан → дефолт + флаг ``False``.

    CONTRACT-2 С12: дефолтный кейс — правдоподобная догадка, и раньше она была
    неотличима от уверенного распознавания. Дальше по цепочке это стоит дорого:
    неверный кейс → другая политика → другой набор слайсов (С3).
    """
    # Пунктуация → пробелы, текст в пробелах по краям: якоря с пробелом («кп », «доклад ») ловят
    # слово в конце фразы и перед запятой, а «докладная» не путается с «доклад».
    low = " " + re.sub(r"[^\w&+-]+", " ", text.lower()) + " "
    for use_case, keywords in _USE_CASE_KEYWORDS:
        if any(kw in low for kw in keywords):
            return use_case, True
    return DEFAULT_USE_CASE, False


def _match_entities(text: str, vault_path: Path) -> dict[str, str]:
    """Hubs named in ``text`` (by every catalog name) → their param keys.

    Один каталог имен с поиском (:func:`hub_catalog`) и тот же матчер (:func:`match_hubs`: границы
    слова, стем-ключи, короткое имя - только целым словом в том же регистре); сверх поиска
    принимаются аббревиатуры из H1 хаба («ГЛБ», «АМБ»). Порядок - по ``(сущность, id)``, поэтому
    при двух клиентах в тексте выбор детерминирован.
    """
    catalog = hub_catalog(vault_path, tuple(_ENTITY_TO_PARAM))
    found: dict[str, str] = {}
    # Frontmatter links to fill in related ids once a hub is matched.
    links: dict[str, dict[str, Any]] = {}
    by_id = {e.note_id: e for e in catalog}

    for hit in match_hubs(text, catalog, h1_abbreviations=True):
        param = _ENTITY_TO_PARAM.get(hit.entity)
        if not param:
            continue
        found.setdefault(param, hit.note_id)
        entry = by_id[hit.note_id]
        try:
            links[hit.note_id] = dict(read_note(Path(vault_path) / entry.path).frontmatter)
        except Exception:  # noqa: BLE001 — нечитаемый хаб: имя найдено, связи не достроим
            links[hit.note_id] = {"entity": hit.entity}

    # Infer related ids from the matched hubs' own links — only where the text did not name them.
    for fm in links.values():
        if fm.get("entity") == "project":
            _fill_link(found, "client_id", fm.get("client"))
            _fill_link(found, "industry_id", fm.get("industry"))
        elif fm.get("entity") == "client":
            _fill_link(found, "industry_id", fm.get("industry"))

    return found


def _fill_link(found: dict[str, str], key: str, value: Any) -> None:
    if key in found or not value:
        return
    # Wikilink fields are normalized to bare ids (or lists) by read_note.
    found[key] = value[0] if isinstance(value, list) else value


def parse_task(
    text: str,
    *,
    params: dict[str, Any] | None = None,
    vault_path: Path | None = None,
) -> ParsedTask:
    """Parse ``text`` into a use case + entity params + a confirmable summary.

    ``params`` (if given) override anything parsed — letting a caller bypass the
    heuristics entirely. Pass ``use_case`` inside ``params`` to force the case.
    """
    vault_path = vault_path or default_vault_path()
    overrides = dict(params or {})

    forced: Any = overrides.pop("use_case", None)
    if forced:
        use_case_id, detected = str(forced), True  # задан явно — догадки нет
    else:
        use_case_id, detected = _detect_use_case(text)

    parsed_params = _match_entities(text, vault_path)
    parsed_params.update(overrides)  # explicit params win

    interpretation = _describe(use_case_id, parsed_params)
    return ParsedTask(
        use_case_id=use_case_id, params=parsed_params, interpretation=interpretation,
        detected=detected,
    )


_DESCRIBED_KEYS = ("client_id", "industry_id", "project_id", "product_id", "deal_ref")


def _describe(use_case_id: str, params: dict[str, Any]) -> str:
    label = _USE_CASE_LABELS.get(use_case_id)
    bits = [f"use_case={use_case_id}" + (f" ({label})" if label else "")]
    for key in _DESCRIBED_KEYS:
        if params.get(key):
            bits.append(f"{key}={params[key]}")
    extra = [k for k in params if k not in set(_DESCRIBED_KEYS)]
    for key in sorted(extra):
        bits.append(f"{key}={params[key]}")
    return ", ".join(bits)
