"""PERSONAL-3 п.C - источник захвата личного: свой список TickTick и полоса для задач без тега.

Оба экземпляра читают TickTick через ``DT_TICKTICK_CAPTURE_PROJECT_*``; без своего списка личный
наследует список рабочего (``engine/.env``), и развод идет только тегами. Задачи БЕЗ тега личная
роль по умолчанию пропускает (``DT_PERSONAL_UNTAGGED_LANE=skip``). Ручка ``untagged_lane`` не
``skip`` имеет смысл лишь при ОТДЕЛЬНОМ списке личного: иначе одна и та же задача без тега ушла бы в
оба vault (рабочий получает ее в «Требуют решения»). Поэтому ``untagged_lane != skip`` при списке,
совпадающем с рабочим, - отказ ``same_project`` (запись настройки) и warn доктора «Захват».

«Список рабочего» берется из ``engine/.env`` (файл), «свой список личного» - из его оверлея: слои
env процесса уже смешаны и различить их по ``os.environ`` нельзя."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from core.config import env_file

__all__ = ["HINT", "ID_KEY", "NAME_KEY", "describe", "is_project_id", "same_project",
           "work_project"]

NAME_KEY = "DT_TICKTICK_CAPTURE_PROJECT_NAME"
ID_KEY = "DT_TICKTICK_CAPTURE_PROJECT_ID"
HINT = "заведите отдельный список TickTick для личного (DT_TICKTICK_CAPTURE_PROJECT_NAME/ID)"
_ID_RE = re.compile(r"^[0-9a-f]{24}$", re.IGNORECASE)  # id списка TickTick: 24 hex-символа


def is_project_id(value: str) -> bool:
    """Значение похоже на id списка TickTick (иначе это имя)."""
    return bool(_ID_RE.fullmatch(str(value).strip()))


def work_project() -> tuple[str, str]:
    """``(id, имя)`` списка захвата РАБОЧЕГО экземпляра из ``engine/.env`` (пусто - не задан)."""
    path = env_file._ENGINE_DIR / ".env"
    return ((env_file.read_value(path, ID_KEY) or "").strip(),
            (env_file.read_value(path, NAME_KEY) or "").strip())


def _own(overlay: Path | None) -> tuple[str, str]:
    if overlay is None:
        return "", ""
    return ((env_file.read_value(overlay, ID_KEY) or "").strip(),
            (env_file.read_value(overlay, NAME_KEY) or "").strip())


def same_project(own: tuple[str, str], work: tuple[str, str] | None = None) -> bool:
    """Список личного совпадает с рабочим: своего нет вовсе либо равны id или имя (без регистра)."""
    own_id, own_name = own
    if not own_id and not own_name:
        return True  # наследует список рабочего
    work_id, work_name = work if work is not None else work_project()
    if own_id and work_id and own_id.lower() == work_id.lower():
        return True
    return bool(own_name and work_name and own_name.casefold() == work_name.casefold())


def describe(overlay: Path | None = None) -> dict[str, Any]:
    """Источник захвата личного для пульта и доктора: ``{project, own, lane, same_project}``.

    ``project`` - свой список (имя либо id) или ``""`` (наследует рабочий); ``lane`` - полоса для
    задач без тега; ``same_project`` - совпадение с рабочим списком (опасно, если lane не skip)."""
    from core.instance import instance_name, untagged_lane

    if overlay is None and instance_name():
        overlay = env_file.instance_overlay_path(instance_name() or "")
    own = _own(overlay)
    return {"project": own[1] or own[0], "own": bool(own[0] or own[1]), "lane": untagged_lane(),
            "same_project": same_project(own)}
