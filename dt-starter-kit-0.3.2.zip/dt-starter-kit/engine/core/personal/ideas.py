"""PERSONAL-2 п.1 - заметка идеи: ``#личное`` → ``<папка идей>/<заголовок>.md`` (детерминированно).

Только у экземпляра с ручкой ``DT_PERSONAL_IDEAS_DIR`` (без нее ``личное`` идет в инбокс с ``lane:
personal``, как в PERSONAL-1). Имя файла - первая строка записи до 60 символов (без символов,
недопустимых в имени файла); коллизия - суффикс времени ``ЧЧММ`` (затем ``-2``, ``-3``…).
Frontmatter - по шаблону Idea (``title``, ``date``, ``time``, ``tags: [idea]``, ``linked_notes:
[]``; ``location``/``mood`` не заполняются, плейсхолдеров Templater нет). Тело - остальной текст
записи + provenance-футер (как у inbox).

Писатель - движок (``core.vault.write_note``). Заметкой после создания владеет человек: правка
задачи в TickTick ее НЕ переписывает (:func:`write_idea` не трогает существующий файл задачи).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from core.vault import Note, write_note

__all__ = ["IdeaWrite", "idea_filename", "split_title", "write_idea"]

TITLE_MAX = 60
_BAD_CHARS = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


def split_title(text: str) -> tuple[str, str]:
    """``(первая непустая строка, остальной текст)``; пустой текст - ``("Идея", "")``."""
    lines = [ln for ln in (text or "").strip().splitlines()]
    for i, line in enumerate(lines):
        if line.strip():
            title = line.strip().lstrip("#").strip() or line.strip()
            return title, "\n".join(lines[i + 1:]).strip()
    return "Идея", ""


def idea_filename(title: str) -> str:
    """Имя файла без расширения: заголовок до 60 символов, без недопустимых в имени файла знаков."""
    name = _BAD_CHARS.sub(" ", title)
    name = " ".join(name.split()).strip(" .")[:TITLE_MAX].strip(" .")
    return name or "Идея"


def _footer(task_id: str, captured_at: str, modified: str) -> str:
    return "\n".join(["---", "источник: ticktick", "lane: личное", f"taskId: {task_id}",
                      f"captured: {captured_at}", f"modified: {modified}"])


@dataclass(frozen=True)
class IdeaWrite:
    path: Path
    title: str


def _free_name(folder: Path, stem: str, when: datetime) -> Path:
    plain = folder / f"{stem}.md"
    if not plain.exists():
        return plain
    stamped = folder / f"{stem} {when:%H%M}.md"
    n = 1
    candidate = stamped
    while candidate.exists():
        n += 1
        candidate = folder / f"{stem} {when:%H%M}-{n}.md"
    return candidate


def write_idea(
    vault: Path, ideas_dir: str, when: datetime, text: str, *, task_id: str, modified: str,
    captured_at: str,
) -> IdeaWrite:
    """Создать заметку идеи; возвращает путь и заголовок. Существующие файлы не перезаписываются."""
    title, rest = split_title(text)
    folder = Path(vault) / ideas_dir
    folder.mkdir(parents=True, exist_ok=True)
    path = _free_name(folder, idea_filename(title), when)
    meta = {"title": title, "date": f"{when:%Y-%m-%d}", "time": f"{when:%H:%M}",
            "tags": ["idea"], "linked_notes": []}
    body = (f"{rest}\n\n" if rest else "") + _footer(task_id, captured_at, modified) + "\n"
    write_note(Note(id=path.stem, type=None, path=path, frontmatter=meta, body=body))
    return IdeaWrite(path=path, title=title)
