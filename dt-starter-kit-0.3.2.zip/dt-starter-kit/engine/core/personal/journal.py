"""PERSONAL-1 п.3 - заметка дня: ``05-journal/ГГГГ-ММ-ДД.md``, одна на день.

Папка дневника - ручка экземпляра ``DT_PERSONAL_JOURNAL_DIR`` (PERSONAL-2; дефолт ``05-journal``).
Запись ``#дневник`` из TickTick дописывается секцией ``## ЧЧ:ММ`` с provenance-футером (тот же, что
у inbox-захватов: источник, lane, taskId, captured, modified). Заметка - ``type: journal``.
Повторный захват ТОЙ ЖЕ задачи (она изменилась в TickTick) обновляет свою секцию по ``taskId``,
а не плодит дубль.

Писатель - движок (``core.vault.write_note``), в vault шеллом не пишем. Детерминированно: размещение
следует из даты, Путь B (предложение хоста) не нужен.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import UTC, datetime, tzinfo
from pathlib import Path
from typing import Any

from core.vault import Note, read_note, write_note

__all__ = ["JOURNAL_DIR", "JournalWrite", "day_path", "entry_time", "upsert_entry"]

JOURNAL_DIR = "05-journal"
_SECTION_RE = re.compile(r"(?m)^## (\d{2}:\d{2})[ \t]*$")
_HEADING_RE = re.compile(r"(?m)^(#{1,2}) ")


@dataclass(frozen=True)
class JournalWrite:
    path: Path
    created: bool  # заметки дня не было
    replaced: bool  # обновлена секция той же задачи (а не добавлена новая)
    heading: str


def entry_time(task: dict[str, Any], tz: tzinfo | None = None) -> datetime:
    """Момент записи для заметки дня: ``createdTime`` задачи, иначе ``modifiedTime``, иначе сейчас;
    в часовом поясе ``tz`` (по умолчанию - местный: «время суток» читает человек)."""
    for key in ("createdTime", "modifiedTime"):
        raw = str(task.get(key) or "").strip()
        if not raw:
            continue
        try:
            when = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError:
            continue
        if when.tzinfo is None:
            when = when.replace(tzinfo=UTC)
        return when.astimezone(tz)
    return datetime.now(UTC).astimezone(tz)


def day_path(vault: Path, when: datetime, journal_dir: str | None = None) -> Path:
    """Заметка дня: ``<vault>/<папка дневника>/ГГГГ-ММ-ДД.md``; папка - ``DT_PERSONAL_JOURNAL_DIR``
    (PERSONAL-2), без ручки - ``05-journal``."""
    from core.instance import personal_journal_dir

    return Path(vault) / (journal_dir or personal_journal_dir()) / f"{when:%Y-%m-%d}.md"


def _safe(text: str) -> str:
    """Заголовки ``#``/``##`` из текста записи экранируем: ``## ЧЧ:ММ`` - разметка секций дня."""
    return _HEADING_RE.sub(lambda m: "\\" + m.group(1) + " ", text.strip())


def _footer(lane_tag: str, task_id: str, captured_at: str, modified: str) -> str:
    return "\n".join(["---", "источник: ticktick", f"lane: {lane_tag}", f"taskId: {task_id}",
                      f"captured: {captured_at}", f"modified: {modified}"])


def _split(body: str) -> tuple[str, list[tuple[str, str]]]:
    """Тело дня → (преамбула, [(время, содержимое секции)])."""
    marks = list(_SECTION_RE.finditer(body))
    if not marks:
        return body, []
    pre = body[: marks[0].start()]
    out = []
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(body)
        out.append((m.group(1), body[m.end():end].strip("\n")))
    return pre, out


def upsert_entry(
    vault: Path, when: datetime, text: str, *, task_id: str, modified: str, captured_at: str,
    lane_tag: str = "дневник", target: Path | None = None,
) -> JournalWrite:
    """Записать запись в заметку дня: новая секция ``## ЧЧ:ММ`` либо обновление секции задачи.

    ``target`` - заметка, где запись уже лежит (путь из dedup-стейта): правка задачи обновляет ту же
    секцию, даже если дата ``createdTime`` теперь иная. Нет заметки дня - создается с ``type:
    journal``."""
    path = Path(target) if target is not None else day_path(vault, when)
    heading = f"{when:%H:%M}"
    entry = f"{_safe(text)}\n\n{_footer(lane_tag, task_id, captured_at, modified)}"
    marker = f"taskId: {task_id}\n"

    if path.is_file():
        note = read_note(path, Path(vault))
        pre, sections = _split(note.body)
        replaced = False
        for i, (hh, content) in enumerate(sections):
            if marker in content + "\n":
                sections[i] = (hh, entry)  # время секции остается первоначальным
                heading, replaced = hh, True
                break
        if not replaced:
            sections.append((heading, entry))
        body = pre.rstrip("\n") + "\n\n" + "\n\n".join(
            f"## {hh}\n\n{content}" for hh, content in sections) + "\n"
        write_note(Note(id=note.id, type=note.type, path=path, frontmatter=dict(note.frontmatter),
                        body=body))
        return JournalWrite(path, created=False, replaced=replaced, heading=heading)

    path.parent.mkdir(parents=True, exist_ok=True)
    day = f"{when:%Y-%m-%d}"
    body = f"# {day}\n\n## {heading}\n\n{entry}\n"
    meta = {"type": "journal", "date": day}
    write_note(Note(id=day, type="journal", path=path, frontmatter=meta, body=body))
    return JournalWrite(path, created=True, replaced=False, heading=heading)
