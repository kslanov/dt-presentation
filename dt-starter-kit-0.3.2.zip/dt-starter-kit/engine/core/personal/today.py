"""PERSONAL-2 п.5 - «Сегодня» личного пульта: заметка дня (последние секции) + инбокс личного.

Только чтение (инструмент ``personal_today`` личного экземпляра). Заметка дня - та же, что пишет
захват ``#дневник`` (:mod:`core.personal.journal`); из секций отдаются последние ``sections`` -
время и текст БЕЗ служебного футера. Инбокс - ``_staging/inbox`` (``DT_PERSONAL_INBOX``): имя файла,
``lane`` из футера и первая строка текста.
"""

from __future__ import annotations

from datetime import datetime, tzinfo
from pathlib import Path
from typing import Any

from core.personal.journal import _split, day_path
from core.vault import read_note

__all__ = ["today"]

_PREVIEW = 120


def _strip_footer(content: str) -> str:
    """Текст секции без провенанс-футера (``---`` + ``источник: …`` и далее)."""
    marker = "\n---\nисточник:"
    cut = content.find(marker)
    return (content[:cut] if cut >= 0 else content).strip()


def _first_line(text: str) -> str:
    for line in text.splitlines():
        if line.strip() and not line.strip().lower().startswith(
                ("---", "источник:", "lane:", "taskid:", "captured:", "modified:")):
            return line.strip()[:_PREVIEW]
    return ""


def today(
    vault: Path, *, now: datetime | None = None, tz: tzinfo | None = None, sections: int = 3,
    inbox_limit: int = 20,
) -> dict[str, Any]:
    """``{date, path, exists, sections: [{time, text}], journal_dir, inbox: {count, items}, capture:
    {project, untagged_lane, same_project}}`` (``project`` пуст - список рабочего)."""
    from core.ingest import inbox_lane, list_inbox
    from core.instance import personal_ideas_dir, personal_journal_dir

    vault = Path(vault)
    when = now or datetime.now(tz).astimezone(tz)
    path = day_path(vault, when)
    from core.personal.capture_source import describe

    cap = describe()  # PERSONAL-3: откуда берется захват и куда идут задачи без тега
    out: dict[str, Any] = {
        "date": f"{when:%Y-%m-%d}", "path": path.relative_to(vault).as_posix(),
        "exists": path.is_file(), "sections": [], "journal_dir": personal_journal_dir(),
        "ideas_dir": personal_ideas_dir(),
        "capture": {"project": cap["project"], "untagged_lane": cap["lane"],
                    "same_project": cap["same_project"]},
    }
    if path.is_file():
        try:
            _pre, parts = _split(read_note(path, vault).body)
        except Exception:  # noqa: BLE001 - битая заметка дня не роняет виджет
            parts = []
        out["sections"] = [{"time": hh, "text": _strip_footer(text)} for hh, text in parts][
            -max(1, sections):]
    from core.config import staging_inbox_path

    items = list_inbox(staging_inbox_path(vault))
    out["inbox"] = {
        "count": len(items),
        "items": [{"name": i.path.name, "lane": inbox_lane(i) or "", "preview": _first_line(i.text)}
                  for i in items[:inbox_limit]],
    }
    return out
