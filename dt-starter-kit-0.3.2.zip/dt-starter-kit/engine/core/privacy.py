"""NDA barrier — one predicate, enforced on every path (NDA-1).

Concept principle: commercial secrets never enter the inference context (prompts).
Before NDA-1 the barrier was leaky and one-sided — the index dropped ``_``-folders
but not ``report_nda.md`` files, and SRC-1's ``lift_source`` read *any* absolute
path with no privacy filter, so an NDA file could be lifted, its facts extracted,
and shipped into a prompt. The fix is a single predicate, :func:`is_nda`, reused at
every layer (index + lift + facts + exemplar): "decide once, enforce on every path"
— otherwise NDA leaks through whichever layer skipped the check.

:func:`is_nda` is **pure string logic over the path structure** — no file read, no
network, no LLM, no content scan (принцип 9: an inspectable path marker, never a
"CONFIDENTIAL"-in-the-body heuristic). It matches by **path structure** (a
directory segment equal to / prefixed by a marker, or a filename stem ending in a
marker), case-insensitively and NFC-normalized — deliberately **not** by absolute
prefix, because the operational sources live outside the vault in an iCloud folder
whose absolute path differs per device, while the ``_nda/`` segment and ``_nda``
suffix are invariant.

**NDA-2 (инцидент 16.08).** Каталог и файл симметричны: сегмент, ОКАНЧИВАЮЩИЙСЯ
маркером (``x_nda/``, ``проект_nda/``), — NDA на любой позиции пути. Раньше суффикс
работал только на последнем сегменте, и ``x_nda/БПЛА/f.pdf`` проходил барьер. Плюс
:func:`any_nda` — тот же предикат по НЕСКОЛЬКИМ путям одной заметки (её путь и
``source_path``): слугифицированное имя заметки маркер теряет, а её источник — нет.

Invariants: this module has **no core dependencies** beyond the dependency-free
:mod:`core.config` (so it imports cleanly into every layer with no cycles); Path B
— deterministic, offline, never reads the file.
"""

from __future__ import annotations

import unicodedata
from pathlib import Path

from core.config import nda_markers

__all__ = ["EVAL_MARKER", "any_eval", "any_nda", "is_eval", "is_nda", "normalized_markers"]


def _normalize(text: str) -> str:
    """NFC-normalize + lowercase, so a marker matches an NFD macOS filename too."""
    return unicodedata.normalize("NFC", text).lower()


def normalized_markers() -> list[str]:
    """Configured NDA markers, NFC-normalized + lowercased (default ``_nda``).

    Empty / malformed config falls back to the default in
    :func:`core.config.nda_markers` — the barrier is never disabled.
    """
    return [_normalize(m) for m in nda_markers() if m and m.strip()]


def _segment_matches(segment: str, marker: str, *, is_last: bool) -> bool:
    """Does one path component trip a marker? Каталог и файл — СИММЕТРИЧНО (NDA-2).

    Три формы, любая из которых делает сегмент NDA-маркированным:

    * **префикс** — сегмент равен маркеру или маркер + разделитель (``_nda``,
      ``_nda-2024``, ``_nda_x``), но не ``_ndax`` (следом буква/цифра);
    * **суффикс** — сегмент ОКАНЧИВАЕТСЯ маркером (``x_nda``, ``проект_nda``) на
      ЛЮБОЙ позиции пути;
    * **стем файла** (последний сегмент) — то же по имени без расширения
      (``отчёт_nda.pdf``).

    Суффикс на каталогах — инцидент 16.08 (NDA-2). До него он работал ТОЛЬКО для
    последнего сегмента, и путь ``x_nda/БПЛА/f.pdf`` барьер не ловил, хотя ``x_nda``
    последним сегментом — ловил. Человек читает ``*_nda`` как маркер на чём угодно;
    несимметрия дала две заметки под NDA в vault и вопрос «какого хрена из папки nda
    на индексе?». Ложные срабатывания держит сам маркер: он начинается с ``_``, а
    значит ``agenda``/``фонда`` (нет ``_``) не оканчиваются на ``_nda``. Маркер без
    разделителя (``DT_NDA_MARKERS=nda``) — осознанный выбор конфигуратора: он ловит
    ``agenda`` и на каталоге, и на файле — одинаково, а не через раз.
    """
    if segment.startswith(marker):
        nxt = segment[len(marker) : len(marker) + 1]
        if not nxt.isalnum():  # exact ("") or a separator like -, _, ., space
            return True
    if segment.endswith(marker):
        return True
    if is_last:
        stem = segment.rsplit(".", 1)[0] if "." in segment else segment
        if stem.endswith(marker):
            return True
    return False


def is_nda(path: str | Path | None) -> bool:
    """True when ``path`` is NDA-marked by its structure (NDA-1 PART-1).

    Pure, deterministic path-string logic — no file read. A path is NDA when, for
    any configured marker (case-insensitive, NFC-normalized): a path segment equals
    the marker, is prefixed by ``marker`` + separator (``_nda/``, ``_nda-2024/``),
    **ends with the marker** (``x_nda/``, ``проект_nda/`` — NDA-2, каталог и файл
    симметричны), or the filename stem ends with it (``report_nda.xlsx``).
    Matched on the path **structure** (per-segment / suffix), never on an absolute
    prefix — so it holds across devices where the iCloud root path differs.
    """
    if path is None:
        return False
    raw = str(path)
    if not raw.strip():
        return False

    norm = _normalize(raw).replace("\\", "/")
    segments = [s for s in norm.split("/") if s]
    if not segments:
        return False

    markers = normalized_markers()
    last_idx = len(segments) - 1
    for i, segment in enumerate(segments):
        is_last = i == last_idx
        for marker in markers:
            if _segment_matches(segment, marker, is_last=is_last):
                return True
    return False


# EVAL-HYGIENE-1: маркер карантина прогонов eval/selftest - ТОТ ЖЕ класс маркера пути, что ``_nda``
# (сегмент / префикс / суффикс / стем файла, NFC, без учета регистра; одна функция
# ``_segment_matches`` на оба). Маркер фиксирован (не конфигурируется): карантин нельзя выключить
# настройкой.
EVAL_MARKER = "_eval"


def is_eval(path: str | Path | None) -> bool:
    """True, если путь лежит в карантине прогонов (``<корень>/_eval/…``) по СТРУКТУРЕ пути.

    Чистая строковая логика, как :func:`is_nda`: без чтения файла и без абсолютного префикса (он
    разный на устройствах). Файлы под ``_eval`` не идут в знание: ``file_ingest``, индекс,
    ретривал, ``find_latest``, OCR их не видят."""
    if path is None:
        return False
    raw = str(path)
    if not raw.strip():
        return False
    segments = [s for s in _normalize(raw).replace("\\", "/").split("/") if s]
    last_idx = len(segments) - 1
    return any(
        _segment_matches(seg, EVAL_MARKER, is_last=i == last_idx)
        for i, seg in enumerate(segments)
    )


def any_eval(*paths: str | Path | None) -> bool:
    """Карантин, если ЛЮБАЯ из ссылок заметки (путь / ``source_path``) под ``_eval``."""
    return any(is_eval(p) for p in paths)


def any_nda(*paths: str | Path | None) -> bool:
    """NDA, если под барьером ЛЮБАЯ из ссылок (путь заметки ИЛИ её ``source_path``).

    Не второй матчер, а тот же :func:`is_nda` по нескольким полям одной сущности.
    Нужен потому, что у заметки ДВА пути, и NDA-ность может жить только в одном:
    легаси-рендер слугифицирует имя (``About_EC_НМ_NDA.pptx`` → ``about-ec-nm-nda-
    e123d3f0.md``), и подчёркивание из маркера теряется — путь заметки чист, а её
    источник под NDA. Проверять только путь заметки — значит индексировать такой
    документ (найдено sweep'ом NDA-2 на живом индексе).
    """
    return any(is_nda(p) for p in paths)
