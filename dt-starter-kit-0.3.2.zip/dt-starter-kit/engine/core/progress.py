"""ACT-1 — прогресс-маяки долгих операций (единый хелпер, roadmap §UX-5/PERF-1).

Одна точка наблюдаемости для index / link / mail / dt-sync: каждая долгая
операция ведёт :class:`ProgressBeacon`, который

* печатает прогресс-строку в stdout **с ``flush=True``** (закрывает flush-хвост
  PERF-1: под launchd/pipe строки видны живьём, формат существующих
  ``[index]``/``[link]``/``[mail]``-строк не меняется — текст формирует
  вызывающий);
* атомарно (tmp + ``os.replace``) пишет маяк ``.derived/status/<proc>.json``:
  ``{proc, pid, phase, current, total, eta_s, extra, started, updated}`` — не
  чаще раза в :data:`BEACON_INTERVAL_S` (``phase``/``done`` пишут сразу);
* :meth:`ProgressBeacon.done` ставит ``finished: true`` + ``summary`` и лениво
  подчищает маяки старше :data:`BEACON_TTL_DAYS` дней.

Прерванный процесс маяк не трогает — ``pult_activity`` увидит живой файл с
мёртвым pid и покажет «interrupted» (продолжится от чекпойнта: index/link/mail
и так resumable).

Rules (как у :mod:`core.metrics`):

* **Best-effort, never in the way** — любой сбой записи маяка проглатывается:
  наблюдаемость НИКОГДА не роняет наблюдаемую операцию.
* **Privacy** — в маяке только счётчики, фазы и обезличенные extra; имена
  клиентов/сделок и тексты заметок сюда не передаются by design.
* **Путь — функция** :func:`core.config.status_dir` (читает ``DT_DERIVED_ROOT`` в момент
  вызова); тесты изолируются одной переменной в ``tests/conftest.py`` — её наследуют и
  подпроцессы (monkeypatch атрибута модуля они не видят).

Инвариант: ``core/`` не зависит от mcp/cli; сети и LLM здесь нет.
"""

from __future__ import annotations

import contextlib
import json
import os
import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from core import runlock
from core.config import status_dir

__all__ = ["BEACON_INTERVAL_S", "BEACON_TTL_DAYS", "ProgressBeacon"]

# Каталог маяков — ``core.config.status_dir()`` (TEST-SANDBOX-1: функция, не константа).

# Маяк пишется не чаще раза в столько секунд (update; phase/done — сразу).
BEACON_INTERVAL_S = 5.0

# Ленивая уборка: done() удаляет чужие маяки старше стольких дней (по mtime).
BEACON_TTL_DAYS = 7


def _utc_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


class ProgressBeacon:
    """Прогресс одной долгой операции: stdout-строки + json-маяк для пульта.

    ``emit`` (default: ``print(..., flush=True)``) получает готовые
    прогресс-строки — вызывающий передаёт свой ``log``-callable, чтобы захват
    вывода (dt-sync, тесты) работал как раньше. ``interval_s`` переопределяет
    throttle в тестах.
    """

    def __init__(
        self,
        proc: str,
        total: int | None = None,
        *,
        emit: Callable[[str], None] | None = None,
        interval_s: float | None = None,
    ) -> None:
        self.proc = str(proc).replace("/", "-")
        self.total = int(total) if total is not None else None
        self.pid = os.getpid()
        self.started = _utc_iso()
        self.current = 0
        self.extra: dict[str, Any] = {}
        self.phase_name: str | None = None
        self.steps: dict[str, dict[str, Any]] = {}
        self._emit = emit if emit is not None else (lambda line: print(line, flush=True))
        self._interval = BEACON_INTERVAL_S if interval_s is None else float(interval_s)
        self._t0 = time.monotonic()
        self._last_write = float("-inf")

    # -- public API (ТЗ ACT-1 §1) ---------------------------------------------
    def update(
        self,
        current: int,
        extra: dict[str, Any] | None = None,
        *,
        line: str | None = None,
    ) -> None:
        """Продвинуть прогресс: напечатать ``line`` (flush) + маяк (throttled)."""
        if line is not None:
            self._emit(line)
        runlock.beat()  # ADAPTER-HONEST-1: тик прогресса = сердцебиение lock'а прогона
        self.current = int(current)
        if extra is not None:
            self.extra = dict(extra)
        self._write(throttled=True)

    def phase(self, name: str) -> None:
        """Сменить фазу (шаг оркестрации и т.п.) — маяк пишется сразу."""
        self.phase_name = str(name)
        runlock.beat(step=str(name))
        self._write(throttled=False)

    def set_step(self, name: str, record: dict[str, Any]) -> None:
        """NIGHT-CHAIN-1: запись о шаге (``started/finished/elapsed_s/exit``) - в ``steps`` маяка.

        Пишется сразу (не по throttle): по маяку видно, на каком шаге прогон и сколько шли
        прошлые. Порядок вставки = порядок шагов."""
        self.steps[str(name)] = dict(record)
        self._write(throttled=False)

    def done(self, summary: str = "") -> None:
        """Финальный маяк ``finished: true`` + ленивое подчищение старых."""
        runlock.beat()
        self._write(throttled=False, finished=True, summary=str(summary))
        self._prune()

    # -- internals -------------------------------------------------------------
    def _eta_s(self) -> int | None:
        if not self.total or not self.current:
            return None
        elapsed = time.monotonic() - self._t0
        if elapsed <= 0:
            return None
        rate = self.current / elapsed
        if rate <= 0:
            return None
        return int(max(0, self.total - self.current) / rate)

    def _write(
        self, *, throttled: bool, finished: bool = False, summary: str | None = None
    ) -> None:
        """Атомарная запись маяка — best-effort, никогда не бросает."""
        try:
            now_mono = time.monotonic()
            if throttled and (now_mono - self._last_write) < self._interval:
                return
            body: dict[str, Any] = {
                "proc": self.proc,
                "pid": self.pid,
                "phase": self.phase_name,
                "current": self.current,
                "total": self.total,
                "eta_s": None if finished else self._eta_s(),
                "extra": self.extra,
                "started": self.started,
                "updated": _utc_iso(),
            }
            if self.steps:
                body["steps"] = self.steps
            if finished:
                body["finished"] = True
                body["summary"] = summary or ""
            directory = status_dir()
            directory.mkdir(parents=True, exist_ok=True)
            target = directory / f"{self.proc}.json"
            tmp = target.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(body, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, target)
            self._last_write = now_mono
        except Exception:  # noqa: BLE001, S110 — маяк никогда не роняет операцию
            pass

    def _prune(self) -> None:
        """Удалить маяки старше TTL (по mtime файла). Best-effort."""
        try:
            cutoff = time.time() - BEACON_TTL_DAYS * 86400
            for path in status_dir().glob("*.json"):
                with contextlib.suppress(OSError):
                    if path.stat().st_mtime < cutoff:
                        path.unlink()
        except Exception:  # noqa: BLE001, S110 — уборка тем более не роняет операцию
            pass
