"""PROV-SESSION-1 — сессионный провенанс выхода: что сессия читала, поднимала и искала.

До этого ``sources.md`` ad-hoc-выхода собирался из двух вещей: подъёмов ``lift_source`` за окно
(аудит-журнал) и ручного ``sources=``. Почти вся справочная работа идёт через ``read_note``/
``get_facts``/``find_*``, а не через ``lift_source`` — и этих чтений в провенансе не было. Окно
``output_begin → save_output`` держалось на дисциплине хоста (13 из 18 выходов октября — без
``output_begin``; у остальных окно 0-1 минута). Сырьё для сессионного разреза уже пишется — это
журнал запросов EVAL-2 (:mod:`core.eval_journal`, ``sid`` + ``host`` в каждом событии).

Модуль даёт три вещи:

* :func:`session_window` — окно СЕССИИ вместо окна «последние N часов» (:class:`SessionWindow`);
* :func:`collect_session_sources` — строки ``read``/``lift``/``facts`` + секция поиска
  (:class:`SessionProvenance`). Поиски — КАНДИДАТЫ, а не источники: в таблицу не попадают;
* строки и их слияние (:class:`SourceRow`, :func:`merge_sources`) — переехали из ``core.output``
  (там остался реэкспорт).

Privacy: из журнала берутся только id, пути и аргументы поиска; тексты заметок здесь не читаются
для записи в файл (читается frontmatter заметки ради пути/даты/источника). Второй замок NDA —
``any_nda`` по id/пути/source_path каждой строки. Сети и LLM нет.

Инвариант слоя: ``core.provenance`` не импортирует ``core.output`` на уровне модуля (output
реэкспортирует отсюда) — только лениво внутри функций.
"""

from __future__ import annotations

import json
import os
from collections.abc import Iterable
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

__all__ = [
    "DEFAULT_ADHOC_SOURCES_H",
    "DEFAULT_LATE_BEGIN_MIN",
    "KIND_BEGIN",
    "KIND_HOST",
    "KIND_HOURS",
    "KIND_SESSION",
    "ORIGIN_FACTS",
    "ORIGIN_LIFT",
    "ORIGIN_MANUAL",
    "ORIGIN_READ",
    "ORIGIN_TELEMETRY",
    "SearchRow",
    "SessionProvenance",
    "SessionWindow",
    "SourceRow",
    "adhoc_sources_hours",
    "collect_lift_sources",
    "collect_session_sources",
    "late_begin_minutes",
    "manual_sources",
    "merge_rows",
    "merge_sources",
    "parse_manual_rows",
    "render_search_lines",
    "render_source_table",
    "render_window_line",
    "session_window",
]

# SRC-TRACE-2 — окно телеметрии для выхода БЕЗ сессии (``save_output(title=…)`` без sid/журнала):
# честная пометка «окно, а не сессия» идёт в sources.md.
DEFAULT_ADHOC_SOURCES_H = 8.0
_ADHOC_SOURCES_ENV = "DT_ADHOC_SOURCES_H"
# Поздний ``output_begin``: хост зовёт его перед самым save_output - это не начало работы.
DEFAULT_LATE_BEGIN_MIN = 3.0
_LATE_BEGIN_ENV = "DT_PROV_LATE_BEGIN_MIN"

# Происхождение строки sources.md. Порядок значим: так склеивается ``read+lift+manual``.
ORIGIN_READ = "read"
ORIGIN_LIFT = "lift"
ORIGIN_FACTS = "facts"
ORIGIN_MANUAL = "manual"
ORIGIN_TELEMETRY = ORIGIN_LIFT  # прежнее имя (SRC-TRACE-2): подъём теперь называется ``lift``
_ORIGIN_ORDER = (ORIGIN_READ, ORIGIN_LIFT, ORIGIN_FACTS, ORIGIN_MANUAL)
_LEGACY_ORIGINS = {"telemetry": ORIGIN_LIFT}  # старые файлы не трогаем, но читаем

# Вид окна (шапка sources.md и ``sources.window.kind`` в ответе save_output).
KIND_SESSION = "session"  # сегмент сессии по журналу (sid)
KIND_BEGIN = "begin"      # от постановки (output_begin)
KIND_HOST = "host"        # sid неизвестен - сегмент по хосту
KIND_HOURS = "hours"      # ничего не известно - последние N часов

# В провенанс идут только удавшиеся подъёмы: ``unavailable``/``nda_refused`` означают, что
# содержимого сессия не видела.
_LIFT_TOOL = "lift_source"
_LIFT_OK_OUTCOMES = ("ok",)
_READ_TOOLS = ("read_note", "work_note_preview")
_OWN_FILES = ("output.md", "prompt.md", "sources.md")
_SEARCH_LINES_MAX = 30
_TS_FMT = "%Y-%m-%dT%H:%M:%SZ"


# --------------------------------------------------------------------------- #
# Строки                                                                       #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class SourceRow:
    """Одна строка таблицы источников ``sources.md``.

    ``mtime`` — дата САМОГО ИСТОЧНИКА (не подъёма/чтения): она в каждой строке by design —
    разрыв «источник 2023 года в справке от 2026-го» виден при чтении провенанса.
    ``note_id`` — id прочитанной заметки (``read``); ``hub`` — это хаб клиента/продукта из
    каталога (идёт в «## Связано»); ``detail`` — машинная оговорка («прочитано 3 из 5»).
    """

    path: str
    origin: str
    kind: str = ""
    mtime: float | None = None
    content_hash: str = ""
    what_taken: str = ""
    lifted_at: datetime | None = None
    note_id: str = ""
    hub: bool = False
    detail: str = ""

    @property
    def name(self) -> str:
        return Path(self.path).name or self.path


@dataclass(frozen=True)
class SearchRow:
    """Поиск сессии: кандидаты, НЕ источники (``top_ids`` — то, что выдал поиск)."""

    tool: str
    args: dict[str, Any]
    top_ids: tuple[str, ...] = ()
    count: int = 1


@dataclass(frozen=True)
class SessionWindow:
    """Окно сбора: ``[since, until]`` и как оно определено (``kind``)."""

    since: datetime
    until: datetime
    kind: str
    sid: str = ""
    host: str = ""

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "kind": self.kind,
            "since": self.since.astimezone(UTC).strftime(_TS_FMT),
            "until": self.until.astimezone(UTC).strftime(_TS_FMT),
        }
        if self.sid:
            out["sid"] = self.sid
        return out


@dataclass
class SessionProvenance:
    """Итог сборщика: строки источников, поиски, окно."""

    rows: list[SourceRow] = field(default_factory=list)
    searches: list[SearchRow] = field(default_factory=list)
    window: SessionWindow | None = None

    def count(self, origin: str) -> int:
        return sum(1 for r in self.rows if origin in r.origin.split("+"))


def _positive_float(name: str, default: float) -> float:
    raw = os.environ.get(name, "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return default
    return value if value > 0 else default


def adhoc_sources_hours() -> float:
    """Окно телеметрии без сессии, часы (env ``DT_ADHOC_SOURCES_H``, дефолт 8; мусор → дефолт)."""
    return _positive_float(_ADHOC_SOURCES_ENV, DEFAULT_ADHOC_SOURCES_H)


def late_begin_minutes() -> float:
    """Порог «позднего» ``output_begin``, минут (``DT_PROV_LATE_BEGIN_MIN``, дефолт 3)."""
    return _positive_float(_LATE_BEGIN_ENV, DEFAULT_LATE_BEGIN_MIN)


def _join_origin(*origins: str) -> str:
    parts = {
        _LEGACY_ORIGINS.get(p, p) for o in origins for p in str(o).split("+") if p
    }
    return "+".join(sorted(parts, key=lambda p: (
        _ORIGIN_ORDER.index(p) if p in _ORIGIN_ORDER else len(_ORIGIN_ORDER), p)))


def merge_rows(*groups: Iterable[SourceRow]) -> list[SourceRow]:
    """Объединить строки: дедуп по пути, происхождения складываются (``read+lift``).

    Порядок — первого появления пути. Путь, названный в нескольких группах, даёт ОДНУ строку:
    видно, что его и читали, и поднимали, и (если есть) человек сказал, что оттуда взято.
    """
    by_path: dict[str, SourceRow] = {}
    for group in groups:
        for row in group:
            prev = by_path.get(row.path)
            if prev is None:
                by_path[row.path] = row
                continue
            by_path[row.path] = SourceRow(
                path=prev.path,
                origin=_join_origin(prev.origin, row.origin),
                kind=prev.kind or row.kind,
                mtime=prev.mtime if prev.mtime is not None else row.mtime,
                content_hash=prev.content_hash or row.content_hash,
                what_taken=row.what_taken if ORIGIN_MANUAL in row.origin else prev.what_taken,
                lifted_at=prev.lifted_at or row.lifted_at,
                note_id=prev.note_id or row.note_id,
                hub=prev.hub or row.hub,
                detail=prev.detail or row.detail,
            )
    return list(by_path.values())


def merge_sources(auto: list[SourceRow], manual: list[SourceRow]) -> list[SourceRow]:
    """Автострока + ручные: дедуп по пути, ручное не вытесняет (``lift+manual``).

    Автоматические строки идут первыми (порядок появления), ручные — за ними.
    """
    return merge_rows(auto, manual)


def _stat_mtime(path: str) -> float | None:
    try:
        return Path(path).stat().st_mtime
    except OSError:
        return None


def manual_sources(items: list[dict] | None) -> list[SourceRow]:
    """``[{path, what_taken?}]`` → строки ``origin: manual``.

    Ручное объявление НЕ заменяет автосбор, а дополняет его: чем-то сессия пользовалась мимо
    DT (переписка в чате, бумага, устная фактура), и ``what_taken`` — единственное место, где
    написано, ЧТО именно оттуда взято. Записи без пути молча пропускаются; дата — живым ``stat``.
    """
    out: list[SourceRow] = []
    seen: set[str] = set()
    for item in items or []:
        if not isinstance(item, dict):
            continue
        path = str(item.get("path") or "").strip()
        if not path or path in seen:
            continue
        seen.add(path)
        out.append(
            SourceRow(
                path=path,
                origin=ORIGIN_MANUAL,
                kind=Path(path).suffix.lower().lstrip(".") or "",
                mtime=_stat_mtime(path),
                what_taken=" ".join(str(item.get("what_taken") or "").split()),
            )
        )
    return out


# --------------------------------------------------------------------------- #
# Окно сессии                                                                  #
# --------------------------------------------------------------------------- #
def _ident_matches(ev_sid: str, ev_host: str, sid: str, host: str, by_host: bool) -> bool:
    """Событие/аудит-строка принадлежит этой сессии?

    ``sid`` известен → точное совпадение ``sid``. Пустой ``sid`` (stdio/CLI/пульт) или режим
    ``by_host`` (ретро: у старых записей журнала ``sid`` нет) → по хосту; без ``by_host`` у
    события тогда не должно быть своего ``sid`` (чужая http-сессия того же хоста - не наша).
    """
    ev_host = ev_host or "cli"
    if by_host:
        return ev_host == (host or "cli")
    if sid:
        return ev_sid == sid
    return not ev_sid and ev_host == (host or "cli")


def _parse_ts(value: Any) -> datetime | None:
    try:
        return datetime.strptime(str(value), _TS_FMT).replace(tzinfo=UTC)
    except ValueError:
        return None


def _begin_created(meta: dict[str, Any]) -> datetime | None:
    """Время ``output_begin`` из меты (ключ ``status`` пишет только он) либо ``None``.

    У ad-hoc-папки DOD-1 (``save_output(title=…)``) ``created`` — время СОХРАНЕНИЯ, не начала
    работы, поэтому без ``status`` оно не годится.
    """
    raw = str(meta.get("created") or "").strip() if meta.get("status") else ""
    if not raw:
        return None
    try:
        started = datetime.fromisoformat(raw)
    except ValueError:
        return None
    if started.tzinfo is None:
        started = started.astimezone()  # мета пишется в локальном времени
    return started


def _previous_save_end(
    out_dir: Path, until: datetime, floor: datetime, sid: str, host: str, by_host: bool,
    actions_path: Path | None,
) -> datetime | None:
    """Конец ПРЕДЫДУЩЕГО ``save_output`` той же сессии (по аудиту) - граница сегмента.

    Сохранения ЭТОЙ ЖЕ папки не считаются: повторный save_output того же выхода пересобирает
    провенанс с прежнего начала, а не от самого себя.
    """
    from core.operational.pult import read_actions

    own = str(Path(out_dir))
    last: datetime | None = None
    for action in read_actions(tools=("save_output",), since=floor, until=until,
                               path=actions_path):
        if action.at >= until or own in action.args.get("path", ""):
            continue
        if not _ident_matches(action.args.get("sid", ""), action.args.get("host", ""),
                              sid, host, by_host):
            continue
        last = action.at if last is None or action.at > last else last
    return last


def session_window(
    out_dir: Path,
    sid: str = "",
    host: str = "",
    *,
    now: datetime | None = None,
    by_host: bool = False,
    events: list[dict[str, Any]] | None = None,
    actions_path: Path | None = None,
) -> SessionWindow:
    """Окно сбора источников для папки выхода (вместо ``sources_window``).

    ``since`` — САМОЕ ПОЗДНЕЕ из: начала сессии по журналу (первое событие этого ``sid``;
    пустой ``sid`` - первое событие хоста), конца предыдущего ``save_output`` той же сессии (по
    аудиту ``pult-actions.log``; пустой ``sid`` - того же хоста) и ``now - DT_ADHOC_SOURCES_H``.
    Если ``output_begin`` этого выхода РАНЬШЕ этой точки - ``since`` = его ``created`` (хост
    поставил задачу до работы); журнал о сессии молчит, а ``output_begin`` есть - окно от него.
    «Поздний» ``begin`` (позже ``now - DT_PROV_LATE_BEGIN_MIN`` при более ранних событиях
    сессии) - не начало работы: берётся сегмент.

    ``kind``: ``begin`` | ``session`` (sid известен, события есть) | ``host`` (sid неизвестен,
    события хоста есть) | ``hours`` (ничего не известно - последние N часов, «окно, а не сессия»).
    ``events`` - журнал для подстановки (тесты/ретро); ``by_host`` - ретро по записям без ``sid``.
    """
    from core.eval_journal import read_events
    from core.output import read_meta

    until = now or datetime.now(UTC)
    hours_floor = until - timedelta(hours=adhoc_sources_hours())
    begin = _begin_created(read_meta(Path(out_dir) / "meta.yaml"))
    floor = min(hours_floor, begin) if begin is not None else hours_floor
    pool = events if events is not None else read_events()  # весь журнал: начало сессии - из него
    seen = [
        ts for e in pool
        if (ts := _parse_ts(e.get("ts"))) is not None and ts <= until
        and _ident_matches(str(e.get("sid") or ""), str(e.get("host") or ""), sid, host, by_host)
    ]
    mine = [ts for ts in seen if ts >= floor]  # события сессии внутри окна поиска
    start = min(seen) if seen else None
    if begin is not None and not mine:
        # журнал о сессии молчит (выключен, stdio без http): лучшее, что известно, - постановка
        return SessionWindow(begin, until, KIND_BEGIN, sid, host)
    prev_save = _previous_save_end(out_dir, until, floor, sid, host, by_host, actions_path)
    point = max(t for t in (hours_floor, start, prev_save) if t is not None)

    if begin is not None and begin <= point:
        late = begin > until - timedelta(minutes=late_begin_minutes())
        earlier = start is not None and start < begin
        if not (late and earlier):
            return SessionWindow(begin, until, KIND_BEGIN, sid, host)
    if not mine:
        kind = KIND_HOURS
    else:
        kind = KIND_SESSION if sid and not by_host else KIND_HOST
    return SessionWindow(point, until, kind, sid, host)


# --------------------------------------------------------------------------- #
# Сборщик                                                                      #
# --------------------------------------------------------------------------- #
def collect_lift_sources(
    since: datetime,
    until: datetime | None = None,
    *,
    sid: str | None = None,
    host: str | None = None,
    by_host: bool = False,
    actions_path: Path | None = None,
) -> list[SourceRow]:
    """Подъёмы файлов за окно → строки ``origin: lift`` (дедуп по пути).

    Читает аудит-журнал (:func:`core.operational.pult.read_actions`) — телеметрию подъёмов со
    ВРЕМЕНЕМ (реестр источников времени лифта не хранит: ``last_lift`` там путь, а не время).
    Дата источника — живым ``stat``; файла нет → ``mtime=None`` и в файле «—». Один путь,
    поднятый несколько раз, — одна строка (время — первого подъёма).

    ``sid``/``host`` заданы (``None`` - без фильтра, как в SRC-TRACE-2) → только подъёмы этой
    сессии: чужие подъёмы соседних хостов не попадают.
    """
    from core.operational.pult import read_actions

    rows: dict[str, SourceRow] = {}
    for action in read_actions(
        tools=(_LIFT_TOOL,), since=since, until=until, outcomes=_LIFT_OK_OUTCOMES,
        path=actions_path,
    ):
        if sid is not None or host is not None:
            if not _ident_matches(action.args.get("sid", ""), action.args.get("host", ""),
                                  sid or "", host or "", by_host):
                continue
        path = action.args.get("path", "").strip()
        if not path or path in rows:
            continue
        rows[path] = SourceRow(
            path=path,
            origin=ORIGIN_LIFT,
            kind=action.args.get("kind", ""),
            mtime=_stat_mtime(path),
            content_hash=action.args.get("content_hash", ""),
            lifted_at=action.at,
        )
    return list(rows.values())


def _nda(*refs: Any) -> bool:
    from core.privacy import any_nda

    return any_nda(*[str(r) for r in refs if r])


def _note_date(fm: dict[str, Any], note_path: Path | None, source: str) -> float | None:
    """Дата заметки/источника: файл-источник → дата во frontmatter → mtime файла заметки."""
    if source:
        stamp = _stat_mtime(source)
        if stamp is not None:
            return stamp
    for key in ("date", "created"):
        raw = str(fm.get(key) or "").strip()[:10]
        try:
            return datetime.strptime(raw, "%Y-%m-%d").timestamp()
        except ValueError:
            continue
    return _stat_mtime(str(note_path)) if note_path is not None else None


def _hub_ids(vault_path: Path | None) -> set[str]:
    try:
        from core.config import default_vault_path
        from core.legacy.linking import entity_catalog

        return {c.id for c in entity_catalog(vault_path or default_vault_path())}
    except Exception:  # noqa: BLE001 - каталог хабов не обязателен для провенанса
        return set()


def _thread_progress(
    window: SessionWindow, note_id: str, total: int
) -> str:
    """«прочитано N из M» по событиям ``thread_read`` окна (как ``check_sources``)."""
    from core.thread_coverage import _window_events

    covered: set[int] = set()
    seen_total = total
    touched = False
    for ev in _window_events(window.since, window.until):
        if ev.get("note_id") != note_id:
            continue
        touched = True
        covered.update(i for i in (ev.get("shown_full") or []) if isinstance(i, int))
        seen_total = seen_total or int(ev.get("total") or 0)
    if not touched or not seen_total:
        return ""  # о том, сколько показано, события молчат - «0 из M» было бы выдумкой
    return f"прочитано {len(covered)} из {seen_total}"


def _read_row(
    note_id: str, window: SessionWindow, hubs: set[str], vault_path: Path | None,
    own: set[str], own_ids: frozenset[str] = frozenset(),
) -> SourceRow | None:
    """Строка ``read`` по id/ссылке прочитанной заметки (резолвер NOTE-ID-1) либо ``None``."""
    from core.retrieval.mail_read import EMAIL_THREAD
    from core.vault import read_note, resolve_note_path

    note_path: Path | None = None
    fm: dict[str, Any] = {}
    try:
        note_path = resolve_note_path(note_id, vault_path=vault_path)
        if note_path is not None:
            fm = dict(read_note(note_path, vault_path).frontmatter)
    except Exception:  # noqa: BLE001 - нечитаемая заметка остаётся строкой «читали по id»
        note_path, fm = None, {}
    if note_path is not None and str(note_path.resolve()) in own:
        return None
    if note_id in own_ids:  # заметка выхода, которую резолвер не нашел (индекс еще не видел)
        return None
    source = str(fm.get("source_path") or "").strip()
    canon_id = str(fm.get("id") or note_id)
    if _nda(note_id, canon_id, note_path, source):
        return None  # второй замок: журнал NDA и так не пишет
    is_thread = fm.get("source_type") == EMAIL_THREAD
    path = source or (str(note_path) if note_path is not None else note_id)
    is_hub = canon_id in hubs
    if is_thread:
        kind = EMAIL_THREAD
    elif is_hub:
        kind = "hub"
    else:
        kind = (Path(source).suffix.lower().lstrip(".") if source else "") or str(
            fm.get("type") or "note")
    detail = ""
    if is_thread:
        detail = _thread_progress(window, canon_id, int(fm.get("message_count") or 0))
    return SourceRow(
        path=path, origin=ORIGIN_READ, kind=kind, mtime=_note_date(fm, note_path, source),
        note_id=canon_id, hub=is_hub, detail=detail,
    )


def collect_session_sources(
    out_dir: Path,
    window: SessionWindow,
    sid: str = "",
    host: str = "",
    *,
    by_host: bool = False,
    vault_path: Path | None = None,
    events: list[dict[str, Any]] | None = None,
    actions_path: Path | None = None,
) -> SessionProvenance:
    """Что сессия читала/поднимала/искала в окне → :class:`SessionProvenance`.

    * ``read`` — ``read_note``/``work_note_preview`` (заметка → путь, ``source_path`` и дата
      через резолвер NOTE-ID-1; почтовый тред — «прочитано N из M»);
    * ``lift`` — подъёмы ``lift_source`` (аудит, как в SRC-TRACE-2);
    * ``facts`` — пути источников ``get_facts``;
    * поиски (``find_notes``/``find_latest``/``retrieve``) — отдельный список: кандидаты, а НЕ
      источники, в таблицу не идут.

    Исключаются: файлы самого выхода, NDA (второй замок), хосты selftest (``read_events`` их не
    отдаёт). Один путь, прочитанный и поднятый, — одна строка ``read+lift``.
    """
    from core.eval_journal import read_events
    from core.purpose import is_selftest_host

    since = window.since.astimezone(UTC).replace(microsecond=0)
    until = window.until.astimezone(UTC)
    pool = events if events is not None else read_events(since=since)
    own = {str((Path(out_dir) / n).resolve()) for n in _OWN_FILES}
    # id заметок выхода (WAVE0-HYGIENE п.2): ``<файл>-<папка>``
    own_ids = frozenset(f"{n.removesuffix('.md')}-{Path(out_dir).name}" for n in _OWN_FILES)
    hubs = _hub_ids(vault_path)
    read_rows: list[SourceRow] = []
    fact_rows: list[SourceRow] = []
    seen_notes: set[str] = set()
    searches: dict[str, SearchRow] = {}
    for ev in pool:
        ts = _parse_ts(ev.get("ts"))
        if ts is None or not (since <= ts <= until):
            continue
        if not _ident_matches(str(ev.get("sid") or ""), str(ev.get("host") or ""), sid, host,
                              by_host) or is_selftest_host(str(ev.get("host") or "")):
            continue  # selftest-хосты - шум (журнал их и не пишет; замок на подставленный пул)
        kind = ev.get("event")
        tool = str(ev.get("tool") or "")
        if kind == "search":
            raw_args = ev.get("args")
            args: dict[str, Any] = raw_args if isinstance(raw_args, dict) else {}
            key = json.dumps([tool, args], ensure_ascii=False, sort_keys=True)
            prev = searches.get(key)
            if prev is not None:
                searches[key] = replace(prev, count=prev.count + 1)
                continue
            top = tuple(str(i) for i in ev.get("top_ids") or [] if not _nda(i))
            searches[key] = SearchRow(tool=tool, args=dict(args), top_ids=top)
        elif kind == "open" and tool in _READ_TOOLS:
            ref = str(ev.get("note_id") or "").strip()
            if not ref or ref in seen_notes:
                continue
            seen_notes.add(ref)
            row = _read_row(ref, window, hubs, vault_path, own, own_ids)
            if row is not None:
                read_rows.append(row)
        elif kind == "open" and tool == "get_facts":
            for p in ev.get("paths") or []:
                path = str(p or "").strip()
                if path and not _nda(path) and str(Path(path).resolve()) not in own:
                    fact_rows.append(SourceRow(
                        path=path, origin=ORIGIN_FACTS, mtime=_stat_mtime(path),
                        kind=Path(path).suffix.lower().lstrip(".")))
    lift_rows = [
        r for r in collect_lift_sources(
            window.since, window.until, sid=sid, host=host, by_host=by_host,
            actions_path=actions_path)
        if not _nda(r.path) and str(Path(r.path).resolve()) not in own
    ]
    rows = merge_rows(read_rows, lift_rows, fact_rows)
    return SessionProvenance(rows=rows, searches=list(searches.values()), window=window)


# --------------------------------------------------------------------------- #
# Разметка                                                                      #
# --------------------------------------------------------------------------- #
_TABLE_HEADER = (
    "| origin | source_path | kind | date | hash | взято | note |\n"
    "| --- | --- | --- | --- | --- | --- | --- |"
)


def _fmt_date(mtime: float | None) -> str:
    if mtime is None:
        return "—"
    return datetime.fromtimestamp(mtime).strftime("%Y-%m-%d")


def _cell(value: str) -> str:
    return " ".join(str(value or "").split()).replace("|", "/")


def render_source_table(rows: list[SourceRow]) -> str:
    """Таблица источников (шапка + строки либо ``(none)``)."""
    body = "\n".join(
        f"| {r.origin} | {_cell(r.path)} | {r.kind or '—'} | {_fmt_date(r.mtime)} | "
        f"{(r.content_hash or '')[:12] or '—'} | "
        f"{_cell(' · '.join(x for x in (r.what_taken, r.detail) if x)) or '—'} | "
        f"{_cell(r.note_id) or '—'} |"
        for r in rows
    ) or "| (none) |  |  |  |  |  |  |"
    return f"{_TABLE_HEADER}\n{body}"


def parse_manual_rows(text: str) -> list[SourceRow]:
    """Ручные строки (``origin`` с ``manual``) из таблицы СВОЕГО формата - чтобы повторный
    ``save_output`` не потерял ``sources=`` прошлого вызова. Остальные строки пересобираются."""
    out: list[SourceRow] = []
    for line in text.splitlines():
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 6 or ORIGIN_MANUAL not in cells[0].split("+"):
            continue
        path = cells[1]
        if not path or path in ("source_path", "—"):
            continue
        taken = cells[5] if cells[5] != "—" else ""
        out.append(SourceRow(
            path=path, origin=ORIGIN_MANUAL, kind="" if cells[2] == "—" else cells[2],
            mtime=_stat_mtime(path), what_taken=taken,
        ))
    return out


def _fmt_args(args: dict[str, Any]) -> str:
    parts = []
    for key, value in args.items():
        parts.append(f"«{value}»" if key == "query" else f"{key}={value}")
    return ", ".join(parts)


def render_search_lines(searches: list[SearchRow]) -> list[str]:
    """Маркированные строки секции поиска (БЕЗ таблицы: eval ``sources_min`` их не считает)."""
    lines: list[str] = []
    for s in searches[:_SEARCH_LINES_MAX]:
        times = f" ×{s.count}" if s.count > 1 else ""
        top = f" → {', '.join(s.top_ids)}" if s.top_ids else " → ничего"
        lines.append(f"- `{s.tool}` {_fmt_args(s.args)}{times}{top}")
    if len(searches) > _SEARCH_LINES_MAX:
        lines.append(f"- … и ещё {len(searches) - _SEARCH_LINES_MAX}")
    return lines


def render_window_line(window: SessionWindow | None) -> str:
    """Строка шапки: как определено окно сбора (сессия / постановка / хост / часы)."""
    if window is None:
        return ""
    stamp = (f"{window.since.astimezone():%Y-%m-%d %H:%M} → "
             f"{window.until.astimezone():%Y-%m-%d %H:%M}")
    if window.kind == KIND_BEGIN:
        how = "от постановки задачи (`output_begin`) до сохранения выхода."
    elif window.kind == KIND_SESSION:
        how = (f"сессия `{window.sid}` (журнал запросов: с первого вызова сессии либо после "
               "предыдущего `save_output` этой сессии).")
    elif window.kind == KIND_HOST:
        how = (f"сессия хоста `{window.host or 'cli'}` (идентификатор сессии неизвестен: "
               "сегмент по хосту и времени).")
    else:
        how = (f"последние {adhoc_sources_hours():g} ч (сессия неизвестна). **Это окно, а не "
               "сессия**: начало работы неизвестно — в списке могут быть чтения соседних задач, "
               "а более раннее в него не попало.")
    return f"Окно сбора: {stamp} — {how}"
