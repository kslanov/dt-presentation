"""EVAL-HYGIENE-1 п.1 - назначение выхода: ``work`` | ``eval`` | ``selftest``.

Прогон golden-генерации (g1 «сделай справку по клиенту ИТХ …») и самопроверки (мост, шпионы)
создавали обычные выходы: доставляли docx в папку клиента, попадали в досье хаба, линт и поиск -
и были неотличимы от работы. Здесь - один детерминированный ответ «что это за выход»:

* ``eval`` - постановка совпала с фразой задачи ``golden-generation.yaml`` (ТА ЖЕ функция, что у
  eval-раннера: :func:`core.eval_generation.task_matches_text`, одна правда); ``eval_task`` - id
  задачи;
* ``selftest`` - хост из тестовых (``shim-test``, ``dt-spike-*``, ``idle-test``) либо
  ``DT_SELFTEST=1`` в окружении;
* ``work`` - всё остальное (дефолт; в ``meta.yaml`` ключа нет вовсе - поведение рабочих выходов
  байт-в-байт прежнее).

Явный ``purpose`` хоста сильнее автоопределения ТОЛЬКО в сторону ``eval``/``selftest``: пометить
прогон работой нельзя (явный ``work`` при совпадении с фразой - все равно ``eval``), и уже
помеченный выход обратно в ``work`` не переводится.

Чистая логика: без записи, без сети, без LLM; golden читается из vault (нет файла/битый -
автоопределения по задаче нет, ``selftest`` по хосту работает).
"""

from __future__ import annotations

import fnmatch
import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path

__all__ = [
    "EVAL_TASK_KEY",
    "PURPOSES",
    "PURPOSE_EVAL",
    "PURPOSE_KEY",
    "PURPOSE_SELFTEST",
    "PURPOSE_WORK",
    "SELFTEST_HOSTS",
    "Resolution",
    "detect_eval_task",
    "is_quarantined",
    "is_selftest_host",
    "normalize_explicit",
    "purpose_of",
    "resolve",
    "selftest_env",
]

logger = logging.getLogger(__name__)

PURPOSE_WORK = "work"
PURPOSE_EVAL = "eval"
PURPOSE_SELFTEST = "selftest"
PURPOSES = (PURPOSE_WORK, PURPOSE_EVAL, PURPOSE_SELFTEST)
PURPOSE_KEY = "purpose"
EVAL_TASK_KEY = "eval_task"

# Хосты самопроверок: мост (tests/test_shim.py), спайки HOSTS-ATTACH, проба простоя сессий.
SELFTEST_HOSTS = ("shim-test", "dt-spike-*", "idle-test")
_SELFTEST_ENV = "DT_SELFTEST"
_TRUE = {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Resolution:
    purpose: str
    eval_task: str | None = None
    source: str = "default"  # default | task | host | env | explicit | prior

    @property
    def is_work(self) -> bool:
        return self.purpose == PURPOSE_WORK


def selftest_env() -> bool:
    return os.environ.get(_SELFTEST_ENV, "").strip().lower() in _TRUE


def is_selftest_host(name: str | None) -> bool:
    low = re.sub(r"\s+", " ", str(name or "")).strip().lower()
    return bool(low) and any(fnmatch.fnmatchcase(low, pat) for pat in SELFTEST_HOSTS)


def normalize_explicit(value: str | None) -> str | None:
    """Явный ``purpose`` хоста → канон; пусто → ``None``; незнакомое → ``ValueError``."""
    raw = str(value or "").strip().lower()
    if not raw:
        return None
    if raw not in PURPOSES:
        raise ValueError(f"purpose ∈ {{{', '.join(PURPOSES)}}}, получено {raw!r}")
    return raw


def purpose_of(meta: dict | None) -> str:
    """Назначение по ``meta.yaml`` выхода (нет ключа / мусор → ``work``)."""
    raw = str((meta or {}).get(PURPOSE_KEY) or "").strip().lower()
    return raw if raw in PURPOSES else PURPOSE_WORK


def is_quarantined(meta: dict | None) -> bool:
    return purpose_of(meta) != PURPOSE_WORK


def detect_eval_task(*texts: str, title: str = "", vault: Path | None = None) -> str | None:
    """id первой задачи golden-генерации, фраза которой есть в ``texts`` (либо заголовок = фразе).

    Та же функция сопоставления, что у eval-раннера. Нет файла/битый YAML/пусто → ``None``
    (канон пишет К.: ломаный набор не должен ронять контур выхода)."""
    from core import eval_generation as eg

    try:
        tasks = eg.load_generation_golden(eg.generation_golden_path(vault))
    except (eg.GenerationGoldenError, OSError) as exc:
        logger.debug("[purpose] golden-generation не прочитан: %s", exc)
        return None
    for task in tasks:
        if task.trace == eg.TRACE_OUTPUT and eg.task_matches_text(task, texts, title=title):
            return task.id
    return None


def resolve(
    *,
    texts: tuple[str, ...] = (),
    title: str = "",
    host: str | None = None,
    explicit: str | None = None,
    prior: str | None = None,
    prior_eval_task: str | None = None,
    vault: Path | None = None,
) -> Resolution:
    """Назначение выхода: ранг ``eval`` > ``selftest`` > ``work``; вниз (к ``work``) не переводит.

    ``prior`` - уже записанное в мете (идемпотентный повтор/пересохранение): остается как есть
    либо усиливается, но не слабеет."""
    explicit_n = normalize_explicit(explicit)
    task_id = detect_eval_task(*texts, title=title, vault=vault)
    found: list[Resolution] = []
    if task_id:
        found.append(Resolution(PURPOSE_EVAL, task_id, "task"))
    if explicit_n == PURPOSE_EVAL:
        found.append(Resolution(PURPOSE_EVAL, prior_eval_task, "explicit"))
    if prior == PURPOSE_EVAL:
        found.append(Resolution(PURPOSE_EVAL, prior_eval_task, "prior"))
    if found:
        # eval_task из автоопределения точнее прежнего/пустого
        best = next((r for r in found if r.eval_task), found[0])
        return Resolution(PURPOSE_EVAL, best.eval_task, found[0].source)
    if explicit_n == PURPOSE_SELFTEST:
        return Resolution(PURPOSE_SELFTEST, None, "explicit")
    if prior == PURPOSE_SELFTEST:
        return Resolution(PURPOSE_SELFTEST, None, "prior")
    if is_selftest_host(host):
        return Resolution(PURPOSE_SELFTEST, None, "host")
    if selftest_env():
        return Resolution(PURPOSE_SELFTEST, None, "env")
    return Resolution(PURPOSE_WORK)
