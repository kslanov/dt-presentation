"""Legacy-aware note finding: три слоя, единая шкала (RETR-LEGACY FIX-1/2, RETR-RANK-1).

Интерактивный ``find_notes`` обязан поднимать и сырую legacy-переписку
(``_legacy/correspondence/…``, ``corpus: legacy``), и живые файлы слоя ``current``
(КП, расчеты, справки), хотя они лежат вне vault-скоупа по умолчанию — триггер-баг
«последнее письмо Кутеповой по TMS» не находилось, пока не указан путь.

Конвейер (:func:`find_notes`) — модель (BGE-M3) грузится ТОЛЬКО когда лексики мало:

1. **Лексика, один проход по всем слоям (без эмбеддинга).** FTS (BM25,
   :func:`core.retrieval.search.lexical_search`, ``corpus`` = нужный слой/набор или все три)
   *плюс* скан frontmatter vault (:mod:`core.retrieval.notemeta`, тот же обход, что у
   индекса). Скан сопоставляет запрос с ``id``/алиасами/заголовком/прочими полями и даёт
   ЯРУС (``scan:id|alias|title|fm``); почтовые контакты — ``person``/``domain`` — жёсткий AND
   поверх ВСЕХ ступеней (FTS- и семантические хиты проверяются по frontmatter).
2. **Слияние вместо обрыва (RETR-RANK-1).** Раньше первая непустая ступень (vault → legacy)
   обрывала лестницу: слабый FTS-хит по телу vault-заметки прятал тред и ТЗ из legacy/current.
   Теперь ступени объединяются в :func:`core.retrieval.rank.fuse` — единая шкала 0..1 (BM25 и
   ярусы скана несравнимы по сырым значениям, RRF по рангам — шкало-независим).
3. **Семантика (BGE) — только если лексических хитов меньше ``DT_FIND_SEMANTIC_FLOOR``**
   (дефолт 3): принцип «без модели, если лексики хватает» сохранён; семантические хиты
   вливаются в то же слияние. С реранкером (RETR-RERANK-1) лестница не обрезает: семантика идёт
   всегда (``DT_FIND_SEMANTIC_ALWAYS``).
4. **Реранкер (RETR-RERANK-1)** — верхние ``DT_RERANK_POOL`` кандидатов слияния переоценивает
   локальный cross-encoder (:mod:`core.retrieval.rerank`); хаб клиента при этом гарантированно в
   топ-3, а не обязательно первым (:func:`core.retrieval.rank.apply_pin_top`).

Каждый хит помечен ``matched_by`` из закрытого списка
(:data:`core.retrieval.rank.MATCHED_BY_VALUES`) и ``corpus`` (``vault``/``current``/``legacy``).
``sort="recent"`` упорядочивает по дате frontmatter убыв. («последнее письмо в X»),
``"relevance"`` (по умолчанию) — по единой шкале.

:func:`read_full_note` (FIX-2) — парный полный читатель: любая заметка по пути (в т.ч.
``_legacy/``) за той же охраной containment, что ``operational.hub_notes`` / ``attribute``.

**Видимость давности (SRC-FRESH-1, фейлкейс 2026-08-11).** Папка хранилища = семейство
версий документа, и поиск возвращал члена семейства, ничего не говоря о его позиции:
лексически плотный шаблон 2023 обошёл действующий план 2026, и вывод в документе для
аудитора получился обратным истине. Ранжирование остаётся как есть (релевантность
честная) — добавлены два ЧИТАЮЩИХ сигнала: :func:`date_spread_warning` (верхний хит
существенно старше свежайшего в той же выдаче) и :func:`find_latest` («последняя
версия» по каталогу-семейству — из каталога, а не из выдачи).

Invariants: Path B (no network/LLM here — the embedder is a local model),
read-only, reuse (``iter_vault``; the existing FTS/BGE in ``search.py``).
"""

from __future__ import annotations

import logging
import os
import re
import time
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any

from core.config import default_vault_path
from core.contract import CODE_STORE_UNAVAILABLE, CODE_UNAVAILABLE, warning
from core.privacy import any_nda, is_eval
from core.retrieval import rank
from core.retrieval import rerank as rr
from core.retrieval.fm_cache import load_metas_cached
from core.retrieval.hubcat import build_catalog, canonical_terms, match_hubs
from core.retrieval.mail_read import (
    EMAIL_THREAD,
    full_summary,
    last_message_info,
    parse_messages_arg,
    parse_thread,
    render_budgeted,
)
from core.retrieval.notemeta import (
    DOMAIN_FIELDS,
    PERSON_FIELDS,
    QUERY_FIELDS,
    NoteMeta,
    as_texts,
    fold_plain,
    is_quarantined,
    owner_ids,
)
from core.retrieval.search import SearchResult, lexical_search, search
from core.text.stem import fold_stem, fts_query
from core.vault import note_path_for_id, read_note, resolve_note_path

logger = logging.getLogger(__name__)

__all__ = [
    "FindHit",
    "FindResult",
    "find_notes",
    "find_notes_ex",
    "read_full_note",
    "ReadNoteError",
    "LatestFamily",
    "find_latest",
    "date_spread_warning",
    "DEFAULT_SPREAD_MONTHS",
    "spread_months",
    "semantic_floor",
    "DEFAULT_SEMANTIC_FLOOR",
]

# Поля, с которыми скан сопоставляет запрос; контактные — для жёстких фильтров (см. notemeta).
_QUERY_FIELDS = QUERY_FIELDS
_PERSON_FIELDS = PERSON_FIELDS
_DOMAIN_FIELDS = DOMAIN_FIELDS

# scope → аргумент ``corpus`` для search()/lexical_search() (``raw`` = current+legacy,
# разрешается ``search._corpus_layers``; ``None`` = все три) и → допустимые слои скана.
_SCOPE_CORPUS: dict[str, str | None] = {
    "vault": "vault",
    "current": "current",
    "legacy": "legacy",
    "raw": "raw",
    "both": None,
}
_SCOPE_SET: dict[str, frozenset[str] | None] = {
    "vault": frozenset({"vault"}),
    "current": frozenset({"current"}),
    "legacy": frozenset({"legacy"}),
    "raw": frozenset({"current", "legacy"}),
    "both": None,
}

# Порог семантики: BGE грузится, только если лексических хитов (скан ∪ FTS) меньше порога.
DEFAULT_SEMANTIC_FLOOR = 3
_FLOOR_ENV = "DT_FIND_SEMANTIC_FLOOR"
# Пул FTS в чанках: у одной заметки много чанков, а заметок нужно с запасом под слияние.
_FTS_POOL_MIN, _FTS_POOL_MAX, _FTS_POOL_PER_LIMIT = 200, 500, 25
# Пул скана при сортировке по релевантности (по дате — без обрезки: свежесть видна лишь целиком).
_SCAN_POOL_MIN, _SCAN_POOL_PER_LIMIT = 40, 4
# Сколько хабов клиента из запроса закрепляется в голове выдачи (п.4).
_PIN_TOP = 3


@dataclass
class FindHit:
    """One note-level result of :func:`find_notes`.

    Контракт полей-ссылок (CONTRACT-1 ФП-2): ``note_id`` — идентичность заметки
    (frontmatter ``id``); ``path`` — **vault-относительный путь заметки**, читаемый
    ``read_note``/``work_note_preview``/``attribute_note`` (пусто, если индекс-манифест
    заметку не знает); ``source_path`` — провенанс, путь исходного файла или виртуальный
    ключ почтового треда, и **файлом заметки он не является**.

    ``score`` — итоговая оценка 0..1 (единая шкала, :mod:`core.retrieval.rank`);
    ``matched_by`` — честный источник из закрытого списка
    ``scan:id|scan:alias|scan:title|scan:title_tokens|scan:fm|fts|semantic|pin:client``.
    """

    note_id: str
    title: str
    source_path: str
    path: str
    score: float
    matched_by: str  # rank.MATCHED_BY_VALUES
    corpus: str  # "vault" | "current" | "legacy" | …
    date: str = ""
    # MAIL-THREAD-1: только для email-thread — кто и когда написал ПОСЛЕДНЕЕ сообщение
    # (из frontmatter, тело не читается). Пусто у не-почты — в выдачу не попадает.
    last_from: str = ""
    last_date: str = ""
    last_from_me: bool | None = None
    # PERSONAL-3: структурный признак хита - единица документа (``slide|page|sheet|block``: слайд,
    # страница, лист, безымянный блок легаси-документа) или ``""`` для обычной заметки;
    # ``doc_title`` - родительский документ (заголовок заметки либо имя исходного файла), когда
    # ``title`` - заголовок самой единицы («Слайд 22»). Мост по ним отсеивает служебные страницы.
    kind: str = ""
    doc_title: str = ""


def _unit_kind(*headings: str) -> str:
    from core.legacy.normalize import unit_kind_of_heading

    for heading in headings:
        kind = unit_kind_of_heading(heading)
        if kind:
            return kind
    return ""


def _doc_title(title: str, source_path: str, meta_title: str = "") -> str:
    """Заголовок родительского документа: заголовок заметки, если он не заголовок единицы, иначе
    имя исходного файла без расширения."""
    if meta_title and not _unit_kind(meta_title):
        return meta_title
    if title and not _unit_kind(title):
        return title
    stem = Path(source_path).stem if source_path and ":" not in source_path else ""
    return stem or meta_title or title


@dataclass
class FindResult:
    """Выдача + конверты деградации (``core.contract.warning``): FTS недоступен и т.п."""

    hits: list[FindHit] = field(default_factory=list)
    warnings: list[dict[str, Any]] = field(default_factory=list)
    # RETR-RERANK-1: итоги второго этапа для телеметрии — ``{applied, ms, pool, device}``;
    # пусто, если реранкер не запрашивался/не требовался (пул ≤ limit, sort=recent, нет запроса).
    rerank: dict[str, Any] = field(default_factory=dict)


class ReadNoteError(ValueError):
    """Bad path (escapes vault / not a file) for :func:`read_full_note`."""


# --------------------------------------------------------------------------- #
# Frontmatter helpers                                                         #
# --------------------------------------------------------------------------- #
_as_texts = as_texts


def _fm_contains(fm: dict[str, Any], fields: tuple[str, ...], needle: str) -> bool:
    """Whether ``needle`` (case-insensitive substring) appears in any ``field``."""
    needle = needle.lower()
    for field_name in fields:
        for text in _as_texts(fm.get(field_name)):
            if needle in text.lower():
                return True
    return False


def _note_corpus(fm: dict[str, Any]) -> str:
    """A note's corpus (frontmatter ``corpus``; missing ⇒ ``vault``)."""
    corpus = fm.get("corpus")
    return str(corpus).strip() if corpus else "vault"


def _note_title(fm: dict[str, Any], note_id: str) -> str:
    """Best human title: ``title`` → ``subject`` → the note id."""
    for key in ("title", "subject"):
        value = fm.get(key)
        if value:
            return str(value)
    return note_id


_DATE_FIELDS: tuple[str, ...] = ("last_date", "modified", "created", "first_date")


def _note_date(fm: dict[str, Any]) -> str:
    """First present date among :data:`_DATE_FIELDS` (ISO-ish strings sort well)."""
    for key in _DATE_FIELDS:
        value = fm.get(key)
        if value:
            return str(value)
    return ""


def _vault_rel(path: Path, vault_path: Path) -> str:
    """Путь заметки относительно корня vault, posix (вне vault → как есть)."""
    try:
        return path.relative_to(vault_path).as_posix()
    except ValueError:
        return str(path)


def _from_search(r: SearchResult, matched_by: str) -> FindHit:
    """Adapt a chunk-level :class:`SearchResult` into a note-level :class:`FindHit`.

    **CONTRACT-1 ФП-2 (Д1, главный вывод спайка `docs/findings/audit-contract-1.md`).**
    ``path`` — путь ЗАМЕТКИ, и берётся он из индекс-манифеста по ``note_id`` (O(1),
    :func:`core.vault.note_path_for_id`); ``source_path`` остаётся отдельным полем как
    есть. Раньше здесь стояло ``path=r.source_path`` — и на боевом индексе поле, которое
    докстринг инструмента объявляет «читаемым путём для ``read_note``», отдавало
    ``…/kickOff_….pptx`` и ``correspondence/conv:73068`` (8 строк из 8). Почему дефект
    жил незаметно: у КУРИРОВАННОЙ заметки индексная колонка ``source_path`` вырождается в
    путь самой заметки (`index.py:_record_meta`), поэтому ломались только те заметки, у
    которых `source_path` настоящий — весь легаси-корпус, файловый инжест и почта.

    Манифеста нет / заметки в нём нет (дрейф индекса и манифеста) → ``path`` пустой:
    честное «путь неизвестен» вместо строки, которую не примет ни один читатель.
    Идентичность при этом не теряется — ``note_id`` резолвится всеми читателями сам.
    """
    md = r.metadata
    date = ""
    for key in ("modified", "created"):
        if md.get(key):
            date = str(md.get(key))
            break
    kind = _unit_kind(r.heading_path)
    return FindHit(
        note_id=r.note_id,
        title=(r.heading_path or r.note_id),
        source_path=r.source_path,
        path=note_path_for_id(r.note_id) or "",
        score=float(r.score),
        matched_by=matched_by,
        corpus=str(md.get("corpus") or "vault"),
        date=date,
        kind=kind,
        doc_title=_doc_title(r.heading_path, r.source_path, str(md.get("title") or ""))
        if kind else "",
    )


def _layer_of(corpus: str) -> str:
    return corpus if corpus in ("current", "legacy") else "vault"


# --------------------------------------------------------------------------- #
# Ступени                                                                     #
# --------------------------------------------------------------------------- #
def semantic_floor() -> int:
    """Порог семантики (env ``DT_FIND_SEMANTIC_FLOOR``, дефолт 3; мусор → дефолт, 0 = никогда)."""
    raw = os.environ.get(_FLOOR_ENV, "").strip()
    try:
        value = int(float(raw))
    except (TypeError, ValueError):
        return DEFAULT_SEMANTIC_FLOOR
    return value if value >= 0 else DEFAULT_SEMANTIC_FLOOR


# Поля, которые сравниваются в пространстве стем-ключей (падежные формы запроса и поля заметки
# сводятся к одному ключу). Контактные поля (участники, домены) — имена и адреса: сравниваются
# только по регистру (стеммить e-mail бессмысленно, а обход ~12 тыс. заметок должен быть дешёвым).
_STEMMED_FIELDS: tuple[str, ...] = ("id", "title", "aliases", "subject", "tags", "client")
_PLAIN_FIELDS: tuple[str, ...] = tuple(f for f in QUERY_FIELDS if f not in _STEMMED_FIELDS)

_FTS_EXPAND_ENV = "DT_FIND_FTS_EXPAND"


def _pin_enabled() -> bool:
    """Выключатель нормализации клиента целиком (пин + буст + расширение); по умолчанию вкл."""
    return os.environ.get("DT_FIND_PIN", "1").strip().lower() not in ("0", "false", "no", "off")


def _canon_expand_enabled() -> bool:
    return os.environ.get("DT_FIND_CANON_EXPAND", "1").strip().lower() not in ("0", "false", "no")


def _fts_expand_enabled() -> bool:
    """Стем-варианты слов запроса в FTS (по умолчанию ВЫКЛ: замер на золотом наборе — шум)."""
    return os.environ.get(_FTS_EXPAND_ENV, "0").strip().lower() in ("1", "true", "yes", "on")


def _folded_fields(meta: NoteMeta) -> dict[str, tuple[str, ...]]:
    """Свёрнутые тексты полей заметки — один раз на процесс (кэш в самой записи).

    ``_STEMMED_FIELDS`` — ключи слов (:func:`core.text.stem.fold_stem`), остальные — регистр.
    """
    if meta.folded is None:
        meta.folded = {
            name: tuple(
                fold_stem(t) if name in _STEMMED_FIELDS else fold_plain(t) for t in texts
            )
            for name, texts in meta.fields.items()
        }
    return meta.folded


def _passes_filters(meta: NoteMeta, *, person: str | None, domain: str | None) -> bool:
    """Жёсткие фильтры контактов: подстрока без учёта регистра по контактным полям."""
    if person:
        needle = person.lower()
        if not any(needle in t.lower() for t in meta.texts(_PERSON_FIELDS)):
            return False
    if domain:
        needle = domain.lower()
        if not any(needle in t.lower() for t in meta.texts(_DOMAIN_FIELDS)):
            return False
    return True


def _scan_tier_of(meta: NoteMeta, q_stem: str, q_plain: str) -> str | None:
    """Ярус совпадения запроса с заметкой (см. :func:`rank.scan_tier`).

    Два пространства сравнения: стем-ключи (id/алиасы/заголовок/subject/теги/клиент) и регистр
    (контакты). Берётся лучший ярус из двух.
    """
    folded = _folded_fields(meta)
    stem_other: list[str] = []
    for name in _STEMMED_FIELDS:
        if name not in ("id", "aliases", "title"):
            stem_other.extend(folded.get(name, ()))
    title = " ".join(folded.get("title", ())) or " ".join(folded.get("subject", ()))
    ident = lambda s: s  # noqa: E731 — обе стороны уже свёрнуты
    tier = rank.scan_tier(
        q_stem,
        note_id=fold_stem(meta.id),
        aliases=folded.get("aliases", ()),
        title=title,
        other_fields=stem_other,
        norm=ident,
    )
    plain_other: list[str] = []
    for name in _PLAIN_FIELDS:
        plain_other.extend(folded.get(name, ()))
    plain = rank.scan_tier(
        q_plain, note_id="", aliases=(), title="", other_fields=plain_other, norm=ident
    )
    candidates = [t for t in (tier, plain) if t is not None]
    if not candidates:
        return None
    return max(candidates, key=lambda t: rank.SCAN_TIERS[t])


def _scan_cands(
    metas: list[NoteMeta],
    query: str,
    *,
    scope: frozenset[str] | None,
    person: str | None,
    domain: str | None,
) -> list[rank.Cand]:
    """Ступень скана: заметки, прошедшие ВСЕ заданные критерии (AND), с ярусом совпадения.

    Критерии: слой в ``scope`` (если задан), ``person``/``domain`` по контактным полям (если
    заданы), запрос по полям :data:`QUERY_FIELDS` (если задан). Без запроса (чистый
    фильтр контактов) ярус — ``scan:fm``: заметка пришла по frontmatter, не по тексту.
    """
    q_stem = fold_stem(query)
    q_plain = fold_plain(query)
    out: list[rank.Cand] = []
    for meta in metas:
        if scope is not None and meta.corpus not in scope:
            continue
        if not _passes_filters(meta, person=person, domain=domain):
            continue
        if q_plain:
            tag = _scan_tier_of(meta, q_stem, q_plain)
            if tag is None:
                continue
        else:
            tag = "scan:fm"
        out.append(
            rank.Cand(meta.id, layer=_layer_of(meta.corpus), tag=tag, date=meta.date)
        )
    return out


def _hit_from_meta(meta: NoteMeta, sr: SearchResult | None = None) -> FindHit:
    """Хит из среза frontmatter (опционально — с лучшим чанком FTS/семантики для заголовка)."""
    heading = sr.heading_path if sr is not None else ""
    title = meta.title or heading or meta.id
    source = sr.source_path if sr is not None and sr.source_path else meta.source_path
    kind = _unit_kind(meta.title or "", heading)
    return FindHit(
        note_id=meta.id,
        title=title,
        source_path=source,
        path=meta.path,
        score=0.0,
        matched_by="fts",
        corpus=meta.corpus,
        date=meta.date,
        kind=kind,
        doc_title=_doc_title(title, source, meta.title or "") if kind else "",
    )


def _fts_pool(limit: int) -> int:
    return min(max(limit * _FTS_POOL_PER_LIMIT, _FTS_POOL_MIN), _FTS_POOL_MAX)


def _fts_cands(
    query: str,
    *,
    extra_terms: tuple[str, ...] = (),
    corpus_arg: str | None,
    limit: int,
    by_id: dict[str, NoteMeta],
    person: str | None,
    domain: str | None,
    warnings: list[dict[str, Any]],
) -> tuple[list[rank.Cand], dict[str, SearchResult]]:
    """Ступень FTS: заметки по лучшему чанку (BM25). Best-effort: сбой индекса → пусто + конверт.

    ``person``/``domain`` — жёсткий AND: FTS-хит без среза frontmatter (нечем проверить) при
    заданном фильтре отбрасывается.
    """
    q = (query or "").strip()
    if not q:
        return [], {}
    fts_text = fts_query(q, extra_terms, variants=_fts_expand_enabled())
    try:
        rows = lexical_search(fts_text, corpus=corpus_arg, k=_fts_pool(limit))
    except Exception as exc:  # noqa: BLE001 — FTS index optional; scan still valid
        logger.warning("[find_notes] FTS unavailable (%s); scan-only", exc)
        warnings.append(
            warning(
                CODE_STORE_UNAVAILABLE,
                f"полнотекстовый индекс недоступен ({type(exc).__name__}): выдача — только скан "
                "frontmatter, тела заметок не просмотрены",
                component="fts",
            )
        )
        return [], {}
    best: dict[str, SearchResult] = {}
    for r in rows:
        if not r.note_id:
            continue
        prev = best.get(r.note_id)
        if prev is None or r.score > prev.score:
            best[r.note_id] = r
    cands: list[rank.Cand] = []
    kept: dict[str, SearchResult] = {}
    for nid, r in best.items():
        meta = by_id.get(nid)
        if (person or domain) and (meta is None or not _passes_filters(
            meta, person=person, domain=domain
        )):
            continue
        corpus = meta.corpus if meta is not None else str(r.metadata.get("corpus") or "vault")
        date = meta.date if meta is not None else _search_date(r)
        cands.append(rank.Cand(nid, raw=r.score, layer=_layer_of(corpus), date=date))
        kept[nid] = r
    return cands, kept


def _search_date(r: SearchResult) -> str:
    for key in ("modified", "created"):
        if r.metadata.get(key):
            return str(r.metadata[key])
    return ""


def _semantic_cands(
    query: str,
    *,
    corpus_arg: str | None,
    limit: int,
    by_id: dict[str, NoteMeta],
    person: str | None,
    domain: str | None,
    warnings: list[dict[str, Any]],
) -> tuple[list[rank.Cand], dict[str, SearchResult]]:
    """Семантическая ступень — ЕДИНСТВЕННАЯ, что грузит BGE (через :func:`search`).

    Только для настоящего текстового ``query``: голый ``person``/``domain`` — фильтр
    frontmatter, которого векторный индекс не знает (поля не индексные колонки), и
    синтезировать из них запрос значило бы выдумать хиты вне фильтра. Хиты схлопываются до
    заметки (лучший чанк), ``person``/``domain`` проверяются по frontmatter (жёсткий AND).
    Сбой модели/индекса не роняет выдачу: пусто + конверт ``unavailable``.
    """
    q = query.strip()
    if not q:
        return [], {}
    try:
        results = search(q, corpus=corpus_arg, k=limit * 4)
    except Exception as exc:  # noqa: BLE001 — семантика — надстройка над лексикой
        logger.warning("[find_notes] semantic rung unavailable (%s)", exc)
        warnings.append(
            warning(
                CODE_UNAVAILABLE,
                f"семантический поиск недоступен ({type(exc).__name__}): выдача — только "
                "лексика",
                component="semantic",
            )
        )
        return [], {}
    best: dict[str, SearchResult] = {}
    for r in results:
        if not r.note_id:
            continue
        prev = best.get(r.note_id)
        if prev is None or r.score > prev.score:
            best[r.note_id] = r
    cands: list[rank.Cand] = []
    kept: dict[str, SearchResult] = {}
    for nid, r in best.items():
        meta = by_id.get(nid)
        if (person or domain) and (meta is None or not _passes_filters(
            meta, person=person, domain=domain
        )):
            continue
        corpus = meta.corpus if meta is not None else str(r.metadata.get("corpus") or "vault")
        date = meta.date if meta is not None else _search_date(r)
        cands.append(rank.Cand(nid, raw=r.score, layer=_layer_of(corpus), date=date))
        kept[nid] = r
    return cands, kept


def _finalize(hits: list[FindHit], sort: str, limit: int) -> list[FindHit]:
    """Sort (recent = date desc, else score desc) and cap to ``limit``."""
    if sort == "recent":
        hits.sort(key=lambda h: (h.date or "", h.score), reverse=True)
    else:
        hits.sort(key=lambda h: h.score, reverse=True)
    return hits[:limit]


def _body_head(vault: Path, meta: NoteMeta) -> str:
    """Голова тела заметки для пары реранкера (чтение с диска; best-effort)."""
    try:
        return read_note(vault / meta.path).body[: rr.body_chars() * 2]
    except Exception:  # noqa: BLE001 — без головы остаются заголовок/алиасы
        return ""


def _pair_text(
    f: rank.Fused, meta: NoteMeta | None, sr: SearchResult | None, vault: Path
) -> str:
    """Текст пары реранкера: чанк FTS/семантики с «title · heading_path», иначе скан-хит —
    ``title · H1 · aliases`` + голова тела с диска."""
    if sr is not None and sr.text:
        title = (meta.title if meta is not None else "") or f.note_id
        return rr.chunk_pair_text(title, sr.heading_path, sr.text)
    if meta is None:
        return f.note_id
    return rr.scan_pair_text(meta.title, meta.h1, meta.aliases, _body_head(vault, meta))


def _rerank_stage(
    query: str,
    fused: list[rank.Fused],
    *,
    by_id: dict[str, NoteMeta],
    rows: dict[str, SearchResult],
    vault: Path,
    result: FindResult,
) -> tuple[list[rank.Fused], set[str]]:
    """Второй этап (RETR-RERANK-1 п.2): верхние ``DT_RERANK_POOL`` fused → cross-encoder.

    ``final = α·score01 + (1-α)·fused`` (``DT_RERANK_ALPHA``), пул пересортирован; хвост пула
    ниже и в прежнем порядке (оценки хвоста подрезаны так, чтобы выдача осталась отсортирована
    по ``score``). Сбой/нет модели → ``rerank_unavailable`` и прежний порядок. Возвращает новый
    список и множество переоценённых id (для суффикса ``+rerank``).
    """
    pool_n = min(rr.rerank_pool(), len(fused))
    head, tail = fused[:pool_n], fused[pool_n:]
    started = time.perf_counter()
    stats: dict[str, Any] = {"applied": False, "pool": pool_n}
    try:
        cands = [
            rr.RerankCand(
                f.note_id, _pair_text(f, by_id.get(f.note_id), rows.get(f.note_id), vault)
            )
            for f in head
        ]
        scores = rr.rerank(query, cands)
    except Exception as exc:  # noqa: BLE001 — реранкер опционален: деградация с кодом
        logger.warning("[find_notes] reranker unavailable (%s); fused order", exc)
        result.warnings.append(
            warning(
                rr.CODE_RERANK_UNAVAILABLE,
                f"реранкер недоступен ({type(exc).__name__}: {str(exc)[:200]}): порядок — по "
                "слиянию ступеней, без переоценки",
                component="rerank",
            )
        )
        stats["ms"] = round((time.perf_counter() - started) * 1000)
        result.rerank = stats
        return fused, set()
    alpha = rr.rerank_alpha()
    for f, (_, s01) in zip(head, scores, strict=True):
        f.score = rr.blend(s01, f.score, alpha)
    head = sorted(head, key=lambda f: f.score, reverse=True)
    ceiling = head[-1].score if head else 1.0
    for f in tail:
        ceiling = min(ceiling, f.score)
        f.score = ceiling
    stats.update(
        applied=True, ms=round((time.perf_counter() - started) * 1000),
        device=rr.get_reranker().device,
    )
    result.rerank = stats
    return head + tail, {f.note_id for f in head}


def _lexical(
    vault_path: Path,
    query: str,
    *,
    scope: str,
    person: str | None,
    domain: str | None,
    limit: int,
) -> list[FindHit]:
    """Только лексика (скан ∪ FTS, без эмбеддинга) по ``scope`` — слитая по единой шкале.

    Тонкая обёртка для вызывающих, которым нужна ровно лексическая часть конвейера (без
    семантики и закрепления хабов). FTS best-effort: сбой индекса логируется WARNING, скан
    остаётся валидным.
    """
    return _run(
        query, scope=scope, person=person, domain=domain, sort="relevance", limit=limit,
        vault_path=vault_path, semantic=False, pin=False, rerank=False,
    ).hits


# --------------------------------------------------------------------------- #
# Public API                                                                  #
# --------------------------------------------------------------------------- #
def find_notes(
    query: str = "",
    *,
    corpus: str | None = None,
    person: str | None = None,
    domain: str | None = None,
    sort: str = "relevance",
    limit: int = 8,
    vault_path: Path | None = None,
    rerank: bool | None = None,
    include_eval: bool = False,
) -> list[FindHit]:
    """Legacy-aware note finder (RETR-LEGACY FIX-1) + MAIL-THREAD-1 + RETR-RANK-1.

    ``include_eval`` (EVAL-HYGIENE-1): по умолчанию прогоны eval/selftest (``purpose != work``,
    файлы под ``_eval``) из выдачи исключены; ``True`` - для eval-отладки.

    Тонкая обёртка над :func:`find_notes_ex` без конвертов деградации (для вызывающих,
    которым нужен только список хитов). ``rerank`` — см. :func:`find_notes_ex`.
    """
    return find_notes_ex(
        query, corpus=corpus, person=person, domain=domain, sort=sort, limit=limit,
        vault_path=vault_path, rerank=rerank, include_eval=include_eval,
    ).hits


def find_notes_ex(
    query: str = "",
    *,
    corpus: str | None = None,
    person: str | None = None,
    domain: str | None = None,
    sort: str = "relevance",
    limit: int = 8,
    vault_path: Path | None = None,
    rerank: bool | None = None,
    include_eval: bool = False,
) -> FindResult:
    """:func:`find_notes` + конверты деградации (FTS/семантика недоступны, кэш битый).

    После отбора докладывает у почтовых тредов ``last_from``/``last_date`` (frontmatter
    последнего сообщения) — чтобы «чем кончился тред» было видно в выдаче без чтения тела.

    ``rerank`` (RETR-RERANK-1): ``True``/``False`` бьёт env ``DT_RERANK``; ``None`` — по env.
    Реранкер включается для текстового запроса при ``sort="relevance"`` и пуле больше ``limit``;
    нет модели → конверт ``rerank_unavailable`` и порядок слияния.
    """
    result = _find_notes_result(
        query, corpus=corpus, person=person, domain=domain, sort=sort, limit=limit,
        vault_path=vault_path, rerank=rerank, include_eval=include_eval,
    )
    root = Path(vault_path) if vault_path is not None else default_vault_path()
    for hit in result.hits:
        _enrich_mail_hit(hit, root)
    return result


def _enrich_mail_hit(hit: FindHit, vault_path: Path) -> None:
    """Доложить ``last_from``/``last_date`` почтовому хиту (молча пропустить не-почту).

    Источник — frontmatter (``last_from``/``last_date``); у заметок, отрендеренных до
    MAIL-THREAD-1, ``last_from`` нет — тогда он берётся из заголовка последнего
    сообщения тела (одна дешёвая разборка, только для хитов-тредов)."""
    if not hit.path or not (
        hit.source_path.startswith("correspondence/") or "/correspondence/" in hit.path
    ):
        return
    try:
        note = read_note(vault_path / hit.path)
    except Exception:  # noqa: BLE001 — обогащение best-effort, выдача важнее
        return
    fm = note.frontmatter
    if fm.get("source_type") != EMAIL_THREAD:
        return
    last_from = str(fm.get("last_from") or "")
    last_date = str(fm.get("last_date") or "")
    from_me = fm.get("last_from_me")
    if not last_from:
        info = last_message_info(parse_thread(note.body))
        last_from = info["last_from"]
        last_date = last_date or info["last_date"]
        from_me = info["last_from_me"] if last_from else None
    hit.last_from, hit.last_date = last_from, last_date
    hit.last_from_me = bool(from_me) if from_me is not None else None


def _find_notes_core(
    query: str = "",
    *,
    corpus: str | None = None,
    person: str | None = None,
    domain: str | None = None,
    sort: str = "relevance",
    limit: int = 8,
    vault_path: Path | None = None,
    rerank: bool | None = None,
) -> list[FindHit]:
    """Хиты :func:`_find_notes_result` без конвертов (совместимость)."""
    return _find_notes_result(
        query, corpus=corpus, person=person, domain=domain, sort=sort, limit=limit,
        vault_path=vault_path, rerank=rerank,
    ).hits


def _find_notes_result(
    query: str = "",
    *,
    corpus: str | None = None,
    person: str | None = None,
    domain: str | None = None,
    sort: str = "relevance",
    limit: int = 8,
    vault_path: Path | None = None,
    rerank: bool | None = None,
    include_eval: bool = False,
) -> FindResult:
    """Конвейер поиска (см. докстринг модуля).

    ``corpus`` — scope: ``vault``/``current``/``legacy``/``raw`` (= current+legacy)/``both``/
    ``None`` (авто — все три слоя одним проходом; ``both`` тождественен авто). Пустой ввод
    (нет query/person/domain) → пустая выдача. Эмбеддер грузится, только если лексических
    хитов меньше :func:`semantic_floor`.
    """
    scope = corpus if corpus in _SCOPE_SET else "both"
    return _run(
        (query or "").strip(),
        scope=scope,
        person=(person or "").strip() or None,
        domain=(domain or "").strip() or None,
        sort=sort,
        limit=max(1, int(limit)),
        vault_path=vault_path,
        rerank=rerank,
        include_eval=include_eval,
    )


def _run(
    query: str,
    *,
    scope: str,
    person: str | None,
    domain: str | None,
    sort: str,
    limit: int,
    vault_path: Path | None,
    semantic: bool = True,
    pin: bool = True,
    rerank: bool | None = None,
    include_eval: bool = False,
) -> FindResult:
    """Ступени → слияние → (реранкер) → хиты.

    ``semantic``/``pin`` выключаются для чисто лексического вызова.
    """
    result = FindResult()
    if not query and not person and not domain:
        return result
    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    metas, cache_warnings = load_metas_cached(vault)
    result.warnings.extend(cache_warnings)
    # EVAL-HYGIENE-1 п.3: прогоны eval/selftest не отдаем (хабы/поиск/досье) без include_eval
    quarantined = frozenset() if include_eval else frozenset(
        m.id for m in metas if is_quarantined(m))
    if quarantined:
        metas = [m for m in metas if m.id not in quarantined]
    by_id = {m.id: m for m in metas}
    corpus_arg = _SCOPE_CORPUS[scope]
    scope_set = _SCOPE_SET[scope]

    # П.4: хабы клиента/продукта/проекта из запроса (по алиасам, H1 и слагу, на стем-ключах).
    # Только для текстового запроса по relevance и без жёстких контактных фильтров: у хаба нет
    # контактов (AND по person/domain его исключил бы), а sort="recent" — явный порядок по дате.
    use_pin = pin and _pin_enabled()
    catalog = build_catalog(metas) if (use_pin and query and not person and not domain) else []
    matched = [
        m for m in match_hubs(query, catalog)
        if sort != "recent" and (scope_set is None or by_id[m.note_id].corpus in scope_set)
    ][:_PIN_TOP]
    pinned = [m.note_id for m in matched]
    terms = tuple(canonical_terms(matched, catalog)) if _canon_expand_enabled() else ()

    scan = _scan_cands(metas, query, scope=scope_set, person=person, domain=domain)
    if sort != "recent":
        pool = max(limit * _SCAN_POOL_PER_LIMIT, _SCAN_POOL_MIN)
        scan = [c for c, _ in rank.stage_order("scan", scan)[:pool]] if len(scan) > pool else scan
    fts, fts_rows = _fts_cands(
        query, extra_terms=terms, corpus_arg=corpus_arg, limit=limit, by_id=by_id,
        person=person, domain=domain, warnings=result.warnings,
    )
    if quarantined:
        fts = [c for c in fts if c.note_id not in quarantined]
        fts_rows = {k: v for k, v in fts_rows.items() if k not in quarantined}
    stages: dict[str, list[rank.Cand]] = {"scan": scan, "fts": fts}

    sem_rows: dict[str, SearchResult] = {}
    lexical_ids = {c.note_id for c in scan} | {c.note_id for c in fts}
    # RETR-RERANK-1 п.4 / абляция 29.10: «семантика всегда» при реранкере роняет recall@5
    # (0.85 → 0.82, вариант «в») - только по явному DT_FIND_SEMANTIC_ALWAYS, не вслед за реранкером.
    want_rerank = rr.rerank_enabled() if rerank is None else bool(rerank)
    sem_always = rr.semantic_always_enabled()
    if semantic and query and (sem_always or len(lexical_ids) < semantic_floor()):
        sem, sem_rows = _semantic_cands(
            query, corpus_arg=corpus_arg, limit=limit, by_id=by_id, person=person,
            domain=domain, warnings=result.warnings,
        )
        if quarantined:
            sem = [c for c in sem if c.note_id not in quarantined]
            sem_rows = {k: v for k, v in sem_rows.items() if k not in quarantined}
        stages["semantic"] = sem

    boosts: dict[str, float] = {}
    if pinned:
        wanted = set(pinned)
        for nid in lexical_ids | {c.note_id for c in stages.get("semantic", [])}:
            meta = by_id.get(nid)
            if meta is not None and nid not in wanted and owner_ids(meta) & wanted:
                boosts[nid] = rank.BOOST_CLIENT

    fused = rank.fuse(stages, boosts=boosts)
    extra = {
        nid: rank.Fused(nid, 0.0, "fts", _layer_of(by_id[nid].corpus), by_id[nid].date)
        for nid in pinned
    }
    scored: set[str] = set()
    if (want_rerank and query and sort == "relevance" and len(fused) > limit
            and rr.query_token_count(query) >= rr.min_tokens()):
        fused, scored = _rerank_stage(
            query, fused, by_id=by_id, rows={**sem_rows, **fts_rows}, vault=vault, result=result
        )
    if pinned:
        if scored:  # хаб гарантированно в топ-3, а первым — лучший по реранкеру
            fused = rank.apply_pin_top(fused, pinned, top=_PIN_TOP, extra=extra)
        else:
            fused = rank.apply_pin(fused, pinned, top=_PIN_TOP, extra=extra)
    hits: list[FindHit] = []
    for f in fused:
        meta = by_id.get(f.note_id)
        sr = fts_rows.get(f.note_id) or sem_rows.get(f.note_id)
        if meta is not None:
            hit = _hit_from_meta(meta, sr)
        elif sr is not None:
            hit = _from_search(sr, matched_by=f.matched_by)
        else:  # pragma: no cover — кандидат без среза и без чанка невозможен
            continue
        hit.score = f.score if query else 1.0
        hit.matched_by = f.matched_by + (rank.RERANK_SUFFIX if f.note_id in scored else "")
        hits.append(hit)
    result.hits = _finalize(hits, sort, limit)
    return result


# --------------------------------------------------------------------------- #
# SRC-FRESH-1 — разброс дат в выдаче (видимость давности, ранжирование не трогаем) #
# --------------------------------------------------------------------------- #
DEFAULT_SPREAD_MONTHS = 12
_SPREAD_ENV = "DT_DATE_SPREAD_MONTHS"

# Дата из frontmatter бывает ``2023-11-23``, ``2023-11-23 10:00``, ``23.11.2023``.
_ISO_RE = re.compile(r"(\d{4})-(\d{2})-(\d{2})")
_DOTTED_RE = re.compile(r"(\d{2})\.(\d{2})\.(\d{4})")


def spread_months() -> int:
    """Порог разброса дат, месяцы (env ``DT_DATE_SPREAD_MONTHS``, дефолт 12)."""
    raw = os.environ.get(_SPREAD_ENV, "").strip()
    try:
        value = int(float(raw))
    except (TypeError, ValueError):
        return DEFAULT_SPREAD_MONTHS
    return value if value > 0 else DEFAULT_SPREAD_MONTHS


def _as_date(raw: str) -> date | None:
    """Строка даты из frontmatter → :class:`datetime.date` (или ``None``)."""
    text = str(raw or "").strip()
    if not text:
        return None
    m = _ISO_RE.search(text)
    if m:
        y, mo, d = (int(g) for g in m.groups())
    else:
        m = _DOTTED_RE.search(text)
        if not m:
            return None
        d, mo, y = (int(g) for g in m.groups())
    try:
        return date(y, mo, d)
    except ValueError:
        return None


def _months_between(older: date, newer: date) -> int:
    """Полных месяцев от ``older`` до ``newer`` (календарно, без 30-дневной прикидки)."""
    months = (newer.year - older.year) * 12 + (newer.month - older.month)
    if newer.day < older.day:
        months -= 1
    return max(0, months)


def date_spread_warning(hits: list[FindHit], *, months: int | None = None) -> str:
    """Предупреждение, если верхний хит существенно старше самого свежего в выдаче.

    Кейс (фейлкейс 2026-08-11): по бизнес-плану 2023 сделан вывод «план обрывается
    на 2026, нужен новый» — обратный истине, потому что действующий план 2026–2029
    лежал в той же выдаче ниже. Ранжирование при этом честное (шаблон лексически
    плотнее), поэтому **порядок мы не меняем** — только говорим вслух, что верхний
    результат старше свежайшего более чем на ``months`` (env
    ``DT_DATE_SPREAD_MONTHS``, дефолт 12), и даём путь свежего.

    Пусто, если хитов меньше двух, даты не разобрались, верхний И ЕСТЬ свежайший или
    разрыв в пределах порога. При ``sort="recent"`` самогасится (верхний = свежайший).
    """
    if len(hits) < 2:
        return ""
    limit = months if months is not None and months > 0 else spread_months()
    top_date = _as_date(hits[0].date)
    if top_date is None:
        return ""
    freshest: FindHit | None = None
    freshest_date: date | None = None
    for hit in hits[1:]:
        d = _as_date(hit.date)
        if d is None:
            continue
        if freshest_date is None or d > freshest_date:
            freshest, freshest_date = hit, d
    if freshest is None or freshest_date is None or freshest_date <= top_date:
        return ""
    gap = _months_between(top_date, freshest_date)
    if gap <= limit:
        return ""
    return (
        f"верхний результат на {gap} мес старше самого свежего "
        f"({freshest.path}, {freshest.date}) — проверь версию или sort='recent'"
    )


# --------------------------------------------------------------------------- #
# SRC-FRESH-1 — «последняя версия по семейству»                                #
# --------------------------------------------------------------------------- #
# Бонус семейства за пересечение токенов запроса с ОБЩИМИ токенами семейства (токены имен, которые
# есть не менее чем у половины членов). Формула детерминирована и без НЛП:
#   ранг = score лучшего хита + LATEST_QUERY_BONUS * |токены запроса ∩ shared| / |токены запроса|
# 0..1 шкала хита + бонус до 0,2: семейство, чье имя говорит то же, что запрос, обгоняет соседа с
# чуть более высоким score, но не перебивает большой разрыв релевантности.
LATEST_QUERY_BONUS = 0.2
# Полоса «одинаково релевантных»: семейства, чей итоговый ранг не ниже лучшего минус эта величина,
# идут по ДАТЕ своего latest (новые первыми), остальные - ниже по рангу. Вопрос «какая последняя
# версия» отвечает на свежесть, а не на лексику: два семейства КП с разницей в 0,05 по FTS - не
# повод показывать старое первым (на папке Acme: лексика ставила расчеты КП выше самого свежего
# КП). Вне полосы порядок прежний - по рангу.
LATEST_RELEVANCE_BAND = 0.2
# Сколько членов семейства отдавать в ответе (остальные - в ``versions``).
LATEST_MEMBERS_SHOWN = 10


@dataclass
class LatestFamily:
    """Семейство версий ВОКРУГ найденного файла (а не вся папка) и его самый новый файл.

    ``latest_path``/``latest_mtime`` — новейший не-архивный член семейства, даже если поиск его
    не вернул: ровно этот случай и был дефектом SRC-FRESH-1 (в выдаче жил шаблон 2023, действующий
    план 2026 не показывался вовсе). ``latest_final_path`` — новейший член, который не черновик и
    не архив (``None``, если такого нет: действующей версии в семействе нет, и это видно).
    ``versions`` — размер СЕМЕЙСТВА (не папки), ``hits`` — сколько хитов поиска в него попало;
    ``note_id``/``title``/``score`` — лучший хит, которым семейство найдено (след к заметке),
    ``score`` — итоговый ранг семейства (хит + бонус за запрос); ``seed`` — файл-основа семейства;
    ``members`` — первые :data:`LATEST_MEMBERS_SHOWN` (``path, mtime, draft, archived``, новые
    сверху); ``shared_tokens`` — о чем семейство.
    """

    directory: str
    latest_path: str
    latest_mtime: float
    versions: int
    hits: int
    note_id: str
    title: str
    score: float
    latest_draft: bool = False
    latest_archived: bool = False
    latest_final_path: str | None = None
    latest_final_mtime: float | None = None
    seed: str = ""
    members: list[dict[str, Any]] = field(default_factory=list)
    shared_tokens: list[str] = field(default_factory=list)


def _note_status_draft(hit: FindHit, vault: Path) -> bool:
    """``status: draft`` у заметки-хита (frontmatter; тело не нужно). Нет заметки/поля - False."""
    rel = (hit.path or "").strip()
    if not rel.lower().endswith(".md"):
        return False
    target = Path(rel) if Path(rel).is_absolute() else vault / rel
    try:
        fm = read_note(target).frontmatter
    except Exception:  # noqa: BLE001 — сигнал дополнительный, выдача важнее
        return False
    return str(fm.get("status") or "").strip().lower() == "draft"


def find_latest(
    query: str = "",
    *,
    corpus: str | None = None,
    person: str | None = None,
    domain: str | None = None,
    limit: int = 5,
    vault_path: Path | None = None,
    include_eval: bool = False,
) -> list[LatestFamily]:
    """«Какая последняя версия?» — по СЕМЕЙСТВАМ вокруг найденных файловых источников.

    Поверх :func:`find_notes` (та же лексика/семантика, тот же scope), без нового
    стейта. ``source_path`` заметки — путь ОТНОСИТЕЛЬНО корня хранилища (у legacy —
    относительно Bitrix-базы), поэтому файл берётся не из строки, а разрешением
    через :func:`core.sources.resolve_source_path` — тем же порядком, которым живёт
    ``lift_source`` (абсолютный → legacy-корни → операционные корни → релокация по
    content-hash), но без чтения и хеширования файла.

    **Семейство - вокруг файла, не папка (FIND-LATEST-1).** Папка клиента (23 файла: КП, расчеты,
    деки, ТС, сайзинг) не версии одного документа: прежний «новейший файл каталога» отвечал на
    «КП Acme» файлом «Требования к персоналу». Теперь для хита seed = его файл, семейство -
    :func:`core.sources.family_of` (файлы той же папки, похожие на seed именем; один листинг на
    папку, содержимое не читается). Семейства с тем же набором членов (и входящие целиком в
    более релевантное) схлопываются, их хиты идут в ``hits``; пересекающиеся, но разные -
    остаются раздельно (звезда от периферийного файла - другое семейство).

    **Ранжирование** семейств: ранг = лучший ``score`` хита + :data:`LATEST_QUERY_BONUS` × доля
    токенов запроса в ОБЩИХ токенах семейства (формула у константы). Семейства в полосе
    :data:`LATEST_RELEVANCE_BAND` от лучшего («одинаково релевантные») идут по дате своего
    ``latest`` (новые первыми) - это вопрос про свежесть; остальные ниже по рангу; равные - большее
    семейство, затем путь. Нового ранжирования ``find_notes`` нет.

    **Черновик vs действующий.** Члены помечаются ``draft``/``archived`` по маркерам имени/папки
    (``_system/freshness-markers.yaml``) и ``status: draft`` заметки-хита; ``latest`` - новейший
    не-архивный, ``latest_final`` - новейший не-черновик и не-архив, или ``None``.

    Почему не «самый новый ИЗ ХИТОВ»: поиск в кейсе 11.08 не вернул действующую
    версию вовсе — ответ обязан приходить из каталога, а не из выдачи.

    Заметки без файлового источника семейством НЕ становятся: у курированной заметки
    vault ``source_path`` вырождается в путь самой заметки, у legacy-переписки это
    провенанс-строка треда. Папка ``01-style/letters`` — не версии одного документа,
    и назвать её «семейством» значило бы соврать. Нечитаемая папка - пусто, не исключение.
    Read-only.
    """
    from core.sources import family_files, family_of, resolve_source_path
    from core.sources.freshness import text_tokens
    from core.sources.markers import load_markers

    limit = max(1, int(limit))
    vault = (Path(vault_path) if vault_path is not None else default_vault_path())
    # Scope по умолчанию — все слои (``both`` ≡ авто, RETR-RANK-1: раньше авто-лестница отдавала
    # vault-рунг и останавливалась, а файловый источник есть как раз у legacy/current/инжест-заметок
    # — «последняя версия» возвращала пусто). Явный ``corpus`` вызывающего уважается как есть.
    hits = find_notes(
        query,
        corpus=corpus if corpus is not None else "both",
        person=person,
        domain=domain,
        sort="relevance",
        limit=max(limit * 8, 40),  # пул под группировку: семейство схлопывает хиты
        vault_path=vault_path,
        include_eval=include_eval,
    )
    sourced: list[tuple[FindHit, Path]] = []
    for hit in hits:
        raw = (hit.source_path or "").strip()
        if not raw:
            continue
        try:
            src = resolve_source_path(raw, vault_path=vault_path, note_path=hit.path or None)
        except Exception as exc:  # noqa: BLE001 — нерешаемый путь не роняет выдачу
            logger.debug("[find_latest] источник не разрешён (%s): %s", raw, exc)
            continue
        # Единственный признак «источник файловый»: путь разрешился в НЕ-``.md``.
        # У курированной заметки vault source_path — её же .md (и у FTS/семантик-хитов
        # ``path`` совпадает с ``source_path`` по контракту FindHit), у нерешаемого
        # провенанса legacy-треда не разрешается вовсе.
        if src is None or src.suffix.lower() == ".md":
            continue
        if not include_eval and is_eval(src):  # EVAL-HYGIENE-1: семейство из карантина - не версия
            continue
        sourced.append((hit, src))
    if not sourced:
        return []
    sourced.sort(key=lambda item: item[0].score, reverse=True)  # лучший хит строит семейство первым

    markers = load_markers(vault_path)
    listings: dict[str, list[tuple[str, float]]] = {}
    draft_paths = {str(src) for hit, src in sourced if _note_status_draft(hit, vault)}
    q_tokens = text_tokens(query or "", query=True)

    built: list[dict[str, Any]] = []
    for hit, src in sourced:
        directory = str(src.parent)
        if directory not in listings:
            listings[directory] = family_files(directory)
        if not listings[directory]:
            continue  # папка нечитаема/пуста: честно «нет семейства»
        fam = family_of(src, files=listings[directory], markers=markers, draft_paths=draft_paths)
        if not fam.members or fam.latest is None:
            continue
        shared = fam.shared_tokens()
        coverage = len(q_tokens & set(shared)) / len(q_tokens) if q_tokens else 0.0
        bonus = LATEST_QUERY_BONUS * coverage
        built.append({"family": fam, "hit": hit, "hits": 1, "shared": shared,
                      "score": hit.score + bonus,
                      "paths": frozenset(m.path for m in fam.members)})

    built.sort(key=lambda b: (-b["score"], -b["family"].versions, b["family"].seed))
    # Схлопывание: семейство с тем же набором членов (или входящее целиком в более релевантное)
    # не дублируется - его хиты считаются в «hits» объемлющего. Пересекающиеся, но разные
    # семейства остаются раздельными: звезда от периферийного файла - другое семейство.
    kept: list[dict[str, Any]] = []
    for b in built:
        host = next((k for k in kept if b["paths"] <= k["paths"]), None)
        if host is not None:
            host["hits"] += b["hits"]
        else:
            kept.append(b)
    top = max((b["score"] for b in kept), default=0.0)
    band = [b for b in kept if b["score"] >= top - LATEST_RELEVANCE_BAND]
    rest = [b for b in kept if b["score"] < top - LATEST_RELEVANCE_BAND]
    band.sort(key=lambda b: (-b["family"].latest.mtime, -b["score"], b["family"].seed))
    built = band + rest
    out: list[LatestFamily] = []
    for b in built[:limit]:
        fam = b["family"]
        latest, final = fam.latest, fam.latest_final
        out.append(
            LatestFamily(
                directory=fam.directory,
                latest_path=latest.path,
                latest_mtime=latest.mtime,
                versions=fam.versions,
                hits=b["hits"],
                note_id=b["hit"].note_id,
                title=b["hit"].title,
                score=b["score"],
                latest_draft=latest.draft,
                latest_archived=latest.archived,
                latest_final_path=final.path if final else None,
                latest_final_mtime=final.mtime if final else None,
                seed=fam.seed,
                members=[m.to_dict() for m in fam.members[:LATEST_MEMBERS_SHOWN]],
                shared_tokens=b["shared"],
            )
        )
    return out


def read_full_note(
    path: str,
    *,
    max_chars: int = 8000,
    vault_path: Path | None = None,
    messages: str | int | None = None,
) -> dict[str, Any]:
    """Full-read a note by path, имени файла или frontmatter id (RETR-LEGACY FIX-2).

    Accepts a vault-relative or absolute path behind a containment guard (only
    inside the vault — same shape as ``operational.hub_notes`` /
    ``operational.attribute``). Returns ``{path, id, frontmatter, body, truncated}``
    with ``body`` cut to ``max_chars`` (``truncated`` flags the cut). Read-only.

    **MAIL-THREAD-1 (почта).** Для ``source_type: email-thread`` бюджет ``max_chars``
    считается по сообщениям, а не по символам: заголовки ВСЕХ сообщений остаются,
    тела отдаются с конца (ранние урезаются первыми, цитатные хвосты — раньше целых
    сообщений), в ответе ``messages{total, shown_full, shown_header_only, last_from,
    last_date}``. ``messages="last"|N|"inbound_last"`` — прямой доступ к хвосту.
    Не-почтовые заметки: параметр игнорируется, поведение прежнее байт-в-байт.

    **NOTE-ID-1 / CONTRACT-1 ФП-1.** Путь не сложился → ссылка резолвится
    :func:`core.vault.resolve_note_path`: frontmatter ``id`` (индекс-манифест, O(1)) →
    ``source_path`` заметки (обратные карты манифестов инжеста, включая виртуальные
    ``correspondence/conv:…`` у почты) → имя файла. Кейс К. с пульта: цель
    линк-предложения ``pak-a-zdo-overview`` при файле ``pak-a-overview.md``. Кейс
    справки 14.08: ``correspondence/conv:207549`` из выдачи ``find_notes``.

    **Containment цел.** Читается только то, что лежит внутри vault: `source_path`
    может быть абсолютным путём файла-источника ВНЕ vault, но результатом резолва всё
    равно становится заметка внутри — сам файл-источник этим инструментом не читается
    (для него есть ``lift_source``). Ссылка, которая не резолвится в заметку и уводит
    наружу, — отказ с прежней ошибкой ``path escapes vault``.
    """
    vault = (Path(vault_path) if vault_path is not None else default_vault_path()).resolve()
    raw = Path(path)
    candidate = (vault / raw if not raw.is_absolute() else raw).resolve()
    inside = candidate == vault or vault in candidate.parents
    if inside and candidate.is_file():
        p = candidate
    else:
        # Не путь к заметке — резолвим как ссылку любой формы (id / source_path / имя
        # файла). Единая точка на всех читателей; результат всегда внутри vault.
        resolved = resolve_note_path(path, vault_path=vault)
        if resolved is None:
            # Порядок сообщений прежний: уводящий наружу путь — своя ошибка, чтобы не
            # маскировать нарушение границы под «не нашлось».
            if not inside:
                raise ReadNoteError(f"path escapes vault: {path}")
            raise ReadNoteError(f"no such note: {path}")
        p = resolved

    max_chars = max(1, int(max_chars))
    note = read_note(p)

    # NDA-2: барьер и на чтении заметки, по ОБОИМ её путям. Обход vault отбрасывает
    # NDA по пути файла, но легаси-слуг маркер теряет (``About_EC_НМ_NDA.pptx`` →
    # ``about-ec-nm-nda-….md``): такую заметку ``lift_source`` уже отказывался
    # поднимать (``nda=True``), а ``read_note`` отдавал ЦЕЛИКОМ — то есть тот же текст
    # приезжал в контекст через другую дверь. Отказ, а не пустое тело: молчаливая
    # пустота неотличима от «заметка пустая».
    source = note.frontmatter.get("source_path")
    if isinstance(source, list):
        source = source[0] if source else ""
    if any_nda(p, source):
        raise ReadNoteError(
            f"NDA-исключение: заметка {note.id} под барьером "
            f"(источник {source!r}) — содержимое не отдаётся"
        )

    body = note.body
    # MAIL-THREAD-1: почтовый тред читается по сообщениям (бюджет — заголовки всех,
    # тела с конца, сводка пропущенного). Не-почта идёт прежним путём БАЙТ-в-БАЙТ.
    if note.frontmatter.get("source_type") == EMAIL_THREAD:
        mailed = _read_mail_thread(
            note.frontmatter, body, max_chars, messages, path=p, vault=vault, note_id=note.id
        )
        if mailed is not None:
            return mailed
    truncated = len(body) > max_chars
    if truncated:
        body = body[:max_chars].rstrip() + "\n\n…[truncated]"
    return {
        "path": str(p.relative_to(vault)),
        "id": note.id,
        "frontmatter": note.frontmatter,
        "body": body,
        "truncated": truncated,
    }


def _read_mail_thread(
    frontmatter: dict[str, Any],
    body: str,
    max_chars: int,
    messages: str | int | None,
    *,
    path: Path,
    vault: Path,
    note_id: str,
) -> dict[str, Any] | None:
    """MAIL-THREAD-1 P0: чтение ``email-thread`` по сообщениям, а не по символам.

    ``None`` — тело не разобралось в сообщения (нет заголовков ``## дата — от``): тогда
    вызывающий читает по-старому. Иначе ответ = прежняя форма ``{path, id, frontmatter,
    body, truncated}`` **плюс** ``messages{total, shown_full, shown_header_only, …,
    last_from, last_date}`` — честная сводка того, что агент НЕ прочитал.

    Параметр ``messages``: ``"all"`` (дефолт; бюджет по сообщениям) | ``"last"`` |
    ``N`` (последние N) | ``"inbound_last"`` (последнее сообщение не от меня).
    """
    try:
        mode, n = parse_messages_arg(messages)
    except ValueError as exc:
        raise ReadNoteError(str(exc)) from exc
    parsed = parse_thread(body)
    if parsed is None:
        return None
    if mode == "all" and len(body) <= max_chars:
        out_body, summary, truncated = body, full_summary(parsed), False
    else:
        out_body, summary, truncated = render_budgeted(parsed, max_chars, mode=mode, n=n)
    return {
        "path": str(path.relative_to(vault)),
        "id": note_id,
        "frontmatter": frontmatter,
        "body": out_body,
        "truncated": truncated,
        "messages": summary,
    }
