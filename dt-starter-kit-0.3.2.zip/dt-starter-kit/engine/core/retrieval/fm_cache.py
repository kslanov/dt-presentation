"""RETR-RANK-1 п.6 — кэш frontmatter для скана ``find_notes`` (``.derived/index/frontmatter.json``).

Скан раньше парсил frontmatter ВСЕХ заметок (~17,5 тыс. файлов, ~4-7 с) на каждый вызов
``find_notes``. Теперь каждый вызов делает только обход путей и ``stat`` (≈0,2 с), а парсит —
лишь файлы, чьи ``(mtime_ns, size)`` не совпали с кэшем; остальное — срезы из кэша
(:class:`core.retrieval.notemeta.NoteMeta`). Кэш хранится по vault-относительному пути, на
процесс держится ещё и в памяти (свёрнутые стем-ключи полей живут в самих срезах).

Кэш — производный и перестраиваемый (источник истины — vault): отсутствует, битый, не от этого
vault или старой версии → полный обход диска, как до п.6, и **конверт** в ответ (``warnings``
вызывающему: «не молча»); после обхода кэш пишется заново, так что деградация разовая. Нечитаемая
заметка (битый frontmatter) пропускается и тоже попадает в конверт: одна плохая заметка не
должна ронять поиск по всем остальным. NDA и системные каталоги — как у индекса
(:func:`core.vault.iter_vault_paths`). Шаг ``reindex`` обновляет кэш в конце прогона.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.config import lancedb_path
from core.contract import CODE_PARTIAL, CODE_STORE_UNAVAILABLE, warning
from core.retrieval.notemeta import NoteMeta, meta_from_note
from core.vault import iter_vault_paths, read_note

logger = logging.getLogger(__name__)

__all__ = ["CACHE_VERSION", "cache_path", "forget", "load_metas_cached", "peek_metas", "refresh"]

CACHE_VERSION = 1
_ENV = "DT_FM_CACHE_PATH"
_LOCK = threading.Lock()


def cache_path() -> Path:
    """``.derived/index/frontmatter.json`` (рядом с lancedb; env ``DT_FM_CACHE_PATH``)."""
    override = os.environ.get(_ENV)
    if override:
        return Path(override)
    return lancedb_path().parent / "index" / "frontmatter.json"


@dataclass
class _State:
    """Записи кэша: vault-относительный путь → ((mtime_ns, size), срез)."""

    entries: dict[str, tuple[tuple[int, int], NoteMeta]] = field(default_factory=dict)


# Память процесса: (vault, файл кэша) → состояние. Сверка со stat-обходом на каждый вызов.
_MEMO: dict[tuple[str, str], _State] = {}


def _to_json(meta: NoteMeta) -> dict[str, Any]:
    return {
        "id": meta.id, "path": meta.path, "corpus": meta.corpus, "type": meta.note_type,
        "entity": meta.entity, "title": meta.title, "source_path": meta.source_path,
        "date": meta.date, "h1": meta.h1,
        "fields": {k: list(v) for k, v in meta.fields.items()},
        **({"purpose": meta.purpose} if meta.purpose else {}),  # у рабочей ключа нет
    }


def _from_json(raw: dict[str, Any]) -> NoteMeta:
    return NoteMeta(
        id=str(raw["id"]), path=str(raw["path"]), corpus=str(raw["corpus"]),
        note_type=str(raw.get("type") or ""), entity=str(raw.get("entity") or ""),
        title=str(raw.get("title") or ""), source_path=str(raw.get("source_path") or ""),
        date=str(raw.get("date") or ""), h1=str(raw.get("h1") or ""),
        purpose=str(raw.get("purpose") or ""),
        fields={str(k): tuple(str(x) for x in v) for k, v in (raw.get("fields") or {}).items()},
    )


def _read_disk(vault: Path, path: Path) -> tuple[_State, str]:
    """(состояние, причина деградации). Причина пуста — кэш прочитан здоров."""
    if not path.is_file():
        return _State(), "кэша frontmatter нет (первый запуск или удалён)"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or data.get("version") != CACHE_VERSION:
            return _State(), "кэш frontmatter другой версии — перестраивается"
        if data.get("vault") != str(vault):
            return _State(), "кэш frontmatter от другого vault — перестраивается"
        state = _State()
        for rel, entry in data["entries"].items():
            sig = entry["sig"]
            state.entries[str(rel)] = ((int(sig[0]), int(sig[1])), _from_json(entry["meta"]))
        return state, ""
    except (OSError, ValueError, KeyError, TypeError, IndexError) as exc:
        return _State(), f"кэш frontmatter нечитаем ({type(exc).__name__}) — перестраивается"


def _write_disk(vault: Path, path: Path, state: _State) -> None:
    payload = {
        "version": CACHE_VERSION,
        "vault": str(vault),
        "entries": {
            rel: {"sig": list(sig), "meta": _to_json(meta)}
            for rel, (sig, meta) in state.entries.items()
        },
    }
    tmp = path.with_suffix(path.suffix + f".{os.getpid()}.tmp")
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)
    except OSError as exc:  # кэш — оптимизация: не записался → следующий вызов обойдёт диск снова
        logger.warning("[find_notes] кэш frontmatter не записан (%s)", exc)
        with contextlib.suppress(OSError):
            tmp.unlink()


def load_metas_cached(
    vault_path: Path,
) -> tuple[list[NoteMeta], list[dict[str, Any]]]:
    """Срезы всех заметок vault + конверты деградации (пусто — всё здорово).

    Обход путей и ``stat`` — на каждый вызов; парсятся только новые/изменённые файлы;
    удалённые исчезают из набора; изменение набора пишется на диск.
    """
    vault = Path(vault_path)
    path = cache_path()
    key = (str(vault), str(path))
    warnings: list[dict[str, Any]] = []
    with _LOCK:
        state = _MEMO.get(key)
        if state is None:
            state, reason = _read_disk(vault, path)
            if reason:
                logger.warning("[find_notes] %s — полный обход диска", reason)
                warnings.append(
                    warning(
                        CODE_STORE_UNAVAILABLE,
                        f"{reason}: скан frontmatter идёт полным обходом диска (медленнее; "
                        "результат полный)",
                        component="frontmatter_cache",
                    )
                )
        entries: dict[str, tuple[tuple[int, int], NoteMeta]] = {}
        changed = False
        unreadable: list[str] = []
        for note_path in iter_vault_paths(vault):
            try:
                rel = note_path.relative_to(vault).as_posix()
            except ValueError:
                rel = str(note_path)
            try:
                stat = note_path.stat()
                sig = (stat.st_mtime_ns, stat.st_size)
                prev = state.entries.get(rel)
                if prev is not None and prev[0] == sig:
                    entries[rel] = prev
                    continue
                entries[rel] = (sig, meta_from_note(read_note(note_path, vault), vault))
                changed = True
            except Exception as exc:  # noqa: BLE001 — битая заметка не роняет поиск по остальным
                logger.warning("[find_notes] заметка не прочитана (%s): %s", note_path, exc)
                unreadable.append(rel)
        if set(entries) != set(state.entries):
            changed = True
        state = _State(entries)
        _MEMO[key] = state
        if changed or warnings:
            _write_disk(vault, path, state)
    if unreadable:
        warnings.append(
            warning(
                CODE_PARTIAL,
                f"{len(unreadable)} заметок не прочитано (битый frontmatter) и пропущено в скане",
                unreadable=unreadable[:5],
                count=len(unreadable),
            )
        )
    return [meta for _, meta in state.entries.values()], warnings


def peek_metas(vault_path: Path) -> list[NoteMeta]:
    """Срезы из снимка как он есть (память процесса, иначе диск): без обхода vault и без записи.

    Для проверок «по frontmatter.json» (доктор, dry-run бэкфилла): снимок мог отстать от диска
    на последние правки - вызывающий, который пишет, перечитывает саму заметку.
    """
    vault = Path(vault_path)
    path = cache_path()
    with _LOCK:
        state = _MEMO.get((str(vault), str(path)))
        if state is None:
            state, _reason = _read_disk(vault, path)
    return [meta for _sig, meta in state.entries.values()]


def forget(vault_path: Path, rels: list[str] | None = None) -> None:
    """Забыть записи снимка: ``rels`` (vault-относительные пути) - только их, ``None`` - все.

    Следующий ``load_metas_cached`` перечитает именно их, даже если ``(mtime_ns, size)`` файла
    не изменились (правка алиасов хаба с пульта: единый каталог имен сбрасывается точечно, без
    полного обхода ~17,5 тыс. заметок).
    """
    vault = Path(vault_path)
    path = cache_path()
    key = (str(vault), str(path))
    with _LOCK:
        if rels is None:
            _MEMO.pop(key, None)
            return
        state = _MEMO.get(key)
        if state is None:
            state, _reason = _read_disk(vault, path)
        for rel in rels:
            state.entries.pop(rel, None)
        _MEMO[key] = state


def refresh(vault_path: Path) -> int:
    """Обновить кэш на диске (шаг ``reindex``); возвращает число заметок. Best-effort."""
    metas, _ = load_metas_cached(vault_path)
    return len(metas)
