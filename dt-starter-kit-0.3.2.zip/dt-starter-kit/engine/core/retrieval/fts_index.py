"""RETR-RANK-1 п.3 — настройки и метка полнотекстового индекса (FTS) LanceDB.

Раньше FTS строился с дефолтами LanceDB 0.33 (``language="English"``, ``stem=True``,
``remove_stop_words=True``): английский стеммер и английские стоп-слова на русском корпусе,
поэтому «лицензия»/«лицензии» были разными термами. Теперь — Snowball-ru; английские и
цифровые термы он не трогает (регистр/ASCII-свёртка остаются).

Метка индекса — **sidecar** ``index_fts.json`` рядом с манифестом индекса. В самом манифесте
флаг хранить нельзя: манифест — плоская карта ``note_id → запись``, и зарезервированный ключ
инкрементальный прогон счёл бы удалённой заметкой. Метка пишется при каждой сборке FTS
(полный/инкрементальный reindex, ``--rebuild-fts``), doctor сверяет её с :data:`FTS_LANGUAGE`.
"""

from __future__ import annotations

import contextlib
import json
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import index_manifest_path

__all__ = [
    "FTS_LANGUAGE",
    "fts_options",
    "fts_meta_path",
    "read_fts_meta",
    "write_fts_meta",
    "fts_meta_verdict",
]

# Язык FTS-индекса. Код — источник истины; метка индекса сверяется с ним (doctor).
FTS_LANGUAGE = "Russian"


def fts_options() -> dict[str, Any]:
    """Аргументы ``table.create_fts_index("text", **fts_options())``."""
    return {
        "use_tantivy": False,
        "replace": True,
        "language": FTS_LANGUAGE,
        "stem": True,
        "remove_stop_words": True,
        "lower_case": True,
        "ascii_folding": True,
    }


def fts_meta_path() -> Path:
    """``index_fts.json`` рядом с манифестом (тест-изоляция по ``DT_INDEX_MANIFEST_PATH``)."""
    return index_manifest_path().with_name("index_fts.json")


def read_fts_meta() -> dict[str, Any] | None:
    """Метка индекса или ``None`` (нет файла / нечитаем)."""
    try:
        data = json.loads(fts_meta_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def write_fts_meta(*, rows: int, elapsed_s: float | None = None) -> None:
    """Записать метку (атомарно, best-effort: сбой метки не ломает сборку индекса)."""
    meta = {
        "fts_language": FTS_LANGUAGE,
        "stem": True,
        "remove_stop_words": True,
        "rows": int(rows),
        "built_at": datetime.now(UTC).isoformat(timespec="seconds"),
    }
    if elapsed_s is not None:
        meta["elapsed_s"] = round(float(elapsed_s), 1)
    path = fts_meta_path()
    tmp = path.with_suffix(path.suffix + ".tmp")
    with contextlib.suppress(OSError):
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, path)


def fts_meta_verdict(meta: dict[str, Any] | None) -> tuple[str, str]:
    """(статус, деталь) для doctor: метка индекса против языка в коде."""
    if meta is None:
        return (
            "warn",
            "метки языка FTS нет — индекс собран до RETR-RANK-1 (английский стеммер) "
            f"или метка потеряна; код ждёт {FTS_LANGUAGE}",
        )
    language = str(meta.get("fts_language") or "")
    if language != FTS_LANGUAGE:
        return ("warn", f"FTS собран с языком {language or '?'}, код ждёт {FTS_LANGUAGE}")
    return ("ok", f"{language}, {meta.get('rows', '?')} строк, {meta.get('built_at', '?')}")
