"""RETR-RANK-1 п.4 — нормализация клиента: запрос → хабы сущностей (алиасы каталога).

«Хули конкурс» не знает, что «Хули» = ``client-hooli``; «Амбреллы» — что это хаб
``client-umbrella`` (у него нет ``aliases``, имя живёт в H1 тела: «АО «Амбрелла» (АМБ)»).
Каталог берёт имена хаба из: ``aliases`` (явные), ``title``, H1 (целиком и фрагменты в «…» и
(…)), слага id без префикса сущности. Совпадение — по стем-ключам слов
(:func:`core.text.stem.stem_key`): падежные формы запроса находят имя хаба.

Правила совпадения те же, что у детерминированного резолвера линковки
(:mod:`core.linking.deterministic`: границы слова, ``MIN_TEXT_TOKEN``):

* имя из нескольких слов — подпоследовательность ключей запроса подряд;
* однословное имя ≥ ``MIN_TEXT_TOKEN`` (4) символов — равенство ключей;
* однословное КОРОТКОЕ имя (ИТХ, ЦД) — только явный алиас и ТОЧНО в том же регистре как слово
  запроса (иначе «цд» из прозы закрепляло бы чужой хаб);
* слаг id — только как фраза целиком и только производные имена ≥ 4 символов.

Чистые функции без обращения к диску: каталог строится из срезов :class:`NoteMeta`.

**HUB-ALIAS-1: ОДИН каталог имен хабов для всех потребителей.** :func:`hub_catalog` - фабрика
над общим снимком frontmatter (``fm_cache``: stat-обход, парсятся только изменившиеся файлы);
каждое имя несет метку источника (``HubName.source``: ``alias`` | ``h1`` | ``title`` | ``slug``) и
флаг ``explicit``. Поиск (``find_notes``), ``parse_task``, ``resolve`` (материалы хаба), линковка
(``core.ingest._entity_catalog`` → ``deterministic``/легаси) и доктор «Хабы: имена» читают ЭТОТ
каталог; собственных обходов vault за именами хабов больше нет. Правила совпадения поиска
(:func:`match_hubs` по умолчанию) не менялись.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

from core.retrieval.notemeta import NoteMeta, fold_plain
from core.text.stem import key_tokens, tokens

__all__ = [
    "CATALOG_ENTITIES",
    "HubName",
    "HubEntry",
    "HubMatch",
    "NAME_SOURCES",
    "build_catalog",
    "h1_alias_names",
    "hub_catalog",
    "hub_entry",
    "invalidate_hub_catalog",
    "match_hubs",
    "similar_hub_word",
    "canonical_terms",
]

# Сущности, по которым нормализуем (как TEXT_ENTITIES линковки; industry — слишком общие слова).
CATALOG_ENTITIES: tuple[str, ...] = ("client", "product", "project", "direction")
_MIN_TOKEN = 4
_PREFIX_RE = re.compile(r"^(?:client|product|project|direction|deal|industry)-")
_QUOTED_RE = re.compile(r"[«\"“]([^»\"”]{2,})[»\"”]")
_PAREN_RE = re.compile(r"\(([^()]{2,})\)")
# Хвосты H1-заголовков хабов, не относящиеся к имени.
_H1_TAIL_RE = re.compile(
    r"\s*[—–-]\s*(?:клиентский хаб|хаб(?: клиента| проекта| продукта)?|хаб сущности).*$", re.I
)


# Откуда имя: явный frontmatter-алиас | H1 тела хаба (целиком и фрагменты «…»/(…)) | frontmatter
# title (в схеме хабов его нет, читается, если появится) | слаг id без префикса сущности.
NAME_SOURCES: tuple[str, ...] = ("alias", "h1", "title", "slug")


@dataclass(frozen=True)
class HubName:
    """Одно имя хаба: показ, ключи слов, явный ли это алиас, откуда оно."""

    text: str
    keys: tuple[str, ...]
    explicit: bool           # frontmatter alias (разрешает короткие аббревиатуры)
    source: str = "alias"    # см. NAME_SOURCES


@dataclass
class HubEntry:
    note_id: str
    entity: str
    names: list[HubName] = field(default_factory=list)
    path: str = ""           # vault-относительный путь заметки хаба
    h1: str = ""             # первый «# …» тела (пусто - заголовка нет)


@dataclass(frozen=True)
class HubMatch:
    note_id: str
    entity: str
    name: str                # какое имя сработало
    explicit: bool

    @property
    def abbreviation(self) -> bool:
        """Запрос назвал хаб аббревиатурой (все слова имени короче ``MIN_TOKEN``: ИТХ, ПАК-А)."""
        words = tokens(self.name)
        return bool(words) and max(len(w) for w in words) < _MIN_TOKEN


def _h1_names(h1: str) -> list[str]:
    """Имена из H1 хаба: целиком (без хвоста «— клиентский хаб») + фрагменты «…» и (…)."""
    if not h1:
        return []
    cleaned = _H1_TAIL_RE.sub("", unicodedata.normalize("NFC", h1)).strip()
    out = [cleaned] if cleaned else []
    out += [m.group(1).strip() for m in _QUOTED_RE.finditer(cleaned)]
    out += [m.group(1).strip() for m in _PAREN_RE.finditer(cleaned)]
    # Имя без юрформы в начале: «АО «Акме» (Acme)» → «Акме» уже даёт «…»-фрагмент.
    return [n for n in dict.fromkeys(out) if n]


def h1_alias_names(h1: str) -> list[str]:
    """Имена из H1 хаба, достойные стать ``aliases`` (HUB-ALIAS-1): фрагменты «…» и (…); нет
    фрагментов - заголовок целиком без юрформы и хвоста «— клиентский хаб». Целиком С юрформой
    («АО «Акме» (Acme)») алиасом не предлагается: ОПФ отдельно - шум.
    """
    names = _h1_names(h1)
    if not names:
        return []
    fragments = names[1:]
    if fragments:
        return list(dict.fromkeys(f for f in fragments if f))
    plain = _plain_name(names[0])
    return [plain] if plain else []


def _slug_name(note_id: str) -> str:
    """Слаг id без префикса сущности: ``client-umbrella`` → ``umbrella``."""
    return _PREFIX_RE.sub("", note_id).replace("-", " ").strip()


def _add_name(
    entry: HubEntry, seen: set[tuple[str, ...]], text: str, explicit: bool, source: str = "alias"
) -> None:
    keys = tuple(key_tokens(text))
    if not keys or keys in seen:
        return
    seen.add(keys)
    entry.names.append(HubName(text.strip(), keys, explicit, source))


def build_catalog(
    metas: list[NoteMeta], entities: tuple[str, ...] | None = CATALOG_ENTITIES
) -> list[HubEntry]:
    """Каталог хабов (``type: hub``, сущности :data:`CATALOG_ENTITIES`) из срезов заметок.

    ``entities=None`` - хабы любых сущностей (доктор, ``resolve``); по умолчанию - как для поиска.
    """
    catalog: list[HubEntry] = []
    for meta in metas:
        if meta.note_type != "hub" or not meta.entity:
            continue
        if entities is not None and meta.entity not in entities:
            continue
        entry = HubEntry(meta.id, meta.entity, path=meta.path, h1=meta.h1)
        seen: set[tuple[str, ...]] = set()
        for alias in meta.aliases:
            _add_name(entry, seen, alias, True, "alias")
        if meta.title:
            _add_name(entry, seen, meta.title, False, "title")
        for name in _h1_names(meta.h1):
            _add_name(entry, seen, name, False, "h1")
        _add_name(entry, seen, _slug_name(meta.id), False, "slug")
        catalog.append(entry)
    return catalog


def hub_catalog(
    vault_path: Path, entities: tuple[str, ...] | None = CATALOG_ENTITIES
) -> list[HubEntry]:
    """ЕДИНАЯ фабрика каталога имен хабов vault (HUB-ALIAS-1), порядок - по ``(сущность, id)``.

    Берет срезы из общего снимка frontmatter (:func:`core.retrieval.fm_cache.load_metas_cached`:
    обход путей + ``stat``, парсятся только изменившиеся файлы), поэтому правка алиаса/H1 хаба
    (по mtime/размеру) и запись с пульта видны следующему вызову без рестарта. Битые заметки
    пропускаются снимком (конверт деградации поиска; каталогу хаба без чтения нечего предложить).
    """
    from core.retrieval.fm_cache import load_metas_cached

    metas, _warnings = load_metas_cached(Path(vault_path))
    catalog = build_catalog(metas, entities)
    catalog.sort(key=lambda e: (e.entity, e.note_id))
    return catalog


def hub_entry(vault_path: Path, hub_id: str) -> HubEntry | None:
    """Запись каталога одного хаба (любой сущности) по id; ``None`` - такого хаба нет."""
    target = unicodedata.normalize("NFC", str(hub_id or "")).strip()
    for entry in hub_catalog(vault_path, None):
        if entry.note_id == target:
            return entry
    return None


def invalidate_hub_catalog(vault_path: Path, hub_paths: list[Path] | None = None) -> None:
    """Сбросить записи каталога (после записи алиасов с пульта): ``hub_paths`` - файлы хабов.

    Снимок и так сверяется со ``stat`` на каждый вызов; явный сброс - страховка от правки с тем же
    ``mtime_ns`` и размером. Без ``hub_paths`` забывается весь снимок vault (полный перечит).
    """
    from core.retrieval.fm_cache import forget

    vault = Path(vault_path)
    if hub_paths is None:
        forget(vault)
        return
    rels = []
    for p in hub_paths:
        try:
            rels.append(Path(p).resolve().relative_to(vault.resolve()).as_posix())
        except ValueError:
            rels.append(str(p))
    forget(vault, rels)


def _contains(seq: list[str], sub: tuple[str, ...]) -> bool:
    n = len(sub)
    if n == 0 or n > len(seq):
        return False
    return any(tuple(seq[i : i + n]) == sub for i in range(len(seq) - n + 1))


def match_hubs(
    query: str, catalog: list[HubEntry], *, h1_abbreviations: bool = False
) -> list[HubMatch]:
    """Хабы, чьи имена найдены в запросе (порядок каталога; один хаб — одно совпадение).

    ``h1_abbreviations=True`` (``parse_task``, HUB-ALIAS-1): короткая аббревиатура из H1
    («(ГЛБ)», «(АМБ)») тоже совпадает - как явный алиас, ТОЛЬКО целым словом и в том же регистре.
    Поиск (по умолчанию ``False``) эти имена по-прежнему не использует - ранжирование прежнее.
    """
    q_keys = key_tokens(query)
    if not q_keys:
        return []
    q_raw = {unicodedata.normalize("NFC", t) for t in tokens(query)}
    out: list[HubMatch] = []
    for entry in catalog:
        for name in entry.names:
            if len(name.keys) >= 2:
                hit = _contains(q_keys, name.keys)
            else:
                key = name.keys[0]
                if len(key) >= _MIN_TOKEN and len(fold_plain(name.text)) >= _MIN_TOKEN - 1:
                    hit = key in q_keys
                elif name.explicit or (h1_abbreviations and name.source == "h1"):
                    # короткая аббревиатура: только как отдельное слово запроса в том же регистре
                    hit = unicodedata.normalize("NFC", name.text.strip()) in q_raw
                else:
                    hit = False
            if hit:
                out.append(HubMatch(entry.note_id, entry.entity, name.text, name.explicit))
                break
    return out


_LEGAL_RE = re.compile(r"\b(?:ООО|АО|ПАО|ЗАО|ОАО|НПО|ГК|ТОО|LLC|JSC|Ltd)\b\.?", re.I)


def _plain_name(text: str) -> str:
    """Имя без кавычек и юрформы: ``ООО «Инитех Холдинг»`` → ``Инитех Холдинг``."""
    cleaned = re.sub(r"[«»\"“”]", " ", _LEGAL_RE.sub(" ", text))
    return " ".join(cleaned.split())


def canonical_terms(
    matches: list[HubMatch], catalog: list[HubEntry], *, limit: int = 2
) -> list[str]:
    """Канонические полные имена хабов для расширения FTS-запроса (OR) — только для аббревиатур.

    Короткий ярлык запроса («ИТХ», «ПАК-А») не встречается в теле документов, где живёт полное
    имя («Инитех Холдинг», «Цифровой двойник Завода-1»): его и добавляем. Если запрос уже
    назвал хаб полным именем («Акме», «Сойлент», «Хули»), расширение только зашумляет BM25
    (транслит, домены в подписях писем) и роняет ранг ожидаемой заметки — замер на золотом
    наборе, поэтому не расширяем. Берутся имена из нескольких слов без кавычек и юрформы, явные
    алиасы раньше производных, дубли по стем-ключам схлопываются; не более ``limit`` имён."""
    by_id = {e.note_id: e for e in catalog}
    terms: list[str] = []
    seen: set[tuple[str, ...]] = set()
    for match in matches:
        entry = by_id.get(match.note_id)
        if entry is None or not match.abbreviation:
            continue
        for name in sorted(entry.names, key=lambda n: not n.explicit):
            plain = _plain_name(name.text)
            keys = tuple(key_tokens(plain))
            if len(keys) < 2 or len(plain) < _MIN_TOKEN or keys in seen:
                continue
            seen.add(keys)
            terms.append(plain)
            if len(terms) >= limit:
                return terms
    return terms


_CAPITAL_RE = re.compile(r"(?<!\w)[А-ЯЁA-Z][\w-]{3,}")


def similar_hub_word(query: str, catalog: list[HubEntry]) -> str | None:
    """Слово запроса, похожее ПО ПРЕФИКСУ на имя хаба каталога, хотя хаб не нашелся (HUB-ALIAS-1).

    Подсказка для ``client_unresolved``: «Инитехбанк» в запросе, а у хаба ``client-initech`` имя
    «Инитех» - общий префикс из 4+ знаков, но целиком имя не совпало. Кандидат - слово с заглавной
    буквы и не короче 4 знаков (имена собственные, не проза); слово, ТОЧНО совпавшее с именем
    хаба, не подсказка (его нашел бы ``match_hubs``). ``None`` - похожего нет.
    """
    names: set[str] = set()
    for entry in catalog:
        for name in entry.names:
            for word in tokens(name.text):
                folded = fold_plain(word)
                if len(folded) >= _MIN_TOKEN:
                    names.add(folded)
    for match in _CAPITAL_RE.finditer(unicodedata.normalize("NFC", query or "")):
        word = match.group(0).strip("-")
        folded = fold_plain(word)
        if len(folded) < _MIN_TOKEN or folded in names:
            continue
        if any(n[:_MIN_TOKEN] == folded[:_MIN_TOKEN] for n in names):
            return word
    return None
