"""LanceDB index building (architecture §2, §5).

Builds the ``chunks`` table: markdown → chunks → BGE-M3 embeddings → LanceDB,
with flat metadata columns for pre-filtering and an FTS index for lexical search.
The store lives in ``<workspace_root>/.derived/lancedb/`` (derived, per-machine,
not versioned — see core.config).
"""

from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import logging
import os
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import lancedb
from lancedb.pydantic import LanceModel, Vector

from core import runlock
from core.chunking import Chunk, chunk_note, chunker_version, count_tokens
from core.config import index_lock_path, index_manifest_path, lancedb_path
from core.embeddings import EMBEDDING_DIM, Embedder, get_embedder
from core.privacy import is_nda
from core.progress import ProgressBeacon
from core.retrieval.fts_index import fts_options, write_fts_meta
from core.retrieval.index_report import build_report, write_report
from core.retrieval.lance_health import ensure_scalar_indexes, optimize_table
from core.vault import Note, iter_vault_paths, read_note

logger = logging.getLogger(__name__)

__all__ = [
    "ChunkRecord",
    "IndexBusyError",
    "IndexStats",
    "TEXT_HASH_COLUMN",
    "backfill_text_hash",
    "ChunkerVersionMismatch",
    "invalidate_stale_chunker",
    "index_chunker_mismatch",
    "open_chunks_table",
    "reindex",
    "rebuild_fts",
    "text_hash_coverage",
    "TABLE_NAME",
]


class IndexBusyError(RuntimeError):
    """Another (re)index run holds the index lock — the caller should skip
    softly (the scheduled incremental pass catches up next time) rather than
    write into a table a concurrent run is rebuilding."""

TABLE_NAME = "chunks"

# VEC-REUSE-1: sha256(text чанка) — ключ реюза вектора по СОДЕРЖИМОМУ (position-independent).
# Колонка и значения манифеста считаются одной функцией (:func:`_text_hash`), а бэкфилл
# старого индекса — тем же sha256 в SQL (``encode(sha256(text),'hex')``): байты те же.
TEXT_HASH_COLUMN = "text_hash"
_SQL_TEXT_HASH = "encode(sha256(text), 'hex')"
_BLANK_HASH = f"({TEXT_HASH_COLUMN} IS NULL OR {TEXT_HASH_COLUMN} = '')"

# Scalar metadata fields stored flat for filtering; list-valued fields handled
# separately (see _LIST_FIELDS). `genre`/`audience` drive retrieval-policy slices
# (e.g. style exemplars by genre/audience); `created`/`modified` enable
# recency sorting (sort: recency_desc) — see core/retrieval/policies.py.
# `source_type`/`era`/`section` are layer-B (legacy corpus) provenance/filter
# fields (Phase 5); `corpus`/`curated`/`source_path` are handled explicitly in
# _to_record (they carry non-empty defaults, unlike the generic ""-default here).
_SCALAR_FIELDS = (
    "type",
    "client",
    "project",
    "deal",
    "industry",
    "direction",
    "status",
    "genre",
    "audience",
    "created",
    "modified",
    "source_type",
    "era",
    "section",
)
_LIST_FIELDS = ("product", "tags")


class ChunkRecord(LanceModel):
    """LanceDB row schema for an indexed chunk."""

    vector: Vector(EMBEDDING_DIM)  # type: ignore[valid-type]
    text: str
    chunk_id: str
    note_id: str
    type: str
    # Layer discriminator (Phase 5): curated vault (layer A) vs ingested legacy
    # corpus (layer B). Old/curated notes default to corpus="vault", curated=True.
    corpus: str = "vault"
    curated: bool = True
    client: str
    project: str
    deal: str
    industry: str
    direction: str
    product: list[str]
    status: str
    genre: str
    audience: str
    created: str
    modified: str
    tags: list[str]
    heading_path: str
    chunk_index: int
    source_path: str
    # Layer-B provenance (Phase 5): original source type / era / first-level
    # section. Empty for curated vault notes.
    source_type: str = ""
    era: str = ""
    section: str = ""
    # VEC-REUSE-1: sha256 текста чанка (hex) — ключ глобального реюза вектора. Не входит в
    # meta-хэш (``_record_meta``): он производен от ``text``, а не метаданных, и его
    # появление не должно превращать каждый чанк в «изменились метаданные».
    text_hash: str = ""


@dataclass
class IndexStats:
    """Summary of a reindex run.

    ``notes``/``chunks`` are the totals in the vault / table after the run.
    ``new``/``changed``/``deleted``/``unchanged`` count notes by disposition vs
    the manifest; ``embedded_chunks`` is how many chunks were actually (re)embedded
    (0 when nothing changed). ``mode`` is ``"incremental"`` or ``"full"``.

    PERF-2 chunk-level transparency: ``meta_updated`` = chunks whose text was
    unchanged but metadata changed (column update, stored vector reused — no
    embed); ``chunks_skipped`` = chunks identical in text and metadata (row left
    untouched).
    """

    notes: int
    chunks: int
    elapsed_s: float
    db_path: str
    mode: str = "full"
    new: int = 0
    changed: int = 0
    deleted: int = 0
    unchanged: int = 0
    embedded_chunks: int = 0
    meta_updated: int = 0
    chunks_skipped: int = 0
    device: str = "unknown"
    # NIGHT-CHAIN-1: вектора считал демон (``daemon``) или эта копия модели (``local``/пусто)
    via: str = ""
    checkpoints: int = 0  # durable flushes performed during the run
    # NDA-2: заметки, отброшенные барьером по ``source_path`` (путь заметки чист,
    # источник — под NDA). Считаем вслух: «столько-то документов не индексируется»
    # обязано быть видно, а не проявляться пустой выдачей.
    nda_skipped: int = 0
    # PULT-EVENTLOG: note_ids затронутых заметок — заполняется ТОЛЬКО в
    # инкрементальном прогоне (полный reindex пишет одно run-событие, не N).
    dirty_note_ids: list[str] = field(default_factory=list)
    # WAVE0-HYGIENE п.1: отчёт гигиены LanceDB после прогона (optimize + замер каталога
    # до/после, канарейка); ``None`` — optimize не запускался (нет изменений не бывает:
    # он идёт после КАЖДОГО reindex) либо stats собран вне :func:`reindex`.
    lance: dict[str, Any] | None = None
    # WAVE0-HYGIENE п.2: id, повторно встреченные в прогоне (WARNING+пропуск, не затирание).
    id_collisions: dict[str, list[str]] = field(default_factory=dict)
    # WAVE0-HYGIENE п.7: почему эмбеддер ушёл на CPU ("" — не уходил).
    device_fallback: str = ""
    # WAVE1-MEASURE п.5: чанки/секунды по устройствам и OOM-повторы ЭТОГО прогона
    # (разность снимков ``Embedder.embed_stats``); пусто — эмбеддер без учёта.
    embed: dict[str, Any] = field(default_factory=dict)
    # VEC-REUSE-1: реюз вектора по содержимому (``embedded_chunks`` — реально заэмбедженные).
    # ``reused_same_note`` — вектор прежнего чанка той же заметки (сдвиг границ, вставка
    # абзаца), ``reused_cross_note`` — строка другой заметки с тем же ``text_hash``,
    # ``reused_in_run`` — тот же текст уже эмбеддился в этом прогоне. ``reuse_mode``:
    # ``on`` | ``full`` (полная пересборка: таблица не источник) | ``no_column`` (индекс до
    # VEC-REUSE-1 — нужен бэкфилл) | ``model_mismatch`` (модель индекса ≠ текущей).
    reused_same_note: int = 0
    reused_cross_note: int = 0
    reused_in_run: int = 0
    reuse_mode: str = "on"

    @property
    def reused_total(self) -> int:
        return self.reused_same_note + self.reused_cross_note + self.reused_in_run

    def reuse_summary(self) -> dict[str, Any]:
        """Реюз за прогон: счётчики, доля reused/(reused+embedded), режим."""
        total = self.reused_total + self.embedded_chunks
        return {
            "mode": self.reuse_mode,
            "reused_same_note": self.reused_same_note,
            "reused_cross_note": self.reused_cross_note,
            "reused_in_run": self.reused_in_run,
            "embedded": self.embedded_chunks,
            "share": round(self.reused_total / total, 4) if total else None,
        }

    def report(self, scope: str | None = None) -> dict[str, Any]:
        """Итог прогона для MCP/джоба: одна форма вместо двух копий словаря."""
        out: dict[str, Any] = {
            "mode": self.mode,
            "device": self.device,
            "new": self.new,
            "changed": self.changed,
            "deleted": self.deleted,
            "unchanged": self.unchanged,
            "embedded_chunks": self.embedded_chunks,
            "reuse": self.reuse_summary(),
            "notes": self.notes,
            "chunks": self.chunks,
            "elapsed_s": round(self.elapsed_s, 3),
            "db_path": self.db_path,
        }
        if scope is not None:
            out = {"scope": scope, **out}
        if self.device_fallback:
            out["device_fallback"] = self.device_fallback
        if self.via:
            out["via"] = self.via
        if self.id_collisions:
            out["id_collisions"] = len(self.id_collisions)
        if self.embed:
            out["embed"] = self.embed
        if self.lance is not None:
            out["lance"] = _lance_summary(self.lance)
        return out


def reuse_line(stats: IndexStats) -> str:
    """Строка лога шага reindex о реюзе векторов (VEC-REUSE-1 п.4)."""
    r = stats.reuse_summary()
    share = "—" if r["share"] is None else f"{r['share']:.0%}"
    return (
        f"[index] reuse [{r['mode']}]: same_note={r['reused_same_note']} "
        f"cross_note={r['reused_cross_note']} in_run={r['reused_in_run']} "
        f"embedded={r['embedded']} (реюз {share})"
    )


def embed_run_stats(
    before: dict[str, Any], after: dict[str, Any]
) -> dict[str, Any]:
    """Итог эмбеддинга за прогон: разность снимков ``embed_stats`` → доли и скорость.

    ``{chunks, mps_chunks, cpu_chunks, mps_share, chunks_per_s, oom_retries,
    oom_cpu_fallbacks, batch_size}``; пусто, если за прогон ничего не эмбеддилось или
    эмбеддер учёта не ведёт.
    """
    if not after:
        return {}
    by_dev_a = after.get("chunks_by_device") or {}
    by_dev_b = before.get("chunks_by_device") or {}
    sec_a = after.get("seconds_by_device") or {}
    sec_b = before.get("seconds_by_device") or {}
    chunks = {d: int(n) - int(by_dev_b.get(d, 0)) for d, n in by_dev_a.items()}
    chunks = {d: n for d, n in chunks.items() if n > 0}
    total = sum(chunks.values())
    if not total:
        return {}
    seconds = sum(float(sec_a.get(d, 0.0)) - float(sec_b.get(d, 0.0)) for d in chunks)
    return {
        "chunks": total,
        "mps_chunks": chunks.get("mps", 0),
        "cpu_chunks": chunks.get("cpu", 0),
        "mps_share": round(chunks.get("mps", 0) / total, 4),
        "chunks_per_s": round(total / seconds, 2) if seconds > 0 else None,
        "oom_retries": int(after.get("oom_retries", 0)) - int(before.get("oom_retries", 0)),
        "oom_cpu_fallbacks": int(after.get("oom_cpu_fallbacks", 0))
        - int(before.get("oom_cpu_fallbacks", 0)),
        "batch_size": after.get("batch_size"),
    }


def _lance_summary(report: dict[str, Any]) -> dict[str, Any]:
    """Плоский итог optimize для отчёта (канарейка: размер/версии до и после)."""
    before, after = report.get("before", {}), report.get("after", {})
    return {
        "ok": report.get("ok", False),
        "error": report.get("error", ""),
        "keep_h": report.get("keep_h"),
        "versions_before": before.get("versions"),
        "versions_after": after.get("versions"),
        "versions_gb_before": before.get("versions_gb"),
        "versions_gb_after": after.get("versions_gb"),
        "fragments_after": after.get("fragments"),
        "freed_gb": report.get("freed_gb"),
        "elapsed_s": report.get("elapsed_s"),
    }


def _scalar(value: Any) -> str:
    """Coerce a metadata value to a flat string (first item if it's a list)."""
    if value is None:
        return ""
    if isinstance(value, list):
        return str(value[0]) if value else ""
    return str(value)


def _string_list(value: Any) -> list[str]:
    """Coerce a metadata value to a list of strings."""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v) for v in value]
    return [str(value)]


def _bool(value: Any, *, default: bool) -> bool:
    """Coerce a metadata value to a bool (``default`` when absent).

    YAML frontmatter usually parses ``true``/``false`` to real bools, but a
    string ("false") or number may slip through — handle both so a stray
    ``curated: "false"`` still flips the flag.
    """
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in ("true", "1", "yes", "y", "on")
    return bool(value)


def _note_id(chunk: Chunk, note: Note) -> str:
    """Resolve the stable note id for a chunk (frontmatter ``id`` or file stem)."""
    return _scalar(chunk.metadata.get("id") or note.id)


def _chunk_id(note_id: str, chunk_index: int) -> str:
    """Deterministic chunk id (``<note_id>::<index>``) for idempotent delete/add."""
    return f"{note_id}::{chunk_index}"


def _record_meta(chunk: Chunk, note: Note) -> dict[str, Any]:
    """Every stored column EXCEPT ``vector`` and ``text`` — i.e. everything a
    metadata-only edit can change without touching the embedding.

    This is both what :func:`_chunk_meta_hash` fingerprints and what a
    metadata-only re-add writes, so the two can never drift apart (PERF-2).
    """
    md = chunk.metadata
    note_id = _note_id(chunk, note)
    meta: dict[str, Any] = {
        "chunk_id": _chunk_id(note_id, chunk.chunk_index),
        "note_id": note_id,
        "heading_path": " > ".join(chunk.heading_path),
        "chunk_index": chunk.chunk_index,
        # Layer B (Phase 5): a legacy note's frontmatter `source_path` points at
        # the original ingested file (pptx/pdf/…) for provenance; curated vault
        # notes have no such key and fall back to their own path (unchanged).
        "source_path": _scalar(md.get("source_path")) or str(note.path),
        "corpus": _scalar(md.get("corpus")) or "vault",
        "curated": _bool(md.get("curated"), default=True),
    }
    for field_name in _SCALAR_FIELDS:
        meta[field_name] = _scalar(md.get(field_name))
    for field_name in _LIST_FIELDS:
        meta[field_name] = _string_list(md.get(field_name))
    return meta


def _with_text_hash(row: dict[str, Any], chunk: Chunk, with_hash: bool) -> dict[str, Any]:
    """Добавить ``text_hash`` в строку, если в таблице есть такая колонка.

    Старый индекс (до VEC-REUSE-1) колонки не имеет, и ``table.add`` с лишним ключом
    упал бы — пишем без неё (честная деградация, см. :func:`_index_stream`)."""
    if with_hash:
        row[TEXT_HASH_COLUMN] = _chunk_text_hash(chunk)
    return row


def _to_record(
    chunk: Chunk, note: Note, vector: Any, *, with_hash: bool = False
) -> dict[str, Any]:
    """Full LanceDB row from a freshly embedded chunk (``vector`` is a ndarray)."""
    row = {"vector": vector.tolist(), "text": chunk.text, **_record_meta(chunk, note)}
    return _with_text_hash(row, chunk, with_hash)


def _record_reusing_vector(
    chunk: Chunk, note: Note, vector: list[float], *, with_hash: bool = False
) -> dict[str, Any]:
    """Full row for a reused vector (metadata-only change PERF-2, or content reuse
    VEC-REUSE-1): the chunk text equals the one the vector was computed from, so the
    embedding is valid. Writes exactly the same columns as :func:`_to_record`, so the
    row is byte-identical to a full rebuild's."""
    row = {"vector": list(vector), "text": chunk.text, **_record_meta(chunk, note)}
    return _with_text_hash(row, chunk, with_hash)


# --------------------------------------------------------------------------- #
# Manifest — note_id → {hash, chunks, indexed_at, mtime, size, path}           #
# INDEX-PERF-1: mtime/size/path are the fast-path fingerprint (path-keyed via a  #
# reverse index) — a stat-match skips read/parse/hash. Additive: old entries     #
# lack them and get re-hashed once, which fills them in for the next run.        #
# PERF-2: `chunks` is the per-chunk fingerprint list [{text_hash, meta_hash}],   #
# index-aligned by chunk_index — lets a changed note re-embed only the chunks    #
# whose text changed and column-update (reuse vector) the metadata-only ones.    #
# Additive: a pre-PERF-2 entry (no `chunks`) → one full re-embed backfills it.   #
# --------------------------------------------------------------------------- #


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def _note_source_path(note: Note) -> str:
    """Frontmatter ``source_path`` заметки как строка (``""``, если поля нет).

    CONTRACT-1 ФП-1: попадает в запись манифеста, чтобы единый резолвер ссылки
    (:func:`core.vault.note_path_for_source`) знал форму «строка source_path» за O(1),
    без сканов vault. У курированной заметки поля нет — пишем пустую строку (в отличие
    от индексной колонки, где пустое значение подменяется путём самой заметки: там это
    провенанс чанка, здесь — ключ обратной карты, и подмена сломала бы карту).
    """
    value = note.frontmatter.get("source_path")
    if isinstance(value, list):
        value = value[0] if value else ""
    return str(value).strip() if value else ""


def _note_hash(note: Note) -> str:
    """sha256 over frontmatter + body — changes iff chunks/metadata could change.

    Frontmatter is serialized canonically (sorted keys) so the hash is stable
    across runs and independent of dict ordering; the body is appended verbatim.
    """
    payload = json.dumps(
        note.frontmatter, sort_keys=True, ensure_ascii=False, default=str
    )
    h = hashlib.sha256()
    h.update(payload.encode("utf-8"))
    h.update(b"\0")
    h.update(note.body.encode("utf-8"))
    return h.hexdigest()


def _chunk_text_hash(chunk: Chunk) -> str:
    """sha256 of the chunk text — the embedding depends only on this (PERF-2).

    text_hash unchanged ⇒ the stored vector is still valid ⇒ no re-embed."""
    return hashlib.sha256(chunk.embed_text.encode("utf-8")).hexdigest()


def _chunk_meta_hash(chunk: Chunk, note: Note) -> str:
    """sha256 of the chunk's stored metadata columns (canonical, sorted keys).

    meta_hash changed but text_hash unchanged ⇒ a metadata-only edit ⇒ update the
    columns and reuse the vector (no re-embed)."""
    meta = _record_meta(chunk, note)
    if chunk.embed_text != chunk.text:
        # режим fts: префикс не входит в text_hash, но входит в колонку text — его смена
        # (переименовали документ) должна обновить строку, а не остаться «неизменной»
        meta["_context_prefix"] = chunk.context_prefix
    payload = json.dumps(meta, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


# A note is capped at _max_chunks_per_note() live rows; this is a safe upper bound
# for a single-note vector fetch (the where-filter returns only matching rows).
_NOTE_ROWS_LIMIT = 1_000_000


def _fetch_note_vectors(table: Any, note_id: str) -> dict[str, list[float]]:
    """``chunk_id → stored vector`` for a note's current rows (metadata-only reuse).

    A plain filtered scan (no query vector). Returns ``{}`` on any error or when
    the note has no rows yet (e.g. a crash mid-window left them deleted) — the
    caller then re-embeds those chunks, which is safe: embedding is deterministic,
    so it reproduces the very same vector."""
    try:
        rows = (
            table.search()
            .where(f"note_id = {_sql_quote(note_id)}")
            .limit(_NOTE_ROWS_LIMIT)
            .to_list()
        )
    except Exception:  # noqa: BLE001 — reuse is an optimization; fall back to embed
        return {}
    return {
        r["chunk_id"]: r["vector"]
        for r in rows
        if r.get("chunk_id") is not None and r.get("vector") is not None
    }


def _load_manifest(path: Path) -> dict[str, dict[str, Any]]:
    """Read the manifest, or ``{}`` if missing/malformed (rebuildable cache)."""
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        # Манифест — перестраиваемый кэш (таблица LanceDB — источник), поэтому «пусто» тут
        # безопасно, но ДОРОГО: все заметки будут пере-эмбеддены. Не молча (ADAPTER-HONEST-1).
        logger.warning("[index] манифест %s нечитаем (%s) — полная пересборка эмбеддингов",
                       path.name, type(exc).__name__)
        return {}
    if not isinstance(data, dict):
        logger.warning("[index] манифест %s: не словарь — полная пересборка", path.name)
        return {}
    return {str(k): v for k, v in data.items() if isinstance(v, dict)}


def _save_manifest(path: Path, manifest: dict[str, dict[str, Any]]) -> None:
    """Persist the manifest atomically (write-temp-then-replace)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    tmp.replace(path)


def _sql_quote(value: str) -> str:
    """Quote a string for a LanceDB SQL filter (single-quote, doubling escapes)."""
    return "'" + value.replace("'", "''") + "'"


_DELETE_BATCH = 500


def _delete_in(table: Any, column: str, values: list[str]) -> None:
    """Delete rows whose ``column`` is in ``values`` — one filter per batch.

    WAVE0-HYGIENE п.1 (аудит B2): по-чанковый ``table.delete`` в цикле коммитил версию на
    КАЖДЫЙ id (~0,7 с на 24 тыс. фрагментов без индекса — 55–60% времени инкремента).
    Батч ``IN (...)`` по колонке со скалярным индексом — одна версия на батч. Порядок и
    дубли значений не важны (idempotent), пустой список — no-op.
    """
    unique = list(dict.fromkeys(values))
    for at in range(0, len(unique), _DELETE_BATCH):
        chunk = unique[at : at + _DELETE_BATCH]
        table.delete(f"{column} IN ({', '.join(_sql_quote(v) for v in chunk)})")


def _build_secondary_indexes(table: Any) -> None:
    """(Re)build the FTS index and, past a safe row count, the vector ANN index.

    Native Lance FTS (``use_tantivy=False``) composes with prefiltering and
    hybrid search. The FTS index does not auto-cover rows added after it was
    built, so we rebuild it whenever the table content changed. A vector ANN
    index needs enough rows to train (IVF/PQ); below the threshold LanceDB does
    exact brute-force KNN, which is fine.
    """
    rows = table.count_rows()
    if rows == 0:
        return
    started = time.perf_counter()
    table.create_fts_index("text", **fts_options())
    write_fts_meta(rows=rows, elapsed_s=time.perf_counter() - started)
    if rows >= 256:
        table.create_index(metric="cosine", vector_column_name="vector")


def _embed_batch_size() -> int:
    """Texts per ``embed`` call — the memory guard against one giant ``encode``.

    A full reindex over a large vault must NOT embed every chunk in a single
    call: BGE-M3 pads to the longest sequence and allocates huge tensors (a live
    full rebuild stuck at ~14 GB RAM). Embedding in fixed-size batches caps peak
    memory to one batch regardless of corpus size, on CPU and MPS alike.
    Override with ``DT_INDEX_BATCH_SIZE`` (default 16; sane range 8–32).
    """
    raw = os.environ.get("DT_INDEX_BATCH_SIZE")
    if raw and raw.strip().isdigit():
        return max(1, int(raw.strip()))
    return 16


def _checkpoint_every() -> int:
    """Dirty notes per durable checkpoint (table write + manifest save).

    A multi-hour reindex must be **resumable**: rather than one final ``table.add``
    + manifest save (a crash/sleep loses the whole run), we flush in fixed-size
    batches so a killed run keeps every completed checkpoint and resumes from the
    rest. Override with ``DT_INDEX_CHECKPOINT_EVERY`` (default 50; min 1).

    PERF-1: this is now the *upper* cap in notes — the primary window trigger is
    the token budget (:func:`_window_token_budget`), because notes vary wildly in
    size (a mail thread ≠ a short curated note).
    """
    raw = os.environ.get("DT_INDEX_CHECKPOINT_EVERY")
    if raw and raw.strip().isdigit():
        return max(1, int(raw.strip()))
    return 50


# PERF-1: token budget of one streaming window (chunk texts buffered between
# checkpoints). The 12k-note mail run swapped 19 GB because the window was
# measured in NOTES — 50 mail threads ≈ thousands of long chunks in memory at
# once. ~50k tokens ≈ 50 typical notes worth of chunks, but a window collapses
# to a couple of notes when threads are huge. Peak memory = one window,
# independent of corpus size.
WINDOW_TOKEN_BUDGET = 50_000


def _window_token_budget() -> int:
    """Tokens per streaming window (:data:`WINDOW_TOKEN_BUDGET`).

    Override with ``DT_INDEX_WINDOW_TOKENS`` (min 1).
    """
    raw = os.environ.get("DT_INDEX_WINDOW_TOKENS")
    if raw and raw.strip().isdigit():
        return max(1, int(raw.strip()))
    return WINDOW_TOKEN_BUDGET


def _max_chunks_per_note() -> int:
    """Hard cap on chunks indexed from a SINGLE note (head kept, tail dropped).

    A few legacy notes are huge (converted xlsx dumps / event logs up to ~7 MB →
    thousands of chunks). One such note would block a whole checkpoint window
    (the flush waits for it to embed) and bloat the index with low-value rows. We
    keep the first N chunks — a note's head (preamble/start/structure) is usually
    representative — and drop the rest, logging a WARNING. Override with
    ``DT_INDEX_MAX_CHUNKS_PER_NOTE`` (default 120; min 1).
    """
    raw = os.environ.get("DT_INDEX_MAX_CHUNKS_PER_NOTE")
    if raw and raw.strip().isdigit():
        return max(1, int(raw.strip()))
    return 120


def _embed_watchdog_seconds() -> float:
    """Seconds after which a still-running checkpoint embed logs its window's
    note ids (diagnose a silent stall). ``0`` disables. Override with
    ``DT_INDEX_EMBED_WATCHDOG_SECONDS`` (default 180)."""
    raw = os.environ.get("DT_INDEX_EMBED_WATCHDOG_SECONDS")
    if raw and raw.strip():
        try:
            return max(0.0, float(raw.strip()))
        except ValueError:
            return 180.0
    return 180.0


def _count_notes(vault_path: Path) -> int:
    """Cheaply count indexable ``.md`` files (no frontmatter parse) for the ETA.

    Reuses :func:`core.vault.iter_vault_paths` (path-only, no parse) so the total
    matches exactly what the run will walk — including the NDA-1 exclusion, so the
    ETA does not count files the index will skip.
    """
    from core.vault import iter_vault_paths

    return sum(1 for _ in iter_vault_paths(vault_path))


def _format_dur(seconds: float) -> str:
    """Compact human duration: ``45s`` / ``12m`` / ``3h07m``."""
    seconds = max(0, int(seconds))
    if seconds < 90:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 90:
        return f"{minutes}m"
    return f"{minutes // 60}h{minutes % 60:02d}m"


def _progress_line(processed: int, total: int, embedded: int, start: float) -> str:
    """A single observable progress line (``tail -f``-friendly) with a rough ETA."""
    elapsed = time.perf_counter() - start
    where = f"{processed}/{total}" if total else f"{processed}"
    eta = ""
    if total and processed and elapsed > 0:
        rate = processed / elapsed
        if rate > 0:
            eta = f" | ~{_format_dur((total - processed) / rate)} eta"
    return (
        f"[index] {where} notes | {embedded} chunks | "
        f"{_format_dur(elapsed)} elapsed{eta}"
    )


# WAVE0-HYGIENE п.5: у хронологических заметок (почтовый тред) новое — в КОНЦЕ. Кап «голова
# остаётся» отрезал именно новейшие письма (фейлкейс 01.10; живой тред conv:74294: 32 из 39
# писем за капом). Для них кап считается с начала: остаётся ХВОСТ.
_CHRONOLOGICAL_SOURCE_TYPES = frozenset({"email-thread"})


# RETR-CHUNK-1 п.4: потолок чанков треда как кратное капа (кап считает сообщения).
_THREAD_CHUNK_CAP_FACTOR = 4


def _is_chronological(note: Note) -> bool:
    """Заметка с хронологическим порядком секций (новое — в конце): тред переписки."""
    fm = note.frontmatter
    return (
        str(fm.get("source_type") or "") in _CHRONOLOGICAL_SOURCE_TYPES
        or str(fm.get("type") or "") in _CHRONOLOGICAL_SOURCE_TYPES
    )


def _plan_note(
    note: Note, log: Callable[[str], None] | None = None
) -> tuple[list[tuple[Note, Chunk]], int, dict[str, Any] | None]:
    """Chunk a note → (``(note, chunk)`` pairs in chunk_index order, tokens, capped).

    No embedding here — the pairs feed the disposition/embedding pass. The token
    total (estimated, :func:`core.chunking.count_tokens`) sizes the streaming
    window (PERF-1) — notes vary too much for a note-count window.

    A note that yields more than :func:`_max_chunks_per_note` chunks is truncated
    and a WARNING is logged with the note id + original chunk count. By default the
    **head** stays (the tail of a monster xlsx dump is low-value); a chronological note
    (:func:`_is_chronological`, mail thread) keeps the **tail** — newest messages are
    the point (WAVE0-HYGIENE п.5). Kept chunks keep their original ``chunk_index``, so
    ``chunk_id`` stays deterministic: a sliding tail window only deletes the oldest kept
    chunk and embeds the new one. ``capped`` (``None`` — не капнута) →
    ``{total, kept, policy[, unit]}`` for the manifest/doctor.

    RETR-CHUNK-1 п.4: у почтового треда, разобранного по сообщениям, ``cap`` — число
    СООБЩЕНИЙ (``unit: "messages"``), а не чанков: чанк упаковывает несколько писем.
    """
    chunks = list(chunk_note(note))
    cap = _max_chunks_per_note()
    capped: dict[str, Any] | None = None
    messages_total = max((c.messages[1] for c in chunks if c.messages), default=0)
    if _is_chronological(note) and messages_total:
        # RETR-CHUNK-1 п.4: чанки треда упакованы по сообщениям, поэтому кап хвоста считает
        # СООБЩЕНИЯ (те же ``cap`` штук, что раньше чанков): остаются последние ``cap`` сообщений
        # с их чанками (+ футер «Связано»). Чанк, задетый окном частично, остаётся целиком.
        # Страховка от тредов из нескольких гигантских сообщений — потолок чанков 4×cap с хвоста.
        if messages_total > cap:
            floor = messages_total - cap
            kept = [c for c in chunks if c.messages is None or c.messages[1] > floor]
            message = (
                f"[index] WARNING: note {note.id!r} has {messages_total} messages; "
                f"capped to last {cap} (dropped {messages_total - cap}). "
                "Raise DT_INDEX_MAX_CHUNKS_PER_NOTE to keep more."
            )
            logger.warning(message)
            if log is not None:
                log(message)
            capped = {"total": messages_total, "kept": cap, "policy": "tail", "unit": "messages"}
            chunks = kept
        backstop = cap * _THREAD_CHUNK_CAP_FACTOR
        if len(chunks) > backstop:
            message = (
                f"[index] WARNING: note {note.id!r} produced {len(chunks)} chunks; "
                f"capped to last {backstop} (dropped {len(chunks) - backstop})."
            )
            logger.warning(message)
            if log is not None:
                log(message)
            capped = {"total": len(chunks), "kept": backstop, "policy": "tail", "unit": "chunks"}
            chunks = chunks[-backstop:]
    elif len(chunks) > cap:
        policy = "tail" if _is_chronological(note) else "head"
        dropped = len(chunks) - cap
        message = (
            f"[index] WARNING: note {note.id!r} produced {len(chunks)} chunks; "
            f"capped to {'last' if policy == 'tail' else 'first'} {cap} "
            f"(dropped {dropped}). Raise DT_INDEX_MAX_CHUNKS_PER_NOTE to keep more."
        )
        logger.warning(message)
        if log is not None:
            log(message)
        capped = {"total": len(chunks), "kept": cap, "policy": policy}
        chunks = chunks[-cap:] if policy == "tail" else chunks[:cap]

    pairs = [(note, chunk) for chunk in chunks]
    tokens = sum(count_tokens(chunk.text) for chunk in chunks)
    return pairs, tokens, capped


def _chunk_base(entry: dict[str, Any] | None) -> int:
    """``chunk_index`` первого чанка в ``chunks`` записи манифеста (0, если ключа нет)."""
    if not entry:
        return 0
    try:
        return max(0, int(entry.get("chunk_base", 0)))
    except (TypeError, ValueError):
        return 0


def _fastpath_note_id(
    by_path: dict[str, tuple[str, dict[str, Any]]],
    rel: str,
    mode: str,
    mtime: float | None,
    size: int | None,
) -> str | None:
    """note_id записи манифеста, которую можно пропустить без чтения (INDEX-PERF-1).

    Fast-path только для инкремента: запись по этому пути с совпавшими mtime И size
    → файл байт-идентичен, читать/парсить/хешировать нечего. Вернувшийся id кладут в
    ``seen``, чтобы цикл удаления не снял его чанки. ``mode == "full"`` fast-path'а не
    знает (полный прогон перечитывает всё — на то он и полный).
    """
    if mode == "full" or mtime is None:
        return None
    hit = by_path.get(rel)
    if hit is None:
        return None
    entry = hit[1]
    if entry.get("mtime") != mtime or entry.get("size") != size:
        return None
    return hit[0]


def open_chunks_table(db_path: Path | None = None) -> Any | None:
    """Открыть таблицу чанков на чтение/удаление; ``None`` — её нет или не открыть.

    Единственная точка коннекта к LanceDB вне самого индексатора: sweep NDA-следов
    (:mod:`core.nda_purge`) должен уметь снять чанки, но заводить ради этого второй
    ``import lancedb`` (и второе знание об имени таблицы) — верный способ разъехаться.
    Молчаливый ``None`` вместо исключения: у вызывающего есть другие поверхности,
    отсутствие индекса не повод падать.
    """
    from core.config import lancedb_path

    path = db_path or lancedb_path()
    if not path.exists():
        return None
    try:
        db = lancedb.connect(str(path))
        if TABLE_NAME not in db.table_names():
            return None
        return db.open_table(TABLE_NAME)
    except Exception:  # noqa: BLE001 — нет индекса/битая таблица = «нечего снимать»
        return None


def _refresh_fingerprint(
    prev: dict[str, Any],
    rel: str,
    mtime: float | None,
    size: int | None,
    note_source: str,
) -> bool:
    """Обновить отпечаток неизменившейся записи манифеста. ``True`` — если тронули.

    Содержимое то же, но отпечаток «поехал» (или его нет — старая запись, файл
    тронули без правки): освежаем на месте, чтобы СЛЕДУЮЩИЙ прогон попал в
    fast-path. Пере-эмбеддинга нет, чанки стоят. CONTRACT-1 ФП-1: сюда же
    досыпается ``source_path`` старым записям (заметка уже прочитана — бесплатно).
    """
    if (
        prev.get("mtime") == mtime
        and prev.get("size") == size
        and prev.get("path") == rel
        and prev.get("source_path", "") == note_source
    ):
        return False
    prev["mtime"] = mtime
    prev["size"] = size
    prev["path"] = rel
    prev["source_path"] = note_source
    return True


@dataclass
class _ChunkDisposition:
    """Что делать с чанками заметки (PERF-2 / VEC-REUSE-1): embed / запись с готовым вектором /
    delete. ``meta_records`` — строки, пишущиеся БЕЗ эмбеддинга (вектор взят из таблицы:
    metadata-only правка, реюз по содержимому из той же заметки или из другой)."""

    embed_pairs: list[tuple[Note, Chunk]] = field(default_factory=list)
    meta_records: list[dict[str, Any]] = field(default_factory=list)
    delete_chunk_ids: list[str] = field(default_factory=list)
    meta_updated: int = 0
    skipped: int = 0
    reused_same_note: int = 0  # вектор прежнего чанка ЭТОЙ заметки (в т.ч. при сдвиге границ)
    reused_cross_note: int = 0  # вектор строки другой заметки с тем же text_hash


def _fetch_vector_by_hash(table: Any, text_hash: str) -> tuple[str, list[float]] | None:
    """``(note_id, vector)`` любой строки таблицы с этим ``text_hash`` или ``None``.

    Один фильтрованный запрос по BTREE-индексу колонки, ``limit 1`` (VEC-REUSE-1 п.2).
    Любой сбой (нет колонки в старой таблице, битый индекс) → ``None``: реюз — оптимизация,
    безопасный фолбэк — заэмбеддить."""
    try:
        rows = (
            table.search()
            .where(f"{TEXT_HASH_COLUMN} = {_sql_quote(text_hash)}")
            .select(["note_id", "vector"])
            .limit(1)
            .to_list()
        )
    except Exception:  # noqa: BLE001
        return None
    if not rows or rows[0].get("vector") is None:
        return None
    return str(rows[0].get("note_id") or ""), rows[0]["vector"]


def _dispose_chunks(
    table: Any,
    nid: str,
    note: Note,
    note_pairs: list[tuple[Note, Chunk]],
    new_fps: list[dict[str, str]],
    prev: dict[str, Any] | None,
    *,
    with_hash: bool = False,
    reuse: bool = False,
) -> _ChunkDisposition:
    """Chunk-level diff of a note against its manifest entry (``prev`` — ``None`` для новой).

    Порядок решения для каждого нового чанка:

    1. Позиционный быстрый путь (PERF-2): на том же ``chunk_index`` стоит чанк с тем же
       ``text_hash`` → метаданные те же (``skipped``, строка не трогается) или изменились
       только они (``meta_updated``, вектор той же строки).
    2. **Реюз по содержимому** (VEC-REUSE-1; только при ``reuse``): сначала среди прежних
       чанков ТОЙ ЖЕ заметки — словарь ``text_hash → chunk_index`` из манифеста, без запроса
       (сдвиг границ/вставка абзаца больше не ломает выравнивание); затем глобально по
       колонке ``text_hash`` таблицы (``_fetch_vector_by_hash``). Нашли — строка пишется с
       готовым вектором, эмбеддер не зовётся.
    3. Иначе — embed.

    ``prev["chunks"]`` выровнен по ``chunk_index`` от ``chunk_base`` (0, если заметка не
    tail-капнута, :func:`_plan_note`). ``reuse=False`` (старый индекс без колонки / модель
    индекса ≠ текущей) оставляет только п.1 — прежнее позиционное поведение.
    """
    prev_chunks: list[Any] = list((prev or {}).get("chunks") or [])
    prev_base = _chunk_base(prev)
    out = _ChunkDisposition()

    def stored_at(chunk_index: int) -> dict[str, Any] | None:
        j = chunk_index - prev_base
        return prev_chunks[j] if 0 <= j < len(prev_chunks) else None

    # text_hash → chunk_index прежнего чанка этой заметки (первый при дублях).
    prev_by_hash: dict[str, int] = {}
    for j, st in enumerate(prev_chunks):
        h = st.get("text_hash") if isinstance(st, dict) else None
        if h:
            prev_by_hash.setdefault(h, prev_base + j)

    def positional_same_text(chunk: Chunk, fp: dict[str, str]) -> dict[str, Any] | None:
        st = stored_at(chunk.chunk_index)
        return st if st is not None and fp["text_hash"] == st.get("text_hash") else None

    needs_note_vectors = False
    for (_, c), fp in zip(note_pairs, new_fps, strict=True):
        st = positional_same_text(c, fp)
        if st is not None:
            needs_note_vectors |= fp["meta_hash"] != st.get("meta_hash")
        elif reuse and fp["text_hash"] in prev_by_hash:
            needs_note_vectors = True
    existing_vecs = _fetch_note_vectors(table, nid) if needs_note_vectors else {}

    for (_, chunk), fp in zip(note_pairs, new_fps, strict=True):
        cid = _chunk_id(nid, chunk.chunk_index)
        st = positional_same_text(chunk, fp)
        if st is not None:
            if fp["meta_hash"] == st.get("meta_hash"):
                out.skipped += 1  # identical text + metadata → row stands
                continue
            # Metadata-only (e.g. corpus retag): reuse the stored vector, rewrite the
            # columns — no embed. Fall back to embed if the row is missing (crash
            # window) — same vector, deterministic.
            vec = existing_vecs.get(cid)
            out.delete_chunk_ids.append(cid)
            if vec is None:
                out.embed_pairs.append((note, chunk))
            else:
                out.meta_records.append(
                    _record_reusing_vector(chunk, note, vec, with_hash=with_hash)
                )
                out.meta_updated += 1
            continue
        # New index (append) or this chunk's text changed / moved.
        out.delete_chunk_ids.append(cid)
        vec = None
        same_note = False
        if reuse:
            old_index = prev_by_hash.get(fp["text_hash"])
            if old_index is not None:
                vec = existing_vecs.get(_chunk_id(nid, old_index))
                same_note = vec is not None
            if vec is None:
                hit = _fetch_vector_by_hash(table, fp["text_hash"])
                if hit is not None:
                    vec = hit[1]
                    same_note = hit[0] == nid
        if vec is None:
            out.embed_pairs.append((note, chunk))
            continue
        out.meta_records.append(_record_reusing_vector(chunk, note, vec, with_hash=with_hash))
        if same_note:
            out.reused_same_note += 1
        else:
            out.reused_cross_note += 1
    # Chunks that existed before but are gone now (truncation / sliding tail) → delete.
    live_indices = {chunk.chunk_index for _, chunk in note_pairs}
    for i in range(prev_base, prev_base + len(prev_chunks)):
        if i not in live_indices:
            out.delete_chunk_ids.append(_chunk_id(nid, i))
    return out


# VEC-REUSE-1 п.3: потолок словаря «text_hash → вектор» на прогон (float32 ≈ 4 КБ/вектор →
# ~80 МБ). Старейшие вытесняются; вытесненное по-прежнему находится в таблице по text_hash.
_RUN_VECTORS_MAX = 20_000


def _embed_and_add(
    table: Any,
    embedder: Embedder,
    pairs: list[tuple[Note, Chunk]],
    run_vectors: dict[str, Any],
    with_hash: bool,
) -> tuple[int, int]:
    """Заэмбеддить и дописать чанки окна: ``(заэмбеддено, взято готовым из прогона)``.

    PERF-1: по одному под-батчу (:func:`_embed_batch_size`), записи под-батча не копятся
    дальше него. VEC-REUSE-1 п.3: текст с уже виденным в прогоне ``text_hash`` (в этом
    под-батче или раньше — ``run_vectors``) эмбеддится один раз, остальные берут вектор из
    словаря (потолок :data:`_RUN_VECTORS_MAX`, вытесненное ищется в таблице по text_hash)."""
    batch_size = _embed_batch_size()
    embedded = reused = 0
    for at in range(0, len(pairs), batch_size):
        sub = pairs[at : at + batch_size]
        hashes = [_chunk_text_hash(chunk) for _, chunk in sub]
        fresh: dict[str, str] = {}  # text_hash → текст, которого ещё нет в прогоне
        for (_, chunk), h in zip(sub, hashes, strict=True):
            if h not in run_vectors:
                fresh.setdefault(h, chunk.embed_text)
        if fresh:
            for h, vector in zip(fresh, embedder.embed(list(fresh.values())), strict=True):
                run_vectors[h] = vector
        vectors = [run_vectors[h] for h in hashes]  # читаем ДО возможного вытеснения
        while len(run_vectors) > _RUN_VECTORS_MAX:
            del run_vectors[next(iter(run_vectors))]
        records = [
            _to_record(chunk, note, vector, with_hash=with_hash)
            for (note, chunk), vector in zip(sub, vectors, strict=True)
        ]
        if records:
            table.add(records)
        embedded += len(fresh)
        reused += len(sub) - len(fresh)
        del records, vectors, sub  # освободить до следующего под-батча
    return embedded, reused


def _reuse_mode(
    mode: str, with_hash: bool, embedder: Embedder, log: Callable[[str], None]
) -> str:
    """Режим реюза векторов по содержимому для этого прогона (VEC-REUSE-1 п.5).

    ``full`` — полная пересборка «чистая» (таблица не источник векторов); ``no_column`` —
    индекс до VEC-REUSE-1 (честная деградация к позиционному PERF-2 + громкий WARNING);
    ``model_mismatch`` — модель индекса ≠ текущей (вектор чужой модели реюзать нельзя);
    иначе ``on``."""
    if mode == "full":
        return "full"
    if not with_hash:
        log(
            "[index] WARNING: в таблице нет колонки text_hash — реюз векторов по содержимому "
            "ВЫКЛЮЧЕН (остаётся позиционный PERF-2); разово: dt_index.py --backfill-text-hash"
        )
        return "no_column"
    mismatch = index_model_mismatch(embedder)
    if mismatch:
        log(
            f"[index] WARNING: индекс построен другой моделью ({mismatch}) — реюз векторов по "
            "содержимому ВЫКЛЮЧЕН; нужна полная пересборка: dt_index.py --full"
        )
        return "model_mismatch"
    return "on"


def _index_stream(
    vault_path: Path,
    embedder: Embedder,
    table: Any,
    manifest: dict[str, dict[str, Any]],
    *,
    mode: str,
    start: float,
    log: Callable[[str], None],
) -> IndexStats:
    """Walk the vault and durably (re)index dirty notes in streamed windows.

    Shared by full and incremental runs (they differ only in setup: full starts
    from an empty table + empty manifest, incremental from the existing ones).

    Durability/resumability contract:

    * Dirty notes (new/changed) are buffered into a **window sized by tokens**
      (:func:`_window_token_budget`; :func:`_checkpoint_every` notes stays as the
      upper cap) and flushed window by window. Each flush is ``delete-before-add``
      at the granularity the disposition chose — a wholesale delete-by-note for a
      new note / full rebuild, or targeted delete-by-chunk_id for a changed note's
      re-embedded / metadata-updated / removed chunks (a no-op delete clears any
      rows left by a crashed prior flush, so re-adding can't duplicate). Then the
      metadata-only rows are re-added with their reused vectors, the dirty chunks
      are embedded+``table.add``ed **per sub-batch** (:func:`_embed_batch_size`
      texts at a time — records are never accumulated for the whole window, let
      alone the run), and the manifest is saved with *only* the just-written
      notes. PERF-1: peak memory = one window, independent of corpus size; the
      embedder's accelerator cache is released after every window
      (:meth:`core.embeddings.Embedder.release_cache`).
    * Because the manifest is saved **after** the adds, a crash leaves the
      manifest reflecting only durably-written notes; the in-flight window is
      simply reprocessed on the next run (its partial rows cleaned by the
      delete-before-add).
    * ``KeyboardInterrupt`` (incl. SIGTERM, mapped by the CLI) flushes the current
      window if it is safe to do so, logs, and re-raises — prior checkpoints are
      already durable.

    Progress is logged once per window (``tail -f``-friendly).
    """
    embed_before = dict(getattr(embedder, "embed_stats", {}) or {})
    # VEC-REUSE-1: у старого индекса колонки text_hash нет — строки пишем без неё.
    with_hash = _table_has_text_hash(table)
    reuse_mode = _reuse_mode(mode, with_hash, embedder, log)
    reuse = reuse_mode == "on"
    run_vectors: dict[str, Any] = {}  # п.3: text_hash → вектор, заэмбедженный в этом прогоне
    reused_same_note = reused_cross_note = reused_in_run = 0
    manifest_path = index_manifest_path()
    checkpoint_every = _checkpoint_every()
    token_budget = _window_token_budget()
    total = _count_notes(vault_path)

    # ACT-1: маяк для pult_activity — счётчики и фаза, без имён заметок.
    beacon = ProgressBeacon("index", total, emit=log)
    beacon.phase(mode)

    new = changed = unchanged = embedded = note_count = checkpoints = 0
    nda_skipped = 0  # NDA-2: отброшено барьером по source_path заметки
    meta_updated = chunks_skipped = 0  # PERF-2 chunk-level transparency
    table_dirty = False  # did any flush mutate the table? (drives secondary rebuild)
    # PULT-EVENTLOG: собираем note_id затронутых заметок ТОЛЬКО в инкрементальном
    # прогоне (полный reindex не раздувает лог — одно run-событие в reindex()).
    dirty_ids: list[str] = []
    # PERF-2 window buffers — targeted per-chunk ops instead of per-note delete-all:
    buf_pairs: list[tuple[Note, Chunk]] = []          # chunks to embed + add
    buf_meta_records: list[dict[str, Any]] = []       # metadata-only rows (vector reused)
    buf_delete_note_ids: list[str] = []               # wholesale (new note / full mode)
    buf_delete_chunk_ids: list[str] = []              # targeted (re-embed / meta / removed)
    buf_manifest: dict[str, dict[str, Any]] = {}
    pending_dirty = 0
    window_tokens = 0
    seen: set[str] = set()
    # WAVE0-HYGIENE п.2: кто владеет id в этом прогоне (id → vault-путь) и коллизии.
    owners: dict[str, str] = {}
    collisions: dict[str, list[str]] = {}

    def _record_collision(nid: str, owner_rel: str, rel: str) -> None:
        paths = collisions.setdefault(nid, [owner_rel])
        if rel not in paths:
            paths.append(rel)
            message = (
                f"[index] WARNING: note_id {nid!r} уже занят {owner_rel}; "
                f"{rel} ПРОПУЩЕН (дубль id — задай уникальный frontmatter id)"
            )
            logger.warning(message)
            log(message)

    flushing = False  # guards against a re-entrant flush from the interrupt path
    # INDEX-PERF-1: was the manifest mutated in place for unchanged notes only
    # (mtime/size refresh, no re-embed)? Such runs never flush, so we persist the
    # manifest once at the end when this is set.
    manifest_meta_dirty = False

    # INDEX-PERF-1: reverse index vault-relative-path → (note_id, entry) so the
    # fast-path can stat-match a file WITHOUT parsing it to learn its note id
    # (the id may live in frontmatter). Built once from the manifest we diff
    # against; entries without a stored ``path`` (pre-PERF-1) simply miss and get
    # read once (which then records their fingerprint).
    by_path: dict[str, tuple[str, dict[str, Any]]] = {}
    for _pid, _entry in manifest.items():
        _rel = _entry.get("path")
        if isinstance(_rel, str):
            by_path[_rel] = (_pid, _entry)

    def flush() -> None:
        nonlocal embedded, checkpoints, flushing, pending_dirty, window_tokens
        nonlocal table_dirty, reused_in_run
        if not (
            buf_pairs
            or buf_meta_records
            or buf_delete_note_ids
            or buf_delete_chunk_ids
            or buf_manifest
        ):
            return
        flushing = True
        # Watchdog: if this window's embedding outlasts the threshold, log which
        # notes are in flight (diagnoses a silent stall without blocking the run).
        timer: threading.Timer | None = None
        watchdog_s = _embed_watchdog_seconds()
        window_ids = list(buf_manifest.keys())
        if watchdog_s > 0 and window_ids:
            timer = threading.Timer(
                watchdog_s,
                lambda: log(
                    f"[index] WATCHDOG: checkpoint embed still running after "
                    f"{watchdog_s:.0f}s — notes in window: {', '.join(window_ids)}"
                ),
            )
            timer.daemon = True
            timer.start()
        # delete-before-add → idempotent across resumes. Wholesale (new note / full
        # mode) drops the whole note in one filter; targeted drops just the chunk
        # ids being re-embedded / metadata-updated / removed. A no-op delete on a
        # chunk_id with no row clears any leftover from a crashed prior flush.
        if buf_delete_note_ids or buf_delete_chunk_ids or buf_meta_records or buf_pairs:
            table_dirty = True
        _delete_in(table, "note_id", buf_delete_note_ids)
        _delete_in(table, "chunk_id", buf_delete_chunk_ids)
        # Metadata-only rows: re-add with their preserved vectors (no embed). Byte-
        # identical columns to a full rebuild's — only the metadata differs from the
        # deleted row.
        if buf_meta_records:
            table.add(buf_meta_records)
        # Stream the dirty chunks (PERF-1: one sub-batch at a time; VEC-REUSE-1 п.3: equal
        # texts are embedded once per run).
        try:
            written, dup = _embed_and_add(table, embedder, buf_pairs, run_vectors, with_hash)
            reused_in_run += dup
        finally:
            if timer is not None:
                timer.cancel()
        manifest.update(buf_manifest)  # only NOW are these notes "indexed"
        _save_manifest(manifest_path, manifest)
        embedded += written
        checkpoints += 1
        buf_pairs.clear()
        buf_meta_records.clear()
        buf_delete_note_ids.clear()
        buf_delete_chunk_ids.clear()
        buf_manifest.clear()
        pending_dirty = 0
        window_tokens = 0
        embedder.release_cache()  # PERF-1: MPS-кэш не растёт между окнами
        flushing = False

    try:
        # INDEX-PERF-1: walk PATHS (no parse). stat each file; an unchanged one
        # (same mtime+size as its manifest fingerprint) is skipped without being
        # read/parsed/hashed — the cold legacy archive costs one stat per file.
        for path in iter_vault_paths(vault_path):
            note_count += 1
            rel = path.relative_to(vault_path).as_posix()
            try:
                st = path.stat()
                fp_mtime: float | None = st.st_mtime
                fp_size: int | None = st.st_size
            except OSError:
                fp_mtime = fp_size = None

            fast_id = _fastpath_note_id(by_path, rel, mode, fp_mtime, fp_size)
            if fast_id is not None:
                if fast_id in owners:
                    _record_collision(fast_id, owners[fast_id], rel)
                    continue
                owners[fast_id] = rel
                seen.add(fast_id)
                unchanged += 1
                continue

            note = read_note(path, vault_path)
            nid = note.id
            note_source = _note_source_path(note)
            # NDA-2: барьер по ОБОИМ путям заметки. Обход vault отбрасывает NDA по
            # пути файла, но легаси-слуг маркер теряет (``About_EC_НМ_NDA.pptx`` →
            # ``about-ec-nm-nda-….md``), и такая заметка индексировалась — найдено
            # sweep'ом на живом индексе. ``seen`` НЕ помечаем: цикл удаления снимет
            # её прежние чанки, а новых мы не планируем.
            if is_nda(note_source):
                nda_skipped += 1
                continue
            # WAVE0-HYGIENE п.2: id уникален в прогоне. Второй файл с тем же id —
            # WARNING + пропуск, а НЕ затирание чанков первого (так 129 выходов жили
            # как 3 id, и каждую ночь переэмбеддились впустую).
            if nid in owners:
                _record_collision(nid, owners[nid], rel)
                continue
            owners[nid] = rel
            seen.add(nid)
            digest = _note_hash(note)
            prev = manifest.get(nid)
            if prev is not None and prev.get("hash") == digest:
                unchanged += 1
                if _refresh_fingerprint(prev, rel, fp_mtime, fp_size, note_source):
                    manifest_meta_dirty = True
                continue

            # Note-level: (re)plan the note. new_fps is the per-chunk fingerprint
            # (index-aligned by chunk_index), stored in the manifest so the NEXT
            # run can diff chunk by chunk (PERF-2).
            note_pairs, note_tokens, capped = _plan_note(note, log=log)
            new_fps = [
                {"text_hash": _chunk_text_hash(c), "meta_hash": _chunk_meta_hash(c, note)}
                for _, c in note_pairs
            ]
            # п.5: tail-кап оставляет чанки с исходными индексами base..base+N-1;
            # ``chunks`` манифеста выровнен по base (``chunk_base``; нет ключа → 0).
            new_base = note_pairs[0][1].chunk_index if note_pairs else 0
            if prev is not None:
                changed += 1
            else:
                new += 1
            if mode == "incremental":
                dirty_ids.append(nid)

            prev_chunks = prev.get("chunks") if prev is not None else None
            if mode == "full" or prev is None or not isinstance(prev_chunks, list):
                # Full (re)embed of the whole note: no per-chunk baseline to diff
                # against (new note, mode=full, or a pre-PERF-2 entry without
                # ``chunks`` → embed once, which backfills the fingerprints). One
                # wholesale delete-by-note, then embed every chunk.
                buf_delete_note_ids.append(nid)
                if reuse:
                    # VEC-REUSE-1: новая заметка / запись до PERF-2 — вектор для чанка с
                    # уже известным text_hash берём из таблицы, эмбеддим только новое.
                    # Удаление note_id целиком уже стоит в буфере (delete_chunk_ids не нужны).
                    disp = _dispose_chunks(
                        table, nid, note, note_pairs, new_fps, None,
                        with_hash=with_hash, reuse=True,
                    )
                    buf_pairs.extend(disp.embed_pairs)
                    buf_meta_records.extend(disp.meta_records)
                    reused_same_note += disp.reused_same_note
                    reused_cross_note += disp.reused_cross_note
                else:
                    buf_pairs.extend(note_pairs)
            else:
                # Chunk-level disposition of a changed note, aligned by chunk_index.
                disp = _dispose_chunks(
                    table, nid, note, note_pairs, new_fps, prev,
                    with_hash=with_hash, reuse=reuse,
                )
                reused_same_note += disp.reused_same_note
                reused_cross_note += disp.reused_cross_note
                buf_pairs.extend(disp.embed_pairs)
                buf_meta_records.extend(disp.meta_records)
                buf_delete_chunk_ids.extend(disp.delete_chunk_ids)
                meta_updated += disp.meta_updated
                chunks_skipped += disp.skipped

            buf_manifest[nid] = {
                "hash": digest,
                "chunks": new_fps,
                "indexed_at": _now_iso(),
                "mtime": fp_mtime,
                "size": fp_size,
                "path": rel,
                # RETR-CHUNK-1 п.9/12: какой чанкер писал запись — ``--rechunk`` берёт только
                # записи с другой версией, поэтому прерванная перепланировка возобновляема
                "chunker": chunker_version(),
                # CONTRACT-1 ФП-1: ``source_path`` заметки в манифесте — обратная карта
                # «ссылка-source_path → заметка» для единого резолвера
                # (`core.vault.note_path_for_source`). Пусто у курированных заметок.
                "source_path": note_source,
            }
            if new_base:
                buf_manifest[nid]["chunk_base"] = new_base
            if capped is not None:
                buf_manifest[nid]["capped"] = capped
            pending_dirty += 1
            window_tokens += note_tokens
            # PERF-1: окно закрывается по токенам (первично) или по числу заметок
            # (верхняя крышка) — почтовый тред ≠ короткая заметка.
            if window_tokens >= token_budget or pending_dirty >= checkpoint_every:
                flush()
                beacon.update(
                    note_count,
                    {"chunks": embedded, "checkpoints": checkpoints},
                    line=_progress_line(note_count, total, embedded, start),
                )

        flush()  # last partial window

        # Notes that vanished from the vault: drop their chunks + manifest entries.
        deleted = 0
        gone = [n for n in manifest if n not in seen]
        _delete_in(table, "note_id", gone)
        for nid in gone:
            del manifest[nid]
            deleted += 1
        if gone:
            table_dirty = True
        # Persist when anything on disk changed: dropped entries (gone) OR an
        # in-place fingerprint refresh on unchanged notes (INDEX-PERF-1). A flush
        # (dirty notes) already saved the whole manifest — this covers the pure-
        # unchanged run that never flushed. No-op for a steady-state run with no
        # drift (manifest_meta_dirty stays False → no write, no read).
        if gone or manifest_meta_dirty:
            _save_manifest(manifest_path, manifest)
    except KeyboardInterrupt:
        # Persist the in-flight window unless we were interrupted mid-flush (then
        # the partial write is cleaned by delete-before-add on the next run).
        if not flushing:
            try:
                flush()
            except Exception:  # noqa: BLE001, S110 — best effort; prior checkpoints hold
                pass
        log(
            f"[index] interrupted at {note_count} notes "
            f"({embedded} chunks embedded, {checkpoints} checkpoints saved) — "
            "re-run to resume."
        )
        raise

    # Rebuild FTS/ANN once at the end. PERF-2: a metadata-only run re-adds rows
    # (delete+add with the reused vector) without embedding, so trigger on any
    # table mutation, not just embeds/deletes — else the secondary indexes could
    # miss re-added rows.
    if table_dirty:
        _build_secondary_indexes(table)

    stats = IndexStats(
        notes=note_count,
        chunks=table.count_rows(),
        elapsed_s=time.perf_counter() - start,
        db_path=str(lancedb_path()),
        mode=mode,
        new=new,
        changed=changed,
        deleted=deleted,
        unchanged=unchanged,
        embedded_chunks=embedded,
        reused_same_note=reused_same_note,
        reused_cross_note=reused_cross_note,
        reused_in_run=reused_in_run,
        reuse_mode=reuse_mode,
        meta_updated=meta_updated,
        chunks_skipped=chunks_skipped,
        device=getattr(embedder, "device", "unknown"),
        via=str(getattr(embedder, "via", "") or ""),
        checkpoints=checkpoints,
        dirty_note_ids=dirty_ids,
        nda_skipped=nda_skipped,
        id_collisions=collisions,
        device_fallback=getattr(embedder, "fallback_reason", "") or "",
        embed=embed_run_stats(embed_before, dict(getattr(embedder, "embed_stats", {}) or {})),
    )
    # Прерывание (KeyboardInterrupt выше) сюда не доходит — маяк остаётся без
    # finished, и pult_activity честно покажет interrupted (resume чекпойнтами).
    beacon.update(
        note_count,
        {"chunks": embedded, "checkpoints": checkpoints},
        line=_progress_line(note_count, total, embedded, start) + " | done",
    )
    beacon.done(f"{mode}: {note_count} notes, {embedded} chunks embedded")
    log(reuse_line(stats))
    return stats


# --------------------------------------------------------------------------- #
# Метка модели индекса — ``index_meta.json`` рядом с манифестом (VEC-REUSE-1 п.5).   #
# Манифест — плоская карта note_id → запись, его обходят vault/nda_purge, поэтому      #
# общий ключ в него не кладём: отдельный крошечный файл (не кэш векторов).            #
# --------------------------------------------------------------------------- #


def index_meta_path() -> Path:
    """``.derived/index_meta.json`` (рядом с манифестом → тест-изоляция по тем же env)."""
    return index_manifest_path().with_name("index_meta.json")


def read_index_meta() -> dict[str, Any]:
    """Метка индекса (``{embed_model, …}``); нет файла/битый → ``{}`` (индекс «до метки»)."""
    try:
        data = json.loads(index_meta_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def write_index_meta(model_id: str, *, how: str, chunker: str | None = None) -> None:
    """Записать метку модели атомарно. ``how`` — ``build`` (полная пересборка) | ``adopt``.

    ``chunker`` (RETR-CHUNK-1 п.9) — версия чанкера, которым построен индекс; пишется при
    ``build``. При ``adopt`` (метки не было) прежняя версия сохраняется, а её отсутствие
    читается как «v0» — чанкер до RETR-CHUNK-1."""
    path = index_meta_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload: dict[str, Any] = {
        "embed_model": model_id, "embed_dim": EMBEDDING_DIM, "set_by": how, "set_at": _now_iso(),
    }
    chunker = chunker or read_index_meta().get("chunker_version")
    if chunker:
        payload["chunker_version"] = str(chunker)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(path)


class ChunkerVersionMismatch(IndexBusyError):
    """Индекс построен другим чанкером, чем текущий код: инкремент дал бы смешанный индекс.

    Подкласс :class:`IndexBusyError` намеренно: все плановые вызовы (``dt_index``/``dt_sync``
    ``reindex_inc``, ingest) уже мягко пропускают такой отказ (WARNING, код 0), а ``--full``
    лечит и ставит новую версию."""


def index_chunker_mismatch() -> str:
    """``""`` — версия чанкера индекса = коду; иначе ``«индекс ≠ код»`` (нет метки = ``v0``).

    Источник правды и для guard'а :func:`reindex`, и для doctor. Нет индекса вовсе — ``""``."""
    from core.chunking import LEGACY_CHUNKER_VERSION, chunker_version

    stored = str(read_index_meta().get("chunker_version") or LEGACY_CHUNKER_VERSION)
    current = chunker_version()
    return f"{stored} ≠ {current}" if stored != current else ""


def embedder_model_id(embedder: Embedder | None = None) -> str:
    """Идентификатор модели эмбеддера (у фейков без свойства — модель по умолчанию)."""
    from core.embeddings import MODEL_NAME

    return str(getattr(embedder, "model_id", "") or MODEL_NAME)


def _adopt_index_model(model_id: str) -> None:
    """Индекс «до метки» (файла нет) — принять текущую модель как родную, один раз.

    До VEC-REUSE-1 единственной поддержанной моделью была BGE-M3 (размерность колонки
    ``vector`` зашита в схему), поэтому «нет метки» ⇒ «индекс от текущей модели»."""
    if not read_index_meta().get("embed_model"):
        write_index_meta(model_id, how="adopt")


def index_model_mismatch(embedder: Embedder | None = None) -> str:
    """``""`` — модель индекса совпадает с текущей (или метки нет); иначе строка с обеими.

    Источник правды и для guard'а реюза (:func:`reindex`), и для doctor."""
    stored = str(read_index_meta().get("embed_model") or "")
    current = embedder_model_id(embedder)
    return f"{stored} ≠ {current}" if stored and stored != current else ""


@contextlib.contextmanager
def _index_lock(mode: str) -> Any:
    """Эксклюзивный ``index.lock`` для разовых операций (rebuild FTS, бэкфилл).

    Тот же flock, что у :func:`reindex`: параллельный прогон → :class:`IndexBusyError`.
    Регистрирует heartbeat (``runlock``), чтобы сторож/doctor видели операцию."""
    lock_path = index_lock_path()
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    lock_fh = open(lock_path, "a+")
    registered = False
    try:
        try:
            fcntl.flock(lock_fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise IndexBusyError(
                f"другой (re)index уже идёт — lock занят: {lock_path}"
            ) from None
        runlock.register(lock_path, mode=mode)
        registered = True
        yield
    finally:
        if registered:
            runlock.unregister(lock_path)
        with contextlib.suppress(Exception):
            fcntl.flock(lock_fh.fileno(), fcntl.LOCK_UN)
        lock_fh.close()


def _table_has_text_hash(table: Any) -> bool:
    """Есть ли в таблице колонка ``text_hash`` (старый индекс — нет)."""
    try:
        return TEXT_HASH_COLUMN in table.schema.names
    except Exception:  # noqa: BLE001 — не смогли прочитать схему = считаем, что колонки нет
        return False


def text_hash_coverage(table: Any) -> dict[str, Any]:
    """Покрытие колонки ``text_hash``: ``{column, rows, filled}`` (``filled`` — непустых).

    Для doctor и бэкфилла: без колонки ``filled == 0``. Фильтр читает одну колонку."""
    rows = table.count_rows()
    if not _table_has_text_hash(table):
        return {"column": False, "rows": rows, "filled": 0}
    blank = table.count_rows(_BLANK_HASH)
    return {"column": True, "rows": rows, "filled": rows - blank}


_BACKFILL_NOTES = 500  # заметок на один update (одна версия LanceDB на пачку)


def _blank_hash_notes(table: Any, rows: int) -> dict[str, int]:
    """``note_id → число строк с пустым text_hash`` (читает только колонку note_id)."""
    arrow = (
        table.search().where(_BLANK_HASH).select(["note_id"]).limit(max(rows, 1)).to_arrow()
    )
    counts: dict[str, int] = {}
    for nid in arrow.column("note_id").to_pylist():
        counts[nid] = counts.get(nid, 0) + 1
    return counts


def backfill_text_hash(
    *, log: Callable[[str], None] | None = None, batch_notes: int = _BACKFILL_NOTES
) -> dict[str, Any]:
    """Заполнить ``text_hash`` в существующей таблице БЕЗ переэмбеддинга (VEC-REUSE-1 п.1).

    Хэш считается из колонки ``text`` самим LanceDB (``encode(sha256(text),'hex')`` —
    байт-в-байт тот же sha256, что :func:`_chunk_text_hash`); эмбеддер не нужен и не грузится.
    Нет колонки → один ``add_columns`` (записывается только новая колонка, векторы не
    переписываются). Колонка есть, но часть строк пуста (оборванный прогон) → ``update``
    пачками по ``batch_notes`` заметок, прогресс в маяк. **Идемпотентно**: заполненные строки
    не трогаются, повторный запуск на полном индексе — no-op. Затем BTREE-индекс на колонку,
    метка модели индекса (``index_meta``), optimize. Под ``index.lock``: параллельный
    reindex → :class:`IndexBusyError`. Нет таблицы → ``FileNotFoundError``.

    Возвращает ``{rows, column_added, filled_before, filled, remaining, elapsed_s}``.
    """
    with _index_lock("index-backfill"):
        log = log or (lambda msg: print(msg, file=sys.stderr, flush=True))
        db = lancedb.connect(str(lancedb_path()))
        if TABLE_NAME not in db.table_names():
            raise FileNotFoundError(f"нет таблицы {TABLE_NAME!r} в {lancedb_path()}")
        table = db.open_table(TABLE_NAME)
        rows = table.count_rows()
        before = text_hash_coverage(table)
        beacon = ProgressBeacon("index-backfill", rows, emit=log)
        started = time.perf_counter()
        column_added = False
        if not before["column"]:
            beacon.phase("add-column")
            log(f"[index] backfill text_hash: колонки нет, считаю sha256 для {rows} строк …")
            table.add_columns({TEXT_HASH_COLUMN: _SQL_TEXT_HASH})
            column_added = True
            beacon.update(
                rows, {}, line=f"[index] backfill text_hash: {rows}/{rows} (колонка добавлена)"
            )
        else:
            beacon.phase("fill-blank")
            todo = _blank_hash_notes(table, rows)
            todo_rows = sum(todo.values())
            log(f"[index] backfill text_hash: пустых строк {todo_rows} в {len(todo)} заметках")
            done_rows = before["filled"]
            ids = list(todo)
            for at in range(0, len(ids), max(1, batch_notes)):
                group = ids[at : at + max(1, batch_notes)]
                where = f"{_BLANK_HASH} AND note_id IN ({', '.join(_sql_quote(n) for n in group)})"
                table.update(where=where, values_sql={TEXT_HASH_COLUMN: _SQL_TEXT_HASH})
                done_rows += sum(todo[n] for n in group)
                beacon.update(
                    done_rows, {},
                    line=f"[index] backfill text_hash: {done_rows}/{rows}",
                )
        after = text_hash_coverage(table)
        ensure_scalar_indexes(table)
        _adopt_index_model(embedder_model_id())
        optimize_table(table, db_path=lancedb_path())
        elapsed = time.perf_counter() - started
        out = {
            "rows": rows,
            "column_added": column_added,
            "filled_before": before["filled"],
            "filled": after["filled"],
            "remaining": after["rows"] - after["filled"],
            "elapsed_s": round(elapsed, 1),
        }
        beacon.done(f"backfill text_hash: {after['filled']}/{rows} in {elapsed:.0f}s")
        return out


def rebuild_fts(*, log: Callable[[str], None] | None = None) -> dict[str, Any]:
    """Пересобрать ТОЛЬКО полнотекстовый индекс (без переэмбеддинга) — RETR-RANK-1 п.3.

    Нужен, когда меняются настройки FTS (язык/стеммер): векторы и данные таблицы не
    трогаются, обновляется лишь индекс ``text`` (~минуты на сотнях тысяч чанков). Под тем же
    ``index.lock``, что и reindex: параллельный прогон → :class:`IndexBusyError`. Прогресс —
    в маяк ``.derived/status/index-fts.json`` и в ``log`` (по умолчанию stderr). Возвращает
    ``{rows, language, elapsed_s}``. Нет таблицы → ``FileNotFoundError`` (перестраивать нечего).
    """
    with _index_lock("index-fts"):
        log = log or (lambda msg: print(msg, file=sys.stderr, flush=True))
        db = lancedb.connect(str(lancedb_path()))
        if TABLE_NAME not in db.table_names():
            raise FileNotFoundError(f"нет таблицы {TABLE_NAME!r} в {lancedb_path()}")
        table = db.open_table(TABLE_NAME)
        rows = table.count_rows()
        beacon = ProgressBeacon("index-fts", rows, emit=log)
        beacon.phase("fts-rebuild")
        log(f"[index] FTS rebuild: {rows} строк, language={fts_options()['language']} …")
        started = time.perf_counter()
        table.create_fts_index("text", **fts_options())
        elapsed = time.perf_counter() - started
        write_fts_meta(rows=rows, elapsed_s=elapsed)
        beacon.update(rows, {}, line=f"[index] FTS rebuild done in {elapsed:.0f}s")
        beacon.done(f"fts-rebuild: {rows} rows in {elapsed:.0f}s")
        return {"rows": rows, "language": fts_options()["language"], "elapsed_s": round(elapsed, 1)}


def _emit_index_events(stats: IndexStats) -> None:
    """PULT-EVENTLOG for a reindex run (best-effort inside the emitter).

    Полный reindex → **одно** run-событие (не по-заметочно: полный проход всего
    vault не должен родить 10k событий). Инкрементальный → по одному ``index``-
    событию на затронутую (new/changed) заметку (по ``note_id``), одной пачкой с
    общим ``run_id``. ``detail`` — только счётчики/режим, без тела.
    """
    from core.eventlog import emit, emit_batch, new_run_id

    run_id = new_run_id()
    if stats.mode == "full":
        emit(
            "index",
            "done",
            run_id=run_id,
            detail={
                "mode": "full", "notes": stats.notes, "chunks": stats.chunks,
                "new": stats.new, "changed": stats.changed, "deleted": stats.deleted,
                "embedded_chunks": stats.embedded_chunks, "device": stats.device,
            },
        )
        return
    emit_batch(
        [
            {
                "stage": "index", "status": "done", "note_id": nid,
                "run_id": run_id,
                "detail": {"mode": "incremental", "device": stats.device},
            }
            for nid in stats.dirty_note_ids
        ]
    )


def invalidate_stale_chunker(manifest: dict[str, dict[str, Any]]) -> list[str]:
    """Сбросить отпечатки записей, написанных ДРУГИМ чанкером (RETR-CHUNK-1 п.12, ``--rechunk``).

    Запись без ключа ``chunker`` — прежняя нарезка. Сброс ``hash``/``mtime``/``size`` заставляет
    следующий проход перечитать и перепланировать заметку; чанки с тем же текстом (по
    ``text_hash``) не эмбеддятся. Меняет только переданный словарь; на диск — чекпойнтами."""
    version = chunker_version()
    stale = [nid for nid, e in manifest.items()
             if isinstance(e, dict) and e.get("chunker") != version]
    for nid in stale:
        manifest[nid]["hash"] = ""
        manifest[nid]["mtime"] = None
        manifest[nid]["size"] = None
    return stale


def invalidate_capped(
    manifest: dict[str, dict[str, Any]], *, limit: int | None = None
) -> list[str]:
    """Пометить капнутые заметки на перепланирование (WAVE0-HYGIENE п.5, бэкфилл флага).

    Капнутая = число чанков в записи достигло кап-порога, а ключа ``capped`` ещё нет
    (запись писалась до п.5). У такой записи обнуляются отпечатки (``hash``/``mtime``/
    ``size``) — следующий проход заметку перечитает и перепланирует: у почтового треда
    кап теперь с хвоста (реальная работа), у остальных чанки совпадут побайтно
    (``chunks_skipped``, без эмбеддинга) и лишь проставится ``capped``. Порядок —
    почтовые треды первыми (канарейка «1 тред → все»), ``limit`` ограничивает число.
    Меняет только переданный словарь в памяти; на диск уйдёт обычным чекпойнтом.
    """
    cap = _max_chunks_per_note()
    candidates = [
        nid for nid, entry in manifest.items()
        if isinstance(entry, dict) and "capped" not in entry
        and len(entry.get("chunks") or []) >= cap
    ]
    candidates.sort(
        key=lambda nid: (not str(manifest[nid].get("path", "")).startswith(
            "_legacy/correspondence/"), nid)
    )
    chosen = candidates if limit is None else candidates[: max(0, limit)]
    for nid in chosen:
        entry = manifest[nid]
        entry["hash"] = ""
        entry["mtime"] = None
        entry["size"] = None
    return chosen


def reindex(
    vault_path: Path,
    *,
    full: bool = False,
    embedder: Embedder | None = None,
    log: Callable[[str], None] | None = None,
    replan_capped: bool = False,
    replan_limit: int | None = None,
    rechunk: bool = False,
) -> IndexStats:
    """(Re)build the LanceDB ``chunks`` table from a vault — durable + resumable.

    Single-writer: the whole run holds a non-blocking ``flock`` on
    :func:`core.config.index_lock_path`; when another (re)index already holds it,
    :class:`IndexBusyError` is raised immediately (callers skip softly — the
    scheduled incremental pass catches up on its next run).

    Incremental by default, at two levels. Note-level (INDEX-PERF-1): walks note
    *paths* and stat-compares each against the ``.derived/index_manifest.json``
    fingerprint (path+mtime+size) — an unchanged file is skipped without being
    read/parsed/hashed. Chunk-level (PERF-2): a changed note re-embeds only the
    chunks whose *text* changed; a chunk whose text is unchanged but whose metadata
    changed (e.g. a corpus retag) is column-updated with its **stored vector reused
    (no embed)**; identical chunks are left untouched; appended chunks are embedded
    and removed ones deleted. ``full=True`` ignores both fast-paths and re-embeds
    every chunk (clean rebuild). Table content is byte-identical to a full rebuild.

    Writes are **checkpointed**: chunks + manifest are persisted every
    :func:`_checkpoint_every` dirty notes rather than once at the end, so a long
    run survives sleep/kill/crash and resumes — already-written notes are skipped
    as unchanged next time. ``log`` (default ``print``) receives one progress line
    per checkpoint.

    ``full=True`` drops + recreates the table and rebuilds the manifest (needed
    when the schema/model/chunker changes); it is checkpointed too, so an
    interrupted full run is itself resumable via a follow-up incremental call.
    With no existing table *or* no manifest, an incremental call falls back to a
    full first pass automatically.
    """
    lock_path = index_lock_path()
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    # ADAPTER-HONEST-1 п.5: ``a+`` (не усекаем содержимое lock'а живого держателя) +
    # регистрация heartbeat'а — сторож снимает прогон без прогресса, doctor его видит.
    lock_fh = open(lock_path, "a+")
    registered_lock = False
    try:
        try:
            fcntl.flock(lock_fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise IndexBusyError(
                f"другой (re)index уже идёт — lock занят: {lock_path}"
            ) from None
        runlock.register(lock_path, mode="index-full" if full else "index")
        registered_lock = True

        start = time.perf_counter()
        embedder = embedder or get_embedder()
        # ACT-1 / хвост PERF-1: прогресс виден живьём и под пайпом launchd (flush).
        # RETR-LEGACY FIX-3: дефолт пишет в **stderr**, не stdout — иначе прогресс
        # `[index] N` летит в JSON-RPC-канал, когда `reindex` гоняется в процессе
        # MCP-сервера, и роняет клиента («Unexpected token 'i', "[index] 606"»).
        # CLI-прогресс по-прежнему виден (stderr); вызывающий может передать свой log.
        log = log or (lambda msg: print(msg, file=sys.stderr, flush=True))
        vault_path = Path(vault_path)
        manifest_path = index_manifest_path()

        db = lancedb.connect(str(lancedb_path()))
        table_exists = TABLE_NAME in db.table_names()
        manifest_exists = manifest_path.is_file()
        # No table or no manifest → nothing to diff against → full first pass.
        do_full = full or not table_exists or not manifest_exists

        if do_full:
            if table_exists:
                db.drop_table(TABLE_NAME)
            table = db.create_table(TABLE_NAME, schema=ChunkRecord)
            # VEC-REUSE-1 п.5 + RETR-CHUNK-1 п.9: метка модели и версии чанкера ставится в НАЧАЛЕ
            # полной пересборки — оборванный прогон дальше возобновляется обычным инкрементом
            write_index_meta(embedder_model_id(embedder), how="build", chunker=chunker_version())
            # Clear the on-disk manifest up front so an interrupt before the first
            # checkpoint can't leave a stale manifest pointing at the dropped table.
            manifest: dict[str, dict[str, Any]] = {}
            _save_manifest(manifest_path, manifest)
            mode = "full"
        else:
            mismatch = index_chunker_mismatch()
            if (
                mismatch
                and not rechunk
                and os.environ.get("DT_INDEX_ALLOW_CHUNKER_MISMATCH", "") != "1"
            ):
                raise ChunkerVersionMismatch(
                    f"версия чанкера индекса ≠ кода ({mismatch}): инкремент дал бы смешанный "
                    "индекс — нужна полная пересборка dt_index.py --full "
                    "(осознанный обход: DT_INDEX_ALLOW_CHUNKER_MISMATCH=1)"
                )
            table = db.open_table(TABLE_NAME)
            manifest = _load_manifest(manifest_path)
            mode = "incremental"
            _adopt_index_model(embedder_model_id(embedder))  # VEC-REUSE-1 п.5: индекс «до метки»
            # WAVE0-HYGIENE п.1: BTREE на chunk_id/note_id ДО первых delete — фильтр
            # перестаёт сканировать все фрагменты (идемпотентно, best-effort).
            ensure_scalar_indexes(table)
            if rechunk:
                stale = invalidate_stale_chunker(manifest)
                log(f"[index] rechunk: {len(stale)} заметок на перечанкование "
                    f"(версия чанкера {chunker_version()})")
            if replan_capped:
                marked = invalidate_capped(manifest, limit=replan_limit)
                log(f"[index] replan capped: {len(marked)} заметок на перепланирование")

        stats = _index_stream(
            vault_path, embedder, table, manifest, mode=mode, start=start, log=log
        )
        # WAVE0-HYGIENE п.1: гигиена LanceDB после КАЖДОГО reindex (инкремент и full):
        # скалярные индексы (после full таблица только что создана), затем optimize с
        # cleanup версий старше DT_LANCE_KEEP_H и замером каталога до/после. Под
        # index-lock'ом — конкурентной записи нет. Сбой не роняет прогон (данные записаны).
        if do_full:
            ensure_scalar_indexes(table)
        stats.lance = optimize_table(table, db_path=lancedb_path())
        # RETR-RANK-1 п.6: кэш frontmatter для скана find_notes обновляется шагом reindex —
        # ПЕРВЫЙ поиск после индексации уже не платит полным обходом vault. Best-effort.
        try:
            from core.retrieval.fm_cache import refresh as _refresh_fm_cache

            _refresh_fm_cache(vault_path)
        except Exception as exc:  # noqa: BLE001 — кэш перестраиваем на первом поиске
            logger.warning("[index] кэш frontmatter не обновлён (%s)", exc)
        if rechunk and not do_full:
            done = all(e.get("chunker") == chunker_version() for e in manifest.values())
            if done:  # метка версии — только когда перечанкованы ВСЕ заметки (иначе гард держит)
                write_index_meta(embedder_model_id(embedder), how="rechunk",
                                 chunker=chunker_version())
            log("[index] rechunk: " + ("завершён, версия чанкера проставлена" if done
                                       else "НЕ завершён — повтори dt_index.py --rechunk"))
        write_report(build_report(stats, manifest))
        _emit_index_events(stats)
        return stats
    finally:
        if registered_lock:
            runlock.unregister(lock_path)
        with contextlib.suppress(Exception):
            fcntl.flock(lock_fh.fileno(), fcntl.LOCK_UN)
        lock_fh.close()
