"""WAVE0-HYGIENE — отчёт последнего reindex для doctor (``.derived/index_report.json``).

Индексатор видит во время прогона то, чего doctor без повторного обхода 17 тыс. файлов не
узнает: коллизии ``note_id`` (п.2), капнутые заметки (п.5), устройство эмбеддера и причину
фолбэка MPS→CPU (п.7), итог гигиены LanceDB (п.1). Пишется атомарно в конце КАЖДОГО
завершённого прогона (прерванный прогон отчёта не оставляет — прежний остаётся).
Best-effort: сбой записи — WARNING, индексацию не роняет.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = ["build_report", "read_report", "write_report"]


def _capped_summary(manifest: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Капнутые заметки по манифесту: всего, по политикам, топ-10 по потерянным чанкам."""
    rows = [
        (nid, entry["capped"])
        for nid, entry in manifest.items()
        if isinstance(entry, dict) and isinstance(entry.get("capped"), dict)
    ]
    by_policy: dict[str, int] = {}
    for _nid, cap in rows:
        policy = str(cap.get("policy") or "head")
        by_policy[policy] = by_policy.get(policy, 0) + 1
    rows.sort(key=lambda r: int(r[1].get("total", 0)) - int(r[1].get("kept", 0)), reverse=True)
    return {
        "count": len(rows),
        "by_policy": by_policy,
        "top": [
            {"note_id": nid, "total": cap.get("total"), "kept": cap.get("kept"),
             "policy": cap.get("policy", "head"), "unit": cap.get("unit", "chunks")}
            for nid, cap in rows[:10]
        ],
    }


def build_report(stats: Any, manifest: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Отчёт из итогов прогона (:class:`core.retrieval.index.IndexStats`) и манифеста."""
    lance = stats.lance or {}
    return {
        "ts": datetime.now(UTC).isoformat(timespec="seconds"),
        "mode": stats.mode,
        "device": stats.device,
        "device_fallback": stats.device_fallback,
        "notes": stats.notes,
        "chunks": stats.chunks,
        "embedded_chunks": stats.embedded_chunks,
        # VEC-REUSE-1 п.4: реюз векторов по содержимому (режим, счётчики, доля).
        "reuse": stats.reuse_summary() if hasattr(stats, "reuse_summary") else {},
        "embed": dict(getattr(stats, "embed", {}) or {}),
        "id_collisions": {nid: list(paths) for nid, paths in stats.id_collisions.items()},
        "capped": _capped_summary(manifest),
        "lance": {
            "ok": lance.get("ok"),
            "error": lance.get("error", ""),
            "versions_after": (lance.get("after") or {}).get("versions"),
            "versions_gb_after": (lance.get("after") or {}).get("versions_gb"),
            "freed_gb": lance.get("freed_gb"),
        },
    }


def write_report(report: dict[str, Any], path: Path | None = None) -> None:
    """Атомарная запись (tmp → replace); сбой — WARNING."""
    if path is None:
        from core.config import index_report_path

        path = index_report_path()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, path)
    except OSError as exc:
        logger.warning("[index] отчёт %s не записан: %s", path, exc)


def read_report(path: Path | None = None) -> dict[str, Any] | None:
    """Отчёт последнего прогона; нет файла/битый → ``None`` (doctor скажет «не было»)."""
    if path is None:
        from core.config import index_report_path

        path = index_report_path()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None
