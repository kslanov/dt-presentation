"""WAVE0-HYGIENE п.1 — гигиена LanceDB: optimize после reindex, скалярные индексы,
замер здоровья каталога (аудит B1/B2).

Каждая запись в таблицу (delete/add) коммитит новую версию-манифест; без очистки
``_versions`` рос на ~100 ГБ/мес (252 ГБ при 3,2 ГБ данных). Здесь три вещи:

* :func:`optimize_table` — ``table.optimize(cleanup_older_than=…)`` с замером размера
  каталога до/после (канарейка в отчёт reindex);
* :func:`ensure_scalar_indexes` — BTREE на ``chunk_id``/``note_id``/``text_hash``: delete по фильтру
  перестаёт сканировать десятки тысяч фрагментов;
* :func:`lance_health` — дешёвый (без открытия таблицы) замер каталога для doctor и
  плитки «Хранилище»: версий / фрагментов / ГБ + пороги.

Всё best-effort на стороне reindex: сбой гигиены логируется WARNING и попадает в
отчёт, но не роняет индексацию (данные уже записаны).
"""

from __future__ import annotations

import logging
import os
import time
from datetime import timedelta
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "KEEP_HOURS_DEFAULT",
    "SCALAR_INDEX_COLUMNS",
    "ensure_scalar_indexes",
    "keep_hours",
    "lance_health",
    "lance_health_verdict",
    "optimize_table",
    "warn_thresholds",
]

KEEP_HOURS_DEFAULT = 24.0
WARN_VERSIONS_DEFAULT = 500
WARN_VERSIONS_GB_DEFAULT = 5.0
# По этим колонкам идут delete по фильтру (index.py) — на них нужен скалярный индекс;
# ``text_hash`` (VEC-REUSE-1) — поиск готового вектора по содержимому. Колонки, которых нет
# в схеме (старый индекс до бэкфилла), пропускаются.
SCALAR_INDEX_COLUMNS = ("chunk_id", "note_id", "text_hash")

_GB = 1024**3


def keep_hours() -> float:
    """Сколько часов версий хранить (``DT_LANCE_KEEP_H``, дефолт 24; мусор → дефолт)."""
    raw = (os.environ.get("DT_LANCE_KEEP_H") or "").strip()
    try:
        value = float(raw)
    except ValueError:
        return KEEP_HOURS_DEFAULT
    return value if value >= 0 else KEEP_HOURS_DEFAULT


def warn_thresholds() -> tuple[int, float]:
    """(версий, ГБ ``_versions``), выше которых doctor светит warn.

    Env: ``DT_LANCE_WARN_VERSIONS`` (500), ``DT_LANCE_WARN_VERSIONS_GB`` (5).
    """
    try:
        versions = int((os.environ.get("DT_LANCE_WARN_VERSIONS") or "").strip())
    except ValueError:
        versions = WARN_VERSIONS_DEFAULT
    try:
        gigabytes = float((os.environ.get("DT_LANCE_WARN_VERSIONS_GB") or "").strip())
    except ValueError:
        gigabytes = WARN_VERSIONS_GB_DEFAULT
    return (versions if versions > 0 else WARN_VERSIONS_DEFAULT,
            gigabytes if gigabytes > 0 else WARN_VERSIONS_GB_DEFAULT)


def _dir_stats(path: Path) -> tuple[int, int]:
    """(файлов, байт) каталога одним scandir без рекурсии (``_versions`` плоский)."""
    files = size = 0
    try:
        with os.scandir(path) as it:
            for entry in it:
                try:
                    if entry.is_file(follow_symlinks=False):
                        files += 1
                        size += entry.stat(follow_symlinks=False).st_size
                except OSError:
                    continue
    except OSError:
        return 0, 0
    return files, size


def _tree_stats(path: Path) -> tuple[int, int]:
    """(файлов, байт) каталога с вложенными (``_indices`` — каталог на индекс)."""
    files = size = 0
    for root, _dirs, names in os.walk(path):
        for name in names:
            try:
                size += os.stat(os.path.join(root, name)).st_size
                files += 1
            except OSError:
                continue
    return files, size


def lance_health(db_path: Path | None = None, table_name: str = "chunks") -> dict[str, Any]:
    """Замер каталога таблицы БЕЗ открытия LanceDB (scandir; секунды даже на 160 тыс. файлов).

    Ключи: ``exists``, ``versions`` (файлов-манифестов), ``versions_bytes``/``versions_gb``,
    ``fragments`` (файлов данных), ``data_gb``, ``indices`` (каталогов индексов),
    ``total_gb``, ``path``. Нет каталога → ``exists=False`` и нули.
    """
    if db_path is None:
        from core.config import lancedb_path

        db_path = lancedb_path()
    root = Path(db_path) / f"{table_name}.lance"
    health: dict[str, Any] = {"path": str(root), "exists": root.is_dir(), "versions": 0,
                              "versions_bytes": 0, "versions_gb": 0.0, "fragments": 0,
                              "data_gb": 0.0, "indices": 0, "total_gb": 0.0}
    if not health["exists"]:
        return health
    versions, versions_bytes = _dir_stats(root / "_versions")
    fragments, data_bytes = _dir_stats(root / "data")
    indices = 0
    try:
        with os.scandir(root / "_indices") as it:
            indices = sum(1 for e in it if e.is_dir(follow_symlinks=False))
    except OSError:
        pass
    side = 0
    for sub in ("_deletions", "_transactions"):
        side += _dir_stats(root / sub)[1]
    idx_bytes = _tree_stats(root / "_indices")[1] if indices else 0
    health.update(
        versions=versions,
        versions_bytes=versions_bytes,
        versions_gb=round(versions_bytes / _GB, 3),
        fragments=fragments,
        data_gb=round(data_bytes / _GB, 3),
        indices=indices,
        total_gb=round((versions_bytes + data_bytes + idx_bytes + side) / _GB, 3),
    )
    return health


def lance_health_verdict(health: dict[str, Any]) -> tuple[str, str]:
    """(status, detail) для doctor: warn при версий > порога или ``_versions`` > порога ГБ."""
    if not health.get("exists"):
        return "ok", "каталога таблицы нет (индекс ещё не строился)"
    max_versions, max_gb = warn_thresholds()
    detail = (
        f"версий {health['versions']} / фрагментов {health['fragments']} / "
        f"_versions {health['versions_gb']:.2f} ГБ (всего {health['total_gb']:.1f} ГБ)"
    )
    over = []
    if health["versions"] > max_versions:
        over.append(f"версий > {max_versions}")
    if health["versions_bytes"] / _GB > max_gb:
        over.append(f"_versions > {max_gb:g} ГБ")
    if over:
        return "warn", f"{detail}; порог превышен: {', '.join(over)}"
    return "ok", detail


def ensure_scalar_indexes(table: Any) -> list[str]:
    """Гарантировать BTREE на :data:`SCALAR_INDEX_COLUMNS`; вернуть созданные колонки.

    Идемпотентно: существующий индекс на колонке не пересоздаётся. Пустая таблица
    индексов не получает. Исключения наружу не летят — индекс только ускоряет delete,
    без него всё корректно (просто медленнее): WARNING и пустой список.
    """
    created: list[str] = []
    try:
        if table.count_rows() == 0:
            return created
        have = {col for idx in table.list_indices() for col in getattr(idx, "columns", [])}
        present = set(table.schema.names)
        for column in SCALAR_INDEX_COLUMNS:
            if column in have or column not in present:
                continue
            table.create_scalar_index(column, index_type="BTREE", replace=True)
            created.append(column)
    except Exception as exc:  # noqa: BLE001 — ускоритель, не критичный путь
        logger.warning("[index] скалярный индекс %s не создан: %s", SCALAR_INDEX_COLUMNS, exc)
    return created


def optimize_table(
    table: Any, *, hours: float | None = None, db_path: Path | None = None
) -> dict[str, Any]:
    """``table.optimize(cleanup_older_than=hours)`` + замер каталога до/после.

    Возвращает отчёт (канарейка): ``before``/``after`` — :func:`lance_health`,
    ``freed_gb``, ``elapsed_s``, ``keep_h``, ``ok``, ``error``. Сбой optimize — WARNING и
    ``ok=False`` (reindex уже записал данные; следующий прогон повторит).
    """
    keep = keep_hours() if hours is None else hours
    before = lance_health(db_path)
    start = time.perf_counter()
    report: dict[str, Any] = {"keep_h": keep, "ok": True, "error": "", "before": before}
    try:
        table.optimize(cleanup_older_than=timedelta(hours=keep))
    except Exception as exc:  # noqa: BLE001 — гигиена best-effort, данные уже записаны
        report["ok"] = False
        report["error"] = f"{type(exc).__name__}: {exc}"[:300]
        logger.warning("[index] LanceDB optimize не удался: %s", report["error"])
    after = lance_health(db_path)
    report["after"] = after
    report["elapsed_s"] = round(time.perf_counter() - start, 1)
    report["freed_gb"] = round(before["total_gb"] - after["total_gb"], 3)
    logger.info(
        "[index] LanceDB optimize (keep %sч): версий %s→%s, _versions %.2f→%.2f ГБ, %.1fс",
        keep, before["versions"], after["versions"], before["versions_gb"],
        after["versions_gb"], report["elapsed_s"],
    )
    return report
