"""MAIL-THREAD-1 P0 — чтение почтового треда по сообщениям, а не по символам.

Тело заметки ``source_type: email-thread`` — это сообщения с детерминированными
заголовками ``## YYYY-MM-DD HH:MM — <от> → <кому>`` (``core/legacy/mail.py::_thread_body``).
Раньше :func:`core.retrieval.find.read_full_note` резал ``body[:max_chars]`` с начала:
на треде, где чужой хвост на сотни КБ стоит перед ответом контрагента, исход (последнее
сообщение) отрезался первым (фейлкейс 01.10.2026). Для почты это инверсия ценности:
последнее письмо — и есть итог.

Что делает модуль (чистые функции, без I/O и без LLM):

* :func:`parse_thread` — тело → ``преамбула + [сообщения] + футер`` (футер — хвост
  ``## Связано``, который дописывает линковщик; это не сообщение).
* :func:`render_budgeted` — бюджет **по сообщениям**: заголовки ВСЕХ остаются всегда
  (в сжатом виде — дата/от/кому), тела отдаются с конца, ранние урезаются первыми;
  цитатные хвосты внутри сообщения режутся раньше, чем сообщение целиком.
* :func:`select_messages` — прямой доступ к хвосту: ``last`` / ``N`` / ``inbound_last``.
* Честная сводка ``messages{total, shown_full, shown_header_only, …, last_from,
  last_date}`` — агент видит «не прочитан ответ v.shevtsov@ от 02.09», а не выводит это.

Почему сводка, а не только ``truncated: true``: в фейлкейсе агент видел оба факта
(``truncated`` и что последнее сообщение — от контрагента) и пошёл писать. Неполнота
должна быть громкой именно там, где принимается решение.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "ThreadMessage",
    "ParsedThread",
    "parse_thread",
    "cut_quote_tail",
    "render_budgeted",
    "full_summary",
    "select_messages",
    "parse_messages_arg",
    "last_message_info",
    "EMAIL_THREAD",
]

EMAIL_THREAD = "email-thread"

# Заголовок сообщения. Рендер пишет ``## 2026-09-02 13:08 — <от> → <кому>``; дату
# допускаем без времени, тире — любое из трёх (ТЗ пишет «-», рендер — «—»). Сообщение
# без даты рендерится как ``##  — <от>`` (двойной пробел + длинное тире) — узнаём его
# отдельно, чтобы строка вида ``## - пункт`` в теле письма не стала «сообщением».
_HEADER_RE = re.compile(
    r"^##[ \t]+(?:(?P<when>\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2})?)[ \t]+[—–-]"
    r"|[ \t]*—)[ \t]+(?P<rest>.*?)[ \t]*$"
)
_FOOTER_RE = re.compile(r"^##[ \t]+Связано\b")

# Маркеры цитатного хвоста (дешёвая эвристика, без НЛП).
_QUOTE_MARKER_RE = re.compile(
    r"^\s*(?:"
    r"(?:От|From|Sent|Отправлено|Дата|Date)\s*:"
    r"|-{2,}\s*(?:Original Message|Исходное сообщение|Forwarded message|Пересылаемое сообщение)"
    r"|_{5,}\s*$"
    r"|On\s.{5,200}\swrote\s*:?\s*$"
    r"|.{3,200}\sнаписал(?:а)?\s*:?\s*$"
    r")",
    re.IGNORECASE,
)
_QUOTED_LINE_RE = re.compile(r"^\s*>")

# Сжатый заголовок: сколько получателей показывать у сообщения «только заголовок».
_COMPACT_RECIPIENTS = 3
_COMPACT_HEADER_MAX = 400


@dataclass
class ThreadMessage:
    """Одно сообщение треда, разобранное из тела заметки."""

    idx: int  # 1-based, в хронологическом порядке (как в теле)
    header: str  # исходная строка заголовка
    date: str  # «YYYY-MM-DD HH:MM» (может быть пусто)
    sender: str  # «Я» или адрес/имя
    recipients: str  # хвост после « → » (может быть пусто)
    text: str  # тело сообщения (без заголовка)

    @property
    def is_me(self) -> bool:
        return self.sender.strip() == "Я"


@dataclass
class ParsedThread:
    preamble: str  # всё до первого сообщения (Источник/Тред/Участники/…)
    messages: list[ThreadMessage] = field(default_factory=list)
    footer: str = ""  # «## Связано …» и далее


def _split_header(rest: str) -> tuple[str, str]:
    """``<от> → <кому>`` → ``(от, кому)``; без стрелки — ``(rest, "")``."""
    if " → " in rest:
        sender, _, recips = rest.partition(" → ")
        return sender.strip(), recips.strip()
    return rest.strip(), ""


def parse_thread(body: str) -> ParsedThread | None:
    """Разобрать тело почтового треда. ``None`` — заголовков сообщений нет
    (читатель падает на прежнее поведение, а не выдумывает структуру)."""
    lines = body.split("\n")
    header_at: list[int] = []
    header_m: list[re.Match[str]] = []
    footer_at: int | None = None
    for i, line in enumerate(lines):
        hm = _HEADER_RE.match(line)
        if hm:
            header_at.append(i)
            header_m.append(hm)
        elif _FOOTER_RE.match(line) and header_at:
            footer_at = i
            break
    if not header_at:
        return None
    end = footer_at if footer_at is not None else len(lines)
    preamble = "\n".join(lines[: header_at[0]]).rstrip("\n")
    footer = "\n".join(lines[end:]).strip("\n") if footer_at is not None else ""
    messages: list[ThreadMessage] = []
    for n, start in enumerate(header_at):
        stop = header_at[n + 1] if n + 1 < len(header_at) else end
        m = header_m[n]
        sender, recips = _split_header(m.group("rest"))
        messages.append(
            ThreadMessage(
                idx=n + 1,
                header=lines[start],
                date=(m.group("when") or "").replace("T", " "),
                sender=sender,
                recipients=recips,
                text="\n".join(lines[start + 1 : stop]).strip("\n"),
            )
        )
    return ParsedThread(preamble=preamble, messages=messages, footer=footer)


# --------------------------------------------------------------------------- #
# Цитатные хвосты                                                             #
# --------------------------------------------------------------------------- #
def cut_quote_tail(text: str) -> tuple[str, int]:
    """Отрезать цитатный хвост сообщения → ``(ядро, длина_отрезанного)``.

    Хвост начинается с первой строки-маркера (``От:``/``From:``/``-----Original``/
    «… написал(а):») либо с блока строк ``>``, если блок преобладает в остатке.
    Если ядро пустое (сообщение целиком — пересылка/цитата) — не режем: потерять
    единственное содержимое хуже, чем потратить бюджет.
    """
    lines = text.split("\n")
    cut: int | None = None
    for i, line in enumerate(lines):
        if _QUOTE_MARKER_RE.match(line):
            cut = i
            break
    if cut is None:
        for i, line in enumerate(lines):
            if _QUOTED_LINE_RE.match(line):
                rest = [ln for ln in lines[i:] if ln.strip()]
                quoted = sum(1 for ln in rest if _QUOTED_LINE_RE.match(ln))
                if rest and quoted / len(rest) >= 0.6:
                    cut = i
                break
    if cut is None:
        return text, 0
    core = "\n".join(lines[:cut]).rstrip()
    if not core.strip():
        return text, 0
    return core, len(text) - len(core)


# --------------------------------------------------------------------------- #
# Рендер                                                                       #
# --------------------------------------------------------------------------- #
def _compact_header(msg: ThreadMessage) -> str:
    """Заголовок «только шапка»: дата/от/первые получатели (+N) — дёшево и читаемо."""
    when = msg.date or ""
    base = f"## {when} — {msg.sender}".rstrip() if when else f"##  — {msg.sender}"
    if msg.recipients:
        parts = [p.strip() for p in msg.recipients.split(", ") if p.strip()]
        shown = ", ".join(parts[:_COMPACT_RECIPIENTS])
        extra = len(parts) - _COMPACT_RECIPIENTS
        base += f" → {shown}" + (f" (+{extra})" if extra > 0 else "")
    if len(base) > _COMPACT_HEADER_MAX:
        base = base[: _COMPACT_HEADER_MAX - 1].rstrip() + "…"
    return base


def last_message_info(parsed: ParsedThread | None) -> dict[str, Any]:
    """``{last_from, last_date, last_from_me, last_inbound}`` по треду (пусто — нет).

    ``last_inbound`` — 1-based индекс последнего сообщения НЕ от меня (``None`` — входящих
    нет): OUT-COMPLETE-1 меряет полноту чтения именно по нему."""
    if parsed is None or not parsed.messages:
        return {"last_from": "", "last_date": "", "last_from_me": False, "last_inbound": None}
    last = parsed.messages[-1]
    inbound = next((m.idx for m in reversed(parsed.messages) if not m.is_me), None)
    return {"last_from": last.sender, "last_date": last.date, "last_from_me": last.is_me,
            "last_inbound": inbound}


def parse_messages_arg(value: Any) -> tuple[str, int]:
    """Нормализовать параметр ``messages`` → ``(mode, n)``.

    ``all`` | ``last`` | ``inbound_last`` | ``N`` (последние N; int или «3»).
    Нераспознанное — ``ValueError`` (громкий отказ вместо молчаливого ``all``).
    """
    if value is None or value == "":
        return "all", 0
    if isinstance(value, bool):
        raise ValueError(f"messages: bad value {value!r}")
    if isinstance(value, int):
        if value < 1:
            raise ValueError(f"messages: N must be >= 1, got {value}")
        return "last_n", value
    text = str(value).strip().lower()
    if text in ("all", "last", "inbound_last"):
        return text, 1 if text == "last" else 0
    if text.isdigit() and int(text) >= 1:
        return "last_n", int(text)
    raise ValueError(
        f"messages: expected 'all' | 'last' | 'inbound_last' | N>=1, got {value!r}"
    )


def select_messages(parsed: ParsedThread, mode: str, n: int) -> list[int]:
    """Индексы (1-based) сообщений, запрошенных селектором. ``all`` → все."""
    total = len(parsed.messages)
    if mode == "all":
        return list(range(1, total + 1))
    if mode in ("last", "last_n"):
        return list(range(max(1, total - n + 1), total + 1))
    if mode == "inbound_last":
        for msg in reversed(parsed.messages):
            if not msg.is_me:
                return [msg.idx]
        return []
    raise ValueError(f"unknown messages mode {mode!r}")


def _full_text(msg: ThreadMessage) -> str:
    return msg.header + ("\n" + msg.text if msg.text else "")


def full_summary(parsed: ParsedThread) -> dict[str, Any]:
    """Сводка для случая «тред показан целиком»."""
    return _summary(
        len(parsed.messages),
        [m.idx for m in parsed.messages],
        [], [], [], [],
        last_message_info(parsed),
        "all",
    )


def render_budgeted(
    parsed: ParsedThread, max_chars: int, *, mode: str = "all", n: int = 0
) -> tuple[str, dict[str, Any], bool]:
    """Собрать тело треда в бюджет ``max_chars`` → ``(body, messages_summary, truncated)``.

    **mode=all** — преамбула и футер остаются; каждое сообщение получает заголовок
    (сжатый, если тело не влезло); тела раздаются **с конца**: сначала сообщение
    целиком, затем без цитатного хвоста, затем (только последнее) обрезанное по
    бюджету; что не влезло — «только заголовок», и раздача останавливается (показанные
    тела — непрерывный суффикс треда). Вызывающий сам решает, нужен ли бюджет: тред,
    который влезает целиком, отдаётся без разбора (см. ``read_full_note``).

    **mode=last/last_n/inbound_last** — рендерятся только выбранные сообщения (по тем же
    правилам бюджета); остальные в тело не попадают и перечислены в сводке
    ``not_shown``.
    """
    msgs = parsed.messages
    total = len(msgs)
    info = last_message_info(parsed)
    wanted_set = set(select_messages(parsed, mode, n))
    pre, foot = parsed.preamble, parsed.footer

    # Что уже оплачено заранее: преамбула, футер, пометки и (mode=all) сжатые заголовки.
    pre_paid: dict[int, int] = {}
    fixed = len(pre) + (len(foot) + 2 if foot else 0) + 64
    if mode == "all":
        for m in msgs:
            pre_paid[m.idx] = len(_compact_header(m)) + 2
        fixed += sum(pre_paid.values())

    def cost(msg: ThreadMessage, text: str) -> int:
        """Сколько бюджета съест показ ``text`` вместо заранее оплаченного заголовка."""
        return len(text) + 2 - pre_paid.get(msg.idx, 0)

    remaining = max_chars - fixed
    shown_full: list[int] = []
    shown_partial: list[int] = []
    quote_trimmed: list[int] = []
    header_only: list[int] = []
    not_shown: list[int] = []
    rendered: dict[int, str] = {}
    giving = True  # раздача тел с конца идёт, пока не встретили не влезшее

    for msg in reversed(msgs):
        if msg.idx not in wanted_set:
            not_shown.append(msg.idx)
            continue
        if giving:
            full = _full_text(msg)
            if cost(msg, full) <= remaining:
                rendered[msg.idx] = full
                remaining -= cost(msg, full)
                shown_full.append(msg.idx)
                continue
            core, cut = cut_quote_tail(msg.text)
            if cut:
                trimmed = (
                    msg.header + ("\n" + core if core else "")
                    + f"\n[…цитата {cut} симв. опущена]"
                )
                if cost(msg, trimmed) <= remaining:
                    rendered[msg.idx] = trimmed
                    remaining -= cost(msg, trimmed)
                    shown_full.append(msg.idx)
                    quote_trimmed.append(msg.idx)
                    continue
            if not shown_full:
                # Последнее запрошенное сообщение показываем всегда — хотя бы начало
                # ядра: исход важнее полноты.
                source = core if cut else msg.text
                room = max(200, remaining - len(msg.header) - 80)
                piece = source[:room].rstrip()
                lost = len(msg.text) - len(piece)
                rendered[msg.idx] = msg.header + "\n" + piece + f"\n[…обрезано {lost} симв.]"
                remaining -= cost(msg, rendered[msg.idx])
                shown_partial.append(msg.idx)
                if cut:
                    quote_trimmed.append(msg.idx)
                giving = False
                continue
            giving = False
        # Не влезло (или раздача остановлена): mode=all — только заголовок.
        if mode == "all":
            rendered[msg.idx] = _compact_header(msg)
            header_only.append(msg.idx)
        else:
            not_shown.append(msg.idx)

    parts: list[str] = [pre] if pre else []
    parts.extend(rendered[m.idx] for m in msgs if m.idx in rendered)
    if foot:
        parts.append(foot)
    summary = _summary(
        total,
        sorted(shown_full + shown_partial),
        sorted(header_only),
        sorted(shown_partial),
        sorted(quote_trimmed),
        sorted(not_shown),
        info,
        mode,
    )
    # Усечением считается всё, что не показано целиком в исходном виде.
    truncated = bool(
        header_only or not_shown or shown_partial or quote_trimmed
    )
    return "\n\n".join(parts), summary, truncated


def _summary(
    total: int,
    shown_full: list[int],
    header_only: list[int],
    partial: list[int],
    quote_trimmed: list[int],
    not_shown: list[int],
    info: dict[str, Any],
    mode: str,
) -> dict[str, Any]:
    out: dict[str, Any] = {
        "total": total,
        "shown_full": shown_full,
        "shown_header_only": header_only,
        "last_from": info["last_from"],
        "last_date": info["last_date"],
        "last_from_me": info["last_from_me"],
        "last_inbound": info.get("last_inbound"),
    }
    if partial:
        out["shown_partial"] = partial
    if quote_trimmed:
        out["quote_trimmed"] = quote_trimmed
    if not_shown:
        out["not_shown"] = not_shown
    if mode != "all":
        out["mode"] = mode
    return out
