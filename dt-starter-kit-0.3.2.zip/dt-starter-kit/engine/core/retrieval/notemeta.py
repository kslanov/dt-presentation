"""RETR-RANK-1 — метаданные заметок для скана, фильтров и каталога хабов ``find_notes``.

Одна запись :class:`NoteMeta` на заметку vault: то, что ``find_notes`` берёт из frontmatter,
не читая тело заново (id, путь, слой, заголовок, алиасы, контактные поля, дата, H1 хаба).
:func:`load_metas` — полный обход vault тем же ``iter_vault``, что и индекс (NDA-барьер и
правила ``_``-каталогов — те же). Кэш на диске (п.6) подключается здесь же и ничего не меняет
для вызывающего: «записи» одни и те же.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.vault import Note, iter_vault

__all__ = [
    "QUERY_FIELDS",
    "PERSON_FIELDS",
    "DOMAIN_FIELDS",
    "NoteMeta",
    "meta_from_note",
    "is_quarantined",
    "load_metas",
    "OWNER_FIELDS",
    "as_texts",
    "fold_plain",
    "owner_ids",
]

# Поля frontmatter, с которыми скан сопоставляет свободный запрос. ``title``/``aliases``/``id``
# есть у любой заметки; ``subject`` и контактные поля — у ингестной переписки (её контакты
# НЕ индексные колонки, FTS до них не дотянется — отсюда обход vault).
QUERY_FIELDS: tuple[str, ...] = (
    "id",
    "title",
    "aliases",
    "subject",
    "counterparties",
    "counterparty_domains",
    "participants",
    "client",
    "tags",
)
# Жёсткие фильтры ``person``/``domain`` — только контактные поля.
PERSON_FIELDS: tuple[str, ...] = ("counterparties", "participants")
DOMAIN_FIELDS: tuple[str, ...] = ("counterparty_domains", "counterparties", "participants")
# Поля принадлежности заметки хабу (п.4: буст заметкам закреплённого хаба). ``links`` — wikilinks
# легаси-заметок (``[[client-initech]]``), у которых ``client`` — свободный текст.
OWNER_FIELDS: tuple[str, ...] = ("client", "project", "product", "links")

_DATE_FIELDS: tuple[str, ...] = ("last_date", "modified", "created", "first_date")
_KEPT_FIELDS: tuple[str, ...] = tuple(dict.fromkeys((*QUERY_FIELDS, *OWNER_FIELDS)))


def as_texts(value: Any) -> list[str]:
    """Скаляр или список frontmatter → список строк."""
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v) for v in value]
    return [str(value)]


def fold_plain(text: str) -> str:
    """NFC + casefold + ё→е: каноническая форма для точных сравнений."""
    return unicodedata.normalize("NFC", str(text)).casefold().replace("ё", "е").strip()


_WIKILINK_RE = re.compile(r"\[\[([^\[\]|]+?)(?:\|[^\]]*)?\]\]")


@dataclass(slots=True)
class NoteMeta:
    """Frontmatter-срез одной заметки (всё, что нужно ступеням поиска)."""

    id: str
    path: str                      # vault-относительный posix-путь заметки
    corpus: str                    # vault | current | legacy | …
    note_type: str = ""
    entity: str = ""               # у хаба: client | project | product | …
    title: str = ""                # frontmatter title → subject; пусто, если нет обоих
    source_path: str = ""          # frontmatter source_path, иначе абсолютный путь файла
    date: str = ""
    h1: str = ""                   # первый «# …» тела — только у хабов (имя без aliases)
    purpose: str = ""              # EVAL-HYGIENE-1: eval|selftest у прогона; пусто = рабочая
    fields: dict[str, tuple[str, ...]] = field(default_factory=dict)
    # свёрнутые тексты полей — лениво, одной свёрткой на процесс (см. find._folded)
    folded: dict[str, tuple[str, ...]] | None = None

    def texts(self, names: tuple[str, ...]) -> list[str]:
        """Значения перечисленных полей (плоский список строк)."""
        out: list[str] = []
        for name in names:
            out.extend(self.fields.get(name, ()))
        return out

    @property
    def aliases(self) -> tuple[str, ...]:
        return self.fields.get("aliases", ())


def owner_ids(meta: NoteMeta) -> set[str]:
    """Id хабов, которым принадлежит заметка (``client``/``project``/``product``/``links``)."""
    out: set[str] = set()
    for text in meta.texts(OWNER_FIELDS):
        match = _WIKILINK_RE.search(text)
        out.add((match.group(1) if match else text).strip())
    return out


def _first_h1(body: str) -> str:
    for line in body.splitlines():
        stripped = line.strip()
        if stripped.startswith("# "):
            return stripped[2:].strip()
    return ""


def _date_of(fm: dict[str, Any]) -> str:
    for key in _DATE_FIELDS:
        value = fm.get(key)
        if value:
            return str(value)
    return ""


def _purpose_of_fm(fm: dict[str, Any]) -> str:
    """``purpose`` из frontmatter: только ``eval``/``selftest`` (``work``/мусор → пусто)."""
    raw = str(fm.get("purpose") or "").strip().lower()
    return raw if raw in ("eval", "selftest") else ""


def is_quarantined(meta: NoteMeta) -> bool:
    """Заметка - прогон eval/selftest: ``purpose != work`` либо путь/источник под ``_eval``."""
    from core.privacy import any_eval

    return bool(meta.purpose) or any_eval(meta.path, meta.source_path)


def meta_from_note(note: Note, vault_path: Path) -> NoteMeta:
    """Срез frontmatter заметки (+ H1 для хаба)."""
    fm = note.frontmatter
    corpus = fm.get("corpus")
    try:
        rel = note.path.relative_to(vault_path).as_posix()
    except ValueError:
        rel = str(note.path)
    entity = str(fm.get("entity") or "")
    is_hub = str(note.type or "") == "hub"
    kept: dict[str, tuple[str, ...]] = {}
    for name in _KEPT_FIELDS:
        texts = as_texts(fm.get(name))
        if name == "id" and not texts:
            texts = [note.id]
        if texts:
            kept[name] = tuple(texts)
    title = ""
    for key in ("title", "subject"):
        if fm.get(key):
            title = str(fm[key])
            break
    return NoteMeta(
        id=note.id,
        path=rel,
        corpus=str(corpus).strip() if corpus else "vault",
        note_type=str(note.type or ""),
        entity=entity,
        title=title,
        source_path=str(fm.get("source_path") or note.path),
        date=_date_of(fm),
        h1=_first_h1(note.body) if is_hub else "",
        purpose=_purpose_of_fm(fm),
        fields=kept,
    )


def load_metas(vault_path: Path) -> list[NoteMeta]:
    """Полный обход vault → срезы всех заметок (NDA и системные каталоги — как у индекса)."""
    vault_path = Path(vault_path)
    return [meta_from_note(note, vault_path) for note in iter_vault(vault_path)]
