"""RETR-CHUNK-1 п.5 — parent-child: родительская секция вместо соседних чанков.

Чанк — единица ПОИСКА (мелкий, точный вектор); читателю (промпт генерации, ``retrieve``) часто
нужна секция целиком: таблица смет с шапкой, раздел КП. ``section_id`` — стабильный ключ секции
(``note_id`` + путь заголовков), вычисляется из колонок индекса (новой колонки и миграции нет).

:func:`expand_hits` заменяет хит-чанк словарём «чанк + соседи той же секции» в бюджете токенов:
секция влезла — отдаётся целиком, не влезла — окно вокруг лучшего хита. Несколько хитов одной
секции склеиваются в один (оценка — лучшая). Включение — ключ ``parent_section`` слайса/политики;
дефолт (ключа нет): для документов слоёв ``current``/``legacy``, не для почтовых тредов (письмо —
уже единица, соседние чанки — другие письма). Бюджет на весь прогон политики —
``parent_budget_tokens`` (дефолт :data:`PARENT_BUDGET_TOKENS`); исчерпан — остальные хиты остаются
обычными чанками. Любая ошибка чтения индекса оставляет хиты как есть (расширение — оптимизация).
"""

from __future__ import annotations

import logging
from dataclasses import replace
from typing import Any

from core.chunking import count_tokens, section_id, split_context_prefix
from core.retrieval.search import SearchResult

logger = logging.getLogger(__name__)

__all__ = [
    "PARENT_SECTION_TOKENS",
    "PARENT_BUDGET_TOKENS",
    "section_id",
    "parent_enabled",
    "expand_hits",
]

PARENT_SECTION_TOKENS = 2400   # потолок одной развёрнутой секции
PARENT_BUDGET_TOKENS = 6000    # потолок на все развёрнутые секции одного прогона политики
_THREAD_TYPES = frozenset({"email-thread"})
_PARA_SEP = "\n\n"


def parent_enabled(setting: Any, hit: SearchResult) -> bool:
    """Включено ли расширение для хита. ``setting``: ``True``/``False`` — явно; ``None`` —
    дефолт (документы current/legacy, не треды); словарь — как ``True`` (параметры снаружи)."""
    if isinstance(setting, dict):
        return True
    if setting is not None:
        return bool(setting)
    md = hit.metadata
    if str(md.get("corpus") or "vault") not in ("current", "legacy"):
        return False
    return str(md.get("source_type") or "") not in _THREAD_TYPES and str(
        md.get("type") or ""
    ) not in _THREAD_TYPES


def _join_bodies(bodies: list[str]) -> str:
    """Склеить тела соседних чанков секции, убрав перекрытие (хвост предыдущего = голова
    следующего на уровне абзацев)."""
    if not bodies:
        return ""
    out = bodies[0].split(_PARA_SEP)
    for body in bodies[1:]:
        paras = body.split(_PARA_SEP)
        k = min(len(out), len(paras))
        while k > 0 and out[-k:] != paras[:k]:
            k -= 1
        out.extend(paras[k:])
    return _PARA_SEP.join(out)


def _fetch_section(table: Any, note_id: str, heading_path: str) -> list[dict[str, Any]]:
    """Строки секции по порядку ``chunk_index`` (без векторов); ошибка → ``[]``."""
    from core.retrieval.index import _sql_quote

    try:
        rows = (
            table.search()
            .where(f"note_id = {_sql_quote(note_id)} AND heading_path = {_sql_quote(heading_path)}")
            .select(["chunk_index", "text"])
            .limit(10_000)
            .to_list()
        )
    except Exception as exc:  # noqa: BLE001 — оптимизация: падать нельзя
        logger.debug("parent-section fetch failed for %s: %s", note_id, exc)
        return []
    rows = [r for r in rows if r.get("chunk_index") is not None]
    rows.sort(key=lambda r: int(r["chunk_index"]))
    return rows


def _window(bodies: list[str], anchor: int, limit: int) -> tuple[int, int]:
    """Окно ``[lo, hi]`` чанков вокруг ``anchor``, склеенное — не больше ``limit`` токенов.

    Соседи добавляются по очереди (вперёд, назад, …). Размер считается по СКЛЕЕННОМУ тексту
    (перекрытие соседних чанков в него не входит), поэтому бюджет не недоиспользуется."""
    lo = hi = anchor
    grow_next = True
    while True:
        for forward in (grow_next, not grow_next):
            idx = hi + 1 if forward else lo - 1
            if not 0 <= idx < len(bodies):
                continue
            new_lo, new_hi = (lo, idx) if forward else (idx, hi)
            if count_tokens(_join_bodies(bodies[new_lo : new_hi + 1])) <= limit:
                lo, hi = new_lo, new_hi
                grow_next = not forward
                break
        else:
            return lo, hi


def expand_hits(
    hits: list[SearchResult],
    *,
    setting: Any = None,
    budget: int = PARENT_BUDGET_TOKENS,
    per_section: int = PARENT_SECTION_TOKENS,
    table: Any = None,
) -> tuple[list[SearchResult], int]:
    """Расширить хиты до родительских секций → ``(хиты, израсходовано токенов)``.

    Порядок сохраняется (расширенный хит стоит на месте первого хита своей секции), последующие
    хиты той же секции поглощаются. ``setting`` — значение ``parent_section`` слайса/политики
    (см. :func:`parent_enabled`); ``budget`` — остаток бюджета прогона."""
    if not hits or budget <= 0:
        return hits, 0
    if isinstance(setting, dict):
        per_section = int(setting.get("max_tokens", per_section))
    if table is None:
        from core.retrieval.index import open_chunks_table

        table = open_chunks_table()
    if table is None:
        return hits, 0

    spent = 0
    out: list[SearchResult] = []
    absorbed: set[int] = set()  # id() хитов, поглощённых расширенной секцией
    cache: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for hit in hits:
        if id(hit) in absorbed:
            continue
        key = (hit.note_id, hit.heading_path)
        chunk_index = hit.metadata.get("chunk_index")
        if not parent_enabled(setting, hit) or not hit.note_id or chunk_index is None:
            out.append(hit)
            continue
        rows = cache.get(key)
        if rows is None:
            rows = cache[key] = _fetch_section(table, hit.note_id, hit.heading_path)
        idx_of = {int(r["chunk_index"]): i for i, r in enumerate(rows)}
        anchor = idx_of.get(int(chunk_index))
        if len(rows) < 2 or anchor is None:  # секция из одного чанка: хит и есть секция
            out.append(hit)
            continue
        bodies = [split_context_prefix(str(r["text"]))[1] for r in rows]
        limit = min(per_section, budget - spent)
        if limit < count_tokens(bodies[anchor]):  # бюджет исчерпан — остаётся обычный чанк
            out.append(hit)
            continue
        lo, hi = _window(bodies, anchor, limit)
        text = _join_bodies(bodies[lo : hi + 1])
        covered = {int(rows[i]["chunk_index"]) for i in range(lo, hi + 1)}
        siblings = [
            h for h in hits
            if (h.note_id, h.heading_path) == key and h.metadata.get("chunk_index") in covered
        ]
        absorbed.update(id(h) for h in siblings if h is not hit)  # хиты вне окна остаются чанками
        best = max(siblings, key=lambda h: h.score)
        md = dict(hit.metadata)
        md.update(
            parent_section=True,
            section_id=section_id(hit.note_id, hit.heading_path),
            section_chunks=len(rows),
            window_chunks=sorted(covered),
            chunk_index=int(rows[lo]["chunk_index"]),
        )
        out.append(replace(hit, text=text, score=best.score, metadata=md))
        spent += count_tokens(text)
    return out, spent
