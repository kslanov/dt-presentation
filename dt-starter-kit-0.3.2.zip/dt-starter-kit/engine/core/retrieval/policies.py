"""Per-use-case retrieval policy executor (architecture §5).

The central retrieval decision: a query is not one big search but a *composition
of parallel slices*, each with its own filter, ``k`` and (optionally) recency
sort. Each use case declares its slices in
``_system/retrieval-policies/<use_case>.yaml``; this module loads that policy,
substitutes runtime params into the filters, runs ``search`` per slice, and
returns the slices plus a flattened, de-duplicated context.

Filter conventions (architecture §5, ТЗ D2):
  * ``note_id: "{client_id}"`` pulls an entity's *own hub* by id — a hub's
    frontmatter does not link to itself, so it is fetched by id.
  * ``client: "{client_id}"`` (entity fields) pulls *related content* — notes
    that link to that entity.

Scope (ТЗ D2): policy execution only. Artifact generation, prompt assembly,
style-guide injection and provenance are later deliverables — the policy's
``style_guide`` / ``template`` / ``web`` fields are surfaced here as plain
metadata for those downstream steps to consume.

Invariant: ``core/`` depends on neither MCP nor CLI.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from core.config import retrieval_policies_path
from core.metrics import record_event
from core.retrieval.parent import PARENT_BUDGET_TOKENS, expand_hits
from core.retrieval.search import SearchResult, search

__all__ = ["PolicyResult", "find_policy_path", "load_policy", "run_policy"]

# A filter value that is exactly a single ``{param}`` placeholder, or contains
# embedded placeholders. We support general substitution (``"x-{id}"``) but the
# policies in scope use whole-value placeholders.
_PLACEHOLDER_RE = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")


@dataclass
class PolicyResult:
    """Outcome of running a retrieval policy.

    Attributes:
        use_case: The policy's ``use_case`` id.
        slices: Per-slice results, keyed by slice ``name`` (order preserved as
            in the policy). Skipped slices (failed ``when`` / missing param) are
            absent.
        context: All slice results flattened and de-duplicated (by note +
            chunk), in slice order — the raw material for prompt assembly.
        style_guide: Genre of the style guide to inject downstream (or None).
        template: Output template id to apply downstream (or None).
        web: Whether this policy wants a web-search slice (handled downstream).
        operational_context: Whether this policy wants the live Timetta-mirror
            status block injected downstream (ТЗ B4; assembled by
            :func:`core.operational.context.build_operational_context`).
    """

    use_case: str
    slices: dict[str, list[SearchResult]] = field(default_factory=dict)
    # CONTRACT-2 С3: слайсы, которые НЕ отработали, и почему. Пропуск по ``when`` —
    # штатное выключение (``reason: "when"``), а вот нерезолвнутый плейсхолдер
    # (``missing_param``) — это молча суженная область поиска, и вызывающий обязан
    # сказать об этом вслух: промпт без клиентского слайса выглядит нормальным.
    skipped_slices: list[dict[str, str]] = field(default_factory=list)
    context: list[SearchResult] = field(default_factory=list)
    style_guide: str | None = None
    template: str | None = None
    web: bool = False
    operational_context: bool = False
    # Whether this policy wants the structured-facts block (FACT-1) injected
    # before [Retrieved context]; assembled from lifted source files.
    structured_facts: bool = False
    # Grounding requirements (GATE-1): critical fact kinds that must be present
    # (else generate is blocked) and whether retrieval context is mandatory.
    # Declaration-to-block — distinct from `structured_facts` (inject-if-present).
    required_facts: list[str] = field(default_factory=list)
    required_context: bool = False
    # Whether this policy wants a real past document's *form* injected as the
    # ``[Образец оформления]`` section (TMPL-1); optional overrides for which genre
    # / format to look for when it differs from the style genre.
    exemplar: bool = False
    exemplar_genre: str | None = None
    exemplar_format: str | None = None


def _str_list(value: Any) -> list[str]:
    """Coerce a YAML value into a list of non-empty strings (GATE-1 requirements).

    ``required_facts`` is declared as a plain list of fact-kind strings; a scalar
    is wrapped, anything malformed yields ``[]``. Extended per-requirement
    thresholds are a caller-side concern (``check_grounding`` accepts them), not a
    policy-field shape.
    """
    if value is None:
        return []
    if isinstance(value, str):
        return [value.strip()] if value.strip() else []
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    return []


def _resolve_value(value: Any, params: dict[str, Any]) -> tuple[Any, bool]:
    """Substitute ``{param}`` placeholders in a filter value.

    Returns ``(resolved, ok)``. ``ok`` is False when a referenced param is
    missing or empty — the caller then skips the slice (ТЗ: «слайс
    пропускается… если параметр пуст»). Non-string values pass through.
    """
    if not isinstance(value, str):
        return value, True

    names = _PLACEHOLDER_RE.findall(value)
    if not names:
        return value, True

    for name in names:
        param = params.get(name)
        if param is None or param == "":
            return value, False

    resolved = _PLACEHOLDER_RE.sub(lambda m: str(params[m.group(1)]), value)
    return resolved, True


def _unresolved_param(filter_spec: dict[str, Any], params: dict[str, Any]) -> str:
    """Имя первого плейсхолдера фильтра, который не подставился (для конверта С3).

    Та же логика, что у :func:`_resolve_value` (плейсхолдер где угодно в строке, пустое
    значение = не подставился), иначе конверт называл бы не тот параметр.
    """
    for value in filter_spec.values():
        if not isinstance(value, str):
            continue
        for name in _PLACEHOLDER_RE.findall(value):
            param = params.get(name)
            if param is None or param == "":
                return name
    return ""


def _resolve_filter(
    raw_filter: dict[str, Any], params: dict[str, Any]
) -> tuple[dict[str, Any], bool]:
    """Resolve every value in a slice filter; ``ok`` False ⇒ skip the slice."""
    resolved: dict[str, Any] = {}
    for key, value in raw_filter.items():
        new_value, ok = _resolve_value(value, params)
        if not ok:
            return resolved, False
        resolved[key] = new_value
    return resolved, True


def quarantined_note_ids() -> frozenset[str]:
    """Id заметок-прогонов (``purpose != work`` / под ``_eval``) по frontmatter-снимку vault.

    Снимок как есть (``peek_metas``: без обхода vault и без записи) - его ведет
    индекс/``find_notes``; отставшая на минуты заметка свежего прогона отсекается и по
    ``source_path`` (:func:`drop_quarantined`)."""
    from core.config import default_vault_path
    from core.retrieval.fm_cache import peek_metas
    from core.retrieval.notemeta import is_quarantined

    return frozenset(m.id for m in peek_metas(default_vault_path()) if is_quarantined(m))


def drop_quarantined(
    hits: list[SearchResult], ids: frozenset[str] | None = None
) -> list[SearchResult]:
    """Хиты без заметок-прогонов eval/selftest (EVAL-HYGIENE-1 п.3)."""
    if not hits:
        return hits
    from core.privacy import is_eval

    bad = quarantined_note_ids() if ids is None else ids
    return [h for h in hits if h.note_id not in bad and not is_eval(h.source_path)]


def _recency_key(result: SearchResult) -> str:
    """Sort key for ``recency_desc``: prefer ``modified``, fall back to ``created``.

    Dates are stored as ISO strings (e.g. ``2026-06-17``), which sort
    chronologically as plain strings. Missing dates sort last.
    """
    return result.metadata.get("modified") or result.metadata.get("created") or ""


def _dedup_key(result: SearchResult) -> tuple[Any, ...]:
    """Identity of a result for context de-duplication (note + chunk)."""
    chunk_index = result.metadata.get("chunk_index")
    if chunk_index is not None:
        return (result.note_id, chunk_index)
    return (result.note_id, result.heading_path, result.text)


def find_policy_path(use_case_id: str, *, policies_dir: Path | None = None) -> Path:
    """Resolve the YAML file backing a ``use_case`` id.

    Files may carry an ordering prefix (``01-client-correspondence.yaml``) while
    the policy's ``use_case`` is the bare id (``client_correspondence``). We
    match first by filename stem, then by the YAML's ``use_case`` field. This is
    the single source of truth for *which file* a use case maps to — both
    :func:`load_policy` and provenance (copying the policy verbatim) use it.
    """
    policies_dir = policies_dir or retrieval_policies_path()

    direct = policies_dir / f"{use_case_id}.yaml"
    if direct.is_file():
        return direct

    for path in sorted(policies_dir.glob("*.yaml")):
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if data.get("use_case") == use_case_id:
            return path

    raise FileNotFoundError(
        f"No retrieval policy for use_case {use_case_id!r} in {policies_dir}"
    )


def load_policy(use_case_id: str, *, policies_dir: Path | None = None) -> dict[str, Any]:
    """Load a policy YAML by ``use_case`` id (see :func:`find_policy_path`)."""
    path = find_policy_path(use_case_id, policies_dir=policies_dir)
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def run_policy(
    use_case_id: str,
    query: str,
    params: dict[str, Any] | None = None,
    *,
    policies_dir: Path | None = None,
    corpus: str | None = None,
    boost_curated: bool = True,
    include_eval: bool = False,
) -> PolicyResult:
    """Execute a retrieval policy: run each slice and assemble the context.

    ``include_eval`` (EVAL-HYGIENE-1): по умолчанию заметки-прогоны (``purpose != work`` по
    frontmatter-снимку, источники под ``_eval``) в слайсы не попадают; ``True`` - eval-отладка.

    For every slice the filter placeholders are resolved from ``params``; a
    slice is skipped when its ``when`` param is falsy or a referenced param is
    missing/empty. ``sort: recency_desc`` re-orders a slice's hits by date desc.

    ``corpus`` is a global layer override applied to every slice: when set it
    overrides each slice's own ``corpus`` filter — this is how the vault-only flag
    forces curated-only retrieval across the whole policy. It accepts any value
    :func:`core.retrieval.search._corpus_layers` understands
    (``"vault"``/``"current"``/``"legacy"``, ``"raw"`` = current+legacy, or a list
    of layers). ``None`` leaves each slice's own ``corpus`` filter intact (so a
    legacy opt-in slice still pulls legacy). ``boost_curated`` is threaded to
    :func:`search`.

    RETR-CHUNK-1 п.5 (parent-child): ``parent_section`` слайса (или политики) заменяет хит-чанк
    родительской секцией целиком в бюджете токенов (:mod:`core.retrieval.parent`); ключа нет —
    дефолт: документы слоёв current/legacy, не почтовые треды. ``parent_budget_tokens`` политики —
    потолок на ВСЕ развёрнутые секции прогона.
    """
    params = params or {}
    policy = load_policy(use_case_id, policies_dir=policies_dir)

    result = PolicyResult(
        use_case=str(policy.get("use_case", use_case_id)),
        style_guide=policy.get("style_guide"),
        template=policy.get("template"),
        web=bool(policy.get("web", False)),
        operational_context=bool(policy.get("operational_context", False)),
        structured_facts=bool(policy.get("structured_facts", False)),
        required_facts=_str_list(policy.get("required_facts")),
        required_context=bool(policy.get("required_context", False)),
        exemplar=bool(policy.get("exemplar", False)),
        exemplar_genre=policy.get("exemplar_genre"),
        exemplar_format=policy.get("exemplar_format"),
    )

    parent_left = int(policy.get("parent_budget_tokens", PARENT_BUDGET_TOKENS))
    eval_ids = None if include_eval else quarantined_note_ids()  # одним чтением снимка на прогон
    for spec in policy.get("slices", []):
        name = spec["name"]

        when = spec.get("when")
        if when is not None and not params.get(when):
            result.skipped_slices.append(
                {"name": name, "reason": "when", "param": str(when)}
            )
            continue

        resolved, ok = _resolve_filter(spec.get("filter", {}), params)
        if not ok:
            result.skipped_slices.append(
                {"name": name, "reason": "missing_param",
                 "param": _unresolved_param(spec.get("filter", {}), params)}
            )
            continue

        if corpus is not None:
            resolved["corpus"] = corpus  # global override (vault-only flag)

        hits = search(
            query, filters=resolved, k=spec.get("k", 10), boost_curated=boost_curated
        )
        if eval_ids is not None:
            hits = drop_quarantined(hits, eval_ids)

        if spec.get("sort") == "recency_desc":
            hits = sorted(hits, key=_recency_key, reverse=True)

        hits, spent = expand_hits(
            hits, setting=spec.get("parent_section", policy.get("parent_section")),
            budget=parent_left,
        )
        parent_left -= spent

        result.slices[name] = hits

    seen: set[tuple[Any, ...]] = set()
    for hits in result.slices.values():
        for hit in hits:
            key = _dedup_key(hit)
            if key in seen:
                continue
            seen.add(key)
            result.context.append(hit)

    # KPI-1 (метрика 2, v1): факт прогона и наполненность. Privacy — только
    # generic use-case id и счётчики: ни запроса, ни параметров, ни текстов.
    record_event(
        "retrieval_run",
        use_case=result.use_case,
        corpus=corpus or "",
        slices=len(result.slices),
        hits=len(result.context),
    )
    return result
