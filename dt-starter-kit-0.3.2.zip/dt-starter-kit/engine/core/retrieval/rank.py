"""RETR-RANK-1 п.2 — единая шкала ранжирования и слияние ступеней ``find_notes``.

Чистые функции (ни индекса, ни диска, ни модели): тестируются без LanceDB.

**Проблема (аудит 2026-10 C §3).** Ступени поиска выдавали ТРИ несравнимые шкалы в одном
списке: скан frontmatter — 1.0 / 2.0, FTS — сырой BM25 (единицы и десятки), семантика — RRF
(сотые) × слоевой буст. Сортировка по такому ``score`` ставила хаб с точным алиасом (2.0)
ниже тела письма с BM25 7.3 (q04 «ИТХ»: хаб 6-й).

**Решение.** 1) Внутри ступени — нормализация в [0, 1]: BM25 и RRF — min-max по пулу запроса
(:func:`minmax`), скан — ярусы (:data:`SCAN_TIERS`: точный id/алиас 1.0, подстрока заголовка
0.9, прочие поля frontmatter 0.7). 2) Между ступенями — взвешенный RRF по РАНГАМ
(:func:`fuse`): шкало-независимо; вклад ступени ``w · (0.5 + 0.5·s) / (K + rank)``, где
``s`` — нормализованная оценка внутри ступени (сильное совпадение весит больше слабого
того же ранга; убрать нормализацию — и точный алиас перестанет отличаться от нечёткого).
3) Слоевой приоритет (vault > current > legacy) — только тай-брейк после суммы и лучшей
нормализованной оценки; сами константы живут в ``search.py`` (``CURATED_BOOST`` /
``CURRENT_BOOST``) и импортируются сюда, второго места нет. 4) Закрепление хаба
(:func:`apply_pin`) — хаб клиента из запроса (п.4) встаёт в голову выдачи; после реранкера
(RETR-RERANK-1) — :func:`apply_pin_top`: хаб гарантированно в топ-3, первым идёт лучший
по реранкеру.

Итоговый ``score`` — доля максимально возможной суммы вкладов ступеней, давших кандидатов
в ЭТОМ запросе (0..1): 1.0 = первое место во всех ступенях с максимальной оценкой. При
одной ступени порядок выдачи равен порядку ступени (идемпотентность).
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field

__all__ = [
    "K_RRF",
    "STAGE_WEIGHT",
    "SCAN_TIERS",
    "MATCHED_BY_VALUES",
    "BOOST_CLIENT",
    "Cand",
    "Fused",
    "minmax",
    "scan_tier",
    "title_token_coverage",
    "TITLE_COVERAGE_MIN",
    "layer_priority",
    "stage_order",
    "fuse",
    "apply_pin",
    "apply_pin_top",
    "RERANK_SUFFIX",
    "matched_by_base",
]

# RRF-константа. 60 — канон Cormack et al.; при пулах в десятки-сотни заметок разница между
# рангами 1 и 2 (1/61 против 1/62) мала, а потому ярус скана и оценка внутри ступени
# (множитель ``0.5 + 0.5·s``) решают исход честнее, чем голый ранг.
K_RRF = 60

# Вес ступени в слиянии. Равные: приоритет точного совпадения задаёт ЯРУС скана (s=1.0),
# а не вес ступени — иначе нечёткое совпадение frontmatter (0.7) обходило бы BM25-лидера.
STAGE_WEIGHT: dict[str, float] = {"scan": 1.0, "fts": 1.0, "semantic": 1.0}

# Ярусы скана frontmatter (оценка внутри ступени скана) и их честные ``matched_by``.
SCAN_TIERS: dict[str, float] = {
    "scan:id": 1.0,
    "scan:alias": 1.0,
    "scan:title": 0.9,
    "scan:title_tokens": 0.8,
    "scan:fm": 0.7,
}

# RETR-CHUNK-1 п.6: ярус «покрытие токенов заголовка». Доля значимых токенов запроса, которые
# есть среди токенов title/алиасов, не меньше порога; значимых токенов — не меньше двух (один
# токен и так ловит подстрока). Стоп-слова не считаются: «доклад по ПАК-А» ≈ «доклад ПАК-А».
TITLE_COVERAGE_MIN = 0.8
_TITLE_MIN_TOKENS = 2
_STOPWORDS = frozenset(
    "и в во на по для с со к о об от из у за что как это или а но не бы же ли при про над под до"
    " the a an of to for and or in on at by with from is are".split()
)

# Закрытый список значений ``matched_by`` (контракт ``find_notes``, п.5).
MATCHED_BY_VALUES: frozenset[str] = frozenset(
    {*SCAN_TIERS, "fts", "semantic", "pin:client"}
)

# RETR-RERANK-1: суффикс ``matched_by`` хитов, чью позицию определил реранкер
# (``fts+rerank``, ``pin:client+rerank``); база — из закрытого списка выше.
RERANK_SUFFIX = "+rerank"


def matched_by_base(value: str) -> str:
    """``matched_by`` без суффикса реранкера (значение закрытого списка)."""
    return value.removesuffix(RERANK_SUFFIX)


# Буст заметке, принадлежащей закреплённому хабу (``client: <hub-id>``), в долях вклада
# первого ранга: не источник кандидатов (иначе тысячи писем клиента затопят выдачу), а
# подъём уже найденных.
BOOST_CLIENT = 0.5

_STAGE_TIE = {"scan": 0, "fts": 1, "semantic": 2}  # при равном вкладе честнее точный источник
STRONG_TIER = 0.9   # ярусы скана id/алиас/заголовок задают ``matched_by`` заметки


@dataclass(frozen=True)
class Cand:
    """Кандидат одной ступени: заметка + сырая оценка ступени + слой/дата для тай-брейка."""

    note_id: str
    raw: float = 0.0
    layer: str = "vault"
    tag: str = ""        # ярус скана (``scan:id`` …); у FTS/семантики пусто
    date: str = ""       # ISO-подобная строка (сортируется лексикографически)


@dataclass
class Fused:
    """Итог слияния по одной заметке."""

    note_id: str
    score: float
    matched_by: str
    layer: str
    date: str = ""
    stages: dict[str, tuple[int, float]] = field(default_factory=dict)  # ступень → (ранг, s)


def minmax(values: Sequence[float]) -> list[float]:
    """Min-max нормализация в [0, 1]. Пусто → ``[]``; все равны → все 1.0.

    Все-равны даёт 1.0, а не 0.0: единственный (или одинаковый) результат ступени — это
    «лучший в пуле», а не «худший»; иначе одиночный FTS-хит получал бы нулевой вклад.
    """
    if not values:
        return []
    lo, hi = min(values), max(values)
    if hi == lo:
        return [1.0] * len(values)
    span = hi - lo
    return [(v - lo) / span for v in values]


def layer_priority(layer: str) -> float:
    """Слоевой приоритет для тай-брейка: vault > current > legacy (единая точка — search.py)."""
    from core.retrieval.search import _layer_multiplier

    return _layer_multiplier(layer if layer in ("vault", "current") else "legacy")


def title_token_coverage(query: str, fields: Iterable[str]) -> float:
    """Доля значимых токенов ``query`` (уже свёрнутого), найденных среди токенов ``fields``.

    ``0.0`` — токенов меньше двух (покрытие не определено) или ничего не найдено. Токены —
    слова по пробелам (обе стороны свёрнуты вызывающим: регистр/стем-ключи); стоп-слова и
    однобуквенные токены (кроме цифр) не считаются."""
    wanted = [t for t in query.split() if t not in _STOPWORDS and (len(t) > 1 or t.isdigit())]
    if len(wanted) < _TITLE_MIN_TOKENS:
        return 0.0
    have: set[str] = set()
    for field_text in fields:
        have.update(field_text.split())
    return sum(1 for t in wanted if t in have) / len(wanted)


def scan_tier(
    query: str,
    *,
    note_id: str,
    aliases: Iterable[str],
    title: str,
    other_fields: Iterable[str],
    norm: Callable[[str], str] = lambda s: s.casefold().strip(),
) -> str | None:
    """Ярус совпадения запроса с frontmatter заметки (``None`` — не совпало).

    * ``scan:id`` — запрос равен id заметки;
    * ``scan:alias`` — запрос равен одному из алиасов целиком;
    * ``scan:title`` — запрос подстрока заголовка; либо (RETR-CHUNK-1 п.6) ВСЕ значимые токены
      запроса (без стоп-слов, ≥ 2) найдены среди токенов заголовка/алиасов в любом порядке;
    * ``scan:title_tokens`` — то же, но покрыто 80–99% токенов («совещание Д651 02.10.2026 доклад
      ПАК-А» ↔ «ТЗ доклад ПАК-А совещание Д651 02.10.2026» — 100% → ``scan:title``);
    * ``scan:fm`` — подстрока любого из остальных полей (id/алиасы частично, участники,
      клиент, теги …).

    ``norm`` — свёртка обеих сторон (по умолчанию регистр; п.3 подставляет стемы). Пустой
    запрос ярусов не имеет (``None``): заметка пришла по фильтру person/domain, а не по тексту.
    """
    q = norm(query)
    if not q:
        return None
    if q == norm(note_id):
        return "scan:id"
    alias_list = [norm(a) for a in aliases]
    if q in alias_list:
        return "scan:alias"
    if q in norm(title):
        return "scan:title"
    coverage = title_token_coverage(q, [norm(title), *alias_list])
    if coverage >= 1.0:
        return "scan:title"  # все значимые токены запроса — в заголовке/алиасах: как подстрока
    if coverage >= TITLE_COVERAGE_MIN:
        return "scan:title_tokens"
    haystack = [norm(note_id), *alias_list, *(norm(f) for f in other_fields)]
    if any(q in h for h in haystack):
        return "scan:fm"
    return None


def stage_order(stage: str, cands: Iterable[Cand]) -> list[tuple[Cand, float]]:
    """Кандидаты ступени, лучший первым, с оценкой ``s`` ∈ [0, 1] внутри ступени.

    ``scan`` — ``s`` из яруса (:data:`SCAN_TIERS`); ``fts``/``semantic`` — min-max сырой
    оценки по пулу. Порядок при равной ``s``: слой (vault > current > legacy), свежее,
    id — детерминированно. Дубли ``note_id`` схлопываются по лучшей ``s``.
    """
    pool = list(cands)
    if stage == "scan":
        scores = [SCAN_TIERS.get(c.tag, SCAN_TIERS["scan:fm"]) for c in pool]
    else:
        scores = minmax([c.raw for c in pool])
    best: dict[str, tuple[Cand, float]] = {}
    for cand, s in zip(pool, scores, strict=True):
        prev = best.get(cand.note_id)
        if prev is None or s > prev[1]:
            best[cand.note_id] = (cand, s)
    ordered = sorted(best.values(), key=lambda cs: cs[0].note_id)           # детерминизм
    ordered.sort(key=lambda cs: cs[0].date or "", reverse=True)
    ordered.sort(key=lambda cs: layer_priority(cs[0].layer), reverse=True)
    ordered.sort(key=lambda cs: cs[1], reverse=True)
    return ordered


def fuse(
    stages: Mapping[str, Sequence[Cand]],
    *,
    k: int = K_RRF,
    weights: Mapping[str, float] | None = None,
    boosts: Mapping[str, float] | None = None,
) -> list[Fused]:
    """Слить ступени в один список по единой шкале 0..1 (лучший первым).

    Вклад ступени в заметку на ранге ``r``: ``w · (0.5 + 0.5·s) / (k + r)``. Сумма делится
    на максимально возможную для ступеней, давших кандидатов (``Σ w/(k+1)``), поэтому
    ``score`` ∈ [0, 1]. ``boosts`` — ``{note_id: доля}``: добавка ``доля · w_scan/(k+1)``
    УЖЕ найденной заметке (новых кандидатов не создаёт); если буст поднял сумму выше
    теоретического максимума, шкала растягивается так, чтобы лучший остался 1.0.

    Тай-брейк при равной сумме: лучшая нормализованная оценка → слой → свежесть.
    ``matched_by`` — источник с наибольшим вкладом (скан → его ярус).
    """
    w = dict(STAGE_WEIGHT)
    if weights:
        w.update(weights)
    present = [name for name, cands in stages.items() if len(cands) > 0]
    if not present:
        return []
    max_total = sum(w.get(name, 1.0) for name in present) / (k + 1)

    total: dict[str, float] = {}
    best_s: dict[str, float] = {}
    top_contrib: dict[str, tuple[float, int, str]] = {}  # id → (вклад, -тай-брейк ступени, метка)
    meta: dict[str, Cand] = {}
    seen_stages: dict[str, dict[str, tuple[int, float]]] = {}

    for name in present:
        weight = w.get(name, 1.0)
        for rank, (cand, s) in enumerate(stage_order(name, stages[name]), start=1):
            contrib = weight * (0.5 + 0.5 * s) / (k + rank)
            total[cand.note_id] = total.get(cand.note_id, 0.0) + contrib
            best_s[cand.note_id] = max(best_s.get(cand.note_id, 0.0), s)
            label = cand.tag if name == "scan" and cand.tag else name
            # Детерминированное совпадение (id/алиас/заголовок) — причина, а не фон: его метка
            # побеждает при любом вкладе FTS; слабый ярус ``scan:fm`` честно уступает.
            strong = name == "scan" and SCAN_TIERS.get(cand.tag, 0.0) >= STRONG_TIER
            label_weight = contrib + (1.0 if strong else 0.0)
            cur = top_contrib.get(cand.note_id)
            key = (label_weight, -_STAGE_TIE.get(name, 9), label)
            if cur is None or key[:2] > cur[:2]:
                top_contrib[cand.note_id] = key
            meta.setdefault(cand.note_id, cand)
            seen_stages.setdefault(cand.note_id, {})[name] = (rank, s)

    scan_w = w.get("scan", 1.0)
    if boosts:
        for nid, share in boosts.items():
            if nid in total and share > 0:
                total[nid] += share * scan_w / (k + 1)

    # Знаменатель — максимум из теоретического и фактического: буст может поднять сумму выше
    # «первого места везде», и клиппинг в 1.0 до сортировки склеил бы подобранные заметки в ничью.
    denom = max(max_total, max(total.values()))
    fused = [
        Fused(
            note_id=nid,
            score=total[nid] / denom,
            matched_by=top_contrib[nid][2],
            layer=meta[nid].layer,
            date=meta[nid].date,
            stages=seen_stages[nid],
        )
        for nid in total
    ]
    fused.sort(key=lambda f: f.note_id)
    fused.sort(key=lambda f: f.date or "", reverse=True)
    fused.sort(key=lambda f: layer_priority(f.layer), reverse=True)
    fused.sort(key=lambda f: best_s[f.note_id], reverse=True)
    fused.sort(key=lambda f: round(f.score, 12), reverse=True)
    return fused


def apply_pin(
    fused: list[Fused],
    pinned: Sequence[str],
    *,
    top: int = 3,
    extra: Mapping[str, Fused] | None = None,
) -> list[Fused]:
    """Закрепить хабы ``pinned`` в голове выдачи (до ``top`` штук), остальным порядок сохранить.

    Закрепляемые идут по убыванию их шкалы (при равенстве — порядок ``pinned``). ``extra``
    — готовые :class:`Fused` для хабов, которых слияние НЕ нашло (заходят в выдачу только
    через пин). Закреплённому ставится ``matched_by="pin:client"``, а ``score`` поднимается
    до оценки следующей незакреплённой заметки, чтобы выдача оставалась отсортированной
    по ``score`` (контракт читателей). Нет закрепляемых → список как есть.
    """
    if not pinned:
        return fused
    by_id = {f.note_id: f for f in fused}
    chosen: list[Fused] = []
    for nid in dict.fromkeys(pinned):
        hit = by_id.get(nid) or (extra or {}).get(nid)
        if hit is not None:
            chosen.append(hit)
    if not chosen:
        return fused
    order = {nid: i for i, nid in enumerate(pinned)}
    chosen.sort(key=lambda f: (-f.score, order.get(f.note_id, 0)))
    chosen = chosen[: max(1, int(top))]
    chosen_ids = {f.note_id for f in chosen}
    rest = [f for f in fused if f.note_id not in chosen_ids]
    ceiling = rest[0].score if rest else 0.0
    for f in chosen:
        f.matched_by = "pin:client"
        f.score = max(f.score, ceiling)
    return chosen + rest


def apply_pin_top(
    fused: list[Fused],
    pinned: Sequence[str],
    *,
    top: int = 3,
    extra: Mapping[str, Fused] | None = None,
) -> list[Fused]:
    """Закрепление хаба как ГАРАНТИЯ «в топ-``top``», а не «первым» (RETR-RERANK-1 п.3).

    Для выдачи после реранкера: хаб, уже попавший в первые ``top``, остаётся где его поставил
    реранкер (первым идёт лучший по реранкеру — пользователь просил документ, а не хаб); хаб
    ниже ``top`` (или найденный только пином, ``extra``) поднимается на последние места топа.
    ``score`` поднятого хаба выравнивается к оценке вытесненной им заметки, чтобы выдача
    оставалась отсортированной по ``score``. Закреплённым ставится ``matched_by="pin:client"``.
    Нет закрепляемых → список как есть.
    """
    if not pinned:
        return fused
    by_id = {f.note_id: f for f in fused}
    chosen: list[Fused] = []
    for nid in dict.fromkeys(pinned):
        hit = by_id.get(nid) or (extra or {}).get(nid)
        if hit is not None:
            chosen.append(hit)
    if not chosen:
        return fused
    top = max(1, int(top))
    chosen = chosen[:top]
    chosen_ids = {f.note_id for f in chosen}
    ordered = [f for f in fused if f.note_id not in chosen_ids]
    position = {f.note_id: i for i, f in enumerate(fused)}
    kept = sorted(
        (f for f in chosen if position.get(f.note_id, len(fused)) < top),
        key=lambda f: position[f.note_id],
    )
    lowered = sorted(
        (f for f in chosen if position.get(f.note_id, len(fused)) >= top),
        key=lambda f: position.get(f.note_id, len(fused)),
    )
    # Уже стоявшие в топе хабы — на своих местах (вставка по возрастанию позиции сохраняет их
    # относительный порядок среди остальных), поднятые — в хвост топа.
    result = list(ordered)
    for f in sorted(kept, key=lambda f: position[f.note_id]):
        result.insert(min(position[f.note_id], len(result)), f)
    for j, f in enumerate(lowered):
        slot = max(0, top - len(lowered) + j)
        idx = min(slot, len(result))
        result.insert(idx, f)
        if idx + 1 < len(result):
            f.score = max(f.score, result[idx + 1].score)
    for f in chosen:
        f.matched_by = "pin:client"
    return result
