"""RETR-RERANK-1 п.1 — cross-encoder вторым этапом ранжирования ``find_notes``.

Первый этап (скан frontmatter ∪ FTS ∪ семантика → :func:`core.retrieval.rank.fuse`) отвечает за
ПОЛНОТУ пула; порядок внутри пула он ставит по рангам ступеней и не видит пары «запрос ↔ текст».
Второй этап читает пару целиком: локальный ``BAAI/bge-reranker-v2-m3`` (``CrossEncoder``, та же
семья, что эмбеддер BGE-M3) переоценивает верхние :func:`rerank_pool` кандидатов fused, итог —
``α·score01 + (1-α)·fused`` (:func:`blend`).

Это НЕ LLM-генерация и не удалённый сервис: локальная модель весов, без сети (core ⊥ LLM). Модель
грузится лениво и один раз на процесс (:func:`get_reranker`), устройство — как у эмбеддера
(``DT_RERANK_DEVICE`` → ``DT_EMBED_DEVICE`` → MPS → CUDA → CPU), с тем же откатом на CPU при
OOM/сбое ядра MPS. Кэш — ``models/`` (:func:`core.config.models_path`); докачка — только явным
``DT_MODEL_DOWNLOAD=1`` (или ``DT_EMBED_ALLOW_DOWNLOAD=1``, как у эмбеддера).

Деградация — с кодом, не исключением: модели нет / нельзя качать / сбой →
:class:`RerankUnavailable`, вызывающий (``find``) отдаёт порядок fused и
``warning(code="rerank_unavailable")`` (§9 п.22).
"""

from __future__ import annotations

import logging
import math
import os
import re
import threading
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Any

from core.embeddings import _detect_device, _is_oom, _oom_retries

logger = logging.getLogger(__name__)

__all__ = [
    "RERANK_MODEL",
    "CODE_RERANK_UNAVAILABLE",
    "DEFAULT_POOL",
    "DEFAULT_ALPHA",
    "RerankCand",
    "RerankUnavailable",
    "Reranker",
    "get_reranker",
    "reset_reranker",
    "rerank_enabled",
    "semantic_always_enabled",
    "rerank_pool",
    "rerank_alpha",
    "max_length",
    "chunk_chars",
    "body_chars",
    "chunk_pair_text",
    "scan_pair_text",
    "rerank",
    "blend",
    "sigmoid",
    "model_status",
]

RERANK_MODEL = "BAAI/bge-reranker-v2-m3"
CODE_RERANK_UNAVAILABLE = "rerank_unavailable"

# Решение К. 29.10 по живой абляции (с гейтом «одно слово» и семантикой по лестнице): пул 15 /
# 512 токенов - recall@5 0.87, MRR 0.79, хвост 1.0, p50 ~2,7 с; 20/256 - 0.83/0.73 при 2,1 с.
DEFAULT_POOL = 15
DEFAULT_ALPHA = 0.7
MAX_LENGTH = 512
CHUNK_CHARS = 1200      # текст чанка в паре
BODY_CHARS = 800        # голова тела у скан-хита без чанка

_ENABLE_ENV = "DT_RERANK"
_POOL_ENV = "DT_RERANK_POOL"
_ALPHA_ENV = "DT_RERANK_ALPHA"
_DEVICE_ENV = "DT_RERANK_DEVICE"
_SEM_ALWAYS_ENV = "DT_FIND_SEMANTIC_ALWAYS"
_MAXLEN_ENV = "DT_RERANK_MAX_LENGTH"
_CHUNK_ENV = "DT_RERANK_CHUNK_CHARS"
_BODY_ENV = "DT_RERANK_BODY_CHARS"

_ALLOW_PATTERNS = [
    "config.json",
    "tokenizer.json",
    "tokenizer_config.json",
    "special_tokens_map.json",
    "sentencepiece.bpe.model",
    "*.safetensors",
]

_TRUE = ("1", "true", "yes", "on")


def _env_flag(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or not raw.strip():
        return default
    return raw.strip().lower() in _TRUE


def rerank_enabled() -> bool:
    """Реранкер включён по умолчанию (env ``DT_RERANK``; дефолт ВЫКЛ — решает К. по числам)."""
    return _env_flag(_ENABLE_ENV, False)


def semantic_always_enabled(default: bool | None = None) -> bool:
    """Семантическая ступень всегда (``DT_FIND_SEMANTIC_ALWAYS``).

    Дефолт — ``default`` (эффективное включение реранкера у вызова, явный аргумент ``rerank``),
    а без него — значение ``DT_RERANK``.
    """
    # Абляция 29.10: «семантика всегда» при реранкере роняет recall@5 0.85 → 0.82 (гипотеза ТЗ
    # не подтвердилась) - дефолт ВЫКЛ независимо от DT_RERANK; включается только явно.
    return _env_flag(_SEM_ALWAYS_ENV, False if default is None else default)


def rerank_pool() -> int:
    """Сколько верхних fused переоценивает реранкер (``DT_RERANK_POOL``, дефолт 15)."""
    raw = os.environ.get(_POOL_ENV, "").strip()
    try:
        value = int(float(raw))
    except (TypeError, ValueError):
        return DEFAULT_POOL
    return value if value >= 1 else DEFAULT_POOL


def rerank_alpha() -> float:
    """Вес реранкера в итоговой оценке (``DT_RERANK_ALPHA`` ∈ [0, 1], дефолт 0,7)."""
    raw = os.environ.get(_ALPHA_ENV, "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_ALPHA
    return value if 0.0 <= value <= 1.0 else DEFAULT_ALPHA


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    try:
        value = int(float(raw))
    except (TypeError, ValueError):
        return default
    return value if value >= 1 else default


def max_length() -> int:
    """Токенов на пару (``DT_RERANK_MAX_LENGTH``, дефолт 512): цена инференса растёт с длиной."""
    return _env_int(_MAXLEN_ENV, MAX_LENGTH)


def chunk_chars() -> int:
    """Обрезка текста чанка в паре (``DT_RERANK_CHUNK_CHARS``, дефолт 1200)."""
    return _env_int(_CHUNK_ENV, CHUNK_CHARS)


_MIN_TOKENS_ENV = "DT_RERANK_MIN_TOKENS"
MIN_TOKENS = 2
# Слово: три и более букв ИЛИ двухбуквенная аббревиатура ЗАГЛАВНЫМИ (КП, ГМ, ТЗ - у К. несут смысл).
_WORD_RE = re.compile(r"[^\W\d_]{3,}|(?<![^\W\d_])[A-ZА-ЯЁ]{2}(?![^\W\d_])", re.UNICODE)


def min_tokens() -> int:
    """Минимум значимых слов запроса для реранкера (``DT_RERANK_MIN_TOKENS``, дефолт 2).

    Приемка 29.10: на запросе из ОДНОГО редкого слова («довыгрузите», q11) точное лексическое
    совпадение BM25 надежнее cross-encoder'а - реранкер опускал цель с 1-го места на 3-е.
    Одно слово - порядок слияния; переоценка - от двух значимых слов.
    """
    return _env_int(_MIN_TOKENS_ENV, MIN_TOKENS)


def query_token_count(query: str) -> int:
    """Число значимых слов запроса (буквы ≥ 3 или аббревиатура из 2 заглавных; цифры не в счет)."""
    return len(_WORD_RE.findall(str(query or "")))


def body_chars() -> int:
    """Обрезка головы тела у скан-хита (``DT_RERANK_BODY_CHARS``, дефолт 800)."""
    return _env_int(_BODY_ENV, BODY_CHARS)


def _download_allowed() -> bool:
    """Разовая онлайн-докачка модели: ``DT_MODEL_DOWNLOAD`` или ``DT_EMBED_ALLOW_DOWNLOAD``."""
    from core.embeddings import _download_allowed as embed_allowed

    return _env_flag("DT_MODEL_DOWNLOAD", False) or embed_allowed()


class RerankUnavailable(RuntimeError):
    """Реранкер не может работать (модель не скачана / сбой загрузки или инференса).

    ``cache_miss`` — модели нет в кэше: повторная проверка на следующем запросе дешёвая и
    подхватит докачанную модель; прочие сбои запоминаются на процесс.
    """

    def __init__(self, message: str, *, cache_miss: bool = False) -> None:
        super().__init__(message)
        self.cache_miss = cache_miss


@dataclass(frozen=True)
class RerankCand:
    """Кандидат реранкера: заметка + готовый текст пары (заголовок · текст)."""

    note_id: str
    text: str


def sigmoid(x: float) -> float:
    """Логит → (0, 1), без переполнения на больших по модулю значениях."""
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    e = math.exp(x)
    return e / (1.0 + e)


def chunk_pair_text(title: str, heading_path: str, text: str) -> str:
    """Текст пары для FTS/семантического кандидата: «title · heading_path» + чанк (≤ 1200)."""
    head = " · ".join(p for p in (title.strip(), heading_path.strip()) if p)
    body = (text or "").strip()[: chunk_chars()]
    return f"{head}\n{body}".strip() if head else body


def scan_pair_text(title: str, h1: str, aliases: Sequence[str], body_head: str) -> str:
    """Текст пары для скан-хита без чанка: «title · H1 · aliases» + голова тела (≤ 800)."""
    parts: list[str] = []
    for p in (title, h1, *aliases):
        p = str(p).strip()
        if p and p not in parts:
            parts.append(p)
    head = " · ".join(parts)
    body = (body_head or "").strip()[: body_chars()]
    return f"{head}\n{body}".strip() if head else body


class Reranker:
    """Локальный cross-encoder ``bge-reranker-v2-m3``: ленивая загрузка, откат MPS→CPU при OOM."""

    def __init__(
        self,
        device: str | None = None,
        cache_folder: str | None = None,
        model_factory: Callable[[str], Any] | None = None,
    ) -> None:
        self._device = device or os.environ.get(_DEVICE_ENV, "").strip() or _detect_device()
        self._cache_folder = cache_folder
        self._factory = model_factory  # тесты: подставная модель вместо CrossEncoder
        self._model: Any = None
        self._lock = threading.Lock()
        self._batch_size = 16 if self._device in ("mps", "cuda") else 8
        self.fallback_reason = ""
        self.load_seconds: float | None = None
        self._load_error: RerankUnavailable | None = None

    # -- состояние ---------------------------------------------------------------------- #
    @property
    def device(self) -> str:
        return self._device

    @property
    def loaded(self) -> bool:
        return self._model is not None

    # -- загрузка ----------------------------------------------------------------------- #
    def _resolve_path(self, cache: str) -> str:
        from huggingface_hub import snapshot_download

        try:
            return snapshot_download(
                RERANK_MODEL, cache_dir=cache, allow_patterns=_ALLOW_PATTERNS,
                local_files_only=True,
            )
        except Exception as exc:
            if not _download_allowed():
                raise RerankUnavailable(
                    f"модель {RERANK_MODEL!r} не найдена в локальном кэше ({cache}); поиск идёт "
                    "без реранкера. Разовая докачка (~1–2 ГБ): DT_MODEL_DOWNLOAD=1 и первый запрос"
                    f" (исходная ошибка: {type(exc).__name__})",
                    cache_miss=True,
                ) from exc
            try:
                return snapshot_download(
                    RERANK_MODEL, cache_dir=cache, allow_patterns=_ALLOW_PATTERNS
                )
            except Exception as dl_exc:
                raise RerankUnavailable(
                    f"докачка {RERANK_MODEL!r} не удалась: {type(dl_exc).__name__}: {dl_exc}"
                ) from dl_exc

    def _load_on(self, device: str) -> Any:
        if self._factory is not None:
            return self._factory(device)
        from core.config import models_path

        cache = self._cache_folder or str(models_path())
        local_path = self._resolve_path(cache)
        from sentence_transformers import CrossEncoder

        return CrossEncoder(
            local_path, device=device, max_length=max_length(), local_files_only=True
        )

    def _ensure_model(self) -> None:
        if self._model is not None:
            return
        if self._load_error is not None and not self._load_error.cache_miss:
            raise self._load_error  # сбой, не промах кэша: не повторяем загрузку на каждый запрос
        started = time.perf_counter()
        try:
            self._model = self._load_on(self._device)
        except RerankUnavailable as exc:
            self._load_error = exc
            raise
        except Exception as exc:
            if self._device == "mps" and self._switch_to_cpu("загрузка модели", exc):
                self.load_seconds = round(time.perf_counter() - started, 2)
                return
            err = RerankUnavailable(
                f"не удалось загрузить реранкер {RERANK_MODEL!r} на {self._device}: "
                f"{type(exc).__name__}: {str(exc)[:200]}"
            )
            self._load_error = err
            raise err from exc
        self._load_error = None
        self.load_seconds = round(time.perf_counter() - started, 2)
        logger.info(
            "[rerank] модель %s загружена на %s за %.1f с", RERANK_MODEL, self._device,
            self.load_seconds,
        )

    def _switch_to_cpu(self, stage: str, exc: BaseException) -> bool:
        """MPS→CPU (sticky на процесс), причина — в :attr:`fallback_reason` и WARNING."""
        self.fallback_reason = f"mps→cpu ({stage}): {type(exc).__name__}: {exc}"[:400]
        logger.warning(
            "[rerank] ФОЛБЭК MPS→CPU (%s): %r — реранкер продолжит на CPU, медленнее", stage, exc
        )
        try:
            self._model = self._load_on("cpu")
        except Exception as cpu_exc:  # noqa: BLE001
            logger.error("[rerank] загрузка на CPU после сбоя MPS не удалась: %r", cpu_exc)
            self._model = None
            return False
        self._device = "cpu"
        self._batch_size = 8
        return True

    # -- инференс ----------------------------------------------------------------------- #
    def _predict(self, pairs: list[tuple[str, str]], batch: int) -> list[float]:
        import numpy as np

        try:
            import torch

            identity: Any = torch.nn.Identity()
        except Exception:  # noqa: BLE001 — фейк-модель в тестах без torch
            identity = None
        kwargs: dict[str, Any] = {"batch_size": batch, "show_progress_bar": False}
        if identity is not None and self._factory is None:
            kwargs["activation_fn"] = identity  # сырые логиты; сигмоиду берём сами
        scores = self._model.predict(pairs, **kwargs)
        return [float(x) for x in np.asarray(scores, dtype=np.float64).reshape(-1)]

    def score(self, query: str, texts: Sequence[str]) -> list[float]:
        """Логиты пар (query, text) в порядке ``texts``. Сбой → :class:`RerankUnavailable`."""
        if not texts:
            return []
        pairs = [(query, t) for t in texts]
        with self._lock:
            self._ensure_model()
            batch = self._batch_size
            failures = 0
            limit = _oom_retries()
            while True:
                try:
                    return self._predict(pairs, batch)
                except Exception as exc:
                    if self._device in ("mps", "cuda") and _is_oom(exc):
                        failures += 1
                        if failures <= limit and batch > 1:
                            smaller = max(1, batch // 2)
                            logger.warning(
                                "[rerank] OOM (%s) — батч %d→%d, повтор на %s",
                                type(exc).__name__, batch, smaller, self._device,
                            )
                            batch = self._batch_size = smaller
                            continue
                    if self._device == "mps":
                        if self._switch_to_cpu("inference", exc):
                            batch = self._batch_size
                            failures = 0
                            continue
                    raise RerankUnavailable(
                        f"сбой реранкера на {self._device}: {type(exc).__name__}: "
                        f"{str(exc)[:200]}"
                    ) from exc


# --------------------------------------------------------------------------- #
# Один экземпляр на процесс                                                    #
# --------------------------------------------------------------------------- #
_instance: Reranker | None = None
_instance_lock = threading.Lock()


def get_reranker() -> Reranker:
    """Процессный синглтон (в MCP-сервере — один экземпляр на процесс)."""
    global _instance
    with _instance_lock:
        if _instance is None:
            _instance = Reranker()
        return _instance


def reset_reranker(instance: Reranker | None = None) -> None:
    """Сбросить/подменить синглтон (тесты)."""
    global _instance
    with _instance_lock:
        _instance = instance


def rerank(
    query: str, cands: Sequence[RerankCand], reranker: Reranker | None = None
) -> list[tuple[str, float]]:
    """``[(note_id, score01)]`` в порядке ``cands`` (``score01`` = сигмоида логита).

    Порядок НЕ меняет — сортировку и смешение с fused делает вызывающий (:func:`blend`).
    Сбой → :class:`RerankUnavailable`.
    """
    if not cands:
        return []
    rr = reranker or get_reranker()
    logits = rr.score(query, [c.text for c in cands])
    return [(c.note_id, sigmoid(x)) for c, x in zip(cands, logits, strict=True)]


def blend(rerank_score: float, fused_score: float, alpha: float) -> float:
    """``α·score01 + (1-α)·fused`` — итоговая оценка кандидата пула."""
    return alpha * rerank_score + (1.0 - alpha) * fused_score


def model_status() -> dict[str, Any]:
    """Дешёвый срез для доктора: ``{present, path, device, loaded, load_seconds, fallback}``.

    Модель НЕ грузится: проверяется только наличие снимка в кэше ``models/``.
    """
    from core.config import models_path

    out: dict[str, Any] = {
        "model": RERANK_MODEL, "present": False, "path": "", "enabled": rerank_enabled(),
    }
    try:
        from huggingface_hub import snapshot_download

        out["path"] = snapshot_download(
            RERANK_MODEL, cache_dir=str(models_path()), allow_patterns=_ALLOW_PATTERNS,
            local_files_only=True,
        )
        out["present"] = True
    except Exception:  # noqa: BLE001, S110 — нет снимка = present False
        pass
    inst = _instance
    out["device"] = inst.device if inst is not None else (
        os.environ.get(_DEVICE_ENV, "").strip() or _detect_device()
    )
    out["loaded"] = bool(inst and inst.loaded)
    out["load_seconds"] = inst.load_seconds if inst is not None else None
    out["fallback"] = inst.fallback_reason if inst is not None else ""
    return out
