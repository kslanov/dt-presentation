"""Hybrid retrieval (architecture §5).

On each query: (1) metadata pre-filter (caller ``filters`` plus a default
``status == active`` when not overridden) → (2) vector (BGE-M3) + FTS lexical in
parallel → (3) Reciprocal Rank Fusion (RRF) → top-K. LanceDB performs 1–3
natively via its hybrid search API with an RRF reranker.

Cross-encoder reranking (BGE-reranker-v2-m3) is NOT done here: ``search``/``retrieve`` stay
RRF-only. RETR-RERANK-1 adds it as the second stage of the interactive ``find_notes`` pipeline
(``core/retrieval/rerank.py``, ``core/retrieval/find.py``; architecture §5) — a local model,
off by default (``DT_RERANK``), degrading with the ``rerank_unavailable`` code. RRF fusion
(step 3) IS used everywhere.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import lancedb
from lancedb.rerankers import RRFReranker

from core.chunking import section_id, split_context_prefix
from core.config import lancedb_path
from core.embeddings import embed_query
from core.retrieval.index import TABLE_NAME

__all__ = [
    "SearchResult",
    "search",
    "lexical_search",
    "CURATED_BOOST",
    "CURRENT_BOOST",
]

# List-valued columns need membership predicates rather than equality.
_LIST_FIELDS = ("product", "tags")

# Провенанс выходов 07-outputs (``prompt.md``/``sources.md``: промпт целиком, образец оформления,
# ``[Task]`` прошлых генераций, таблица источников) - след, а не знание. По умолчанию в выдачу не
# идет: 29.10 (золотая g1 в Kimi) слайс client_context принес ``[Task]`` прошлого выхода, и модель
# хоста взяла его как постановку своей задачи. Явный фильтр по ``type``/``note_id`` - отдает.
PROVENANCE_TYPES = ("output-prompt", "output-sources")

# Three-layer corpus model (CORPUS-LAYER-1, design docs/design-3-layer-corpus.md).
# A chunk's layer comes from its ``corpus`` metadata:
#   * ``vault``   (A) — curated twin synthesis            → strongest uplift
#   * ``current`` (B) — live raw material, relevant now   → medium uplift
#   * ``legacy``  (C) — archived raw source              → no uplift (×1.0)
# Missing/empty/unknown ⇒ ``vault`` (backward compatibility; pre-Phase-5 rows).
#
# The uplift is applied multiplicatively to the RRF relevance score so it is
# scale-robust: a chunk of layer L gets ``score * (1 + BOOST[L])``. This is a
# *nudge*, not an override — at similar relevance the higher layer wins (concept
# queries surface synthesis, then current material, then archive), but a
# much-more-relevant legacy chunk still ranks above a barely-matching vault one
# (narrow factual queries still reach archived source material).
#
# The constants are the *additive delta* on the multiplier (vault ×1.25,
# current ×1.20, legacy ×1.0). The invariant on the effective multipliers is
# ``(1 + CURATED_BOOST) > (1 + CURRENT_BOOST) > 1.0`` — i.e. A > B > C — which
# holds as long as ``CURATED_BOOST > CURRENT_BOOST > 0``. Values are a reasonable
# default; final tuning is a D7-eval concern (ТЗ CORPUS-LAYER-1).
CURATED_BOOST = 0.25  # layer A (vault) — unchanged, keeps prior ranking identical
CURRENT_BOOST = 0.20  # layer B (current) — NEW
# When boosting, fetch a larger candidate pool before re-ranking so a boosted hit
# just outside the top-K can be promoted into it. Pool = k × factor, capped.
_BOOST_POOL_FACTOR = 3
_BOOST_POOL_MAX = 60


@dataclass
class SearchResult:
    text: str
    score: float
    note_id: str
    source_path: str
    heading_path: str
    metadata: dict[str, Any] = field(default_factory=dict)


def _escape(value: Any) -> str:
    """Escape a value for a single-quoted SQL literal."""
    return str(value).replace("'", "''")


# The raw layers (uncurated source material) and the full layer set.
_RAW_LAYERS = ("current", "legacy")


def _corpus_layers(value: Any) -> tuple[str, ...] | None:
    """Resolve a ``corpus`` filter value to the concrete layers it admits.

    Returns ``None`` when the value places *no* corpus constraint (all three
    layers): ``None`` itself or the explicit ``"both"``. Otherwise a tuple of
    layer names:

    * ``"vault"`` / ``"current"`` / ``"legacy"`` → that single layer;
    * ``"raw"`` → ``("current", "legacy")`` — all raw source, no curated vault;
    * a list/tuple → taken verbatim (each entry a layer name), for policies that
      want an arbitrary combination.

    Backward compatible: ``None`` ⇒ all three (as before), and the single-value
    cases keep the historical ``vault``/``legacy`` behaviour.
    """
    if value is None or value == "both":
        return None
    if value == "raw":
        return _RAW_LAYERS
    if isinstance(value, (list, tuple)):
        return tuple(str(v) for v in value)
    return (str(value),)


def _corpus_predicate(value: Any) -> str | None:
    """SQL predicate for a ``corpus`` filter value (None ⇒ no constraint).

    ``vault`` also matches rows with no/empty corpus, so a pre-Phase-5 index
    (column absent → run a full reindex) and old rows are treated as curated
    vault by default (ТЗ: missing ⇒ ``corpus = "vault"``).
    """
    layers = _corpus_layers(value)
    if layers is None:
        return None
    parts: list[str] = []
    for layer in layers:
        if layer == "vault":
            parts.append("(corpus = 'vault' OR corpus IS NULL OR corpus = '')")
        else:
            parts.append(f"corpus = '{_escape(layer)}'")
    if len(parts) == 1:
        return parts[0]
    return "(" + " OR ".join(parts) + ")"


def _status_clause(*statuses: str) -> str:
    """``status`` из списка либо отсутствует (пусто/NULL = активна, п.10)."""
    parts = [f"status = '{s}'" for s in statuses] + ["status = ''", "status IS NULL"]
    return "(" + " OR ".join(parts) + ")"


def _provenance_clause() -> str:
    """``type`` не из :data:`PROVENANCE_TYPES`; нет ``type`` (пусто/NULL) - обычная заметка."""
    parts = [f"type != '{t}'" for t in PROVENANCE_TYPES]
    return "(type IS NULL OR type = '' OR (" + " AND ".join(parts) + "))"


def _build_where(filters: dict[str, Any] | None, default_active: bool) -> str | None:
    """Translate filters into a LanceDB SQL ``where`` clause.

    Scalar fields → equality; list fields (``product``, ``tags``) → membership.
    ``corpus``/``client``/``section``/``era`` are ordinary scalars (Phase 5).
    ``corpus`` is special: it resolves to a *set of layers* (see
    :func:`_corpus_layers`) — ``vault``/``current``/``legacy`` single layers,
    ``raw`` = current+legacy, a list = any combination, ``both``/``None`` = all
    three.

    The default-active clause is scope-aware: a vault-only scope keeps ``status =
    'active'``; current/legacy notes are ``status = 'raw'`` so a scope that
    admits them must not drop them. A mixed scope (vault + raw layers, incl. the
    all-three default) admits both ``active`` (curated) and ``raw``; a raw-only
    scope applies no status filter (all its notes are raw).

    RETR-CHUNK-1 п.10: заметка БЕЗ ``status`` (пусто/NULL) — активна, а ``final`` (закрытый
    выход) допускается наравне с ``active``: выходы 07-outputs не имели ``status`` и целиком
    выпадали из FTS и семантики (q24/q26). ``archived``/``draft``/прочее — по-прежнему нет.
    """
    filters = dict(filters or {})
    layers = _corpus_layers(filters.get("corpus"))
    clauses: list[str] = []

    if default_active and "status" not in filters:
        has_vault = layers is None or "vault" in layers
        has_raw = layers is None or any(layer in _RAW_LAYERS for layer in layers)
        if has_vault and has_raw:
            clauses.append(_status_clause("active", "raw", "final"))
        elif has_vault:
            clauses.append(_status_clause("active", "final"))
        # raw-only scope (current/legacy) ⇒ no active filter (its notes are raw)

    # Провенанс выходов - вне выдачи по умолчанию (см. PROVENANCE_TYPES); явный type/note_id -
    # вызывающий знает, что берет.
    if default_active and "type" not in filters and "note_id" not in filters:
        clauses.append(_provenance_clause())

    for key, value in filters.items():
        if key == "corpus":
            predicate = _corpus_predicate(value)
            if predicate:
                clauses.append(predicate)
        elif key in _LIST_FIELDS:
            clauses.append(f"array_has_any({key}, ['{_escape(value)}'])")
        else:
            clauses.append(f"{key} = '{_escape(value)}'")

    return " AND ".join(clauses) if clauses else None


def _layer(result: SearchResult) -> str:
    """The corpus layer of a result: ``"vault"`` | ``"current"`` | ``"legacy"``.

    Read from ``metadata.corpus``; anything missing/empty/unknown ⇒ ``"vault"``
    (backward compatibility — pre-Phase-5 rows and old vault notes). The boost is
    keyed on ``corpus`` (the layer), *not* on the ``curated`` flag, which stays in
    the index untouched for compatibility.
    """
    corpus = result.metadata.get("corpus")
    if corpus in ("current", "legacy"):
        return str(corpus)
    return "vault"


def _layer_multiplier(layer: str) -> float:
    """Score multiplier for a layer: vault ×(1+CURATED), current ×(1+CURRENT), legacy ×1."""
    if layer == "vault":
        return 1 + CURATED_BOOST
    if layer == "current":
        return 1 + CURRENT_BOOST
    return 1.0  # legacy — no uplift


def _apply_layer_boost(results: list[SearchResult], k: int) -> list[SearchResult]:
    """Uplift scores by the result's corpus layer, re-sort, return top-K.

    Pure function (testable without an index): multiplies each result's score by
    its layer multiplier (:func:`_layer_multiplier` — vault > current > legacy),
    re-sorts descending, and returns the top ``k``. Stable for ties.

    Backward compatible: with no ``corpus=current`` results present, only vault
    (×1+CURATED) and legacy (×1.0) multipliers apply — identical to the prior
    binary curated boost, so ranking of an existing vault/legacy index is
    unchanged.
    """
    for result in results:
        result.score *= _layer_multiplier(_layer(result))
    results.sort(key=lambda r: r.score, reverse=True)
    return results[:k]


def _to_result(row: dict[str, Any]) -> SearchResult:
    # LanceDB hybrid returns a fused relevance score under `_relevance_score`;
    # an FTS-only search (:func:`lexical_search`) returns a BM25 `_score`; a pure
    # vector search returns a `_distance`. Fall back through all three.
    score = row.get("_relevance_score")
    if score is None:
        score = row.get("_score")
    if score is None:
        score = row.get("_distance", 0.0)
    metadata = {
        k: v
        for k, v in row.items()
        if k not in {"vector", "text", "_relevance_score", "_distance", "_score"}
    }
    # RETR-CHUNK-1 п.1: контекстный префикс чанка живёт в ``text`` ради FTS/эмбеддинга, а при показе
    # отделён — ``text`` без него, сам префикс в ``metadata["context_prefix"]`` (пусто — нет).
    prefix, body = split_context_prefix(row.get("text", "") or "")
    metadata["context_prefix"] = prefix
    # п.5: ключ родительской секции — из колонок индекса (note_id + путь заголовков), без миграции.
    metadata["section_id"] = section_id(
        str(row.get("note_id", "")), str(row.get("heading_path", ""))
    )
    return SearchResult(
        text=body,
        score=float(score),
        note_id=row.get("note_id", ""),
        source_path=row.get("source_path", ""),
        heading_path=row.get("heading_path", ""),
        metadata=metadata,
    )


def search(
    query: str,
    *,
    filters: dict[str, Any] | None = None,
    k: int = 10,
    default_active: bool = True,
    corpus: str | None = None,
    boost_curated: bool = True,
) -> list[SearchResult]:
    """Hybrid (vector + FTS) search fused with RRF; returns top-K results.

    ``corpus`` constrains the layer: ``None`` searches all three (default),
    ``"vault"``/``"current"``/``"legacy"`` filter to that layer, ``"raw"`` =
    current+legacy, a list = any combination (merged into ``filters`` as a
    scalar; see :func:`_corpus_layers`). ``boost_curated`` (default on) applies
    the per-layer score uplift after fusion (vault > current > legacy; see
    :func:`_apply_layer_boost`); pass ``False`` to rank purely by relevance.
    Backward compatible: existing callers (no ``corpus``/``boost_curated``) keep
    working — the only change is higher-layer hits now sort first at equal
    relevance.
    """
    filters = dict(filters or {})
    if corpus is not None and "corpus" not in filters:
        filters["corpus"] = corpus

    db = lancedb.connect(str(lancedb_path()))
    table = db.open_table(TABLE_NAME)

    query_vector = embed_query(query)

    builder = (
        table.search(query_type="hybrid")
        .text(query)
        .vector(query_vector.tolist())
        .rerank(reranker=RRFReranker())
    )

    where = _build_where(filters, default_active)
    if where:
        builder = builder.where(where, prefilter=True)

    # Oversample when boosting so a higher-layer hit just outside top-K can be lifted in.
    fetch_k = min(k * _BOOST_POOL_FACTOR, _BOOST_POOL_MAX) if boost_curated else k
    fetch_k = max(fetch_k, k)
    rows = builder.limit(fetch_k).to_list()
    results = [_to_result(row) for row in rows]

    if boost_curated:
        return _apply_layer_boost(results, k)
    return results[:k]


def lexical_search(
    query: str,
    *,
    filters: dict[str, Any] | None = None,
    k: int = 10,
    default_active: bool = True,
    corpus: str | None = None,
) -> list[SearchResult]:
    """FTS-only (BM25) lexical search — **never embeds**, so BGE is not loaded.

    The lexical rung of the two-tier ``find_notes`` pipeline (ТЗ RETR-LEGACY
    FIX-1): the same scope/status ``where`` clause as :func:`search` (via
    :func:`_build_where`), but ``query_type="fts"`` with no query vector, so the
    embedding model is never touched. Returns raw BM25-ranked hits (no curated
    boost — that is a fusion-stage nudge, irrelevant to a pure lexical rung).
    Empty/whitespace ``query`` → ``[]`` (an FTS search needs a term).
    """
    if not query or not query.strip():
        return []
    filters = dict(filters or {})
    if corpus is not None and "corpus" not in filters:
        filters["corpus"] = corpus

    db = lancedb.connect(str(lancedb_path()))
    table = db.open_table(TABLE_NAME)

    builder = table.search(query, query_type="fts")
    where = _build_where(filters, default_active)
    if where:
        builder = builder.where(where, prefilter=True)
    rows = builder.limit(k).to_list()
    return [_to_result(row) for row in rows]
