"""ADAPTER-HONEST-1 п.5 — liveness прогона по ПРОГРЕССУ, а не по pid.

Инцидент 2026-10-13: ночной ``dt_sync index`` повис после сна ноутбука на вызове моста,
процесс остался жив (S, 45 с CPU за 10 часов), flock держался, и каждый 30-минутный
fast-синк писал «skipped — another run holds the lock». Доктор «Локи прогонов» проверял
живость pid, а не прогресс. Молчащий процесс был неотличим от зависшего.

Решение — **heartbeat в самом lock-файле**: держатель lock'а после взятия flock'а
регистрирует его (:func:`register` пишет в файл ``{pid, mode, started, step}``) и дальше
каждый шаг/бикон-тик/завершённый вызов моста трогает mtime файла (:func:`beat`). Файл
без движения дольше ``DT_RUN_STALL_MIN`` (дефолт 60 мин) при удерживаемом flock — прогон
без прогресса: его снимает сторож (:mod:`core.operational.runwatch`), о нём предупреждает
doctor. Всё best-effort и дёшево: наблюдаемость никогда не роняет наблюдаемую операцию.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

import contextlib
import fcntl
import json
import os
import threading
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

__all__ = [
    "DEFAULT_STALL_MIN",
    "STALL_ENV",
    "stall_minutes",
    "register",
    "unregister",
    "beat",
    "read_info",
    "heartbeat_age_min",
    "index_sync_lock",
    "hold",
    "HoldResult",
    "RunLockBusy",
    "DEFAULT_WAIT_S",
]

STALL_ENV = "DT_RUN_STALL_MIN"
DEFAULT_STALL_MIN = 60.0

# Не чаще раза в столько секунд реально трогаем файл (beat() зовут из горячих циклов).
_BEAT_MIN_INTERVAL_S = 1.0

# Lock-файлы, которые держит ЭТОТ процесс: path → последняя метка шага.
_ACTIVE: dict[Path, dict[str, Any]] = {}
_last_beat = float("-inf")


def index_sync_lock(sync_lock: Path) -> Path:
    """Lock режима ``index`` рядом с lock'ом ``fast`` (``dt-sync.lock`` → ``dt-sync-index.lock``).

    WAVE0-HYGIENE п.4 (аудит B5): один lock на оба режима держал fast-синк (почта, Timetta)
    весь день, пока ночной index тянулся до утра — 31 пропуск в рабочие часы за 53 дня.
    Теперь у режимов свои lock'и и они идут параллельно; ``full`` берёт оба.
    """
    p = Path(sync_lock)
    return p.with_name(f"{p.stem}-index{p.suffix}")


def stall_minutes() -> float:
    """Порог «прогон без прогресса», минуты (``DT_RUN_STALL_MIN``, дефолт 60)."""
    raw = (os.environ.get(STALL_ENV) or "").strip()
    try:
        value = float(raw)
    except ValueError:
        return DEFAULT_STALL_MIN
    return value if value > 0 else DEFAULT_STALL_MIN


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _write_info(path: Path, info: dict[str, Any]) -> None:
    """Перезаписать содержимое lock-файла (flock уже наш; файл открыт другим дескриптором
    держателя — пишем через отдельный, flock к содержимому не относится)."""
    with contextlib.suppress(OSError):
        with open(path, "r+") as fh:
            fh.seek(0)
            fh.truncate()
            fh.write(json.dumps(info, ensure_ascii=False))


def register(path: Path, *, mode: str = "", step: str = "") -> None:
    """Объявить lock ``path`` (flock уже взят) живым прогоном этого процесса."""
    p = Path(path)
    info = {"pid": os.getpid(), "mode": mode, "step": step, "started": _now_iso()}
    _ACTIVE[p] = info
    _write_info(p, info)
    beat(force=True)


def unregister(path: Path) -> None:
    """Снять lock с учёта (прогон завершён; сам flock отпускает держатель)."""
    _ACTIVE.pop(Path(path), None)


def beat(step: str | None = None, *, force: bool = False) -> None:
    """Сердцебиение: тронуть mtime всех lock'ов этого процесса (+ записать смену шага).

    Зовётся из мест, где прогон реально продвигается: бикон-тики/смена фазы, завершённый
    вызов моста. Не чаще :data:`_BEAT_MIN_INTERVAL_S`. Без зарегистрированных lock'ов —
    no-op (скрипты и тесты, не державшие lock, ничего не трогают).
    """
    global _last_beat
    if not _ACTIVE:
        return
    now = time.monotonic()
    if not force and step is None and now - _last_beat < _BEAT_MIN_INTERVAL_S:
        return
    _last_beat = now
    for path, info in list(_ACTIVE.items()):
        if step is not None and info.get("step") != step:
            info["step"] = step
            _write_info(path, info)
        else:
            with contextlib.suppress(OSError):
                os.utime(path, None)


def read_info(path: Path) -> dict[str, Any]:
    """Содержимое lock-файла (``{pid, mode, step, started}``); ``{}`` — пусто/нечитаемо
    (lock старого формата или чужого держателя)."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def heartbeat_age_min(path: Path, *, now: float | None = None) -> float | None:
    """Минут с последнего сердцебиения (mtime lock-файла); ``None`` — файла нет."""
    try:
        mtime = Path(path).stat().st_mtime
    except OSError:
        return None
    return max(0.0, ((now if now is not None else time.time()) - mtime) / 60.0)


# --------------------------------------------------------------------------- #
# MAIL-LOCK-1 - один лок, один модуль                                          #
# --------------------------------------------------------------------------- #
# Лок ``dt-sync.lock`` раньше брал только ``dt_sync`` (inline flock), а писатели манифеста почты
# (``ingest_mail``, ``--refilter``, ``dt_mail_repair``) шли мимо него и затирали друг другу индекс
# полной перезаписью из своей копии в памяти (29.10: 45 записей без сайдкара). ``hold`` - единая
# точка взятия: flock + register/heartbeat/unregister + отказ с именем держателя. Лок берут ТОЧКИ
# ВХОДА (CLI, обработчики JOB-1); функции ``core`` лока не берут.

DEFAULT_WAIT_S = 600.0
_WAIT_POLL_S = 0.5

# Локи, взятые ЭТИМ процессом: path → ident потока-держателя. ``flock`` у двух дескрипторов одного
# процесса конфликтует, поэтому вложенный ``hold`` в том же потоке (шаг ``dt_sync`` -> CLI почты)
# распознает «уже наш» и проходит; другой поток этого же процесса - честный конкурент.
_HELD: dict[Path, int] = {}


class RunLockBusy(RuntimeError):
    """Lock занят другим прогоном: ``code == "sync_busy"``, ``holder`` - ``read_info`` держателя."""

    code = "sync_busy"

    def __init__(self, path: Path, holder: dict[str, Any], waited_s: float = 0.0) -> None:
        self.path = Path(path)
        self.holder = holder
        self.waited_s = waited_s
        who = (
            f"pid {holder.get('pid')} mode={holder.get('mode') or '?'} "
            f"step={holder.get('step') or '-'} с {holder.get('started') or '?'}"
            if holder else "держатель не определен"
        )
        waited = f" (ждали {waited_s:.0f} с)" if waited_s >= 0.5 else ""
        super().__init__(f"sync_busy: lock {self.path.name} занят - {who}{waited}")


@dataclass
class HoldResult:
    """Итог ``hold``: сколько ждали лок и был ли он уже нашим (вложенный вызов)."""

    path: Path
    waited_s: float = 0.0
    reentrant: bool = False


@contextlib.contextmanager
def hold(
    path: Path,
    *,
    mode: str,
    step: str = "",
    wait_s: float = 0.0,
    on_wait: Callable[[dict[str, Any]], None] | None = None,
    reentrant: bool = True,
) -> Iterator[HoldResult]:
    """Взять lock ``path`` на время блока (flock неблокирующий; ``wait_s > 0`` - повтор до срока).

    Взятый lock регистрируется (pid/mode/step в файле) и несет heartbeat (:func:`register`/
    :func:`beat`) - сторож ``runwatch`` его видит. Занят и ждать нельзя/время вышло -
    :class:`RunLockBusy` (``code="sync_busy"``, ``holder=read_info(path)``). ``on_wait`` вызывается
    один раз, когда начинаем ждать (с информацией держателя). Если lock уже наш в ЭТОМ потоке
    (``dt_sync`` держит ``fast``, шаг ``mail_ingest`` зовет CLI почты) - проходим без повторного
    взятия и без снятия на выходе (``reentrant=False`` - строгая единственность: сам ``dt_sync``
    не пускает второй прогон даже из того же потока).
    """
    p = Path(path)
    if reentrant and _HELD.get(p) == threading.get_ident():
        yield HoldResult(p, 0.0, reentrant=True)
        return
    p.parent.mkdir(parents=True, exist_ok=True)
    fh = open(p, "a+")  # "a+": попытка не усекает файл живого держателя; закрываем в finally
    started = time.monotonic()
    notified = False
    try:
        while True:
            try:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                waited = time.monotonic() - started
                if waited >= wait_s:
                    raise RunLockBusy(p, read_info(p), waited) from None
                if not notified and on_wait is not None:
                    notified = True
                    on_wait(read_info(p))
                time.sleep(min(_WAIT_POLL_S, max(0.0, wait_s - waited)))
        waited_s = time.monotonic() - started if notified else 0.0
        register(p, mode=mode, step=step)
        _HELD[p] = threading.get_ident()
        try:
            yield HoldResult(p, waited_s)
        finally:
            _HELD.pop(p, None)
            unregister(p)
    finally:
        with contextlib.suppress(Exception):
            fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        fh.close()
