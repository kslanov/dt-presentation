"""SEC-5 — единая точка чтения секретов: ``.env``-совместимость + Keychain-бэкенд.

Историческая раскладка: токены (`TICKTICK_ACCESS_TOKEN`, `TIMETTA_API_TOKEN`, …)
грузились из ``engine/.env`` в ``os.environ`` (``cli._env.load_env``) и читались
россыпью ``os.environ.get(...)`` по коду. ``.env`` — plaintext-файл на диске; даже
с правами 600 это менее защищённое хранилище, чем системный Keychain.

:func:`get_secret` — одна точка чтения с явным прецедентом:

1. **``os.environ``** — явный override и **полная обратная совместимость**: пока
   секрет в ``.env`` (его грузит ``load_env``), всё работает ровно как раньше;
2. **macOS Keychain** — ``security find-generic-password -s "dt:<NAME>" -w`` (учётка
   заводится ``dt_secrets --migrate``). Только на Darwin, только если бинарь
   ``security`` есть; не найдено / не Darwin / любой сбой → шаг пропускается;
3. иначе — ``None``.

Значение секрета **НИКОГДА не логируется** — ни в норме, ни в исключении (все
subprocess-сбои глотаются, наружу уходит только факт «нет/есть»). Добытое значение
регистрируется в скраб-фильтре логгера (:func:`core.logging_setup.register_secret`),
чтобы после ``--prune`` из ``.env`` (секрет живёт лишь в Keychain, вне
``os.environ``) скраб продолжал маскировать этот токен в любом выводе.

Инвариант ``core`` ⊥ mcp/cli: модуль импортирует лишь stdlib и
``core.logging_setup``. Subprocess-раннер инъектируем (образец
:mod:`core.operational.folder_picker`) — тесты подставляют фейк, реальный путь
остаётся тривиальным и hermetic-тесты не ходят в живой Keychain.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from collections.abc import Callable

__all__ = [
    "SECRET_NAMES",
    "get_secret",
    "in_keychain",
    "keychain_available",
    "secret_location",
]

# Четыре секрета контура, которые могут жить в ``.env`` и/или Keychain (SEC-5).
# ``dt_secrets`` работает ровно по этому списку; порядок — для стабильного вывода.
SECRET_NAMES = (
    "TICKTICK_ACCESS_TOKEN",
    "TICKTICK_CLIENT_ID",
    "TICKTICK_CLIENT_SECRET",
    "TIMETTA_API_TOKEN",
)

# Префикс service-имени учётки Keychain: ``dt:TIMETTA_API_TOKEN`` и т.п. (общий у
# get/migrate/prune, чтобы имя не разъехалось между чтением и записью).
KEYCHAIN_PREFIX = "dt:"
KEYCHAIN_ACCOUNT = "dt"

# Короткий таймаут — ``security`` не должен подвесить вызов (Keychain может
# спросить разрешение; при headless/CI просто вернёт non-zero быстро).
_TIMEOUT = 5.0

# (cmd, timeout) -> (returncode, stdout, stderr). Инъектируем для тестов —
# тот же контракт, что у ``folder_picker.Runner``.
Runner = Callable[[list[str], float], "tuple[int, str, str]"]


def _default_runner(cmd: list[str], timeout: float) -> tuple[int, str, str]:
    """Запустить ``cmd`` (список, без shell) → (returncode, stdout, stderr)."""
    proc = subprocess.run(  # noqa: S603 — cmd — фиксированная security-инвокация
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


def keychain_available(*, runner: Runner | None = None) -> bool:
    """Возможен ли Keychain-бэкенд здесь (macOS + бинарь ``security`` на PATH).

    Дешёвая read-only проверка (ничего не открывает). ``runner`` принимается для
    симметрии сигнатуры/будущих проб — сама проверка раннером не пользуется.
    """
    if sys.platform != "darwin":
        return False
    return shutil.which("security") is not None


def _keychain_get(name: str, *, runner: Runner | None = None) -> str | None:
    """Прочитать ``dt:<name>`` из Keychain, или ``None`` (никогда не бросает).

    Не-Darwin / нет ``security`` / учётка не найдена (``security`` вернул non-zero)
    / таймаут / любой сбой subprocess → ``None``. Значение не логируется.
    """
    if not keychain_available():
        return None
    run = runner or _default_runner
    cmd = ["security", "find-generic-password", "-s", f"{KEYCHAIN_PREFIX}{name}", "-w"]
    try:
        code, stdout, _stderr = run(cmd, _TIMEOUT)
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None
    if code != 0:  # учётка не найдена (44) или иная ошибка — тихо пропускаем
        return None
    value = (stdout or "").strip()
    return value or None


def get_secret(name: str, *, runner: Runner | None = None) -> str | None:
    """Секрет ``name``: env → Keychain → ``None`` (значение никогда не логируется).

    Прецедент: (1) ``os.environ`` (явный override + обратная совместимость с
    ``.env``); (2) macOS Keychain (``dt:<name>``); иначе ``None``. Добытое значение
    регистрируется в скраб-фильтре логгера, чтобы токен маскировался даже когда его
    уже нет в ``os.environ`` (мигрирован в Keychain + вырезан из ``.env``).
    ``runner`` инъектируется в тестах.
    """
    value = os.environ.get(name)
    if not value:
        value = _keychain_get(name, runner=runner)

    if value:
        # Defense-in-depth: скраб-фильтр логгера должен знать это значение, даже
        # если оно пришло из Keychain (в env его нет). Best-effort.
        try:
            from core.logging_setup import register_secret

            register_secret(value)
        except Exception:  # noqa: BLE001, S110 — регистрация скраба не критична
            pass
    return value


def in_keychain(name: str, *, runner: Runner | None = None) -> bool:
    """Есть ли ``dt:<name>`` в Keychain (независимо от ``os.environ``).

    Нужно ``dt_secrets --prune``, чтобы вырезать из ``.env`` только те секреты,
    что реально переехали в Keychain (env-fallback тут игнорируется). Значение не
    логируется/не возвращается — только факт.
    """
    return _keychain_get(name, runner=runner) is not None


def secret_location(name: str, *, runner: Runner | None = None) -> str:
    """Где живёт секрет ``name``: ``"env"`` | ``"keychain"`` | ``"absent"``.

    Для ``dt_secrets --status`` — **без вывода самого значения**. Прецедент тот же,
    что у :func:`get_secret` (env раньше Keychain). Ничего не регистрирует в скрабе
    (диагностика).
    """
    if os.environ.get(name):
        return "env"
    if _keychain_get(name, runner=runner):
        return "keychain"
    return "absent"
