"""TOOLS-PROFILES-1 п.2 — скиллы DT в git: источник, линтер переносимости, экспорт.

Источник — ``engine/skills/<name>/SKILL.md`` (формат Agent Skills: YAML-шапка ``name``/
``description`` + markdown-тело). Из него генерируются: библиотека Cowork (те же файлы), плагин
Kimi (скиллы + манифест) и MCP ``prompts`` (тело без шапки) — любой хост получает контракт
генерации по протоколу, а не только тот, у кого стоит скилл (дизайн MODEL-1, решение 2).

Линтер переносимости (гард в pytest): шапка валидна; в тексте нет вендора/песочницы чата;
вызовы инструментов ``имя(`` — только из реестра ``TOOL_NAMES``. Исключения — явный allowlist
там, где вендорное имя — предмет скилла (``Claude Design`` в ``tz-presentation-dt``).

Чистое чтение/запись файлов; ``core`` не зависит от MCP и CLI.
"""

from __future__ import annotations

import json
import re
import shutil
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import yaml  # type: ignore[import-untyped]  # стаб-гэп PyYAML — как в note_ids

from core.config import ENGINE_ROOT

__all__ = [
    "EXPORT_MANIFEST",
    "LintIssue",
    "RETIRED",
    "Skill",
    "PERSONAL_SKILLS_DIR",
    "SKILLS_DIR",
    "VENDOR_ALLOWLIST",
    "cherry_skill_text",
    "export_cherry_skills",
    "export_cowork",
    "fit_profile",
    "format_skipped",
    "export_kimi_skills",
    "lint_skills",
    "load_skills",
    "prune_stale",
    "split_header",
    "tool_calls",
]

SKILLS_DIR = ENGINE_ROOT / "skills"
# PERSONAL-1 п.8: скиллы ТОЛЬКО личной записи хоста (``personal-recall``): отдельный каталог, чтобы
# реестр рабочего (``SKILLS_DIR``: экспорты Cowork/Kimi/Cherry, prompts, гарды) остался как был.
# Их зовет ``load_skills(personal=True)`` - личный экземпляр и ``dt skills … --personal``.
PERSONAL_SKILLS_DIR = ENGINE_ROOT / "skills-personal"
SKILL_FILE = "SKILL.md"
# Манифест экспорта: какие каталоги в ``<out>/`` наши (по нему снимаются устаревшие).
EXPORT_MANIFEST = ".dt-skills.json"
# Имена, влитые в другие скиллы (MODEL-1 п.C, 29.10): ``старое -> куда``. Нужны экспорту, чтобы
# снять каталоги, оставшиеся от экспорта до появления манифеста; в реестре таких имен нет (тест).
RETIRED: dict[str, str] = {
    "new-entity-hub": "new-hub",
    "new-presale": "new-hub",
    "new-project": "new-hub",
    "morning": "operational-review",
    "capture-to-timetta": "capture-to-assignment",  # RETIRE-WRITE-1, 2026-10-20
}

VENDOR_RE = re.compile(r"Claude|Cowork|песочниц", re.IGNORECASE)
# CONFIG-1 п.7: путь в vault (``vault/…``) хост без локального vault (серверный режим, Kimi, Cherry)
# прочитать не может - данные берутся инструментами (``list_inbox``, ``read_note``), а канон стиля
# движок сам кладёт в промпт ``generate`` ([Style guide]) и проверяет на ``save_output``.
VAULT_PATH_RE = re.compile(r"\bvault/")
# ``(skill, фраза)``: вендорное имя — предмет скилла по существу (ТЗ на колоду для Claude Design).
VENDOR_ALLOWLIST: frozenset[tuple[str, str]] = frozenset({("tz-presentation-dt", "Claude Design")})

_HEADER_RE = re.compile(r"\A---[ \t]*\n(.*?)\n---[ \t]*(?:\n|\Z)", re.DOTALL)
# Вызов инструмента в тексте скилла: имя в код-спане сразу перед «(» — ``save_output(…``.
_CALL_RE = re.compile(r"`([a-z][a-z0-9_]*)\(")
_MCP_NAME_RE = re.compile(r"mcp__digital-twin__([a-z][a-z0-9_]*)")


@dataclass(frozen=True)
class Skill:
    name: str
    description: str
    body: str  # без YAML-шапки
    text: str  # файл целиком (шапка + тело) — как лежит в git
    path: Path


@dataclass(frozen=True)
class LintIssue:
    skill: str
    code: str  # header | vendor | unknown_tool | name_mismatch | vault_path
    message: str

    def __str__(self) -> str:
        return f"{self.skill}: [{self.code}] {self.message}"


def split_header(text: str) -> tuple[dict | None, str]:
    """``(шапка, тело)``. Нет шапки/битый YAML/не словарь → ``(None, весь текст)``."""
    m = _HEADER_RE.match(text)
    if not m:
        return None, text
    try:
        header = yaml.safe_load(m.group(1))
    except yaml.YAMLError:
        return None, text
    if not isinstance(header, dict):
        return None, text
    return header, text[m.end():].lstrip("\n")


def load_skills(root: Path | None = None, *, personal: bool = False) -> list[Skill]:
    """Скиллы из ``<root>/<name>/SKILL.md`` по имени каталога.

    Без шапки — тело целиком и без описания (линтер это ловит; загрузчик не падает).
    ``personal=True`` (PERSONAL-1) добавляет скиллы личной записи хоста (``skills-personal/``) -
    только личный экземпляр и ``--personal`` экспорта; по умолчанию реестр рабочего без них."""
    base = Path(root) if root is not None else SKILLS_DIR
    skills: list[Skill] = []
    if not base.is_dir():
        return skills
    paths = sorted(base.glob(f"*/{SKILL_FILE}"))
    if personal and root is None:
        paths = sorted([*paths, *PERSONAL_SKILLS_DIR.glob(f"*/{SKILL_FILE}")],
                       key=lambda p: p.parent.name)
    for path in paths:
        text = path.read_text(encoding="utf-8")
        header, body = split_header(text)
        header = header or {}
        skills.append(Skill(
            name=str(header.get("name") or path.parent.name),
            description=str(header.get("description") or "").strip(),
            body=body,
            text=text,
            path=path,
        ))
    return skills


def tool_calls(text: str) -> set[str]:
    """Имена инструментов в тексте: ``имя(`` в код-спане и ``mcp__digital-twin__имя``."""
    return set(_CALL_RE.findall(text)) | set(_MCP_NAME_RE.findall(text))


def fit_profile(
    skills: Iterable[Skill], tool_names: Iterable[str]
) -> tuple[list[Skill], dict[str, list[str]]]:
    """MODEL-1-FIT: скиллы, которые хост с набором ``tool_names`` способен выполнить.

    Скилл подходит, если ``tool_calls(body) ⊆ tool_names`` (скилл без вызовов - подходит).
    Возвращает ``(подходящие в порядке входа, {имя: [каких инструментов нет]})``; список
    недостающих отсортирован. Единый источник для экспорта плагина, манифеста, MCP ``prompts`` и
    ``--selftest``: скилл на хосте - подмножество его профиля, иначе prompt велит модели сделать
    невозможное (вызвать инструмент, которого у хоста нет)."""
    known = set(tool_names)
    fit: list[Skill] = []
    skipped: dict[str, list[str]] = {}
    for sk in skills:
        gone = sorted(tool_calls(sk.body) - known)
        if gone:
            skipped[sk.name] = gone
        else:
            fit.append(sk)
    return fit, skipped


def format_skipped(skipped: dict[str, list[str]], profile: str) -> str:
    """Строка вывода: ``вне профиля lean: имя (инструмент, …); …`` (пусто, если пропусков нет)."""
    if not skipped:
        return ""
    parts = "; ".join(f"{name} ({', '.join(tools)})" for name, tools in sorted(skipped.items()))
    return f"вне профиля {profile}: {parts}"


def lint_skills(
    skills: Iterable[Skill], tool_names: Iterable[str], *, root: Path | None = None
) -> list[LintIssue]:
    """Нарушения переносимости (пусто = чисто)."""
    known = set(tool_names)
    issues: list[LintIssue] = []
    for sk in skills:
        label = sk.path.parent.name
        header, body = split_header(sk.text)
        if header is None:
            issues.append(LintIssue(label, "header", "нет валидной YAML-шапки (--- … ---)"))
            continue
        name, desc = header.get("name"), header.get("description")
        if not isinstance(name, str) or not name.strip():
            issues.append(LintIssue(label, "header", "в шапке нет строки name"))
        elif name != label:
            issues.append(LintIssue(label, "name_mismatch",
                                    f"name {name!r} не совпадает с каталогом {label!r}"))
        if not isinstance(desc, str) or not desc.strip():
            issues.append(LintIssue(label, "header", "в шапке нет непустого description"))
        if not body.strip():
            issues.append(LintIssue(label, "header", "тело скилла пусто"))
        for m in VENDOR_RE.finditer(sk.text):
            frag = sk.text[max(0, m.start() - 12): m.end() + 12]
            if any(label == s and phrase in frag for s, phrase in VENDOR_ALLOWLIST):
                continue
            issues.append(LintIssue(label, "vendor", f"вендор/песочница: …{frag.strip()}…"))
        for m in VAULT_PATH_RE.finditer(sk.text):
            frag = sk.text[max(0, m.start() - 12): m.end() + 24]
            issues.append(LintIssue(
                label, "vault_path",
                f"путь vault в тексте скилла (хост без vault его не прочитает; бери данные "
                f"инструментом): …{frag.strip()}…"))
        for call in sorted(tool_calls(sk.text) - known):
            issues.append(LintIssue(label, "unknown_tool", f"{call}( — нет в TOOL_NAMES"))
    return issues


# --------------------------------------------------------------------------- #
# Экспорт                                                                       #
# --------------------------------------------------------------------------- #
def _read_manifest(out_dir: Path) -> set[str]:
    try:
        data = json.loads((out_dir / EXPORT_MANIFEST).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return set()
    names = data.get("names") if isinstance(data, dict) else None
    return {str(n) for n in names} if isinstance(names, list) else set()


def prune_stale(out_dir: Path, keep: Iterable[str]) -> list[Path]:
    """Убрать из каталога экспорта скиллы, которых больше нет в реестре (MODEL-1 п.C).

    Кандидаты на удаление - имена из прежнего манифеста экспорта (:data:`EXPORT_MANIFEST`) и
    :data:`RETIRED` (имена, влитые в другие скиллы до появления манифеста), которых нет в ``keep``;
    удаляется только ``<out>/<name>/`` с ``SKILL.md`` внутри. Чужие каталоги (не наш экспорт, не
    retired) не трогаем: библиотека Cowork может держать и другие скиллы. Возвращает удаленные."""
    out = Path(out_dir)
    stale = (_read_manifest(out) | set(RETIRED)) - set(keep)
    removed: list[Path] = []
    for name in sorted(stale):
        folder = out / name
        if (folder / SKILL_FILE).is_file():
            shutil.rmtree(folder)
            removed.append(folder)
    return removed


def export_cowork(
    out_dir: Path, skills: Iterable[Skill], *, skipped: dict[str, list[str]] | None = None,
    text_of: Callable[[Skill], str] | None = None,
) -> list[Path]:
    """Библиотека Cowork: ``<out>/<name>/SKILL.md`` — те же файлы, что в git (байт в байт).

    Экспорт = ровно переданный состав: устаревшие каталоги прежнего экспорта (в т.ч. скиллы,
    выпавшие из профиля) снимаются (:func:`prune_stale`), состав пишется в манифест
    ``<out>/.dt-skills.json``: ``names`` (формат прежний) и ``skipped`` - ``{имя: [инструменты,
    которых нет у профиля]}`` (MODEL-1-FIT; для полного экспорта пуст)."""
    out = Path(out_dir)
    skills = list(skills)
    names = sorted(sk.path.parent.name for sk in skills)
    prune_stale(out, names)
    written = []
    for sk in skills:
        target = out / sk.path.parent.name / SKILL_FILE
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text_of(sk) if text_of else sk.text, encoding="utf-8")
        written.append(target)
    out.mkdir(parents=True, exist_ok=True)
    (out / EXPORT_MANIFEST).write_text(
        json.dumps({"names": names, "skipped": dict(sorted((skipped or {}).items())),
                    "exported": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")},
                   ensure_ascii=False, indent=1) + "\n",
        encoding="utf-8",
    )
    return written


def export_kimi_skills(
    out_dir: Path, skills: Iterable[Skill], *, skipped: dict[str, list[str]] | None = None
) -> list[Path]:
    """Плагин Kimi: ``<out>/skills/<name>/SKILL.md`` (``skills: "./skills/"`` манифеста).

    ``skills`` - уже подогнанные под профиль (:func:`fit_profile`), ``skipped`` - что отброшено."""
    return export_cowork(Path(out_dir) / "skills", skills, skipped=skipped)


def cherry_skill_text(skill: Skill, version: str) -> str:
    """``SKILL.md`` для Cherry Studio: frontmatter РОВНО ``name``/``description``/``version`` (как у
    встроенных скиллов Cherry) + тело скилла. Тело - то же, что в git (байт в байт); лишние ключи
    шапки источника (если появятся) в Cherry не уходят."""
    header = yaml.safe_dump(
        {"name": skill.name, "description": skill.description, "version": str(version)},
        allow_unicode=True, sort_keys=False, width=10**6,
    ).rstrip("\n")
    return f"---\n{header}\n---\n\n{skill.body}"


def export_cherry_skills(
    out_dir: Path, skills: Iterable[Skill], *, version: str,
    skipped: dict[str, list[str]] | None = None,
) -> list[Path]:
    """Cherry Studio: ``<out>/<name>/SKILL.md`` (каталог ``Data/Skills`` приложения), установка из
    каталога - в UI Cherry (Settings → Skills). Состав - подогнанный под профиль
    (:func:`fit_profile`, как плагин Kimi); устаревшие каталоги прежнего экспорта снимаются.
    Манифест экспорта ``.dt-skills.json`` лежит в КОРНЕ ``out`` (по нему чистится устаревшее),
    внутри каталога скилла его нет - Cherry читает каталог скилла как есть."""
    return export_cowork(out_dir, skills, skipped=skipped,
                         text_of=lambda sk: cherry_skill_text(sk, version))
