"""LIVE-SMOKE-1 — состояние последнего сценарного прогона (лог + его разбор).

Смоук гоняется на БОЕВОМ vault/конфиге/сторах (``tests/test_live_smoke.py``,
маркер ``live_smoke``), запускается из ``cli/dt_smoke.py`` и по расписанию
(launchd ``com.dt.smoke``). Здесь — единственное место, где живёт **формат
итоговой строки** прогона: её пишет CLI, её же читает doctor-гард
(:func:`core.diagnostics._smoke_check`). Разъехавшийся формат означал бы
доктора, который уверенно молчит о мёртвом смоуке — тот же класс дефекта,
который смоук и ловит.

Сценарии С-1..С-13 (список — в шапке ``tests/test_live_smoke.py``; реестр один — маркеры
``live_smoke``, счётчик ``cli/dt_smoke.py`` и ``RESULT total=`` считают их из прогона, а не из
константы здесь).

Лог человекочитаемый: блок на прогон (строка на сценарий) + машинный итог
``RESULT k=v …`` последней строкой блока. Одно и то же поле не приходится
поддерживать в двух форматах, и `tail -f smoke.log` остаётся полезным.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.config import logs_path

__all__ = [
    "BASELINE_REL",
    "MAX_AGE_DAYS",
    "RESULT_PREFIX",
    "BaselineError",
    "doctor_baseline_path",
    "format_result",
    "last_run",
    "load_doctor_baseline",
    "smoke_log_path",
]

BASELINE_REL = Path("_system") / "eval" / "doctor-baseline.yaml"

# Прогон старше этого — сигнал «смоук умер» (weekly-джоб + запас на выключенный
# ноутбук). Порог здесь, а не в doctor: он же ограничивает смысл самой записи.
MAX_AGE_DAYS = 8.0

RESULT_PREFIX = "RESULT "


def smoke_log_path() -> Path:
    """Лог прогонов смоука (``.derived/logs/smoke.log``)."""
    return logs_path() / "smoke.log"


def format_result(
    *,
    ts: str,
    ok: bool,
    total: int,
    passed: int,
    failed: int,
    duration_s: float,
    red: list[str] | None = None,
) -> str:
    """Машинный итог прогона одной строкой (``RESULT ts=… ok=… …``).

    WAVE1-MEASURE п.3: ``red=С-6_здоровье_окружения,С-9_…`` — КАКИЕ сценарии красные (названия
    без пробелов: итог читается по ``k=v``-токенам). Смоук, о котором известно лишь «1 из 9
    красный», перестают читать — именно так он простоял красным семь недель.
    """
    line = (
        f"{RESULT_PREFIX}ts={ts} ok={'true' if ok else 'false'} total={int(total)} "
        f"passed={int(passed)} failed={int(failed)} duration_s={duration_s:.1f}"
    )
    if red:
        line += " red=" + ",".join("_".join(str(t).split()) for t in red)
    return line


def _parse_ts(value: str) -> datetime | None:
    """ISO-8601 (``…Z``) → aware UTC datetime, иначе ``None``."""
    text = (value or "").strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt.astimezone(UTC)


def last_run(
    *, path: Path | None = None, now: datetime | None = None
) -> dict[str, Any] | None:
    """Итог ПОСЛЕДНЕГО прогона из лога: ``{ts, ok, total, passed, failed,
    duration_s, age_days}``.

    ``red`` — названия красных сценариев (``[]`` у зелёного и у прогона старого формата).

    ``None`` — прогонов нет (лога нет, он пуст, не читается или в нём не осталось
    ни одной ``RESULT``-строки). Различать эти случаи потребителю незачем: любой
    из них значит «свежего прогона нет», и лечится он одинаково — прогнать смоук.
    Битую ``RESULT``-строку пропускаем и идём к предыдущей: усечённый последний
    прогон (kill/полный диск) не должен прятать позавчерашний честный.
    """
    target = path or smoke_log_path()
    try:
        lines = target.read_text(encoding="utf-8").splitlines()
    except OSError:
        return None

    for line in reversed(lines):
        if not line.startswith(RESULT_PREFIX):
            continue
        fields: dict[str, str] = {}
        for token in line[len(RESULT_PREFIX):].split():
            key, _, value = token.partition("=")
            if key and value:
                fields[key] = value
        ts = _parse_ts(fields.get("ts", ""))
        if ts is None:
            continue
        now_dt = now or datetime.now(UTC)
        return {
            "ts": fields.get("ts", ""),
            "ok": fields.get("ok") == "true",
            "total": _num(fields.get("total"), int),
            "passed": _num(fields.get("passed"), int),
            "failed": _num(fields.get("failed"), int),
            "red": [t.replace("_", " ") for t in fields.get("red", "").split(",") if t],
            "duration_s": _num(fields.get("duration_s"), float),
            "age_days": round((now_dt - ts).total_seconds() / 86400.0, 1),
        }
    return None


def _num(raw: str | None, cast: Any) -> Any:
    """Число из поля строки; мусор → 0 (лог — производные данные, не повод падать)."""
    try:
        return cast(raw)
    except (TypeError, ValueError):
        return cast(0)


# --------------------------------------------------------------------------- #
# WAVE1-MEASURE п.3 — принятая база warn'ов доктора (С-6)                        #
# --------------------------------------------------------------------------- #
class BaselineError(ValueError):
    """База не прочитана/не валидна: С-6 без неё судить не о чем (красный с причиной)."""


def doctor_baseline_path(vault: Path | None = None) -> Path:
    """``<vault>/_system/eval/doctor-baseline.yaml`` — канон принятых warn'ов (К. правит)."""
    if vault is None:
        from core.config import default_vault_path

        vault = default_vault_path()
    return Path(vault) / BASELINE_REL


def load_doctor_baseline(path: Path | None = None) -> dict[str, str]:
    """Принятые warn'ы доктора: ``{имя проверки: причина}``.

    С-6 был красным по любому НОВОМУ warn'у, а новое имя вносилось в код — и после каждого
    добавления проверки смоук краснел заново (семь недель красного, сигнал обесценен). Теперь
    «известное» — данные в vault, а не константа в тесте: новый warn → красный, известный —
    нет. «Известный» не значит «нормальный»: строку убирают, когда причину устранили, — тогда
    возврат warn'а снова красный.
    """
    import yaml  # type: ignore[import-untyped]

    target = Path(path) if path is not None else doctor_baseline_path()
    try:
        data = yaml.safe_load(target.read_text(encoding="utf-8"))
    except OSError as exc:
        raise BaselineError(f"база warn'ов доктора не прочитана: {target}: {exc}") from exc
    except yaml.YAMLError as exc:
        raise BaselineError(f"база warn'ов доктора: невалидный YAML ({target}): {exc}") from exc
    items = data.get("known_warns") if isinstance(data, dict) else None
    if not isinstance(items, list):
        raise BaselineError(f"база warn'ов доктора без списка known_warns: {target}")
    known: dict[str, str] = {}
    for i, item in enumerate(items, start=1):
        name = (item.get("name") if isinstance(item, dict) else item)
        if not isinstance(name, str) or not name.strip():
            raise BaselineError(f"база warn'ов доктора: запись #{i} без name ({target})")
        known[name.strip()] = str(item.get("why") or "") if isinstance(item, dict) else ""
    return known
