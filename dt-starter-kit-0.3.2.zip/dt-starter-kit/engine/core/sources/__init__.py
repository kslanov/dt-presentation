"""Runtime Source Resolver — the Facts Plane's file-lift port (SRC-1, §10a).

Dereferences a card's ``source_path`` **at runtime** and lifts the file's content
into a structured, cell-addressable :class:`~core.sources.resolver.LiftResult` —
the code path that was missing when "поднять суммы из xlsx по пути из карточки"
proved impossible (production audit 2026-07-10, Acme). Reuses the offline legacy
parsers (:mod:`core.legacy.extract`) for the text layer and adds a **new
structural layer with cell coordinates** (``sheet!ref``) on top, cached by the
file's content hash.

Invariants (enforced by ``tests/test_invariant.py`` + this package's tests):
- ``core`` ⊥ MCP/CLI — this package imports neither.
- **Path B** — offline & deterministic: no network, no LLM, parsers are pure.
- **Read-only** — sources are opened read-only; never mutated or executed. Every
  lift is bounded by a :class:`~core.sources.resolver.Budget` (timeout + cell cap).
"""

from __future__ import annotations

from core.sources.freshness import (
    Family,
    Freshness,
    Member,
    Sibling,
    directory_freshness,
    family_files,
    family_of,
)
from core.sources.parsers import (
    Cell,
    ParsedContent,
    ParsersUnavailable,
    Row,
    Table,
    parse_source,
)
from core.sources.resolver import (
    Budget,
    LiftResult,
    NdaRefused,
    SourceNotLocal,
    SourceRef,
    SourceUnavailable,
    lift,
    lift_from,
    resolve_ref,
    resolve_source_path,
    slice_result,
)

__all__ = [
    "Budget",
    "Cell",
    "Family",
    "Freshness",
    "Member",
    "LiftResult",
    "NdaRefused",
    "ParsedContent",
    "ParsersUnavailable",
    "Row",
    "SourceRef",
    "Sibling",
    "SourceNotLocal",
    "SourceUnavailable",
    "Table",
    "directory_freshness",
    "family_files",
    "family_of",
    "lift",
    "lift_from",
    "parse_source",
    "resolve_ref",
    "resolve_source_path",
    "slice_result",
]
