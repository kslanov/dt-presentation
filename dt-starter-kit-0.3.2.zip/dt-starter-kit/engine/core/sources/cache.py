"""L2 runtime lift cache + source registry (SRC-1, PART-3; registry unified by DB-1).

A lifted source's **content** is cached as ``<derived>/sources/<content_hash>.json``
keyed by the file's content hash (raw bytes) — not its path or mtime. That choice
is deliberate (production audit 2026-07-10): a path migrates and mtime lies after a
linking wave, but identical bytes must be a cache hit, and any content change is a
new hash → automatic re-read. The content records **stay files** (rebuildable
cache, not state — DB-1 leaves them as-is).

The **registry** — ``content_hash → {paths, mtime, size, kind, last_lift, status,
note_refs}`` — was a JSON ``index.json``; DB-1 moved it into the ``sources`` table
of the shared ``dt.db`` (:mod:`core.db`) so an upsert is a single atomic
transaction (no half-written manifest after a cron crash) instead of a
read-modify-write of a JSON blob. **The public API is unchanged** —
:func:`register_source`/:func:`load_index`/:func:`find_relocated_path`/
:func:`hash_for_path` keep the same signatures and semantics; the old ``index.json``
is imported once on first open (renamed ``.bak``). It still powers **relocation by
hash** — a card whose path is gone but whose bytes are registered under another
live path resolves to that copy.

Parallels :mod:`core.legacy.cache` (atomic write-then-replace, malformed →
rebuildable ``None``). Deterministic, no LLM (Path B).
"""

from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.config import sources_cache_path
from core.db import connect

__all__ = [
    "file_content_hash",
    "cache_record_path",
    "index_path",
    "load_cached",
    "save_cached",
    "load_index",
    "register_source",
    "forget_source",
    "forget_path_versions",
    "find_relocated_path",
    "hash_for_path",
]

_INDEX_NAME = "index.json"


def file_content_hash(path: Path) -> str:
    """sha256 of the file's raw bytes — the content-addressed cache key.

    Same algorithm as :func:`core.legacy.dedup.content_hash` (sha256), but over
    the file's bytes rather than a decoded string: the key must be computable
    *before* parsing (which may be skipped on a cache hit) and a binary source has
    no single canonical text form. Streamed so a large file is not read whole.
    """
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def cache_record_path(content_hash: str) -> Path:
    """``<derived>/sources/<content_hash>.json`` for a lifted source."""
    return sources_cache_path() / f"{content_hash}.json"


def index_path() -> Path:
    """``<derived>/sources/index.json`` — the source registry."""
    return sources_cache_path() / _INDEX_NAME


def _load_json(path: Path) -> Any | None:
    """Read+parse a JSON file, or ``None`` if missing/malformed (rebuildable)."""
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _save_json(path: Path, data: Any) -> None:
    """Persist JSON atomically (write-temp-then-replace), creating parents."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        # default=str is a belt-and-suspenders guard: cell values are already
        # normalized to JSON-safe forms upstream, but a stray non-serializable
        # value must degrade to its string form rather than crash the lift.
        json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True, default=str),
        encoding="utf-8",
    )
    tmp.replace(path)


def load_cached(content_hash: str) -> dict[str, Any] | None:
    """Return the cached lift record for ``content_hash``, or ``None`` on miss."""
    data = _load_json(cache_record_path(content_hash))
    return data if isinstance(data, dict) else None


def save_cached(content_hash: str, record: dict[str, Any]) -> None:
    """Persist a lift record under its content hash."""
    _save_json(cache_record_path(content_hash), record)


def _json_list(raw: Any) -> list[str]:
    """Parse a stored JSON-array cell into a list of strings ( ``[]`` on trouble)."""
    if not raw:
        return []
    try:
        data = json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return []
    return [x for x in data if isinstance(x, str)] if isinstance(data, list) else []


def _row_to_entry(row: sqlite3.Row) -> dict[str, Any]:
    """One ``sources`` row → the historic index.json entry shape (unchanged)."""
    return {
        "paths": _json_list(row["paths"]),
        "mtime": row["mtime"],
        "size": row["size"],
        "kind": row["kind"],
        "status": row["status"],
        "last_lift": row["last_lift"],
        "note_refs": _json_list(row["note_refs"]),
    }


def load_index() -> dict[str, Any]:
    """Read the registry (``content_hash → entry``); ``{}`` if empty/absent.

    Reconstructs the exact prior index.json shape from the ``sources`` table, so
    callers and tests that inspect the registry see no difference (DB-1 backend).
    """
    conn = connect()
    try:
        rows = conn.execute(
            "SELECT content_hash, paths, mtime, size, kind, status, last_lift, "
            "note_refs FROM sources"
        ).fetchall()
    except sqlite3.OperationalError:
        return {}
    finally:
        conn.close()
    return {str(r["content_hash"]): _row_to_entry(r) for r in rows}


def register_source(
    content_hash: str,
    *,
    path: str,
    mtime: float,
    size: int,
    kind: str,
    status: str,
    note_ref: str | None = None,
) -> None:
    """Upsert a registry entry for a lifted source (relocation-by-hash support).

    Keyed by ``content_hash``; ``path`` is appended to the entry's known paths
    (so the same bytes seen at a second location are both recorded) and
    ``note_ref`` to its note references. ``mtime``/``size``/``kind``/``status`` are
    refreshed to the latest lift. **Atomic** (DB-1): the read-merge-write runs as a
    single transaction — an interrupted call rolls back cleanly, never leaving a
    half-written registry (the JSON manifest's failure mode). Best-effort: a write
    error is swallowed (the registry is a rebuildable cache, never a source of
    truth).
    """
    try:
        conn = connect()
    except sqlite3.Error:
        return
    try:
        row = conn.execute(
            "SELECT paths, note_refs FROM sources WHERE content_hash = ?",
            (content_hash,),
        ).fetchone()
        paths = _json_list(row["paths"]) if row else []
        note_refs = _json_list(row["note_refs"]) if row else []
        if path not in paths:
            paths.append(path)
        if note_ref and note_ref not in note_refs:
            note_refs.append(note_ref)
        conn.execute(
            "INSERT OR REPLACE INTO sources "
            "(content_hash, paths, mtime, size, kind, status, last_lift, note_refs) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                content_hash,
                json.dumps(paths, ensure_ascii=False),
                mtime,
                size,
                kind,
                status,
                path,
                json.dumps(note_refs, ensure_ascii=False),
            ),
        )
        conn.commit()
    except sqlite3.Error:
        pass  # best-effort — rebuildable cache; the transaction rolled back
    finally:
        conn.close()


def forget_source(content_hash: str) -> None:
    """Delete a registry entry by ``content_hash`` (atomic; best-effort).

    Preserves the pre-DB-1 purge capability (``dt_purge_nda``) on the table
    backend — the entry's row is removed in a single transaction. The lift
    *content* record (``<hash>.json``) is a separate file the caller unlinks."""
    try:
        conn = connect()
    except sqlite3.Error:
        return
    try:
        conn.execute("DELETE FROM sources WHERE content_hash = ?", (content_hash,))
        conn.commit()
    except sqlite3.Error:
        pass
    finally:
        conn.close()


def forget_path_versions(path: str, keep_hash: str) -> int:
    """Drop ``path`` from every registry row whose hash ≠ ``keep_hash`` (INGEST-SCHEDULE
    PART-3б). An operational file's identity is its **path** (a mutable root — the
    byte-hash is the *version*, not the key), so when a new version is registered the
    stale-version rows that still list this path are pruned: the path is removed from
    them and a row left path-less is deleted. Keeps the registry path-current and
    bounded (no unbounded stale-version growth per edited file) without touching the
    live ``keep_hash`` row or unrelated bytes. Returns rows changed; best-effort
    (rebuildable cache — a write error is swallowed).
    """
    try:
        conn = connect()
    except sqlite3.Error:
        return 0
    changed = 0
    try:
        rows = conn.execute("SELECT content_hash, paths FROM sources").fetchall()
        for row in rows:
            content_hash = str(row["content_hash"])
            if content_hash == keep_hash:
                continue
            paths = _json_list(row["paths"])
            if path not in paths:
                continue
            remaining = [p for p in paths if p != path]
            if remaining:
                conn.execute(
                    "UPDATE sources SET paths = ? WHERE content_hash = ?",
                    (json.dumps(remaining, ensure_ascii=False), content_hash),
                )
            else:
                conn.execute(
                    "DELETE FROM sources WHERE content_hash = ?", (content_hash,)
                )
            changed += 1
        conn.commit()
    except sqlite3.Error:
        pass  # best-effort — rebuildable cache; transaction rolled back
    finally:
        conn.close()
    return changed


def hash_for_path(path: str) -> str | None:
    """Last-known content hash registered for ``path`` (exact string match)."""
    for content_hash, entry in load_index().items():
        if isinstance(entry, dict) and path in entry.get("paths", []):
            return content_hash
    return None


def find_relocated_path(missing_path: str) -> tuple[str, str] | None:
    """Find a live path for ``missing_path``'s bytes via the registry (PART-5).

    When a card's ``source_path`` no longer exists but the registry recorded that
    path's content hash under another location that *does* exist, return
    ``(existing_path, content_hash)`` so the resolver lifts the relocated copy.
    Returns ``None`` if the path was never registered or no known path survives.
    """
    content_hash = hash_for_path(missing_path)
    if content_hash is None:
        return None
    entry = load_index().get(content_hash)
    if not isinstance(entry, dict):
        return None
    for candidate in entry.get("paths", []):
        if isinstance(candidate, str) and candidate != missing_path:
            if Path(candidate).is_file():
                return candidate, content_hash
    return None
