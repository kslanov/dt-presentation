"""Потолок текста в ОТВЕТЕ ``lift_source`` (ARGS-STRICT-1 п.5).

Усечение - только в сериализованном ответе инструмента: ``lift_from``, кэш подъема (L2), OCR и
факты работают с ПОЛНЫМ текстом и этого модуля не знают. Таблицы и ``max_cells`` не затрагиваются.
Аналог ``get_facts(limit)``: укладывается - ответ как был (ни одного нового ключа), больше -
``text`` обрезан по границе строки, ``truncated: true``, ``chars_total`` и конверт ``truncated``.

``core`` ⊥ MCP/CLI; ни сети, ни LLM.
"""

from __future__ import annotations

import os
from typing import Any

from core.contract import CODE_TRUNCATED, add_warning

__all__ = ["DEFAULT_LIFT_MAX_CHARS", "LIFT_MAX_CHARS_ENV", "cap_lift_text", "resolve_max_chars"]

LIFT_MAX_CHARS_ENV = "DT_LIFT_MAX_CHARS"
DEFAULT_LIFT_MAX_CHARS = 40_000


def resolve_max_chars(max_chars: int | None) -> int | None:
    """Потолок в символах: ``0`` - без потолка; ``None`` - отказ (не целое >= 0).

    ``max_chars=None`` берет ``DT_LIFT_MAX_CHARS`` (дефолт 40 000; ``0`` - без потолка; мусор и
    отрицательное - дефолт).
    """
    if max_chars is None:
        raw = os.environ.get(LIFT_MAX_CHARS_ENV, "").strip()
        try:
            value = int(raw)
        except ValueError:
            return DEFAULT_LIFT_MAX_CHARS
        return value if value >= 0 else DEFAULT_LIFT_MAX_CHARS
    if isinstance(max_chars, bool) or not isinstance(max_chars, int) or max_chars < 0:
        return None
    return max_chars


def cap_lift_text(out: dict[str, Any], cap: int) -> dict[str, Any]:
    """Усечь ``out["text"]`` до ``cap`` символов по границе строки (0 - не усекать).

    Укладывается - тот же объект без единой правки. Больше - ``text`` режется до последнего
    перевода строки в пределах ``cap`` (строки без переводов - по ``cap``), ``truncated`` = True
    (поле уже значит «ответ неполон»: упор в потолок ячеек или текста), ``chars_total`` - длина
    полного текста, плюс конверт ``truncated`` с подсказкой.
    """
    text = out.get("text")
    if not cap or not isinstance(text, str) or len(text) <= cap:
        return out
    cut = text[:cap]
    newline = cut.rfind("\n")
    if newline > 0:
        cut = cut[:newline]
    out["text"] = cut
    out["truncated"] = True
    out["chars_total"] = len(text)
    add_warning(
        out, CODE_TRUNCATED,
        f"текст усечен: {len(text)} символов, отдано {len(cut)} (по границе строки)",
        hint="подними max_chars (0 - без потолка) или возьми срез: sheet/cell_range",
        chars_total=len(text), max_chars=cap,
    )
    return out
