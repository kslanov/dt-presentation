"""Свежесть источника в его каталоге — сосед новее + позиция в семействе (SRC-FRESH-1).

Класс дефекта (фейлкейс 2026-08-11, 5 эпизодов за одну сессию; худший — вывод,
обратный истине, в документе для аудитора): **папка хранилища = семейство версий
документа**, а поиск возвращает члена семейства, ничего не говоря о его позиции в
нём. Лексически плотный шаблон 2023 года выигрывает ранжирование у действующего
плана 2026 — и это не дефект ранжирования (релевантность честная), а отсутствие
сигнала давности.

Здесь — самая дешёвая точка такого сигнала: при подъёме файла мы уже сделали
``stat``, каталог рядом, и **один** ``scandir`` отвечает на два вопроса:

* есть ли в этом каталоге файл с похожим именем и существенно более новой датой
  (``DT_NEWER_SIBLING_DAYS``, дефолт 30) — :class:`Sibling`;
* какой этот файл по счёту по дате среди файлов каталога — ``rank_by_date`` из
  ``of`` (позиционный контекст: «5-й из 9» читается сразу, «mtime 2023-11-23» — нет).

«Похожесть имени» — БЕЗ НЛП (сознательное ограничение ТЗ): значимые токены имени
(без дат/версий) пересекаются на :data:`_MIN_OVERLAP` ИЛИ общий нормализованный
префикс не короче :data:`_MIN_PREFIX`. Ложное срабатывание здесь стоит мягкой
пометки «проверь свежесть», пропуск — вывода, обратного истине; порог выбран в эту
сторону.

Read-only, только листинг каталога (содержимое соседей НЕ читается); ``core`` ⊥ MCP/CLI.
"""

from __future__ import annotations

import os
import re
import unicodedata
from collections.abc import Collection
from dataclasses import dataclass
from pathlib import Path

from core.privacy import is_eval
from core.sources.markers import Markers

__all__ = [
    "Sibling",
    "Freshness",
    "DEFAULT_NEWER_SIBLING_DAYS",
    "newer_sibling_days",
    "name_tokens",
    "text_tokens",
    "similar_names",
    "kind_class",
    "compatible_kinds",
    "family_files",
    "family_of",
    "Family",
    "Member",
    "directory_freshness",
]

DEFAULT_NEWER_SIBLING_DAYS = 30.0
_DAYS_ENV = "DT_NEWER_SIBLING_DAYS"

# Общий нормализованный префикс имени (без дат/пунктуации), с которого считаем имена
# однокоренными: «Business plan KCT 2023» ↔ «Business plan 2026-2029».
_MIN_PREFIX = 8
# Доля общих значимых токенов от более короткого имени.
_MIN_OVERLAP = 0.6
# Токен-шум: чистые числа (годы, кварталы) и версии (v2, ver.3, rev4) — ровно то,
# чем отличаются версии одного документа, поэтому из сравнения выбрасываются.
_VERSION_RE = re.compile(r"^(?:v|ver|vers|rev|изм)\.?\d+$", re.IGNORECASE)
# Разделители токенов имени: пунктуация, пробелы И подчёркивание (``Отчёт_ЦОД_v1``
# — три токена, а не один: ``\W`` подчёркивание словом считает, нам оно разделитель).
_SPLIT_RE = re.compile(r"[\W_]+", re.UNICODE)
_DIGITS = "0123456789"
# Служебные слова, не несущие смысла имени документа (предлоги/союзы ru+en). Двухбуквенные
# («по», «от», «of», «и») режутся правилом длины (в нижнем/«Заглавном» регистре), а в ВЕРХНЕМ
# («ПО» - программное обеспечение) это аббревиатура и остается; здесь - от трёх букв.
_STOPWORDS = frozenset({
    "для", "при", "под", "над", "без", "про", "через", "the", "and", "for", "with", "from",
    # «ver.3»/«rev 4»: точка/пробел режут версию на слово и число - слово тоже не смысл имени
    "ver", "vers", "rev", "изм",
})
# Двухбуквенные служебные слова: нужны ТОЛЬКО режиму запроса (в именах строчные коротышки режутся
# правилом длины, заглавные - аббревиатуры, и «ПО»/«ОТ» остаются).
_SHORT_STOPWORDS = frozenset({
    "по", "от", "на", "из", "до", "за", "со", "об", "ко", "во", "не", "ни",
    "or", "of", "in", "to", "on", "at", "an", "as", "by", "is", "it", "if",
})
# Служебные файлы каталога: скрытые и office-локи (``~$Отчёт.docx``) — не версии.
_IGNORED_PREFIXES = (".", "~$")

_DAY_S = 86400.0


@dataclass(frozen=True)
class Sibling:
    """Файл в том же каталоге с похожим именем и существенно более новой датой."""

    path: str
    mtime: float
    days_newer: float

    def to_dict(self) -> dict[str, object]:
        return {"path": self.path, "mtime": self.mtime, "days_newer": self.days_newer}


@dataclass(frozen=True)
class Freshness:
    """Свежесть файла в его каталоге: сосед новее (если есть) + позиция по дате.

    ``rank_by_date`` — 1 у самого нового файла каталога; ``of`` — сколько файлов в
    каталоге. Каталог из одного файла даёт ``1 из 1`` и ``newer_sibling=None`` —
    шума нет by design.
    """

    newer_sibling: Sibling | None = None
    rank_by_date: int = 1
    of: int = 1

    @property
    def family(self) -> dict[str, int]:
        """Позиционный контекст для выдачи (``{rank_by_date, of}``)."""
        return {"rank_by_date": self.rank_by_date, "of": self.of}


def newer_sibling_days() -> float:
    """Порог «существенно новее», дни (env ``DT_NEWER_SIBLING_DAYS``, дефолт 30).

    Мусор/непозитивное → дефолт (образец :func:`core.operational.dod.window_hours`).
    """
    raw = os.environ.get(_DAYS_ENV, "").strip()
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_NEWER_SIBLING_DAYS
    return value if value > 0 else DEFAULT_NEWER_SIBLING_DAYS


def name_tokens(name: str) -> frozenset[str]:
    """Значимые токены имени файла: без расширения, дат, версий, стоп-слов и коротышей.

    ``"Business plan KCT_2023 (v2).docx"`` → ``{"business", "plan", "kct"}``.

    **Один нормализатор имён (FIND-LATEST-1).** Имя приводится к NFC ДО разбиения: macOS
    отдаёт имена файлов в NFD, и разбиение по не-буквам резало «Сайзинг» по комбинирующему
    знаку (``саи`` + ``зинг``), «базовый» превращалось в ``базовыи``. NFD- и NFC-вход
    теперь дают одни токены.

    Двухбуквенный токен сохраняется, только если в исходнике он ЗАГЛАВНЫЙ (КП, ГМ, ЦТ,
    ТС, ТЗ, БП, АО - в именах К. смысл несут именно аббревиатуры); остальные - от 3
    символов. Стоп-слова (:data:`_STOPWORDS`), версии и чисто цифровые/датовые токены
    выбрасываются.

    Цифры срезаются и по краям приклеенных токенов (``"план2023"`` → ``"план"``):
    год, приклеенный к слову без разделителя — самый частый способ назвать версию,
    и именно на нём сравнение по токенам иначе разошлось бы.
    """
    stem = Path(unicodedata.normalize("NFC", str(name or ""))).stem
    return text_tokens(stem)


def text_tokens(text: str, *, query: bool = False) -> frozenset[str]:
    """Те же токены, что :func:`name_tokens`, для строки БЕЗ расширения (запрос поиска).

    ``name_tokens`` отрезает «расширение» по последней точке; у запроса («Acme.kz отчет») такого
    быть не должно. Правила одни: NFC, коротышки только заглавные, стоп-слова, версии, даты.
    ``query=True``: человек пишет запрос строчными («кп acme»), поэтому двухбуквенный токен
    сохраняется в любом регистре, кроме двухбуквенных служебных слов (:data:`_SHORT_STOPWORDS`).
    """
    out = set()
    for raw in _SPLIT_RE.split(unicodedata.normalize("NFC", str(text or ""))):
        if _VERSION_RE.match(raw):
            continue
        token = raw.strip(_DIGITS)
        short_ok = len(token) == 2 and (token.isupper() or query)
        if len(token) < 3 and not short_ok:
            continue
        token = token.lower()
        if token in _STOPWORDS or (query and len(token) == 2 and token in _SHORT_STOPWORDS):
            continue
        out.add(token)
    return frozenset(out)


def _norm_prefix_key(name: str) -> str:
    """Имя без расширения, пунктуации и цифр — для сравнения общего префикса."""
    stem = Path(unicodedata.normalize("NFC", str(name or ""))).stem.lower()
    return "".join(ch for ch in stem if ch.isalpha())


def similar_names(a: str, b: str) -> bool:
    """Похожи ли имена настолько, чтобы считать файлы версиями одного документа.

    Два дешёвых правила (ТЗ: НЕ изобретать НЛП) — достаточно любого:

    1. значимые токены (:func:`name_tokens`) пересекаются на :data:`_MIN_OVERLAP`
       от более короткого набора — «КП Эмба 2023» ↔ «КП Эмба финал 2026»;
    2. общий префикс нормализованных имён ≥ :data:`_MIN_PREFIX` символов —
       «Business plan KCT 2023» ↔ «Business plan 2026-2029».
    """
    ta, tb = name_tokens(a), name_tokens(b)
    if ta and tb:
        common = ta & tb
        if common and len(common) / min(len(ta), len(tb)) >= _MIN_OVERLAP:
            return True
    ka, kb = _norm_prefix_key(a), _norm_prefix_key(b)
    if not ka or not kb:
        return False
    # commonprefix — посимвольный общий префикс (не только про пути); своего цикла не надо
    return len(os.path.commonprefix([ka, kb])) >= _MIN_PREFIX


# Класс носителя по расширению: версии одного документа живут в одном классе (КП - docx/pdf,
# расчет - xlsx, дека - pptx). Приемка FIND-LATEST-1 27.10: без этого «Acme_расчеты КП_2026.xlsx»
# стал «новее версией» для «КП_Acme_Телекон.docx» - расчетный лист не версия предложения.
# ``pdf`` - экспорт и документа, и деки → совместим с любым классом; незнакомое расширение
# совместимо только с самим собой.
_KIND_CLASSES: dict[str, frozenset[str]] = {
    "text": frozenset({".doc", ".docx", ".odt", ".rtf", ".txt", ".md", ".pages"}),
    "sheet": frozenset({".xls", ".xlsx", ".xlsm", ".csv", ".numbers", ".ods"}),
    "deck": frozenset({".ppt", ".pptx", ".key", ".odp"}),
}
_KIND_ANY = frozenset({".pdf"})


def kind_class(name: str) -> str:
    """Класс носителя файла: ``text`` | ``sheet`` | ``deck`` | ``any`` (pdf) | само расширение."""
    ext = Path(str(name or "")).suffix.lower()
    if ext in _KIND_ANY:
        return "any"
    for cls, exts in _KIND_CLASSES.items():
        if ext in exts:
            return cls
    return ext or "?"


def compatible_kinds(a: str, b: str) -> bool:
    """Могут ли два файла быть версиями одного документа по классу носителя."""
    ka, kb = kind_class(a), kind_class(b)
    return ka == kb or "any" in (ka, kb)


def family_files(directory: Path | str) -> list[tuple[str, float]]:
    """``[(путь, mtime)]`` файлов каталога, новые сверху — ОДИН ``scandir``.

    Скрытые и office-локи пропускаются, подкаталоги не обходятся (семейство —
    плоская папка версий). Нечитаемый каталог → ``[]`` (никогда не исключение:
    свежесть — подсказка, а не операция). Порядок детерминирован: при равной дате — по пути.
    """
    out: list[tuple[str, float]] = []
    try:
        with os.scandir(str(directory)) as it:
            for entry in it:
                if entry.name.startswith(_IGNORED_PREFIXES):
                    continue
                if is_eval(entry.path):  # EVAL-HYGIENE-1: карантин прогонов - не версия документа
                    continue
                try:
                    if not entry.is_file():
                        continue
                    out.append((entry.path, entry.stat().st_mtime))
                except OSError:
                    continue
    except OSError:
        return []
    out.sort(key=lambda item: (-item[1], item[0]))
    return out


@dataclass(frozen=True)
class Member:
    """Член семейства: файл, его дата и пометки по маркерам имени/папки (или ``status`` заметки)."""

    path: str
    mtime: float
    draft: bool = False
    archived: bool = False

    def to_dict(self) -> dict[str, object]:
        return {"path": self.path, "mtime": self.mtime,
                "draft": self.draft, "archived": self.archived}


@dataclass(frozen=True)
class Family:
    """Семейство версий ВОКРУГ файла ``seed`` (а не вся папка): звезда от seed по похожести имён.

    ``members`` — новые сверху (при равной дате — по пути). ``latest`` — новейший не-``archived``
    (все архивные → новейший вообще, он помечен ``archived``: ответ остается ответом, но
    честным); ``latest_final`` — новейший не-``draft`` и не-``archived``, ``None``, если такого
    нет (все черновики/архив: действующей версии в семействе нет, и это не прячется).
    """

    directory: str
    seed: str
    members: tuple[Member, ...] = ()
    latest: Member | None = None
    latest_final: Member | None = None

    @property
    def versions(self) -> int:
        return len(self.members)

    def shared_tokens(self) -> list[str]:
        """Токены имён, общие для не менее половины членов (отсортированы): «о чем семейство»."""
        if not self.members:
            return []
        counts: dict[str, int] = {}
        for m in self.members:
            for tok in name_tokens(Path(m.path).name):
                counts[tok] = counts.get(tok, 0) + 1
        need = (len(self.members) + 1) // 2
        return sorted(tok for tok, n in counts.items() if n >= need)


def family_of(
    path: Path | str,
    *,
    files: list[tuple[str, float]] | None = None,
    markers: Markers | None = None,
    mtime: float | None = None,
    draft_paths: Collection[str] = (),
) -> Family:
    """Семейство версий вокруг файла ``path``: файлы ТОЙ ЖЕ папки, похожие на него именем.

    Звезда от seed: член - файл, похожий на ``seed`` по :func:`similar_names` (транзитивности
    нет: «А~Б, Б~В» не делает В членом семейства А). Один листинг :func:`family_files`
    (``files`` - уже снятый вызывающим), содержимое файлов не читается. Папка нечитаема →
    семейство из одного seed (если известен ``mtime``) или пустое: подсказка не операция.

    ``markers`` - :class:`core.sources.markers.Markers` (по умолчанию - файл vault/запасной
    набор); ``draft_paths`` - пути, которые вызывающий уже знает черновиками (``status: draft``
    заметки vault с этим файловым источником).
    """
    from core.sources.markers import classify, load_markers

    target = Path(str(path))
    target_str = str(target)
    listing = family_files(target.parent) if files is None else list(files)
    marks = markers if markers is not None else load_markers()
    drafts = {str(p) for p in draft_paths}

    def member(p: str, m: float) -> Member:
        d, a = classify(Path(p).name, Path(p).parent.name, marks)
        return Member(path=p, mtime=m, draft=d or p in drafts, archived=a)

    picked = [(p, m) for p, m in listing
              if p == target_str
              or (compatible_kinds(p, target_str) and similar_names(Path(p).name, target.name))]
    if not any(p == target_str for p, _m in picked) and mtime is not None:
        picked.append((target_str, mtime))  # файл не в листинге (исчез/переехал) - дата вызывающего
    picked.sort(key=lambda item: (-item[1], item[0]))
    members = tuple(member(p, m) for p, m in picked)
    latest = next((m for m in members if not m.archived), members[0] if members else None)
    final = next((m for m in members if not m.draft and not m.archived), None)
    return Family(directory=str(target.parent), seed=target_str, members=members,
                  latest=latest, latest_final=final)


def directory_freshness(
    path: Path | str, *, mtime: float | None = None, days: float | None = None
) -> Freshness:
    """Свежесть файла ``path`` среди ВЕРСИЙ СВОЕГО СЕМЕЙСТВА (:func:`family_of`, один листинг).

    ``rank_by_date`` и ``of`` считаются ВНУТРИ семейства («2-й из 4 версий», а не «10-й из 23
    файлов папки»); ``newer_sibling`` - файл того же семейства с датой новее порога.

    ``mtime`` — дата самого файла, если она уже известна вызывающему (подъём её уже
    сделал); иначе берётся из листинга. ``days`` переопределяет порог
    :func:`newer_sibling_days` (для тестов и вызовов с явной политикой).

    Файла нет / каталог нечитаем → нейтральный :class:`Freshness` (``1 из 1``, без
    соседа): отсутствие сигнала честнее выдуманного.
    """
    target = Path(str(path))
    target_str = str(target)
    fam = family_of(target, mtime=mtime)
    if not fam.members:
        return Freshness()
    own = next((m.mtime for m in fam.members if m.path == target_str), None)
    if own is None:
        return Freshness(of=len(fam.members))

    rank = sum(1 for m in fam.members if m.mtime > own) + 1
    threshold = (days if days is not None and days > 0 else newer_sibling_days()) * _DAY_S
    newest: Sibling | None = None
    for m in fam.members:  # члены отсортированы: первый подходящий — самый новый
        if m.path == target_str or m.mtime - own <= threshold:
            continue
        newest = Sibling(path=m.path, mtime=m.mtime, days_newer=round((m.mtime - own) / _DAY_S, 1))
        break
    return Freshness(newer_sibling=newest, rank_by_date=rank, of=len(fam.members))
