"""Сколько файлов ingest-корней не локальны в iCloud (SRC-ICLOUD-1, доктор «Источники: iCloud»).

Только ``lstat`` + флаг ``SF_DATALESS`` (``st_flags``): файл не открывается и не материализуется.
Бюджет по времени: огромный корень дает честный ``partial``, а не зависание доктора. Вне macOS
(нет ``st_flags``) все файлы считаются локальными - счетчик 0, ``applicable=False``.
"""

from __future__ import annotations

import os
import sys
import time
from typing import Any

from core.fsguard import SF_DATALESS, cloud_provider

__all__ = ["count_not_local"]

_DEFAULT_BUDGET_S = 5.0


def count_not_local(roots: list[Any], *, budget_s: float = _DEFAULT_BUDGET_S) -> dict[str, Any]:
    """Обойти корни (объекты с ``.name``/``.path``), посчитать файлы с флагом dataless.

    Возвращает ``{applicable, scanned, not_local, roots: {имя: n}, providers: {провайдер: n},
    partial, elapsed_s}``.
    """
    out: dict[str, Any] = {
        "applicable": sys.platform == "darwin", "scanned": 0, "not_local": 0,
        "roots": {}, "providers": {}, "partial": False, "elapsed_s": 0.0,
    }
    if not out["applicable"]:
        return out
    started = time.monotonic()
    deadline = started + budget_s
    for root in roots:
        n = 0
        base = str(root.path)
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = sorted(d for d in dirnames if not d.startswith("."))
            for name in filenames:
                if name.startswith("."):
                    continue
                try:
                    st = os.lstat(os.path.join(dirpath, name))
                except OSError:
                    continue
                out["scanned"] += 1
                if getattr(st, "st_flags", 0) & SF_DATALESS:
                    n += 1
            if time.monotonic() > deadline:
                out["partial"] = True
                break
        out["roots"][str(root.name)] = n
        out["not_local"] += n
        if n:  # PERSONAL-2: провайдер по пути корня (OneDrive / iCloud)
            prov = cloud_provider(base)
            out["providers"][prov] = out["providers"].get(prov, 0) + n
        if out["partial"]:
            break
    out["elapsed_s"] = round(time.monotonic() - started, 3)
    return out
