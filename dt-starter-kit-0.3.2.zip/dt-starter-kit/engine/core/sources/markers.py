"""FIND-LATEST-1 — маркеры «черновик» и «архив» в именах файлов и папок как ДАННЫЕ.

«Самый новый файл семейства» не равен «действующему»: рядом с планом лежит ``…черновик.docx``
новее финала, а в папке ``Архив`` - копии, которые не версия вообще. Раньше ни то ни другое из
имени не читалось. Теперь список слов - ``vault/_system/freshness-markers.yaml`` (правится
текстом в Obsidian), запасной набор :data:`DEFAULT_YAML` - в коде (тест держит их равными).

* ``draft`` - член семейства черновик: ``latest_final`` его пропускает;
* ``archived`` - член устарел/сломан копией: пропускает и ``latest``.

Матч - по ТОКЕНАМ имени файла И имени папки-родителя, целым словом (или целой фразой подряд
идущих слов): «проектирование» не черновик, «проект документа» - да. Регистр и NFD/NFC не
важны. Содержимое файлов не читается, только имена.

Нет файла - запасной набор (штатно); пустой/битый yaml - тот же запасной набор И ``warnings``
с кодом ``store_unavailable`` + запись в лог (§9 п.22: не молча). Парсинг кэшируется по
``mtime``+размеру файла (образец :mod:`core.legacy.mail_filter`).
"""

from __future__ import annotations

import logging
import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]

from core.contract import CODE_STORE_UNAVAILABLE, warning

logger = logging.getLogger(__name__)

__all__ = [
    "DEFAULT_YAML",
    "Markers",
    "MarkersError",
    "classify",
    "load_markers",
    "lint_file",
    "parse_markers",
]

SECTIONS = ("draft", "archived")

# Запасной набор = начальный vault/_system/freshness-markers.yaml (тест держит их равными).
DEFAULT_YAML = """\
# Маркеры черновика/архива в именах файлов и папок (FIND-LATEST-1).
# Читает core/sources/markers.py; правится текстом. Матч - целым словом (или фразой подряд) по имени
# файла И имени папки-родителя; «проектирование» не черновик, «проект документа» - да.
# draft    - найденная версия помечается draft; find_latest отдает latest_final без нее.
# archived - файл не считается ни latest, ни latest_final.
version: 1
draft:
  - черновик
  - черновики
  - draft
  - drafts
  - проект документа
  - рабочая версия
  - wip
archived:
  - архив
  - old
  - backup
  - копия
  - copy
  - superseded
"""

_SPLIT_RE = re.compile(r"[\W_]+", re.UNICODE)
_DIGITS = "0123456789"


class MarkersError(ValueError):
    """Файл маркеров нельзя разобрать (причина - в тексте, для lint и warning)."""


@dataclass(frozen=True)
class Markers:
    """Маркеры как кортежи слов (фраза = несколько слов подряд) + откуда набор."""

    draft: tuple[tuple[str, ...], ...] = ()
    archived: tuple[tuple[str, ...], ...] = ()
    source: str = "defaults"  # file | defaults
    path: str = ""
    warnings: list[dict[str, Any]] = field(default_factory=list)

    def total(self) -> int:
        return len(self.draft) + len(self.archived)


def _words(text: str) -> list[str]:
    """Слова строки: NFC, нижний регистр, цифры по краям срезаны («copy2» → «copy»)."""
    norm = unicodedata.normalize("NFC", str(text or "")).lower()
    return [w for w in (raw.strip(_DIGITS) for raw in _SPLIT_RE.split(norm)) if w]


def parse_markers(text: str, *, source: str = "file", path: str = "") -> Markers:
    """YAML-текст → :class:`Markers`. Ошибка структуры - :class:`MarkersError` (не пустой набор)."""
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise MarkersError(f"yaml не разбирается: {str(exc)[:160]}") from exc
    if not isinstance(data, dict):
        raise MarkersError("в файле нет разделов draft/archived (ожидается mapping)")
    unknown = sorted(set(data) - set(SECTIONS) - {"version"})
    if unknown:
        raise MarkersError(f"неизвестные разделы: {', '.join(map(str, unknown))}")
    parsed: dict[str, tuple[tuple[str, ...], ...]] = {}
    for section in SECTIONS:
        items = data.get(section) or []
        if not isinstance(items, list):
            raise MarkersError(f"{section}: ожидается список")
        phrases: list[tuple[str, ...]] = []
        for raw in items:
            if not isinstance(raw, str):
                raise MarkersError(f"{section}: маркер должен быть строкой: {raw!r}")
            words = tuple(_words(raw))
            if not words:
                raise MarkersError(f"{section}: пустой маркер {raw!r}")
            if words not in phrases:
                phrases.append(words)
        parsed[section] = tuple(phrases)
    markers = Markers(draft=parsed["draft"], archived=parsed["archived"], source=source, path=path)
    if not markers.total():
        raise MarkersError("файл маркеров пуст (ни одного маркера)")
    return markers


def _defaults(warnings_: list[dict[str, Any]] | None = None, path: str = "") -> Markers:
    base = parse_markers(DEFAULT_YAML, source="defaults", path=path)
    return Markers(draft=base.draft, archived=base.archived, source="defaults", path=path,
                   warnings=list(warnings_ or []))


_CACHE: dict[str, tuple[int, int, Markers]] = {}


def load_markers(vault_path: Path | None = None, *, path: Path | None = None) -> Markers:
    """Набор маркеров: файл (кэш по mtime+размеру) → иначе запасной набор из кода.

    Нет файла → запасной набор (штатно, без предупреждения: машина без vault/тесты). Файл есть,
    но пустой/битый → запасной набор И ``warnings`` с кодом ``store_unavailable`` + лог.
    """
    from core.config import freshness_markers_path

    target = path if path is not None else freshness_markers_path(vault_path)
    key = str(target)
    try:
        st = target.stat()
    except OSError:
        _CACHE.pop(key, None)
        return _defaults(path=key)
    stamp = (st.st_mtime_ns, st.st_size)
    cached = _CACHE.get(key)
    if cached is not None and cached[:2] == stamp:
        return cached[2]
    try:
        markers = parse_markers(target.read_text(encoding="utf-8"), path=key)
    except (MarkersError, OSError, UnicodeDecodeError) as exc:
        why = str(exc)[:200]
        logger.warning(
            "[freshness-markers] %s: %s - работает запасной набор маркеров (%s)",
            target.name, why, CODE_STORE_UNAVAILABLE,
        )
        markers = _defaults(
            [warning(CODE_STORE_UNAVAILABLE,
                     f"маркеры черновика/архива не прочитались ({target.name}: {why}); "
                     "работает запасной набор из кода",
                     path=key)],
            path=key,
        )
    _CACHE[key] = (stamp[0], stamp[1], markers)
    return markers


def lint_file(path: Path) -> list[str]:
    """Проблемы файла маркеров текстом (пусто - файл здоров). Для проверок и тестов."""
    try:
        parse_markers(path.read_text(encoding="utf-8"), path=str(path))
    except (MarkersError, OSError, UnicodeDecodeError) as exc:
        return [str(exc)]
    return []


def _hit(words: list[str], phrases: tuple[tuple[str, ...], ...]) -> bool:
    for phrase in phrases:
        n = len(phrase)
        if n == 1:
            if phrase[0] in words:
                return True
            continue
        if any(tuple(words[i:i + n]) == phrase for i in range(len(words) - n + 1)):
            return True
    return False


def classify(name: str, parent: str, markers: Markers) -> tuple[bool, bool]:
    """``(draft, archived)`` для файла ``name`` в папке ``parent`` (имена, не пути).

    Слова имени файла (без расширения) и имени папки сравниваются ВМЕСТЕ как два отдельных
    списка: фраза не склеивается через границу «файл | папка».
    """
    stem = Path(unicodedata.normalize("NFC", str(name or ""))).stem
    lists = [_words(stem), _words(parent)]
    draft = any(_hit(words, markers.draft) for words in lists)
    archived = any(_hit(words, markers.archived) for words in lists)
    return draft, archived
