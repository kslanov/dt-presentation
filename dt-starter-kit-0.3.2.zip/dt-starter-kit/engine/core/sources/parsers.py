"""Structural + text parsers for runtime source lift (SRC-1, PART-1).

Two layers over one file:

- **Text layer (reused).** :func:`core.legacy.extract.extract` already gives a
  deterministic, provenance-carrying ``text`` for every supported type (xlsx /
  docx / pptx / pdf / …). We reuse it verbatim — no duplicated parsing.
- **Structural layer (new).** The legacy xlsx extractor *flattens* a sheet into
  tab-joined text and **drops cell coordinates** (:func:`_parse_xlsx_file`), so a
  downstream fact-typer cannot tell ``480`` at ``B7`` from ``654,1`` at ``B9``.
  This module adds a cell-addressable :class:`Table` (``sheet!ref`` per cell) that
  keeps coordinates intact — empty cells are never collapsed into a neighbour's
  position (the coordinate is the locator).

Everything here is offline and deterministic (Path B). Parser libraries live in
the optional ``parsers`` extra and are lazy-imported; when the extra is absent the
resolver degrades to ``status="unavailable"`` rather than crashing (see
:class:`ParsersUnavailable`).
"""

from __future__ import annotations

import importlib.util
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.legacy.extract import extract

__all__ = [
    "Cell",
    "Row",
    "Table",
    "ParsedContent",
    "ParsersUnavailable",
    "parse_source",
    "STRUCTURAL_KINDS",
    "LIFT_VERSION",
]

# Spreadsheet kinds that get the cell-addressable structural lift: openpyxl (xlsx/xlsm), xlrd
# (legacy xls, FACT-2), pyxlsb (xlsb, FACT-2), stdlib csv (FACT-2). Other supported kinds
# (docx/pptx/pdf/…) get the text layer + best-effort tables.
STRUCTURAL_KINDS = frozenset({"xlsx", "xlsm", "xls", "xlsb", "csv"})

# FACT-2: версия структурного подъема. Меняется, когда в ``Table`` появляется то, чего не было в
# старых записях L2-кеша (``merges``): запись без нее (или с меньшей) для таблично-структурного вида
# считается устаревшей и перечитывается (:func:`core.sources.resolver.lift`).
LIFT_VERSION = 3  # 3: приемка FACT-2 29.10 - записи с merges-строками промежуточной сборки

# Module needed for the structural xlsx lift; checked before parsing so a missing
# extra becomes a soft "unavailable", never an ImportError mid-lift.
_XLSX_MODULE = "openpyxl"


class ParsersUnavailable(RuntimeError):
    """The ``parsers`` extra needed for a kind is not installed (soft failure).

    Raised by :func:`parse_source`; the resolver turns it into
    ``LiftResult(status="unavailable", reason=…)`` so an un-provisioned machine
    degrades gracefully instead of crashing (same contract as the Outlook bridge).
    """


@dataclass
class Cell:
    """One non-empty spreadsheet cell with its coordinate.

    ``col`` is the column letter (``"B"``), ``ref`` the full A1 reference
    (``"B7"``) — the back-traceable locator ``sheet!ref`` is ``f"{sheet}!{ref}"``.
    ``is_number`` marks a numeric value (int/float, excluding bool) so a fact
    typer can trust it as a quantity without re-parsing the string form.
    """

    col: str
    ref: str
    value: Any
    is_number: bool


@dataclass
class Row:
    """A worksheet row: its 1-based number ``r`` and its non-empty ``cells``.

    Only non-empty cells are carried, but each keeps its true coordinate, so an
    empty ``A7`` never shifts ``B7`` left to ``A7`` — coordinates are preserved.
    """

    r: int
    cells: list[Cell] = field(default_factory=list)


@dataclass
class Table:
    """One worksheet lifted with coordinates intact.

    ``merges`` (FACT-2) - объединенные диапазоны листа ``(min_row, min_col, max_row, max_col)``,
    1-based включительно: объединенная ячейка несет значение только в левой верхней клетке,
    остальные пусты, поэтому без диапазонов «верхняя» шапка колонок E-F теряется. Ячейки НЕ
    дублируются по диапазону - ``rows`` те же, что без объединений (пустой список - как раньше, в
    сериализации ключа нет).
    """

    sheet: str
    rows: list[Row] = field(default_factory=list)
    merges: list[tuple[int, int, int, int]] = field(default_factory=list)


@dataclass
class ParsedContent:
    """Result of parsing one source file (before the resolver wraps it).

    ``text`` is the reused flat text layer; ``tables`` the new structural layer
    (populated for spreadsheets); ``meta`` carries per-type extras (sheet names,
    page/slide counts); ``truncated`` flags that a cell cap was hit and
    ``cells_lifted`` counts the non-empty cells actually captured; ``has_formulas``
    drives the resolver's ``stale_hint`` (a formula workbook read via
    ``data_only`` returns *cached* values that can be stale).
    """

    kind: str
    text: str = ""
    tables: list[Table] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)
    truncated: bool = False
    cells_lifted: int = 0
    has_formulas: bool = False
    # Text-layer disposition from the legacy extractor: ``ok`` / ``skipped`` /
    # ``error`` (with ``reason`` when not ok). The resolver maps this into its own
    # status vocabulary.
    text_status: str = "ok"
    reason: str = ""
    # FACT-2: честные оговорки подъема (``{"code", "reason"}``): например ``merges_skipped`` -
    # объединенные шапки не прочитаны (большой файл / формат без объединений). Резолвер кладет их
    # в ``meta["warnings"]`` (так они переживают L2-кеш), ``get_facts`` выносит в конверт.
    warnings: list[dict[str, str]] = field(default_factory=list)


def _module_available(name: str) -> bool:
    """Whether an optional parser module is importable (monkeypatchable in tests)."""
    return importlib.util.find_spec(name) is not None


def parse_source(
    path: Path, kind: str, *, max_cells: int, max_pages: int
) -> ParsedContent:
    """Parse ``path`` into a :class:`ParsedContent` (structural + text layers).

    ``kind`` is the lowercased extension (``"xlsx"``/``"pdf"``/…). Spreadsheets in
    :data:`STRUCTURAL_KINDS` get the coordinate-preserving table lift capped at
    ``max_cells``; every supported kind also gets the reused text layer. Raises
    :class:`ParsersUnavailable` if the extra needed for ``kind`` is absent (the
    resolver softens it to ``status="unavailable"``). Never mutates the file.
    """
    if kind in ("xlsx", "xlsm"):
        if not _module_available(_XLSX_MODULE):
            raise ParsersUnavailable(
                f"parsers extra not installed ({_XLSX_MODULE} missing) — "
                "run `uv sync --extra parsers`"
            )
        return _parse_xlsx(path, kind, max_cells=max_cells)
    if kind == "xls":
        if not _module_available("xlrd"):
            raise ParsersUnavailable(
                "parsers extra not installed (xlrd missing) — run `uv sync --extra parsers`"
            )
        return _parse_xls(path, kind, max_cells=max_cells)
    if kind == "xlsb":
        if not _module_available("pyxlsb"):
            raise ParsersUnavailable(
                "parsers extra not installed (pyxlsb missing) — run `uv sync --extra parsers`"
            )
        return _parse_xlsb(path, kind, max_cells=max_cells)
    if kind == "csv":
        return _parse_csv(path, kind, max_cells=max_cells)

    # Non-spreadsheet: text layer only (best-effort). The legacy extractor
    # lazy-imports its lib and returns status="error" if the extra is missing;
    # translate that specific case into ParsersUnavailable so the resolver reports
    # a soft "unavailable" rather than a hard "error".
    doc = extract(path)
    if doc.status == "error" and _looks_like_missing_parser(doc.error):
        raise ParsersUnavailable(doc.error)
    return ParsedContent(
        kind=kind,
        text=doc.text,
        tables=[],
        meta=dict(doc.meta),
        text_status=doc.status,
        reason=doc.error or doc.skip_reason,
    )


def _looks_like_missing_parser(error: str) -> bool:
    """Heuristic: an extractor error that means "optional parser lib absent"."""
    lowered = (error or "").lower()
    return (
        "modulenotfounderror" in lowered
        or "no module named" in lowered
        or "not installed" in lowered
    )


def _parse_xlsx(path: Path, kind: str, *, max_cells: int) -> ParsedContent:
    """xlsx/xlsm → cell-addressable :class:`Table` per sheet + reused text layer.

    Values come from a ``data_only=True, read_only=True`` load (Excel's cached
    formula results — correct for sums, but stale if the file was never re-saved,
    hence the separate formula probe → ``has_formulas``). Empty cells are skipped
    but never collapse a neighbour's coordinate. The non-empty-cell count is
    capped at ``max_cells`` across all sheets; on overflow the lift stops and
    ``truncated`` is set.
    """
    import openpyxl  # type: ignore[import-untyped]
    from openpyxl.utils import get_column_letter  # type: ignore[import-untyped]

    tables: list[Table] = []
    sheet_titles: list[str] = []
    cells_lifted = 0
    truncated = False

    wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
    try:
        sheet_titles = list(wb.sheetnames)
        for ws in wb.worksheets:
            table = Table(sheet=ws.title)
            for row in ws.iter_rows():
                if truncated:
                    break
                cells: list[Cell] = []
                r_no: int | None = None
                for cell in row:
                    value = cell.value
                    if value is None or (isinstance(value, str) and not value.strip()):
                        continue
                    r_no = cell.row
                    col = get_column_letter(cell.column)
                    is_number = isinstance(value, (int, float)) and not isinstance(
                        value, bool
                    )
                    value = _jsonable_value(value)
                    cells.append(
                        Cell(
                            col=col,
                            ref=f"{col}{cell.row}",
                            value=value,
                            is_number=is_number,
                        )
                    )
                    cells_lifted += 1
                    if cells_lifted >= max_cells:
                        truncated = True
                        break
                if cells and r_no is not None:
                    table.rows.append(Row(r=r_no, cells=cells))
            if table.rows:
                tables.append(table)
            if truncated:
                break
    finally:
        wb.close()

    probe = _xlsx_has_formulas(path, cap=max_cells)
    # ADAPTER-HONEST-1: «не смогли проверить» ≠ «формул нет». Раньше сбой пробы и упор в
    # cap давали False — книга с формулами и непрогретым кэшем выглядела надёжной. Теперь
    # неизвестное поднимает stale_hint (консервативно) и называет причину в meta.
    has_formulas = True if probe is None else probe

    # Reuse the flat text layer verbatim (ТЗ: text present alongside structure).
    doc = extract(path)

    warnings: list[dict[str, str]] = []
    cap_mb = merge_max_mb()
    size_mb = path.stat().st_size / (1024 * 1024)
    if size_mb > cap_mb:
        warnings.append({
            "code": "merges_skipped",
            "reason": f"файл {size_mb:.1f} МБ > {cap_mb:g} МБ (DT_XLSX_MERGE_MAX_MB): объединенные "
                      "шапки не читались - верхний ярус шапки колонок может отсутствовать",
        })
    else:
        merges = _xlsx_merges(path)
        for table in tables:
            table.merges = merges.get(table.sheet, [])

    meta: dict[str, Any] = {"sheets": sheet_titles, "lift_version": LIFT_VERSION}
    if probe is None:
        meta["formula_probe"] = "unknown"
    if truncated:
        meta["cell_cap"] = max_cells
    return ParsedContent(
        kind=kind,
        text=doc.text,
        tables=tables,
        meta=meta,
        truncated=truncated,
        cells_lifted=cells_lifted,
        has_formulas=has_formulas,
        text_status=doc.status if doc.status != "error" else "ok",
        reason=doc.error if doc.status == "error" else "",
        warnings=warnings,
    )


def _jsonable_value(value: Any) -> Any:
    """Coerce a cell value to a JSON-serializable form for the L2 cache.

    openpyxl returns ``datetime``/``date``/``time`` for date-formatted cells,
    which the ``<content_hash>.json`` cache cannot serialize — normalize them to
    ISO strings so the lift roundtrips identically on a cache hit (and a downstream
    fact typer sees a stable string for dates). Other types pass through.
    """
    import datetime as _dt

    if isinstance(value, (_dt.datetime, _dt.date, _dt.time)):
        return value.isoformat()
    return value


def _xlsx_has_formulas(path: Path, *, cap: int) -> bool | None:
    """Whether the workbook holds any formula cell (drives ``stale_hint``).

    A second, ``data_only=False`` read that short-circuits on the first formula
    (``data_type == "f"``) so it is cheap on the common case and bounded by ``cap``
    on the pathological one. Tri-state (ADAPTER-HONEST-1): ``True`` — formula found;
    ``False`` — the whole workbook was scanned within ``cap`` and none exists;
    ``None`` — UNKNOWN (read error or ``cap`` reached before the end): the caller must
    not claim "no formulas". ``data_only=True`` gives Excel's *cached* value, so a
    workbook full of formulas whose cache was never refreshed is exactly the
    staleness risk this flag warns about.
    """
    import openpyxl  # type: ignore[import-untyped]

    seen = 0
    wb = openpyxl.load_workbook(str(path), data_only=False, read_only=True)
    try:
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                for cell in row:
                    if getattr(cell, "data_type", None) == "f":
                        return True
                    seen += 1
                    if seen >= cap:
                        return None
        return False
    except Exception:  # noqa: BLE001 — staleness probe must never break a lift
        return None
    finally:
        wb.close()


# --------------------------------------------------------------------------- #
# FACT-2: объединенные диапазоны xlsx, legacy .xls, .csv                       #
# --------------------------------------------------------------------------- #

_MERGE_RE = re.compile(rb'<mergeCell\s+ref="([A-Za-z]+)(\d+):([A-Za-z]+)(\d+)"')
_MAX_SHEET_XML = 256 * 1024 * 1024  # страховка от гигантского XML листа
_MERGE_MAX_MB_ENV = "DT_XLSX_MERGE_MAX_MB"
_MERGE_MAX_MB_DEFAULT = 8.0


def merge_max_mb() -> float:
    """Порог размера файла (МБ), выше которого объединенные шапки xlsx не читаются."""
    import os

    raw = (os.environ.get(_MERGE_MAX_MB_ENV) or "").strip()
    try:
        value = float(raw)
    except ValueError:
        return _MERGE_MAX_MB_DEFAULT
    return value if value > 0 else _MERGE_MAX_MB_DEFAULT


def _col_index(letters: str) -> int:
    """Буквы колонки → 1-based индекс (``A``→1, ``AA``→27)."""
    n = 0
    for ch in letters.upper():
        n = n * 26 + (ord(ch) - ord("A") + 1)
    return n


def _xlsx_merges(path: Path) -> dict[str, list[tuple[int, int, int, int]]]:
    """Объединенные диапазоны по листам: ``{title: [(min_row, min_col, max_row, max_col), ...]}``.

    ``read_only`` openpyxl не отдает ``merged_cells``, а полная загрузка книги ради них дорога
    (книги до сотен тысяч ячеек). Диапазоны лежат в XML листа тегами ``<mergeCell ref=…/>`` -
    читаем их напрямую из zip (``workbook.xml`` + rels дают соответствие лист → файл). Любой сбой
    разбора - пустой результат: шапки без объединений хуже, чем без факта, но подъем не падает.
    """
    import xml.etree.ElementTree as ET
    import zipfile

    out: dict[str, list[tuple[int, int, int, int]]] = {}
    try:
        with zipfile.ZipFile(path) as zf:
            ns_main = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
            ns_rel = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
            wb = ET.fromstring(zf.read("xl/workbook.xml"))  # noqa: S314
            rels = ET.fromstring(zf.read("xl/_rels/workbook.xml.rels"))  # noqa: S314
            target_by_id = {
                r.get("Id"): (r.get("Target") or "") for r in rels
            }
            for sheet in wb.iter(f"{ns_main}sheet"):
                title = sheet.get("name") or ""
                target = target_by_id.get(sheet.get(f"{ns_rel}id"), "")
                if not title or not target:
                    continue
                member = target.lstrip("/") if target.startswith("/") else f"xl/{target}"
                try:
                    info = zf.getinfo(member)
                except KeyError:
                    continue
                if info.file_size > _MAX_SHEET_XML:
                    continue
                refs: list[tuple[int, int, int, int]] = []
                for c0, r0, c1, r1 in _MERGE_RE.findall(zf.read(member)):
                    box = (int(r0), _col_index(c0.decode()), int(r1), _col_index(c1.decode()))
                    if box[0] != box[2] or box[1] != box[3]:
                        refs.append(box)
                if refs:
                    out[title] = refs
    except Exception:  # noqa: BLE001 — объединения вторичны: сбой не ломает подъем
        return {}
    return out


def _col_letter(idx0: int) -> str:
    """0-based индекс колонки → буквы (0→A, 26→AA)."""
    n, letters = idx0 + 1, ""
    while n:
        n, rem = divmod(n - 1, 26)
        letters = chr(ord("A") + rem) + letters
    return letters


def _parse_xls(path: Path, kind: str, *, max_cells: int) -> ParsedContent:
    """Legacy ``.xls`` → :class:`Table` на лист (xlrd) + объединения + reused text layer.

    Значения - кэш Excel (формулы в BIFF хранят вычисленный результат). Отличить ячейку-формулу
    xlrd не позволяет, поэтому «формул нет» утверждать нельзя: ``stale_hint`` поднят, причина в
    ``meta["formula_probe"] = "unavailable"`` (ADAPTER-HONEST-1: неизвестное ≠ отсутствующее).
    Числа в xls всегда ``float`` (``3.0``) - экстрактор сам снимает хвост ``.0``.
    """
    import xlrd  # type: ignore[import-untyped]

    try:
        book = xlrd.open_workbook(str(path), formatting_info=True)
    except NotImplementedError:  # формат без поддержки formatting_info
        book = xlrd.open_workbook(str(path))
    tables: list[Table] = []
    cells_lifted = 0
    truncated = False
    try:
        for sheet in book.sheets():
            table = Table(sheet=sheet.name)
            for rx in range(sheet.nrows):
                if truncated:
                    break
                cells: list[Cell] = []
                for cx in range(sheet.ncols):
                    ctype = sheet.cell_type(rx, cx)
                    if ctype in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK, xlrd.XL_CELL_ERROR):
                        continue
                    raw = sheet.cell_value(rx, cx)
                    is_number = False
                    value: Any
                    if ctype == xlrd.XL_CELL_TEXT:
                        value = str(raw).strip()
                        if not value:
                            continue
                    elif ctype == xlrd.XL_CELL_NUMBER:
                        value, is_number = float(raw), True
                    elif ctype == xlrd.XL_CELL_DATE:
                        try:
                            value = xlrd.xldate_as_datetime(raw, book.datemode).isoformat()
                        except (xlrd.XLDateError, ValueError, OverflowError):
                            value, is_number = float(raw), True
                    elif ctype == xlrd.XL_CELL_BOOLEAN:
                        value = bool(raw)
                    else:
                        continue
                    col = _col_letter(cx)
                    cells.append(Cell(col=col, ref=f"{col}{rx + 1}", value=value,
                                      is_number=is_number))
                    cells_lifted += 1
                    if cells_lifted >= max_cells:
                        truncated = True
                        break
                if cells:
                    table.rows.append(Row(r=rx + 1, cells=cells))
            merged = getattr(sheet, "merged_cells", None) or []
            table.merges = [
                (rlo + 1, clo + 1, rhi, chi)  # xlrd: hi-границы исключающие → 1-based включающие
                for rlo, rhi, clo, chi in merged
                if (rhi - rlo) * (chi - clo) > 1
            ]
            if table.rows:
                tables.append(table)
            if truncated:
                break
        sheet_titles = [sh.name for sh in book.sheets()]
    finally:
        book.release_resources()
    doc = extract(path)
    meta: dict[str, Any] = {
        "sheets": sheet_titles, "lift_version": LIFT_VERSION, "formula_probe": "unavailable",
    }
    if truncated:
        meta["cell_cap"] = max_cells
    return ParsedContent(
        kind=kind, text=doc.text, tables=tables, meta=meta, truncated=truncated,
        cells_lifted=cells_lifted, has_formulas=True,
        text_status=doc.status if doc.status != "error" else "ok",
        reason=doc.error if doc.status == "error" else "",
    )


def _csv_text(path: Path) -> str:
    """Содержимое csv как текст: utf-8(-sig), иначе cp1251 (типичная выгрузка 1С/Excel-RU)."""
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp1251"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def _csv_delimiter(text: str) -> str:
    """Разделитель по первым строкам: тот, чье число вхождений в строке чаще всего одинаково.

    Кандидаты ``; \t | ,`` (при равенстве - в этом порядке: ``,`` последним, он же десятичный
    знак RU-чисел). Строки в кавычках не разбираются - для выбора разделителя это допустимая
    погрешность. Нет явного победителя - ``,``.
    """
    from collections import Counter

    lines = [ln for ln in text.splitlines() if ln.strip()][:30]
    best, best_score = ",", 0
    for cand in (";", "\t", "|", ","):
        counts = [ln.count(cand) for ln in lines if cand in ln]
        if not counts:
            continue
        mode, freq = Counter(counts).most_common(1)[0]
        score = freq * (1 if mode >= 1 else 0)
        if score > best_score:
            best, best_score = cand, score
    return best


def _parse_csv(path: Path, kind: str, *, max_cells: int) -> ParsedContent:
    """``.csv`` → один :class:`Table` (лист ``csv``); значения - строки как в файле.

    Разделитель - :func:`_csv_delimiter` (RU-выгрузки: ``;`` и десятичная запятая, на которой
    ``csv.Sniffer`` ошибается). Числа остаются СТРОКАМИ (``"654,1"``): ``is_number=False`` -
    экстрактор сам распознает числовую строку и сохранит оригинал в ``value_raw``. Объединений
    в csv нет.
    """
    import csv
    import io

    text = _csv_text(path)
    delimiter = _csv_delimiter(text)
    table = Table(sheet="csv")
    cells_lifted = 0
    truncated = False
    for rx, record in enumerate(csv.reader(io.StringIO(text), delimiter=delimiter), start=1):
        cells: list[Cell] = []
        for cx, raw in enumerate(record):
            value = raw.strip()
            if not value:
                continue
            col = _col_letter(cx)
            cells.append(Cell(col=col, ref=f"{col}{rx}", value=value, is_number=False))
            cells_lifted += 1
            if cells_lifted >= max_cells:
                truncated = True
                break
        if cells:
            table.rows.append(Row(r=rx, cells=cells))
        if truncated:
            break
    doc = extract(path)
    meta: dict[str, Any] = {
        "sheets": ["csv"], "lift_version": LIFT_VERSION,
        "delimiter": delimiter,
    }
    if truncated:
        meta["cell_cap"] = max_cells
    return ParsedContent(
        kind=kind, text=doc.text, tables=[table] if table.rows else [], meta=meta,
        truncated=truncated, cells_lifted=cells_lifted, has_formulas=False,
        text_status=doc.status if doc.status != "error" else "ok",
        reason=doc.error if doc.status == "error" else "",
    )


def _parse_xlsb(path: Path, kind: str, *, max_cells: int) -> ParsedContent:
    """``.xlsb`` → :class:`Table` на лист (pyxlsb). Объединений pyxlsb не отдает.

    Даты в xlsb - числа (формат ячейки pyxlsb не раскрывает) и остаются числами; формулы
    неотличимы от значений - ``stale_hint`` поднят (``formula_probe = "unavailable"``). Честная
    оговорка ``merges_skipped`` в ``warnings``: верхний ярус объединенных шапок не виден.
    """
    from pyxlsb import open_workbook  # type: ignore[import-untyped]

    tables: list[Table] = []
    cells_lifted = 0
    truncated = False
    with open_workbook(str(path)) as wb:
        titles = list(wb.sheets)
        for title in titles:
            table = Table(sheet=title)
            with wb.get_sheet(title) as sheet:
                for row in sheet.rows(sparse=True):
                    if truncated:
                        break
                    cells: list[Cell] = []
                    r_no = 0
                    for c in row:
                        value = c.v
                        if value is None or (isinstance(value, str) and not value.strip()):
                            continue
                        r_no = c.r + 1
                        col = _col_letter(c.c)
                        is_number = isinstance(value, (int, float)) and not isinstance(value, bool)
                        if isinstance(value, str):
                            value = value.strip()
                        cells.append(Cell(col=col, ref=f"{col}{r_no}", value=value,
                                          is_number=is_number))
                        cells_lifted += 1
                        if cells_lifted >= max_cells:
                            truncated = True
                            break
                    if cells:
                        table.rows.append(Row(r=r_no, cells=cells))
            if table.rows:
                tables.append(table)
            if truncated:
                break
    doc = extract(path)
    meta: dict[str, Any] = {
        "sheets": titles, "lift_version": LIFT_VERSION, "formula_probe": "unavailable",
    }
    if truncated:
        meta["cell_cap"] = max_cells
    return ParsedContent(
        kind=kind, text=doc.text, tables=tables, meta=meta, truncated=truncated,
        cells_lifted=cells_lifted, has_formulas=True,
        text_status=doc.status if doc.status != "error" else "ok",
        reason=doc.error if doc.status == "error" else "",
        warnings=[{"code": "merges_skipped",
                   "reason": "xlsb: объединенные шапки не читаются (pyxlsb не отдает диапазоны)"}],
    )
