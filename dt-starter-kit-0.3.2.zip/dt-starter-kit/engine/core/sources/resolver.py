"""Runtime source resolution + lift (SRC-1, PART-2 & PART-5).

:func:`resolve_ref` turns a ``note_id`` or an explicit ``path`` into a
:class:`SourceRef` (an existing, content-hashed, absolute file), following a
deterministic, inspectable order (PART-5). :func:`lift` then reads that file
**read-only**, within a :class:`Budget` (timeout + cell cap), into a
:class:`LiftResult` carrying the structural tables (with ``sheet!ref`` locators),
the reused text layer, a freshness hint, and a status. :func:`lift_from` is the
convenience that does both and never raises for an expected condition (missing
file / field / note) — it returns ``status="unavailable"`` with a clear reason.

Path B: offline, deterministic, no network, no LLM. The only side effect is the
L2 cache write under ``.derived/sources/`` (rebuildable).
"""

from __future__ import annotations

import errno
import logging
import sys
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutureTimeout
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.config import default_vault_path, icloud_download_s, legacy_roots, sources_cell_cap
from core.contract import CODE_SOURCE_NOT_LOCAL
from core.fsguard import cloud_provider, is_dataless, materialize, not_local_hint
from core.metrics import record_event
from core.sources import cache
from core.sources.freshness import directory_freshness
from core.sources.parsers import (
    LIFT_VERSION,
    STRUCTURAL_KINDS,
    Cell,
    ParsedContent,
    ParsersUnavailable,
    Row,
    Table,
    parse_source,
)

logger = logging.getLogger(__name__)

__all__ = [
    "Budget",
    "SourceRef",
    "LiftResult",
    "SourceUnavailable",
    "SourceNotLocal",
    "NdaRefused",
    "resolve_ref",
    "resolve_source_path",
    "lift",
    "lift_from",
    "slice_result",
]

# Statuses on a LiftResult. ``ok`` — content lifted; ``unavailable`` — could not
# (missing file / field, absent parsers extra, timeout, unsupported type) — a soft
# signal, never an exception across the tool boundary.
STATUS_OK = "ok"
STATUS_UNAVAILABLE = "unavailable"
# SRC-ICLOUD-1: файл есть в каталоге, но его байты в iCloud и не скачались (демон launchd iCloud
# не материализует). Отдельный статус + конверт ``source_not_local`` у всех потребителей подъема.
STATUS_NOT_LOCAL = "not_local"

_MAX_PAGES_DEFAULT = 500

# NDA-1: the refusal reason for an NDA-marked source (no content ever surfaces).
_NDA_REASON = "NDA-исключение (_nda)"


class SourceUnavailable(RuntimeError):
    """A source could not be resolved to a liftable file (carries a reason)."""


class SourceNotLocal(SourceUnavailable):
    """Источник - не скачанная заглушка iCloud (SRC-ICLOUD-1): точечная попытка не помогла.

    Подкласс :class:`SourceUnavailable`: старые ``except SourceUnavailable`` ловят его как
    раньше, а :func:`lift_from` и потребители отличают по типу и отдают ``source_not_local``.
    """

    def __init__(self, path: str):
        where = "OneDrive не скачан" if cloud_provider(path) == "onedrive" else "iCloud не скачан"
        super().__init__(f"источник не локален ({where}): {path}")
        self.path = path
        self.code = CODE_SOURCE_NOT_LOCAL
        self.hint = not_local_hint(path)


class NdaRefused(SourceUnavailable):
    """Resolution refused because the path is NDA-marked (NDA-1).

    A :class:`SourceUnavailable` subclass so existing ``except SourceUnavailable``
    handlers still catch it, while :func:`lift_from` can detect it specifically and
    surface ``nda=True``. Carries the offending path for the (content-free) audit.
    """

    def __init__(self, path: str):
        super().__init__(_NDA_REASON)
        self.path = path


@dataclass
class Budget:
    """Bounds one lift so a big/slow file never wedges the caller (принцип 11).

    ``timeout_s`` caps wall-clock (the parse runs in a worker thread we abandon on
    overrun); ``max_cells`` caps the structural spreadsheet lift; ``max_pages`` is
    reserved for paged formats. True heavy-file handling (checkpoints/progress) is
    JOB-1 — here a timeout + cap is enough.
    """

    timeout_s: float = 20.0
    max_cells: int = field(default_factory=sources_cell_cap)
    max_pages: int = _MAX_PAGES_DEFAULT


@dataclass
class SourceRef:
    """A resolved, existing source file ready to lift.

    ``path`` is absolute and confirmed to exist; ``kind`` the lowercased extension
    (``"xlsx"``/``"pdf"``/…); ``content_hash`` the sha256 of its bytes (the L2
    cache key). ``note_ref`` records the note this was resolved from (for the
    registry), empty for an explicit-path lift.
    """

    path: Path
    kind: str
    content_hash: str
    note_ref: str = ""


@dataclass
class LiftResult:
    """The lifted content of one source (PART-2).

    ``tables`` is the structural layer (cell coordinates preserved); ``text`` the
    reused flat text layer; ``meta`` per-type extras (sheets/pages); ``stale_hint``
    warns that xlsx values came from a formula cache and may be stale;
    ``truncated`` flags a hit cell cap. ``status`` is ``ok``/``unavailable`` and
    ``reason`` explains a non-ok. Locators are back-traceable: ``sheet!ref`` for
    spreadsheet cells.
    """

    path: str
    kind: str
    content_hash: str
    mtime: float
    stale_hint: bool = False
    text: str = ""
    tables: list[Table] = field(default_factory=list)
    meta: dict[str, Any] = field(default_factory=dict)
    truncated: bool = False
    status: str = STATUS_OK
    reason: str = ""
    cache_hit: bool = False
    # NDA-1: True when the lift was refused because the path is NDA-marked (the
    # file was never read, cached, or registered). A soft, honest signal.
    nda: bool = False
    # SRC-FRESH-1: свежесть файла в его каталоге (папка = семейство версий).
    # ``newer_sibling`` — ``{path, mtime, days_newer}`` файла с похожим именем и
    # существенно более новой датой (он же поднимает ``stale_hint``); ``family`` —
    # ``{rank_by_date, of}``. Данные ЖИВЫЕ (зависят от каталога, не от содержимого),
    # поэтому в L2-кеш по content_hash они не попадают — см. :func:`_with_freshness`.
    newer_sibling: dict[str, Any] | None = None
    family: dict[str, int] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """JSON-serializable form for the MCP/CLI boundary (locators expanded)."""
        out: dict[str, Any] = {
            "path": self.path,
            "kind": self.kind,
            "content_hash": self.content_hash,
            "mtime": self.mtime,
            "stale_hint": self.stale_hint,
            "text": self.text,
            "tables": [_table_to_dict(t) for t in self.tables],
            "meta": self.meta,
            "truncated": self.truncated,
            "status": self.status,
            "reason": self.reason,
            "cache_hit": self.cache_hit,
            "nda": self.nda,
            "newer_sibling": self.newer_sibling,
            "family": self.family,
        }
        if self.status == STATUS_NOT_LOCAL:
            # единый конверт: тот же, что у get_facts/OCR/ingest (список ``warning``)
            from core.contract import add_warning

            add_warning(
                out, CODE_SOURCE_NOT_LOCAL, self.reason,
                path=self.path, hint=str(self.meta.get("hint") or not_local_hint(self.path)),
            )
        return out


def _table_to_dict(table: Table) -> dict[str, Any]:
    """Serialize a table, expanding each cell's back-traceable ``sheet!ref``.

    FACT-2: ``merges`` попадает в словарь ТОЛЬКО когда объединения есть - таблица без них
    сериализуется байт в байт как до FACT-2.
    """
    out: dict[str, Any] = {
        "sheet": table.sheet,
        "rows": [
            {
                "r": row.r,
                "cells": [
                    {
                        "col": c.col,
                        "ref": c.ref,
                        "locator": f"{table.sheet}!{c.ref}",
                        "value": c.value,
                        "is_number": c.is_number,
                    }
                    for c in row.cells
                ],
            }
            for row in table.rows
        ],
    }
    if table.merges:
        out["merges"] = [list(m) for m in table.merges]
    return out


# --------------------------------------------------------------------------- #
# Resolution (PART-5)                                                          #
# --------------------------------------------------------------------------- #


def _resolve_path_str(raw: str, vault: Path) -> Path:
    """Absolute path as-is; a relative one is resolved against the vault root."""
    p = Path(raw).expanduser()
    return p if p.is_absolute() else (vault / p)


def _note_source_candidates(note_id: str, vault: Path) -> tuple[str, list[str]]:
    """Note path + ordered source-path candidates from frontmatter (PART-5 step 2).

    Reads ``source_path`` (a string) then ``source_paths`` (a list) — the canonical
    file-source fields. The ``sources`` field (wikilinks to entities, architecture
    §1) is deliberately NOT consulted: it encodes relations, not files. Returns the
    note's own path too so the caller can enforce the NDA barrier on an NDA note
    (``NDA-1``): the note is still *found* and can be refused explicitly
    (``nda=True``), not reported as missing.

    **CONTRACT-1 ФП-1 (Д7).** ``note_id`` — ссылка ЛЮБОЙ формы: единая точка
    :func:`core.vault.resolve_note_path` даёт заметку по id, пути (vault-относительному
    или абсолютному), имени файла и ``source_path``. Обход vault со сверкой ``id``
    остаётся вторым шагом — он находит заметку, которой нет в манифестах, и он же
    единственный, кто ходит с ``apply_nda=False`` (NDA-заметка обязана быть НАЙДЕНА,
    чтобы получить явный отказ, а не «не существует»).
    """
    from core.vault import iter_vault, read_note, resolve_note_path

    def _candidates(note: Any) -> tuple[str, list[str]]:
        fm = note.frontmatter
        out: list[str] = []
        sp = fm.get("source_path")
        if isinstance(sp, str) and sp.strip():
            out.append(sp.strip())
        raw_list = fm.get("source_paths")
        if isinstance(raw_list, list):
            for item in raw_list:
                if isinstance(item, str) and item.strip():
                    out.append(item.strip())
        return str(note.path), out

    resolved = resolve_note_path(note_id, vault_path=vault)
    if resolved is not None:
        return _candidates(read_note(resolved))
    for note in iter_vault(vault, apply_nda=False):
        if note.id != note_id:
            continue
        return _candidates(note)
    raise SourceUnavailable(f"note not found: {note_id}")


def _icloud_applicable() -> bool:
    """iCloud-признак осмыслен только на macOS; Linux/без iCloud - файл всегда локален."""
    return sys.platform == "darwin"


def _build_ref(path: Path, *, note_ref: str) -> SourceRef:
    """Content-hash an existing file into a :class:`SourceRef`.

    SRC-ICLOUD-1: ДО чтения (хэш - уже чтение) проверяем dataless; при заглушке - одна точечная
    попытка ``brctl download`` (``DT_ICLOUD_DOWNLOAD_S``), не скачалось - :class:`SourceNotLocal`.
    ``EDEADLK`` на самом чтении (демон launchd, флаг не успел показать) - тот же отказ.
    """
    kind = path.suffix.lower().lstrip(".") or "unknown"
    if _icloud_applicable() and is_dataless(path) and not materialize(
        path, timeout_s=icloud_download_s()
    ):
        raise SourceNotLocal(str(path))
    try:
        digest = cache.file_content_hash(path)
    except OSError as exc:
        if _icloud_applicable() and exc.errno in (errno.EDEADLK, errno.ETIMEDOUT):
            raise SourceNotLocal(str(path)) from exc
        raise
    return SourceRef(path=path, kind=kind, content_hash=digest, note_ref=note_ref)


def _resolve_under_legacy_roots(raw: str) -> Path | None:
    """A legacy note's ``source_path`` resolved against ``DT_LEGACY_ROOTS`` (PART-1).

    A legacy card stores ``source_path`` **relative to the legacy-corpus base**, not
    absolute or vault-relative — e.g. ``2023-2026/Kazakhstan/Acme/Acme_расчёты.xlsx``
    (see ``core.legacy.discover.file_metadata``: the path is taken ``relative_to`` the
    root, or the root's parent when the root name is an era like ``2023-2026``). So a
    relative raw path is probed under each configured legacy root **and its parent**
    (the era prefix lives in ``source_path``, so the parent is the right base when the
    root itself is the era dir); the first existing file wins. An absolute raw path is
    never joined onto a root — it is handled by the caller's earlier absolute step.
    """
    rel = Path(raw)
    if rel.is_absolute():
        return None
    for root in legacy_roots():
        for base in (root, root.parent):
            candidate = base / rel
            if candidate.is_file():
                return candidate.resolve()
    return None


# SRC-PATH-1: пакетный резолв (доктор, бэкфилл: ~10 тыс. путей подряд) не должен на каждый путь
# заново разбирать ``ingest-roots.yaml`` (1 мс × 10 тыс. = полбюджета чека). Вызывающий закрепляет
# список корней на время пакета; вне пакета поведение прежнее (чтение на каждый вызов).
_PINNED_ROOTS: ContextVar[list[Any] | None] = ContextVar("src_pinned_roots", default=None)


@contextmanager
def pinned_ingest_roots(vault: Path) -> Iterator[None]:
    """Закрепить список ingest-корней на время пакета резолвов (контекстно-локально)."""
    from core.file_ingest.config import load_ingest_roots

    try:
        roots = list(load_ingest_roots(vault))
    except Exception:  # noqa: BLE001 — сломанный конфиг: не закрепляем, резолв идет как раньше
        yield
        return
    token = _PINNED_ROOTS.set(roots)
    try:
        yield
    finally:
        _PINNED_ROOTS.reset(token)


def _resolve_under_ingest_roots(raw: str, vault: Path) -> Path | None:
    """A relative ``source_path`` resolved against **every** ingest root (PART-3в).

    Two-archive transition (INGEST-SCHEDULE): ~8k notes carry a Bitrix-relative
    ``source_path`` (e.g. ``2023-2026/Kazakhstan/Acme/x.xlsx``) whose content is now
    live under an ingest root (e.g. ``<CDT_Internal>/Kazakhstan/Acme/x.xlsx``) — not
    under ``DT_LEGACY_ROOTS``. So a relative path is probed under each configured root
    by a **full join first, then a progressive tail match** on the shared substructure
    (``Kazakhstan/Acme/…``): the first existing file wins. A tail match requires **≥2
    segments** so a bare filename never false-matches (that is what relocation-by-hash
    is for). Read-only, last-resort (after legacy join, before relocation); an absolute
    path is never joined. No roots → no-op.

    **RESOLVE-KNOWLEDGE-1 (регрессия переключения 15.07).** Раньше шаг фильтровал
    ``route == operational``, а с 2026-07-15 ЕДИНСТВЕННЫЙ корень — ``knowledge``: подъём
    не мог достать НИ ОДИН файл хранилища через заметку (``unavailable: none of the
    note's source paths exist`` при живом файле). Регрессия была скрытой — retrieve и
    L2-кеш работали, падал только подъём live-байтов. Решение постановщика: **чтение
    файла-источника по требованию законно и для knowledge-корней** (канон §10a
    «markdown primary» — про источник истины, а не про запрет читать файлы; NDA-гард
    стоит на пути в любом случае). Операционные корни идут ПЕРВЫМИ: там, где настроены
    оба вида, порядок сохраняет прежнюю семантику выбора файла.
    """
    rel = Path(raw)
    if rel.is_absolute():
        return None
    try:
        from core.file_ingest.config import ROUTE_OPERATIONAL, load_ingest_roots

        # operational первыми, внутри группы — порядок конфига (сортировка стабильна)
        pinned = _PINNED_ROOTS.get()
        roots = [
            r.path for r in sorted(
                pinned if pinned is not None else load_ingest_roots(vault),
                key=lambda r: 0 if r.route == ROUTE_OPERATIONAL else 1,
            )
        ]
    except Exception:  # noqa: BLE001 — missing/broken ingest config never breaks resolve
        return None
    parts = rel.parts
    for root in roots:
        for start in range(len(parts)):
            sub = parts[start:]
            if start > 0 and len(sub) < 2:
                break  # never match on a bare filename (avoid a false hit)
            candidate = root.joinpath(*sub)
            if candidate.is_file():
                return candidate.resolve()
    return None


def resolve_source_path(
    raw: str, *, vault_path: Path | None = None, note_path: str | Path | None = None
) -> Path | None:
    """Строка ``source_path`` → существующий файл, **без чтения и хеширования**.

    Порядок разрешения (PART-5, PART-1) — один на весь движок: (1) абсолютный /
    vault-относительный путь как есть; (2) относительно legacy-корней
    (``DT_LEGACY_ROOTS``) — у legacy-карточек ``source_path`` хранится относительно
    Bitrix-базы; (3) относительно **операционных** ingest-корней по подструктуре
    (INGEST-SCHEDULE PART-3в — контент переехал в живой корень); (4) релокация по
    реестру content-hash (файл переместили после инжеста). ``None``, если ни один шаг
    не нашёл файла.

    Отделено от :func:`_resolve_candidate` для потребителей, которым нужен ПУТЬ, а не
    содержимое (SRC-FRESH-1 ``find_latest``: каталог-семейство): sha256 файла ради
    имени каталога — цена ни за что. Порядок при этом остаётся ровно один — и он же
    единственный: флага ``any_route`` больше нет (RESOLVE-KNOWLEDGE-1 сделал охват
    всех ingest-корней дефолтом, и «путь для каталога» перестал отличаться от «путь
    для чтения»).

    **SRC-PATH-1 (защита в глубину).** ``note_path`` (путь заметки: vault-относительный или
    абсолютный) включает ПОСЛЕДНИЙ рубеж, и только когда все четыре шага выше вернули ``None``:
    ключ манифеста инжеста по ``note_path`` (``source_path`` заметки мог отстать после переезда
    папки) прогоняется той же цепочкой. Порядок прежних шагов не меняется.
    """
    vault = Path(vault_path) if vault_path is not None else default_vault_path()
    found = _resolve_chain(raw, vault)
    if found is None and note_path:
        from core.legacy.repoint import resolve_via_manifest

        return resolve_via_manifest(note_path, vault, lambda key: _resolve_chain(key, vault))
    return found


def _resolve_chain(raw: str, vault: Path) -> Path | None:
    """Четыре прежних шага резолва (абсолютный → легаси-корни → ingest-корни → реестр SRC-1)."""
    path = _resolve_path_str(raw, vault)
    if path.is_file():
        return path.resolve()
    legacy = _resolve_under_legacy_roots(raw)
    if legacy is not None:
        return legacy
    under_root = _resolve_under_ingest_roots(raw, vault)
    if under_root is not None:
        return under_root
    relocated = cache.find_relocated_path(str(path))
    if relocated is not None:
        new_path, _hash = relocated
        return Path(new_path).resolve()
    return None


def _resolve_candidate(
    raw: str, vault: Path, *, note_ref: str, note_path: str | None = None
) -> SourceRef | None:
    """Resolve one raw path string to a :class:`SourceRef`, or ``None`` (PART-5, PART-1).

    The resolution order lives in :func:`resolve_source_path`; this adds the content
    hash (the L2 cache key) that a lift needs.
    """
    path = resolve_source_path(raw, vault_path=vault, note_path=note_path)
    return _build_ref(path, note_ref=note_ref) if path is not None else None


def resolve_ref(
    *,
    note_id: str | None = None,
    path: str | None = None,
    vault_path: Path | None = None,
) -> SourceRef:
    """Resolve a ``note_id`` or explicit ``path`` to a :class:`SourceRef` (PART-5).

    Order (deterministic, inspectable):

    1. Explicit ``path`` (absolute, or vault-relative) — highest priority.
    2. From the note's frontmatter ``source_path`` / ``source_paths``.

    Each candidate path is resolved (:func:`_resolve_candidate`) absolute/vault-first,
    then against the legacy-corpus roots (``DT_LEGACY_ROOTS``, PART-1), then via the
    content-hash registry (relocation). Raises :class:`SourceUnavailable` when nothing
    resolves — callers that want a soft result use :func:`lift_from`.
    """
    if not note_id and not path:
        raise SourceUnavailable("neither note_id nor path was given")

    # NDA-1: refuse an NDA-marked path BEFORE any resolution — a SourceRef is built
    # by content-hashing the file, which reads it. The check is pure path-string
    # logic, so nothing is read/cached/registered for an NDA source.
    from core.privacy import is_nda

    vault = (Path(vault_path) if vault_path is not None else default_vault_path()).resolve()

    if path:
        if is_nda(path):
            raise NdaRefused(path)
        ref = _resolve_candidate(path, vault, note_ref="")
        if ref is not None:
            if is_nda(str(ref.path)):  # relocated to an NDA path
                raise NdaRefused(str(ref.path))
            return ref
        raise SourceUnavailable(f"file not found: {path}")

    assert note_id is not None  # noqa: S101 — type-narrowing assert; non-None guaranteed above
    note_path, candidates = _note_source_candidates(note_id, vault)
    if is_nda(note_path):  # the note itself is NDA → refuse its lift
        raise NdaRefused(note_path)
    if not candidates:
        raise SourceUnavailable(
            f"note {note_id!r} has no source_path/source_paths in frontmatter"
        )
    not_local: SourceNotLocal | None = None
    for raw in candidates:
        if is_nda(raw):  # a card pointing at an NDA source
            raise NdaRefused(raw)
        try:
            ref = _resolve_candidate(raw, vault, note_ref=note_id, note_path=note_path)
        except SourceNotLocal as exc:  # следующий кандидат может оказаться локальным
            not_local = not_local or exc
            continue
        if ref is not None:
            if is_nda(str(ref.path)):
                raise NdaRefused(str(ref.path))
            return ref
    if not_local is not None:
        raise not_local
    raise SourceUnavailable(
        f"none of the note's source paths exist: {candidates}"
    )


# --------------------------------------------------------------------------- #
# Lift (PART-2)                                                                #
# --------------------------------------------------------------------------- #


def _parsed_to_result(ref: SourceRef, parsed: ParsedContent, mtime: float) -> LiftResult:
    """Assemble a :class:`LiftResult` from a fresh parse."""
    status = STATUS_OK
    reason = ""
    if parsed.text_status == "skipped" and not parsed.tables:
        status = STATUS_UNAVAILABLE
        reason = parsed.reason or f"unsupported source type: {ref.kind}"
    meta = dict(parsed.meta)
    if parsed.warnings:
        meta["warnings"] = list(parsed.warnings)  # переживает L2-кеш (FACT-2: merges_skipped)
    return LiftResult(
        path=str(ref.path),
        kind=ref.kind,
        content_hash=ref.content_hash,
        mtime=mtime,
        stale_hint=parsed.has_formulas,
        text=parsed.text,
        tables=parsed.tables,
        meta=meta,
        truncated=parsed.truncated,
        status=status,
        reason=reason,
    )


def _merge_tuple(raw: Any) -> tuple[int, int, int, int] | None:
    """Объединенный диапазон из записи кеша → ``(min_row, min_col, max_row, max_col)``.

    Приемка FACT-2 29.10: промежуточная сборка писала диапазоны строками (``"O2:O3"``) под той же
    ``lift_version`` - кеш не инвалидировался, а ``int("O")`` ронял подъем целиком. Принимаем и
    4 числа, и строку-диапазон; иное - пропускаем (``None``), не исключение: кеш - подсказка.
    """
    if isinstance(raw, str):
        try:
            from openpyxl.utils import range_boundaries  # type: ignore[import-untyped]

            min_col, min_row, max_col, max_row = range_boundaries(raw.strip())
        except Exception:  # noqa: BLE001 - кривая строка диапазона
            return None
        if None in (min_col, min_row, max_col, max_row):
            return None
        return (int(min_row), int(min_col), int(max_row), int(max_col))
    try:
        a, b, c, d = (int(x) for x in raw)
    except (TypeError, ValueError):
        return None
    return (a, b, c, d)


def _record_to_result(record: dict[str, Any]) -> LiftResult:
    """Rehydrate a cached JSON record into a :class:`LiftResult` (tables as objects)."""
    tables: list[Table] = []
    for t in record.get("tables", []):
        rows: list[Row] = []
        for r in t.get("rows", []):
            cells = [
                Cell(
                    col=c["col"],
                    ref=c["ref"],
                    value=c["value"],
                    is_number=bool(c["is_number"]),
                )
                for c in r.get("cells", [])
            ]
            rows.append(Row(r=r["r"], cells=cells))
        merges = [mt for m in (t.get("merges") or []) if (mt := _merge_tuple(m)) is not None]
        tables.append(Table(sheet=t["sheet"], rows=rows, merges=merges))
    return LiftResult(
        path=record["path"],
        kind=record["kind"],
        content_hash=record["content_hash"],
        mtime=record.get("mtime", 0.0),
        stale_hint=bool(record.get("stale_hint", False)),
        text=record.get("text", ""),
        tables=tables,
        meta=record.get("meta", {}),
        truncated=bool(record.get("truncated", False)),
        status=record.get("status", STATUS_OK),
        reason=record.get("reason", ""),
    )


def _audit_nda(path_str: str) -> None:
    """Audit an NDA refusal (SEC-6): path-hash + ``nda_refused``, never content.

    Best-effort and lazy-imported so the resolver keeps no module-level dependency
    on the operational stack; a failure to audit never blocks the refusal.
    """
    try:
        import hashlib

        from core.operational.pult import record_action

        digest = hashlib.sha256(path_str.encode("utf-8")).hexdigest()[:12]
        record_action(
            "lift_source", {"path_hash": digest, "nda": True}, outcome="nda_refused"
        )
    except Exception:  # noqa: BLE001, S110 — audit must never break the barrier
        pass


def _nda_refusal(path_str: str) -> LiftResult:
    """Build the NDA refusal result (nothing read/cached/registered) + audit it."""
    _audit_nda(path_str)
    return LiftResult(
        path=path_str,
        kind="unknown",
        content_hash="",
        mtime=0.0,
        status=STATUS_UNAVAILABLE,
        reason=_NDA_REASON,
        nda=True,
    )


def _with_freshness(result: LiftResult) -> LiftResult:
    """SRC-FRESH-1: досыпать ``newer_sibling``/``family`` и поднять ``stale_hint``.

    Вызывается на КАЖДОМ возврате поднятого файла — и после парса, и после
    cache-hit — но **после** записи в L2-кеш: кеш адресуется content_hash'ем, а
    свежесть зависит от каталога (те же байты в другой папке имеют других соседей).
    Закешированный ``newer_sibling`` был бы просто неверным.

    ``stale_hint`` расширяется по смыслу: раньше «значения из кэша формул», теперь
    ещё и «рядом лежит существенно более новая версия» — оба про «не доверяй этому
    числу как последнему» (фейлкейс 2026-08-11). Никогда не роняет подъём.
    """
    try:
        fresh = directory_freshness(result.path, mtime=result.mtime)
    except Exception as exc:  # noqa: BLE001 — подсказка не имеет права ломать подъём
        logger.debug("[lift] freshness skipped for %s: %s", result.path, exc)
        return result
    result.family = fresh.family
    if fresh.newer_sibling is not None:
        result.newer_sibling = fresh.newer_sibling.to_dict()
        result.stale_hint = True
    return result


def _emit_lift(kind: str, status: str, *, cache_hit: bool) -> None:
    """CODE-5-1 наблюдаемость: один структурный факт lift — вид/статус/попал ли в
    L2-кеш. Privacy: без пути/контента/хеша. ``corr_id`` досыпается в record_event
    (сшивка с логом). ``cache_hit=True`` = L2 cache-hit (закрывает и метрику кеша).
    Поле называется ``source_kind`` (не ``kind``: первый арг record_event — это
    kind самого события, ``"lift"``)."""
    record_event("lift", source_kind=kind or "", status=status, cache_hit=cache_hit)


def _cache_is_current(record: dict[str, Any]) -> bool:
    """FACT-2: запись L2-кеша годна, если структура подъема не старше :data:`LIFT_VERSION`.

    Для видов с табличным подъемом (xlsx/xls/csv) запись без ``meta.lift_version`` (до FACT-2:
    нет объединенных диапазонов, у xls/csv нет таблиц вовсе) перечитывается; остальные виды
    (docx/pdf/…) версию не несут и годны всегда.
    """
    if str(record.get("kind") or "") not in STRUCTURAL_KINDS:
        return True
    meta = record.get("meta")
    version = meta.get("lift_version") if isinstance(meta, dict) else None
    return isinstance(version, int) and version >= LIFT_VERSION


def lift(
    ref: SourceRef, *, budget: Budget | None = None, persist: bool = True
) -> LiftResult:
    """Lift ``ref``'s content into a :class:`LiftResult`, using the L2 cache.

    Cache hit (a record already exists for this content hash) → returned without
    re-parsing. Miss → the file is parsed read-only within ``budget`` (timeout +
    cell cap), the record cached under its content hash, and the registry updated.
    A missing parsers extra or a timeout yields ``status="unavailable"`` (never an
    exception).

    NDA-1 defense-in-depth: a hand-built ``ref`` whose path is NDA-marked is refused
    here too — no parse, no cache write, no registry entry — even though
    :func:`resolve_ref` already refuses before a ref is built.
    """
    from core.privacy import is_nda

    if is_nda(str(ref.path)):
        return _nda_refusal(str(ref.path))

    budget = budget or Budget()
    stat = ref.path.stat()

    cached = cache.load_cached(ref.content_hash) if persist else None
    if cached is not None and not _cache_is_current(cached):
        cached = None  # устаревшая структура подъема - перечитать и перезаписать
    if cached is not None:
        result = _record_to_result(cached)
        result.cache_hit = True
        # SRC-CACHE-PATH: content is addressed by hash (correct as-is), but the
        # cached record's ``path`` is where the bytes were *first* seen — possibly a
        # now-dead location (e.g. a deleted Bitrix export). Report the freshly
        # resolved live path (the one we just stat'd) so provenance
        # (get_facts/resolve ``source_path``) cites a real file, and register it so
        # the registry knows the current location. Idempotent (register_source
        # dedups paths); best-effort.
        result.path = str(ref.path)
        result.mtime = stat.st_mtime
        cache.register_source(
            ref.content_hash,
            path=str(ref.path),
            mtime=stat.st_mtime,
            size=stat.st_size,
            kind=result.kind,
            status=result.status,
            note_ref=ref.note_ref or None,
        )
        # Keep the registry path-current: drop this live path from any stale-hash
        # rows (a prior, different version once seen here). Idempotent, best-effort.
        cache.forget_path_versions(str(ref.path), keep_hash=ref.content_hash)
        _emit_lift(result.kind, result.status, cache_hit=True)
        return _with_freshness(result)  # SRC-FRESH-1: живые соседи, не из кеша

    try:
        parsed = _parse_with_timeout(ref, budget)
    except ParsersUnavailable as exc:
        _emit_lift(ref.kind, STATUS_UNAVAILABLE, cache_hit=False)
        return LiftResult(
            path=str(ref.path),
            kind=ref.kind,
            content_hash=ref.content_hash,
            mtime=stat.st_mtime,
            status=STATUS_UNAVAILABLE,
            reason=str(exc),
        )
    except FutureTimeout:
        _emit_lift(ref.kind, STATUS_UNAVAILABLE, cache_hit=False)
        return LiftResult(
            path=str(ref.path),
            kind=ref.kind,
            content_hash=ref.content_hash,
            mtime=stat.st_mtime,
            status=STATUS_UNAVAILABLE,
            reason=f"lift exceeded budget timeout ({budget.timeout_s}s)",
        )
    except Exception as exc:  # noqa: BLE001 — битый файл - мягкий отказ с кодом, не исключение
        # FACT-2: повреждённый xls/xlsx/csv (BadZipFile, XLRDError, …) роняло подъем
        # исключением через границу инструмента; теперь - ``unavailable`` с причиной.
        logger.warning("[lift] %s не разобран: %s", ref.kind, exc)
        _emit_lift(ref.kind, STATUS_UNAVAILABLE, cache_hit=False)
        return LiftResult(
            path=str(ref.path),
            kind=ref.kind,
            content_hash=ref.content_hash,
            mtime=stat.st_mtime,
            status=STATUS_UNAVAILABLE,
            reason=f"parse_error: {type(exc).__name__}: {str(exc)[:160]}",
        )

    result = _parsed_to_result(ref, parsed, stat.st_mtime)
    if not persist:
        # FACT-2: сухой подъем (``dt_facts --reextract`` без --apply) - ни кеша, ни реестра.
        _emit_lift(result.kind, result.status, cache_hit=False)
        return _with_freshness(result)
    # Кеш пишем ДО досыпки свежести: в записи по content_hash соседям каталога места нет.
    cache.save_cached(ref.content_hash, result.to_dict())
    cache.register_source(
        ref.content_hash,
        path=str(ref.path),
        mtime=stat.st_mtime,
        size=stat.st_size,
        kind=ref.kind,
        status=result.status,
        note_ref=ref.note_ref or None,
    )
    _emit_lift(result.kind, result.status, cache_hit=False)
    return _with_freshness(result)


def _parse_with_timeout(ref: SourceRef, budget: Budget) -> ParsedContent:
    """Run the parse in a worker thread, abandoning it if it overruns the budget.

    A read-only parse that overruns is abandoned (the thread finishes in the
    background harmlessly) rather than killed — enough for SRC-1; true cancellation
    is JOB-1. Raises :class:`concurrent.futures.TimeoutError` on overrun.

    Note: the executor is shut down with ``wait=False`` on timeout — a ``with``
    block would ``shutdown(wait=True)`` on exit and re-block for the whole parse,
    defeating the budget.
    """
    pool = ThreadPoolExecutor(max_workers=1)
    future = pool.submit(
        parse_source,
        ref.path,
        ref.kind,
        max_cells=budget.max_cells,
        max_pages=budget.max_pages,
    )
    try:
        parsed = future.result(timeout=budget.timeout_s)
    except FutureTimeout:
        pool.shutdown(wait=False, cancel_futures=True)
        raise
    pool.shutdown(wait=False)
    return parsed


def lift_from(
    *,
    note_id: str | None = None,
    path: str | None = None,
    vault_path: Path | None = None,
    budget: Budget | None = None,
    persist: bool = True,
) -> LiftResult:
    """Resolve then lift, softening resolution failures into ``unavailable``.

    The convenience the MCP/CLI wrappers call: an unresolvable note/path never
    raises across the boundary — it comes back as ``status="unavailable"`` with a
    reason (production audit: a dead card link must be a clear signal, not a crash).
    """
    try:
        ref = resolve_ref(note_id=note_id, path=path, vault_path=vault_path)
    except NdaRefused as exc:
        # NDA-1: a hard refusal — surface nda=True and audit; nothing was read.
        return _nda_refusal(exc.path)
    except SourceNotLocal as exc:
        # SRC-ICLOUD-1: файл есть, но не скачан из iCloud - не «нет файла», а свой статус и конверт.
        return LiftResult(
            path=exc.path,
            kind=Path(exc.path).suffix.lower().lstrip(".") or "unknown",
            content_hash="",
            mtime=0.0,
            status=STATUS_NOT_LOCAL,
            reason=str(exc),
            meta={"code": exc.code, "hint": exc.hint},
        )
    except SourceUnavailable as exc:
        return LiftResult(
            path=path or (note_id or ""),
            kind="unknown",
            content_hash="",
            mtime=0.0,
            status=STATUS_UNAVAILABLE,
            reason=str(exc),
        )
    return lift(ref, budget=budget, persist=persist)


def slice_result(
    result: LiftResult, *, sheet: str | None = None, cell_range: str | None = None
) -> LiftResult:
    """Return a view of ``result`` narrowed to a ``sheet`` and/or ``cell_range``.

    ``sheet`` keeps only the matching worksheet (case-insensitive); ``cell_range``
    (A1 form, e.g. ``"B7:B9"``) keeps only cells inside the box. A no-op when both
    are ``None``. Non-structural results (no tables) are returned unchanged. The
    text layer is left intact — slicing narrows the structural view only.
    """
    if sheet is None and cell_range is None:
        return result
    bounds = _range_bounds(cell_range) if cell_range else None
    needle = sheet.strip().lower() if sheet else None

    sliced: list[Table] = []
    for table in result.tables:
        if needle is not None and table.sheet.strip().lower() != needle:
            continue
        if bounds is None:
            sliced.append(table)
            continue
        min_col, min_row, max_col, max_row = bounds
        rows = []
        for row in table.rows:
            if not (min_row <= row.r <= max_row):
                continue
            kept = [c for c in row.cells if min_col <= _col_index(c.col) <= max_col]
            if kept:
                rows.append(Row(r=row.r, cells=kept))
        if rows:
            sliced.append(Table(sheet=table.sheet, rows=rows, merges=list(table.merges)))

    meta = dict(result.meta)
    meta["sliced"] = {"sheet": sheet, "cell_range": cell_range}
    return LiftResult(
        path=result.path,
        kind=result.kind,
        content_hash=result.content_hash,
        mtime=result.mtime,
        stale_hint=result.stale_hint,
        text=result.text,
        tables=sliced,
        meta=meta,
        truncated=result.truncated,
        status=result.status,
        reason=result.reason,
        cache_hit=result.cache_hit,
        # срез — это вид того же файла: свежесть каталога переносится как есть
        newer_sibling=result.newer_sibling,
        family=dict(result.family),
    )


def _col_index(col: str) -> int:
    """Column letters → 1-based index (``"A"``→1, ``"B"``→2, ``"AA"``→27)."""
    idx = 0
    for ch in col.upper():
        idx = idx * 26 + (ord(ch) - ord("A") + 1)
    return idx


def _range_bounds(cell_range: str) -> tuple[int, int, int, int]:
    """Parse ``"B7:B9"`` → ``(min_col, min_row, max_col, max_row)`` (1-based).

    A single cell (``"B7"``) collapses to a 1×1 box. Deterministic, no openpyxl.
    """
    import re

    parts = cell_range.replace(" ", "").split(":")
    coords = []
    for part in parts:
        m = re.fullmatch(r"([A-Za-z]+)(\d+)", part)
        if not m:
            raise SourceUnavailable(f"bad cell_range: {cell_range!r}")
        coords.append((_col_index(m.group(1)), int(m.group(2))))
    (c0, r0) = coords[0]
    (c1, r1) = coords[-1]
    return (min(c0, c1), min(r0, r1), max(c0, c1), max(r0, r1))
