"""Style injection — exemplar selection (architecture §5, ТЗ D5 / ex-D4).

Style injection puts two things in front of the retrieved context: (1) the
genre style guide (a static document, read by ``core.generation``) and (2) a
handful of *exemplars* — the task-closest real samples from the corpus, picked
here.

Path B (decision 2026-06-17): no networked LLM calls live in ``core/``. Style
guides are authored in Cowork; this module only *selects* samples via the
existing hybrid ``search``. ``generate_style_guide`` (the LLM synthesis from the
superseded D4) is intentionally absent.

Invariant: ``core/`` depends on neither MCP nor CLI.
"""

from __future__ import annotations

from core.retrieval.search import SearchResult, search

__all__ = ["select_exemplars"]


def select_exemplars(
    query: str,
    genre: str,
    *,
    k: int = 3,
    audience: str | None = None,
) -> list[SearchResult]:
    """Pick the ``k`` task-closest style-samples of ``genre`` for prompt injection.

    Runs the hybrid retriever filtered to ``type=style-sample`` and the given
    ``genre`` (and ``audience`` when provided), so the exemplars are both
    on-genre and relevant to *this* task rather than a fixed set. Returns the
    raw :class:`SearchResult` objects (text + id + metadata) for the caller to
    render and to record in provenance.

    No LLM is involved — selection is pure retrieval (Path B).
    """
    filters: dict[str, str] = {"type": "style-sample", "genre": genre}
    if audience:
        filters["audience"] = audience
    return search(query, filters=filters, k=k)
