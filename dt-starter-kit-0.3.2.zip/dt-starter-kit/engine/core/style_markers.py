"""STYLE-GUARD-1 — механическая проверка ИИ-маркеров в тексте выхода (канон §9 п.19).

Основание: решение К. 2026-09-09 — «дженерик-стиль очень ИИшный, полечить раз и
навсегда». Ключевое слово — **раз и навсегда**: правило в ПАМЯТИ LLM живёт до
следующего сеанса, правило в СИСТЕМЕ переживает и сеанс, и модель. Отсюда чекер в
ядре, а не инструкция в скилле.

Канон — ОДИН файл: ``vault/_system/style-guides/ai-markers.yaml`` (пополняет К. как
заметку: увидел новый маркер — добавил строку). Пороги, списки фраз и включённость
паттернов берутся ОТТУДА, здесь их нет — иначе «пополнить канон» превратилось бы в
правку кода, и файл стал бы декорацией. Три уровня жёсткости:

* **ban** (уровень 1) — в текстах К. не встречается никогда: длинное тире, ``ё``,
  дежурные фразы-затычки, эмодзи в деловом тексте. Найдено → warning всегда.
* **density** (уровень 2) — живая речь в малых дозах, ИИ — частота. Считаем
  СУММАРНУЮ плотность связок на 1000 слов против порога из файла: «кроме того»
  один раз — норма, пять на страницу — маркер. Ниже порога → тишина.
* **calques** (уровень 3) — кальки с английского: нашли левое → подсказали правое.

Плюс два паттерн-детектора (не словарных): заголовок-вопрос («Почему это важно»
вместо русской нормы «Значимость») и ритмичные тройки («быстро, качественно и
надёжно»).

**Границы намеренно узкие** (не изобретаем НЛП):

* цитаты пропускаются ТОЛЬКО по явным backtick-блокам и inline-`````-спанам —
  чужое написание в цитате не должно фонить, а разбирать «кавычки это цитата или
  выделение» без морфологии всё равно нельзя (в текстах К. «…» чаще выделение);
* тройки ловятся по совпадению окончаний трёх однородных слов — покрыты очевидные
  случаи, и это осознанно: детектор уровня 2 имеет право пропустить, но не имеет
  права фонить на эталоне;
* автоправки нет вовсе. Чекер ПОКАЗЫВАЕТ, решение за человеком (ТЗ: «НЕ блок»).

Файл канона отсутствует или бит → :class:`StyleReport` с ``unavailable`` и конверт
``store_unavailable`` (п.22), НЕ падение и НЕ тихое «маркеров нет»: «проверка не
состоялась» обязано отличаться от «текст чист».

Слой: ``core`` ⊥ MCP/CLI; ни сети, ни LLM.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]  # стаб-гэп PyYAML — как в file_ingest/aliases.py

from core.config import ai_markers_path
from core.contract import CODE_STORE_UNAVAILABLE, CODE_STYLE_MARKERS, add_warning

__all__ = [
    "STYLE_MARKERS_KEY",
    "MarkerCanon",
    "StyleReport",
    "load_canon",
    "check_text",
    "attach_style_markers",
]

# Ключ ответа инструмента. Держим константой: по нему читают и скиллы, и тесты
# байт-идентичности happy-path (0 находок → ключа НЕТ вовсе).
STYLE_MARKERS_KEY = "style_markers"

# Сколько номеров строк показывать на одну находку. Больше не нужно: задача —
# привести человека к месту, а не пересказать текст в ответе инструмента.
_MAX_LINES = 3

# Слово — последовательность букв (без цифр и подчёркиваний): «на 1000 слов»
# считается по словам, а не по токенам, иначе таблица с числами задерёт делитель
# и любая плотность окажется «в норме».
_WORD_RE = re.compile(r"[^\W\d_]+", re.UNICODE)

# Цитаты, которые пропускаем ДЁШЕВО: fenced-блоки и inline-спаны в backticks.
# Заменяем пробелами той же длины (переводы строк сохраняем) — так номера строк и
# смещения остаются настоящими, и находка указывает на реальную строку файла.
_FENCE_RE = re.compile(r"(?:```|~~~).*?(?:```|~~~)", re.DOTALL)
_INLINE_CODE_RE = re.compile(r"`[^`\n]*`")

# Заголовок: markdown-решётки, либо строка капсом (канон К.: «разделы капсом или
# нумерацией»), возможно с номером. Нумерованный пункт обычного текста заголовком
# НЕ считаем — иначе любой перечень с вопросом станет находкой.
_MD_HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+(?P<text>.+?)\s*$")
_NUM_PREFIX_RE = re.compile(r"^\s*(?:\d+[.)]\s*)+")
# Вопросительные слова заголовка-калькИ (ТЗ: Почему/Как/Что/Зачем).
_QUESTION_WORDS = ("почему", "как", "что", "зачем")

# Тройка: три слова через «, … и …». Морфологии нет — однородность приближаем
# совпадением окончания (см. ``_TRIAD_SUFFIXES``).
_TRIAD_RE = re.compile(
    r"\b([^\W\d_]{5,}),\s+([^\W\d_]{5,})\s+и\s+([^\W\d_]{5,})\b",
    re.UNICODE,
)
# Окончания прилагательных и наречий, по которым узнаём однородный ряд. Наречия
# берём только на «-о» после согласной (качественно, надёжно, быстро) — этого
# хватает для очевидных случаев и не тащит существительные вроде «время».
_TRIAD_SUFFIXES: tuple[str, ...] = (
    "ого", "его", "ому", "ему", "ыми", "ими", "ных", "них",
    "ый", "ий", "ой", "ая", "яя", "ое", "ее", "ые", "ие", "ых", "их", "ым", "им",
    "но", "во", "ко", "ро", "мо", "ло", "то", "зо", "го", "до", "со", "по",
)

# Эмодзи — по блокам Unicode, а не по «непонятным символам»: стрелка «→», знак «№»
# и типографские кавычки в деловом тексте К. живут законно, и ловить их нельзя.
_EMOJI_RANGES: tuple[tuple[int, int], ...] = (
    (0x1F000, 0x1FAFF),  # emoticons, pictographs, transport, supplemental, flags
    (0x2600, 0x27BF),    # misc symbols + dingbats (☀ ✅ ✈ ✔ ❌)
    (0x2B00, 0x2BFF),    # geometric/arrow emoji (⬛ ⭐)
    (0xFE0F, 0xFE0F),    # variation selector-16 (эмодзи-представление)
    (0x1F1E6, 0x1F1FF),  # regional indicators (флаги)
)


# --------------------------------------------------------------------------- #
# Канон                                                                       #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class MarkerCanon:
    """Канон проверки, прочитанный из ``ai-markers.yaml``.

    Пороги и списки — только отсюда. Пустой список какого-то уровня — законная
    конфигурация («этот уровень пока не заполнен»), а не повод считать файл битым.
    """

    ban_typography: tuple[str, ...] = ()
    ban_phrases: tuple[str, ...] = ()
    ban_emoji: bool = False
    density_threshold: float = 0.0
    density_phrases: tuple[str, ...] = ()
    calques: tuple[tuple[str, str], ...] = ()
    question_headings: bool = False
    triads: bool = False
    path: str = ""


class CanonUnavailable(RuntimeError):
    """Канон не прочитался (нет файла / битый YAML / не та структура)."""


def _flag(value: Any) -> bool:
    """Включённость детектора в каноне: ``true`` / ``warn`` — да, остальное — нет.

    В файле у ``triads`` стоит ``warn`` (уровень сигнала, а не булево) — читаем и
    его: канон писал человек, и он вправе назвать уровень словом.
    """
    if isinstance(value, bool):
        return value
    return str(value or "").strip().casefold() in {"warn", "yes", "on", "true"}


def _strings(value: Any) -> tuple[str, ...]:
    """Список маркеров из канона: непустые строки, без повторов, порядок сохранён."""
    if not isinstance(value, list):
        return ()
    out: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        marker = item.strip()
        if marker and marker not in out:
            out.append(marker)
    return tuple(out)


def load_canon(path: Path | None = None) -> MarkerCanon:
    """Прочитать канон. Нет файла / битый YAML / не словарь → :class:`CanonUnavailable`.

    Причина отказа — ПО СУЩЕСТВУ (чего именно не хватило), а не «что-то пошло не
    так»: ею продолжают работу — идут и правят файл.
    """
    target = Path(path) if path is not None else ai_markers_path()
    try:
        raw = target.read_text(encoding="utf-8")
    except OSError as exc:
        raise CanonUnavailable(
            f"канон ИИ-маркеров не прочитался ({target}): {exc.strerror or exc}"
        ) from exc
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as exc:
        raise CanonUnavailable(
            f"канон ИИ-маркеров битый (YAML не разобрался): {target}"
        ) from exc
    if not isinstance(data, dict):
        raise CanonUnavailable(
            f"канон ИИ-маркеров не разобрался в словарь (получено {type(data).__name__}): {target}"
        )

    def _section(name: str) -> dict[Any, Any]:
        """Секция канона словарём. Не словарь или нет вовсе → пустая (не падение).

        Одна опечатка в ключе не имеет права уронить весь гард: уровень просто
        окажется пустым, а пустой ЦЕЛИКОМ канон отсеется проверкой ниже.
        """
        value = data.get(name)
        return value if isinstance(value, dict) else {}

    ban = _section("ban")
    density = _section("density")
    calques_raw = _section("calques")
    patterns = _section("patterns")

    threshold = density.get("threshold_per_1000_words")
    try:
        threshold_value = float(threshold) if threshold is not None else 0.0
    except (TypeError, ValueError):
        threshold_value = 0.0

    calques: list[tuple[str, str]] = []
    for left, right in calques_raw.items():
        if isinstance(left, str) and left.strip():
            calques.append((left.strip(), str(right or "").strip()))

    canon = MarkerCanon(
        ban_typography=_strings(ban.get("typography")),
        ban_phrases=_strings(ban.get("phrases")),
        ban_emoji=_flag(ban.get("emoji_in_business")),
        density_threshold=threshold_value,
        density_phrases=_strings(density.get("phrases")),
        calques=tuple(calques),
        question_headings=_flag(patterns.get("question_headings")),
        triads=_flag(patterns.get("triads")),
        path=str(target),
    )
    if not (canon.ban_typography or canon.ban_phrases or canon.ban_emoji
            or canon.density_phrases or canon.calques
            or canon.question_headings or canon.triads):
        # Пустой канон — не «текст чист», а нечитаемая конфигурация: файл есть,
        # проверять нечем. Молчать про это значило бы выдать отсутствие проверки
        # за отсутствие маркеров.
        raise CanonUnavailable(
            f"канон ИИ-маркеров пуст (ни одного уровня и ни одного детектора): {target}"
        )
    return canon


# --------------------------------------------------------------------------- #
# Отчёт                                                                       #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class StyleReport:
    """Находки по тексту. ``unavailable`` — проверка не состоялась (канон не прочитан).

    ``density`` заполняется ТОЛЬКО при превышении порога (ТЗ: ниже порога — тишина):
    иначе блок с цифрами приезжал бы на каждый чистый текст и стал бы фоном.
    """

    ban: tuple[dict[str, Any], ...] = ()
    density: dict[str, Any] = field(default_factory=dict)
    calques: tuple[dict[str, Any], ...] = ()
    patterns: tuple[dict[str, Any], ...] = ()
    unavailable: str = ""
    canon_path: str = ""

    def has_findings(self) -> bool:
        """Есть ли хоть одна находка любого уровня (ключ ответа появляется по ней)."""
        return bool(self.ban or self.density or self.calques or self.patterns)

    def warns(self) -> bool:
        """Нужен ли warning-конверт: уровень ban либо превышение density (ТЗ п.2).

        Кальки и паттерны конверта НЕ поднимают: это подсказки замены, и делать из
        них отказ значило бы утопить сигнал уровня 1 в фоне уровня 3.
        """
        return bool(self.ban) or bool(self.density)

    def to_dict(self) -> dict[str, Any]:
        """Форма для ответа инструмента (все четыре уровня, пустые — пустыми)."""
        return {
            "ban": list(self.ban),
            "density": dict(self.density),
            "calques": list(self.calques),
            "patterns": list(self.patterns),
        }

    def reason(self) -> str:
        """Человеку — одной фразой, по уровням, с самыми частыми маркерами."""
        parts: list[str] = []
        if self.ban:
            parts.append(
                "запрет: "
                + ", ".join(f"{h['marker']}×{h['count']}" for h in self.ban[:5])
            )
        if self.density:
            top = ", ".join(
                f"{p['phrase']}×{p['count']}" for p in self.density.get("phrases", [])[:5]
            )
            parts.append(
                f"плотность связок {self.density['per_1000_words']} на 1000 слов "
                f"(порог {self.density['threshold']}): {top}"
            )
        if self.calques:
            parts.append(
                "кальки: "
                + ", ".join(
                    f"«{c['found']}» → {c['suggest']}" for c in self.calques[:3] if c["suggest"]
                )
            )
        if self.patterns:
            kinds = sorted({p["pattern"] for p in self.patterns})
            parts.append("паттерны: " + ", ".join(kinds))
        return "ИИ-маркеры в тексте — " + "; ".join(parts) if parts else ""


# --------------------------------------------------------------------------- #
# Детекторы                                                                   #
# --------------------------------------------------------------------------- #
def _blank_out(match: re.Match[str]) -> str:
    """Заменить цитату пробелами, сохранив переводы строк (номера строк не съезжают)."""
    return "".join("\n" if ch == "\n" else " " for ch in match.group(0))


def _mask_quotes(text: str) -> str:
    """Убрать из проверки явные backtick-цитаты (чужое написание — не наш маркер)."""
    return _INLINE_CODE_RE.sub(_blank_out, _FENCE_RE.sub(_blank_out, text))


def _line_starts(text: str) -> list[int]:
    """Смещения начал строк — чтобы перевести позицию находки в номер строки."""
    starts = [0]
    for i, ch in enumerate(text):
        if ch == "\n":
            starts.append(i + 1)
    return starts


def _line_of(starts: list[int], pos: int) -> int:
    """Номер строки (1-based) для смещения. Бинарный поиск не нужен: строк немного."""
    line = 1
    for i, start in enumerate(starts):
        if start > pos:
            break
        line = i + 1
    return line


def _occurrences(haystack_low: str, needle: str) -> list[int]:
    """Смещения всех вхождений (без пересечений), поиск по уже опущенному регистру."""
    needle_low = needle.casefold()
    if not needle_low:
        return []
    out: list[int] = []
    start = 0
    while True:
        found = haystack_low.find(needle_low, start)
        if found < 0:
            return out
        out.append(found)
        start = found + len(needle_low)


def _hit(marker: str, kind: str, positions: list[int], starts: list[int]) -> dict[str, Any]:
    """Одна находка: что, какого рода, сколько раз и на каких строках."""
    lines: list[int] = []
    for pos in positions:
        line = _line_of(starts, pos)
        if line not in lines:
            lines.append(line)
        if len(lines) >= _MAX_LINES:
            break
    return {"marker": marker, "kind": kind, "count": len(positions), "lines": lines}


def _emoji_hits(text: str, starts: list[int]) -> list[dict[str, Any]]:
    """Эмодзи в деловом тексте (запрет канона). Группируем по символу."""
    found: dict[str, list[int]] = {}
    for pos, ch in enumerate(text):
        code = ord(ch)
        if any(low <= code <= high for low, high in _EMOJI_RANGES):
            found.setdefault(ch, []).append(pos)
    return [
        _hit(char, "emoji", positions, starts)
        for char, positions in sorted(found.items(), key=lambda kv: -len(kv[1]))
    ]


def _ban_hits(text: str, low: str, starts: list[int], canon: MarkerCanon) -> list[dict[str, Any]]:
    """Уровень 1: вхождения запретных маркеров (типографика, фразы, эмодзи)."""
    hits: list[dict[str, Any]] = []
    for marker in canon.ban_typography:
        positions = _occurrences(low, marker)
        if positions:
            hits.append(_hit(marker, "typography", positions, starts))
    for marker in canon.ban_phrases:
        positions = _occurrences(low, marker)
        if positions:
            hits.append(_hit(marker, "phrase", positions, starts))
    if canon.ban_emoji:
        hits.extend(_emoji_hits(text, starts))
    return hits


def _density(low: str, words: int, canon: MarkerCanon) -> dict[str, Any]:
    """Уровень 2: СУММАРНАЯ плотность связок на 1000 слов против порога канона.

    Пусто, если порога нет, слов нет или плотность в норме — ТЗ требует тишины
    ниже порога, и это главное свойство уровня: маркер здесь не фраза, а частота.
    """
    if canon.density_threshold <= 0 or words <= 0 or not canon.density_phrases:
        return {}
    counted: list[dict[str, Any]] = []
    total = 0
    for phrase in canon.density_phrases:
        count = len(_occurrences(low, phrase))
        if count:
            counted.append({"phrase": phrase, "count": count})
            total += count
    if not total:
        return {}
    per_1000 = round(total * 1000.0 / words, 1)
    if per_1000 <= canon.density_threshold:
        return {}
    counted.sort(key=lambda p: (-int(p["count"]), str(p["phrase"])))
    return {
        "per_1000_words": per_1000,
        "threshold": canon.density_threshold,
        "words": words,
        "hits": total,
        "phrases": counted,
    }


def _calque_hits(low: str, starts: list[int], canon: MarkerCanon) -> list[dict[str, Any]]:
    """Уровень 3: нашли левую часть — подсказали правую."""
    hits: list[dict[str, Any]] = []
    for left, right in canon.calques:
        positions = _occurrences(low, left)
        if not positions:
            continue
        hit = _hit(left, "calque", positions, starts)
        hits.append({"found": left, "suggest": right,
                     "count": hit["count"], "lines": hit["lines"]})
    return hits


def _heading_text(line: str) -> str:
    """Текст заголовка, если строка им является; иначе пустая строка.

    Заголовок — либо markdown-решётки, либо строка КАПСОМ (канон К.: разделы капсом
    или нумерацией). Обычная фраза с вопросом внутри абзаца заголовком не считается.
    """
    md = _MD_HEADING_RE.match(line)
    if md:
        return md.group("text").strip().strip("*_ ")
    stripped = _NUM_PREFIX_RE.sub("", line.strip()).strip("*_ ")
    if not stripped:
        return ""
    letters = [ch for ch in stripped if ch.isalpha()]
    if len(letters) >= 3 and all(ch.isupper() for ch in letters):
        return stripped
    return ""


def _is_question_heading(heading: str) -> bool:
    """Заголовок-вопрос: начинается вопросительным словом + «?» либо придаточное.

    «Полное придаточное» приближаем дёшево: после вопросительного слова есть ещё
    не меньше двух слов («Как это работает»). «Что делать» под детектор не идёт —
    осознанный пропуск вместо угадывания без морфологии.
    """
    words = re.findall(r"[^\W\d_]+", heading, re.UNICODE)
    if not words or words[0].casefold() not in _QUESTION_WORDS:
        return False
    return heading.rstrip().endswith("?") or len(words) >= 3


def _triad_hits(text: str, starts: list[int]) -> list[dict[str, Any]]:
    """Ритмичная тройка «X, Y и Z» из однородных слов (по совпадению окончания)."""
    hits: list[dict[str, Any]] = []
    for match in _TRIAD_RE.finditer(text):
        words = [w.casefold() for w in match.groups()]
        suffix = next(
            (s for s in _TRIAD_SUFFIXES if all(w.endswith(s) for w in words)),
            None,
        )
        if suffix is None:
            continue
        hits.append({
            "pattern": "triads",
            "line": _line_of(starts, match.start()),
            "text": match.group(0),
        })
    return hits


def _pattern_hits(text: str, starts: list[int], canon: MarkerCanon) -> list[dict[str, Any]]:
    """Паттерн-детекторы: заголовки-вопросы и тройки (каждый — по флагу канона)."""
    hits: list[dict[str, Any]] = []
    if canon.question_headings:
        for number, line in enumerate(text.splitlines(), start=1):
            heading = _heading_text(line)
            if heading and _is_question_heading(heading):
                hits.append({"pattern": "question_headings", "line": number,
                             "text": heading})
    if canon.triads:
        hits.extend(_triad_hits(text, starts))
    hits.sort(key=lambda h: (int(h["line"]), str(h["pattern"])))
    return hits


# --------------------------------------------------------------------------- #
# Точка входа                                                                 #
# --------------------------------------------------------------------------- #
def check_text(
    text: str,
    *,
    canon: MarkerCanon | None = None,
    canon_path: Path | None = None,
) -> StyleReport:
    """Проверить текст по канону ИИ-маркеров. Никогда не бросает.

    Канон не прочитался → отчёт с ``unavailable`` (и без находок): «проверка не
    состоялась» структурно отличается от «текст чист» (п.22).
    """
    if canon is None:
        try:
            canon = load_canon(canon_path)
        except CanonUnavailable as exc:
            return StyleReport(unavailable=str(exc))
    body = _mask_quotes(unicodedata.normalize("NFC", text or ""))
    low = body.casefold()
    starts = _line_starts(body)
    words = len(_WORD_RE.findall(body))
    return StyleReport(
        ban=tuple(_ban_hits(body, low, starts, canon)),
        density=_density(low, words, canon),
        calques=tuple(_calque_hits(low, starts, canon)),
        patterns=tuple(_pattern_hits(body, starts, canon)),
        canon_path=canon.path,
    )


def attach_style_markers(
    payload: dict[str, Any],
    text: str,
    *,
    canon_path: Path | None = None,
) -> dict[str, Any]:
    """Положить находки в ответ инструмента. Возвращает тот же ответ.

    Три исхода, все различимы машиной:

    * канон не прочитался → конверт ``store_unavailable``, ключа находок НЕТ
      (проверять было нечем — и об этом сказано вслух);
    * находок нет → ответ НЕ меняется вовсе (байт-идентичен прежнему: happy-path
      обязан пройти снапшотом без правок);
    * находки есть → ключ ``style_markers`` со всеми четырьмя уровнями, а конверт
      ``style_markers`` — только при ban / превышении density (ТЗ п.2). НЕ блок:
      сохранение уже состоялось, решение по тексту за человеком.
    """
    report = check_text(text, canon_path=canon_path)
    if report.unavailable:
        add_warning(
            payload, CODE_STORE_UNAVAILABLE, report.unavailable
            + " — проверка ИИ-маркеров НЕ выполнена (это не «текст чист»); "
            "канон: vault/_system/style-guides/ai-markers.yaml",
        )
        return payload
    if not report.has_findings():
        return payload
    payload[STYLE_MARKERS_KEY] = report.to_dict()
    if report.warns():
        add_warning(payload, CODE_STYLE_MARKERS, report.reason(),
                    ban=len(report.ban),
                    density_per_1000=report.density.get("per_1000_words"))
    return payload
