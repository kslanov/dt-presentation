"""PERSONAL-3 п.A1 - манифест роли: ОДНО место, где записано, что есть у роли.

До этого «что есть у роли» было размазано по трем реестрам (адаптеры входа, задания JOB-1, секции
пульта) и CSS-списку скрытий в клиенте: личный экземпляр регистрировал те же адаптеры
``timetta``/``mail``/ ``legacy``, а пульт прятал рабочие секции стилями, оставляя кнопки Outlook и
плитки почты. Теперь:

* таблица :data:`SURFACES` - **данные**, а не ветки ``if is_personal()``: секции пульта, блоки
карточки «Мониторинг», кнопки заданий, виды карточек, источники свежести, проверки доктора, которых
у роли нет;
* реестры движка (``ingress.registry``, ``freshness``, ``jobs``, ``decisions.kinds``, шаги
``dt_sync``, доктор) читают отсюда и из ``IngressAdapter.roles``, своих списков не держат;
* инструмент ``pult_manifest`` отдает пульту ответ :func:`manifest` для роли процесса; клиент рисует
  только объявленное (необъявленное - не «скрыто», а отсутствует).

Роль ``work`` - все как до ТЗ (снимок - тест регрессии ``tests/test_surface_manifest.py``).

**DEV-3-CORE: вторая ось таблицы - коннектор.** :data:`CONNECTOR_AXIS` - данные: какой элемент
поверхности (секция, op задания, вид карточки, шаг ``dt_sync``, проверка доктора, инструмент MCP)
принадлежит какому коннектору (:mod:`core.connectors`: ``timetta``/``ticktick``/``outlook``) -
вентиль :class:`Gate` (``any_of``: хватает любого из коннекторов; ``all_of``: нужны все). Входные
источники (шаги, свежесть, строки «Хранилища», ops) берут коннектор у своего адаптера
(``IngressAdapter.connector``). Выключенный коннектор: элемент НЕ объявлен (секции/задания/виды),
шаг не идет, проверка не считается (вместо нее одна строка ``ok «коннектор X выключен»``),
инструмент отвечает конвертом ``connector_disabled``. Включены все (auto с секретами) - таблица
прозрачна: снимок роли ``work`` байт в байт как до ТЗ."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any

__all__ = [
    "BOTH", "SURFACES", "STATIC_SOURCES", "STATIC_STEPS", "OP_ROLES", "CONNECTOR_AXIS", "Gate",
    "JobSpec", "LAUNCHD_JOBS", "Surface", "launchd_jobs",
    "blocked", "card_kinds", "connector_notes", "connector_state", "gated_items",
    "doctor_excluded", "freshness_sources", "has_ingest_roots", "job_specs", "manifest", "op_roles",
    "role_of", "skipped_steps", "static_steps", "step_roles", "sync_steps", "surface",
]

WORK, PERSONAL = "work", "personal"
BOTH = (WORK, PERSONAL)


@dataclass(frozen=True)
class JobSpec:
    """Кнопка задания пульта: подпись, ``op`` JOB-1 и его аргументы."""

    label: str
    op: str
    args: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {"label": self.label, "op": self.op, "args": dict(self.args)}


@dataclass(frozen=True)
class Surface:
    """Поверхность роли. ``sections`` - ключи секций пульта (``data-help``/``data-sec``); те, что в
    ``roots_sections``, показываются только при непустых ingest-корнях (иначе пусты по сути)."""

    title: str
    subtitle: str
    sections: tuple[str, ...]
    roots_sections: tuple[str, ...]
    monitor_blocks: tuple[str, ...]
    jobs: tuple[JobSpec, ...]
    card_kinds: tuple[str, ...]
    roots_freshness: tuple[str, ...]  # источники свежести, которых нет без ingest-корней
    doctor_excluded: tuple[str, ...]
    # DEV-3-CORE: коннекторы, состояние которых роль объявляет в манифесте (личная - нет: у нее
    # их нет по роли); ``connector_sections`` - секции, объявляемые, когда один из них выключен
    connectors: tuple[str, ...] = ()
    connector_sections: tuple[str, ...] = ()


# --------------------------------------------------------------------------- #
# Рабочая роль: ровно то, что пульт показывал до ТЗ                             #
# --------------------------------------------------------------------------- #
_WORK = Surface(
    title="Работа",
    subtitle="",
    sections=(
        # Работа
        "rings", "brief", "work-kpis", "work-attention", "work-stale", "work-meetings",
        "work-resurface",
        # Двойник
        "queue", "synth-entry", "inbox", "links", "function", "create", "ripe", "store-sources",
        "store-journal", "store-refusals", "store-trace",
        # Мониторинг
        "monitor", "eval-quality", "doctor", "log", "hosts", "trend",
        # Настройки
        "store-paths", "services", "ai-synth", "webpult", "owner", "store-actions",
    ),
    roots_sections=(),
    monitor_blocks=("health", "night_chain", "sync", "jobs", "freshness", "storage", "activity",
                    "long_ops"),
    jobs=(
        JobSpec("reindex · инкремент", "reindex", {"scope": "incremental"}),
        JobSpec("reindex · полный", "reindex", {"scope": "full"}),
        JobSpec("Outlook · встречи", "outlook_read", {"mode": "meetings"}),
        JobSpec("Outlook · задачи", "outlook_read", {"mode": "ticktick"}),
        JobSpec("Outlook · почта", "outlook_read", {"mode": "mail"}),
    ),
    card_kinds=("assignment", "untriaged", "hub", "alias", "synth", "lint", "gold", "reattr",
                "link", "ripe_lead"),
    roots_freshness=(),
    doctor_excluded=(),
    connectors=("timetta", "ticktick", "outlook"),
    connector_sections=("connectors",),
)

# --------------------------------------------------------------------------- # Личная роль: Работа
# - личные виджеты; Двойник - очередь моста и инбокс; без почты/Timetta/Outlook   #
# --------------------------------------------------------------------------- #
_PERSONAL = Surface(
    title="Личное",
    subtitle="личный контур",
    sections=(
        "pers-today", "pers-recall", "pers-bridge",                       # Работа
        "queue", "inbox", "store-sources", "store-journal",                # Двойник
        "monitor", "doctor", "log", "trend",                               # Мониторинг
        "store-paths", "services", "pers-bridge-settings", "pers-folders", "owner",  # Настройки
    ),
    roots_sections=("store-sources", "store-journal"),
    monitor_blocks=("health", "night_chain", "sync", "jobs", "freshness", "activity", "long_ops"),
    jobs=(
        JobSpec("reindex · инкремент", "reindex", {"scope": "incremental"}),
        JobSpec("reindex · полный", "reindex", {"scope": "full"}),
    ),
    card_kinds=("bridge",),
    roots_freshness=("files:knowledge",),
    # перечень снят с живого ``doctor()`` личного экземпляра (tmp-копия, 01.11); тест сверяет с
    # кодом
    doctor_excluded=(
        "Timetta токен", "Timetta identity", "Зеркало Timetta", "Манифест почты",
        "Outlook-мост (osascript)", "Почтовые треды", "Byte-hash легаси", "Качество выдачи",
        "Золотой набор", "Доступ хостов: папки с _nda не выданы", "Хосты без записи в host-access",
        "Хабы без track", "Хабы: имена", "Хабы: кандидаты", "Синтез хабов",
    ),
)

SURFACES: dict[str, Surface] = {WORK: _WORK, PERSONAL: _PERSONAL}


# --------------------------------------------------------------------------- #
# Ось «коннектор» (DEV-3-CORE)                                                  #
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Gate:
    """Вентиль элемента поверхности: открыт, если включен любой из ``any_of`` (когда задан) И все из
    ``all_of``. Ключи - коннекторы реестра :mod:`core.connectors`."""

    any_of: tuple[str, ...] = ()
    all_of: tuple[str, ...] = ()

    def open(self, on: Callable[[str], bool]) -> bool:
        return (not self.any_of or any(on(k) for k in self.any_of)) and all(
            on(k) for k in self.all_of)

    @property
    def keys(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys((*self.any_of, *self.all_of)))


def _one(key: str) -> Gate:
    return Gate(any_of=(key,))


_FEED = Gate(any_of=("timetta", "ticktick", "outlook"))  # из чего собран work_feed

# kind -> {элемент: вентиль}. Виды: section | job_op | card_kind | step | doctor | tool |
# launchd_job (DEV-3-KIT: плановое задание; ключ - ``com.dt.<ключ>``).
CONNECTOR_AXIS: dict[str, dict[str, Gate]] = {
    # секции пульта (data-sec); необъявленная не рисуется и ничего не грузит
    "section": {
        "rings": _one("timetta"), "function": _one("timetta"), "ripe": _one("timetta"),
        "work-meetings": _one("outlook"),
        "brief": _FEED, "work-kpis": _FEED, "work-attention": _FEED, "work-stale": _FEED,
    },
    # ops JOB-1 вне реестра входа (ops адаптеров берут коннектор у адаптера)
    "job_op": {"outlook_read": _one("outlook")},
    "card_kind": {"assignment": _one("timetta"), "ripe_lead": _one("timetta")},
    # статические шаги dt_sync (шаги адаптеров - у адаптеров)
    "step": {"reconcile": Gate(all_of=("timetta", "ticktick"))},
    # проверки доктора по имени (другие проверки роли - в ``Surface.doctor_excluded``)
    "doctor": {
        "Timetta токен": _one("timetta"), "Timetta identity": _one("timetta"),
        "Зеркало Timetta": _one("timetta"), "Сделки без юрлица": _one("timetta"),
        "Зеркало: удалённые": _one("timetta"), "Кольца орбиты": _one("timetta"),
        "TickTick токен": _one("ticktick"), "Захват": _one("ticktick"),
        "Манифест почты": _one("outlook"), "Outlook-мост (osascript)": _one("outlook"),
        "Почтовые треды": _one("outlook"),
    },
    # плановые задания launchd: задание выключенного коннектора не ставится
    "launchd_job": {"meetings": _one("outlook")},
    # инструменты MCP: выключенный коннектор - конверт ``connector_disabled``
    "tool": {
        "pult_deals": _one("timetta"), "pult_watch": _one("timetta"),
        "pult_hub_link_deal": _one("timetta"), "pult_hub_unlink_deal": _one("timetta"),
        "pult_set_track": _one("timetta"), "pult_function": _one("timetta"),
        "pult_ripe_leads": _one("timetta"),
        "work_meetings": _one("outlook"), "work_meeting_prep": _one("outlook"),
        "work_ticktick": _one("ticktick"),
        "work_feed": _FEED, "work_context": _FEED,
    },
}


def _on(key: str) -> bool:
    from core import connectors

    return connectors.enabled(key)


def blocked(kind: str, item: str) -> tuple[str, ...] | None:
    """Коннекторы, из-за которых ``item`` недоступен (вентиль закрыт), либо ``None`` (открыт/нет в
    таблице). Для ops JOB-1 адаптеров вход - в :func:`_op_gate`."""
    gate = CONNECTOR_AXIS.get(kind, {}).get(item)
    if kind == "job_op" and gate is None:
        gate = _op_gate(item)
    if gate is None or gate.open(_on):
        return None
    return gate.keys


#: Плановые задания рабочей роли (DEV-3-KIT п.3): ``(ключ, ярус)``, шаблон - ``ops/launchd/
#: com.dt.<ключ>.plist``. ``base`` - ставятся всегда (кроме закрытых вентилем коннектора);
#: ``ops`` - только владельцу (``dt install --ops-full``): смоук eval и сторож прогонов.
LAUNCHD_JOBS: tuple[tuple[str, str], ...] = (
    ("server", "base"), ("sync.fast", "base"), ("sync.index", "base"), ("backup", "base"),
    ("meetings", "base"), ("smoke", "ops"), ("run.watchdog", "ops"),
)


def launchd_jobs(
    *, ops_full: bool = False, environ: Mapping[str, str] | None = None,
) -> list[str]:
    """Ключи заданий launchd для установки: ярус ``base`` (+ ``ops`` при ``ops_full``) минус
    задания выключенных коннекторов. ``environ`` - окружение ЦЕЛИ (``.env`` устанавливаемого
    экземпляра), а не процесса: так ``dt install`` решает состав до запуска демона."""
    from core import connectors

    def on(key: str) -> bool:
        return connectors.enabled(key, environ)

    out: list[str] = []
    for key, tier in LAUNCHD_JOBS:
        if tier == "ops" and not ops_full:
            continue
        gate = CONNECTOR_AXIS["launchd_job"].get(key)
        if gate is None or gate.open(on):
            out.append(key)
    return out


def gated_items(kind: str) -> list[str]:
    """Все элементы ``kind`` из таблицы оси (тесты и обертки инструментов выводят список отсюда)."""
    return list(CONNECTOR_AXIS.get(kind, {}))


def _op_gate(op: str) -> Gate | None:
    """Вентиль op: таблица оси либо коннектор адаптера, которому op принадлежит."""
    if op in CONNECTOR_AXIS["job_op"]:
        return CONNECTOR_AXIS["job_op"][op]
    from core.ingress import registry

    for adapter in registry.ADAPTERS.values():
        if adapter.op == op and adapter.connector:
            return _one(adapter.connector)
    return None

# Источники свежести вне реестра входа: (ключ, порядок строки, порог часов, шаг, (режим, шаги
# точечного синка), роли). Входные источники берутся из реестра адаптеров (``fresh_order``).
_Sync = tuple[str, tuple[str, ...]]
STATIC_SOURCES: tuple[tuple[str, int, float, str, _Sync, tuple[str, ...]], ...] = (
    ("index", 40, 26.0, "reindex_inc", ("index", ("reindex_inc",)), BOTH),
    ("linking", 50, 26.0, "link_auto", ("index", ("link_auto", "hub_scan")), BOTH),
    # последний скан моста: только личная роль
    ("bridge", 55, 26.0, "bridge", ("index", ("bridge",)), (PERSONAL,)),
)

# --------------------------------------------------------------------------- #
# Шаги dt_sync: имена, место и роли не-входных шагов (входные - у адаптеров)       #
# --------------------------------------------------------------------------- #
# (режим, порядок, имя, роли). Имена прежние: на них завязаны launchd-логи, свежесть, пульт.
STATIC_STEPS: tuple[tuple[str, int, str, tuple[str, ...]], ...] = (
    ("fast", 25, "reconcile", (WORK,)),
    ("index", 5, "ocr", BOTH),
    ("index", 20, "link_auto", BOTH),
    ("index", 30, "hub_scan", BOTH),
    ("index", 35, "lint", BOTH),
    ("index", 40, "reindex_inc", BOTH),
    ("index", 45, "bridge", (PERSONAL,)),
    ("index", 50, "eval", (WORK,)),
    ("index", 60, "doctor", BOTH),
)

# Роли статических ops JOB-1 (ops входа берут роли у своих адаптеров).
OP_ROLES: dict[str, tuple[str, ...]] = {
    "reindex": BOTH,
    "outlook_read": (WORK,),
    "lift_source": BOTH,
    "backfill_hashes": (WORK,),
    "ocr": BOTH,
}


def role_of(role: str | None = None) -> str:
    """Роль процесса (``DT_INSTANCE_ROLE``) либо переданная явно."""
    if role:
        return role
    from core.instance import instance_role

    return instance_role()


def surface(role: str | None = None) -> Surface:
    return SURFACES[role_of(role)]


def has_ingest_roots() -> bool:
    """Есть ли у экземпляра хоть один ingest-корень (``_system/ingest-roots.yaml`` не пуст)."""
    try:
        from core.file_ingest.config import load_ingest_roots

        return bool(load_ingest_roots())
    except Exception:  # noqa: BLE001 - нет конфига/vault: корней нет
        return False


def _roots(roots: bool | None) -> bool:
    return has_ingest_roots() if roots is None else roots


def _off(role_connectors: tuple[str, ...]) -> list[str]:
    return [k for k in role_connectors if not _on(k)]


def sections(role: str | None = None, *, roots: bool | None = None) -> list[str]:
    s = surface(role)
    keep = list(s.sections)
    if s.roots_sections and not _roots(roots):
        keep = [k for k in keep if k not in s.roots_sections]
    keep = [k for k in keep if blocked("section", k) is None]
    if _off(s.connectors):  # есть что объяснить - строка «Коннекторы» в Настройках
        keep += list(s.connector_sections)
    return keep


def card_kinds(role: str | None = None) -> list[str]:
    return [k for k in surface(role).card_kinds if blocked("card_kind", k) is None]


def job_specs(role: str | None = None) -> list[JobSpec]:
    return [j for j in surface(role).jobs if blocked("job_op", j.op) is None]


def doctor_excluded(role: str | None = None) -> frozenset[str]:
    """Проверки, которых у роли нет: таблица роли + проверки выключенных коннекторов."""
    off = {name for name, gate in CONNECTOR_AXIS["doctor"].items() if not gate.open(_on)}
    return frozenset(surface(role).doctor_excluded) | off


def connector_state(role: str | None = None) -> dict[str, dict[str, object]]:
    """``{ключ: {enabled, reason, requires}}`` коннекторов роли (у личной - ``{}``)."""
    from core import connectors

    return {k: connectors.status(k).as_dict() for k in surface(role).connectors}


def connector_notes(role: str | None = None) -> list[tuple[str, str, str]]:
    """``(ключ, подпись, причина)`` выключенных коннекторов роли - по строке ``ok`` в докторе."""
    from core import connectors

    out = []
    for k in _off(surface(role).connectors):
        out.append((k, connectors.CONNECTORS[k].label, connectors.status(k).reason))
    return out


def freshness_sources(role: str | None = None, *, roots: bool | None = None) -> list[str]:
    """Источники плитки «Свежесть» роли, по порядку строк: входы - из реестра адаптеров (по
    ``roles``), остальные - из :data:`STATIC_SOURCES`; ``roots_freshness`` роли - только при
    ingest-корнях."""
    from core.ingress import registry

    r = role_of(role)
    s = SURFACES[r]
    rows: list[tuple[int, str]] = [
        (a.fresh_order, a.freshness_key) for a in registry.adapters(role=r)
        if a.freshness_key and a.stale_after_h is not None and a.step]
    rows += [(order, key) for key, order, _h, _st, _sy, roles in STATIC_SOURCES if r in roles]
    rows.sort(key=lambda x: x[0])
    keep_roots = _roots(roots) if s.roots_freshness else True
    return [k for _o, k in rows if keep_roots or k not in s.roots_freshness]


def step_roles(name: str) -> tuple[str, ...]:
    """Роли шага: статический - по таблице, шаг адаптера - по ролям адаптера (иначе обе)."""
    for _mode, _order, step, roles in STATIC_STEPS:
        if step == name:
            return roles
    from core.ingress import registry

    for adapter in registry.ADAPTERS.values():
        if name == adapter.step or name in adapter.sync_steps:
            return adapter.roles
    return BOTH


def static_steps(mode: str, role: str | None = None) -> list[tuple[int, str]]:
    r = role_of(role)
    return [(order, name) for m, order, name, roles in STATIC_STEPS
            if m == mode and r in roles and blocked("step", name) is None]


def skipped_steps(mode: str, role: str | None = None) -> list[tuple[str, tuple[str, ...]]]:
    """Шаги режима роли, которых нет из-за выключенного коннектора: ``(шаг, коннекторы)``."""
    from core.ingress import registry

    r = role_of(role)
    out: list[tuple[str, tuple[str, ...]]] = []
    for a in registry.adapters(mode, role=r, enabled_only=False):
        if a.step and a.connector and not registry.connector_enabled(a):
            out.append((a.step, (a.connector,)))
    for m, _order, name, roles in STATIC_STEPS:
        keys = blocked("step", name)
        if m == mode and r in roles and keys:
            out.append((name, keys))
    return out


def sync_steps(role: str | None = None) -> dict[str, tuple[str, ...]]:
    """``{fast, index, full}`` для роли: входы - из реестра адаптеров (по ``roles``), прочие - из
    :data:`STATIC_STEPS`; порядок - по ``order``. У роли ``work`` совпадает с прежним
    ``SYNC_STEPS``."""
    from core.ingress import registry

    r = role_of(role)
    out: dict[str, tuple[str, ...]] = {}
    for mode in ("fast", "index"):
        rows = [(a.order, a.step) for a in registry.adapters(mode, role=r) if a.step]
        rows += static_steps(mode, r)
        rows.sort(key=lambda x: x[0])
        out[mode] = tuple(name for _order, name in rows)
    out["full"] = out["fast"] + out["index"]
    return out


def op_roles(op: str) -> tuple[str, ...]:
    """Роли ``op`` JOB-1: статические - :data:`OP_ROLES`, входные - роли их адаптера."""
    if op in OP_ROLES:
        return OP_ROLES[op]
    from core.ingress import registry

    for adapter in registry.ADAPTERS.values():
        if adapter.op == op:
            return adapter.roles
    return ()


def manifest(role: str | None = None, *, roots: bool | None = None) -> dict[str, Any]:
    """Ответ ``pult_manifest``: что у роли есть. ``version`` - 12 символов sha256 содержимого."""
    r = role_of(role)
    s = SURFACES[r]
    from core.instance import instance_name

    body: dict[str, Any] = {
        "instance": {"name": instance_name() or "", "role": r},
        "title": s.title,
        "subtitle": s.subtitle,
        "sections": sections(r, roots=roots),
        "monitor_blocks": list(s.monitor_blocks),
        "jobs": [j.to_dict() for j in job_specs(r)],
        "card_kinds": card_kinds(r),
        "freshness_sources": freshness_sources(r, roots=roots),
        "sync_modes": {k: list(v) for k, v in sync_steps(r).items()},
    }
    # версия - по составу поверхности (до DEV-3-CORE ключей не прибавилось): состояние коннекторов
    # в нее не входит - оно меняет секции/задания/виды, а те уже в хэше
    digest = hashlib.sha256(json.dumps({k: v for k, v in body.items() if k != "instance"},
                                       sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    body["version"] = digest[:12]
    body["connectors"] = connector_state(r)
    return body
