"""Адрес этой машины в сети Tailscale (CONFIG-1 п.5): ``tailscale status --json`` → DNS-имя и IP.

Нужен режиму ``DT_MODE=server``: DNS-rebinding защита ``/mcp`` пускает ``Host`` с этим именем/IP, а
``/health`` и доктор называют, где сервер. Только чтение статуса, в сеть не ходит (локальный сокет
``tailscaled``). Нет бинаря / не залогинен / не JSON - ``None`` («Tailscale нет»): вызывающий
решает (демон стартует в ``local``, ``dt config check`` ругается).

``core`` не зависит от MCP/CLI; запуск процесса инъектируется (``runner``), тесты подставляют ответ.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

__all__ = ["BIN_ENV", "TailscaleInfo", "find_binary", "parse_status", "status"]

BIN_ENV = "DT_TAILSCALE_BIN"
_MAC_APP_BIN = "/Applications/Tailscale.app/Contents/MacOS/Tailscale"
_TIMEOUT = 5.0

#: (argv, timeout) -> (returncode, stdout)
Runner = Callable[[list[str], float], "tuple[int, str]"]


@dataclass(frozen=True)
class TailscaleInfo:
    dns: str  # ``konstantins-macbook-pro.tail1faf5a.ts.net`` (без хвостовой точки)
    ips: tuple[str, ...]  # ``100.99.184.42``, ``fd7a:…``

    def as_health(self) -> dict[str, object]:
        """Для ``/health``: имя и адреса, без секретов."""
        return {"dns": self.dns, "ips": list(self.ips)}


def find_binary() -> str | None:
    """``DT_TAILSCALE_BIN`` → ``tailscale`` в PATH → приложение Tailscale на macOS."""
    override = (os.environ.get(BIN_ENV) or "").strip()
    if override:
        return override if shutil.which(override) or Path(override).exists() else None
    return shutil.which("tailscale") or (_MAC_APP_BIN if Path(_MAC_APP_BIN).exists() else None)


def parse_status(raw: str) -> TailscaleInfo | None:
    """``tailscale status --json`` → ``Self.DNSName`` + ``Self.TailscaleIPs``; иначе ``None``."""
    try:
        data = json.loads(raw)
    except ValueError:
        return None
    if not isinstance(data, dict) or data.get("BackendState") not in (None, "Running"):
        return None  # не вошли / остановлен: адреса нет
    self_ = data.get("Self")
    if not isinstance(self_, dict):
        return None
    dns = str(self_.get("DNSName") or "").rstrip(".").strip()
    ips = tuple(str(ip) for ip in (self_.get("TailscaleIPs") or []) if ip)
    if not dns and not ips:
        return None
    return TailscaleInfo(dns=dns, ips=ips)


def _default_runner(argv: list[str], timeout: float) -> tuple[int, str]:
    proc = subprocess.run(  # noqa: S603 — фиксированный argv
        argv, capture_output=True, text=True, timeout=timeout, check=False,
    )
    return proc.returncode, proc.stdout


def status(*, runner: Runner | None = None, binary: str | None = None) -> TailscaleInfo | None:
    """Адрес этой машины в tailnet или ``None`` (нет Tailscale / не вошли / сбой)."""
    exe = binary or (find_binary() if runner is None else "tailscale")
    if not exe:
        return None
    try:
        code, out = (runner or _default_runner)([exe, "status", "--json"], _TIMEOUT)
    except (OSError, subprocess.SubprocessError):
        return None
    return parse_status(out) if code == 0 else None
