"""RETR-RANK-1 п.3 — русский стем-ключ для скана, нормализации клиента и FTS-запроса.

Зачем свой слой поверх snowball. Индекс FTS LanceDB (``language="Russian"``) стеммит русские
формы одним проходом Snowball-ru, и этого не хватает для имён: Snowball режет ``-ом`` у
именительного («телеком» → «телек») и ``-а`` у родительного («телекома» →
«телеком») — формы одного слова получают РАЗНЫЕ стемы (замер q06, docs/findings/
retr-rank-1.md). Здесь стем-ключ — **неподвижная точка** повторного прохода: оба → «телек».
Для поиска сущностей перестемливание безвредно (ключ нужен для равенства форм, а не для
показа), поэтому скан и каталог хабов сравнивают ключи, а запрос в FTS расширяется ключами
(:func:`fts_query`).

Латиница, цифры и аббревиатуры без кириллицы не стеммятся (индекс при языке Russian тоже
оставляет английские термы как есть): только нижний регистр.

Зависимость ``snowballstemmer`` (чистый python). Нет модуля → ключ = нижний регистр без
стемминга (поиск работает, как до RETR-RANK-1; флаг :data:`AVAILABLE` для doctor/логов).
"""

from __future__ import annotations

import re
import unicodedata
from functools import lru_cache

try:  # pragma: no cover — ветка зависит от окружения
    import snowballstemmer  # type: ignore[import-untyped]  # чистый python, без стабов

    _STEMMER = snowballstemmer.stemmer("russian")
except Exception:  # noqa: BLE001 — зависимость опциональна: деградация без стемминга
    _STEMMER = None

__all__ = [
    "AVAILABLE",
    "stem_word",
    "stem_chain",
    "stem_key",
    "tokens",
    "fold_stem",
    "key_tokens",
    "fts_query",
]

AVAILABLE = _STEMMER is not None

_TOKEN_RE = re.compile(r"\w+", re.UNICODE)
_CYRILLIC_RE = re.compile(r"[а-яё]", re.IGNORECASE)
_MAX_PASSES = 6          # неподвижная точка достигается за 1-4 прохода; страховка от цикла
_MIN_WORD_LEN = 4        # короткие слова (ЦД, ИТХ, ПАК) не трогаем — стемминг портит аббревиатуры
_MIN_STEM_LEN = 4        # стем короче не принимаем: остановка на предыдущем проходе


def _clean(word: str) -> str:
    return unicodedata.normalize("NFC", word).casefold().replace("ё", "е")


@lru_cache(maxsize=262144)
def stem_word(word: str) -> str:
    """Один проход Snowball-ru (как в индексе FTS); не-кириллица — только регистр."""
    w = _clean(word)
    if _STEMMER is None or not _CYRILLIC_RE.search(w):
        return w
    return str(_STEMMER.stemWord(w))


@lru_cache(maxsize=262144)
def stem_chain(word: str) -> tuple[str, ...]:
    """Цепочка стемов слова: проход 1, проход 2, … до неподвижной точки (без самого слова).

    Каждый элемент — потенциальный терм индекса FTS (его стеммер однопроходный): «телекома»
    → («телеком», «телек»); индексный терм «телек» живёт у слов «…ком».
    """
    w = _clean(word)
    if len(w) < _MIN_WORD_LEN or not _CYRILLIC_RE.search(w):
        return ()
    chain: list[str] = []
    cur = w
    for _ in range(_MAX_PASSES):
        nxt = stem_word(cur)
        if nxt == cur or len(nxt) < _MIN_STEM_LEN:
            break
        chain.append(nxt)
        cur = nxt
    return tuple(chain)


@lru_cache(maxsize=262144)
def stem_key(word: str) -> str:
    """Стем-ключ слова: неподвижная точка :func:`stem_word` (формы одного слова → один ключ)."""
    chain = stem_chain(word)
    return chain[-1] if chain else _clean(word)


def tokens(text: str) -> list[str]:
    """Слова текста (``\\w+``, NFC), без свёртки регистра."""
    return _TOKEN_RE.findall(unicodedata.normalize("NFC", str(text)))


def key_tokens(text: str) -> list[str]:
    """Стем-ключи слов текста по порядку."""
    return [stem_key(t) for t in tokens(text)]


def fold_stem(text: str) -> str:
    """Свёртка текста для сравнения подстрокой: ключи слов через пробел."""
    return " ".join(key_tokens(text))


def fts_query(
    query: str, extra_terms: tuple[str, ...] | list[str] = (), *, variants: bool = True
) -> str:
    """Запрос для FTS: исходный текст + цепочки стемов слов (термы, которых нет в запросе).

    FTS LanceDB — OR по термам, стемминг ИНДЕКСА однопроходный; промежуточные стемы и
    неподвижная точка добавляют термы, на которые «телекома» не вышла бы сама.
    ``extra_terms`` — готовые слова/фразы (канонические имена хаба, п.4), как есть.
    ``variants=False`` — только ``extra_terms`` (без стем-вариантов слов запроса).
    """
    base = str(query).strip()
    if not base:
        return ""
    seen = {_clean(t) for t in tokens(base)}
    extra: list[str] = []
    for tok in tokens(base) if variants else ():
        for variant in stem_chain(tok):
            if variant not in seen:
                seen.add(variant)
                extra.append(variant)
    for term in extra_terms:
        for t in tokens(term):
            c = _clean(t)
            if c and c not in seen:
                seen.add(c)
                extra.append(t)
    return " ".join([base, *extra]) if extra else base
