"""OUT-COMPLETE-1 — покрытие чтения почтовых тредов: от прослеживаемости к ПОЛНОТЕ.

Контур выхода (SRC-TRACE-2) фиксирует, что ИСПОЛЬЗОВАНО; фейлкейс 01.10 показал, что
строка ``sources.md`` про тред верна, а неверно то, что из того же источника НЕ взято:
справка писалась по треду, чьё последнее входящее (ответ контрагента) агент не читал —
``truncated: true`` он видел и пошёл писать. Здесь неполнота становится громкой в точке
принятия решения (``save_output``).

Две половины, одна на границе MCP, другая на выходе:

* **Событие ``thread_read``** (:func:`thread_read_event`) — пишут ``read_note`` /
  ``work_note_preview`` / ``lift_source`` по заметке ``email-thread``: ``{tool, note_id,
  shown_full: [idx], total, last_inbound_read}``. Privacy: только индексы и счётчики —
  без адресов, тем и текстов. Точка записи одна — обёртка ``guarded_tool`` (как
  телеметрия отказов FAIL-TELEMETRY-1), не россыпь по инструментам.
* **Свёртка окна** (:func:`check_sources`) — для источников выхода, которые являются
  почтовыми тредами, сводит события окна [``output_begin`` .. ``save_output``]:
  последнее входящее прочитано → тишина; нет → ``source_incomplete`` с ``{date, from}``
  непрочитанного; тред вообще не читался (только объявлен вручную) →
  ``not_read_in_window``. Предупреждение, не блок: решение остаётся за автором.

``core`` ⊥ mcp/cli; без сети и LLM.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.contract import CODE_NOT_READ_IN_WINDOW, CODE_SOURCE_INCOMPLETE
from core.retrieval.mail_read import EMAIL_THREAD, ParsedThread, parse_thread

logger = logging.getLogger(__name__)

__all__ = [
    "THREAD_READ_KIND",
    "THREAD_READ_TOOLS",
    "ThreadFinding",
    "thread_read_event",
    "check_sources",
]

THREAD_READ_KIND = "thread_read"
THREAD_READ_TOOLS = ("read_note", "work_note_preview", "lift_source")

# Форма ссылки на почтовый тред в sources.md (виртуальный ключ, id легаси-заметки, путь).
_THREAD_REF_MARKERS = ("correspondence/", "conv:", "msg:")


def _note_fm(ref: str, vault_path: Path | None) -> tuple[dict[str, Any], str] | None:
    """``(frontmatter, body)`` заметки по ссылке любой формы или ``None``."""
    from core.vault import read_note, resolve_note_path

    try:
        found = resolve_note_path(ref, vault_path=vault_path)
        if found is None:
            return None
        note = read_note(found)
    except Exception:  # noqa: BLE001 — телеметрия/проверка best-effort
        return None
    return dict(note.frontmatter), note.body


def thread_read_event(
    tool: str, args: tuple[Any, ...], kwargs: dict[str, Any], result: Any
) -> dict[str, Any] | None:
    """Поля события ``thread_read`` по ответу инструмента или ``None`` (не почтовый тред).

    * ``read_note`` — по ``messages``-сводке ответа: показанными целиком считаются
      сообщения из ``shown_full`` БЕЗ ``shown_partial`` (обрезанное не прочитано);
    * ``work_note_preview`` — превью почтового треда: касание без чтения сообщений;
    * ``lift_source`` — по ``note_id`` заметки-треда: файла за виртуальным
      ``source_path`` нет, содержимое сообщений подъём не даёт.
    """
    if tool not in THREAD_READ_TOOLS or not isinstance(result, dict):
        return None
    if tool == "read_note":
        summary = result.get("messages")
        note_id = result.get("id")
        if not isinstance(summary, dict) or not note_id:
            return None
        partial = set(summary.get("shown_partial") or [])
        read = sorted(i for i in (summary.get("shown_full") or []) if i not in partial)
        inbound = summary.get("last_inbound")
        return {
            "tool": tool, "note_id": str(note_id), "shown_full": read,
            "total": int(summary.get("total") or 0),
            "last_inbound_read": inbound is None or inbound in read,
        }
    if tool == "work_note_preview":
        note_id = result.get("note_id")
        if not note_id or "message_count" not in result:
            return None
        return {"tool": tool, "note_id": str(note_id), "shown_full": [],
                "total": int(result.get("message_count") or 0), "last_inbound_read": False}
    ref = kwargs.get("note_id") or (args[0] if args else None)
    if not ref:
        return None
    loaded = _note_fm(str(ref), None)
    if loaded is None or loaded[0].get("source_type") != EMAIL_THREAD:
        return None
    fm = loaded[0]
    return {"tool": tool, "note_id": str(fm.get("id") or ref), "shown_full": [],
            "total": int(fm.get("message_count") or 0), "last_inbound_read": False}


@dataclass
class ThreadFinding:
    """Итог проверки одного источника-треда."""

    code: str  # source_incomplete | not_read_in_window
    note_id: str
    source: str  # как источник назван в sources.md
    shown: str  # «3 из 4»
    total: int
    unread: list[dict[str, str]] = field(default_factory=list)  # [{date, from}]
    line: str = ""  # строка для sources.md
    reason: str = ""  # человеку, одной фразой

    def envelope_context(self) -> dict[str, Any]:
        return {"note_id": self.note_id, "source": self.source, "shown": self.shown,
                "unread": self.unread}


def _is_thread_ref(path: str, kind: str) -> bool:
    return kind == EMAIL_THREAD or any(m in path for m in _THREAD_REF_MARKERS) or path.startswith(
        "legacy-"
    )


def _window_events(since: datetime, until: datetime) -> list[dict[str, Any]]:
    from core.metrics import _parse_ts, read_events

    start = since.astimezone(UTC).replace(microsecond=0)
    end = until.astimezone(UTC)
    out = []
    for ev in read_events(since=start):
        if ev.get("kind") != THREAD_READ_KIND:
            continue
        ts = _parse_ts(ev.get("ts"))
        if ts is not None and start <= ts <= end.replace(microsecond=999999):
            out.append(ev)
    return out


def _fmt_unread(parsed: ParsedThread, idxs: list[int]) -> list[dict[str, str]]:
    by_idx = {m.idx: m for m in parsed.messages}
    return [{"date": by_idx[i].date, "from": by_idx[i].sender} for i in idxs if i in by_idx]


def check_sources(
    sources: list[tuple[str, str]],
    since: datetime,
    until: datetime,
    *,
    vault_path: Path | None = None,
    events: list[dict[str, Any]] | None = None,
) -> list[ThreadFinding]:
    """Полнота чтения для источников выхода, являющихся почтовыми тредами.

    ``sources`` — ``[(path, kind)]`` строк ``sources.md``. Полностью прочитанный тред
    (последнее входящее показано целиком хотя бы одним вызовом окна) и не-почтовые
    источники в результат не попадают — вызывающий при пустом результате ничего не меняет
    (байт-идентичный ответ).
    """
    findings: list[ThreadFinding] = []
    pool = events if events is not None else _window_events(since, until)
    seen: set[str] = set()
    for path, kind in sources:
        if not _is_thread_ref(path, kind):
            continue
        loaded = _note_fm(path, vault_path)
        if loaded is None or loaded[0].get("source_type") != EMAIL_THREAD:
            continue
        fm, body = loaded
        note_id = str(fm.get("id") or "")
        if not note_id or note_id in seen:
            continue
        seen.add(note_id)
        parsed = parse_thread(body)
        if parsed is None or not parsed.messages:
            continue
        total = len(parsed.messages)
        mine = [e for e in pool if e.get("note_id") == note_id]
        inbound = [m.idx for m in parsed.messages if not m.is_me]
        last_inbound = inbound[-1] if inbound else None
        if not mine:
            # Раскрываем, что именно осталось непрочитанным: последнее входящее.
            unread = _fmt_unread(parsed, inbound[-1:])
            tail = (f"; последнее входящее — {unread[0]['from']} от {unread[0]['date']}"
                    if unread else "")
            findings.append(ThreadFinding(
                CODE_NOT_READ_IN_WINDOW, note_id, path, f"0 из {total}", total, unread,
                line=f"{path} — в окне begin→save не читался (0 из {total}){tail}",
                reason=f"тред {path} указан источником, но в окне работы не читался{tail}",
            ))
            continue
        covered: set[int] = set()
        for e in mine:
            covered.update(i for i in (e.get("shown_full") or []) if isinstance(i, int))
        done = any(e.get("last_inbound_read") for e in mine) or (
            last_inbound is None or last_inbound in covered
        )
        if done:
            continue
        unread_idx = [i for i in inbound if i not in covered][-3:]
        unread = _fmt_unread(parsed, unread_idx)
        last = unread[-1]
        shown = f"{len(covered & {m.idx for m in parsed.messages})} из {total}"
        findings.append(ThreadFinding(
            CODE_SOURCE_INCOMPLETE, note_id, path, shown, total, unread,
            line=f"{path} — прочитано {shown}, не прочитан ответ {last['from']} от {last['date']}",
            reason=(f"тред {path}: прочитано {shown}, не прочитан ответ {last['from']} "
                    f"от {last['date']} — вывод по треду неполон"),
        ))
    return findings
