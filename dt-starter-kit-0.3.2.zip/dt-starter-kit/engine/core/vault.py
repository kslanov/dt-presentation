"""Vault reading — markdown notes with YAML-frontmatter (architecture §1, §3).

Reads the plain-markdown source of truth into typed :class:`Note` objects and
walks the vault tree. Frontmatter wikilink fields are normalized to bare ids so
downstream code (chunking, retrieval) gets structured metadata without parsing
markdown bodies.
"""

from __future__ import annotations

import logging
import os
import re
from collections.abc import Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import frontmatter

logger = logging.getLogger(__name__)

__all__ = [
    "Note",
    "read_note",
    "iter_vault",
    "iter_vault_paths",
    "write_note",
    "resolve_note_path",
    "note_path_for_id",
    "note_path_for_source",
    "set_frontmatter_fields",
    "set_frontmatter_fields_text",
    "read_frontmatter_fields_text",
    "FrontmatterError",
    "RawYaml",
]

# Frontmatter fields that hold wikilinks ("to what does this belong"), per §1.
# Their values are normalized from "[[client-x]]" → "client-x"; both single
# values and arrays are supported.
WIKILINK_FIELDS: tuple[str, ...] = (
    "client",
    "project",
    "deal",
    "industry",
    "direction",
    "product",
    "participants",
    "sources",
)

# Known frontmatter schema (§1). Listed for documentation / validation; unknown
# fields are preserved as-is in Note.frontmatter rather than dropped.
KNOWN_FIELDS: tuple[str, ...] = (
    "id",
    "type",
    "created",
    "modified",
    "status",
    "tags",
    *WIKILINK_FIELDS,
    "genre",
    "timetta_id",
    "timetta_sync",
)

# Matches [[target]] or [[target|display]], capturing the target id.
_WIKILINK_RE = re.compile(r"\[\[([^\[\]|]+?)(?:\|[^\]]*)?\]\]")


@dataclass
class Note:
    """A single markdown note parsed from the vault.

    Attributes:
        id: Stable identifier (frontmatter ``id`` or, as fallback, file stem).
        type: Content-file type (``note``, ``meeting``, ``output`` …) or None.
        path: Source file path.
        frontmatter: Full parsed frontmatter dict (wikilinks normalized,
            unknown fields preserved).
        body: Markdown body with the frontmatter block stripped.
    """

    id: str
    type: str | None
    path: Path
    frontmatter: dict[str, Any]
    body: str


def _extract_id(value: Any) -> Any:
    """Normalize a single wikilink value to its bare id.

    ``"[[client-x]]"`` → ``"client-x"``; ``"[[id|Display]]"`` → ``"id"``.
    Plain strings without brackets are stripped and returned. Non-strings are
    returned untouched.
    """
    if not isinstance(value, str):
        return value
    match = _WIKILINK_RE.search(value)
    if match:
        return match.group(1).strip()
    return value.strip()


def _normalize_wikilink(value: Any) -> Any:
    """Normalize a wikilink field, supporting both a single value and a list."""
    if isinstance(value, list):
        return [_extract_id(item) for item in value]
    return _extract_id(value)


def note_id_from_path(path: Path, vault_root: Path | None = None) -> str:
    """Идентичность заметки БЕЗ frontmatter ``id`` (WAVE0-HYGIENE п.2, аудит B2/C3).

    Путь заметки относительно корня vault без ``.md`` (posix, NFC): ``07-outputs/2026-10/
    <папка>/output``. Раньше id = ``path.stem`` — 129 выходов с одинаковыми именами
    ``output``/``sources``/``prompt`` схлопывались в 3 id, и индекс жил с одним выходом из
    54. Путь уникален по построению. Корень не задан → берём vault из конфига; путь вне
    vault (или конфиг недоступен) → прежний ``stem`` (разовое чтение файла вне vault).
    """
    path = Path(path)
    root = vault_root
    if root is None:
        try:
            from core.config import default_vault_path

            root = default_vault_path()
        except Exception:  # noqa: BLE001 — нижний слой: без конфига остаётся stem
            root = None
    if root is not None:
        try:
            rel = path.resolve().relative_to(Path(root).resolve())
        except (ValueError, OSError):
            rel = None
        if rel is not None:
            import unicodedata

            return unicodedata.normalize("NFC", rel.with_suffix("").as_posix())
    return path.stem


def read_note(path: Path, vault_root: Path | None = None) -> Note:
    """Read one markdown file with YAML-frontmatter into a :class:`Note`.

    Missing frontmatter fields never raise; unknown fields are preserved. Без
    frontmatter ``id`` идентичность — vault-относительный путь без ``.md``
    (:func:`note_id_from_path`), а не имя файла: имена в vault не уникальны.
    """
    path = Path(path)
    post = frontmatter.load(str(path))
    meta: dict[str, Any] = dict(post.metadata)

    for field in WIKILINK_FIELDS:
        if meta.get(field) is not None:
            meta[field] = _normalize_wikilink(meta[field])

    note_id = meta.get("id") or note_id_from_path(path, vault_root)
    note_type = meta.get("type")
    return Note(
        id=str(note_id),
        type=note_type,
        path=path,
        frontmatter=meta,
        body=post.content,
    )


# ``_``-prefixed folders that ARE part of the retrieval index despite the prefix.
# ``_legacy/`` is the layer-B legacy corpus (ТЗ phase5): real notes living under
# a single underscore-root so Obsidian can fold them, but they must be indexed
# like any vault note. Everything else under ``_`` (``_system``, ``_staging``)
# stays excluded.
INDEXED_UNDERSCORE_DIRS: frozenset[str] = frozenset({"_legacy"})

# DEV-3-CORE: README папок из каркаса vault (``engine/vault-template``) - не знание: первая строка
# файла ``README.md`` - этот маркер, и обход его пропускает (в индекс, линковку, линт не попадает).
# Открывается только файл с именем README.md, остальные .md обход не читает.
TEMPLATE_README_MARKER = "<!-- dt-template: readme"


def is_template_readme(path: Path) -> bool:
    """``README.md`` каркаса vault (первая строка - :data:`TEMPLATE_README_MARKER`)."""
    if path.name != "README.md":
        return False
    try:
        with open(path, "rb") as fh:
            head = fh.read(64)
    except OSError:
        return False
    return head.decode("utf-8", errors="ignore").lstrip("\ufeff").startswith(
        TEMPLATE_README_MARKER)


def iter_vault_paths(
    vault_path: Path, include_system: bool = False, *, apply_nda: bool = True
) -> Iterator[Path]:
    """Walk a vault and yield every markdown file **path** (no parsing).

    Same walk rules as :func:`iter_vault` (``_``/``.``-prefixed folders excluded,
    ``_legacy/`` included) — split out so cheap passes (e.g. the Phase-9 link
    scan) can stat-compare files against a manifest and parse only the changed
    ones instead of reading the whole vault.

    PERSONAL-2: у личного экземпляра обход пропускает пути из ``DT_INDEX_EXCLUDE`` (дефолт
    ``Templates/**``): они не попадают ни в индекс, ни в скан frontmatter, ни в линковку. У рабочего
    экземпляра исключений нет - обход прежний.

    NDA barrier (NDA-1): an ``_nda/`` folder is already dropped by the ``_``-rule,
    but a suffix file (``report_nda.md``) or a custom-marker folder would slip
    through — so :func:`core.privacy.is_nda` is applied to each directory segment
    and filename (per-component, no absolute prefix) and NDA paths never index,
    even under ``_legacy/``. ``apply_nda=False`` opts out — used only by the
    source resolver to *find* an NDA note so it can refuse it explicitly, never for
    indexing.
    """
    from core.instance import excluded, index_exclude
    from core.privacy import is_nda

    vault_path = Path(vault_path)
    skip = index_exclude()  # PERSONAL-2: у личного экземпляра - DT_INDEX_EXCLUDE; у рабочего пусто
    for root, dirs, files in os.walk(vault_path):
        if skip:
            rel_root = Path(root).relative_to(vault_path).as_posix()
            base = "" if rel_root == "." else rel_root + "/"
            dirs[:] = [d for d in dirs if not excluded(base + d, skip)]
            files = [f for f in files if not excluded(base + f, skip)]
        if not include_system:
            dirs[:] = [
                d
                for d in dirs
                if (
                    d in INDEXED_UNDERSCORE_DIRS
                    or not (d.startswith("_") or d.startswith("."))
                )
                and not (apply_nda and is_nda(d))
            ]
        elif apply_nda:
            dirs[:] = [d for d in dirs if not is_nda(d)]
        dirs.sort()
        for name in sorted(files):
            if name.endswith(".md") and not (apply_nda and is_nda(name)):
                if name == "README.md" and is_template_readme(Path(root) / name):
                    continue
                yield Path(root) / name


def iter_vault(
    vault_path: Path, include_system: bool = False, *, apply_nda: bool = True
) -> Iterator[Note]:
    """Walk a vault and yield every markdown :class:`Note`.

    Folders prefixed with ``_`` (system, e.g. ``_system/``, ``_staging/``) and
    hidden ``.``-folders are excluded from the walk — they are not part of the
    retrieval index (§3) — unless ``include_system=True``. The legacy corpus root
    ``_legacy/`` is the one exception (see :data:`INDEXED_UNDERSCORE_DIRS`): it is
    underscore-prefixed for graph hygiene but indexed like any other note.

    NDA-marked notes (NDA-1) are excluded like the index unless ``apply_nda=False``
    (the resolver's explicit-refusal path only).
    """
    for path in iter_vault_paths(vault_path, include_system, apply_nda=apply_nda):
        yield read_note(path, vault_path)


def write_note(note: Note, path: Path | None = None) -> Path:
    """Serialize a :class:`Note` back to markdown (frontmatter + body).

    Optional helper for round-trips. Writes ``note.frontmatter`` verbatim, so
    re-reading is stable (normalization is idempotent: ids carry no brackets).
    """
    target = Path(path) if path is not None else note.path
    post = frontmatter.Post(note.body, **note.frontmatter)
    target.write_text(frontmatter.dumps(post), encoding="utf-8")
    return target


# --------------------------------------------------------------------------- #
# SRC-PATH-1 - один хирургический писатель полей frontmatter                    #
# --------------------------------------------------------------------------- #
# Раньше было три регекса-копии (hub_link: timetta_id и произвольное поле, attribute: client).
# Контракт один: меняется/вставляется ТОЛЬКО строка(и) поля, остальной frontmatter и тело -
# байт-в-байт; окончания строк (CRLF) сохраняются; повтор того же значения - без записи.
# Скаляр, который PyYAML сложил на несколько строк (длинный ``source_path`` с пробелами -
# продолжение с отступом), заменяется целиком вместе с продолжением.

_FM_BLOCK_RE = re.compile(r"^---\r?\n(.*?)\r?\n---\r?\n?", re.DOTALL)


class FrontmatterError(ValueError):
    """Нет YAML-блока / значение не разбирается - заметку не трогаем."""


@dataclass(frozen=True)
class RawYaml:
    """Значение, которое пишется во frontmatter КАК ЕСТЬ (уже готовый YAML-скаляр)."""

    text: str


def _render_field(field: str, value: str | RawYaml, eol: str) -> list[str]:
    """Строки ``<field>: <value>`` (сложенный скаляр - несколько строк), как их пишет PyYAML."""
    if isinstance(value, RawYaml):
        return [f"{field}: {value.text}" if value.text else f"{field}:"]
    import yaml  # type: ignore[import-untyped]

    dumped = yaml.safe_dump(
        {field: str(value)}, allow_unicode=True, default_flow_style=False
    )
    return dumped.rstrip("\n").split("\n")


def _field_span(lines: list[str], field: str) -> tuple[int, int] | None:
    """(start, end) - строка ключа и последняя строка продолжения; нет поля - ``None``."""
    key = f"{field}:"
    for i, ln in enumerate(lines):
        if ln.startswith(key):
            end = i
            while end + 1 < len(lines) and re.match(r"(?:\s+\S|- )", lines[end + 1]):
                end += 1
            return (i, end)
    return None


def _previous_value(chunk: list[str], field: str) -> tuple[str, str]:
    """(сырое значение для отчета, разобранное YAML-значение для сравнения)."""
    import yaml  # type: ignore[import-untyped]

    first = chunk[0][len(field) + 1 :].strip()
    try:
        loaded = yaml.safe_load("\n".join(chunk))
    except yaml.YAMLError:
        return (first, first)
    value = loaded.get(field) if isinstance(loaded, dict) else None
    parsed = first if value is None else str(value)
    return (first if len(chunk) == 1 else parsed, parsed)


def set_frontmatter_fields_text(
    text: str, fields: dict[str, str | RawYaml], *, insert_missing: bool = True
) -> tuple[str, dict[str, str], bool]:
    """Хирургически проставить скалярные поля во frontmatter ``text``.

    Возвращает ``(new_text, previous, changed)``: ``previous`` - прежние значения (``""`` -
    поля не было), ``changed`` - изменилась ли хоть одна строка. Строка поля заменяется на
    месте; нового поля нет - вставка после ``id:`` (иначе в конец блока), а при
    ``insert_missing=False`` не вставляется (``unlink``: нечего очищать). Остальное -
    байт-в-байт, CRLF сохраняется. Идемпотентно: значение, равное прежнему, - ``changed=False``,
    текст тот же. Нет YAML-блока → :class:`FrontmatterError`. ``str``-значения кодируются как
    это делает ``write_note`` (PyYAML, ``allow_unicode``); :class:`RawYaml` - дословно.
    """
    m = _FM_BLOCK_RE.match(text)
    if not m:
        raise FrontmatterError("во frontmatter нет YAML-блока")
    eol = "\r\n" if "\r\n" in text[: m.end()] else "\n"
    lines = m.group(1).split(eol)
    previous: dict[str, str] = {}
    changed = False
    for field, value in fields.items():
        new_lines = _render_field(field, value, eol)
        span = _field_span(lines, field)
        if span is None:
            previous[field] = ""
            if not insert_missing:
                continue
            at = next((i for i, ln in enumerate(lines) if ln.startswith("id:")), None)
            at = len(lines) if at is None else at + 1
            lines[at:at] = new_lines
            changed = True
            continue
        start, end = span
        chunk = lines[start : end + 1]
        previous[field], parsed = _previous_value(chunk, field)
        same = previous[field] == value.text if isinstance(value, RawYaml) else parsed == str(value)
        if chunk == new_lines or same:
            continue
        lines[start : end + 1] = new_lines
        changed = True
    if not changed:
        return (text, previous, False)
    new_fm = eol.join(lines)
    return (text[: m.start(1)] + new_fm + text[m.end(1) :], previous, True)


def read_frontmatter_fields_text(text: str, fields: tuple[str, ...]) -> dict[str, str]:
    """Скалярные значения полей (разобранные YAML) из frontmatter ``text``; нет поля - ``""``.

    Читает тем же срезом строк, что писатель (сложенный скаляр - целиком), и не парсит остальной
    блок. Нет YAML-блока → :class:`FrontmatterError`.
    """
    m = _FM_BLOCK_RE.match(text)
    if not m:
        raise FrontmatterError("во frontmatter нет YAML-блока")
    lines = m.group(1).split("\r\n" if "\r\n" in text[: m.end()] else "\n")
    out: dict[str, str] = {}
    for field in fields:
        span = _field_span(lines, field)
        out[field] = _previous_value(lines[span[0] : span[1] + 1], field)[1] if span else ""
    return out


def set_frontmatter_fields(
    path: Path, fields: dict[str, str | RawYaml]
) -> tuple[dict[str, str], bool]:
    """:func:`set_frontmatter_fields_text` над файлом (пишет, только если изменилось).

    Читает/пишет байты без перевода строк (``newline=""``), чтобы CRLF не терялся.
    """
    target = Path(path)
    with target.open(encoding="utf-8", newline="") as fh:
        text = fh.read()
    new_text, previous, changed = set_frontmatter_fields_text(text, fields)
    if changed:
        with target.open("w", encoding="utf-8", newline="") as fh:
            fh.write(new_text)
    return previous, changed


# --------------------------------------------------------------------------- #
# NOTE-ID-1 — одна идентичность заметки на всех читателей                       #
# --------------------------------------------------------------------------- #
# Кейс К. с пульта (2026-08-12): линк-предложение на цель ``pak-a-zdo-overview``,
# превью — «заметка не найдена в vault», при живой заметке
# ``03-projects/gp-zdo-pak-a-xyz/pak-a-overview.md`` (frontmatter ``id`` ≠ имя файла).
# У заметки было ДВЕ идентичности в разных резолверах: линковка/apply ищет по
# frontmatter id (и находит — «Применить» было безопасно), а читатели искали по имени
# файла/пути. Тот же класс уже чинился в индексе (INDEX-PERF-1, reverse-index id↔path).
#
# Здесь резолв один для всех читателей, и порядок выбран по цене:
#   1. путь (абсолютный или vault-относительный) — один ``stat``;
#   2. **frontmatter id через индекс-манифест** — он ключуется note_id, поэтому путь
#      известен за O(1), без обхода vault;
#   3. имя файла ``<ref>.md`` (и legacy-форма ``legacy-<hash>`` → ``*-<hash[:8]>.md``) —
#      один обход дерева, последним: это самый дорогой шаг.
#
# Заметка вне индекса (только что созданная, reindex ещё не прошёл) резолвится шагами
# 1/3 — то есть ровно как раньше.
#
# CONTRACT-1 ФП-1 (2026-08-14, FINDINGS `docs/findings/audit-contract-1.md` Д2/Д7):
# добавлена ЧЕТВЁРТАЯ форма — строка, которую движок сам показывает как ``source_path``
# заметки: относительная корню хранилища (``2018-2023/…/x.pdf``), абсолютная
# (``/…/CDT_Internal/…/ТКП.pdf``), root-относительная (``Kazakhstan/Emba/x.docx``) и
# ВИРТУАЛЬНАЯ у почты (``correspondence/conv:207549`` — файла за ней нет вовсе,
# `core/legacy/mail.py:321`). Кейс справки 14.08: `read_note` отвечал «no such note» на
# строку из выдачи `find_notes`. Индекса под это заводить не надо — обратные карты
# ``source_path → заметка`` уже лежат на диске в трёх манифестах инжеста (тот же джойн,
# что делает INGEST-VIS-1 ``pult_ingest_trace``), поэтому шаг остаётся O(1) по словарю и
# НЕ добавляет ни сканов vault, ни нового стейта.
_LEGACY_ID_PREFIX = "legacy-"
_LEGACY_HASH_HEAD = 8

# Сколько последних сегментов пути образуют «хвост» для сшивки разных записей одного и
# того же файла (абсолютный путь ↔ root-относительный ↔ относительный корню легаси).
# Два — минимум, при котором голое имя файла не даёт ложных совпадений (то же правило,
# что в `core.sources.resolver._resolve_under_ingest_roots`).
_TAIL_SEGMENTS = 2


@dataclass(frozen=True)
class _RefMaps:
    """Обратные карты ссылок, собранные из уже существующих манифестов (ФП-1/ФП-2).

    ``by_note_id`` — ``note_id → vault-относительный путь заметки`` (индекс-манифест).
    ``by_source`` — ``нормализованный source_path → путь заметки`` (манифесты инжеста
    current/legacy + почтовый индекс, где ключ — ``conv:``/``msg:``-тред).
    ``by_tail`` — то же по хвосту из :data:`_TAIL_SEGMENTS` сегментов, и **только для
    однозначных** хвостов: неоднозначный выброшен, потому что угадывать заметку по
    обрывку пути — ровно та тихая деградация, которую запрещает канон §9 п.22.
    """

    by_note_id: dict[str, str]
    by_source: dict[str, str]
    by_tail: dict[str, str]


# Кеш карт с инвалидацией по отпечатку файлов-манифестов (mtime+size каждого): reindex /
# прогон инжеста заметен сразу, а повторные промахи резолва не перечитывают JSON.
_REF_MAPS_CACHE: dict[str, Any] = {"fingerprint": None, "maps": None}


def _manifest_paths() -> list[Path]:
    """Файлы-манифесты, из которых собираются обратные карты (в порядке доверия)."""
    from core.config import (
        current_ingest_manifest_path,
        index_manifest_path,
        legacy_ingest_manifest_path,
        outlook_ingest_manifest_path,
    )

    return [
        index_manifest_path(),
        current_ingest_manifest_path(),
        legacy_ingest_manifest_path(),
        outlook_ingest_manifest_path(),
    ]


def _manifest_fingerprint(paths: list[Path]) -> tuple[tuple[str, float, int], ...]:
    """Отпечаток набора манифестов (путь+mtime+size) — ключ инвалидации кеша."""
    out: list[tuple[str, float, int]] = []
    for path in paths:
        try:
            st = path.stat()
            out.append((str(path), st.st_mtime, st.st_size))
        except OSError:
            out.append((str(path), 0.0, -1))
    return tuple(out)


def _load_manifest_json(path: Path) -> dict[str, Any]:
    """JSON-манифест как словарь; отсутствующий/битый — пустой (производное состояние)."""
    import json

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        # Производное состояние (резолв ссылок деградирует до обхода имён файлов), но не
        # молча: ADAPTER-HONEST-1.
        logger.warning("[vault] манифест %s нечитаем (%s) — резолв ссылок через обход имён",
                       path.name, type(exc).__name__)
        return {}
    return data if isinstance(data, dict) else {}


def _norm_ref(raw: str) -> str:
    """Нормализация ссылки для сверки: NFC + posix-слэши + без обрамляющих пробелов.

    NFC обязателен: macOS отдаёт имена в NFD, а манифесты писались из разных источников
    (`core.legacy.discover.nfc` — тот же приём).
    """
    import unicodedata

    return unicodedata.normalize("NFC", str(raw or "").strip().replace("\\", "/"))


def _tail_key(norm: str) -> str | None:
    """Хвост из :data:`_TAIL_SEGMENTS` сегментов, или ``None`` (сегментов меньше)."""
    parts = [p for p in norm.split("/") if p]
    if len(parts) < _TAIL_SEGMENTS:
        return None
    return "/".join(parts[-_TAIL_SEGMENTS:])


def _add_source(
    by_source: dict[str, str], tails: dict[str, list[str]], raw_key: str, note_rel: str
) -> None:
    """Занести пару ``source_path → путь заметки`` в прямую и хвостовую карты."""
    norm = _norm_ref(raw_key)
    if not norm or not note_rel:
        return
    by_source.setdefault(norm, note_rel)
    tail = _tail_key(norm)
    if tail is not None:
        bucket = tails.setdefault(tail, [])
        if note_rel not in bucket:
            bucket.append(note_rel)


def _ref_maps() -> _RefMaps:
    """Обратные карты ссылок (кеш с инвалидацией по отпечатку манифестов).

    Читает только уже существующее производное состояние:

    * индекс-манифест — ``note_id → {path, …}`` (плюс ``source_path``, если запись его
      несёт: поле появилось в CONTRACT-1 и заполняется по мере reindex — «пояс» к
      манифестам инжеста, а не замена им);
    * ``current_ingest_manifest`` / ``legacy_ingest_manifest`` — ``source_path →
      {note_path, …}`` (ключи: относительно знаниевого корня и корня легаси);
    * почтовый манифест — ``conv:<id>``/``msg:<id>`` → ``{note_path, …}``.

    Сбой чтения любого манифеста — не ошибка: карта просто беднее (индекс/инжест —
    производное состояние, источник истины — markdown).
    """
    paths = _manifest_paths()
    fingerprint = _manifest_fingerprint(paths)
    if _REF_MAPS_CACHE["fingerprint"] == fingerprint and _REF_MAPS_CACHE["maps"] is not None:
        return _REF_MAPS_CACHE["maps"]  # type: ignore[return-value]

    index_manifest, current_manifest, legacy_manifest, mail_manifest = (
        _load_manifest_json(p) for p in paths
    )

    by_note_id: dict[str, str] = {}
    by_source: dict[str, str] = {}
    tails: dict[str, list[str]] = {}

    for note_id, record in index_manifest.items():
        if not isinstance(record, dict):
            continue
        note_rel = str(record.get("path") or "")
        if not note_rel:
            continue
        by_note_id[str(note_id)] = note_rel
        source_path = record.get("source_path")
        if isinstance(source_path, str) and source_path.strip():
            _add_source(by_source, tails, source_path, note_rel)

    for manifest in (current_manifest, legacy_manifest, mail_manifest):
        for key, record in manifest.items():
            if not isinstance(record, dict):
                continue
            note_rel = str(record.get("note_path") or "")
            if note_rel:
                _add_source(by_source, tails, str(key), note_rel)

    maps = _RefMaps(
        by_note_id=by_note_id,
        by_source=by_source,
        # Однозначные хвосты только: неоднозначный хвост — не подсказка, а угадывание.
        by_tail={tail: rels[0] for tail, rels in tails.items() if len(rels) == 1},
    )
    _REF_MAPS_CACHE["fingerprint"] = fingerprint
    _REF_MAPS_CACHE["maps"] = maps
    return maps


def note_path_for_id(note_id: str) -> str | None:
    """vault-относительный путь заметки по её ``note_id`` (или ``None``) — O(1).

    ФП-2: этим живёт эмиттер ``find_notes`` — ссылку в поле ``path`` он обязан отдавать
    как путь заметки, а не как её ``source_path`` (Д1). Индекс-манифест ключуется
    ``note_id``, поэтому это словарный доступ; хит поиска пришёл ИЗ индекса, так что
    запись для него в манифесте есть.
    """
    ref = str(note_id or "").strip()
    if not ref:
        return None
    return _ref_maps().by_note_id.get(ref)


def note_path_for_source(source_path: str) -> str | None:
    """vault-относительный путь заметки по строке её ``source_path`` (или ``None``).

    Четвёртая форма ссылки (ФП-1): принимаются все виды, которые движок сам отдаёт —
    относительный корню хранилища/легаси, абсолютный, root-относительный и виртуальный
    почтовый (``correspondence/conv:207549``). Порядок: точное совпадение ключа →
    последний сегмент (снимает секцию-префикс у почты) → однозначный хвост из двух
    сегментов (сшивает абсолютный путь с относительным). Неоднозначный хвост не
    резолвится вовсе — лучше честное «не нашлось», чем чужая заметка.
    """
    norm = _norm_ref(source_path)
    if not norm:
        return None
    maps = _ref_maps()
    hit = maps.by_source.get(norm)
    if hit:
        return hit
    if "/" in norm:
        # Почта: ключ манифеста — сам тред (``conv:<id>``), а ``source_path`` заметки
        # несёт секцию-префикс (``correspondence/conv:<id>``).
        last = norm.rsplit("/", 1)[-1]
        hit = maps.by_source.get(last)
        if hit:
            return hit
    tail = _tail_key(norm)
    if tail is not None:
        return maps.by_tail.get(tail)
    return None


def _index_manifest_path_lookup(note_id: str) -> str | None:
    """Путь заметки по её ``note_id`` из индекс-манифеста (или ``None``).

    Тонкая обёртка над :func:`note_path_for_id` (кеш карт + инвалидация по отпечатку) —
    имя сохранено, потому что на него ссылаются комментарии NOTE-ID-1 и тесты.
    """
    return note_path_for_id(note_id)


def _walk_for_name(ref: str, vault: Path) -> Path | None:
    """Найти ``<ref>.md`` (или legacy-хвост ``-<hash[:8]>.md``) обходом дерева."""
    target = f"{ref}.md"
    legacy_suffix = None
    if ref.startswith(_LEGACY_ID_PREFIX):
        # Легаси-заметки: id = ``legacy-<hash>``, файл — ``<человекочит-slug>-<hash[:8]>.md``
        digest = ref[len(_LEGACY_ID_PREFIX):]
        if digest:
            legacy_suffix = f"-{digest[:_LEGACY_HASH_HEAD]}.md"
    for dirpath, _dirnames, filenames in os.walk(vault):
        if target in filenames:
            return Path(dirpath) / target
        if legacy_suffix is not None:
            hit = next((f for f in filenames if f.endswith(legacy_suffix)), None)
            if hit is not None:
                return Path(dirpath) / hit
    return None


def resolve_note_path(ref: str, *, vault_path: Path | None = None) -> Path | None:
    """Заметка по ссылке ЛЮБОЙ формы: путь | имя файла | frontmatter id | source_path.

    **Единственная точка резолва ссылки на заметку** — её обязаны звать ВСЕ читатели и
    писатели заметок (CONTRACT-1 ФП-1: `read_full_note`, превью «Работы», привязка к
    клиент-хабу, дописывание в хаб, хаб-писатели, резолвер источников, отбор источников
    линковки, образец оформления). Четыре формы, одна идентичность (плюс id без
    frontmatter = путь без ``.md``, WAVE0-HYGIENE п.2). ``None`` — не нашлось.

    Порядок — от самого дешёвого шага к самому дорогому:

    1. путь (абсолютный или vault-относительный) — один ``stat``;
    2. frontmatter ``id`` через индекс-манифест — O(1) по словарю;
    3. ``source_path`` заметки через обратные карты манифестов инжеста — O(1)
       (:func:`note_path_for_source`; сюда попадают ``conv:``/``msg:``-формы почты);
    4. имя файла ``<ref>.md`` (и legacy-форма ``legacy-<hash>`` → ``*-<hash[:8]>.md``) —
       один обход дерева, последним: это самый дорогой шаг.

    Возвращаемый путь **всегда внутри vault** — гард не ослаблен ни одной из форм: шаг 1
    отбрасывает уводящий наружу путь, шаги 2-4 конструируют путь от корня vault сами и
    проверяют его существование.
    """
    raw = str(ref or "").strip()
    if not raw:
        return None
    vault = Path(vault_path) if vault_path is not None else _default_vault()
    try:
        vault_resolved = vault.resolve()
    except OSError:
        return None

    def _inside(rel: str | None) -> Path | None:
        """vault-относительный путь из карты → существующий файл внутри vault."""
        if not rel:
            return None
        hit = (vault / rel).resolve()
        if not hit.is_file():
            return None
        if hit != vault_resolved and vault_resolved not in hit.parents:
            return None  # запись манифеста ведёт наружу — не наша заметка
        return hit

    candidate = Path(raw).expanduser()
    candidate = candidate if candidate.is_absolute() else vault / candidate
    if candidate.is_file():
        resolved = candidate.resolve()
        if resolved == vault_resolved or vault_resolved in resolved.parents:
            return resolved

    # WAVE0-HYGIENE п.2: id заметки без frontmatter — путь без ``.md``; индекс-манифест
    # ещё может его не знать (заметка новая), поэтому форму принимаем и напрямую.
    if not raw.endswith(".md"):
        bare = Path(str(candidate) + ".md")
        if bare.is_file():
            resolved = bare.resolve()
            if resolved == vault_resolved or vault_resolved in resolved.parents:
                return resolved

    from_index = note_path_for_id(raw)
    hit = _inside(from_index)
    if hit is not None:
        return hit

    from_source = note_path_for_source(raw)
    hit = _inside(from_source)
    if hit is not None:
        return hit

    found = _walk_for_name(raw, vault)
    return found.resolve() if found is not None else None


def _default_vault() -> Path:
    """Vault по конфигу (ленивый импорт: ``core.vault`` — нижний слой)."""
    from core.config import default_vault_path

    return default_vault_path()
