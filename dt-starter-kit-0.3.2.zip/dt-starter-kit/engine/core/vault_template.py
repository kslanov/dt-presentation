"""PERSONAL-1 п.2 - генератор каркаса vault: один код, два пресета ``work | personal``.

``build_vault(vault, preset)`` создаёт папки и стартовые файлы, которых движку нужно для работы, и
ничего не затирает (повтор - идемпотентен: существующее пропускается). Пресет ``work`` - только
каркас функции: дерево ``engine/vault-template/`` (DEV-3-CORE: README папок, политики поиска,
шаблоны гайдов стиля, пустые ingest-roots/host-access, образец mail-filter, шаблоны профиля),
которое ГЕНЕРИРУЕТ ``scripts/build_vault_template.py`` из боевого vault (руками не правится). Пресет
``personal`` (``dt instance add`` / ``dt vault init --kind personal``) добавляет личные папки и
правило границы:

::

    <vault>/
      README.md                       правило границы личного (что сюда попадает и что нет)
      _system/
        ingest-roots.yaml             пустой список корней (личный ingest файлов не настроен)
        profile/owner.yaml            копия профиля рабочего vault (личность владельца)
        profile/about.md, rules.md    пустые шаблоны (как у ``dt owner init``)
        style-guides/ai-markers.yaml  копия канона ИИ-маркеров рабочего vault
      _staging/inbox/                 сюда ложатся захваты (#контент, #личное) до разбора
      02-notes/  05-journal/  06-content/  07-outputs/

Писатель - движок (атомарная запись, как у профиля владельца): в vault шеллом не пишем. Никакого
аудита в журнал действий РАБОЧЕГО экземпляра: вызов идёт из процесса оператора
(``dt instance add``), а рабочий ``.derived`` о существовании личного контура знать не должен.
"""

from __future__ import annotations

from pathlib import Path

from core.config import ENGINE_ROOT
from core.mcp_json_edit import write_text_atomic
from core.owner.init import ABOUT_TEMPLATE, RULES_TEMPLATE
from core.owner.store import ABOUT_FILE, OWNER_FILE, PROFILE_DIRNAME, RULES_FILE

__all__ = [
    "PRESETS",
    "PERSONAL_DIRS",
    "README_PERSONAL",
    "TEMPLATE_DIR",
    "WORK_DIRS",
    "build_vault",
    "template_files",
]

PRESETS = ("work", "personal")
#: рабочий пресет: пустые папки сверх дерева шаблона (в шаблоне - только файлы)
WORK_DIRS = ("_system", "_staging/inbox", "07-outputs")
#: дерево шаблона рабочего vault (генерируется ``scripts/build_vault_template.py``)
TEMPLATE_DIR = ENGINE_ROOT / "vault-template"
TEMPLATE_MANIFEST = "_generated.json"
PERSONAL_DIRS = ("_system", "_system/profile", "_system/style-guides", "_staging/inbox",
                 "02-notes", "05-journal", "06-content", "07-outputs")

README_PERSONAL = """\
# Личный vault

Этот vault - личный контур Digital Twin: отдельный экземпляр движка (свой демон, свой индекс, свои
токены). Он отделён от рабочего vault конструкцией, а не договорённостью.

## Что здесь

- `05-journal/` - заметки дня (`ГГГГ-ММ-ДД.md`): запись с тегом `#дневник` дописывается секцией
  `## ЧЧ:ММ`;
- `06-content/` - прочитанное и услышанное (`#контент`): ссылка, источник, мысль;
- `02-notes/` - идеи и заметки, размещённые из инбокса;
- `_staging/inbox/` - захваты до разбора (`#контент`, `#личное`);
- `07-outputs/` - результаты работы ассистента для личных задач.

## Правило границы

1. Личное в рабочий vault не попадает: рабочий контур теги `#личное`, `#дневник`, `#контент`
   отбрасывает ДО записи, а о существовании этого vault не знает.
2. Связи с работой майнит ЭТА сторона: `bridge_scan` ищет в рабочем знании (по токену ЧТЕНИЯ) то,
   что перекликается с личной заметкой, и предлагает связь карточкой. Принятая связь записывается
   сюда, в `work_refs` заметки; в рабочем vault не появляется ничего, даже обратной ссылки.
3. Взгляд из работы - только по явной просьбе и только через личную запись хоста
   (`personal_recall`); в рабочих записях хоста этого инструмента нет.
4. Секретов здесь нет: токены лежат в каталоге секретов экземпляра, не в vault.
"""

_EMPTY_ROOTS = """\
# Корни ingest файлов личного vault (PERSONAL-1). Пусто: файловый ingest личного не настроен.
# Формат тот же, что у рабочего vault (core.file_ingest.config); корни добавляет владелец.
roots: []
"""


def _write_new(target: Path, text: str, created: list[str], vault: Path) -> None:
    """Файл создаётся, только если его нет; созданное попадает в отчёт (путь от vault)."""
    if target.exists():
        return
    write_text_atomic(target, text)
    created.append(target.relative_to(vault).as_posix())


def _copy_new(src: Path | None, target: Path, created: list[str], vault: Path) -> bool:
    """Копия файла рабочего vault (если он есть и целевого еще нет)."""
    if src is None or not src.is_file() or target.exists():
        return False
    write_text_atomic(target, src.read_text(encoding="utf-8"))
    created.append(target.relative_to(vault).as_posix())
    return True


def template_files(template: Path | None = None) -> list[str]:
    """Файлы шаблона рабочего vault (пути от его корня, без манифеста), по порядку."""
    root = Path(template) if template is not None else TEMPLATE_DIR
    if not root.is_dir():
        return []
    return sorted(p.relative_to(root).as_posix() for p in root.rglob("*")
                  if p.is_file() and p.name != TEMPLATE_MANIFEST)


def _lay_template(vault: Path, created: list[str], template: Path | None = None) -> None:
    """Разложить шаблон рабочего vault: недостающие файлы создаются, существующие не трогаются."""
    root = Path(template) if template is not None else TEMPLATE_DIR
    for rel in template_files(root):
        target = vault / rel
        if target.exists():
            continue
        parent = target.parent
        missing = []
        while parent != vault and not parent.is_dir():
            missing.append(parent.relative_to(vault).as_posix() + "/")
            parent = parent.parent
        target.parent.mkdir(parents=True, exist_ok=True)
        created.extend(reversed(missing))
        write_text_atomic(target, (root / rel).read_text(encoding="utf-8"))
        created.append(rel)


def build_vault(
    vault: Path, preset: str = "personal", *, work_vault: Path | None = None,
    journal_dir: str | None = None, ideas_dir: str | None = None, inbox: str | None = None,
    minimal: bool | None = None,
) -> list[str]:
    """Создать каркас ``preset`` в ``vault``; вернуть созданное (пути от vault, папки с ``/``).

    ``work_vault`` - рабочий vault, откуда копируются ``owner.yaml`` и ``ai-markers.yaml`` (только
    чтение; без него файлы личности и стиля не создаются - владелец заполнит сам). Существующие
    файлы и папки не трогаются: повторный вызов ничего не меняет.

    PERSONAL-2: личный vault, который уже ЕСТЬ (непустой каталог) или экземпляр с ручками папок
    (``journal_dir``/``ideas_dir``/``inbox``), получает минимум - ``_system/`` (ingest-roots,
    профиль, стиль), инбокс и заданные папки дневника/идей; ``README.md``, ``02-notes``,
    ``05-journal``, ``06-content``, ``07-outputs`` не создаются (``07-outputs`` - лениво при первом
    ``save_output``). ``minimal`` задает режим явно. Пустой vault без ручек - прежний полный каркас
    PERSONAL-1."""
    if preset not in PRESETS:
        raise ValueError(f"пресет {preset!r}: допустимы {', '.join(PRESETS)}")
    vault = Path(vault)
    created: list[str] = []
    is_minimal = minimal
    if is_minimal is None:
        is_minimal = (vault.is_dir() and any(vault.iterdir())) or bool(
            journal_dir or ideas_dir or inbox)
    dirs: tuple[str, ...] = WORK_DIRS if preset == "work" else PERSONAL_DIRS
    if preset == "personal" and is_minimal:
        dirs = ("_system", "_system/profile", "_system/style-guides", inbox or "_staging/inbox",
                *(d for d in (journal_dir, ideas_dir) if d))
    for rel in dirs:
        path = vault / rel
        if not path.is_dir():
            path.mkdir(parents=True, exist_ok=True)
            created.append(rel + "/")
    if preset == "work":
        _lay_template(vault, created)
        return created

    if not is_minimal:
        _write_new(vault / "README.md", README_PERSONAL, created, vault)
    _write_new(vault / "_system" / "ingest-roots.yaml", _EMPTY_ROOTS, created, vault)
    profile = vault / "_system" / PROFILE_DIRNAME
    src_profile = (work_vault / "_system" / PROFILE_DIRNAME) if work_vault else None
    _copy_new(src_profile / OWNER_FILE if src_profile else None, profile / OWNER_FILE,
              created, vault)
    _write_new(profile / ABOUT_FILE, ABOUT_TEMPLATE, created, vault)
    _write_new(profile / RULES_FILE, RULES_TEMPLATE, created, vault)
    src_markers = (work_vault / "_system" / "style-guides" / "ai-markers.yaml") if work_vault \
        else None
    _copy_new(src_markers, vault / "_system" / "style-guides" / "ai-markers.yaml", created, vault)
    return created
