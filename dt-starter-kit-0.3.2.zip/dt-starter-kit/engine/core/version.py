"""DEV-3-CORE п.4 (принцип 17): версия движка и версии схем - одно место для ``dt version``,
``/health`` и доктора.

Версия релиза - ``version`` из ``pyproject.toml`` (источник правды; тег волны и ``git describe`` -
рядом, не вместо). Схемы берутся из существующих реестров, своих чисел здесь нет: ``dt.db`` -
``core.db.DB_SCHEMA_VERSION`` (миграции), факты/задания - их константы, чанкер -
``core.chunking.chunker_version()``, индекс - метка ``index_meta.json`` (какой моделью и каким
чанкером построен). Чтение без побочных эффектов: ни индекса, ни сети, ни записи."""

from __future__ import annotations

import subprocess
import tomllib
from pathlib import Path
from typing import Any

from core.config import ENGINE_ROOT

__all__ = ["engine_version", "git_describe", "schema_versions", "version_info"]


def engine_version(root: Path | None = None) -> str:
    """Версия релиза движка (``pyproject.toml``); нет файла/поля - ``unknown``."""
    path = (Path(root) if root is not None else ENGINE_ROOT) / "pyproject.toml"
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "unknown"
    return str(data.get("project", {}).get("version") or "unknown")


def git_describe(root: Path | None = None) -> str | None:
    """``git describe --tags --always --dirty`` репо движка; нет git/репо - ``None``."""
    cwd = Path(root) if root is not None else ENGINE_ROOT
    try:
        out = subprocess.run(
            ["git", "describe", "--tags", "--always", "--dirty"],  # noqa: S607
            cwd=str(cwd), capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    text = out.stdout.strip()
    return text if out.returncode == 0 and text else None


def schema_versions() -> dict[str, Any]:
    """Версии схем из существующих реестров (читаются, не вычисляются заново)."""
    from core.chunking import chunker_version
    from core.db import DB_SCHEMA_VERSION
    from core.facts.schema import SCHEMA_VERSION as FACTS_SCHEMA
    from core.orchestration.jobs import SCHEMA_VERSION as JOBS_SCHEMA
    from core.retrieval.index import read_index_meta

    meta = read_index_meta()
    return {
        "dt.db": DB_SCHEMA_VERSION,
        "facts": FACTS_SCHEMA,
        "jobs": JOBS_SCHEMA,
        "chunker": chunker_version(),
        "index": {
            "embed_model": meta.get("embed_model") or None,
            "chunker": meta.get("chunker_version") or None,
        },
    }


def version_info() -> dict[str, Any]:
    """Всё, что печатает ``dt version``: релиз, ``git describe``, версии схем."""
    return {"version": engine_version(), "git": git_describe(), "schemas": schema_versions()}
