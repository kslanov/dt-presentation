"""WEBPULT-ACCESS-1 п.2/п.5 — токены веб-пульта: ``read`` и ``write`` (rw), ротация, доктор.

Два токена вместо одного (дизайн MODEL-1, принцип 4 / G8): утечка cookie с телефона раньше
открывала ВСЕ инструменты с записью.

* ``read`` — страница + инструменты чтения (``.secrets/web_token``, env ``DT_WEB_TOKEN``): файл и
  закладки как были — обратная совместимость;
* ``write`` — всё то же + ``WRITE_TOOLS ∩ профиль pult`` (``.secrets/web_token_rw``, env
  ``DT_WEB_TOKEN_RW``; генерится при отсутствии).

Токены читаются с диска на КАЖДЫЙ запрос (:class:`WebTokens`): ротация (``dt web-token rotate``)
действует сразу, старая cookie/ссылка перестает работать без перезапуска сервиса. Токен из env
перекрывает файл (и ротацию файлом: ``rotate`` отказывает, если токен задан через env).

Чистые функции от каталога секретов; ``core`` не зависит от MCP и CLI.
"""

from __future__ import annotations

import os
import secrets
import stat
import time
from dataclasses import dataclass
from pathlib import Path

from core.instance import secrets_path

__all__ = [
    "EMBED_FILE",
    "ENV_EMBED",
    "ENV_READ",
    "ENV_RW",
    "READ_FILE",
    "RW_FILE",
    "RW_COOKIE_DAYS",
    "RW_WARN_DAYS",
    "FixedTokens",
    "WebTokens",
    "inspect_tokens",
    "rotate",
    "store_token",
    "tail",
]

READ_FILE = "web_token"
RW_FILE = "web_token_rw"
ENV_READ = "DT_WEB_TOKEN"
ENV_RW = "DT_WEB_TOKEN_RW"
# PERSONAL-1: узкий токен «только посчитать вектора» (``POST /internal/embed``) для соседнего
# экземпляра без модели. Не read и не rw: ни ``/mcp``, ни ``/api``, ни запись его не принимают.
# Файла нет - рабочий демон ведет себя ровно как раньше; выпускает его только ``dt instance add``.
EMBED_FILE = "embed_token"
ENV_EMBED = "DT_EMBED_TOKEN"
RW_COOKIE_DAYS = 7  # cookie записи живет неделю (читающая - год, как раньше)
RW_WARN_DAYS = 90  # rw-токен старше - доктор подсказывает перевыпустить
AUTH_READ, AUTH_WRITE = "read", "write"


def secrets_dir() -> Path:
    """Каталог секретов: ``DT_SECRETS_DIR`` (PERSONAL-1, у каждого экземпляра свой) либо прежний
    ``<workspace>/.secrets``."""
    return secrets_path()


def tail(token: str | None) -> str:
    """Последние 4 символа токена - для аудита (весь токен в журнал не попадает)."""
    return (token or "")[-4:]


def _clean(value: str | None) -> str | None:
    value = (value or "").strip()
    return value or None


def _write_secret(path: Path, token: str) -> None:
    """Атомарно, с правами 0600 с самого создания (без окна, когда файл читаем всем)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    tmp = path.with_name(path.name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        fh.write(token)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


class FixedTokens:
    """Токены, заданные значениями (тесты, обратная совместимость ``make_handler(tools, "x")``)."""

    def __init__(self, read: str | None, rw: str | None = None):
        self._read, self._rw = _clean(read), _clean(rw)

    def read(self) -> str | None:
        return self._read

    def rw(self) -> str | None:
        return self._rw

    def classify(self, presented: list[str]) -> str | None:
        return _classify(presented, self.read(), self.rw())


def _classify(presented: list[str], read: str | None, rw: str | None) -> str | None:
    """``write`` / ``read`` / ``None``: высшее право среди предъявленных (constant-time)."""
    best = None
    for value in presented:
        if not value:
            continue
        if rw and secrets.compare_digest(value, rw):
            return AUTH_WRITE
        if read and secrets.compare_digest(value, read):
            best = AUTH_READ
    return best


class WebTokens(FixedTokens):
    """Токены с диска/окружения, перечитываются на каждый вызов (ротация без рестарта)."""

    def __init__(self, directory: Path | None = None, env: dict[str, str] | None = None):
        self.dir = Path(directory) if directory is not None else secrets_dir()
        self._env = env  # None → os.environ в момент вызова

    def _environ(self) -> dict[str, str]:
        return os.environ if self._env is None else self._env  # type: ignore[return-value]

    def _get(self, env_name: str, file_name: str) -> str | None:
        env = _clean(self._environ().get(env_name))
        if env:
            return env
        try:
            return _clean((self.dir / file_name).read_text(encoding="utf-8"))
        except OSError:
            return None

    def read(self) -> str | None:
        return self._get(ENV_READ, READ_FILE)

    def rw(self) -> str | None:
        return self._get(ENV_RW, RW_FILE)

    def embed(self) -> str | None:
        """Токен соседа-эмбеддера (PERSONAL-1) или ``None`` - демон эту дверь не открывал."""
        return self._get(ENV_EMBED, EMBED_FILE)

    def classify_embed(self, presented: list[str]) -> bool:
        """Предъявлен ли токен соседа-эмбеддера (constant-time); только для ``/internal/embed``."""
        token = self.embed()
        if not token:
            return False
        return any(v and secrets.compare_digest(v, token) for v in presented)

    def ensure(self) -> list[str]:
        """Создать недостающие файловые токены (env не трогаем). Возвращает, что создано."""
        created = []
        for env_name, file_name, label in ((ENV_READ, READ_FILE, "read"), (ENV_RW, RW_FILE, "rw")):
            if _clean(self._environ().get(env_name)) or (self.dir / file_name).is_file():
                continue
            try:
                _write_secret(self.dir / file_name, secrets.token_urlsafe(24))
                created.append(label)
            except OSError:
                pass
        return created


def rotate(
    which: str, directory: Path | None = None, env: dict[str, str] | None = None
) -> str:
    """Выпустить новый токен ``read`` | ``rw`` в файл; старый перестает работать сразу.

    Токен, заданный через env (``DT_WEB_TOKEN``/``DT_WEB_TOKEN_RW``), файлом не перекрыть —
    ротация отказывает ``ValueError`` (меняется значение переменной).
    """
    if which not in ("read", "rw"):
        raise ValueError(f"ротируется read | rw, не {which!r}")
    env_name, file_name = (ENV_READ, READ_FILE) if which == "read" else (ENV_RW, RW_FILE)
    environ = os.environ if env is None else env
    if _clean(environ.get(env_name)):
        raise ValueError(
            f"токен {which} задан через {env_name} (env/.env) - смени значение там; "
            "файловая ротация его не перекроет"
        )
    directory = Path(directory) if directory is not None else secrets_dir()
    new = secrets.token_urlsafe(24)
    _write_secret(directory / file_name, new)
    return new


def store_token(which: str, token: str, directory: Path | None = None) -> Path:
    """Положить ВЫДАННЫЙ ЕЩЕ ГДЕ-ТО токен (``read`` | ``rw``) в файл (клиент без vault: ключ получен
    на сервере ``dt web-token show``). Права 600 с создания; пустой токен - ``ValueError``;
    возвращает путь файла. Значение нигде не печатается."""
    if which not in ("read", "rw"):
        raise ValueError(f"токен read | rw, не {which!r}")
    value = _clean(token)
    if not value:
        raise ValueError("пустой токен")
    path = (Path(directory) if directory is not None else secrets_dir()) / (
        READ_FILE if which == "read" else RW_FILE)
    _write_secret(path, value)
    return path


@dataclass(frozen=True)
class TokenStatus:
    name: str  # read | rw
    configured: bool
    source: str  # env | file | -
    mode: str = ""  # права файла, '600'
    mode_ok: bool = True
    age_days: float | None = None


def inspect_tokens(
    directory: Path | None = None, env: dict[str, str] | None = None, now: float | None = None
) -> dict[str, TokenStatus]:
    """Сводка для доктора: заданы ли токены, откуда, права файла (0600), возраст. Только чтение."""
    d = Path(directory) if directory is not None else secrets_dir()
    environ = os.environ if env is None else env
    now = time.time() if now is None else now
    out: dict[str, TokenStatus] = {}
    for label, env_name, file_name in (("read", ENV_READ, READ_FILE), ("rw", ENV_RW, RW_FILE)):
        if _clean(environ.get(env_name)):
            out[label] = TokenStatus(label, True, "env")
            continue
        path = d / file_name
        try:
            st = path.stat()
            value = _clean(path.read_text(encoding="utf-8"))
        except OSError:
            out[label] = TokenStatus(label, False, "-")
            continue
        perm = stat.S_IMODE(st.st_mode)
        out[label] = TokenStatus(
            label, bool(value), "file", mode=f"{perm:o}", mode_ok=(perm & 0o077) == 0,
            age_days=round((now - st.st_mtime) / 86400.0, 1),
        )
    return out
