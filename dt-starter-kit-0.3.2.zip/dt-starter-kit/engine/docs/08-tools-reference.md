# Справочник MCP-инструментов

<!-- Генерируется: uv run python scripts/tools_reference.py. Руками не править: гард tests/test_tools_reference.py сверяет файл с реестром сервера. -->

Всего **82** инструмента(ов): `lean` 12, `pult` 62, `full` 82; пишущих (`WRITE_TOOLS`) 26. Профиль выбирает `--profile` / `DT_TOOL_PROFILE` (`mcp-server/README.md`); `full` - все.

Тип: **W** - в `WRITE_TOOLS` (пишет, аудит в `pult-actions.log`), **R** - остальные (читают; `submit_job`/`job_cancel` управляют заданиями, данных vault не пишут). Колонки профилей: + входит, пусто - нет.

| Инструмент | Тип | lean | pult | full | Описание |
|---|---|---|---|---|---|
| `reindex` | R |  |  | + | (Re)build the LanceDB index from the vault. |
| `submit_job` | R |  | + | + | Запустить долгую операцию АСИНХРОННО и вернуть `job_id` мгновенно (JOB-1). |
| `job_status` | R |  | + | + | Состояние/прогресс/результат асинхронного задания по `job_id` (JOB-1). |
| `job_list` | R |  | + | + | Список недавних async-заданий (JOB-1) для панели «Задания» пульта. |
| `job_cancel` | R |  | + | + | Запросить мягкую отмену async-задания (JOB-1). Действие. |
| `parse_task` | R | + | + | + | Interpret a natural-language task into a use case + entity params. |
| `plan_task` | R |  | + | + | Материализовать план кейса и прозондировать, что уже готово (PLAN-1). |
| `retrieve` | R | + | + | + | Run a use case's retrieval policy and return the slices (no generation). |
| `generate` | R | + | + | + | Assemble the generation prompt + write provenance; return the prompt. |
| `resolve` | R |  |  | + | Одним вызовом: разложить задачу, поднять источники, свести факты/образец/ |
| `doctor` | R |  | + | + | Диагностика окружения DT (UX-1) — секреты (наличие), пути, индекс, зеркало, |
| `find_notes` | R | + | + | + | Искать в vault: заметки, письма, документы, переписку — по теме, человеку, домену. |
| `find_latest` | R | + |  | + | Последняя версия документа по СЕМЕЙСТВАМ вокруг найденного файла. Read-only. |
| `read_note` | R | + |  | + | Открыть и прочитать заметку целиком по ссылке любой формы (путь, id, source_path). |
| `attribute_note` | W |  | + | + | Привязать заметку к клиент-хабу (RETR-LINK) — проставить frontmatter |
| `lift_source` | R |  |  | + | Прочитать файл-источник: PDF, xlsx, docx, pptx — извлечь текст, таблицы и цифры. |
| `get_facts` | R | + | + | + | Найти цифры и реквизиты: суммы, даты, БИН, ставки — из файлов-источников, с ярлыком. |
| `owner_profile` | R | + | + | + | Профиль владельца (read-only): `about` - кто он, `rules` - правила работы с ним. |
| `find_exemplar` | R |  | + | + | Найти реальный прошлый документ как ОБРАЗЕЦ ОФОРМЛЕНИЯ (форму) (TMPL-1). |
| `ingest_scan` | W |  |  | + | Превью файлового ingest: скан наблюдаемых папок + дельта (INGEST-1, read-only). |
| `output_begin` | W | + |  | + | Завести папку выхода С ПОСТАНОВКОЙ **до** работы (DOD-2) — каркас, не результат. |
| `save_output` | W | + | + | + | Вернуть результат в DT и (по желанию) собрать документ ЛОКАЛЬНО: сохранить |
| `store_file` | W |  |  | + | Доставить бинарь из чата в рабочую папку по мосту (base64 ≤25 МБ, sha-гард) — |
| `store_file_begin` | W |  |  | + | Порционно доставить крупный бинарь из чата (части по 16 КБ, resume) — когда одним |
| `store_file_append` | R |  |  | + | Передать очередную часть файла (base64) в сессию `session_id` (ФТ-5). |
| `store_file_status` | R |  |  | + | Состояние сессии порционной записи: сколько принято и с чего продолжать (ФТ-5). |
| `store_file_commit` | W |  |  | + | Завершить сессию: сверить sha256 собранного файла и положить его в цель (ФТ-5). |
| `store_file_abort` | W |  |  | + | Снять незавершённую сессию порционной записи: части и состояние удаляются (ФТ-5). |
| `place_download` | W | + |  | + | Положить готовый файл с диска в рабочую папку: доставить docx/xlsx/pdf клиенту, |
| `folder_alias_list` | R |  |  | + | Перечень алиасов рабочих папок (ФТ-2) — read-only подсказка для чата. |
| `folder_alias_set` | W |  |  | + | Добавить/изменить алиас рабочей папки (ФТ-2): `alias` → `root_name`+`rel_path`. |
| `list_inbox` | R |  | + | + | List unprocessed quick-capture items in `_staging/inbox/`. |
| `refine_inbox` | R |  |  | + | Build a placement-refinement request for every inbox item (Path B). |
| `apply_refinement` | W |  |  | + | Write a confirmed placement `proposal` into the vault, clearing the item. |
| `propose_links` | R |  |  | + | Generate AI-semantic link candidates into the review queue (Phase 6). |
| `apply_links` | W |  |  | + | Approve selected proposals and apply them into source notes (Phase 6). |
| `pult_kpi` | R |  | + | + | Агрегаты dt-kpi как данные для плиток/тренда пульта (не текст). |
| `pult_sync_status` | R |  | + | + | Здоровье оперативного контура — последний fast/full прогон + running. |
| `pult_log_tail` | R |  | + | + | Хвост dt-sync-лога для админ-вкладки пульта (только текст). |
| `pult_run_sync` | W |  | + | + | Кнопка «sync сейчас» — detached-запуск dt_sync, ответ сразу. |
| `pult_activity` | R |  | + | + | Что сейчас работает — прогресс-маяки долгих операций + load/swap (ACT-1). |
| `pult_freshness` | R |  | + | + | Актуальность данных по источникам (FRESH-1) — «данные на момент X». |
| `pult_monitor` | R |  | + | + | Мониторинг одной карточкой (PULT-SURFACE-2, MONITOR-CARD-1): всё, что смотрит вкладка |
| `pult_manifest` | R |  | + | + | Манифест роли экземпляра (PERSONAL-3): что есть у ЭТОГО экземпляра - пульт рисует только это. |
| `pult_services` | R |  | + | + | Статус всех сервисов движка (PULT-ENGINE) — сетка контура «Движок». |
| `pult_service_control` | W |  | + | + | Управление сервисом движка — start/stop/restart (PULT-ENGINE). Действие. |
| `pult_events` | R |  | + | + | Сквозной лог стадий пайплайна (PULT-EVENTLOG) — read-only лента/таймлайн. |
| `pult_ingest_sources` | R |  | + | + | Список источников ingest со статусом для панели «Хранилище» (PULT-STORAGE). |
| `pult_ingest_trace` | R |  | + | + | Файловая трасса инжеста «файл → заметка → индекс» (INGEST-VIS-1) — read-only. |
| `pult_storage_status` | R |  | + | + | Здоровье хранилища одним вызовом (PULT-STORAGE) — read-only, реюз diagnostics. |
| `pult_storage_action` | W |  | + | + | Действие над хранилищем — gated (PULT-STORAGE). Деструктив за подтверждением. |
| `pult_paths_get` | R |  | + | + | Текущие корни ingest + legacy для редактора путей (PULT-STORAGE, read-only). |
| `pult_paths_set` | W |  | + | + | Записать конфиг путей (PULT-STORAGE; PULT-TOKEN-UX — без токен-гейта). Конфиг. |
| `pult_settings_get` | R |  | + | + | Настройки пульта (PULT-STANDALONE-1), раздел `ai` - read-only. |
| `pult_settings_set` | W |  | + | + | Изменить настройки пульта (PULT-STANDALONE-1). Конфиг (`_system/pult.yaml`). |
| `pult_ai` | R |  | + | + | ИИ-синтез пульта по настройке `pult.yaml: ai` (PULT-STANDALONE-1, GATEWAY-1) - пять видов. |
| `pult_choose_folder` | R |  | + | + | Открыть нативный выбор папки в Finder и вернуть путь (PULT-FOLDER-PICKER). |
| `pult_cards` | R |  | + | + | Очередь решений ОДНИМ вызовом: карточки всех видов единой формы (QUEUE-SERVER-1). |
| `pult_card_decide` | W |  | + | + | Решение по карточке очереди: `card_id` (`<вид>:<id>`) + `action` из `card.actions`. |
| `pult_card_explain` | R |  | + | + | «Почему предложено» по карточке очереди: `{ok, card_id, kind, why}` (read-only). |
| `pult_eval` | R |  | + | + | Качество выдачи для плитки пульта (EVAL-3): сводка из истории прогонов золотого набора. |
| `pult_create_hub` | W |  | + | + | Завести хаб сущности из пульта одной кнопкой (Слой 1 — детерминированно). |
| `pult_hub_add_note` | W |  | + | + | Дописать строку-ссылку в заметку хаба (Слой 1: «Задача + в существующий |
| `hub_synth_context` | R | + | + | + | Досье «Состояние хаба клиента»: что нового с `since` (ГГГГ-ММ-ДД; иначе `synth_at` |
| `hub_synth_propose` | R |  | + | + | Поставить написанную сессией секцию «Состояние» карточкой на решение К. (HUB-SYNTH-1). |
| `pult_ripe_leads` | R |  | + | + | «Дозревшие лиды» — vault-хабы без пары в Timetta, готовые стать сделкой. |
| `pult_deals` | R |  | + | + | Сделки локального зеркала Timetta для пикера «связать с CRM» (HUB-DEAL-LINK). |
| `pult_function` | R |  | + | + | Виджет «Функция» (ORBIT-3): надзор над сделками ВСЕХ колец — read-only, без сети, без сумм. |
| `pult_watch` | W |  | + | + | «Следить» за сделкой кольца 2/3 (ORBIT-3): ручной watchlist, БЕЗ права записи. |
| `pult_hub_link_deal` | W |  | + | + | Связать vault-хаб `hub_id` с СУЩЕСТВУЮЩЕЙ сделкой `deal_guid` Timetta. |
| `pult_hub_unlink_deal` | W |  | + | + | Снять связь хаба `hub_id` со сделкой Timetta (обратная к link; только vault). |
| `pult_set_track` | W |  | + | + | Сменить трек vault-хаба `hub_id` → `track` ∈ `{presale, project, internal}` (TRACK-2). |
| `work_feed` | R |  | + | + | Фид рабочего кокпита (WORK-1/WORK-2) — данные для вкладки «Работа». |
| `work_resurface` | R |  | + | + | Resurfacing по связям (DEV-1d): «новое легло рядом с тем, что ты знал» — read-only. |
| `work_dismiss` | W |  | + | + | Снять/отложить пункт «Работы» (WORK-3) — серверное решение по фиду. |
| `work_context` | R |  | + | + | Инлайн-сводка по пункту «Работы» (WORK-4) — чтобы понять без ухода в чат. |
| `work_note_preview` | R |  | + | + | Превью заметки vault по slug (WORK-5) — «о чём заметка» для решения по ссылке. |
| `work_meetings` | R |  | + | + | Предстоящие встречи для вкладки «Работа» — **из кэша, мгновенно** (PERF-3). |
| `work_ticktick` | R |  | + | + | Висящие «свои» задачи TickTick (WORK-ATTN-TICKTICK) для «Требует внимания». |
| `work_meeting_prep` | R |  | + | + | Досье к встрече (DEV-1b) — фактический контекст ПЕРЕД разговором, без модели. |
| `pult_web_status` | R |  | + | + | Статус веб-пульта (PULT-WEB) для «Машинного отделения» — read-only. |
| `pult_web_restart` | W |  | + | + | Перезапустить веб-пульт через launchd (`launchctl kickstart -k`). Действие. |

## Инструменты личного экземпляра (2)

Регистрируются только при `DT_INSTANCE_ROLE=personal` (личный контур, `ops/README.md`) и добавляются к любому профилю; в `TOOL_NAMES`/`PROFILES` рабочего экземпляра их нет, хост подключает личный экземпляр отдельной записью `dt host-config <хост> --instance personal`.

- `personal_recall` (R) - Что я читал и думал по теме: личные заметки, их work_refs и оверлей рабочего контекста.
- `personal_today` (R) - Сегодня в личном vault: заметка дня (последние секции) и инбокс личного. Read-only.

## Снятые инструменты (22)

Имена не переиспользуются (гард `tests/test_no_timetta_write.py`).

| Имя | Чем заменено |
|---|---|
| `propose_timetta_change` | RETIRE-WRITE-1 (2026-10-20): запись в Timetta выведена, CRM ведет администратор |
| `pult_decide` | RETIRE-WRITE-1 (2026-10-20): запись в Timetta выведена, CRM ведет администратор |
| `pult_queue` | RETIRE-WRITE-1 (2026-10-20): запись в Timetta выведена, CRM ведет администратор |
| `pult_autonomy` | RETIRE-WRITE-1 (2026-10-20): запись в Timetta выведена, CRM ведет администратор |
| `work_checklist_done` | RETIRE-WRITE-1 (2026-10-20): запись в Timetta выведена, CRM ведет администратор |
| `list_operational_inbox` | RETIRE-WRITE-1 (2026-10-20): запись в Timetta выведена, CRM ведет администратор |
| `list_link_proposals` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_link_decide` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `list_reattr_proposals` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_reattr_decide` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_untriaged` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_route` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_assignments` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_assignment_decide` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_hub_candidates` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_hub_decide` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_hub_alias_candidates` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_hub_alias_decide` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_golden_candidates` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_golden_decide` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_ripe_snooze` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
| `pult_ripe_reject` | SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide |
