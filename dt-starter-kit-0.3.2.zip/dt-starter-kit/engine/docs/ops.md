# Эксплуатация: хосты на демоне (HOSTS-ATTACH-1)

Движок - сервис, хост - клиент (DAEMON-1): демон `com.dt.server` на 8787 (`ops/README.md`, «Демон
движка») отдает MCP по `/mcp/lean|pult|full`; хосты подключаются к нему, а не запускают свой
`server.py`. Здесь - как подключить каждый хост, как проверить и что делать, когда что-то разошлось.

| Хост | Форма записи | Профиль | Токен | Как ставится |
|---|---|---|---|---|
| Claude Desktop / Cowork | мост `cli/dt_shim.py` (команда) | full | rw (файл, не в конфиге) | `dt host-config claude --install` |
| Cursor | url | lean | rw | `dt host-config cursor --install` |
| Kimi Work / Code | url (в `mcp.json` агента) | lean | rw | `dt plugin kimi --out plugins/kimi-work --install` |
| Cherry Studio | url + `type: streamableHttp` | lean | rw | руками в UI: `dt host-config cherry` → Import from JSON |
| любой другой клиент | голая запись `{url, headers}` | lean | rw | `dt host-config url` |

`rw`-токен нужен всем: lean/full содержат `output_begin`/`save_output`/`place_download`, а запись через
`/mcp` разрешена только с write-токеном (иначе `{ok:false, code:"write_token_required"}`).

## Мост `cli/dt_shim.py` (Desktop и Cowork)

Desktop запускает только команду (локальный http-адрес для него недостижим), поэтому между ним и
демоном - тонкий процесс (httpx + stdlib, ~230 строк, ≈30 МБ): строки stdin (JSON-RPC) уходят POST-ом
в `/mcp/<профиль>` как есть, ответы (JSON/SSE) возвращаются в stdout. Протокол мост не разбирает:
`clientInfo` хоста проходит сквозь - `host` в провенансе и телеметрии остается именем Desktop/Cowork
(`claude-desktop` / `local-agent-mode-digital-twin`), а в `tool_call` появляется `sid`.

- запись в `claude_desktop_config.json`: `{command: <venv python>, args: [cli/dt_shim.py, --profile,
  full, --token-file, <абс. путь к .secrets/web_token_rw>]}` - БЕЗ `env` (движок `DT_USER_NAME` из
  конфига хоста не читает) и без токена: в `ps` виден только путь к файлу;
- перезапуск демона (`launchctl kickstart -k gui/$UID/com.dt.server`) рвет сессии MCP (старый
  `Mcp-Session-Id` -> 404): мост на 404 сам повторяет сохраненный `initialize` хоста и запрос (по
  умолчанию; `--no-reconnect` - для тестов) - следующий вызов проходит без перезапуска Desktop;
- демон не отвечает - хосту уходит ошибка JSON-RPC «демон не отвечает на 127.0.0.1:<порт>: `launchctl
  kickstart -k gui/<uid>/com.dt.server`», сам мост жив и подключится, когда демон вернется;
- мост запускается `.venv/bin/python` напрямую (не `uv run`), поэтому `httpx` - в базовых зависимостях.

## `dt host-config <хост>`

```sh
uv run python cli/dt.py host-config claude --verify       # что стоит в конфиге: daemon | stdio-legacy | missing | foreign
uv run python cli/dt.py host-config claude --install      # своя запись + бэкап рядом; затем Cmd+Q и запуск Desktop
uv run python cli/dt.py host-config cursor --install
uv run python cli/dt.py host-config cherry --token-placeholder   # запись для Import from JSON без токена
uv run python cli/dt.py host-config cursor --legacy-stdio --profile lean   # прежняя stdio-форма (тесты, fallback)
```

- **Токен в печати - настоящий** (секрет в вашем терминале): вывод в чат не вставлять
  (`--token-placeholder` печатает `<web_token_rw>`; `--token read` - read-токен). В вердиктах и логах токена
  нет - только хвост 4 символа.
- **`--install`** пишет ТОЛЬКО член `mcpServers.digital-twin` байт-точным редактором
  (`core/mcp_json_edit.py`: чужие серверы, ключи, пробелы, переносы, CRLF, конец файла - как были), с
  бэкапом `<файл>.bak-<время>` рядом; повтор - «без изменений» (ни бэкапа, ни записи); битый JSON - отказ
  без записи; нет хоста (нет файла и каталога) - отказ. Старая stdio-запись заменяется целиком. `--out`
  в конфиги хостов по-прежнему не пишет (только `--install`).
- **`--verify`** только читает: `daemon` (мост/url на наш порт, токен есть), `stdio-legacy` (старая
  команда `server.py` - дрейф: свой процесс движка на хост), `missing`, `foreign` (ключ есть, но не наш
  либо токен перевыпущен). Для Cherry - только по употреблению: сессии хоста по url в телеметрии за 30 дн.
- `--sandbox`/`--desc-chars` - только с `--legacy-stdio` (демон берет настройки из своего `.env`);
  `--user-name` снят.

Доктор («Хосты: подключение») показывает то же по всем конфигам + живые stdio-процессы `server.py`
(`ps`, счет и хост-владелец) + сессии за 24 ч по url/мосту и по stdio; `warn` - есть `stdio-legacy` или
живые stdio-процессы. **Процессы живут до перезапуска хоста-владельца**: после `--install` полностью
перезапустите Claude Desktop (Cmd+Q), иначе шесть старых процессов (`disclaimer` → `uv` → `python` на
каждого) останутся до его закрытия. Доктор по stdio-серверу Cowork после слияния кода «падает импортом»
(процесс старше кода) - тот же класс, лечится тем же перезапуском.

## Kimi: плагин = скиллы, MCP = `mcp.json` агента

В бандле Kimi (app.asar, 30.10) MCP-сервер плагина классифицируется `gateway-hosted` либо
`unsupported-local-mcp` и снимается проверкой «legacy local MCP safety scan». Поэтому манифест плагина
MCP не несет, а `dt plugin kimi --install` пишет url демона в `mcp.json` агента (только ключ
`digital-twin`; бэкап не нужен - файл правится точечно; `config.toml` рядом содержит api_key и не
читается). `--verify-install` и доктор «Плагин Kimi» сверяют: `registered` («MCP агента: url →
:8787/lean»), `mcp_stdio_legacy` (лечится `--install`), `mcp_differs` (другой url/токен перевыпущен),
`mcp_missing`, `mcp_invalid`.

## Cherry Studio (третий хост со своими ключами)

Open source, BYOK (OpenAI/Anthropic/Gemini и custom-совместимые провайдеры), MCP по Streamable HTTP,
Skills. Свой стор приложения (MCP-серверы - внутренняя база, скиллы - `Data/Skills`) генератор НЕ пишет:
регистрация - руками в UI. Порядок (`plugins/cherry/README.md`):

1. `dt host-config cherry` → Settings → MCP → «Import from JSON» (без `"type": "streamableHttp"` импорт
   сохранит stdio - не наша форма; у сервера должна быть именно url-запись).
2. `dt skills export cherry --out plugins/cherry/skills` (то же: `dt skills export --host cherry`):
   `skills/<имя>/SKILL.md` с frontmatter `name`/`description`/`version`, набор = lean, как у плагина Kimi;
   Settings → Skills → «Установить из каталога» - по одной папке на навык (`skills/<имя>`, где лежит
   `SKILL.md`; родительскую `skills/` Cherry отвергает - один навык = одна запись его стора).
3. `dt host-config cherry --verify` - есть ли сессии по url в телеметрии за 30 дн.
4. В `vault/_system/host-access.yaml` добавить запись (имя - из `clientInfo`, снять живьем при первом
   подключении и записать в `docs/findings/hosts-attach-1.md`):

   ```yaml
   cherry-studio:
     folders: []
     granted: 2026-10-30
     note: "Cherry Studio, свои ключи; clientInfo снят живьем"
     aliases: ["<имя из clientInfo>"]
   ```

   Хост с реальным именем не считается ни анонимом (`mcp` - имя SDK по умолчанию), ни «без записи».

Ограничения хоста (не чиним): свой стор MCP и скиллов, регистрация руками; живой g1 из Cherry - после
заведения API-ключа.

## Пульт без Desktop и слой ИИ-синтезов (PULT-STANDALONE-1)

Пульт отдает тот же демон (`com.dt.server`, порт `DT_WEB_PORT`, по умолчанию 8787), поэтому для работы
нужен только браузер: Claude Desktop и Cowork не нужны. Телефон - по публичному адресу Tailscale funnel.

```bash
uv run python cli/dt.py pult open            # браузер по умолчанию на http://127.0.0.1:8787/?t=<read>
uv run python cli/dt.py pult open --rw       # то же с токеном записи (решения, настройки; cookie 7 дней)
uv run python cli/dt.py pult open --public   # публичный адрес funnel (с телефона)
uv run python cli/dt.py pult url [--rw] [--public]   # печать ссылки С токеном (только url печатает токен)
uv run python cli/dt.py pult status          # pult_web_status текстом: демон, launchd, funnel, токены (хвосты)
```

Демон не отвечает: `open` пишет `launchctl kickstart -k gui/<uid>/com.dt.server` и выходит с кодом 1.

**База и синтез.** Пульт всегда рисует детерминированную базу движка, без модели: утренний бриф
(`work_feed.brief`: счетчики, главное внимание, дельты, коллеги) и подсказку лейна захвата
(`pult_untriaged.suggested_lane` + причина из 5-8 слов; правила - `core/operational/capture_lane.py`).
ИИ-синтез - необязательный слой поверх: переформулировать бриф, уточнить лейн, написать черновик по
промпту `generate`. Кто пишет текст, решает **шлюз моделей** (GATEWAY-1): у каждого **класса задач** свой
**маршрут** на **профиль** модели - раздел `ai` файла `vault/_system/pult.yaml` (нет файла = все маршруты
`none`). Классы: `triage` (бриф, лейн захвата), `synth` (состояние хаба, проверка хаба), `draft` (черновик).

| маршрут класса | кто пишет текст | данные уходят наружу |
|---|---|---|
| `none` (дефолт) | никто: база движка; черновик - кнопка «Собрать промпт» (промпт в буфер) | нет |
| `host` | модель хоста (`askClaude` в Cowork); вне Cowork и в веб-пульте - база | нет (через хост) |
| имя профиля с `provider: openai` | демон, OpenAI-совместимый chat completions (Moonshot/Kimi, OpenRouter; LM Studio/Ollama по `http://localhost`) | да, если url не локальный |
| имя профиля с `provider: anthropic` | демон, Messages API | да, провайдеру |

Профиль: `provider`, `url`, `model`, `key_file`, `timeout_s` = 20, `max_chars` = 2000, `max_calls_per_hour`
(дефолт - `DT_AI_MAX_CALLS_PER_HOUR` = 120). Пример `pult.yaml` («дешево / сильно / локально»):

```yaml
ai:
  profiles:
    cheap:  {provider: openai,    url: https://api.moonshot.ai/v1, model: kimi-k2}  # имя из кабинета
    strong: {provider: anthropic, model: claude-opus-5-5}                            # url по умолчанию api.anthropic.com
    local:  {provider: openai,    url: http://localhost:11434/v1, model: <имя загруженной модели>}
  routes: {triage: cheap, synth: strong, draft: host}
```

Плоский `ai: {provider, url, model}` (до GATEWAY-1) читается как профиль `default` + все маршруты на него; файл
остается как есть до `dt ai migrate` (бэкап `pult.yaml.bak-<время>` рядом) или первой записи настроек.

Команды (`dt ai`, то же, что раздел «ИИ-синтезы» во вкладке «Настройки» пульта, кроме ключа):

```bash
uv run python cli/dt.py ai show                       # профили (без ключей), маршруты, классы, последний вызов
uv run python cli/dt.py ai set profile cheap provider=openai model=kimi-k2 url=https://api.moonshot.ai/v1
uv run python cli/dt.py ai set route triage cheap     # класс -> профиль | host | none
uv run python cli/dt.py ai rm profile cheap           # нельзя, пока на него есть маршрут (profile_in_use)
uv run python cli/dt.py ai set-key --profile cheap    # ключ из stdin или скрытого ввода -> .secrets/pult_ai_key-cheap (600)
uv run python cli/dt.py ai test --class triage        # один вызов по маршруту класса мимо кэша: мс + 80 знаков
uv run python cli/dt.py ai migrate                    # плоский ai: -> профили и маршруты (бэкап рядом)
```

Прежние `dt ai set --provider ... --model ... --url ...` и `set-key` без `--profile` работают на профиль `default`.

Ключ профиля - ТОЛЬКО файл `.secrets/pult_ai_key-<имя>` (`default` - `pult_ai_key`, права 600): его нет в
`pult.yaml`, в ответах инструментов, в браузере и артефакте, в аудите и логах (видны последние 4 символа).
Инструмент `pult_settings_set` ключ и `key_file` не принимает (`key_not_here`), `http://` разрешен только для
localhost и локальной сети. Вызов к профилю делает демон, поэтому текст одинаков на обеих поверхностях: кэш на
день по `(kind, sha(payload), профиль, provider, model)` в `.derived/pult/ai_cache.json`. Отказ или таймаут -
`{ok:false, code}`: пульт остается на базе и один раз пишет «ИИ: <профиль> (<provider>) недоступен». Потолок
реальных вызовов - 120 в час на профиль (`DT_AI_MAX_CALLS_PER_HOUR`; свой - `max_calls_per_hour`). `max_chars` -
потолок ответа `brief`/`lane` (для `draft` в 10 раз больше); таймаут 20 с для длинных черновиков, возможно,
придется поднять (`dt ai set profile <имя> timeout_s=60`). Аудит `ai_synthesis` (provider, model, kind, class,
profile, route, ms, chars, ok, code) - без текста и ключа; доктор: «ИИ-шлюз» (маршрут и состояние профиля по
классам) и «Пульт: поверхности».

## Тесты и демон в процессе (SANDBOX-DAEMON)

Тесты поднимают демон в потоке (`tests/_asgi_server.serve_asgi`). `shutdown()` ждет живые потоки
инструментов (`core.daemon.wait_idle`, ≤ 10 с) и падает с именем теста, если они остались: откат env
песочницы (`DT_DERIVED_ROOT`) до конца потока писал бы в боевой журнал (DAEMON-1: `host=idle-test`).

## Один конфиг (CONFIG-1)

Где что живет (правило, `docs/02-architecture.md` §9 п.27):

| Что | Где | Кто пишет |
|---|---|---|
| секреты и настройки ЭТОЙ машины: пути, устройство эмбеддера, порт, режим, токены | `engine/.env` (600, вне git) | `dt config set` (единственный писатель - `core/config/env_file.py`); токены - Keychain (`dt_secrets`) или файлы `.secrets/` |
| настройки vault: доступ хостов, корни инжеста, политики, пульт, фильтр почты | `vault/_system/*.yaml` | редактор/пульт; едут вместе с vault |
| конфиги хостов (Desktop, Cursor, Kimi, Cherry) | у хоста | производные: `dt host-config`, `dt plugin kimi` |
| плисты launchd | `ops/launchd/*.plist` | только `PATH`, ни одного `DT_*` (гард-тест) |

Реестр настроек - `core/config/knobs.py`: каждое имя `DT_*`, которое читает код, с типом, дефолтом,
областью (`engine | vault | host | test | deprecated`), модулем и описанием; секреты (`type: secret`) никогда
не печатаются, только хвост 4 символа. Новая настройка в коде без записи в реестре = красный тест
(`tests/test_config_knobs.py`); после правки реестра - `uv run python scripts/gen_env_template.py`
(шаблон `ops/env.template` - артефакт сборки).

```bash
uv run python cli/dt.py config show              # действующие значения: источник .env | env | дефолт
uv run python cli/dt.py config check             # неизвестные ключи (с подсказкой), устаревшие, пустые обязательные, права, режим
uv run python cli/dt.py config set DT_RERANK_POOL 20   # один ключ: бэкап .env.bak-<ts>, права 600
uv run python cli/dt.py config init              # .env из ops/env.template (вторая машина)
```

`--env-file PATH` работает на копии `.env` (пробы без риска для боевого). Секрет через `set` - только
`--stdin` (`printf %s "$KEY" | dt config set TIMETTA_API_TOKEN --stdin`): значение в argv остается в
истории shell. Демон читает `.env` при старте: после `set` - `launchctl kickstart -k gui/$UID/com.dt.server`.
`dt config check` ловит опечатку в имени ключа (`DT_RERANKK` -> «возможно DT_RERANK»), битый JSON в
значении (код читает его как пустой список - тихо), пустые обязательные ключи, права `.env`/`.secrets`,
`.env` под git. Доктор «Конфиг» - тот же результат одной строкой + режим.

## Сервер: движок на отдельной машине (CONFIG-1, дизайн DAEMON п.10)

Схема «сервер + клиенты»: демон, launchd-цепочки, эмбеддер/реранкер, `.derived` и индекс живут на
всегда включенной машине (Mac Studio/mini), ноутбук - клиент. Живой переезд - когда будет железо; порядок:

**На сервере**
1. `git clone` engine, `uv sync --all-extras`.
2. `uv run python cli/dt.py config init` - `.env` из шаблона; заполнить обязательные ключи
   (`DT_TIMETTA_USER_ID`, `DT_TIMETTA_USER_EMAIL`, `DT_OUTLOOK_SELF_TOKENS` - иначе своя почта попадает в
   privacy) командой `dt config set`; `dt config check` - чисто.
3. Модели: разово `DT_MODEL_DOWNLOAD=1` (и `DT_EMBED_ALLOW_DOWNLOAD=1`) для скачивания BGE-M3 и реранкера,
   затем полная индексация (`dt_index.py --full`). `.derived`, индекс и модели не синхронизируются.
4. vault - git-клон на сервере: писатель по умолчанию - сервер (цепочки sync/ingest/linking/outputs пишут
   туда). На ноутбуке - второй клон для Obsidian (pull перед работой, push после правок; конфликт явный).
   НЕ iCloud: два писателя дают молчаливые «конфликтные копии», `.git` в iCloud бьется, dataless-заглушки
   ломают прямое чтение и детектор изменений.
5. `source_path` в заметках абсолютные: имя пользователя на сервере то же, иначе
   `dt_ingest.py --repoint-sources` (SRC-PATH-1). Папка CDT_Internal - в iCloud (общая с бизнесом), на
   сервере «Хранить загруженной».
6. `.secrets/` на сервере: токены создает демон при старте; ключ для клиента - `dt web-token show rw`.
7. `dt config set DT_MODE server`; Tailscale установлен и вошли (адрес: `tailscale status --json`,
   `Self.DNSName`/`Self.TailscaleIPs`; нет адреса - демон честно стартует в `local`, `dt config check`
   называет причину). Funnel для `/mcp` не включать никогда: прокси-заголовки режут `/mcp` (403) в любом
   режиме; funnel допустим только для пульта.
8. `bash ops/install_launchd.sh` (демон слушает `0.0.0.0:8787`, как и раньше); `dt doctor` - строка «Демон
   DT»: `режим server · <dns> · клиентов по Tailscale за 24 ч N`.

**На ноутбуке (клиент без vault)**
9. Ключ: на сервере `dt web-token show rw`; на ноутбуке
   `printf %s "$KEY" | uv run python cli/dt.py client join --server <dns|ip>` - проверит `/health` и
   принятие токена, положит `.secrets/web_token_rw` (600) и допишет в `.env` `DT_MODE=client`,
   `DT_SERVER_URL`. Значение ключа не печатается (только хвост).
10. Хосты на сервер: `dt host-config claude --server <dns> --install` (мост `dt_shim.py --url
    http://<dns>:8787/mcp/full`), `dt host-config cursor --server <dns> --install`; Cherry/другие -
    `dt host-config cherry --server <dns>` (печать для Import from JSON). Kimi: `dt host-config url
    --server <dns>` и запись в `mcp.json` агента руками (`dt plugin kimi` пока ставит url локального демона).
11. Проверка: `dt host-config <host> --verify` (url сервера + токен-файл + `/health`), `dt doctor` на
    клиенте - короткий набор (сервер отвечает, версия кода сервера, токены, хосты) без проверок vault и
    индекса; на сервере `dt doctor` и `dt config check` - как обычно.

Проверка «по проводу» с сервера (peer - его же Tailscale-адрес): `curl -s -o /dev/null -w '%{http_code}\n'
-H "Authorization: Bearer $(cat .secrets/web_token_rw)" -X POST -H 'Content-Type: application/json' -H
'Accept: application/json, text/event-stream' -d '<initialize>' http://<tailscale-ip>:8787/mcp/lean` -> 200;
без `Authorization` -> 401; через funnel-адрес (прокси-заголовки) -> 403; `DT_MODE=local` -> 403.
Трафик по tailnet шифрует Tailscale (HTTPS/OAuth для `/mcp` вне объема).
