# MCP server — conversational interface

Wraps the engine's `core/` (retrieval / policies / generation / output / ingest)
in an [MCP](https://modelcontextprotocol.io) server spoken over **stdio** — the
transport MCP hosts connect to. This is the primary interface from
architecture §8.

**Path B.** Nothing here calls a network LLM. The flow is:

```
parse_task → (you confirm) → generate → the host's chat model writes the artifact → save_output
```

`generate` assembles the full prompt and writes provenance, then *returns the
prompt*. The host's chat model produces the artifact text **in the conversation**, and
`save_output` saves it back as `output.md` next to the provenance. The engine
prepares context and records what produced an artifact; the model that fills
`output.md` is whatever the host runs — the host (from the MCP handshake) and the model the
client declares (`model=` of `output_begin`/`save_output`) go to `meta.yaml`
(`host`, `model`, `model_source: declared|host|unknown`, `engine_calls`).

> **Invariant.** This layer imports `core`; `core` never imports it
> (`tests/test_invariant.py`). The `mcp` SDK is imported lazily inside
> `build_server`, so the tool wrappers are unit-tested without the SDK present.

## Tools

| Tool | Wraps (core) | Returns |
| --- | --- | --- |
| `reindex(scope="incremental", async_=False)` | `retrieval.index.reindex` | `{scope, mode, device, new, changed, deleted, unchanged, embedded_chunks, notes, chunks, elapsed_s, db_path}` — `scope="full"` forces drop+recreate. `async_=True` → уводит в фон (JOB-1): возвращает `{job_id, op, state}`, результат через `job_status` (для полного ребилда, который иначе упрётся в клиентский потолок) |
| `submit_job(op, args=None)` | `orchestration.jobs.submit` | `{job_id, op, state:"queued"}` — запустить долгую операцию АСИНХРОННО (JOB-1) и получить `job_id` мгновенно; чат опрашивает `job_status`, клиент MCP не отваливается по таймауту (фейл Acme «4-мин»). Белый список `op`: `reindex` (`args={"scope":"incremental"\|"full"}`), `outlook_read` (`args={"mode":"meetings"\|"ticktick"\|"mail","days"?,"since"?,"scope"?}`), `lift_source` (`args={"note_id"?\|"path"?,"sheet"?,"cell_range"?,"max_cells"?}`); **ingest (PULT-STORAGE, `args={"mode":"light"\|"full","root"?}`):** `ingest_operational`, `ingest_knowledge`, `ingest_legacy`, `ingest_mail`, `ingest_capture`, `backfill_hashes` (light=dry-run превью / full=apply); **`ocr` (OCR-1, `args={"mode":"light"|"full","limit"?,"budget"?,"path_scope"?}`; light = очередь и оценка, full = прогон с бюджетом `DT_OCR_BUDGET_S`)**; прочее → ошибка. Detached-воркер (не держит MCP-процесс); прогресс durable + маяк (`pult_activity` видит задание); Path B — воркер гоняет саму операцию, без LLM. **MAIL-GAP-1:** у `ingest_mail` в общем результате поле `extra` = `{since_effective: {папка: дата границы|"all"}, skipped_since: N, skipped_since_by_folder: {…}}` - граница выгрузки и сколько СООБЩЕНИЙ отрезано ею (отдельно от `resumed`: уже в манифесте); у остальных ops `extra: {}`; то же в `ingress/last_runs.json`. |
| `job_status(job_id)` | `orchestration.jobs.status` | `{job_id, op, state:queued\|running\|done\|failed\|cancelled\|unknown, phase, current, total, cancel_requested}` + для `done` — `result` (payload операции) + `result_ref`, для `failed` — `error` (JOB-1). Читает durable-хранилище (`jobs.db` + `.derived/jobs/<id>.json`), поэтому переживает рестарт сервера; прогресс пишется по ходу (фазы/счётчики), не молчит до конца. |
| `job_list(state=None, limit=50)` | `orchestration.jobs.list_jobs` | `[{job_id, op, state, phase, current, total, cancel_requested, created_at, updated_at}]` — недавние async-задания для панели «Задания» контура «Движок» (JOB-1), новые сверху; `state` фильтрует, `limit` ограничивает. Паритет с `dt-job list`; durable `dt.db.jobs` (переживает рестарт); тяжёлый `result` с диска не читается. Read-only. |
| `job_cancel(job_id)` | `orchestration.jobs.cancel` | `{job_id, state, …}` (актуальный `job_status`) — мягкая отмена задания (JOB-1): `queued` гасится сразу, `running` получает кооперативный флаг + best-effort SIGTERM, терминальное — no-op. Паритет с `dt-job cancel`; действие, журналируется в JOB-1. |
| `parse_task(text)` | `parse_task.parse_task` | `{use_case_id, params, interpretation}` — confirm before generating |
| `plan_task(task, use_case_id=None, params=None)` | `parse_task` (если нет `use_case_id`) → `orchestration.planner.plan` + `resolve_status` | `{use_case_id, params, plan:{nodes:[{name, kind, critical, status, how}]}, blocking:[{what,kind,how}]}` — материализованный план кейса + read-only проба статусов узлов (PLAN-1). Делает оркестрацию видимой ДО генерации: `commercial_offer`→ money·exemplar·requisite (critical) + context + assemble; неизвестный кейс → `context→assemble`. Статус `present`/`missing`/`unknown` через реюз резолверов (`get_facts`/`find_exemplar`/`run_policy`); резолвер `unavailable`→`unknown`, не краш. `blocking` — только критичные `missing` в формате GATE-1 (`{what,kind,how}`) — единый список «нужно закрыть»; «найди образец» виден как незакрытый узел. Детерминированный (шаблоны, без LLM), ничего не пишет (безопасный preview). Крит. узлы → требования гейта при `generate(use_plan=True)`. |
| `retrieve(use_case_id, query, params, corpus, client, section, era)` | `retrieval.policies.run_policy` | `{slices, context}` (note_id / slice / score + preview) — inspection only |
| `generate(use_case_id, task, params, corpus, persist, require_facts=None, require_context=False, exemplar=False, exemplar_ref=None, use_plan=False)` | `generation.assemble_prompt` + `orchestration.gate.check_grounding` (+ `output.write_provenance` when `persist`) | `{output_dir, corpus, status:"ok", prompt, sources, facts, exemplar?}` — **no artifact text**; `persist=False` → эфемерно (папку не пишет). **Провенанс (UX-4/PULT-WORK):** ответ `ok` несёт `sources` (заметки vault, дедуп), `facts` (использованные структурные факты FACT-1 — whitelist `label`/`value_raw`/`value_num`/`unit`/`currency`/`vat_flag`/`kind`/`locator`/`confidence`/`stale_hint`/`source_path`; пусто, если политика без фактов) и `exemplar` (форма TMPL-1, когда была) — всё whitelisted, без внутренних id/хэшей/экстрактора; «Работа» показывает, чем обоснован черновик. **Грант-гейт (GATE-1):** объявленные критичные ресурсы (`required_facts`/`required_context` политики ∪ params `require_facts`/`require_context` ∪ критичные узлы плана при `use_plan`) проверяются после сборки; если чего-то нет → `{status:"blocked", missing:[{what,kind,how}], reason}` **без `prompt`** и **без output-папки** (даже при `persist=True`) — честный стоп с how-to вместо заглушек. **Образец оформления (TMPL-1):** `exemplar=True` (или `exemplar: true` политики, или явный `exemplar_ref` = note_id/путь) → реальная ФОРМА прошлого документа (структура+бланк) вставляется секцией `[Образец оформления]` ПЕРЕД `[Output format]` и приоритетнее скелета; провенанс в `exemplar`. Требование `required_facts:[exemplar]` без найденного образца → `blocked` c `kind="exemplar"`+how. **План (PLAN-1):** `use_plan=True` → критичные узлы шаблона кейса (`commercial_offer`→money+exemplar+requisite) авто-становятся требованиями гейта (без ручного авторинга политики); критичный exemplar-узел заодно триггерит его резолв в сборке. Дефолт `use_plan=False` → поведение не меняется. Нет требований → как раньше, плюс `status:"ok"` |
| `doctor(refresh=False)` | `diagnostics.run_diagnostics` | `{ok, oks, fails, warns, checks:[{name, status, detail, hint}], as_of, cached}` — окружение **и все гарды движка**; значения секретов не выводятся. **PULT-SURFACE-2:** доктор считается ~10 с, поэтому без `refresh` отдается СНИМОК (`.derived/status/cache/doctor.json`, TTL `DT_PULT_DOCTOR_TTL_S`=1800 с; его же пишут CLI `dt-doctor` и ночной шаг `doctor`), `refresh=true` пересчитывает; `as_of` - когда посчитано, `cached` - из снимка ли. Счётчики (`oks`/`warns`/`fails`) отдаются готовыми: свёртку «✓ N · ⚠ M · ✗ K» виджета «Здоровье DT» на «Мониторинге» рендерит выдача, а не фронт-арифметика (принцип 14); warning ≠ fail — `ok` падает только на критичных. значения секретов не выводятся. Среди проверок — строка **«NDA-барьер: маркеры = […]»** (NDA-1): видно, что барьер включён и по каким маркерам (`DT_NDA_MARKERS`, дефолт `_nda`); и строка **«Ingest-корни: N (knowledge M / operational K)»** (INGEST-1): сколько наблюдаемых корней, их маршруты и живы ли пути; и строка **«Byte-hash легаси: X/Y записей»** (INGEST-DEDUP): доля записей легаси-манифеста с проставленным `source_content_hash` — низкая ⇒ нужен `dt_legacy_ingest.py --backfill-hashes`, иначе перенос папки выглядит как переимпорт; и строка **«БД (dt.db): schema vN \| facts M / sources K / jobs L»** (DB-1): единая SQLite (facts/sources/jobs) с версией схемы и счётчиками таблиц — снести `dt.db` → пересоберётся |
| `find_notes(query="", corpus=None, person=None, domain=None, sort="relevance", limit=8, rerank=None)` | `retrieval.find.find_notes` | `{query, corpus, person, domain, sort, notes:[{note_id, title, path, source_path, score, matched_by, corpus, date}]}` (`path` — читаемый путь для `read_note`; для legacy `source_path` — провенанс, не файл) — двухуровневый legacy-aware поиск (RETR-LEGACY FIX-1). Лексика (FTS + точный матч frontmatter, **БЕЗ загрузки BGE**) вперёд; семантика (BGE) — только при пустой лексике. `corpus`: `vault` (строго без legacy)/`legacy`/`both`/`None` (авто vault→legacy→семантика). `person`/`domain` — фильтр по контрагентам/участникам frontmatter (`find_notes(person="Кутепова", sort="recent")` заменяет отдельный `find_correspondence`). Пустой ввод → `[]`. Read-only | **Разброс дат (SRC-FRESH-1):** верхний хит старше самого свежего хита выдачи более чем на `DT_DATE_SPREAD_MONTHS` (12) мес → в ответе `warning` с путём и датой свежего («верхний результат на N мес старше самого свежего (<path>, <date>) — проверь версию или sort='recent'»). Ранжирование НЕ меняется: релевантность честная, но «шаблон 2023 выше действующего плана 2026» один раз уже дало вывод, обратный истине (фейлкейс 11.08). Ключа нет, когда разрыв в пределах порога — форма ответа прежняя. **Реранкер (RETR-RERANK-1):** `rerank=true/false` бьёт env `DT_RERANK`, `null` — по env. Верхние `DT_RERANK_POOL` (30) кандидатов слияния переоценивает локальный cross-encoder `bge-reranker-v2-m3`; хвост пула идёт ниже в прежнем порядке; только для текстового запроса при `sort="relevance"` и пуле больше `limit`. С реранкером семантика (BGE) подключается всегда, хаб клиента из запроса гарантированно в первых трёх (первым — лучший по реранкеру), а `matched_by` переоценённых хитов получает суффикс `+rerank` (`fts+rerank`, база — из закрытого списка). **Предупреждение:** модели нет в `models/` / сбой → `warning[].code = "rerank_unavailable"`, порядок слияния и хаб первым (как без реранкера); пустая выдача с конвертом ≠ «ничего нет». Новых инструментов нет. |
| `find_latest(query, corpus=None, person=None, domain=None, limit=5)` | `retrieval.find.find_latest` (+ `sources.resolve_source_path`/`family_of`) | `{query, families:[{directory, latest:{path, mtime, draft, archived}, latest_final:{path, mtime}\|null, seed, versions, hits, members:[{path, mtime, draft, archived}] (до 10, новые сверху), shared_tokens, note_id, title, score}], warning?}` — **последняя версия документа по семействам ВОКРУГ найденного файла (SRC-FRESH-1, FIND-LATEST-1)**. Отвечает на вопрос, который `find_notes` не покрывает by design: какая версия ДЕЙСТВУЮЩАЯ. Кейс 11.08: по бизнес-плану 2023 сделан вывод «план обрывается на 2026», обратный истине — действующий план 2026–2029 лежал в том же каталоге, но в выдачу поиска не попал вовсе; поэтому новейший файл берётся **из каталога**, а не из выдачи. **Семейство — не папка (FIND-LATEST-1):** папка клиента (КП, расчеты, деки, ТС, сайзинг вперемешку) — не версии одного документа; семейство = `family_of(seed)` — файлы ТОЙ ЖЕ папки, похожие на файл-хит именем (звезда от seed, один `scandir`, содержимое НЕ читается; токены имени без дат/версий/стоп-слов, аббревиатуры КП/ГМ/ЦТ/ТС учитываются, NFD→NFC). `versions` — размер семейства, `seed` — файл-основа, `shared_tokens` — токены имен, общие для половины членов. Семейства с тем же набором членов (и входящие целиком в более релевантное) схлопываются в `hits`. **Черновик vs действующий:** `latest` — новейший не-архивный, `latest_final` — новейший не-черновик и не-архив или `null` (действующей версии нет — не прячется). `draft` — слово маркера (`черновик`, `draft`, `проект документа`, `рабочая версия`, `wip`…) в имени файла или папки-родителя, целым словом (`проектирование` — не черновик), либо `status: draft` заметки-хита; `archived` — `архив`, `old`, `backup`, `копия`, `copy`, `superseded`. Маркеры — данные: `vault/_system/freshness-markers.yaml` (нет файла — запасной набор из кода; битый — запасной набор + конверт `store_unavailable`). **Ранг семейства** = лучший `score` хита + 0,2 × доля токенов запроса в `shared_tokens`; семейства в полосе 0,2 от лучшего («одинаково релевантные») идут по дате `latest` (новые первыми), остальные ниже по рангу (`score` в ответе — ранг, не порядок внутри полосы). Каталог получается разрешением `source_path` (он относителен корню хранилища) тем же порядком, что у `lift_source`, но без чтения/хеширования; заметки без файлового источника (курированные vault — `source_path` вырождается в их же `.md`; провенанс legacy-треда) и нечитаемая папка семейством не становятся (`families: []`). Scope по умолчанию — оба корпуса. Read-only, нового стейта нет. |
| `read_note(path, max_chars=8000)` | `retrieval.find.read_full_note` | `{path, id, frontmatter, body, truncated}` — полное чтение заметки по пути **включая `_legacy/`** (RETR-LEGACY FIX-2), containment-guard (только внутрь vault). Тело до `max_chars` (флаг `truncated`). В отличие от `work_note_preview` (режет ~320 символов, только vault) | **NOTE-ID-1:** принимает ЛЮБУЮ форму ссылки — путь, имя файла или frontmatter `id`; путь не сложился → резолв через `core.vault.resolve_note_path` (id по индекс-манифесту за O(1), затем обход по имени). Кейс К. с пульта: цель линк-предложения `pak-a-zdo-overview` при файле `pak-a-overview.md` — линковка её находила (ищет по frontmatter id), а читатель отвечал «no such note». Путь за пределы vault — по-прежнему отказ с тем же текстом.
| `attribute_note(path, client_id)` | `operational.attribute.attribute_note_client` | `{path, note_id, client, changed, previous, needs_reindex}` — frontmatter `client:[[hub]]`, путь внутри vault |
| `lift_source(note_id=None, path=None, sheet=None, cell_range=None, max_cells=None, async_=False, max_chars=None)` | `sources.lift_from` (+ `slice_result`) | `{path, kind, content_hash, mtime, stale_hint, text, tables, meta, truncated, status, reason, cache_hit, nda, newer_sibling, family}` — подъём файла-источника в рантайме (SRC-1). Разрешение: явный `path` (абс/vault-относит.) приоритетен, иначе `source_path`/`source_paths` из frontmatter заметки (`sources`-wikilinks НЕ путь); относительный путь пробуется по legacy-корням, затем по **всем** ingest-корням (операционные первыми) полным джойном и прогрессивным tail-match'ем ≥2 сегментов, затем релокацией по content-hash. **RESOLVE-KNOWLEDGE-1:** до 11.08 шаг по корням фильтровал `route: operational`, а единственный корень с 15.07 — `knowledge` ⇒ подъём через заметку не доставал НИ ОДИН файл хранилища (`unavailable` при живом файле; регрессия скрытая — retrieve и кэш работали). Чтение файла-источника законно и для knowledge-корней; NDA-гард на пути и осторожность tail-match (bare filename никогда) целы. Для xlsx — `tables` с координатами `sheet!ref` + `is_number` сверх плоского `text`; `sheet`/`cell_range` (`"B7:B9"`) — срез. Кэш L2 по `content_hash` (`cache_hit`). Read-only + бюджет (timeout+cap); мёртвый путь / нет extra `parsers` / таймаут → `status="unavailable"` (без исключения). `async_=True` → подъём большого файла в фон (JOB-1): `{job_id, op, state}`, результат через `job_status`. **NDA-барьер (NDA-1):** путь-маркер `_nda` (сегмент `_nda/` или суффикс `*_nda.*`, регистронезависимо), либо NDA-заметка / NDA-`source_path` карточки → **отказ** `status="unavailable"`, `nda=True` — файл НЕ читается, L2-кэш и реестр НЕ пишутся; отказ пишется в аудит как `nda_refused` (path-hash, без контента). **Потолок текста (ARGS-STRICT-1):** `max_chars` (`None` - `DT_LIFT_MAX_CHARS`, дефолт 40 000; `0` - без потолка): `text` длиннее - усечен по границе строки, `truncated: true`, `chars_total` и конверт `warning: [{code: "truncated", hint}]`; таблицы и `max_cells` как были; кэш L2 и `lift_from` хранят полный текст - усечение только в ответе (в `async_` - по явному `max_chars`). Требует `uv sync --extra parsers`. | **Свежесть каталога (SRC-FRESH-1):** папка хранилища = семейство версий, поэтому один `scandir` рядом с уже сделанным `stat` даёт `newer_sibling` = `{path, mtime, days_newer}` файла с похожим именем и датой новее на `DT_NEWER_SIBLING_DAYS` (30) дней — он же поднимает `stale_hint` (смысл поля шире: «не считай это число последним»), и `family` = `{rank_by_date, of}` (какой файл по счёту по дате из скольких **версий его семейства** — FIND-LATEST-1: «2-й из 4», а не «10-й из 23 файлов папки»; `newer_sibling` — тоже только из семейства). Похожесть имени — без НЛП: общие значимые токены (NFC, без дат/версий/стоп-слов; двухбуквенные аббревиатуры КП/ГМ/ЦТ в верхнем регистре сохраняются) ИЛИ общий префикс ≥8 символов. Каталог из одного файла / непохожие имена → `newer_sibling: null`, `1 из 1`. Данные ЖИВЫЕ: в L2-кеш по content_hash не попадают (те же байты в другой папке имеют других соседей). Живой кейс: подъём `PPS_статус ДДС_23122024.xlsx` → «13-й из 13, новее на 317 дн — `PPS_статус ДДС_22042026.xlsx`».
| `get_facts(entity=None, kind=None, note_id=None, source_path=None, min_confidence=0.0, as_of=None, known_as_of=None, include_superseded=False, limit=None)` | `facts.get_facts` (+ `lift_from`/`extract_facts`/`upsert_facts` on demand) | `[{fact_id, entity_ref, source_path, source_content_hash, locator, kind, label, value_num, value_raw, unit, currency, vat_flag, confidence, stale_hint, extracted_at, extractor_version, schema_version, scale, section, is_total, value_base, valid_from, valid_to, known_at, superseded_at, superseded_by, fact_key, prev_fact_id, provisional, date_basis}]` (**FACTS-BITEMPORAL-1:** две оси времени - `valid_from`/`valid_to` (когда верно; даты, полуинтервал `[from, to)`, `valid_to=null` - пока верно; `date_basis` - `name\|mtime\|""`) и `known_at` (когда узнали - mtime источника); новая версия документа вытесняет факты старой с тем же `fact_key` (`superseded_by`/`valid_to` у старого, `prev_fact_id` у нового), черновик (`provisional`) ничего не вытесняет. **По умолчанию - только актуальные факты** (вытесненные скрыты; прежде отдавались все версии); `as_of="YYYY-MM-DD"` - верное на дату; `known_as_of` - что знали на дату; `include_superseded=true` - вся история; неразбираемая дата → `filter_not_applied` и пусто. FACT-2: `unit` - канон: деньги - код валюты, количества - `чел.-дн`/`шт`/…, ставки - `%`; `scale` - множитель подписи «млн/тыс.»; `value_num` - как в ячейке и НИКОГДА не домножается, `value_base = value_num × scale` - производное; `section` - самая левая подпись строки; `is_total` - строка «Итого»; `kind=ordinal` - порядковые номера, без явного `kind` не отдаются; факты прежней версии экстрактора по `note_id`/`source_path` переизвлекаются сами, в выдаче без источника - конверт `facts_outdated`; `merges_skipped` - объединенные шапки не прочитаны) — типизированные факты из источников (FACT-1). Семантика над SRC-1: 480 «себестоимость витрины» vs 654,1 «витрина+ЭХД» не путаются (аудит Acme). При `note_id`/`source_path` без фактов в сторе — под капотом `lift_from`→`extract_facts`→`upsert` (идемпотентно по `fact_id`); иначе из стора. Фильтры `entity`/`kind` (money\|quantity\|date\|rate\|requisite\|bin\|contact)/`min_confidence`. Экстракция ДЕТЕРМИНИРОВАННАЯ (Path B, без LLM). **Потолок выдачи (ARGS-STRICT-1):** `limit` (`None` - `DT_FACTS_MAX`, дефолт 200; `0` - без потолка): укладывается - список как был; больше - конверт `{facts: [первые limit], total, limit, warning: [{code: "truncated", hint: "сузь entity/kind/note_id/source_path или подними limit"}]}`; невалидный `limit` (<0, не целое) - `filter_not_applied` и пусто. Гейт «нет фактуры → blocked» — GATE-1 (не здесь). **Сканы (OCR-1):** источник - pdf, текст которого получен распознаванием (`source_type: pdf-ocr`) - факты НЕ извлекаются, ответ - конверт `{facts: [], warning: [{code: "facts_not_from_ocr", …}]}` (цифры со скана без проверки хуже отсутствия). Заметки сканов: `source_type: pdf-scan` (заглушка, `ocr: pending\|refused\|refused_text\|empty`) и `pdf-ocr` (`ocr: done\|low`, `ocr_engine`, `ocr_confidence` 0..1). |
| `owner_profile()` | `owner.load_profile` | PROFILE-1: профиль владельца, read-only - `{name, company, role, about, rules, updated, version, missing, issues}`; `about` - о владельце (то же идет в промпт `generate` секцией `[Owner]`), `rules` - правила работы для любого ассистента/хоста, `version` - 12 символов sha256 по трем файлам профиля (хост видит, что профиль сменился), `missing` - файлы без содержания, `issues` - замечания схемы `owner.yaml` (`code`/`field`/`message`). Не `WRITE_TOOLS`; все три профиля (`lean`/`pult`/`full`), не в allowlist артефакта пульта (сводка - `pult_settings_get.owner`) |
| `ingest_scan(root=None, dry_run=True)` | `file_ingest.scan` (read-only preview) | `{configured, roots, root_names, total_seen, new, changed, unchanged, nda_skipped, excluded, pending_download, errors, operational_registered, knowledge_roots_ingested, reindex_triggered, dry_run, …}` — превью файлового ingest (INGEST-1): скан корней из `_system/ingest-roots.yaml` (per-device резолв путей), фильтр include/exclude + NDA-1 `is_nda` (**всегда**), диспозиция new/changed/unchanged + пропуски (nda/excluded) + iCloud `pending_download`. `root` — один корень. **`dry_run=True` (дефолт) строго read-only:** ничего не пишет (реестр/заметки/манифест) и **не скачивает** dataless-файлы. Боевой проход (register/ingest/reindex) — CLI `dt_ingest --apply`. Инкрементальность по `content_hash` (не mtime); оператив→SRC-1 `register_source` (без заметки/индекса), знание→legacy `ingest_corpus`+reindex. Path B (сеть только для iCloud-материализации). |
| `find_exemplar(genre, client=None, fmt=None, render=True)` | `exemplars.find_exemplar` (+ `as_template` when `render`) | `{found, exemplar:{note_id, path, source_path, genre, fmt, client, score, why}, render?:{sections, letterhead, salutation, closing, boilerplate, sample, source_note, source_path, fmt, available, reason, output_format}}` — реальный прошлый документ как ОБРАЗЕЦ ОФОРМЛЕНИЯ (форма), отдельно от `[Style exemplars]` (тон) (TMPL-1). Отвечает на «найди пример КП как образец» — то, чего не было в фейл-кейсе Acme. Ранжирование ДЕТЕРМИНИРОВАННОЕ: тот же `client` > та же отрасль (по хабу) > любой того же жанра; `type: template` буст; свежесть — тай-брейк. `genre` (плюрал/сингуляр нормализуются), `fmt` — фильтр формата/расширения (docx\|pptx\|md). Ничего нет → `{found: false}` (не выдумываем). `render` поднимает форму: бинарь через SRC-1 `lift_from` (best-effort, `unavailable`→мягко), markdown — из тела заметки; `output_format` — компактная секция `[Образец оформления]`. Path B, read-only. |
| `output_begin(title, task, channel=None, model=None, purpose=None)` | `output.begin_output` | `{output_dir, created, channel, purpose?, eval_task?, prompt_chars, next, warning?}` — **EVAL-HYGIENE-1:** `purpose` ∈ `work`(дефолт)`|eval|selftest`; назначение решает движок (постановка = фраза задачи `golden-generation.yaml` → `eval` + `eval_task`; хост `shim-test`/`dt-spike-*`/`idle-test` либо `DT_SELFTEST=1` → `selftest`), явное значение сильнее только в сторону `eval`/`selftest` (работой прогон не пометить); в ответе `purpose` есть только у не-`work`, у рабочего выхода ответ и мета байт-в-байт прежние; выход не-`work` доставляет файлы в `<корень>/_eval/…` и не попадает в досье/линт/поиск.  **каркас выхода ДО работы (DOD-2)**. Создаёт `07-outputs/YYYY-MM/<дата>-<slug>/` с `meta.yaml` (`status: draft`, `source: adhoc`, `engine_run: false`, `channel` если задан) и `prompt.md` — постановка `task` **дословно**. Обязателен, когда артефакт уходит ЗА ПРЕДЕЛЫ vault (опер. хранилище, клиент, HR, внешняя форма): контур собирался ПОСЛЕ работы, и таймаут моста на середине оставлял полу-папку, которая «выглядит оформленной» (фейлкейс 2026-08-11, 3-е повторение класса). Падение после `output_begin` оставляет валидную заявку с зафиксированной постановкой — провенанс постфактум невосстановим. `channel` ∈ {`vault`,`storage`,`external`,`hr`,`client`}; незнакомая метка — не отказ, а `warning` (контур не должен падать из-за словаря). **Идемпотентно по `title` в тот же день** → та же папка (`created: false`, постановка обновляется, время заявки исходное); папку с готовым `output.md` не трогает (суффикс `-2`). Пустой `title`/`task` → отказ. Закрывает контур `save_output(output_dir=…)`; незакрытые дольше `DT_OUTPUT_DRAFT_WARN_H` (24 ч) показывает `doctor`. SEC-2 containment + аудит (постановка в аудит не идёт). |
| `save_output(output_dir=None, text, file_refs=None, title=None, dest=None, format=None, sources=None, model=None, overwrite=False, purpose=None)` | `output.save_artifact` (+ `operational.deliver_output.deliver_text` при `dest`) | `{path, chars, purpose?}` (+ `delivered` при `dest`) — **EVAL-HYGIENE-1:** выход не-`work` (`purpose: eval|selftest`, см. `output_begin`) доставляет `dest` в `<корень>/_eval/<ГГГГ-ММ>/<папка выхода>/` (тот же корень; NDA-адрес не прячется - отказ `nda`), `delivered` несет `quarantined: true` и `intended_dest`, запись `meta.delivered[]` - `intended_dest` (куда просили); `place_download`/`store_file*` без папки выхода уходят в `_eval` по хосту вызова (тестовый хост либо последний выход хоста за `DT_EVAL_SESSION_H` помечен). `find_notes`/`retrieve`/`find_latest` принимают `include_eval` (дефолт `false`: прогоны скрыты).  `output_dir` must resolve inside `07-outputs/` (SEC-2 guard). `file_refs` (OUT-FILE-1) — опц. пути к файловым deliverable (доставленным `store_file`): добавляет секцию «## Файлы» со ссылками в `output.md`; без него байт-идентично прежнему. **Ad-hoc (DOD-1):** без `output_dir`, но с `title` — папка `07-outputs/YYYY-MM/<дата>-<slug>/` создаётся сама (+ `meta.yaml` c `source: adhoc`), так что закрывающий шаг контракта делается ОДНИМ вызовом даже без `generate`; `output_dir` приоритетнее `title`; ни того, ни другого → отказ; SEC-2 containment проверяется для обоих путей. **`dest`+`format` (ФТ-4/FT-4)** — адресат известен заранее → содержимое едет через мост **один раз** (этим текстом), файл нужного формата собирается **локально** (pandoc), бинарь через мост не передаётся вовсе: `dest` — алиас рабочей папки (`folder_alias_list`) либо путь относительно ingest-корня, `format` ∈ {`md`,`docx`,`pdf`} (дефолт `md`). `output.md` в `07-outputs` пишется ВСЕГДА, путь доставленного файла автоматически попадает в его «## Файлы» (указывать в `file_refs` не нужно); имя файла — имя папки задачи (task-id) + расширение. Гарды `dest` — те же, что у `store_file`/`place_download` (containment/NDA/байт-идентичный `existed`/отличающийся требует `overwrite`), тексты отказов дословно те же. Нет pandoc или pdf-движка (равно как сбой/таймаут конвертации) → сохраняется `.md` + `warning` в ответе, **не отказ** (требование ФТ). `delivered` = `{ok, path, abs_path, root_name, size, sha256, format_used, requested_format, existed, overwritten, outcome, alias, warning}`; отказ гарда → `{ok:false, refused, code, error}` (при этом `output.md` сохранён — текст не теряется). **DELIVER-2 (контракт доставки):** каждая доставка пишет в `meta.yaml` запись `delivered: [{root, rel_path, sha256, format, at}]` (в конец меты; снапшот-ключи generate-папки неизменны). Повторный `save_output` тем же `output_dir`/`dest` — правка выхода: файл с sha нашей прошлой доставки — свой, перезаписывается без `overwrite` (`delivered.outcome: updated`; байт-идентичный — `existed`); файл с другим sha (правили снаружи) или чужой → `exists_differs` с причиной (`ours_sha256`/`disk_sha256`: «sha разошелся с нашей доставкой» либо «не наша доставка»); `overwrite=True` затирает и его (`outcome: overwritten`). Секция «## Файлы» не теряется при повторном сохранении: к явным `file_refs` сливаются (без дублей) ссылки уже лежащего `output.md` и `delivered` меты, отказ доставки секцию не трогает. **`format` без `dest`** («файл в чате») → файл в ПАПКЕ ВЫХОДА `07-outputs/<месяц>/<task>/<task>.<fmt>` (pandoc локально, гард — только эта папка и не `_nda`; ingest-корни не затрагиваются), ссылка `vault:<путь от корня vault>` в «## Файлы», `delivered: {ok, path, abs_path, root_name: "vault", in_output_dir: true, …}`; `md` и откат на md (нет pandoc/pdf-движка) отдельного файла не создают — указывают на `output.md`. `place_download`/`store_file*` поверх пути из `delivered` другого выхода по-прежнему разрешены, но выход получает пометку `replaced_by: <host>/<sha>` (подпись ссылки «заменен снаружи» в «## Файлы», строка аудита `delivered_replaced`, справка доктора DOD). **Источники по сессии (SRC-TRACE-2 → PROV-SESSION-1):** `sources.md` собирается САМ из журнала запросов (`.derived/eval/queries.jsonl`, `core/eval_journal.py`; события `search`/`open` несут `host` и - при http-контексте MCP - `sid` сессии; `get_facts` пишет `open` с путями источников фактов, без значений; selftest-хосты в журнал не пишутся; выключатель `DT_EVAL_QUERY_LOG=0` гасит и провенанс сессии, ретенция 90 дн) и аудита подъемов: `read_note`/`work_note_preview` → `origin: read` (путь, `source_path` и дата через резолвер NOTE-ID-1; почтовый тред - «прочитано N из M»), `lift_source` → `lift`, `get_facts` → `facts`, один путь читали и поднимали → одна строка `read+lift`; **поиски** (`find_notes`/`find_latest`/`retrieve`) - отдельная секция «## Поиск в сессии» (запрос, инструмент, `top_ids`): кандидаты, НЕ источники, в таблицу и в eval `sources_min` не идут. **Окно - сессия** (`core/provenance.py:session_window`): с первого вызова `sid` либо после предыдущего `save_output` той же сессии (по аудиту), не дальше `DT_ADHOC_SOURCES_H` (8) ч; `output_begin` раньше этой точки двигает начало к постановке, «поздний» `output_begin` (позже `DT_PROV_LATE_BEGIN_MIN`, 3 мин, при более ранних событиях сессии) - не начало работы; `sid` неизвестен - по хосту; журнал молчит - последние 8 ч с пометкой «окно, а не сессия»; шапка файла говорит, как определено окно. Папка от `generate`: её `sources.md` (чанки промпта) НЕ перетирается - в конец дописываются автосекции «## Прочитано в сессии»/«## Поиск в сессии» (повтор пересобирает, не дублирует); читать было нечего - файл и ответ байт-идентичны. Ответ: `sources: {path, rows, read, lift, facts, manual, searches, window: {kind, since, until, sid?}}`. `sources=[{path, what_taken}]` - только то, что использовано мимо DT (бумага, переписка в чате, устное): строки `origin: manual`, сливаются с автосбором по пути, повторный `save_output` их не теряет. Нет ни строк, ни поисков и `sources` не передан → `warning` (не отказ) + строка `doctor`; «Выходы: провенанс» - доля выходов с телеметрией сессии (ретро - `dt outputs sources`). Существующий `sources.md` движкового выхода не перетирается. Из путей источников выводятся хабы клиентов/продуктов (**только существующие**, детерминированный каталог линковки) → секция «## Связано» в `output.md`: выход виден со стороны клиента. Кейс 11.08: ad-hoc-выход с 16 первоисточниками получил ноль машиночитаемого провенанса. **Финализация (DOD-2):** папка от `output_begin` (мета несёт `status: draft`) закрывается этим вызовом — `status → final` + `finalized`, канал уточняется фактом доставки (`dest` → `storage`); в ответе `finalized: true`. Папки от `generate` и ad-hoc DOD-1 байт-идентичны (ключа `status` у них нет — мету не трогаем). |
| `store_file(root_name, rel_path, content_b64, sha256, overwrite=False)` | `operational.store_file.store_file` | `{ok, path, size, sha256, existed, overwritten}` — доставить файловый deliverable (base64) в рабочую папку (OUT-FILE-1). Запись **только под ingest-корни** `ingest-roots.yaml` (operational/knowledge); `root_name` — имя корня, `rel_path` — относительный путь. Гарды: containment по `resolve` (`../`/абсолютный/симлинк → отказ); NDA (`_nda` → отказ); size-cap 25MB (env `DT_STORE_FILE_MAX_BYTES`); **sha256 сверяется ДО записи** (заявленный == декодированному) **И ПОСЛЕ** (перечитан с диска; не сошёлся → удалён + ошибка). Существующий байт-идентичный → `existed` без перезаписи (mtime цел); отличающийся → отказ без `overwrite=True`. Атомарно (tmp+rename); аудит без контента; отказ гарда → `{ok:false, refused, error}`. Запись в vault/вне корней невозможна. Path B |
| `store_file_begin(root_name, rel_path, final_sha256, total_size, overwrite=False)` | `operational.store_chunked.begin` | `{ok, session_id, chunk_limit, expected_next, expected_offset, bytes_done, total_size, path, root_name, resumed, existed}` — открыть сессию порционной записи (ФТ-5/FT-5), **только для бинарей без текстового источника** (xlsx с формулами, заполненный PDF, изображение). **Все гарды цели проверяются здесь** (корень/containment/NDA/существующий) — fail-fast ДО передачи частей. Байт-идентичный файл уже на месте → `{existed:true, session_id:null}` (передавать нечего). Повторный вызов с той же целью и тем же `final_sha256` **возобновляет** сессию (id детерминирован) — потерянный `session_id` не повод начинать заново. Сборка идёт в `.derived/chunked/`, не в клиентской папке. Отказ → `{ok:false, refused, code, error}`. Аудит — одна строка |
| `store_file_append(session_id, part_index, content_b64)` | `operational.store_chunked.append` | `{ok, session_id, received, expected_next, expected_offset, bytes_done, remaining, complete}` — очередная часть, **строго по порядку** с `part_index=0`, размер ≤ `chunk_limit` (env `DT_CHUNK_LIMIT`, дефолт 16 КБ — ниже зоны отказов моста 29–39 КБ и ниже порога диагностики FT-3). Часть не по порядку → отказ `out_of_order` с `expected_next`/`expected_offset` — **из отказа видно, с чего продолжать** (это и есть resume). Больше лимита → `chunk_too_large`. Каждая принятая часть — на диск с `fsync` (обрыв не теряет принятого). В аудит НЕ пишется (только свой scratch в `.derived`, не клиентская папка) |
| `store_file_status(session_id)` | `operational.store_chunked.status` | `{ok, session_id, root_name, path, received, expected_next, expected_offset, bytes_done, total_size, remaining, complete, chunk_limit, final_sha256, expires_in_s}` — состояние сессии: первый вызов после обрыва. Read-only (попутно снимает истёкшие по TTL). Нет сессии/истекла → `{ok:false, refused, code, error}` |
| `store_file_commit(session_id)` | `operational.store_chunked.commit` | `{ok, path, root_name, size, sha256, parts, existed, overwritten}` — сверка sha256 собранного файла с заявленным на `begin` → атомарная подмена цели через тот же write-слой, что у `store_file`/`place_download`. Собрано не всё → `incomplete` (с остатком); sha не совпал → `sha_mismatch`, части удалены, **в целевой папке не появляется ничего**. Аудит — одна строка (с `parts=N`: сколько было приёмов) |
| `store_file_abort(session_id)` | `operational.store_chunked.abort` | `{ok, session_id, removed, discarded_bytes}` — снять незавершённую сессию (идемпотентно). Незавершённые в любом случае живут не дольше TTL (env `DT_CHUNK_SESSION_TTL_H`, дефолт 24 ч, ленивая чистка); висящие видны в `doctor` строкой «Chunk-сессии (ФТ-5)». Аудит — одна строка |
| `place_download(match, dest, root_name="current", new_name=None, overwrite=False, max_age_minutes=60, keep_source=False)` | `operational.place_download.place_download` | `{ok, path, size, sha256, matched_name, moved, copied, existed, overwritten, alias, root_name, source}` — перенести **скачанный браузером** файл из каталога загрузок в рабочую папку (ФТ-1/FT-12). Основной канал доставки файла из чата: **байты через мост НЕ идут** (команда ~60 байт вместо десятков КБ base64 — инцидент 04.08.2026, когда одно тяжёлое сообщение обесточило все локальные MCP); `store_file` остаётся для файлов без «скачанного» источника. `match` — glob (`*.docx`) ИЛИ подстрока имени, регистронезависимо; `dest` — алиас папки (`folder_alias_list`) либо путь относительно корня `root_name`; каталоги поиска — env `DT_DOWNLOADS_DIRS` (дефолт `~/Downloads`, без рекурсии; недокачанные `*.crdownload`/`*.part` игнорируются); `max_age_minutes` — потолок возраста кандидата (`0` — без ограничения); `keep_source=True` — копировать, а не перемещать. **Неоднозначность не разрешается сама:** 0 кандидатов → отказ `no_candidates` + `recent` (5 последних файлов — видно, почему шаблон не сработал); >1 → отказ `ambiguous` + `candidates` (имя/размер/mtime) — автовыбор «самого свежего» ЗАПРЕЩЁН (ошибочная запись в клиентскую папку дороже повторного вызова). Гарды — **те же, что у `store_file`** (общий слой `file_ingest.write_target`): containment по `resolve`, NDA (`_nda`), байт-идентичный существующий → `existed` без перезаписи (mtime цел), отличающийся → отказ без `overwrite=True`. Dataless iCloud-источник материализуется (`brctl`, бюджет `DT_INGEST_MATERIALIZE_TIMEOUT`); не удалось → отказ `not_materialized`, частичный/нулевой файл не создаётся. Перенос атомарный (`rename`; между томами — копия+`fsync`+`replace`); аудит без контента; ≤2 с для 50 МБ. Отказ → `{ok:false, refused, code, error, …}`. |
| `folder_alias_list()` | `file_ingest.aliases.list_aliases` | `{registry, count, aliases:[{name, root_name, rel_path}]}` — перечень алиасов рабочих папок (ФТ-2), read-only подсказка для чата. Алиас сворачивает разнородно написанный путь (`Kazakhstan/Globex` латиницей, `Russia/Подводные технологии` кириллицей) в один короткий токен для `dest` в `place_download`. Сопоставление регистронезависимое, кириллица и латиница, с транслит-допуском («ЦОД» = «цод» = «TSOD» = «cod»); при двусмысленном транслите догадка НЕ делается. Реестр — `_system/folder-aliases.yaml`; нет файла/битый YAML → `{count: 0, aliases: []}`. |
| `folder_alias_set(alias, root_name, rel_path)` | `file_ingest.aliases.set_alias` | `{ok, name, root_name, rel_path, path, exists, created, updated}` — добавить/изменить алиас папки (ФТ-2). Целевой путь проверяется **теми же гардами, что запись файла**: `root_name` ∈ `ingest-roots.yaml`, containment по `resolve`, не `_nda` — алиас за пределы корней или под `_nda` **не регистрируется** (реестр не может стать обходным путём). `rel_path` пустой = сам корень; папки может ещё не быть на диске (`exists` покажет). Файл реестра пишется атомарно (tmp+`replace`), правится и руками. Отказ → `{ok:false, refused, code, error}`; аудит — `record_action`. |
| `list_inbox()` | `ingest.list_inbox` | `[{file, chars, preview}]` |
| `refine_inbox()` | `ingest.build_refinement_request` | `[{file, request}]` — request is a prompt for a placement proposal |
| `apply_refinement(inbox_file, proposal)` | `ingest.apply_refinement` | `{written_path, cleared_inbox_file}` — target must stay inside the vault (SEC-1 guard) |
| `propose_links(...)` | `linking.propose.propose_for_notes` | proposed candidates queued for review |
| `apply_links(...)` | `linking.apply.apply_approved` | applied/skipped — idempotent insertion into `## Связано` + frontmatter |
| `pult_cards(kinds=None, limit=50, refresh=False)` | `decisions.registry.queue` | QUEUE-SERVER-1: очередь решений ОДНИМ вызовом - `{cards, totals: {вид: ждут}, errors: {вид: код}, as_of, as_of_kinds, timings: {вид: мс}}`; карточки девяти видов единой формы (см. «Очередь решений» ниже); `limit` - на вид, `totals` - реальные счетчики; сбой вида - в `errors`, остальные отдаются; вид `gold` на чтении НЕ считается никогда (PULT-SURFACE-2: реранкер = секунды внутри read-вызова) - отдается последний расчет (`as_of_kinds.gold`; его пересчитывает шаг `eval` ночной цепочки), `refresh=True` пересчитывает только `gold` сейчас. Read-only. Профили `pult`/`full` |
| `pult_card_decide(card_id, action, params=None)` | `decisions.registry.decide` | QUEUE-SERVER-1: решение по карточке `<вид>:<id>` - исход `{ok, outcome: applied\|rejected\|snoozed\|routed\|stale\|refused, code?, detail, effects, card_id, kind, action}`; звонит в ядро вида (ядра не менялись); аудит ОДИН раз (`pult-actions.log` + событие `queue_decision`). `WRITE_TOOLS` |
| `pult_card_explain(card_id, params=None)` | `decisions.registry.explain` | QUEUE-SERVER-1: «почему» по карточке - `{ok, card_id, kind, why}`; SURFACE-HYGIENE-1: у `assignment` с `params={deal_guid}` - `why.draft` (черновик под выбранную сделку, чтение; замена `pult_assignments(capture_id, deal_guid)`) (link - превью источника/цели и фрагмент, reattr - что переехало, hub - сигналы/сделка/похожие хабы, alias - варианты); `why: null` - вид не объясняется. Read-only |
| `pult_kpi(days=7)` | `metrics.summarize` | metric 1–3 counters + shares + `daily` series — the exact numbers `dt-kpi` prints (single source). EVAL-3: `health` — снимок последнего доктора (`diagnostics.last_snapshot`: `{ts, oks, warns, fails, worst, items[{name,status,detail}], age_min, stale}`, только warn/fail; пишет его каждый прогон доктора и ночной шаг `doctor`) для индикатора здоровья в шапке пульта; нет снимка → `health: null` + конверт `no_runs`, битый → `store_unavailable` |
| `pult_sync_status()` | `operational.pult.sync_status` | `{last_fast: {ts, ok, failed_steps}, last_full: {…}, running}` — parsed from the dt-sync log tail; `running` via the flock lock |
| `pult_log_tail(lines=80, errors_only=False)` | `operational.pult.log_tail` | `{path, lines}` — dt-sync log tail (already token-scrubbed at write time); `errors_only` keeps ERROR/WARNING |
| `pult_run_sync(mode, steps=None)` | `operational.pult.start_sync` | `{started, mode, pid, steps, already_running}` — fire-and-forget detached `dt_sync fast\|index\|full`; `steps` — только эти шаги режима (RETIRE-WRITE-1 п.7; неизвестный → конверт `bad_steps`); режим уже идёт → `started:false` + `running:{mode,step,pid}` + конверт `skipped` с именем прогона и шага; audited |
| `pult_freshness()` | `operational.freshness.snapshot` | `{sources: [{source: mail\|timetta\|ticktick\|index\|linking, data_as_of, lag_h, stale, stale_after_h, last_run: {ts, ok}, …}], elapsed_ms}` — data freshness per source from manifests/cursors (no heavy dir scans; `index` also carries `notes_newer`); last runs parsed from the dt-sync log; missing source → honest nulls; <200ms |
| `pult_monitor()` | `operational.monitor.monitor` | PULT-SURFACE-2 (MONITOR-CARD-1): вкладка «Мониторинг» ОДНИМ read-вызовом из снимков и статусов, без сканов и расчетов - `{health, night_chain, services, sync, jobs, activity, freshness, storage, as_of: {блок: время}, timings: {блок: мс}}`. `health` - `{worst, oks, warns, fails, problems, items: [первые 5 warn/fail], source: doctor\|doctor_last}` из снимка доктора; `night_chain` - последний прогон index (`total`, `top` из 3 шагов, `warnings`, `status` - те же пороги, что у доктора «Ночная цепочка»); `services` / `sync` / `jobs` / `activity` / `freshness` - те же формы, что у `pult_services` / `pult_sync_status` / `job_list` / `pult_activity` / `pult_freshness`; `storage` - снимок `pult_storage_status`. Нет снимка (доктор/хранилище не считались) → `{available: false}`, ничего не запускается; сбой блока → `{error}`, прочие отдаются. Профили `pult` и `full`, в allowlist артефакта. Read-only |
| `pult_activity()` | `operational.pult.activity` | `{processes: [{proc, status: running\|finished\|interrupted, phase, current, total, eta_s, uptime_s, …}], system: {load_avg_1m, cpu_count, swap}}` — ACT-1 progress beacons from `.derived/status/` (liveness via kill-0) + load/swap numbers; read-only |
| `pult_services()` | `operational.services.service_status` | `[{key, label, kind: launchd\|mcp, control: full\|status_only, plist_label, loaded, running, status: running\|loaded\|stopped, pid, last_exit_code, note}]` — сетка сервисов контура «Движок» (PULT-ENGINE): три launchd-демона (`sync.fast`/`sync.index`/`webpult`) по `launchctl list` + MCP-сервер (эвристика живости, `status_only` + подпись «управляется MCP-хостом»). macOS; сбой `launchctl` → честный `stopped`; read-only |
| `pult_service_control(key, action)` | `operational.services.service_control` | `{ok, key, action, cmd, returncode, error?}` — start/stop/restart сервиса движка (PULT-ENGINE). `action` обязателен (гард): `start`=`launchctl bootstrap`, `stop`=`bootout`, `restart`=`kickstart -k` (тот же паттерн, что `pult_web_restart`). Только launchd (`control="full"`); MCP (`status_only`) → отказ `{ok: False, refused: True, error}` («управляется MCP-хостом»), команда не выполняется. Мутация журналируется. |
| `pult_events(note_id=None, source_hash=None, recent=False, limit=50, stage=None)` | `eventlog.artifact_timeline` / `eventlog.recent_events` | `[{event_id, ts, note_id, source_hash, path, stage, status, detail, run_id}]` — сквозной лог стадий пайплайна (PULT-EVENTLOG): по каждому идущему через пайплайн артефакту стадия (`ingest`→`hub`→`index`→`link`) пишет событие по `note_id` (ingest несёт ещё `source_hash` — сшивка файл→заметка). `note_id`/`source_hash` → **таймлайн артефакта** по времени (`source_hash` резолвится в `note_id` через ingest-событие); иначе → **свежая лента** (новые сверху, фильтр `stage`, `limit`). НЕ путать с `pult_kpi` (агрегатная аналитика); тут per-artifact lifecycle из таблицы `events` (`dt.db`, миграция v2). `detail` — только метаданные стадии (counts/статусы/пути), без тела/сумм. Полный reindex → одно run-событие (не по-заметочно). Read-only. |
| `pult_ingest_sources()` | `operational.storage.ingest_sources` | `[{key, kind: operational\|knowledge\|legacy\|mail\|capture, label, op, adapter, path?/roots?, exists, include?, exclude?, last_ingest, refused_7d, refused_last}]` (INGRESS-1: `adapter` - ключ адаптера входа; `refused_7d` - `{причина: n}` за 7 дн по адаптеру (корни одного маршрута повторяют его цифры), `null` - журнал отказов не прочитался; `refused_last` - до 20 последних отказов с hint и, у почтового шума, `rule` - именем сработавшего правила `_system/mail-filter.yaml`) — источники ingest для панели «Хранилище» (PULT-STORAGE): сконфигурированные ingest-roots + legacy/mail/capture. `op` — JOB-1 op источника; запуск = `submit_job(op, {"mode": "light"\|"full", "root"?})` (light=dry-run превью, full=apply); пачкой = несколько submit. Прогресс/cancel — панель заданий (Движок). Read-only Файловые источники (знаниевые корни, легаси) несут `ocr: {pending, done, low, refused}` (OCR-1; из манифеста ingest; `null` - манифест не прочитался). **MAIL-PRIVACY-2:** `refused_7d.privacy_probe` (адаптер `mail`) - письма, снятые пробой приватности; в `refused_last` у такой строки `rule` = класс правила (`privacy-name\|privacy-term\|privacy-contract`), `hint` = `inbox\|sent · дата`, `source_id` - id письма; темы, участников и фамилии там нет. |
| `pult_ingest_trace(query=None, root=None, limit=20)` | `file_ingest.trace.ingest_trace` | `{ok, query, root, limit, total, shown, rows, counts, index_as_of, hint}`, строка — `{source_path, root, corpus, note_path, ingested_at, ingested_from, modified_at, doc_date, indexed, index_age, status, chunks, size}` — файловая трасса инжеста «файл → заметка → индекс» (INGEST-VIS-1). Отвечает на то, что агрегаты «Источников» не закрывают: **мой файл X попал в vault и в индекс?** **Никакого нового стейта**: read-only джойн уже существующих манифестов (`current`/`legacy` ingest + `index_manifest`) — ни сканов деревьев, ни сети; обращения к ФС — только по отфильтрованным строкам: `stat` заметки и чтение её «головы» (≤4 КБ) у строк выдачи. **TRACE-FIX-1 — три разные даты, каждая под своим именем:** `ingested_at` — когда инжест ЗАПИСАЛ заметку (`st_birthtime` файла; линковка двигает mtime, а birthtime нет — раньше поле «инжест» омолаживалось после каждого разбора связей), `ingested_from` = `birthtime`|`mtime` (при откате на mtime UI подписывает строку «изменена», а не «инжест»), `modified_at` — mtime (по нему же считается «заметку тронули позже индекса»), `doc_date` — `created:` из frontmatter, то есть дата ИСХОДНОГО документа (легаси-рендер пишет туда mtime источника: у записки 2023 года там 2023-01-09, хотя в vault она легла в 2026-м). `query` — подстрока по пути источника ИЛИ заметки (регистронезависимо, кириллица как есть); `root` — фильтр по корню/корпусу; `limit` — дефолт 20, потолок 200; сортировка — новые сверху. `status` честный по факту: `indexed` / `waiting_index` (ждёт ближайшего reindex) / `nda` (под NDA-барьером — в индекс не попадёт **by design**, «ждёт» было бы ложью) / `note_missing` (заметку удалили с диска) / `duplicate` (несколько источников свёрнуты дедупом в одну заметку). Пустой результат тоже ответ: `hint` объясняет, где искать причину (скан не видел / отфильтровано include-exclude / дубль). Живой замер: джойн 6,8k×12,8k записей — ~0,2 с без фильтра, ~0,08 с с запросом. Read-only, **не** в WRITE_TOOLS. |
| `pult_storage_status(refresh=False)` | `operational.storage.storage_status` (реюз diagnostics) | `{db: {schema_version, facts, sources, jobs, events, exists}, nda: {markers, sources_flagged, facts_flagged}, dedup: {with_hash, total, coverage_pct}, eventlog: {ingest, hub, index, link, total}, lance, as_of, cached}` — **из снимка** (PULT-SURFACE-2: скан NDA-следов и LanceDB ~6 с; TTL `DT_PULT_STORAGE_TTL_S`=900 с, `refresh=true` считает, `pult_storage_action` сбрасывает снимок) — здоровье хранилища одним вызовом: DB-1 (схема+счётчики), NDA-1 (маркеры + сколько NDA-следов в derived), INGEST-DEDUP (byte-hash coverage), PULT-EVENTLOG (события по стадиям). Каждый блок при сбое → `{error}`. Read-only |
| `pult_storage_action(action, confirm=False)` | `operational.storage.storage_action` | `{action, ...}` — действие над хранилищем (PULT-STORAGE), деструктив за подтверждением. `rebuild-db` (снести `dt.db`+WAL/SHM → пересоберётся) / `purge-nda` (удалить NDA-следы из derived) **без `confirm`** → read-only **превью** (что удалит; ничего не трогает); **с `confirm=True`** → выполняет + `record_action` (аудит). `backfill-hashes` (INGEST-DEDUP) → долгое, уходит в JOB-1 (`{job_id, op, state}`). vault-контент не трогается. |
| `pult_paths_get()` | `operational.storage.paths_get` | `{roots: [{name, path, route, include, exclude, note_type, entity_hint}], legacy_roots: [str], roots_yaml, editable}` — корни ingest (`ingest-roots.yaml`, resolved per-device) + `DT_LEGACY_ROOTS` для редактора путей. `editable` — сконфигурирован ли веб-токен (без него только просмотр). Read-only |
| `pult_paths_set(roots=None, legacy_roots=None, token=None)` | `operational.storage.paths_set` | `{ok, roots_written?, roots_yaml?, legacy_written?, warnings}` — запись конфига путей (PULT-STORAGE) **за веб-токеном** (`token` = `DT_WEB_TOKEN`/`.secrets/web_token`; не совпал/не задан → `{ok: False, refused: True, error}`). `roots` → валидация схемы (name/`route`∈{operational,knowledge}/globs; невалидное → отказ) + запись `_system/ingest-roots.yaml` с `.bak`; несуществующий путь → warning, не отказ. `legacy_roots` → правит **только** `DT_LEGACY_ROOTS` в `engine/.env` (прочие ключи/комментарии целы, `.env.bak`). `record_action`; в vault-контент не пишет. |
| `pult_settings_get()` | `operational.ai_layer.get_settings` | `{ai: {profiles: {имя: {provider, url, model, timeout_s, max_chars, max_calls_per_hour, key: {configured, tail, file, mode_ok}}}, routes: {triage\|synth\|draft: профиль\|host\|none}, classes: {класс: [виды]}, sides: {класс: none\|host\|daemon}, sends_data_out: {класс: bool}, route_errors, legacy_flat}, providers, editable, last_call}` — настройки слоя ИИ-синтезов (`_system/pult.yaml`, PULT-STANDALONE-1, GATEWAY-1: профили моделей и маршруты «класс задачи → профиль»). Плоский `ai:` читается как профиль `default` + маршруты на него (`legacy_flat: true`, файл не меняется до `dt ai migrate`). Ключ профиля - только статус (хвост 4 символа). Read-only. Профили `pult`/`full` |
| `pult_settings_set(section, values)` | `operational.ai_layer.save_settings` | `{ok, ai, providers, editable, last_call}` или `{ok:false, refused:true, code, error}` — правка `routes.<класс>` (профиль\|`host`\|`none`), `profiles.<имя>.<поле>` (`provider`/`url`/`model`/`timeout_s`/`max_chars`/`max_calls_per_hour`; профиля нет - создается), `profiles.<имя>: null` (удалить) и плоских полей на профиль `default` (совместимость) с валидацией (`unknown_class`, `unknown_profile`, `profile_in_use`, `bad_profile_name`, `bad_provider`, `bad_url`, `url_insecure`, `model_required`...). Ключ и `key_file` НЕ принимаются (`key_not_here`: `dt ai set-key --profile`). Запись конфига, `WRITE_TOOLS`, аудит `pult_settings_set` (имена полей) |
| `pult_ai(kind, payload)` | `operational.ai_layer.synthesize` | `{ok, kind, class, route, profile, text, provider, model, cached, ms, code?}` — ИИ-синтез пульта пяти видов (вид → класс: `brief`/`lane` - `triage`, `hub_synth`/`hub_lint` - `synth`, `draft` - `draft`; профиль модели - по маршруту класса, лимит вызовов и кэш - по профилю) с фиксированными шаблонами: `brief` (`{brief, summary}` -> 2-3 фразы), `lane` (`{text, suggested_lane}` -> `LANE\|причина`), `draft` (`{prompt}` -> текст), `hub_synth` (HUB-SYNTH-1, `{hub_id}` -> промпт досье `hub_synth_context` -> провайдер -> ТЕ ЖЕ проверки и карточка `synth`, что у `hub_synth_propose`; ответ несет `proposal.card_id`, отказ проверки - `ok:false` + `code` `ungrounded`/`too_long`/… и текст провайдера в `text`; пользователь пульта - одно поле `hub_id` и кнопка в «Двойнике»), `hub_lint` (KNOWLEDGE-LINT-1, `{hub_id}` -> промпт досье `hub_synth_context` с заданием «назови утверждения состояния, которые дельта опровергает» -> провайдер -> строки `- утверждение [локатор]`, локатор ⊆ `locators` досье, иначе строка отброшена -> находки правила `claim` в карточки `lint`; ответ несет `findings: [{id, claim, locators, state}]`, `dropped`; отказы `no_state`/`no_delta`/`unsupported_entity`/`hub_not_found`; без провайдера `ai_disabled`, остальной линт работает). Вызов делает демон по `pult.yaml: ai` (`openai`/`anthropic`; `none`/`host` -> `ok:false, code: ai_disabled\|ai_host_side`, сети нет). Кэш на день, потолок 120 вызовов в час, отказ провайдера -> `{ok:false, code, text:null}`. Аудит `ai_synthesis` без текста и ключа. Не `WRITE_TOOLS`; профили `pult`/`full`, не `lean` |
| `pult_eval(points=14)` | `eval_status.eval_status` | `{last: {ts, metrics, groups, stale, verified, hypotheses, age_days}, prev, delta: {recall5, hub3, mrr}, delta_basis, red, red_text, history: [{ts, recall5, hub3, mrr, control_recall5}], misses: [{id, type, label, group, top[:3]}], misses_total, by_type: [{type, n, metrics, delta, delta_known}] (EVAL-4: срез последнего прогона по типам запросов; Δ к прошлому прогону только при том же составе типа; диагностика, на `red` не влияет), stale_ids, candidates_pending, canon_age_days, outdated}` — плитка «Качество выдачи» пульта (EVAL-3): сводка из `.derived/eval/history.jsonl` (пишут `dt_eval`, смоук С-10 и ночной шаг `eval` цепочки index), без поиска, < 50 мс. Дельта — к прошлому прогону (`delta_basis`: `all` — набор тот же, `work` — сменилась контрольная, сравнили рабочую; иначе `null`); промахи — не попавшие и не stale, формулировки из канона (история текстов запросов не хранит); `outdated` — прогон старше 2 дн. Пустая история → `last: null` + конверт `no_runs`; канон не читается → `store_unavailable`. Read-only |
| `work_feed()` | `operational.work.snapshot` | `{now, brief: {text, items: [{kind, title, ref}], as_of}, attention: [{type, title, deal?, due?, days_overdue?/days_until?/silent_days?}], stale: [{entity_type, code, title, subtitle, last_activity, silent_days, cool}], deltas: [{type, title, subtitle, when}], counts: {deals_active, presales, tasks_overdue, tasks_due_week, unanswered_mail}}` — рабочий кокпит (WORK-1/WORK-2): «горит» / «остывает» / «изменилось» из зеркал Timetta + манифеста почты; тишина по `modified`/`last_date` (не mtime vault); no amounts/probability; read-only, no network. PULT-STANDALONE-1: `brief` - детерминированный бриф (2-4 предложения: счетчики; главное внимание до 3 пунктов `просрочено > срок сегодня/завтра > письмо без ответа > остальное`; дельты; коллеги ORBIT-3; пусто - «Событий нет»), `items` = чипы под текстом; база пульта без модели |
| `work_resurface(limit=10)` | `operational.resurface.resurfaced` | `{now, window_days, old_days, total, pairs}`, пара — `{id, new_note:{id,title,path}, old_note:{…}, resolver, score, rationale, when, as_of, new_age_days, old_age_days}` — resurfacing по связям (DEV-1d): «новое легло рядом с тем, что ты знал». Пара к «Забытым темам» (те показывают, что тихо умирает, этот — что всплыло). Берёт применённые за `DT_RESURFACE_DAYS` (7) связи, где источник — свежая заметка, а цель старше `DT_RESURFACE_OLD_DAYS` (30). **Нового стейта нет**: джойн `link_applied.jsonl` (что с чем связали) × журнала стадий `stage=link` (когда — только он даёт время) × индекс-манифеста (`note_id` → путь). Дедуп по паре, потолок 10. Превью — `work_note_preview`; убрать/отложить — `work_dismiss` (тот же серверный стор, что у «Внимания»). Read-only, без сети/LLM. |
| `work_dismiss(item_id, action, as_of, until_days)` | `operational.work.record_dismissal` | `{ok, item_id, action, until?}` — снять/отложить пункт «Работы» (WORK-3): `snooze` (на `until_days`, дефолт 7), `ack`/`dismiss`/`done` (до нового события — фиксирует `as_of` пункта из `work_feed`), `clear` (undo). RMW `.derived/operational/work_dismissals.json`; resurfacing при новом `as_of`; без сети |
| `work_context(item_id)` | `operational.work.context` (+ комментарии ORBIT-3) | `{type, title, lines: […], deal_guid?, changes?[], comments?[{at, author, text}]}` — инлайн-сводка по пункту фида (WORK-4): сделка/проект/issue из зеркала (стадия, менеджер, клиент, чек-лист, связанные задачи), письмо из манифеста+сайдкара (контрагенты, кол-во сообщений, направление последнего). Read-only, без сети/LLM, без сумм |
| `work_note_preview(name)` | `operational.work.note_preview` | `{name, found, title, preview}` — заголовок + ~320 символов тела заметки vault по slug (frontmatter/«## Связано» срезаны). Для раскрытия «о чём» источника/цели у link-предложений. Read-only, без сети/LLM | **NOTE-ID-1:** та же единая точка резолва (путь | имя файла | frontmatter `id`; легаси-форма `legacy-<hash>` → `*-<hash[:8]>.md` цела) — превью в линк-карточках пульта больше не пишет «заметка не найдена в vault» при живой заметке с id ≠ именем файла.
| `work_meetings(days=7)` | `operational.meetings.cached` | `{available:true, status, now, days, window_days, data_as_of, stale, reason?, meetings: [{entryID, subject, start, end, location, all_day, attendees, counterparty_domains, external, clients}]}` — предстоящие встречи **из кэша-снапшота** `.derived/meetings/cache.json` (PERF-3): рендерит мгновенно, НЕ бьёт Outlook-мост на каждом рендере (был синхронный ~31с live-read). `status` ∈ `ok`/`unavailable`/`no_cache`; `data_as_of`/`stale` — «данные на момент X». Снапшот обновляет `meetings.refresh` — планово (launchd `com.dt.meetings`) и по кнопке (`submit_job outlook_read mode=meetings`). Нет кэша → `status:"no_cache"`, `meetings:[]` (мягко «нет данных, обновите», не live-read) |
| `work_ticktick(days=14)` | `operational.ticktick_tasks.attention` | `{available, now, days, tasks: [{id, title, list, due, silent_days, type, as_of, url?}]}` — висящие «свои» задачи из curated capture-листа `DT.Захват` (WORK-ATTN-TICKTICK + FIX-1) для «Требует внимания»: живой опрос ТОЛЬКО capture-проекта (`config.ticktick_capture_project`; скан всех списков убран — заваливал ленту мёртвыми личными списками 2018–2023), как `work_meetings`, `work_feed` offline и не трогается. Open-задачи overdue (`dueDate` в прошлом) / stale (без движения `days` дней по `modifiedTime`, порог = `work.STALE_MIN_DAYS` — незатриаженный захват), `type` ∈ `task_overdue`/`task_stale`. Дедуп по маркеру `⟦tt:…⟧` (в capture-листе зеркал нет — no-op). Снуз/ack — `work_dismiss` с id `ticktick:<taskId>`. Read-only; privacy — только title/list/due/silent_days; нет токена / capture-проект не сконфигурирован → `{available: False, tasks: []}` |
| `work_meeting_prep(subject, counterparty_domains=[], client_ids=[], entity_id=None)` | `operational.meeting_prep.prepare` | `{generated_at, meeting:{subject, domains}, clients: [{id, name, deals:[{code, name, stage, open_items, nearest_due, last_activity}], other_deals, recent_mail:[{subject, date, from, direction}], notes:[{note_id, title, path}], entity?:{kind, id, name}}], unresolved_domains, entities, entity_candidates, needs_clarification}` — досье к встрече (DEV-1b): активные сделки/стадии/открытые/дедлайны из зеркала + недавняя внешняя переписка + релевантные заметки (`find_notes`). Релевантность: переписка приписывается клиенту только по домену/counterparty встречи (FIX-1); ретривал и порядок сделок ведёт различимый термин темы, прочие сделки → `other_deals` (FIX-2); `entity_id` скоупит досье к сделке/проекту/хабу, неоднозначно → `needs_clarification` + `entity_candidates` (FIX-3). Аргументы приходят из `work_meetings`. Read-only, без сети/LLM, без сумм/вероятностей |
| `pult_web_status()` | (server.py, subprocess+socket; launchd-статус через `operational.services`) | `{server_running, port, funnel_on, public_url, launchd_loaded}` — статус веб-пульта (PULT-WEB): слушает ли HTTP-сервер, включён ли Tailscale Funnel (+ публичный URL), загружен ли launchd-джоб `com.dt.webpult` (свёрнуто в единый service-DAO, контракт не изменился). macOS; read-only |
| `pult_web_restart()` | `operational.services.service_control("webpult", "restart")` | `{ok, error?}` — перезапуск веб-пульта через launchd (`kickstart -k`, свёрнуто в единый service-DAO; требует установленного джоба). С телефона связь на пару секунд прервётся |
| `pult_deals(client=None, rings=None, refresh=False)` | `operational.hub_link.deals_for_picker` | `[{guid, code, name, stage, client, linked_hub}]` — сделки локального зеркала Timetta для пикера «связать с CRM» (HUB-DEAL-LINK): `stage` = стадия, `client` = имя организации, `linked_hub` = id хаба, чей frontmatter уже указывает `timetta_id` на эту сделку (иначе `null`). `client` (опц.) — подстрочный фильтр по имени/коду организации. Свободные раньше связанных, затем по свежести. Суммы/вероятность НЕ выдаются. Read-only, **без сети** (Path B) |
| `pult_function(rings=None, limit=50)` | `operational.function_view.function_view` | `{now, rings, counts, funnel[], leaders[], idle{}, no_legal_entity{}, recent{total, items[], summary}}` — виджет «Функция» (ORBIT-3): воронка стадий × кольцо × ведущий, «давно без движения» по всем кольцам, сделки без юрлица, последние изменения коллег (автор + суть, `source`: `history`\|`snapshot`). Без сумм. `rings=None` = все включённые в `DT_ORBIT_RINGS`; неизвестное кольцо → `{ok:false, code:"bad_rings"}`. Read-only, без сети |
| `pult_watch(deal_guid, action="add")` | `operational.watchlist` | `{ok, changed, deal, ring}` — «следить» за сделкой кольца 2/3 (ORBIT-3): для внимания как кольцо 1, **без права записи** (гейт `DT_ORBIT_WRITE_RINGS` прежний). `action`: `add`\|`remove`\|`list`. Персистентно (`watchlist.json`), исчезнувшая сделка снимается сверкой. Отказы — конверт: `item_not_found`/`deal_deleted`/`skipped` (сделка уже «моя»). Только локальная запись (аудит `record_action`) |
| `pult_hub_link_deal(hub_id, deal_guid)` | `operational.hub_link.link_hub_to_deal` | `{ok, hub_id, deal:{code, name}, timetta_id, changed, path}` — связать vault-хаб с СУЩЕСТВУЮЩЕЙ сделкой Timetta: валидирует `deal_guid` в зеркале, хирургически пишет `timetta_id` во frontmatter хаба (остальное байт-в-байт), обновляет crosswalk (vault↔Guid). **В Timetta ничего не пишет** (нет сетевых вызовов). Идемпотентно; операционный контекст подтянется сам по `timetta_id`. Отказ (нет guid/хаба, путь вне vault) → `{ok:false, refused, error}`; audited |
| `pult_hub_unlink_deal(hub_id)` | `operational.hub_link.unlink_hub_from_deal` | `{ok, hub_id, changed, previous}` — снять связь: обнулить `timetta_id` во frontmatter + убрать `vault_id` из crosswalk (хаб снова «дозревший лид»). Только vault, в Timetta не пишет. Идемпотентно; отказ → `{ok:false, refused, error}`; audited |
| `hub_synth_context(hub_id, since=None)` | `operational.hub_synth.context` | HUB-SYNTH-1: досье «Состояние хаба на дату» (только хабы-клиенты, read-only, без LLM) - `{hub: {id, title, entity, aliases, current_state: {text, as_of, source: synth\|manual} \| null, synth_at, path}, since, since_source: param\|synth_at\|default, as_of, delta: {deals, mail, outputs, notes, files, facts}, locators, current_refs, prompt, limits: {budget_chars, used_chars, truncated, dropped, counts, undated_skipped, max_chars}, warning?}`. У КАЖДОГО элемента дельты поле `loc` - локатор (`note_id` / путь файла-источника / `deal:<код>` / ключ треда `conv:…` / путь выхода `07-outputs/…`), дата и 1-2 строки сути (почта - тема + последний входящий, не тело); сделки без сумм и вероятностей; NDA-пути (`core.privacy.any_nda`) не попадают, почта прошла приватность на инжесте. `since`: параметр, иначе `synth_at` из frontmatter, иначе 90 дней. Бюджет `DT_SYNTH_CONTEXT_CHARS` (40 000) режет дельту поровну по видам, новое первым - честный `limits.truncated`/`dropped`. `prompt` - текст для модели СЕССИИ: `[System]` + `[Owner]` + `[Style guide]` (канон `ai-markers`) + `[Current state]` + `[Delta]` + `[Task]` (секция «## Состояние (на ДД.ММ.ГГГГ)», 5-12 пунктов с локатором в `[скобках]`, «Не покрыто: …», устаревшее - пометить). `current_state.source: manual` - ручная секция К. «## Текущее взаимодействие (на …)», пока синтеза нет; ссылки из нее (`legacy-…`, `conv:…`, пути в бэктиках) разрешены как локаторы (`current_refs`). Хаб без `timetta_id` и доменов - конверт `warning` (`partial`); нет новых элементов - тоже. Отказ: `{ok: false, refused: true, code: hub_not_found\|unsupported_entity\|bad_since, error}`. Профили `lean`/`pult`/`full`; не `WRITE_TOOLS` |
| `hub_synth_propose(hub_id, text, sources=None, covered_until=None, since=None)` | `operational.hub_synth.propose` | HUB-SYNTH-1: написанную сессией секцию - карточкой `synth` на решение К. Проверки ДО очереди: пусто/длина `<= DT_SYNTH_MAX_CHARS` (6 000, `too_long`), нет путей с NDA-маркером (`privacy`), стоп по хабу после отказа `DT_SYNTH_SNOOZE_DAYS` (14) (`snoozed`, `until`), у КАЖДОГО пункта (строка основной части, не «Не покрыто:») >= 1 локатор в одиночных `[скобках]` и все локаторы ⊆ `locators` досье (`ungrounded` + `items` - номера пунктов без локатора, `foreign` - `[{item, locator}]`), `sources` ⊆ локаторов (`bad_sources`), `covered_until` - дата (`bad_covered_until`). Канон ИИ-маркеров - предупреждение `style_markers` (текст принят). Досье пересобирается тем же `context` (`since` - как при сборке досье). Стор `.derived/hub_synth.jsonl` (`{id, hub_id, text, sources, covered_until, created, host, model, status: pending\|applied\|rejected\|snoozed, diff: {added, changed, removed, lines}, uncovered, items, source_meta, style}`); прежняя неснятая карточка того же хаба заменяется новой (`replaced`). Возврат `{ok, card_id: "synth:<id>", hub_id, items, sources, diff: {added, changed, removed}, uncovered, covered_until, next, replaced?, warning?, style_markers?}`; отказ - `{ok: false, refused: true, code, error, …}`, аудит `hub_synth_propose` (id, счетчики, длина - без текста). **В хаб НИЧЕГО не пишет** - запись только approve карточки; не `WRITE_TOOLS` (пишет лишь `.derived`). Профили `pult`/`full`, не `lean` |
| `pult_ripe_leads()` | `operational.ripe_leads.ripe_leads` | `{now, leads:[{id, name, entity, status, presale, track, client, notes, …, ripe, reasons}], counts, elapsed_ms}` — vault-хабы-лиды (`entity ∈ {project, deal}`) без пары в Timetta + сигналы зрелости. `track` (`presale`\|`project`\|`internal`) берётся из **явного поля `track:`** во frontmatter (приоритет), иначе двузначная эвристика (`status`/тег `presale`; `project` — только явным полем). Сменить классификацию — одной строкой `track:` во frontmatter или кнопкой `pult_set_track`. Read-only, без сети |
| `pult_set_track(hub_id, track)` | `operational.hub_link.set_track` | `{ok, hub_id, track, previous, changed, path}` — сменить трек хаба (`track ∈ {presale, project, internal}`): хирургически пишет `track:` во frontmatter (остальное байт-в-байт), идемпотентно, только vault (в CRM ничего). Меняет ярлык/классификацию карточки в «Дозрели». Отказ (невалидный `track` / нет хаба / путь вне vault) → `{ok:false, refused, error}`; audited |

**`resolve` / `generate` - причина вместо молчания (HUB-ALIAS-1 п.4).** Кейс требует клиента (слайсы его политики
ждут `{client_id}`), а `client_id` не распознан → конверт `client_unresolved` (`reason`: «клиент не распознан: назови
client_id или добавь имя в aliases хаба», `mentioned` - слово текста, похожее по префиксу на имя клиентского хаба,
`skipped` - пропущенные слайсы) рядом с `blocked`. Узел плана `present` при пустых собранных данных и той же категории в
`missing` понижается до `partial` + конверт `plan_inconsistent` (`nodes`); блок гейта не ослабляется.

Privileged pult calls (`pult_card_decide`, `pult_hub_link_deal`, `pult_hub_unlink_deal`, `pult_set_track`,
`pult_run_sync`,
`pult_service_control` — incl. the `status_only` refusal — and PULT-STORAGE
`pult_storage_action` / `pult_paths_set`, incl. their confirm/token refusals)
append an audit line — timestamp, tool, argument ids (never content), outcome — to
`.derived/logs/pult-actions.log`.

BGE-M3 and LanceDB load lazily from the local cache (offline) — the **first**
`reindex`/`retrieve`/`generate` call is slow. A long op that would outlast the
client's per-tool ceiling (a full `reindex`, a heavy Outlook read, a big-file
`lift`) can be run **asynchronously** via `submit_job` (or `reindex(async_=True)` /
`lift_source(async_=True)`): it returns a `job_id` immediately and the chat polls
`job_status` (JOB-1). The CLI twin is `cli/dt_job.py` (`submit`/`status`/`list`/
`cancel`); the detached worker is `cli/dt_job_worker.py`.

**Unified DB (DB-1).** Facts, the SRC-1 source registry, and JOB-1 jobs live in a
single `.derived/dt.db` (SQLite, WAL) with one schema version and one migration
framework (`core/db/`). On first open after the update, the pre-DB-1 stores
(`.derived/facts.db`, `.derived/jobs.db`, `.derived/sources/index.json`) are
imported once and renamed `.bak` — nothing is lost, re-runs don't re-import. It's
fully derivable: **rebuild** by deleting `.derived/dt.db` (+ `-wal`/`-shm`) and
reopening — facts re-extract on demand, sources re-register on lift/`dt_ingest`,
jobs are ephemeral. `dt doctor` shows the schema version and per-table counts.

## Слой ИИ-синтезов: профили и маршруты (раздел `ai`, GATEWAY-1)

`pult_ai` и `hub_synth`/`hub_lint` делает один слой (`core/operational/ai_layer.py`); какая модель пишет, решает
шлюз (`core/operational/ai_gateway.py`): **класс задачи → профиль модели**. Классы: `triage` (`brief`, `lane`),
`synth` (`hub_synth`, `hub_lint`), `draft` (`draft`); таблица вид → класс одна, новый вид обязан объявить класс.
**Профиль** - именованный набор (`provider`, `url`, `model`, `key_file`, `timeout_s`, `max_chars`,
`max_calls_per_hour`); имена свободные. **Маршрут** класса - имя профиля, `host` (синтез делает модель хоста,
`askClaude`) или `none` (база движка). Раздел `ai` файла `vault/_system/pult.yaml`; пример «cheap = openai-совместимый
Moonshot, strong = anthropic, local = Ollama на localhost»:

```yaml
ai:
  profiles:
    cheap:  {provider: openai,    url: https://api.moonshot.ai/v1, model: <имя из кабинета>}
    strong: {provider: anthropic, model: <имя модели>}            # url по умолчанию api.anthropic.com
    local:  {provider: openai,    url: http://localhost:11434/v1, model: <имя загруженной модели>}
  routes: {triage: cheap, synth: strong, draft: host}             # профиль | host | none
```

Имен моделей в коде нет: только в этом конфиге. Ключ профиля - файл `.secrets/pult_ai_key-<имя>` (профиль
`default` - прежний `pult_ai_key`), права 600; в `pult.yaml`, ответах, аудите, логах и браузере его нет (видны
4 последних символа). Лимит вызовов (`DT_AI_MAX_CALLS_PER_HOUR`, 120 - дефолт профиля, свой -
`max_calls_per_hour`) и кэш дня считаются **по профилю**: исчерпанный `cheap` не мешает `strong`. Данные уходят
наружу, только если маршрут ведет на профиль `openai|anthropic` с нелокальным url - `sends_data_out` по классам.
Плоская форма PULT-STANDALONE-1 (`ai: {provider, url, model}`) читается как профиль `default` + все маршруты на
него; файл не меняется до `dt ai migrate` (бэкап `pult.yaml.bak-*` рядом) или первой записи настроек. Правка:
`pult_settings_set("ai", {"routes.triage": "cheap", "profiles.cheap.model": "..."})`, `dt ai set route/profile`,
раздел «ИИ-синтезы» в Настройках пульта; доктор «ИИ-шлюз» - маршрут и состояние профиля по классам.
Путь B не меняется: артефакты пишет хост, `core` вне слоя синтезов LLM не зовет (гард-тест
`tests/test_ai_gateway.py`).

## Очередь решений (QUEUE-SERVER-1)

Решение человека - КАРТОЧКА реестра `core/decisions`: вид умеет отдать свои карточки единой формы, принять решение
`(id, action, params)` и объяснить «почему». Каждый вид - фасад над своим готовым ядром (ядра решений, `scaffold_hub`
и сторы не менялись); единого стора очереди нет. Три инструмента (`pult_cards`, `pult_card_decide`,
`pult_card_explain`) заменили шестнадцать: **с SURFACE-HYGIENE-1 (31.10) старые сняты совсем**, `pult_cards` /
`pult_card_decide` - единственная очередь. Снятые имена (`list_link_proposals`, `pult_link_decide`,
`list_reattr_proposals`, `pult_reattr_decide`, `pult_untriaged`, `pult_route`, `pult_assignments`,
`pult_assignment_decide`, `pult_hub_candidates`, `pult_hub_decide`, `pult_hub_alias_candidates`,
`pult_hub_alias_decide`, `pult_golden_candidates`, `pult_golden_decide`, `pult_ripe_snooze`,
`pult_ripe_reject`) в гарде `retired` (`test_no_timetta_write`) и не переиспользуются; скиллы
`capture-to-assignment`/`operational-review` зовут `pult_cards(kinds=["assignment"])` /
`pult_card_decide`, черновик под выбранную сделку - `pult_card_explain(card_id, params={deal_guid})`.
Новые инструменты - в профилях `pult`/`full`, не в `lean`.

**Свои алиасы (п.9).** У `approve` вида `alias` второй параметр `extra: {type: "text", placeholder: "свои варианты через
запятую", required: false}`; `required: true` у `aliases` снимается при непустом `extra` (клиент - `_qCollect`, сервер -
`decide_hub_alias`): карточка без отмеченных предложений, но со своими вариантами валидна (пустое и то и другое -
отказ `invalid_params`). Варианты: trim, дедуп без регистра, ≤ 48 символов; вариант,
совпавший с именем/алиасом ДРУГОГО хаба или с названием самого хаба, - отказ с именем варианта, ничего не пишется.
В `effects`: «свои: СУПР»; в аудите - `extra_count` (без текстов). Записанный свой алиас попадает в каталог имен хаба
(`source: alias`), детектор его больше не предлагает.

**Снимки видов (п.3).** Выдача `hub`/`alias`/`link` кэшируется тем же `core.operational.snapshot.cached_read`, что в
PULT-SURFACE-2 (ключ `cards-<вид>-<limit>`, TTL `DT_PULT_CARDS_TTL_S`, токен свежести - mtime/размер сторов и каталога
хабов); `pult_card_decide` сбрасывает снимок вида. `timings`/`as_of_kinds` в ответе - как у `gold`. В `pult_monitor`
блоки `freshness` и `services` - снимок на `DT_PULT_MONITOR_TTL_S` (60 с); `pult_service_control` сбрасывает статус.

**Карточка:** `{id: "<вид>:<id>", kind, title, reason, since, meta, actions: [{action, label, style: primary|secondary|danger,
params: {имя: {type: select|multiselect|text, options?, default?, required?, ui?, more?, label?, allow_custom?}}, confirm?, more?}],
explainable}`. Пульт рисует кнопки и их параметры ИЗ `actions` (`select`, `multiselect`, `ui: "buttons"` - по кнопке на вариант,
`more` - в раскрытие «ещё…», `allow_custom` - можно ввести свое значение), подтверждение - из `confirm`.

**Исход:** `{ok, outcome: applied|rejected|snoozed|routed|stale|refused, code?, detail, effects: [...], card_id, kind, action}`.
`effects` - что реально сделано («хаб создан <путь>», «timetta_id записан», «ссылка вставлена»); `stale` - уже решено (не
ошибка); `refused` - ничего не записано, `code`: `unknown_card` | `bad_action` | `invalid_params` | `no_deal` |
`hub_already_linked` | `link_failed` | `apply_failed` | код ядра.

| Вид | Ядро | Действия (`params`) | `meta` |
|---|---|---|---|
| `assignment` | `operational.assignment` | `sent` (`deal_guid`), `reject` | `deal`, `candidates`, `formulation`, `subject`, `body`, `mailto`, `admin_email` |
| `untriaged` | `ticktick.capture.route_capture` | `route` (`lane`: knowledge\|assignment\|drop\|task) | `text`, `tags`, `suggested_lane`, `suggested_reason` |
| `hub` | `linking.hub_candidates` + `operational.hub_link` | `approve` (`entity`), `link` (`hub_id`, только для кандидата от сделки Timetta), `reject` | `entity_guess`, `signals`, `ring` (`{ring, leader}` - кольцо и ведущий сделки-источника), `deal`, `similar_hubs` (до 3, из `hub_catalog`, с долей) |
| `alias` | `linking.hub_aliases` | `approve` (`aliases`: отмеченные предложения; `extra`: `text` - СВОИ варианты через запятую, SURFACE-HYGIENE-1 п.9), `reject`, `snooze` | `hub_id`, `title`, `aliases`, `suggestions` |
| `synth` | `operational.hub_synth` (HUB-SYNTH-1) | `approve` (`confirm`: «прежняя секция уйдет в Архив состояний»), `reject` (`reason`: text; стоп по хабу `DT_SYNTH_SNOOZE_DAYS`), `snooze` (`days`: 3\|7\|14) | `hub_id`, `title`, `text`, `diff` (`added`/`changed`/`removed` + `lines: [{op: +\|-, text}]`), `uncovered`, `sources`, `covered_until`, `current_as_of`, `current_source`, `style`, `host`, `model` |
| `lint` | `lint.actions` (KNOWLEDGE-LINT-1) | по правилу: `fact_conflict` - `keep_a`/`keep_b` (`confirm`), `snooze` (`days`: 3\|7\|14), `dismiss` (`reason`); `hub_stale` - `synth`, `snooze`, `dismiss`; `orphan` - `attach` (`hub_id`: select из кандидатов, `allow_custom`), `dismiss`; `duplicate` - `mark`, `dismiss`; `claim` - `note`, `dismiss` | `rule`, `rule_label` (чип), `subject`, `evidence` (локаторы), `candidates` (orphan: `{hub_id, title, entity, hits, matched, where}`), поля правила (`fact_key`/`a`/`b`; `hub_id`/`age_days`/`delta`; `newer`/`older`/`via`; `claim`/`locators`) |
| `gold` | `eval_candidates` | `accept` (`expected_ids`), `reject`, `snooze` | `query`, `expected`, `repeats`, `today_rank` |
| `reattr` | `linking.reattr_decide` | `apply`, `reject` | `note_id`, `old_path`, `new_path`, `from_hubs`, `to_hubs` |
| `link` | `linking.decide` | `approve`, `reject` | `source`, `target`, `score`, `target_type` |
| `ripe_lead` | `operational.ripe_leads` | `snooze` (`days`), `reject` | `name`, `track`, `notes`, `reasons` (только лиды СВОИХ сделок: хаб, чье имя совпало с чужой видимой сделкой кольца unit/group, не «слежу», не показывается; в вкладке «Требуют решения» не показывается: своя секция «Дозрели») |

**KNOWLEDGE-LINT-1 (вид `lint`, «Линт знаний»).** Находки четырех детерминированных правил (`fact_conflict`, `hub_stale`,
`orphan`, `duplicate`; шаг `lint` ночной цепочки или `dt lint`) и модельного `claim` (`pult_ai(kind="hub_lint")`) лежат в
`.derived/lint_findings.jsonl` и отдаются карточками: заголовок по правилу («Противоречие фактов? …», «Хаб устарел? …»,
«Заметка без хаба? …», «Дубль? …»), причина с цифрами, `meta.rule` + чип `meta.rule_label`. `explain` -
`why: {rule, why, evidence: [{loc/path/source_path, date, …}], facts?: [{role: А|Б, source, locator, value, valid_from,
known_at}] (fact_conflict), candidates? (orphan), choose?/mark_effect?}`. Запись в vault/стор фактов - ТОЛЬКО действие
карточки, хирургически (`attach` - одно поле frontmatter, `mark` - `duplicate_of` в более новой заметке, `keep_*` -
`valid_to`/`superseded_by` проигравшему факту, `note` - строка под `## Проверить (линт ДАТА)`), аудит `lint_<действие>` и
событие `lint/<правило>_applied`; `synth` без провайдера слоя ИИ - `refused` с `code: ai_disabled|ai_host_side` и
подсказкой про скилл `hub-synth` (ничего не записано). Исходы: `dismiss` -> `rejected` (стоп `DT_LINT_SNOOZE_DAYS`),
`snooze` -> `snoozed`, `synth` -> `routed` (карточка `synth` + находка отложена), `stale` - причина уже снята.

**Конверт `source_not_local` (SRC-ICLOUD-1).** Файл-источник есть, но в iCloud не скачан, а демон launchd его не
материализует: после одной попытки `brctl download` (`DT_ICLOUD_DOWNLOAD_S`, 20 с) `lift_source` отвечает `status:
"not_local"` с `warning: [{code: "source_not_local", reason, path, hint}]`, `get_facts(note_id|source_path)` -
`{facts: [], warning: [{code: "source_not_local", reason, note_id, source_path, path, hint}]}`, `resolve` кладет в
`unresolved[]` запись с `code: "source_not_local"`. Подсказка `hint` - «открыть в Finder или brctl download …». Обычные
файлы, Linux и машины без iCloud - поведение прежнее.

**HUB-SYNTH-1 (вид `synth`, «Состояние хаба?»).** Карточка ставится `hub_synth_propose` (или `pult_ai(kind="hub_synth")`);
заголовок «Состояние хаба? <хаб>», причина «N пунктов · M источников · изменилось K строк» (+ «есть ИИ-маркеры»);
`explain` (`pult_card_explain`) - `why: {hub_id, covered_until, sources: [{locator, kind, title, date}], leaves_current: [строки
нынешней секции, которые уходят], uncovered, diff, status}`. `approve` - ЕДИНСТВЕННАЯ запись текста синтеза в хаб:
`hub_notes.upsert_section` заменяет «## Состояние (на …)» (при первом синтезе - ручную «## Текущее взаимодействие (на …)»
К.), прежняя секция уходит под «## Архив состояний» (`<details>` с датой архивации), `modified`/`synth_at` во frontmatter
обновляются на месте, остальной файл байт-в-байт; подвал секции - `<!-- synth: <дата> · карточка <id> · источников <n> ·
<host/model> -->` и «Источники: [[note_id]], `путь`, `conv:…`». `effects`: «секция записана», «архивирована прежняя
(<дата>)»; аудит `hub_synth_apply` + событие `hub/synth_applied` (без текста). Повтор по закрытой карточке - `stale`.
Автосинтеза по расписанию нет: только по слову К. или кнопке «Двойника».

**HUB-CAND-LINK-1.** `approve` кандидата от сделки Timetta (`sources: timetta:deal:<code>`) создает хаб и затем записывает
`timetta_id` сделки (`link_hub_to_deal`); `effects` перечисляют оба шага. `link` привязывает кандидата к существующему хабу
(`params.hub_id`, пикер - `meta.similar_hubs`) и закрывает его статусом `linked`; хаб, у которого уже стоит другая сделка,
не перезаписывается (`hub_already_linked`). Кандидат без сделки действия `link` не получает. Хаб не создается и `timetta_id`
не пишется иначе как действием человека.

**Аудит и телеметрия - в одном месте** (`registry.decide`): одна строка `pult-actions.log` (`pult_card_decide kind=… id=…
action=… host=… surface=… outcome=…`, без текста карточки) и, если решение состоялось (`applied|rejected|snoozed|routed`),
событие метрик `queue_decision` (`card_kind`, `decision`, `host`); прежние `hub_decision`/`link_decision` ядер сохраняются.
Доктор «Очередь решений»: ждут по видам, принято/отклонено за 30 дн, `warn` при > 100 ждущих или доле принятых < 20% при >= 30
решениях («детектор шумит: <вид>» - замер, не правка детектора).

## Профили инструментов, prompts и конфиги хостов (TOOLS-PROFILES-1)

`tools/list` полного сервера - 81 инструмент, ~120К символов (~40-50К токенов до первого
вопроса): барьер для чужих и локальных моделей. Сервер поднимается в одном из профилей:

| Профиль | Инструментов | `tools/list` | Для кого |
|---|---|---|---|
| `lean` | 12: `parse_task`, `find_notes`, `find_latest`, `read_note`, `get_facts`, `retrieve`, `generate`, `output_begin`, `save_output`, `owner_profile`, `place_download`, `hub_synth_context` | ~36К симв. (~14К с `DT_TOOL_DESC_CHARS=600`; без `place_download` было ~30К/~11К) | Cursor, Kimi, локальные модели; из записи - только контур выхода (`output_begin`, `save_output`, `place_download`) |
| `pult` | 62: `pult_*` (в т.ч. `pult_manifest`), `work_*` + то, что пульт зовет из тела страницы (в т.ч. `hub_synth_context`, `hub_synth_propose`) + `owner_profile` | ~90К | хост, строящий свой пульт |
| `full` (дефолт) | 82 | ~125К | Claude Desktop; артефакт пульта Cowork |

Выбор: `server.py --profile lean|pult|full` или `DT_TOOL_PROFILE` (аргумент приоритетнее;
дефолт `full` - прежний сервер байт в байт). `DT_TOOL_DESC_CHARS=N` мягко усекает описания (по
границе предложения, с «…»; схема аргументов не режется; 0 - как есть). `instructions` одни на все
профили; урезанный профиль добавляет одну строку «Профиль X: N инструментов; остальное - в full».
Реестр - `PROFILES` рядом с `TOOL_NAMES`; гарды полноты/вложенности и `WRITE_TOOLS ∩ lean` -
`tests/test_tool_profiles.py`.

**Prompts.** Скиллы DT живут в git (`engine/skills/<name>/SKILL.md`, 9 штук) и отдаются по
протоколу как MCP `prompts` (`prompts/list`; тело prompt = SKILL.md без YAML-шапки). **Скилл на хосте =
подмножество профиля** (MODEL-1-FIT): публикуется только скилл, чьи вызовы инструментов ⊆ профиля
(`core.skills.fit_profile`), иначе prompt велит модели вызвать то, чего нет в `tools/list`. `full` -
все 9; `pult` - 6 (без скиллов, зовущих инструменты вне профиля); `lean` - 4: generate-artifact,
save-output, text-normalizer, tz-presentation-dt (операционные - capture-to-assignment, hub-synth,
inbox-triage, new-hub, operational-review - поверхность Cowork). `--selftest` сверяет prompts именно с
`fit_profile`. Хост без скилла
получает контракт генерации по протоколу: маршрут `parse_task → retrieve → generate →
save_output` (при `detected=false` - спросить кейс, не перебирать) укладывается в 8 вызовов.
Генератор: `uv run python cli/dt.py skills list|lint|export cowork|kimi|prompts --out DIR` (`export kimi
[--profile lean]` кладет в плагин только скиллы профиля, отброшенные - строкой в выводе и полем
`skipped` манифеста `.dt-skills.json`; `export cowork|prompts` - весь реестр);
линтер переносимости (шапка, нет Claude/Cowork/песочницы, инструменты только из `TOOL_NAMES`)
- гард в pytest. Библиотеку Cowork обновляет человек (`save_skill` из экспорта).

**Конфиги хостов (HOSTS-ATTACH-1).** Хосты подключаются к демону, а не запускают свой `server.py`.
`uv run python cli/dt.py host-config claude|cursor|kimi|cherry|url [--profile lean|pult|full]
[--token read|rw] [--token-placeholder] [--legacy-stdio]` печатает `mcpServers` JSON: `claude` - мост
`cli/dt_shim.py` (команда, токен - в файле `.secrets/web_token_rw`, не в конфиге), `cursor`/`kimi`/`url` -
`{url, headers}` на `http://127.0.0.1:8787/mcp/<профиль>`, `cherry` - то же с `"type": "streamableHttp"`.
`--legacy-stdio` - прежняя форма (`command` = venv python, `server.py --profile …`; с ней же `--sandbox` и
`--desc-chars`). `--verify` читает конфиг хоста и называет вердикт `daemon | stdio-legacy | missing | foreign`;
`--install` пишет ТОЛЬКО член `mcpServers.digital-twin` (байт-точный редактор `core/mcp_json_edit.py`, бэкап
`<файл>.bak-<время>`, повтор - без изменений). Манифест плагина Kimi - `--plugin-manifest` (MCP в нем нет:
плагин = скиллы). Плагин Kimi: `plugins/kimi-work/README.md`; Cherry Studio: `plugins/cherry/README.md`;
порядок установки и разбор расхождений - `docs/ops.md`.

**Два хоста на одном vault (MODEL-1-CLOSE).** Через демон (штатно) процесс один и общий; на stdio-fallback у
каждого хоста свой процесс, vault и `.derived` общие. Имя хоста берется из handshake (`clientInfo.name`) и пишется в `meta.yaml` выхода, в
каждую строку `pult-actions.log` (`host=`) и в телеметрию. При коллизии папки выхода (одинаковый
`title` в один день) второй хост получает суффикс `-<хост>` (`-kimi`, `-claude`), затем счетчик; свою
незакрытую заявку хост переиспользует, чужую - нет. **Штамп прогона и у `generate`-папок**
(MODEL-1-STAMP): `save_output` дописывает в `meta.yaml` `engine_calls` (вызовы этого хоста от
`meta.created` - момента `generate` - до сохранения; контур выхода не считается, `parse_task`/`retrieve`
до `generate` не входят), `engine_calls_window: generate` и объявленную `model`/`model_source`; ключи
ретривала (`use_case`/`params`/`created`/`host`) не меняются. Модель можно объявить уже в
`generate(model=…)`. Самопроверка без хоста:
`uv run python mcp-server/server.py --profile lean --selftest` (поднялся, `tools/list` = профиль,
prompts = реестр скиллов; инструменты не вызываются). Плагин Kimi целиком: `uv run python cli/dt.py
plugin kimi --out DIR`; качество генерации по хостам: `uv run python cli/dt_eval.py --generation
--host kimi` (золотые задачи `vault/_system/eval/golden-generation.yaml`). Скиллов в реестре 8:
`new-hub` (пресеты клиент/продукт/проект/пресейл/направление) и `operational-review` (режимы
`утро|сводка`) заменили `new-entity-hub`/`new-presale`/`new-project` и `morning`. `pult_kpi.outputs`
- выходы за 30 дн по хостам; `pult_eval.generation` - история ручных прогонов задач по хостам.

## Личный экземпляр: `personal_recall` и вид `bridge` (PERSONAL-1)

`personal_recall(query, k=5)` - инструмент ТОЛЬКО личного экземпляра (`DT_INSTANCE_ROLE=personal`): личные
попадания по личному индексу + их `work_refs` + живой оверлей рабочего контекста (`work.notes`, каждая запись
`source: "work"`; рабочий демон недоступен - `work.available: false`, личная часть отдана). Ничего не пишет.
Он не входит в `TOOL_NAMES`/`PROFILES` и в `tools/list` рабочего экземпляра в любом профиле (гард
`tests/test_personal_recall.py`); личная роль добавляет его к любому профилю. Подключение хоста -
отдельной записью: `dt host-config <хост> --instance personal [--install]` → ключ `digital-twin-personal` на
порт экземпляра (мост `dt_shim --label com.dt.server-personal`); скиллы личной записи -
`dt skills export … --personal` (каталог `skills-personal/`, скилл `personal-recall`).

Вид карточек `bridge` («Мост») есть только в реестре личного экземпляра: `approve` пишет `work_refs` в личную
заметку, `reject` - стоп пары на `DT_BRIDGE_SNOOZE_DAYS`, `snooze` - скрыть на срок; `pult_card_explain` -
цитаты обеих сторон. Карточки создает `bridge_scan` (`dt bridge`, шаг ночной цепочки личного).

**PERSONAL-2.** `personal_today()` - второй инструмент личного экземпляра (тоже в `PERSONAL_TOOLS`, вне
профилей): `{date, path, exists, sections:[{time,text}], journal_dir, ideas_dir, inbox:{count, items}}` -
последние секции заметки дня и инбокс личного; read-only. Пульт личного вызывает оба личных инструмента
через запись `digital-twin-personal` (в артефакте Cowork переключатель «Работа | Личное» подставляет префикс
`mcp__digital-twin-personal__`). У личного экземпляра `pult_settings_get/set` получают секции `bridge`
(`min_score`, `exclude`, `snooze_days`, `limit`, `budget_s`) и `personal` (`journal_dir`, `ideas_dir`,
`content_dirs`, `inbox`, `index_exclude`): значения проверяются все или ни одно (`SettingsError` с кодом),
пишутся в оверлей экземпляра и применяются сразу; у рабочего этих секций нет. Службы, пути и
`pult_run_sync` тоже экземпляро-зависимы: метки `-<имя>`, шаги личной цепочки.

**DEV-3-CORE: конверт `connector_disabled` и `pult_manifest.connectors`.** Инструменты выключенного
коннектора (`DT_CONNECTORS`, см. `ops/README.md`, «Коннекторы») отвечают ОДНИМ конвертом, исключений
наружу нет: `{ok: false, refused: "connector_disabled", code: "connector_disabled", error, tool,
connector, hint}` (коннектор один - его ключ в `connector`, несколько - первый и список `connectors`;
`hint` - как включить). Список инструментов оси - в `core/surface/manifest.CONNECTOR_AXIS["tool"]`
(`work_feed`, `work_meetings`, `work_ticktick`, `work_context`, `work_meeting_prep`, `pult_deals`,
`pult_watch`, `pult_hub_link_deal`, `pult_hub_unlink_deal`, `pult_set_track`, `pult_function`,
`pult_ripe_leads`); `work_feed`/`work_context` живут, пока включен любой из трех коннекторов. `submit_job` с
op выключенного коннектора (`outlook_read`, `ingest_mail`, `ingest_capture`) - тот же конверт (+ `op`);
`pult_cards(kinds=[...])` - вид выключенного коннектора в `errors: {вид: "connector_disabled"}`, остальные
виды отдаются. `pult_manifest()` получил ключ `connectors: {ключ: {enabled, reason, requires}}`
(`requires` - имена секретов/ручек, без значений; у личной роли - `{}`); секция `connectors` («Настройки»)
объявляется, только когда хотя бы один коннектор выключен, `version` по-прежнему считается по составу
поверхности. `/health` отдает `version.engine` (релиз из `pyproject.toml`).

**PERSONAL-3.** `pult_manifest()` - манифест роли экземпляра (`{instance, title, subtitle, sections,
monitor_blocks, jobs, card_kinds, freshness_sources, sync_modes, version}`): пульт рисует только то,
что объявлено; у рабочей роли - все как до PERSONAL-3. `submit_job` вне роли - конверт отказа
`op_not_available` (форма как у `unknown_param`). `find_notes` у хитов-единиц документа (слайд,
страница, лист) добавляет `kind` (`slide|page|sheet|block`) и `doc_title` (родительский документ); у
обычных заметок ключей нет. Секция `bridge` настроек пополнилась `min_score_fts`, `min_score_legacy`,
`work_corpus`, `min_body_chars`, `min_quote_chars`; секция `personal` - `capture_project` (имя или id
списка TickTick; пусто - список рабочего) и `untagged_lane` (`skip|personal|journal|content`;
не `skip` - только при отдельном списке: иначе отказ `same_project`). `personal_today` отдает
`capture: {project, untagged_lane, same_project}`.


## HTTP-транспорт: демон движка (DAEMON-1)

Кроме stdio (хост запускает сервер сам; остается для тестов, самопроверки и fallback - поведение не менялось)
сервер умеет работать ОДНИМ постоянным процессом на машину - демоном `com.dt.server` под launchd:

```bash
uv run --extra operational --extra server python mcp-server/server.py --transport http --host 0.0.0.0 --port 8787
# без пульта (только /mcp):  ... --no-pult        самопроверка работающего демона:  ... --selftest --transport http
```

- **Пути = профили.** `/mcp/lean`, `/mcp/pult`, `/mcp/full` - три `FastMCP` одного реестра в одном процессе
  (Streamable HTTP, `stateless_http: false`). `tools/list` и `prompts/list` по http равны stdio побайтно
  (проверяет `--selftest --transport http` и тесты). Рядом, на том же порту: пульт (`/`, `/api/*`) и `/health`.
- **Доступ.** `/mcp` отвечает только loopback-peer без прокси-заголовков (иначе 403 до проверки токена); `Host` -
  только localhost. Токен - заголовок `Authorization: Bearer` из `.secrets/web_token` (read) или `web_token_rw`
  (write), без токена 401. **read** - `tools/list`, prompts, инструменты чтения; **`WRITE_TOOLS` - только с
  write-токеном**: иначе `{ok:false, refused:"write_token_required", code:"write_token_required"}` без вызова
  инструмента (профиль lean: `output_begin`, `save_output`, `place_download` - запись, для g1 нужен write-токен).
  Токены целиком не логируются: журнал метрик и аудит несут режим токена, его хвост (4 символа), peer и первые
  8 символов id сессии.
- **Хост - по сессии.** `clientInfo` берется с каждого запроса (`core.host.bind_session_host`, ContextVar):
  `host` в мете выходов, суффикс папки при коллизии, строки аудита и `tool_call` - хоста ЭТОЙ сессии; анонимный
  клиент (`mcp`) помечается как в stdio.
- **Параллельность.** Инструмент всегда в потоке (FastMCP 1.28 иначе зовет синхронный инструмент в event loop и
  один `generate` морозит все сессии); `generate`/`retrieve` ждут слот семафора (`DT_DAEMON_HEAVY_PARALLEL`, дефолт
  2, превышение ждет и не отказывает), остальные - параллельно; эмбеддер и реранкер под lock'ами.
- **Сессии.** Простой до закрытия - `DT_DAEMON_SESSION_IDLE_H` (дефолт 24 ч, `0` - без таймаута): FastMCP 1.28
  не пробрасывает `session_idle_timeout`, поэтому `build_http_app` кладет в FastMCP собственный
  `StreamableHTTPSessionManager` (приватные `_session_manager`/`_mcp_server`; при смене SDK сборка деградирует
  в «без таймаута» с предупреждением, тест `test_session_idle_timeout_*` падает). Закрытые клиентом сессии SDK
  оставляет в словаре менеджера - демон их не считает живыми и зачищает раз в 5 минут. **Рестарт демона рвет
  все сессии** (старый `Mcp-Session-Id` → 404): прямой клиент переподключается сам, Claude Desktop - через мост
  с `--reconnect` (HOSTS-ATTACH-1); это же сказано в поле `note` ответа `/health`.
- **`/health`** (без токена; только loopback и Tailscale-peer): `{ok, version:{code, started, uptime_s}, pid,
  sessions:{total, by_host, by_profile}, profiles, pult, limits, note}` - без токенов и путей. `version.code` -
  короткий sha `HEAD` репо на старте демона; доктор («Демон DT») сравнивает его с текущим `HEAD`.
- **Конфиги хостов** (HOSTS-ATTACH-1): Desktop/Cowork - мост `cli/dt_shim.py` (stdio ↔ `/mcp/full`, `clientInfo`
  сквозь, на 404 после рестарта демона повторяет `initialize`), Cursor/Kimi/Cherry - `url` + `Authorization:
  Bearer <write-токен>`; печать, проверка и установка - `dt host-config`, подробности - `docs/ops.md`.

- **`POST /internal/embed`** (NIGHT-CHAIN-1) - внутренний вход, **не MCP-инструмент**: его нет в `tools/list` ни одного
  профиля и в allowlist пульта (гард-тест). Один эмбеддер на машину: плановые джобы (`dt_index`, `dt_eval`)
  берут вектора у демона вместо второй копии BGE-M3 (на 16 ГБ - MPS OOM → CPU). Доступ: loopback-peer без прокси-
  заголовков (Tailscale-peer нельзя даже при `DT_MODE=server`), `Authorization: Bearer` **rw**-токен (read - 403
  `write_token_required`, без токена - 401). Запрос `{texts:[...], batch_size?, format?}` (текстов ≤ 4 × `DT_EMBED_BATCH_SIZE`,
  по умолчанию 256; текст ≤ 32768 символов; иначе 413), ответ `{vectors, model, device, ms, n}`: `vectors` - base64
  little-endian float32 `{dtype, shape, b64}` (`format:"json"` - списки). Расчет - в потоке под `RLock` эмбеддера демона:
  запросы джобов и хостов стоят в одной очереди (`DT_DAEMON_HEAVY_PARALLEL` не затронут). Тела чанков нигде не
  логируются. Клиент - `core.embeddings.get_embedder()` (`core/embed_daemon.py`), настройки - `DT_EMBED_VIA_DAEMON`
  (дефолт 1) и `DT_EMBED_DAEMON_TIMEOUT_S`; недоступность демона → локальная модель, одно предупреждение на процесс.
  Stdio-путь сервера прежний: stdio-процесс - обычный клиент `get_embedder()`.

Установка, перезапуск, логи - `ops/README.md`, раздел «Демон движка».

## Setup

Requires Python 3.11+ and [uv](https://docs.astral.sh/uv/). The MCP SDK is an
optional extra (`core` does not need it):

```bash
uv sync --extra server
```

Run the server directly (stdio; it will block waiting for an MCP client):

```bash
uv run --extra server python mcp-server/server.py
```

## Connect to an MCP host

**Штатно хосты подключаются к демону (`dt host-config <хост> --install`, `docs/ops.md`); ниже - прямой stdio
(fallback, тесты, хост без доступа к демону).**

The server speaks stdio MCP and works with any MCP host (Claude Desktop, Cursor, Kimi Work, …);
the host announces itself in the handshake and is recorded as `host` in output provenance and
in usage telemetry. Example below — Claude Desktop: add the server to `claude_desktop_config.json`. On macOS it lives at
`~/Library/Application Support/Claude/claude_desktop_config.json` (create it if
absent); on Windows, `%APPDATA%\Claude\claude_desktop_config.json`.

```json
{
  "mcpServers": {
    "digital-twin": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/ABS/PATH/TO/engine",
        "--extra",
        "server",
        "python",
        "mcp-server/server.py"
      ],
      "env": {
        "DT_VAULT_PATH": "/Users/me/Claude/Projects/Digital twin/vault"
      }
    }
  }
}
```

Notes:

- `--directory` pins uv to this repo regardless of where the host launches it —
  no reliance on a working-directory setting.
- If `uv` is not on the host's `PATH`, use its absolute path for `command`
  (find it with `which uv`).
- `env` is optional. The owner's name for the prompt's `[System]` line (and the
  `[Owner]` section) comes from the **owner profile in the vault**
  (`_system/profile/owner.yaml`, `about.md`; create it once with `dt owner init`,
  PROFILE-1) — not from the host's `env`: a daemon under launchd never sees the
  host's `env`, so a name set there reaches one host only. `DT_USER_NAME` still
  works as a supplement (priority: profile > `DT_USER_NAME` > `the user`).
  `DT_VAULT_PATH` / `DT_LANCEDB_PATH` override the vault / index locations
  (see `core/config.py`).

Then **fully quit and reopen the host**. The `digital-twin` tools appear
under the host's tools menu. To verify the tool list outside the host:

```bash
uv run --extra server python -c "import sys, asyncio; sys.path.insert(0, 'mcp-server'); \
import server; print([t.name for t in asyncio.run(server.build_server().list_tools())])"
```

## Example conversation (Path B)

> **You:** Сделай письмо клиенту Инитех о продлении контракта.

1. Claude calls `parse_task("Сделай письмо клиенту Инитех …")` →
   `use_case=client_correspondence, client_id=client-initech` and asks you to
   confirm.
2. On confirm, Claude calls `generate("client_correspondence", "<task>", {...})`
   → gets back `{output_dir, prompt}` and writes the provenance folder under
   `07-outputs/`.
3. Claude writes the letter **in the chat** from the returned `prompt`.
4. Claude calls `save_output(output_dir, "<letter text>")` → `output.md` lands
   beside `prompt.md` / `sources.md` / `policy.yaml` / `meta.yaml`.

Ingestion mirrors this: `refine_inbox()` returns a placement request per inbox
item, Claude proposes `{type, target_path, frontmatter, summary?}`, you confirm,
and `apply_refinement(inbox_file, proposal)` writes it into the vault.

## Файл из чата в рабочую папку (ФТ-1/ФТ-2, FT-12)

Байты файла через мост MCP **не передаются** — мост управляющий канал:

> **Вы:** сохрани эту справку в папку ЦОД

1. Файл собран в чате → вы скачиваете его браузером (он попадает в `~/Downloads`).
2. Claude вызывает `place_download(match="справка*.docx", dest="цод")` — по мосту
   уходит команда (~60 байт), движок делает локальный `rename` за миллисекунды.
3. Ответ: путь, размер, `sha256`. Неоднозначно (2 файла под шаблон) или пусто —
   явный отказ со списком, а не догадка.

Алиас папки (`dest="цод"`) заводится один раз:
`folder_alias_set("ЦОД", "current", "Kazakhstan/Globex/ЦОД")` — дальше
адресация одним токеном, в любом написании (кириллица/латиница/транслит).
`folder_alias_list()` показывает, что уже заведено.

`store_file` остаётся для файлов, у которых «скачанного» источника нет; для
крупных бинарей он же — узкое место (base64 через мост), см. ФТ п. 1.2.

## Лимиты вызова и почему они такие (ФТ-3, FT-3 — наша часть)

Инцидент 04.08.2026 (ФТ п. 1.2): `store_file` с ~29 КБ base64 в параметре — и мост
хоста не отвечал 4 минуты, **вместе с непричастным MacOS-MCP**. То есть в
мосте нет изоляции серверов: одно тяжёлое сообщение блокирует канал, общий для всех
локальных MCP-серверов.

Граница честная: **изоляция серверов и таймаут вызова — уровень моста хоста**
(вопрос 5 ФТ, к поставщику); сообщение могло вообще не дойти до нашего процесса, и
серверный лимит от такого зависания не спасает. Наша часть — fail-fast и видимость
для всего, что **до нас дошло**. Всё это ставится одним местом — обёрткой
`guarded_tool` при регистрации инструментов в `build_server`, а не копипастой в
каждый инструмент; **под лимитом поведение байт-идентично** (схемы инструментов у
FastMCP не меняются, сами функции не тронуты).

| Ручка | Дефолт | Что делает |
| --- | --- | --- |
| `DT_ADHOC_SOURCES_H` | 8 | Окно телеметрии источников для ad-hoc-выхода БЕЗ `output_begin` (у него нет зафиксированного начала работы). В `sources.md` такое окно помечается явно — «окно, а не сессия». Мусор/непозитивное → дефолт |
| `DT_NEWER_SIBLING_DAYS` | 30 | На сколько дней сосед по каталогу должен быть новее поднимаемого файла, чтобы попасть в `newer_sibling` (и поднять `stale_hint`). Мусор/непозитивное → дефолт |
| `DT_DATE_SPREAD_MONTHS` | 12 | Разрыв дат, после которого `find_notes` добавляет `warning` о том, что верхний хит существенно старше самого свежего в выдаче. Мусор/непозитивное → дефолт |
| `DT_RERANK` | 0 | RETR-RERANK-1: реранкер `find_notes` вкл (`1`) / выкл. Дефолт ВЫКЛ до решения К. по числам абляции; `find_notes(rerank=…)` бьёт env. Выкл → поведение байт в байт прежнее (хаб первым, лестница семантики) |
| `DT_RERANK_POOL` | 30 | Сколько верхних кандидатов слияния переоценивает реранкер (хвост — ниже, в прежнем порядке). Мусор/непозитивное → дефолт |
| `DT_RERANK_ALPHA` | 0.7 | Вес реранкера: `final = α·score01 + (1-α)·fused`. Вне [0, 1]/мусор → дефолт |
| `DT_FIND_SEMANTIC_ALWAYS` | = `DT_RERANK` | Семантическая ступень `find_notes` всегда (а не только при < `DT_FIND_SEMANTIC_FLOOR` лексических хитов). Дефолт следует за реранкером |
| `DT_RERANK_MAX_LENGTH` / `DT_RERANK_CHUNK_CHARS` / `DT_RERANK_BODY_CHARS` | 512 / 1200 / 800 | Токенов на пару и обрезка текста пары (чанк / голова тела скан-хита). Цена реранкера растёт с длиной: на MPS ~90 мс на пару при 512 токенах |
| `DT_RERANK_DEVICE` | авто | Устройство реранкера (`mps`/`cpu`/`cuda`); без него — как у эмбеддера (`DT_EMBED_DEVICE` → MPS → CUDA → CPU), OOM/сбой MPS → откат на CPU |
| `DT_MCP_PARAM_LIMIT` | 10 МБ | Суммарный размер строковых аргументов вызова (UTF-8 байты, включая строки внутри dict/list). Больше → **немедленный** `{ok:false, refused:"param_limit", error:"<размер> > <лимит> …"}`, инструмент не вызывается вовсе. Потолок «от абсурда»: легитимный deliverable столько не весит (`store_file` режет на 25 МБ уже после декода), а молчаливое зависание на гигантском параметре недопустимо |
| `DT_MCP_PARAM_WARN` | 32 КБ | Порог диагностики: эмпирическая зона отказов моста — 29–39 КБ. Warning в лог **до** вызова (если мост/инструмент повиснет, строка уже записана — пост-фактум её бы не было) + итоговый warning с длительностью по завершении |
| `DT_MCP_SLOW_WARN_S` | 30 с | Вызов дольше порога → warning с длительностью (тот же дефолт, что ФТ-3 просит у таймаута моста). Пишется и когда инструмент упал |

В строках лога только имя инструмента, размеры и длительность — **контента
аргументов там нет никогда**. Логгер `dt.mcp` пишет в stderr сервера (у хоста
это его MCP-лог, где инцидент и диагностируют); `dt-sync.log` не трогаем,
чтобы не менять то, что читает пульт. Материал для вопроса 5 ФТ поставщику —
«когда и на чём мост деградирует» — берётся ровно из этих строк.

## Контракт аргументов на границе и потолки ответов (ARGS-STRICT-1)

FastMCP строит модель аргументов из сигнатуры, а pydantic по умолчанию отбрасывает лишние
ключи ДО вызова функции: `get_facts(client="client-initech-holding", limit=5)` молча отдавал весь стор
(2692 факта, 2,5 МБ), а `lift_source(path, max_chars=1500)` - весь текст. Теперь граница
честная - одной точкой, подклассом `FastMCP` в `build_server` (оба транспорта, stdio и http):

* **Неизвестный аргумент -> отказ, инструмент НЕ вызывается.** Ответ - конверт CONTRACT-2:
  `{ok: false, refused: "unknown_param", code: "unknown_param", error: "<tool>: неизвестные
  аргументы a, b; допустимые: …", unknown: [...], accepted: [...]}`. Отказ - событие
  `tool_degradation` с кодом `unknown_param` (только имя инструмента и код, значений аргументов
  в журнале нет): доктор «где агенты спотыкаются» видит, какие хосты зовут с лишним ключом.
  У шести инструментов с `outputSchema` «массив» (`job_list`, `list_inbox`, `refine_inbox`,
  `pult_services`, `pult_ingest_sources`, `pult_deals`) конверт не ложится в схему вывода -
  он идет текстом с `isError: true`.
* **Схема честная.** В `tools/list` у каждого инструмента `inputSchema.additionalProperties:
  false` (+31 символ на инструмент; остальная схема байт в байт прежняя).
* **`/api/<tool>` - та же семантика:** лишний ключ тела -> HTTP 400, `code: "unknown_param"`,
  то же тело конверта + `isError`/`content` (веб-клиент читает прежние поля); проверка по
  `inspect.signature` до вызова, `TypeError` внутри инструмента остается `tool_error`.
* **Потолки ответов:** `get_facts(limit)` (`DT_FACTS_MAX`, 200) и `lift_source(max_chars)`
  (`DT_LIFT_MAX_CHARS`, 40 000), `0` - без потолка. Укладывается - ответ байт в байт прежний.

| Ручка | Дефолт | Что делает |
| --- | --- | --- |
| `DT_FACTS_MAX` | 200 | Потолок `get_facts` без явного `limit`, фактов; `0` - без потолка; больше - конверт `truncated` с `total` |
| `DT_LIFT_MAX_CHARS` | 40000 | Потолок `text` в ответе `lift_source` без явного `max_chars`, символов; `0` - без потолка; больше - усечение по границе строки + `truncated`/`chars_total` |

## Справка сразу в папку клиента (ФТ-4, FT-4)

Когда адресат известен ДО генерации, сохранение перестаёт быть отдельным действием, а
содержимое едет через мост **один раз**:

> **Вы:** сделай справку по ЦОД и положи её в папку Эмбы в docx

1. `generate(...)` → промпт; Claude пишет текст справки **в чате** (как обычно).
2. `save_output(output_dir, "<текст справки>", dest="цод", format="docx")` — один
   вызов: `output.md` ложится в `07-outputs` (провенанс), pandoc **локально** собирает
   `.docx`, файл ложится в рабочую папку, а его путь сам попадает в «## Файлы»
   output-заметки.
3. Ответ: `delivered.path`, `size`, `sha256`, `format_used`.

Ноль base64: раньше то же содержимое проходило через мост дважды — текстом и потом
`store_file`-ом в base64 (21 КБ .docx → 28 КБ base64 → минуты генерации, см. ФТ п. 1.2),
не добавляя ни байта информации. Второй проход устранён целиком.

`format` собирается локально: `docx` — pandoc, `pdf` — pandoc + установленный
pdf-движок (`tectonic`/`xelatex`/…). Конвертера нет, он упал или не успел за
`DT_PANDOC_TIMEOUT_S` (60 с) → в папку ложится `.md` и в ответе приходит `warning` —
операция **не отказывает**: артефакт доезжает, человек видит, почему формат другой.
Сборка идёт в системном временном каталоге, в клиентскую папку попадают только готовые
проверенные байты.

Когда адресат становится известен ПОСЛЕ правок в чате — сценарий другой: скачать файл
браузером и `place_download` (ФТ-1). `store_file` остаётся для бинарей без текстового
источника (xlsx с формулами, заполненный PDF) — ФТ-5.

## Бинарь частями (ФТ-5, FT-5)

Последний по приоритету канал — **только когда у файла нет текстового источника** и он
не проходит одним параметром: xlsx с формулами, заполненный PDF, изображение,
произвольное вложение. Если файл скачан браузером — `place_download` (ФТ-1, единицы
миллисекунд). Если есть текст — `save_output(dest=…, format=…)` (ФТ-4, байты через мост
не идут вовсе). ФТ предупреждает прямо: **быстро не станет** — цель порционности в
предсказуемости и отсутствии падений, а не в скорости.

```
store_file_begin(root, "Эмба/расчёт.xlsx", final_sha256, total_size)
  → store_file_append(session_id, 0, <base64 16 КБ>)
  → store_file_append(session_id, 1, …)   …
  → store_file_commit(session_id)         # sha сверен → файл в папке
```

Почему это не падает как одно большое сообщение: часть 16 КБ → ~21,8 КБ base64, то есть
ниже эмпирической зоны отказов моста (29–39 КБ, инцидент 04.08.2026) и ниже порога
диагностики FT-3 (32 КБ) — штатная доставка даже не поднимает предупреждений.

**Обрыв — не потеря.** Принятые части лежат на диске с `fsync`. После обрыва:
`store_file_status(session_id)` → `expected_next` (какую часть слать) и
`expected_offset` (с какого смещения её резать) → продолжаем с этого места → `commit`.
Если потерян сам `session_id` — повторите `store_file_begin` с теми же целью и
`final_sha256`: id детерминирован, вернётся **та же** сессия со своим прогрессом.
Часть не по порядку тоже не тупик: отказ `out_of_order` сам сообщает `expected_next`.

Целостность и гарды: все гарды цели (корень/containment/NDA/существующий отличающийся)
проверяются на `begin` — отказ приходит до передачи мегабайтов. Сборка идёт в
`.derived/chunked/` (состояние — json со смещениями, **без контента**; данные — `.part`),
поэтому **в клиентской папке недособранный файл не виден ни секунды**. На `commit`
sha256 собранного сверяется с заявленным: не сошлось → части удаляются, цели не
появляется. Брошенные сессии снимает `store_file_abort` или TTL (24 ч), а `doctor`
показывает висящие.

## Контракт в handshake и видимость незакрытого контура (DOD-1)

Кейс 04.08.2026: чат работал с движком сырыми инструментами, произвёл артефакты и **не
вернул результат в vault**, пока не напомнили. Разбор дал три причины — и правило
теперь живёт в системе, а не в памяти модели:

1. **Правило не доезжало.** Скиллы несут его только тем, кто их загрузил; ad-hoc чат
   видит лишь описания инструментов. Поэтому контракт уходит в **server instructions**
   (`FastMCP("digital-twin", instructions=SERVER_INSTRUCTIONS)`) — единственный канал,
   который получает ЛЮБОЙ MCP-клиент при подключении. Текст короткий (≤15 строк, гард
   в тестах): результат возвращается в DT, генерация в стиле — через скилл, внешние
   записи — через очередь подтверждений.
2. **Соблюдать было дорого.** `save_output` требовал `output_dir` от `generate()` — без
   генерации закрыть контур было нельзя ни одним вызовом. Теперь можно:
   `save_output(text=…, title="Справка по ЦОД", file_refs=["store/Эмба/расчёт.xlsx"])`.
3. **Нарушение было невидимо.** `doctor` показывает строку «Незакрытый контур (DOD-1)»:
   файлы, доставленные в хранилище за последние `DT_DOD_WINDOW_H` часов (дефолт 48) и не
   упомянутые ни в одной заметке `07-outputs/**/output.md`. Это **warning, не fail**:
   файл, положенный в папку без генерации, — легитимный случай, ложное срабатывание тут
   дешевле пропуска. Предупреждение видно и в чатовом `doctor()`, и в `dt-doctor`.

Definition of done: задача, в которой использован DT, не завершена, пока результат не
вернулся в vault.

## Каркас выхода до работы и триггер «уходит наружу» (DOD-2)

Фейлкейс 11.08.2026 — **3-е повторение того же класса** (ГЛБ 21.07 → кейс 04.08/DOD-1 →
профиль роли 10.08). Артефакт уехал в опер. хранилище и в HR, а `07-outputs` не был
задействован ни разу; при исправлении жёсткий таймаут моста пришёлся на середину записи
и оставил полу-папку (`meta.yaml` + `policy.yaml` без `prompt.md`) — она хуже
отсутствующей, потому что **выглядит оформленной**. Почему DOD-1 не дотянулся и что
изменилось:

1. **Триггера не было.** В сессии закрепился шаблон «написать в vault heredoc'ом →
   `wc -l` → закоммитить», и факт «файл уехал в хранилище и в HR» режим не переключил.
   Контракт в handshake теперь начинается с триггера: артефакт уходит ЗА ПРЕДЕЛЫ vault
   (опер. хранилище, клиент, HR, внешняя форма) → контур выхода ОБЯЗАТЕЛЕН,
   `output_begin` ДО работы; плюс прямой запрет писать в vault шеллом (heredoc/cat/mv)
   — только инструментами DT, иначе нет ни провенанса, ни аудита. Гард ≤15 строк держится.
2. **Контур собирался ПОСЛЕ работы.** `output_begin(title, task, channel=…)` создаёт
   папку с `meta.yaml` (`status: draft`) и `prompt.md` (постановка дословно) **до**
   генерации; `save_output(output_dir=…)` закрывает контур (`draft → final`, канал
   уточняется фактом доставки). Падение на любом шаге после begin оставляет валидную
   заявку с зафиксированной постановкой, а не мусор: провенанс постфактум
   невосстановим — через день по одному тексту не сказать, откуда взялась цифра.
3. **Битый контур был невидим.** `doctor` показывает строку «Недооформленный выход
   (DOD-2)»: папки `07-outputs/**` без `output.md` или с мета-`status: draft` старше
   `DT_OUTPUT_DRAFT_WARN_H` (дефолт 24 ч), старейшие сверху. Тоже **warning, не fail** —
   папка в работе легитимна; подсказка предлагает дооформить или удалить.
