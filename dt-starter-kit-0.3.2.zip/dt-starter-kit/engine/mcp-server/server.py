"""MCP server — conversational interface over the engine (architecture §8, Track C).

Wraps the ready ``core/`` (retrieval / policies / generation / output / ingest)
in an MCP server spoken over **stdio**, the transport MCP hosts use. Each
tool is a *thin* wrapper that calls ``core`` and returns JSON-serializable data.

**Path B (decision 2026-06-17).** Nothing here calls a network LLM. ``generate``
assembles the prompt and writes provenance, then returns the prompt; the MCP host's
chat model writes the artifact *in the conversation*, and ``save_output`` saves that
text back next to the provenance. The engine prepares context and records what
produced an artifact — host and declared model go to ``meta.yaml``, the model that
fills ``output.md`` is whatever the host runs.

Layering / invariant: this module imports ``core``; ``core`` never imports this
(``tests/test_invariant.py``). The ``mcp`` SDK is imported lazily in
:func:`build_server` so the tool wrappers below can be unit-tested without the
SDK present (they are plain functions; registration is the only SDK-coupled bit).

Run (see ``mcp-server/README.md``)::

    uv run --extra server python mcp-server/server.py
"""

from __future__ import annotations

import functools
import inspect
import logging
import os
import re
import time
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

from core import daemon as _core_daemon
from core import instance as _core_instance
from core.config import default_vault_path
from core.config import outputs_path as _core_outputs_path
from core.config.env_file import load_env_layers
from core.generation import assemble_prompt as _core_assemble_prompt
from core.ingest import (
    InboxItem,
)
from core.ingest import (
    apply_refinement as _core_apply_refinement,
)
from core.ingest import (
    build_refinement_request as _core_build_refinement_request,
)
from core.ingest import (
    is_assignment as _core_is_assignment,
)
from core.ingest import (
    list_inbox as _core_list_inbox,
)
from core.linking.apply import apply_approved as _core_apply_approved
from core.linking.propose import (
    STATUS_APPROVED,
    STATUS_PENDING,
    LinkProposal,
    LinkProposalQueue,
)
from core.linking.propose import (
    propose_for_notes as _core_propose_for_notes,
)
from core.linking.propose import (
    select_sources as _core_select_sources,
)
from core.metrics import summarize as _core_kpi_summarize
from core.operational import pult as _core_pult
from core.operational import services as _core_services
from core.operational import storage as _core_storage
from core.output import create_output_dir, save_artifact, write_provenance
from core.parse_task import parse_task as _core_parse_task
from core.retrieval.index import reindex as _core_reindex
from core.retrieval.policies import run_policy as _core_run_policy
from core.retrieval.search import SearchResult

# engine/.env → os.environ (tokens + DT_* knobs; values never logged). The CLI
# layer does this via cli/_env.py; the server must do it itself — an MCP host
# launches it without the shell environment, so os.environ alone has no tokens
# (surfaced by the first live pult_decide probe, 2026-07-04). Tokens are read
# lazily inside tool calls, so loading after imports is safe.
# PERSONAL-1: оверлей экземпляра (DT_INSTANCE из plist) поверх .env; без него - один .env, как было.
load_env_layers(Path(__file__).resolve().parents[1] / ".env")

# How much chunk text to surface in inspection tools (retrieve / list_inbox).
_PREVIEW_CHARS = 240

# Names of the tools the server exposes, in registration order — also the
# single source of truth used by the README and the start-up self-check.
TOOL_NAMES = (
    "reindex",
    "submit_job",
    "job_status",
    "job_list",
    "job_cancel",
    "parse_task",
    "plan_task",
    "retrieve",
    "generate",
    "resolve",
    "doctor",
    "find_notes",
    "find_latest",
    "read_note",
    "attribute_note",
    "lift_source",
    "get_facts",
    "owner_profile",
    "find_exemplar",
    "ingest_scan",
    "output_begin",
    "save_output",
    "store_file",
    "store_file_begin",
    "store_file_append",
    "store_file_status",
    "store_file_commit",
    "store_file_abort",
    "place_download",
    "folder_alias_list",
    "folder_alias_set",
    "list_inbox",
    "refine_inbox",
    "apply_refinement",
    "propose_links",
    "apply_links",
    "pult_kpi",
    "pult_sync_status",
    "pult_log_tail",
    "pult_run_sync",
    "pult_activity",
    "pult_freshness",
    "pult_monitor",
    "pult_manifest",
    "pult_services",
    "pult_service_control",
    "pult_events",
    "pult_ingest_sources",
    "pult_ingest_trace",
    "pult_storage_status",
    "pult_storage_action",
    "pult_paths_get",
    "pult_paths_set",
    "pult_settings_get",
    "pult_settings_set",
    "pult_ai",
    "pult_choose_folder",
    "pult_cards",
    "pult_card_decide",
    "pult_card_explain",
    "pult_eval",
    "pult_create_hub",
    "pult_hub_add_note",
    "hub_synth_context",
    "hub_synth_propose",
    "pult_ripe_leads",
    "pult_deals",
    "pult_function",
    "pult_watch",
    "pult_hub_link_deal",
    "pult_hub_unlink_deal",
    "pult_set_track",
    "work_feed",
    "work_resurface",
    "work_dismiss",
    "work_context",
    "work_note_preview",
    "work_meetings",
    "work_ticktick",
    "work_meeting_prep",
    "pult_web_status",
    "pult_web_restart",
)


# Снятые инструменты: имя -> чем заменено. Имена НЕ переиспользуются (гард
# ``test_no_timetta_write``); справочник ``docs/08-tools-reference.md`` и гард документации
# (``docs/02-architecture.md`` §8) читают этот словарь: «снятое» живет здесь, а не в трех текстах.
_RETIRE_WRITE = "RETIRE-WRITE-1 (2026-10-20): запись в Timetta выведена, CRM ведет администратор"
_QUEUE_ONE = "SURFACE-HYGIENE-1 (2026-10-31): очередь решений одна - pult_cards / pult_card_decide"
RETIRED_TOOLS: dict[str, str] = {
    **dict.fromkeys(
        ("propose_timetta_change", "pult_decide", "pult_queue", "pult_autonomy",
         "work_checklist_done", "list_operational_inbox"), _RETIRE_WRITE),
    **dict.fromkeys(
        ("list_link_proposals", "pult_link_decide", "list_reattr_proposals",
         "pult_reattr_decide", "pult_untriaged", "pult_route", "pult_assignments",
         "pult_assignment_decide", "pult_hub_candidates", "pult_hub_decide",
         "pult_hub_alias_candidates", "pult_hub_alias_decide", "pult_golden_candidates",
         "pult_golden_decide", "pult_ripe_snooze", "pult_ripe_reject"), _QUEUE_ONE),
}

# --------------------------------------------------------------------------- #
# TOOLS-PROFILES-1 п.1 — профили инструментов (дизайн MODEL-1, решение 3)        #
# --------------------------------------------------------------------------- #
# ``tools/list`` полного сервера — 85 инструментов, ~120К символов (~40-50К токенов) ДО первого
# вопроса: барьер для чужих и локальных моделей. Профиль выбирает, какое подмножество увидит хост:
#
#   * ``lean`` — 11: поиск / чтение / факты / ретривал / генерация / контур выхода (то, что нужно
#     хосту с чат-моделью без скилла) + ``owner_profile`` (правила владельца, PROFILE-1); из
#     WRITE_TOOLS — ТОЛЬКО контур выхода (output_begin, save_output, place_download);
#   * ``pult`` — инструменты пульта (``pult_*``, ``work_*``) + то, что пульт зовет из тела страницы
#     (=allowlist артефакта) + ``owner_profile``; для хоста, который строит свой пульт;
#   * ``full`` — всё (по умолчанию; поведение сервера не меняется ни на байт).
#
# Каждый инструмент входит хотя бы в ``full`` (= ``TOOL_NAMES``); вложенность и границы
# профилей стережет ``tests/test_tool_profiles.py``. Профиль меняет ТОЛЬКО то, что сервер
# регистрирует: сами инструменты, их схемы и поведение — те же (``instructions`` одни).
LEAN_TOOLS = frozenset({
    "parse_task", "find_notes", "find_latest", "read_note", "get_facts", "retrieve", "generate",
    "output_begin", "save_output",
    # HUB-SYNTH-1: досье состояния хаба (read-only; текст пишет модель хоста, запись - карточкой)
    "hub_synth_context",
    # PROFILE-1: правила владельца любому хосту (read-only; не в allowlist артефакта пульта -
    # пульт берет сводку из pult_settings_get)
    "owner_profile",
    # MODEL-1-FIT: доставка файла, уже лежащего на диске (контракт п.2, ветка скилла
    # generate-artifact); запись только под ingest-корни с хэш-гардами. Контур выхода, не пульт.
    "place_download",
})
# Что пульт зовет из тела страницы сверх ``pult_*``/``work_*`` (сверка с pult.html — в тесте).
PULT_EXTRA_TOOLS = frozenset({
    "attribute_note", "doctor", "find_exemplar", "find_notes", "generate", "get_facts",
    "hub_synth_context", "hub_synth_propose",  # HUB-SYNTH-1 (allowlist артефакта +2: постановщик)
    "job_cancel", "job_list", "job_status", "list_inbox", "parse_task", "plan_task", "retrieve",
    "save_output", "submit_job",
})
# Сверх allowlist'а артефакта: общие для всех профилей инструменты хоста (PROFILE-1).
HOST_COMMON_TOOLS = frozenset({"owner_profile"})
PROFILE_FULL = "full"
PROFILES: dict[str, tuple[str, ...]] = {
    "lean": tuple(n for n in TOOL_NAMES if n in LEAN_TOOLS),
    "pult": tuple(
        n for n in TOOL_NAMES
        if n.startswith(("pult_", "work_")) or n in PULT_EXTRA_TOOLS or n in HOST_COMMON_TOOLS
    ),
    PROFILE_FULL: TOOL_NAMES,
}
DEFAULT_PROFILE = PROFILE_FULL
# PERSONAL-1 п.6: инструменты ТОЛЬКО личного экземпляра (``DT_INSTANCE_ROLE=personal``). Не входят
# ни в ``TOOL_NAMES``, ни в ``PROFILES``: у рабочего экземпляра их нет по построению (гард
# ``tests/test_personal_recall.py``); личная роль добавляет их к ЛЮБОМУ профилю (profile_tools).
PERSONAL_TOOLS: tuple[str, ...] = ("personal_recall", "personal_today")
TOOL_PROFILE_ENV = "DT_TOOL_PROFILE"
TOOL_DESC_CHARS_ENV = "DT_TOOL_DESC_CHARS"


def resolve_profile(name: str | None = None) -> str:
    """Профиль: аргумент (``--profile``) → ``DT_TOOL_PROFILE`` → ``full``. Незнакомый — ошибка."""
    chosen = (name or os.environ.get(TOOL_PROFILE_ENV) or DEFAULT_PROFILE).strip().lower()
    if chosen not in PROFILES:
        raise ValueError(
            f"неизвестный профиль {chosen!r}: допустимы {', '.join(PROFILES)} "
            f"(--profile или {TOOL_PROFILE_ENV})"
        )
    return chosen


def _is_personal_role() -> bool:
    from core.instance import is_personal

    return is_personal()


def profile_tools(profile: str) -> tuple[str, ...]:
    """Инструменты профиля ЭТОГО процесса: ``PROFILES[профиль]`` (+ личные у роли personal)."""
    from core.instance import is_personal

    base = PROFILES[profile]
    return (*base, *PERSONAL_TOOLS) if is_personal() else base


def profile_instructions(profile: str) -> str:
    """``SERVER_INSTRUCTIONS`` одни на все профили; урезанный профиль добавляет одну строку.

    ``full`` — ровно прежняя константа (handshake не меняется ни на байт).
    """
    if profile == PROFILE_FULL:
        return SERVER_INSTRUCTIONS
    return (
        f"{SERVER_INSTRUCTIONS}\n\nПрофиль {profile}: {len(profile_tools(profile))} инструментов; "
        f"остальное — в профиле {PROFILE_FULL}."
    )


def desc_chars_limit(value: int | str | None = None) -> int:
    """Бюджет описаний, символов: аргумент → ``DT_TOOL_DESC_CHARS``; ``0``/мусор → без усечения."""
    raw = value if value is not None else os.environ.get(TOOL_DESC_CHARS_ENV, "")
    try:
        return max(0, int(str(raw).strip() or 0))
    except ValueError:
        return 0


def trim_description(doc: str, limit: int) -> str:
    """Мягкое усечение описания по границе предложения/абзаца, с «…»; ``limit<=0`` — как есть.

    Режет только ТЕКСТ описания: схема аргументов инструмента (сигнатура) не затрагивается.
    Предпочитает конец предложения не раньше середины бюджета, иначе — границу слова.
    """
    doc = (doc or "").strip()
    if limit <= 0 or len(doc) <= limit:
        return doc
    cut = doc[:limit]
    half = limit // 2
    boundary = max(cut.rfind("\n\n"), cut.rfind(". "), cut.rfind(".\n"), cut.rfind("; "))
    if boundary >= half:
        cut = cut[: boundary + 1]
    else:
        space = cut.rfind(" ")
        cut = cut[:space] if space >= half else cut
    return cut.rstrip(" ;,:—-") + " …"


# SEC-6 — реестр инструментов, МЕНЯЮЩИХ состояние (vault-контент / Timetta /
# TickTick / диск / карточки поручений / crosswalk / конфиг путей /
# службы). Каждый ОБЯЗАН эмитить ровно одну аудит-строку ``record_action`` (только
# идентификаторы/пути/kind/counts — без контента/текстов/токенов). Реестр держим
# рядом с ``TOOL_NAMES``, чтобы ревью нового инструмента сразу видело: пишет →
# заноси сюда + добавь аудит (``tests/test_write_audit.py`` стережёт оба факта).
#
# Умышленно НЕ включены (по коду, не аспирация):
#   * read-only инструменты (retrieve/find_notes/pult_*_status/…), включая
#     ``lift_source`` — он аудитится как факт ЧТЕНИЯ файла, не как запись;
#   * ``propose_links`` — пишет лишь локальную стейджинг-очередь предложений (без
#     внешнего эффекта); привилегированная запись — ``apply_links`` (в vault);
#   * derived/оркестрация (``reindex``/``submit_job``/``job_cancel``) —
#     идемпотентно-пересобираемое состояние индекса/заданий, не привилегированная
#     запись (см. чек-лист в SECURITY.md).
WRITE_TOOLS = frozenset(
    {
        # -- уже под аудитом до SEC-6 --
        "ingest_scan",
        "store_file",
        # REATTR-1: apply перевешивает ``client:`` во frontmatter заметки (vault-запись)
        "pult_run_sync",
        "pult_service_control",
        # WEBPULT-ACCESS-1: рестарт веб-пульта - действие (через service-DAO), только с rw-токеном
        "pult_web_restart",
        "pult_storage_action",
        "pult_paths_set",
        # PULT-STANDALONE-1: настройки слоя ИИ-синтезов (``_system/pult.yaml``; ключа тут нет)
        "pult_settings_set",
        # QUEUE-SERVER-1: решение по карточке реестра (аудит - core.decisions.registry, одна строка)
        "pult_card_decide",
        # RETIRE-WRITE-1: «отправлено»/«отклонить» по карточке поручения — запись статуса захвата
        # HUB-ALIAS-1: approve дописывает ``aliases`` во frontmatter хаба (vault-запись списком)
        # EVAL-2: accept дописывает запрос в канон golden-queries.yaml (vault-запись текстом)
        "pult_hub_link_deal",
        "pult_hub_unlink_deal",
        # ORBIT-3: ручной список «слежу» (локальный watchlist.json + пересчёт флага в зеркале)
        "pult_watch",
        # -- покрыто в SEC-6 (privileged writes: vault-контент / внешние системы) --
        "attribute_note",
        # DOD-2: каркас выхода — запись в vault (папка + мета + постановка) до работы
        "output_begin",
        "save_output",
        "apply_refinement",
        "apply_links",
        # -- покрыто в SEC-6 (найдено ревью сверх 7 из ТЗ; те же классы записи) --
        "pult_create_hub",
        "pult_hub_add_note",
        "work_dismiss",
        # -- TRACK-1: смена трека хаба (vault-запись frontmatter) --
        "pult_set_track",
        # -- FT-12: файловая доставка мимо моста (ФТ-1) + реестр алиасов (ФТ-2) --
        "place_download",
        "folder_alias_set",
        # -- FT-5: порционная запись бинаря. В реестре — begin/commit/abort (по одной
        #    аудит-строке каждый). ``store_file_append`` НЕ включён СОЗНАТЕЛЬНО:
        #    (1) он не делает привилегированной записи — только дописывает в наш
        #        собственный scratch в ``.derived/chunked/`` (тот же класс, что уже
        #        исключённые derived-инструменты reindex/submit_job);
        #    (2) привилегированная запись случается ровно в ``commit`` — и она в аудите,
        #        вместе с числом принятых частей (``parts=N``), так что «сколько было
        #        приёмов» видно ОДНОЙ строкой;
        #    (3) файл на 5 МБ = 320 частей = 320 аудит-строк на одну доставку; шум такой
        #        плотности ломает саму функцию аудита (найти в нём отказ/запись).
        #    ``store_file_status`` — read-only (плюс ленивая чистка истёкших сессий).
        "store_file_begin",
        "store_file_commit",
        "store_file_abort",
    }
)

# --------------------------------------------------------------------------- #
# CONTRACT-1 — реестр контрактов ссылок (FINDINGS §7, канон §9 п.21/23)          #
# --------------------------------------------------------------------------- #
# Зачем реестр, а не «починим найденные дырки». Спайк AUDIT-CONTRACT-1 нашёл 12 дырок
# round-trip, и все они одного рода: движок отдаёт ссылку в одной форме, а принимает в
# другой — при 2000+ зелёных тестов, потому что форму ответа не с чем было сверить. Здесь
# формы объявлены ЯВНО: ``emits`` — что инструмент отдаёт наружу, ``reads`` — что обязан
# принимать. Тест ``tests/test_contract_round_trip.py`` параметризуется этим реестром,
# поэтому НОВАЯ форма ссылки (или новый инструмент) попадает под гард автоматически:
# необъявленное поле-ссылка и непринимаемая форма — красный тест, а не следующий фейлкейс.
#
# Реестр держим рядом с ``WRITE_TOOLS``: ревью нового инструмента видит оба требования
# в одном месте («пишет → занеси в WRITE_TOOLS + аудит», «отдаёт/принимает ссылку →
# занеси в CONTRACTS»).

# Формы ссылок (Ф-коды — из §1 FINDINGS; строкой, чтобы реестр читался как таблица).
REF_FORMS: frozenset[str] = frozenset(
    {
        "note_rel",     # Ф1  vault-относительный путь заметки
        "note_abs",     # Ф2  абсолютный путь заметки внутри vault
        "inbox_file",   # Ф2  абсолютный путь файла-захвата в _staging/inbox (не заметка
                        #     vault: свой жизненный цикл, резолву ссылок не подлежит)
        "note_id",      # Ф3  frontmatter id заметки
        "file_name",    # Ф4  имя файла заметки без .md
        "legacy_id",    # Ф5  legacy-<hash>
        "src_rel",      # Ф6  source_path относительно корня хранилища/легаси
        "src_abs",      # Ф7  source_path абсолютный (опер. хранилище, iCloud)
        "conv",         # Ф8  виртуальный source_path переписки (conv:/msg:)
        "root_rel",     # Ф9  путь относительно ingest-корня (+ root_name отдельно)
        "file_ref",     # Ф10 склейка root_name/rel для file_refs
        "alias",        # Ф11 алиас рабочей папки
        "hub_id",       # Ф12 id хаба — РЕЗОЛВИТСЯ как ссылка на заметку-хаб
        "hub_scope",     # Ф12 id хаба как ФИЛЬТР/значение (не резолвится: контракт по
                         #     нему — честность пустоты, то есть класс Б / CONTRACT-2)
        "feed_id",      # Ф13 составной id пункта ленты «Работы»
        "external_id",  # Ф14 служебные/внешние id (proposal/candidate/capture/job/…)
        "deal_ref",     # Ф14 сделка: code или guid орбиты
        "source_hash",  # Ф14 byte-hash файла-источника
        "output_dir",   # Ф15 папка выхода под 07-outputs
        "dir_abs",      # Ф16 каталог-семейство в хранилище
        "root_name",    # имя ingest-корня (пара к root_rel)
    }
)


class ToolContract:
    """Контракт одного инструмента по ссылкам (только ссылки, не вся схема).

    ``emits`` — ``{"путь.в.ответе": "форма|форма"}``: что инструмент отдаёт наружу как
    ссылку. Несколько форм через ``|`` — только там, где это ОСОЗНАННО (иначе одно поле
    двух форм = дефект Д1).
    ``reads`` — ``{"параметр": {формы}}``: что инструмент обязан принимать.
    ``probe`` — как тест дёргает читателя: ``None`` = дёргает напрямую по ``reads``;
    строка = имя инструмента, через который форма уже покрыта (общий резолвер), с
    обоснованием в ``probe_note``.
    ``fails`` — коды деградации (CONTRACT-2), которые инструмент ОБЯЗАН уметь выдавать
    вместо тихого «правдоподобного» ответа. Каждый заявленный код проверяется тестом
    ``tests/test_contract_degradation.py``: ветку дёргают и требуют ``warning[].code``.

    Обычный класс, а не ``dataclass``: ``server.py`` грузят через
    ``importlib.util.module_from_spec`` без регистрации в ``sys.modules``, а
    ``@dataclass`` в таком модуле падает на резолве строковых аннотаций
    (``from __future__ import annotations``).
    """

    __slots__ = ("emits", "fails", "probe", "probe_note", "reads")

    def __init__(
        self,
        emits: dict[str, str] | None = None,
        reads: dict[str, frozenset[str]] | None = None,
        probe: str | None = None,
        probe_note: str = "",
        fails: tuple[str, ...] = (),
    ) -> None:
        self.emits = dict(emits or {})
        self.reads = dict(reads or {})
        self.probe = probe
        self.probe_note = probe_note
        self.fails = tuple(fails)


def _c(
    emits: dict[str, str] | None = None,
    reads: dict[str, set[str]] | None = None,
    *,
    probe: str | None = None,
    probe_note: str = "",
    fails: tuple[str, ...] = (),
) -> ToolContract:
    """Короткий конструктор записи реестра (реестр должен читаться как таблица)."""
    return ToolContract(
        emits=dict(emits or {}),
        reads={k: frozenset(v) for k, v in (reads or {}).items()},
        probe=probe,
        probe_note=probe_note,
        fails=fails,
    )


# Формы заметки, которые обязан принимать ЛЮБОЙ читатель заметки (ФП-1: одна точка
# резолва ``core.vault.resolve_note_path`` на всех).
_NOTE_FORMS = {"note_rel", "note_abs", "note_id", "file_name", "legacy_id"}
# + формы «ссылка, которую движок сам показывает как source_path заметки»: относительная
# корню хранилища, абсолютная и виртуальная почтовая. Набор ОДИН на всех читателей — это
# и есть обещание ФП-1 «одна точка резолва»; отдельного «облегчённого» набора нет, иначе
# матрица снова разъедется по читателям.
_NOTE_FORMS_FULL = _NOTE_FORMS | {"src_rel", "src_abs", "conv"}

CONTRACTS: dict[str, ToolContract] = {
    "reindex": _c({"db_path": "src_abs"}),
    "submit_job": _c({"job_id": "external_id"}),
    "job_status": _c({"job_id": "external_id", "result_ref": "src_abs"},
                     {"job_id": {"external_id"}}, fails=("store_unavailable",)),
    "job_list": _c({"[].job_id": "external_id"}),
    "job_cancel": _c({"job_id": "external_id"}, {"job_id": {"external_id"}}),
    "parse_task": _c({"params.client_id": "hub_id"}, fails=("skipped",)),
    "plan_task": _c({"params.client_id": "hub_id"}),
    "retrieve": _c({"slices[].note_id": "note_id", "slices[].source_path": "src_rel|src_abs",
                    "context[].note_id": "note_id"},
                   fails=("skipped",)),
    "generate": _c(
        {"output_dir": "output_dir", "sources[].note_id": "note_id",
         "sources[].source_path": "src_rel|src_abs", "facts[].source_path": "src_rel|src_abs",
         "exemplar.note_id": "note_id", "exemplar.path": "note_abs"},
        {"exemplar_ref": _NOTE_FORMS | {"src_abs"}, "require_facts": set()},
        fails=("unresolved_ref", "source_unavailable", "skipped"),
        probe="core:exemplar_from_ref",
        probe_note=(
            "exemplar_ref резолвится общим core.exemplars.exemplar_from_ref — он и "
            "пробуется (generate поверх него добавляет только ретривал и промпт)"
        ),
    ),
    "resolve": _c(
        {"sources[].note_id": "note_id", "sources[].source_path": "src_rel|src_abs",
         "hub_materials[].note_id": "note_id", "jobs[].job_id": "external_id"},
        {"source_refs": _NOTE_FORMS | {"src_rel", "src_abs"}},
        fails=("unresolved_ref", "source_unavailable", "skipped", "client_unresolved",
               "plan_inconsistent"),
        probe="lift_source",
        probe_note="source_refs закрываются общим core.sources.resolve_ref",
    ),
    "doctor": _c(),
    "owner_profile": _c(),  # PROFILE-1: ссылок не выдает и не читает (ни note_id, ни путей)
    # RETR-RANK-1: полнотекстовый индекс / кэш frontmatter недоступны, семантика недоступна, часть
    # заметок не прочиталась → выдача цела, но с конвертом ``store_unavailable`` /
    # ``unavailable`` / ``partial`` — не молча.
    "find_notes": _c({"notes[].note_id": "note_id", "notes[].path": "note_rel",
                      "notes[].source_path": "src_rel|src_abs|conv"},
                     fails=("store_unavailable", "unavailable", "partial")),
    "find_latest": _c({"families[].directory": "dir_abs", "families[].latest.path": "src_abs",
                       "families[].latest_final.path": "src_abs", "families[].seed": "src_abs",
                       "families[].members[].path": "src_abs", "families[].note_id": "note_id"}),
    "read_note": _c({"path": "note_rel", "id": "note_id"},
                    {"path": _NOTE_FORMS_FULL}),
    "attribute_note": _c({"path": "note_abs", "note_id": "note_id"},
                         {"path": _NOTE_FORMS_FULL, "client_id": {"hub_scope"}}),
    "lift_source": _c({"path": "src_abs", "newer_sibling.path": "src_abs",
                       "content_hash": "source_hash"},
                      {"note_id": _NOTE_FORMS, "path": {"src_rel", "src_abs", "note_rel"}}),
    "get_facts": _c({"[].source_path": "src_rel|src_abs", "[].entity_ref": "hub_id"},
                    {"note_id": _NOTE_FORMS, "source_path": {"src_rel", "src_abs"}},
                    fails=("filter_not_applied", "store_unavailable"),
                    probe="lift_source",
                    probe_note="та же core.sources.resolve_ref; фильтр — класс Б (CONTRACT-2)"),
    "find_exemplar": _c({"exemplar.note_id": "note_id", "exemplar.path": "note_abs",
                         "exemplar.source_path": "src_rel|src_abs"},
                        {"client": {"hub_scope"}}),
    "ingest_scan": _c({"root_names": "root_name"}, {"root": {"root_name"}}),
    "output_begin": _c({"output_dir": "output_dir"}),
    # STYLE-GUARD-1: ``style_markers`` — ИИ-маркеры найдены (не отказ: текст сохранён,
    # правка за человеком); ``store_unavailable`` — канон ai-markers.yaml не прочитался,
    # и «проверка не состоялась» обязано отличаться от «текст чист». Конверты у этого
    # инструмента едут ключом ``warning_envelopes``: ``warning`` занят человекочитаемой
    # строкой доконвертной эпохи (CONTRACT-2 её сознательно не трогает), а ``warnings_of``
    # сводит оба ключа — телеметрия и гард класса Б их не различают.
    "save_output": _c({"path": "note_abs", "delivered.path": "root_rel",
                       "delivered.root_name": "root_name", "related[]": "hub_id"},
                      {"output_dir": {"output_dir"}, "file_refs": {"file_ref", "root_rel"},
                       "dest": {"alias", "root_rel"}},
                      fails=("style_markers", "store_unavailable", "source_incomplete",
                             "not_read_in_window")),
    "store_file": _c({"path": "root_rel"}, {"root_name": {"root_name"}, "rel_path": {"root_rel"}}),
    "store_file_begin": _c({"session_id": "external_id", "path": "root_rel"},
                           {"root_name": {"root_name"}, "rel_path": {"root_rel"}}),
    "store_file_append": _c(reads={"session_id": {"external_id"}}),
    "store_file_status": _c({"path": "root_rel"}, {"session_id": {"external_id"}}),
    "store_file_commit": _c({"path": "root_rel"}, {"session_id": {"external_id"}}),
    "store_file_abort": _c(reads={"session_id": {"external_id"}}),
    # FILE-LOCAL-1: ``source_path`` — абсолютный путь файла на диске. Форма ``src_abs``
    # та же, что отдаёт сам инструмент в ``abs_path`` (и что принимает ``lift_source``):
    # доставленный файл можно тут же поднять или переложить, не собирая путь руками.
    "place_download": _c({"path": "root_rel", "abs_path": "src_abs", "alias": "alias"},
                         {"dest": {"alias", "root_rel"}, "root_name": {"root_name"},
                          "source_path": {"src_abs"}}),
    # Отказы источника (``source_not_found``/``source_is_dir``/``bad_source_path``/
    # ``nda``) едут в форме семейства store_file — ``{ok:false, refused:true, code}``,
    # а не конвертом ``warning`` (в ``fails`` объявляют именно конверты): две формы
    # одного отказа у одного инструмента читались бы хуже, чем одна. Коды проверяет
    # ``tests/test_place_download.py``; телеметрия отказов их видит по ``refused+code``.
    "folder_alias_list": _c({"aliases[].name": "alias", "aliases[].rel_path": "root_rel",
                             "aliases[].root_name": "root_name"}),
    "folder_alias_set": _c({"name": "alias", "rel_path": "root_rel", "root_name": "root_name"},
                           {"alias": {"alias"}, "root_name": {"root_name"},
                            "rel_path": {"root_rel"}}),
    "list_inbox": _c({"[].file": "inbox_file"}),
    "refine_inbox": _c({"[].file": "inbox_file"}),
    "apply_refinement": _c({"written_path": "note_abs", "cleared_inbox_file": "inbox_file"},
                           {"inbox_file": {"inbox_file"}}),
    "propose_links": _c({"proposals[].id": "external_id", "proposals[].source": "note_id",
                         "proposals[].target": "note_id"},
                        {"scope": _NOTE_FORMS},
                        probe="core:select_sources",
                        probe_note=(
                            "форму ``scope`` резолвит core.linking.propose.select_sources — "
                            "он и пробуется; сам инструмент поверх него требует LanceDB "
                            "(семантические кандидаты), к контракту ссылки не относящегося"
                        )),
    "apply_links": _c({"touched_notes[]": "note_id"}, {"approve_ids": {"external_id"}},
                      fails=("skipped",)),
    "pult_kpi": _c(fails=("no_runs", "store_unavailable")),  # EVAL-3: секция health
    "pult_sync_status": _c({"log_path": "src_abs"}),
    "pult_log_tail": _c({"path": "src_abs"}),  # log_present — признак, не конверт
    "pult_run_sync": _c(fails=("skipped", "bad_steps")),
    "pult_activity": _c(fails=("partial",)),
    "pult_freshness": _c(),
    "pult_monitor": _c({"services[].key": "external_id", "jobs[].job_id": "external_id",
                        "storage.db.path": "src_abs", "sync.log_path": "src_abs"}),
    "pult_manifest": _c(),
    "pult_services": _c({"[].key": "external_id"}),
    "pult_service_control": _c(reads={"key": {"external_id"}}),
    "pult_events": _c({"[].note_id": "note_id", "[].path": "note_rel|src_abs",
                       "[].source_hash": "source_hash"},
                      {"note_id": _NOTE_FORMS_FULL, "source_hash": {"source_hash"}},
                      fails=("store_unavailable",)),
    "pult_ingest_sources": _c({"[].key": "external_id", "[].path": "src_abs"}),
    "pult_ingest_trace": _c({"rows[].source_path": "src_rel|src_abs",
                             "rows[].note_path": "note_rel"}),
    "pult_storage_status": _c({"db.path": "src_abs"}),
    "pult_storage_action": _c({"job_id": "external_id"}, fails=("partial",)),
    "pult_paths_get": _c({"roots[].name": "root_name", "roots[].path": "src_abs"}),
    "pult_paths_set": _c({"roots[].name": "root_name"}, {"roots": {"root_name"}}),
    # PULT-STANDALONE-1: настройки/синтез не отдают и не принимают ссылок на заметки
    "pult_settings_get": _c(),
    "pult_settings_set": _c(),
    "pult_ai": _c(),
    "pult_choose_folder": _c({"path": "src_abs"}),
    # QUEUE-SERVER-1: id карточки = ``<вид>:<родной id>`` - ключ очереди, не ссылка на заметку
    "pult_cards": _c({"cards[].id": "external_id"}),
    "pult_card_decide": _c(reads={"card_id": {"external_id"}}),
    "pult_card_explain": _c({"why.draft.deal.guid": "deal_ref"},
                            {"card_id": {"external_id"}}),
    # id строки очереди = id хаба, но принимается ТОЛЬКО как ключ очереди (не путь/имя файла)
    # EVAL-3: плитка «Качество выдачи» — ссылок на заметки не отдаёт, только id запросов
    # золотого набора (external_id) и note_id в топ-3 выдачи промахов.
    "pult_eval": _c({"misses[].id": "external_id", "misses[].top[]": "note_id",
                     "stale_ids[]": "external_id"},
                    fails=("no_runs", "store_unavailable")),
    "pult_create_hub": _c({"hub_id": "hub_id", "path": "note_rel"}),
    "pult_hub_add_note": _c({"path": "note_rel"},
                            {"note_path": _NOTE_FORMS | {"hub_id"}}),
    # HUB-SYNTH-1: ``hub.id``/``hub.path`` - хаб; локаторы дельты разнородны (note_id, путь
    # источника, ``deal:<код>``, ключ треда ``conv:…``) и читаются read_note/lift_source сами
    "hub_synth_context": _c({"hub.id": "hub_id", "hub.path": "note_rel"},
                            {"hub_id": _NOTE_FORMS | {"hub_id"}},
                            probe="pult_set_track",
                            probe_note="общий hub_link._resolve_hub"),
    "hub_synth_propose": _c({"hub_id": "hub_id", "card_id": "external_id"},
                            {"hub_id": _NOTE_FORMS | {"hub_id"}},
                            probe="pult_set_track",
                            probe_note="общий hub_link._resolve_hub"),
    "pult_ripe_leads": _c({"leads[].id": "hub_id", "leads[].path": "note_rel"}),
    "pult_deals": _c({"[].guid": "deal_ref", "[].code": "deal_ref", "[].linked_hub": "hub_id"}),
    "pult_function": _c({}, fails=("bad_rings",)),
    "pult_watch": _c({"deal": "deal_ref", "items[].guid": "deal_ref"}, {"deal_guid": {"deal_ref"}},
                     fails=("item_not_found", "deal_deleted", "skipped")),
    "pult_hub_link_deal": _c({"hub_id": "hub_id", "path": "note_rel"},
                             {"hub_id": _NOTE_FORMS | {"hub_id"}, "deal_guid": {"deal_ref"}},
                             probe="pult_set_track",
                             probe_note="общий hub_link._resolve_hub; link требует зеркала"),
    "pult_hub_unlink_deal": _c({"hub_id": "hub_id"},
                               {"hub_id": _NOTE_FORMS | {"hub_id"}},
                               probe="pult_set_track",
                               probe_note="общий hub_link._resolve_hub"),
    "pult_set_track": _c({"hub_id": "hub_id", "path": "note_rel"},
                         {"hub_id": _NOTE_FORMS | {"hub_id"}}),
    "work_feed": _c({"attention[].id": "feed_id", "stale[].id": "feed_id",
                     "attention[].clients[]": "hub_id"}, fails=("bad_rings",)),
    "work_resurface": _c({"pairs[].id": "feed_id", "pairs[].new_note.id": "note_id",
                          "pairs[].new_note.path": "note_rel"}),
    "work_dismiss": _c(reads={"item_id": {"feed_id"}}),
    "work_context": _c(reads={"item_id": {"feed_id"}}, fails=("unavailable",)),
    "work_note_preview": _c(reads={"name": _NOTE_FORMS_FULL}),
    "work_meetings": _c({"meetings[].entryID": "external_id"}),
    "work_ticktick": _c({"tasks[].id": "external_id"}, fails=("unavailable",)),
    "work_meeting_prep": _c({"clients[].id": "hub_id", "entities[].id": "external_id"},
                            {"client_ids": {"hub_scope"},
                             "entity_id": {"external_id", "hub_scope"}},
                            fails=("unresolved_ref",)),
    "pult_web_status": _c(fails=("unavailable",)),
    "pult_web_restart": _c(),
}

# Осознанные исключения: ``(форма, инструмент)`` → почему форма НЕ принимается. Пустой
# словарь был бы удобнее, но нечестным: часть форм не должна резолвиться by design.
CONTRACT_NA: dict[tuple[str, str], str] = {
    ("conv", "lift_source"): (
        "виртуальный ключ треда (correspondence/conv:…) — файла за ним нет вовсе, "
        "поднимать нечего: правильный ответ — честный unavailable, а не заметка"
    ),
}
# Словарь короткий не потому, что исключений «не нашли», а потому что после ФП-1 читатели
# заметок принимают ОДИН набор форм: осознанное исключение осталось ровно одно. Каждая
# клетка здесь проверяется тестом на ОТКАЗ — фиктивных исключений быть не может.

# --------------------------------------------------------------------------- #
# FAIL-TELEMETRY-1 — что считать «агент споткнулся» (и что НЕ считать)          #
# --------------------------------------------------------------------------- #
# Учёт живёт на границе MCP (обёртка :func:`guarded_tool`), а не в core: код деградации
# уже есть в ОТВЕТЕ инструмента — CONTRACT-2 сделал его машиночитаемым, — и одна обёртка
# видит их все, включая те, что вернулись из core через три слоя. Правило про исключения
# держим здесь же, рядом с реестром ``CONTRACTS``: и код деградации, и решение «это не
# отказ» должны читаться в одном месте, иначе телеметрия разъедется с конвертом.
#
# Считаем ТОЛЬКО машинные признаки отказа:
#   * конверты CONTRACT-2 — ``warning: [{code, …}]``;
#   * ``refused`` (гарды записи, param_limit) — код в ``refused``/``code``;
#   * ``ok: false`` + ``code``; ``found: false`` + ``code``.
# Человекочитаемая строка-``warning`` доконвертной эпохи (SRC-FRESH-1 в ``find_notes``,
# ``deliver_output``, ``save_output``) отказом НЕ является: это подсказка «есть файл
# свежее», ответ при этом здоров. Считать её значило бы утопить сигнал в фоне — а фон
# перестают читать, и телеметрия отказов умрёт той же смертью, что и жёлтый доктор.
DEGRADATION_EXEMPT: frozenset[tuple[str, str]] = frozenset(
    {
        # (инструмент, код) — подсказки свежести SRC-FRESH-1, не отказ.
        ("find_notes", "date_spread"),
        ("find_latest", "date_spread"),
        ("lift_source", "stale_hint"),
    }
)
# Код кладём в журнал только в машинном виде (a-z, 0-9, ``_.-``): в ``code`` попадает
# ``exc.code`` из разных слоёв, и privacy телеметрии не должна зависеть от того, не
# положил ли кто-то однажды в код имя файла. Всё непохожее на код → ``other``.
_CODE_RE = re.compile(r"^[a-z0-9][a-z0-9_.\-]{0,47}$")

# FT-12 — дефолты чатовых параметров ``place_download``. Держим литералами: схему
# инструмента FastMCP строит по сигнатуре, и она должна читаться в чате как есть.
# Дрейф от core-дефолтов стережёт ``tests/test_place_download.py``.
_PLACE_DEFAULT_ROOT = "current"
_PLACE_DEFAULT_MAX_AGE_MINUTES = 60


def _preview(text: str, limit: int = _PREVIEW_CHARS) -> str:
    text = (text or "").strip()
    return text if len(text) <= limit else text[:limit].rstrip() + "…"


def _fact_provenance(fact: Any) -> dict[str, Any]:
    """Whitelisted provenance view of one used fact (FACT-1) for the draft UI (PULT-WORK).

    Only the fields the «Работа» draft-provenance shows — label + value (raw/num +
    unit/currency/НДС), the back-traceable locator, confidence and the ``stale_hint``
    (values from xlsx formula-cache → «проверь свежесть»), plus the source path for
    an obsidian:// / file link. Privacy: no ``fact_id``/content_hash/extractor
    internals leak (mirrors the UX-4 whitelist for context notes).
    """
    return {
        "label": getattr(fact, "label", None),
        "value_raw": getattr(fact, "value_raw", None),
        "value_num": getattr(fact, "value_num", None),
        "unit": getattr(fact, "unit", None),
        "currency": getattr(fact, "currency", None),
        "vat_flag": getattr(fact, "vat_flag", None),
        "kind": getattr(fact, "kind", None),
        "locator": getattr(fact, "locator", None),
        "confidence": getattr(fact, "confidence", None),
        "stale_hint": bool(getattr(fact, "stale_hint", False)),
        "source_path": getattr(fact, "source_path", None),
    }


def _result_brief(slice_name: str, r: SearchResult) -> dict[str, Any]:
    """Compact view of one retrieval hit for inspection (note_id / slice / score)."""
    return {
        "note_id": r.note_id,
        "slice": slice_name,
        "score": round(r.score, 4),
        "corpus": r.metadata.get("corpus", "vault"),
        "curated": r.metadata.get("curated", True),
        "source_path": r.source_path,
        "heading_path": r.heading_path,
        "context_prefix": r.metadata.get("context_prefix", ""),
        "section_id": r.metadata.get("section_id", ""),
        "parent_section": bool(r.metadata.get("parent_section", False)),
        "preview": _preview(r.text),
    }


# --------------------------------------------------------------------------- #
# Tool wrappers — thin shims over core. Each returns JSON-serializable data.   #
# --------------------------------------------------------------------------- #


def reindex(scope: str = "incremental", async_: bool = False) -> dict[str, Any]:
    """(Re)build the LanceDB index from the vault.

    ``scope="incremental"`` (default) re-embeds only new/changed notes and drops
    chunks of changed/removed ones, diffing against the index manifest — fast
    after a small batch (e.g. a Track-D drop). ``scope="full"`` forces a drop +
    recreate that re-embeds everything (needed on a schema/model/chunker change);
    an incremental call with no existing table/manifest auto-falls-back to full.
    The first call is slow — BGE-M3 loads lazily from the local cache. Returns
    the disposition counts (new/changed/deleted/unchanged), chunks (re)embedded,
    device, and timing.

    ``async_=True`` runs it off the MCP client's ceiling (JOB-1): returns
    ``{job_id, op, state}`` immediately and the chat polls :func:`job_status` — use
    it for a full rebuild that would otherwise outlast the per-tool timeout.
    """
    if scope not in ("incremental", "full"):
        raise ValueError(
            f"unsupported scope {scope!r}; use 'incremental' (default) or 'full'"
        )
    if async_:
        return submit_job("reindex", {"scope": scope})
    stats = _core_reindex(default_vault_path(), full=(scope == "full"))
    return stats.report(scope)


def submit_job(op: str, args: dict[str, Any] | None = None) -> dict[str, Any]:
    """Запустить долгую операцию АСИНХРОННО и вернуть ``job_id`` мгновенно (JOB-1).

    Обходит клиентский потолок на инструмент (~минуты): тяжёлое чтение моста /
    ``reindex`` / подъём большого файла уходит в **detached-воркер**, вызов
    возвращается сразу, а чат опрашивает :func:`job_status` по ``job_id`` — клиент
    не отваливается по таймауту (фейл Acme «4-минутные таймауты»).

    Белый список ``op`` (иначе ошибка): ``reindex`` (``args={"scope":
    "incremental"|"full"}``); ``outlook_read`` (``args={"mode": "meetings"|
    "ticktick"|"mail", "days"?, "since"?, "scope"?}``); ``lift_source``
    (``args={"note_id"?|"path"?, "sheet"?, "cell_range"?, "max_cells"?}``).
    Прогресс пишется durable (переживает рестарт сервера) и в маяк —
    ``pult_activity`` видит задание. Path B: воркер гоняет саму операцию, без LLM.

    Возврат ``{job_id, op, state: "queued"}``.
    """
    from core import connectors as _connectors
    from core.contract import connector_disabled_refusal, op_not_available_refusal
    from core.orchestration.jobs import JobError, OpNotAvailable, submit

    try:
        job_id = submit(op, dict(args or {}))
    except OpNotAvailable as exc:  # PERSONAL-3: op вне роли - конверт отказа, не исключение
        return op_not_available_refusal(exc.op, exc.role, exc.available)
    except _connectors.ConnectorDisabled as exc:  # DEV-3-CORE: op выключенного коннектора
        return connector_disabled_refusal("submit_job", exc.connectors,
                                          _connectors.enable_hint(exc.connectors), op=op)
    except JobError as exc:
        raise ValueError(str(exc)) from exc
    return {"job_id": job_id, "op": op, "state": "queued"}


def job_status(job_id: str) -> dict[str, Any]:
    """Состояние/прогресс/результат асинхронного задания по ``job_id`` (JOB-1).

    Читает durable-хранилище (``jobs.db`` + результат из ``.derived/jobs/<id>.json``),
    поэтому переживает рестарт сервера. Возврат: ``{job_id, op, state:
    queued|running|done|failed|cancelled|unknown, phase, current, total,
    cancel_requested}``; для ``done`` — ``result`` (payload операции) + ``result_ref``;
    для ``failed`` — ``error``. Прогресс пишется по ходу (фазы/счётчики), не молчит
    до конца. ``state: "unknown"`` при НЕпрочитанной таблице несёт ``warning`` с
    ``store_unavailable`` (CONTRACT-2 С7): «нет такого задания» и «БД недоступна» —
    разные вещи.
    """
    from core.orchestration.jobs import status

    return status(job_id)


def job_list(state: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
    """Список недавних async-заданий (JOB-1) для панели «Задания» пульта.

    Паритет с ``dt-job list``: читает durable ``dt.db.jobs`` (переживает рестарт
    сервера), новые сверху; ``state`` (``queued|running|done|failed|cancelled``)
    фильтрует, ``limit`` ограничивает. По каждому — компактная строка для UI:
    ``{job_id, op, state, phase, current, total, cancel_requested, created_at,
    updated_at}`` (прогресс — как в ``job_status``, без чтения тяжёлого результата
    с диска). Read-only.
    """
    from core.operational.monitor import compact_jobs
    from core.orchestration.jobs import list_jobs

    return compact_jobs(list_jobs(state=state or None, limit=max(1, int(limit))))


def job_cancel(job_id: str) -> dict[str, Any]:
    """Запросить мягкую отмену async-задания (JOB-1). Действие.

    Паритет с ``dt-job cancel``: обёртка над ``core.orchestration.jobs.cancel`` —
    ``queued`` гасится сразу как ``cancelled``; ``running`` получает кооперативный
    флаг (воркер остановится на ближайшем чекпойнте) + best-effort SIGTERM;
    терминальное — no-op. Возвращает актуальный ``job_status`` после запроса.
    """
    from core.orchestration.jobs import cancel

    return cancel(job_id)


def parse_task(text: str) -> dict[str, Any]:
    """Interpret a natural-language task into a use case + entity params.

    Returns ``use_case_id``, ``params`` and a human-readable ``interpretation``
    for the user to confirm in the conversation *before* generating. It does not
    run generation.
    """
    parsed = _core_parse_task(text)
    out: dict[str, Any] = {
        "use_case_id": parsed.use_case_id,
        "params": parsed.params,
        "interpretation": parsed.interpretation,
        # CONTRACT-2 С12: распознан кейс или подставлен дефолт.
        "detected": parsed.detected,
    }
    if not parsed.detected:
        from core.contract import CODE_SKIPPED, add_warning

        add_warning(
            out, CODE_SKIPPED,
            f"кейс не распознан по тексту — подставлен дефолт {parsed.use_case_id!r}; "
            "если задача другая, передай use_case_id явно (иначе политика подбора "
            "будет чужой)",
            use_case_id=parsed.use_case_id,
        )
    # Пустые ``params`` конвертом НЕ помечаем: у задачи законно может не быть сущности,
    # и предупреждение на каждый такой вызов стало бы фоном (а фон не читают). Ущерб от
    # ненайденной сущности виден там, где он возникает — ``skipped_slices`` у
    # retrieve/generate (С3), с именем недостающего параметра.
    return out


def plan_task(
    task: str,
    use_case_id: str | None = None,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Материализовать план кейса и прозондировать, что уже готово (PLAN-1).

    Делает оркестрацию **видимой** ДО генерации: по кейсу раскладывает задачу в
    явный чек-лист узлов-ресурсов с критичностью (детерминированный шаблон, без
    LLM), затем read-only зондирует статус каждого — `present`/`missing`/`unknown`
    — реюзая существующие резолверы (`get_facts`/`find_exemplar`/`run_policy`).
    Так «найди образец» — узел плана, а не забытый пункт (фейл-кейс Acme).

    Без `use_case_id` — реюз `parse_task` (кейс+params из NL). `blocking` — только
    критичные `missing` в том же формате `{what,kind,how}`, что GATE-1, чтобы
    чат/пульт показывал единый список «нужно закрыть». Ничего не пишет (безопасно
    гонять как preview). Крит. узлы этого плана становятся требованиями гейта при
    `generate(use_plan=True)`.
    """
    from core.metrics import record_event
    from core.orchestration.planner import plan as _plan
    from core.orchestration.planner import resolve_status

    resolved_params = dict(params or {})
    if use_case_id is None:
        parsed = _core_parse_task(task)
        use_case_id = parsed.use_case_id
        # Parsed params seed the probe; explicit params override.
        resolved_params = {**parsed.params, **resolved_params}

    the_plan = _plan(use_case_id, resolved_params)
    resolve_status(the_plan, resolved_params, vault_path=default_vault_path(), query=task)
    blocking = the_plan.blocking()

    # KPI/observability, privacy — only use-case id and the blocking kinds.
    record_event(
        "plan",
        use_case=use_case_id,
        missing_kinds=[b["kind"] for b in blocking],
    )
    return {
        "use_case_id": use_case_id,
        "params": resolved_params,
        "plan": the_plan.to_dict(),
        "blocking": blocking,
    }


_CORPUS_SCOPE = {"both": None, "vault": "vault", "legacy": "legacy"}


def retrieve(
    use_case_id: str,
    query: str,
    params: dict[str, Any] | None = None,
    corpus: str = "both",
    client: str | None = None,
    section: str | None = None,
    era: str | None = None,
    include_eval: bool = False,
) -> dict[str, Any]:
    """Run a use case's retrieval policy and return the slices (no generation).

    For inspecting what context a task would pull: per-slice hits
    (note_id / slice / score + a short preview) plus the de-duplicated context.

    ``corpus`` sets the layer scope (Phase 5): ``"both"`` (default — curated +
    legacy with the curated boost), ``"vault"`` (vault-only flag, curated only),
    or ``"legacy"``. ``client``/``section``/``era`` are folded into ``params`` so a
    legacy-aware policy slice (filtering on those fields) can use them.

    Each hit carries ``context_prefix`` (контекстная строка чанка «документ › раздел · клиент ·
    дата», отделена от ``preview``) and ``section_id``; ``parent_section: true`` — хит расширен
    до родительской секции (ключ ``parent_section`` слайса; дефолт — документы current/legacy).
    """
    merged = dict(params or {})
    for key, value in (("client", client), ("section", section), ("era", era)):
        if value:
            merged.setdefault(key, value)
    if client:
        merged.setdefault("client_id", client)

    result = _core_run_policy(
        use_case_id, query, merged, corpus=_CORPUS_SCOPE.get(corpus),
        **({"include_eval": True} if include_eval else {}),
    )
    slices = {
        name: [_result_brief(name, r) for r in hits]
        for name, hits in result.slices.items()
    }
    context = [_result_brief("context", r) for r in result.context]
    out: dict[str, Any] = {
        "use_case": result.use_case,
        "corpus": corpus,
        "style_guide": result.style_guide,
        "template": result.template,
        "web": result.web,
        "slices": slices,
        "context": context,
    }
    _skipped_slices_warning(out, result)
    return out


def _skipped_slices_warning(payload: dict[str, Any], result: Any) -> dict[str, Any]:
    """Конверт про слайсы, которые не отработали (CONTRACT-2 С3).

    Пропуск по ``when`` — штатное выключение опционального слайса, о нём молчим.
    Нерезолвнутый параметр — другое: область поиска МОЛЧА сузилась (клиент не
    распознан → в промпт уехал один стилевой слайс, и выглядит это нормально
    работающим). Такое обязано быть видно машине, а не только по отсутствию ключа.
    """
    from core.contract import CODE_SKIPPED, add_warning

    dropped = [
        s for s in getattr(result, "skipped_slices", []) or []
        if s.get("reason") == "missing_param"
    ]
    if not dropped:
        return payload
    payload["skipped_slices"] = dropped
    add_warning(
        payload, CODE_SKIPPED,
        "слайсы политики не отработали (нет параметра): "
        + ", ".join(f"{s['name']} (нужен {s.get('param') or '?'})" for s in dropped)
        + " — область подбора у́же заявленной политикой",
        skipped=[s["name"] for s in dropped],
    )
    return payload


def generate(
    use_case_id: str,
    task: str,
    params: dict[str, Any] | None = None,
    corpus: str = "both",
    persist: bool = True,
    require_facts: list[str] | None = None,
    require_context: bool = False,
    exemplar: bool = False,
    exemplar_ref: str | None = None,
    use_plan: bool = False,
    model: str | None = None,
) -> dict[str, Any]:
    """Assemble the generation prompt + write provenance; return the prompt.

    Path B: this does **not** produce the artifact. It runs retrieval, composes
    the full prompt (system / style guide / exemplars / facts / context / template
    / task), and writes ``07-outputs/YYYY-MM/<task-id>/`` with prompt.md,
    sources.md, policy.yaml and meta.yaml. the host's chat model then writes the artifact
    from the returned ``prompt`` and ``save_output`` saves it next to provenance.

    ``corpus`` scopes the retrieval layer (Phase 5): ``"both"`` (default — curated
    + legacy with the curated boost; legacy blocks are marked as raw source
    material), or ``"vault"`` for clean generation on curated knowledge only
    (no legacy raw material), or ``"legacy"`` for source-only.

    **Grounding gate (GATE-1).** After assembly the declared critical resources
    are checked: fact kinds in the policy's ``required_facts`` (plus the
    ``require_facts`` param) and, when ``required_context`` / ``require_context``
    is set, a non-empty retrieval. If any are unmet the call is **blocked**:
    returns ``{status:"blocked", missing:[{what,kind,how}], reason}`` with **no
    ``prompt``** and **no output/provenance folder** (even at ``persist=True``) —
    an honest stop with how-to instead of a stub-inviting prompt. When satisfied
    (or nothing is required) behaviour is unchanged, plus ``status:"ok"``.

    **Provenance (UX-4 / PULT-WORK).** The ``status:"ok"`` response carries
    ``sources`` (deduped vault notes that fed the prompt), ``facts`` (the used
    structured facts — ``label``/``value_raw``/``value_num``/``unit``/``currency``/
    ``vat_flag``/``kind``/``locator``/``confidence``/``stale_hint``/``source_path``;
    empty when the policy uses no facts) and ``exemplar`` (the form-exemplar behind
    ``[Образец оформления]``, when one led it). All whitelisted — no extractor/id
    internals leak — so «Работа» can show what grounded the draft.

    **Form exemplar (TMPL-1).** With ``exemplar=True`` (or the policy's
    ``exemplar: true``, or an explicit ``exemplar_ref`` = note id / source path) a
    real past document's *form* is resolved and injected as the ``[Образец
    оформления]`` section (before ``[Output format]``) so generation clones the
    structure and letterhead instead of inventing them. When a case declares
    ``required_facts: [exemplar]`` and none is found, the gate blocks with
    ``kind="exemplar"`` and a how-to.

    **Task plan (PLAN-1).** With ``use_plan=True`` the case's critical plan nodes
    (:mod:`core.orchestration.planner`) auto-become grounding requirements — e.g.
    for ``commercial_offer`` that is ``money`` + ``exemplar`` + ``requisite`` — so
    the critical decomposition is enforced without hand-authoring each policy.
    Default ``False`` keeps behaviour unchanged (backward compatible).

    ``model``: the host's chat model, declared here (``save_output(model=…)`` overrides).
    """
    from core.metrics import record_event
    from core.orchestration.resolve import resolve_task

    params = params or {}

    # ORCH-RESOLVE PART-3: one orchestration path. Delegate plan → lift/probe →
    # assemble → gate to the shared runner; generate adds only prompt + persist on
    # top. ``assemble_fn=_core_assemble_prompt`` routes assembly through this
    # module's patchable reference (so existing generate tests still stub it);
    # ``probe_plan=False`` keeps generate's fast path (no standalone plan probe) and
    # backward-compatible behaviour when ``use_plan=False``. Side benefit: with
    # ``use_plan=True`` generate now also *lifts* the missing sources, not just probes.
    res = resolve_task(
        use_case_id,
        task,
        params,
        corpus=corpus,
        lift=True,
        use_plan=use_plan,
        probe_plan=False,
        require_facts=require_facts,
        require_context=require_context,
        exemplar=exemplar,
        exemplar_ref=exemplar_ref,
        vault_path=default_vault_path(),
        assemble_fn=_core_assemble_prompt,
    )

    # KPI/observability (audit §6): grounding-block rate. Privacy — only status,
    # missing kinds and the generic use-case id; no task/params/content.
    record_event(
        "gate",
        status=res.status,
        use_case=res.use_case_id,
        missing_kinds=[m["kind"] for m in res.missing],
    )

    if res.status == "blocked":
        # Nothing generated → no prompt, and no output/provenance folder even at
        # persist=True (don't spawn an empty artifact dir).
        blocked: dict[str, Any] = {
            "use_case_id": use_case_id,
            "corpus": corpus,
            "status": "blocked",
            "missing": res.missing,
            "reason": (
                "grounding gate: не хватает критичных ресурсов "
                f"({', '.join(m['kind'] for m in res.missing)}) — генерация "
                "остановлена, заглушки не выдаются"
            ),
        }
        _degradations(blocked, res)
        return blocked

    # An ``ok`` verdict always carries the assembled prompt (the runner assembles
    # before gating) — narrow the Optional for the provenance/return below.
    assembled = res.assembled
    assert assembled is not None  # noqa: S101 — type-narrowing assert; non-None guaranteed above

    # ``persist`` (default True — CLI/chat Path B пишет provenance-папку под
    # сохраняемый артефакт). ``False`` — эфемерная генерация (черновик из пульта,
    # который тыкают на пробу): ничего на диск не пишем, папок-мусора нет.
    if persist:
        out_dir = create_output_dir(use_case_id, task or use_case_id)
        # назначение (eval/selftest) write_provenance определяет сам: фраза задачи в промпте, хост
        write_provenance(out_dir, assembled, model=model)
    else:
        out_dir = None
    # Provenance for the UI (UX-4): which vault notes fed the prompt, deduped by
    # note, so the caller can show "использовано N заметок" with obsidian:// links.
    sources: list[dict[str, Any]] = []
    seen: set[str] = set()
    for chunk in assembled.context:
        r = chunk.result
        if r.note_id in seen:
            continue
        seen.add(r.note_id)
        sources.append(
            {
                "note_id": r.note_id,
                "source_path": r.source_path,
                "heading_path": r.heading_path,
                "slice": chunk.slice,
            }
        )
    result: dict[str, Any] = {
        "use_case_id": use_case_id,
        "output_dir": str(out_dir),
        "corpus": corpus,
        "status": "ok",
        "prompt": assembled.prompt,
        "sources": sources,
        # Provenance for the used structured facts (FACT-1), so the «Работа» draft
        # can show «использованные факты» with locators/confidence/stale (PULT-WORK
        # PART-1). Whitelisted (privacy); empty list when the policy uses no facts.
        "facts": [_fact_provenance(f) for f in assembled.facts],
    }
    # Provenance for the form-exemplar (TMPL-1), when one led the [Output format].
    if assembled.exemplar is not None:
        result["exemplar"] = assembled.exemplar.to_dict()
    # CONTRACT-2: что не разрешилось — вслух, даже когда гейт пропустил (политика
    # образца не требовала). Промпт при этом собран БЕЗ секции «Образец оформления»,
    # а не с чужой формой.
    _degradations(result, res)
    _skipped_slices_warning(result, assembled.policy_result)
    return result


def _degradations(payload: dict[str, Any], res: Any) -> dict[str, Any]:
    """Конверты деградации раннера в ответ инструмента (CONTRACT-2 С2/С4).

    Два случая, оба про ЯВНО заданную ссылку, которая не разрешилась:

    * ``exemplar_ref`` (С2) — образца нет, и подмены другим документом НЕ было: раньше
      КП для одного клиента молча собиралось по бланку другого. При политике с
      ``required_facts: [exemplar]`` гейт вдобавок блокирует — но сказать вслух надо и
      тогда, когда не блокирует (промпт просто без секции формы);
    * ``source_refs``/``note_id``/``source_path`` (С4) — источник не поднялся, и
      «lifted_n: 0» без причины неотличимо от «источников и не просили».
    """
    from core.contract import (
        CODE_CLIENT_UNRESOLVED,
        CODE_PLAN_INCONSISTENT,
        CODE_SOURCE_UNAVAILABLE,
        CODE_UNRESOLVED_REF,
        add_warning,
    )

    unresolved_client = getattr(res, "client_unresolved", None)
    if unresolved_client:
        add_warning(
            payload, CODE_CLIENT_UNRESOLVED,
            "клиент не распознан: назови client_id или добавь имя в aliases хаба",
            mentioned=unresolved_client.get("mentioned"),
            skipped=unresolved_client.get("slices"),
            param="client_id",
        )
    inconsistent = list(getattr(res, "plan_inconsistent", []) or [])
    if inconsistent:
        add_warning(
            payload, CODE_PLAN_INCONSISTENT,
            "план противоречит ответу: узел помечен как имеющийся, а собранных данных нет "
            "и гейт считает их недостающими (узел понижен до partial): "
            + ", ".join(i["kind"] for i in inconsistent),
            nodes=[i["kind"] for i in inconsistent],
        )

    ref = getattr(res, "exemplar_unresolved", "")
    if ref:
        add_warning(
            payload, CODE_UNRESOLVED_REF,
            f"exemplar_ref {ref!r} не найден — секция «Образец оформления» НЕ собрана; "
            "другой образец вместо него НЕ подставлен (проверь ссылку: "
            "find_exemplar(genre, client) покажет доступные)",
            ref=ref, param="exemplar_ref",
        )
    unresolved = list(getattr(res, "unresolved_refs", []) or [])
    if unresolved:
        add_warning(
            payload, CODE_SOURCE_UNAVAILABLE,
            "не поднялись источники: "
            + "; ".join(f"{u.get('ref')} — {u.get('reason')}" for u in unresolved[:5]),
            unresolved_refs=unresolved,
        )
    return payload


def resolve(
    task: str,
    use_case_id: str | None = None,
    params: dict[str, Any] | None = None,
    source_refs: list[str] | None = None,
    corpus: str = "both",
    lift: bool = True,
) -> dict[str, Any]:
    """Одним вызовом: разложить задачу, поднять источники, свести факты/образец/
    контекст и вынести grounding-вердикт (ORCH-RESOLVE). Затем — ``generate``.

    Схлопывает цепочку, которая раньше жгла ~15 round-trip'ов из чата (``parse_task``
    → ``plan_task`` → ``lift_source`` → ``job_status``×N → ``get_facts`` →
    ``find_exemplar``) в ОДИН бэкенд-вызов на общем раннере ``resolve_task`` (тот же
    путь, что и ``generate``). Шаги: (``parse_task`` если нет ``use_case_id``) → план
    + зонд → **закрыть недостающие факт-узлы подъёмом ограниченного набора
    источников** (явные ``source_refs`` / ``note_id`` из ``params`` + ``source_path``
    топ-N ретривала, cap; реюз SRC-1 ``lift_from`` + FACT-1 extract/upsert;
    идемпотентно по L2/``fact_id``) → пере-зонд → ``assemble`` + grounding-gate.

    Path B: **не** зовёт LLM и **не** возвращает ``prompt`` (генерация — в
    ``generate``/чат хоста). NDA-барьер соблюдается на каждом подъёме (NDA-путь
    не читается, факты из него не берутся). Крупный источник (> бюджета) уходит в
    JOB-1 — его ``job_id`` в ``jobs`` (вызов не виснет; чат поллит ОДИН раз).

    Возврат: ``{status: "ok"|"blocked", use_case_id, params, facts:[…FACT-1 whitelist…],
    exemplar?, sources:[{note_id,source_path,…}], missing:[{what,kind,how}], plan,
    jobs:[{job_id,op}], lifted_n, corpus}`` — БЕЗ ``prompt``. При ``blocked`` —
    ``missing`` с how-to (честный стоп, не заглушка).
    """
    from core.metrics import record_event
    from core.orchestration.resolve import resolve_task

    res = resolve_task(
        use_case_id,
        task,
        params or {},
        source_refs=source_refs,
        corpus=corpus,
        lift=lift,
        use_plan=True,
        probe_plan=True,
        vault_path=default_vault_path(),
        assemble_fn=_core_assemble_prompt,
    )

    # Метрика (privacy): только use-case, виды недостающего, сколько поднято, вердикт,
    # число async-заданий — ни задачи, ни params, ни контента.
    record_event(
        "resolve",
        use_case=res.use_case_id,
        missing_kinds=[m["kind"] for m in res.missing],
        lifted_n=res.lifted_n,
        blocked=res.status == "blocked",
        jobs_n=len(res.jobs),
    )

    out: dict[str, Any] = {
        "status": res.status,
        "use_case_id": res.use_case_id,
        "params": res.params,
        "corpus": corpus,
        "facts": [_fact_provenance(f) for f in res.facts],
        "sources": res.sources,
        "missing": res.missing,
        "plan": res.plan,
        "lifted_n": res.lifted_n,
    }
    if res.jobs:
        out["jobs"] = res.jobs
    if res.exemplar is not None:
        out["exemplar"] = res.exemplar.to_dict()
    # RESOLVE-SCOPE-RANK: relevance-ranked hub materials (when no explicit source),
    # so the chat can show/disambiguate. Does not affect gate/facts.
    if res.hub_materials:
        out["hub_materials"] = res.hub_materials
    _degradations(out, res)
    if res.assembled is not None:
        _skipped_slices_warning(out, res.assembled.policy_result)
    return out


def doctor(refresh: bool = False) -> dict[str, Any]:
    """Диагностика окружения DT (UX-1) — секреты (наличие), пути, индекс, зеркало,
    модель, Outlook-мост **и все гарды движка**: незакрытый контур (DOD-1),
    недооформленный выход (DOD-2), инбокс захватов, хабы без track, зависшие локи и
    chunk-сессии, плановые джобы launchd, byte-hash легаси, отказы инструментов за
    7 дней (FAIL-TELEMETRY-1 — где агенты спотыкаются чаще всего), свежесть и цвет
    последнего сценарного смоука (LIVE-SMOKE-1). Без побочных эффектов, кроме снимков
    прогона: ``.derived/doctor_last.json`` (EVAL-3: только warn/fail + счётчики, от него горит
    индикатор здоровья в шапке пульта) и ``.derived/status/cache/doctor.json`` (полный ответ);
    значения секретов не выводятся.

    **Из снимка (PULT-SURFACE-2).** Доктор считается ~10 с, поэтому ``refresh=False`` отдаёт
    снимок не старше ``DT_PULT_DOCTOR_TTL_S`` (1800 с) — его же пишет ночной шаг ``doctor`` и CLI
    ``dt-doctor``; ``refresh=True`` («Проверить живьём») пересчитывает сейчас. В ответ добавлены
    ``as_of`` (когда посчитано) и ``cached`` (из снимка ли).

    Возвращает ``{ok, oks, fails, warns, checks:[{name, status, detail, hint}], as_of, cached}``:
    ``status`` ∈ ``ok|warn|fail``, ``detail`` — что именно найдено, ``hint`` — что с
    этим делать. Счётчики отдаём готовыми (``oks``/``warns``/``fails``) — свёртка
    виджета «Здоровье DT» на пульте рендерится из выдачи, а не из фронт-арифметики
    (принцип 14). Warning ≠ fail: ``ok`` падает только на критичных.
    """
    from core.diagnostics import doctor_payload, run_diagnostics
    from core.operational.snapshot import cached_read, ttl_from_env

    payload, meta = cached_read(
        "doctor", ttl_from_env("DT_PULT_DOCTOR_TTL_S", 1800),
        lambda: doctor_payload(run_diagnostics(known_tools=TOOL_NAMES)),
        refresh=bool(refresh),
    )
    return {**payload, "as_of": meta["as_of"], "cached": meta["cached"]}


def find_notes(
    query: str = "",
    corpus: str | None = None,
    person: str | None = None,
    domain: str | None = None,
    sort: str = "relevance",
    limit: int = 8,
    rerank: bool | None = None,
    include_eval: bool = False,
) -> dict[str, Any]:
    """Искать в vault: заметки, письма, документы, переписку — по теме, человеку, домену.

    Legacy-aware поиск заметок по ТРЁМ слоям (RETR-LEGACY FIX-1, RETR-RANK-1). Read-only.

    Лексика (FTS по русскому стеммеру + точный матч frontmatter, БЕЗ загрузки BGE) собирается
    ОДНИМ проходом по всем слоям — ``vault`` (синтез), ``current`` (живые файлы: КП, расчёты,
    справки) и ``legacy`` (архив, сырая переписка) — и сливается в единую шкалу: слабое
    совпадение в vault больше не прячет тред или КП из current/legacy. Семантика (BGE)
    подключается только если лексических хитов меньше ``DT_FIND_SEMANTIC_FLOOR`` (дефолт 3).

    * ``corpus`` — scope: ``"vault"`` | ``"current"`` | ``"legacy"`` | ``"raw"``
      (= current + legacy, без curated vault) | ``"both"`` | ``None`` (авто; ``both`` ≡ авто:
      все три слоя одним проходом).
    * ``person``/``domain`` — ЖЁСТКИЙ фильтр (AND поверх всех ступеней, включая FTS и семантику)
      по контрагентам/участникам frontmatter (``counterparties``/``participants``/
      ``counterparty_domains``). Кейс «письма с X»: ``find_notes(person="Кутепова",
      sort="recent")`` / ``find_notes(domain="cmtech.rs", sort="recent")`` — отдельный
      ``find_correspondence`` не нужен. Вместе с контактным фильтром закрепление хаба не
      применяется.
    * ``include_eval`` — вернуть и прогоны eval/selftest (по умолчанию скрыты).
    * ``sort`` — ``"relevance"`` (дефолт) | ``"recent"`` (по дате убыв. —
      «последнее письмо в X»; закрепление хаба не применяется).
    * ``rerank`` (RETR-RERANK-1) — ``true``/``false`` бьёт env ``DT_RERANK``, ``null`` — по env.
      Второй этап: верхние ``DT_RERANK_POOL`` (20) кандидатов переоценивает локальный
      cross-encoder (``bge-reranker-v2-m3``); только текстовый запрос, ``sort="relevance"``,
      пул больше ``limit``. Хаб клиента из запроса — в первых трёх, первым — лучший по
      реранкеру; ``matched_by`` получает суффикс ``+rerank``. Модели нет/сбой →
      ``warning[].code = "rerank_unavailable"``, порядок — слияние ступеней.

    **Единая шкала (RETR-RANK-1).** ``score`` — итоговая оценка 0..1 (1.0 — первое место во
    всех ступенях с максимальной силой совпадения), выдача отсортирована по ней. Ступени
    несравнимы по сырым значениям (BM25, ярусы скана, RRF) и сливаются по рангам. ``matched_by`` —
    честный источник хита из закрытого списка: ``scan:id`` (запрос = id заметки),
    ``scan:alias`` (= алиас), ``scan:title`` (подстрока заголовка), ``scan:title_tokens`` (≥80%
    значимых токенов запроса — в заголовке/алиасах, порядок не важен), ``scan:fm`` (прочие поля
    frontmatter), ``fts`` (тело, BM25), ``semantic`` (BGE), ``pin:client`` (хаб клиента/проекта/
    продукта, названный в запросе, закреплён в голове выдачи).

    **Нормализация клиента.** Имя из запроса (по стеммам, падежные формы тоже: «Амбреллы»)
    сопоставляется с хабами по ``aliases``, ``title``, H1 и слагу id: хаб закрепляется в начале
    выдачи (``pin:client``, до 3 — многозначный алиас закрепляет все), заметки с
    ``client``/``project``/``product`` этого хаба поднимаются в слиянии, а аббревиатура («ИТХ»,
    «ПАК-А») дополняет FTS-запрос полным именем хаба. Нет совпадения — выдача не меняется.

    Пустой ввод (нет query/person/domain) → ``notes: []``. Каждый хит помечен ``matched_by`` и
    ``corpus`` (``vault``/``current``/``legacy``). Возвращает ``{query, corpus, person, domain,
    sort, notes:[{note_id, title, path, source_path, score, matched_by, corpus, date}]}``. У
    хитов-почтовых тредов дополнительно ``last_from``/``last_date``/``last_from_me`` — автор и
    дата ПОСЛЕДНЕГО сообщения (из frontmatter, без чтения тела): «чем кончился тред» видно в
    выдаче.

    **Деградация (§9 п.22).** Полнотекстовый индекс или кэш frontmatter недоступны →
    ``warning[].code = "store_unavailable"`` (без FTS выдача — только скан frontmatter; без кэша —
    полный обход диска, результат полный, но медленный); семантика недоступна при лексике ниже
    порога → ``"unavailable"``; часть заметок не прочиталась (битый frontmatter) → ``"partial"``.
    Пустая выдача с конвертом ≠ «ничего нет».

    **Ссылки в выдаче (CONTRACT-1).** ``path`` — **vault-относительный путь заметки**,
    читаемый ``read_note``/``work_note_preview``/``attribute_note`` (пусто, если
    индекс-манифест заметку не знает); ``note_id`` — её идентичность; ``source_path`` —
    провенанс: путь исходного файла (pdf/xlsx/…) или виртуальный ключ почтового треда
    (``correspondence/conv:…``), **файлом заметки он не является**. Содержимое источника
    поднимает ``lift_source`` (он принимает и ``source_path``, и ``note_id``).

    **Разброс дат (SRC-FRESH-1).** Если верхний хит старше самого свежего хита той
    же выдачи более чем на ``DT_DATE_SPREAD_MONTHS`` (12) месяцев — в ответе
    появляется ``warning`` с путём и датой свежего. Ранжирование при этом НЕ
    меняется: релевантность честная, но «шаблон 2023 выше действующего плана 2026»
    один раз уже дало вывод, обратный истине (фейлкейс 11.08). Нужна последняя
    версия документа, а не самый релевантный текст → :func:`find_latest`.
    """
    from core.contract import add_warning
    from core.retrieval.find import date_spread_warning
    from core.retrieval.find import find_notes_ex as _core_find_notes_ex

    found = _core_find_notes_ex(
        query or "",
        corpus=corpus,
        person=person,
        domain=domain,
        sort=sort,
        limit=max(1, int(limit)),
        rerank=rerank,
        **({"include_eval": True} if include_eval else {}),
    )
    if found.rerank:  # RETR-RERANK-1: итоги этапа — в detail tool_call (не новая метрика)
        from core.metrics import note_call_detail

        note_call_detail(
            rerank_ms=found.rerank.get("ms"), rerank_pool=found.rerank.get("pool"),
            rerank_device=found.rerank.get("device"),
        )
    hits = found.hits
    notes = [
        {
            "note_id": h.note_id,
            "title": h.title,
            # CONTRACT-1 ФП-2: ``path`` — путь ЗАМЕТКИ (vault-относительный), а не
            # ``source_path``: раньше на FTS/семантик-ранге здесь стоял провенанс, и
            # выдачу поиска не принимал ни один читатель (Д1).
            "path": h.path,
            "source_path": h.source_path,
            "score": round(h.score, 4),
            "matched_by": h.matched_by,
            "corpus": h.corpus,
            "date": h.date,
            # PERSONAL-3: единица документа (слайд/страница/лист) - ``kind`` и родительский
            # документ;
            # у обычных заметок ключей нет - форма выдачи прежняя
            **({"kind": h.kind, "doc_title": h.doc_title} if h.kind else {}),
            # MAIL-THREAD-1: у почтовых тредов — автор/дата последнего сообщения
            # (без чтения тела). У не-почты ключей нет — форма прежняя.
            **(
                {
                    "last_from": h.last_from,
                    "last_date": h.last_date,
                    "last_from_me": h.last_from_me,
                }
                if h.last_from
                else {}
            ),
        }
        for h in hits
    ]
    out: dict[str, Any] = {
        "query": query,
        "corpus": corpus,
        "person": person,
        "domain": domain,
        "sort": sort,
        "notes": notes,
    }
    # SRC-FRESH-1: давность верхнего хита — вслух (ключ появляется только при разрыве,
    # прежняя форма ответа для «нормальной» выдачи не меняется).
    warning = date_spread_warning(hits)
    if warning:
        out["warning"] = warning
    # RETR-RANK-1: деградация лексики/семантики — машинным конвертом (§9 п.22), не молча.
    for env in found.warnings:
        add_warning(out, env["code"], env["reason"],
                    **{k: v for k, v in env.items() if k not in ("code", "reason")})
    return out


def find_latest(
    query: str = "",
    corpus: str | None = None,
    person: str | None = None,
    domain: str | None = None,
    limit: int = 5,
    include_eval: bool = False,
) -> dict[str, Any]:
    """Последняя версия документа по СЕМЕЙСТВАМ вокруг найденного файла. Read-only.

    Отвечает на вопрос, на который ``find_notes`` не отвечает by design: **какая версия этого
    документа действующая**. Кейс 2026-08-11: по бизнес-плану 2023 сделан вывод «план обрывается
    на 2026, нужен новый» — обратный истине, потому что действующий план 2026–2029 лежал в том
    же каталоге, а в выдачу поиска не попал вовсе.

    **Семейство — вокруг файла, не папка (FIND-LATEST-1).** Для каждого файлового хита
    ``find_notes`` семейство = файлы ТОЙ ЖЕ папки, похожие на него именем (токены без дат/версий,
    аббревиатуры КП/ГМ/ЦТ учитываются; содержимое файлов не читается). Папка клиента с КП,
    расчетами, деками и ТС — не одно семейство: «КП Acme» отвечает семейством КП, а не
    «Требованиями к персоналу». Новейший берётся ИЗ каталога, а не из выдачи: в кейсе
    действующая версия в выдаче отсутствовала. Ранжирование ``find_notes`` не тронуто; семейства
    ранжируются по лучшему хиту + бонус за токены запроса в общих токенах семейства.

    **Черновик vs действующий.** ``latest`` — новейший файл семейства (не архивный), у него
    ``draft``/``archived``; ``latest_final`` — новейший, который НЕ черновик и НЕ архив, или
    ``null``, если действующей версии в семействе нет. Маркеры — слова в имени файла/папки
    (``_system/freshness-markers.yaml``: черновик, draft, архив, old, копия…) и ``status: draft``
    заметки. **Черновик называй черновиком**: ``latest.draft=true`` — не выдавай его за действующий.

    Возврат ``{query, families:[{directory, latest:{path, mtime, draft, archived},
    latest_final:{path, mtime}|null, seed, versions, hits, members:[{path, mtime, draft,
    archived}] (до 10, новые сверху), shared_tokens, note_id, title, score}]}`` — ``versions`` —
    размер СЕМЕЙСТВА, ``hits`` из них в выдаче, ``seed`` — файл-основа, ``note_id``/``title`` —
    заметка лучшего хита (обратный след). Пустой запрос / нет хитов / ``source_path`` не
    файловый (провенанс legacy-переписки) / папка нечитаема → ``families: []``. Маркеры не
    прочитались → запасной набор из кода и конверт ``store_unavailable``.
    """
    from core.retrieval.find import find_latest as _core_find_latest

    families = _core_find_latest(
        query or "",
        corpus=corpus,
        person=person,
        domain=domain,
        limit=max(1, int(limit)),
        **({"include_eval": True} if include_eval else {}),
    )
    out: dict[str, Any] = {
        "query": query,
        "families": [
            {
                "directory": f.directory,
                "latest": {"path": f.latest_path, "mtime": f.latest_mtime,
                           "draft": f.latest_draft, "archived": f.latest_archived},
                "latest_final": (
                    {"path": f.latest_final_path, "mtime": f.latest_final_mtime}
                    if f.latest_final_path else None
                ),
                "seed": f.seed,
                "versions": f.versions,
                "hits": f.hits,
                "members": f.members,
                "shared_tokens": f.shared_tokens,
                "note_id": f.note_id,
                "title": f.title,
                "score": round(f.score, 4),
            }
            for f in families
        ],
    }
    from core.contract import add_warning
    from core.sources.markers import load_markers

    for env in load_markers().warnings:
        add_warning(out, env["code"], env["reason"],
                    **{k: v for k, v in env.items() if k not in ("code", "reason")})
    return out


def read_note(
    path: str, max_chars: int = 8000, messages: str | int = "all"
) -> dict[str, Any]:
    """Открыть и прочитать заметку целиком по ссылке любой формы (путь, id, source_path).

    Полное чтение заметки — включая ``_legacy/`` (RETR-LEGACY FIX-2).

    Принимает ссылку ЛЮБОЙ формы (CONTRACT-1 ФП-1, единая точка резолва): путь
    vault-относительный или абсолютный, frontmatter ``id``, имя файла, а также
    **строку ``source_path``**, которую движок сам показывает в выдаче — включая
    виртуальную почтовую ``correspondence/conv:207549``. Читает тело целиком (в отличие
    от ``work_note_preview`` с его ~320 символами). Возвращает ``{path, id, frontmatter,
    body (до max_chars), truncated}``; ``path`` — vault-относительный путь заметки,
    которым её принимают и остальные читатели/писатели. Read-only.

    Containment: результат всегда внутри vault. ``source_path`` может быть абсолютным
    путём файла ВНЕ vault — тогда вернётся ЗАМЕТКА про этот файл, а сам файл читает
    ``lift_source``. Ссылка, которая не резолвится и уводит наружу, — отказ.

    **Почтовые треды (MAIL-THREAD-1, ``source_type: email-thread``).** Бюджет
    ``max_chars`` считается по СООБЩЕНИЯМ, а не по символам: заголовки всех сообщений
    остаются всегда, тела отдаются с конца (последние целиком, ранние урезаются
    первыми, цитатные хвосты «От:/From:/>» режутся раньше целых сообщений). Поверх
    прежней формы приходит ``messages{total, shown_full, shown_header_only,
    shown_partial, quote_trimmed, not_shown, last_from, last_date, last_from_me}`` —
    честная сводка того, что НЕ показано; ``last_from``/``last_date`` — автор и дата
    ПОСЛЕДНЕГО сообщения треда. Если последнее сообщение от контрагента и оно не в
    ``shown_full`` — тред не прочитан, выводов по нему делать нельзя.

    * ``messages`` — ``"all"`` (дефолт) | ``"last"`` (последнее сообщение) | ``N``
      (последние N) | ``"inbound_last"`` (последнее сообщение НЕ от меня — «что
      ответил контрагент» без вычитывания треда). Для не-почтовых заметок параметр
      игнорируется, ответ прежний.
    """
    from core.retrieval.find import read_full_note as _core_read_full_note

    return _core_read_full_note(path, max_chars=max(1, int(max_chars)), messages=messages)


def attribute_note(path: str, client_id: str) -> dict[str, Any]:
    """Привязать заметку к клиент-хабу (RETR-LINK) — проставить frontmatter
    ``client: "[[<client_id>]]"`` в файле ``path``, чтобы слайс ``client_context``
    её находил. Хирургическая правка (тело/остальной frontmatter не трогаются),
    идемпотентно, путь обязан быть внутри vault. После — нужен reindex (отдельно,
    ``reindex`` incremental), чтобы изменение попало в индекс. Возвращает
    ``{path, note_id, client, changed, previous, needs_reindex}``.
    """
    from core.operational.attribute import attribute_note_client

    r = attribute_note_client(path, client_id)
    r["needs_reindex"] = bool(r.get("changed"))
    # SEC-6 audit: note id + client id + changed flag — no note content.
    _core_pult.record_action(
        "attribute_note",
        {"note_id": r.get("note_id") or "", "client_id": client_id,
         "changed": bool(r.get("changed"))},
        outcome="ok",
    )
    return r


def lift_source(
    note_id: str | None = None,
    path: str | None = None,
    sheet: str | None = None,
    cell_range: str | None = None,
    max_cells: int | None = None,
    async_: bool = False,
    max_chars: int | None = None,
) -> dict[str, Any]:
    """Прочитать файл-источник: PDF, xlsx, docx, pptx — извлечь текст, таблицы и цифры.

    Поднять файл-источник в рантайме и вернуть структуру + текст (SRC-1, §10a).

    Разыменовывает ``source_path`` карточки (или явный ``path``) и извлекает
    содержимое **read-only** во время работы — код-путь, которого не было, когда
    «поднять суммы из xlsx по пути из карточки» оказалось невыполнимо (аудит Acme).

    Вход (порядок разрешения): явный ``path`` (абсолютный или vault-относительный)
    приоритетен; иначе по ``note_id`` берутся frontmatter-поля ``source_path`` /
    ``source_paths`` (поле ``sources`` — wikilinks на сущности — как путь НЕ
    трогается). Оперативные исходники живут ВНЕ vault → абсолютные пути законны
    (это чтение своих файлов; вместо containment — read-only + бюджет + аудит).

    Для xlsx отдаёт cell-addressable ``tables`` (координаты ``sheet!ref``,
    ``is_number``) сверх плоского ``text``; ``sheet``/``cell_range`` (``"B7:B9"``)
    возвращают срез. ``stale_hint`` предупреждает, что значения xlsx взяты из кэша
    формул. Кэш L2 по content_hash (``cache_hit``). Несуществующий путь / нет extra
    ``parsers`` / таймаут → ``status="unavailable"`` с ``reason`` (без исключения).

    **NDA-барьер (NDA-1):** путь с маркером ``_nda`` (сегмент ``_nda/`` или суффикс
    ``*_nda.*``), либо NDA-заметка/NDA-``source_path`` карточки → **отказ**
    ``status="unavailable"``, ``nda=True`` — файл НЕ читается, L2-кэш и реестр НЕ
    пишутся; отказ логируется как ``nda_refused`` (path-hash, без контента).

    **Свежесть в каталоге (SRC-FRESH-1).** Папка хранилища = семейство версий, и один
    ``scandir`` рядом с уже сделанным ``stat`` отвечает на «а это последняя версия?»:
    ``newer_sibling`` = ``{path, mtime, days_newer}`` файла с похожим именем и датой
    новее на ``DT_NEWER_SIBLING_DAYS`` (30) дней — он же поднимает ``stale_hint``
    (смысл поля шире: «не считай это число последним»); ``family`` =
    ``{rank_by_date, of}`` — какой файл по счёту по дате из скольких в каталоге.
    Каталог из одного файла или непохожие имена → ``newer_sibling: null``, ``1 из 1``.
    Данные ЖИВЫЕ (в L2-кеш по content_hash не кешируются). Кейс: подъём
    «Business plan…2023» при живом соседе 2026 дал вывод, обратный истине.

    Возврат — сериализованный ``LiftResult`` (``{path, kind, content_hash, mtime,
    stale_hint, text, tables, meta, truncated, status, reason, cache_hit, nda,
    newer_sibling, family}``).

    **Потолок текста.** ``max_chars`` (``None`` - ``DT_LIFT_MAX_CHARS``, дефолт 40 000; ``0`` - без
    потолка): ``text`` больше - усечен по границе строки, ``truncated: true``, ``chars_total`` и
    конверт ``truncated``; таблицы и ``max_cells`` как были, кэш подъема хранит полный текст.

    ``async_=True`` уводит подъём большого файла в фон (JOB-1): возвращает
    ``{job_id, op, state}`` сразу, результат — через :func:`job_status`.
    """
    if async_:
        # Big-file lift off the client ceiling (JOB-1) — returns a job_id at once.
        return submit_job(
            "lift_source",
            {
                "note_id": note_id, "path": path, "sheet": sheet,
                "cell_range": cell_range, "max_cells": max_cells,
                # потолок текста - только по явному запросу: результат задания читают и
                # внутренние потребители (orchestration), им нужен полный текст
                **({"max_chars": max_chars} if max_chars is not None else {}),
            },
        )

    from core.sources.cap import cap_lift_text, resolve_max_chars

    cap = resolve_max_chars(max_chars)
    if cap is None:
        from core.contract import CODE_FILTER_DROPPED, add_warning

        bad: dict[str, Any] = {
            "path": path or "", "status": "unavailable", "text": "", "tables": [],
            "reason": f"max_chars={max_chars!r}: ожидается целое >= 0 (0 - без потолка)",
        }
        add_warning(
            bad, CODE_FILTER_DROPPED,
            f"max_chars={max_chars!r}: ожидается целое >= 0 - параметр НЕ отброшен, "
            "источник не поднят",
            param="max_chars",
        )
        return bad

    from core.operational.pult import record_action
    from core.sources import Budget, lift_from, slice_result

    budget = Budget(max_cells=int(max_cells)) if max_cells and max_cells > 0 else Budget()
    result = lift_from(note_id=note_id, path=path, budget=budget)
    if sheet or cell_range:
        result = slice_result(result, sheet=sheet, cell_range=cell_range)

    # Audit the fact of file access (read-only, SEC-6 seed) — path + hash + outcome,
    # never the lifted content. An NDA refusal (NDA-1) is already audited inside the
    # resolver as `nda_refused` with a path-hash (no raw path); don't re-log it here
    # (which would leak the NDA filename).
    if not result.nda:
        record_action(
            "lift_source",
            {
                "note_id": note_id or "",
                "path": result.path,
                "content_hash": result.content_hash[:12],
                "kind": result.kind,
                "cache_hit": result.cache_hit,
            },
            outcome=result.status,
        )
    return cap_lift_text(result.to_dict(), cap)


_FACTS_MAX_ENV = "DT_FACTS_MAX"
DEFAULT_FACTS_MAX = 200


def _facts_cap(limit: int | None) -> int | None:
    """Потолок выдачи ``get_facts``: ``0`` - без потолка; ``None`` - отказ (``limit`` не целое >=0).

    ``limit=None`` берет ``DT_FACTS_MAX`` (дефолт 200; ``0`` - без потолка; мусор - дефолт).
    """
    if limit is None:
        raw = os.environ.get(_FACTS_MAX_ENV, "").strip()
        try:
            value = int(raw)
        except ValueError:
            return DEFAULT_FACTS_MAX
        return value if value >= 0 else DEFAULT_FACTS_MAX
    if isinstance(limit, bool) or not isinstance(limit, int) or limit < 0:
        return None
    return limit


def _cap_facts(response: list[dict[str, Any]] | dict[str, Any], cap: int):
    """Усечь выдачу ``get_facts`` до ``cap`` (0 - не усекать): ответ меняется ТОЛЬКО при превышении.

    Укладывается - тот же объект, байт в байт. Больше - конверт CONTRACT-2: ``facts`` (первые
    ``cap`` в порядке стора - стабильном, по локатору), ``total``, ``limit`` и ``warning``
    с кодом ``truncated`` - структурно отличается от здорового списка. Уже конверт (с другими
    оговорками) сохраняет их и получает еще одну.
    """
    from core.contract import CODE_TRUNCATED, add_warning

    envelope: dict[str, Any] = response if isinstance(response, dict) else {"facts": response}
    facts = envelope.get("facts") or []
    if not cap or len(facts) <= cap:
        return response
    envelope["facts"] = facts[:cap]
    envelope["total"] = len(facts)
    envelope["limit"] = cap
    add_warning(
        envelope, CODE_TRUNCATED,
        f"выдача усечена: фактов {len(facts)}, отдано первые {cap}",
        hint="сузь entity/kind/note_id/source_path или подними limit",
        total=len(facts), limit=cap,
    )
    return envelope


def get_facts(
    entity: str | None = None,
    kind: str | None = None,
    note_id: str | None = None,
    source_path: str | None = None,
    min_confidence: float = 0.0,
    as_of: str | None = None,
    known_as_of: str | None = None,
    include_superseded: bool = False,
    limit: int | None = None,
) -> list[dict[str, Any]] | dict[str, Any]:
    """Найти цифры и реквизиты: суммы, даты, БИН, ставки — из файлов-источников, с ярлыком.

    Типизированные факты из источников (FACT-1): суммы/даты/реквизиты с ярлыком.

    Семантический слой над SRC-1: число в файле осмысляется подписью строки/шапкой
    колонки, чтобы 480 («себестоимость витрины») и 654,1 («витрина+ЭХД») не
    путались (аудит Acme). Экстракция ДЕТЕРМИНИРОВАННАЯ (Path B — без LLM).

    Если задан ``note_id`` / ``source_path`` и в сторе для этого файла фактов нет —
    под капотом поднимает источник (SRC-1 ``lift_from``), извлекает факты и
    апсертит их (идемпотентно по ``fact_id``), затем возвращает. Иначе — читает из
    стора. Фильтры ``entity`` (client/deal-хаб), ``kind``
    (money|quantity|date|rate|requisite|bin|contact), ``min_confidence``.

    **FACT-2.** ``unit`` - единица (валюта / ``чел.-дн`` / ``%``…), ``scale`` - множитель подписи
    («млн» → 1e6): ``value_num`` как в ячейке, НЕ домножен; ``value_base = value_num × scale``.
    ``section``, ``is_total``; ``kind="ordinal"`` (номера строк) - только по явному запросу.
    Старая версия экстрактора переизвлекается при запросе по источнику; ``merges_skipped`` и
    устаревшие факты без источника - конвертом ``warning``.

    **Время (FACTS-BITEMPORAL-1).** Оси: ``valid_from``/``valid_to`` (когда верно, ``[from, to)``,
    ``valid_to=null`` - пока верно) и ``known_at`` (когда узнали). Новая версия документа вытесняет
    факты старой (``superseded_by``; у нового ``prev_fact_id``), черновик (``provisional``) не
    вытесняет. По умолчанию - ТОЛЬКО актуальные (раньше отдавались все версии); ``as_of``
    (``YYYY-MM-DD``) - верное на дату, ``known_as_of`` - что знали на дату,
    ``include_superseded`` - вся история.

    **Потолок выдачи.** ``limit`` (``None`` - ``DT_FACTS_MAX``, дефолт 200; ``0`` - без потолка):
    уложилось - список как есть; больше - конверт ``{facts: [первые limit], total, limit,
    warning: [{code: "truncated", hint}]}``: сузьте ``entity``/``kind``/``note_id``/``source_path``.

    Возврат — **список** сериализованных фактов (форма как элементы у ``LiftResult``).
    Грант-гейт «нет фактуры → blocked» — это GATE-1, здесь не делается. Read-only к
    файлам + запись в локальный facts-стор.

    **Честный отказ фильтра (CONTRACT-2 С1).** Если ``note_id``/``source_path`` задан, а
    источник не поднялся (нет файла, NDA, почтовый ``conv:``-тред), возвращается
    ``{"facts": [], "warning": [{code: "filter_not_applied", reason, …}]}`` — **словарь
    вместо списка**: деградировавший ответ обязан отличаться от здорового структурно, а
    не только содержимым. Прежнее поведение (молча отбросить фильтр и отдать весь стор)
    закрыто: чужие цифры с видом фактуры дороже любого отказа.
    """
    from core.facts import ensure_facts
    from core.facts import get_facts as _core_get_facts
    from core.facts.temporal import norm_day
    from core.sources import lift_from

    for arg_name, arg_val in (("as_of", as_of), ("known_as_of", known_as_of)):
        if arg_val is not None and norm_day(arg_val) is None:
            from core.contract import CODE_FILTER_DROPPED, add_warning

            bad: dict[str, Any] = {"facts": []}
            add_warning(
                bad, CODE_FILTER_DROPPED,
                f"{arg_name}={arg_val!r}: ожидается дата YYYY-MM-DD - фильтр НЕ отброшен, "
                "факты не отданы",
                param=arg_name,
            )
            return bad
    temporal_kw: dict[str, Any] = {
        "as_of": as_of, "known_as_of": known_as_of, "include_superseded": include_superseded,
    }

    cap = _facts_cap(limit)
    if cap is None:
        from core.contract import CODE_FILTER_DROPPED, add_warning

        bad_limit: dict[str, Any] = {"facts": []}
        add_warning(
            bad_limit, CODE_FILTER_DROPPED,
            f"limit={limit!r}: ожидается целое >= 0 (0 - без потолка) - параметр НЕ отброшен, "
            "факты не отданы",
            param="limit",
        )
        return bad_limit

    # Materialize facts for a specific source on demand, if not already stored (or outdated).
    if note_id or source_path:
        lifted = lift_from(note_id=note_id, path=source_path)
        if lifted.status == "not_local":
            # SRC-ICLOUD-1: файл есть, но в iCloud не скачан (демон его не материализует) -
            # конверт с причиной и подсказкой, не «источник не поднялся» и не EDEADLK.
            from core.contract import CODE_SOURCE_NOT_LOCAL, add_warning

            nl_out: dict[str, Any] = {"facts": []}
            add_warning(
                nl_out, CODE_SOURCE_NOT_LOCAL, lifted.reason,
                note_id=note_id, source_path=source_path, path=lifted.path,
                hint=str((lifted.meta or {}).get("hint") or ""),
            )
            return nl_out
        if lifted.status != "ok":
            # CONTRACT-2 С1 (кейс справки 14.08 дословно). Раньше здесь фильтр по
            # источнику МОЛЧА обнулялся (``source_content_hash=None``) и возвращался
            # ВЕСЬ стор: «57 чужих фактов выглядят убедительнее честного отказа».
            # Правило §9 п.22: фильтр не применился → ПУСТО + причина, и ответ
            # структурно отличается от здорового (список против конверта).
            from core.contract import CODE_FILTER_DROPPED, add_warning

            out: dict[str, Any] = {"facts": []}
            add_warning(
                out, CODE_FILTER_DROPPED,
                f"источник не поднялся ({lifted.reason or lifted.status}) — фактов по "
                "нему нет; фильтр НЕ отброшен, чужие факты не подставлены"
                + (" · это почтовый тред (conv:), файла за ним нет — фактов из файла "
                   "не бывает by design" if "conv:" in str(source_path or "") or
                   "conv:" in str(lifted.path or "") else ""),
                note_id=note_id, source_path=source_path,
                status=lifted.status, nda=lifted.nda or None,
            )
            return out
        # OCR-1 п.4: источник - распознанный скан: факты из OCR-текста НЕ извлекаются (цифры со
        # скана без проверки хуже отсутствия) - конверт вместо тихого ``[]``.
        from core.ocr.state import is_ocr_source

        if is_ocr_source(lifted.path, lifted.content_hash):
            from core.contract import CODE_FACTS_NOT_FROM_OCR, add_warning

            ocr_out: dict[str, Any] = {"facts": []}
            add_warning(
                ocr_out, CODE_FACTS_NOT_FROM_OCR,
                "источник - распознанный скан (pdf-ocr): факты из OCR-текста не извлекаются, "
                "цифры со скана без проверки хуже отсутствия; сверьте значения по самому документу",
                note_id=note_id, source_path=source_path,
            )
            return ocr_out
        # FACT-2 п.7: гейт версии - факты прежнего экстрактора переизвлекаются и заменяются
        # (source_path - живой путь из подъема), а не отдаются как есть.
        ensure_facts(lifted, entity_ref=entity or note_id)
        facts_out = _core_get_facts(
            entity_ref=entity,
            kind=kind,
            source_content_hash=lifted.content_hash,
            min_confidence=min_confidence,
            **temporal_kw,
        )
        lift_warnings = list((lifted.meta or {}).get("warnings") or [])
    else:
        facts_out = _core_get_facts(
            entity_ref=entity, kind=kind, min_confidence=min_confidence, **temporal_kw
        )
        lift_warnings = []
    from core.facts.store import last_read_error

    broken = last_read_error()
    if broken:
        # CONTRACT-2 С7: «фактов нет» и «стор не прочитался» — разные вещи.
        from core.contract import CODE_STORE_UNAVAILABLE, add_warning

        degraded: dict[str, Any] = {"facts": [f.to_dict() for f in facts_out]}
        add_warning(
            degraded, CODE_STORE_UNAVAILABLE,
            f"facts-стор не прочитан ({broken}) — выдача НЕ полна",
        )
        return _cap_facts(degraded, cap)
    # FACT-2: честные оговорки. Подъем источника сообщил, что часть шапок не прочитана
    # (``merges_skipped``), либо в выдаче есть факты прежней версии экстрактора (стор без
    # источника не переизвлекается сам) - ответ становится конвертом, а не голым списком.
    from core.facts.materialize import needs_reextract

    old_version = sorted(
        {f.extractor_version for f in facts_out if needs_reextract(f.extractor_version)}
    )
    if lift_warnings or old_version:
        from core.contract import CODE_FACTS_OUTDATED, CODE_MERGES_SKIPPED, add_warning

        enveloped: dict[str, Any] = {"facts": [f.to_dict() for f in facts_out]}
        for w in lift_warnings:
            add_warning(
                enveloped, str(w.get("code") or CODE_MERGES_SKIPPED), str(w.get("reason") or "")
            )
        if old_version:
            n_old = sum(1 for f in facts_out if needs_reextract(f.extractor_version))
            add_warning(
                enveloped, CODE_FACTS_OUTDATED,
                f"{n_old} из {len(facts_out)} фактов извлечены прежней версией экстрактора "
                f"({', '.join(old_version)}): единицы/масштаб/типы могут быть неверны; "
                "запросите по note_id/source_path (переизвлечение автоматическое) или "
                "`dt_facts --reextract`",
                outdated=n_old,
            )
        return _cap_facts(enveloped, cap)
    return _cap_facts([f.to_dict() for f in facts_out], cap)


def owner_profile() -> dict[str, Any]:
    """Профиль владельца (read-only): ``about`` - кто он, ``rules`` - правила работы с ним.

    ``{name, company, role, about, rules, updated, version, missing, issues}``; ``version``
    меняется при правке профиля, ``missing`` - пустые файлы.
    """
    from core.config import user_display_name
    from core.owner import PLACEHOLDER_NAME, load_profile

    prof = load_profile()
    name = user_display_name()
    return {
        "name": "" if name == PLACEHOLDER_NAME else name,
        "company": prof.data.company,
        "role": prof.data.role,
        "about": prof.about,
        "rules": prof.rules,
        "updated": prof.data.updated,
        "version": prof.version,
        "missing": prof.missing,
        "issues": [i.as_dict() for i in prof.issues],
    }


def find_exemplar(
    genre: str,
    client: str | None = None,
    fmt: str | None = None,
    render: bool = True,
) -> dict[str, Any]:
    """Найти реальный прошлый документ как ОБРАЗЕЦ ОФОРМЛЕНИЯ (форму) (TMPL-1).

    Отвечает на «найди пример КП/письма/справки как образец» — то, чего не было,
    когда ассистент собирал структуру с нуля и ставил заглушку вместо бланка
    (аудит Acme). Отдельно от ``[Style exemplars]`` (тон): здесь — ФОРМА
    (структура + бланк) для клонирования.

    Ранжирование ДЕТЕРМИНИРОВАННОЕ и объяснимое: **тот же клиент** > **та же
    отрасль** (по хабу клиента) > любой того же жанра; ``type: template`` получает
    буст «эталон оформления»; при равенстве — свежесть. ``genre`` — жанр
    (letter/report/…; плюрал/сингуляр нормализуются), ``client`` — id хаба клиента,
    ``fmt`` — фильтр по формату/расширению источника (docx/pptx/md). Ничего не
    нашли → ``{found: false}`` (не выдумываем).

    С ``render=True`` (по умолчанию) поднимает форму через ``as_template``: бинарь
    (docx/pptx) — через SRC-1 ``lift_from`` best-effort, markdown — из тела заметки;
    в ``render`` — ``sections``/``letterhead``/``salutation``/``closing`` +
    компактный ``output_format`` для секции ``[Образец оформления]``. Path B: без
    сети/LLM, read-only.
    """
    from core.exemplars import as_template
    from core.exemplars import find_exemplar as _core_find

    ex = _core_find(genre, client=client, fmt=fmt)
    if ex is None:
        return {"found": False, "genre": genre, "client": client, "fmt": fmt}
    out: dict[str, Any] = {"found": True, "exemplar": ex.to_dict()}
    if render:
        out["render"] = as_template(ex).to_dict()
    return out


def ingest_scan(root: str | None = None, dry_run: bool = True) -> dict[str, Any]:
    """Превью файлового ingest: скан наблюдаемых папок + дельта (INGEST-1, read-only).

    Сканирует корни из ``_system/ingest-roots.yaml`` (per-device резолв путей),
    фильтрует (include/exclude + NDA-1 ``is_nda`` — всегда) и показывает
    диспозицию: сколько new/changed/unchanged, сколько пропущено по NDA/excluded,
    сколько iCloud-``pending_download``. ``root`` ограничивает одним корнем.

    **``dry_run=True`` (по умолчанию) — строго read-only:** ничего не пишет (ни
    реестр, ни заметки, ни манифест) и **не скачивает** dataless-файлы iCloud (их
    видно как ``pending_download``). Для боевого прохода (register/ingest/reindex)
    — CLI ``dt_ingest --apply`` (не из превью). Возврат — сериализованный
    ``ScanStats`` (счётчики + пути корней; без содержимого файлов). Path B: без LLM.
    """
    from core.file_ingest import load_ingest_roots
    from core.file_ingest import scan as _scan

    vault = default_vault_path()
    roots = load_ingest_roots(vault)
    if not roots:
        return {"configured": False, "roots": 0, "note": "ingest-roots.yaml absent/empty"}
    stats = _scan(vault_path=vault, root_name=root, dry_run=dry_run, log=lambda _m: None)
    out = stats.to_dict()
    out["configured"] = True
    out["root_names"] = [r.name for r in roots]
    return out


def output_begin(
    title: str, task: str, channel: str | None = None, model: str | None = None,
    purpose: str | None = None,
) -> dict[str, Any]:
    """Завести папку выхода С ПОСТАНОВКОЙ **до** работы (DOD-2) — каркас, не результат.

    **Когда обязателен.** Артефакт уходит ЗА ПРЕДЕЛЫ vault — в опер. хранилище, клиенту,
    в HR/рекрутинг, во внешнюю форму. Тогда это не рабочая заметка, а выход, и контур
    ``07-outputs`` обязателен. Порядок: ``output_begin`` → работа →
    ``save_output(output_dir=…, text=…)``.

    **Почему до, а не после.** Кейс 2026-08-11: контур собирали в конце сессии, мост
    упал на середине — в vault осталась полу-папка (мета есть, постановки и результата
    нет), которая «выглядит оформленной». Здесь падение после ``output_begin``
    оставляет валидную заявку с зафиксированной постановкой: провенанс постфактум
    невосстановим — через день по одному тексту уже не сказать, откуда взялась цифра и
    почему решение такое.

    Создаёт ``07-outputs/YYYY-MM/<дата>-<slug>/`` с ``meta.yaml``
    (``status: draft``, ``source: adhoc``, ``engine_run: false``, ``channel`` если
    задан) и ``prompt.md`` — постановка ``task`` **дословно** (что просили, какие
    ограничения; не пересказ). ``channel`` ∈ ``{vault, storage, external, hr, client}``
    — куда уходит; незнакомая метка не отказ, а ``warning``.

    **Идемпотентно по ``title`` в тот же день:** повторный вызов возвращает ту же папку
    (``created: false``) и обновляет постановку; папку с готовым ``output.md`` не
    трогает (там закрытый выход → берётся суффикс ``-2``). Пустой ``title``/``task`` —
    отказ: папка без постановки и есть та самая полу-папка.

    ``model`` — имя модели, которая пишет текст (объявленное клиентом, движок его не
    проверяет): уходит в ``meta.yaml`` как ``model`` + ``model_source: declared``. Хост —
    ``host: {name, version}`` — берется из handshake сам; без ``model`` источник
    модели — ``unknown`` (отказа нет).

    ``purpose``: ``eval``/``selftest`` (``work`` по умолчанию) решает движок по фразе золотой
    задачи/хосту; такой выход доставляется в ``_eval``, а не клиенту. Возврат ``{output_dir,
    created, channel, purpose?, prompt_chars, warning, next}`` (``purpose`` - не у ``work``).
    Незакрытые дольше суток папки показывает ``doctor`` (``DT_OUTPUT_DRAFT_WARN_H``).
    """
    from core.note_ids import split_frontmatter
    from core.output import begin_output, read_meta
    from core.purpose import purpose_of

    draft = begin_output(title, task, channel=channel, model=model, purpose=purpose)
    out_dir = draft.path.resolve()
    # SEC-2 containment теми же глазами, что в save_output: title — недоверенный ввод,
    # и хотя слаггер режет ``../``, проверяем факт (симлинк, чужой vault).
    outputs_root = _core_outputs_path().resolve()
    if not out_dir.is_relative_to(outputs_root):
        raise ValueError(f"output_dir is outside 07-outputs ({outputs_root}): {out_dir}")
    result: dict[str, Any] = {
        "output_dir": str(out_dir),
        "created": draft.created,
        "channel": draft.channel,
        "prompt_chars": len(
            split_frontmatter((out_dir / "prompt.md").read_text(encoding="utf-8"))[1]
        ),
        "next": ("работа → save_output(output_dir=…, text=…) переведёт meta в final; "
                 "файловый deliverable — dest=/file_refs в том же вызове"),
    }
    out_meta = read_meta(out_dir / "meta.yaml")
    if purpose_of(out_meta) != "work":  # у рабочего выхода ответ байт-идентичен прежнему
        result["purpose"] = purpose_of(out_meta)
        if out_meta.get("eval_task"):
            result["eval_task"] = out_meta["eval_task"]
    if draft.warning:
        result["warning"] = draft.warning
    # SEC-6 audit: папка/канал/размер постановки — но НЕ её текст.
    _core_pult.record_action(
        "output_begin",
        {"output_dir": str(out_dir), "channel": draft.channel or "-",
         "task_chars": len(task or ""), **({"purpose": result["purpose"]}
                                           if "purpose" in result else {})},
        outcome="created" if draft.created else "existed",
    )
    return result


def save_output(
    output_dir: str | None = None,
    *,
    text: str,
    file_refs: list[str] | None = None,
    title: str | None = None,
    dest: str | None = None,
    format: str | None = None,  # имя параметра — из контракта ФТ-4 (не builtins)
    sources: list[dict[str, Any]] | None = None,
    model: str | None = None,
    overwrite: bool = False,
    purpose: str | None = None,
) -> dict[str, Any]:
    """Вернуть результат в DT и (по желанию) собрать документ ЛОКАЛЬНО: сохранить
    справку/письмо/отчёт, положить docx/pdf/md в рабочую папку — без base64.

    **Первый пункт развилки доставки** (кейс 17.08): если документ собран ИЗ ТЕКСТА —
    это ваш инструмент: ``dest`` + ``format`` соберут файл на маке (pandoc), через мост
    поедет только текст. Файл уже на диске → ``place_download(source_path=…)``; истинный
    бинарь из чата → ``store_file``/``store_file_begin``.

    ``output_dir`` is the folder returned by :func:`generate`; the artifact lands
    beside its provenance. Returns the written path.

    **Ad-hoc режим (DOD-1).** Если ``generate`` не звали — передайте ``title`` вместо
    ``output_dir``: папка ``07-outputs/YYYY-MM/<дата>-<slug>/`` создастся сама, рядом
    появится ``meta.yaml`` c ``source: adhoc``. Это делает закрывающий шаг контракта
    («результат возвращается в DT») **одним вызовом** — раньше без ``generate`` его
    нельзя было выполнить вовсе, и результат оставался в чате. ``output_dir``
    приоритетнее ``title``; ни того, ни другого → отказ.

    ``file_refs`` (OUT-FILE-1) — опциональные пути к файловым deliverable, уже
    доставленным в хранилище через :func:`store_file` (root-относительные или
    человекочитаемые); при наличии в ``output.md`` добавляется секция «## Файлы»
    со ссылками. Без ``file_refs`` — поведение байт-идентично прежнему.

    **Адресат как параметр (ФТ-4/FT-4).** ``dest`` — алиас рабочей папки
    (:func:`folder_alias_list`) либо путь относительно ingest-корня; ``format`` ∈
    ``{md, docx, pdf}`` (дефолт ``md``). Когда адресат известен заранее, содержимое
    едет через мост **один раз** — этим текстом: файл нужного формата собирается
    **локально** (pandoc), бинарное содержимое через мост не передаётся вовсе
    (в отличие от base64 в :func:`store_file`). ``output.md`` в ``07-outputs``
    пишется ВСЕГДА (провенанс), доставленный путь автоматически попадает в его
    секцию «## Файлы» — ``file_refs`` для него указывать не нужно. Имя файла — имя
    папки задачи (task-id) с расширением формата. Нет pandoc или pdf-движка →
    сохраняется ``.md`` + ``warning`` в ответе (**не отказ**, требование ФТ).

    Без ``dest``/``format`` поведение и ответ прежние: ``{path, chars}``. С ``dest``
    добавляется ``delivered`` — ``{ok, path, root_name, size, sha256, format_used,
    existed, overwritten, outcome, alias, warning}``, а при отказе гарда (containment/NDA/
    существующий отличающийся файл) — ``{ok:false, refused, code, error}``; сам
    ``output.md`` при этом всё равно сохранён (текст не теряется).

    **Правка выхода (DELIVER-2):** повторный ``save_output`` тем же ``output_dir``/``dest``
    перезаписывает СВОЙ файл (``outcome: updated``; docx самому не собирать), правленный снаружи или
    чужой - ``exists_differs``, ``overwrite=True`` затирает. ``format`` без ``dest`` - файл в папку
    выхода (``abs_path``).

    **Финализация контура (DOD-2).** Если ``output_dir`` — папка от
    :func:`output_begin` (мета несёт ``status: draft``), этот вызов её **закрывает**:
    ``status → final`` + ``finalized`` (и ``channel`` фактом доставки — при ``dest``
    это ``storage``, сам вызов его и пишет). В ответе — ``finalized: true``. Папки от
    ``generate`` и ad-hoc-папки DOD-1 остаются байт-идентичными: у них ключа ``status``
    нет, и мету мы не трогаем вовсе.

    **Источники по сессии (PROV-SESSION-1).** ``sources.md`` собирается САМ: что сессия читала
    (``read_note`` → ``origin: read``), поднимала (``lift_source`` → ``lift``) и откуда брала
    цифры (``get_facts`` → ``facts``) - строки с путём, хешем и **датой источника**; тред -
    «прочитано N из M». Поиски - секция «## Поиск в сессии» (кандидаты, не источники). Окно -
    СЕССИЯ по ``sid`` (не дальше ``DT_ADHOC_SOURCES_H`` ч; ``output_begin`` раньше двигает
    начало; без ``sid`` - по хосту; журнал молчит - «окно, а не сессия»). Папка от ``generate``:
    её чанки НЕ перетираются, в конец дописываются «## Прочитано в сессии»/«## Поиск в сессии».
    ``sources=[{path, what_taken}]`` - ТОЛЬКО то, что взято мимо DT (бумага, чат, устное):
    ``origin: manual``, повторный save его не теряет. Ответ ``sources: {path, rows, read, lift,
    facts, manual, searches, window}``. Хабы источников → «## Связано» в ``output.md``.

    **Провенанс «кем собрано» (VENDOR-HYGIENE-1).** ``meta.yaml`` несёт ``host: {name,
    version}`` (из handshake), ``model`` (параметр ``model`` — объявленное, не проверяется;
    ``model_source: declared | host | unknown``) и ``engine_calls: N`` — сколько вызовов
    DT сделал этот хост в окне выхода (``0`` = «собрано без вызовов DT»); ``sources.md``
    начинается строкой «собрано: хост / модель (источник) / вызовов DT». Старые выходы без
    этих полей читаются как ``model_source: unknown``.

    ``engine_run: false`` и нет ни строк (чтения/подъёмы/факты/руками), ни поисков → ``warning``
    в ответе (**не отказ**) + строка ``doctor`` рядом с draft-гардом. Существующий
    ``sources.md`` (папка от ``generate`` — чанки промпта с политикой) НЕ
    перетирается: движковый путь байт-идентичен.

    **Назначение.** ``purpose`` (``eval``/``selftest``) решает движок; такой выход доставляется
    в ``_eval`` (``delivered.quarantined``, ``intended_dest``), ответ несет ``purpose``.

    **Идентичность (WAVE0-HYGIENE п.2).** ``output.md`` (как ``sources.md``/``prompt.md``
    папки выхода) пишется С frontmatter: ``id: output-<папка>`` (``sources-…``/``prompt-…``),
    ``type: output``, ``title``, ``created`` и ``client``/``project`` из хабов «Связано».
    Раньше все выходы без id схлопывались в один (``output``) и в индексе жил 1 из 54.
    Тело файла — ровно переданный ``text`` (frontmatter сверху, дословность сохранена).

    **Связка с сущностями.** Из путей источников выводятся хабы клиентов/продуктов
    (детерминированный каталог линковки, **только существующие** — выдуманных
    ``[[…]]`` не появляется) → секция «## Связано» в ``output.md``: выход виден со
    стороны клиента, а не только из ``07-outputs``.

    Containment guard: MCP input is untrusted, so ``output_dir`` must resolve
    inside ``07-outputs/`` (where :func:`generate` creates folders). Anything
    else — ``../`` traversal or an absolute path elsewhere — is rejected.
    """
    if not text or not text.strip():
        raise ValueError("refusing to save empty artifact text")
    adhoc = False
    if output_dir is not None and str(output_dir).strip():
        out_dir = Path(output_dir).resolve()
    elif title is not None and str(title).strip():
        from core.output import create_adhoc_output_dir

        out_dir = create_adhoc_output_dir(
            str(title).strip(), model=model, purpose=purpose).resolve()
        adhoc = True
    else:
        raise ValueError(
            "нужен output_dir (папка от generate) либо title (ad-hoc: папка создастся сама)"
        )
    # SEC-2 containment — для ОБОИХ путей одной проверкой: ad-hoc папку мы создаём сами
    # под 07-outputs, но проверяем её теми же глазами (слаггер, симлинк, чужой vault).
    outputs_root = _core_outputs_path().resolve()
    if not out_dir.is_relative_to(outputs_root):
        raise ValueError(
            f"output_dir is outside 07-outputs ({outputs_root}): {out_dir}"
        )
    # 0. EVAL-HYGIENE-1: назначение сводится ДО записи (frontmatter output.md и адрес доставки)
    from core.output import apply_purpose

    purpose_res = apply_purpose(out_dir, purpose)
    # 1. output.md — ВСЕГДА (провенанс не зависит от доставки файла в рабочую папку).
    path = save_artifact(out_dir, text, file_refs=file_refs)
    result: dict[str, Any] = {"path": str(path), "chars": len(text)}
    if purpose_res["purpose"] != "work":  # у рабочего выхода ответ байт-идентичен прежнему
        result["purpose"] = purpose_res["purpose"]
        if purpose_res.get("eval_task"):
            result["eval_task"] = purpose_res["eval_task"]
    audit: dict[str, Any] = {
        "path": str(path), "chars": len(text), "file_refs": len(file_refs or []),
        **({"purpose": purpose_res["purpose"]} if purpose_res["purpose"] != "work" else {}),
    }
    # CONTRACT-1 ФП-7: ссылки на файлы проверяются на существование. НЕ отказ (текст уже
    # сохранён и дороже подсказки) — предупреждение: секция «## Файлы» не имеет права
    # ссылаться в никуда, а постфактум это не выясняется.
    from core.output import missing_file_refs

    dead_refs = missing_file_refs(file_refs)
    if dead_refs:
        result["file_refs_missing"] = dead_refs
        _add_warning(
            result,
            "не найдены файлы по ссылкам file_refs: " + ", ".join(dead_refs[:5])
            + " — секция «## Файлы» ссылается в никуда; проверь, что файл доставлен "
            "(store_file / place_download / save_output(dest=…)) и путь взят из его ответа",
        )
        audit["file_refs_missing"] = len(dead_refs)
    if adhoc:
        result["adhoc"] = True  # папку создали мы (meta.yaml: source: adhoc)
        audit["adhoc"] = 1

    # 2. Адресат задан → локальная сборка формата + запись в рабочую папку, а путь
    #    доставленного файла — обратно в «## Файлы» output.md (перезапись заметки).
    outcome = "ok"
    if dest is not None and str(dest).strip():
        delivered = _deliver_to_dest(out_dir, text, dest, format, overwrite)
        result["delivered"] = delivered
        if delivered.get("ok"):
            ref = f"{delivered['root_name']}/{delivered['path']}"
            _record_delivery(out_dir, delivered)  # meta.yaml: delivered (+ «свой файл» в след. раз)
            save_artifact(out_dir, text, file_refs=[*(file_refs or []), ref])
            audit |= {"dest": ref, "format": delivered["format_used"],
                      "sha256": str(delivered["sha256"])[:12],
                      "delivery": delivered.get("outcome", "created")}
        else:
            # output.md сохранён, доставка файла — нет: в аудите это видно как отказ
            audit |= {"dest": str(dest)[:120], "code": delivered.get("code", "?")}
            outcome = "dest_refused"
    elif format is not None and str(format).strip():
        # DELIVER-2 п.3: «файл в чат» - format БЕЗ dest кладет файл в ПАПКУ ВЫХОДА
        # (07-outputs/<месяц>/<task>/<task>.<fmt>): хост показывает его в чате, не собирая docx
        # своим инструментом. Прежний отказ no_dest был дырой контура (DELIVER-CHAT-1, 29.10).
        delivered = _deliver_in_output_dir(out_dir, text, format, overwrite, outputs_root)
        result["delivered"] = delivered
        if delivered.get("ok"):
            if delivered.get("file_written"):
                _record_delivery(out_dir, delivered)
                ref = f"vault:{delivered['path']}"
                save_artifact(out_dir, text, file_refs=[*(file_refs or []), ref])
                audit |= {"dest": ref, "format": delivered["format_used"],
                          "sha256": str(delivered["sha256"])[:12], "in_output_dir": 1,
                          "delivery": delivered.get("outcome", "created")}
        else:
            audit |= {"dest": "(output_dir)", "code": delivered.get("code", "?")}
            outcome = "dest_refused"

    # 3. DOD-2: контур, начатый output_begin, закрывается ЗДЕСЬ (draft → final).
    #    Канал уточняем фактом: доставили файл в рабочую папку → это storage,
    #    что бы ни было заявлено на begin. Чужую мету (generate / DOD-1) не трогаем.
    from core.output import finalize_output

    # (файл, оставшийся в папке выхода, - не «ушло наружу»: канал не уточняем)
    delivered_out = result.get("delivered", {})
    channel_fact = (
        "storage" if delivered_out.get("ok") and not delivered_out.get("in_output_dir") else None
    )
    if finalize_output(out_dir, channel=channel_fact) is not None:
        result["finalized"] = True
        audit["finalized"] = 1

    # 3а. VENDOR-HYGIENE-1 п.2: кем собрано — ``engine_calls`` (+ ``model``, если объявлена).
    #    ДО sources.md: строка «собрано: …» читает мету. Мягко: текст уже на диске.
    _stamp_provenance(out_dir, audit, model)

    # 4. SRC-TRACE-2: провенанс ad-hoc-выхода — сам, из телеметрии подъёмов + ручных
    #    строк; плюс связка с хабами по путям источников. Ни один шаг не имеет права
    #    сорвать сохранение текста (он уже на диске) — отсюда мягкие ветки.
    _attach_sources(out_dir, result, audit, text=text, sources=sources,
                    file_refs=file_refs)

    # 5. STYLE-GUARD-1: механическая проверка ИИ-маркеров по канону
    #    ``_system/style-guides/ai-markers.yaml``. ПОСЛЕДНИМ шагом и намеренно
    #    «не блоком»: текст уже сохранён, а решение по стилю за человеком — гард
    #    показывает находки и подсказки, править или нет решает К. Ноль находок →
    #    ответ байт-идентичен прежнему (ключа нет вовсе).
    _style_markers(result, audit, text)

    # SEC-6 audit: written path + sizes/counts (+ адресат/формат) — never the text.
    _core_pult.record_action("save_output", audit, outcome=outcome)
    return result


def _stamp_provenance(out_dir: Path, audit: dict[str, Any], model: str | None) -> None:
    """VENDOR-HYGIENE-1 п.2: ``meta.yaml`` += ``engine_calls`` (и ``model``); аудит — хост/число."""
    from core.host import current_host
    from core.output import stamp_engine_run

    try:
        meta = stamp_engine_run(out_dir, model=model)
    except Exception as exc:  # noqa: BLE001 — провенанс не роняет сохранение текста
        _logger.warning("[save_output] провенанс (host/model/engine_calls) не записан: %s", exc)
        return
    audit["host"] = current_host()["name"]
    if meta is not None and isinstance(meta.get("engine_calls"), int):
        audit["engine_calls"] = meta["engine_calls"]


def _style_markers(result: dict[str, Any], audit: dict[str, Any], text: str) -> None:
    """Находки ИИ-маркеров → в ответ (STYLE-GUARD-1), счётчики → в аудит.

    Зачем на выходном контуре, а не в скилле: правило в памяти LLM живёт до
    следующего сеанса, правило в системе — переживает и сеанс, и модель (класс §9
    п.19). ``save_output`` — единственная точка, через которую проходит ЛЮБОЙ текст
    выхода, чем бы он ни был сгенерирован.

    Обёрнуто: проверка стиля не имеет права уронить вызов, который уже записал
    текст на диск (тот же принцип, что у провенанса выше). В аудит уходят ТОЛЬКО
    счётчики по уровням — сам текст и найденные фразы в журнал не попадают.
    """
    from core.style_markers import STYLE_MARKERS_KEY, attach_style_markers

    try:
        attach_style_markers(result, text)
    except Exception as exc:  # noqa: BLE001 — стиль не роняет сохранение текста
        _logger.warning("[save_output] проверка ИИ-маркеров не выполнена: %s", exc)
        return
    found = result.get(STYLE_MARKERS_KEY)
    if isinstance(found, dict):
        audit["style_markers"] = {
            "ban": len(found.get("ban") or []),
            "density": 1 if found.get("density") else 0,
            "calques": len(found.get("calques") or []),
            "patterns": len(found.get("patterns") or []),
        }


def _add_warning(result: dict[str, Any], text: str) -> None:
    """Добавить предупреждение, не затирая уже стоящее (одно поле — все причины).

    У ``save_output`` предупреждений может быть несколько сразу (мёртвая ссылка в
    ``file_refs`` + не собравшийся провенанс). Затирать чужое значило бы прятать одну
    причину за другой — ровно то, что запрещает канон §9 п.22.
    """
    previous = str(result.get("warning") or "").strip()
    result["warning"] = f"{previous}; {text}" if previous else text


def _adhoc_meta(out_dir: Path) -> dict[str, Any]:
    """Мета папки, если она НЕ движковая (для движковой — пустой словарь).

    Признак ad-hoc: ``engine_run: false`` (папка от ``output_begin``) либо
    ``source: adhoc`` (папка от ``save_output(title=…)``, DOD-1). У папки от
    ``generate`` ни того, ни другого нет — её провенанс собирает движок сам, и
    телеметрия подъёмов ему не замена.
    """
    from core.output import SOURCE_ADHOC, read_meta

    meta = read_meta(out_dir / "meta.yaml")
    if meta.get("engine_run") is False or meta.get("source") == SOURCE_ADHOC:
        return meta
    return {}


def _attach_sources(
    out_dir: Path,
    result: dict[str, Any],
    audit: dict[str, Any],
    *,
    text: str,
    sources: list[dict[str, Any]] | None,
    file_refs: list[str] | None,
) -> None:
    """SRC-TRACE-2 / PROV-SESSION-1: собрать ``sources.md`` и «## Связано» по СЕССИИ.

    Порядок: окно сессии (журнал запросов + аудит ``save_output``, :func:`core.provenance.
    session_window`) → чтения/подъёмы/факты сессии + поиски + ручные строки →
    ``sources.md``: ad-hoc-выход получает таблицу (свой файл пересобирается, ручные строки
    сохраняются), движковый (``generate``) - автосекции «## Прочитано в сессии»/«## Поиск в
    сессии» в конец (чанки промпта не перетираются; читать было нечего - файл не меняется) →
    хабы по строкам в «## Связано» (ad-hoc) → ``warning``, если провенанса нет вовсе.
    Каждый шаг обёрнут: текст артефакта уже сохранён, и подсказка не имеет права превратить
    успешное сохранение в ошибку.
    """
    from core.host import current_host, request_fields
    from core.output import (
        append_session_sections,
        manual_sources,
        merge_sources,
        previous_manual_rows,
        related_hubs,
        write_adhoc_sources,
    )
    from core.output import save_artifact as _save_artifact
    from core.provenance import collect_session_sources, session_window

    meta = _adhoc_meta(out_dir)
    adhoc = bool(meta)
    sid = request_fields().get("sid", "")
    host = current_host()["name"]
    try:
        from core.output import provenance_line, read_meta

        window = session_window(out_dir, sid, host)
        prov = collect_session_sources(out_dir, window, sid, host)
        rows = merge_sources(
            prov.rows, merge_sources(manual_sources(sources), previous_manual_rows(out_dir)))
        if not adhoc and not prov.rows and not prov.searches:
            rows = []  # движковый путь без чтений: файл и ответ байт-идентичны прежним
        if adhoc:
            written = write_adhoc_sources(
                out_dir, rows, title=str(meta.get("title") or ""), window=window,
                searches=prov.searches,
                built_by=provenance_line(read_meta(out_dir / "meta.yaml")),
            )
        else:
            written = None
        if written is None and (out_dir / "sources.md").is_file():
            written = append_session_sections(out_dir, rows, prov.searches, window)
    except Exception as exc:  # noqa: BLE001 — провенанс не роняет сохранение текста
        _logger.warning("[save_output] sources.md не собрался: %s", exc)
        return
    if written is not None:
        origins = [r.origin.split("+") for r in rows]
        result["sources"] = {
            "path": str(written), "rows": len(rows),
            "read": sum(1 for o in origins if "read" in o),
            "lift": sum(1 for o in origins if "lift" in o),
            "facts": sum(1 for o in origins if "facts" in o),
            "manual": sum(1 for o in origins if "manual" in o),
            "searches": len(prov.searches),
            "window": window.to_dict(),
        }
        audit["sources"] = len(rows)
    if not adhoc:
        return  # движковый путь: дальше (связка, полнота тредов, warning) - только ad-hoc

    # OUT-COMPLETE-1: полнота чтения источников-почтовых тредов (предупреждение, не блок).
    _check_thread_coverage(
        out_dir, result, audit, rows, window.since, window.until, written is not None)

    # Связка с сущностями: только существующие хабы, иначе секции не будет вовсе.
    try:
        hubs = related_hubs([r.path for r in rows])
        for hub_id in (r.note_id for r in rows if r.hub):  # прочитанный хаб - сам «Связано»
            if hub_id not in hubs:
                hubs.append(hub_id)
        if hubs:
            _save_artifact(out_dir, text, file_refs=file_refs, related=hubs)
            result["related"] = hubs
            audit["related"] = len(hubs)
    except Exception as exc:  # noqa: BLE001
        _logger.warning("[save_output] «## Связано» не собралось: %s", exc)

    # Видимость пропуска: провенанса нет ни из телеметрии, ни руками (работали мимо
    # движка и ничего не объявили). Не отказ — предупреждение и строка доктора.
    if not rows and not prov.searches and not (out_dir / "sources.md").exists():
        _add_warning(
            result,
            "sources.md не собран: в сессии нет ни чтений/подъёмов/фактов DT, ни поисков, и "
            "параметр sources не передан — у выхода нет машиночитаемых первоисточников. "
            "Допиши save_output(sources=[{path, what_taken}]) — провенанс постфактум "
            "невосстановим (doctor покажет этот выход через сутки)",
        )


def _check_thread_coverage(
    out_dir: Path,
    result: dict[str, Any],
    audit: dict[str, Any],
    rows: list[Any],
    since: Any,
    until: Any,
    sources_written: bool,
) -> None:
    """OUT-COMPLETE-1: для источников-почтовых тредов свести чтение окна begin→save.

    Тред прочитан не до последнего входящего → ``source_incomplete`` с ``{date, from}``
    непрочитанного; тред указан, но в окне не читался → ``not_read_in_window``; строка —
    в ``sources.md`` (если его написали мы). Полностью прочитанный тред и не-почтовые
    источники → ничего не меняется (ответ и файл байт-идентичны). Не блок: решение за
    автором. Обёрнуто: проверка не имеет права сорвать уже сохранённый текст.
    """
    from core.contract import add_warning

    try:
        from core.output import append_thread_coverage
        from core.thread_coverage import check_sources

        findings = check_sources([(r.path, r.kind) for r in rows], since, until)
    except Exception as exc:  # noqa: BLE001 — проверка полноты не роняет сохранение
        _logger.warning("[save_output] проверка полноты чтения тредов не выполнена: %s", exc)
        return
    if not findings:
        return
    for f in findings:
        # Сначала человекочитаемая строка (``warning``), затем конверт: с занятым
        # ``warning`` он поедет ключом ``warning_envelopes`` и строку не затрёт.
        _add_warning(result, f.reason)
        add_warning(result, f.code, f.reason, **f.envelope_context())
    audit["thread_incomplete"] = len(findings)  # только счётчик — без имён и дат
    if sources_written:
        try:
            append_thread_coverage(out_dir, [f.line for f in findings])
        except Exception as exc:  # noqa: BLE001
            _logger.warning("[save_output] строка полноты в sources.md не записана: %s", exc)


def _known_sha_of(out_dir: Path) -> Any:
    """``known_sha(root, rel_path)`` для ``deliver_text``: sha нашей последней доставки по адресу
    (``meta.yaml: delivered`` этой папки выхода) либо ``None`` - файл не наш."""
    from core.output import latest_delivery, read_meta

    def known(root: str, rel_path: str) -> str | None:
        rec = latest_delivery(read_meta(out_dir / "meta.yaml"), root, rel_path)
        return str(rec.get("sha256") or "") or None if rec else None

    return known


def _deliver_to_dest(
    out_dir: Path, text: str, dest: str, format: str | None,  # имя из контракта ФТ-4
    overwrite: bool = False,
) -> dict[str, Any]:
    """ФТ-4: собрать файл из текста локально и положить в ``dest`` (или объяснить отказ).

    Имя файла — имя папки задачи (task-id вида ``2026-08-07-справка-по-цод``): путь
    в рабочей папке остаётся сшитым с провенансом в ``07-outputs``. DELIVER-2: свой файл
    (sha = нашей прошлой доставки из меты) перезаписывается; ``overwrite=True`` - явная перезапись.
    """
    from core import eval_quarantine as _eq
    from core.operational.deliver_output import DeliverError, deliver_text

    # EVAL-HYGIENE-1 п.2: прогон eval/selftest доставляет в <корень>/_eval/…, не в папку клиента
    redirect = _eq.redirect_dest(_eq.for_output(out_dir), dest, _PLACE_DEFAULT_ROOT)
    try:
        if redirect is None:
            return deliver_text(text, dest, file_name=out_dir.name, format=format,
                                overwrite=overwrite, known_sha=_known_sha_of(out_dir))
        return _eq.annotate(
            deliver_text(text, redirect.dest, file_name=out_dir.name, format=format,
                         root_name=redirect.root_name, overwrite=overwrite,
                         known_sha=_known_sha_of(out_dir)),
            redirect)
    except DeliverError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc),
                **exc.details}


def _deliver_in_output_dir(
    out_dir: Path, text: str, format: str | None,  # имя из контракта ФТ-4
    overwrite: bool, outputs_root: Path,
) -> dict[str, Any]:
    """DELIVER-2 п.3: собрать файл из текста и положить в папку выхода (или объяснить отказ).

    Гард - только ``out_dir`` (она уже проверена containment-ом под ``07-outputs``); ingest-корни не
    трогаются. Путь в ответе - от корня vault (``07-outputs/…``)."""
    from core.operational.deliver_output import DeliverError, deliver_text_to_output_dir

    try:
        return deliver_text_to_output_dir(
            text, out_dir, file_name=out_dir.name, vault_root=outputs_root.parent, format=format,
            overwrite=overwrite, known_sha=_known_sha_of(out_dir),
        )
    except DeliverError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc),
                **exc.details}


def _note_replaced_delivery(result: dict[str, Any], root_name: str) -> dict[str, Any]:
    """DELIVER-2 п.4: перезапись файла инструментами ``place_download``/``store_file*`` (разрешена,
    как раньше) поверх пути, который ДОСТАВИЛ какой-то выход, помечается в этом выходе:
    ``delivered[].replaced_by: <host>/<sha>`` + подпись ссылки в «## Файлы» + строка аудита
    ``delivered_replaced``. Ответ инструмента не меняется; сбой пометки его не роняет."""
    if not (isinstance(result, dict) and result.get("ok") and result.get("overwritten")):
        return result
    path, sha = str(result.get("path") or ""), str(result.get("sha256") or "")
    root = str(result.get("root_name") or root_name or "")
    if not (path and sha and root):
        return result
    try:
        from core.host import current_host
        from core.output import mark_replaced

        host = current_host()["name"]
        for out_dir in mark_replaced(root, path, sha, host):
            _core_pult.record_action(
                "delivered_replaced",
                {"output": out_dir.name, "path": f"{root}/{path}",
                 "replaced_by": f"{host}/{sha[:12]}"},
                outcome="replaced",
            )
    except Exception as exc:  # noqa: BLE001 — пометка не роняет доставку, которая уже состоялась
        _logger.warning("[delivered_replaced] пометка выходов не записана: %s", exc)
    return result


def _record_delivery(out_dir: Path, delivered: dict[str, Any]) -> None:
    """Успешная доставка → ``meta.yaml: delivered`` (в конец меты). Мягко: файл уже лежит, текст -
    на диске; сбой записи не роняет сохранение (но следующий раз файл будет «не нашим»)."""
    from core.output import record_delivery

    try:
        record_delivery(
            out_dir, root=str(delivered["root_name"]), rel_path=str(delivered["path"]),
            sha256=str(delivered["sha256"]), fmt=str(delivered.get("format_used") or ""),
            intended_dest=str(delivered.get("intended_dest") or "") or None,
        )
    except Exception as exc:  # noqa: BLE001 — провенанс не роняет сохранение текста
        _logger.warning("[save_output] delivered не записан в meta.yaml: %s", exc)


def store_file(
    root_name: str,
    rel_path: str,
    content_b64: str,
    sha256: str,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Доставить бинарь из чата в рабочую папку по мосту (base64 ≤25 МБ, sha-гард) —
    когда файла на диске НЕТ и собрать его из текста нельзя.

    **Сначала проверьте развилку** (кейс 17.08): документ, который вы сочинили, →
    ``save_output(dest=…, format="docx")`` (pandoc локально, без base64); файл уже на
    диске мака → ``place_download(source_path=…)`` (по мосту ~60 байт вместо десятков
    КБ). Здесь — только истинный БИНАРЬ, рождённый в чате; крупнее ~16 КБ →
    ``store_file_begin`` порциями (зона отказов моста 29–39 КБ).

    Канал записи файла из чата: base64 приходит в параметре MCP (JSON, без шелл-пайпов,
    что дважды побило файл в кейсе Эмба). Запись **только под ingest-корни** ``ingest-roots.
    yaml`` (operational/knowledge; ``root_name`` — имя корня, ``rel_path`` —
    относительный путь внутри него). Гарды: containment по ``resolve`` (``../``/
    абсолютный/симлинк-эскейп → отказ); NDA (``_nda`` → отказ); size-cap (25MB,
    env ``DT_STORE_FILE_MAX_BYTES``); **sha256 сверяется ДО записи** (заявленный ==
    декодированному) **И ПОСЛЕ** (файл перечитан с диска; не сошёлся → удалён,
    ошибка). Существующий байт-идентичный → ``existed`` без перезаписи (mtime цел);
    отличающийся → отказ без ``overwrite=True`` (клиентские файлы молча не затираем).
    Атомарно (tmp+rename); аудит без контента. Успех → ``{ok, path, size, sha256,
    existed, overwritten}``; отказ гарда → ``{ok:false, refused, error}``. **Запись
    в vault/систему/вне корней невозможна.** Путь файла кладётся в output-заметку
    через ``save_output(file_refs=…)``; плановый ingest подхватит файл штатно.
    """
    from core import eval_quarantine as _eq
    from core.operational.store_file import StoreFileError
    from core.operational.store_file import store_file as _core_store_file

    # EVAL-HYGIENE-1 п.2: сессия прогона (eval/selftest) пишет в <корень>/_eval/…
    redirect = _eq.redirect_rel(_eq.session_quarantine(), root_name, rel_path)
    if redirect is not None:
        rel_path = redirect.dest
    try:
        result = _core_store_file(
            root_name, rel_path, content_b64, sha256=sha256, overwrite=overwrite
        )
    except StoreFileError as exc:
        return {"ok": False, "refused": True, "error": str(exc)}
    return _note_replaced_delivery(_eq.annotate(result, redirect), root_name)


def _chunked_refusal(exc: Any) -> dict[str, Any]:
    """Отказ порционной записи → ``{ok:false, refused, code, error, …details}``.

    ``details`` несёт то, чем клиент продолжает работу (``expected_next``,
    ``expected_offset``, ``limit``) — отказ обязан подсказывать следующий шаг.
    """
    return {"ok": False, "refused": True, "code": exc.code, "error": str(exc),
            **exc.details}


def store_file_begin(
    root_name: str,
    rel_path: str,
    final_sha256: str,
    total_size: int,
    overwrite: bool = False,
) -> dict[str, Any]:
    """Порционно доставить крупный бинарь из чата (части по 16 КБ, resume) — когда одним
    параметром не проходит и файла на диске нет.

    Когда применять — ПОСЛЕДНИЙ пункт развилки (кейс 17.08): у файла **нет текстового
    источника** (xlsx с формулами, заполненный PDF, изображение, вложение) И его нет на
    диске. Документ из текста → :func:`save_output` c ``dest``/``format`` (pandoc
    локально, байты через мост не идут вовсе); файл на диске (скачан/отрендерен/
    смонтированный в хост каталог) → :func:`place_download` c ``source_path`` или ``match`` —
    дешевле в разы. ФТ прямо предупреждает: **быстро не станет** — цель порционности в
    предсказуемости, а не в скорости.

    Протокол: ``store_file_begin`` → ``store_file_append`` × N → ``store_file_commit``
    (``store_file_status`` — узнать, с чего продолжать; ``store_file_abort`` — снять).
    ``final_sha256`` и ``total_size`` — итогового файла: по ним ``commit`` проверяет,
    что собралось именно то, что задумано.

    **Все гарды цели проверяются здесь** (корень/containment/NDA/существующий файл) —
    fail-fast до передачи хоть одной части. Байт-идентичный файл уже на месте →
    ``{ok, existed: true, session_id: null}``, передавать нечего. Повторный вызов с той
    же целью и тем же ``final_sha256`` **возобновляет** сессию (id детерминирован),
    поэтому потерянный ``session_id`` не повод начинать заново. Сборка идёт в
    ``.derived/chunked/``, в клиентской папке недособранного не видно.

    Возврат ``{ok, session_id, chunk_limit, expected_next, expected_offset, bytes_done,
    total_size, path, root_name, resumed, existed}``; отказ → ``{ok:false, refused,
    code, error}``. Аудит — одна строка.
    """
    from core import eval_quarantine as _eq
    from core.operational.store_chunked import ChunkedStoreError, begin

    # EVAL-HYGIENE-1 п.2: цель фиксируется здесь (commit берет ее из сессии) - сразу под _eval
    redirect = _eq.redirect_rel(_eq.session_quarantine(), root_name, rel_path)
    if redirect is not None:
        rel_path = redirect.dest
    try:
        return _eq.annotate(
            begin(root_name, rel_path, final_sha256, total_size, overwrite=overwrite), redirect)
    except ChunkedStoreError as exc:
        return _chunked_refusal(exc)


def store_file_append(session_id: str, part_index: int, content_b64: str) -> dict[str, Any]:
    """Передать очередную часть файла (base64) в сессию ``session_id`` (ФТ-5).

    Части идут **строго по порядку**, начиная с ``part_index=0``; размер части ≤
    ``chunk_limit`` из ответа ``store_file_begin`` (env ``DT_CHUNK_LIMIT``, дефолт
    16 КБ — заведомо ниже зоны отказов моста 29–39 КБ). Часть не по порядку → отказ
    ``out_of_order`` с ``expected_next``/``expected_offset``: **из самого отказа видно,
    с чего продолжать** (это и есть протокол возобновления после обрыва). Часть больше
    лимита → ``chunk_too_large`` с лимитом и фактическим размером.

    Каждая принятая часть дописывается на диск с ``fsync`` — обрыв не теряет
    принятого. Возврат ``{ok, session_id, received, expected_next, expected_offset,
    bytes_done, remaining, complete}``; когда ``complete: true`` — зовите
    ``store_file_commit``. В аудит не пишется (только свой scratch, не клиентская папка).
    """
    from core.operational.store_chunked import ChunkedStoreError, append

    try:
        return append(session_id, part_index, content_b64)
    except ChunkedStoreError as exc:
        return _chunked_refusal(exc)


def store_file_status(session_id: str) -> dict[str, Any]:
    """Состояние сессии порционной записи: сколько принято и с чего продолжать (ФТ-5).

    Read-only (попутно снимает истёкшие по TTL сессии). Возврат ``{ok, session_id,
    root_name, path, received, expected_next, expected_offset, bytes_done, total_size,
    remaining, complete, chunk_limit, final_sha256, expires_in_s}`` — после обрыва это
    первый вызов: ``expected_next`` говорит, какую часть слать, ``expected_offset`` — с
    какого смещения её резать. Нет такой сессии (или истекла) → ``{ok:false, refused,
    code, error}``.
    """
    from core.operational.store_chunked import ChunkedStoreError, status

    try:
        return status(session_id)
    except ChunkedStoreError as exc:
        return _chunked_refusal(exc)


def store_file_commit(session_id: str) -> dict[str, Any]:
    """Завершить сессию: сверить sha256 собранного файла и положить его в цель (ФТ-5).

    Собрано не всё → отказ ``incomplete`` (с остатком). sha256 собранного не совпал с
    заявленным в ``store_file_begin`` → отказ ``sha_mismatch``, накопленные части
    удаляются, **в целевой папке не появляется ничего**. Иначе — атомарная подмена цели
    через тот же write-слой, что у ``store_file``/``place_download`` (существующий
    байт-идентичный → ``existed``; отличающийся требовал ``overwrite=True`` ещё на
    ``begin``). Успех → ``{ok, path, root_name, size, sha256, parts, existed,
    overwritten}``, сессия закрыта; отказ → ``{ok:false, refused, code, error}``.
    Аудит — одна строка (включая число принятых частей).
    """
    from core.operational.store_chunked import ChunkedStoreError, commit

    try:
        result = commit(session_id)
    except ChunkedStoreError as exc:
        return _chunked_refusal(exc)
    root = str(result.get("root_name") or "") if isinstance(result, dict) else ""
    return _note_replaced_delivery(result, root)


def store_file_abort(session_id: str) -> dict[str, Any]:
    """Снять незавершённую сессию порционной записи: части и состояние удаляются (ФТ-5).

    Идемпотентно — неизвестная/уже снятая сессия тоже ``{ok:true, removed:false}``.
    Незавершённые сессии в любом случае живут не дольше TTL
    (env ``DT_CHUNK_SESSION_TTL_H``, дефолт 24 ч) и подчищаются сами; ``doctor``
    показывает висящие. Аудит — одна строка.
    """
    from core.operational.store_chunked import abort

    return abort(session_id)


def place_download(
    match: str = "",
    dest: str = "",
    source_path: str | None = None,
    root_name: str = _PLACE_DEFAULT_ROOT,
    new_name: str | None = None,
    overwrite: bool = False,
    max_age_minutes: int = _PLACE_DEFAULT_MAX_AGE_MINUTES,
    keep_source: bool = False,
) -> dict[str, Any]:
    """Положить готовый файл с диска в рабочую папку: доставить docx/xlsx/pdf клиенту,
    перенести по пути, забрать из Downloads — байты через мост НЕ идут.

    **Развилка доставки — выбирайте по ПРОИСХОЖДЕНИЮ файла** (кейс 17.08: механизм был,
    маршрут выбрали не тот — 30 КБ base64 и битые байты вместо одной команды):

    1. документ, который вы СОЧИНИЛИ (текст/markdown → md/docx/pdf) →
       ``save_output(dest=…, format="docx")``: текст едет обычным параметром, файл
       собирает pandoc ЛОКАЛЬНО. Без base64, без хэшей, один вызов;
    2. файл УЖЕ ЛЕЖИТ НА ДИСКЕ мака (скачан браузером, отрендерен, смонтированный в хост каталог,
       любой путь) → **этот инструмент**: ``source_path`` (абсолютный путь) ИЛИ
       ``match`` (шаблон имени в каталогах загрузок);
    3. истинный БИНАРЬ, рождённый в чате (xlsx с формулами, изображение, вложение) →
       ``store_file`` (≤16 КБ base64) либо ``store_file_begin``+``append``+``commit``
       (порции с resume). Хэш-гарды там обязательны: 17.08 канал привёз битые байты.

    Файл хоста с изолированной ФС (путь из чата недоступен на диске мака) ``source_path``
    не найдёт (``source_not_found``); для него пункты 1 или 3.

    ``source_path`` (FILE-LOCAL-1) и ``match`` **взаимоисключимы** (два адреса одного
    файла в одном вызове — неоднозначность → отказ ``both_sources``). У ``source_path``
    фильтр возраста НЕ действует: явный путь — намеренный выбор, а не догадка по
    шаблону. Отказы источника: ``source_not_found`` / ``source_is_dir`` /
    ``bad_source_path`` (не абсолютный) / ``nda``.

    ``match`` — glob (``*.docx``) ИЛИ подстрока имени, регистронезависимо; ``dest`` —
    алиас папки (:func:`folder_alias_list`) либо путь относительно ingest-корня
    ``root_name``; ``new_name`` — переименование при переносе; ``max_age_minutes``
    (60) — потолок возраста кандидата; ``keep_source=True`` — копировать, не
    перемещать. Каталоги поиска — ``DT_DOWNLOADS_DIRS`` (дефолт ``~/Downloads``),
    недокачанные ``*.crdownload``/``*.part`` игнорируются.

    **Неоднозначность не разрешается автоматически:** 0 кандидатов → отказ
    ``no_candidates`` + ``recent`` (5 последних файлов — видно, почему шаблон не
    сработал); >1 → отказ ``ambiguous`` + ``candidates`` (имя/размер/mtime), уточните
    шаблон (ошибочная запись в клиентскую папку дороже повторного вызова). Гарды —
    те же, что у ``store_file``: containment по ``resolve``, NDA (``_nda``), байт-
    идентичный существующий → ``existed`` без перезаписи (mtime цел), отличающийся →
    отказ без ``overwrite=True``. Dataless-источник iCloud материализуется
    (``brctl``), не удалось → отказ ``not_materialized`` (частичный файл не создаётся).
    Перенос атомарный (``rename``; между томами — копия+``fsync``+``replace``); sha256
    считается ЛОКАЛЬНО после доставки; аудит без контента. NDA проверяется и на цели, и
    на ИСТОЧНИКЕ (перенос под чистый корень снял бы маркер пути). Успех → ``{ok, path,
    abs_path, size, sha256, matched_name, moved, copied, existed, overwritten, alias,
    root_name, source, via}`` (``via`` — ``source_path``/``match``); отказ →
    ``{ok:false, refused, code, error, …}``. 
    """
    from core import eval_quarantine as _eq
    from core.operational.place_download import PlaceDownloadError
    from core.operational.place_download import place_download as _core_place_download

    # EVAL-HYGIENE-1 п.2: сессия прогона (eval/selftest) доставляет в <корень>/_eval/…
    redirect = _eq.redirect_dest(_eq.session_quarantine(), dest, root_name)
    if redirect is not None:
        dest, root_name = redirect.dest, redirect.root_name
    try:
        result = _core_place_download(
            match,
            dest,
            source_path=source_path,
            root_name=root_name,
            new_name=new_name,
            overwrite=overwrite,
            max_age_minutes=max_age_minutes,
            keep_source=keep_source,
        )
    except PlaceDownloadError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc),
                **exc.details}
    return _note_replaced_delivery(_eq.annotate(result, redirect), root_name)


def folder_alias_list() -> dict[str, Any]:
    """Перечень алиасов рабочих папок (ФТ-2) — read-only подсказка для чата.

    Алиас сворачивает разнородно написанный путь (``Kazakhstan/Globex``
    латиницей, ``Russia/Подводные технологии`` кириллицей) в один короткий токен для
    ``dest`` в :func:`place_download`. Сопоставление регистронезависимое, кириллица
    и латиница, с транслит-допуском («цод» = «TSOD» = «cod»). Реестр —
    ``_system/folder-aliases.yaml``; отсутствует → ``{count: 0, aliases: []}``.
    Возврат ``{registry, count, aliases:[{name, root_name, rel_path}]}``.
    """
    from core.config import folder_aliases_path
    from core.file_ingest.aliases import list_aliases

    aliases = list_aliases()
    return {
        "registry": str(folder_aliases_path()),
        "count": len(aliases),
        "aliases": [a.to_dict() for a in aliases],
    }


def folder_alias_set(alias: str, root_name: str, rel_path: str) -> dict[str, Any]:
    """Добавить/изменить алиас рабочей папки (ФТ-2): ``alias`` → ``root_name``+``rel_path``.

    Целевой путь проверяется **теми же гардами, что запись файла**: ``root_name`` ∈
    ``_system/ingest-roots.yaml``, containment по ``resolve`` (``../``/абсолютный/
    симлинк-эскейп → отказ), не ``_nda``. Алиас за пределы корней или под ``_nda``
    **не регистрируется** — реестр не может стать обходным путём к запрещённой папке.
    ``rel_path`` пустой = сам корень. Папки может ещё не быть на диске (``exists``
    покажет). Возврат ``{ok, name, root_name, rel_path, path, exists, created,
    updated}``; отказ → ``{ok:false, refused, code, error}``. Аудит —
    ``record_action`` (алиас+корень+путь, без контента).
    """
    from core.file_ingest.aliases import AliasError, set_alias

    try:
        out = set_alias(alias, root_name, rel_path)
    except AliasError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc)}
    # SEC-6 audit: алиас + адрес папки — идентификаторы, без контента файлов.
    _core_pult.record_action(
        "folder_alias_set",
        {"alias": out["name"], "root": out["root_name"], "rel_path": out["rel_path"],
         "exists": out["exists"]},
        outcome="updated" if out["updated"] else "created",
    )
    return out


def list_inbox() -> list[dict[str, Any]]:
    """List unprocessed quick-capture items in ``_staging/inbox/``.

    Returns one entry per item: its ``file`` (pass to :func:`apply_refinement`),
    size, and a short text preview.
    """
    return [
        {"file": str(item.path), "chars": len(item.text), "preview": _preview(item.text)}
        for item in _core_list_inbox()
        if not _core_is_assignment(item)  # RETIRE-WRITE-1: поручение — карточка, не знание
    ]


def refine_inbox() -> list[dict[str, Any]]:
    """Build a placement-refinement request for every inbox item (Path B).

    Each ``request`` is a ready-to-read prompt (captured text + entity catalog +
    parse_task hints + frontmatter schema + candidate folders). The host's chat model
    turns one into a ``{type, target_path, frontmatter, summary?}`` proposal,
    which the user confirms and :func:`apply_refinement` writes to the vault.
    """
    out: list[dict[str, Any]] = []
    for item in _core_list_inbox():
        if _core_is_assignment(item):  # RETIRE-WRITE-1: поручения — карточка, не placement
            continue
        request = _core_build_refinement_request(item)
        out.append({"file": str(item.path), "request": request.render()})
    return out


def apply_refinement(inbox_file: str, proposal: dict[str, Any]) -> dict[str, Any]:
    """Write a confirmed placement ``proposal`` into the vault, clearing the item.

    ``proposal`` keys: ``type``, ``frontmatter`` (dict), ``target_path`` (vault-
    relative ``.md`` path), optional ``summary``. Returns the written note path.
    """
    path = Path(inbox_file)
    if not path.is_file():
        raise FileNotFoundError(f"inbox file not found: {inbox_file}")
    item = InboxItem(path=path, text=path.read_text(encoding="utf-8"))
    written = _core_apply_refinement(item, proposal)
    # SEC-6 audit: source/target paths + proposal type — no note text/frontmatter.
    _core_pult.record_action(
        "apply_refinement",
        {"inbox_file": str(path), "written_path": str(written),
         "type": str(proposal.get("type") or "")},
        outcome="ok",
    )
    return {"written_path": str(written), "cleared_inbox_file": str(path)}


# --------------------------------------------------------------------------- #
# Лейн поручения (#поручение / #тиметта) — карточка «Поручение администратору CRM» #
# --------------------------------------------------------------------------- #
# RETIRE-WRITE-1: записи в Timetta нет; захват превращается в черновик поручения, которое К.
# отправляет администратору CRM сам (core.operational.assignment).
def _link_brief(p: LinkProposal) -> dict[str, Any]:
    """Compact JSON view of one link proposal."""
    return {
        "id": p.id,
        "source": p.source_note,
        "target": p.target_note,
        "score": round(p.score, 4),
        "target_type": p.target_type,
        "status": p.status,
        "resolver": p.resolver,
        "evidence": _preview(p.evidence_snippet),
        "rationale": p.rationale,
    }


def _reattr_brief(p: Any) -> dict[str, Any]:
    """Компактный вид одного предложения переатрибуции (REATTR-1)."""
    return {
        "id": p.id,
        "note_id": p.note_id,
        "old_path": p.old_path,
        "new_path": p.new_path,
        "from_hubs": list(p.from_hubs),
        "to_hubs": list(p.to_hubs),
        "detected_at": p.detected_at,
        "status": p.status,
    }


def propose_links(
    scope: str = "all",
    target_filter: str = "spine",
    min_score: float | None = None,
    topn: int | None = None,
    persist: bool = True,
) -> dict[str, Any]:
    """Generate AI-semantic link candidates into the review queue (Phase 6).

    For a scope of source notes — ``all`` / ``legacy`` / ``curated`` (isolates of
    that layer, i.e. notes the deterministic Phase-5 pass left unlinked) or a bare
    ``<note-id>`` — finds the nearest *other* notes by BGE-M3 / LanceDB similarity
    and enqueues the new ones for review. Writes **nothing** into any note (that is
    :func:`apply_links`). ``target_filter`` (default ``spine``) constrains targets
    to the semantic skeleton — non-client hubs + knowledge/cases + project hubs
    (client links are the deterministic layer's job). ``persist`` (default True)
    saves the queue (a reversible review surface). Returns counts + the new rows.
    """
    from core.config import default_vault_path, link_proposals_path

    sources = _core_select_sources(default_vault_path(), scope)
    queue = LinkProposalQueue.load(link_proposals_path())
    result = _core_propose_for_notes(
        sources, queue=queue, min_score=min_score, topn=topn, target_filter=target_filter,
    )
    if persist:
        queue.save()
    return {
        "scope": scope,
        "target_filter": target_filter,
        "sources": result.sources,
        "skipped_sources": result.skipped_sources,
        "candidates": result.candidates,
        "added": result.added,
        "duplicates": result.duplicates,
        "persisted": persist,
        "queue_path": str(link_proposals_path()),
        "proposals": [_link_brief(p) for p in result.proposals],
    }


def apply_links(
    approve_ids: list[str] | None = None,
    approve_above: float | None = None,
    apply: bool = False,
) -> dict[str, Any]:
    """Approve selected proposals and apply them into source notes (Phase 6).

    Selection: ``approve_ids`` (specific proposal ids) **or** ``approve_above`` (a
    cosine threshold — every pending proposal with score ≥ it). The chosen pending
    rows are marked approved, then each ``[[target]]`` is written into its source
    note's ``## Связано`` section — additive, idempotent, prose untouched. Only
    **approved** proposals are ever applied. ``apply`` (default False) gates the
    write: False returns the plan and changes nothing; True edits the notes, saves
    the queue (statuses → ``applied``) and appends the journal. Returns counts.
    """
    from core.config import default_vault_path, link_proposals_path

    queue = LinkProposalQueue.load(link_proposals_path())
    selected: list[str] = []
    skipped: list[dict[str, str]] = []
    if approve_ids:
        for pid in approve_ids:
            p = queue.by_id.get(pid)
            if p is None:
                # CONTRACT-2 С13: раньше неизвестный id молча выпадал, и ответ
                # «approved: 0» был неотличим от «нечего одобрять».
                skipped.append({"id": pid, "reason": "not_found"})
            elif p.status != STATUS_PENDING:
                skipped.append({"id": pid, "reason": f"status:{p.status}"})
            else:
                p.status = STATUS_APPROVED
                selected.append(pid)
    elif approve_above is not None:
        for p in queue.by_id.values():
            if p.status == STATUS_PENDING and p.score >= approve_above:
                p.status = STATUS_APPROVED
                selected.append(p.id)

    result = _core_apply_approved(queue, default_vault_path(), dry_run=not apply)
    # SEC-6 audit: counts + write flag only — no note ids/content/link targets.
    _core_pult.record_action(
        "apply_links",
        {"approved": len(selected), "applied": result.applied,
         "touched": len(set(result.touched_notes)), "written": bool(apply)},
        outcome="applied" if apply else "dry_run",
    )
    out: dict[str, Any] = {
        "approved": len(selected),
        "applied": result.applied,
        "already_present": result.already_present,
        "missing_source": result.missing_source,
        "touched_notes": sorted(set(result.touched_notes)),
        "written": apply,
        "journal": result.journal,
    }
    if skipped:
        from core.contract import CODE_SKIPPED, add_warning

        out["skipped_ids"] = skipped
        add_warning(
            out, CODE_SKIPPED,
            "часть approve_ids не применена: "
            + ", ".join(f"…{s['id'][-4:]} — {s['reason']}" for s in skipped[:5]),
            skipped=len(skipped),
        )
    return out


# --------------------------------------------------------------------------- #
# Пульт (ADMIN-1 v2A) — очередь/автономия/KPI/здоровье sync.                    #
# Логика в core.operational.pult / core.metrics; здесь — тонкие обёртки.        #
# --------------------------------------------------------------------------- #
def pult_kpi(days: int = 7, unused: bool = False) -> dict[str, Any]:
    """Агрегаты dt-kpi как данные для плиток/тренда пульта (не текст).

    Ровно те же цифры, что ``dt-kpi``: оба зовут ``core.metrics.summarize`` —
    счётчики и доли метрик 1–3 + ``daily`` (ряд по дням окна для тренда).
    WAVE1-MEASURE п.2: ``usage`` — употребление за 30 дн (``core.metrics.usage_summary``:
    вызовов, инструментов без вызовов N из M, вкладок/секций пульта без открытий,
    ``coverage_days`` — с каких пор телеметрия копится; ``hosts`` — вызовы по хостам).
    PULT-STANDALONE-1: ``usage.surfaces`` - разрез по поверхности (``mcp`` = артефакт пульта и
    MCP-хосты, ``webpult``, ``cli``, ``unknown`` = до разметки): ``[{surface, calls, pult_calls,
    ui_opens, last_ui_ts, last_ts}]``; ``usage.by_surface`` - по поверхности ``{available, called,
    unused}`` инструментов (веб-пульту доступен профиль ``pult``, остальным - все); с
    ``unused=true`` + ``unused_by_surface`` (списки).
    ``usage.rerank`` — ``{days, calls, p50_ms, p95_ms, pool_p50, device}``: время второго этапа
    ранжирования ``find_notes`` за 7 дн или ``null``, если реранкер не работал.
    ``host_access`` — хосты и выданные им папки (``host-access.yaml``) + сверка с телеметрией.
    MODEL-1: ``outputs`` — выходы 07-outputs за 30 дн по хостам: ``{days, total, no_host, hosts:
    [{host, count, model_known, model_share, last}]}`` (``host: "—"`` — выход без ``host`` в мете;
    ``model_share`` — доля с ``model_source ≠ unknown``).
    ``unused=True`` добавляет
    ПОЛНЫЕ списки молчащих инструментов/поверхностей (по умолчанию — только числа).
    EVAL-3: ``health`` — снимок последнего доктора (``core.diagnostics.last_snapshot``:
    ``{ts, oks, warns, fails, worst, items[{name,status,detail}], age_min, stale}``) для
    индикатора здоровья в шапке пульта; нет снимка → ``health: null`` + конверт ``no_runs``,
    битый файл → ``store_unavailable``.
    Read-only, без сети; privacy журнала — только счётчики/типы.
    """
    from core.metrics import usage_summary

    out = _core_kpi_summarize(max(1, int(days)))
    use = usage_summary(30, known_tools=TOOL_NAMES)
    compact = {
        "days": use["days"], "calls": use["calls"], "ui_opens": use["ui_opens"],
        "coverage_days": use["coverage_days"], "observed_since": use["observed_since"],
        "tools_total": use.get("tools_total", len(TOOL_NAMES)),
        "tools_unused": len(use.get("unused_tools", [])),
        "ui_total": use.get("ui_total", 0), "ui_unused": len(use["unused_ui"]),
    }
    # VENDOR-HYGIENE-1 п.3: вызовы по хостам за 30 дн (claude-ai / webpult / Kimi после его
    # вызова): ``[{host, surface, calls, errors, last_ts}]``, без аргументов и текстов.
    compact["hosts"] = use["hosts"]
    # PULT-STANDALONE-1 п.6: разрез по поверхностям (решение «что первично» - по этим числам).
    compact["surfaces"] = use["surfaces"]
    reachable = {"webpult": set(PROFILES["pult"])}
    by_surface: dict[str, dict[str, int]] = {}
    unused_lists: dict[str, list[str]] = {}
    for surface in ("mcp", "webpult"):
        avail = reachable.get(surface, set(TOOL_NAMES))
        called = set(use["tools_by_surface"].get(surface, [])) & avail
        by_surface[surface] = {"available": len(avail), "called": len(called),
                               "unused": len(avail - called)}
        unused_lists[surface] = sorted(avail - called)
    compact["by_surface"] = by_surface
    # RETR-RERANK-1 п.5: p50/p95 времени реранкера за 7 дн (``None`` — реранкер не работал).
    compact["rerank"] = use.get("rerank")
    if unused:
        compact["unused_tools"] = use.get("unused_tools", [])
        compact["unused_by_surface"] = unused_lists
        compact["unused_ui"] = use["unused_ui"]
        compact["top_tools"] = use["tools"][:15]
    if "warning" in use:
        compact["warning"] = use["warning"]
    out["usage"] = compact
    # VENDOR-HYGIENE-1 п.6: хосты и выданные им папки (read-only, ``_system/host-access.yaml``)
    # + сверка с телеметрией: для блока «Хосты и папки» в Мониторинге пульта.
    try:
        from core.host_access import overview as _host_access_overview

        out["host_access"] = _host_access_overview()
    except Exception as exc:  # noqa: BLE001 — витрина не должна ронять KPI
        out["host_access"] = {"hosts": [], "error": f"host-access не прочитан: {exc}"[:300]}
    # MODEL-1 п.A3: выходы по хостам (чтение meta.yaml, без LLM).
    try:
        from core.eval_generation import outputs_by_host

        out["outputs"] = outputs_by_host(30)
    except Exception as exc:  # noqa: BLE001 — витрина не должна ронять KPI
        out["outputs"] = {"days": 30, "total": 0, "no_host": 0, "hosts": [],
                          "error": f"выходы не прочитаны: {exc}"[:300]}
    # EVAL-3 п.5: индикатор здоровья в шапке пульта — снимок последнего доктора (warn/fail +
    # счётчики, ``age_min``, ``stale`` > 24 ч). Из файла, без запуска проверок (3 мс).
    from core.contract import CODE_NO_RUNS, CODE_STORE_UNAVAILABLE, add_warning
    from core.diagnostics import snapshot_state

    health, health_error = snapshot_state()
    out["health"] = health
    if health_error:
        add_warning(out, CODE_STORE_UNAVAILABLE, health_error, component="doctor_snapshot")
    elif health is None:
        add_warning(out, CODE_NO_RUNS,
                    "снимка доктора ещё нет — запусти dt_sync index --steps doctor или "
                    "кнопку «Проверить» в «Здоровье DT»", component="doctor_snapshot")
    return out


def pult_sync_status() -> dict[str, Any]:
    """Здоровье оперативного контура — последний fast/full прогон + running.

    Разбор хвоста ``.derived/logs/dt-sync.log`` (в core): ``{last_fast: {ts, ok,
    failed_steps}, last_full: {…}, running}``; ``running`` — по flock-локу
    dt-sync. Read-only, без сети.
    """
    return _core_pult.sync_status()


def pult_log_tail(lines: int = 80, errors_only: bool = False) -> dict[str, Any]:
    """Хвост dt-sync-лога для админ-вкладки пульта (только текст).

    Строки уже отскраблены при записи (токены никогда не попадают в лог);
    ``errors_only=True`` оставляет ERROR/WARNING. Максимум 1000 строк за вызов.
    """
    return _core_pult.log_tail(lines, errors_only)


def pult_run_sync(mode: str, steps: list[str] | None = None) -> dict[str, Any]:
    """Кнопка «sync сейчас» — detached-запуск dt_sync, ответ сразу.

    ``mode="fast"`` (оборот входящих) | ``"index"`` (линковка+индекс) |
    ``"full"`` (fast+index). ``steps`` — только эти шаги режима (RETIRE-WRITE-1 п.7: «обновить
    почту», а не весь fast): fast = refresh, pull_capture, reconcile, file_ingest, mail_ingest;
    index = file_ingest_knowledge, link_auto, hub_scan, lint, reindex_inc, eval, doctor. Неизвестный
    шаг → конверт ``bad_steps`` и ничего не запущено. Fire-and-forget: процесс отвязывается
    и НЕ ожидается.

    Возвращает ``{started, mode, pid, steps, already_running}``. **Занято** (лок режима держит
    другой прогон) → ``started: false`` + ``running: {mode, step, pid, started}`` + конверт
    ``skipped`` с ИМЕНЕМ идущего прогона и шагом — а не тихий запуск дубля. Запуск
    журналируется в pult-actions.log (режим + имена шагов).
    """
    return _core_pult.start_sync(mode, steps=steps)


def pult_activity(ui: str = "") -> dict[str, Any]:
    """Что сейчас работает — прогресс-маяки долгих операций + load/swap (ACT-1).

    WAVE1-MEASURE п.2: ``ui="tab:work,sec:queue"`` — пульт отмечает открытие вкладки/секции
    (запятая — пачка за один вызов, чтобы не плодить MCP-запросов). Только имена из
    закрытого словаря (``core.metrics.UI_TABS``/``UI_SECTIONS``); чужое отбрасывается.
    С ``ui`` возвращается ``{ui_recorded:[…], ui_rejected:n}`` — маяки не читаются. Это не
    запись данных пользователя: один счётчик в журнал метрик.

    ``processes``: по маяку на процесс (index / link / mail / dt-sync) — статус
    ``running`` (pid жив) / ``finished`` / ``interrupted`` (прерван; продолжится
    от чекпойнта), фаза, current/total, eta_s, аптайм. ``system``:
    ``{load_avg_1m, cpu_count, swap}`` — числа для плитки «ноут раскочегарен»
    (swap = null, если sysctl недоступен). Read-only, без сети.
    """
    if ui and ui.strip():
        from core.metrics import UI_PREFIX, valid_ui_name

        names = [n.strip() for n in ui.split(",") if n.strip()][:24]
        good = [n for n in names if valid_ui_name(n)]
        for name in good:
            _record_tool_call(UI_PREFIX + name, True, 0)
        return {"ui_recorded": good, "ui_rejected": len(names) - len(good)}
    return _core_pult.activity()


def pult_freshness() -> dict[str, Any]:
    """Актуальность данных по источникам (FRESH-1) — «данные на момент X».

    По каждому из шести источников (mail / timetta / ticktick / index / linking /
    files:knowledge — последний ЗАВЕРШЁННЫЙ скан знаниевого корня, плюс ``pending_download``
    и ``watchdog_kills`` за 7 дн):
    ``{source, data_as_of, lag_h, stale, stale_after_h, last_run: {ts, ok}}`` —
    свежесть из манифестов/курсоров (12k-файловые директории не сканируются,
    индексный манифест не парсится), последний прогон шага — из dt-sync-лога,
    ``index`` дополнительно несёт ``notes_newer`` (заметок vault новее индекса).
    Отсутствующий источник — честные null, не ошибка. Read-only, без сети,
    выдача < 200 мс.
    """
    from core.operational.freshness import snapshot as _freshness_snapshot

    return _freshness_snapshot()


def pult_monitor() -> dict[str, Any]:
    """Мониторинг одной карточкой (PULT-SURFACE-2, MONITOR-CARD-1): всё, что смотрит вкладка
    «Мониторинг», ОДНИМ read-вызовом из снимков и статусов, без сканов и расчетов.

    ``{health, night_chain, services, sync, jobs, activity, freshness, storage, as_of, timings}``:
    ``health`` - ``{worst, oks, warns, fails, problems, items: [первые 5 warn/fail {name, status,
    detail}], source}`` из снимка доктора (``doctor()`` целиком - кнопка «Проверить живьем»);
    ``night_chain`` - последний прогон index: общее время, топ-3 шага, ``warnings``, ``status``
    (те же пороги, что у доктора «Ночная цепочка»); ``services`` - как ``pult_services``; ``sync`` -
    как ``pult_sync_status`` (fast/index/full: последний запуск и итог, ``running``); ``jobs`` -
    как ``job_list`` (12 последних); ``activity`` - как ``pult_activity``; ``freshness`` - как
    ``pult_freshness``; ``storage`` - снимок ``pult_storage_status``. Снимка нет (доктор/хранилище
    ни разу не считались) → блок ``{available: false}``, НИЧЕГО не запускается. Сбой блока →
    ``{error}``, остальные отдаются. ``as_of`` - время данных по блокам, ``timings`` - мс на блок.
    Read-only, без сети/LLM.
    """
    from core.operational.monitor import monitor

    return monitor()


def pult_manifest() -> dict[str, Any]:
    """Манифест роли экземпляра (PERSONAL-3): что есть у ЭТОГО экземпляра - пульт рисует только это.

    ``{instance: {name, role}, title, subtitle, sections, monitor_blocks, jobs, card_kinds,
    freshness_sources, sync_modes, version}``. ``sections`` - ключи секций пульта (``data-help``);
    ``monitor_blocks`` - блоки карточки «Мониторинг»; ``jobs`` - кнопки заданий
    ``[{label, op, args}]``; ``card_kinds`` - виды «Требуют решения»; ``freshness_sources`` - строки
    «Свежести»; ``sync_modes`` - шаги ``fast``/``index``/``full`` роли; ``version`` - 12 символов
    sha256 содержимого (хост видит, что манифест сменился). Таблица одна для всех потребителей
    (``core.surface.manifest``): адаптеры входа, задания, виды карточек, доктор читают ее же. У
    рабочей роли - все как до PERSONAL-3. Read-only, без сети.
    """
    from core.surface import manifest

    return manifest.manifest()


def pult_services() -> list[dict[str, Any]]:
    """Статус всех сервисов движка (PULT-ENGINE) — сетка контура «Движок».

    Единый реестр из ``core.operational.services``: три launchd-демона
    (``sync.fast`` / ``sync.index`` / ``webpult``) + MCP-сервер. По каждому —
    ``{key, label, kind, control, plist_label, loaded, running, status
    (running|loaded|stopped), pid, last_exit_code, note}``. launchd — по
    ``launchctl list``; MCP — эвристика живости (``control="status_only"`` +
    подпись «управляется MCP-хостом»). Read-only, без гарда. macOS-специфично; сбой
    ``launchctl`` → честный ``stopped``.
    """
    return _core_services.service_status("all")  # type: ignore[return-value]


def pult_service_control(key: str, action: str) -> dict[str, Any]:
    """Управление сервисом движка — start/stop/restart (PULT-ENGINE). Действие.

    ``action`` обязателен (гард): ``start`` (``launchctl bootstrap``) / ``stop``
    (``bootout``) / ``restart`` (``kickstart -k``) — тот же паттерн, что
    ``pult_web_restart``. Только для launchd-сервисов (``control="full"``);
    MCP-сервер (``status_only``) → отказ ``{ok: False, refused: True, error}``
    («управляется MCP-хостом»), команда не выполняется. Мутация журналируется
    в ``pult-actions.log``. Возврат ``{ok, key, action, cmd, returncode, error?}``.
    """
    try:
        return _core_services.service_control(key, action)
    except _core_services.ServiceControlError as exc:
        return {"ok": False, "refused": True, "key": key, "action": action,
                "error": str(exc)}


def pult_events(
    note_id: str | None = None,
    source_hash: str | None = None,
    recent: bool = False,
    limit: int = 50,
    stage: str | None = None,
) -> list[dict[str, Any]] | dict[str, Any]:
    """Сквозной лог стадий пайплайна (PULT-EVENTLOG) — read-only лента/таймлайн.

    По каждому артефакту, идущему через пайплайн, стадия пишет событие
    (**ingest→hub→index→link**), привязанное к ``note_id`` (ingest-событие несёт
    ещё ``source_hash`` — сшивка файл→заметка). НЕ путать с ``pult_kpi`` (та —
    агрегатная аналитика ``dt-kpi``); тут per-artifact lifecycle из таблицы
    ``events`` единой ``dt.db``.

    Режимы: ``note_id`` (или ``source_hash`` — резолвится в ``note_id`` через
    ingest-событие) → **таймлайн артефакта** по времени; иначе (или ``recent=True``)
    → **свежая лента** (новые сверху), фильтр ``stage`` (``ingest``/``hub``/
    ``index``/``link``), ``limit``. Каждое событие: ``{event_id, ts, note_id,
    source_hash, path, stage, status, detail, run_id}``; ``detail`` — только
    метаданные стадии (counts/статусы/пути), без тела/сумм. Read-only, без
    сети/LLM.

    **Журнал не прочитался (CONTRACT-2 С7)** → ``{"events": [], "warning": [{code:
    "store_unavailable", …}]}`` вместо голого списка: пустая лента при заблокированной
    ``dt.db`` выглядела как «событий нет».
    """
    from core.eventlog import artifact_timeline, last_read_error, recent_events

    if (note_id or source_hash) and not recent:
        events = artifact_timeline(note_id=note_id, source_hash=source_hash)
    else:
        events = recent_events(limit=limit, stage=stage)
    broken = last_read_error()
    if broken:
        # CONTRACT-2 С7: пустая лента при нечитаемой БД выглядела как «событий нет».
        from core.contract import CODE_STORE_UNAVAILABLE, add_warning

        degraded: dict[str, Any] = {"events": []}
        add_warning(
            degraded, CODE_STORE_UNAVAILABLE,
            f"журнал стадий не прочитан ({broken}) — лента пуста НЕ потому, что "
            "событий нет; проверь .derived/dt.db (pult_storage_status)",
        )
        return degraded
    return [
        {
            "event_id": e.event_id,
            "ts": e.ts,
            "note_id": e.note_id,
            "source_hash": e.source_hash,
            "path": e.path,
            "stage": e.stage,
            "status": e.status,
            "detail": e.detail,
            "run_id": e.run_id,
        }
        for e in events
    ]


def pult_ingest_sources() -> list[dict[str, Any]]:
    """Список источников ingest со статусом для панели «Хранилище» (PULT-STORAGE).

    Сконфигурированные ingest-roots (operational/knowledge из
    ``_system/ingest-roots.yaml``) + фиксированные legacy/mail/capture. По каждому:
    ``{key, kind, label, op, adapter, path?/roots?, exists, include?, exclude?, last_ingest,
    refused_7d, refused_last}`` (INGRESS-1: список фиксированных источников — из реестра адаптеров
    входа; ``refused_7d`` — отказы входа за 7 дн ``{причина: n}``, ``null`` — журнал отказов не
    прочитался; ``refused_last`` — до 20 последних с подсказкой; приватное в журнал не попадает).
    ``op`` — JOB-1 op источника: запуск = ``submit_job(op, {"mode": "light"|"full",
    "root"?})`` (light=dry-run превью, full=apply); пачкой = несколько submit.
    Прогресс/cancel — через панель заданий (Движок). Read-only, без сети.
    """
    return _core_storage.ingest_sources()


def pult_ingest_trace(
    query: str | None = None, root: str | None = None, limit: int = 20, offset: int = 0
) -> dict[str, Any]:
    """Файловая трасса инжеста «файл → заметка → индекс» (INGEST-VIS-1) — read-only.

    Отвечает на вопрос, который агрегаты «Источников» не закрывают: **а мой файл X
    попал в vault и в индекс?** Джойн уже существующих манифестов
    (``current``/``legacy`` ingest + ``index_manifest``) — **никакого нового стейта**,
    ни сканов деревьев, ни сети: только чтение манифестов + ``stat`` заметок
    отфильтрованных строк (mtime заметки = когда инжест её записал).

    ``query`` — подстрока по пути источника ИЛИ заметки (регистронезависимо, кириллица
    как есть); ``root`` — фильтр по корню/корпусу (``current``/``legacy``); ``limit`` —
    размер порции (дефолт 20, потолок 200), ``offset`` — сколько строк пропустить
    (пагинация «показать ещё» на пульте). Сортировка — новые сверху, при равных датах
    по пути источника: порядок между вызовами стабилен, поэтому листание не даёт
    дублей и пропусков. ``has_more`` в ответе говорит, есть ли следующая порция.

    Возврат ``{ok, query, root, limit, total, shown, rows, counts, index_as_of, hint}``;
    строка — ``{source_path, root, corpus, note_path, ingested_at, indexed, index_age,
    status, chunks, size}``. ``status``: ``indexed`` (в индексе и не менялась) /
    ``waiting_index`` (ждёт ближайшего reindex) / ``nda`` (под NDA-барьером — в индекс
    не попадёт by design) / ``note_missing`` (заметку удалили с диска) / ``duplicate``
    (несколько источников свёрнуты дедупом в одну заметку). Пусто → ``hint`` объясняет,
    где искать причину.
    """
    from core.file_ingest.trace import ingest_trace

    return ingest_trace(query=query, root=root, limit=limit, offset=offset)


def pult_storage_status(refresh: bool = False) -> dict[str, Any]:
    """Здоровье хранилища одним вызовом (PULT-STORAGE) — read-only, реюз diagnostics.

    ``{db: {schema_version, facts, sources, jobs, events, exists}, nda: {markers,
    sources_flagged, facts_flagged}, dedup: {with_hash, total, coverage_pct},
    eventlog: {ingest, hub, index, link, total}, lance: {...}, as_of, cached}`` — DB-1
    (схема+счётчики), NDA-1 (маркеры + сколько NDA-следов в derived, что отсёк бы purge),
    INGEST-DEDUP (byte-hash coverage), PULT-EVENTLOG (события по стадиям), WAVE0-HYGIENE
    (LanceDB). Каждый блок при сбое → ``{error}`` (витрина частична, не пуста). Без сети/LLM.

    **Из снимка (PULT-SURFACE-2).** Скан NDA-следов по ``.derived`` и статистика LanceDB дают
    ~6 с, поэтому ``refresh=False`` отдает снимок не старше ``DT_PULT_STORAGE_TTL_S`` (900 с);
    ``refresh=True`` («Пересчитать хранилище») считает сейчас. Действие над хранилищем
    (``pult_storage_action``) сбрасывает снимок. ``as_of`` - когда посчитано, ``cached`` - из
    снимка ли.
    """
    from core.operational.snapshot import cached_read, ttl_from_env

    payload, meta = cached_read(
        "storage", ttl_from_env("DT_PULT_STORAGE_TTL_S", 900), _core_storage.storage_status,
        refresh=bool(refresh),
    )
    return {**payload, "as_of": meta["as_of"], "cached": meta["cached"]}


def pult_storage_action(action: str, confirm: bool = False) -> dict[str, Any]:
    """Действие над хранилищем — gated (PULT-STORAGE). Деструктив за подтверждением.

    ``action``: ``rebuild-db`` (снести ``dt.db``+WAL/SHM → пересоберётся),
    ``purge-nda`` (удалить NDA-следы из derived), ``backfill-hashes`` (INGEST-DEDUP
    — долгое, уходит в JOB-1). Деструктив (``rebuild-db``/``purge-nda``) **без
    ``confirm``** возвращает read-only **превью** (что будет удалено; ничего не
    трогает); **с ``confirm=True``** выполняет и пишет аудит ``record_action``.
    ``backfill-hashes`` → ``{job_id, op, state}`` (следи через ``job_status`` /
    панель заданий Движка).
    """
    out = _core_storage.storage_action(action, confirm=confirm)
    # PULT-SURFACE-2: действие меняет то, что показывает снимок «Хранилища» - сбросить его.
    from core.operational.snapshot import invalidate

    invalidate("storage")
    return out


def pult_paths_get() -> dict[str, Any]:
    """Текущие корни ingest + legacy для редактора путей (PULT-STORAGE, read-only).

    ``{roots: [{name, path, route, include, exclude, note_type, entity_hint}],
    legacy_roots: [str], roots_yaml, editable}``. ``editable`` — сконфигурирован ли
    веб-токен (без него правка недоступна, только просмотр). Пути уже
    разрешены per-device. Без сети/LLM.
    """
    return _core_storage.paths_get()


def pult_paths_set(
    roots: list[dict[str, Any]] | None = None,
    legacy_roots: list[str] | None = None,
    token: str | None = None,
) -> dict[str, Any]:
    """Записать конфиг путей (PULT-STORAGE; PULT-TOKEN-UX — без токен-гейта). Конфиг.

    Авторизация — на границе транспорта (сетевой веб-пульт гейтит ``/api/`` в
    ``webpult/server.py::_authorized``; доверенный десктопный MCP её не дублирует),
    поэтому собственного токен-гейта нет. ``token`` принимается для обратной
    совместимости и игнорируется. ``roots`` (если задан) — валидация схемы
    (name/``route``∈{operational,knowledge}/globs; невалидное → отказ) + запись
    ``_system/ingest-roots.yaml`` с ``.bak``; несуществующий путь → warning, не отказ
    (iCloud dataless). ``legacy_roots`` (если задан) — правит **только** ключ
    ``DT_LEGACY_ROOTS`` в ``engine/.env`` (прочие секреты целы, ``.env.bak``). Пишет
    ``record_action``; в vault-контент не пишет.
    """
    from core.operational.storage import PathsError

    try:
        return _core_storage.paths_set(
            roots=roots, legacy_roots=legacy_roots, token=token
        )
    except PathsError as exc:
        return {"ok": False, "refused": True, "error": str(exc)}


def _ai_view(settings: dict[str, Any]) -> dict[str, Any]:
    """Настройки ``ai`` для ответа (GATEWAY-1): профили, маршруты, классы, ``sends_data_out`` по
    классам; у профиля - статус ключа (хвост 4 символа, не ключ)."""
    from core.operational import ai_layer

    return ai_layer.settings_view(settings)


def _crm_admin_email() -> str | None:
    from core.config import crm_admin_email

    return crm_admin_email()


def pult_settings_get() -> dict[str, Any]:
    """Настройки пульта (PULT-STANDALONE-1), раздел ``ai`` - read-only.

    PERSONAL-2: у ЭКЗЕМПЛЯРА (``DT_INSTANCE``) добавлены ``instance`` (``{name, role}``) и секции
    ``bridge`` (``min_score``, ``exclude``, ``snooze_days``, ``limit``, ``budget_s``) и ``personal``
    (``journal_dir``, ``ideas_dir``, ``content_dirs``, ``inbox``, ``index_exclude``): каждая -
    ``{поле: {value, key, doc, set}}``, действующие значения из оверлея экземпляра. У рабочего
    экземпляра этих ключей нет.

    ``{ai: {profiles: {имя: {provider, url, model, timeout_s, max_chars, max_calls_per_hour,
    key: {configured, tail, file, mode_ok}}}, routes: {класс: профиль|host|none}, classes: {класс:
    [виды]}, sides: {класс: none|host|daemon}, sends_data_out: {класс: bool}, legacy_flat},
    providers, editable, last_call}`` (GATEWAY-1). Классы задач: ``triage`` (``brief``, ``lane``),
    ``synth`` (``hub_synth``, ``hub_lint``), ``draft``; маршрут класса - имя профиля, ``host``
    (синтез делает хост через ``askClaude``) или ``none`` (база без синтезов). ``provider`` профиля:
    ``none`` | ``host`` | ``openai`` | ``anthropic`` (вызов делает демон; данные уходят провайдеру,
    если url не локальный, - явный выбор пользователя). ``legacy_flat: true`` - файл еще в плоской
    форме (прочитан как профиль ``default``; ``dt ai migrate``).
    ``owner`` - строка профиля владельца (PROFILE-1, read-only): ``{exists, name, updated, version,
    status, summary, hint, missing}``, статус тот же, что у строки доктора «Профиль владельца».
    ``crm_admin_email`` - адресат поручений администратору CRM (``DT_CRM_ADMIN_EMAIL``) или
    ``null``.
    Ключ показывается ТОЛЬКО статусом (``configured``, ``tail`` - последние 4 символа): задать его
    можно командой ``dt ai set-key [--profile P]`` (файл ``.secrets/pult_ai_key[-P]``, права 600),
    через артефакт и браузер секрет не ходит. ``last_call`` - последний вызов провайдеру из аудита
    (или ``null``).
    """
    from core import instance_settings
    from core.instance import instance_name, instance_role
    from core.operational import ai_layer
    from core.owner import load_profile
    from core.owner.check import settings_view

    out: dict[str, Any] = {
        "ai": _ai_view(ai_layer.get_settings()),
        "providers": list(ai_layer.PROVIDERS),
        "editable": list(ai_layer.TOOL_FIELDS),
        "last_call": ai_layer.last_call(),
        "owner": settings_view(load_profile(), os.environ),
        # SURFACE-HYGIENE-1: адресат поручений (DT_CRM_ADMIN_EMAIL) - для черновика «поручить» у
        # «Дозрели»; раньше его отдавал pult_assignments. Адрес - не секрет: он в каждом письме.
        "crm_admin_email": _crm_admin_email() or None,
    }
    if instance_name():  # PERSONAL-2: у рабочего экземпляра этих ключей нет
        out["instance"] = {"name": instance_name(), "role": instance_role()}
        out["bridge"] = instance_settings.get_section("bridge")
        out["personal"] = instance_settings.get_section("personal")
    return out


def pult_settings_set(section: str, values: dict[str, Any]) -> dict[str, Any]:
    """Изменить настройки пульта (PULT-STANDALONE-1). Конфиг (``_system/pult.yaml``).

    ``section`` - ``"ai"``; у личного экземпляра (PERSONAL-2) еще ``"bridge"`` и ``"personal"``
    (поля - в :func:`pult_settings_get`; пишет оверлей экземпляра писателем ``env_file``, демон
    видит новое значение без рестарта; значение проверяется, битое - ``invalid_value`` и ничего не
    записано). Для ``ai`` (GATEWAY-1) ``values`` - частичный набор ключей: ``routes.<класс>`` (класс
    ``triage|synth|draft`` -> имя профиля | ``host`` | ``none``; нет класса - ``unknown_class``, нет
    профиля - ``unknown_profile``), ``profiles.<имя>.<поле>`` с полем из ``provider``, ``url``,
    ``model``, ``timeout_s``, ``max_chars``, ``max_calls_per_hour`` (профиль, которого нет,
    создается),
    ``profiles.<имя>: null`` (удалить; ``profile_in_use``, если на него есть маршрут). Плоские поля
    (``provider``, ``url``...) - на профиль ``default`` (совместимость). Валидация: провайдер из
    списка, url ``http(s)`` без логина/query, ``http`` только для localhost/локальной сети, модель
    без пробелов, для ``openai``/``anthropic`` обязательна модель. **Ключ через инструмент не
    принимается**: любое поле про ключ/токен/секрет - отказ ``key_not_here``, указатель на файл
    (``key_file``) тоже (``dt ai set-key``). Отказ валидации - ``{ok: false, refused: true, code,
    error}``. Пишет аудит ``pult_settings_set`` (имена полей, не значения) и возвращает то же, что
    :func:`pult_settings_get`.
    """
    from core import instance_settings
    from core.instance import instance_name
    from core.operational import ai_layer
    from core.operational.pult import record_action

    if section in instance_settings.SECTIONS and instance_name():
        try:
            saved_inst = instance_settings.set_section(section, values)
        except instance_settings.SettingsError as exc:
            record_action("pult_settings_set", {"section": section}, f"refused:{exc.code}")
            return {"ok": False, "refused": True, "code": exc.code, "error": exc.detail}
        record_action("pult_settings_set",
                      {"section": section, "fields": ",".join(sorted(values))}, "ok")
        return {"ok": True, "section": section, **saved_inst}
    if section != "ai":
        return {"ok": False, "refused": True, "code": "bad_section",
                "error": "section: пока только ai"}
    try:
        saved = ai_layer.save_settings(values)
    except ai_layer.SettingsError as exc:
        record_action("pult_settings_set", {"section": section}, f"refused:{exc.code}")
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc)}
    record_action("pult_settings_set",
                  {"section": section, "fields": ",".join(sorted(values))}, "ok")
    return {"ok": True, "ai": _ai_view(saved), "providers": list(ai_layer.PROVIDERS),
            "editable": list(ai_layer.TOOL_FIELDS), "last_call": ai_layer.last_call()}


def pult_ai(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    """ИИ-синтез пульта по настройке ``pult.yaml: ai`` (PULT-STANDALONE-1, GATEWAY-1) - пять видов.

    Вид относится к классу задач (``brief``/``lane`` - ``triage``, ``hub_synth``/``hub_lint`` -
    ``synth``, ``draft`` - ``draft``); профиль модели берется по маршруту класса.

    ``kind``: ``brief`` (переформулировать бриф: ``payload={brief, summary}`` -> 2-3 фразы),
    ``lane``
    (рекомендация лейна: ``payload={text, suggested_lane}`` -> ``text="LANE|причина"`` + ``lane`` +
    ``reason``), ``draft`` (черновик по промпту ``generate``: ``payload={prompt}``),
    ``hub_synth`` (HUB-SYNTH-1: ``payload={hub_id}`` -> промпт досье состояния хаба
    (:func:`hub_synth_context`) -> провайдер -> ТЕ ЖЕ проверки и карточка, что у
    :func:`hub_synth_propose`; ответ несет ``proposal.card_id``; отказ проверки - ``ok: false`` с
    ``code`` ``ungrounded``/``too_long``/... и текстом провайдера в ``text``), ``hub_lint``
    (KNOWLEDGE-LINT-1: ``payload={hub_id}``; утверждения хаба, которые дельта опровергает ->
    ``findings`` правила claim в карточки lint). Шаблоны
    промптов фиксированы в движке (``core/operational/ai_layer.py``), свободных вызовов нет: это
    слой подсказок интерфейса, а не генератор артефактов (Путь B). Вызов к ``openai``/``anthropic``
    делает демон, ключ - только из ``.secrets/``.

    Возврат ``{ok, kind, class, route, profile, text, provider, model, cached, ms, code?}``; отказ
    (``ai_disabled`` для маршрута ``none``, ``ai_host_side`` для ``host``, ``unknown_profile``,
    ``no_key``, ``timeout``, ``rate_limited``, ``auth``, ``provider_error``, ``bad_format``...) -
    ``{ok: false, code, text: null}`` с теми же ``class/route/profile``: пульт остается на
    детерминированной базе. Кэш на день по ``(kind, sha(payload), профиль, provider, model)``:
    повторный запрос не стоит нового вызова и дает тот же текст; лимит вызовов - по профилю.
    Аудит ``ai_synthesis`` без текста и ключа (с ``class``, ``profile``, ``route``).
    """
    from core.operational import ai_gateway, ai_layer

    where = {"class": ai_gateway.KIND_CLASS.get(kind), "route": None, "profile": None}

    def refused(code: str) -> dict[str, Any]:
        return {"ok": False, "kind": kind, **where, "code": code, "text": None}

    if kind == "hub_synth":
        from core.operational import hub_synth

        hub_id = (payload or {}).get("hub_id") if isinstance(payload, dict) else None
        if not isinstance(hub_id, str) or not hub_id.strip():
            return refused("bad_payload")
        res = {**where, **hub_synth.run_ai(hub_id.strip(), ai_layer.synthesize)}
        if res.get("proposal"):
            _core_pult.record_action(
                "hub_synth_propose",
                {"hub_id": res["proposal"]["hub_id"], "card": res["proposal"]["card_id"],
                 "items": res["proposal"]["items"], "via": "pult_ai"}, "ok")
        return res
    if kind == "hub_lint":  # KNOWLEDGE-LINT-1: проход по хабу -> находки правила claim (по кнопке)
        from core.lint import claims

        hub_id = (payload or {}).get("hub_id") if isinstance(payload, dict) else None
        if not isinstance(hub_id, str) or not hub_id.strip():
            return refused("bad_payload")
        res = {**where, **claims.run_ai(hub_id.strip(), ai_layer.synthesize)}
        if res.get("findings"):
            _core_pult.record_action(
                "lint_claims", {"hub_id": hub_id.strip(), "n": len(res["findings"]),
                                "via": "pult_ai"}, "ok")
        return res
    return ai_layer.synthesize(kind, payload)


def pult_choose_folder(prompt: str | None = None) -> dict[str, Any]:
    """Открыть нативный выбор папки в Finder и вернуть путь (PULT-FOLDER-PICKER).

    Хостовый ``osascript 'choose folder'`` (браузер/артефакт нативный Finder не
    умеет — страница без доступа к ОС). Возврат ``{path: str|null, cancelled: bool, available:
    bool}``: ``available=false`` — не macOS / нет ``osascript`` (фронт прячет кнопку
    и падает на ручной ввод); ``path=null`` при ``available=true`` — пользователь
    отменил диалог. Read-only — только возвращает путь, ничего не пишет; сам путь
    сохраняется отдельным ``pult_paths_set`` за токеном. На веб-пульте (телефон)
    диалог открылся бы на Mac, не на телефоне — фронт кнопку там не показывает.
    """
    from core.operational.folder_picker import choose_folder, picker_available

    if not picker_available():
        return {"path": None, "cancelled": False, "available": False}
    from core.adapters import AdapterError

    try:
        path = choose_folder(prompt or "Выберите папку для Digital Twin")
    except AdapterError as exc:
        # Ошибка диалога ≠ «пользователь отменил»: конверт п.22 с причиной (ADAPTER-HONEST-1).
        return exc.add_to({"path": None, "cancelled": False, "available": True})
    return {"path": path, "cancelled": path is None, "available": True}


def work_feed(rings: str | None = None) -> dict[str, Any]:
    """Фид рабочего кокпита (WORK-1/WORK-2) — данные для вкладки «Работа».

    Структурный срез из локальных зеркал (без сети, без LLM; утренний бриф
    синтезирует потребитель через askClaude поверх этого):

    * ``attention`` — что «горит»: просроченные/близкие пункты чек-листа сделок,
      просроченные project-issues, входящие письма без ответа в свежем окне;
    * ``stale`` — что «остывает» (resurfacing): активные сделки/проекты/issues,
      давно без изменений, со скором ``cool`` (0..1); терминальные стадии скрыты;
    * ``deltas`` — что изменилось за последние сутки-двое (зеркало + почта);
    * ``counts`` — плитки: ``deals_active, presales, tasks_overdue,
      tasks_due_week, unanswered_mail``;
    * ``brief`` — PULT-STANDALONE-1: детерминированный бриф ``{text, items: [{kind, title,
      ref}], as_of}``, 2-4 предложения по правилам (счетчики, главное внимание до 3 пунктов
      ``просрочено > срок сегодня/завтра > письмо без ответа > остальное``, дельты, коллеги;
      пусто - «Событий нет»). База пульта без модели; ИИ-слой (:func:`pult_ai`) только
      переформулирует его.

    Тишина считается по ``modified`` зеркала и ``last_date`` манифеста почты (не
    по mtime заметок vault). Privacy: code/name/state_name/темы/даты/счётчики —
    суммы и вероятности сделок в выдачу не попадают. Read-only.

    **Кольца орбиты (ORBIT-2).** ``rings`` — ``"mine"`` | ``"mine,unit"`` | ``"mine,unit,group"``
    (``None`` = ``mine``: «Требует внимания» — только мои сделки, форма и поля прежние).
    Запрошенное пересекается с ``DT_ORBIT_RINGS`` (дефолт ``mine,unit``): невидимое кольцо
    не расширяет выдачу. У пунктов по сделкам НЕ из кольца ``mine`` в ``deal`` есть
    ``ring``/``leader`` (бейдж ведущего). Неизвестное кольцо → ``{ok: false, code:
    "bad_rings"}``.
    """
    from core.operational.orbit import OrbitError
    from core.operational.work import snapshot as _work_snapshot

    try:
        return _work_snapshot(rings=rings)
    except OrbitError as exc:
        from core.contract import CODE_BAD_RINGS, add_warning

        return add_warning(
            {"ok": False, "refused": True, "code": exc.code, "error": str(exc)},
            CODE_BAD_RINGS, str(exc), requested=rings,
        )


def work_resurface(limit: int = 10) -> dict[str, Any]:
    """Resurfacing по связям (DEV-1d): «новое легло рядом с тем, что ты знал» — read-only.

    Пара к «Забытым темам»: те показывают, что тихо умирает, этот — что **всплыло**.
    Берёт применённые за последние ``DT_RESURFACE_DAYS`` (7) связи, где источник —
    свежая заметка, а цель — старая (``DT_RESURFACE_OLD_DAYS``, 30): «ты сохранил X —
    она состыковалась с тем, что ты знал». **Нового стейта нет**: джойн журнала
    применённых связей (``link_applied.jsonl``), журнала стадий (``stage=link`` — он
    даёт время) и индекс-манифеста (``note_id`` → путь).

    Возврат ``{now, window_days, old_days, total, pairs}``; пара — ``{id, new_note:
    {id, title, path}, old_note: {…}, resolver, score, rationale, when, as_of,
    new_age_days, old_age_days}``. Превью заметки — ``work_note_preview``; убрать
    карточку — ``work_dismiss(id, "dismiss"|"snooze")`` (тот же серверный стор, что у
    ленты «Внимание»). Read-only, без сети/LLM.
    """
    from core.operational.resurface import resurfaced

    return resurfaced(limit=limit)


def work_dismiss(
    item_id: str,
    action: str,
    as_of: str | None = None,
    until_days: float | None = None,
) -> dict[str, Any]:
    """Снять/отложить пункт «Работы» (WORK-3) — серверное решение по фиду.

    ``action``: ``snooze`` (отложить на ``until_days``, дефолт 7), ``ack``/
    ``dismiss``/``done`` (убрать до нового события — фиксируется ``as_of`` пункта
    из ``work_feed``), ``clear`` (undo — снять решение). Пишет в
    ``.derived/operational/work_dismissals.json``; ``work_feed`` учитывает при
    следующем чтении (пункт с новым ``as_of`` всплывёт снова). Read-modify-write,
    без сети.

    ``item_id`` — составной id из ``work_feed``/``work_resurface`` (``deal:``,
    ``checklist:``, ``project:``, ``issue:``, ``mail:``, ``orphan:``,
    ``hub_deadline:``, ``resurface:``). Неизвестный id → ``{ok: false, refused: true,
    code: "unknown_item"}`` и **ничего не записывается** (CONTRACT-1 ФП-4): решение по
    опечатке молча не принимается. ``clear`` работает и по исчезнувшему пункту, если
    решение по нему уже лежит в сторе (иначе мусор нечем убрать).
    """
    from core.operational.work import record_dismissal

    r = record_dismissal(item_id, action, as_of=as_of, until_days=until_days)
    # SEC-6 audit: item id (identifier) + action + snooze window — no feed content.
    # Отказ по неизвестной ссылке попадает в аудит как отказ, а не как «ok».
    _core_pult.record_action(
        "work_dismiss",
        {"item_id": item_id, "action": action, "until_days": until_days},
        outcome=str(r.get("code") or "refused") if r.get("refused") else "ok",
    )
    return r


def work_context(item_id: str) -> dict[str, Any]:
    """Инлайн-сводка по пункту «Работы» (WORK-4) — чтобы понять без ухода в чат.

    По ``item_id`` из ``work_feed``/``work_resurface`` собирает читабельные ``lines``:
    сделка/проект/issue (``deal:``/``project:``/``issue:``/``checklist:``) — из зеркала
    (стадия, менеджер, клиент, чек-лист, связанные задачи); письмо (``mail:``) — из
    манифеста+сайдкара (контрагенты, число сообщений, направление последнего);
    **заметочные пункты** (``orphan:``/``hub_deadline:``/``resurface:``) — из vault
    (frontmatter + превью тела). Неизвестный вид → ``{found: false, code:
    "unknown_kind"}``. Без LLM; сумм в выдаче нет.

    **ORBIT-3.** У сделки (``deal:``/``checklist:``) добавлены: ``changes[]`` и блок «Изменения
    коллег» в ``lines`` (оффлайн, из ленты ``history_feed``: автор + суть, без значений) и
    ``comments[]`` — последние 5 комментариев Timetta (автор/дата/текст ≤400 симв.) **живым
    чтением** (единственная сеть здесь; только чтение, ничего не сохраняется). Не удалось
    прочитать → ``comments: []`` + конверт ``unavailable``.
    """
    from core.operational.work import context as _work_context

    out = _work_context(item_id)
    guid = out.get("deal_guid") if isinstance(out, dict) else None
    if guid:  # ORBIT-3 п.4: комментарии сделки — живое чтение, без записи и без сохранения
        out = _attach_comments(out, str(guid))
    return out


def _attach_comments(out: dict[str, Any], deal_guid: str, limit: int = 5) -> dict[str, Any]:
    """Дописать ``comments`` (последние N, автор/дата/текст ≤400 симв.) в контекст сделки.

    Сбой чтения не рушит контекст: ``comments: []`` + конверт ``unavailable`` с причиной (нет
    токена / API недоступен / сделки уже нет). Тексты нигде не сохраняются. ``AddComment`` не
    внедрён (P2: упоминание шлёт уведомление)."""
    from core.contract import CODE_UNAVAILABLE, add_warning
    from core.operational.timetta.client import TimettaError
    from core.operational.timetta.connector import TimettaConnector

    out["comments"] = []
    try:
        connector = TimettaConnector.from_env()
        if connector.client is None:
            raise RuntimeError("TIMETTA_API_TOKEN не задан")
        out["comments"] = connector.read_comments(deal_guid, limit=limit)
    except (TimettaError, RuntimeError, OSError) as exc:
        add_warning(out, CODE_UNAVAILABLE, f"комментарии не прочитались: {type(exc).__name__}",
                    deal=deal_guid[-8:])
    return out


def work_note_preview(name: str) -> dict[str, Any]:
    """Превью заметки vault по slug (WORK-5) — «о чём заметка» для решения по ссылке.

    ``{name, found, title, preview}`` — заголовок + первые ~320 символов тела
    (frontmatter и хвост «## Связано» срезаны). Нужно, чтобы у link-предложения
    можно было раскрыть, что за источник и цель. Read-only, без сети/LLM.
    """
    from core.operational.work import note_preview

    return note_preview(name)


def work_meetings(days: int = 7) -> dict[str, Any]:
    """Предстоящие встречи для вкладки «Работа» — **из кэша, мгновенно** (PERF-3).

    Читает локальный снапшот ``.derived/meetings/cache.json`` (не бьёт Outlook-мост
    на рендере — раньше это был синхронный ~31с live-read). Возвращает ``meetings``
    + ``data_as_of`` + ``stale`` + ``status`` (``ok``/``unavailable``/``no_cache``);
    завершившиеся события уже отсеяны при снятии снапшота, окно фильтрует клиент.
    Нет кэша → мягкое ``no_cache`` (пусто) — пульт предложит «Обновить», НЕ live-read.
    Обновление снапшота — по расписанию (launchd) и по кнопке (``submit_job``
    ``outlook_read`` mode=meetings → :func:`core.operational.meetings.refresh`).
    """
    from core.operational.meetings import cached

    return cached(days)


def work_ticktick(days: int = 14) -> dict[str, Any]:
    """Висящие «свои» задачи TickTick (WORK-ATTN-TICKTICK) для «Требует внимания».

    Живой опрос **только curated capture-листа ``DT.Захват``** (FIX-1: скан всех
    списков убран — заваливал ленту мёртвыми личными списками 2018–2023) через
    тот же клиент, что и захват; как ``work_meetings`` для календаря — отдельный
    live-инструмент, ``work_feed`` намеренно offline и не трогается. Открытые
    задачи overdue (``dueDate`` в прошлом) / stale (без движения ``days`` дней по
    ``modifiedTime`` — незатриаженный захват). Дедуп по маркеру ``⟦tt:…⟧`` (в
    capture-листе зеркал нет — no-op). Read-only; privacy — только title/list/
    due/silent_days. Нет токена / capture-проект не сконфигурирован → ``{available:
    False, tasks: []}`` (не падает; лента показывает Timetta + почту).
    """
    from core.operational.ticktick_tasks import attention

    return attention(days=days)


def work_meeting_prep(
    subject: str,
    counterparty_domains: list[str] | None = None,
    client_ids: list[str] | None = None,
    entity_id: str | None = None,
) -> dict[str, Any]:
    """Досье к встрече (DEV-1b) — фактический контекст ПЕРЕД разговором, без модели.

    По клиенту(ам) встречи собирает из локальных зеркал: активные сделки (стадия,
    число открытых пунктов чек-листа, ближайший дедлайн, последняя активность),
    недавнюю ВНЕШНЮЮ переписку по доменам клиента (темы/даты/направление — без
    текстов) и релевантные заметки vault (``find_notes`` по различимому термину темы
    + клиент). Аргументы приходят с пульта из ``work_meetings`` (второго чтения
    календаря нет).

    Релевантность: переписка приписывается клиенту только по домену/counterparty
    встречи (без над-атрибуции); сделки со совпадением темы — вперёд, прочие в
    ``other_deals``. Резолв конкретной сущности: ``entity_id`` скоупит досье к
    сделке/проекту/хабу; неоднозначно → ``needs_clarification=True`` + ``entity_
    candidates`` (пульт спросит).

    ``{generated_at, meeting, clients:[{id,name,deals,other_deals,recent_mail,notes,
    entity?}], unresolved_domains, entities, entity_candidates, needs_clarification}``.
    Read-only, без сети/LLM; сумм/вероятностей в выдаче нет. Клиент не распознан →
    пустой ``clients`` (внутренняя встреча).
    """
    from core.operational.meeting_prep import prepare

    return prepare(
        subject=subject or "",
        counterparty_domains=counterparty_domains or [],
        client_ids=client_ids or None,
        entity_id=entity_id or None,
        find_notes=find_notes,
    )


_TAILSCALE_BINS = ("tailscale", "/Applications/Tailscale.app/Contents/MacOS/Tailscale")


def pult_web_status() -> dict[str, Any]:
    """Статус веб-пульта (PULT-WEB) для «Машинного отделения» — read-only.

    ``{server_running, port, funnel_on, public_url, launchd_loaded}``: слушает ли
    HTTP-сервер (сокет на 127.0.0.1:порт), включён ли Tailscale Funnel и его
    публичный адрес (`tailscale funnel status`), загружен ли launchd-джоб
    (`launchctl list`). macOS-специфично. ``access`` (WEBPULT-ACCESS-1) — токены без значений:
    хвосты read/rw, настроен ли rw, возраст rw-файла, срок cookie записи.

    **CONTRACT-2 С6.** Если команду выполнить не удалось (нет tailscale, таймаут,
    сбой launchctl), поле получает ``null`` — «не смог узнать», а не ``false``
    («выключено»), плюс ``warning`` с причиной. Раньше витрина уверенно показывала
    выключенным то, о чём не смогла спросить.
    """
    import os
    import socket
    import subprocess

    port = int(os.environ.get("DT_WEB_PORT") or 8787)
    running = False
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            running = True
    except OSError:
        running = False

    # CONTRACT-2 С6: «tailscale не запустился» и «funnel выключен» — РАЗНЫЕ вещи.
    # Раньше обе давали ``funnel_on: false``, и витрина уверенно врала про выключенный
    # туннель там, где просто не смогла спросить.
    funnel_on: bool | None = False
    url = None
    funnel_reason = ""
    probed = False
    for binary in _TAILSCALE_BINS:
        try:
            out = subprocess.run([binary, "funnel", "status"],  # noqa: S603 — args code-built, no shell; inputs are our own paths
                                 capture_output=True, text=True, timeout=4)
        except (OSError, subprocess.SubprocessError) as exc:
            funnel_reason = f"{binary}: {str(exc)[:80]}"
            continue
        probed = True
        text = f"{out.stdout}\n{out.stderr}"
        for line in text.splitlines():
            token = line.strip().split()[0] if line.strip() else ""
            if token.startswith("https://") and url is None:
                url = token
        funnel_on = "Funnel on" in text or url is not None
        break
    if not probed:
        funnel_on = None  # не смогли спросить — не «выключено»

    # launchd-статус — через единый service-DAO (webpult = один из сервисов
    # движка). Сбой команды → ``None`` (неизвестно), а не ``false``.
    loaded: bool | None
    launchd_reason = ""
    try:
        webpult = _core_services.service_status("server")
        loaded = webpult.get("loaded")  # type: ignore[union-attr]
        launchd_reason = str(webpult.get("reason") or "")  # type: ignore[union-attr]
    except Exception as exc:  # noqa: BLE001 — неизвестность ≠ «не загружен»
        loaded, launchd_reason = None, str(exc)[:120]

    result: dict[str, Any] = {
        "server_running": running, "port": port, "funnel_on": funnel_on,
        "public_url": url, "launchd_loaded": loaded,
    }
    result["access"] = _web_access_summary()
    if funnel_on is None or loaded is None:
        from core.contract import CODE_UNAVAILABLE, add_warning

        add_warning(
            result, CODE_UNAVAILABLE,
            "статус узнать не удалось (значение null, а не false): "
            + "; ".join(x for x in (funnel_reason, launchd_reason) if x)
            or "команда не выполнилась",
            funnel_on=funnel_on, launchd_loaded=loaded,
        )
    return result


def _web_access_summary() -> dict[str, Any]:
    """WEBPULT-ACCESS-1 п.4: токены веб-пульта БЕЗ значений - хвосты, срок и команды.

    Ссылки с токенами печатает сервер при старте и ``dt web-token show``. В ответ инструмента
    токены не кладем: ответ уходит в контекст чата хоста (а read-инструмент доступен и с
    read-токена - rw-ссылка в нем была бы повышением прав). ``rw_cookie_days`` - срок cookie
    записи при заходе по rw-ссылке.
    """
    from core.web_tokens import RW_COOKIE_DAYS, WebTokens, inspect_tokens, tail

    tokens = WebTokens()
    info = inspect_tokens()
    rw = info["rw"]
    return {
        "read_tail": tail(tokens.read()) or None,
        "rw_tail": tail(tokens.rw()) or None,
        "rw_configured": rw.configured,
        "rw_age_days": rw.age_days,
        "rw_cookie_days": RW_COOKIE_DAYS,
        "links": "dt web-token show read|rw (ссылка с токеном печатается локально)",
        "rotate": "dt web-token rotate read|rw",
    }


def pult_web_restart() -> dict[str, Any]:
    """Перезапустить веб-пульт через launchd (`launchctl kickstart -k`). Действие.

    Свёрнуто под единый service-DAO (``pult_service_control("webpult",
    "restart")`` — тот же ``kickstart -k``), контракт не изменился. Требует
    установленного launchd-джоба (`bash ops/install_launchd.sh`). Возврат
    ``{ok, error?}``. С телефона: связь на пару секунд прервётся — после
    перезапуска просто обнови страницу.
    """
    result = _core_services.service_control("server", "restart")
    # WEBPULT-ACCESS-1: свой аудит (WRITE_TOOLS); ``service_control`` пишет и общую строку действия.
    _core_pult.record_action("pult_web_restart", {}, "ok" if result.get("ok") else "failed")
    if result.get("ok"):
        return {"ok": True}
    return {"ok": False,
            "error": (result.get("error") or "не удалось — джоб установлен? "
                      "`bash ops/install_launchd.sh`")}


def _queue_env() -> Any:
    """Окружение видов очереди: боевые пути + проба «сегодняшней выдачи» (она живет в этом слое)."""
    from core.decisions import QueueEnv

    return QueueEnv(golden_probe=_golden_probe)


def pult_cards(
    kinds: list[str] | None = None, limit: int = 50, refresh: bool = False
) -> dict[str, Any]:
    """Очередь решений ОДНИМ вызовом: карточки всех видов единой формы (QUEUE-SERVER-1).

    ``{cards, totals: {вид: ждут}, errors: {вид: код}, as_of}``. Виды (``kinds=None`` - все):
    ``assignment`` (поручение администратору CRM), ``untriaged`` (захват без тега), ``hub``
    (кандидат в хабы; от сделки Timetta - с ``meta.deal``/``similar_hubs``), ``alias`` (алиасы
    хаба), ``gold`` (кандидат в золотой набор eval), ``reattr`` (переатрибуция), ``link``
    (ссылка), ``ripe_lead`` (дозревший лид), ``lint`` (находка линта). Карточка:
    ``{id: "<вид>:<id>", kind, title, reason, since, meta, actions: [{action, label, style:
    primary|secondary|danger, params: {имя: {type: select|multiselect|text, options?, default?,
    required?}}, confirm?, more?}], explainable}``;
    кнопки рисуются из ``actions``. ``limit`` - карточек НА ВИД (``<=0`` - все); ``totals`` -
    сколько ждут на самом деле. Сбой одного вида - в ``errors`` (``store_unavailable``/…),
    остальные отдаются: «ошибка ≠ пусто». ``gold`` на чтении НЕ считается никогда (PULT-SURFACE-2:
    реранкер = секунды внутри read-вызова): отдается последний расчет (``as_of_kinds.gold``), его
    обновляет шаг ``eval`` ночной цепочки; ``refresh=True`` (кнопка) пересчитывает ТОЛЬКО ``gold``
    сейчас. ``timings`` - ``{вид: мс}``. Read-only.
    Решение - :func:`pult_card_decide`, «почему» - :func:`pult_card_explain`.
    """
    from core.decisions import queue
    from core.surface import manifest

    off: dict[str, str] = {}
    if kinds is not None:  # PERSONAL-3: виды роли - из манифеста; чужих видов у экземпляра нет
        allowed = set(manifest.card_kinds())
        # DEV-3-CORE: вид выключенного коннектора - в errors (остальные виды живут)
        off = {k: "connector_disabled" for k in kinds
               if k in manifest.surface().card_kinds and manifest.blocked("card_kind", k)}
        kinds = [k for k in kinds if k in allowed]
        if not kinds:  # запрошены только чужие виды: пустой список queue понял бы как «все»
            return {"cards": [], "totals": {}, "errors": off, "as_of_kinds": {}, "timings": {}}
    result = queue(_queue_env(), kinds=kinds, limit=limit, refresh=refresh)
    if off:
        result["errors"] = {**result.get("errors", {}), **off}
    return result


def pult_card_decide(
    card_id: str, action: str, params: dict[str, Any] | None = None
) -> dict[str, Any]:
    """Решение по карточке очереди: ``card_id`` (``<вид>:<id>``) + ``action`` из ``card.actions``.

    Исход одной формы: ``{ok, outcome: applied|rejected|snoozed|routed|stale|refused, code?,
    detail, effects: [...], card_id, kind, action}``; ``effects`` - что сделано («хаб создан
    <путь>», «timetta_id записан»). ``stale`` - уже решено (не ошибка), ``refused`` - ничего не
    записано (``code``: ``unknown_card`` | ``bad_action`` | ``invalid_params`` | ``no_deal`` |
    ...). ``params`` - из ``card.actions[].params`` (``entity``, ``hub_id``, ``deal_guid``,
    ``lane``, ``aliases``, ``expected_ids``, ``days``). Звонит в готовое ядро вида: ядра решений
    не менялись. Хаб не создается и ``timetta_id`` не пишется иначе как этим действием человека.
    Аудит ОДИН раз: строка ``pult-actions.log`` (вид, id, действие, исход, хост/поверхность -
    без текста карточки) и событие метрик ``queue_decision``.
    """
    from core.decisions import decide

    return decide(card_id, action, params, env=_queue_env())


def pult_card_explain(card_id: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
    """«Почему предложено» по карточке очереди: ``{ok, card_id, kind, why}`` (read-only).

    ``why`` зависит от вида: ``link`` - превью источника/цели + фрагмент-доказательство и score;
    ``reattr`` - что переехало и куда перевесим; ``hub`` - сигналы/источники, сделка Timetta и
    похожие хабы; ``alias`` - варианты с источниками и конфликтами; ``assignment`` - ТОЛЬКО с
    ``params={"deal_guid": …}``: ``{draft: {deal, subject, body, mailto, formulation, due, …}}`` -
    черновик поручения, пересобранный под выбранную сделку орбиты (замена прежнего
    ``pult_assignments(capture_id, deal_guid)``); остальные виды - ``null``.
    Нет карточки - ``{ok: false, refused: true, code: "unknown_card"}``.
    """
    from core.decisions import explain

    return explain(card_id, env=_queue_env(), params=params)


def _golden_probe(tool: str, args: dict[str, Any]) -> list[str]:
    """«Сегодняшняя выдача» для ранга кандидата: тот же поиск, что сделал К. (EVAL-2 п.3).

    Зовёт НЕОБЁРНУТЫЕ функции модуля — проба не попадает ни в журнал запросов, ни в метрики
    (иначе пересчёт очереди плодил бы «запросы» из собственных проб)."""
    from core.eval import _observe

    fn = globals().get(tool)
    if tool not in ("find_notes", "find_latest", "retrieve") or not callable(fn):
        return []
    call = dict(args)
    if tool == "find_notes":
        call["limit"] = 20  # ранг глубже дефолтной выдачи (8): «был 12-м» ≠ «нет в выдаче»
    return _observe(tool, fn(**call)).ids


def pult_eval(points: int = 14) -> dict[str, Any]:
    """Качество выдачи для плитки пульта (EVAL-3): сводка из истории прогонов золотого набора.

    Read-only, из ``.derived/eval/history.jsonl`` (пишут ``dt_eval``, смоук С-10 и ночной шаг
    ``eval`` цепочки index; нового прогона и поиска тут нет, < 50 мс). ``{last: {ts, metrics,
    groups, stale, verified, hypotheses, age_days}, prev: {ts, metrics}, delta: {recall5, hub3,
    mrr}, delta_basis, red, red_text, history: [{ts, recall5, hub3, mrr, control_recall5}]
    (последние ``points``), rerank: {enabled, semantic_always, last_run: {rerank,
    semantic_always} | null} (RETR-RERANK-1: конфигурация выдачи сейчас и у последнего прогона),
    misses: [{id, type, label, group, top[:3]}] (промахи последнего
    прогона: не попали и не stale; формулировка — из канона), by_type: [{type, n, metrics,
    delta, delta_known}] (EVAL-4: срез последнего прогона по типам запросов; Δ к прошлому прогону
    только при том же составе типа; диагностика, на ``red`` не влияет), stale_ids,
    candidates_pending, canon_age_days, outdated, generation}``. MODEL-1: ``generation: {hosts:
    {<host>: {last_ts, model, tasks_ok, tasks_total, matched, score, history[{ts, score}]}}}`` -
    золотые задачи ГЕНЕРАЦИИ по хостам (вторая строка виджета, из
    ``.derived/eval/generation.jsonl``; ручных прогонов нет - ``hosts: {}``). Дельты и «устарело»
    (> 2 дн) считает выдача, не фронт. Пустая
    история → ``{last: null}`` + конверт ``no_runs``; канон не прочитался → ``store_unavailable``.
    """
    from core.eval_status import eval_status

    return eval_status(points)


def pult_create_hub(
    name: str, entity: str = "client", status: str = "active", track: str | None = None
) -> dict[str, Any]:
    """Завести хаб сущности из пульта одной кнопкой (Слой 1 — детерминированно).

    Обёртка над той же scaffold-механикой, что approve карточки ``hub`` (``pult_card_decide``),
    но по произвольному имени (а не кандидату детектора): правильный frontmatter
    ``type: hub`` + ``entity`` (client | product | project | direction |
    industry) + ``status`` (``presale`` для пресейла) + ``aliases: [name]``.
    Для lead-хабов (project/deal) проставляется явный ``track: presale|internal``
    (TRACK-1): ``track`` можно задать явно, иначе presale-пресет → ``presale``,
    прочие lead-хабы → ``internal`` (детектор «дозревших» классифицирует полем).
    Идемпотентно (существующий файл не перезаписывается). Возвращает
    ``{hub_id, path, created, entity, status, reindex_hint}``; чтобы хаб увидела
    линковка/ретривал — нужен прогон ``index`` (кнопка «index сейчас»).
    """
    from core.config import default_vault_path
    from core.legacy.linking import scaffold_hub
    from core.linking.hub_candidates import HUB_ENTITIES

    ent = (entity or "client").strip()
    if ent not in HUB_ENTITIES:
        raise ValueError(f"unsupported entity {ent!r}; use {' | '.join(HUB_ENTITIES)}")
    name = (name or "").strip()
    if not name:
        raise ValueError("name is required")
    vault = default_vault_path()
    path, created = scaffold_hub(
        vault, name, entity=ent, status=(status or "active").strip(), track=track
    )
    # SEC-6 audit: hub id (identifier) + entity/status + created flag — not raw name.
    _core_pult.record_action(
        "pult_create_hub",
        {"hub_id": path.stem, "entity": ent, "status": (status or "active").strip(),
         "created": bool(created)},
        outcome="created" if created else "exists",
    )
    return {
        "hub_id": path.stem,  # scaffold_hub уже назвал файл <entity>-<slug>.md
        "path": str(path.relative_to(vault)),
        "created": created,
        "entity": ent,
        "status": (status or "active").strip(),
        "reindex_hint": (
            "запусти index-sync, чтобы хаб попал в линковку/ретривал" if created else ""
        ),
    }


def pult_hub_add_note(note_path: str, text: str) -> dict[str, Any]:
    """Дописать строку-ссылку в заметку хаба (Слой 1: «Задача + в существующий
    хаб»). Добавляет ``- <дата> — <text>`` под секцию ``## Связанное`` (создаёт,
    если нет). Containment-guard (только внутрь vault), идемпотентно (точная
    строка не дублируется). Возвращает ``{added, path, line}``.
    """
    from core.config import default_vault_path
    from core.operational.hub_notes import append_reference

    r = append_reference(note_path, text, vault_path=default_vault_path())
    # SEC-6 audit: path + added flag + text length — never the appended line text.
    _core_pult.record_action(
        "pult_hub_add_note",
        {"path": str(r.get("path") or note_path), "added": bool(r.get("added")),
         "text_len": len(text or "")},
        outcome="added" if r.get("added") else "noop",
    )
    return r


def hub_synth_context(hub_id: str, since: str | None = None) -> dict[str, Any]:
    """Досье «Состояние хаба клиента»: что нового с ``since`` (ГГГГ-ММ-ДД; иначе ``synth_at``
    хаба, иначе 90 дн.). Read-only, без модели (HUB-SYNTH-1).

    ``{hub, since, delta{deals,mail,outputs,notes,files,facts}, locators, prompt, limits}``: у
    каждого элемента локатор (note_id / путь / ``deal:<код>`` / ``conv:…``), NDA нет. ``prompt`` -
    задание модели сессии: секция «## Состояние (на ДД.ММ.ГГГГ)», 5-12 пунктов с [локатором],
    «Не покрыто: …». Покажи текст К., по его слову - ``hub_synth_propose``. Отказ -
    ``{ok: false, refused: true, code}`` (``hub_not_found``, ``unsupported_entity``).
    """
    from core.operational import hub_synth

    try:
        return hub_synth.context(hub_id, since)
    except hub_synth.SynthError as exc:
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc)}


def hub_synth_propose(
    hub_id: str,
    text: str,
    sources: list[str] | None = None,
    covered_until: str | None = None,
    since: str | None = None,
) -> dict[str, Any]:
    """Поставить написанную сессией секцию «Состояние» карточкой на решение К. (HUB-SYNTH-1).

    Проверки до очереди: у КАЖДОГО пункта локатор в [скобках], все локаторы ⊆ ``hub_synth_context``
    (иначе ``ungrounded`` с номерами пунктов), ``sources`` ⊆ локаторов (``bad_sources``), длина
    <= ``DT_SYNTH_MAX_CHARS`` (``too_long``), нет путей из NDA (``privacy``), стоп после отказа по
    хабу (``snoozed``); ИИ-маркеры - предупреждение ``style_markers``. ``covered_until`` - дата
    данных (ГГГГ-ММ-ДД, по умолчанию сегодня), ``since`` - как в досье. В хаб НИЧЕГО не пишется:
    запись - только approve карточки ``synth`` в пульте (``pult_card_decide`` по явному слову К.).
    Возвращает ``{ok, card_id, items, sources, diff, uncovered}``; отказ - ``{ok: false, refused:
    true, code, error, ...}``.
    """
    from core.operational import hub_synth

    try:
        res = hub_synth.propose(hub_id, text, sources, covered_until, since=since)
    except hub_synth.SynthError as exc:
        _core_pult.record_action(
            "hub_synth_propose", {"hub_id": str(hub_id)[:80], "text_len": len(text or "")},
            f"refused:{exc.code}")
        return {"ok": False, "refused": True, "code": exc.code, "error": str(exc), **exc.extra}
    _core_pult.record_action(
        "hub_synth_propose",
        {"hub_id": res["hub_id"], "card": res["card_id"], "items": res["items"],
         "sources": res["sources"], "text_len": len(text or "")}, "ok")
    return res


def pult_ripe_leads() -> dict[str, Any]:
    """«Дозревшие лиды» — vault-хабы без пары в Timetta, готовые стать сделкой.

    Read-only, без сети (LEAD-2): хабы ``entity ∈ {project, deal}`` с пустым
    ``timetta_id`` + сигналы зрелости (заметки в папке, свежесть, дедлайн,
    ``presale``). ``leads`` отсортирован ripe-first, без снуженных. Промоут в
    Timetta заводит администратор CRM (карточка «поручить» - вид ``assignment`` у
    :func:`pult_cards`); здесь только сигнал.
    """
    from core.operational.ripe_leads import ripe_leads

    return ripe_leads()


def pult_deals(
    client: str | None = None, rings: str | None = None, refresh: bool = False
) -> list[dict[str, Any]]:
    """Сделки локального зеркала Timetta для пикера «связать с CRM» (HUB-DEAL-LINK).

    Read-only, **без сети** (Path B, из ``.derived/timetta/``): каждая строка
    ``{guid, code, name, stage, client, linked_hub}`` — где ``stage`` = стадия
    сделки, ``client`` = имя организации, ``linked_hub`` = id хаба, если чей-то
    frontmatter уже указывает ``timetta_id`` на эту сделку (иначе ``null``).
    Суммы/вероятность в выдачу НЕ попадают (коммерческая тайна). ``client`` (если
    задан) — подстрочный фильтр по имени/коду организации. Свободные сделки идут
    раньше связанных, затем по свежести. Связать — :func:`pult_hub_link_deal`.

    **Кольца (ORBIT-2).** ``rings`` — ``"mine"`` | ``"mine,unit"`` | ``"mine,unit,group"``
    (``None`` = ``mine``, прежний пикер); пересекается с ``DT_ORBIT_RINGS``. У сделки не из
    кольца ``mine`` в строке есть ``ring``/``leader``/``unit`` — бейдж ведущего. Неизвестное
    кольцо → ``ValueError`` (``bad_rings``).

    **Из снимка (PULT-SURFACE-2).** Обход vault за ``linked_hub`` стоит ~5 с, поэтому выдача
    берется из снимка не старше ``DT_PULT_DEALS_TTL_S`` (300 с); он протухает раньше, если
    обновилось зеркало Timetta или связали/развязали хаб; ``refresh=True`` считает сейчас. Форма
    ответа (список) прежняя - ``as_of``/``cached`` лежат только в самом снимке.
    """
    from core.operational.hub_link import deals_for_picker_cached

    rows, _meta = deals_for_picker_cached(client=client, rings=rings, refresh=bool(refresh))
    return rows


def pult_function(rings: str | None = None, limit: int = 50) -> dict[str, Any]:
    """Виджет «Функция» (ORBIT-3): надзор над сделками ВСЕХ колец — read-only, без сети, без сумм.

    ``{now, rings, counts{deals, by_ring, watched}, funnel[], leaders[], idle{}, no_legal_entity{},
    recent{total, items[], summary}}``: ``funnel`` — стадии × кольцо (``mine``/``unit``/``group``) ×
    ведущий; ``idle`` — «давно без движения» (порог ``threshold_days``, тот же, что у «Забытых тем»)
    по всем кольцам; ``no_legal_entity`` — сделки с пустым юрлицом; ``recent`` — последние изменения
    коллег (автор + суть: стадия/поля/чек-лист, ``source``: ``history``|``snapshot``; без значений
    полей и текстов комментариев), ``limit`` строк, свежие первыми.

    ``rings`` — ``"mine"`` | ``"mine,unit"`` | ``"mine,unit,group"`` (``None`` = ВСЕ включённые
    в ``DT_ORBIT_RINGS``: надзор шире «моего»); пересекается с ``DT_ORBIT_RINGS``. Неизвестное
    кольцо → ``{ok:false, refused, code:"bad_rings"}``. Битое зеркало → пустые срезы + конверт
    ``store_unavailable``.
    """
    from core.contract import CODE_BAD_RINGS, add_warning
    from core.operational.function_view import function_view
    from core.operational.orbit import OrbitError

    try:
        return function_view(rings=rings, limit=limit)
    except OrbitError as exc:
        return add_warning(
            {"ok": False, "refused": True, "code": exc.code, "error": str(exc)},
            CODE_BAD_RINGS, str(exc), requested=rings,
        )


def pult_watch(deal_guid: str = "", action: str = "add") -> dict[str, Any]:
    """«Следить» за сделкой кольца 2/3 (ORBIT-3): ручной watchlist, БЕЗ права записи.

    ``action``: ``add`` | ``remove`` | ``list``. Наблюдаемая сделка — как кольцо 1 для ВНИМАНИЯ
    (лента «Работа», дайджест), но её реальное кольцо не меняется. Список лежит в
    ``watchlist.json`` (персистентно); сделка, исчезнувшая в Timetta, снимается сверкой.
    Только локальная запись — в Timetta/TickTick ничего не пишется. Аудит — ``record_action``.

    Ответ ``{ok, changed, deal, ring}``; отказ — конверт: ``item_not_found`` (нет в зеркале),
    ``deal_deleted`` (удалена в Timetta), ``skipped`` (сделка уже «моя»). ``list`` → ``{ok, items[
    {guid, code, name, ring, leader}]}``. Повтор идемпотентен.
    """
    from core.config import timetta_mirror_path, timetta_user_id
    from core.operational import orbit, watchlist
    from core.operational.pult import record_action
    from core.operational.timetta.mirror import MirrorStore

    store = MirrorStore(timetta_mirror_path())
    act = (action or "add").strip().lower()
    if act == "list":
        items = []
        for gid in watchlist.load_ids():
            d = orbit.find(store, gid) or {}
            items.append({"guid": gid, "code": d.get("code"), "name": d.get("name"),
                          "ring": orbit.ring(d) if d else None, "leader": d.get("manager_name"),
                          "deleted": orbit.is_deleted(d) if d else None})
        return {"ok": True, "items": items}
    if act not in ("add", "remove"):
        from core.contract import CODE_SKIPPED, add_warning

        bad = {"ok": False, "refused": True, "error": f"action: add|remove|list, не {action!r}"}
        return add_warning(bad, CODE_SKIPPED, "неизвестное действие")
    me = timetta_user_id()
    if act == "add":
        out = watchlist.watch(store, deal_guid, me=me)
    else:
        out = watchlist.unwatch(store, deal_guid, me=me)
    record_action(
        "pult_watch", {"deal": str(out.get("deal") or deal_guid)[-8:], "op": act},
        "changed" if out.get("changed") else ("refused" if not out.get("ok") else "noop"),
    )
    return out


def pult_hub_link_deal(hub_id: str, deal_guid: str) -> dict[str, Any]:
    """Связать vault-хаб ``hub_id`` с СУЩЕСТВУЮЩЕЙ сделкой ``deal_guid`` Timetta.

    Запись **только в vault** (HUB-DEAL-LINK): валидирует ``deal_guid`` в зеркале
    (иначе отказ), хирургически пишет ``timetta_id: <deal_guid>`` во frontmatter
    хаба (остальное байт-в-байт; это и есть якорь vault→Guid). В Timetta
    **ничего не пишет** — ни одной сетевой операции. Идемпотентно (повтор → тот же
    результат). Операционный контекст хаба подтянется сам по свежему ``timetta_id``.
    Возвращает ``{ok, hub_id, deal:{code,name}, timetta_id, changed, path}``; отказ
    (нет guid/хаба, путь вне vault) → ``{ok:false, refused, error}``. Аудит —
    ``record_action``.
    """
    from core.operational.hub_link import HubLinkError, link_hub_to_deal

    try:
        return link_hub_to_deal(hub_id, deal_guid)
    except HubLinkError as exc:
        return {"ok": False, "refused": True, "error": str(exc)}


def pult_hub_unlink_deal(hub_id: str) -> dict[str, Any]:
    """Снять связь хаба ``hub_id`` со сделкой Timetta (обратная к link; только vault).

    Обнуляет ``timetta_id`` во frontmatter хаба
    (хаб снова считается «дозревшим лидом»). В Timetta ничего не пишет.
    Идемпотентно. Возвращает ``{ok, hub_id, changed, previous}``; отказ → ``{ok:
    false, refused, error}``. Аудит — ``record_action``.
    """
    from core.operational.hub_link import HubLinkError, unlink_hub_from_deal

    try:
        return unlink_hub_from_deal(hub_id)
    except HubLinkError as exc:
        return {"ok": False, "refused": True, "error": str(exc)}


def pult_set_track(hub_id: str, track: str) -> dict[str, Any]:
    """Сменить трек vault-хаба ``hub_id`` → ``track`` ∈ ``{presale, project, internal}`` (TRACK-2).

    Запись **только в vault**: хирургически пишет ``track:`` во frontmatter хаба
    (остальное байт-в-байт), идемпотентно. Меняет классификацию карточки в
    «Дозрели для Timetta» (:func:`pult_ripe_leads`) — поле читается с приоритетом
    над эвристикой ``presale``. В Timetta/CRM ничего не пишет; обратимо (повтор с
    другим треком возвращает как было). Возвращает ``{ok, hub_id, track, previous,
    changed, path}``; отказ (невалидный ``track`` / нет хаба / путь вне vault) →
    ``{ok:false, refused, error}``. Аудит — ``record_action`` (id+track, без контента).
    """
    from core.operational.hub_link import HubLinkError, set_track

    try:
        return set_track(hub_id, track)
    except HubLinkError as exc:
        return {"ok": False, "refused": True, "error": str(exc)}


# --------------------------------------------------------------------------- #
# FT-3 (наша часть) — fail-fast по размеру параметра + видимость зоны риска     #
# --------------------------------------------------------------------------- #
# Инцидент 04.08.2026 (ФТ п. 1.2): ``store_file`` с ~29 КБ base64 положил мост на
# 4 минуты — вместе с непричастным MacOS-MCP. Причина — отсутствие ИЗОЛЯЦИИ
# серверов и таймаута вызова в мосте MCP-хоста, то есть уровень поставщика
# (вопрос 5 ФТ): наш процесс мог вообще не получить сообщение. Поэтому граница
# честная и узкая:
#
#   * НАШЕ — fail-fast и диагностика для всего, что ДО нас дошло: гигантский
#     параметр отклоняется мгновенно (вместо минут обработки), а вход в зону
#     риска и медленные вызовы видны в логе — материал для вопроса поставщику;
#   * НЕ НАШЕ — изоляция серверов и таймаут в мосте; MacOS-MCP (там уже стоит
#     хотфикс таймаут+killpg).
#
# Обвязка ставится ОДНИМ местом — в :func:`build_server` при регистрации, не
# копипастой в 70 инструментов. Под лимитом поведение байт-идентично: модульные
# функции-инструменты не меняются вовсе (тесты зовут их напрямую и остаются
# зелёными без правок), обёртка лишь считает размер и делегирует.
_PARAM_LIMIT_ENV = "DT_MCP_PARAM_LIMIT"
_PARAM_WARN_ENV = "DT_MCP_PARAM_WARN"
_SLOW_WARN_ENV = "DT_MCP_SLOW_WARN_S"

# Потолок «от абсурда»: 10 МБ строковых аргументов — заведомо больше любого
# легитимного deliverable (``store_file`` сам режет на 25 МБ ПОСЛЕ декода base64),
# но меньше того, на что стоит тратить минуты генерации/обработки.
DEFAULT_MCP_PARAM_LIMIT = 10 * 1024 * 1024
# Порог диагностики: эмпирическая зона отказов моста — 29–39 КБ полезной нагрузки
# (инцидент). 32 КБ — вход в эту зону: дальше отказ вероятен, и это надо видеть.
DEFAULT_MCP_PARAM_WARN = 32 * 1024
# Медленный вызов: 30 с — тот же дефолт, что ФТ-3 просит у таймаута моста.
DEFAULT_MCP_SLOW_WARN_S = 30.0

# Глубина обхода вложенных аргументов (dict/list в параметрах вроде ``proposal``/
# ``file_refs``). Ограничена, чтобы подсчёт размера сам не стал стоимостью.
_MAX_ARG_DEPTH = 6

# Единый логгер (CODE-5-1): человекочитаемая строка, скраб секретов и corr_id —
# если процесс уже настроен через ``setup_logging``. Сам сервер логирование НЕ
# настраивает: под MCP-хостом stderr сервера уходит в его MCP-лог (там и
# диагностируют инцидент моста), а писать MCP-строки в ``dt-sync.log`` значило бы
# менять то, что читает пульт. В строках только имя инструмента, размеры и
# длительность — **контента аргументов нет никогда**.
_logger = logging.getLogger("dt.mcp")


def _env_positive(name: str, default: float, *, integer: bool) -> float:
    """``name`` из окружения как положительное число, иначе ``default`` (best-effort)."""
    raw = os.environ.get(name, "")
    try:
        value = float(str(raw).strip())
    except (TypeError, ValueError):
        return default
    if value <= 0:
        return default
    return float(int(value)) if integer else value


def _arg_bytes(value: Any, depth: int = 0) -> int:
    """Размер строковых/байтовых аргументов вызова в БАЙТАХ (UTF-8), рекурсивно.

    Байты, а не символы: через мост едет именно закодированный текст, и ФТ говорит
    о размере полезной нагрузки. Числа/флаги/None не считаются — они не могут
    положить канал. Вложенность (``proposal``-dict, ``file_refs``-list) обходится
    до :data:`_MAX_ARG_DEPTH`, дальше не спускаемся (подсчёт не должен стать ценой).
    """
    if isinstance(value, str):
        return len(value.encode("utf-8", errors="ignore"))
    if isinstance(value, (bytes, bytearray, memoryview)):
        return len(bytes(value))
    if depth >= _MAX_ARG_DEPTH:
        return 0
    if isinstance(value, Mapping):
        return sum(
            _arg_bytes(k, depth + 1) + _arg_bytes(v, depth + 1) for k, v in value.items()
        )
    if isinstance(value, (list, tuple, set, frozenset)):
        return sum(_arg_bytes(item, depth + 1) for item in value)
    return 0


def _degradation_code(raw: Any) -> str:
    """Код деградации в машинном виде для журнала (см. :data:`_CODE_RE`)."""
    code = str(raw or "").strip().lower()
    return code if _CODE_RE.match(code) else "other"


def degradation_codes(payload: Any) -> list[str]:
    """Коды деградации в ответе инструмента (порядок сохранён, без повторов).

    Четыре машинных признака (см. :data:`DEGRADATION_EXEMPT`): конверты CONTRACT-2,
    ``refused``, ``ok: false`` + ``code``, ``found: false`` + ``code``. Один ответ
    может нести несколько причин — считаем каждую по разу: две одинаковые ветки в
    одном ответе это один спотык, а «не поднялся источник» + «фильтр не применился» —
    два разных, и складывать их в один счётчик значило бы прятать одну за другой.
    """
    if not isinstance(payload, Mapping):
        return []
    from core.contract import warnings_of

    codes: list[str] = []

    def _add(raw: Any) -> None:
        code = _degradation_code(raw)
        if code not in codes:
            codes.append(code)

    for envelope in warnings_of(payload):
        _add(envelope.get("code"))
    refused = payload.get("refused")
    if refused:
        _add(payload.get("code") or (refused if isinstance(refused, str) else "refused"))
    if payload.get("ok") is False or payload.get("found") is False:
        code = payload.get("code")
        # Безымянный отказ (доконтрактная ветка ``ok:false`` без ``code``) считаем как
        # ``other`` — чтобы он был виден и получил свой код при следующем касании, а не
        # растворился. Но только если причину ещё не назвали выше: ``ok:false`` рядом с
        # конвертом/``refused`` — это тот же один отказ, а не второй безымянный.
        if code or not codes:
            _add(code)
    return codes


def _record_degradation(tool: str, payload: Any) -> None:
    """Отказ/деградация ответа → счётчик (privacy: ТОЛЬКО имя инструмента и код).

    Best-effort поверх best-effort: ``record_event`` уже глотает свои сбои, но и
    сама инспекция ответа не имеет права уронить вызов, который УЖЕ отработал.
    Аргументы, тексты, пути и контекст конверта в журнал не попадают — считаем
    «где спотыкаются», а не «на чём именно», и телеметрия не становится теневой
    копией переписки.
    """
    try:
        from core.metrics import DEGRADATION_KIND, record_event

        for code in degradation_codes(payload):
            if (tool, code) in DEGRADATION_EXEMPT:
                continue
            record_event(DEGRADATION_KIND, tool=tool, code=code)
    except Exception:  # noqa: BLE001, S110 — телеметрия никогда не ломает вызов
        pass


def _drop_call_detail() -> None:
    try:
        from core.metrics import take_call_detail

        take_call_detail()
    except Exception:  # noqa: BLE001, S110 — телеметрия никогда не ломает вызов
        pass


def _record_tool_call(tool: str, ok: bool, ms: float) -> None:
    """WAVE1-MEASURE п.2 (аудит A1): вызов → ``tool_call {tool, ok, ms, host, surface}``.

    ОДНА точка на все ~85 инструментов (и на открытия вкладок/секций пульта под именем
    ``ui:…``): без неё нельзя сказать, какая поверхность употребляется, — решения волны 3
    (что убирать/сворачивать) принимались бы догадкой. Privacy: ТОЛЬКО имя, исход и
    длительность — ни аргументов, ни ответа. Best-effort, как весь журнал метрик.
    VENDOR-HYGIENE-1 п.3: ``host`` (имя из handshake) и ``surface`` (``mcp`` | ``webpult`` |
    ``cli``) — решения «что убирать» принимаются по хостам, а не вслепую.
    """
    try:
        from core.host import current_host, request_fields
        from core.metrics import TOOL_CALL_KIND, record_event, take_call_detail

        h = current_host()
        # RETR-RERANK-1: инструмент мог доложить rerank_ms/pool/device — в тот же detail.
        # WEBPULT-ACCESS-1 п.3: вызов с веб-пульта - + auth (read|write), хвост токена, peer.
        record_event(TOOL_CALL_KIND, tool=tool, ok=bool(ok), ms=round(ms),
                     host=h["name"], surface=h["surface"], **take_call_detail(),
                     **request_fields())
    except Exception:  # noqa: BLE001, S110 — телеметрия никогда не ломает вызов
        pass


def _capture_host() -> None:
    """VENDOR-HYGIENE-1 п.1: снять ``clientInfo`` handshake — один раз на процесс.

    Инструменты — плоские функции без ``Context``, поэтому хост берется из контекста запроса
    SDK (``request_ctx`` → ``session.client_params.clientInfo``) здесь, в единственной обертке.
    Кэш — ``core.host``; пока хост не снят (нет контекста запроса, клиент не прислал
    ``clientInfo``) — остается ``unknown``. Веб-пульт/CLI хост не меняют. Best-effort.
    """
    try:
        from core.host import adopt_client_info, needs_handshake

        if not needs_handshake():
            return
        from mcp.server.lowlevel.server import request_ctx

        params = request_ctx.get().session.client_params
        info = getattr(params, "clientInfo", None)
        if info is None:
            return
        extra = getattr(info, "model_extra", None) or {}
        adopt_client_info(info.name, info.version, extra.get("model", ""))
    except Exception:  # noqa: BLE001, S110 — хост не обязателен для вызова
        pass


def _result_ok(result: Any) -> bool:
    """Исход вызова для телеметрии: явный отказ ``{ok: false}`` — не успех (исключение — тоже)."""
    return not (isinstance(result, dict) and result.get("ok") is False)


def _record_thread_read(
    tool: str, args: tuple[Any, ...], kwargs: dict[str, Any], result: Any
) -> None:
    """OUT-COMPLETE-1: касание почтового треда → событие ``thread_read`` (ОДНА точка).

    ``read_note`` / ``work_note_preview`` / ``lift_source`` по заметке ``email-thread``
    оставляют ``{tool, note_id, shown_full, total, last_inbound_read}`` — по ним
    ``save_output`` сводит, прочитано ли последнее входящее источников-тредов. Privacy:
    индексы и счётчики, без адресов/тем/текстов. Best-effort: телеметрия не ломает вызов.
    """
    try:
        from core.metrics import record_event
        from core.thread_coverage import THREAD_READ_KIND, thread_read_event

        fields = thread_read_event(tool, args, kwargs, result)
        if fields is not None:
            record_event(THREAD_READ_KIND, **fields)
    except Exception:  # noqa: BLE001, S110 — телеметрия никогда не ломает вызов
        pass


def _record_query_log(
    fn: Callable[..., Any], tool: str, args: tuple[Any, ...], kwargs: dict[str, Any],
    result: Any, ms: float,
) -> None:
    """EVAL-2 п.2: поиск/открытие заметки → локальный журнал запросов (ОДНА точка).

    ``find_notes``/``find_latest``/``retrieve`` → ``search`` (аргументы поиска + топ-5 id),
    ``read_note``/``lift_source``/``work_note_preview`` → ``open`` (id заметки), ``get_facts`` →
    ``open`` (пути источников фактов; PROV-SESSION-1: + ``sid`` сессии). Это НЕ журнал
    метрик: ``metrics.jsonl`` остаётся без аргументов (privacy-контракт), тексты запросов
    живут в отдельном файле ``.derived/eval/queries.jsonl`` (``core.eval_journal``,
    выключатель ``DT_EVAL_QUERY_LOG=0``, ретенция 90 дн). Best-effort, как соседние точки.
    """
    try:
        from core.eval_journal import FACTS_TOOLS, OPEN_TOOLS, SEARCH_TOOLS, record_call

        if tool not in SEARCH_TOOLS and tool not in OPEN_TOOLS and tool not in FACTS_TOOLS:
            return
        bound = dict(inspect.signature(fn).bind_partial(*args, **kwargs).arguments)
        record_call(tool, bound, result, ms)
    except Exception:  # noqa: BLE001, S110 — журнал никогда не ломает вызов
        pass


def guarded_tool(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Обернуть инструмент лимитом размера параметров + диагностикой (FT-3).

    Три вещи, все прозрачные для контракта инструмента:

    * **лимит** — суммарный размер строковых аргументов > ``DT_MCP_PARAM_LIMIT``
      (дефолт 10 МБ) → немедленный ``{ok:false, refused:"param_limit", error:
      "<размер> > <лимит> …"}``; инструмент **не вызывается вовсе** (молчаливое
      зависание на гигантском параметре недопустимо — требование ФТ-3);
    * **зона риска** — размер > ``DT_MCP_PARAM_WARN`` (дефолт 32 КБ) → warning
      ДО вызова: если мост/инструмент повиснет, строка уже в логе (пост-фактум
      её бы не было — ровно то, что случилось 04.08);
    * **итог** — по завершении warning с длительностью, если параметр был крупным
      ИЛИ вызов оказался медленнее ``DT_MCP_SLOW_WARN_S`` (дефолт 30 с).

    Плюс FAIL-TELEMETRY-1: ответ с машинным признаком отказа (:func:`degradation_codes`)
    оставляет счётчик ``tool_degradation`` — «где агенты спотыкаются» видно в doctor,
    а не только тому, кто словил отказ в своём сеансе. В журнал уходят ТОЛЬКО имя
    инструмента и код.

    Сигнатура и docstring сохраняются (``functools.wraps``), поэтому схема
    инструмента, которую FastMCP строит по сигнатуре, не меняется. Исключения
    инструмента проходят наружу как были.
    """

    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        tool = getattr(fn, "__name__", "?")
        _capture_host()
        _drop_call_detail()  # поля прямого вызова (eval/CLI) не попадают в чужой tool_call
        size = _arg_bytes(args) + _arg_bytes(kwargs)
        limit = int(_env_positive(_PARAM_LIMIT_ENV, DEFAULT_MCP_PARAM_LIMIT, integer=True))
        if size > limit:
            _logger.warning(
                "param_limit: tool=%s bytes=%d limit=%d — вызов отклонён без запуска "
                "инструмента (env %s)", tool, size, limit, _PARAM_LIMIT_ENV,
            )
            refusal = {
                "ok": False,
                "refused": "param_limit",
                "error": (
                    f"{size} > {limit} байт — суммарный размер строковых аргументов "
                    f"превышает лимит (env {_PARAM_LIMIT_ENV}); инструмент не вызван. "
                    "Файл в рабочую папку доставляет place_download (байты через мост "
                    "не идут)"
                ),
            }
            # FAIL-TELEMETRY-1: отказ ДО вызова — тот же спотык агента, что и отказ
            # инструмента, и считается наравне (иначе упор в лимит моста виден только
            # в логе того сеанса, который его словил).
            _record_degradation(tool, refusal)
            _record_tool_call(tool, False, 0)
            return refusal
        warn_at = int(_env_positive(_PARAM_WARN_ENV, DEFAULT_MCP_PARAM_WARN, integer=True))
        big = size > warn_at
        if big:
            _logger.warning(
                "param_zone: tool=%s bytes=%d warn=%d — крупный параметр, зона отказов "
                "моста (29–39 КБ, инцидент 04.08.2026); вызов начат", tool, size, warn_at,
            )
        started = time.monotonic()
        qlog_started = time.perf_counter()  # журнал запросов — свои часы (не трогает monotonic)
        call_ok = False
        try:
            result = fn(*args, **kwargs)
            call_ok = _result_ok(result)
            # FAIL-TELEMETRY-1: ответ уже несёт машинный код деградации (CONTRACT-2) —
            # снимаем счётчик здесь, в одном месте на все инструменты. Исключение
            # инструмента наружу проходит как раньше и счётчиком НЕ становится: это
            # дефект кода, его место в логе/трейсе, а не в статистике спотыканий.
            _record_degradation(tool, result)
            _record_thread_read(tool, args, kwargs, result)
            _record_query_log(
                fn, tool, args, kwargs, result, (time.perf_counter() - qlog_started) * 1000
            )
            return result
        finally:
            elapsed = time.monotonic() - started
            _record_tool_call(tool, call_ok, elapsed * 1000)  # WAVE1-MEASURE п.2
            slow_s = _env_positive(_SLOW_WARN_ENV, DEFAULT_MCP_SLOW_WARN_S, integer=False)
            if big or elapsed > slow_s:
                _logger.warning(
                    "call_done: tool=%s bytes=%d elapsed_s=%.1f (warn_bytes=%d slow_s=%.1f)",
                    tool, size, elapsed, warn_at, slow_s,
                )

    return wrapper


# DOD-1 — контракт движка в handshake. Это ЕДИНСТВЕННЫЙ канал, который видит любой
# MCP-клиент при подключении: скиллы несут правило только тем, кто их загрузил, а
# ad-hoc чат видит лишь описания инструментов (и то после загрузки схем). Кейс
# 2026-08-04: чат сырыми инструментами произвёл артефакты и не вернул результат в
# vault — правило до исполнителя не доехало. Держим коротко (правило, которое дорого
# прочитать, тоже не соблюдается) и не дублируем README-простыню.
SERVER_INSTRUCTIONS = """\
Digital Twin — движок личного vault: поиск по корпусу, структурные факты, генерация в \
стиле автора, операционка (Timetta — только чтение; TickTick).

Контракт (definition of done — задача, в которой использован DT, НЕ завершена без \
закрывающего шага):
1. Артефакт уходит ЗА ПРЕДЕЛЫ vault (опер. хранилище, клиент, HR, внешняя форма) →
   контур выхода ОБЯЗАТЕЛЕН: output_begin(title, task, channel=…, model=…) ДО работы (папка
   07-outputs + постановка дословно), save_output(output_dir=…, text=…) в конце; почтовый \
тред — читать до последнего входящего (read_note messages="inbound_last").
2. Результат ВОЗВРАЩАЕТСЯ в DT: save_output(text=…, title="…") заведёт папку сам; \
путь файла — в file_refs заметки.
   Доставка файла в ingest-корень — ПО ПОРЯДКУ: (а) документ ИЗ ТЕКСТА → \
save_output(dest=…, format="docx"): pandoc локально, без base64;
   (б) файл УЖЕ НА ДИСКЕ → place_download(source_path=абс.путь | match=имя); \
(в) бинарь из чата → store_file / store_file_begin (хэш-гарды).
3. В vault не писать шеллом (heredoc/cat/mv) — только инструментами DT: иначе нет \
провенанса и аудита, а битую запись никто не увидит.
4. Генерация в стиле автора — по prompt generate-artifact (prompts/list; тот же текст, что \
скилл): parse_task → при detected=false спросить кейс → retrieve (один вызов) → generate → \
save_output; не сырыми retrieve/generate (иначе теряются политика подбора, образец оформления \
и провенанс). Провенанс выхода: \
передай model=<имя модели, которая пишет текст> в output_begin/save_output (объявленное, \
не проверяемое движком); результат, собранный чтением файлов напрямую, без вызовов DT, \
помечается как таковой (engine_calls: 0). Хаб — prompt new-hub, сводка — prompt \
operational-review.
5. DT в Timetta НЕ пишет (CRM ведёт администратор): операционное поручение — карточка
   pult_cards(kinds=["assignment"]), письмо отправляет К. сам. Прямых записей нет by design.
6. Пути из индекса и заметок — подсказка, не адрес: содержимое файла поднимает ТОЛЬКО
   lift_source (он резолвит ссылку сам), корни — pult_paths_get; рекурсивный обход \
сетевых шар запрещён (кладёт мост).

Гарды: запись только под ingest-корни (_system/ingest-roots.yaml), пути с _nda \
исключены везде. Отказы возвращают машиночитаемый code и причину — читайте их."""


def _skill_prompt(body: str) -> Callable[[], str]:
    """Prompt без аргументов, возвращающий тело скилла (FastMCP строит схему по сигнатуре)."""

    def prompt() -> str:
        return body

    return prompt


def profile_skills(profile: str) -> tuple[list[Any], dict[str, list[str]]]:
    """MODEL-1-FIT: скиллы реестра, выполнимые инструментами профиля, и отброшенные с причиной.

    Единый источник для prompts сервера и ``--selftest`` (``core.skills.fit_profile``)."""
    from core.skills import fit_profile, load_skills

    return fit_profile(load_skills(personal=_is_personal_role()), profile_tools(profile))


def _register_prompts(mcp: Any, profile: str = PROFILE_FULL) -> int:
    """TOOLS-PROFILES-1 п.2: скилл DT из ``engine/skills`` — MCP ``prompt`` (тело SKILL.md).

    Контракт генерации и контур выхода доезжают до ЛЮБОГО хоста по протоколу (``prompts/list``),
    а не только до того, у кого стоит скилл. MODEL-1-FIT: регистрируются только скиллы, чьи вызовы
    инструментов ⊆ профиля хоста (prompt, велящий вызвать то, чего нет в ``tools/list``, - ложь
    модели): ``full`` - весь реестр, ``lean`` - то, что помещается в 10 инструментов. Prompts не
    входят в ``tools/list`` и контекст не раздувают. Нет каталога скиллов — промптов нет.
    """
    count = 0
    for skill in profile_skills(profile)[0]:
        mcp.prompt(name=skill.name, description=skill.description or skill.name)(
            _skill_prompt(skill.body)
        )
        count += 1
    return count


_STRICT_MCP_CLASS: Any = None


def _tool_accepted_params(tool: Any) -> list[str]:
    """Имена аргументов инструмента, как их видит клиент (алиас, если есть), в порядке сигнатуры."""
    fields = tool.fn_metadata.arg_model.model_fields
    return [info.alias or name for name, info in fields.items()]


def _strict_fastmcp_class() -> Any:
    """ARGS-STRICT-1: ``FastMCP`` с контрактом аргументов на границе (подкласс, SDK - лениво).

    FastMCP 1.28 строит модель аргументов из сигнатуры, а pydantic по умолчанию
    ``extra='ignore'``: лишние ключи исчезают в ``model_validate`` ДО вызова функции, и
    ``guarded_tool`` их уже не видит (``get_facts(client=…, limit=5)`` отдавал весь стор).
    Подкласс переопределяет ``call_tool`` - единственную точку для всех инструментов, обоих
    транспортов (метод привязывается в ``_setup_handlers`` при создании): неизвестные
    аргументы -> конверт :func:`core.contract.unknown_param_refusal`, инструмент не вызван;
    иначе прежний путь. ``add_tool`` дописывает в схему ``additionalProperties: false`` -
    клиент знает то же, что проверяет сервер.
    """
    global _STRICT_MCP_CLASS
    if _STRICT_MCP_CLASS is not None:
        return _STRICT_MCP_CLASS
    from mcp.server.fastmcp import FastMCP

    class StrictFastMCP(FastMCP):  # type: ignore[misc]
        dt_http: bool = False  # http-демон: хост/токен сессии снимаются как в ``_threaded``

        def add_tool(self, fn: Any, *args: Any, **kwargs: Any) -> None:
            super().add_tool(fn, *args, **kwargs)
            for tool in self._tool_manager.list_tools():
                tool.parameters["additionalProperties"] = False

        async def call_tool(self, name: str, arguments: dict[str, Any]) -> Any:
            tool = self._tool_manager.get_tool(name)
            if tool is not None and arguments:
                accepted = _tool_accepted_params(tool)
                unknown = [key for key in arguments if key not in accepted]
                if unknown:
                    return self._refuse_unknown(tool, name, unknown, accepted)
            return await super().call_tool(name, arguments)

        def _refuse_unknown(
            self, tool: Any, name: str, unknown: list[str], accepted: list[str]
        ) -> Any:
            from core.contract import unknown_param_refusal
            from core.host import clear_request, unbind_session_host

            refusal = unknown_param_refusal(name, unknown, accepted)
            host_token = req_token = None
            if self.dt_http:
                host_token, req_token, _ = _bind_http_request()
            try:
                _capture_host()
                _drop_call_detail()
                _logger.warning(
                    "unknown_param: tool=%s unknown=%s - вызов отклонен без запуска инструмента",
                    name, ",".join(unknown),
                )
                # Отказ ДО вызова - тот же спотык агента, что отказ инструмента (как param_limit).
                _record_degradation(name, refusal)
                _record_tool_call(name, False, 0)
            finally:
                if req_token is not None:
                    clear_request(req_token)
                if host_token is not None:
                    unbind_session_host(host_token)
            try:
                return tool.fn_metadata.convert_result(refusal)
            except Exception:  # noqa: BLE001 - outputSchema инструмента не допускает словарь
                # Шесть инструментов объявлены ``-> list[...]``: их outputSchema - массив, конверт
                # в нее не ложится (клиент отверг бы и structuredContent, и его отсутствие).
                # Отказ идет текстом с ``isError`` - его клиентские SDK от схемы освобождают.
                import json

                from mcp.types import CallToolResult, TextContent

                text = json.dumps(refusal, ensure_ascii=False, indent=2)
                return CallToolResult(content=[TextContent(type="text", text=text)], isError=True)

    _STRICT_MCP_CLASS = StrictFastMCP
    return StrictFastMCP


def personal_recall(query: str, k: int = 5) -> dict[str, Any]:
    """Что я читал и думал по теме: личные заметки, их work_refs и оверлей рабочего контекста.

    Инструмент ЛИЧНОГО экземпляра (регистрируется только при ``DT_INSTANCE_ROLE=personal``; в
    рабочей записи хоста его нет и быть не может). Read-only: ничего не пишет ни здесь, ни в
    рабочем контуре. Возвращает ``{query, k, personal: [{note_id, title, path, score, matched_by,
    work_refs: [{id, title, path, at}]}], linked_work: [...], work: {source: "work", available,
    notes: [{..., source: "work"}]}}``: ``personal`` - попадания по личному индексу, ``work_refs`` -
    связи с рабочим знанием, принятые карточками ``bridge``; ``work`` - живой поиск по тому же
    запросу в рабочем демоне (токен чтения; записи помечены ``source: "work"``). Рабочий демон
    недоступен - ``work.available: false`` с конвертом ``work_unavailable``, личная часть отдана.
    """
    from core.bridge.recall import recall
    from core.bridge.work_client import WorkClient
    from core.instance import is_personal

    if not is_personal():
        return {"ok": False, "refused": "personal_only", "code": "personal_only",
                "error": "personal_recall есть только у личного экземпляра"}
    return recall(
        query, k, personal_search=lambda q, n: find_notes(query=q, limit=n),
        vault=default_vault_path(), client=WorkClient.from_env())


def personal_today() -> dict[str, Any]:
    """Сегодня в личном vault: заметка дня (последние секции) и инбокс личного. Read-only.

    Инструмент ЛИЧНОГО экземпляра (``DT_INSTANCE_ROLE=personal``): виджет «Сегодня» личного пульта.
    ``{date, path, exists, sections: [{time, text}], journal_dir, ideas_dir, inbox: {count, items:
    [{name, lane, preview}]}}``: ``sections`` - последние секции ``## ЧЧ:ММ`` заметки дня (текст
    без футера), ``inbox`` - захваты, ждущие разбора (``lane``: ``content``/``personal``).
    Ничего не пишет."""
    from core.instance import is_personal
    from core.personal.today import today

    if not is_personal():
        return {"ok": False, "refused": "personal_only", "code": "personal_only",
                "error": "personal_today есть только у личного экземпляра"}
    return today(default_vault_path())


def _connector_gated(name: str, fn: Callable[..., Any]) -> Callable[..., Any]:
    """DEV-3-CORE: инструмент выключенного коннектора отвечает конвертом ``connector_disabled``.

    Один механизм на все инструменты оси (``core.surface.manifest.CONNECTOR_AXIS['tool']``): тело
    инструмента не зовется, исключения наружу нет; подпись и докстринг прежние
    (``functools.wraps``),
    так что схема FastMCP и ``_tool_accepted_params`` не меняются."""

    @functools.wraps(fn)
    def gated(*args: Any, **kwargs: Any) -> Any:
        from core import connectors
        from core.contract import connector_disabled_refusal
        from core.surface import manifest

        off = manifest.blocked("tool", name)
        if off:
            return connector_disabled_refusal(name, off, connectors.enable_hint(off))
        return fn(*args, **kwargs)

    return gated


def _gate_connector_tools() -> list[str]:
    """Обернуть инструменты оси «коннектор» (список - из таблицы манифеста, не руками)."""
    from core.surface import manifest

    gated = []
    for tool_name in manifest.gated_items("tool"):
        fn = globals().get(tool_name)
        if callable(fn) and not getattr(fn, "__connector_gated__", False):
            wrapped = _connector_gated(tool_name, fn)
            wrapped.__connector_gated__ = True  # type: ignore[attr-defined]
            globals()[tool_name] = wrapped
            gated.append(tool_name)
    return gated


_gate_connector_tools()


def build_server(
    profile: str | None = None,
    desc_chars: int | str | None = None,
    *,
    http: Mapping[str, Any] | None = None,
):
    """Construct the FastMCP app and register the tool wrappers.

    TOOLS-PROFILES-1: ``profile`` (``lean|pult|full``; иначе ``DT_TOOL_PROFILE``, дефолт ``full``)
    выбирает набор регистрируемых инструментов; ``desc_chars`` (иначе ``DT_TOOL_DESC_CHARS``)
    мягко усекает описания. ``full`` без усечения — прежний сервер байт в байт.

    The ``mcp`` SDK is imported here (not at module load) so the wrappers above
    stay importable — and unit-testable — without the SDK installed.

    FT-3: каждый инструмент регистрируется через :func:`guarded_tool` — одно место
    для лимита размера параметра и диагностики, без правки самих инструментов.
    DOD-1: :data:`SERVER_INSTRUCTIONS` уходят в handshake — контракт получает любой
    MCP-клиент, независимо от скиллов.

    DAEMON-1-SPIKE: ``http`` (настройки FastMCP: ``host``/``port``/``streamable_http_path``…) -
    сервер для http-транспорта: инструменты уходят в поток (:func:`_threaded`), иначе FastMCP
    1.28 гонит синхронный инструмент прямо в event loop и один долгий вызов держит все сессии.
    Без ``http`` - прежний сервер (stdio) байт в байт.
    """
    from core.host import begin_mcp_host

    begin_mcp_host()  # VENDOR-HYGIENE-1: процесс — MCP-сервер; хост снимет guarded_tool
    chosen = resolve_profile(profile)
    limit = desc_chars_limit(desc_chars)
    mcp = _strict_fastmcp_class()(
        "digital-twin", instructions=profile_instructions(chosen), **(http or {})
    )
    mcp.dt_http = http is not None
    for name in profile_tools(chosen):
        wrapped = guarded_tool(globals()[name])
        if http is not None:
            # DAEMON-1: для http инструмент ВСЕГДА в потоке (FastMCP 1.28 иначе гонит синхронный
            # вызов в event loop и один ``generate`` морозит все сессии демона)
            wrapped = _threaded(wrapped)
        if limit:
            wrapped.__doc__ = trim_description(wrapped.__doc__ or "", limit)
        mcp.tool()(wrapped)
    _register_prompts(mcp, chosen)
    return mcp


# --------------------------------------------------------------------------- #
# DAEMON-1-SPIKE - http-транспорт: один процесс на несколько хостов                      #
# --------------------------------------------------------------------------- #
DEFAULT_HTTP_HOST = "127.0.0.1"
DEFAULT_HTTP_PORT = 8787  # порт демона (пульт + /mcp); проверки из worktree - явный --port 8788
WRITE_TOKEN_CODE = "write_token_required"  # noqa: S105 — машинный код отказа, не секрет
_SESSIONS = _core_daemon.SessionRegistry()  # какой хост в какой MCP-сессии (для /health)
LOOPBACK_PEERS = frozenset({"127.0.0.1", "::1", "::ffff:127.0.0.1"})


def _write_token_refusal(tool: str) -> dict[str, Any]:
    """Отказ записи без rw-токена: машинный код (как ``/api``: 403 ``write_token_required``), не
    исключение - модель хоста читает ``code``/``error`` и говорит К., какой токен нужен."""
    return {
        "ok": False,
        "refused": WRITE_TOKEN_CODE,
        "code": WRITE_TOKEN_CODE,
        "error": (
            f"{tool}: запись через MCP-http требует write-токена (.secrets/web_token_rw); "
            "соединение открыто read-токеном - инструменты чтения доступны. Пропиши в записи "
            "хоста Authorization с write-токеном (профиль lean: output_begin / save_output / "
            "place_download тоже запись)"
        ),
    }


def _threaded(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Синхронный инструмент -> async-обертка для http: токен, семафор, поток (anyio).

    Хост сессии снимается здесь, в контексте запроса SDK (``request_ctx``), и кладется в
    ContextVar ``core.host`` на время вызова: поток получает копию контекста, поэтому
    ``current_host()`` внутри инструмента отвечает хостом ЭТОЙ сессии, а не процесса.
    DAEMON-1: инструмент из ``WRITE_TOOLS`` без write-токена не вызывается (отказ с кодом, аудит
    ``denied``); ``generate``/``retrieve`` ждут слот семафора (``DT_DAEMON_HEAVY_PARALLEL``).
    """
    import anyio

    tool = getattr(fn, "__name__", "?")

    @functools.wraps(fn)
    async def runner(*args: Any, **kwargs: Any) -> Any:
        from core.daemon import heavy_slot
        from core.host import clear_request, unbind_session_host

        host_token, req_token, auth = _bind_http_request()
        try:
            if tool in WRITE_TOOLS and auth != "write":
                refusal = _write_token_refusal(tool)
                _record_degradation(tool, refusal)
                _record_tool_call(tool, False, 0)
                _core_pult.record_action("mcp_http", {"tool": tool}, f"denied:{WRITE_TOKEN_CODE}")
                return refusal
            def call() -> Any:
                with _core_daemon.track_tool():  # живой поток виден тому, кто гасит демон
                    return fn(*args, **kwargs)

            async with heavy_slot(tool):
                return await anyio.to_thread.run_sync(call)
        finally:
            if req_token is not None:
                clear_request(req_token)
            unbind_session_host(host_token)

    return runner


def _bind_http_request() -> tuple[Any, Any, str | None]:
    """``clientInfo`` сессии + кто звонит (режим токена, хвост, peer) из контекста запроса SDK.

    Возвращает ``(токен хоста, токен запроса | None, режим токена)``: режим - ``read``/``write``
    (``None`` - нет http-контекста или токен не распознан). Нет контекста/``clientInfo`` - хост
    ``unknown`` (как stdio до handshake). Токен целиком не сохраняется - только хвост (``tail``)."""
    from core.host import bind_session_host, set_request

    name = version = model = ""
    req_token = None
    auth: str | None = None
    try:
        from mcp.server.lowlevel.server import request_ctx

        rc = request_ctx.get()
        info = getattr(rc.session.client_params, "clientInfo", None)
        if info is not None:
            name, version = info.name, info.version
            model = (getattr(info, "model_extra", None) or {}).get("model", "")
        http_req = getattr(rc, "request", None)
        if http_req is not None:
            from core.web_tokens import WebTokens, tail

            tokens = WebTokens()
            hdr = http_req.headers.get("authorization", "")
            presented = [hdr[7:]] if hdr.startswith("Bearer ") else []
            auth = tokens.classify(presented)
            matched = (tokens.rw() if auth == "write" else tokens.read()) if auth else ""
            peer = http_req.client.host if http_req.client else ""
            sid = http_req.headers.get("mcp-session-id", "")
            profile = http_req.url.path.rsplit("/", 1)[-1]
            _SESSIONS.touch(sid, name or "unknown", profile)  # кто в какой сессии (для /health)
            req_token = set_request(auth or "none", tail(matched) if matched else "", peer, sid)
    except Exception:  # noqa: BLE001, S110 - хост/аудит best-effort, вызов не ломаем
        pass
    return bind_session_host(name, version, model), req_token, auth


async def _send_json(
    send: Any, status: int, obj: Any, extra: list[tuple[bytes, bytes]] | None = None
) -> None:
    import json

    body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    await send({"type": "http.response.start", "status": status, "headers": [
        (b"content-type", b"application/json; charset=utf-8"),
        (b"content-length", str(len(body)).encode()), *(extra or [])]})
    await send({"type": "http.response.body", "body": body})


def _proxied(headers: dict[bytes, bytes]) -> bool:
    """Запрос пришел через прокси (Tailscale Funnel/Serve, nginx): ``Forwarded``, ``X-Forwarded-*``,
    ``Tailscale-*``. Локальные хосты (Kimi, мост Desktop) такого не шлют."""
    return any(name == b"forwarded" or name.startswith((b"x-forwarded-", b"tailscale-"))
               for name in headers)


async def _internal_embed(
    scope: dict, receive: Any, send: Any, peer: str, owner: bool = True
) -> None:
    """``POST /internal/embed`` - внутренний вход NIGHT-CHAIN-1: один эмбеддер на машину.

    Только loopback-peer БЕЗ прокси-заголовков (Tailscale-peer не допускается даже в режиме
    ``server``) и Bearer **rw**-токен (read - 403 ``write_token_required``, без токена - 401).
    Это не MCP-инструмент: его нет в ``tools/list`` ни одного профиля и в allowlist пульта.
    Расчет - в потоке (anyio) под ``RLock`` эмбеддера: запросы плановых джобов и хостов идут в
    одной очереди. Тела чанков не логируются (ни при успехе, ни при ошибке).

    PERSONAL-1: демон без модели (``owner=False``, ``DT_EMBED_OWNER=0``) считать не умеет - 404
    ``embed_not_owned`` (он сам клиент соседа). Соседу-экземпляру достаточно узкого токена
    ``embed_token`` (:meth:`core.web_tokens.WebTokens.classify_embed`): он открывает ТОЛЬКО эту
    дверь; файла нет - поведение прежнее (read - 403, без токена - 401)."""
    import anyio

    from core import embed_daemon
    from core.web_tokens import WebTokens

    if scope.get("method") != "POST":
        await _send_json(send, 405, {"error": "method_not_allowed"}, [(b"allow", b"POST")])
        return
    headers = dict(scope.get("headers") or [])
    if _proxied(headers) or peer not in LOOPBACK_PEERS:
        await _send_json(send, 403, {"error": "internal_loopback_only"})
        return
    hdr = headers.get(b"authorization", b"").decode("latin-1")
    presented = [hdr[7:]] if hdr.startswith("Bearer ") else []
    tokens = WebTokens()
    auth = tokens.classify(presented)
    if auth is None and tokens.classify_embed(presented):
        auth = "write"  # токен соседа-эмбеддера: расчет векторов, больше ничего
    if auth is None:
        await _send_json(send, 401, {"error": "auth_required"}, [(b"www-authenticate", b"Bearer")])
        return
    if auth != "write":
        await _send_json(send, 403, {"error": WRITE_TOKEN_CODE})
        return
    if not owner:
        await _send_json(send, 404, {"error": "embed_not_owned"})
        return
    max_texts, max_chars = embed_daemon.request_limits()
    cap = max_texts * max_chars * 3 + 4096  # UTF-8: до 3 байт на символ
    body = bytearray()
    while True:
        msg = await receive()
        body += msg.get("body", b"")
        if len(body) > cap:
            await _send_json(send, 413, {"error": "body_too_large"})
            return
        if not msg.get("more_body"):
            break

    def call() -> dict[str, Any]:
        with _core_daemon.track_tool():  # живой расчет виден тому, кто гасит демон
            return embed_daemon.serve_embed(bytes(body))

    try:
        out = await anyio.to_thread.run_sync(call)
    except embed_daemon.EmbedRequestError as exc:
        await _send_json(send, exc.status, {"error": exc.code})
        return
    except Exception as exc:  # noqa: BLE001 — клиент откатится на локальную загрузку
        _logger.warning("/internal/embed: расчет не удался (%s)", type(exc).__name__)
        await _send_json(send, 500, {"error": "embed_failed"})
        return
    await _send_json(send, 200, out)


class _DaemonApp:
    """ASGI-диспетчер одного процесса: ``/health``; ``/mcp/<профиль>`` (только loopback-peer без
    прокси-заголовков, Bearer, 401 без токена) -> MCP; остальное (``/``, ``/api/*``) -> веб-пульт
    (свой разбор токенов: Bearer, ``?t=``, cookie)."""

    def __init__(self, mcp_app: Any, pult_app: Any | None, health: Callable[[], dict] | None = None,
                 mode: str = "local", embed_owner: bool = True) -> None:
        self._mcp, self._pult, self._health = mcp_app, pult_app, health
        self._mode = mode  # CONFIG-1: local | server (в server /mcp открыт и Tailscale-peer)
        self._embed_owner = embed_owner  # PERSONAL-1: False - модели нет, /internal/embed → 404

    async def __call__(self, scope: dict, receive: Any, send: Any) -> None:
        if scope["type"] == "lifespan":
            await self._mcp(scope, receive, send)
            return
        path = scope.get("path", "")
        peer = (scope.get("client") or ("", 0))[0]
        if path == "/health" and self._health is not None:
            if not _core_daemon.health_peer_ok(peer):  # Wi-Fi/чужим - нет
                await _send_json(send, 403, {"error": "health_peer_forbidden"})
                return
            await _send_json(send, 200, self._health())
            return
        if path == "/internal/embed":  # NIGHT-CHAIN-1: эмбеддер демона - плановым джобам; не MCP
            await _internal_embed(scope, receive, send, peer, self._embed_owner)
            return
        if path.startswith("/mcp/") or path == "/mcp":
            from core.web_tokens import WebTokens

            headers = dict(scope.get("headers") or [])
            # Пульт может слушать 0.0.0.0 (телефон по Tailscale), а ``/mcp`` - только локальным
            # хостам (принцип 4 дизайна: наружу ничего): чужой peer - 403 ДО проверки токена; запрос
            # через прокси (Funnel приходит с 127.0.0.1) - тоже 403. CONFIG-1: в режиме ``server``
            # (DT_MODE) peer из Tailscale тоже допустим (с токеном); прокси - по-прежнему никогда.
            if _proxied(headers) or not (
                peer in LOOPBACK_PEERS
                or (self._mode == "server" and _core_daemon.is_tailscale(peer))
            ):
                await _send_json(send, 403, {"error": "mcp_loopback_only"})
                return
            hdr = headers.get(b"authorization", b"").decode("latin-1")
            presented = [hdr[7:]] if hdr.startswith("Bearer ") else []
            if WebTokens().classify(presented) is None:
                await _send_json(send, 401, {"error": "auth_required"},
                                 [(b"www-authenticate", b"Bearer")])
                return
            await self._mcp(scope, receive, send)
            return
        if self._pult is not None:
            await self._pult(scope, receive, send)
            return
        await send({"type": "http.response.start", "status": 404, "headers": [
            (b"content-length", b"9")]})
        await send({"type": "http.response.body", "body": b"not found"})


class _ModuleView:
    """Живой вид на глобалы модуля: пульту нужен «модуль инструментов» (``PROFILES``,
    ``WRITE_TOOLS``, функции, ``guarded_tool``), а ``sys.modules[__name__]`` есть не всегда (модуль
    загружен по пути через ``importlib`` - так его грузят тесты и
    ``webpult.server.load_tool_module``)."""

    def __init__(self, namespace: dict[str, Any]) -> None:
        self._ns = namespace

    def __getattr__(self, name: str) -> Any:
        try:
            return self._ns[name]
        except KeyError:
            raise AttributeError(name) from None


_ENV_IDLE: Any = object()  # «взять таймаут сессий из DT_DAEMON_SESSION_IDLE_H»
SESSION_SWEEP_S = 300.0


def _live_sessions(mcp: Any, *, sweep: bool = True) -> set[str]:
    """Живые id сессий менеджера SDK. В mcp 1.28 сессия, закрытая клиентом (DELETE), остается в
    ``_server_instances`` с ``is_terminated`` (чистится только упавшая и простоявшая): считать ее
    живой нельзя, а копить - утечка объектов; ``sweep`` убирает закрытые из словаря менеджера."""
    instances = getattr(mcp.session_manager, "_server_instances", None) or {}
    owners = getattr(mcp.session_manager, "_session_owners", {})
    live: set[str] = set()
    for sid, transport in list(instances.items()):
        if getattr(transport, "is_terminated", False):
            if sweep:
                instances.pop(sid, None)
                owners.pop(sid, None)
            continue
        live.add(sid)
    return live


def _mount_session_manager(mcp: Any, idle_s: float) -> bool:
    """``session_idle_timeout`` для ``StreamableHTTPSessionManager``: FastMCP 1.28 не пробрасывает
    его из настроек, но создает менеджер лениво (``if self._session_manager is None``), поэтому до
    ``streamable_http_app()`` кладем свой - с таймаутом и ТЕМИ ЖЕ параметрами, что у FastMCP.
    Опирается на приватные ``_session_manager``/``_mcp_server``: при их исчезновении (обновление
    SDK) возвращает ``False`` - демон работает без таймаута, а тест ``test_session_idle_timeout_*``
    падает и сообщает об этом.

    Семантика SDK: таймаут - пауза между HTTP-запросами сессии, а не после ответа; вызов инструмента
    длиннее таймаута обрывает сессию на лету (клиент не получает ответ). С 24 ч это не встречается;
    ставить секунды/минуты (тесты, отладка) - только заведомо больше самого долгого инструмента."""
    try:
        from mcp.server.streamable_http_manager import StreamableHTTPSessionManager

        mcp._session_manager = StreamableHTTPSessionManager(
            app=mcp._mcp_server,
            event_store=getattr(mcp, "_event_store", None),
            retry_interval=getattr(mcp, "_retry_interval", None),
            json_response=mcp.settings.json_response,
            stateless=mcp.settings.stateless_http,
            security_settings=mcp.settings.transport_security,
            session_idle_timeout=idle_s,
        )
        return True
    except Exception as exc:  # noqa: BLE001 - без таймаута лучше, чем без демона
        _logger.warning("session_idle_timeout не собран (%s: %s) - сессии без таймаута",
                        type(exc).__name__, exc)
        return False


def _resolve_daemon_mode(mode: str | None, tailscale: Any) -> tuple[str, Any]:
    """CONFIG-1 п.5: ``(режим, адрес Tailscale)`` демона. ``server`` - только при ``DT_MODE=server``
    (или явном ``mode``) И найденном адресе Tailscale; иначе честный откат в ``local`` с
    предупреждением в лог (демон не открывается наружу без адреса, ``dt config check`` назовет
    причину). ``tailscale`` по умолчанию определяется ``tailscale status --json``, но только когда
    режим вообще ``server`` (в ``local`` процесс не запускается)."""
    requested = mode if mode is not None else _core_daemon.server_mode()
    if requested != "server":
        return "local", None
    if tailscale is _ENV_IDLE:
        from core.tailscale import status as _tailscale_status

        tailscale = _tailscale_status()
    resolved = _core_daemon.resolve_mode(tailscale, requested)
    if resolved != "server":
        _logger.warning("DT_MODE=server, но адреса Tailscale нет - демон стартует в режиме local")
        return "local", None
    return "server", tailscale


def build_http_app(
    *, host: str = DEFAULT_HTTP_HOST, port: int = DEFAULT_HTTP_PORT, pult: bool = True,
    desc_chars: int | str | None = None, session_idle_s: Any = _ENV_IDLE,
    mode: str | None = None, tailscale: Any = _ENV_IDLE, embed_owner: bool | None = None,
):
    """ASGI-приложение демона: три ``FastMCP`` (lean|pult|full) одного реестра в ОДНОМ процессе
    по путям ``/mcp/<профиль>`` (``stateless_http=False`` - сессии нужны для идентичности хоста и
    prompts) + веб-пульт (``/``, ``/api/*``) и ``/health`` на том же порту.

    ``session_idle_s`` - простой сессии до закрытия, секунды (``None`` - без таймаута; по умолчанию
    ``DT_DAEMON_SESSION_IDLE_H``, 24 ч). DNS-rebinding защита ``/mcp`` включена ВСЕГДА (Host только
    localhost), в том числе при bind ``0.0.0.0``, где SDK сам ее не включает.

    CONFIG-1: ``mode`` (по умолчанию ``DT_MODE``) - ``local`` | ``server``; в ``server`` ``/mcp``
    принимает и Tailscale-peer, а ``Host`` может быть DNS-именем/IP этой машины в tailnet
    (``tailscale`` - ``core.tailscale.TailscaleInfo``; по умолчанию ``tailscale status --json``)."""
    import time
    from contextlib import AsyncExitStack, asynccontextmanager

    from mcp.server.transport_security import TransportSecuritySettings
    from starlette.applications import Starlette

    if session_idle_s is _ENV_IDLE:
        idle_h = _core_daemon.session_idle_hours()
        session_idle_s = idle_h * 3600 if idle_h else None
    mode, tailscale = _resolve_daemon_mode(mode, tailscale)
    allowed_hosts, allowed_origins = _core_daemon.transport_hosts(mode, tailscale)
    security = TransportSecuritySettings(
        enable_dns_rebinding_protection=True,
        allowed_hosts=allowed_hosts,
        allowed_origins=allowed_origins,
    )
    apps = {}
    routes: list[Any] = []
    idle_applied = session_idle_s is None
    for prof in PROFILES:
        mcp = build_server(prof, desc_chars, http={
            "host": host, "port": port, "streamable_http_path": f"/mcp/{prof}",
            "stateless_http": False, "transport_security": security,
        })
        if session_idle_s is not None:
            idle_applied = _mount_session_manager(mcp, session_idle_s)
        apps[prof] = mcp
        routes.extend(mcp.streamable_http_app().routes)  # маршруты уже на пути профиля

    @asynccontextmanager
    async def lifespan(_app: Any):
        import anyio

        async with AsyncExitStack() as stack:
            for mcp in apps.values():  # у каждого FastMCP свой менеджер сессий
                await stack.enter_async_context(mcp.session_manager.run())

            async def sweeper() -> None:  # закрытые клиентом сессии не копим (см. _live_sessions)
                while True:
                    await anyio.sleep(SESSION_SWEEP_S)
                    for mcp in apps.values():
                        _live_sessions(mcp)

            async with anyio.create_task_group() as tg:
                tg.start_soon(sweeper)
                yield
                tg.cancel_scope.cancel()

    started, code = time.time(), _core_daemon.code_version()

    def health() -> dict[str, Any]:
        live = {prof: _live_sessions(mcp) for prof, mcp in apps.items()}
        return _core_daemon.health_payload(
            code=code, started=started, now=time.time(), sessions=_SESSIONS.snapshot(live),
            profiles=list(apps), pult=pult, pid=os.getpid(),
            idle_h=(session_idle_s / 3600 if session_idle_s is not None and idle_applied
                    else None),
            mode=mode, tailscale=tailscale,
        )

    mcp_app = Starlette(routes=routes, lifespan=lifespan)
    pult_app = None
    if pult:
        from webpult.asgi import make_pult_asgi

        pult_app = make_pult_asgi(_ModuleView(globals()))
    return _DaemonApp(
        mcp_app, pult_app, health, mode,
        embed_owner=_core_instance.embed_owner() if embed_owner is None else embed_owner)


def serve_http(host: str, port: int, *, pult: bool = True) -> None:
    """Поднять демон (блокирующе). Токены - ``.secrets/web_token*`` / ``DT_WEB_TOKEN*``; в лог они
    целиком не попадают (под launchd - хвосты и команда показа, ссылки - только в терминале)."""
    import uvicorn

    from core import embed_daemon
    from core.web_tokens import WebTokens

    if _core_instance.embed_owner():
        embed_daemon.mark_model_owner()  # NIGHT-CHAIN-1: модель - наша, к самим себе не ходим
    else:  # PERSONAL-1: модели нет - вектора и запросы считает сосед (DT_EMBED_URL), откат локально
        _logger.info("демон DT без модели (DT_EMBED_OWNER=0): эмбеддинг через %s",
                     _core_instance.embed_url() or "собственный порт (соседа не задали)")
    tokens = WebTokens()
    created = tokens.ensure()  # недостающие файловые токены (read как раньше, rw - новый)
    app = build_http_app(host=host, port=port, pult=pult)
    _logger.info("демон DT: порт %s, пульт=%s, /mcp %s", port, pult,
                 "loopback+tailscale" if getattr(app, "_mode", "local") == "server" else "loopback")
    if getattr(app, "_mode", "local") == "server" and host in ("127.0.0.1", "localhost", "::1"):
        _logger.warning("DT_MODE=server, но bind %s: клиенты по Tailscale не достанут - "
                        "нужен --host 0.0.0.0 (так в ops/launchd/com.dt.server.plist)", host)
    if pult:
        from webpult.server import announce, resolve_html_path

        announce(tokens, port, resolve_html_path(), created)
    # access_log выключен: в строках запроса пульта бывает ``?t=<токен>``; proxy_headers выключен:
    # peer в аудите и проверках - реальный TCP-peer, а не заголовок ``X-Forwarded-For``
    uvicorn.run(app, host=host, port=port, log_level="warning", access_log=False,
                proxy_headers=False)


def selftest(profile: str | None = None) -> tuple[bool, list[str]]:
    """MODEL-1 п.D: самопроверка сервера без хоста - ``(ок, строки отчета)``.

    Поднимает ``build_server(profile)`` в памяти (тот же объект, что уходит в stdio), проходит
    handshake как клиент и сверяет: ``tools/list`` = набор профиля, ``prompts/list`` = скиллы,
    подходящие профилю (``fit_profile(load_skills(), PROFILES[профиль])``; ``full`` - весь
    реестр), ``instructions`` не пусты. Инструменты НЕ вызываются
    (ни телеметрии, ни записей): проверяется то, что увидит хост в первые секунды."""
    import asyncio

    from mcp.shared.memory import create_connected_server_and_client_session

    from core.skills import fit_profile, load_skills

    chosen = resolve_profile(profile)
    expect_tools = set(profile_tools(chosen))
    fit, skipped = fit_profile(load_skills(personal=_is_personal_role()), profile_tools(chosen))
    expect_prompts = {s.name for s in fit}
    lines: list[str] = []

    async def run() -> tuple[set[str], set[str], str]:
        async with create_connected_server_and_client_session(build_server(chosen)) as session:
            init = await session.initialize()
            tools = {t.name for t in (await session.list_tools()).tools}
            prompts = {p.name for p in (await session.list_prompts()).prompts}
            return tools, prompts, init.instructions or ""

    try:
        tools, prompts, instructions = asyncio.run(run())
    except Exception as exc:  # noqa: BLE001 - самопроверка обязана ответить, а не упасть
        return False, [f"FAIL старт: {type(exc).__name__}: {str(exc)[:200]}"]
    results = [
        (tools == expect_tools, f"tools/list = {len(tools)} (профиль {chosen}: "
         f"{len(expect_tools)})" + ("" if tools == expect_tools else
                                    f"; разница: {sorted(tools ^ expect_tools)}")),
        (prompts == expect_prompts, f"prompts/list = {len(prompts)} (скиллы профиля {chosen}: "
         f"{len(expect_prompts)}, вне профиля: {len(skipped)})"
         + ("" if prompts == expect_prompts else
                                      f"; разница: {sorted(prompts ^ expect_prompts)}")),
        (bool(instructions.strip()), f"instructions: {len(instructions)} симв."),
    ]
    for ok, text in results:
        lines.append(("ok   " if ok else "FAIL ") + text)
    all_ok = all(ok for ok, _ in results)
    lines.append(f"SELFTEST {'ok' if all_ok else 'FAIL'} profile={chosen} tools={len(tools)} "
                 f"prompts={len(prompts)}")
    return all_ok, lines


def selftest_http(
    host: str = "127.0.0.1", port: int = DEFAULT_HTTP_PORT, profile: str | None = None
) -> tuple[bool, list[str]]:
    """DAEMON-1 п.7: самопроверка РАБОТАЮЩЕГО демона по http - ``(ок, строки отчета)``.

    Подключается к ``host:port`` как хост (read-токен из ``.secrets/web_token`` / ``DT_WEB_TOKEN``),
    инструменты НЕ вызывает (ни телеметрии, ни записей). Сверяет: ``/health`` ok; по каждому профилю
    (или одному ``profile``) ``tools/list`` и ``prompts/list`` по http = реестр профиля =
    stdio-сборка (полная схема, не только имена), ``instructions`` не пусты; ``GET /`` пульта 200
    с токеном, если
    ``/health`` говорит ``pult: true``. Используется приемкой (``launchctl kickstart -k`` → снова
    ok)."""
    import asyncio
    import json

    import httpx
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    from mcp.shared.memory import create_connected_server_and_client_session
    from mcp.types import Implementation

    from core.skills import fit_profile, load_skills
    from core.web_tokens import WebTokens

    base = f"http://{host}:{port}"
    lines: list[str] = []
    ok_all = True

    def note(ok: bool, text: str) -> None:
        nonlocal ok_all
        ok_all = ok_all and ok
        lines.append(("ok   " if ok else "FAIL ") + text)

    token = WebTokens().read()
    if not token:
        return False, [
            "FAIL нет read-токена (.secrets/web_token / DT_WEB_TOKEN): подключиться нельзя"]
    auth = {"Authorization": f"Bearer {token}"}
    chosen = [resolve_profile(profile)] if profile else list(PROFILES)

    try:
        health = httpx.get(f"{base}/health", timeout=5).json()
    except (httpx.HTTPError, ValueError) as exc:
        return False, [f"FAIL /health: демон не отвечает на {base} ({type(exc).__name__})"]
    ver = health.get("version") or {}
    note(bool(health.get("ok")) and sorted(health.get("profiles") or []) == sorted(PROFILES),
         f"/health: ok, код {ver.get('code')}, uptime {ver.get('uptime_s')} с, профили "
         f"{health.get('profiles')}, сессий {(health.get('sessions') or {}).get('total')}")

    async def dump(session: Any) -> tuple[str, str, str]:
        init = await session.initialize()
        tools = (await session.list_tools()).tools
        prompts = (await session.list_prompts()).prompts
        return (
            json.dumps([t.model_dump(mode="json", by_alias=True) for t in tools], sort_keys=True),
            json.dumps([p.model_dump(mode="json", by_alias=True) for p in prompts], sort_keys=True),
            init.instructions or "",
        )

    async def one(prof: str) -> tuple[tuple[str, str, str], tuple[str, str, str]]:
        async with create_connected_server_and_client_session(build_server(prof)) as mem:
            stdio = await dump(mem)
        async with httpx.AsyncClient(headers=auth, timeout=httpx.Timeout(60.0)) as client, \
                streamable_http_client(f"{base}/mcp/{prof}", http_client=client) as (r, w, _sid), \
                ClientSession(r, w, client_info=Implementation(name="dt-selftest", version="1")
                              ) as http:
            return stdio, await dump(http)

    for prof in chosen:
        expect_tools = set(profile_tools(prof))
        fit, skipped = fit_profile(load_skills(personal=_is_personal_role()), profile_tools(prof))
        try:
            stdio, http = asyncio.run(one(prof))
        except Exception as exc:  # noqa: BLE001 - самопроверка обязана ответить, а не упасть
            note(False, f"{prof}: подключение к {base}/mcp/{prof}: {type(exc).__name__}: "
                        f"{str(exc)[:160]}")
            continue
        http_tools = {t["name"] for t in json.loads(http[0])}
        http_prompts = {p["name"] for p in json.loads(http[1])}
        note(http_tools == expect_tools,
             f"{prof}: tools/list по http = {len(http_tools)} (реестр {len(expect_tools)})"
             + ("" if http_tools == expect_tools
                else f"; разница: {sorted(http_tools ^ expect_tools)}"))
        note(http_prompts == {s.name for s in fit},
             f"{prof}: prompts/list по http = {len(http_prompts)} (скиллы профиля {len(fit)}, "
             f"вне профиля {len(skipped)})")
        note(http[0] == stdio[0] and http[1] == stdio[1],
             f"{prof}: tools/list и prompts/list по http = stdio (полная схема)")
        note(bool(http[2].strip()) and http[2] == stdio[2],
             f"{prof}: instructions {len(http[2])} симв. = stdio")

    if health.get("pult"):
        try:
            resp = httpx.get(f"{base}/", headers=auth, timeout=10)
            note(resp.status_code == 200 and b"__DT_WEB_MODE" in resp.content,
                 f"пульт: GET / → {resp.status_code}, {len(resp.content)} байт")
        except httpx.HTTPError as exc:
            note(False, f"пульт: GET / не ответил ({type(exc).__name__})")
    else:
        lines.append("ok   пульт: отключен в этом демоне (--no-pult), проверка пропущена")

    lines.append(f"SELFTEST {'ok' if ok_all else 'FAIL'} transport=http {host}:{port} "
                 f"profiles={','.join(chosen)}")
    return ok_all, lines


def main(argv: list[str] | None = None) -> None:
    """Run the server over stdio (the transport MCP hosts connect to).

    ``--profile lean|pult|full`` (иначе ``DT_TOOL_PROFILE``; дефолт ``full``): набор инструментов
    в ``tools/list`` (TOOLS-PROFILES-1). Без аргументов запуск прежний.
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="server.py", description="Digital Twin MCP server (stdio)"
    )
    parser.add_argument(
        "--profile", choices=tuple(PROFILES), default=None,
        help=f"профиль инструментов (env {TOOL_PROFILE_ENV}; дефолт {DEFAULT_PROFILE})",
    )
    parser.add_argument(
        "--transport", choices=("stdio", "http"), default="stdio",
        help="stdio - как хост запускает сервер (по умолчанию); http - один процесс на хосты "
             "(DAEMON-1-SPIKE: /mcp/<профиль> + веб-пульт на том же порту)",
    )
    parser.add_argument("--host", default=DEFAULT_HTTP_HOST, help="только для --transport http")
    parser.add_argument("--port", type=int, default=DEFAULT_HTTP_PORT,
                        help=f"только для --transport http (дефолт {DEFAULT_HTTP_PORT})")
    parser.add_argument("--no-pult", action="store_true",
                        help="http: без веб-пульта (только /mcp)")
    parser.add_argument(
        "--selftest", action="store_true",
        help="самопроверка и выход: поднялся, tools/list = профиль, prompts = реестр скиллов; "
             "с --transport http - проверка РАБОТАЮЩЕГО демона на --host/--port (три профиля = "
             "реестр = stdio, /health, пульт)",
    )
    args = parser.parse_args(argv)
    if args.selftest and args.transport == "http":
        ok, report = selftest_http(args.host, args.port, args.profile)
        print("\n".join(report))
        raise SystemExit(0 if ok else 1)
    if args.selftest:
        ok, report = selftest(args.profile)
        print("\n".join(report))
        raise SystemExit(0 if ok else 1)
    if args.transport == "http":
        serve_http(args.host, args.port, pult=not args.no_pult)
        return
    build_server(args.profile).run(transport="stdio")


if __name__ == "__main__":
    main()
