# SETUP - установка Digital Twin на новой машине

Порядок для человека, который ставит движок первый раз. Команды - из каталога `engine/`. Нужны: macOS,
[`uv`](https://docs.astral.sh/uv/), хост MCP (Claude Desktop/Cowork или другой), около 2 ГБ места под
модель эмбеддингов (разовая докачка при первом индексе).

Версия движка и схем - `uv run python cli/dt.py version` (релизы - `CHANGELOG.md`).

**Одной командой: `dt install`** (DEV-3-KIT). Шаги 0-8 ниже - те же команды движка, которые оркестратор
выполняет по порядку, с проверкой каждого шага и состоянием (`.derived/install/state.json`: на чем
остановились, проценты скачивания моделей, ответы мастера; секретов нет):

```sh
uv run python cli/dt.py install --check     # таблица «шаг - сделано/нет - почему» (ничего не пишет)
uv run python cli/dt.py install --dry-run   # что было бы сделано
uv run python cli/dt.py install             # продолжить с первого незавершенного шага (спросит имя, почты, хост)
uv run python cli/dt.py install --yes --name "Имя Фамилия" --email me@example.com --host claude
uv run python cli/dt.py install --step models --models-from dt-models.tar   # модели офлайн
uv run python cli/dt.py uninstall           # снять задания и запись хоста; vault, .env, модели остаются
```

Шаги: `platform` (macOS 14+, место, `uv`, `git`) → `deps` → `config` → `vault` → `owner` → `models`
(~4.5 ГБ, с процентами) → `launchd` → `host` → `index` → `doctor`. `sudo` не нужен, ключи и токены
установщик не спрашивает (секреты - `dt config set KEY --stdin`, шаг 4). Для нового человека в кит
кладется `installer/INSTALL.md`: его вставляют в Claude, и он проводит по профилю, стилю и интеграциям.
Пошаговый порядок ниже остается ручным путем и справкой.

## 0. Зависимости

```sh
uv sync --all-extras
```

## 1. Конфиг - `dt config init`

```sh
uv run python cli/dt.py config init     # engine/.env из реестра настроек (права 600)
uv run python cli/dt.py config check    # что в .env не так (пустые обязательные, опечатки, права)
```

Список всех настроек - реестр `core/config/knobs.py`; значения - `dt config show`; ключ правится
`dt config set KEY VALUE` (бэкап `.env.bak-<ts>`). Правило «где что живет» - `docs/ops.md` («Один
конфиг»). `.env` не попадает в git: в нем настройки и секреты ЭТОЙ машины.

## 2. Каркас vault - `dt vault init`

```sh
uv run python cli/dt.py vault init --kind work --vault ~/DigitalTwin/vault
uv run python cli/dt.py config set DT_VAULT_PATH ~/DigitalTwin/vault
```

Каркас берется из `engine/vault-template/` (его генерирует `scripts/build_vault_template.py`, руками он
не правится): README в каждой папке (`01-style` … `07-outputs`, `_staging`, `_system`), политики поиска,
шаблоны гайдов стиля, пустые `ingest-roots.yaml` и `host-access.yaml`, образец `mail-filter.yaml`, шаблоны
профиля. Повторный запуск ничего не перезаписывает - его можно запускать и на уже живом vault.

Дальше положите свои образцы стиля в `01-style/` (через `dt ingest` или `store_file`) и впишите корни с
вашими файлами в `_system/ingest-roots.yaml`.

## 3. Профиль владельца - `dt owner init`

```sh
uv run python cli/dt.py owner init      # owner.yaml + about.md + rules.md в vault/_system/profile
uv run python cli/dt.py owner check
```

В `owner.yaml` - вы: `name`, `name_variants`, `emails`, `company: {name, domains, internal_domains}`,
`privacy.people`. Домены ваших адресов и `company.domains` движок считает «своими» в почте (участник с таким
доменом - вы, остальные - контрагенты); служебные домены группы - `company.internal_domains`. Пустой список
доменов при включенной почте - предупреждение `dt config check` и доктора: вся почта станет внешней.
`about.md` идет в промпт генерации (1-2 экрана о вас), `rules.md` - правила для ассистентов; оба заполняются
руками. Старый `owner.yaml` со строкой `company: <название>` `dt owner init` переписывает в объект (с
бэкапом).

## 4. Коннекторы: секреты и `DT_CONNECTORS`

Коннекторы - внешние сервисы, которых у многих нет: `timetta` (CRM, только чтение), `ticktick` (захваты по
тегам), `outlook` (почта и календарь через Classic Outlook, macOS). Выключенный коннектор не грузит свои
секции пульта, не ходит в сеть, не дает ошибок и предупреждений доктора: вместо них одна строка «коннектор
выключен».

| `DT_CONNECTORS` | что значит |
|---|---|
| не задан / `auto` | включен тот, чей секрет/настройка есть (таблица ниже) - как работало до коннекторов |
| `none` | «базовый DT»: знания, поиск, генерация, пульт без CRM/почты/таск-менеджера |
| `timetta,outlook` | включены ровно перечисленные (секрет не проверяется: нет секрета - предупреждение `dt config check`) |

| коннектор | нужно для `auto` | где |
|---|---|---|
| `timetta` | `TIMETTA_API_TOKEN`; для «моих сделок» - `DT_TIMETTA_USER_ID` и `DT_TIMETTA_USER_EMAIL` | Keychain / `.env` |
| `ticktick` | `TICKTICK_ACCESS_TOKEN`; служебный список захвата - `DT_TICKTICK_CAPTURE_PROJECT_NAME` | Keychain / `.env` |
| `outlook` | `DT_OUTLOOK_FOLDERS` (папки почты) и Classic Outlook на машине | `.env` |

Без коннекторов: `uv run python cli/dt.py config set DT_CONNECTORS none`. С коннекторами - секреты в Keychain
(не в `.env`): `uv run python cli/dt_secrets.py --status`, затем `--migrate` (и `--prune`, чтобы вырезать
значения из `.env`). Состояние коннекторов видно в «Настройках» пульта (строка «Коннекторы») и в
`pult_manifest.connectors`; подробности - `ops/README.md`, раздел «Коннекторы».

Если включен TickTick: служебный список (top-level, НЕ внутри папки клиента) - «Захват»; теги на захвате:
`#личное` (не грузим), `#оператив` (только TickTick), `#знание` (→ vault), `#поручение` (→ карточка
«Поручение администратору CRM»: письмо отправляете вы; адрес - `DT_CRM_ADMIN_EMAIL`).

## 4a. Личный контур (опция, PERSONAL-1)

Не обязателен. Второй экземпляр движка на личном vault: захват `#дневник`/`#контент`, связи с рабочим знанием
по токену чтения, `personal_recall` в отдельной записи хоста. Подробно - `ops/README.md`, раздел «Экземпляры».

1. `uv run python cli/dt.py instance add personal --vault <путь>/vault-personal --port 8788`
2. `launchctl list | grep dt` - три метки `*-personal`; `uv run python cli/dt.py instance status`
3. запись хоста: `uv run python cli/dt.py host-config claude --instance personal --install --relaunch`
   (ключ `digital-twin-personal`; рабочая запись не меняется)

## 4b. Модели ИИ-синтезов (второй человек без Desktop, GATEWAY-1)

Не обязателен: без настройки пульт работает на базе движка (бриф, подсказка лейна, «Собрать промпт»). Чтобы
синтезы писала модель, а не хост, - три профиля и маршруты «класс задачи → профиль» (подробно - `docs/ops.md`,
«База и синтез»):

| профиль | что это | какой класс туда |
|---|---|---|
| `cheap` | дешевая быстрая модель, openai-совместимый API (Moonshot/Kimi, OpenRouter) | `triage` (бриф, лейн захвата) |
| `strong` | сильная модель (anthropic или openai-совместимая) | `synth` (состояние хаба, проверка хаба) |
| `local` | модель на этой машине (Ollama/LM Studio, `http://localhost`) - данные не уходят | любой класс, где данные не должны выходить; `draft` обычно `host` или `strong` |

1. `uv run python cli/dt.py ai set profile cheap provider=openai url=https://api.moonshot.ai/v1 model=<имя>`
2. `uv run python cli/dt.py ai set profile strong provider=anthropic model=<имя>`
3. ключи (не в чат и не в конфиг): `uv run python cli/dt.py ai set-key --profile cheap`, то же для `strong`
4. `uv run python cli/dt.py ai set route triage cheap`; `... set route synth strong`; `... set route draft host|strong|none`
5. проверка: `uv run python cli/dt.py ai test --class triage`; `uv run python cli/dt.py ai show`; `dt doctor` - строка «ИИ-шлюз»

Старый плоский `ai:` в `pult.yaml` читается как профиль `default`; перепишет в профили `dt ai migrate` (бэкап рядом).

## 5. Автозапуск контура (launchd) - `dt install --step launchd`

Одной командой из каталога `engine`:

```sh
uv run python cli/dt.py install --step launchd             # состав по манифесту и коннекторам
bash ops/install_launchd.sh                                 # полный состав владельца (= --ops-full)
```

Команда сама определит пути `engine/` и `uv`, подставит их в плисты-шаблоны, создаст каталог логов, положит
плисты в `~/Library/LaunchAgents/` и загрузит задания: демон движка `com.dt.server` (пульт и MCP на `:8787`),
`fast` (входящие потоки - только включенные коннекторы и файлы) каждые 30 минут, `index` ночью, `backup`
по воскресеньям; `meetings` - только при коннекторе `outlook`; `smoke` и `run.watchdog` - только с `--ops-full`
(`ops/install_launchd.sh` - обертка над ним). Детали, управление и логи - [`ops/README.md`](README.md).
Снять (на время правок):

```sh
bash ops/uninstall_launchd.sh
```

## 6. Подключить хост - `dt host-config`

```sh
uv run python cli/dt.py host-config claude --install --relaunch
```

Пишет запись `digital-twin` в конфиг Claude Desktop (бэкап рядом). Desktop перезаписывает свой конфиг при выходе,
поэтому `--relaunch` закрывает его, пишет запись и запускает снова (без `--relaunch` при запущенном Desktop - отказ
`desktop_running`). Проверка: `uv run python cli/dt.py host-config claude --verify`. Другие хосты (Cursor, Kimi,
Cherry) - `docs/ops.md`.

## 7. Первый индекс

```sh
DT_MODEL_DOWNLOAD=1 uv run python cli/dt_index.py --full
```

Первый запуск докачивает модель эмбеддингов (около 2 ГБ, разово - дальше `DT_MODEL_DOWNLOAD` не нужен). Пустой
vault индексируется без ошибок: поиск вернет пустой ответ, пока в vault нет знаний. Дальше индекс обновляет ночной
шаг `index`.

## 8. Проверка - `dt doctor`

```sh
uv run python cli/dt_doctor.py          # ни одного fail; warn - подсказки, что настроить дальше
uv run python cli/dt.py version         # версия движка и схем
launchctl list | grep dt                # задания видны
tail -n 40 "$(cd ops/.. && pwd)/../.derived/logs/dt-sync.log"   # счетчики осмысленны, ошибок нет
```

Первая неделя: поглядывайте `.derived/logs/dt-sync.log` и «Мониторинг» пульта. Если что-то не так - `bash
ops/uninstall_launchd.sh` и назад на ручные прогоны (`ops/README.md`, «Ручной запуск»).
