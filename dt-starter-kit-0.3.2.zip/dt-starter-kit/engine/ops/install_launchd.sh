#!/usr/bin/env bash
# Установка launchd-заданий владельца: тонкая обертка над `dt install --step launchd --ops-full`.
# Запуск из любого каталога:  bash ops/install_launchd.sh
#
# DEV-3-KIT: логика (состав заданий по манифесту и коннекторам, подстановка путей в ops/launchd/
# *.plist, launchctl, снятие устаревших com.dt.sync.full / com.dt.webpult) переехала в
# core/install/launchd.py; здесь осталось только «поставить ПОЛНЫЙ состав владельца» -
# server, sync.fast, sync.index, backup, meetings (если включен коннектор outlook), smoke и
# run.watchdog. Новому человеку - `dt install` (без --ops-full: смоук и сторож не ставятся).
# Повтор безопасен: неизменившиеся задания не перезагружаются.
set -euo pipefail

ENGINE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v uv >/dev/null 2>&1; then
  echo "ОШИБКА: uv не найден в PATH. Установи uv или поправь PATH и повтори." >&2
  exit 1
fi

cd "$ENGINE_DIR"
uv run python cli/dt.py install --step launchd --ops-full "$@"

echo
echo "Проверка:        launchctl list | grep -i dt"
echo "Разовый прогон:  launchctl start com.dt.sync.index   # или .fast"
echo "Логи:            tail -f \"$ENGINE_DIR/../.derived/logs/dt-sync.log\""
echo "Снять:           bash ops/uninstall_launchd.sh   # или dt uninstall"
