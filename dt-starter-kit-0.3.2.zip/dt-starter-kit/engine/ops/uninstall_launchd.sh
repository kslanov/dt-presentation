#!/usr/bin/env bash
# Снятие launchd-заданий операционного контура.
# Запуск:  bash ops/uninstall_launchd.sh
set -euo pipefail

LA_DIR="$HOME/Library/LaunchAgents"

# Список обязан покрывать манифест заданий (core.surface.manifest.LAUNCHD_JOBS - его ставит
# `dt install --step launchd`, плюс снятые с планирования легаси-джобы): джоб, который ставят и
# не снимают, переживает «снял всё» и потом удивляет — так com.dt.meetings оставался загруженным
# после uninstall (гард - tests/test_install_launchd.py). Полное снятие вместе с хостами - `dt uninstall`.
for f in com.dt.sync.fast com.dt.sync.index com.dt.sync.full com.dt.server com.dt.webpult \
         com.dt.meetings com.dt.smoke com.dt.backup com.dt.run.watchdog; do
  dst="$LA_DIR/$f.plist"
  if [ -f "$dst" ]; then
    launchctl unload "$dst" 2>/dev/null || true
    rm -f "$dst"
    echo "removed: $f"
  else
    echo "нет: $f (уже снят)"
  fi
done

echo "Готово. Контур больше не запускается по расписанию (ручные прогоны dt_sync работают как прежде)."
