"""DEV-3-KIT п.2: собрать ``dt-models.tar`` - офлайн-раздачу моделей из боевого кэша.

Нужна, чтобы второй человек не качал ~4.5 ГБ из интернета: ``dt install --step models
--models-from dt-models.tar`` распаковывает набор в свой кэш БЕЗ сети и сверяет sha256 каждого
файла по манифесту ``dt-models.json`` внутри архива. В набор идут только нужные движку файлы
(``allow_patterns`` эмбеддера/реранкера + веса ``pytorch_model.bin`` старого кэша) из снимка
``refs/main`` с их блобами; README, картинки и лишние снимки - нет. Архив детерминирован
(порядок, mtime=0): повторная сборка даёт тот же файл. Кэш читается только на чтение.

Usage:
    uv run python scripts/build_models_bundle.py --out dist/dt-models.tar
    uv run python scripts/build_models_bundle.py --dry-run          # что войдет и сколько весит
"""

from __future__ import annotations

import argparse
import fnmatch
import hashlib
import io
import json
import sys
import tarfile
from pathlib import Path

ENGINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE))

from core.config import models_path  # noqa: E402
from core.install.models import BUNDLE_MANIFEST, MODELS, ModelSpec, _snapshot  # noqa: E402

_GIB = 1024**3


def _wanted(spec: ModelSpec, name: str) -> bool:
    patterns = [*spec.allow_patterns(), *spec.weights]
    return any(fnmatch.fnmatch(name, p) for p in patterns)


def plan(cache: Path) -> list[tuple[Path, str]]:
    """``[(путь в кэше, имя в архиве)]``: refs, нужные файлы снимка (ссылки) и их блобы."""
    items: list[tuple[Path, str]] = []
    seen: set[Path] = set()
    for spec in MODELS:
        repo = cache / spec.dirname
        snap = _snapshot(repo)
        if snap is None:
            raise SystemExit(
                f"в кэше {cache} нет снимка {spec.repo_id}: сначала `dt install --step models`")
        ref = repo / "refs" / "main"
        if ref.is_file():
            items.append((ref, ref.relative_to(cache).as_posix()))
        for link in sorted(snap.rglob("*")):
            if not link.is_file():
                continue
            rel = link.relative_to(snap).as_posix()
            if not _wanted(spec, rel):
                continue
            items.append((link, link.relative_to(cache).as_posix()))
            blob = link.resolve()
            if blob not in seen:
                seen.add(blob)
                items.append((blob, blob.relative_to(cache.resolve()).as_posix()))
    return items


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _norm(info: tarfile.TarInfo) -> tarfile.TarInfo:
    info.uid = info.gid = 0
    info.uname = info.gname = ""
    info.mtime = 0
    return info


def build(cache: Path, out: Path) -> dict[str, int]:
    items = plan(cache)
    blobs = {name: path for path, name in items if "/blobs/" in name}
    manifest = {"files": {name: {"sha256": _sha256(path), "size": path.stat().st_size}
                          for name, path in sorted(blobs.items())}}
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, "w") as tar:
        for path, name in sorted(items, key=lambda it: it[1]):
            info = _norm(tar.gettarinfo(str(path), arcname=name))  # ссылка остается ссылкой
            if info.isreg():
                with path.open("rb") as fh:
                    tar.addfile(info, fh)
            else:
                tar.addfile(info)
        blob = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
        info = _norm(tarfile.TarInfo(BUNDLE_MANIFEST))
        info.size = len(blob)
        tar.addfile(info, io.BytesIO(blob))
    return {"files": len(manifest["files"]), "bytes": out.stat().st_size}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--cache", default=None, help="кэш моделей (по умолчанию DT_MODELS_PATH)")
    parser.add_argument("--out", default="dist/dt-models.tar")
    parser.add_argument("--dry-run", action="store_true", help="показать состав и размер")
    args = parser.parse_args(argv)
    cache = Path(args.cache).expanduser() if args.cache else models_path()
    if args.dry_run:
        items = plan(cache)
        blobs = {n: p for p, n in items if "/blobs/" in n}
        total = sum(p.stat().st_size for p in blobs.values())
        print(f"{cache}: {len(blobs)} файлов, {total / _GIB:.2f} ГБ (в архив пойдут только они)")
        for name, path in sorted(blobs.items()):
            print(f"  {path.stat().st_size / 1e6:9.1f} МБ  {name}")
        return 0
    stats = build(cache, Path(args.out))
    print(f"{args.out}: {stats['files']} файлов, {stats['bytes'] / _GIB:.2f} ГБ; "
          f"манифест {BUNDLE_MANIFEST} с sha256 внутри")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
