"""DEV-3-KIT п.5: собрать стартовый кит - ``dist/dt-starter-kit-<версия>.zip`` для второго человека.

Кит ГЕНЕРИРУЕТСЯ, руками не правится (как ``vault-template``): вход - этот репозиторий, выход - zip
с манифестом хэшей ``KIT-MANIFEST.json``. Состав::

    README.md  INSTALL.md  CHANGELOG.md  VERSION  KIT-MANIFEST.json
    engine/       движок БЕЗ: .env*, .secrets*, .derived*, models/, .git, .venv, .claude,
                  instances/, __pycache__, tests/, spikes/, plugins/, PROGRESS.md, внутренних
                  docs/ (остаются четыре справочных) и личного скилла tz-presentation-dt;
                  vault-template/ остается внутри (его читает ``dt vault init``)
    installer/    INSTALL.md (промпт наставника) + brain/ (рельсы по фазам и glossary.md) + state/
                  (копия ``engine/installer``: так их видит человек); ``INSTALL.md`` лежит и в
                  корне кита, рядом с README: его видно сразу
    skills/       скиллы в формате Cherry (``<имя>/SKILL.md``) + README «как подключить»; скилл
                  правил владельца ``dt-owner`` НЕ входит (он строится из профиля человека)

**Гард утечек** (код 1 и zip не пишется): в архиве нет файлов ``.env*``/секретов/производных/кэшей,
нет приватных терминов боевого ``owner.yaml`` (имя, фамилии, компания, домены - по номеру, сами
термины не печатаются), токенов по маске и абсолютных путей ``/Users/<имя>`` (заглушки
``you``/``me`` в примерах допустимы). Архив детерминирован (порядок, даты, права):
``--check`` пересобирает и сверяет с лежащим файлом.

Usage:
    uv run python scripts/build_starter_kit.py --vault ../../vault          # dist/…-<версия>.zip
    uv run python scripts/build_starter_kit.py --vault ../../vault --check  # код 1, если zip иной
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import tempfile
import zipfile
from collections.abc import Mapping, Sequence
from fnmatch import fnmatch
from pathlib import Path

ENGINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE))
sys.path.insert(0, str(ENGINE / "scripts"))
sys.path.insert(0, str(ENGINE / "cli"))

from core.owner.privacy import PrivateTerms  # noqa: E402

MANIFEST = "KIT-MANIFEST.json"
GENERATOR = "scripts/build_starter_kit.py"
ZIP_DATE = (2026, 1, 1, 0, 0, 0)

#: каталоги, которых в ките нет НИГДЕ (шаблоны ``fnmatch`` по имени каждого компонента пути)
EXCLUDE_DIR_GLOBS = (
    ".git", ".venv", "venv", ".claude", ".pytest_cache", ".ruff_cache", ".mypy_cache",
    "__pycache__", "node_modules", "dist", "htmlcov", "models", "instances", ".secrets*",
    ".derived*",
)
#: ПОСТАВЛЯЕМЫЕ корни engine/ (KIT-PRIVACY-1): в кит идет только перечисленное, остальное (tests,
#: spikes, plugins, docs/tz, PROGRESS …) - нет. Этот же список читает гард тестов
#: ``test_no_private_terms_in_shipped_code``: область гарда и состав кита не разъезжаются.
SHIPPED_DIRS = ("core", "cli", "mcp-server", "webpult", "scripts", "skills", "skills-personal",
                "ops", "vault-template", "policies", "prompts")
SHIPPED_TOP_FILES = ("README.md", "CHANGELOG.md", "SECURITY.md", "Makefile", "pyproject.toml",
                     "uv.lock", ".gitignore")
#: путь внутри engine/, который в кит не идет, и почему
EXCLUDE_PATHS = {
    # личная версия скилла владельца: в тексте названия его проектов и клиентов
    "skills/tz-presentation-dt": "личный скилл владельца (примеры с названиями его проектов)",
    # разовые миграции исторического корпуса: рабочий материал владельца, в репо остаются
    "cli/_oneoff": "разовые скрипты миграций корпуса владельца",
    # скрипты прогона на живых данных владельца (id его хабов и клиентов зашиты в константы)
    "scripts/demo_policy.py": "демо политик на хабах боевого vault",
    "scripts/retr_chunk_canary.py": "канарейка индекса на подмножестве клиента владельца",
    "scripts/smoke_retrieval.py": "смоук поиска на заметках боевого vault",
    # исключения из списка приватных терминов - решение владельца, его слова в ките не нужны
    "scripts/privacy-ignore.txt": "решение владельца о приватных терминах",
}
#: ``docs/`` - только справочные файлы (остальное - аудиты, разборы инцидентов, ТЗ с именами)
DOCS_ALLOW = ("docs/01-concept.md", "docs/02-architecture.md", "docs/08-tools-reference.md",
              "docs/ops.md")
#: имена файлов, которых в ките нет (шаблоны ``fnmatch``)
EXCLUDE_FILE_GLOBS = (
    ".env", ".env.*", ".secrets*", "*.secret", "*.bak-*", ".derived*", "*.pyc", "*.pyo",
    ".DS_Store", ".git", "dt-models.tar", "*.egg-info", ".coverage", ".coverage.*", "*.db",
    "*.db-wal", "*.db-shm",
)

_BINARY_SUFFIXES = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".ico", ".woff", ".woff2", ".ttf", ".pdf", ".zip", ".tar",
    ".gz", ".lance", ".pt", ".bin", ".safetensors"})
#: запрещенные каталоги в ГОТОВОМ архиве (проверка гарда, не только фильтр сборки)
FORBIDDEN_PARTS = (".git", ".venv", ".claude", "__pycache__", "models", "instances", ".secrets*",
                   ".derived*")
FORBIDDEN_NAME_GLOBS = (".env", ".env.*", ".secrets*", "*.secret", "*.bak-*", ".derived*",
                        "*.pyc", ".DS_Store", "dt-models.tar", ".git")
_TOKEN_MASKS = (
    ("sk-", re.compile(r"(?<![A-Za-z0-9_])sk-[A-Za-z0-9_-]{20,}")),
    ("ghp_", re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}")),
    ("slack", re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}")),
    ("aws", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("jwt", re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}")),
    ("bearer", re.compile(r"Bearer [A-Za-z0-9._~+/-]{24,}")),
    ("private key", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    # ``KEY=значение`` в конфигах и доках (в .py - константы с ИМЕНАМИ переменных, не секреты)
    ("env assignment", re.compile(
        r"(?m)^(?:export )?[A-Z0-9_]*(?:TOKEN|SECRET|PASSWORD|API_KEY)[A-Z0-9_]*\s*=\s*"
        r"[\"']?(?![<$\[{(])(?![A-Z0-9_]+[\"'\s]*$)[A-Za-z0-9_./+=-]{20,}")),
)
_CODE_SUFFIXES = frozenset({".py"})
_HOME = "/" + "Users" + "/"  # литерал не лежит в этом файле целиком: гард читает и сам скрипт
_USERS_PATH = re.compile(re.escape(_HOME) + r"(?!(?:you|me|user|username|name|someone|example)\b"
                         r"|<|\$|\.\.\.)")


# --------------------------------------------------------------------------- сбор ------------ #
def _excluded_name(name: str) -> bool:
    return any(fnmatch(name, g) for g in EXCLUDE_FILE_GLOBS)


def collect_engine(src: Path) -> tuple[dict[str, bytes], set[str]]:
    """``({путь внутри kit/engine: байты}, {исполняемые})`` по правилам исключений."""
    files: dict[str, bytes] = {}
    execs: set[str] = set()
    for path in sorted(src.rglob("*")):
        if not path.is_file() and not path.is_symlink():
            continue
        rel = path.relative_to(src)
        parts = rel.parts
        if any(fnmatch(p, g) for p in parts[:-1] for g in EXCLUDE_DIR_GLOBS):
            continue
        if not (parts[0] in SHIPPED_DIRS or rel.as_posix() in SHIPPED_TOP_FILES
                or rel.as_posix() in DOCS_ALLOW):
            continue
        if _excluded_name(rel.name) or path.is_symlink():
            continue
        posix = rel.as_posix()
        if any(posix == p or posix.startswith(p + "/") for p in EXCLUDE_PATHS):
            continue
        files[f"engine/{posix}"] = path.read_bytes()
        if path.stat().st_mode & 0o111:
            execs.add(f"engine/{posix}")
    return files, execs


def _tree_of(base: Path, prefix: str) -> dict[str, bytes]:
    return {f"{prefix}/{p.relative_to(base).as_posix()}": p.read_bytes()
            for p in sorted(base.rglob("*")) if p.is_file() and not _excluded_name(p.name)}


SKILLS_README = """\
# Скиллы Digital Twin

Скиллы - готовые инструкции для ассистента: как писать артефакт в вашем стиле, как оформить выход,
как завести хаб, как собрать операционную сводку. Источник у них один (`engine/skills`); здесь они в
формате Cherry Studio: `<имя>/SKILL.md` (шапка `name`/`description`/`version`).

## Как подключить

- **Claude Desktop / Cowork.** Для каждой папки `<имя>/` создайте скилл в библиотеке аккаунта с
  содержимым `SKILL.md` (или попросите ассистента: «опубликуй эти скиллы в мою библиотеку»). Нужен
  полный набор. Правила про вас (`dt-owner`) создаются отдельно командой
  `uv run python cli/dt.py skills export cowork --out <папка>` из каталога `engine/` - она читает
  ваш профиль, поэтому в кит не входит.
- **Kimi Work.** `uv run python cli/dt.py plugin kimi --out plugins/kimi-work --install` из каталога
  `engine/`: соберет плагин со скиллами, подходящими профилю `lean`, и положит его в Kimi.
- **Cherry Studio.** Settings → Skills → «Установить из каталога», по одной папке `<имя>/` на
  навык; подключение самого движка (`host-config cherry`) - в `engine/plugins/cherry` после
  установки: `uv run python cli/dt.py host-config cherry`.

Какие скиллы подходят какому хосту, определяет профиль инструментов хоста: `dt skills export <хост>`
сам отбирает подходящие и называет отброшенные.
"""

KIT_README = """\
# Digital Twin - стартовый кит

Персональный движок знаний: ищет по вашему vault и пишет документы в вашем стиле. Все считается у
вас на машине. Нужны: Mac с macOS 14 или новее, около 12 ГБ свободного места, интернет для первой
установки (модели поиска ~4.5 ГБ - или офлайн-набор `dt-models.tar`, если вам его передали).
Ничего ставить заранее не нужно: ни терминал, ни Obsidian, ни Python. Если на машине пусто, все
поставит наставник вместе с вами.

## Три шага

1. **Откройте Claude и вставьте `INSTALL.md`.** Подойдет claude.ai, Claude Desktop, Cowork,
   Claude Code или Kimi. Файл `INSTALL.md` лежит рядом с этим README (копия -
   `installer/INSTALL.md`): откройте его в любом текстовом редакторе, скопируйте весь текст и
   вставьте в новый разговор.
2. **Дальше ведет наставник.** Он коротко расскажет, что такое цифровой двойник, спросит, как вы
   работаете с компьютером, и подстроится под ответ: новичку объяснит каждый шаг, эксперту даст
   факты.
   Потом по порядку: поставит нужное (Terminal, git, `uv`, Obsidian, Claude Desktop), соберет ваш
   профиль, запустит установку, настроит поиск, возьмет ваши образцы стиля, подключит сервисы, если
   они нужны, и сделает с вами первый настоящий документ. Прервались - вставьте `INSTALL.md` снова:
   наставник начнет с записанного прогресса (`installer/state/`), а не с нуля.
3. **Если умеете сами:** поставьте `uv` (менеджер Python) и `git` (`xcode-select --install`),
   откройте новое окно Terminal и запустите установку из каталога `engine/`:

   ```
   curl -LsSf https://astral.sh/uv/install.sh | sh
   cd engine
   uv run python cli/dt.py install
   ```

   Установка задаст несколько вопросов (где vault, как вас зовут, какой ассистент подключать) и сама
   сделает остальное: настройки, каркас vault, модели поиска, плановые задания, подключение
   ассистента, первый индекс, проверку. Первый запуск соберет окружение (несколько минут, нужен
   интернет); модели поиска - самый долгий шаг, процент виден. Прервались - запустите команду снова:
   она продолжит с того же места. Что уже сделано:
   `uv run python cli/dt.py install --check`.

## Что внутри

| что | что это |
|---|---|
| `INSTALL.md` | промпт наставника: его вставляют в Claude, он ведет по установке |
| `engine/` | сам движок: код, шаблон vault `vault-template`, справка `docs`, `ops/SETUP.md` |
| `installer/` | рельсы наставника: `INSTALL.md`, `brain/` (фазы и словарь), `state/` |
| `skills/` | скиллы для ассистента (как подключить - `skills/README.md`) |

## Безопасность

Установка не просит ключей и паролей и не требует `sudo`. Ваш vault - ваши данные: установка и
`dt uninstall` его не удаляют. Секреты вы вводите только сами, в своем Terminal; наставнику их
присылать не нужно. Снять установку, оставив данные: `uv run python cli/dt.py uninstall`.
Версия - файл `VERSION`, что нового - `CHANGELOG.md`.
"""


def build_files(src: Path = ENGINE) -> tuple[dict[str, bytes], set[str]]:
    """Дерево кита ``{путь: байты}`` и множество исполняемых путей (без ``KIT-MANIFEST.json``)."""
    from core.version import engine_version

    version = engine_version(src)
    files, execs = collect_engine(src)
    files.update(_tree_of(src / "installer", "installer"))
    files["INSTALL.md"] = files["installer/INSTALL.md"]  # и в корне кита: видно сразу
    files.update(_skills_tree(src, version))
    files["README.md"] = KIT_README.encode("utf-8")
    files["VERSION"] = f"{version}\n".encode()
    changelog = src / "CHANGELOG.md"
    if changelog.is_file():
        files["CHANGELOG.md"] = changelog.read_bytes()
    return files, execs


def _skills_tree(src: Path, version: str) -> dict[str, bytes]:
    """Скиллы реестра в формате Cherry (профиль ``full``: весь набор). ``dt-owner`` не входит,
    манифест экспорта (с временной меткой) не входит - архив детерминирован."""
    import dt_skills

    from core.skills import cherry_skill_text, fit_profile, lint_skills, load_skills

    skills = [sk for sk in load_skills(src / "skills")
              if f"skills/{sk.path.parent.name}" not in EXCLUDE_PATHS]
    issues = lint_skills(skills, dt_skills.tool_names())
    if issues:
        raise KitError("скиллы не проходят линтер: " + "; ".join(str(i) for i in issues[:3]))
    fit, _skipped = fit_profile(skills, dt_skills.profile_tools("full"))
    out = {f"skills/{sk.path.parent.name}/SKILL.md": cherry_skill_text(sk, version).encode("utf-8")
           for sk in fit}
    out["skills/README.md"] = SKILLS_README.encode("utf-8")
    return out


class KitError(RuntimeError):
    """Кит не собрался: гард или вход не прошли."""


# --------------------------------------------------------------------------- гард ------------ #
def private_terms(vault: Path | None, **kwargs) -> PrivateTerms:
    """ОДИН список приватных терминов (владелец + клиенты): тот же сборщик, что у гарда тестов и
    шаблона vault (:mod:`core.owner.privacy`); ``ignore_file`` - как у сборщика."""
    from core.owner.privacy import private_terms as _terms

    return _terms(Path(vault) if vault else None, **kwargs)


def guard_files(files: Mapping[str, bytes], terms: Sequence[str]) -> list[str]:
    """Нарушения (пусто - чисто): ``файл:строка: приватный термин «…»`` (границы слова, NFC и NFD),
    токены по маске, пути ``/Users/<имя>``, запрещенные имена."""
    from core.owner.privacy import scan_text

    bad: list[str] = []
    for rel, data in sorted(files.items()):
        parts = rel.split("/")
        name = parts[-1]
        if any(fnmatch(p, g) for p in parts[:-1] for g in FORBIDDEN_PARTS):
            bad.append(f"{rel}: запрещенный каталог в архиве")
            continue
        if any(fnmatch(name, g) for g in FORBIDDEN_NAME_GLOBS):
            bad.append(f"{rel}: запрещенный файл (конфиг/секрет/производное)")
            continue
        suffix = Path(name).suffix.lower()
        if suffix in _BINARY_SUFFIXES:
            continue
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            continue
        for hit in scan_text(text, terms):
            bad.append(f"{rel}:{hit.line}: приватный термин «{hit.term}»")
        for label, mask in _TOKEN_MASKS:
            if label == "env assignment" and suffix in _CODE_SUFFIXES:
                continue
            if mask.search(text):
                bad.append(f"{rel}: похоже на токен ({label})")
        if _USERS_PATH.search(text):
            bad.append(f"{rel}: абсолютный путь в домашнем каталоге ({_HOME}<имя>)")
    return sorted(set(bad))


# --------------------------------------------------------------------------- архив ----------- #
def manifest_of(files: Mapping[str, bytes], version: str) -> bytes:
    entries = {rel: hashlib.sha256(data).hexdigest() for rel, data in sorted(files.items())}
    body = {"generator": GENERATOR, "version": version, "files": entries}
    return (json.dumps(body, ensure_ascii=False, indent=1) + "\n").encode("utf-8")


def write_zip(files: Mapping[str, bytes], execs: set[str], out: Path, version: str) -> None:
    """Детерминированный zip: порядок по имени, фиксированная дата, права 644/755, ``KIT-MANIFEST``
    первым."""
    out.parent.mkdir(parents=True, exist_ok=True)
    all_files = {MANIFEST: manifest_of(files, version), **files}
    tmp = out.with_suffix(out.suffix + ".part")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel in [MANIFEST, *sorted(files)]:
            info = zipfile.ZipInfo(f"dt-starter-kit/{rel}", ZIP_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (0o755 if rel in execs else 0o644) << 16
            zf.writestr(info, all_files[rel], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    tmp.replace(out)


def zip_contents(path: Path) -> dict[str, bytes]:
    """Содержимое кита ``{путь без dt-starter-kit/: байты}``; выход за корень - отказ."""
    out: dict[str, bytes] = {}
    with zipfile.ZipFile(path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            name = info.filename
            if name.startswith("/") or ".." in Path(name).parts or not name.startswith(
                    "dt-starter-kit/"):
                raise KitError(f"запись вне корня кита: {name}")
            out[name.removeprefix("dt-starter-kit/")] = zf.read(info)
    return out


def tree_summary(files: Mapping[str, bytes]) -> list[str]:
    """Верхний уровень: ``имя  файлов  КБ``."""
    sizes: dict[str, list[int]] = {}
    for rel, data in files.items():
        top = rel.split("/", 1)[0] + ("/" if "/" in rel else "")
        row = sizes.setdefault(top, [0, 0])
        row[0] += 1
        row[1] += len(data)
    return [f"  {name:<14} {n:5d} файлов {size / 1024:9.1f} КБ"
            for name, (n, size) in sorted(sizes.items())]


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--vault", default=None,
                        help="боевой vault: из него берутся приватные термины для гарда (читается)")
    parser.add_argument("--no-owner-terms", action="store_true",
                        help="собрать без проверки приватных терминов (только для проб; "
                             "остальные гарды работают)")
    parser.add_argument("--privacy-ignore", default=str(ENGINE / "scripts" / "privacy-ignore.txt"),
                        help="файл исключений из списка приватных терминов (решение владельца)")
    parser.add_argument("--src", default=str(ENGINE), help="каталог движка (по умолчанию этот)")
    parser.add_argument("--out", default=None,
                        help="путь zip (по умолчанию dist/dt-starter-kit-<версия>.zip)")
    parser.add_argument("--check", action="store_true", help="не писать: код 1, если zip иной")
    args = parser.parse_args(argv)

    src = Path(args.src).expanduser().resolve()
    from core.version import engine_version

    version = engine_version(src)
    out = Path(args.out) if args.out else src / "dist" / f"dt-starter-kit-{version}.zip"
    if args.vault is None and not args.no_owner_terms:
        print("нужен --vault (боевой vault для списка приватных терминов) либо явный "
              "--no-owner-terms", file=sys.stderr)
        return 2
    from core.owner.privacy import PrivacyError

    try:
        listed = (PrivateTerms((), ()) if args.no_owner_terms
                  else private_terms(Path(args.vault).expanduser().resolve(),
                                     ignore_file=Path(args.privacy_ignore)))
        listed.require_clean_ignore()
    except PrivacyError as exc:
        print(f"список приватных терминов не собран: {exc}", file=sys.stderr)
        return 2
    terms = listed.all
    if not args.no_owner_terms and not listed.owner:
        print("в owner.yaml нет терминов владельца: гард без них бессмысленен "
              "(--no-owner-terms, если так и задумано)", file=sys.stderr)
        return 2
    try:
        files, execs = build_files(src)
    except KitError as exc:
        print(f"кит не собран: {exc}", file=sys.stderr)
        return 1
    bad = guard_files(files, terms)
    if not bad and args.check and terms:
        # ``--check`` зелен только при нуле совпадений в ОБОИХ проходах: этом и независимом (verify)
        from verify_starter_kit import independent_hits

        bad = [f"{rel}:{line}: приватный термин «{term}» (независимый проход)"
               for rel, line, term in independent_hits(files, terms)]
    if bad:
        print("гард утечек не пройден, zip не записан:" if not args.check
              else "гард утечек не пройден:", file=sys.stderr)
        for line in bad[:40]:
            print(f"  {line}", file=sys.stderr)
        if len(bad) > 40:
            print(f"  ... и еще {len(bad) - 40}", file=sys.stderr)
        return 1
    if args.check:
        if not out.is_file():
            print(f"{out}: нет файла - нечего сверять")
            return 1
        with tempfile.TemporaryDirectory() as tmp:
            fresh = Path(tmp) / "fresh.zip"
            write_zip(files, execs, fresh, version)
            same = zip_contents(fresh) == zip_contents(out)
        print("кит совпадает с пересборкой" if same else "кит НЕ совпадает с пересборкой")
        return 0 if same else 1
    write_zip(files, execs, out, version)
    total = sum(len(d) for d in files.values())
    print(f"{out}: {len(files)} файлов, {total / 1048576:.1f} МБ распакованно, "
          f"{out.stat().st_size / 1048576:.1f} МБ в архиве; гард чист "
          f"({len(listed.owner)} терминов владельца + {len(listed.clients) + len(listed.others)} "
          "клиентов и хабов, маски токенов, пути, запрещенные имена)")
    print("состав верхнего уровня:")
    for line in tree_summary({MANIFEST: manifest_of(files, version), **files}):
        print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
