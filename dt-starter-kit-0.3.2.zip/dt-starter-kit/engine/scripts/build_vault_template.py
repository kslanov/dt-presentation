"""DEV-3-CORE п.3: сгенерировать ``engine/vault-template/`` - каркас vault для второго человека.

Шаблон ГЕНЕРИРУЕТСЯ, руками не правится: вход - боевой vault ТОЛЬКО НА ЧТЕНИЕ, выход - дерево
``vault-template/`` с манифестом хэшей ``_generated.json`` (тест сверяет файлы с манифестом: ручная
правка видна). Из боевого vault берется то, что по построению generic и без данных владельца:

* ``_system/retrieval-policies/*.yaml`` - политики поиска как есть, кроме приватных терминов
  (KIT-PRIVACY-1: тег/имя корпоративной базы владельца → ``company``);
* ``_system/style-guides/ai-markers.yaml`` - канон ИИ-маркеров;
* ``_system/freshness-markers.yaml`` - маркеры черновика/архива в именах файлов;
* ``_system/style-guides/<жанр>.md`` - ТОЛЬКО скелет (id/genre и заголовки разделов): текст стиля
  автора в шаблон не идет.

Остальное сочиняет сам генератор: README папок, пустые ``ingest-roots``/``host-access``, образец
``mail-filter`` (нейтральный запасной набор движка), два примера золотого набора, шаблоны профиля
(как у ``dt owner init``). Гарды сборки: ни один выходной файл не содержит приватных терминов
боевого ``owner.yaml`` (имя, фамилии, домены, компания) и в папках ``02-knowledge``/``04-clients``/
``07-outputs`` лежит только README; нарушение - код 1, дерево не пишется.

Usage:
    uv run python scripts/build_vault_template.py --vault ../../vault          # собрать
    uv run python scripts/build_vault_template.py --vault ../../vault --check  # код 1, если
                                                                              # дерево иное
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

ENGINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE))

from core.legacy.mail_filter import DEFAULT_YAML as MAIL_FILTER_SAMPLE  # noqa: E402
from core.owner.init import ABOUT_TEMPLATE, RULES_TEMPLATE, render_owner_yaml  # noqa: E402
from core.vault import TEMPLATE_README_MARKER  # noqa: E402

TEMPLATE_DIR = ENGINE / "vault-template"
MANIFEST = "_generated.json"
GENERATOR = "scripts/build_vault_template.py"

#: папки боевого vault, из которых в шаблон не копируется ничего (в шаблоне - только свой README)
FORBIDDEN_COPY = ("02-knowledge", "04-clients", "07-outputs", "_legacy")

_README_TOP = """\
# Vault Digital Twin

Это ваш vault: заметки, образцы стиля и настройки движка. Движок (Digital Twin) его читает и
индексирует; в vault пишет только он сам (инструменты DT, атомарная запись, провенанс), шеллом и
скриптами - не пишем.

| Папка | Что здесь |
|---|---|
| `01-style/` | образцы вашего стиля: письма, отчеты, доклады, стратегии |
| `02-knowledge/` | знания: отрасли, продукты, направления (хабы сущностей) |
| `03-projects/` | проекты и пресейлы (хабы проектов) |
| `04-clients/` | клиенты (хабы клиентов) |
| `06-templates/` | шаблоны заметок и хабов |
| `07-outputs/` | результаты работы ассистента (контур выхода) |
| `_staging/` | захваты до разбора (`inbox/`) |
| `_system/` | настройки vault: политики поиска, гайды стиля, профиль владельца, фильтры |

Начало работы - `engine/ops/SETUP.md`: `dt config init` → `dt vault init` (этот каркас) →
`dt owner init` → первый `dt_index` → `dt doctor`.
"""

_READMES: dict[str, str] = {
    "01-style": """\
# 01-style - образцы вашего стиля

Что здесь лежит: по подпапкам-жанрам (`letters/`, `reports/`, `speeches/`, `strategy/`,
`analyses/`) - ваши настоящие тексты, 5-10 образцов на жанр. Это материал, из которого
складывается стиль: по образцам пишется гайд жанра (`_system/style-guides/<жанр>.md`).

Что делает движок: подбирает образцы при генерации (`find_exemplar`), берет оформление образца
как шаблон; сами тексты наружу не отдает. Свои тексты кладите через `dt ingest`/`store_file`,
а не копированием в обход движка.
""",
    "02-knowledge": """\
# 02-knowledge - знания

Что здесь лежит: хабы сущностей - отрасли, продукты, направления (по одному файлу на сущность с
frontmatter `type: hub`, `entity: industry|product|direction`). Хаб собирает ссылки на заметки
и документы по теме.

Что делает движок: линкует новые заметки к хабам (`dt link`), предлагает связи карточками в
пульте, поднимает состояние хаба по запросу (`hub-synth`). Хабы заводит скилл `new-hub`
или вы сами по шаблону из `06-templates/`.
""",
    "03-projects": """\
# 03-projects - проекты и пресейлы

Что здесь лежит: хабы проектов (`entity: project`) и пресейлов - цель, объем, стадия, связи с
клиентом и продуктом. Шаблон хаба - `06-templates/`.

Что делает движок: линкует к хабу письма, документы и заметки по проекту, показывает «забытые
темы» и состояние в пульте. Если подключен CRM-коннектор, у хаба появляется `timetta_id`.
""",
    "04-clients": """\
# 04-clients - клиенты

Что здесь лежит: хабы клиентов (`entity: client`), у каждого `aliases` - разные написания имени
(по ним движок узнает клиента в письмах и файлах).

Что делает движок: привязывает переписку и документы к хабу клиента, ищет «все по клиенту»
(`find_notes`), готовит досье для письма и встречи.
""",
    "06-templates": """\
# 06-templates - шаблоны

Что здесь лежит: шаблоны заметок и хабов (письма, презентации, отчеты). Движок их не индексирует
как знание: это заготовки, из которых вы или ассистент создаете новые документы.
""",
    "07-outputs": """\
# 07-outputs - результаты ассистента

Что здесь лежит: по папке на каждый артефакт, который ассистент сделал для вас (письмо, справка,
отчет): сам файл, постановка задачи и провенанс (`sources.md` - откуда взято). Папки создает
контур выхода (`output_begin` / `save_output`), руками сюда ничего не кладите.

Что делает движок: проверяет текст по канону ИИ-маркеров, ведет журнал источников и держит выходы
вне обычного поиска (черновики и пробные прогоны - в карантине).
""",
    "_staging": """\
# _staging - захваты до разбора

`inbox/` - сюда ложатся быстрые захваты (заметки, ссылки, мысли с тегами) до разбора. Движок
сам не решает, куда их положить: разбор - словами в чате (скилл `inbox-triage`) или карточкой в
пульте. Папка вне индекса: после разбора заметка переезжает в свою папку vault.
""",
    "_system": """\
# _system - настройки vault

Файлы, которые движок читает, но не индексирует как знание:

- `profile/` - вы: `owner.yaml` (имя, почты, компания, домены), `about.md` (идет в промпт
  генерации), `rules.md` (правила для ассистентов); создает `dt owner init`;
- `retrieval-policies/` - как искать под каждый кейс генерации;
- `style-guides/` - канон ИИ-маркеров и гайды жанров (шаблоны: заполните по своим образцам);
- `ingest-roots.yaml` - папки с вашими файлами, которые движок забирает в vault;
- `host-access.yaml` - каким ассистентам (хостам) какие папки выданы;
- `mail-filter.yaml` - что считать шумом в почте (нужно только при подключенной почте);
- `freshness-markers.yaml` - слова «черновик»/«архив» в именах файлов;
- `eval/` - золотой набор запросов к поиску (качество выдачи);
- `prompts/`, `guide/` - заготовки и справка.
""",
}

_PROMPTS_README = """\
# prompts - заготовки промптов vault

Пока пусто: движок берет промпты из своего репозитория. Сюда кладите свои заготовки, если
захотите переопределить поведение для своего vault.
"""

_GUIDE_README = """\
# guide - справка по системе

Рабочий гайд живет в репозитории движка: `docs/02-architecture.md` (устройство),
`docs/08-tools-reference.md` (инструменты, собирается из кода), `ops/SETUP.md` (установка). Сюда
кладите свои заметки об устройстве вашего vault.
"""

_INGEST_ROOTS = """\
# Корни ingest файлов (INGEST-1): папки, откуда движок забирает ваши файлы в vault.
# Пусто - файловый ingest не настроен. Добавить корень:
#
# roots:
#   - name: work-docs
#     path: /абсолютный/путь/к/папке
#     route: knowledge        # knowledge - в знания и индекс | operational - реестр источников
#     include: ['**/*']
#     exclude: ['**/~$*']
#
# Папки с маркером _nda (сегмент или суффикс) не идут ни в индекс, ни в промпт, ни хостам.
roots: []
"""

_HOST_ACCESS = """\
# Доступ хостов к папкам (host-access): реестр того, что выдано каждому ассистенту (MCP-хосту).
# Один набор правил для всех хостов: чтение напрямую допустимо, запись в vault - только
# инструментами DT, папки _nda не выдаются никому. Файл - реестр выданного: движок его только
# читает (доктор «Доступ хостов», пульт «Мониторинг»); что хост видит на деле, определяет сам хост.
#
# Ключ - имя хоста из MCP-handshake (clientInfo.name); aliases - другие имена того же хоста.
# Пример записи:
#
# claude-ai:
#   aliases: []
#   folders:
#     - /абсолютный/путь/к/рабочей/папке
#   granted: 2026-01-01
#   note: Claude Desktop
#
# Новый хост доктор подсветит сам: «Хосты без записи в host-access».
"""

_GOLDEN = """\
# Золотой набор запросов к выдаче (EVAL-1): примеры. Замените своими, когда появятся заметки.
#
# Запрос = вызов инструмента чтения + ожидание. Прогон: `uv run python cli/dt_eval.py`; метрики
# recall@5, MRR, hub@3; история - .derived/eval/history.jsonl. Пока набор из заглушек, метрика
# считает честную пустоту: «заметок нет» - это ожидаемый ответ, а не ошибка.
#
# Поля запроса: id (q01…, не менять у живых), тип, вызов {tool, args}, ожидание (note_ids | any_of |
# hub | notes_empty | warning none|any|<код> | ...), источник (проверено | гипотеза), заметка.
# «Гипотеза» прогоняется, но в метрику не входит, пока вы не поменяете на «проверено».

queries:
  - id: q01
    тип: клиент
    вызов: {tool: find_notes, args: {query: "пример клиента"}}
    ожидание: {notes_empty: true}
    источник: гипотеза
    заметка: "заглушка: после первых заметок замените на реальный хаб клиента и note_ids"

  - id: q02
    тип: тема
    вызов: {tool: find_notes, args: {query: "пример темы"}}
    ожидание: {notes_empty: true}
    источник: гипотеза
    заметка: "заглушка: замените на реальный запрос по вашей теме"
"""

_STYLE_HINT = (
    "<!-- Шаблон раздела: опишите по своим образцам из 01-style/{folder}, 2-4 пункта, без цитат.\n"
    "     Гайд инжектируется в промпт перед образцами и retrieval-контекстом. -->"
)
_STYLE_FOLDERS = {"letter": "letters", "analysis": "analyses", "speech": "speeches",
                  "strategy": "strategy", "report": "reports"}


class TemplateError(RuntimeError):
    """Гард сборки не прошел: в шаблон попало лишнее."""


def _read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _style_skeleton(text: str, stem: str) -> str:
    """Скелет гайда жанра: id/type/genre из frontmatter + заголовки; тексты автора не берутся."""
    meta: dict[str, str] = {}
    body = text
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            for line in text[3:end].splitlines():
                key, _, value = line.partition(":")
                if key.strip() in ("id", "type", "genre"):
                    meta[key.strip()] = value.strip().strip('"')
            body = text[end + 4:]
    h1 = next((ln for ln in body.splitlines() if ln.startswith("# ")), f"# Style guide - {stem}")
    h2 = [ln for ln in body.splitlines() if ln.startswith("## ") and "НЕ делать" not in ln]
    h2.append("## Чего НЕ делать")
    genre = meta.get("genre", stem)
    hint = _STYLE_HINT.format(folder=_STYLE_FOLDERS.get(genre, stem))
    head = "\n".join(f"{k}: {v}" for k, v in meta.items())
    parts = [f"---\n{head}\nstatus: template\n---", h1, ""]
    for heading in h2:
        parts += [heading, "", hint, ""]
    return "\n".join(parts).rstrip() + "\n"


def private_terms(vault: Path, **kwargs) -> list[str]:
    """Приватные термины vault: владелец + клиенты - ОДИН сборщик с гардом тестов и кита
    (:mod:`core.owner.privacy`, KIT-PRIVACY-1); ``ignore_file`` - как у сборщика."""
    from core.owner.privacy import private_terms as _terms

    return _terms(Path(vault), **kwargs).all


def _readme(text: str) -> str:
    """README каркаса с маркером первой строкой: движок такие файлы за знание не считает."""
    return TEMPLATE_README_MARKER + " (не знание: в индекс не идет) -->\n" + text


def build_files(vault: Path) -> dict[str, str]:
    """Дерево шаблона ``{путь: текст}``: боевой vault (только чтение) + константы генератора."""
    system = vault / "_system"
    files: dict[str, str] = {"README.md": _readme(_README_TOP)}
    for folder, text in _READMES.items():
        files[f"{folder}/README.md"] = _readme(text)
    files["_system/prompts/README.md"] = _PROMPTS_README
    files["_system/guide/README.md"] = _GUIDE_README
    files["_system/ingest-roots.yaml"] = _INGEST_ROOTS
    files["_system/host-access.yaml"] = _HOST_ACCESS
    files["_system/mail-filter.yaml"] = MAIL_FILTER_SAMPLE
    files["_system/eval/golden-queries.yaml"] = _GOLDEN
    # профиль: шаблоны ``dt owner init`` (пустой owner.yaml - init его дозаполнит из .env)
    owner = render_owner_yaml()
    files["_system/profile/owner.yaml"] = "\n".join(
        ln for ln in owner.splitlines() if not ln.startswith("updated:")) + "\n"
    files["_system/profile/about.md"] = ABOUT_TEMPLATE
    files["_system/profile/rules.md"] = RULES_TEMPLATE
    from core.owner.privacy import private_terms as _terms
    from core.owner.privacy import replace_terms

    terms = _terms(vault).all
    for src in sorted((system / "retrieval-policies").glob("*.yaml")):
        text = replace_terms(_read(src), terms, "company")
        files[f"_system/retrieval-policies/{src.name}"] = text
    for name in ("style-guides/ai-markers.yaml", "freshness-markers.yaml"):
        if (system / name).is_file():
            files[f"_system/{name}"] = _read(system / name)
    for src in sorted((system / "style-guides").glob("*.md")):
        files[f"_system/style-guides/{src.name}"] = _style_skeleton(_read(src), src.stem)
    return files


def guard(files: dict[str, str], terms: list[str]) -> None:
    """Гарды: нет приватных терминов, в запретных папках только README."""
    bad: list[str] = []
    for rel, text in files.items():
        top = rel.split("/", 1)[0]
        if top in FORBIDDEN_COPY and rel != f"{top}/README.md":
            bad.append(f"{rel}: файл в запретной папке")
        from core.owner.privacy import scan_text

        for hit in scan_text(text, terms):
            bad.append(f"{rel}:{hit.line}: приватный термин «{hit.term}»")
    if bad:
        raise TemplateError("; ".join(bad))


def manifest_of(files: dict[str, str]) -> str:
    entries = {rel: hashlib.sha256(text.encode("utf-8")).hexdigest() for rel, text in files.items()}
    return json.dumps({"generator": GENERATOR, "files": dict(sorted(entries.items()))},
                      ensure_ascii=False, indent=2) + "\n"


def write_tree(files: dict[str, str], out: Path) -> None:
    if out.exists():
        shutil.rmtree(out)
    for rel, text in files.items():
        target = out / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    (out / MANIFEST).write_text(manifest_of(files), encoding="utf-8")


def current_tree(out: Path) -> dict[str, str]:
    return {p.relative_to(out).as_posix(): _read(p) for p in sorted(out.rglob("*"))
            if p.is_file() and p.name != MANIFEST}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--vault", required=True, help="боевой vault (читается, не меняется)")
    parser.add_argument("--out", default=str(TEMPLATE_DIR))
    parser.add_argument("--privacy-ignore", default=str(ENGINE / "scripts" / "privacy-ignore.txt"),
                        help="файл исключений из списка приватных терминов (решение владельца)")
    parser.add_argument("--check", action="store_true", help="не писать: код 1, если дерево иное")
    args = parser.parse_args(argv)
    vault = Path(args.vault).expanduser().resolve()
    out = Path(args.out)
    files = build_files(vault)
    try:
        from core.owner.privacy import PrivacyError
        from core.owner.privacy import private_terms as _listed

        listed = _listed(vault, ignore_file=Path(args.privacy_ignore))
        listed.require_clean_ignore()
        guard(files, listed.all)
    except (TemplateError, PrivacyError) as exc:
        print(f"гард шаблона не пройден: {exc}", file=sys.stderr)
        return 1
    if args.check:
        same = out.is_dir() and current_tree(out) == files
        print("vault-template совпадает с входом" if same else "vault-template НЕ совпадает")
        return 0 if same else 1
    write_tree(files, out)
    print(f"{out}: {len(files)} файлов + {MANIFEST}")
    renamed = [rel for rel in files if rel.startswith("_system/retrieval-policies/")
               and _read(vault / rel) != files[rel]]
    if renamed:
        print(f"политики: приватные термины заменены на «company» в {len(renamed)} файлах "
              "(данные боевого vault не меняются)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
