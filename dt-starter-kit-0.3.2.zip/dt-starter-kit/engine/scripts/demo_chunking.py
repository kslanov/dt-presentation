"""Demo: read a vault note and print its chunks (heading_path + metadata).

Usage:
    uv run python scripts/demo_chunking.py tests/fixtures/report_large.md
"""

from __future__ import annotations

import sys
from pathlib import Path

from core.chunking import chunk_note, count_tokens
from core.vault import read_note


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(__doc__)
        return 1

    note = read_note(Path(argv[1]))
    chunks = chunk_note(note)

    print(f"note id   : {note.id}")
    print(f"note type : {note.type}")
    print(f"chunks    : {len(chunks)}")
    print("=" * 70)

    for chunk in chunks:
        path = " > ".join(chunk.heading_path) or "(document root)"
        preview = chunk.text.replace("\n", " ")
        if len(preview) > 120:
            preview = preview[:117] + "..."
        print(f"\n[chunk {chunk.chunk_index}] ~{count_tokens(chunk.text)} tokens")
        print(f"  heading_path: {path}")
        print(f"  metadata    : {chunk.metadata}")
        print(f"  text        : {preview}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
