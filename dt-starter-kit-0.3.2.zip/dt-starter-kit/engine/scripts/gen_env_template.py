"""Сгенерировать ``ops/env.template`` из реестра настроек (CONFIG-1 п.3).

Usage:
    uv run python scripts/gen_env_template.py          # записать ops/env.template
    uv run python scripts/gen_env_template.py --check  # код 1, если файл не совпадает с реестром
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.config.env_template import TEMPLATE_REL, render  # noqa: E402


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--check", action="store_true", help="только сверить, не писать")
    args = ap.parse_args(argv)
    target = ENGINE_ROOT / TEMPLATE_REL
    text = render()
    if args.check:
        same = target.is_file() and target.read_text(encoding="utf-8") == text
        print(f"{target}: {'совпадает с реестром' if same else 'ОТСТАЕТ от реестра'}")
        return 0 if same else 1
    target.write_text(text, encoding="utf-8")
    print(f"записано {target} ({len(text.splitlines())} строк)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
