"""Скан настроек ``DT_*`` в коде (CONFIG-1 п.1): имя → места, где оно встречается как строка.

Что считается «настройкой в коде»: **целая строковая константа** ``"DT_X"`` в ``.py``
(``os.environ.get("DT_X")``, ``_env_int("DT_X", …)``, ``ENV = "DT_X"``,
``monkeypatch.setenv("DT_X", …)``)
и любое вхождение в ``.sh``/``.plist`` каталога ``ops``. Упоминания в докстрингах, комментариях и
``*.md`` настройкой не считаются: это текст, а не чтение (опечатка в сообщении об ошибке не должна
требовать записи в реестре). Реестр (``core/config/knobs.py``) и шаблон ``ops/env.template``
из скана исключены - они и есть «список».

Гард-тест ``tests/test_config_knobs.py`` требует: множество найденных имён == множество в реестре.

Usage:
    uv run python scripts/knobs_scan.py            # таблица: имя, где читается, число мест
    uv run python scripts/knobs_scan.py --names    # только имена (по одному на строку)
    uv run python scripts/knobs_scan.py --json
"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path

ENGINE_ROOT = Path(__file__).resolve().parents[1]

#: Каталоги скана (относительно корня engine/).
SCAN_DIRS = ("core", "mcp-server", "webpult", "cli", "ops", "tests", "scripts")

#: Файлы, которые сами «список имён» (в скан не входят).
EXCLUDE = frozenset({"core/config/knobs.py", "scripts/knobs_scan.py"})

NAME_RE = re.compile(r"\bDT_[A-Z0-9_]*[A-Z0-9]\b")
_EXACT_RE = re.compile(r"DT_[A-Z0-9_]*[A-Z0-9]")
_SKIP_PARTS = {"__pycache__", ".venv", "node_modules", ".derived"}


@dataclass(frozen=True)
class Site:
    path: str  # относительно engine/
    line: int

    @property
    def is_test(self) -> bool:
        return self.path.startswith("tests/")


def _iter_files(root: Path) -> Iterable[Path]:
    for d in SCAN_DIRS:
        base = root / d
        if not base.is_dir():
            continue
        for p in sorted(base.rglob("*")):
            if not p.is_file() or _SKIP_PARTS & set(p.parts):
                continue
            if p.suffix == ".py" or (d == "ops" and p.suffix in {".sh", ".plist"}):
                yield p


def _py_sites(text: str) -> list[tuple[str, int]]:
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return []
    return [
        (n.value, n.lineno)
        for n in ast.walk(tree)
        if isinstance(n, ast.Constant)
        and isinstance(n.value, str)
        and _EXACT_RE.fullmatch(n.value)
    ]


def scan(root: Path | None = None) -> dict[str, list[Site]]:
    """Имя ``DT_*`` → места (файл:строка). Порядок мест стабилен (по пути, по строке)."""
    root = Path(root) if root is not None else ENGINE_ROOT
    found: dict[str, list[Site]] = {}
    for path in _iter_files(root):
        rel = path.relative_to(root).as_posix()
        if rel in EXCLUDE:
            continue
        text = path.read_text(encoding="utf-8", errors="ignore")
        if path.suffix == ".py":
            hits = _py_sites(text)
        else:
            hits = [
                (m.group(), text.count("\n", 0, m.start()) + 1) for m in NAME_RE.finditer(text)
            ]
        for name, line in hits:
            found.setdefault(name, []).append(Site(rel, line))
    return found


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--names", action="store_true", help="только имена")
    ap.add_argument("--json", action="store_true", help="JSON: имя → [файл:строка]")
    args = ap.parse_args(argv)
    found = scan()
    if args.json:
        out = {k: [f"{s.path}:{s.line}" for s in v] for k, v in sorted(found.items())}
        print(json.dumps(out, ensure_ascii=False, indent=1))
    elif args.names:
        print("\n".join(sorted(found)))
    else:
        for name in sorted(found):
            sites = found[name]
            prod = [s for s in sites if not s.is_test]
            first = (prod or sites)[0]
            kind = "код" if prod else "только тесты"
            print(f"{name:42s} {kind:13s} {len(sites):3d}  {first.path}:{first.line}")
        print(f"\nвсего имён: {len(found)}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
