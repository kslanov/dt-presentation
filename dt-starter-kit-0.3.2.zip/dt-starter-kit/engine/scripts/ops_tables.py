"""Сгенерировать таблицы ``ops/README.md`` из реестров (SURFACE-HYGIENE-1 п.5, R11).

Режимы ``dt_sync`` (шаги по порядку) берутся из ``cli/dt_sync.MODES``, задания launchd - из
``ops/launchd/*.plist``. Блок между маркерами README переписывается целиком; рядом лежит гард
``tests/test_cli_inventory.py`` (файл = генератор, байт в байт): описание не дрейфует от кода.

Usage:
    uv run python scripts/ops_tables.py            # переписать блок в ops/README.md
    uv run python scripts/ops_tables.py --check    # код 1, если блок не совпадает с реестрами
"""

from __future__ import annotations

import argparse
import plistlib
import sys
from pathlib import Path
from typing import Any

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))
sys.path.insert(0, str(ENGINE_ROOT / "cli"))

README = ENGINE_ROOT / "ops" / "README.md"
PLIST_DIR = ENGINE_ROOT / "ops" / "launchd"
BEGIN = "<!-- ops-tables:begin -->"
END = "<!-- ops-tables:end -->"
_WEEKDAYS = {0: "вс", 1: "пн", 2: "вт", 3: "ср", 4: "чт", 5: "пт", 6: "сб"}


def _duration(seconds: int) -> str:
    if seconds % 3600 == 0:
        return f"{seconds // 3600} ч"
    if seconds % 60 == 0:
        return f"{seconds // 60} мин"
    return f"{seconds} с"


def _calendar(item: dict[str, Any]) -> str:
    when = f"{int(item.get('Hour', 0)):02d}:{int(item.get('Minute', 0)):02d}"
    day = item.get("Weekday")
    return f"{_WEEKDAYS.get(int(day), str(day))} {when}" if day is not None else when


def schedule_of(plist: dict[str, Any]) -> str:
    parts: list[str] = []
    if plist.get("KeepAlive"):
        parts.append("постоянно (KeepAlive)")
    if "StartInterval" in plist:
        parts.append(f"каждые {_duration(int(plist['StartInterval']))}")
    cal = plist.get("StartCalendarInterval")
    if cal:
        items = cal if isinstance(cal, list) else [cal]
        parts.append(", ".join(_calendar(i) for i in items))
    if plist.get("RunAtLoad"):
        parts.append("при загрузке")
    return " · ".join(parts) or "вручную"


def command_of(plist: dict[str, Any]) -> str:
    """Что запускается: аргументы после ``uv run [--extra …] python`` (без шаблонных путей)."""
    args = [str(a) for a in plist.get("ProgramArguments", []) if not str(a).startswith("__")]
    if "python" in args:
        args = args[args.index("python") + 1:]
    return " ".join(args)


def jobs() -> list[tuple[str, str, str]]:
    rows = []
    for path in sorted(PLIST_DIR.glob("*.plist")):
        data = plistlib.loads(path.read_bytes())
        rows.append((str(data.get("Label") or path.stem), schedule_of(data), command_of(data)))
    return rows


def modes() -> list[tuple[str, str]]:
    """Шаги режимов рабочей роли при ВСЕХ включенных коннекторах: таблица описывает полную цепочку,
    а не то, что включено у машины, на которой гоняют генератор (DEV-3-CORE)."""
    import os

    import dt_sync

    previous = os.environ.get("DT_CONNECTORS")
    os.environ["DT_CONNECTORS"] = "timetta,ticktick,outlook"
    try:
        dt_sync._rebuild_modes()
        return [(name, " → ".join(step for step, _ in dt_sync.MODES[name]))
                for name in ("fast", "index", "full")]
    finally:
        if previous is None:
            os.environ.pop("DT_CONNECTORS", None)
        else:
            os.environ["DT_CONNECTORS"] = previous
        dt_sync._rebuild_modes()


def render_block() -> str:
    lines = [BEGIN,
             "<!-- генерируется: scripts/ops_tables.py; гард tests/test_cli_inventory.py -->",
             "", "### Режимы `dt_sync` (из `cli/dt_sync.MODES`)", "",
             "| Режим | Шаги по порядку |", "|---|---|"]
    lines += [f"| `{name}` | {steps} |" for name, steps in modes()]
    lines += ["", "### Задания launchd (из `ops/launchd/*.plist`)", "",
              "| Задание | Расписание | Запуск |", "|---|---|---|"]
    lines += [f"| `{label}` | {when} | `{cmd}` |" for label, when, cmd in jobs()]
    lines += ["", END]
    return "\n".join(lines)


def current_block(text: str) -> str | None:
    if BEGIN not in text or END not in text:
        return None
    return text[text.index(BEGIN):text.index(END) + len(END)]


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--check", action="store_true", help="только сверить, не писать")
    args = ap.parse_args(argv)
    text = README.read_text(encoding="utf-8")
    old = current_block(text)
    new = render_block()
    if args.check:
        same = old == new
        print(f"{README}: {'совпадает с реестрами' if same else 'ОТСТАЕТ от реестров'}")
        return 0 if same else 1
    if old is None:
        print(f"в {README} нет маркеров {BEGIN!r} / {END!r}", file=sys.stderr)
        return 2
    README.write_text(text.replace(old, new), encoding="utf-8")
    print(f"переписан блок ops-tables в {README}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
