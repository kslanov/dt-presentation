"""RETR-CHUNK-1 п.11 — канарейка-2 «покрытие золотого набора» (боевой индекс и vault НЕ трогаются).

Подмножество = все заметки, которые ждёт golden (note_ids/any_of/current_ids/hub/path_contains и
note_id читающих вызовов) + все заметки, привязанные к хабам из ожиданий (``[[hub]]`` в теле или
``client/project/product`` frontmatter = id/имя хаба). Три индекса подмножества в песочнице
``<base>/<variant>/derived``:

* ``a`` — чанкер main (клон боевого ``lancedb`` ``cp -c``, строки вне подмножества удалены);
* ``b`` — новый чанкер, префикс в тексте и в векторе (``DT_CHUNK_CONTEXT_PREFIX=1``);
* ``v`` — новый чанкер, префикс только в FTS, вектор по телу (``=fts``).

``b`` и ``v`` строятся ``reindex(rechunk=True)`` ПОВЕРХ клона ``a`` (так, как пойдёт боевой
``dt_index --rechunk``): векторы чанков с неизменённым текстом переиспользуются, эмбеддится
остальное. Маяк — ``<base>/<variant>/progress.json`` (число эмбеддингов, темп, оценка).

Usage:
    uv run python scripts/retr_chunk_canary2.py subset --base <dir>
    uv run python scripts/retr_chunk_canary2.py build  --base <dir> --variant a
    uv run python scripts/retr_chunk_canary2.py prune --base <dir>   # then: build a
    uv run python scripts/retr_chunk_canary2.py build  --base <dir> --variant b|v
    uv run python scripts/retr_chunk_canary2.py eval   --base <dir> --variant a|b|v [--code <tree>]
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

ENGINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE))
sys.path.insert(0, str(ENGINE / "cli"))

HUB_PREFIXES = ("client-", "project-", "product-", "org-", "direction-", "industry-")
VARIANT_ENV = {"a": None, "b": "1", "v": "fts"}


def _vault() -> Path:
    from core.config import default_vault_path

    return default_vault_path()


def _live() -> Path:
    from core.config import WORKSPACE_ROOT

    return WORKSPACE_ROOT / ".derived"


def _subset_file(base: Path) -> Path:
    return base / "subset2.json"


def cmd_subset(args: argparse.Namespace) -> int:
    from core.eval import expected_refs, golden_path, load_golden
    from core.vault import iter_vault_paths, read_note

    base = Path(args.base)
    base.mkdir(parents=True, exist_ok=True)
    vault = _vault()
    queries = [q for q in load_golden(golden_path()) if q.verified]
    manifest = json.loads((_live() / "index_manifest.json").read_text("utf-8"))
    refs: dict[str, str] = {}
    path_subs: list[str] = []
    for q in queries:
        for ref in expected_refs(q):
            refs[ref] = q.id
        for exp in [q.expect, *(c.expect or {} for c in q.calls)]:
            path_subs += [str(s) for s in exp.get("path_contains") or []]
    chosen: dict[str, dict[str, str]] = {}

    def add(nid: str, why: str) -> None:
        entry = manifest.get(nid)
        if entry and entry.get("path"):
            chosen.setdefault(nid, {"path": entry["path"], "why": why})

    for ref in refs:
        add(ref, f"golden:{refs[ref]}")
    for nid, entry in manifest.items():
        if any(s in str(entry.get("path", "")) for s in path_subs):
            add(nid, "golden:path")
    hubs = {r for r in refs if r.startswith(HUB_PREFIXES)}
    # хабы из ожиданий + хабы, на которые ссылаются ожидаемые заметки (client/project)
    for nid in list(chosen):
        path = vault / chosen[nid]["path"]
        try:
            note = read_note(path, vault)
        except Exception:
            continue
        for key in ("client", "project", "product", "deal"):
            vals = note.frontmatter.get(key)
            for v in vals if isinstance(vals, list) else [vals]:
                if v and str(v).startswith(HUB_PREFIXES):
                    hubs.add(str(v))
    names: set[str] = set()
    for hub in hubs:
        add(hub, "hub")
        entry = manifest.get(hub)
        if not entry:
            continue
        try:
            note = read_note(vault / entry["path"], vault)
        except Exception:
            continue
        for key in ("title", "aliases"):
            vals = note.frontmatter.get(key)
            for v in vals if isinstance(vals, list) else [vals]:
                if v:
                    names.add(str(v).strip().casefold())
    link_res = {h: re.compile(r"\[\[" + re.escape(h) + r"(\||\]\])") for h in hubs}
    fm_re = re.compile(r"^(?:client|project|product):\s*['\"]?(.+?)['\"]?\s*$", re.M)
    by_path = {e.get("path"): nid for nid, e in manifest.items() if e.get("path")}
    # пассаж 1: сколько заметок ссылается на каждый хаб — «общие» хабы (своя организация, на неё
    # ссылается чуть не весь корпус) подмножество раздули бы до всего vault, их связи не берём
    linked: dict[str, list[str]] = {h: [] for h in hubs}
    fm_hit: dict[str, str] = {}
    for path in iter_vault_paths(vault):
        rel = path.relative_to(vault).as_posix()
        nid = by_path.get(rel)
        if nid is None or nid in chosen:
            continue
        try:
            raw = path.read_text(encoding="utf-8")
        except OSError:
            continue
        for hub, rx in link_res.items():
            if rx.search(raw):
                linked[hub].append(nid)
        for m in fm_re.finditer(raw[:4000]):
            val = m.group(1).strip().casefold()
            if val in hubs or val in names:
                fm_hit[nid] = "fm"
                break
    generic = {h for h, ids in linked.items() if len(ids) > args.max_links}
    for hub, ids in linked.items():
        if hub not in generic:
            for nid in ids:
                add(nid, "link")
    for nid in fm_hit:
        add(nid, "fm")
    print("хабы (ссылок): " + ", ".join(f"{h}={len(v)}{'*' if h in generic else ''}"
                                         for h, v in sorted(linked.items()))
          + "  (* — общий, пропущен)")
    (base / "subset2.json").write_text(json.dumps(chosen, ensure_ascii=False, indent=1), "utf-8")
    why: dict[str, int] = {}
    for item in chosen.values():
        k = item["why"].split(":")[0]
        why[k] = why.get(k, 0) + 1
    rows = sum(len(manifest[n].get("chunks") or []) or 0 for n in chosen)
    print(f"subset2: {len(chosen)} заметок {why}; хабов {len(hubs)}; golden-ссылок {len(refs)}; "
          f"чанков по манифесту ≈{rows}")
    return 0


def cmd_prune(args: argparse.Namespace) -> int:
    """Выкинуть из подмножества не-golden заметки-монстры (≥ ``--max-chunks`` чанков в индексе main:
    xlsx-дампы под кап 120). Число чанков — из клона ``a`` (боевой индекс не читается). Они
    составляют ~40% строк, а на ранги ожиданий не влияют; без них канарейка укладывается в часы."""
    base = Path(args.base)
    subset = json.loads(_subset_file(base).read_text("utf-8"))
    root = base / "a" / "derived"
    os.environ["DT_DERIVED_ROOT"] = str(root)
    _assert_sandbox(root)
    import lancedb

    table = lancedb.connect(str(root / "lancedb")).open_table("chunks")
    ids = table.search().select(["note_id"]).limit(10**7).to_arrow().column("note_id").to_pylist()
    counts: dict[str, int] = {}
    for nid in ids:
        counts[nid] = counts.get(nid, 0) + 1
    drop = [n for n, v in subset.items()
            if v["why"] in ("link", "fm") and counts.get(n, 0) >= args.max_chunks]
    for n in drop:
        del subset[n]
    _subset_file(base).write_text(json.dumps(subset, ensure_ascii=False, indent=1), "utf-8")
    left = sum(v for n, v in counts.items() if n in subset)
    print(f"prune: -{len(drop)} монстров (≥{args.max_chunks} чанков); осталось {len(subset)} "
          f"заметок, {left} строк индекса main; перестрой a")
    return 0


def _assert_sandbox(root: Path) -> None:
    from core.config import index_manifest_path, lancedb_path

    for p in (lancedb_path(), index_manifest_path()):
        if root.resolve() not in p.resolve().parents:
            raise SystemExit(f"канарейка-2: путь {p} вне песочницы {root} — отказ")


def _build_a(base: Path, subset: dict) -> None:
    live = _live()
    root = base / "a" / "derived"
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True)
    subprocess.run(["cp", "-c", "-R", str(live / "lancedb"), str(root / "lancedb")], check=True)
    os.environ["DT_DERIVED_ROOT"] = str(root)
    _assert_sandbox(root)
    import lancedb

    from core.retrieval.index import TABLE_NAME, _build_secondary_indexes, _sql_quote

    table = lancedb.connect(str(root / "lancedb")).open_table(TABLE_NAME)
    total = table.count_rows()
    ids = list(subset)
    keep = ", ".join(_sql_quote(i) for i in ids)
    table.delete(f"note_id NOT IN ({keep})")
    _build_secondary_indexes(table)
    manifest = json.loads((live / "index_manifest.json").read_text("utf-8"))
    (root / "index_manifest.json").write_text(
        json.dumps({k: v for k, v in manifest.items() if k in subset}, ensure_ascii=False), "utf-8")
    for name in ("index_meta.json", "index_fts.json"):
        if (live / name).exists():
            shutil.copy2(live / name, root / name)
    print(f"a: боевой {total} строк -> подмножество {table.count_rows()} строк, "
          f"{len(subset)} заметок")


def _beacon(path: Path, **fields: object) -> None:
    path.write_text(json.dumps({"ts": time.strftime("%H:%M:%S"), **fields}, ensure_ascii=False))


def cmd_build(args: argparse.Namespace) -> int:
    base = Path(args.base)
    subset = json.loads(_subset_file(base).read_text("utf-8"))
    if args.variant == "a":
        _build_a(base, subset)
        return 0
    a_root = base / "a" / "derived"
    root = base / args.variant / "derived"
    if root.exists():
        shutil.rmtree(root)
    root.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(["cp", "-c", "-R", str(a_root), str(root)], check=True)  # клон a, COW
    os.environ["DT_DERIVED_ROOT"] = str(root)
    os.environ["DT_CHUNK_CONTEXT_PREFIX"] = VARIANT_ENV[args.variant] or "1"
    _assert_sandbox(root)
    sub_vault = base / "vault"
    if not sub_vault.exists():
        vault = _vault()
        for item in subset.values():
            dst = sub_vault / item["path"]
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(vault / item["path"], dst)
    from core.retrieval.index import reindex

    beacon = root.parent / "progress.json"
    started = time.perf_counter()
    state = {"embedded": 0}

    def log(line: str) -> None:
        m = re.search(r"\[index\] (\d+)/(\d+) notes \| (\d+) chunks", line)
        if m:
            done, total, emb = (int(x) for x in m.groups())
            el = time.perf_counter() - started
            _beacon(beacon, variant=args.variant, notes=f"{done}/{total}", embedded=emb,
                    elapsed_min=round(el / 60, 1),
                    rate_per_s=round(emb / el, 2) if el else 0,
                    eta_min=round((total - done) / done * el / 60, 1) if done else None)
            state["embedded"] = emb
        print(line, file=sys.stderr, flush=True)

    stats = reindex(sub_vault, rechunk=True, log=log)
    el = time.perf_counter() - started
    out = {"variant": args.variant, "notes": stats.notes, "chunks": stats.chunks,
           "embedded": stats.embedded_chunks, "reuse": stats.reuse_summary(),
           "device": stats.device, "seconds": round(el), "rate_per_s": round(
               stats.embedded_chunks / el, 2) if el else 0}
    (root.parent / "build.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), "utf-8")
    _beacon(beacon, **out, done=True)
    print(json.dumps(out, ensure_ascii=False))
    return 0


def cmd_eval(args: argparse.Namespace) -> int:
    base = Path(args.base)
    code = Path(args.code or ENGINE)
    env = dict(os.environ)
    env["DT_DERIVED_ROOT"] = str(base / args.variant / "derived")
    for k in ("DT_LANCEDB_PATH", "DT_INDEX_MANIFEST_PATH", "DT_EVENTS_PATH"):
        env.pop(k, None)
    env["PYTHONPATH"] = str(code)
    env["DT_VAULT_PATH"] = str(_vault())
    if args.variant != "a":
        env["DT_CHUNK_CONTEXT_PREFIX"] = VARIANT_ENV[args.variant] or "1"
    cmd = [sys.executable, str(code / "cli" / "dt_eval.py"), "--no-record", "--json"]
    out = subprocess.run(cmd, env=env, capture_output=True, text=True, check=False)
    (base / f"eval2-{args.label or args.variant}.json").write_text(out.stdout, "utf-8")
    if out.returncode not in (0, 1):
        print(out.stderr[-2000:], file=sys.stderr)
        return out.returncode
    d = json.loads(out.stdout)
    print(json.dumps({k: d[k] for k in ("metrics", "groups", "stale")}, ensure_ascii=False)[:1500])
    return 0


def cmd_ranks(args: argparse.Namespace) -> int:
    base = Path(args.base)
    code = Path(args.code or ENGINE)
    env = dict(os.environ)
    env["DT_DERIVED_ROOT"] = str(base / args.variant / "derived")
    for k in ("DT_LANCEDB_PATH", "DT_INDEX_MANIFEST_PATH", "DT_EVENTS_PATH"):
        env.pop(k, None)
    env["PYTHONPATH"] = str(code)
    env["DT_VAULT_PATH"] = str(_vault())
    if args.variant != "a":
        env["DT_CHUNK_CONTEXT_PREFIX"] = VARIANT_ENV[args.variant] or "1"
    env["RANKS_CODE"] = str(code)
    out = subprocess.run([sys.executable, str(ENGINE / "scripts" / "retr_chunk_ranks.py")],
                         env=env, capture_output=True, text=True, check=False)
    line = next((ln for ln in out.stdout.splitlines() if ln.startswith("{")), "{}")
    (base / f"ranks-{args.label or args.variant}.json").write_text(line, "utf-8")
    print(line[:400])
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="retr_chunk_canary2")
    sub = parser.add_subparsers(dest="cmd", required=True)
    prune = sub.add_parser("prune")
    prune.add_argument("--base", required=True)
    prune.add_argument("--max-chunks", type=int, default=60)
    for name in ("subset", "build", "eval", "ranks"):
        p = sub.add_parser(name)
        p.add_argument("--base", required=True)
        if name == "subset":
            p.add_argument("--max-links", type=int, default=1500,
                           help="хаб с большим числом ссылок считается общим и не расширяет набор")
        if name != "subset":
            p.add_argument("--variant", required=True, choices=("a", "b", "v"))
        if name in ("eval", "ranks"):
            p.add_argument("--code")
            p.add_argument("--label")
    args = parser.parse_args(argv)
    from _env import load_env

    load_env()
    return {"subset": cmd_subset, "prune": cmd_prune, "build": cmd_build,
            "eval": cmd_eval, "ranks": cmd_ranks}[args.cmd](args)


if __name__ == "__main__":
    raise SystemExit(main())
