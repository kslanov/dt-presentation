"""Ранги ожидаемых golden-запросов (find_notes, limit=30) — для таблицы канарейки-2.

Запускается ПОД окружением варианта (``DT_DERIVED_ROOT`` песочницы, ``DT_VAULT_PATH``,
``DT_CHUNK_CONTEXT_PREFIX``) из ``retr_chunk_canary2.py ranks``; печатает JSON
``{qid: {ожидаемое: ранг|null}}``. Только чтение."""

from __future__ import annotations

import importlib.util
import json
import os
import sys
from pathlib import Path

# дерево кода: RANKS_CODE (worktree/архив main для «до») либо это дерево
ENGINE = Path(os.environ.get("RANKS_CODE") or Path(__file__).resolve().parents[1])
sys.path.insert(0, str(ENGINE))
sys.path.insert(0, str(ENGINE / "cli"))

from _env import load_env  # noqa: E402


def main() -> int:
    load_env()
    from core.eval import golden_path, load_golden

    spec = importlib.util.spec_from_file_location("srv", ENGINE / "mcp-server" / "server.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    out: dict[str, dict[str, int | None]] = {}
    for q in load_golden(golden_path()):
        if not q.verified:
            continue
        ranks: dict[str, int | None] = {}
        for call in q.calls:
            if call.tool != "find_notes":
                continue
            exp = {**q.expect, **(call.expect or {})}
            args = dict(call.args)
            args["limit"] = 30
            try:
                notes = mod.find_notes(**args).get("notes", [])
            except Exception as exc:
                ranks["error"] = str(exc)[:80]
                continue
            ids = [str(n.get("note_id")) for n in notes]
            paths = [str(n.get("path")) for n in notes]
            for key in ("note_ids", "current_ids", "any_of"):
                for ref in exp.get(key) or []:
                    ranks[ref] = ids.index(ref) + 1 if ref in ids else None
            if exp.get("hub"):
                hub = exp["hub"]
                ranks["hub:" + hub] = ids.index(hub) + 1 if hub in ids else None
            for sub in exp.get("path_contains") or []:
                hit = next((i for i, p in enumerate(paths, 1) if sub in p), None)
                ranks["path~" + sub[:24]] = hit
        if ranks:
            out[q.id] = ranks
    print(json.dumps(out, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
