#!/usr/bin/env python3
# ruff: noqa: E501  - встроенные CSS/JS страницы длиннее 100 символов намеренно
"""Roadmap: один источник (docs/roadmap.yaml) → два вида.

* ``docs/roadmap.html`` - самодостаточная интерактивная страница (без внешних зависимостей);
  ее копия публикуется артефактом Cowork «dt-roadmap» (делает постановщик через
  update_artifact).
* блок §8 в ``docs/05-roadmap-2026-07.md`` между маркерами ``<!-- roadmap:begin -->`` /
  ``<!-- roadmap:end -->`` - сводка для чтения в git.

Запуск: ``uv run python scripts/roadmap_view.py`` (из engine/). ``--check`` - только
проверить, что оба вида совпадают с реестром (для приемки/CI), ничего не писать.
"""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
from datetime import date
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "docs" / "roadmap.yaml"
HTML_OUT = ROOT / "docs" / "roadmap.html"
MD_OUT = ROOT / "docs" / "05-roadmap-2026-07.md"
MD_BEGIN, MD_END = "<!-- roadmap:begin -->", "<!-- roadmap:end -->"

STATUS = {
    "accepted": ("принят", "ok"),
    "done": ("выполнен, ждет приемки", "warn"),
    "in_progress": ("в работе", "act"),
    "tz": ("ТЗ поставлено", "act"),
    "planned": ("в очереди", "plan"),
    "backlog": ("бэклог", "dim"),
    "dropped": ("снят", "x"),
    "superseded": ("поглощен", "x"),
}
WAVE_STATUS = {"done": "закрыта", "active": "идет", "planned": "впереди", "legacy": "наследие"}
COUNTABLE = {"accepted", "done", "in_progress", "tz", "planned"}


def load() -> dict:
    data = yaml.safe_load(REGISTRY.read_text(encoding="utf-8"))
    for w in data["waves"]:
        for it in w["items"]:
            if it["status"] not in STATUS:
                raise SystemExit(f"{it['id']}: неизвестный статус {it['status']!r}")
    return data


def _item_key(it: dict) -> tuple:
    """Принятые - первыми по дате, затем очередь по order, остальные по id."""
    rank = 0 if it["status"] == "accepted" else 1 if it["status"] in COUNTABLE else 2
    return (rank, it.get("accepted", ""), it.get("order", 99), it["id"])


def progress(wave: dict) -> tuple[int, int]:
    items = [i for i in wave["items"] if i["status"] in COUNTABLE]
    return sum(1 for i in items if i["status"] == "accepted"), len(items)


# ----------------------------------------------------------------------------- md
def render_md(data: dict) -> str:
    out = [MD_BEGIN, "",
           f"_Реестр: `docs/roadmap.yaml` (обновлен {data['updated']}); виды генерирует "
           f"`scripts/roadmap_view.py` - этот блок и `docs/roadmap.html` руками не править._",
           "", f"Линейка: {data['baseline']['eval']}; {data['baseline']['tests']}.", ""]
    for w in data["waves"]:
        done, total = progress(w)
        bar = f" - {done}/{total} принято" if total else ""
        out.append(f"- **{w['title']}** ({WAVE_STATUS[w['status']]}{bar}) - {w['goal']}")
        for it in sorted(w["items"], key=_item_key):
            label = STATUS[it["status"]][0]
            bits = [f"**{it['id']}** - {it['title']} - _{label}"
                    + (f" {it['accepted']}" if it.get("accepted") else "") + "_"]
            if it.get("metric"):
                bits.append(f"метрика: {it['metric']}")
            if it.get("metric_target"):
                bits.append(f"цель: {it['metric_target']}")
            if it.get("closes"):
                bits.append(f"закрывает: {it['closes']}")
            if it.get("tz"):
                bits.append(f"ТЗ `{it['tz']}`")
            if it.get("note"):
                bits.append(it["note"])
            out.append("  - " + "; ".join(bits))
    out.append("- **Не брать**: " + "; ".join(data["not_taking"]) + ".")
    out += ["", MD_END]
    return "\n".join(out)


def write_md(block: str, *, check: bool) -> bool:
    text = MD_OUT.read_text(encoding="utf-8")
    if MD_BEGIN not in text or MD_END not in text:
        raise SystemExit(f"{MD_OUT.name}: нет маркеров {MD_BEGIN} / {MD_END}")
    head, rest = text.split(MD_BEGIN, 1)
    _, tail = rest.split(MD_END, 1)
    new = head + block + tail
    if new == text:
        return True
    if not check:
        MD_OUT.write_text(new, encoding="utf-8")
    return False


# --------------------------------------------------------------------------- html
_CSS = """
:root{--bg:#f5f5f7;--card:#fff;--ink:#1d1d1f;--mute:#6e6e73;--line:#e5e5ea;--ok:#34c759;--warn:#ff9f0a;
--act:#5856d6;--plan:#0a84ff;--dim:#8e8e93;--x:#c7c7cc;--bar:#e5e5ea;--chip:#f2f2f7;--shadow:0 1px 2px rgba(0,0,0,.06)}
@media(prefers-color-scheme:dark){:root{--bg:#000;--card:#1c1c1e;--ink:#f5f5f7;--mute:#98989d;--line:#2c2c2e;
--bar:#2c2c2e;--chip:#2c2c2e;--x:#48484a;--shadow:none}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 -apple-system,BlinkMacSystemFont,"SF Pro Text","Helvetica Neue",Arial,sans-serif}
.wrap{max-width:1180px;margin:0 auto;padding:22px 18px 60px}
h1{font-size:22px;margin:0 0 4px;font-weight:650;letter-spacing:-.01em}.sub{color:var(--mute);font-size:13px;margin-bottom:14px}
.top{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:16px}
.tile{background:var(--card);border-radius:12px;padding:10px 14px;box-shadow:var(--shadow);min-width:150px}
.tile .k{color:var(--mute);font-size:11.5px;text-transform:uppercase;letter-spacing:.04em}.tile .v{font-size:19px;font-weight:650;margin-top:2px}
.tile .s{font-size:12px;color:var(--mute)}
.filters{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin:8px 0 18px}
.f{border:1px solid var(--line);background:var(--card);border-radius:999px;padding:4px 11px;font-size:12.5px;cursor:pointer;color:var(--ink)}
.f.on{background:var(--ink);color:var(--bg);border-color:var(--ink)}
input.q{border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:9px;padding:6px 10px;font-size:13px;min-width:220px}
.wave{background:var(--card);border-radius:14px;padding:14px 16px;margin-bottom:14px;box-shadow:var(--shadow)}
.wh{display:flex;flex-wrap:wrap;align-items:baseline;gap:8px 12px;cursor:pointer}
.wh h2{font-size:16px;margin:0;font-weight:650}.wh .g{color:var(--mute);font-size:13px;flex:1 1 320px}
.ws{font-size:11.5px;padding:2px 8px;border-radius:999px;background:var(--chip);color:var(--mute)}
.bar{height:6px;background:var(--bar);border-radius:3px;margin:10px 0 12px;overflow:hidden}.bar i{display:block;height:100%;background:var(--ok)}
.items{display:grid;grid-template-columns:repeat(auto-fill,minmax(330px,1fr));gap:10px}
.it{border:1px solid var(--line);border-radius:11px;padding:10px 12px;cursor:pointer;position:relative}
.it.hide{display:none}.it .id{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;color:var(--mute)}
.it .t{font-weight:600;margin:3px 0 6px;font-size:13.5px;line-height:1.35}
.st{display:inline-block;font-size:11px;padding:2px 8px;border-radius:999px;color:#fff;margin-right:6px}
.st.ok{background:var(--ok)}.st.warn{background:var(--warn)}.st.act{background:var(--act)}.st.plan{background:var(--plan)}.st.dim{background:var(--dim)}.st.x{background:var(--x);color:var(--ink)}
.meta{color:var(--mute);font-size:12px;margin-top:4px}.meta b{color:var(--ink);font-weight:600}
.more{display:none;margin-top:8px;padding-top:8px;border-top:1px dashed var(--line);font-size:12.5px}.it.open .more{display:block}
.more div{margin:3px 0}.more code{font-family:ui-monospace,Menlo,monospace;font-size:11.5px;background:var(--chip);padding:1px 5px;border-radius:5px}
.wave.collapsed .items,.wave.collapsed .bar{display:none}
.nt{background:var(--card);border-radius:14px;padding:12px 16px;color:var(--mute);font-size:13px;box-shadow:var(--shadow)}
.nt b{color:var(--ink)}.legend{color:var(--mute);font-size:12px;margin-top:14px}
.empty{color:var(--mute);font-size:13px;padding:6px 0}
.gwrap{background:var(--card);border-radius:14px;padding:12px 14px 8px;margin-bottom:14px;box-shadow:var(--shadow)}
.gh{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}.gh h2{font-size:16px;margin:0;font-weight:650}.gh .g{color:var(--mute);font-size:13px;flex:1}
.gbox{overflow:auto;margin-top:8px}.gbox.fit svg{width:100%;height:auto}
svg text{font:11px -apple-system,BlinkMacSystemFont,"SF Pro Text",Arial,sans-serif;fill:var(--ink)}svg text.id{font-weight:650;font-family:ui-monospace,Menlo,monospace;font-size:10.5px}
svg .rowlbl{fill:var(--mute);font-size:11px;font-weight:600;letter-spacing:.03em}
svg .edge{fill:none;stroke:var(--mute);stroke-opacity:.45;stroke-width:1.4}svg .edge.hi{stroke:var(--ink);stroke-opacity:1;stroke-width:2}
svg .edge.lo,svg .node.lo{opacity:.18}svg .node{cursor:pointer}svg .node rect{stroke-width:1.4}
.glegend{color:var(--mute);font-size:12px;margin-top:6px;display:flex;gap:12px;flex-wrap:wrap}.glegend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-right:4px;vertical-align:-1px}
"""

_JS = """
const DATA=__DATA__;const ST=__ST__;const WS=__WS__;const COUNT=new Set(__COUNT__);
let filt="all",q="";
function esc(s){return String(s==null?"":s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]))}
function matches(it){const s=it.status;
 const f=filt==="all"||(filt==="open"&&["in_progress","tz","planned","done"].includes(s))||(filt==="accepted"&&s==="accepted")||(filt==="backlog"&&s==="backlog")||(filt==="closed"&&["dropped","superseded"].includes(s));
 if(!f)return false;if(!q)return true;const hay=(it.id+" "+it.title+" "+(it.note||"")+" "+(it.closes||"")+" "+(it.source||"")).toLowerCase();return hay.includes(q)}
function item(it){const st=ST[it.status];const acc=it.accepted?" · "+it.accepted:"";
 let meta=[];if(it.metric)meta.push("<b>метрика</b> "+esc(it.metric));if(it.metric_target)meta.push("<b>цель</b> "+esc(it.metric_target));if(it.closes)meta.push("<b>закрывает</b> "+esc(it.closes));
 let more=[];if(it.note)more.push("<div>"+esc(it.note)+"</div>");if(it.tz)more.push("<div>ТЗ: <code>"+esc(it.tz)+"</code></div>");if(it.tag)more.push("<div>тег: <code>"+esc(it.tag)+"</code></div>");if(it.source)more.push("<div>источник: "+esc(it.source)+"</div>");
 return `<div class="it${matches(it)?"":" hide"}" data-id="${esc(it.id)}" onclick="this.classList.toggle('open')"><div class="id">${esc(it.id)}</div><div class="t">${esc(it.title)}</div><span class="st ${st[1]}">${st[0]}${acc}</span>${meta.length?`<div class="meta">${meta.join(" · ")}</div>`:""}${more.length?`<div class="more">${more.join("")}</div>`:""}</div>`}
function render(){const root=document.getElementById("waves");root.innerHTML=DATA.waves.map(w=>{
 const rk=i=>i.status==="accepted"?0:COUNT.has(i.status)?1:2;const items=[...w.items].sort((a,b)=>rk(a)-rk(b)||(a.accepted||"").localeCompare(b.accepted||"")||(a.order||99)-(b.order||99)||a.id.localeCompare(b.id));
 const cnt=items.filter(i=>COUNT.has(i.status));const done=cnt.filter(i=>i.status==="accepted").length;
 const pct=cnt.length?Math.round(100*done/cnt.length):0;const vis=items.filter(matches).length;
 return `<section class="wave${w.status==="done"||w.status==="legacy"?" collapsed":""}" id="${esc(w.id)}"><div class="wh" onclick="this.parentNode.classList.toggle('collapsed')"><h2>${esc(w.title)}</h2><span class="ws">${WS[w.status]}${cnt.length?` · ${done}/${cnt.length}`:""}</span><span class="g">${esc(w.goal||"")}</span></div>
 ${cnt.length?`<div class="bar"><i style="width:${pct}%"></i></div>`:""}<div class="items">${items.map(item).join("")}</div>${vis?"":`<div class="empty">по фильтру ничего</div>`}</section>`}).join("");
 let tot=0,acc=0;DATA.waves.filter(w=>w.status!=="legacy").forEach(w=>w.items.forEach(i=>{if(COUNT.has(i.status)){tot++;if(i.status==="accepted")acc++}}));
 document.getElementById("prog").textContent=`${acc} / ${tot}`;document.getElementById("open").textContent=DATA.waves.flatMap(w=>w.items).filter(i=>["in_progress","tz","done"].includes(i.status)).length;
 document.querySelectorAll(".f").forEach(b=>b.classList.toggle("on",b.dataset.f===filt));
 if(q||filt!=="all")document.querySelectorAll(".wave").forEach(w=>w.classList.remove("collapsed"))}
function setF(f){filt=f;render()}function setQ(v){q=v.trim().toLowerCase();render()}
render();
const COLOR={ok:"var(--ok)",warn:"var(--warn)",act:"var(--act)",plan:"var(--plan)",dim:"var(--dim)",x:"var(--x)"};
function graph(){const box=document.getElementById("gbox");const W=150,H=34,GX=14,GY=56,PADL=118,PADT=14;
 const waves=DATA.waves.filter(w=>w.status!=="legacy");const rk=i=>i.status==="accepted"?0:COUNT.has(i.status)?1:2;
 const pos={};let maxCols=0;const rows=waves.map((w,r)=>{const items=[...w.items].sort((a,b)=>rk(a)-rk(b)||(a.accepted||"").localeCompare(b.accepted||"")||(a.order||99)-(b.order||99)||a.id.localeCompare(b.id));
  maxCols=Math.max(maxCols,items.length);items.forEach((it,c)=>{pos[it.id]={x:PADL+c*(W+GX),y:PADT+r*(H+GY),it,r}});return {w,items}});
 const width=PADL+maxCols*(W+GX)+10,height=PADT+rows.length*(H+GY);
 const edges=[];waves.forEach(w=>w.items.forEach(it=>(it.depends||[]).forEach(d=>{if(pos[d]&&pos[it.id])edges.push([d,it.id])})));
 const esc2=s=>esc(s);let svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}"><defs><marker id="ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="currentColor"/></marker></defs>`;
 rows.forEach(({w},r)=>{svg+=`<text class="rowlbl" x="8" y="${PADT+r*(H+GY)+H/2+4}">${esc2(w.title.split(" - ")[0].replace("Решение №1","Реш. №1"))}</text>`});
 edges.forEach(([a,b],i)=>{const A=pos[a],B=pos[b];let d;
  if(A.r===B.r){const y=A.y-10,x1=A.x+W/2,x2=B.x+W/2;d=`M${x1},${A.y} C${x1},${y} ${x2},${y} ${x2},${B.y}`}
  else{const x1=A.x+W/2,y1=A.y+H,x2=B.x+W/2,y2=B.y;const m=(y1+y2)/2;d=`M${x1},${y1} C${x1},${m} ${x2},${m} ${x2},${y2}`}
  svg+=`<path class="edge" data-a="${esc2(a)}" data-b="${esc2(b)}" d="${d}" marker-end="url(#ar)" style="color:var(--mute)"/>`});
 Object.values(pos).forEach(({x,y,it})=>{const c=COLOR[ST[it.status][1]];const t=it.title.length>26?it.title.slice(0,25)+"…":it.title;
  svg+=`<g class="node" data-id="${esc2(it.id)}" transform="translate(${x},${y})" onmouseenter="ghi('${esc2(it.id)}')" onmouseleave="ghi(null)" onclick="gopen('${esc2(it.id)}')"><title>${esc2(it.id)} - ${esc2(it.title)} [${ST[it.status][0]}]</title><rect width="${W}" height="${H}" rx="8" fill="${c}" fill-opacity=".16" stroke="${c}"/><text class="id" x="9" y="14">${esc2(it.id)}</text><text x="9" y="27" fill-opacity=".85">${esc2(t)}</text></g>`});
 box.innerHTML=svg+"</svg>";if(box.clientWidth<width*0.6){box.classList.remove("fit");document.getElementById("gfit").textContent="1:1"}}
function ghi(id){const nodes=document.querySelectorAll("#gbox .node"),edges=document.querySelectorAll("#gbox .edge");
 if(!id){nodes.forEach(n=>n.classList.remove("lo"));edges.forEach(e=>e.classList.remove("lo","hi"));return}
 const near=new Set([id]);edges.forEach(e=>{if(e.dataset.a===id)near.add(e.dataset.b);if(e.dataset.b===id)near.add(e.dataset.a)});
 nodes.forEach(n=>n.classList.toggle("lo",!near.has(n.dataset.id)));edges.forEach(e=>{const on=e.dataset.a===id||e.dataset.b===id;e.classList.toggle("hi",on);e.classList.toggle("lo",!on)})}
function gopen(id){filt="all";q="";const inp=document.querySelector("input.q");if(inp)inp.value="";render();const el=document.querySelector(`.it[data-id="${id}"]`);if(!el)return;el.closest(".wave").classList.remove("collapsed");el.classList.add("open");el.scrollIntoView({behavior:"smooth",block:"center"})}
function toggleFit(){const b=document.getElementById("gbox");b.classList.toggle("fit");document.getElementById("gfit").textContent=b.classList.contains("fit")?"по ширине":"1:1"}
graph();
"""


def render_html(data: dict) -> str:
    waves = [{**w, "items": [{k: v for k, v in it.items()} for it in w["items"]]} for w in data["waves"]]
    payload = json.dumps({"waves": waves, "not_taking": data["not_taking"]}, ensure_ascii=False)
    st = json.dumps(STATUS, ensure_ascii=False)
    ws = json.dumps(WAVE_STATUS, ensure_ascii=False)
    count = json.dumps(sorted(COUNTABLE))
    js = (_JS.replace("__DATA__", payload).replace("__ST__", st).replace("__WS__", ws)
          .replace("__COUNT__", count))
    b = data["baseline"]
    not_taking = "".join(f"<div>· {html.escape(x)}</div>" for x in data["not_taking"])
    return f"""<!doctype html>
<html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Digital Twin - roadmap</title><style>{_CSS}</style></head>
<body><div class="wrap">
<h1>Digital Twin - roadmap</h1>
<div class="sub">Реестр <code>engine/docs/roadmap.yaml</code>, обновлен {html.escape(data['updated'])} · страница собрана {date.today().isoformat()} · клик по карточке - подробности, по заголовку волны - свернуть</div>
<div class="top">
 <div class="tile"><div class="k">Принято / в волнах 0-5</div><div class="v" id="prog">-</div><div class="s">без наследия, снятых и поглощенных</div></div>
 <div class="tile"><div class="k">В работе сейчас</div><div class="v" id="open">-</div><div class="s">ТЗ поставлено · у Code · ждет приемки</div></div>
 <div class="tile" style="flex:1 1 320px"><div class="k">Линейка качества</div><div class="v" style="font-size:14px">{html.escape(b['eval'])}</div><div class="s">{html.escape(b['tests'])}</div></div>
</div>
<div class="filters">
 <button class="f on" data-f="all" onclick="setF('all')">все</button>
 <button class="f" data-f="open" onclick="setF('open')">открытые</button>
 <button class="f" data-f="accepted" onclick="setF('accepted')">принятые</button>
 <button class="f" data-f="backlog" onclick="setF('backlog')">бэклог</button>
 <button class="f" data-f="closed" onclick="setF('closed')">снятые / поглощенные</button>
 <input class="q" placeholder="поиск: id, слово, запрос q12…" oninput="setQ(this.value)">
</div>
<div class="gwrap"><div class="gh"><h2>Граф зависимостей</h2><span class="g">волны сверху вниз, стрелка - «нужно до»; наведение подсвечивает соседей, клик - карточка ниже</span><button class="f" id="gfit" onclick="toggleFit()">по ширине</button></div><div class="gbox fit" id="gbox"></div><div class="glegend"><span><i style="background:var(--ok)"></i>принят</span><span><i style="background:var(--warn)"></i>ждет приемки</span><span><i style="background:var(--act)"></i>в работе / ТЗ</span><span><i style="background:var(--plan)"></i>в очереди</span><span><i style="background:var(--dim)"></i>бэклог</span><span><i style="background:var(--x)"></i>снят / поглощен</span></div></div>
<div id="waves"></div>
<div class="nt"><b>Не брать</b> (аудит D + курс 26.10):{not_taking}</div>
<div class="legend">Решения К. 2026-10-19: {html.escape(b['decisions'])}. Статусы: принят - приемка Cowork прошла; выполнен - отчет Code есть, приемки нет; ТЗ поставлено - kickoff выдан; в очереди - порядок внутри волны по номеру; бэклог - без срока.</div>
</div><script>{js}</script></body></html>
"""


def _undated(page: str) -> str:
    """Страница без даты сборки - чтобы --check не считал ежедневный штамп изменением."""
    return re.sub(r"страница собрана \d{4}-\d{2}-\d{2}", "страница собрана", page)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="только сверить виды с реестром")
    args = ap.parse_args(argv)
    data = load()
    md_ok = write_md(render_md(data), check=args.check)
    page = render_html(data)
    html_ok = HTML_OUT.exists() and _undated(HTML_OUT.read_text(encoding="utf-8")) == _undated(page)
    if not args.check and not html_ok:
        HTML_OUT.write_text(page, encoding="utf-8")
    if args.check:
        if md_ok and html_ok:
            print("roadmap: виды совпадают с реестром")
            return 0
        print("roadmap: виды устарели - запусти scripts/roadmap_view.py", file=sys.stderr)
        return 1
    print(f"roadmap: §8 {'без изменений' if md_ok else 'обновлен'}; html {'без изменений' if html_ok else 'обновлен'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
