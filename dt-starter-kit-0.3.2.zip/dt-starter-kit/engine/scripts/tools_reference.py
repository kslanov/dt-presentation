"""Сгенерировать ``docs/08-tools-reference.md`` из реестра MCP-сервера (SURFACE-HYGIENE-1 п.6, R13).

Инструменты берутся из ``mcp-server/server.py``: ``TOOL_NAMES`` (порядок регистрации),
``PROFILES`` (lean/pult/full), ``WRITE_TOOLS`` (пишущие), первая строка docstring, ``RETIRED_TOOLS``
(снятые). Текст детерминирован (без дат и путей машины): гард ``tests/test_tools_reference.py``
сверяет файл с генератором байт в байт - справочник не отстает от кода.

Usage:
    uv run python scripts/tools_reference.py           # записать docs/08-tools-reference.md
    uv run python scripts/tools_reference.py --check   # код 1, если файл не совпадает с реестром
    uv run python scripts/tools_reference.py --guide   # текст раздела MCP для vault-гайда (stdout)
"""

from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path
from types import ModuleType

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

TARGET = ENGINE_ROOT / "docs" / "08-tools-reference.md"
_DOC_LIMIT = 150


def load_server() -> ModuleType:
    spec = importlib.util.spec_from_file_location(
        "dt_tools_reference_server", ENGINE_ROOT / "mcp-server" / "server.py")
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def first_line(fn: object) -> str:
    """Первая содержательная строка docstring (без markdown-вставок ``|``), не длиннее лимита."""
    doc = (getattr(fn, "__doc__", "") or "").strip()
    line = next((ln.strip() for ln in doc.splitlines() if ln.strip()), "")
    line = line.replace("|", "\\|").replace("``", "`")
    return line if len(line) <= _DOC_LIMIT else line[: _DOC_LIMIT - 1].rstrip() + "…"


def render(server: ModuleType | None = None) -> str:
    srv = server or load_server()
    profiles = {name: set(tools) for name, tools in srv.PROFILES.items()}
    write = set(srv.WRITE_TOOLS)
    lines = [
        "# Справочник MCP-инструментов",
        "",
        "<!-- Генерируется: uv run python scripts/tools_reference.py. Руками не править: "
        "гард tests/test_tools_reference.py сверяет файл с реестром сервера. -->",
        "",
        f"Всего **{len(srv.TOOL_NAMES)}** инструмента(ов): "
        + ", ".join(f"`{name}` {len(srv.PROFILES[name])}" for name in ("lean", "pult", "full"))
        + f"; пишущих (`WRITE_TOOLS`) {len(write)}. Профиль выбирает `--profile` / "
        "`DT_TOOL_PROFILE` (`mcp-server/README.md`); `full` - все.",
        "",
        "Тип: **W** - в `WRITE_TOOLS` (пишет, аудит в `pult-actions.log`), **R** - остальные "
        "(читают; `submit_job`/`job_cancel` управляют заданиями, данных vault не пишут). "
        "Колонки профилей: + входит, пусто - нет.",
        "",
        "| Инструмент | Тип | lean | pult | full | Описание |",
        "|---|---|---|---|---|---|",
    ]
    for name in srv.TOOL_NAMES:
        marks = ["+" if name in profiles[p] else "" for p in ("lean", "pult", "full")]
        kind = "W" if name in write else "R"
        lines.append(
            f"| `{name}` | {kind} | {marks[0]} | {marks[1]} | {marks[2]} | "
            f"{first_line(getattr(srv, name))} |")
    personal = tuple(getattr(srv, "PERSONAL_TOOLS", ()))
    if personal:  # PERSONAL-1: не строки таблицы - в реестре профилей рабочего их нет
        lines += ["", f"## Инструменты личного экземпляра ({len(personal)})", "",
                  "Регистрируются только при `DT_INSTANCE_ROLE=personal` (личный контур, "
                  "`ops/README.md`) и добавляются к любому профилю; в `TOOL_NAMES`/`PROFILES` "
                  "рабочего экземпляра их нет, хост подключает личный экземпляр отдельной записью "
                  "`dt host-config <хост> --instance personal`.", ""]
        lines += [f"- `{name}` (R) - {first_line(getattr(srv, name))}" for name in personal]
    lines += ["", f"## Снятые инструменты ({len(srv.RETIRED_TOOLS)})", "",
              "Имена не переиспользуются (гард `tests/test_no_timetta_write.py`).", "",
              "| Имя | Чем заменено |", "|---|---|"]
    lines += [f"| `{name}` | {why} |" for name, why in srv.RETIRED_TOOLS.items()]
    return "\n".join(lines) + "\n"


def guide_section(server: ModuleType | None = None) -> str:
    """Замена раздела «MCP-инструменты» vault-гайда ``07-reference.md``: ссылка на справочник."""
    srv = server or load_server()
    return (
        "## MCP-инструменты (что Claude зовёт под капотом)\n\n"
        f"Полный справочник ({len(srv.TOOL_NAMES)} инструментов по профилям lean/pult/full, "
        "чтение/запись, снятые) - `engine/docs/08-tools-reference.md`; генерируется из кода, "
        "поэтому не устаревает. Детали по каждому - `engine/mcp-server/README.md`.\n"
    )


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--check", action="store_true", help="только сверить, не писать")
    ap.add_argument("--guide", action="store_true", help="напечатать раздел MCP для vault-гайда")
    args = ap.parse_args(argv)
    if args.guide:
        print(guide_section(), end="")
        return 0
    text = render()
    if args.check:
        same = TARGET.is_file() and TARGET.read_text(encoding="utf-8") == text
        print(f"{TARGET}: {'совпадает с реестром' if same else 'ОТСТАЕТ от реестра'}")
        return 0 if same else 1
    TARGET.write_text(text, encoding="utf-8")
    print(f"записано {TARGET} ({len(text.splitlines())} строк)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
