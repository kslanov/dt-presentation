"""DEV-3-KIT п.5: проверить собранный стартовый кит так, как его получит человек.

``verify_starter_kit.py <zip>``:

1. распаковка во временную папку (выход за корень архива - отказ);
2. целостность: ``KIT-MANIFEST.json`` - хэш каждого файла совпадает, лишних и недостающих нет;
3. состав: ``README.md``/``INSTALL.md``/``CHANGELOG.md``/``VERSION``, ``engine/`` с точкой входа
   и шаблонами заданий, ``installer/`` с восемью фазами и словарем, ``skills/``; ``VERSION`` =
   версии в ``pyproject.toml``;
4. гард утечек на распакованном дереве (тот же, что при сборке: запрещенные файлы, токены, пути,
   приватные термины, если передан ``--vault``);
5. ``dt install --check --json --root <tmp> --home <tmp>`` из РАСПАКОВАННОГО кита (код из архива,
   не из репозитория): таблица из десяти шагов, ``platform`` сделан, проверка ``deps`` отработала
   («нет .venv» - норма: кит еще не ставили), и во временных ``--root``/``--home`` после прогона
   ничего не появилось (``--check`` ничего не пишет).

Код выхода 0 - кит годен, 1 - причина названа.

Usage:
    uv run python scripts/verify_starter_kit.py dist/dt-starter-kit-0.2.0.zip --vault ../../vault
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from build_starter_kit import MANIFEST, KitError, guard_files, private_terms, zip_contents

STEPS = ["platform", "deps", "config", "vault", "owner", "models", "launchd", "host", "index",
         "doctor"]
BRAIN = ("00-welcome", "01-prereqs", "02-profile", "03-setup", "04-method", "05-style",
         "06-integrations", "07-first-run")
REQUIRED = ("README.md", "INSTALL.md", "CHANGELOG.md", "VERSION", MANIFEST, "engine/cli/dt.py",
            "engine/pyproject.toml", "engine/uv.lock", "engine/vault-template/_generated.json",
            "engine/ops/SETUP.md", "installer/INSTALL.md", "installer/state/install-plan.md",
            "installer/state/install-progress.md", "skills/README.md",
            "installer/brain/glossary.md", *(f"installer/brain/{n}.md" for n in BRAIN),
            *(f"engine/ops/launchd/com.dt.{k}.plist" for k in (
                "server", "sync.fast", "sync.index", "backup", "meetings", "smoke",
                "run.watchdog")))


def check_integrity(files: dict[str, bytes]) -> list[str]:
    """Манифест кита против фактического содержимого."""
    if MANIFEST not in files:
        return [f"нет {MANIFEST}"]
    try:
        listed = json.loads(files[MANIFEST].decode("utf-8"))["files"]
    except (ValueError, KeyError) as exc:
        return [f"{MANIFEST} нечитаем: {exc}"]
    actual = {rel: hashlib.sha256(data).hexdigest() for rel, data in files.items()
              if rel != MANIFEST}
    problems = [f"{rel}: хэш не совпал с манифестом" for rel in sorted(listed)
                if rel in actual and listed[rel] != actual[rel]]
    problems += [f"{rel}: в манифесте есть, в архиве нет"
                 for rel in sorted(set(listed) - set(actual))]
    problems += [f"{rel}: в архиве есть, в манифесте нет"
                 for rel in sorted(set(actual) - set(listed))]
    return problems


def _word_char(ch: str) -> bool:
    return ch.isalnum()  # «_» и «-» - граница: client-<имя>, КП_<имя>_… не должны проходить


def independent_hits(files: dict[str, bytes], terms: list[str]) -> list[tuple[str, int, str]]:
    """НЕЗАВИСИМЫЙ проход по терминам (KIT-PRIVACY-1): ни регулярок, ни функций сборки - простой
    поиск подстроки по свернутому тексту с ручной проверкой границ слова (буква или цифра рядом -
    не граница). Тот же смысл, что у гарда сборки, другая реализация: ошибка в одной не
    прячет утечку от другой. ``[(файл, строка, термин)]``."""
    import unicodedata

    def fold(text: str) -> str:
        return unicodedata.normalize("NFC", text).casefold()

    needles = sorted({(fold(t), t) for t in terms if t.strip()})
    out: list[tuple[str, int, str]] = []
    for rel, data in sorted(files.items()):
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            continue
        for lineno, raw in enumerate(text.splitlines(), 1):
            line = fold(raw)
            for needle, term in needles:
                start = line.find(needle)
                while start != -1:
                    end = start + len(needle)
                    before = line[start - 1] if start else " "
                    after = line[end] if end < len(line) else " "
                    if not _word_char(before) and not _word_char(after):
                        out.append((rel, lineno, term))
                        break
                    start = line.find(needle, start + 1)
    return out


def check_layout(files: dict[str, bytes]) -> list[str]:
    problems = [f"нет {rel}" for rel in REQUIRED if rel not in files]
    version = files.get("VERSION", b"").decode("utf-8").strip()
    pyproject = files.get("engine/pyproject.toml", b"").decode("utf-8")
    if version and f'version = "{version}"' not in pyproject:
        problems.append(f"VERSION {version} не совпадает с engine/pyproject.toml")
    top = {rel.split("/", 1)[0] for rel in files}
    extra = top - {"README.md", "INSTALL.md", "CHANGELOG.md", "VERSION", MANIFEST, "engine",
                   "installer", "skills"}
    problems += [f"лишнее на верхнем уровне: {name}" for name in sorted(extra)]
    return problems


def extract(files: dict[str, bytes], dest: Path) -> Path:
    for rel, data in files.items():
        target = dest / rel
        if not target.resolve().is_relative_to(dest.resolve()):
            raise KitError(f"запись вне папки распаковки: {rel}")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return dest


def run_install_check(kit: Path, work: Path) -> tuple[list[str], dict[str, dict[str, str]]]:
    """``dt install --check --json`` из распакованного кита на пустых ``--root``/``--home``."""
    engine = kit / "engine"
    root, home = work / "ws", work / "home"
    env = {k: v for k, v in os.environ.items()
           if not k.startswith("DT_") and k not in ("PYTEST_CURRENT_TEST", "VIRTUAL_ENV")}
    env["PYTHONPATH"] = str(engine)  # код из распакованного кита, а не из репозитория
    home.mkdir(parents=True, exist_ok=True)
    cmd = [sys.executable, str(engine / "cli" / "dt.py"), "install", "--check", "--json",
           "--root", str(root), "--home", str(home), "--engine-dir", str(engine),
           "--env-file", str(root / ".env")]
    done = subprocess.run(cmd, cwd=str(engine), env=env, capture_output=True, text=True,
                          timeout=180, check=False)
    problems: list[str] = []
    try:
        rows = json.loads(done.stdout)
    except ValueError:
        return [f"dt install --check не вернул JSON (код {done.returncode}): "
                f"{(done.stderr or done.stdout)[-300:]}"], {}
    by = {r["step"]: r for r in rows}
    if [r["step"] for r in rows] != STEPS:
        problems.append(f"шаги {[r['step'] for r in rows]} вместо {STEPS}")
    if by.get("platform", {}).get("state") != "done":
        why = by.get("platform", {}).get("reason")
        problems.append(f"шаг platform не сделан на этой машине: {why}")
    if "deps" not in by or not by["deps"].get("reason"):
        problems.append("проверка deps не отработала")
    if done.returncode != 1:
        problems.append(f"на пустой цели --check должен вернуть 1, вернул {done.returncode}")
    written = [p for p in work.rglob("*") if p.is_file() and home not in p.parents]
    written += [p for p in home.rglob("*") if p.is_file()]
    if written:
        problems.append("--check записал файлы: " + ", ".join(
            str(p.relative_to(work)) for p in written[:5]))
    return problems, by


def verify(zip_path: Path, *, vault: Path | None = None, keep: bool = False,
           run: bool = True) -> list[str]:
    """Все проверки; пустой список - кит годен."""
    try:
        files = zip_contents(zip_path)
    except (KitError, zipfile.BadZipFile) as exc:
        return [f"архив не читается: {exc}"]
    problems = check_integrity(files) + check_layout(files)
    body = {r: d for r, d in files.items() if r != MANIFEST}
    terms = private_terms(vault).all if vault else []
    problems += guard_files(body, [])  # запрещенные имена, токены, пути
    problems += [f"{rel}:{line}: приватный термин «{term}» (независимый проход)"
                 for rel, line, term in independent_hits(body, terms)]
    if problems or not run:
        return problems
    with tempfile.TemporaryDirectory(prefix="dt-kit-verify-") as tmp:
        base = Path(tmp)
        kit = extract(files, base / "dt-starter-kit")
        found, _rows = run_install_check(kit, base / "target")
        problems += found
        if keep:
            print(f"распаковано в {base} (удалится по выходу)")
    return problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("zip", help="путь к dt-starter-kit-<версия>.zip")
    parser.add_argument("--vault", default=None,
                        help="боевой vault: приватные термины для гарда (читается)")
    parser.add_argument("--no-run", action="store_true",
                        help="только целостность, состав и гард (без запуска dt install --check)")
    args = parser.parse_args(argv)
    path = Path(args.zip).expanduser()
    vault = Path(args.vault).expanduser().resolve() if args.vault else None
    problems = verify(path, vault=vault, run=not args.no_run)
    if problems:
        print(f"кит НЕ годен ({path.name}):", file=sys.stderr)
        for line in problems:
            print(f"  {line}", file=sys.stderr)
        return 1
    files = zip_contents(path)
    tail = "" if args.no_run else (", dt install --check из распакованного кита (десять шагов, "
                                   "platform сделан, ничего не записано)")
    print(f"{path.name}: годен - целостность по манифесту ({len(files) - 1} файлов), состав, "
          f"гард утечек{tail}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
