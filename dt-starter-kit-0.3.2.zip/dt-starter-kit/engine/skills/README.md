# Скиллы DT (источник истины - git)

`skills/<name>/SKILL.md` - единственный источник. Из него генерируются библиотека Cowork
(`dt skills export cowork`), плагин Kimi Work (`dt skills export kimi` / `dt plugin kimi`), MCP
`prompts` сервера (любой профиль) и `skillInstructions` манифеста Kimi (из реестра, не руками).
Проверка переносимости - `dt skills lint` (шапка, нет вендора/песочницы чата, инструменты только из
`TOOL_NAMES`). Реестр: **9 скиллов**.

**Скилл на хосте = подмножество профиля** (MODEL-1-FIT). `core.skills.fit_profile(skills,
tool_names)` оставляет скиллы, у которых вызовы инструментов в теле ⊆ инструменты профиля хоста, и
называет отброшенные с перечнем недостающих. Один источник для экспорта плагина Kimi (`dt plugin kimi`,
`dt skills export kimi --profile …`), MCP `prompts` сервера и `--selftest`; Cowork (`export cowork`) и
`export prompts` берут весь реестр. На `lean` (12 инструментов) подходят `generate-artifact`,
`save-output`, `text-normalizer`, `tz-presentation-dt`; `capture-to-assignment`, `hub-synth`, `inbox-triage`,
`new-hub`, `operational-review` зовут `pult_*`/`work_*`/`list_inbox`… - они для профилей `pult|full`
(Cowork). Новый скилл нового инструмента: если инструмент не в `lean`, скилл на lean-хост не
поедет - это не ошибка, а видно в выводе сборки. Метаданных «необязательный вызов» в шапке нет:
вывод делается из текста тела.

| скилл | lean (12) | pult (61) | full (81) | чего нет там, где не подходит |
|---|---|---|---|---|
| generate-artifact | да | нет | да | pult: `find_latest`, `place_download` |
| save-output | да | нет | да | pult: `output_begin` |
| text-normalizer | да | да | да | - |
| tz-presentation-dt | да | да | да | - |
| capture-to-assignment | нет | да | да | lean: `pult_cards`, `pult_card_decide`, `pult_card_explain` |
| new-hub | нет | да | да | lean: `pult_create_hub` |
| operational-review | нет | да | да | lean: `pult_cards`, `pult_freshness`, `work_context`, `work_feed`, `work_meetings`, `work_resurface`, `work_ticktick` |
| hub-synth | нет | да | да | lean: `hub_synth_propose`, `pult_card_decide` (досье `hub_synth_context` в lean есть) |
| inbox-triage | нет | нет | да | lean: `list_inbox`, `refine_inbox`, `apply_refinement`; pult: `refine_inbox`, `apply_refinement` |

**`dt-owner` (PROFILE-1) - единственный скилл, которого нет в git:** он ГЕНЕРИРУЕТСЯ из профиля
владельца при `dt skills export cowork|kimi|cherry` (`rules.md` + первый абзац `about.md` до 600 символов по границе предложения, шапка
«источник, версия, не править руками»; тот же текст отдает `dt owner export`). Нет профиля или
`rules.md` пуст - скилл не создается, причина в выводе и в `skipped` манифеста экспорта. Он не входит
в таблицу выше и в «Реестр: 9 скиллов»; зовет только `owner_profile` (есть во всех профилях).

Таблица - снимок на 2026-10-31 (HUB-SYNTH-1: + `hub-synth`); источник истины - `fit_profile` (тест `test_docs_numbers_follow_fit_profile`).

## Слияние MODEL-1 (2026-10-29)

| было | стало |
|---|---|
| `new-entity-hub`, `new-presale`, `new-project` | **`new-hub`** - пресеты вида: клиент / продукт / проект / пресейл / направление (+ отрасль, контакт) |
| `operational-review` + `morning` (утренний бриф, не наш скилл библиотеки) | **`operational-review`** - режимы `утро` / `сводка` |

Старые имена остаются **триггерами в `description`** нового скилла (хост находит `new-hub` по фразе
«заведи пресейл» или «new-project»). Отдельных скиллов-алиасов в реестре нет: экспорт и prompts
содержат ровно реестр. В библиотеке аккаунта Cowork старые `new-project`, `new-presale`,
`new-entity-hub` и `morning` снимаются при переопубликации (после приемки) - это делает постановщик,
генератор в библиотеку не пишет. Если нужен переходный период, вернуть тонкие алиасы
(`description` со старым именем + тело «см. new-hub, пресет X») и удалить их в следующем релизе.
