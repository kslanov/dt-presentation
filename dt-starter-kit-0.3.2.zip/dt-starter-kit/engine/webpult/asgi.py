"""DAEMON-1 — веб-пульт: ЕДИНСТВЕННАЯ реализация ``GET /`` и ``POST /api/<tool>`` (ASGI).

Пульт и ``/mcp/<профиль>`` живут в одном процессе на одном порту (демон ``com.dt.server``);
автономный ``python webpult/server.py`` поднимает тот же ASGI без ``/mcp``. Контракт
WEBPULT-ACCESS-1: профиль ``pult``, два токена (read/write), cookie, ``inject_mode``, write-гейт
(403 ``write_token_required``), 404 вне профиля, аудит с ``auth``/хвостом токена/``peer``. Разбор
токенов, ``inject_mode`` и константы - в ``webpult.server`` (общие хелперы). Инструмент идет в
поток (``anyio``), хост запроса - ``webpult`` через ContextVar ``core.host`` (хост процесса не
трогаем).
"""

from __future__ import annotations

import inspect
import json
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from core import eval_journal as _eval_journal
from core.contract import unknown_param_refusal
from core.daemon import heavy_slot, track_tool
from core.host import (
    SURFACE_WEBPULT,
    bind_session_host,
    clear_request,
    set_request,
    unbind_session_host,
)
from core.operational.pult import record_action
from core.web_tokens import FixedTokens, WebTokens, tail
from webpult import server as _wp

Scope = dict[str, Any]
Receive = Callable[[], Awaitable[dict[str, Any]]]
Send = Callable[[dict[str, Any]], Awaitable[None]]


class _Headers:
    """``.get`` как у ``http.server`` (регистр не важен) - для ``webpult.server._presented``."""

    def __init__(self, scope: Scope) -> None:
        self._h = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope["headers"]}

    def get(self, name: str, default: str = "") -> str:
        return self._h.get(name.lower(), default)


async def _body(receive: Receive) -> bytes:
    chunks: list[bytes] = []
    while True:
        msg = await receive()
        chunks.append(msg.get("body", b""))
        if not msg.get("more_body"):
            return b"".join(chunks)


async def _send(
    send: Send, status: int, body: bytes, ctype: str, extra: list[tuple[str, str]] | None = None
) -> None:
    headers = [(b"content-type", ctype.encode()), (b"content-length", str(len(body)).encode())]
    headers += [(k.lower().encode(), v.encode()) for k, v in extra or []]
    await send({"type": "http.response.start", "status": status, "headers": headers})
    await send({"type": "http.response.body", "body": body})


async def _json(send: Send, status: int, obj: Any) -> None:
    await _send(
        send,
        status,
        json.dumps(obj, ensure_ascii=False).encode("utf-8"),
        "application/json; charset=utf-8",
    )


async def _fail(send: Send, http: int, code: str, text: str) -> None:
    await _json(send, http, {"isError": True, "code": code, "content": [{"text": text}]})


def unknown_args(fn: Any, args: dict[str, Any]) -> tuple[list[str], list[str]]:
    """``(неизвестные, допустимые)`` ключи тела по сигнатуре инструмента (ARGS-STRICT-1).

    Та же семантика, что у границы MCP (``StrictFastMCP.call_tool``): имя, которого нет среди
    параметров, - отказ ДО вызова. Инструмент с ``**kwargs`` или без читаемой сигнатуры - не
    проверяется (``([], [])``): сомнение не повод отказывать здоровому вызову.
    """
    try:
        params = inspect.signature(fn).parameters.values()
    except (TypeError, ValueError):
        return [], []
    if any(p.kind is inspect.Parameter.VAR_KEYWORD for p in params):
        return [], []
    accepted = [
        p.name for p in params
        if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY)
    ]
    return [key for key in args if key not in accepted], accepted


def make_pult_asgi(tools: Any, tokens: Any | None = None, html_path: Path | None = None):
    """ASGI-приложение пульта поверх ``tools`` (модуль ``mcp-server/server.py``)."""
    import anyio

    tokens = tokens if tokens is not None else WebTokens()
    if isinstance(tokens, str):  # прежняя сигнатура: строка = только read-токен
        tokens = FixedTokens(tokens)
    names, write_names = _wp.tool_sets(tools)
    guard = getattr(tools, "guarded_tool", None)

    def call_tool(
        name: str, args: dict[str, Any], ctx_args: tuple[str, str, str], quiet: bool = False
    ) -> Any:
        """Выполняется в потоке: контекст запроса и хост ``webpult`` ставятся здесь.

        ``quiet`` (PERSONAL-1, заголовок ``X-DT-No-Journal: 1``) - вызов не пишется в журнал
        запросов поиска (:func:`core.eval_journal.suppressed`)."""
        host_token = bind_session_host("webpult", surface=SURFACE_WEBPULT)
        req_token = set_request(*ctx_args)
        try:
            fn = getattr(tools, name)
            with track_tool(), _eval_journal.suppressed(quiet):  # SANDBOX-DAEMON: поток виден
                return (guard(fn) if callable(guard) else fn)(**args)
        finally:
            clear_request(req_token)
            unbind_session_host(host_token)

    async def app(scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            return
        path = scope["path"]
        query = scope.get("query_string", b"").decode("latin-1")
        headers = _Headers(scope)
        presented, from_query = _wp._presented(headers, query)
        auth = tokens.classify(presented)

        if scope["method"] in ("GET", "HEAD") and path in ("/", "/index.html", "/pult.html"):
            if auth is None:
                await _send(send, 401, "Нужен токен.".encode(), "text/html; charset=utf-8")
                return
            try:
                html = (html_path or _wp.resolve_html_path()).read_bytes()
            except OSError:
                await _send(send, 500, b"pult.html not found", "text/plain; charset=utf-8")
                return
            cookies: list[tuple[str, str]] = []
            read_tok = tokens.read()
            if read_tok:
                cookies.append(
                    (
                        "Set-Cookie",
                        f"{_wp.COOKIE_READ}={read_tok}; Path=/; "
                        f"Max-Age={_wp.READ_COOKIE_MAX_AGE}; HttpOnly; SameSite=Lax",
                    )
                )
            if tokens.classify(from_query) == "write" and tokens.rw():
                cookies.append(
                    (
                        "Set-Cookie",
                        f"{_wp.COOKIE_RW}={tokens.rw()}; Path=/; "
                        f"Max-Age={_wp.RW_COOKIE_MAX_AGE}; HttpOnly; SameSite=Lax",
                    )
                )
            await _send(
                send,
                200,
                _wp.inject_mode(html, auth, write_names),
                "text/html; charset=utf-8",
                cookies,
            )
            return

        if scope["method"] != "POST" or not path.startswith("/api/"):
            await _send(send, 404, b"not found", "text/plain; charset=utf-8")
            return
        name = path[len("/api/") :]
        if name not in names:
            await _fail(send, 404, _wp.CODE_UNKNOWN_TOOL, f"unknown tool: {name}")
            return
        is_write = name in write_names
        peer = (scope.get("client") or ("", 0))[0]
        matched = tokens.rw() if auth == "write" else tokens.read()
        ctx = (auth or "none", tail(matched) if auth else "", peer)

        # запись аудита идет в поток: ``record_action`` читает контекст запроса и хост
        def audit(outcome: str) -> None:
            host_token = bind_session_host("webpult", surface=SURFACE_WEBPULT)
            req_token = set_request(*ctx)
            try:
                record_action("web_api", {"tool": name}, outcome)
            finally:
                clear_request(req_token)
                unbind_session_host(host_token)

        if auth is None:
            if is_write:
                await anyio.to_thread.run_sync(audit, "denied:auth_required")
            await _fail(send, 401, _wp.CODE_AUTH_REQUIRED, "нужен токен (?t=… или Bearer)")
            return
        if is_write and auth != "write":
            await anyio.to_thread.run_sync(audit, "denied:write_token_required")
            await _fail(
                send,
                403,
                _wp.CODE_WRITE_TOKEN_REQUIRED,
                "нужен токен записи: открой ссылку с rw-токеном",
            )
            return
        try:
            args = json.loads((await _body(receive)) or b"{}")
            if not isinstance(args, dict):
                raise ValueError("body must be a JSON object")
        except (ValueError, json.JSONDecodeError) as e:
            await _fail(send, 400, _wp.CODE_BAD_REQUEST, f"bad request: {e}")
            return
        unknown, accepted = unknown_args(getattr(tools, name, None), args)
        if unknown:
            # ARGS-STRICT-1: лишний ключ - 400 с конвертом CONTRACT-2 (не ``tool_error``),
            # инструмент не вызван; ``TypeError`` ВНУТРИ инструмента остается ``tool_error``.
            refusal = unknown_param_refusal(name, unknown, accepted)

            def record_refusal() -> None:
                host_token = bind_session_host("webpult", surface=SURFACE_WEBPULT)
                req_token = set_request(*ctx)
                try:
                    for hook, extra in (("_record_degradation", (refusal,)),
                                        ("_record_tool_call", (False, 0))):
                        fn = getattr(tools, hook, None)
                        if callable(fn):
                            fn(name, *extra)
                finally:
                    clear_request(req_token)
                    unbind_session_host(host_token)

            await anyio.to_thread.run_sync(record_refusal)
            if is_write:
                await anyio.to_thread.run_sync(audit, f"denied:{_wp.CODE_UNKNOWN_PARAM}")
            await _json(send, 400, {
                "isError": True, "code": _wp.CODE_UNKNOWN_PARAM,
                "content": [{"text": refusal["error"]}], **refusal,
            })
            return
        try:
            async with heavy_slot(name):  # generate/retrieve: слот семафора демона
                quiet = headers.get(_eval_journal.HEADER_NO_JOURNAL) == "1"
                val = await anyio.to_thread.run_sync(call_tool, name, args, ctx, quiet)
            outcome = "ok"
            reply = {"structuredContent": _wp._wrap(val), "isError": False}
        except Exception as e:  # noqa: BLE001 - сбой инструмента -> в ответ, не в 500
            outcome = "error"
            reply = {
                "isError": True,
                "code": _wp.CODE_TOOL_ERROR,
                "content": [{"text": str(e)[:500]}],
            }
        if is_write:
            await anyio.to_thread.run_sync(audit, outcome)
        await _json(send, 200, reply)

    return app


__all__ = ["make_pult_asgi"]
