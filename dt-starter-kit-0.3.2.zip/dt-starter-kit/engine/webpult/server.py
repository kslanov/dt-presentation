"""PULT-WEB — веб-пульт: общие хелперы + тонкий запуск (доступ с телефона через Tailscale).

DAEMON-1: реализация ``GET /`` и ``POST /api/<tool>`` ОДНА - ASGI в ``webpult/asgi.py``
(``make_pult_asgi``); тот же код обслуживает пульт в демоне ``com.dt.server`` (рядом с ``/mcp``).
Прежний ``ThreadingHTTPServer``-путь удален. Здесь остались: константы и машинные коды отказов,
``tool_sets``/``inject_mode``/``startup_links``/``resolve_html_path``/``load_tool_module`` и
:func:`serve` - поднять ТОТ ЖЕ ASGI-пульт отдельно от MCP (``python webpult/server.py``, без
``/mcp``; боевой запуск - демон: ``mcp-server/server.py --transport http``).

Безопасность (WEBPULT-ACCESS-1): ``/api`` принимает только инструменты профиля ``pult``
(``PROFILES["pult"]``; остальное - 404 ``unknown_tool``) и два токена. ``read`` (``.secrets/
web_token`` / ``DT_WEB_TOKEN``) открывает страницу и инструменты чтения, ``write`` (``.secrets/
web_token_rw`` / ``DT_WEB_TOKEN_RW``) - ещё и ``WRITE_TOOLS ∩ pult``; запись с read-токеном - 403
``write_token_required``. Токен: ``Bearer`` / ``?t=`` / cookie (``dtweb`` - год, ``dtweb_rw`` -
7 дн.; ставятся при заходе со ``?t=``). Каждый отказ несёт машинный ``code``. Вызовы пишут в журналы
``surface=webpult``, ``auth``, последние 4 символа токена и peer-IP (``X-Forwarded-For`` не
доверяем). Бинд ``0.0.0.0``; наружу порт руками не пробрасываем.
"""

from __future__ import annotations

import importlib.util
import json
import os
import socket
import subprocess
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

ENGINE_ROOT = Path(__file__).resolve().parents[1]
# При запуске `python webpult/server.py` в sys.path попадает папка webpult, а не
# корень engine → импорт `core` (внутри mcp-server) падает. Добавляем корень явно,
# чтобы работало и как файл, и как `python -m webpult.server`.
if str(ENGINE_ROOT) not in sys.path:
    sys.path.insert(0, str(ENGINE_ROOT))

from core.web_tokens import RW_COOKIE_DAYS, WebTokens  # noqa: E402

_TAILSCALE_BIN = "/Applications/Tailscale.app/Contents/MacOS/Tailscale"

DEFAULT_HTML = Path(__file__).resolve().parent / "pult.html"  # источник HTML — репо
DEFAULT_PORT = 8787


def resolve_html_path() -> Path:
    """HTML пульта: источник — репо (VENDOR-HYGIENE-1 п.5).

    Приоритет: ``webpult/pult.html`` (репо) — первым; другой файл (например, артефакт
    ``~/Claude/Artifacts/dt-pult/index.html``) — только по ЯВНОМУ ``DT_PULT_HTML_PATH``
    (прежнее имя ``DT_PULT_HTML`` принимается как синоним). Раньше артефакт стоял первым,
    и копии расходились (allowlist 60/65): веб-пульт отдавал не то, что в git. Файл читается
    на каждый запрос — правки репо видны сразу. Синхрон тел двух копий стережет
    ``test_pult_two_files_have_identical_bodies`` и строка доктора «Пульт: копии».
    """
    candidates = []
    from core.config import pult_html_override

    env = pult_html_override()
    if env:
        candidates.append(Path(env))
    candidates.append(DEFAULT_HTML)
    for cand in candidates:
        if cand.is_file():
            return cand
    return DEFAULT_HTML


def load_tool_module() -> ModuleType:
    """Импортировать ``mcp-server/server.py`` как модуль (дир с дефисом — по пути).

    Переиспользует ВСЕ tool-обёртки MCP (``TOOL_NAMES`` + функции). ``mcp`` SDK не
    требуется — он лениво импортируется только в ``build_server`` (не тут).
    """
    path = ENGINE_ROOT / "mcp-server" / "server.py"
    spec = importlib.util.spec_from_file_location("dt_mcp_server", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


COOKIE_READ = "dtweb"  # год, как раньше
COOKIE_RW = "dtweb_rw"  # неделя (не год): запись - короткоживущее право
READ_COOKIE_MAX_AGE = 31536000
RW_COOKIE_MAX_AGE = RW_COOKIE_DAYS * 86400

# Машинные коды отказов (§9 п.22): клиент (пульт) и тесты различают их по ``code``, не по тексту.
CODE_UNKNOWN_TOOL = "unknown_tool"
CODE_AUTH_REQUIRED = "auth_required"
CODE_WRITE_TOKEN_REQUIRED = "write_token_required"  # noqa: S105 — машинный код отказа, не секрет
CODE_BAD_REQUEST = "bad_request"
CODE_TOOL_ERROR = "tool_error"
CODE_UNKNOWN_PARAM = "unknown_param"  # ARGS-STRICT-1: ключ тела, которого нет в сигнатуре (400)


def resolve_token() -> str:
    """Read-токен (``DT_WEB_TOKEN`` / ``.secrets/web_token``; создается при отсутствии).

    Оставлено для обратной совместимости; сервер использует :class:`core.web_tokens.WebTokens`.
    """
    tokens = WebTokens()
    tokens.ensure()
    return tokens.read() or ""


def _wrap(val: Any) -> Any:
    """Как FastMCP: list-возврат кладём под ``result`` (dict — как есть)."""
    return {"result": val} if isinstance(val, list) else val


def tool_sets(tools: Any) -> tuple[frozenset[str], frozenset[str]]:
    """``(имена, из них write)``: ``/api`` отдает ТОЛЬКО профиль ``pult``.

    Модуль без реестра профилей (фейк в тестах) - прежнее поведение: ``TOOL_NAMES`` целиком,
    записи нет. ``write = WRITE_TOOLS ∩ names``.
    """
    profiles = getattr(tools, "PROFILES", None)
    names = frozenset(profiles["pult"] if profiles else getattr(tools, "TOOL_NAMES", ()))
    from core.instance import is_personal

    if is_personal():  # PERSONAL-2: личный пульт зовет и личные (читающие) инструменты
        names |= frozenset(getattr(tools, "PERSONAL_TOOLS", ()))
    write = frozenset(getattr(tools, "WRITE_TOOLS", ())) & names
    return names, write


def _presented(headers: Any, query: str) -> tuple[list[str], list[str]]:
    """``(все предъявленные токены, только из ?t=)``: Bearer, ``?t=``, cookie обоих видов."""
    from urllib.parse import unquote

    from_query = [unquote(p[2:]) for p in query.split("&") if p.startswith("t=")]
    out = list(from_query)
    auth = headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        out.append(auth[7:])
    for part in headers.get("Cookie", "").split(";"):
        k, _, v = part.strip().partition("=")
        if k in (COOKIE_READ, COOKIE_RW) and v:
            out.append(v)
    return out, from_query


def inject_mode(html: bytes, mode: str, write_tools: frozenset[str]) -> bytes:
    """Режим доступа и набор write-инструментов - в страницу при отдаче (файл на диске не меняется).

    ``window.__DT_WEB_MODE`` (``read`` | ``write``) и ``window.__DT_WEB_WRITE_TOOLS`` читает фронт:
    чип режима и честный отказ «нужен токен записи» без запроса в сеть. Артефакт в десктопном
    хосте эти переменные не получает (их там нет) - чипа нет, поведение прежнее.
    """
    from core.instance import instance_name

    inst = instance_name()  # PERSONAL-2: веб-пульт экземпляра знает, чей он (переключателя нет)
    extra = f"window.__DT_INSTANCE={json.dumps(inst)};" if inst else ""
    snippet = (
        f"<script>window.__DT_WEB_MODE={json.dumps(mode)};"
        f"window.__DT_WEB_WRITE_TOOLS={json.dumps(sorted(write_tools))};{extra}</script>"
    ).encode()
    marker = b"</head>"
    idx = html.find(marker)
    return html[:idx] + snippet + html[idx:] if idx >= 0 else snippet + html


def startup_links(
    tokens: Any, port: int, *, tailscale: str | None, lan: str | None
) -> list[str]:
    """Ссылки при старте. read - для закладки (Tailscale, Wi-Fi, localhost); rw - ТОЛЬКО
    локально и по Tailscale, с пометкой срока cookie. По Wi-Fi/публично запись не выдается."""
    read, rw = tokens.read(), tokens.rw()
    lines: list[str] = []
    if tailscale and read:
        lines.append(f"  📱 Tailscale (чтение):  http://{tailscale}:{port}/?t={read}")
    elif read:
        lines.append(f"  📱 Tailscale-IP не найден — `tailscale ip -4` и вставь: "
                     f"http://<100.x>:{port}/?t={read}")
    if tailscale and rw:
        lines.append(f"  ✍️  Tailscale (чтение и решения, cookie на {RW_COOKIE_DAYS} дней): "
                     f"http://{tailscale}:{port}/?t={rw}")
    if lan and read:
        lines.append(f"  🖥  Wi-Fi (чтение):     http://{lan}:{port}/?t={read}")
    if read:
        lines.append(f"  🖥  локально (чтение):  http://localhost:{port}/?t={read}")
    if rw:
        lines.append(f"  ✍️  локально (чтение и решения, {RW_COOKIE_DAYS} дней): "
                     f"http://localhost:{port}/?t={rw}")
    return lines


def _lan_ip() -> str | None:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return None


def _tailscale_ip() -> str | None:
    for cmd in (["tailscale", "ip", "-4"], [_TAILSCALE_BIN, "ip", "-4"]):
        try:
            out = subprocess.run(cmd, capture_output=True, text=True, timeout=3)  # noqa: S603 — args code-built, no shell; inputs are our own paths
        except (OSError, subprocess.SubprocessError):
            continue
        for line in out.stdout.split():
            if line.strip().startswith("100."):
                return line.strip()
    return None


def announce(tokens: WebTokens, port: int, html: Path, created: list[str] | None = None) -> None:
    """Строки старта в stdout.

    В терминале - ссылки с токенами (read - закладка, rw - локально/TS); под launchd stdout - файл
    лога, поэтому токены целиком туда НЕ пишутся: только хвосты и команда показа (инвариант
    DAEMON-1: токены целиком не логируются)."""
    print(f"DT web-пульт запущен, порт {port}. HTML: {html}")
    if created:
        print(f"  создан токен: {', '.join(created)} (.secrets/, права 0600)")
    if sys.stdout.isatty():
        for line in startup_links(tokens, port, tailscale=_tailscale_ip(), lan=_lan_ip()):
            print(line)
        return
    from core.web_tokens import tail

    print(f"  токены: read …{tail(tokens.read()) or '-'}, rw …{tail(tokens.rw()) or '-'}; "
          "ссылки: `dt web-token show read|rw`")


def serve(
    *, port: int = DEFAULT_PORT, host: str = "0.0.0.0", html_path: Path | None = None  # noqa: S104 — binds LAN interface to serve the pult by design
) -> None:
    """Поднять ТОЛЬКО пульт (без ``/mcp``) тем же ASGI, что в демоне. Блокирующе.

    Боевой запуск - демон ``mcp-server/server.py --transport http`` (``com.dt.server``); этот вход
    остается для ручного/отладочного запуска пульта отдельно."""
    import uvicorn

    from webpult.asgi import make_pult_asgi

    tools = load_tool_module()
    tokens = WebTokens()
    created = tokens.ensure()  # недостающие файловые токены (read как раньше, rw - новый)
    html = html_path or resolve_html_path()
    announce(tokens, port, html, created)
    # access_log выключен: в строках запроса пульта бывает ``?t=<токен>``
    # proxy_headers=False: peer в аудите - реальный TCP-peer (``X-Forwarded-For`` не доверяем)
    uvicorn.run(make_pult_asgi(tools, tokens, html), host=host, port=port, log_level="warning",
                access_log=False, proxy_headers=False)


if __name__ == "__main__":
    serve(port=int(os.environ.get("DT_WEB_PORT") or DEFAULT_PORT))
