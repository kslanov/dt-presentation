---
name: new-hub
description: 'Завести хаб в vault Digital Twin одним скиллом с пресетами вида: клиент, продукт, проект, пресейл, направление (также отрасль, контакт) - правильный frontmatter, track, crosswalk Timetta. Use when the user says «заведи хаб клиента/продукта/проекта/отрасли/направления», «заведи пресейл», «подними пресейл-хаб», «новый проект», «завести проект», create/scaffold a hub or project. Заменяет скиллы new-entity-hub, new-presale и new-project (их имена остаются триггерами).'
version: 0.3.2
---

# new-hub (хаб сущности по пресету)

Один скилл вместо трех (new-entity-hub, new-presale, new-project): общий каркас хаба `type: hub` + `entity: <вид>` и пресет под вид. Только vault-сторона: **Deal в Timetta не создаётся** (его заводит администратор CRM по поручению; зеркало подхватит), DT в Timetta не пишет.

## Шаги
1. **Вид (пресет) - спросить, если не назван:** `клиент` | `продукт` | `проект` | `пресейл` | `направление` (также `отрасль`, `контакт`). Имя сущности. Для проекта и пресейла - рамка: клиент, отрасль, продукт(ы), мандат/конфиденциальность, первый deliverable.
2. **Дубль:** `find_notes(query=<имя>)` - хаб не должен дублировать существующий (сверить `04-clients/`, `03-projects/`, `02-knowledge/`). Нашелся - сказать и не заводить второй.
3. **Создать каркас.** Основной путь - `pult_create_hub(name, entity, status, track)`: идемпотентно, frontmatter `type: hub` + `entity` + `aliases: [name]`. Нет такого инструмента в профиле хоста - файлом по пресету ниже (папки по конвенции vault, id `<вид>-<slug>`).
4. **Пресет вида:**

   | вид | entity | где | особенности |
   |---|---|---|---|
   | клиент | `client` | `04-clients/` | `id: client-<slug>`; для клиента с парой в Timetta - `timetta_id` + `timetta_sync` (`own`/`monitor`) |
   | продукт / отрасль / направление | `product` / `industry` / `direction` | `02-knowledge/{products,industries,directions}/` | связи wikilinks с клиентами и проектами |
   | контакт | `person` | по конвенции vault | связь с клиентом через `client:` |
   | проект | `project` | `03-projects/<slug>/hub.md` (+ `notes/`, `documents/`) | **`track` спросить, не угадывать:** `presale` (лид) \| `project` (исполнение) \| `internal`; поля `client` / `industry` / `direction` / `product`; кейс и срезы контекста - в блоке «Ведение» |
   | пресейл | `project` | `03-projects/<slug>/hub.md` | `status: presale`, **`track: presale`** (при выигрыше сделки - промоут в `project` кликом по бейджу в «Дозрели», без миграции id/папки); обязательные `client` / `industry` / `product`; `timetta_id` сделки + `timetta_sync: own`; секция «Связанные сделки/пресейлы»; план: квалификация → обследование → КП/ТКП → защита; срезы под «выиграть»: `client + industry + product + practices + style/letters` |

5. **Связи и чувствительное.** Недостающие сущности - заведи хабами или пометь TBD (curation позже). Исходники - в `notes/` (или `_staging/inbox/` → refine); чувствительное - только в `notes/`, не в контекст генерации.
6. **Крупный проект** - добавить `plan.md` (фазы → deliverables → exit criteria) и `PROGRESS.md` (живой лог); мелкому достаточно хаба.
7. Чтобы хаб увидела линковка и поиск - нужен прогон индекса (`reindex` или кнопка «index сейчас» в пульте).

## Guardrails
- Конвенция id/frontmatter - по существующим хабам; не придумывать поля.
- Deal в Timetta НЕ создаём: только линкуем к существующему (`timetta_id`); новая сделка - поручение администратору (`capture-to-assignment`).
- Один deliverable за сессию; передача между чатами - через hand-off файлы хаба (hub/plan/PROGRESS).
- Артефакты проекта - в `documents/` с провенансом; верификация против exit criteria, не self-report.
