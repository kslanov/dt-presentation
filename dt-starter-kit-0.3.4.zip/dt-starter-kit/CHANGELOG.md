# Changelog

Формат - [Keep a Changelog](https://keepachangelog.com/ru/1.1.0/); версии - `pyproject.toml`
(принцип 17: версии и миграции при появлении второго пользователя). Тег волны и `git describe`
(`dt version`) - рядом, не вместо. Дальше запись пополняет постановщик при приемках.

## [0.3.4] - 2026-11-08

Первая живая установка кита (KIT-REHEARSAL-1, второй человек): шаг `models` не ставил эмбеддер.

### Fixed
- `dt install --step models`: у `BAAI/bge-m3` на Hugging Face весов в `*.safetensors` нет (только
  `pytorch_model.bin`, 2.3 ГБ), а шаблоны эмбеддера (`core/embeddings.py::_ALLOW_PATTERNS`) качали
  только safetensors - на чистой машине скачивались 21 МБ служебных файлов и проверка писала
  «нет файла весов»; у владельца работало только потому, что в кэше лежал старый `pytorch_model.bin`.
  Оба формата в шаблонах; перед скачиванием `core/install/models.py::prefer_single_weights`
  оставляет один по перечню файлов репозитория (safetensors, если есть, иначе bin - двойной
  загрузки нет; перечень недоступен - качается то, что лежит). Тот же выбор у разового онлайн-прогрева
  `DT_EMBED_ALLOW_DOWNLOAD=1`.

## [0.3.3] - 2026-11-08

Почта по аккаунтам (MAIL-ACCOUNTS-1): снимает Known из 0.3.2.

### Added
- `DT_OUTLOOK_FOLDERS` принимает `account` (адрес ящика): мост ищет папку внутри аккаунта
  (`resolveFolderIn`), несколько ящиков и одноименные папки в одном прогоне; ключ треда
  `conv:<адрес>:<id>`, курсор по паре ящик+папка; `DT_OUTLOOK_LEGACY_ACCOUNT` и
  `dt_mail_ingest --migrate-accounts` (dry-run, бэкап, идемпотентно); `--account`, `--list-folders`.
- Отказы с кодом вместо «0 новых»: `folder_unresolved`, `folder_empty_suspicious` (код выхода 5,
  шаг `mail_ingest` FAILED), `outlook_new_mode` (preflight, кэш встреч несвеж по причине).
- Доктор «Почта: ящики и папки»; смоук С-13 идет по всем ящикам и краснеет с кодом причины.
- Мастер `dt install` спрашивает ящики Outlook (по умолчанию все живые, без архивов без аккаунта).

### Fixed
- `dt_mail_ingest --limit` раньше принимался и игнорировался; теперь потолок кандидатов на папку
  (новейшие первыми).
- Рельсы `brain/06-integrations`: вопрос «какие ящики», команда `DT_OUTLOOK_FOLDERS` в формате
  движка с `account`, таблица отказов по кодам (Known 0.3.2 снят).
- Приемка: кривая запись `DT_OUTLOOK_FOLDERS` (строка, без bucket/name) - замечание `config check`
  и доктора, не молчаливое умолчание; `list_folders` - дедуп папок по `id` (Outlook отдает корни
  аккаунтов и их детей на верхнем уровне - счетчики ящиков удваивались); снятое приватностью письмо -
  в память «отказано» (id + класс правила), иначе сухой проход С-13 считал его дырой курсора;
  `record_run` частичного прогона (`--account`/`--folders`) не стирает снимок остальных спецификаций.

## [0.3.2] - 2026-11-08

Кит для первой живой установки (KIT-REHEARSAL-1): код смоука и доктора после SMOKE-DRIFT-1.
Код движка в остальном как в 0.3.1.

### Changed
- Смоук С-3: любая оговорка в ответе `get_facts` с фактами (`truncated`, `facts_outdated`,
  `merges_skipped`, `facts_not_from_ocr`, `store_unavailable`) - здоровый ответ; отказ - только пустые
  факты с кодом; факты без кода - дефект (`tests/_smoke_facts.py::facts_or_refusal`).
- Доктор «Демон DT»: отставание считается по путям кода (`core/daemon.py::CODE_PATHS`,
  `code_drift` через `git diff --quiet`), коммит только в доках после рестарта - ok с числом коммитов.
- Смоук С-13 и доктор дыры курсора: письма новее курсора (`stats.added_after_cursor_by_folder`,
  граница - новейшее письмо папки в манифесте) не считаются дырой; хвост «новее курсора N (ждут
  синхронизации)».
- `ops/README`: элемент, меняющий контракт инструмента, принимается с `make smoke` на боевой машине.

### Known
- Рельсы `brain/06-integrations`: команда `DT_OUTLOOK_FOLDERS '["Inbox"]'` не в формате движка
  (список строк молча заменяется умолчаниями «Входящие»+«Отправленные»); мост читает один ящик -
  умолчание Outlook; в «новом» Outlook читает пустоту без предупреждения. Исправляется в
  MAIL-ACCOUNTS-1 (ветка готова, приемка не проведена). На установку без Outlook не влияет.

## [0.3.1] - 2026-11-02

Кит без имен клиентов владельца (KIT-PRIVACY-1); снимает Known из 0.3.0. Наставник вместо
инсталлера (KIT-MENTOR-1).

### Added
- Наставник (`installer/`): `INSTALL.md` - самодостаточный промпт (72 строки): калибровка уровня
  `novice | confident | expert`, проверка возможностей хоста (читает файлы / выполняет команды),
  ветка «Рельсы с нуля» для веб-чата без файлов; `brain/00-welcome … 07-first-run` в одной форме
  «Картина (новичок/эксперт) → Вопросы → Делаем (сам / даю команду) → Проверка → Если не вышло →
  Переход», фаза `01-prereqs` ставит с человеком Terminal, git, `uv`, Obsidian, Claude Desktop и кит;
  `glossary.md`; `state/` с уровнем, хостом и тем, что уже стояло. `INSTALL.md` лежит и в корне кита,
  README кита «три шага» без предусловий. Тесты рельсов (`tests/test_installer_brain.py`, 27).
- Один сборщик приватных терминов `core/owner/privacy.py`: владелец (`owner.yaml`) + клиенты и другие
  хабы с `aliases` (title, aliases, части slug) - на боевом vault 242 термина; границы слова,
  регистронезависимо, минимум 4 символа. Файл исключений `scripts/privacy-ignore.txt` (термин +
  причина, только по решению владельца); термин из игнор-списка, которого нет в vault, - отказ.
- Гард поставляемого кода `test_no_private_terms_in_shipped_code` по тому же списку; область - корни
  кита `SHIPPED_DIRS` из `scripts/build_starter_kit.py` (один список для теста и сборки).
- `build_starter_kit` - отказ при любом совпадении (файл:термин); `verify_starter_kit` - независимый
  проход по тем же терминам; `--privacy-ignore PATH`.

### Changed
- Нейтрализованы примеры и комментарии в 47 поставляемых файлах (`core`, `cli`, `mcp-server`,
  `webpult`, `scripts`, `skills`, `ops`, `docs`): имена клиентов → `Acme`/«Клиент А», пути примеров →
  `Region/ClientA/…`; поведение кода не менялось (полный pytest 6151/0).
- `cli/_oneoff/` и скрипты по живым данным в кит не кладутся.

## [0.3.0] - 2026-11-01

Установка для второго человека (DEV-3-KIT, фаза B инсталлера).

### Added
- `dt install` - оркестратор установки с состоянием и возобновлением (`.derived/install/state.json`):
  шаги platform → deps → config (мастер) → vault → owner → models → launchd → host → index → doctor,
  каждый идемпотентен; `--check`, `--step`, `--from`, `--yes`, `--dry-run`, `--json`. Шаги зовут
  существующие команды движка (слой CLI: `cli/dt_install_steps.py`).
- `dt install --step models`: загрузка `bge-m3` и `bge-reranker-v2-m3` с прогрессом и докачкой,
  `--models-from` (офлайн-копия кэша), `scripts/build_models_bundle.py` → `dt-models.tar`; доктор «Модели».
- launchd по манифесту роли и коннекторов (`core/install/launchd.py`): `server`, `sync.fast`,
  `sync.index`, `backup` всегда, `meetings` при Outlook, `smoke`/`run.watchdog` - `--ops-full`;
  `ops/install_launchd.sh` - обертка. `dt uninstall [--purge]` (vault не трогает).
- Мозг инсталлера `installer/`: `INSTALL.md` (промпт для Claude), `brain/00-05` (профиль, сетап,
  методология, стиль, интеграции, первый прогон), шаблоны `state/`.
- Стартовый кит: `scripts/build_starter_kit.py` (гард утечек: приватные термины владельца, маски
  токенов, абсолютные пути, запрещенные файлы; `KIT-MANIFEST.json`) и `scripts/verify_starter_kit.py`.
- `dt owner init --name/--email/--company/--domain/--internal-domain`.

### Known
- В коде и скиллах остаются имена клиентов владельца в комментариях и примерах (не данные владельца,
  гардом не ловятся) - KIT-PRIVACY-1 до раздачи кита.

## [0.2.0] - 2026-11-01

Движок для второго человека (DEV-3-CORE, фаза A инсталлера).

### Added
- Коннекторы как выключаемая ось манифеста роли: `core/connectors.py` (`timetta`, `ticktick`,
  `outlook`), `DT_CONNECTORS` = `auto` (дефолт, поведение прежнее) | список | `none` («базовый DT»).
  Выключенный коннектор: секции пульта не объявлены, шаги `dt_sync`/ops заданий/виды карточек/проверки
  доктора пропущены (одна строка «коннектор выключен»), инструменты отвечают конвертом
  `connector_disabled`; `pult_manifest.connectors`, строка «Коннекторы» в «Настройках».
- `engine/vault-template/` - каркас vault, который генерирует `scripts/build_vault_template.py`
  (README папок, политики поиска, шаблоны гайдов стиля, пустые `ingest-roots`/`host-access`, образец
  `mail-filter`, шаблоны профиля); `dt vault init --kind work` и `dt instance add --role work` его
  раскладывают, существующее не трогают.
- `dt version` (версия, `git describe`, версии схем `dt.db`/facts/jobs/чанкер/индекс),
  `version.engine` в `/health`, версия в строке доктора «Демон DT».
- `owner.yaml`: `company: {name, domains, internal_domains}`; `dt owner init` мигрирует старую строку
  `company` (с бэкапом) и дозаполняет пустой шаблон профиля.
- `dt config check`: явно включенный коннектор без секрета, опечатки в `DT_CONNECTORS`, пустые домены
  владельца при включенной почте.

### Changed
- Данные владельца и компании ушли из кода в профиль: почтовые домены владельца - домены `emails` +
  `company.domains` + `DT_MAIL_OWNER_DOMAINS`, служебные - `company.internal_domains` +
  `DT_MAIL_INTERNAL_DOMAINS` (дефолта в коде нет). Запасной образец `mail-filter` нейтрален.
- Справка и подписи пульта без названия компании (кольцо с названием компании → «Подразделение»).
- `ops/SETUP.md` переписан под порядок установки нового человека.
- README папок каркаса помечены маркером `<!-- dt-template: readme` и в индекс/линковку не идут.

### Migration
- Рабочий `.env` без `DT_CONNECTORS` ведет себя как раньше (auto: коннектор включен, если есть его
  секрет/`DT_OUTLOOK_FOLDERS`). Домены владельца: добавить в `owner.yaml` `company.internal_domains`
  (раньше служебные домены были зашиты в коде) - `DT_MAIL_INTERNAL_DOMAINS=… dt owner init` перенесет.

## [0.1.0] - 2026-06

Первая рабочая версия: индекс и поиск, генерация в стиле автора, операционный контур.
