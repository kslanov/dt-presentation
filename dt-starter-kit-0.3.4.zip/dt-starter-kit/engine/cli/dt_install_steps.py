"""Шаги ``dt install`` в порядке выполнения (слой CLI: ``core/`` не импортирует ``cli/``).
Каждый: ``check`` (только чтение) + ``run`` (зовет существующую команду/функцию движка) + пояснение.

::

    platform  → deps → config → vault → owner → models → launchd → host → index → doctor

``check`` отвечает по ФАКТАМ системы (не по ``state.json``): машина, поставленная руками, показывает
«сделано». ``run`` идемпотентен: повтор на готовом шаге ничего не меняет и не затирает.
"""

from __future__ import annotations

import contextlib
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config import env_file
from core.install import wizard
from core.install.base import ABSENT, DONE, PARTIAL, InstallError, Step, StepCheck, StepResult
from core.install.context import InstallContext
from core.install.platform_check import evaluate

__all__ = ["STEPS", "step_by_name", "step_names"]

_INDEX_SKIP = ("eval", "bridge", "doctor")  # первый индекс без качества/моста; доктор - свой шаг
_VAULT_MARKERS = ("_system/ingest-roots.yaml", "_system/retrieval-policies")


# --------------------------------------------------------------------------- platform ------- #
def _platform_check(ctx: InstallContext) -> StepCheck:
    present = (ctx.models_dir / "models--BAAI--bge-m3").is_dir()
    problems, _hints = evaluate(ctx.tools.probe, workspace=ctx.workspace, engine_dir=ctx.engine_dir,
                                models_present=present)
    if problems:
        return StepCheck(ABSENT, "; ".join(problems))
    return StepCheck(DONE, "macOS, место, uv, git, Python - в порядке")


def _platform_run(ctx: InstallContext) -> StepResult:
    present = (ctx.models_dir / "models--BAAI--bge-m3").is_dir()
    problems, hints = evaluate(ctx.tools.probe, workspace=ctx.workspace, engine_dir=ctx.engine_dir,
                               models_present=present)
    if problems:
        raise InstallError("platform", "; ".join(problems), " | ".join(hints))
    return StepResult(note="машина подходит")


# --------------------------------------------------------------------------- deps ---------- #
_SYNC = ("uv", "sync", "--all-extras")


def _deps_check(ctx: InstallContext) -> StepCheck:
    if not (ctx.engine_dir / "pyproject.toml").is_file():
        return StepCheck(ABSENT, f"нет pyproject.toml в {ctx.engine_dir}")
    if not (ctx.engine_dir / ".venv").is_dir():
        return StepCheck(ABSENT, "нет .venv (зависимости не ставились)")
    code, out = ctx.tools.capture([*_SYNC, "--frozen", "--dry-run"], ctx.engine_dir, None)
    if code == 0 and "Would make no changes" in out:
        return StepCheck(DONE, "зависимости на месте (uv sync --dry-run: без изменений)")
    if code != 0:
        return StepCheck(PARTIAL, "uv sync --dry-run не прошел (нет сети или uv.lock изменен)")
    return StepCheck(PARTIAL, "окружение расходится с uv.lock: нужен uv sync")


def _deps_run(ctx: InstallContext) -> StepResult:
    code, tail = ctx.tools.run_cmd(_SYNC, ctx.engine_dir, None)
    if code != 0:
        raise InstallError("deps", f"uv sync завершился с кодом {code}",
                           "проверь интернет и повтори: dt install --step deps")
    return StepResult(output=tail, note="зависимости установлены")


# --------------------------------------------------------------------------- config -------- #
def _config_check(ctx: InstallContext) -> StepCheck:
    if not ctx.env_path.is_file():
        return StepCheck(ABSENT, f"нет {ctx.env_path.name}")
    return StepCheck(DONE, f"{ctx.env_path.name}: {len(env_file.read_keys(ctx.env_path))} ключей")


def _dt_config(ctx: InstallContext, *argv: str) -> str:
    """Существующая команда ``dt config`` на ``.env`` цели; значения секретов не передаются."""
    import dt_config

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        code = dt_config.main(["--env-file", str(ctx.env_path), *argv])
    text = buf.getvalue()
    if code != 0:
        raise InstallError("config", f"dt config {argv[0]} отказал: {text.strip()[:200]}",
                           "исправь значение и повтори: dt install --step config")
    return text


def _config_run(ctx: InstallContext) -> StepResult:
    wizard.complete(ctx, wizard.ALL_FIELDS)
    ctx.guard(ctx.env_path, ctx.vault, ctx.derived)
    lines: list[str] = []
    if not ctx.env_path.is_file():
        lines.append(_dt_config(ctx, "init").strip())
    existing = ctx.env_values()
    if str(ctx.vault) != str(ctx.workspace / "vault") and env_file.read_value(
            ctx.env_path, "DT_VAULT_PATH") != str(ctx.vault):
        lines.append(_dt_config(ctx, "set", "DT_VAULT_PATH", str(ctx.vault)).splitlines()[0])
    conn = ctx.answers.connectors or "none"
    if "DT_CONNECTORS" not in existing or (
            ctx.answers.connectors and existing["DT_CONNECTORS"] != conn):
        lines.append(_dt_config(ctx, "set", "DT_CONNECTORS", conn).splitlines()[0])
    specs = ctx.answers.mailbox_specs
    if specs and existing.get("DT_OUTLOOK_FOLDERS") != specs:
        # MAIL-ACCOUNTS-1 п.6: ящики, выбранные в мастере (адрес+папки), - в DT_OUTLOOK_FOLDERS
        lines.append(_dt_config(ctx, "set", "DT_OUTLOOK_FOLDERS", specs).splitlines()[0])
    note = "настройки записаны (ключей и токенов мастер не просит)"
    if specs:
        note += f"; ящиков Outlook к чтению: {len(ctx.answers.mailboxes)}"
    if conn not in ("none", "auto"):
        note += (f"; коннекторы {conn}: ключи - отдельно, `dt config set <КЛЮЧ> --stdin` "
                 "(installer/brain/04-integrations.md)")
    return StepResult(output="\n".join(lines), note=note)


# --------------------------------------------------------------------------- vault --------- #
def _vault_check(ctx: InstallContext) -> StepCheck:
    if not ctx.vault.is_dir():
        return StepCheck(ABSENT, f"нет папки vault {ctx.vault}")
    missing = [m for m in _VAULT_MARKERS if not (ctx.vault / m).exists()]
    if missing:
        return StepCheck(PARTIAL, "в vault нет: " + ", ".join(missing))
    return StepCheck(DONE, "каркас vault на месте")


def _vault_run(ctx: InstallContext) -> StepResult:
    from core.vault_template import build_vault

    ctx.guard(ctx.vault)
    created = build_vault(ctx.vault, "work")
    note = f"создано {len(created)}" if created else "каркас уже на месте"
    return StepResult(output="\n".join(created[:40]), note=note)


# --------------------------------------------------------------------------- owner --------- #
def _owner_check(ctx: InstallContext) -> StepCheck:
    from core.owner import load_profile

    prof = load_profile(ctx.vault)
    if not prof.exists:
        return StepCheck(ABSENT, "профиля владельца нет")
    if not prof.data.name:
        return StepCheck(PARTIAL, "owner.yaml без имени")
    return StepCheck(DONE, "профиль владельца заполнен")


def _owner_run(ctx: InstallContext) -> StepResult:
    from core.owner import load_profile
    from core.owner.init import init_profile

    wizard.complete(ctx, ("name", "emails", "company", "domains", "internal_domains"))
    ctx.guard(ctx.vault)
    ans = ctx.answers
    res = init_profile(
        ctx.vault, environ=ctx.environ(), people=ans.people, name=ans.name, emails=ans.emails,
        company=ans.company, domains=ans.domains, internal_domains=ans.internal_domains)
    prof = load_profile(ctx.vault)
    if not prof.data.name:
        raise InstallError(
            "owner", "owner.yaml уже есть и заполнен без имени (свой файл не затираю)",
            "впиши name в vault/_system/profile/owner.yaml или `dt owner init --force`")
    parts = [f"создан {n}" for n in res.created] + [f"уже есть {n}" for n in res.skipped]
    return StepResult(output="; ".join(parts), note="профиль владельца записан")


# --------------------------------------------------------------------------- models -------- #
def _models_check(ctx: InstallContext) -> StepCheck:
    from core.install.models import models_step_check

    return models_step_check(ctx)


def _models_run(ctx: InstallContext) -> StepResult:
    from core.install.models import models_step_run

    return models_step_run(ctx)


# --------------------------------------------------------------------------- launchd ------- #
def _launchd_check(ctx: InstallContext) -> StepCheck:
    from core.install.launchd import launchd_step_check

    return launchd_step_check(ctx)


def _launchd_run(ctx: InstallContext) -> StepResult:
    from core.install.launchd import launchd_step_run

    return launchd_step_run(ctx)


# --------------------------------------------------------------------------- host ---------- #
_MANUAL_HOSTS = {
    "cherry": "Cherry Studio: регистрация руками в UI (`dt host-config cherry`, скиллы - "
              "`dt skills export cherry`)",
    "none": "хост не выбран (--host none): подключить позже `dt host-config <хост> --install`",
}


def _host_check(ctx: InstallContext) -> StepCheck:
    host = ctx.host
    if host in _MANUAL_HOSTS:
        return StepCheck(DONE, _MANUAL_HOSTS[host])
    from core.host_config import VERDICT_DAEMON, verify_host

    verdict = verify_host(host, home=ctx.home) if host != "kimi" else verify_host(host)
    if verdict["verdict"] == VERDICT_DAEMON:
        return StepCheck(DONE, f"{host}: запись digital-twin на месте ({verdict['path']})")
    state = ABSENT if verdict["verdict"] == "missing" else PARTIAL
    return StepCheck(state, f"{host}: {verdict['verdict']} - {verdict['reason']}")


def _host_run(ctx: InstallContext) -> StepResult:
    host = ctx.host
    if host in _MANUAL_HOSTS:
        return StepResult(note=_MANUAL_HOSTS[host], skipped=True)
    wizard.complete(ctx, ("host",))
    if host == "kimi":
        return _host_kimi(ctx)
    from core.host_config import (
        SERVER_NAME,
        HostConfigError,
        daemon_url_entry,
        default_profile,
        install_entry,
        install_target,
        shim_entry,
    )
    from core.web_tokens import WebTokens

    ctx.guard(ctx.home)
    secrets = ctx.workspace / ".secrets"
    profile = default_profile(host)
    try:
        target = install_target(host, ctx.home)
        WebTokens(directory=secrets).ensure()  # токены создает и демон при старте: не ждем его
        if host == "claude":
            entry = shim_entry(profile, "rw", engine=ctx.engine_dir, secrets=secrets)
        else:
            entry = daemon_url_entry(profile, "rw", secrets=secrets)
        done = install_entry(host, entry, path=target, name=SERVER_NAME, relaunch=ctx.relaunch,
                             desktop=ctx.tools.desktop)
    except (HostConfigError, ValueError) as exc:
        code = getattr(exc, "code", "")
        hint = {"desktop_running": "закрой Claude Desktop или повтори с --relaunch",
                "host_not_found": f"запусти {host} один раз, чтобы он создал свой конфиг"
                }.get(code, "см. `dt host-config " + host + " --install`")
        raise InstallError("host", str(exc), hint) from exc
    words = {"created": "создан файл", "added": "ключ добавлен", "updated": "ключ обновлен",
             "unchanged": "без изменений"}
    note = f"{host}: {words[done['outcome']]} ({done['path']})"
    if done["outcome"] != "unchanged" and not any("запущен снова" in s for s in done["steps"]):
        note += "; перезапусти хост (Cmd+Q и открыть снова)"
    return StepResult(output="; ".join(done["steps"]), note=note,
                      details={"backup": done["backup"] or ""})


def _host_kimi(ctx: InstallContext) -> StepResult:
    import dt_plugin

    out = ctx.engine_dir / "plugins" / "kimi-work"
    ctx.guard(out)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        code = dt_plugin.main(["kimi", "--out", str(out), "--install"])
    if code != 0:
        raise InstallError("host", f"dt plugin kimi --install: {buf.getvalue().strip()[:200]}",
                           "запусти Kimi один раз и повтори: dt install --step host")
    return StepResult(output=buf.getvalue()[-500:], note="плагин Kimi установлен; перезапусти Kimi")


# --------------------------------------------------------------------------- index --------- #
def _index_check(ctx: InstallContext) -> StepCheck:
    if (ctx.derived / "index_meta.json").is_file():
        return StepCheck(DONE, "индекс построен (index_meta.json)")
    return StepCheck(ABSENT, "индекса еще нет")


def index_steps() -> list[str]:
    """Шаги первого индекса: все ночные шаги режима ``index`` без ``eval``/``bridge``/``doctor``."""
    import dt_sync

    return [name for name, _thunk in dt_sync.MODES["index"] if name not in _INDEX_SKIP]


def _index_run(ctx: InstallContext) -> StepResult:
    ctx.guard(ctx.derived)
    ctx.derived.mkdir(parents=True, exist_ok=True)
    chosen = ",".join(index_steps())
    code, tail = ctx.tools.run_cmd(
        ctx.python_cmd("cli/dt_sync.py", "index", "--steps", chosen), ctx.engine_dir,
        ctx.child_env())
    if code != 0:
        raise InstallError("index", f"первый индекс завершился с кодом {code}",
                           "посмотри вывод выше и повтори: dt install --step index "
                           "(индекс продолжит с места остановки)")
    return StepResult(output=tail, note="первый индекс построен")


# --------------------------------------------------------------------------- doctor -------- #
def _doctor_check(ctx: InstallContext) -> StepCheck:
    from core.diagnostics import snapshot_state

    snap, err = snapshot_state(path=ctx.derived / "doctor_last.json")
    if snap is None:
        return StepCheck(ABSENT, err or "доктор еще не запускался")
    if snap["fails"]:
        return StepCheck(PARTIAL, f"доктор: критичных {snap['fails']}")
    return StepCheck(DONE, f"доктор без критичных (предупреждений {snap['warns']})")


def _doctor_run(ctx: InstallContext) -> StepResult:
    ctx.guard(ctx.derived)
    code, tail = ctx.tools.run_cmd(ctx.python_cmd("cli/dt_doctor.py"), ctx.engine_dir,
                                   ctx.child_env())
    if code != 0:
        raise InstallError("doctor", "доктор нашел критичные проблемы (FAIL)",
                           "исправь по подсказкам выше и повтори: dt install --step doctor")
    return StepResult(output=tail, note="доктор: критичных нет")


STEPS: list[Step] = [
    Step("platform", "Машина", "macOS 14+, место на диске, uv, git, Python (ничего не ставлю - "
         "только проверяю и подсказываю)", _platform_check, _platform_run,
         "platform.mac_ver, shutil.disk_usage, uv python find"),
    Step("deps", "Зависимости", "Библиотеки движка в .venv (uv sync --all-extras)",
         _deps_check, _deps_run, "uv sync --all-extras"),
    Step("config", "Настройки", "Файл .env из шаблона + ответы мастера (vault, владелец, хост, "
         "коннекторы); ключи не спрашиваются", _config_check, _config_run,
         "dt config init / set"),
    Step("vault", "Каркас vault", "Папки и шаблоны вашего vault (существующее не трогается)",
         _vault_check, _vault_run, "core.vault_template.build_vault (dt vault init --kind work)"),
    Step("owner", "Профиль владельца", "Кто вы: имя, почты, компания, домены - из ответов мастера",
         _owner_check, _owner_run, "core.owner.init.init_profile (dt owner init)"),
    Step("models", "Модели поиска", "bge-m3 и bge-reranker-v2-m3 (~4.5 ГБ, разово, с прогрессом; "
         "офлайн - --models-from)", _models_check, _models_run,
         "core.install.models (snapshot_download | dt-models.tar)"),
    Step("launchd", "Плановые задания", "Демон движка, синк, индекс, бэкап (+ встречи при "
         "Outlook; смоук и сторож - с --ops-full): launchd, без sudo", _launchd_check,
         _launchd_run, "ops/launchd/*.plist по манифесту + launchctl"),
    Step("host", "Подключение ассистента", "Запись digital-twin в конфиг выбранного хоста",
         _host_check, _host_run, "core.host_config.install_entry (dt host-config --install)"),
    Step("index", "Первый индекс", "Первичная индексация vault (без качества и моста)",
         _index_check, _index_run, "cli/dt_sync.py index --steps …"),
    Step("doctor", "Диагностика", "Итоговая проверка: должно быть без критичных проблем",
         _doctor_check, _doctor_run, "cli/dt_doctor.py"),
]


def step_names() -> list[str]:
    return [s.name for s in STEPS]


def step_by_name(name: str) -> Step:
    for step in STEPS:
        if step.name == name:
            return step
    raise KeyError(name)

