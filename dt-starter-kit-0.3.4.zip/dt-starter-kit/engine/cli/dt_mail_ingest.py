"""dt-mail-ingest — render Outlook correspondence into per-thread vault notes.

Thin wrapper over :func:`core.legacy.mail.ingest_mail`: pulls the configured
Outlook folders (Sent + Входящие by default) through the read-only bridge
(:class:`core.operational.outlook_bridge.OutlookBridge`) and writes/updates ONE
``_legacy/correspondence/<thread>.md`` note per conversation (spanning Inbox +
Sent), governed by the conversationId thread manifest for idempotent, resumable,
append-only intake. It does NOT embed — run ``dt_index`` afterwards. CLI depends
on core, never the reverse (architecture §8). No LLM, read-only.

Usage:
    uv run python cli/dt_mail_ingest.py [--folders sent,inbox] [--since DATE]
                                        [--scope incremental|full] [--dry-run]
                                        [--limit N] [--vault PATH]
    uv run python cli/dt_mail_ingest.py --dry-run --explain-privacy   # privacy-отказы окна
    uv run python cli/dt_mail_ingest.py --refilter [--limit 50] [--report out.json]   # dry-run
    uv run python cli/dt_mail_ingest.py --refilter --apply [--limit 50]

``--refilter`` (MAIL-FILTER-1 п.4) применяет правила ``_system/mail-filter.yaml`` к накопленному
корпусу по сайдкарам (Outlook НЕ нужен): dry-run по умолчанию; порядок - dry-run → ``--limit 50
--apply`` → ``dt_index`` (reindex_inc снимает исчезнувшие заметки) → полный ``--apply`` →
``dt_index``.
MAIL-LOCK-1: писатель манифеста почты (ингест без ``--dry-run``, ``--refilter --apply``) берет
``dt-sync.lock`` (:mod:`core.runlock`): занят - ждет ``--wait`` секунд (дефолт 600,
``DT_MAIL_LOCK_WAIT_S``) и пишет «ждал лок N с»; ``--no-wait`` - отказ с кодом ``sync_busy`` и
именем держателя (exit 4). Внутри ``dt_sync fast`` лок уже наш. Dry-run лок не берет.
``--explain-privacy`` (только с ``--dry-run``) печатает в консоль правило/дату/тему[:60] каждого
privacy-отказа окна и счетчики до/после - в журнал и файлы не пишет. Боевой прогон (без
``--dry-run``) пишет в журнал отказов ``privacy_probe`` с id письма и КЛАССОМ правила
(MAIL-PRIVACY-2), без темы и фамилии.
"""

from __future__ import annotations

import argparse
import os
import signal
import sys
from pathlib import Path

# cli/ is not an importable package; put our own dir on sys.path so the shared
# _env helper imports cleanly (matches dt_legacy_ingest.py / dt_sync.py).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.config import (
    default_vault_path,
    folder_label,
    normalize_account,
    outlook_folders,
    outlook_legacy_account,
)
from core.legacy.mail import ingest_mail
from core.operational.outlook_bridge import (
    OutlookBridge,
    OutlookNewModeError,
    OutlookUnavailableError,
)

# Код выхода: часть спецификаций не прочиталась (folder_unresolved / folder_empty_suspicious).
# Шаг mail_ingest в dt_sync при любом ненулевом коде - FAILED (3 - Outlook недоступен).
EXIT_FOLDER_PROBLEMS = 5


def _select_folders(requested: str | None, account: str | None = None) -> list[dict[str, str]]:
    """Resolve ``--folders sent,inbox`` / ``--account a@b.c`` against the configured specs.

    Order follows the request; unknown buckets are reported and skipped. Without
    ``--folders``, all configured folders are ingested in config order. MAIL-ACCOUNTS-1:
    один bucket может быть у нескольких ящиков (``inbox`` у двух аккаунтов) - ``--folders inbox``
    берет ВСЕ такие спецификации, ``--account`` оставляет спецификации одного ящика.
    """
    configured = outlook_folders()
    acc = normalize_account(account)
    if acc:
        configured = [s for s in configured if normalize_account(s.get("account")) == acc]
        if not configured:
            print(f"  ! account {acc!r} не найден в DT_OUTLOOK_FOLDERS")
            return []
    if not requested:
        return configured
    by_bucket: dict[str, list[dict[str, str]]] = {}
    for spec in configured:
        by_bucket.setdefault(spec["bucket"].lower(), []).append(spec)
    selected: list[dict[str, str]] = []
    for raw in requested.split(","):
        bucket = raw.strip().lower()
        if not bucket:
            continue
        specs = by_bucket.get(bucket)
        if not specs:
            print(
                f"  ! unknown folder bucket {bucket!r} — configured: "
                f"{', '.join(by_bucket) or '(none)'}"
            )
            continue
        for spec in specs:
            if spec not in selected:
                selected.append(spec)
    return selected


def _safe_state(action) -> None:
    """Запись снимка для доктора: сбой снимка не ломает ингест (ни молча, ни падением)."""
    try:
        from core.legacy import mail_accounts

        action(mail_accounts)
    except Exception as exc:  # noqa: BLE001
        print(f"[mail] снимок ящиков не записан: {exc}")


def _run_list_folders() -> int:
    """``--list-folders``: перечень ящиков/папок живого Outlook + снимок для доктора и мастера."""
    from core.legacy.mail_accounts import record_mailboxes

    try:
        rows = OutlookBridge(require_preflight=True).list_folders()
    except OutlookUnavailableError as exc:
        code = getattr(exc, "code", "unavailable")
        print(f"{code}: Outlook недоступен - перечень не снят: {exc}")
        return 3
    boxes = record_mailboxes(rows)
    for acc, box in sorted(boxes.items(), key=lambda kv: (kv[0] == "", kv[0])):
        print(f"{acc or '(без аккаунта: On My Computer, PST-архивы)'} · писем {box['total']}")
        for f in sorted(box["folders"], key=lambda f: -f["total"])[:6]:
            newest = f["newest"][:10] or "-"
            print(f"    {f['path']} · {f['total']} · новейшее {newest}")
    configured = {str(s.get("account") or "") for s in outlook_folders()}
    for acc in sorted(a for a in boxes if a and a not in configured):
        print(f"! ящик {acc} не читается: его нет в DT_OUTLOOK_FOLDERS")
    return 0


def _run_migrate(args: argparse.Namespace) -> int:
    """``--migrate-accounts``: ключи тредов и курсор манифеста → по аккаунтам; dry-run, пока нет
    ``--apply`` (MAIL-ACCOUNTS-1). Outlook не нужен."""
    from core.legacy.mail_accounts import migrate_manifest

    legacy = normalize_account(args.legacy_account) or outlook_legacy_account()
    if not legacy:
        print("Нужен ящик старого манифеста: --legacy-account a@b.c или DT_OUTLOOK_LEGACY_ACCOUNT.")
        return 2
    apply = bool(args.apply) and not args.dry_run
    print(f"Mail accounts migration ({'APPLY' if apply else 'DRY-RUN'}) · старый манифест "
          f"принадлежит {legacy}")
    try:
        rep = migrate_manifest(legacy, dry_run=not apply)
    except ValueError as exc:
        print(str(exc))
        return 2
    print(f"Тредов в манифесте: {rep.threads_total}; уже с аккаунтом: {rep.already_with_account}; "
          f"к переименованию conv:<id> → conv:<ящик>:<id>: {rep.to_rename}; к пометке msg: "
          f"{rep.to_tag}.")
    for ex in rep.examples:
        print(f"  · {ex}")
    if rep.nothing_to_do:
        print("Миграция не нужна: все треды уже с аккаунтом (повторный прогон безопасен).")
        return 0
    if not apply:
        print("DRY-RUN: ничего не записано. --apply делает копию (mail_backup_pre_accounts_*) "
              "и переписывает манифест.")
        return 0
    print(f"Переименовано {rep.renamed}, помечено {rep.tagged}, сообщений с аккаунтом "
          f"{rep.messages_tagged}. Резервная копия: {rep.backup_dir}")
    if rep.store_errors:
        print(f"⚠ нечитаемых сайдкаров: {len(rep.store_errors)} - треды пропущены, не затёрты.")
        return 1
    return 0


def _run_refilter(args: argparse.Namespace) -> int:
    """``--refilter``: ретро-проход по сайдкарам; dry-run, пока нет ``--apply``."""
    import json

    from core.legacy.mail_refilter import refilter_corpus

    apply = bool(args.apply) and not args.dry_run
    print(f"Mail refilter ({'APPLY' if apply else 'DRY-RUN'}"
          f"{f', limit {args.limit} тредов' if args.limit else ''}) → {args.vault}")
    rep = refilter_corpus(args.vault, dry_run=not apply, limit=args.limit, on_progress=print)
    print(f"Правила: {rep.rules_source}. Тредов в корпусе {rep.threads_total}, сообщений "
          f"{rep.messages_total}.")
    of_total = (f" из {rep.candidates_total} кандидатов"
                if rep.threads_affected != rep.candidates_total else "")
    print(f"Затронуто тредов: {rep.threads_affected}{of_total}"
          f" - снять целиком {rep.threads_dropped}, переписать {rep.threads_trimmed}; убрать "
          f"сообщений {rep.messages_removed} (по теме треда решено: {rep.subject_from_thread}).")
    print("правило | тредов | снято целиком | сообщений | примеры hint")
    for name, row in sorted(rep.by_rule.items(), key=lambda kv: -kv[1]["messages"]):
        print(f"  {name} | {row['threads']} | {row['threads_dropped']} | {row['messages']} | "
              + " ; ".join(row["examples"]))
    if rep.store_errors:
        print(f"⚠ нечитаемых сайдкаров: {rep.store_errors} - пропущены, не затёрты.")
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(
            json.dumps(rep.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"Отчет: {args.report}")
    if apply:
        print("Next: `uv run python cli/dt_index.py` - снять исчезнувшие заметки из индекса.")
    else:
        print("DRY-RUN: ничего не записано. --apply (после dry-run и канарейки --limit 50).")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dt-mail-ingest",
        description="Render Outlook correspondence into vault/_legacy/ notes.",
    )
    parser.add_argument(
        "--vault",
        type=Path,
        default=default_vault_path(),
        help="Path to the vault (default: sibling vault/ or $DT_VAULT_PATH).",
    )
    parser.add_argument(
        "--folders",
        default=None,
        help="Comma list of folder buckets to ingest (e.g. sent,inbox; "
        "default: all configured in DT_OUTLOOK_FOLDERS).",
    )
    parser.add_argument(
        "--account",
        default=None,
        help="Только спецификации этого ящика (адрес из DT_OUTLOOK_FOLDERS, напр. "
        "box@example.org); курсор и ключи тредов у каждого ящика свои.",
    )
    parser.add_argument(
        "--list-folders",
        action="store_true",
        default=False,
        help="Показать ящики и папки Outlook (адрес, путь, писем, новейшее) и записать снимок "
        "для доктора (.derived/mail_accounts.json). Только чтение; десятки секунд.",
    )
    parser.add_argument(
        "--migrate-accounts",
        action="store_true",
        default=False,
        help="Миграция манифеста на ключи по аккаунтам (старые треды = ящик "
        "--legacy-account / DT_OUTLOOK_LEGACY_ACCOUNT). Без --apply - dry-run.",
    )
    parser.add_argument(
        "--legacy-account",
        default=None,
        help="С --migrate-accounts: ящик, которому принадлежит старый манифест.",
    )
    parser.add_argument(
        "--all",
        dest="all_history",
        action="store_true",
        default=False,
        help="Ingest the WHOLE folder (all years) — ignore the incremental "
        "cursor. Resumable: already-ingested messages are skipped.",
    )
    parser.add_argument(
        "--since",
        default=None,
        help="Only messages on/after this date (YYYY-MM-DD); overrides the "
        "per-folder incremental cursor. Ignored when --all is given.",
    )
    parser.add_argument(
        "--scope",
        choices=("incremental", "full"),
        default="incremental",
        help="incremental (default): only new/changed since the cursor; full: "
        "re-render all within the look-back window.",
    )
    parser.add_argument(
        "--batch",
        type=int,
        default=None,
        help="Messages per durable batch (default: $DT_MAIL_BATCH or 300).",
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=None,
        help="Optional cap on survivors processed per folder (default: no cap).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Show the disposition without writing notes or the manifest.",
    )
    parser.add_argument(
        "--explain-privacy",
        action="store_true",
        default=False,
        help="С --dry-run: напечатать в консоль privacy-отказы окна (правило · дата · тема[:60]) "
        "и счетчики до/после. Читает тела писем (read-only); журнал и файлы не трогает.",
    )
    parser.add_argument(
        "--refilter",
        action="store_true",
        default=False,
        help="Ретро-проход: применить правила mail-filter.yaml к накопленным тредам (по "
        "сайдкарам, без Outlook). Без --apply - dry-run с отчетом.",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        default=False,
        help="С --refilter: действительно снять шум (заметки/сайдкары/индекс почты); с "
        "--migrate-accounts: действительно переписать манифест. Сначала --limit 50, затем "
        "dt_index, затем полный.",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=None,
        help="С --refilter: записать полный отчет прохода в JSON-файл.",
    )
    parser.add_argument(
        "--wait",
        type=float,
        default=None,
        metavar="SECONDS",
        help="Писатель ждет занятый dt-sync.lock столько секунд (дефолт 600 или "
        "$DT_MAIL_LOCK_WAIT_S).",
    )
    parser.add_argument(
        "--no-wait",
        action="store_true",
        default=False,
        help="Не ждать лок: занят - отказ с кодом sync_busy и именем держателя (exit 4).",
    )
    args = parser.parse_args(argv)
    load_env()  # engine/.env → os.environ (DT_OUTLOOK_* knobs) before config reads

    if args.apply and not (args.refilter or args.migrate_accounts):
        print("--apply имеет смысл только с --refilter или --migrate-accounts.")
        return 2
    if args.explain_privacy and not args.dry_run:
        print("--explain-privacy работает только с --dry-run (диагностика ничего не пишет).")
        return 2
    writes = bool(args.apply) if (args.refilter or args.migrate_accounts) else not args.dry_run
    if not writes:
        return _dispatch(args)  # dry-run ничего не пишет - лок не нужен
    from core.legacy.mail_lock import mail_writer_lock, resolve_wait_s
    from core.runlock import RunLockBusy

    step = "refilter" if args.refilter else ("migrate" if args.migrate_accounts else "ingest")
    try:
        with mail_writer_lock(step, wait_s=resolve_wait_s(args.wait, no_wait=args.no_wait)):
            return _dispatch(args)
    except RunLockBusy as exc:
        print(str(exc))
        return 4


def _dispatch(args: argparse.Namespace) -> int:
    """Тело CLI после разбора аргументов - под локом, когда команда пишет."""
    if args.refilter:
        return _run_refilter(args)
    if args.migrate_accounts:
        return _run_migrate(args)
    if args.list_folders:
        return _run_list_folders()

    folders = _select_folders(args.folders, args.account)
    if not folders:
        print("No Outlook folders selected/configured. Set DT_OUTLOOK_FOLDERS or --folders.")
        return 2

    scan = "ALL-HISTORY" if args.all_history else args.scope
    mode = f"{scan}{' DRY-RUN' if args.dry_run else ''}"
    print(f"Mail ingest ({mode}) → {args.vault}/_legacy/correspondence")
    pairs = ", ".join(
        f"{folder_label(s)}←{s['name']}" + ("" if s.get("account") else " (без аккаунта)")
        for s in folders
    )
    print(f"Folders: {pairs}")

    # Graceful stop: SIGTERM/SIGINT finishes + flushes the in-flight batch, then
    # returns (resumable). Polled by ingest_mail after each batch.
    stopping = {"v": False}

    def _request_stop(signum, _frame):
        stopping["v"] = True
        print(f"\n[mail] signal {signum} — finishing current batch, then stopping…")

    signal.signal(signal.SIGTERM, _request_stop)
    signal.signal(signal.SIGINT, _request_stop)

    # preflight=True: stopped / New Outlook fails fast, not a multi-minute stall.
    bridge = OutlookBridge(require_preflight=True)
    from core.ingress.run import ingress_run

    try:
        with ingress_run("mail", dry_run=args.dry_run) as run:  # INGRESS-1: run_id + итог прогона
            stats = ingest_mail(
                args.vault,
                bridge,
                folders=folders,
                since=args.since,
                scope=args.scope,
                dry_run=args.dry_run,
                all_history=args.all_history,
                batch_size=args.batch,
                limit=args.limit,
                should_stop=lambda: stopping["v"],
                on_progress=print,
                explain_privacy=print if args.explain_privacy else None,
            )
            run.finish(stats)
    except OutlookUnavailableError as exc:
        print(f"Outlook unavailable — nothing ingested: {exc}")
        if isinstance(exc, OutlookNewModeError):
            print(f"{exc.code}: {exc}")  # код причины в логе шага (доктор «Outlook-мост»)
            code, reason = exc.code, str(exc)
            _safe_state(lambda m: m.record_bridge(code, reason))
        return 3

    def _snapshot(m) -> None:
        m.record_bridge("", "")  # мост читается - прежний отказ снят
        m.record_run(stats)  # снимок по спецификациям для доктора

    _safe_state(_snapshot)

    print(
        "Disposition: "
        f"threads new={stats.new} updated={stats.changed} | msgs added={stats.msgs_added} "
        f"resumed={stats.resumed} duplicate={stats.duplicate} "
        f"skipped(noise)={stats.skipped_noise} skipped(privacy)={stats.skipped_privacy} "
        f"skipped(since)={stats.skipped_since} refused-before={stats.refused_resumed}"
    )
    # MAIL-GAP-1: граница по папкам (откуда курсор) и сколько отрезано ею - «отказ ≠ пропуск»
    for bucket, note in stats.since_notes.items():
        cut = stats.skipped_since_by_folder.get(bucket, 0)
        print(f"Boundary: {note}; отрезано границей: {cut}")
    if stats.noise_by_rule:
        print("Noise by rule: " + "; ".join(
            f"{k} {v}" for k, v in sorted(stats.noise_by_rule.items(), key=lambda kv: -kv[1])[:8]
        ))
    print(f"Thread notes written/updated: {stats.notes_total} in {stats.elapsed_s:.1f}s")
    # MAIL-THREAD-1: целостность — громко, не мелким шрифтом.
    if stats.bridge_misaligned:
        print(
            f"⚠ bridge_misaligned: {stats.bridge_misaligned} раз(а) массивы моста разошлись — "
            "страницы перечитаны мельче, сдвинутых записей нет."
        )
    if stats.rejected_multi_thread:
        print(
            f"⚠ отказано положить в второй тред: {stats.rejected_multi_thread} сообщ. "
            f"(msg_id уже в другом треде; разбор — dt_mail_repair). Примеры: "
            + "; ".join(stats.reject_examples)
        )
    if stats.thread_store_errors:
        print(
            f"⚠ нечитаемых сайдкаров тредов: {stats.thread_store_errors} — треды пропущены, "
            "не затёрты (store_unavailable); починить файл и перезапустить."
        )
    if stats.splice_suspects:
        print(f"⚠ подозрение на склейку: {stats.splice_suspects} тредов (см. лог [mail]).")
    if stats.examples:
        print("Examples:")
        for rel in stats.examples:
            print(f"  - {rel}")
    if stats.noise_examples:
        print("Noise skipped (examples):")
        for ex in stats.noise_examples:
            print(f"  · {ex}")
    if stopping["v"]:
        print("Stopped early (signal) — progress flushed; re-run to resume.")
    elif not args.dry_run:
        print("Next: run `uv run python cli/dt_index.py` to index the new/changed notes.")
    if stats.folder_problems:
        # MAIL-ACCOUNTS-1: «папка пуста при истории» / «папка не нашлась» - не «0 новых»
        for p in stats.folder_problems:
            print(f"⚠ {p['folder']}: {p['code']} - {p['reason']}")
        print(f"mail_ingest: {len(stats.folder_problems)} спецификаций не прочитано "
              f"(код выхода {EXIT_FOLDER_PROBLEMS}); остальные прочитаны.")
        return EXIT_FOLDER_PROBLEMS
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
