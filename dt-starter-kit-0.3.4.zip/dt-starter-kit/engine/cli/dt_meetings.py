"""dt-meetings — refresh the meetings cache snapshot from Outlook (PERF-3).

Thin wrapper over :func:`core.operational.meetings.refresh`: a scheduled, gentle
live-read of the Outlook calendar (via the same osascript bridge as the mail
ingest, ``require_preflight=True`` → a stopped/New Outlook fails fast, no multi-
minute stall) written to ``.derived/meetings/cache.json``. The pult then renders
from that snapshot instantly instead of doing a ~31s live read on every render.

Read-only to Outlook; ``core/`` ⊥ mcp/cli (this wrapper only calls core). Meant
to run on a gentle launchd cadence (``ops/launchd/com.dt.meetings.plist``) — NOT
in the 30-min fast turnover; the pult «Обновить» button covers on-demand refresh
through JOB-1 (``submit_job outlook_read mode=meetings``).

Usage:
    uv run --extra operational python cli/dt_meetings.py [--days N]
"""

from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _env import load_env

from core.operational.meetings import DEFAULT_DAYS, refresh


def main(argv: list[str] | None = None) -> int:
    load_env()  # engine/.env → os.environ (owner domains, vault path) + logging
    parser = argparse.ArgumentParser(
        prog="dt-meetings",
        description="Refresh the meetings cache snapshot from Outlook (PERF-3).",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=DEFAULT_DAYS,
        help=f"Window in days to read/cache (default: {DEFAULT_DAYS}).",
    )
    args = parser.parse_args(argv)

    result = refresh(args.days)
    if result.get("ok"):
        print(
            f"meetings cache refreshed: {len(result.get('meetings') or [])} events "
            f"(data_as_of={result.get('data_as_of')})"
        )
        return 0
    # unavailable — the prior snapshot is preserved (never zeroed).
    print(
        f"Outlook unavailable — cache kept as-is: {result.get('reason') or 'unavailable'}"
    )
    if result.get("code") == "outlook_new_mode":
        # MAIL-ACCOUNTS-1 п.4а: новый Outlook - не «сбой моста»: календарь не обновится, пока не
        # вернут legacy. Код выхода не 0 (launchd/доктор видят), кэш помечен несвежим.
        print(f"outlook_new_mode: календарь не обновляется с {result.get('data_as_of')}")
        return 3
    return 0  # scheduled run: a bridge hiccup is not a failure (prior cache stands)


if __name__ == "__main__":
    raise SystemExit(main())
