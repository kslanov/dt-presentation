"""CONTRACT-2 ФП-5/ФП-6 — единый конверт деградации (канон §9 п.22).

Правило одно: **фильтр не применился → пусто + причина, НИКОГДА — расширение выборки**.
Спайк AUDIT-CONTRACT-1 нашёл 20 мест, где это правило нарушалось молча (`get_facts`
отбрасывал фильтр и отдавал весь стор; `exemplar_ref` с опечаткой подменялся ЧУЖИМ
образцом; слайс с нерезолвнутым параметром исчезал без следа). Общее у них не механика,
а отсутствие **машиночитаемого** сигнала: деградировавший ответ выглядел как здоровый.

Конверт собран по эталонам честности, которые в движке уже были (FINDINGS §3.9) —
ничего нового не изобретаем:

* ``lift_source`` — ``status``/``reason``: отказ пересекает границу инструмента как
  ДАННЫЕ, а не как исключение;
* ``store_file``/``place_download`` — ``{ok:false, refused:true, code, error, …details}``:
  у отказа есть машинный ``code`` и контекст, которым продолжают работу;
* GATE-1 (``generate``) — ``{status:"blocked", missing:[…]}`` и **без** ``prompt``:
  деградировавший ответ отличается от здорового СТРУКТУРНО, а не только текстом.

Отсюда форма: :func:`warning` даёт ``{code, reason, …контекст}``; :func:`add_warning`
кладёт её в ответ под ключ ``warning`` (несколько причин на один ответ — список, потому
что у одного вызова их правда бывает две: и ссылка мёртвая, и провенанс не собрался).

**Обратная совместимость.** Ключ ``warning`` добавляется только там, где его не было;
существующие человекочитаемые строки-``warning`` (``deliver_output``, ``find_notes``
SRC-FRESH-1, ``save_output``) — отдельная, уже сложившаяся история, и мы их не трогаем:
happy-path формы ответов обязаны пройти снапшотами без правок.

``core`` ⊥ mcp/cli; ни сети, ни LLM.
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "WARNING_KEY",
    "WARNING_ENVELOPES_KEY",
    "warning",
    "add_warning",
    "warnings_of",
    "has_warning",
    "CODE_UNRESOLVED_REF",
    "CODE_FILTER_DROPPED",
    "CODE_STORE_UNAVAILABLE",
    "CODE_SOURCE_UNAVAILABLE",
    "CODE_EMPTY_ORBIT",
    "CODE_ITEM_NOT_FOUND",
    "CODE_SKIPPED",
    "CODE_UNAVAILABLE",
    "CODE_PARTIAL",
    "CODE_STYLE_MARKERS",
    "CODE_BRIDGE_MISALIGNED",
    "CODE_FOLDER_UNRESOLVED",
    "CODE_FOLDER_EMPTY_SUSPICIOUS",
    "CODE_OUTLOOK_NEW_MODE",
    "CODE_ADAPTER_INTERRUPTED",
    "CODE_SOURCE_INCOMPLETE",
    "CODE_NOT_READ_IN_WINDOW",
    "CODE_DEAL_DELETED",
    "CODE_BAD_RINGS",
    "CODE_BAD_STEPS",
    "CODE_MERGES_SKIPPED",
    "CODE_FACTS_OUTDATED",
    "CODE_FACTS_NOT_FROM_OCR",
    "CODE_SOURCE_NOT_LOCAL",
    "CODE_UNKNOWN_PARAM",
    "CODE_TRUNCATED",
    "unknown_param_refusal",
    "op_not_available_refusal",
    "connector_disabled_refusal",
    "CODE_CONNECTOR_DISABLED",
]

WARNING_KEY = "warning"
# Второй ключ конвертов — для инструментов, у которых ``warning`` УЖЕ занят
# человекочитаемой строкой доконвертной эпохи (``save_output``, ``deliver_output``,
# ``find_notes`` SRC-FRESH-1). Такую строку решено не трогать (см. «Обратная
# совместимость» выше), а положить конверт на её место значило бы её ПОТЕРЯТЬ —
# то самое тихое поведение, против которого весь модуль. Поэтому конверт едет
# рядом, а :func:`warnings_of` сводит оба ключа в один список: кто читает конверты
# через контракт, разницы не видит вовсе, и телеметрия отказов считает как обычно.
WARNING_ENVELOPES_KEY = "warning_envelopes"

# Коды — машинная причина деградации. Держим списком констант (не свободной строкой):
# по ним будет считать телеметрия отказов (отдельное ТЗ), и разнобой «unresolved_ref» /
# «unresolved-ref» / «refUnresolved» убил бы её на старте.
CODE_UNRESOLVED_REF = "unresolved_ref"          # ссылка не разрешилась (образец, источник)
CODE_FILTER_DROPPED = "filter_not_applied"      # фильтр применить не удалось → пусто
CODE_STORE_UNAVAILABLE = "store_unavailable"    # локальное хранилище не прочиталось
CODE_SOURCE_UNAVAILABLE = "source_unavailable"  # источник не поднялся (SRC-1)
CODE_EMPTY_ORBIT = "empty_orbit"                # каталог сущностей пуст/не настроен
CODE_ITEM_NOT_FOUND = "item_not_found"          # адресат операции не найден
CODE_SKIPPED = "skipped"                        # часть работы не выполнена (с перечнем)
CODE_UNAVAILABLE = "unavailable"                # внешняя зависимость недоступна
CODE_PARTIAL = "partial"                        # витрина собралась частично
CODE_STYLE_MARKERS = "style_markers"            # ИИ-маркеры в тексте выхода (STYLE-GUARD-1)
# ADAPTER-HONEST-1: контракт действует и на ВНУТРЕННИЕ адаптеры (мосты, парсеры,
# манифесты), не только на границу MCP.
CODE_BRIDGE_MISALIGNED = "bridge_misaligned"    # параллельные массивы моста разошлись по длине
CODE_ADAPTER_INTERRUPTED = "adapter_interrupted"  # вызов адаптера прерван (сон/таймаут/зависание)
# MAIL-ACCOUNTS-1: «папка пуста» не равно «писем нет» - три отказа почтового моста.
CODE_FOLDER_UNRESOLVED = "folder_unresolved"      # папка (аккаунт+имя) в Outlook не нашлась
CODE_FOLDER_EMPTY_SUSPICIOUS = "folder_empty_suspicious"  # папка 0 писем при непустой истории
CODE_OUTLOOK_NEW_MODE = "outlook_new_mode"        # Outlook в новом режиме: AppleScript без почты
# OUT-COMPLETE-1: полнота чтения источника-почтового треда на выходе (save_output). Не блок —
# предупреждение: контур выхода обеспечивает прослеживаемость, а здесь — полноту.
CODE_SOURCE_INCOMPLETE = "source_incomplete"      # тред прочитан не до последнего входящего
CODE_NOT_READ_IN_WINDOW = "not_read_in_window"    # тред указан источником, но в окне не читался
# HUB-ALIAS-1 п.4: resolve говорит причину, а не молчит.
CODE_CLIENT_UNRESOLVED = "client_unresolved"      # кейс требует клиента, а client_id не распознан
CODE_PLAN_INCONSISTENT = "plan_inconsistent"      # узел плана present, а данных нет, missing непуст


# FACT-2: честные оговорки фактов из таблиц.
CODE_MERGES_SKIPPED = "merges_skipped"            # объединенные шапки не прочитаны
CODE_FACTS_OUTDATED = "facts_outdated"            # в сторе факты прежней версии экстрактора
# OCR-1 п.4: цифры со скана без проверки - хуже отсутствия: факты из OCR-текста не извлекаются.
CODE_FACTS_NOT_FROM_OCR = "facts_not_from_ocr"    # источник - распознанный скан (pdf-ocr)
# SRC-ICLOUD-1: файл в iCloud не скачан (демон launchd его не материализует) - не «нет файла».
CODE_SOURCE_NOT_LOCAL = "source_not_local"        # источник - не скачанная заглушка iCloud
# ARGS-STRICT-1: контракт аргументов на границе и потолки ответов.
CODE_UNKNOWN_PARAM = "unknown_param"              # аргумент, которого нет в сигнатуре инструмента
CODE_TRUNCATED = "truncated"                      # ответ усечен потолком (get_facts limit)
# PERSONAL-3: операция есть в белом списке, но не у роли экземпляра (манифест поверхности).
CODE_CONNECTOR_DISABLED = "connector_disabled"    # инструмент/op выключенного коннектора
CODE_OP_NOT_AVAILABLE = "op_not_available"        # submit_job: op вне роли (личный без Outlook)


def unknown_param_refusal(
    tool: str, unknown: list[str], accepted: list[str]
) -> dict[str, Any]:
    """Отказ «неизвестные аргументы»: инструмент НЕ вызывается (ARGS-STRICT-1).

    Одна форма для обоих путей к инструменту - границы MCP и ``/api/<tool>``. Раньше MCP
    молча отбрасывал лишние ключи (``get_facts(client=…, limit=5)`` отдавал весь стор), а
    веб-путь падал ``TypeError`` кодом ``tool_error``. Конверт структурно отличается от
    здорового ответа (``ok: false`` + ``refused``), ``code`` считает телеметрия деградаций.
    """
    names = ", ".join(unknown)
    allowed = ", ".join(accepted) if accepted else "(аргументов нет)"
    return {
        "ok": False,
        "refused": CODE_UNKNOWN_PARAM,
        "code": CODE_UNKNOWN_PARAM,
        "error": f"{tool}: неизвестные аргументы {names}; допустимые: {allowed}",
        "unknown": list(unknown),
        "accepted": list(accepted),
    }


def op_not_available_refusal(op: str, role: str, available: list[str]) -> dict[str, Any]:
    """Отказ «операция вне роли» (PERSONAL-3): конверт той же формы, что ``unknown_param_refusal``
    (``ok: false`` + ``refused`` + ``code``): вызов не выполнен, ничего не поставлено в очередь."""
    allowed = ", ".join(available) if available else "(нет)"
    return {
        "ok": False,
        "refused": CODE_OP_NOT_AVAILABLE,
        "code": CODE_OP_NOT_AVAILABLE,
        "error": f"submit_job: op {op!r} недоступен роли {role!r}; доступны: {allowed}",
        "op": op,
        "role": role,
        "accepted": list(available),
    }


def connector_disabled_refusal(
    subject: str, connectors: list[str] | tuple[str, ...], hint: str, **extra: Any,
) -> dict[str, Any]:
    """Отказ «коннектор выключен» (DEV-3-CORE): ОДИН конверт на все инструменты и ops, форма как у
    ``op_not_available_refusal``/``unknown_param_refusal`` (``ok: false`` + ``refused`` + ``code``).
    ``connector`` - ключ коннектора (при нескольких - первый, остальные в ``connectors``),
    ``hint`` - как включить. Вызов не выполнен, исключения наружу нет."""
    keys = list(connectors)
    env: dict[str, Any] = {
        "ok": False,
        "refused": CODE_CONNECTOR_DISABLED,
        "code": CODE_CONNECTOR_DISABLED,
        "error": f"{subject}: коннектор {', '.join(keys)} выключен",
        "tool": subject,
        "connector": keys[0],
        "hint": hint,
    }
    if len(keys) > 1:
        env["connectors"] = keys
    env.update(extra)
    return env


def warning(code: str, reason: str, **context: Any) -> dict[str, Any]:
    """Один конверт деградации: ``{code, reason, …контекст}``.

    ``code`` — машинная причина (константы выше), ``reason`` — человеку, одной фразой и
    ПО СУЩЕСТВУ («источник не поднялся: none of the note's source paths exist»), а не
    «что-то пошло не так». ``context`` — то, чем продолжают работу: какая ссылка, какой
    параметр, сколько пропущено. Пустые значения контекста отбрасываются, чтобы конверт
    не оброс ``None``-полями.
    """
    env: dict[str, Any] = {"code": str(code), "reason": str(reason)}
    for key, value in context.items():
        if value is None or value == "" or value == []:
            continue
        env[key] = value
    return env


def add_warning(
    payload: dict[str, Any], code: str, reason: str, **context: Any
) -> dict[str, Any]:
    """Добавить конверт в ответ (ключ ``warning`` — список). Возвращает тот же ответ.

    Список, а не один объект: у вызова бывает несколько причин сразу, и вторая не имеет
    права затирать первую (иначе одна деградация прячется за другой — то же тихое
    поведение, только этажом выше).

    Ключ выбирается по тому, что в ответе УЖЕ лежит: занят человекочитаемой строкой
    (``save_output`` и родня) → конверт едет вторым ключом
    :data:`WARNING_ENVELOPES_KEY`, чтобы строка не потерялась; иначе — ``warning``,
    как было. Оба ключа читает :func:`warnings_of`.
    """
    key = WARNING_KEY
    existing = payload.get(WARNING_KEY)
    if existing is not None and not isinstance(existing, list):
        key = WARNING_ENVELOPES_KEY
    envelopes = payload.get(key)
    if not isinstance(envelopes, list):
        envelopes = []
        payload[key] = envelopes
    envelopes.append(warning(code, reason, **context))
    return payload


def warnings_of(payload: Any) -> list[dict[str, Any]]:
    """Конверты ответа (пустой список, если их нет или ответ не словарь).

    Сводит ОБА ключа — ``warning`` и ``warning_envelopes``: для читателя конвертов
    (телеметрия отказов, гард CONTRACT-2, доктор) их два только в форме ответа, а
    в контракте один список. Человекочитаемая строка в ``warning`` конвертом не
    считается — она отфильтруется как не-словарь.
    """
    if not isinstance(payload, dict):
        return []
    out: list[dict[str, Any]] = []
    for key in (WARNING_KEY, WARNING_ENVELOPES_KEY):
        envelopes = payload.get(key)
        if isinstance(envelopes, list):
            out.extend(e for e in envelopes if isinstance(e, dict))
    return out


def has_warning(payload: Any, code: str | None = None) -> bool:
    """Есть ли в ответе конверт (с кодом ``code``, если задан)."""
    envelopes = warnings_of(payload)
    if code is None:
        return bool(envelopes)
    return any(e.get("code") == code for e in envelopes)

# ORBIT-2: кольца орбиты и сверка удалений.
CODE_DEAL_DELETED = "deal_deleted"            # сделки больше нет в Timetta (сверка удалений)
CODE_BAD_RINGS = "bad_rings"                  # неизвестное кольцо в параметре rings
CODE_BAD_STEPS = "bad_steps"                  # неизвестный шаг режима dt-sync (pult_run_sync steps)
CODE_NO_RUNS = "no_runs"                      # прогонов золотого набора ещё нет (pult_eval, EVAL-3)
