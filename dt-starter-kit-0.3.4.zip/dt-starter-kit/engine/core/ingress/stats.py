"""INGRESS-1 п.2 — общая статистика входа: один словарь диспозиций для всех адаптеров.

Четыре входа считали по-своему (``ScanStats`` / ``IngestStats`` / ``MailIngestStats`` /
``CaptureResult``), и панель заданий показывала у каждого свой набор полей. Здесь — единый
:class:`IngressStats` (``new, changed, unchanged, relocated, duplicate, skipped_*, pending,
interrupted, errors, refused, written`` + ``adapter, run_id, dry_run, elapsed_s, examples``).

Родные классы НЕ переписываются: у каждого есть явная карта полей в :data:`FIELD_MAPS` — каждое
родное поле либо отображено в общее, либо названо в ``excluded`` с причиной «не входит в общий
словарь» (тест ``tests/test_ingress_stats.py`` сверяет карту с ``dataclasses.fields`` родного
класса: новое родное поле без записи в карте — красный тест, молчаливой потери счетчика нет).

Единицы адаптеров разные (файлы / треды / задачи) — общий словарь считает ЕДИНИЦЫ ЭТОГО
адаптера; сравнивать числа между адаптерами нельзя, и это сказано здесь, а не угадывается.

Чистый модуль: ``core/`` не зависит от MCP/CLI, без сети и записи.
"""

from __future__ import annotations

import dataclasses
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

__all__ = [
    "DISPOSITIONS",
    "FIELD_MAPS",
    "FieldMap",
    "IngressStats",
    "convert",
    "native_fields",
]

# Словарь диспозиций (счетчики единиц): порядок — как в ``to_dict()``.
DISPOSITIONS: tuple[str, ...] = (
    "new", "changed", "unchanged", "relocated", "duplicate",
    "skipped_privacy", "skipped_noise", "skipped_exclude", "skipped_untagged",
    "pending", "interrupted", "errors", "refused", "written",
)
_EXAMPLES_MAX = 5


@dataclass
class IngressStats:
    """Итог одного прогона адаптера в общих словах.

    * ``refused`` — единицы, отвергнутые ПО ПОЛИТИКЕ с записью в журнал отказов (не приватность и
      не шум: ``needs_ocr``, ``unsupported``, ``multi_thread``, ``operative_tag`` …);
    * ``skipped_privacy`` — ``личное``/``_nda``/privacy-probe: ТОЛЬКО счетчик, ни строки в журнале;
    * ``pending`` — не прочитано сейчас (iCloud-заглушка), повторится; ``interrupted`` — снят
      сигналом/сном посреди прогона (0 или 1 для адаптеров с булевым флагом);
    * ``written`` — заметок/inbox-файлов/записей реестра реально записано (в dry-run — 0).
    """

    adapter: str = ""
    run_id: str = ""
    dry_run: bool = False
    elapsed_s: float = 0.0
    new: int = 0
    changed: int = 0
    unchanged: int = 0
    relocated: int = 0
    duplicate: int = 0
    skipped_privacy: int = 0
    skipped_noise: int = 0
    skipped_exclude: int = 0
    skipped_untagged: int = 0
    pending: int = 0
    interrupted: int = 0
    errors: int = 0
    refused: int = 0
    written: int = 0
    examples: list[str] = field(default_factory=list)
    # Адаптерные поля сверх общего словаря (MAIL-GAP-1: ``since_effective``/``skipped_since``
    # почты) — единицы адаптера, смешивать между адаптерами нельзя. В ``to_dict`` ключ есть у
    # всех (пусто — ``{}``).
    extra: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Одна форма для всех адаптеров (``submit_job`` ingest-ops, доктор, пульт)."""
        out: dict[str, Any] = {
            "adapter": self.adapter,
            "run_id": self.run_id,
            "dry_run": self.dry_run,
            "elapsed_s": round(float(self.elapsed_s or 0.0), 3),
        }
        for name in DISPOSITIONS:
            out[name] = int(getattr(self, name))
        out["examples"] = list(self.examples[:_EXAMPLES_MAX])
        out["extra"] = dict(self.extra)  # одна форма у всех адаптеров; пусто - ``{}``
        return out

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IngressStats:
        """Обратное чтение (``last_runs.json``): неизвестные/битые поля не роняют."""
        obj = cls(adapter=str(data.get("adapter") or ""), run_id=str(data.get("run_id") or ""),
                  dry_run=bool(data.get("dry_run")))
        try:
            obj.elapsed_s = float(data.get("elapsed_s") or 0.0)
        except (TypeError, ValueError):
            obj.elapsed_s = 0.0
        for name in DISPOSITIONS:
            try:
                setattr(obj, name, int(data.get(name) or 0))
            except (TypeError, ValueError):
                setattr(obj, name, 0)
        raw = data.get("examples")
        obj.examples = [str(x) for x in raw][:_EXAMPLES_MAX] if isinstance(raw, list) else []
        extra = data.get("extra")
        obj.extra = dict(extra) if isinstance(extra, dict) else {}
        return obj


# --------------------------------------------------------------------------- #
# Карты полей                                                                   #
# --------------------------------------------------------------------------- #
Getter = Callable[[Any], Any]


@dataclass(frozen=True)
class FieldMap:
    """``fields``: родное поле → (общее поле, вычисление значения); ``excluded``: поле → причина."""

    native: type
    fields: dict[str, tuple[str, Getter | None]]
    excluded: dict[str, str]

    def covered(self) -> set[str]:
        return set(self.fields) | set(self.excluded)


def _same(name: str) -> Getter:
    return lambda n: getattr(n, name)


def _bool_int(name: str) -> Getter:
    return lambda n: 1 if getattr(n, name) else 0


def native_fields(cls: type) -> set[str]:
    """Родные поля класса статистики (dataclass-поля) — то, что обязана покрыть карта."""
    return {f.name for f in dataclasses.fields(cls)}


def _build_maps() -> dict[str, FieldMap]:
    # Ленивый импорт: родные классы живут в своих модулях, ``core.ingress`` их не дублирует.
    from core.file_ingest.scan import ScanStats
    from core.legacy.ingest import IngestStats
    from core.legacy.mail import MailIngestStats
    from core.operational.ticktick.capture import CaptureResult

    scan = FieldMap(
        ScanStats,
        {
            "new": ("new", _same("new")),
            "changed": ("changed", _same("changed")),
            "unchanged": ("unchanged", _same("unchanged")),
            "nda_skipped": ("skipped_privacy", _same("nda_skipped")),
            "excluded": ("skipped_exclude", _same("excluded")),
            "pending_download": ("pending", _same("pending_download")),
            "errors": ("errors", _same("errors")),
            "interrupted": ("interrupted", _bool_int("interrupted")),
            "operational_registered": ("written", _same("operational_registered")),
            "dry_run": ("dry_run", _same("dry_run")),
            "elapsed_s": ("elapsed_s", _same("elapsed_s")),
        },
        {
            "roots": "число корней прохода — контекст, не диспозиция единицы",
            "total_seen": "производное: сумма диспозиций + пропущенное фильтром",
            "knowledge_roots_ingested": "число корней, отданных в legacy-пайплайн; сами заметки "
                                        "считает ingest_corpus (адаптер legacy)",
            "reindex_triggered": "флаг побочного действия (reindex), не счетчик единиц",
            "manifest_path": "путь манифеста — служебное, не статистика",
            "actions": "построчный список диспозиций; в общий словарь идут агрегаты и примеры",
            "eval_skipped": "EVAL-HYGIENE-1: файлы под _eval (прогоны eval/selftest) - не вход "
                            "знания и не отказ по правилу; счет отдельный, причина "
                            "eval_quarantine - в журнале отказов",
        },
    )
    legacy = FieldMap(
        IngestStats,
        {
            "new": ("new", _same("new")),
            "changed": ("changed", _same("changed")),
            "unchanged": ("unchanged", _same("unchanged")),
            "relocated": ("relocated", _same("relocated")),
            "duplicate": ("duplicate", _same("duplicate")),
            "skipped_exclude": ("skipped_exclude", _same("skipped_exclude")),
            "skipped_privacy": ("skipped_privacy", _same("skipped_privacy")),
            "needs_conversion": ("refused", lambda n: n.needs_conversion + n.skipped_unsupported),
            "skipped_unsupported": ("refused", None),  # суммируется вместе с needs_conversion
            "pending_download": ("pending", _same("pending_download")),
            "interrupted": ("interrupted", _same("interrupted")),
            "errors": ("errors", _same("errors")),
            "notes_total": ("written", lambda n: 0 if n.dry_run else n.new + n.changed),
            "examples": ("examples", _same("examples")),
            "dry_run": ("dry_run", _same("dry_run")),
            "elapsed_s": ("elapsed_s", _same("elapsed_s")),
        },
        {
            "needs_ocr": "OCR-1 п.1: скан без текстового слоя - заметка-заглушка (считается в "
                         "new/changed), не отказ; счетчик - число заглушек прохода",
            "reattr_proposed": "предложения переатрибуции (REATTR-1) — очередь, не диспозиция",
            "relocated_note_updates": "SRC-PATH-1: сколько заметок relocation переписал "
                                      "(подмножество relocated, не отдельная диспозиция)",
            "deleted": "удаление заметки при исчезновении источника — в общем словаре нет такой "
                       "диспозиции (вход ничего не удаляет)",
            "mocs": "навигационный постпроход (_index.md), не входной поток",
            "hub_candidates": "отчет кандидатов в хабы — постпроход, не диспозиция",
            "backlinks": "обратные ссылки на curated-заметки — постпроход",
            "backlinked": "список id для backlinks — постпроход",
            "scope": "режим прогона (incremental|full) — параметр, не результат",
            "manifest_path": "путь манифеста — служебное",
            "report_path": "путь диагностического отчета — служебное",
        },
    )
    mail = FieldMap(
        MailIngestStats,
        {
            "new": ("new", _same("new")),
            "changed": ("changed", _same("changed")),
            "unchanged": ("unchanged", _same("unchanged")),
            "skipped_privacy": ("skipped_privacy", _same("skipped_privacy")),
            "skipped_noise": ("skipped_noise", lambda n: n.skipped_noise + n.skipped_empty),
            "skipped_empty": ("skipped_noise", None),  # пустое письмо — шум; суммируется выше
            "duplicate": ("duplicate", _same("duplicate")),
            # MAIL-GAP-1: единицы — СООБЩЕНИЯ; в общий словарь (треды) не входят, едут в ``extra``
            "skipped_since": ("extra:skipped_since", _same("skipped_since")),
            "skipped_since_by_folder": ("extra:skipped_since_by_folder",
                                        _same("skipped_since_by_folder")),
            "since_effective": ("extra:since_effective", _same("since_effective")),
            "rejected_multi_thread": ("refused", _same("rejected_multi_thread")),
            "thread_store_errors": ("errors", _same("thread_store_errors")),
            "notes_total": ("written", lambda n: 0 if n.dry_run else n.notes_total),
            "examples": ("examples", _same("examples")),
            "dry_run": ("dry_run", _same("dry_run")),
            "elapsed_s": ("elapsed_s", _same("elapsed_s")),
        },
        {
            "resumed": "единицы — СООБЩЕНИЯ (уже в манифесте треда), а общий словарь почты "
                       "считает треды; смешивать единицы нельзя",
            "msgs_added": "сообщения, добавленные в треды — единицы сообщений, не тредов",
            "scope": "режим прогона — параметр, не результат",
            "manifest_path": "путь манифеста — служебное",
            "folders": "список папок прогона — контекст",
            "noise_examples": "примеры шума уходят в журнал отказов (refuse), не в examples",
            "reject_examples": "примеры отказов multi_thread/store — в журнал отказов",
            "bridge_misaligned": "диагностика моста (конверт bridge_misaligned), не диспозиция",
            "splice_suspects": "сигнал подозрения на склейку тредов — диагностика",
            "noise_by_rule": "шум по правилам yaml: имя правила - в строке журнала отказов (rule)",
            "refused_resumed": "единицы — СООБЩЕНИЯ, пропущенные по памяти «отказано» прежних "
                               "прогонов; смешивать с тредами нельзя",
            "privacy_before": "диагностика --explain-privacy (dry-run): только консоль, не итог",
            "privacy_after": "диагностика --explain-privacy (dry-run): только консоль, не итог",
            "filter_source": "откуда правила фильтра (file|defaults) — служебное",
            "since_notes": "MAIL-GAP-1: строки границы для лога/CLI — не статистика",
            "added_by_folder": "MAIL-GAP-1: кандидаты по папкам — вход смоука С-13",
            "added_dates": "MAIL-GAP-1: дни кандидатов по папкам — вход смоука С-13",
            "added_after_cursor_by_folder": "SMOKE-DRIFT-1: кандидаты новее новейшего в манифесте "
                                            "(ждут синхронизации) — вход смоука С-13",
            "folder_problems": "MAIL-ACCOUNTS-1: деградации спецификаций (folder_unresolved / "
                               "folder_empty_suspicious) - диагностика ящиков, не диспозиция",
            "folder_snapshot": "MAIL-ACCOUNTS-1: снимок ящиков/папок прогона для доктора - "
                               "служебное, не статистика",
        },
    )
    capture = FieldMap(
        CaptureResult,
        {
            "pulled": ("new", lambda n: sum(n.pulled.values())),
            "skipped_personal": ("skipped_privacy", _same("skipped_personal")),
            "skipped_operative": ("refused", _same("skipped_operative")),
            "skipped_untagged": ("skipped_untagged", _same("skipped_untagged")),
            "skipped_dedup": ("unchanged", _same("skipped_dedup")),
            "written": ("written", lambda n: len(n.written)),
            "dry_run": ("dry_run", _same("dry_run")),
        },
        {
            "untriaged_recorded": "запись в манифест untriaged (карточка пульта) — состояние "
                                  "очереди, не inbox-файл; считается TRIAGE-1",
            "skipped_work_tag": "PERSONAL-1: рабочие теги, которые личный контур пропускает без "
                                "записи (их берет рабочий) — не отказ и не вход этого контура",
        },
    )
    return {
        "files": scan, "files:operational": scan, "files:knowledge": scan,
        "legacy": legacy, "mail": mail, "capture": capture,
    }


class _LazyMaps(dict):  # type: ignore[type-arg]
    """Карты строятся при первом обращении (импорт родных модулей тяжелый)."""

    def _load(self) -> None:
        if not super().__len__():
            super().update(_build_maps())

    def __getitem__(self, key: str) -> FieldMap:
        self._load()
        return super().__getitem__(key)

    def __iter__(self):  # type: ignore[no-untyped-def]
        self._load()
        return super().__iter__()

    def __len__(self) -> int:
        self._load()
        return super().__len__()

    def items(self):  # type: ignore[no-untyped-def]
        self._load()
        return super().items()

    def __contains__(self, key: object) -> bool:
        self._load()
        return super().__contains__(key)


FIELD_MAPS: dict[str, FieldMap] = _LazyMaps()


def convert(
    adapter: str, native: Any, *, map_key: str | None = None, run_id: str = "",
    elapsed_s: float | None = None,
) -> IngressStats:
    """Родной итог → :class:`IngressStats` по карте ``map_key`` (по умолчанию — ключ адаптера).

    Поля карты с ``None``-вычислением (суммируются другим полем) пропускаются. Отсутствующее в
    родном объекте поле — ноль (адаптер сторонний/упрощенный не роняет прогон).
    """
    fmap = FIELD_MAPS[map_key or adapter]
    out = IngressStats(adapter=adapter, run_id=run_id)
    for _native_name, (target, getter) in fmap.fields.items():
        if getter is None:
            continue
        try:
            value = getter(native)
        except AttributeError:
            continue
        if target.startswith("extra:"):
            out.extra[target[len("extra:"):]] = value
        elif target == "examples":
            out.examples = [str(x) for x in (value or [])][:_EXAMPLES_MAX]
        elif target == "dry_run":
            out.dry_run = bool(value)
        elif target == "elapsed_s":
            out.elapsed_s = float(value or 0.0)
        else:
            setattr(out, target, int(value or 0))
    if elapsed_s is not None and not out.elapsed_s:
        out.elapsed_s = float(elapsed_s)
    return out
