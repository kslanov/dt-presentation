"""Контекст установки: куда пишем (корень, дом, .env, vault, derived), ответы мастера, инструменты.

Все пути - параметры (``--root``/``--home``/``--engine-dir``/``--env-file``): тест гоняет весь
сценарий на tmp-корне и не касается боевых ``.env``, vault, ``.derived``, LaunchAgents,
конфигов хостов и Keychain. Внешние вызовы собраны в :class:`Tools` (подпроцессы, ``launchctl``,
Desktop, скачивание, ввод, вывод) - боевые умолчания под pytest отказывают (``live_guard``), тест
обязан подставить подделку. Писатель вне tmp под pytest - тоже отказ (:meth:`InstallContext.guard`),
как ``live_guard`` у ``core.host_config``.
"""

from __future__ import annotations

import os
import subprocess
import sys
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.config import ENGINE_ROOT, derived_root, env_file
from core.install.base import InstallError
from core.install.platform_check import PlatformProbe
from core.install.state import STATE_REL, InstallState, load_state

__all__ = ["Answers", "HOST_CHOICES", "InstallContext", "Tools", "live_guard"]

HOST_CHOICES = ("claude", "cursor", "kimi", "cherry", "none")
DEFAULT_HOST = "claude"
_TAIL_LINES = 40

RunCmd = Callable[[Sequence[str], Path, Mapping[str, str] | None], tuple[int, str]]
Launchctl = Callable[[Sequence[str]], tuple[int, str]]
Prompt = Callable[[str, str], str]
#: ``downloader(repo_id, cache_dir, allow_patterns, progress)`` - ``progress(done, total)`` в байтах
Downloader = Callable[[str, str, Sequence[str], Callable[[int, int], None]], str]


def _real_home() -> Path:
    import pwd

    return Path(pwd.getpwuid(os.getuid()).pw_dir).resolve()


def live_guard(path: Path) -> None:
    """Под pytest писатель установки не пишет в настоящий домашний каталог (там боевые
    ``.env``/vault/``.derived``/LaunchAgents/конфиги хостов): тест обязан увести корень в tmp."""
    if "PYTEST_CURRENT_TEST" not in os.environ:
        return
    target = Path(path).expanduser().resolve()
    if target.is_relative_to(_real_home()):
        raise InstallError(
            "live_guard", f"тест целится в боевой путь {target}: задай --root/--home в tmp")


def _default_run_cmd(argv: Sequence[str], cwd: Path,
                     env: Mapping[str, str] | None = None) -> tuple[int, str]:
    """Подпроцесс с живым выводом (прогресс ``uv sync``/индекса виден); хвост - в состояние."""
    if "PYTEST_CURRENT_TEST" in os.environ:
        raise InstallError("live_guard", f"тест пытается запустить настоящую команду {argv[0]}")
    merged = {k: v for k, v in os.environ.items() if k != "VIRTUAL_ENV"}
    merged.update(env or {})
    try:
        proc = subprocess.Popen(list(argv), cwd=str(cwd), env=merged,  # noqa: S603
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                bufsize=1)
    except OSError as exc:
        return 127, str(exc)
    tail: list[str] = []
    for line in proc.stdout or ():
        sys.stdout.write(line)
        sys.stdout.flush()
        tail.append(line.rstrip("\n"))
        del tail[:-_TAIL_LINES]
    return proc.wait(), "\n".join(tail)


def _default_capture(argv: Sequence[str], cwd: Path,
                     env: Mapping[str, str] | None = None) -> tuple[int, str]:
    """Подпроцесс БЕЗ печати (пробы ``check()``): ``(код, stdout+stderr)``."""
    if "PYTEST_CURRENT_TEST" in os.environ:
        raise InstallError("live_guard", f"тест пытается запустить настоящую команду {argv[0]}")
    merged = {k: v for k, v in os.environ.items() if k != "VIRTUAL_ENV"}
    merged.update(env or {})
    try:
        done = subprocess.run(list(argv), cwd=str(cwd), env=merged, capture_output=True,  # noqa: S603
                              text=True, timeout=120, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        return 127, str(exc)
    return done.returncode, (done.stdout or "") + (done.stderr or "")


def _default_launchctl(argv: Sequence[str]) -> tuple[int, str]:
    if "PYTEST_CURRENT_TEST" in os.environ:
        raise InstallError("live_guard", "тест пытается вызвать настоящий launchctl")
    try:
        done = subprocess.run(["launchctl", *argv], capture_output=True,  # noqa: S603, S607
                              text=True, timeout=60, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        return 127, str(exc)
    return done.returncode, done.stdout


def _default_prompt(question: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        answer = input(f"{question}{suffix}: ").strip()
    except EOFError:
        return default
    return answer or default


def _default_list_mailboxes() -> list[dict[str, Any]]:
    """Ящики/папки живого Outlook для мастера (read-only: ``OutlookBridge.list_folders``).

    Пусто = Outlook недоступен (не запущен, новый режим, не macOS): мастер пропускает вопрос о
    ящиках, а не падает. Под pytest - отказ (как у остальных боевых инструментов)."""
    if "PYTEST_CURRENT_TEST" in os.environ:
        raise InstallError("live_guard", "тест пытается читать настоящий Outlook")
    from core.operational.outlook_bridge import OutlookBridge, OutlookUnavailableError

    try:
        return OutlookBridge(require_preflight=True).list_folders()
    except OutlookUnavailableError:
        return []


def _default_downloader(repo_id: str, cache_dir: str, allow: Sequence[str],
                        progress: Callable[[int, int], None]) -> str:
    from core.install.models import hub_download

    return hub_download(repo_id, cache_dir, allow, progress)


@dataclass
class Tools:
    """Внешний мир установки; каждое поле - точка подмены в тестах."""

    run_cmd: RunCmd = _default_run_cmd
    capture: RunCmd = _default_capture
    launchctl: Launchctl = _default_launchctl
    desktop: Any = None  # core.host_config.DesktopControl | None (None - desktop_control())
    downloader: Downloader = _default_downloader
    prompt: Prompt = _default_prompt
    #: перечень папок живого Outlook со счетчиками и аккаунтом (MAIL-ACCOUNTS-1 п.6)
    list_mailboxes: Callable[[], list[dict[str, Any]]] = _default_list_mailboxes
    out: Callable[[str], None] = print
    probe: PlatformProbe = field(default_factory=PlatformProbe)
    #: argv интерпретатора движка для CLI-шагов (боевой: ``uv run --extra operational python``)
    python: tuple[str, ...] = ("uv", "run", "--extra", "operational", "python")


@dataclass
class Answers:
    """Ответы мастера: не секреты, хранятся в ``state.json`` и переживают повтор."""

    name: str = ""
    emails: list[str] = field(default_factory=list)
    company: str = ""
    domains: list[str] = field(default_factory=list)
    internal_domains: list[str] = field(default_factory=list)
    people: list[str] = field(default_factory=list)
    host: str = ""
    connectors: str = ""  # none | список через запятую | auto
    #: ящики Outlook, которые читаем (адреса); спецификации DT_OUTLOOK_FOLDERS - JSON-строкой
    mailboxes: list[str] = field(default_factory=list)
    mailbox_specs: str = ""
    vault: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v not in ("", [], None)}

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> Answers:
        out = cls()
        for key, value in raw.items():
            if not hasattr(out, key):
                continue
            if isinstance(getattr(out, key), list):
                setattr(out, key, [str(v) for v in value] if isinstance(value, list) else [])
            else:
                setattr(out, key, str(value))
        return out

    def merged(self, over: Answers) -> Answers:
        """``over`` (флаги командной строки) перекрывает то, что уже известно."""
        data = self.as_dict()
        data.update(over.as_dict())
        return Answers.from_dict(data)


@dataclass
class InstallContext:
    engine_dir: Path
    workspace: Path
    home: Path
    env_path: Path
    vault: Path
    derived: Path
    models_dir: Path
    answers: Answers = field(default_factory=Answers)
    tools: Tools = field(default_factory=Tools)
    state: InstallState | None = None
    yes: bool = False
    dry_run: bool = False
    relaunch: bool = False
    ops_full: bool = False
    models_from: Path | None = None
    model_attempts: int = 3
    #: ``DT_CONNECTORS`` отдельно от ``.env`` (флаг ``--connectors``); пусто - из ``.env``/ответов
    extra_env: dict[str, str] = field(default_factory=dict)
    #: папка оверлеев экземпляров; по умолчанию ``<engine>/instances``. Тесты обязаны давать tmp:
    #: удаление экземпляра деструктивно (01.11 прогон на боевом движке снес instances/personal.env)
    instances_dir: Path | None = None

    def instances_path(self) -> Path:
        if self.instances_dir is not None:
            return self.instances_dir
        return self.engine_dir / "instances"

    # ---- построение --------------------------------------------------------------------- #
    @classmethod
    def build(
        cls, *, engine_dir: Path | None = None, root: Path | None = None, home: Path | None = None,
        env_path: Path | None = None, vault: Path | None = None, models_dir: Path | None = None,
        tools: Tools | None = None, answers: Answers | None = None,
        instances_dir: Path | None = None, **flags: Any,
    ) -> InstallContext:
        if engine_dir is not None:
            engine = Path(engine_dir).expanduser().resolve()
        elif root is not None and (Path(root).expanduser() / "engine").is_dir():
            engine = (Path(root).expanduser() / "engine").resolve()
        else:
            engine = ENGINE_ROOT
        workspace = Path(root).expanduser().resolve() if root is not None else engine.parent
        env = Path(env_path).expanduser().resolve() if env_path else engine / ".env"
        ctx = cls(
            engine_dir=engine, workspace=workspace,
            home=Path(home).expanduser().resolve() if home else Path.home(),
            env_path=env, vault=workspace / "vault", derived=derived_root(workspace),
            models_dir=Path(models_dir).expanduser().resolve() if models_dir else engine / "models",
            tools=tools or Tools(),
            instances_dir=Path(instances_dir).expanduser().resolve() if instances_dir else None,
            **flags)
        # vault: флаг > DT_VAULT_PATH из .env > <workspace>/vault (process-env не читаем)
        configured = vault if vault is not None else (
            env_file.read_value(env, "DT_VAULT_PATH") if env.is_file() else None)
        if configured:
            ctx.vault = Path(str(configured)).expanduser().resolve()
        ctx.state = load_state(ctx.derived / STATE_REL)
        ctx.answers = ctx.state_answers().merged(answers or Answers())
        return ctx

    # ---- чтение конфигурации ------------------------------------------------------------ #
    def env_values(self) -> dict[str, str]:
        """Значения из ФАЙЛА ``.env`` цели (не из окружения процесса): герметично в тестах."""
        if not self.env_path.is_file():
            return {}
        # stdlib-читатель ``env_file``: python-dotenv - extra ``operational``, а установщик стартует
        # в базовом окружении кита (``uv run`` без extras)
        out: dict[str, str] = {}
        for key in dict.fromkeys(env_file.read_keys(self.env_path)):
            value = env_file.read_value(self.env_path, key)
            if value is not None:
                out[key] = value
        return out

    def environ(self) -> dict[str, str]:
        """Окружение цели для реестров (коннекторы, профиль): ``.env`` + явные добавки."""
        env = self.env_values()
        env.update(self.extra_env)
        return env

    def state_answers(self) -> Answers:
        return Answers.from_dict(self.state.answers if self.state else {})

    # ---- помощники ---------------------------------------------------------------------- #
    @property
    def host(self) -> str:
        return self.answers.host or DEFAULT_HOST

    def guard(self, *paths: Path) -> None:
        for path in paths:
            live_guard(path)

    def say(self, line: str = "") -> None:
        self.tools.out(line)

    def child_env(self) -> dict[str, str]:
        """Окружение дочерних CLI: пути цели явно (процесс-env побеждает ``.env`` движка)."""
        env = {"DT_VAULT_PATH": str(self.vault), "DT_DERIVED_ROOT": str(self.derived),
               "DT_MODELS_PATH": str(self.models_dir)}
        env.update(self.extra_env)
        return env

    def python_cmd(self, *args: str) -> list[str]:
        return [*self.tools.python, *args]
