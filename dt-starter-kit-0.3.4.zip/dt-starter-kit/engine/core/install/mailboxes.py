"""Ящики Outlook для мастера установки (MAIL-ACCOUNTS-1 п.6): что показать и что записать.

``OutlookBridge.list_folders()`` отдает папки со счетчиками и АККАУНТОМ каждой. Здесь из этого
получаются ящики (адрес + папка входящих + папка отправленных) и спецификации
``DT_OUTLOOK_FOLDERS``. По умолчанию читаются все живые ящики; «On My Computer» и архивы без
аккаунта (PST, ``NN archive``) не предлагаются вовсе: их чтение - отдельное решение владельца.

Чистые функции от списка строк: Outlook не вызывается (вызов - ``Tools.list_mailboxes``).
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from core.config import normalize_account
from core.install.base import InstallError

__all__ = ["Mailbox", "build_specs", "default_selection", "describe", "discover", "select"]

_INBOX = frozenset({"inbox", "входящие"})
_SENT = frozenset({"sent", "sent items", "отправленные", "sent mail"})


@dataclass(frozen=True)
class Mailbox:
    """Живой ящик: адрес, папки входящих/отправленных (как называет их Outlook) и счетчики."""

    account: str
    inbox: str
    inbox_total: int
    sent: str = ""
    sent_total: int = 0


def _best(rows: list[dict[str, Any]], names: frozenset[str]) -> tuple[str, int]:
    """Самая наполненная папка из синонимов (как выбирает мост внутри аккаунта)."""
    cands = [r for r in rows if str(r.get("name") or "").strip().lower() in names]
    if not cands:
        return "", 0
    top = max(cands, key=lambda r: int(r.get("total") or 0))
    return str(top.get("name") or ""), int(top.get("total") or 0)


def discover(rows: list[dict[str, Any]]) -> list[Mailbox]:
    """Ящики с аккаунтом из ``list_folders()``; папки без аккаунта и ящики без Inbox - мимо."""
    by_acc: dict[str, list[dict[str, Any]]] = {}
    for r in rows:
        acc = normalize_account(r.get("account"))
        if acc:
            by_acc.setdefault(acc, []).append(r)
    out: list[Mailbox] = []
    for acc, folders in by_acc.items():
        inbox, inbox_total = _best(folders, _INBOX)
        if not inbox:
            continue
        sent, sent_total = _best(folders, _SENT)
        out.append(Mailbox(acc, inbox, inbox_total, sent, sent_total))
    return sorted(out, key=lambda b: -b.inbox_total)


def default_selection(boxes: list[Mailbox]) -> list[Mailbox]:
    """По умолчанию - ВСЕ живые ящики (архивы без аккаунта в ``boxes`` не попадают)."""
    return list(boxes)


def describe(boxes: list[Mailbox]) -> list[str]:
    """Строки для вопроса мастера: ``адрес · Входящие N · Отправленные M``."""
    return [
        f"  {b.account} · {b.inbox} {b.inbox_total}"
        + (f" · {b.sent} {b.sent_total}" if b.sent else " · отправленных нет")
        for b in boxes
    ]


def select(answer: str, boxes: list[Mailbox]) -> list[Mailbox]:
    """Ответ владельца → ящики: ``all`` - все, ``none`` - ни одного, иначе адреса через запятую.

    Адрес вне перечня - отказ с перечнем допустимых (не молчаливый пропуск)."""
    text = (answer or "").strip().lower()
    if text in ("", "all", "все"):
        return default_selection(boxes)
    if text in ("none", "нет"):
        return []
    known = {b.account: b for b in boxes}
    chosen: list[Mailbox] = []
    for tok in text.replace(";", ",").split(","):
        acc = normalize_account(tok)
        if not acc:
            continue
        if acc not in known:
            raise InstallError(
                "bad_mailbox", f"ящика {acc!r} нет среди живых ящиков Outlook",
                "допустимо: all, none или адреса: " + ", ".join(known))
        if known[acc] not in chosen:
            chosen.append(known[acc])
    return chosen


def build_specs(selected: list[Mailbox]) -> list[dict[str, str]]:
    """Спецификации ``DT_OUTLOOK_FOLDERS``: на ящик - входящие и (если есть) отправленные."""
    specs: list[dict[str, str]] = []
    for b in selected:
        specs.append({"bucket": "inbox", "name": b.inbox, "account": b.account})
        if b.sent:
            specs.append({"bucket": "sent", "name": b.sent, "account": b.account})
    return specs


def specs_json(selected: list[Mailbox]) -> str:
    return json.dumps(build_specs(selected), ensure_ascii=False, separators=(",", ":"))
