"""Модели эмбеддера и реранкера: скачивание с прогрессом, офлайн-раздача, проверка целостности.

Движок берет ``BAAI/bge-m3`` и ``BAAI/bge-reranker-v2-m3`` ТОЛЬКО из локального кэша
``DT_MODELS_PATH`` (``core.embeddings`` / ``core.retrieval.rerank``: ``local_files_only=True``).
Здесь - единственное место, которое этот кэш наполняет при установке:

* ``dt install --step models`` качает недостающее через ``snapshot_download`` с теми же
  ``allow_patterns``, что у движка, показывает проценты (в терминал и в ``state.json``), повтор
  докачивает (``huggingface_hub`` продолжает ``*.incomplete``);
* ``--models-from <папка|архив>`` - офлайн-копия кэша (``dt-models.tar`` собирает
  ``scripts/build_models_bundle.py`` из боевого кэша с контрольными суммами): без сети, с проверкой
  sha256 по манифесту ``dt-models.json``;
* целостность: нужные файлы на месте и не пустые, веса не короче порога, нет недокачанных
  ``*.incomplete``, размеры совпадают с манифестом ``.dt-models.json`` (если он есть - у машины,
  поставленной руками, его нет, и проверка опирается на наличие и размер).

Откуда лежит кэш (хаб/архив) пишет ``.dt-models.json`` рядом с кэшем: его читает доктор «Модели».
"""

from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import shutil
import tarfile
import tempfile
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.install.base import ABSENT, DONE, PARTIAL, InstallError, StepCheck, StepResult
from core.install.context import InstallContext

__all__ = [
    "BUNDLE_MANIFEST", "MANIFEST", "MODELS", "ModelSpec", "ModelState", "hub_download",
    "install_models", "model_state", "models_status", "models_step_check", "models_step_run",
    "prefer_single_weights", "read_manifest",
]

MANIFEST = ".dt-models.json"  # что и откуда лежит в кэше (пишет установка)
BUNDLE_MANIFEST = "dt-models.json"  # манифест раздаваемого архива (sha256 каждого файла)
_GIB = 1024**3


@dataclass(frozen=True)
class ModelSpec:
    key: str
    repo_id: str
    label: str
    #: нужные файлы (шаблоны от корня снимка): каждый обязан найтись; веса - любой из ``weights``
    required: tuple[str, ...]
    weights: tuple[str, ...]
    min_weight_bytes: int
    approx_gib: float

    @property
    def dirname(self) -> str:
        return "models--" + self.repo_id.replace("/", "--")

    def allow_patterns(self) -> list[str]:
        """Те же шаблоны, что у движка (``core.embeddings`` / ``core.retrieval.rerank``)."""
        if self.key == "embedder":
            from core.embeddings import _ALLOW_PATTERNS
        else:
            from core.retrieval.rerank import _ALLOW_PATTERNS
        return list(_ALLOW_PATTERNS)


MODELS: tuple[ModelSpec, ...] = (
    ModelSpec("embedder", "BAAI/bge-m3", "bge-m3",
              ("config.json", "modules.json", "tokenizer.json", "1_Pooling/config.json"),
              ("*.safetensors", "pytorch_model.bin"), 1_000_000_000, 2.3),
    ModelSpec("reranker", "BAAI/bge-reranker-v2-m3", "bge-reranker-v2-m3",
              ("config.json", "tokenizer.json"), ("*.safetensors",), 1_000_000_000, 2.3),
)


@dataclass(frozen=True)
class ModelState:
    spec: ModelSpec
    present: bool
    complete: bool
    problems: tuple[str, ...]
    size: int
    path: str
    source: str

    @property
    def reason(self) -> str:
        if self.complete:
            return f"{self.spec.label} {self.size / _GIB:.1f} ГБ"
        return f"{self.spec.label}: " + ("; ".join(self.problems) or "нет в кэше")


# --------------------------------------------------------------------------- манифест ------- #
def read_manifest(models_dir: Path) -> dict[str, Any]:
    try:
        data = json.loads((Path(models_dir) / MANIFEST).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write_manifest(models_dir: Path, spec: ModelSpec, files: dict[str, int], source: str) -> None:
    data = read_manifest(models_dir)
    data[spec.repo_id] = {"source": source, "at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
                          "files": files}
    models_dir.mkdir(parents=True, exist_ok=True)
    (models_dir / MANIFEST).write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


# --------------------------------------------------------------------------- состояние ------ #
def _snapshot(repo_dir: Path) -> Path | None:
    """Снимок кэша HF: ``refs/main`` → ``snapshots/<rev>`` (нет ссылки - единственный снимок)."""
    snaps = repo_dir / "snapshots"
    if not snaps.is_dir():
        return None
    ref = repo_dir / "refs" / "main"
    if ref.is_file():
        chosen = snaps / ref.read_text(encoding="utf-8").strip()
        return chosen if chosen.is_dir() else None
    dirs = [p for p in snaps.iterdir() if p.is_dir()]
    return dirs[0] if len(dirs) == 1 else None


def _files(snapshot: Path) -> dict[str, int]:
    """``{путь от снимка: размер}`` для РАБОЧИХ файлов (символьная ссылка должна вести в файл)."""
    out: dict[str, int] = {}
    for p in sorted(snapshot.rglob("*")):
        if p.is_file():  # is_file идет по ссылке: битая ссылка не попадает
            out[p.relative_to(snapshot).as_posix()] = p.stat().st_size
    return out


def model_state(models_dir: Path, spec: ModelSpec) -> ModelState:
    repo = Path(models_dir) / spec.dirname
    if not repo.is_dir():
        return ModelState(spec, False, False, ("нет каталога в кэше",), 0, "", "")
    manifest = read_manifest(models_dir).get(spec.repo_id) or {}
    source = str(manifest.get("source") or "")
    snap = _snapshot(repo)
    if snap is None:
        return ModelState(spec, True, False, ("нет снимка (недокачано)",), 0, str(repo), source)
    files = _files(snap)
    problems: list[str] = []
    for need in spec.required:
        if files.get(need, 0) <= 0:
            problems.append(f"нет файла {need}")
    weights = {n: s for n, s in files.items() if any(fnmatch.fnmatch(n, w) for w in spec.weights)}
    if not weights:
        problems.append("нет файла весов")
    elif max(weights.values()) < spec.min_weight_bytes:
        problems.append(f"веса короче нормы ({max(weights.values()) / _GIB:.2f} ГБ)")
    if any((repo / "blobs").glob("*.incomplete")):
        problems.append("есть недокачанные файлы (*.incomplete)")
    for name, size in (manifest.get("files") or {}).items():
        if name in files and files[name] != size:
            problems.append(f"размер {name} не совпадает с манифестом")
    return ModelState(spec, True, not problems, tuple(problems), sum(files.values()),
                      str(snap), source)


def models_status(models_dir: Path) -> list[ModelState]:
    return [model_state(models_dir, s) for s in MODELS]


# --------------------------------------------------------------------------- hub ------------ #
_WEIGHT_GLOBS = ("*.safetensors", "pytorch_model.bin")


def prefer_single_weights(
    repo_id: str, allow: Sequence[str],
    lister: Callable[[str], Sequence[str]] | None = None,
) -> list[str]:
    """Оставить в ``allow`` ОДИН формат весов по перечню файлов репозитория (KIT-MODELS-1).

    Движок принимает и ``*.safetensors``, и ``pytorch_model.bin`` (у ``BAAI/bge-m3`` на Hub
    только bin, у реранкера только safetensors). Качать оба, если репозиторий когда-нибудь
    выложит оба, - лишние 2.3 ГБ, поэтому перед скачиванием смотрим список файлов: есть
    safetensors - bin не качаем; есть только bin - safetensors не ждем. Перечень недоступен
    (сеть, зеркало без API) - шаблоны как есть: ``snapshot_download`` возьмет то, что лежит.
    Списки без обоих шаблонов не трогаем.
    """
    allow = list(allow)
    if not all(g in allow for g in _WEIGHT_GLOBS):
        return allow
    try:
        if lister is None:
            from huggingface_hub import HfApi

            files = HfApi().list_repo_files(repo_id)
        else:
            files = lister(repo_id)
    except Exception:  # noqa: BLE001 - перечень не обязателен, это оптимизация
        return allow
    names = [str(f) for f in files]
    if any(n.endswith(".safetensors") for n in names):
        return [a for a in allow if a != "pytorch_model.bin"]
    if any(n == "pytorch_model.bin" or n.endswith("/pytorch_model.bin") for n in names):
        return [a for a in allow if a != "*.safetensors"]
    return allow


def hub_download(repo_id: str, cache_dir: str, allow: Sequence[str],
                 progress: Callable[[int, int], None]) -> str:
    """Боевое скачивание: ``snapshot_download`` + tqdm, агрегирующий байты по всем файлам;
    формат весов - один (:func:`prefer_single_weights`)."""
    from huggingface_hub import snapshot_download
    from tqdm.auto import tqdm  # type: ignore[import-untyped]  # стаб-гэп tqdm - как yaml

    allow = prefer_single_weights(repo_id, allow)
    totals = {"done": 0, "total": 0}

    class _Bar(tqdm):  # type: ignore[misc]
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            super().__init__(*args, **kwargs)
            self._bytes = getattr(self, "unit", "") == "B"
            if self._bytes:
                totals["total"] += int(self.total or 0)

        def update(self, n: float | None = 1) -> bool | None:
            shown = super().update(n)
            if self._bytes and n:
                totals["done"] += int(n)
                progress(totals["done"], totals["total"])
            return shown

    return str(snapshot_download(repo_id, cache_dir=cache_dir, allow_patterns=list(allow),
                                 tqdm_class=_Bar))


# --------------------------------------------------------------------------- архив/папка ----- #
def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_extract(archive: Path, dest: Path) -> None:
    """Распаковка без выхода из ``dest``: абсолютные пути, ``..`` и ссылки наружу - отказ."""
    base = dest.resolve()
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            target = (dest / member.name).resolve()
            if not target.is_relative_to(base):
                raise InstallError("models_bundle",
                                   f"архив пытается выйти из папки: {member.name}")
            if member.issym() or member.islnk():
                link = (target.parent / member.linkname).resolve()
                if os.path.isabs(member.linkname) or not link.is_relative_to(base):
                    raise InstallError("models_bundle",
                                       f"ссылка в архиве ведет наружу: {member.name}")
            if not (member.isreg() or member.isdir() or member.issym()):
                raise InstallError("models_bundle", f"неожиданный тип в архиве: {member.name}")
        try:
            tar.extractall(dest, filter="data")  # Python ≥ 3.11.4: фильтр tarfile - второй пояс
        except TypeError:  # pragma: no cover - старый 3.11 без filter
            tar.extractall(dest)  # noqa: S202 - каждый член проверен выше


def _bundle_root(src: Path) -> Path:
    """Корень набора: папка с ``models--*`` (сама или единственная вложенная)."""
    if any(src.glob("models--*")):
        return src
    inner = [p for p in src.iterdir() if p.is_dir() and any(p.glob("models--*"))]
    if len(inner) == 1:
        return inner[0]
    raise InstallError("models_bundle", f"в {src} нет каталогов models--*",
                       "это не кэш моделей: нужен dt-models.tar или папка models/")


def _verify_bundle(root: Path) -> None:
    """Контрольные суммы по ``dt-models.json`` (есть - сверяем каждый файл; нет - размеры)."""
    path = root / BUNDLE_MANIFEST
    if not path.is_file():
        return
    try:
        listed = json.loads(path.read_text(encoding="utf-8")).get("files") or {}
    except (OSError, ValueError, AttributeError) as exc:
        raise InstallError("models_bundle", f"манифест {BUNDLE_MANIFEST} нечитаем: {exc}") from exc
    for rel, meta in listed.items():
        file = root / rel
        if not file.is_file():
            raise InstallError("models_bundle", f"в наборе нет файла {rel}",
                               "пересобери dt-models.tar или скачай заново")
        if file.stat().st_size != int(meta.get("size", -1)) or _sha256(file) != meta.get("sha256"):
            raise InstallError("models_bundle", f"контрольная сумма не совпала: {rel}",
                               "файл поврежден при передаче: скачай набор заново")


def _from_bundle(ctx: InstallContext, source: Path, say: Callable[[str], None]
                 ) -> list[ModelSpec]:
    """Скопировать недостающие модели из ``source`` (архив/папка) в кэш; вернуть скопированные."""
    ctx.guard(ctx.models_dir)
    src = Path(source).expanduser()
    if not src.exists():
        raise InstallError("models_bundle", f"нет {src}", "проверь путь к dt-models.tar или папке")
    tmp: Path | None = None
    try:
        if src.is_file():
            ctx.models_dir.mkdir(parents=True, exist_ok=True)
            tmp = Path(tempfile.mkdtemp(prefix=".bundle-", dir=ctx.models_dir))
            say(f"распаковываю {src.name} ...")
            try:
                _safe_extract(src, tmp)
            except tarfile.TarError as exc:
                raise InstallError("models_bundle", f"архив не читается: {exc}") from exc
            root = _bundle_root(tmp)
        else:
            root = _bundle_root(src)
        say("проверяю контрольные суммы ...")
        _verify_bundle(root)
        copied: list[ModelSpec] = []
        for spec in MODELS:
            if model_state(ctx.models_dir, spec).complete:
                continue
            repo = root / spec.dirname
            if not repo.is_dir():
                continue
            say(f"копирую {spec.label} ...")
            shutil.copytree(repo, ctx.models_dir / spec.dirname, symlinks=True,
                            dirs_exist_ok=True)
            copied.append(spec)
        return copied
    finally:
        if tmp is not None:
            shutil.rmtree(tmp, ignore_errors=True)


# --------------------------------------------------------------------------- установка ------ #
def _snapshot_files(models_dir: Path, spec: ModelSpec) -> dict[str, int]:
    snap = _snapshot(Path(models_dir) / spec.dirname)
    return _files(snap) if snap else {}


def install_models(ctx: InstallContext) -> StepResult:
    """Наполнить кэш: офлайн из ``--models-from`` либо с хаба с прогрессом; идемпотентно."""
    ctx.guard(ctx.models_dir, ctx.derived)
    todo = [s for s in MODELS if not model_state(ctx.models_dir, s).complete]
    if not todo:
        return StepResult(note="модели уже на месте")
    notes: list[str] = []
    if ctx.models_from is not None:
        copied = _from_bundle(ctx, ctx.models_from, ctx.say)
        for spec in copied:
            _write_manifest(ctx.models_dir, spec, _snapshot_files(ctx.models_dir, spec),
                            f"bundle: {Path(ctx.models_from).name}")
        todo = [s for s in MODELS if not model_state(ctx.models_dir, s).complete]
        notes.append(f"из набора скопировано: {', '.join(s.label for s in copied) or 'ничего'}")
        if todo:
            raise InstallError(
                "models_bundle", "в наборе нет: " + ", ".join(
                    model_state(ctx.models_dir, s).reason for s in todo),
                "возьми полный dt-models.tar или скачай недостающее: dt install --step models")
        return StepResult(note="; ".join(notes))
    need_gib = sum(s.approx_gib for s in todo) + 1.0
    free = ctx.tools.probe.free_bytes(ctx.models_dir) / _GIB
    if free < need_gib:
        raise InstallError("models", f"для моделей нужно ~{need_gib:.1f} ГБ, свободно {free:.1f}",
                           "освободи место и повтори: dt install --step models")
    done_models = 0
    for spec in todo:
        _download_one(ctx, spec, done_models, len(todo))
        done_models += 1
    return StepResult(note=f"скачано: {', '.join(s.label for s in todo)}")


def _download_one(ctx: InstallContext, spec: ModelSpec, index: int, count: int) -> None:
    ctx.say(f"  качаю {spec.label} (~{spec.approx_gib:g} ГБ, разовая операция; повтор докачает)")
    last_error = ""
    for attempt in range(1, max(1, ctx.model_attempts) + 1):
        marks = {"printed": -1}

        def progress(done: int, total: int, _marks: dict[str, int] = marks) -> None:
            if total <= 0:
                return
            pct = min(100, int(done * 100 / total))
            overall = min(100, int((index * 100 + pct) / count))
            if ctx.state is not None and ctx.state.record("models").progress != overall:
                ctx.state.set_progress("models", overall)
                ctx.state.save()
            if pct // 10 != _marks["printed"] // 10 or pct == 100:
                _marks["printed"] = pct
                ctx.say(f"    {spec.label}: {pct}% ({done / _GIB:.2f} из {total / _GIB:.2f} ГБ)")

        try:
            ctx.tools.downloader(spec.repo_id, str(ctx.models_dir), spec.allow_patterns(),
                                 progress)
        except InstallError:
            raise
        except Exception as exc:  # noqa: BLE001 - сеть/хаб: повтор докачает с места обрыва
            last_error = f"{type(exc).__name__}: {exc}"
            ctx.say(f"    обрыв ({last_error[:120]}); попытка {attempt} из {ctx.model_attempts}")
            continue
        state = model_state(ctx.models_dir, spec)
        if not state.complete:
            raise InstallError("models", f"после скачивания: {state.reason}",
                               "повтори: dt install --step models (докачает)")
        _write_manifest(ctx.models_dir, spec, _snapshot_files(ctx.models_dir, spec), "hub")
        return
    raise InstallError("models", f"не удалось скачать {spec.label}: {last_error[:200]}",
                       "проверь интернет и повтори: dt install --step models (докачает с места "
                       "обрыва); офлайн: --models-from dt-models.tar")


# --------------------------------------------------------------------------- шаг ------------- #
def models_step_check(ctx: InstallContext) -> StepCheck:
    states = models_status(ctx.models_dir)
    if all(s.complete for s in states):
        origin = {s.source for s in states if s.source} or {"установлены ранее"}
        shown = ", ".join(s.reason for s in states)
        return StepCheck(DONE, f"{shown} ({'; '.join(sorted(origin))})")
    reasons = "; ".join(s.reason for s in states if not s.complete)
    state = PARTIAL if any(s.present for s in states) else ABSENT
    return StepCheck(state, reasons)


def models_step_run(ctx: InstallContext) -> StepResult:
    return install_models(ctx)
