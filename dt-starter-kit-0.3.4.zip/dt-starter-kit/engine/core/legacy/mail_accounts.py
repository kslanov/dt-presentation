"""MAIL-ACCOUNTS-1: почта по аккаунтам - миграция манифеста и снимок ящиков для доктора.

Две вещи, которых нет в ``core.legacy.mail`` (там сам инжест):

1. **Миграция манифеста** (:func:`migrate_manifest`). До MAIL-ACCOUNTS-1 ключ треда -
   ``conv:<id>``, а курсор - ``bucket_dates[bucket]``; у ящиков с аккаунтом ключ -
   ``conv:<адрес>:<id>``, курсор - ``bucket_dates[bucket[адрес]]``. Старый манифест
   принадлежит ОДНОМУ ящику (``DT_OUTLOOK_LEGACY_ACCOUNT``) - миграция одним проходом
   переименовывает его ключи и метит сообщения аккаунтом. Порядок: dry-run по умолчанию →
   резервная копия (манифест + хардлинк-копия сайдкаров) → новые сайдкары → манифест → снос
   старых сайдкаров. Повторный прогон ничего не делает (идемпотентно). Заметки vault не
   трогаются: id/путь заметки держит ``anchor_key`` (исходный ключ) - ``account`` появится во
   frontmatter при следующем обновлении треда.
2. **Снимок ящиков** (``.derived/mail_accounts.json``): итог последнего прогона по
   спецификациям (всего писем в папке, новейшее, проблемы с кодом) и последний перечень ящиков
   Outlook (``list_folders``). Читает доктор «Почта: ящики и папки» - живой мост он не дергает
   (перечень папок - десятки секунд).

``core`` ⊥ mcp/cli; ни сети, ни LLM; Outlook не читается и не пишется.
"""

from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core.adapters import StoreUnavailableError
from core.config import normalize_account, outlook_ingest_manifest_path
from core.config._outlook import _ACCOUNT_RE
from core.legacy.mail import (
    MailIngestStats,
    _index_entry,
    _load_manifest,
    _load_thread_rec,
    _save_manifest,
    _save_thread_rec,
    _state_dir,
    _thread_file,
    split_thread_key,
)

__all__ = [
    "MigrationReport",
    "migrate_manifest",
    "state_path",
    "load_state",
    "record_run",
    "record_mailboxes",
    "record_bridge",
    "mailboxes_from_folders",
]


# --------------------------------------------------------------------------- #
# Миграция манифеста                                                           #
# --------------------------------------------------------------------------- #


@dataclass
class MigrationReport:
    """Итог (или план, при ``dry_run``) миграции манифеста почты."""

    legacy_account: str
    dry_run: bool
    threads_total: int = 0
    to_rename: int = 0  # conv:<id> → conv:<адрес>:<id>
    to_tag: int = 0  # msg:<id> без аккаунта: ключ прежний, метка аккаунта
    already_with_account: int = 0
    renamed: int = 0
    tagged: int = 0
    messages_tagged: int = 0
    store_errors: list[str] = field(default_factory=list)
    backup_dir: str = ""
    examples: list[str] = field(default_factory=list)

    @property
    def nothing_to_do(self) -> bool:
        return self.to_rename == 0 and self.to_tag == 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "legacy_account": self.legacy_account, "dry_run": self.dry_run,
            "threads_total": self.threads_total, "to_rename": self.to_rename,
            "to_tag": self.to_tag, "already_with_account": self.already_with_account,
            "renamed": self.renamed, "tagged": self.tagged,
            "messages_tagged": self.messages_tagged, "store_errors": list(self.store_errors),
            "backup_dir": self.backup_dir, "examples": list(self.examples),
        }


def _classify(tkey: str, entry: dict[str, Any]) -> str:
    """``rename`` | ``tag`` | ``done`` для одного треда индекса."""
    if tkey.startswith("conv:"):
        account, _conv = split_thread_key(tkey)
        return "done" if account else "rename"
    if tkey.startswith("msg:"):
        return "done" if entry.get("account") else "tag"
    return "done"


def _link_or_copy(src: str, dst: str) -> str:
    """Хардлинк (мгновенно, без места; сайдкары пишутся через tmp+replace - новый inode, копия
    не портится), иначе обычная копия."""
    try:
        os.link(src, dst)
    except OSError:
        shutil.copy2(src, dst)
    return dst


def _backup(manifest_path: Path, state_dir: Path, now: datetime) -> Path:
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    dest = manifest_path.parent / f"mail_backup_pre_accounts_{stamp}"
    dest.mkdir(parents=True, exist_ok=False)
    if manifest_path.is_file():
        shutil.copy2(manifest_path, dest / manifest_path.name)
    if state_dir.is_dir():
        shutil.copytree(state_dir, dest / state_dir.name, copy_function=_link_or_copy)
    return dest


def migrate_manifest(
    legacy_account: str,
    *,
    dry_run: bool = True,
    manifest_path: Path | None = None,
    now: datetime | None = None,
) -> MigrationReport:
    """Перевести манифест почты на ключи по аккаунтам (все старые треды - ящика ``legacy_account``).

    ``dry_run=True`` (по умолчанию) считает план и ничего не пишет. Реальный прогон делает
    резервную копию (``mail_backup_pre_accounts_<ts>/``: манифест + сайдкары) ДО первой записи.
    Нечитаемый сайдкар - тред пропускается и попадает в ``store_errors`` (не затирается).
    Повторный прогон: ``nothing_to_do`` - ничего не пишет и копии не делает. Вызывать под
    ``mail_writer_lock`` (CLI делает сам).
    """
    account = normalize_account(legacy_account)
    if not _ACCOUNT_RE.match(account):
        raise ValueError("legacy_account: ожидался адрес ящика вида имя@домен")
    mpath = Path(manifest_path) if manifest_path is not None else outlook_ingest_manifest_path()
    sdir = _state_dir(mpath)
    index = {k: v for k, v in _load_manifest(mpath).items() if "msg_ids" in v}
    rep = MigrationReport(legacy_account=account, dry_run=dry_run, threads_total=len(index))
    plan: dict[str, str] = {}
    for tkey, entry in index.items():
        kind = _classify(tkey, entry)
        if kind == "done":
            rep.already_with_account += 1
            continue
        plan[tkey] = kind
        if kind == "rename":
            rep.to_rename += 1
        else:
            rep.to_tag += 1
        if len(rep.examples) < 3:
            target = f"conv:{account}:{tkey[5:]}" if kind == "rename" else tkey
            rep.examples.append(f"{kind}: {tkey} → {target}")
    if dry_run or not plan:
        return rep

    rep.backup_dir = str(_backup(mpath, sdir, now or datetime.now(UTC)))
    renamed_old: list[str] = []
    for tkey, kind in plan.items():
        try:
            rec = _load_thread_rec(sdir, tkey)
        except StoreUnavailableError as exc:
            rep.store_errors.append(f"{tkey}: {exc.reason[:80]}")
            continue  # битый сайдкар не затираем: тред остается как был
        rec["account"] = account
        for mm in (rec.get("messages") or {}).values():
            if isinstance(mm, dict) and not mm.get("account"):
                mm["account"] = account
                rep.messages_tagged += 1
        new_key = f"conv:{account}:{tkey[5:]}" if kind == "rename" else tkey
        if kind == "rename":
            rec["anchor_key"] = str(rec.get("anchor_key") or tkey)
        _save_thread_rec(sdir, new_key, rec)  # новый сайдкар; старый пока на месте
        if kind == "rename":
            index.pop(tkey, None)
            renamed_old.append(tkey)
            rep.renamed += 1
        else:
            rep.tagged += 1
        index[new_key] = _index_entry(rec)
    _save_manifest(mpath, index)  # манифест - после сайдкаров: сбой посередине не теряет тред
    for old in renamed_old:
        _thread_file(sdir, old).unlink(missing_ok=True)
    return rep


# --------------------------------------------------------------------------- #
# Снимок ящиков для доктора                                                    #
# --------------------------------------------------------------------------- #


def state_path(manifest_path: Path | None = None) -> Path:
    """``<derived>/mail_accounts.json`` (рядом с манифестом почты; per-machine, пересобираемый)."""
    mpath = Path(manifest_path) if manifest_path is not None else outlook_ingest_manifest_path()
    return mpath.parent / "mail_accounts.json"


def load_state(manifest_path: Path | None = None) -> dict[str, Any]:
    """Снимок или ``{}`` (нет файла / нечитаем - доктор скажет «не снят», а не «ящиков нет»)."""
    path = state_path(manifest_path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _save_state(state: dict[str, Any], manifest_path: Path | None) -> None:
    path = state_path(manifest_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(
        json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8"
    )
    tmp.replace(path)


def record_run(
    stats: MailIngestStats, *, now: datetime | None = None, manifest_path: Path | None = None
) -> None:
    """Итог прогона по спецификациям → снимок (``specs`` и ``problems``; ``mailboxes`` не трогаем).

    Пишется и после боевого, и после сухого прогона: доктору нужны ``total``/``newest`` папки и
    коды деградации, а не факт записи заметок.
    """
    state = load_state(manifest_path)
    ts = (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ")
    state["run"] = {"ts": ts, "dry_run": stats.dry_run, "scope": stats.scope}
    # Частичный прогон (``--account``/``--folders``, бэкфилл канарейкой) обновляет ТОЛЬКО свои
    # спецификации: иначе остальные пропадали из снимка и доктор показывал их «не читалась»
    # (приемка 08.11). Проблемы - те же правила: свои заменяем, чужие оставляем.
    ran = set(stats.folder_snapshot)
    specs = dict(state.get("specs") or {})
    specs.update({k: dict(v) for k, v in stats.folder_snapshot.items()})
    state["specs"] = specs
    kept = [dict(p) for p in (state.get("problems") or [])
            if isinstance(p, dict) and str(p.get("folder") or "") not in ran]
    state["problems"] = kept + [dict(p) for p in stats.folder_problems]
    _save_state(state, manifest_path)


def mailboxes_from_folders(rows: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Перечень ``list_folders`` → ящики: ``{адрес: {folders:[{name,path,total,newest}…]}}``.

    Папки без аккаунта («On My Computer», PST-архивы) - под ключом ``""``; ``folders`` каждого
    ящика - только папки с письмами (счетчик нужен доктору и мастеру).
    """
    boxes: dict[str, dict[str, Any]] = {}
    for r in rows:
        acc = normalize_account(r.get("account"))
        box = boxes.setdefault(acc, {"folders": [], "total": 0})
        total = int(r.get("total") or 0)
        box["total"] += total
        if total > 0:
            box["folders"].append({
                "name": str(r.get("name") or ""), "path": str(r.get("path") or ""),
                "total": total, "newest": str(r.get("newest") or ""),
            })
    return boxes


def record_mailboxes(
    rows: list[dict[str, Any]], *, now: datetime | None = None, manifest_path: Path | None = None
) -> dict[str, dict[str, Any]]:
    """Последний перечень ящиков Outlook → снимок (``mailboxes`` + ``mailboxes_ts``)."""
    state = load_state(manifest_path)
    boxes = mailboxes_from_folders(rows)
    state["mailboxes"] = boxes
    state["mailboxes_ts"] = (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ")
    _save_state(state, manifest_path)
    return boxes


def record_bridge(
    code: str, reason: str, *, now: datetime | None = None, manifest_path: Path | None = None
) -> None:
    """Последний итог моста: ``code`` (``outlook_new_mode``) или ``""`` - мост читается.

    Пишет ингест (после preflight): доктор «Outlook-мост» показывает отказ и подсказку без живого
    вызова Outlook.
    """
    state = load_state(manifest_path)
    ts = (now or datetime.now(UTC)).strftime("%Y-%m-%dT%H:%M:%SZ")
    state["bridge"] = {"ts": ts, "code": code, "reason": reason}
    _save_state(state, manifest_path)
