"""MAIL-FILTER-1 п.4 — ретро-проход: применить ПРАВИЛА ФИЛЬТРА к уже накопленному корпусу почты.

``ingest_mail`` только добавляет: тред, ставший шумом по новым правилам (роботы, авто-ответы),
жил бы в корпусе вечно. Проход идет по сайдкарам (Outlook НЕ нужен), решает по каждому сообщению
тем же :func:`core.legacy.mail_filter.decide`, что и инжест:

* шумовые сообщения убираются из треда; тред, где не осталось ни одного, - заметка + сайдкар +
  строка индекса почты удаляются; частично очищенный - перерендер штатным ``_render_thread``
  (id заметки прежний: он считается от ключа треда, не от содержимого);
* ``msg_id`` снятых - в журнал отказов (политика hint INGRESS-1 без изменений, ``rule`` в строке) и
  в :class:`~core.legacy.mail_filter.RefusedMemory`, чтобы следующий инкремент их не вернул;
* по каждому треду - событие ``ingest`` со статусом ``refiltered``.

Контракт §9 п.11г: **dry-run по умолчанию** (отчет «правило → тредов/сообщений, примеры hint», НОЛЬ
записей - ни журнала, ни событий, ни памяти), канарейка ``limit`` (первые N затронутых ТРЕДОВ в
порядке ключа), затем полный ``apply``. Индекс поиска проход не трогает: исчезнувшие заметки снимает
штатный ``reindex_inc``. У старых сообщений (~90% корпуса) нет собственной темы (``subject`` в
сайдкаре появился позже), а тема треда - тема самого нового письма первого импорта, не гарантия для
всех. Поэтому темовые правила к ним применяются только в треде из ОДНОГО письма (там тема треда
= тема письма; счетчик ``subject_from_thread``), в многописьменном - только правила по
отправителю (``subject_unknown`` - сколько сообщений остались без темового решения).
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from core import runlock
from core.adapters import StoreUnavailableError
from core.config import mail_owner_domains, outlook_ingest_manifest_path, outlook_self_tokens
from core.ingress.refusals import refuse_many, subject_domain_hint
from core.legacy.mail import (
    _index_entry,
    _is_inbox,
    _load_manifest,
    _load_thread_rec,
    _render_thread,
    _save_manifest,
    _save_thread_rec,
    _state_dir,
    _thread_file,
    _thread_source_path,
)
from core.legacy.mail_filter import RefusedMemory, Rules, decide, load_rules
from core.legacy.render import legacy_note_id

logger = logging.getLogger(__name__)

__all__ = ["RefilterReport", "refilter_corpus"]

_EXAMPLES_PER_RULE = 3
_FLUSH_EVERY = 100  # тредов между сохранениями индекса почты и памяти (resume-safe)


@dataclass
class RefilterReport:
    """Итог прохода (JSON-сериализуем через :meth:`to_dict`)."""

    dry_run: bool = True
    limit: int | None = None
    rules_source: str = ""
    threads_total: int = 0
    messages_total: int = 0
    threads_affected: int = 0  # затронуто (ограничено limit)
    threads_dropped: int = 0  # тред снят целиком
    threads_trimmed: int = 0  # тред переписан без шумовых сообщений
    messages_removed: int = 0
    subject_from_thread: int = 0  # шумовых сообщений, решенных по теме треда из ОДНОГО письма
    subject_unknown: int = 0  # сообщений без своей темы в многописьменных тредах: темовые правила
    #                           к ним НЕ применялись (только правила по отправителю)
    store_errors: int = 0  # нечитаемые сайдкары (пропущены, не затёрты)
    candidates_total: int = 0  # затронутых тредов ДО limit
    by_rule: dict[str, dict[str, Any]] = field(default_factory=dict)
    by_bucket: dict[str, int] = field(default_factory=dict)
    dropped: list[str] = field(default_factory=list)  # ключи тредов (apply)
    rewritten: list[str] = field(default_factory=list)
    elapsed_s: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "dry_run": self.dry_run,
            "limit": self.limit,
            "rules_source": self.rules_source,
            "threads_total": self.threads_total,
            "messages_total": self.messages_total,
            "candidates_total": self.candidates_total,
            "threads_affected": self.threads_affected,
            "threads_dropped": self.threads_dropped,
            "threads_trimmed": self.threads_trimmed,
            "messages_removed": self.messages_removed,
            "subject_from_thread": self.subject_from_thread,
            "subject_unknown": self.subject_unknown,
            "store_errors": self.store_errors,
            "by_bucket": self.by_bucket,
            "by_rule": self.by_rule,
            "dropped": self.dropped,
            "rewritten": self.rewritten,
            "elapsed_s": round(self.elapsed_s, 2),
        }


@dataclass
class _Plan:
    tkey: str
    removed: dict[str, tuple[str | None, str | None, str, str]]  # id → (reason, rule, hint, bucket)
    total: int  # сообщений в треде до прохода

    @property
    def drops(self) -> bool:
        return len(self.removed) >= self.total


def _judge_thread(
    rec: dict[str, Any], rules: Rules, report: RefilterReport
) -> dict[str, tuple[str | None, str | None, str, str]]:
    """Шумовые сообщения треда → ``{msg_id: (reason, rule, hint, bucket)}`` (hint - политика
    INGRESS-1: тема[:60] + домен, адрес не пишем)."""
    out: dict[str, tuple[str | None, str | None, str, str]] = {}
    thread_subject = str(rec.get("subject") or "")
    alone = len(rec.get("messages") or {}) == 1
    for mid, m in (rec.get("messages") or {}).items():
        own = str(m.get("subject") or "").strip()
        # Тема треда - тема САМОГО НОВОГО сообщения первого импорта, не всех: авто-ответ внутри
        # живого разговора дал бы треду тему «Автоматический ответ: …» и снес бы живые письма.
        # Поэтому без собственной темы темовые правила применяются только к треду из ОДНОГО
        # письма (тема треда = его тема); в многописьменном - только правила по отправителю.
        if own:
            subject = own
        elif alone:
            subject = thread_subject
        else:
            subject = ""
            report.subject_unknown += 1
        verdict = decide(
            {"subject": subject, "from": m.get("from")}, inbox=_is_inbox(m.get("bucket") or ""),
            rules=rules,
        )
        if not verdict.noise:
            continue
        if not own and alone and str(verdict.rule or "").startswith("subject_"):
            report.subject_from_thread += 1
        out[str(mid)] = (
            verdict.reason, verdict.rule, subject_domain_hint(subject, m.get("from")),
            str(m.get("bucket") or "?"),
        )
    return out


def _tally(report: RefilterReport, plan: _Plan) -> None:
    seen_rules: set[str] = set()
    for _mid, (reason, rule, hint, bucket) in plan.removed.items():
        name = rule or "?"
        row = report.by_rule.setdefault(
            name, {"reason": reason, "threads": 0, "threads_dropped": 0, "messages": 0,
                   "examples": []},
        )
        row["messages"] += 1
        if name not in seen_rules:
            seen_rules.add(name)
            row["threads"] += 1
            if plan.drops:
                row["threads_dropped"] += 1
        if len(row["examples"]) < _EXAMPLES_PER_RULE and hint not in row["examples"]:
            row["examples"].append(hint)
        report.by_bucket[bucket] = report.by_bucket.get(bucket, 0) + 1
    report.messages_removed += len(plan.removed)
    if plan.drops:
        report.threads_dropped += 1
    else:
        report.threads_trimmed += 1


def _emit(rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    try:
        from core.eventlog import emit_batch, new_run_id

        run_id = new_run_id()
        emit_batch([{**r, "run_id": run_id} for r in rows])
    except Exception:  # noqa: BLE001 — лента событий не критичный путь
        logger.debug("eventlog emit(refiltered) failed", exc_info=True)


def refilter_corpus(
    vault_path: Path,
    *,
    dry_run: bool = True,
    limit: int | None = None,
    rules: Rules | None = None,
    manifest_path: Path | None = None,
    owner_domains: list[str] | None = None,
    self_tokens: list[str] | None = None,
    memory: RefusedMemory | None = None,
    on_progress: Callable[[str], None] | None = None,
) -> RefilterReport:
    """Применить правила фильтра к корпусу почты (см. модульный докстринг).

    ``limit`` - канарейка: взять первые N затронутых тредов (в порядке ключа). ``dry_run=True``
    (по умолчанию) не пишет НИЧЕГО. Нечитаемый сайдкар - тред пропущен и посчитан
    (``store_errors``), не затёрт; нечитаемая память «отказано» при ``apply`` -
    :class:`~core.adapters.StoreUnavailableError` (писать снятое некуда - не снимаем).
    """
    start = time.perf_counter()
    vault = Path(vault_path)
    mpath = manifest_path if manifest_path is not None else outlook_ingest_manifest_path()
    state_dir = _state_dir(mpath)
    rules = rules if rules is not None else load_rules(vault)
    report = RefilterReport(dry_run=dry_run, limit=limit, rules_source=rules.source)
    say = on_progress or (lambda _m: None)
    index = {k: v for k, v in _load_manifest(mpath).items() if "msg_ids" in v}
    report.threads_total = len(index)

    # ---- план: чтение сайдкаров, решение по каждому сообщению -----------------------------
    plans: list[_Plan] = []
    for n, tkey in enumerate(sorted(index), 1):
        runlock.beat()  # MAIL-LOCK-1: писатель держит dt-sync.lock - сторож видит прогресс
        try:
            rec = _load_thread_rec(state_dir, tkey)
        except StoreUnavailableError as exc:
            report.store_errors += 1
            logger.error("[mail-refilter] сайдкар %s нечитаем: %s", tkey, exc)
            continue
        report.messages_total += len(rec["messages"])
        removed = _judge_thread(rec, rules, report)
        if removed:
            plans.append(_Plan(tkey, removed, len(rec["messages"])))
        if n % 1000 == 0:
            say(f"[mail-refilter] просмотрено {n}/{len(index)} тредов")
    report.candidates_total = len(plans)
    if limit is not None:
        plans = plans[: max(0, int(limit))]
    report.threads_affected = len(plans)

    # отчет по правилам считаем по ОТОБРАННЫМ планам (dry-run и apply показывают одно и то же)
    for plan in plans:
        _tally(report, plan)
    if dry_run or not plans:
        report.elapsed_s = time.perf_counter() - start
        return report

    # ---- apply ---------------------------------------------------------------------------------
    mem = memory if memory is not None else RefusedMemory()
    if mem.error is not None:
        raise StoreUnavailableError(
            f"память «отказано» нечитаема: {mem.error}", adapter="mail_refused", path=str(mem.path)
        )
    owner_doms = owner_domains if owner_domains is not None else mail_owner_domains()
    selfs = self_tokens if self_tokens is not None else outlook_self_tokens()
    stamp = datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")
    events: list[dict[str, Any]] = []
    for n, plan in enumerate(plans, 1):
        runlock.beat()
        tkey = plan.tkey
        rec = _load_thread_rec(state_dir, tkey)
        old_rel = str(rec.get("note_path") or index.get(tkey, {}).get("note_path") or "")
        note_id = legacy_note_id(_thread_source_path(str(rec.get("anchor_key") or tkey)))
        for mid, (reason, rule, _hint, _bucket) in plan.removed.items():
            mem.add(mid, reason, rule, stamp)
        mem.save()  # «отказано» - ДО правки треда: сбой посередине не вернет снятое
        for mid in plan.removed:
            rec["messages"].pop(mid, None)
        if not rec["messages"]:
            if old_rel and (vault / old_rel).is_file():
                (vault / old_rel).unlink()
            _thread_file(state_dir, tkey).unlink(missing_ok=True)
            index.pop(tkey, None)
            report.dropped.append(tkey)
            path = old_rel
        else:
            rel, chash = _render_thread(
                tkey, rec, vault, owner_domains=owner_doms, self_tokens=selfs, dry_run=False
            )
            rec["note_path"], rec["content_hash"] = rel, chash
            if old_rel and old_rel != rel and (vault / old_rel).is_file():
                (vault / old_rel).unlink()  # слуг сменился: файл переезжает, id прежний
            _save_thread_rec(state_dir, tkey, rec)
            index[tkey] = _index_entry(rec)
            report.rewritten.append(tkey)
            path = rel
        events.append({
            "stage": "ingest", "status": "refiltered", "note_id": note_id, "path": path,
            "detail": {"route": "mail", "removed": len(plan.removed),
                       "left": len(rec["messages"]), "dropped": not rec["messages"]},
        })
        for (reason, rule), group in _group(plan.removed).items():
            refuse_many("mail", str(reason), group, rule=rule)
        if n % _FLUSH_EVERY == 0:
            _save_manifest(mpath, index)
            _emit(events)
            events = []
            say(f"[mail-refilter] применено {n}/{len(plans)} тредов")
    _save_manifest(mpath, index)
    _emit(events)
    mem.save()
    report.elapsed_s = time.perf_counter() - start
    logger.info(
        "[mail-refilter] тредов снято: %d, переписано: %d, сообщений убрано: %d",
        report.threads_dropped, report.threads_trimmed, report.messages_removed,
    )
    return report


def _group(
    removed: dict[str, tuple[str | None, str | None, str, str]],
) -> dict[tuple[str | None, str | None], list[tuple[str | None, str | None]]]:
    """``{(reason, rule): [(hint, msg_id), …]}`` - одна пачка refuse_many на правило."""
    out: dict[tuple[str | None, str | None], list[tuple[str | None, str | None]]] = {}
    for mid, (reason, rule, hint, _bucket) in removed.items():
        out.setdefault((reason, rule), []).append((hint, mid))
    return out
