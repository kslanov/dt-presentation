-- Shared AppleScript helpers for the read-only Classic Outlook for Mac bridge.
-- Concatenated AHEAD of a read op script (read_messages / read_thread) by
-- core/operational/outlook_bridge.py, so a single `osascript <file> argv…`
-- invocation runs the op's `on run argv` with these handlers in scope.
--
-- Why AppleScript and not JXA: JXA's `whose` on a date property does NOT push
-- the filter into Outlook — it materialises the whole folder (15k+ messages)
-- and hangs. The AppleScript engine sends `messages whose time received > d`
-- as an indexed query, returning only the in-window set in seconds. This lib is
-- READ-ONLY; nothing here ever mutates Outlook.
--
-- Split of concerns: the *pure* handlers below (lc, isSentFolderName, parseISO,
-- isoUTC, formatOneAddr, joinList, topIndicesByKeyDesc, sortIndicesByKeyDesc,
-- JSON emit) touch neither Outlook nor `tell application`, so they are unit-
-- tested via osascript with fake data (tests/test_outlook_read_jxa.py). The
-- app-touching work (whose query, bulk get, per-survivor field reads) lives in
-- the op scripts.

use framework "Foundation"
use scripting additions

-- Apple Event timeout ceiling for every op (the bridge substitutes the literal
-- with DT_OUTLOOK_TIMEOUT). Ops wrap their body in `with timeout of kDTTimeout
-- seconds` to lift the DEFAULT ~120s Apple Event cap — a big meta/heavy call
-- otherwise dies with "AppleEvent timed out" before our work finishes.
property kDTTimeout : 600

-- Unicode-safe lowercase (Cyrillic included) via Foundation.
on lc(s)
	return (current application's NSString's stringWithString:(s as text))'s lowercaseString() as text
end lc

-- Folder-name synonyms (EN + RU) so the default config names work against a
-- localized Outlook.
on isInboxName(nm)
	set k to my lc(nm)
	return (k is "inbox") or (k is "входящие")
end isInboxName

on isSentFolderName(nm)
	set k to my lc(nm)
	return (k is "sent") or (k is "sent items") or (k is "отправленные") or (k is "sent mail")
end isSentFolderName

-- Broader "looks like a Sent folder" test for diagnostics: exact synonyms plus
-- any name containing sent / отправ (e.g. "Sent Messages", "Отправленные").
on looksSent(nm)
	set k to my lc(nm)
	if my isSentFolderName(k) then return true
	if k contains "sent" then return true
	if k contains "отправ" then return true
	return false
end looksSent

-- Zero-padding for ISO components.
on pad2(n)
	set s to (n as integer) as string
	if (count s) < 2 then set s to "0" & s
	return s
end pad2

on pad4(n)
	set s to (n as integer) as string
	repeat while (count s) < 4
		set s to "0" & s
	end repeat
	return s
end pad4

-- AppleScript date (local) → UTC ISO 8601 string ("…Z"), matching what the old
-- JXA bridge emitted via Date.toISOString(). The Python layer parses naive times
-- as UTC, so we must convert. `time to GMT` is the machine's current offset.
on isoUTC(d)
	try
		set g to d - (time to GMT)
		return my pad4(year of g) & "-" & my pad2(month of g as integer) & "-" & my pad2(day of g) & "T" & my pad2(hours of g) & ":" & my pad2(minutes of g) & ":" & my pad2(seconds of g) & "Z"
	on error
		return ""
	end try
end isoUTC

-- Parse "YYYY-MM-DD" or "YYYY-MM-DDTHH:MM:SS…" into a local AppleScript date.
-- Day is set to 1 before month/year to dodge month-overflow on assignment.
on parseISO(iso)
	set s to iso as text
	set y to (text 1 thru 4 of s) as integer
	set mo to (text 6 thru 7 of s) as integer
	set dy to (text 9 thru 10 of s) as integer
	set hh to 0
	set mm to 0
	set ss to 0
	if (count s) ≥ 19 and (character 11 of s is "T") then
		set hh to (text 12 thru 13 of s) as integer
		set mm to (text 15 thru 16 of s) as integer
		set ss to (text 18 thru 19 of s) as integer
	end if
	set d to (current date)
	set day of d to 1
	set year of d to y
	set month of d to mo
	set day of d to dy
	set time of d to (hh * 3600 + mm * 60 + ss)
	return d
end parseISO

-- Combine a name + email address into "Name <addr>" / "addr" / "".
on formatOneAddr(nm, ad)
	set nm to nm as text
	set ad to ad as text
	if nm is not "" and ad is not "" then return nm & " <" & ad & ">"
	if ad is not "" then return ad
	return nm
end formatOneAddr

-- Join a list of strings with a separator (text-item-delimiters, restored).
on joinList(lst, sep)
	if (count lst) is 0 then return ""
	set {oldTID, AppleScript's text item delimiters} to {AppleScript's text item delimiters, sep}
	set s to lst as text
	set AppleScript's text item delimiters to oldTID
	return s
end joinList

-- Sort 1-based indices by a parallel numeric key list, DESCENDING, via a native
-- Foundation sort (O(n log n) — a pure-AppleScript sort would be O(n²) and choke
-- on a large no-since pull). Returns the indices in sorted order.
on sortIndicesByKeyDesc(keys)
	set n to count of keys
	if n is 0 then return {}
	set arr to current application's NSMutableArray's array()
	repeat with i from 1 to n
		set d to current application's NSMutableDictionary's dictionary()
		(d's setObject:(item i of keys) forKey:"k")
		(d's setObject:i forKey:"i")
		(arr's addObject:d)
	end repeat
	set sd to (current application's NSSortDescriptor's sortDescriptorWithKey:"k" ascending:false)
	set sorted to (arr's sortedArrayUsingDescriptors:{sd})
	set outIdx to {}
	repeat with d in sorted
		set end of outIdx to ((d's objectForKey:"i") as integer)
	end repeat
	return outIdx
end sortIndicesByKeyDesc

-- Newest-first indices capped to `lim` — the "sort + limit BEFORE bodies" step.
on topIndicesByKeyDesc(keys, lim)
	set order to my sortIndicesByKeyDesc(keys)
	if lim > 0 and (count order) > lim then set order to items 1 thru lim of order
	return order
end topIndicesByKeyDesc

-- AppleScript list of strings → NSArray (for JSON attachment lists).
on nsArrayFromList(lst)
	set arr to current application's NSMutableArray's array()
	repeat with x in lst
		(arr's addObject:(x as text))
	end repeat
	return arr
end nsArrayFromList

-- Serialize an NSArray/NSDictionary to JSON and write the UTF-8 bytes straight
-- to stdout — bypassing AppleScript text coercion so Cyrillic is byte-correct.
on emitJSON(nsObj)
	set jsonData to (current application's NSJSONSerialization's dataWithJSONObject:nsObj options:0 |error|:(missing value))
	set fh to (current application's NSFileHandle's fileHandleWithStandardOutput())
	fh's writeData:jsonData
end emitJSON

-- ADAPTER-HONEST-1: выровненность ПАРАЛЛЕЛЬНЫХ списков свойств. Bulk-get по одному
-- свойству на список; если у одного элемента свойство не отдалось, список короче на 1
-- и индексный доступ (`item i of …` / `nth`) молча сдвигает ВСЕ последующие значения на
-- соседа (так 200 писем легли в чужие треды). Правило: ОБЯЗАТЕЛЬНЫЙ список обязан иметь
-- ровно n элементов; ОПЦИОНАЛЬНЫЙ — n либо 0 (свойство недоступно целиком, сдвигать
-- нечего → дефолты). Иначе — error "bridge_misaligned: …": Python-сторона превращает его
-- в отказ-конверт, а не в данные.
on assertAligned(label, n, requiredCounts, optionalCounts)
	repeat with c in requiredCounts
		if (c as integer) is not n then error "bridge_misaligned: " & label & " n=" & n & " required=" & (my joinInts(requiredCounts))
	end repeat
	repeat with c in optionalCounts
		set k to c as integer
		if k is not n and k is not 0 then error "bridge_misaligned: " & label & " n=" & n & " optional=" & (my joinInts(optionalCounts))
	end repeat
	return true
end assertAligned

on joinInts(lst)
	set out to ""
	repeat with c in lst
		if out is not "" then set out to out & ","
		set out to out & ((c as integer) as text)
	end repeat
	return out
end joinInts

-- Emit a {"error": "…"} envelope — the bridge turns it into OutlookUnavailableError.
on emitError(msg)
	set d to current application's NSMutableDictionary's dictionary()
	(d's setObject:(msg as text) forKey:"error")
	my emitJSON(d)
end emitError

-- Is Classic Outlook running? Checked via System Events so we never auto-launch
-- it just to read (mirrors the JXA contract).
on isOutlookRunning()
	try
		tell application "System Events" to return (exists (application process "Microsoft Outlook"))
	on error
		return false
	end try
end isOutlookRunning

-- Resolve a folder NAME to a folder object: `inbox` keyword for inbox synonyms,
-- a Sent-synonym match for sent, otherwise an exact (case-insensitive) name
-- match. Recurses into sub-folders (depth-capped) like the old JXA walk.
on resolveFolder(folderName)
	tell application "Microsoft Outlook"
		if my isInboxName(folderName) then return inbox
		if my isSentFolderName(folderName) then return my bestSentFolder()
		return my searchFolders(mail folders, false, my lc(folderName), 0)
	end tell
end resolveFolder

-- MAIL-ACCOUNTS-1 — аккаунт как часть адреса папки.
--
-- Папка по ИМЕНИ без аккаунта (`resolveFolder`) идет через ключевые слова приложения:
-- `inbox` - одно умолчание Outlook, какое именно решает сам Outlook (смена порядка
-- аккаунтов молча перенаправила чтение на пустую «On My Computer/Inbox»), `Sent` -
-- одна «самая активная» папка. Второго ящика в такой модели нет. Поэтому op-скрипты
-- принимают ЗАВЕРШАЮЩИЙ argv-элемент `account=<адрес>`; с ним имя ищется ВНУТРИ аккаунта
-- (`resolveFolderIn`), ключевые слова приложения не используются вовсе. Без него -
-- прежнее поведение (совместимость).

-- Адрес ящика из argv («account=…» в любой позиции), иначе "".
on argAccount(argv)
	repeat with a in argv
		set t to a as text
		if t starts with "account=" and (count t) > 8 then return text 9 thru -1 of t
	end repeat
	return ""
end argAccount

-- argv без элемента «account=…»: позиционные аргументы op-скрипта не меняются.
on argsWithoutAccount(argv)
	set out to {}
	repeat with a in argv
		set t to a as text
		if not (t starts with "account=") then set end of out to t
	end repeat
	return out
end argsWithoutAccount

-- Текст отказа «папка не найдена»: Python-мост по префиксу превращает его в folder_unresolved.
on folderNotFoundMsg(accountAddr, folderName)
	if accountAddr is "" then return "Outlook folder not found: " & folderName
	return "Outlook folder not found: " & folderName & " [account=" & accountAddr & "]"
end folderNotFoundMsg

-- Адрес ящика папки (`email address of account of f`; нет адреса - имя аккаунта), "" у
-- папок без аккаунта («On My Computer», PST-архивы): `account of f` там бросает ошибку.
on folderAccountAddr(f)
	set addr to ""
	tell application "Microsoft Outlook"
		try
			set acc to account of f
			try
				set addr to (email address of acc) as text
			end try
			if addr is "" or addr is "missing value" then
				try
					set addr to (name of acc) as text
				end try
			end if
		end try
	end tell
	if addr is "missing value" then set addr to ""
	return addr
end folderAccountAddr

-- Принадлежит ли папка аккаунту `wantLc` (адрес в нижнем регистре; совпадает email или имя).
on folderAccountMatches(f, wantLc)
	return (my lc(my folderAccountAddr(f)) is wantLc)
end folderAccountMatches

-- Рекурсивный сбор папок ВНУТРИ аккаунта: wantKind = "inbox" | "sent" (синонимы EN+RU) |
-- "name" (точное имя без регистра, `target` - в нижнем регистре). Глубина ограничена как в
-- searchFolders.
on gatherInAccount(folderList, wantLc, wantKind, target, depth)
	set cands to {}
	if depth > 8 then return cands
	tell application "Microsoft Outlook"
		repeat with f in folderList
			set nm to ""
			try
				set nm to (name of f) as text
			end try
			set hit to false
			if wantKind is "inbox" then
				set hit to my isInboxName(nm)
			else if wantKind is "sent" then
				set hit to my isSentFolderName(nm)
			else
				set hit to ((my lc(nm)) is target)
			end if
			if hit and my folderAccountMatches(f, wantLc) then set end of cands to (contents of f)
			try
				set subs to mail folders of f
				if (count subs) > 0 then set cands to cands & (my gatherInAccount(subs, wantLc, wantKind, target, depth + 1))
			end try
		end repeat
	end tell
	return cands
end gatherInAccount

-- Папка `folderName` внутри аккаунта `accountAddr`; `missing value`, если ее там нет.
-- Несколько папок-синонимов в одном ящике (напр. «Sent Items» и «Отправленные») -
-- берем самую наполненную (`count of messages` - O(1)); точное имя - первая найденная.
on resolveFolderIn(accountAddr, folderName)
	set wantLc to my lc(accountAddr)
	set wantKind to "name"
	if my isInboxName(folderName) then
		set wantKind to "inbox"
	else if my isSentFolderName(folderName) then
		set wantKind to "sent"
	end if
	tell application "Microsoft Outlook" to set roots to mail folders
	set cands to my gatherInAccount(roots, wantLc, wantKind, my lc(folderName), 0)
	if (count cands) is 0 then return missing value
	if (count cands) is 1 or wantKind is "name" then return item 1 of cands
	set best to missing value
	set bestN to -1
	tell application "Microsoft Outlook"
		repeat with f in cands
			set n to 0
			try
				set n to (count of messages of f)
			end try
			if n > bestN then
				set bestN to n
				set best to (contents of f)
			end if
		end repeat
	end tell
	return best
end resolveFolderIn

-- Единая точка входа op-скриптов: аккаунт задан - внутри аккаунта, нет - прежний resolveFolder.
on resolveFolderFor(accountAddr, folderName)
	if accountAddr is "" then return my resolveFolder(folderName)
	return my resolveFolderIn(accountAddr, folderName)
end resolveFolderFor

-- Pick THE active Sent folder among many. A mailbox has numerous Sent-named
-- folders across accounts: empty decoys (On-My-Computer "Sent Items"), an
-- archive with a huge total but no recent mail (even surfacing at top level with
-- its account prefix stripped), and the real account Sent. Choosing by TOTAL
-- count would wrongly pick the archive, so we score each candidate by RECENT
-- activity — `count of (messages whose time sent > cutoff)` — and take the max.
-- Only if nothing has recent sends do we fall back to the largest by total.
on bestSentFolder()
	set cutoff to (current date) - 90 * days
	set cands to my gatherSent(missing value, 0)

	set best to missing value
	set bestRecent to -1
	set fallback to missing value
	set fbTotal to -1
	tell application "Microsoft Outlook"
		repeat with f in cands
			set rc to 0
			try
				set rc to (count of (messages of f whose time sent > cutoff))
			end try
			if rc > bestRecent then
				set bestRecent to rc
				set best to (contents of f)
			end if
			if rc is 0 then
				set tc to 0
				try
					set tc to (count of messages of f)
				end try
				if tc > fbTotal then
					set fbTotal to tc
					set fallback to (contents of f)
				end if
			end if
		end repeat
	end tell
	if bestRecent > 0 then return best
	return fallback
end bestSentFolder

-- Recursively collect every Sent-named folder (exact synonyms) across accounts.
-- Returns a list of folder references (dupes are harmless — same folder scores
-- the same). `folderList` is `missing value` at the top to start from the root.
on gatherSent(folderList, depth)
	set cands to {}
	if depth > 8 then return cands
	tell application "Microsoft Outlook"
		if folderList is missing value then set folderList to mail folders
		repeat with f in folderList
			set nm to ""
			try
				set nm to (name of f) as text
			end try
			if my isSentFolderName(nm) then set end of cands to (contents of f)
			try
				set subs to mail folders of f
				if (count subs) > 0 then set cands to cands & (my gatherSent(subs, depth + 1))
			end try
		end repeat
	end tell
	return cands
end gatherSent

on searchFolders(folderList, wantSent, target, depth)
	if depth > 8 then return missing value
	tell application "Microsoft Outlook"
		repeat with f in folderList
			set nm to my lc(name of f)
			if wantSent then
				if my isSentFolderName(nm) then return (contents of f)
			else
				if nm is target then return (contents of f)
			end if
			try
				set subs to mail folders of f
				if (count subs) > 0 then
					set hit to my searchFolders(subs, wantSent, target, depth + 1)
					if hit is not missing value then return hit
				end if
			end try
		end repeat
	end tell
	return missing value
end searchFolders

-- Join a recipient list (each carries an `email address` record) as
-- "Name <addr>, …". App-aware, so wrapped in a tell; one odd recipient is
-- skipped rather than aborting the message.
on recipsToStr(recipList)
	set parts to {}
	tell application "Microsoft Outlook"
		repeat with r in recipList
			try
				set ea to email address of r
				set one to my formatOneAddr(name of ea, address of ea)
				if one is not "" then set end of parts to one
			end try
		end repeat
	end tell
	return my joinList(parts, ", ")
end recipsToStr

-- Attachment display names of a message → NSArray (empty on any failure).
on attachmentNamesNS(m)
	set names to {}
	tell application "Microsoft Outlook"
		try
			repeat with a in (attachments of m)
				try
					set nm to (name of a) as text
					if nm is not "" then set end of names to nm
				end try
			end repeat
		end try
	end tell
	return my nsArrayFromList(names)
end attachmentNamesNS

-- Format a single sender reference (an email-address record) → "Name <addr>".
-- App-aware; called only for survivors, so the per-ref read is bounded.
on formatSenderRef(sndRef)
	set out to ""
	tell application "Microsoft Outlook"
		try
			set out to my formatOneAddr(name of sndRef, address of sndRef)
		end try
	end tell
	return out
end formatSenderRef

-- Format a message's recipient references (one message's `to`/`cc` list, as
-- returned by the bulk get) → "Name <addr>, …". Per-recipient reads are bounded
-- because we only format survivors.
on formatRecipRefs(recipRefs)
	set parts to {}
	tell application "Microsoft Outlook"
		repeat with r in recipRefs
			try
				set ea to email address of r
				set one to my formatOneAddr(name of ea, address of ea)
				if one is not "" then set end of parts to one
			end try
		end repeat
	end tell
	return my joinList(parts, ", ")
end formatRecipRefs

-- A message's attachment references (from the bulk get) → NSArray of names.
on attNamesNSFromRefs(attRefs)
	set names to {}
	tell application "Microsoft Outlook"
		repeat with a in attRefs
			try
				set nm to (name of a) as text
				if nm is not "" then set end of names to nm
			end try
		end repeat
	end tell
	return my nsArrayFromList(names)
end attNamesNSFromRefs

-- Map one message reference to an NSDictionary in the bridge's neutral shape.
-- HEAVY reads (sender, recipients, body, attachments) happen here — callers
-- invoke it ONLY for the survivors (post date-filter, post limit), so bodies are
-- never pulled for the whole backlog. `theID`/`theSubj`/`theWhen` come from the
-- bulk-collected lists; `folderName` is the neutral folder label.
on messageToDict(m, theID, theSubj, theWhen, folderName)
	set fromStr to ""
	set toStr to ""
	set ccStr to ""
	set bodyText to ""
	set convStr to ""
	tell application "Microsoft Outlook"
		try
			set snd to sender of m
			set fromStr to my formatOneAddr(name of snd, address of snd)
		end try
		set toStr to my recipsToStr(to recipients of m)
		set ccStr to my recipsToStr(cc recipients of m)
		try
			set bodyText to (plain text content of m) as text
		end try
		if bodyText is "" then
			try
				set bodyText to (content of m) as text
			end try
		end if
		try
			set convStr to (conversation id of m) as text
		end try
	end tell
	set attArr to my attachmentNamesNS(m)

	set d to current application's NSMutableDictionary's dictionary()
	(d's setObject:(theID as text) forKey:"entryID")
	(d's setObject:(theSubj as text) forKey:"subject")
	(d's setObject:fromStr forKey:"from")
	(d's setObject:toStr forKey:"to")
	(d's setObject:ccStr forKey:"cc")
	(d's setObject:(my isoUTC(theWhen)) forKey:"date")
	(d's setObject:bodyText forKey:"body")
	(d's setObject:(folderName as text) forKey:"folder")
	(d's setObject:convStr forKey:"conversationId")
	(d's setObject:attArr forKey:"attachments")
	return d
end messageToDict
