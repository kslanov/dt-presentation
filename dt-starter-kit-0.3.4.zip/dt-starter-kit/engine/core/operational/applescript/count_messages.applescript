-- count_messages — read-only message count for a resolved folder.
-- argv: [folderName]
-- Output: JSON {"count": N} (or {"error": …}).
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.
--
-- `count of messages` is O(1) in Outlook (instant even on a 15k folder), so the
-- meta orchestrator uses it to decide between a single plain pass and index
-- paging without any expensive scan.

on run argv
	try
		with timeout of kDTTimeout seconds
			set theAccount to my argAccount(argv)
			set argv to my argsWithoutAccount(argv)
		set folderName to (item 1 of argv) as text
		if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."
		set theFolder to my resolveFolderFor(theAccount, folderName)
		if theFolder is missing value then
			my emitError(my folderNotFoundMsg(theAccount, folderName))
			return
		end if
		tell application "Microsoft Outlook" to set c to (count of messages of theFolder)
		set d to current application's NSMutableDictionary's dictionary()
		(d's setObject:c forKey:"count")
		my emitJSON(d)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run
