-- fetch_by_ids — HEAVY phase of the paginated ingest: full message objects for
-- an EXACT list of entryIDs (one batch of survivors). Each id is fetched by
-- `message id X of <folder>` — a DIRECT hash lookup (~0s, no scan), so we pull
-- only the batch's messages, never a whole date span (the date-range fetch
-- dragged in months of bodies on sparse resumes and stalled/errored).
-- argv: [folderName, id1, id2, … idN]
-- Output: JSON array of full message objects (or {"error": …}).
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.

on run argv
	try
		with timeout of kDTTimeout seconds
			set theAccount to my argAccount(argv)
			set argv to my argsWithoutAccount(argv)
			set folderName to (item 1 of argv) as text
			set wantSent to my isSentFolderName(folderName)

			if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."
			set theFolder to my resolveFolderFor(theAccount, folderName)
			if theFolder is missing value then
				my emitError(my folderNotFoundMsg(theAccount, folderName))
				return
			end if

			set outArr to current application's NSMutableArray's array()
			tell application "Microsoft Outlook"
				repeat with k from 2 to (count of argv)
					set idNum to 0
					try
						set idNum to (item k of argv) as integer
					end try
					if idNum > 0 then
						try
							set m to message id idNum of theFolder
							set theID to (id of m) as text
							set theSubj to ""
							try
								set theSubj to (subject of m) as text
							end try
							set theWhen to missing value
							if wantSent then
								try
									set theWhen to time sent of m
								end try
							end if
							if theWhen is missing value then
								try
									set theWhen to time received of m
								end try
							end if
							-- messageToDict reads sender/to/cc/body/attachments of m directly.
							(outArr's addObject:(my messageToDict(m, theID, theSubj, theWhen, folderName)))
						end try
					end if
				end repeat
			end tell
			my emitJSON(outArr)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run
