-- list_folder_meta — CHEAP phase of the paginated ingest: metadata for EVERY
-- message in a folder (no bodies), so Python can sort, filter noise/privacy, and
-- batch before pulling anything heavy.
-- argv: [folderName, sinceISO|"", startIndex|"", count|""]
-- Output: JSON object with PARALLEL ARRAYS {ids, subjects, epochs, convs}
--          (or {"error": …}). The bridge zips + converts epoch→ISO.
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.
--
-- Three modes (the bridge picks one):
--   * INDEX PAGE  — `startIndex`+`count` given → `messages start thru end`
--     (bounded per call, NO whose; the large-folder safety valve).
--   * SINCE       — `sinceISO` given → indexed date `whose` (small window).
--   * PLAIN       — neither → `messages` (fast full pass; no whose — an
--     unbounded `whose time > epoch` re-scans the whole folder per get).
-- Each field is one inline bulk `get`; results are parallel arrays. Sender is
-- deliberately NOT read here (its 2-level bulk get is slow AND errors -1728 on a
-- full folder) — noise-by-sender runs at fetch time where `from` is cheap.

on run argv
	try
		with timeout of kDTTimeout seconds
			set theAccount to my argAccount(argv)
			set argv to my argsWithoutAccount(argv)
		set folderName to (item 1 of argv) as text
		set sinceISO to ""
		if (count argv) ≥ 2 then set sinceISO to (item 2 of argv) as text
		set startIdx to 0
		set pageCount to 0
		if (count argv) ≥ 4 then
			try
				set startIdx to (item 3 of argv) as integer
				set pageCount to (item 4 of argv) as integer
			end try
		end if
		set wantSent to my isSentFolderName(folderName)

		if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."
		set theFolder to my resolveFolderFor(theAccount, folderName)
		if theFolder is missing value then
			my emitError(my folderNotFoundMsg(theAccount, folderName))
			return
		end if
		set hasSince to (sinceISO is not "")
		if hasSince then set sinceDate to my parseISO(sinceISO)
		set paging to (startIdx ≥ 1 and pageCount ≥ 1)

		set idList to {}
		set subjList to {}
		set dateList to {}
		set convList to {}
		tell application "Microsoft Outlook"
			tell theFolder
				if paging then
					-- INDEX PAGE: bounded `messages start thru end`, no whose. Clamp
					-- the end to the live count so the last page can't overrun.
					set total to (count of messages)
					set endIdx to startIdx + pageCount - 1
					if endIdx > total then set endIdx to total
					if startIdx ≤ total then
						set idList to id of (messages startIdx thru endIdx)
						set subjList to subject of (messages startIdx thru endIdx)
						if wantSent then
							set dateList to time sent of (messages startIdx thru endIdx)
						else
							set dateList to time received of (messages startIdx thru endIdx)
						end if
						try
							set convList to conversation id of (messages startIdx thru endIdx)
						end try
					end if
				else if hasSince and wantSent then
					set idList to id of (messages whose time sent > sinceDate)
					set subjList to subject of (messages whose time sent > sinceDate)
					set dateList to time sent of (messages whose time sent > sinceDate)
					try
						set convList to conversation id of (messages whose time sent > sinceDate)
					end try
				else if hasSince then
					set idList to id of (messages whose time received > sinceDate)
					set subjList to subject of (messages whose time received > sinceDate)
					set dateList to time received of (messages whose time received > sinceDate)
					try
						set convList to conversation id of (messages whose time received > sinceDate)
					end try
				else
					-- PLAIN full pass (NO whose): an unbounded `whose time > epoch`
					-- re-scans all 15.8k per get and blew the 180s timeout.
					set idList to id of messages
					set subjList to subject of messages
					if wantSent then
						set dateList to time sent of messages
					else
						set dateList to time received of messages
					end if
					try
						set convList to conversation id of messages
					end try
				end if
			end tell
		end tell

		set n to (count of idList)
		set outDict to current application's NSMutableDictionary's dictionary()
		if n is 0 then
			my emitJSON(outDict)
			return
		end if

		-- Emit PARALLEL ARRAYS, not per-message dicts: bridge each AS list to an
		-- NSArray in one call (no 15.8k-row build loop → no timeout). Dates → epoch
		-- seconds via KVC on the bridged NSDate array (one native pass). Python
		-- zips + converts epoch→ISO. `convList` may be short if its get failed.
		set nsDates to current application's NSArray's arrayWithArray:dateList
		(outDict's setObject:(current application's NSArray's arrayWithArray:idList) forKey:"ids")
		(outDict's setObject:(current application's NSArray's arrayWithArray:subjList) forKey:"subjects")
		(outDict's setObject:(nsDates's valueForKey:"timeIntervalSince1970") forKey:"epochs")
		(outDict's setObject:(current application's NSArray's arrayWithArray:convList) forKey:"convs")
		my emitJSON(outDict)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run
