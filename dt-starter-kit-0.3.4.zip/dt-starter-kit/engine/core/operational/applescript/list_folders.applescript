-- list_folders — read-only enumeration of EVERY mail folder with its account and counters
-- (MAIL-ACCOUNTS-1). Replaces the name-only JXA walk: the wizard, the doctor and the live
-- measurement need to know WHICH mailbox a folder belongs to.
-- argv: [] (none)
-- Output: JSON array of {name, path, account, depth, total, unread, newest}
--          (or {"error": …}). ``account`` = e-mail of the folder's account ("" for folders
--          without an account: «On My Computer», PST archives). ``newest`` = ISO date of the
--          newest message for Inbox/Sent-looking folders WITH an account and mail, found
--          through cheap indexed windows (7 / 30 / 365 days; "" when the newest is older
--          than a year, the folder is not an Inbox/Sent or has no account — a miss over a
--          43k archive is a full scan), never a full-folder scan.
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py. READ-ONLY.

-- ISO date of the newest message of `f` inside the first non-empty window, "" otherwise.
on newestIso(f, wantSent)
	repeat with w in {7, 30, 365}
		set cutoff to (current date) - ((w as integer) * days)
		set ds to {}
		tell application "Microsoft Outlook"
			try
				if wantSent then
					set ds to time sent of (messages of f whose time sent > cutoff)
				else
					set ds to time received of (messages of f whose time received > cutoff)
				end if
			end try
		end tell
		set n to count of ds
		if n > 0 then
			set ref0 to (current date)
			set bestKey to -1.0E+15
			set bestD to missing value
			repeat with i from 1 to n
				try
					set d to item i of ds
					set k to (d - ref0)
					if k > bestKey then
						set bestKey to k
						set bestD to d
					end if
				end try
			end repeat
			if bestD is not missing value then return my isoUTC(bestD)
		end if
	end repeat
	return ""
end newestIso

-- Outlook отдает верхний уровень `mail folders` вместе с корнями аккаунтов (имя `missing value`)
-- и их детьми - одна папка встречается дважды (`/Входящие` и `/missing value/Входящие`), счетчики
-- ящика удваиваются (замер 08.11: 23838 вместо 11919). Дедуп по `id` папки, безымянный корень
-- в путь не пишем.
on walkAll(folderList, prefix, depth, outArr, seen)
	if depth > 8 then return
	tell application "Microsoft Outlook"
		repeat with f in folderList
			set fid to ""
			try
				set fid to (id of f) as text
			end try
			-- уже перечисленная другим путем папка (тот же id) пропускается
			set dup to false
			if fid is not "" then set dup to ((seen's containsObject:fid) as boolean)
			if not dup then
				if fid is not "" then (seen's addObject:fid)
				my emitFolder(f, prefix, depth, outArr, seen)
			end if
		end repeat
	end tell
end walkAll

on emitFolder(f, prefix, depth, outArr, seen)
	tell application "Microsoft Outlook"
			set nm to ""
			try
				set nm to (name of f) as text
			end try
			if nm is "missing value" then set nm to ""
			set p to prefix
			if nm is not "" then set p to prefix & "/" & nm
			set totalN to 0
			try
				set totalN to (count of messages of f)
			end try
			set unreadN to 0
			try
				set unreadN to (unread count of f)
			end try
			set acctAddr to my folderAccountAddr(f)
			set newest to ""
			-- Только папки с аккаунтом: у архивов без аккаунта (43 тыс. писем) три окна `whose`
			-- без единого попадания - это полный скан, 8 минут на всем перечне (замер 04.11).
			if totalN > 0 and acctAddr is not "" then
				if my isInboxName(nm) then
					set newest to my newestIso(f, false)
				else if my looksSent(nm) then
					set newest to my newestIso(f, true)
				end if
			end if
			set d to current application's NSMutableDictionary's dictionary()
			(d's setObject:nm forKey:"name")
			(d's setObject:p forKey:"path")
			(d's setObject:acctAddr forKey:"account")
			(d's setObject:depth forKey:"depth")
			(d's setObject:totalN forKey:"total")
			(d's setObject:unreadN forKey:"unread")
			(d's setObject:newest forKey:"newest")
			(outArr's addObject:d)
			try
				set subs to mail folders of f
				if (count subs) > 0 then my walkAll(subs, p, depth + 1, outArr, seen)
			end try
	end tell
end emitFolder

on run argv
	try
		with timeout of kDTTimeout seconds
			if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."
			set outArr to current application's NSMutableArray's array()
			tell application "Microsoft Outlook" to set topFolders to mail folders
			set seen to current application's NSMutableSet's alloc()'s init()
			my walkAll(topFolders, "", 0, outArr, seen)
			my emitJSON(outArr)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run
