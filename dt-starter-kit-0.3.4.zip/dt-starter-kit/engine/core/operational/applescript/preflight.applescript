-- preflight — cheap, bounded reachability probe for Classic Outlook (JOB-1, R5).
-- argv: [] (none)
-- Output: JSON {"running": true, "scriptable": true, "folders": N,
--               "new_outlook_flag": "1"|"0"|"", "inbox_account": "…", "inbox_total": N}
--         on success, or {"error": …} when Outlook is stopped or does not answer.
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.
--
-- The bridge runs this under a SHORT timeout (preflight_timeout) BEFORE any heavy
-- read, so a stopped / New Outlook fails fast (seconds) instead of stalling a
-- multi-minute meta/read call — the R5 «4-minute timeout» failure. It never opens
-- a folder or reads a message: it only asks whether Outlook is scriptable at all.
--
-- MAIL-ACCOUNTS-1 п.4а: the NEW Outlook for Mac has no AppleScript support, yet the app
-- still answers `tell application "Microsoft Outlook"` — from the FROZEN legacy database
-- (`inbox` → empty «On My Computer», Sent → a snapshot at the switch moment). The
-- bridge cannot tell that from healthy emptiness by the answer alone, so the preflight
-- reads the mode flag `IsRunningNewOutlook` from the `defaults` of the plain AND the
-- container domain ("1" new, "0" classic, "" unreadable — sandbox/TCC may hide it).
-- It also reports where the `inbox` KEYWORD points (account + message count) as a diagnostic
-- only: it is NOT a refusal signal (a legit classic setup may have the keyword on an empty
-- «On My Computer/Inbox» while real mail lives in account folders).

-- "1" | "0" | "": the first readable `IsRunningNewOutlook` of the known domains.
on newOutlookFlag()
	set home to POSIX path of (path to home folder)
	set doms to {"com.microsoft.Outlook", home & "Library/Containers/com.microsoft.Outlook/Data/Library/Preferences/com.microsoft.Outlook"}
	repeat with dom in doms
		try
			set v to do shell script "/usr/bin/defaults read " & quoted form of (dom as text) & " IsRunningNewOutlook 2>/dev/null"
			set v to my lc(v)
			if v is "1" or v is "true" or v is "yes" then return "1"
			if v is "0" or v is "false" or v is "no" then return "0"
		end try
	end repeat
	return ""
end newOutlookFlag

on run argv
	try
		with timeout of kDTTimeout seconds
			if not my isOutlookRunning() then
				error "Microsoft Outlook is not running — open Classic Outlook and retry."
			end if
			-- Scriptability probe: Classic Outlook answers `mail folders` (the
			-- very terminology every read depends on via resolveFolder). `count` is
			-- O(1) on the top-level collection (cheap).
			set folderCount to 0
			tell application "Microsoft Outlook"
				set folderCount to (count of mail folders)
			end tell
			set inboxAcc to ""
			set inboxTotal to -1
			try
				tell application "Microsoft Outlook" to set inboxRef to inbox
				set inboxAcc to my folderAccountAddr(inboxRef)
				tell application "Microsoft Outlook" to set inboxTotal to (count of messages of inboxRef)
			end try
			set d to current application's NSMutableDictionary's dictionary()
			(d's setObject:true forKey:"running")
			(d's setObject:true forKey:"scriptable")
			(d's setObject:folderCount forKey:"folders")
			(d's setObject:(my newOutlookFlag()) forKey:"new_outlook_flag")
			(d's setObject:inboxAcc forKey:"inbox_account")
			(d's setObject:inboxTotal forKey:"inbox_total")
			my emitJSON(d)
		end timeout
	on error errMsg
		my emitError("Outlook preflight failed: " & errMsg & " — Outlook may be the non-scriptable New Outlook (switch to Classic) or is not responding.")
	end try
end run
