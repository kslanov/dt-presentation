-- probe_folder — read-only diagnostic for ONE resolved Outlook folder.
-- argv: [folderName]  (inbox/sent synonym, or an exact folder name)
-- Output: JSON {folder, total, by_time_sent, by_time_received, newest:{class,
--          time_sent, time_received}} (or {"error": …}).
-- Concatenated after _lib.applescript by core/operational/outlook_bridge.py.
--
-- Purpose: determine WHICH date field actually filters a folder. `resolveFolder`
-- reaches account-nested Sent folders that a top-level `mail folder "Sent"`
-- reference cannot ("Invalid index -1719"), so we reuse it here. Read-only.

on run argv
	try
		with timeout of kDTTimeout seconds
			set theAccount to my argAccount(argv)
			set argv to my argsWithoutAccount(argv)
		set folderName to (item 1 of argv) as text

		if not my isOutlookRunning() then error "Microsoft Outlook is not running — open Classic Outlook and retry."

		set theFolder to my resolveFolderFor(theAccount, folderName)
		if theFolder is missing value then
			my emitError(my folderNotFoundMsg(theAccount, folderName))
			return
		end if

		set cutoff to (current date) - 30 * days

		-- Counts: total, and each date field over the same 30-day window. Each is
		-- one Apple Event; `count` over an empty whose set is a safe 0.
		tell application "Microsoft Outlook"
			tell theFolder
				set totalN to (count of messages)
				set sentN to (count of (messages whose time sent > cutoff))
				set recvN to (count of (messages whose time received > cutoff))
			end tell
		end tell

		-- Newest message = argmax over max(time received, time sent). Uses two bulk
		-- gets over the whole folder (diagnostic one-off), then direct indexing.
		set newestClass to ""
		set newestSent to ""
		set newestRecv to ""
		if totalN > 0 then
			set recvAll to {}
			set sentAll to {}
			tell application "Microsoft Outlook"
				tell theFolder
					try
						set recvAll to time received of messages
					end try
					try
						set sentAll to time sent of messages
					end try
				end tell
			end tell

			set ref0 to (current date)
			set nR to (count recvAll)
			set nS to (count sentAll)
			set bestKey to -1.0E+15
			set bestIdx to 1
			repeat with i from 1 to totalN
				set k to -1.0E+15
				if i ≤ nR then
					try
						set k to ((item i of recvAll) - ref0)
					end try
				end if
				if i ≤ nS then
					try
						set ks to ((item i of sentAll) - ref0)
						if ks > k then set k to ks
					end try
				end if
				if k > bestKey then
					set bestKey to k
					set bestIdx to i
				end if
			end repeat

			tell application "Microsoft Outlook"
				tell theFolder
					set m to item bestIdx of messages
					try
						set newestClass to (class of m) as text
					end try
					try
						set newestSent to (time sent of m) as text
					end try
					try
						set newestRecv to (time received of m) as text
					end try
				end tell
			end tell
		end if

		set newestDict to current application's NSMutableDictionary's dictionary()
		(newestDict's setObject:newestClass forKey:"class")
		(newestDict's setObject:newestSent forKey:"time_sent")
		(newestDict's setObject:newestRecv forKey:"time_received")

		set outDict to current application's NSMutableDictionary's dictionary()
		(outDict's setObject:folderName forKey:"folder")
		(outDict's setObject:totalN forKey:"total")
		(outDict's setObject:sentN forKey:"by_time_sent")
		(outDict's setObject:recvN forKey:"by_time_received")
		(outDict's setObject:newestDict forKey:"newest")
		my emitJSON(outDict)
		end timeout
	on error errMsg
		my emitError(errMsg)
	end try
end run
