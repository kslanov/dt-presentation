"""MEET-1 — фид встреч из календаря Outlook (пульт, вкладка «Работа»).

Read-only: тянет предстоящие события календаря через тот же
:class:`~core.operational.outlook_bridge.OutlookBridge`, что и почтовый ingest
(JXA/AppleScript, без сети/LLM; ``core/`` ⊥ mcp/cli). Модуль только ШЕЙПИТ
события — сам текст (бриф/повестку) генерирует уже потребитель (артефакт через
askClaude/generate) поверх этого среза.

:func:`upcoming` возвращает окно ``[начало сегодняшнего дня; +days)``, отсекая
уже завершившиеся события (``end < now``), сортируя по началу. Для каждой встречи
выделяются ВНЕШНИЕ участники (домен не из :func:`mail_owner_domains`) и их домены
— по ним пульт одним кликом готовит бриф по клиенту/сделке из DT.

Graceful degradation — контракт моста: если Outlook не запущен / не читается,
:func:`upcoming` не падает, а возвращает ``{"available": False, "reason": …,
"meetings": []}`` (обёртка ловит :class:`OutlookUnavailableError`).

Privacy: это СОБСТВЕННЫЙ календарь пользователя — тема/место/участники/время идут
как есть; наружу (за пределы пульта) ничего не публикуется.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from core.adapters import AdapterUnavailable, StoreUnavailableError, load_json_store
from core.config import (
    default_vault_path,
    mail_owner_domains,
    meetings_cache_path,
    outlook_self_tokens,
    timetta_user_email,
)
from core.contract import CODE_OUTLOOK_NEW_MODE
from core.operational.outlook_bridge import (
    OutlookBridge,
    OutlookNewModeError,
    OutlookUnavailableError,
    clean_bridge_field,
)

logger = logging.getLogger(__name__)

__all__ = [
    "MAX_MEETINGS",
    "DEFAULT_DAYS",
    "STALE_AFTER_H",
    "upcoming",
    "refresh",
    "cached",
    "load_cache",
]

# Верхняя граница окна по умолчанию (переключатель пульта шлёт 1/2/3/7).
DEFAULT_DAYS = 7
# Разумный потолок карточек, чтобы недельное окно не раздувало ответ.
MAX_MEETINGS = 40
# PERF-3: кэш «протух», если не обновлялся дольше этого (часов). Как FRESH-1: при
# гентельной/ночной каденс суток+люфт держит дневной кэш свежим; кнопка «Обновить»
# закрывает интрадей-нужду.
STALE_AFTER_H = 26.0

_ADDR_RE = re.compile(r"<?([^<>@\s]+@[^<>@\s]+)>?")
# Системные/служебные адреса приглашений — не участники и не контрагенты.
_SYSTEM_LOCALPARTS = {
    "calendar", "noreply", "no-reply", "notifications", "notification",
    "donotreply", "do-not-reply", "mailer-daemon", "postmaster",
}


def _parse_iso(value: Any) -> datetime | None:
    """ISO (в т.ч. с ``Z``) → aware UTC datetime; иначе ``None``."""
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt.replace(tzinfo=UTC) if dt.tzinfo is None else dt


def _domain_of(addr: str) -> str:
    """Домен из адреса ``name@domain`` (lower); иначе ``""``."""
    m = _ADDR_RE.search(addr or "")
    if not m:
        return ""
    _, _, dom = m.group(1).partition("@")
    return dom.lower().strip()


def _is_system_addr(addr: str) -> bool:
    """Служебный адрес приглашения (calendar@…, noreply@… и т.п.)?"""
    m = _ADDR_RE.search(addr or "")
    if not m:
        return False
    local = m.group(1).partition("@")[0].lower().strip()
    return local in _SYSTEM_LOCALPARTS


def _split_attendee(raw: str) -> dict[str, str]:
    """``"Имя <addr>"`` / ``"addr"`` → ``{name, addr, domain}``."""
    raw = (raw or "").strip()
    m = _ADDR_RE.search(raw)
    addr = m.group(1) if m else ""
    name = raw
    if m:
        name = raw[: m.start()].strip().strip("<>").strip() or raw.replace(m.group(0), "").strip()
        if not name or "@" in name:
            name = ""
    return {"name": name, "addr": addr, "domain": _domain_of(addr)}


def _self_addrs() -> set[str]:
    """Свои адреса (владелец календаря) — из уже существующих ручек конфига.

    MEET-FIX-1: нужны, чтобы отличить «список участников есть» от «в списке только
    я» — второе про участников не говорит НИЧЕГО (встречи с одним собой не бывает),
    и показывать по нему «1 участн.» — врать числом. Новой ручки не заводим:
    ``DT_TIMETTA_USER_EMAIL`` + ``DT_OUTLOOK_SELF_TOKENS`` уже описывают владельца.
    """
    out: set[str] = set()
    try:
        email = timetta_user_email()
        if email:
            out.add(email.strip().lower())
        for token in outlook_self_tokens():
            text = str(token or "").strip().lower()
            if "@" in text:
                out.add(text)
    except Exception:  # noqa: BLE001 — best-effort: сбой конфига не роняет фид
        return out
    return out


def _sorted_by_start(meetings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Список встреч по времени начала (asc), стабильно и независимо от моста.

    MEET-FIX-1: мост отдаёт события в порядке своих двух проходов (сначала
    неповторяющиеся, потом развёрнутые серии) — то есть вразнобой по датам. Порядок
    — часть контракта выдачи, а не забота UI: сортируем и в ``upcoming`` (перед
    отсечкой :data:`MAX_MEETINGS`, иначе «ближайшие 40» были бы случайными 40), и в
    :func:`cached` (снапшот мог быть снят прошлой версией — чиним на чтении).
    Нераспознанное/пустое ``start`` уезжает в конец, порядок внутри группы сохраняется.
    """
    def key(item: dict[str, Any]) -> tuple[int, datetime]:
        dt = _parse_iso(item.get("start"))
        if dt is None:
            return (1, datetime.max.replace(tzinfo=UTC))
        return (0, dt)

    return sorted(meetings, key=key)


def _clean_snapshot(meetings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Погасить мусорные поля в СТАРОМ снапшоте (снятом до фикса парсера).

    Кэш живёт до следующего рефреша, а «missing value» в адресе переговорной К. видит
    сейчас. Правило чистки — общее с парсером моста (:func:`clean_bridge_field`), тут
    только применяется к уже снятому снапшоту; свежие снапшоты приходят чистыми.
    """
    selves = _self_addrs()
    out: list[dict[str, Any]] = []
    for m in meetings:
        if not isinstance(m, dict):
            continue
        patch: dict[str, Any] = {}
        if m.get("location") is not None and clean_bridge_field(m.get("location")) is None:
            patch["location"] = None
        if "attendees_known" not in m:
            # В снапшоте до фикса поля нет — считаем по тому же правилу, а не гасим
            # счётчик у встреч, где список участников как раз полный.
            patch["attendees_known"] = any(
                str((a or {}).get("addr", "")).lower() not in selves
                for a in (m.get("attendees") or [])
                if isinstance(a, dict)
            )
        out.append({**m, **patch} if patch else m)
    return out


def _upcoming_only(
    meetings: list[dict[str, Any]], now: datetime
) -> list[dict[str, Any]]:
    """Убрать УЖЕ ЗАВЕРШИВШИЕСЯ встречи (``end < now``); идущая сейчас остаётся.

    MEET-FIX-1, баг К.: в срезе «3 дня» висела встреча, закончившаяся утром. Причина
    — нижней границы окна не было НИГДЕ: :func:`upcoming` отсекает прошедшее в момент
    СНЯТИЯ снапшота, а снапшот живёт часами (кэш PERF-3), и к обеду в нём лежит
    сегодняшнее утро. Поэтому отсечка повторяется на ЧТЕНИИ (:func:`cached`) — там,
    где известно текущее ``now``; фронту остаётся только верхняя граница окна.

    Правило то же, что в :func:`upcoming` (одна семантика на оба конца): нет ``end``
    → держим 12 часов от начала (встречи «весь день» и события без длительности).
    """
    out: list[dict[str, Any]] = []
    for m in meetings:
        end_dt = _parse_iso(m.get("end"))
        start_dt = _parse_iso(m.get("start"))
        if end_dt is not None and end_dt < now:
            continue
        if end_dt is None and start_dt is not None and start_dt < now - timedelta(hours=12):
            continue
        out.append(m)
    return out


def _owner_domains() -> set[str]:
    try:
        return {d.lower() for d in mail_owner_domains() if d}
    except Exception:  # noqa: BLE001 — best-effort; must not break the caller
        return set()


def _domain_label(domain: str) -> str:
    """Second-level label of a domain (``adm.initech.ru`` → ``initech``)."""
    parts = [p for p in (domain or "").lower().split(".") if p]
    if len(parts) >= 2:
        return parts[-2]
    return parts[0] if parts else ""


# Кэш каталога клиент-хабов (id + slug + имя) — читается один раз за процесс из
# одной небольшой папки vault, БЕЗ обхода всего корпуса (перф).
_CLIENT_HUBS: list[dict[str, str]] | None = None


def _read_hub(path: Path) -> dict[str, Any]:
    """Мини-разбор хаба: ``id``, все ``aliases`` и заголовок (без YAML-либы)."""
    hid = ""
    title = ""
    aliases: list[str] = []
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return {}
    in_fm = False
    for line in text.splitlines():
        s = line.strip()
        if s == "---":
            if in_fm:
                break
            in_fm = True
            continue
        if in_fm:
            if s.startswith("id:"):
                hid = s[3:].strip().strip('"').strip("'")
            elif s.startswith("aliases:"):
                body = s[8:]
                quoted = re.findall(r"[\"']([^\"']+)[\"']", body)
                if quoted:
                    aliases = [a.strip() for a in quoted]
                else:
                    aliases = [a.strip() for a in body.strip().strip("[]").split(",") if a.strip()]
        elif s.startswith("# ") and not title:
            title = s[2:].strip()
    if not hid:
        hid = path.stem
    slug = hid[len("client-"):] if hid.startswith("client-") else hid
    return {
        "id": hid,
        "slug": slug.lower(),
        "name": title or (aliases[0] if aliases else slug),
        "aliases": [a for a in aliases if len(a) >= 4],
    }


def _client_hubs(vault_path: Path | None = None) -> list[dict[str, str]]:
    """Клиент-хабы из ``04-clients`` (кэш на процесс). Дёшево: одна папка, ~пара
    десятков файлов, без обхода всего vault."""
    global _CLIENT_HUBS
    if _CLIENT_HUBS is not None:
        return _CLIENT_HUBS
    hubs: list[dict[str, str]] = []
    try:
        base = (vault_path or default_vault_path()) / "04-clients"
        for p in sorted(base.glob("*.md")):
            h = _read_hub(p)
            if h.get("slug"):
                hubs.append(h)
    except Exception:  # noqa: BLE001 — best-effort; must not break the caller
        hubs = []
    _CLIENT_HUBS = hubs
    return hubs


def _resolve_clients(
    domains: list[str], subject: str, hubs: list[dict[str, Any]]
) -> list[dict[str, str]]:
    """Сопоставить встречу с клиент-хабами DT (best-effort): по label домена
    внешнего участника (== slug хаба) ИЛИ по имени клиента в теме (slug/alias).
    Партнёрские домены обычно не матчатся — тогда спасает совпадение по теме."""
    labels = {_domain_label(d) for d in domains if _domain_label(d)}
    subj = (subject or "").lower()
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    for h in hubs:
        if h["id"] in seen:
            continue
        hit = h["slug"] in labels
        if not hit and len(h["slug"]) >= 4 and h["slug"] in subj:
            hit = True
        if not hit:
            for a in h.get("aliases", []):
                if a.lower() in subj:
                    hit = True
                    break
        if hit:
            seen.add(h["id"])
            out.append({"id": h["id"], "name": h["name"]})
    return out


def upcoming(
    days: int = DEFAULT_DAYS,
    *,
    now: datetime | None = None,
    bridge: OutlookBridge | None = None,
    owner_domains: set[str] | None = None,
) -> dict[str, Any]:
    """Предстоящие встречи в окне ``[начало сегодня; +days)``.

    Читает календарь Outlook через ``bridge`` (по умолчанию — реальный мост),
    отбрасывает завершившиеся (``end < now``), сортирует по началу, помечает
    внешних участников и их домены. Всегда возвращает словарь; при недоступном
    Outlook — ``available=False`` с человекочитаемой причиной (не бросает).
    """
    now = now or datetime.now(UTC)
    try:
        days = int(days)
    except (TypeError, ValueError):
        days = DEFAULT_DAYS
    if days < 1:
        days = 1
    # preflight=True: a stopped / New Outlook fails fast (seconds), not a
    # multi-minute stall (JOB-1 R5). The OutlookUnavailableError it raises is the
    # same one the calendar read raises — already caught below → available=False.
    bridge = bridge or OutlookBridge(require_preflight=True)
    owners = owner_domains if owner_domains is not None else _owner_domains()
    self_addrs = _self_addrs()
    hubs = _client_hubs()

    start_date = now.date()
    end_date = start_date + timedelta(days=days)
    start_iso = start_date.isoformat()
    end_iso = end_date.isoformat()

    try:
        raw = bridge.read_calendar_events(start_iso, end_iso)
    except OutlookUnavailableError as exc:
        return {
            "available": False,
            "reason": str(exc),
            # MAIL-ACCOUNTS-1 п.4а: машинный код отказа (outlook_new_mode - новый Outlook без
            # AppleScript отдает календарь из кэша: данные нельзя выдавать за актуальные)
            "code": str(getattr(exc, "code", "") or "unavailable"),
            "now": now.isoformat().replace("+00:00", "Z"),
            "days": days,
            "meetings": [],
        }

    meetings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for ev in raw or []:
        if not isinstance(ev, dict):
            continue
        subject = (ev.get("subject") or "").strip() or "(без темы)"
        # Отменённые встречи не показываем (на случай, если проскочили мост).
        low = subject.lower()
        if low.startswith("canceled:") or low.startswith("отменено"):
            continue
        # Дедуп: одна и та же встреча может прийти дважды (два инвайта/серии).
        dedup_key = (subject, str(ev.get("start") or ""))
        if dedup_key in seen:
            continue
        seen.add(dedup_key)
        start_dt = _parse_iso(ev.get("start"))
        end_dt = _parse_iso(ev.get("end"))
        all_day = bool(ev.get("allDay"))
        # Уже завершившиеся события скрываем (для всё-дня — только если день прошёл).
        if end_dt is not None and end_dt < now:
            continue
        if end_dt is None and start_dt is not None and start_dt < now - timedelta(hours=12):
            continue

        attendees: list[dict[str, str]] = []
        ext_domains: list[str] = []
        selves = self_addrs
        others = 0
        for a in ev.get("attendees") or []:
            raw_att = str(a)
            if _is_system_addr(raw_att):
                continue
            parsed = _split_attendee(raw_att)
            if not (parsed["name"] or parsed["addr"]):
                continue
            attendees.append(parsed)
            if parsed["addr"].lower() not in selves:
                others += 1
            dom = parsed["domain"]
            if dom and dom not in owners and dom not in ext_domains:
                ext_domains.append(dom)

        meetings.append(
            {
                "entryID": str(ev.get("entryID") or ""),
                "subject": subject,
                "start": ev.get("start") or "",
                "end": ev.get("end") or "",
                # location=None означает «места нет» (а не «место называется missing
                # value»): нормализация — в парсере моста, здесь только не выдумываем "".
                "location": (str(ev.get("location")).strip() or None)
                if ev.get("location")
                else None,
                "all_day": all_day,
                # MEET-FIX-2: откуда встреча (папка календаря + аккаунт). В UI не
                # рендерится — это диагностика «почему это здесь» прямо в кэше, чтобы
                # следующий разбор «фантомов» не требовал osascript-раскопок.
                "calendar": ev.get("calendar") or None,
                "account": ev.get("account") or None,
                "attendees": attendees,
                # MEET-FIX-1: список участников содержателен, только если в нём есть
                # кто-то кроме меня. Мост на части встреч отдаёт ровно одну запись
                # (себя или единственный адрес) — по такому списку счётчик не
                # показываем, чтобы не врать числом (ФТ: «не врать, если данных нет»).
                "attendees_known": others > 0,
                "counterparty_domains": ext_domains,
                "external": bool(ext_domains),
                "clients": _resolve_clients(ext_domains, subject, hubs),
            }
        )
    # Сортировка ДО отсечки: MAX_MEETINGS должен оставлять БЛИЖАЙШИЕ события, а не
    # первые сорок в порядке моста.
    meetings = _sorted_by_start(meetings)[:MAX_MEETINGS]

    return {
        "available": True,
        "now": now.isoformat().replace("+00:00", "Z"),
        "days": days,
        "window_end": end_iso,
        "meetings": meetings,
    }


# --------------------------------------------------------------------------- #
# PERF-3 — кэш встреч: refresh (мост → снапшот), cached (мгновенно из снапшота) #
# UI/фид читают КЭШ, мост бьётся только по расписанию / по кнопке — не на       #
# рендере (тот же класс, что зеркало Timetta / offline work_feed).             #
# --------------------------------------------------------------------------- #
def _cache_file(cache_path: Path | None) -> Path:
    return Path(cache_path) if cache_path is not None else meetings_cache_path()


def load_cache(*, cache_path: Path | None = None) -> dict[str, Any] | None:
    """Прочитать снапшот кэша встреч; ``None`` — файла НЕТ (первый запуск, легитимно).

    Файл есть, но не прочитался / не словарь → :class:`~core.adapters.StoreUnavailableError`
    (ADAPTER-HONEST-1): раньше битый кэш выглядел как «кэша нет» и пульт показывал мягкое
    «обновите» вместо «кэш повреждён».
    """
    return load_json_store(_cache_file(cache_path), adapter="meetings_cache", expect=dict)


def _write_cache(snapshot: dict[str, Any], *, cache_path: Path | None = None) -> None:
    """Атомарно записать снапшот (temp→replace) — как зеркало Timetta."""
    path = _cache_file(cache_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def refresh(
    days: int = DEFAULT_DAYS,
    *,
    now: datetime | None = None,
    bridge: OutlookBridge | None = None,
    owner_domains: set[str] | None = None,
    cache_path: Path | None = None,
) -> dict[str, Any]:
    """Live-read моста (:func:`upcoming`) → снапшот кэша ``meetings_cache_path``.

    Успех → ``status="ok"`` со свежими ``data_as_of``/``meetings``. Мост недоступен
    (New/остановленный Outlook — preflight отдаёт быстрый ``unavailable``) →
    **прошлый кэш НЕ затирается**: сохраняем прежние ``data_as_of``/``meetings``,
    лишь помечаем ``status="unavailable"`` + ``reason`` + ``refreshed_at``. Так
    временный сбой моста не «обнуляет» ленту. Никогда не бросает.
    """
    now = now or datetime.now(UTC)
    refreshed_at = now.isoformat().replace("+00:00", "Z")
    result = upcoming(days, now=now, bridge=bridge, owner_domains=owner_domains)

    if result.get("available"):
        snapshot = {
            "status": "ok",
            "data_as_of": refreshed_at,
            "refreshed_at": refreshed_at,
            "window_days": result.get("days", days),
            "window_end": result.get("window_end"),
            "meetings": result.get("meetings", []),
        }
        _write_cache(snapshot, cache_path=cache_path)
        return {"ok": True, **snapshot}

    # Unavailable: keep the last good snapshot's data, annotate the failure.
    try:
        prev = load_cache(cache_path=cache_path) or {}
    except StoreUnavailableError as exc:
        # Прежний кэш битый — «последнего хорошего» нет; перезапишем статусом сбоя, но
        # скажем об этом в логе (не молча).
        logger.warning("[meetings] прежний кэш нечитаем (%s) — перезаписываю статусом сбоя", exc)
        prev = {}
    snapshot = {
        "status": "unavailable",
        "reason": result.get("reason", ""),
        "code": result.get("code", "unavailable"),
        "refreshed_at": refreshed_at,
        "data_as_of": prev.get("data_as_of"),
        "window_days": prev.get("window_days", days),
        "window_end": prev.get("window_end"),
        "meetings": prev.get("meetings", []),
    }
    _write_cache(snapshot, cache_path=cache_path)
    return {"ok": False, **snapshot}


def cached(
    days: int = DEFAULT_DAYS,
    *,
    now: datetime | None = None,
    stale_after_h: float = STALE_AFTER_H,
    cache_path: Path | None = None,
) -> dict[str, Any]:
    """Встречи из кэша **мгновенно, без обращения к мосту** (для рендера пульта).

    Возвращает ``meetings`` + ``data_as_of`` + ``stale`` (кэш старше порога) +
    ``status`` (``ok``/``unavailable``/``no_cache``). Кэша нет → ``no_cache`` с
    пустым списком (пульт покажет мягкое «нет данных, обновите», НЕ live-read).
    Окно (сегодня/+завтра/…) фильтруется на клиенте по ``start`` — здесь отдаём
    весь снятый снапшот (``window_days``).
    """
    now = now or datetime.now(UTC)
    try:
        days = max(1, int(days))
    except (TypeError, ValueError):
        days = DEFAULT_DAYS
    now_iso = now.isoformat().replace("+00:00", "Z")

    try:
        snap = load_cache(cache_path=cache_path)
    except StoreUnavailableError as exc:
        # Кэш есть, но нечитаем: это НЕ «нет кэша» — иной статус и конверт п.22.
        degraded: dict[str, Any] = {
            "available": True,
            "status": "store_unavailable",
            "meetings": [],
            "data_as_of": None,
            "stale": None,
            "window_days": None,
            "days": days,
            "now": now_iso,
        }
        return exc.add_to(degraded)
    if snap is None:
        return {
            "available": True,
            "status": "no_cache",
            "meetings": [],
            "data_as_of": None,
            "stale": None,
            "window_days": None,
            "days": days,
            "now": now_iso,
        }

    data_as_of = _parse_iso(snap.get("data_as_of"))
    stale: bool | None = None
    if data_as_of is not None:
        lag_h = max(0.0, (now - data_as_of).total_seconds()) / 3600
        stale = lag_h > stale_after_h

    result: dict[str, Any] = {
        "available": True,
        "status": snap.get("status", "ok"),
        "meetings": _upcoming_only(
            _clean_snapshot(_sorted_by_start(snap.get("meetings") or [])), now
        ),
        "data_as_of": snap.get("data_as_of"),
        "stale": stale,
        "reason": snap.get("reason"),
        "window_days": snap.get("window_days"),
        "days": days,
        "now": now_iso,
    }
    if result["status"] == "unavailable":
        # Последнее обновление моста не удалось: данные — прошлый снимок. Конверт п.22
        # (его считает телеметрия на границе MCP), а не только поле status.
        reason = str(snap.get("reason") or "мост календаря недоступен")
        if snap.get("code") == CODE_OUTLOOK_NEW_MODE:
            # Новый Outlook не отдает календарь по AppleScript: снимок несвеж ПО ПРИЧИНЕ, а не по
            # возрасту - пульт пишет «календарь не обновляется с …», не старые встречи актуальными.
            result["stale"] = True
            result["stale_reason"] = CODE_OUTLOOK_NEW_MODE
            result["code"] = CODE_OUTLOOK_NEW_MODE
            OutlookNewModeError(reason, adapter="outlook").add_to(result)
        else:
            AdapterUnavailable(reason, adapter="outlook").add_to(result)
    return result
