# ops — автозапуск операционного контура (launchd)

Контур Track B (читающее зеркало Timetta → захват TickTick → сверка → файлы/почта; запись в Timetta
выведена — RETIRE-WRITE-1, код в ветке `archive/timetta-write`) запускается
сам на ноуте по расписанию через launchd-задания; два из них зовут единый
оркестратор [`cli/dt_sync.py`](../cli/dt_sync.py). Разделение — по *стоимости*:
оборот входящих потоков лёгкий и идёт часто; поддержка знаний (линковка+индекс)
тяжёлая (грузит модель) и идёт ночью. Рядом — обслуживающие задания (снимок
встреч, недельный смоук).

<!-- ops-tables:begin -->
<!-- генерируется: scripts/ops_tables.py; гард tests/test_cli_inventory.py -->

### Режимы `dt_sync` (из `cli/dt_sync.MODES`)

| Режим | Шаги по порядку |
|---|---|
| `fast` | refresh → pull_capture → reconcile → file_ingest → mail_ingest |
| `index` | ocr → file_ingest_knowledge → link_auto → hub_scan → lint → reindex_inc → eval → doctor |
| `full` | refresh → pull_capture → reconcile → file_ingest → mail_ingest → ocr → file_ingest_knowledge → link_auto → hub_scan → lint → reindex_inc → eval → doctor |

### Задания launchd (из `ops/launchd/*.plist`)

| Задание | Расписание | Запуск |
|---|---|---|
| `com.dt.backup` | вс 11:00 | `cli/dt_backup.py` |
| `com.dt.meetings` | каждые 3 ч · при загрузке | `cli/dt_meetings.py` |
| `com.dt.run.watchdog` | каждые 10 мин · при загрузке | `cli/dt_run_watchdog.py` |
| `com.dt.server` | постоянно (KeepAlive) · при загрузке | `mcp-server/server.py --transport http --host 0.0.0.0 --port 8787` |
| `com.dt.smoke` | пн 07:30 | `cli/dt_smoke.py` |
| `com.dt.sync.fast` | каждые 30 мин · при загрузке | `cli/dt_sync.py fast` |
| `com.dt.sync.index` | 03:00 | `cli/dt_sync.py index` |

<!-- ops-tables:end -->

Что делают задания (таблицы расписания и шагов выше генерируются из кода, описание - здесь):

- `com.dt.sync.fast` — `refresh` → `pull_capture` → `reconcile` → `file_ingest` → `mail_ingest` (оборот входящих, без индекса; модель не грузится; шагов записи в Timetta нет). Точечно: `dt_sync.py fast --steps mail_ingest` (кнопка ↻ у строки «Свежести» на пульте)
- `com.dt.sync.index` — `file_ingest_knowledge` → `link_auto` → `hub_scan` → `lint` → `reindex_inc` → `eval` → `doctor` (знаниевые файлы + линковка + линт знаний + индекс; тяжёлый, грузит модель). EVAL-3: `eval` — ночной прогон золотого набора с записью точки в `.derived/eval/history.jsonl` (прогрев кэша frontmatter перед прогоном), `doctor` — снимок `.derived/doctor_last.json` (только warn/fail + счётчики) для индикатора здоровья в шапке пульта; оба шага всегда возвращают 0 — красное/сбой уходят WARNING в лог и цепочку index не роняют. Точечно: `dt_sync.py index --steps eval` / `--steps doctor`
- `com.dt.server` — **Демон движка (DAEMON-1)**: один процесс на порту 8787 = веб-пульт (`/`, `/api/*`) + MCP по http (`/mcp/lean\|pult\|full`) + `/health`. Заменил `com.dt.webpult`. См. раздел «Демон движка» ниже
- `com.dt.meetings` — `dt_meetings.py` — снимок встреч Outlook → `.derived/meetings/cache.json` (PERF-3; гентельно, ВНЕ fast — пульт рендерит из кэша мгновенно, не 31с live-read). Мост с preflight: закрытый Outlook → быстрый unavailable, прошлый кэш сохранён. On-demand — кнопка «Обновить» (`submit_job outlook_read meetings`)
- `com.dt.smoke` — `dt_smoke.py` — сценарный смоук на БОЕВОМ vault/конфиге/сторах (LIVE-SMOKE-1): ловит конфиг-зависимые поломки живой машины, которых не видят юнит-тесты с фикстурами. Read-only; итог + причина → `.derived/logs/smoke.log`, оттуда его читает doctor (прогон старше 8 дней или красный → warn). Вручную — `make smoke`. **Смоук и ветки:** `make smoke` на рабочей ветке гоняет сценарии и показывает метрики С-10, но точку в `eval/history.jsonl` НЕ пишет (пишется только с `main`, принудительно — `DT_EVAL_RECORD=1`): линейка истории — это код, влитый в main

**Приемка (SMOKE-DRIFT-1):** элемент, меняющий контракт инструмента или формат ответа (конверты, коды `warning`, поля выдачи), принимается с `make smoke` на боевой машине, а не только с pytest: смоук - потребитель этих контрактов, и без прогона он отстает молча (ARGS-STRICT-1 сделал С-3 красным именно так).

Отдельного планового `full` больше нет: частый `fast` (каждые 30 мин) + ночной
`index` покрывают всё круглосуточно. `full` (= `fast` + `index`) остаётся ручным
«сделать всё сейчас» — кнопкой в пульте или `dt_sync.py full` из терминала.

Полный авто (`--apply` на всех шагах) — выбор пользователя: записи в Timetta
восходят к его действиям (добавил задачу / поставил `approve`). Токены берутся
из `engine/.env`, **в логи не пишутся**; логи обезличены (только счётчики, без
названий клиентов/сумм). Один прогон ОДНОГО режима за раз — у `fast` свой lock
(`.derived/operational/dt-sync.lock`), у `index` свой (`dt-sync-index.lock`): ночной
index, растянутый до утра, больше не останавливает почту и Timetta (WAVE0-HYGIENE п.4).
`full` берёт оба lock'а.

## Демон движка `com.dt.server` (DAEMON-1)

Движок - **сервис, хост - клиент**: Kimi, Cursor и мост Claude Desktop подключаются к уже работающему
процессу, а не запускают свой `server.py`. Один эмбеддер/реранкер на машину (замер спайка: 6,4 ГБ против
12,1 ГБ у двух stdio-серверов и ~20 ГБ у восьми сегодняшних), обновление кода - `kickstart -k` без
перезапуска хостов.

| | |
|---|---|
| Запуск | `uv run --extra operational --extra server python mcp-server/server.py --transport http --host 0.0.0.0 --port 8787` (так в `ops/launchd/com.dt.server.plist`; `KeepAlive`, `NumberOfFiles 4096`) |
| Порт | 8787 (`DT_WEB_PORT` читают `pult_web_status` и доктор). Bind `0.0.0.0` - ради пульта с телефона по Tailscale/Wi-Fi |
| Что отдает | `GET /` и `/api/*` - пульт (токены read/write, cookie, профиль `pult`; реализация одна: `webpult/asgi.py`); `/mcp/lean`, `/mcp/pult`, `/mcp/full` - MCP (Streamable HTTP); `/health` |
| `/mcp` - только локально | loopback-peer, без прокси-заголовков (`X-Forwarded-*`, `Forwarded`, `Tailscale-*`: через Funnel/Serve `/mcp` закрыт), `Host` только `localhost`/`127.0.0.1`/`[::1]` (защита DNS-rebinding включена и при bind `0.0.0.0`). Остальным - 403 до проверки токена. **CONFIG-1:** при `DT_MODE=server` (и найденном адресе Tailscale) допустим еще и Tailscale-peer (100.64.0.0/10), `Host` - DNS-имя/IP машины в tailnet; прокси/funnel - 403 в обоих режимах (`docs/ops.md`, «Сервер»). |
| Токены | `Authorization: Bearer` из `.secrets/web_token` (read) / `web_token_rw` (write), те же, что у пульта; `dt web-token show\|rotate read\|rw`. **read** открывает `tools/list` и инструменты чтения, **`WRITE_TOOLS` (в т.ч. `output_begin`/`save_output`/`place_download` профиля lean) - только с write**: иначе ответ `{ok:false, code:"write_token_required"}` и строка аудита `denied`. Токены целиком нигде не пишутся: в журналах - режим, хвост 4 символа, peer и 8 символов id сессии |
| `/health` | без токена, только loopback и Tailscale-peer (100.64.0.0/10, fd7a:115c:a1e0::/48), без секретов: `{ok, version:{code, started, uptime_s}, pid, sessions:{total, by_host, by_profile}, profiles, pult, limits, note}` |
| Параллельность | каждый инструмент - в потоке (FastMCP 1.28 иначе гонит синхронный вызов в event loop и один `generate` морозит все сессии); `generate`/`retrieve` - семафор `DT_DAEMON_HEAVY_PARALLEL` (дефолт 2; лишний ждет слот, не отказывает); эмбеддер и реранкер - под lock'ами |
| Сессии | `stateless_http: false` (сессия хранит `clientInfo` хоста - от него `host` в мете выходов и телеметрии). Простой сессии до закрытия - `DT_DAEMON_SESSION_IDLE_H` (дефолт 24 ч; `0` - без таймаута). **Рестарт демона рвет все сессии** (старая сессия получает 404): прямой клиент переподключается сам, Claude Desktop - мост с `--reconnect` (HOSTS-ATTACH-1) |
| Логи | `.derived/logs/launchd.server.out.log` / `.err.log` (старт, предупреждения; access-лог uvicorn выключен - в строках пульта бывает `?t=`; токены в лог не попадают: под launchd на старте - только хвосты и команда `dt web-token show`) |

```sh
# Установка/обновление (идемпотентно; снимает старый com.dt.webpult, ставит com.dt.server):
bash ops/install_launchd.sh

# Проверка: жив ли демон, какой код, сессии (без токена, локально):
curl -s http://127.0.0.1:8787/health | python3 -m json.tool
uv run --extra server python mcp-server/server.py --selftest --transport http   # 3 профиля = реестр = stdio, /health, пульт

# Обновление кода = перезапуск демона (хосты по url продолжают работать; сессии переподключаются):
launchctl kickstart -k gui/$UID/com.dt.server
```

Доктор («Демон DT»): жив на :8787, версия кода демона = `HEAD` репо (иначе warn «демон отстает от кода» с этой
командой), uptime, сессии сейчас (`/health`) и за 24 ч по хостам (телеметрия `tool_call` с `sid`), footprint
процесса (`footprint -p`; нет утилиты - «н/д»). Хэш демона может отличаться от `HEAD`: если по путям кода (`core/daemon.py::CODE_PATHS`: `core`, `mcp-server`, `cli`, `webpult`, `pyproject.toml`, `uv.lock`) разницы нет (коммиты только по докам), строка ok «`HEAD` ушел вперед только по докам (N коммитов)»; warn - только при расхождении кода (git недоступен или хэш ему неизвестен - сравнение по хэшу, как раньше). Та же строка - в плитке «Сервисы» пульта (ключ `server`,
прежний `webpult` принимается как алиас в `pult_service_control` / `pult_web_restart`).

## Ручной запуск (работает без launchd)

```sh
cd /путь/к/engine
uv run --extra operational python cli/dt_sync.py fast    # оборот входящих
uv run --extra operational python cli/dt_sync.py index   # линковка + индекс
uv run --extra operational python cli/dt_sync.py full    # fast + index (всё)
```

Переживает отсутствие сети: шаг падает → пишется в лог, остальные продолжают,
процесс не крашится (код возврата `1`, если были ошибки).

## Установка: `dt install` / `dt uninstall` (DEV-3-KIT)

`dt install` - оркестратор НАД командами движка (`cli/dt_install.py`, `core/install/`): каждый шаг -
готовая функция/CLI + `check()` (только чтение, по фактам системы) + идемпотентный `run()`.

| шаг | что делает | зовет |
|---|---|---|
| `platform` | macOS ≥ 14, arm64/x86_64, свободно ≥ 12 ГБ (≥ 2 ГБ, если модели уже есть), `uv`, `git`, Python из `uv`; ничего не ставит - называет команду | `platform`, `uv python find` |
| `deps` | `uv sync --all-extras`; check - `uv sync --frozen --dry-run` | `uv sync` |
| `config` | `.env` из `ops/env.template`, `DT_VAULT_PATH` (если не дефолт), `DT_CONNECTORS` (дефолт `none`); мастер вопросов, ключей не просит | `dt config init/set` |
| `vault` | каркас из `vault-template/`, существующее не трогается | `build_vault(work)` |
| `owner` | `owner.yaml`/`about.md`/`rules.md` из ответов (`--name --email --company --domain --internal-domain`) | `init_profile` |
| `models` | `bge-m3` и `bge-reranker-v2-m3` в `DT_MODELS_PATH` с процентами; `--models-from <папка\|архив>` - офлайн | `snapshot_download`, `dt-models.tar` |
| `launchd` | задания по манифесту (ниже), загрузка, `launchctl list` | `ops/launchd/*.plist` |
| `host` | запись `digital-twin` в конфиг `--host claude\|cursor\|kimi\|cherry\|none` | `install_entry`, `dt plugin kimi` |
| `index` | первый `dt_sync index` без `eval`/`bridge`/`doctor` | `cli/dt_sync.py` |
| `doctor` | `dt doctor`, итог без FAIL | `cli/dt_doctor.py` |

Флаги: без аргументов - с первого незавершенного шага; `--check` - таблица «шаг - сделано/нет - почему» и
строка «в системе стоит …/ничего не стоит» (код 1, если не все сделано; ничего не пишет); `--dry-run`;
`--step <имя>` (выполнится и готовый - шаги идемпотентны); `--from <имя>`; `--yes` (без вопросов: флаги,
состояние, умолчания; нет имени/почты - отказ с названием флага); `--json`; `--relaunch` (шаг `host`: Claude
Desktop запущен - выйти, записать, запустить; **по умолчанию выключен**: установка может идти из самого Desktop,
и его закрытие оборвет разговор - без флага отказ `desktop_running` с подсказкой); `--ops-full`; цель
(`--root`, `--home`, `--engine-dir`, `--env-file`, `--vault`) - тесты и приемка гоняются на tmp. Ошибка шага -
код 1, причина, «что сделать» и команда повтора; `sudo` нигде нет.

**Состояние** - `<корень>/.derived/install/state.json`: на каждый шаг `status` (`done|failed|running|skipped`),
`at`, хвост `output`, `error`, `attempts`, `progress` (проценты скачивания); `answers` - ответы мастера (имя,
почты, компания, домены, хост, коннекторы; секретов нет). Это ПАМЯТЬ о прогонах, а не источник правды:
«сделано» решает `check()` по живой системе, поэтому машина, поставленная руками, показывает все шаги
сделанными. Повтор после обрыва продолжает с первого незавершенного шага.

**Модели.** `core/install/models.py`: недостающая модель качается `snapshot_download` с теми же
`allow_patterns`, что у рантайма (`DT_EMBED_ALLOW_DOWNLOAD` остается ручкой рантайма), проценты - в терминал и
`state.json`, до трех попыток подряд, повтор докачивает `*.incomplete`. Целостность: нужные файлы на месте,
веса ≥ 1 ГБ (`model.safetensors` либо старый `pytorch_model.bin`), нет `*.incomplete`, размеры совпадают с
`models/.dt-models.json` (манифест пишет установка; у ручной установки его нет - тогда по наличию и размеру).
Офлайн: `scripts/build_models_bundle.py --out dist/dt-models.tar` собирает из боевого кэша только нужные файлы с
sha256 каждого (`dt-models.json` внутри); `--models-from` распаковывает без сети (путь только внутри папки, ссылки
наружу - отказ), сверяет суммы и копирует недостающее. Доктор: строка «Модели» (обе на месте, размер, откуда).

**launchd по манифесту.** Состав - `core/surface/manifest.launchd_jobs()`: `server`, `sync.fast`, `sync.index`,
`backup` всегда; `meetings` - только при коннекторе `outlook` (вентиль оси «коннектор», по `.env` ЦЕЛИ);
`smoke`, `run.watchdog` - `--ops-full`. Плисты - из `ops/launchd/*.plist` с подстановкой путей, логи - в
`.derived/logs`; перезагружается только изменившееся или не загруженное (повтор не рестартует демон);
устаревшие `com.dt.sync.full`/`com.dt.webpult` снимаются, как раньше. Демон слушает `127.0.0.1`; `0.0.0.0` (пульт с
телефона по Wi-Fi/Tailscale) - только с `--ops-full`, то есть у владельца, как было. **`ops/install_launchd.sh` -
тонкая обертка над `dt install --step launchd --ops-full`** (полный состав владельца). Доктор «Плановые
джобы» не ждет задание выключенного коннектора и ярус владельца, которого не ставили.

**`dt uninstall`** (`core/install/uninstall.py`): выгружает и удаляет задания ЭТОЙ установки (плист с
`WorkingDirectory` = наш engine; чужой checkout не трогается), снимает запись `digital-twin` из конфигов Claude
Desktop/Cursor (`remove_member`: один член, остальные байты целы, бэкап; Desktop запущен - отказ либо
`--relaunch`; чужая запись `digital-twin` не трогается), снимает экземпляры (`dt instance remove`). Остаются:
vault, `.env`, модели, секреты, `.derived`. `--purge` - еще `.derived`, `.secrets` и кэш моделей, с
подтверждением (`--yes` либо слово «удалить»); **vault не удаляется никогда**: цель, пересекающаяся с vault,
отклоняется. `--dry-run` печатает план. Живая сверка: `uv run python cli/dt.py install --check` на боевой
установке показывает все шаги «сделано».

**Стартовый кит.** `scripts/build_starter_kit.py --vault <боевой vault> [--check]` собирает
`dist/dt-starter-kit-<версия>.zip` (в git не идет): `engine/` без `.env`/секретов/`.derived`/моделей/`tests`/внутренних
docs, `installer/` (`INSTALL.md`, `brain/`, `state/`), `skills/` (формат Cherry, без `dt-owner`), `README.md`
«3 шага», `VERSION`, `CHANGELOG.md`, `KIT-MANIFEST.json`. Гард утечек (запрещенные имена, приватные термины
`owner.yaml`, маски токенов, абсолютные пути) - код 1 и zip не пишется; архив детерминирован, `--check`
пересобирает и сверяет. `scripts/verify_starter_kit.py <zip> --vault …`: целостность по манифесту, состав, гард и
`dt install --check` из распакованного кита.

## Установка плистов вручную (справка: что делает `dt install --step launchd`)

Плисты в [`launchd/`](launchd/) — **шаблоны** с плейсхолдерами
`__ENGINE_DIR__` и `__UV_BIN_DIR__` (пути per-machine, поэтому не зашиты).

1. Определи пути:

   ```sh
   ENGINE_DIR="/абсолютный/путь/к/engine"     # например: $(pwd) из каталога engine
   UV_BIN_DIR="$(dirname "$(which uv)")"        # например: /Users/you/.local/bin
   ```

2. Создай каталог логов (launchd сам не создаёт родительские папки для
   `StandardOutPath`):

   ```sh
   mkdir -p "$ENGINE_DIR/../.derived/logs"
   ```

3. Подставь пути и положи плисты в `~/Library/LaunchAgents/`:

   ```sh
   for f in com.dt.sync.fast com.dt.sync.index com.dt.meetings com.dt.smoke; do
     sed -e "s#__ENGINE_DIR__#$ENGINE_DIR#g" \
         -e "s#__UV_BIN_DIR__#$UV_BIN_DIR#g" \
         "$ENGINE_DIR/ops/launchd/$f.plist" > "$HOME/Library/LaunchAgents/$f.plist"
   done
   ```

4. Загрузи (`-w` — включить и запомнить между перезагрузками):

   ```sh
   launchctl load -w ~/Library/LaunchAgents/com.dt.sync.fast.plist
   launchctl load -w ~/Library/LaunchAgents/com.dt.sync.index.plist
   ```

Лимит дескрипторов: все плисты несут `SoftResourceLimits/NumberOfFiles 4096`. У заданий launchd
по умолчанию 256, а LanceDB держит по файлу на фрагмент/версию/индекс - ночные `eval`/`doctor`
29.10.2026 упали «Too many open files» при 16К версий после rechunk. При правке плиста
перезагружать `launchctl bootout gui/$UID/<label>; launchctl bootstrap gui/$UID ~/Library/
LaunchAgents/<label>.plist`; проверка: `launchctl print gui/$UID/<label> | grep maxfiles`.

## Проверка / управление

```sh
# Видны ли задания (PID, последний код возврата, label):
launchctl list | grep dt

# Разовый прогон прямо сейчас (не дожидаясь расписания):
launchctl start com.dt.sync.fast
launchctl start com.dt.sync.index

# Снять (на время правок) и снова загрузить:
launchctl unload ~/Library/LaunchAgents/com.dt.sync.fast.plist
launchctl load  -w ~/Library/LaunchAgents/com.dt.sync.fast.plist
```

После правки плиста: `unload` → положить новый → `load -w`.

## Где логи

Все под `.derived/logs/` (gitignored, per-machine):

- `dt-sync.log` — основной лог оркестратора (таймстемп, режим, по шагам:
  обезличенные счётчики + ошибки), ротация по размеру (~1 МБ, 5 бэкапов).
- `launchd.fast.out.log` / `launchd.fast.err.log` — stdout/stderr задания fast.
- `launchd.index.out.log` / `launchd.index.err.log` — то же для index.
- `launchd.server.out.log` / `launchd.server.err.log` — демон движка `com.dt.server` (DAEMON-1).
- `smoke.log` — прогоны сценарного смоука: блок на прогон (сценарий: ok/fail +
  деталь или причина) и машинный итог `RESULT …` последней строкой — его читает
  doctor-гард «Смоук-прогон». Плюс `launchd.smoke.out.log`/`.err.log`.
  Сессия смоука идёт с боевым `DT_DERIVED_ROOT` (читает всё как агент); в tmp уведены только
  пишущие сторы (журнал метрик, маяки, журнал запросов/кандидаты eval, jobs/chunk, dt.db, кэш
  источников, логи, кэш frontmatter) — перечень и причины в `tests/_smoke_env.py`. Боевыми пишутся
  штатно только история eval (с `main`), снимок доктора, `smoke.log`, маяки.

```sh
tail -f "$ENGINE_DIR/../.derived/logs/dt-sync.log"
```

## Переменные путей: один корень `DT_DERIVED_ROOT` (TEST-SANDBOX-1)

Все производные данные (индекс, манифесты, `dt.db`, журналы, маяки, снимок доктора, история eval,
логи, локи) строятся от **одного корня**: `core.config.derived_root()`.

- **Без переменных** — `<workspace>/.derived` (и `<workspace>/.backups` для архивов), как всегда.
  launchd-плисты и `.env` ничего из этого не задают и менять их не нужно.
- **`DT_DERIVED_ROOT=<каталог>`** — уводит ВЕСЬ производный стор в другое место одной
  переменной (песочница для тестов/экспериментов). Переменная наследуется подпроцессами —
  в этом её смысл: `dt_sync`, поднятый из теста, пишет в песочницу, а не в боевой `.derived`.
- **Поштучные `DT_*_PATH` / `DT_*_DIR`** остаются переопределениями ПОВЕРХ корня (обратная
  совместимость): `DT_LANCEDB_PATH`, `DT_INDEX_MANIFEST_PATH`, `DT_INDEX_LOCK_PATH`,
  `DT_INDEX_REPORT_PATH`, `DT_HUB_CANDIDATES_PATH`, `DT_LINK_SCAN_PATH`, `DT_DB_PATH`,
  `DT_FACTS_DB_PATH`, `DT_JOBS_DB_PATH`, `DT_JOBS_DIR`, `DT_CHUNK_SESSIONS_DIR`,
  `DT_TIMETTA_MIRROR_PATH`, `DT_MEETINGS_CACHE_PATH`, `DT_TICKTICK_STATE_PATH`,
  `DT_OPERATIONAL_PATH`, `DT_LOGS_PATH`, `DT_LINK_PROPOSALS_PATH`, `DT_REATTR_PROPOSALS_PATH`,
  `DT_LINK_APPLIED_PATH`, `DT_LEGACY_EXTRACTED_PATH`, `DT_LEGACY_INGEST_MANIFEST_PATH`,
  `DT_CURRENT_INGEST_MANIFEST_PATH`, `DT_LEGACY_DRYRUN_REPORT_PATH`,
  `DT_FILE_INGEST_MANIFEST_PATH`, `DT_SOURCES_CACHE_PATH`, `DT_OUTLOOK_INGEST_MANIFEST_PATH`,
  `DT_EVENTS_PATH`, `DT_EVAL_HISTORY_PATH`, `DT_BACKUPS_PATH`. Задавать их без нужды не надо:
  в песочнице их нет, а новая ручка — осознанное решение в одном месте (`core/config/`).
- Реестр всех путь-функций — `core.config.PATH_PROVIDERS` (имя → `derived` / `vault` / `engine`);
  проверка: `DT_DERIVED_ROOT=/tmp/x uv run python -c "import core.config as c; [print(n, getattr(c, n)()) for n in c.PATH_PROVIDERS]"`.
- Тесты изолируются **только** через `DT_DERIVED_ROOT` (autouse-фикстура conftest), а за сессию
  делается снимок боевого `.derived` (`tests/_derived_allowlist.py`): запись вне реестра штатных
  писателей валит сессию. Выключатель для отладки: `DT_SANDBOX_SNAPSHOT=0`.

## Вход данных: журнал отказов и итоги прогонов (INGRESS-1)

Все входы (файлы, почта, захваты, легаси) пишут общий контур в `.derived/ingress/` (производные; корень -
`DT_DERIVED_ROOT`):

- `refusals.jsonl` - что адаптер отбросил и почему: одна JSON-строка `{ts, adapter, reason, hint?, source_id?,
  run_id?}`; хранится 30 дней (чистка на старте прогона), повтор той же единицы не пишется заново 3 суток.
  Приватное (`личное`, `_nda`) в журнал не попадает вообще - только счетчик в итоге прогона; исключение -
  `privacy_probe` почты: класс правила + id письма + папка·дата (MAIL-PRIVACY-2), без темы и фамилии. Читать:
  `tail -n 20 .derived/ingress/refusals.jsonl`, `grep '"reason": "noise_sender"' …`, в пульте -
  «Хранилище» → «Отброшено на входе»; сводка за 7 дн - `pult_ingest_sources` (`refused_7d`/`refused_last`).
- `last_runs.json` - итог последнего (и последнего боевого) прогона каждого адаптера в общих словах
  (`IngressStats`); от него и от `dt-sync.log` строится строка доктора «Вход: источники». Поле `extra` -
  адаптерные поля сверх общего словаря (у остальных адаптеров `{}`): у почты (MAIL-GAP-1)
  `{since_effective: {inbox: "2026-10-16", sent: …}, skipped_since: N, skipped_since_by_folder: {…}}` - граница
  выгрузки по папкам и сколько писем отрезано ею (единицы - СООБЩЕНИЯ; не путать с `resumed` - уже в манифесте).

Новый вход = дескриптор в `core/ingress/registry.py` (шаги `dt_sync`, свежесть, JOB-1 и доктор подхватят его сами).

## Фильтр почты: правила в данных, explain, ретро-проход (MAIL-FILTER-1)

Что считается шумом, решает `vault/_system/mail-filter.yaml` (правится текстом в Obsidian; нет файла - работает
запасной набор из `core/legacy/mail_filter.py`, пустой/битый - тот же набор + предупреждение `store_unavailable` в логе).
Типы правил: `allow` (адрес/домен, бьет всё; только Входящие), `senders` (адрес ЦЕЛИКОМ с glob, `@домен` целиком - не
подстрока), `subject_prefix` (авто-ответы, NDR, ответы на встречи; обе папки), `subject_regex` (якорный),
`senders_weak` + `subject_word` (ПАРА: общий токен адреса И целое слово темы; `слов*` - начало слова). Порядок:
allow → senders → subject_prefix → subject_regex → пара. Sent шумом не режется - только авто-префиксы. Env
`DT_MAIL_NOISE_SENDERS|SUBJECTS|MEETING` только дополняют набор (слабые токены / слова темы / префиксы встреч).

```bash
uv run python cli/dt.py mail-filter explain --from b2b_invoice@acme.kz --subject "Счет за октябрь"
uv run python cli/dt.py mail-filter lint
```

`explain` печатает `noise_sender (rule: senders/b2b_invoice@acme.kz)` или `pass` (без сети, тем же `decide`, что
использует инжест); `lint` - yaml валиден, правила не пустые, `allow` не пересекается с `senders` (код выхода 1 при
ошибках). Имя сработавшего правила (`rule`) лежит в строке журнала отказов и в карточке «Отброшено на входе».
Снятое фильтром сообщение запоминается в `.derived/mail_refused.json`: инкрементальный инжест его не возвращает;
чтобы пересмотреть решение после правки yaml - `dt_mail_ingest --scope full` (решает текущий yaml).

**Ретро-проход** по уже накопленным тредам (по сайдкарам `.derived/mail_threads`, Outlook не нужен). Порядок -
как для всякой правки корпуса (§9 п.11г): **dry-run → канарейка → apply → reindex → полный apply → reindex**:

```bash
uv run python cli/dt_mail_ingest.py --refilter --report /tmp/refilter.json      # dry-run: отчет «правило → тредов/сообщений»
uv run python cli/dt_mail_ingest.py --refilter --apply --limit 50               # канарейка: первые 50 затронутых тредов
uv run python cli/dt_index.py                                                   # reindex_inc снимает исчезнувшие заметки
uv run python cli/dt_mail_ingest.py --refilter --apply                          # остальное
uv run python cli/dt_index.py
```

Тред, где не осталось ни одного сообщения, снимается целиком (заметка + сайдкар + строка индекса почты); частично
очищенный перерисовывается с ПРЕЖНИМ `id` заметки. `msg_id` снятых уходят в журнал отказов и в память «отказано»,
события `ingest` получают статус `refiltered`. Сам проход индекс поиска не трогает. Ограничение: у старых сообщений
в сайдкаре нет собственной темы (~90% корпуса), поэтому темовые правила применяются к ним только в треде из одного
письма, в многописьменном - правила по отправителю (в отчете: `subject_unknown`).

Приватность писем (`_privacy_probe`): A1 для `личн`/`вилк` - только при зарплатном контексте в теме
(`зарплат|оклад|штатн|премии`), A2 («фамилия + контекст») не применяется к Sent, а контекст почты - `гпх|оклад|зарплат|штат|кадр`
БЕЗ голого «договор» (MAIL-PRIVACY-2, `docs/tz/mail-privacy-2.md`; добавить слова - `DT_MAIL_A2_CONTEXT`, JSON-массив).
Владелец вычитается из пробы токенами личности: профиль владельца (`vault/_system/profile/owner.yaml`: `name`,
`name_variants`, `emails`) плюс `DT_OUTLOOK_SELF_TOKENS` (фамилия одним словом, email; добавка, `legacy`): личности нет нигде или
битый JSON без профиля - его фамилия режет его же письма; `dt config check` и доктор «Конфиг» предупреждают.
Фамилии, чьи личные документы не индексируем, - `privacy.people` профиля плюс `DT_LEGACY_PRIVACY_NAMES`; дефолта в коде нет
(пустой список без профиля - предупреждение `dt config check`).
Где смотреть отказы приватности: `grep '"reason": "privacy_probe"' .derived/ingress/refusals.jsonl` - строка
`{ts, adapter: mail, reason, rule: privacy-name|privacy-term|privacy-contract, hint: "inbox · 2026-10-12", source_id}`
(класс правила, без темы/участников/фамилии); сводка за 7 дн - доктор «Вход: источники» («снято по приватности за 7 дн: N»),
`pult_ingest_sources` (`refused_7d.privacy_probe`), пульт «Хранилище» → «Отброшено на входе». Темы и правила -
только `dt_mail_ingest --dry-run --explain-privacy` в КОНСОЛЬ: правило · дату · тему[:60] каждого отказа и счетчики
до/после (читает тела писем, ничего не пишет).

### Курсор почты и дыра (MAIL-GAP-1, `docs/tz/mail-gap-1.md`)

`dt_mail_ingest` берет границу `since` папки как дату новейшего письма в манифесте МИНУС `DT_MAIL_CURSOR_OVERLAP_DAYS`
(14; `0` - без перекрытия), не раньше окна `DT_OUTLOOK_PULL_WINDOW`: письма, пришедшие в Outlook «задним числом», подбираются
следующим прогоном (перекрытые уже в манифесте - `resumed`, тела не читаются). Лог и `--dry-run` печатают границу
(«inbox: since 2026-10-16 (курсор 2026-10-30 − 14 дн), отрезано границей N»), итог CLI - `skipped(since)=N`.
Смоук **С-13 «дыра курсора»** (weekly `com.dt.smoke`): сухой проход `--since сегодня−90 дн`; писем вне манифеста больше
`DT_MAIL_GAP_MAX` (5) - красный с числом и датами; Outlook не отвечает - тоже красный (тишина означала бы «дыры нет»).
Результат последнего смоука - в доктор «Вход: источники» («дыра курсора за 90 дн: N» / «не замерялась»). Письма, снятые
приватностью, в манифест не попадают и остаются «добавляемыми» в сухом проходе - это фон замера, поэтому порог не 0.
Письма новее новейшего письма папки в манифесте (пришли после последнего `sync.fast`) - не дыра, а очередь обычной синхронизации: замер вычитает их из числа и дописывает «· новее курсора N (ждут синхронизации)»; формат строки обратно совместим (`parse_detail`, доктор читают прежние два числа).
Ручной бэкфилл дыры (постановщик, канарейкой): `dt_mail_ingest --since 2026-07-01 --dry-run` → `--since 2026-07-01` →
`dt_index` → `dt_eval` → остаток `--since 2026-01-01` → индекс → eval → доктор.

### Почта по аккаунтам (MAIL-ACCOUNTS-1, `docs/tz/mail-accounts-1.md`)

**Папка = ящик + имя.** `DT_OUTLOOK_FOLDERS` - JSON-массив `{bucket, name, account}`; `account` - адрес ящика, имя
(`inbox`/`входящие`, `sent`/`sent items`/`отправленные` или точное) ищется ВНУТРИ этого аккаунта
(`_lib.applescript::resolveFolderIn`, argv `account=<адрес>` последним элементом). Запись без `account` читается по
ключевому слову Outlook (`inbox` - одно умолчание, какое - решает Outlook; Sent - самая активная папка за 90 дн): так
02.11 чтение молча ушло на пустую «On My Computer/Inbox». Доктор помечает такую запись «папка без аккаунта»;
`dt config check` - ошибка, если `account` не адрес (запись снимается, к ключевому слову не откатывается).
Ящики и папки живого Outlook: `uv run python cli/dt_mail_ingest.py --list-folders` (только чтение, ~30 с; пишет
снимок `.derived/mail_accounts.json`; без него доктор не скажет «ящик не читается»).

```
[{"bucket":"inbox","name":"Входящие","account":"owner@corp.example"},
 {"bucket":"sent","name":"Отправленные","account":"owner@corp.example"},
 {"bucket":"inbox","name":"Inbox","account":"owner@mail.example.org"},
 {"bucket":"sent","name":"Sent Items","account":"owner@mail.example.org"}]
```

**Ключи и курсор.** Тред ящика - `conv:<адрес>:<id>` (один `conversationId` в двух ящиках - два треда); запись без
аккаунта - прежний `conv:<id>`, одиночки `msg:<entryID>` без изменений. Курсор и `bucket_dates` - по паре ящик+папка
(`inbox[адрес]`); лог: `inbox[owner@mail.example.org]: since … отрезано границей N`. Адрес каждого читаемого ящика -
«свой» (`is_me`, проба приватности, контрагенты).

**Миграция старого манифеста** (один раз, постановщик, канарейкой): `DT_OUTLOOK_LEGACY_ACCOUNT=<ящик, чья почта в
манифесте>` - с ним спецификация этого ящика продолжает старые треды и курсор БЕЗ миграции; затем
`dt_mail_ingest --migrate-accounts` (dry-run) → `--apply` (под `dt-sync.lock`): копия `mail_backup_pre_accounts_<ts>/`
(манифест + хардлинки сайдкаров), ключи `conv:<id>` → `conv:<адрес>:<id>`, сообщения с `account`, `anchor_key` держит
исходный ключ - `id`/путь заметки и `correspondence/conv:<id>` не меняются. Повтор безопасен. Заметки vault миграция не
трогает: `account` во frontmatter появится при следующем обновлении треда.

**Деградация с кодом (принцип 22).** Папка не нашлась - `folder_unresolved`; папка вернула 0 писем при непустой истории
по этой паре ящик+папка - `folder_empty_suspicious` (не «0 новых»): остальные ящики читаются дальше, `dt_mail_ingest`
выходит с кодом **5**, шаг `mail_ingest` в `dt_sync` - FAILED. Новый Outlook для Mac (`IsRunningNewOutlook`) не
поддерживает AppleScript, но приложение отвечает из замороженной legacy-базы: preflight отказывает `outlook_new_mode`
(код выхода 3; доктор «Outlook-мост» - warn «верни legacy: Outlook → Help → Revert to Legacy Outlook»; кэш встреч
помечается несвежим по причине - `stale_reason`, `data_as_of` прежний; `dt_meetings` выходит с 3; смоук С-13 красный
с кодом). Признак читается из `defaults` обычного и контейнерного домена; если ключ недоступен (sandbox/TCC), «новый
режим» распознает только пустое чтение по `folder_empty_suspicious`.

**Доктор «Почта: ящики и папки»:** по строке на спецификацию - `аккаунт · папка → путь · всего N · новейшее дата · в
манифесте M тредов` (итог последнего прогона и последний `--list-folders`; живой Outlook доктор не дергает), warn -
пустая папка при истории, папка/аккаунт не найдены, запись без аккаунта, кривой `account`, ящик Outlook вне конфига
(«ящик X не читается»), старые ключи без `DT_OUTLOOK_LEGACY_ACCOUNT`. Смоук С-13 идет по всем спецификациям.

**Бэкфилл после слияния** (постановщик, канарейкой): `dt_mail_ingest --account owner@mail.example.org --since 2026-08-01
--dry-run` → `--limit 50` (самые свежие кандидаты на папку) → полный; `--account owner@corp.example --since
2026-11-01` (дыра дня); `dt_index`; С-13.

## Алиасы хабов: очередь предложений (HUB-ALIAS-1)

Имена хабов читает один каталог (`core/retrieval/hubcat.py::hub_catalog`); доктор «Хабы: имена» показывает хабы без
`aliases`, без H1 и алиасы-дубли. Ночной шаг `hub_scan` (в цепочке `index`; точечно `uv run python cli/dt_hub_scan.py`)
после очереди кандидатов в хабы пополняет очередь алиасов `.derived/hub_alias_candidates.jsonl`: для хаба без явных
алиасов - имена из H1, организаций сделок Timetta (имя и код), меток доменов почтовых тредов хаба, имен клиентских
папок легаси (у каждого имени - источники и счетчик подтверждений; имя, которое уже носит другой хаб, помечено
«конфликт»). Строка = хаб (идемпотентно). Сверка при следующем скане: хаб получил `aliases` руками и предлагать нечего
→ `resolved`; `rejected` - навсегда; `snoozed` - до даты. Решения - карточка «Алиасы хаба?» в «Требуют решения»
(«Принять выбранные» дописывает `aliases` во frontmatter хаба, остальной файл не меняется); автозаписи нет, vault движок
сам не правит. Очередь - производная, в бэкапе `.derived` (ledgers), пересобирается тем же `dt_hub_scan`.

## Линт знаний: шаг `lint`, `dt lint`, доктор (KNOWLEDGE-LINT-1)

Шаг `lint` в цепочке `index` стоит ПОСЛЕ `hub_scan` и до `reindex_inc`: четыре детерминированных правила
(`fact_conflict`, `hub_stale`, `orphan`, `duplicate`; без модели) читают vault, стор фактов, манифест индекса и
`link_proposals.jsonl` и обновляют `.derived/lint_findings.jsonl` (upsert по стабильному id; исчезнувшая причина -
`resolved`; `dismiss` - стоп на `DT_LINT_SNOOZE_DAYS`). Бюджет `DT_LINT_BUDGET_S` (120 с) делится на весь шаг,
правила идут от дешевых к дорогим (`hub_stale` собирает дельту хабов - самое долгое); вышел бюджет - правило честно
`partial` (находки, уже найденные, сохраняются; «исчезнувшие» по такому правилу не снимаются). Шаг печатает только
счетчики (без названий), код всегда 0, тайминг - в `steps` маяка цепочки (`dt-sync-index.json`) и в логе
(`step lint: ok за N с`). Точечно: `dt_sync.py index --steps lint`.

Вручную: `uv run python cli/dt.py lint --dry-run` (что нашли бы, НИЧЕГО не пишет: ни стор, ни сводку),
`dt lint --rule orphan` (одно правило, с записью находок), `--json`, `--all`, `--budget N`. Решения - карточки вида
`lint` в «Требуют решения»; в vault и стор фактов пишет только действие карточки (хирургически, остальной файл
байт-в-байт, аудит `lint_<действие>` в `pult-actions.log` и событие `lint/<правило>_applied`). Писатели `.derived` -
`lint_findings.jsonl` и `lint_last.json` (в `tests/_derived_allowlist.py`: интерактивные). Ручки: `DT_LINT_HUB_STALE_DAYS`
(60), `DT_LINT_ORPHAN_DAYS` (14), `DT_LINT_DUP_SCORE` (0.97), `DT_LINT_SNOOZE_DAYS` (30), `DT_LINT_BUDGET_S` (120).
Доктор «Линт знаний»: `ждут решения N (правила); последний прогон …`; `warn` - есть находки старше 30 дней без решения
(или partial последнего прогона называется в деталях).

**SRC-ICLOUD-1: источник в iCloud не локален.** `get_facts(source_path)`/`lift_source` из демона на не скачанный
iCloud-файл (dataless) раньше падали `[Errno 11] Resource deadlock avoided` (launchd не материализует iCloud; из
foreground CLI файл скачивается). Теперь резолвер перед чтением проверяет `st_flags & SF_DATALESS`, делает одну
попытку `brctl download` с таймаутом `DT_ICLOUD_DOWNLOAD_S` (20 с); не скачалось - `status: "not_local"` и конверт
`{code: "source_not_local", reason, hint}` у `lift_source`, `get_facts`, `resolve` (`unresolved[].code`), OCR (счетчик
`not_local`, строка `skip: source_not_local`) и `file_ingest` (`pending_download` с `reason: source_not_local`);
шаг не падает. Прогреть вручную: открыть файл в Finder или `brctl download <путь>` (массового скачивания нет).
Доктор «Источники: iCloud» считает файлы ingest-корней с флагом dataless (по `lstat`, без чтения; бюджет 5 с -
`partial` назван), вне macOS - «не применимо».

## Синтез состояния хаба: стор и доктор (HUB-SYNTH-1)

Предложения «Состояние хаба?» лежат в `.derived/hub_synth.jsonl` (под `DT_DERIVED_ROOT`): одна строка на
карточку - `{id, hub_id, text, sources, covered_until, created, host, model, status: pending|applied|rejected|
snoozed, diff, uncovered, items, source_meta, style}`. Стор производный (в бэкап `.derived` входит, из vault
не пересобирается: текст предложения не существует нигде, кроме стора, пока К. не решил); отказ (`rejected`)
дополнительно служит стоп-периодом по хабу (`stop_until` = решение + `DT_SYNTH_SNOOZE_DAYS`, 14). Писатели -
`hub_synth_propose` / `pult_ai(hub_synth)` / решение карточки (в `tests/_derived_allowlist.py`: интерактивные).
В vault пишет ТОЛЬКО approve карточки (`hub_notes.upsert_section`, архив прежней секции в хабе, аудит
`hub_synth_apply` в `pult-actions.log` без текста, событие `hub/synth_applied` в журнале стадий).

Ручки (реестр `core/config/knobs.py`): `DT_SYNTH_CONTEXT_CHARS` (40000, бюджет дельты в досье),
`DT_SYNTH_MAX_CHARS` (6000, предел длины секции), `DT_SYNTH_SNOOZE_DAYS` (14, стоп после отказа),
`DT_SYNTH_STALE_DAYS` (60, когда состояние «просит сводку»). Расписания и автосинтеза нет.

Доктор «Синтез хабов»: `ждут решения N; последний синтез <дата|нет>; хабов с состоянием M`; `warn` - от трех
хабов-клиентов, у которых секция «Состояние»/`synth_at` старше `DT_SYNTH_STALE_DAYS` и набралось >= 3 новых
элементов дельты («N хабов просят сводку: id (+дельта)…»; это зерно KNOWLEDGE-LINT-1). Хабы, по которым
синтеза не было, не считаются. Строка попадает в снимок доктора, `pult_monitor.health` видит ее сам.
Откат записи: прежняя секция лежит под «## Архив состояний» в самом хабе (и в git vault).

## Факты во времени: миграция v4 и бэкфилл (FACTS-BITEMPORAL-1)

Схема `dt.db` v4 добавляет `facts` две оси времени и цепочку версий (`valid_from/valid_to/known_at/superseded_*/prev_fact_id/
fact_key/provisional/date_basis`). Миграция применяется при первом открытии БД (`dt doctor`, любой `get_facts`), идемпотентна,
строк не теряет и заполняет колонки из самой БД (`known_at` = `sources.mtime`, `valid_from` по имени файла, иначе mtime).
Откат - из бэкапа (`dt backup` ДО первого открытия новым движком; обратной миграции нет). Второй шаг - явный и с отчетом:

```bash
uv run python cli/dt.py facts backfill --dry-run   # план: атрибуция к хабу, черновики, цепочки, сколько уйдет из дефолтной выдачи
uv run python cli/dt.py facts backfill             # применить (повтор ничего не меняет)
uv run python cli/dt.py facts versions "/путь/к/файлу.xlsx"   # цепочка версий семейства и «было → стало»
```

`--dry-run` читает стор только на чтение (`mode=ro`) и ничего не пишет; на БД без v4 говорит «откройте БД». Бэкфилл меняет
`entity_ref` только там, где источник резолвится в ОДИН клиентский хаб (иначе прежнее), и пересобирает цепочки по семействам
(`family_of`, маркеры `draft`/`archived` из `_system/freshness-markers.yaml` не меняются). После прогона - доктор «Факты: время».
Дефолтная выдача `get_facts` теперь скрывает вытесненные версии: `include_superseded=true` возвращает вручную всю историю.

## Профиль инструментов и конфиги хостов (TOOLS-PROFILES-1)

MCP-сервер (`mcp-server/server.py`) - не launchd-демон, его поднимает хост. Профиль набора
инструментов - аргумент `--profile lean|pult|full` или env `DT_TOOL_PROFILE` (дефолт `full`);
`DT_TOOL_DESC_CHARS` усекает описания. Конфиг хоста печатает `uv run python cli/dt.py host-config
claude|cursor|kimi --profile lean` (в чужие конфиги не пишет); песочница производных для чужого
хоста - `--sandbox <каталог>` (= `DT_DERIVED_ROOT`, см. раздел про переменные путей выше).

## Хосты: выходы, золотые задачи генерации, плагин Kimi (MODEL-1-CLOSE)

Launchd-заданий нет: все три - команды по требованию (хост живет в своем процессе).
- `uv run python cli/dt_eval.py --generation [--host kimi] [--since YYYY-MM-DD] [--json] [--no-record]` -
  таблица «задача × хост» по `07-outputs` (читает `meta.yaml`/`prompt.md`/`sources.md`/`output.md` и
  журнал метрик, без LLM и сети); точка на хост дописывается в `.derived/eval/generation.jsonl`
  (`--no-record` - не писать). Канон задач - `vault/_system/eval/golden-generation.yaml` (К. правит как
  заметку; невалидный - код `golden_*` и код возврата 1).
- `uv run python cli/dt.py plugin kimi --out DIR` - сборка плагина Kimi + самопроверка сервера;
  статус - `.derived/status/kimi-plugin.json` (строка доктора «Плагин Kimi»: нет сборки - справка;
  самопроверка не прошла / реестр скиллов изменился после сборки / каталога нет - warn). Только
  самопроверка: `... plugin kimi --selftest`.
- Доктор «Хосты: выходы»: выход без `host` в мете после того, как движок начал штамповать хост -
  warn (дефект гигиены; старые папки не бэкфиллятся); хост в телеметрии без выходов - справка (ok).
  Выходы по хостам за 30 дн - `pult_kpi.outputs`.
- Лок выбора имени папки выхода - `.derived/outputs-claim.lock` (короткий flock; два хоста не делят
  папку).

## Реранкер `find_notes` (RETR-RERANK-1)

Второй этап ранжирования — локальный cross-encoder `BAAI/bge-reranker-v2-m3` (та же семья, что
эмбеддер BGE-M3; не LLM, сети при работе нет). Модель лежит в `models/` (рядом с BGE-M3), в git не
входит. **Скачивается один раз** явным онлайн-прогревом (по умолчанию движок офлайн, Path B):

```bash
DT_MODEL_DOWNLOAD=1 uv run python -c "from core.retrieval.rerank import rerank, RerankCand; rerank('прогрев', [RerankCand('x', 'прогрев')])"
```

(`DT_MODEL_DOWNLOAD=1` и `DT_EMBED_ALLOW_DOWNLOAD=1` равнозначны; снапшот ~2 ГБ, safetensors fp32.)
Без модели и при выключенном реранкере поиск идёт как раньше; с `DT_RERANK=1` и без модели в каждой
выдаче `find_notes` — конверт `rerank_unavailable` (доктор: «Реранкер» = warn «модель не скачана»).

| Ручка | Дефолт | Что делает |
| --- | --- | --- |
| `DT_RERANK` | 0 в коде; **1 в боевом `.env`** (решение К. 29.10 по абляции) | Включить реранкер (`1`). В коде выкл - инвариант «байт в байт» для тестов и чужих установок |
| `DT_RERANK_POOL` / `DT_RERANK_ALPHA` | 15 / 0.7 | Пул переоценки и вес реранкера в `α·score01 + (1-α)·fused`. Живая абляция 29.10 (с гейтом одного слова): 15 / 512 токенов - recall@5 0.87, MRR 0.79, p50 ~2,7 с; 20 / 256 - 0.83 / 0.73 при 2,1 с (обрезка пары режет цель); 30 / 512 - MRR 0.79 при p50 4,8 с |
| `DT_RERANK_MAX_LENGTH` / `DT_RERANK_CHUNK_CHARS` / `DT_RERANK_BODY_CHARS` | 512 / 1200 / 800 | Токенов на пару и сколько символов чанка/тела идет в пару; цена инференса растет с длиной |
| `DT_RERANK_MIN_TOKENS` | 2 | Реранкер - от двух значимых слов запроса (одно редкое слово - точный BM25 надежнее: q11) |
| `DT_FIND_SEMANTIC_ALWAYS` | 0 | Семантика в пул всегда (не лестница по порогу). Абляция 29.10: с реранкером роняет recall@5 0.85 → 0.82 - выключено независимо от `DT_RERANK` |
| `DT_RERANK_DEVICE` | авто | `mps`/`cpu`; по умолчанию как у эмбеддера, OOM → батч/2 → откат на CPU |

**Прогрев.** Модель грузится при ПЕРВОМ поиске с реранкером в процессе (MPS: ~7 с; процесс MCP-сервера
держит один экземпляр, веб-пульт — свой). Доктор показывает «не прогрета / прогрета (N с)» и устройство.
Телеметрия — поля `rerank_ms` / `rerank_pool` / `rerank_device` в событии `tool_call` (p50/p95 за
7 дней — `pult_kpi.usage.rerank`).

**Абляция (обязательна для решения по дефолтам):**

```bash
uv run --extra parsers --extra operational python cli/dt_eval.py --ablation
uv run ... python cli/dt_eval.py --rerank on --semantic-always off   # один вариант (б)
```

Четыре варианта: (а) база, (б) реранкер, (в) реранкер + семантика всегда, (г) только семантика всегда.
Прогоны с флагами и `--ablation` в историю не пишутся и с прошлым не сравниваются (другая
конфигурация выдачи несравнима); обычный прогон пишет `rerank` / `semantic_always` в точку истории.

## Сканы: OCR (OCR-1)

pdf без текстового слоя получают заметку-заглушку сразу (`ocr: pending`), распознавание идет отдельным
контуром с бюджетом: шаг `ocr` в `dt_sync index` (перед `file_ingest_knowledge`), вручную - `cli/dt_ocr.py`.

**Зависимости (brew, один раз):** `brew install tesseract tesseract-lang ghostscript` (нужны языки `rus`, `eng`,
по желанию `kaz`). Нет `tesseract`/`gs` - шаг печатает `unavailable (ocr_unavailable)` и выходит с кодом 0, заглушки
остаются, доктор «OCR» = warn. Apple Vision - необязательный движок (extra `ocr-vision`, только macOS):
`uv sync --extra ocr-vision` (или `--all-extras`) и `DT_OCR_ENGINE=vision` в `.env`. Решение К. 29.10: на боевой
машине - Vision (~0,8-1 с/страница против 2-4 у tesseract, качество сопоставимое), дефолт кода - tesseract
(переносимо, для инсталлера).

```bash
uv run python cli/dt_ocr.py --dry-run                       # очередь, отказы по приватности, оценка; OCR не идет
uv run python cli/dt_ocr.py --limit 20                      # канарейка: 20 документов
uv run python cli/dt_ocr.py --budget 600 --path-scope "2018-2023/00. Presale"
uv run python cli/dt_ingest.py --apply --route knowledge    # перерисовать заметки с текстом распознанных
```

| Переменная | Дефолт | Смысл |
|---|---|---|
| `DT_OCR_ENGINE` | `tesseract` | `tesseract` или `vision` (если установлен `pyobjc-framework-Vision`) |
| `DT_OCR_LANGS` | `rus+eng` | Языки; `rus+eng+kaz` - по желанию (+15% времени) |
| `DT_OCR_BUDGET_S` | 1800 | Секунд на прогон; обрыв между документами И между страницами (NIGHT-CHAIN-1), страницы недоделанного документа - в чекпойнте |
| `DT_OCR_MIN_CONF` | 0,6 | Средняя уверенность ниже порога - заметка с телом, но `ocr: low` и `ocr_low_confidence` в журнале отказов |

Где что: кэш результатов `.derived/ocr/<байтовый хэш файла>.json` (запись = чекпойнт документа; смена `OCR_VERSION`
обесценивает), журнал `.derived/ocr/journal.jsonl` (без путей и текста), снимок очереди `.derived/ocr/queue.json`,
рабочие png - `.derived/ocr/tmp` (НЕ `/tmp`: из-под MCP-шелла `/tmp` недоступен). Недоделанный документ (бюджет, SIGTERM, сон, kill) сохраняется постранично в
`.derived/ocr/partial/<хэш>.jsonl` (только страницы, прошедшие текстовый гард; итог документа в кэш пишется целиком,
после него чекпойнт снимается) - следующий прогон продолжает с первой нераспознанной страницы (чекпойнт другого
движка/языка не подмешивается). Итог последнего прогона - `.derived/ocr/runs/last.json` (для доктора «OCR»: «бюджет
исчерпан на документе X, страниц Y/Z»), прогресс - строки `[ocr]` в `dt-sync.log` раз в 25 страниц и итог шага. Очередь - записи L1-кэша `.derived/legacy_extracted` с `needs_ocr`; приватное по пути/имени
(`vault/_system/ocr-privacy.yaml` + правила легаси-приватности + NDA) не распознается вовсе (`ocr: refused`), по
содержимому (ИИН, номер паспорта, дата рождения + ФИО) - распознается, но текст НЕ сохраняется (`ocr: refused_text`).
Словарь приватности дополняется текстом в vault (дефолты в `core/ocr/privacy.DEFAULT_YAML` вычитать нельзя). Ночной
бюджет - решение К. (по замеру 29.10: tesseract ~3,7 с/страницу, Vision ~0,8; очередь 6323 страницы).

## Ночная цепочка: шаги, бюджеты, где смотреть время (NIGHT-CHAIN-1)

`com.dt.sync.index` (03:00) = `dt_sync index`, шаги по порядку: `ocr` (бюджет `DT_OCR_BUDGET_S`, 30 мин, по страницам) →
`file_ingest_knowledge` → `link_auto` → `hub_scan` → `reindex_inc` (вектора считает демон, см. ниже) → `eval` → `doctor`.
Ночь 30.10 для справки: цепочка 03:07 → 08:00; `ocr` 3 ч 54 мин (бюджет проверялся между документами), `reindex_inc`
40 мин (вторая копия модели, MPS OOM → CPU), `link_auto` 20 с, `hub_scan` 3 с - линковка узким местом не была.

**Где смотреть время.**

| Что | Где |
|---|---|
| Время по шагам | `.derived/status/dt-sync-index.json`, раздел `steps`: `{шаг: {started, finished, elapsed_s, exit[, device, fallback]}}` (шаг, идущий сейчас, - только `started`; `exit` 0/1; `device`/`fallback` у `reindex_inc` - из отчета этого прогона). `fast`/`full` пишут в `dt-sync.json` |
| Строка лога | `dt-sync.log`: `step ocr: ok за 1801.4 с` (формат для парсеров свежести цел) |
| Доктор | «Ночная цепочка»: общее время, три самых долгих шага; **warn**, если общее > `DT_NIGHT_CHAIN_MAX_H` (3 ч), либо `ocr` > бюджета × 1,5, либо `reindex_inc` шел на CPU (без явного `DT_EMBED_DEVICE=cpu`) |
| Пульт | карточка сервиса `sync.index` («Движок»): последний прогон, топ-3 шага, ошибки - `pult_services` → `last_run` (та же функция чтения `core/nightchain.py`, что у доктора) |
| OCR | доктор «OCR»: очередь, неделя, «бюджет исчерпан на документе X, страниц Y/Z»; журнал `[ocr]` в `dt-sync.log` |

**Один эмбеддер на машину.** Модель BGE-M3 держит демон (`com.dt.server`); `dt_index`/`dt_eval` и любой
процесс, не владеющий моделью, получают вектора у демона: `POST /internal/embed` (loopback, rw-токен; описание -
`mcp-server/README.md`). `DT_EMBED_VIA_DAEMON=1` (дефолт) - ходить к демону при живом `/health`; демона нет, нет rw-токена,
таймаут (`DT_EMBED_DAEMON_TIMEOUT_S`, 300 с) или 5xx - процесс грузит модель сам, как раньше, с одним предупреждением в
лог. `DT_EMBED_VIA_DAEMON=0` - прежнее поведение целиком (своя копия модели). В итоге `dt_index`: `Done [..., device=mps
via daemon]`. Ожидание: `reindex_inc` на MPS демона - минуты вместо 40 и доктор «Эмбеддер: устройство» зеленый.

## Профиль владельца: `dt owner` (PROFILE-1)

Личность владельца живет в vault: `vault/_system/profile/{owner.yaml, about.md, rules.md}` (дизайн
`docs/design-profile-1-owner-boundary.md`, архитектура - `docs/02-architecture.md` §5). Правит владелец
в Obsidian; движок профиль только читает (кэш по mtime - рестарт демона после правки не нужен).

```bash
uv run python cli/dt.py owner init --people Фамилия1 Фамилия2   # один раз: из DT_USER_NAME, DT_OUTLOOK_SELF_TOKENS, DT_TIMETTA_USER_EMAIL, DT_LEGACY_PRIVACY_NAMES
uv run python cli/dt.py owner show                              # что движок видит (поля owner.yaml, размеры блоков, версия, замечания)
uv run python cli/dt.py owner check                             # схема + полнота + about.md + дубли с .env (код 1 при замечаниях; та же функция, что в докторе)
uv run python cli/dt.py owner export > owner-rules.md           # правила + ядро about.md одним markdown для памяти клиента
```

* `init` создает три файла; существующий файл без `--force` не трогается, с `--force` - перезапись с
  бэкапом `<файл>.bak-<ts>`. Секретов в профиль не пишет. `about.md`/`rules.md` - шаблоны (заголовки и
  подсказки в HTML-комментариях, выдуманного текста нет; такой файл считается пустым).
* **Фамилии коллег (`privacy.people`) из кода убраны:** `init` берет их из `DT_LEGACY_PRIVACY_NAMES` и
  `--people`. Пока профиля нет и список пуст, личные документы этих людей (зарплата/ГПХ/HR) НЕ
  фильтруются - `dt config check` предупреждает; запускайте `init --people ...` ДО первой индексации
  после обновления.
* После `init` уберите `DT_USER_NAME` и `DT_OUTLOOK_SELF_TOKENS` из `.env` (`dt config check` называет
  дубль): профиль главнее, `.env` - добавка. `DT_TIMETTA_USER_EMAIL` остается (нужен Timetta).
* Хостам: инструмент `owner_profile` (все профили инструментов), скилл `dt-owner` в
  `dt skills export cowork|kimi|cherry` (нет профиля или `rules.md` пуст - не создается, причина в
  `skipped`). Состояние - доктор «Профиль владельца» и карточка «Владелец» в настройках пульта.

## Приватный список и гард кита (KIT-PRIVACY-1)

Кит не должен нести имен из данных владельца: ни его собственных, ни клиентов. Список терминов собирает ОДИН
сборщик (`core/owner/privacy.py`) из vault: `owner.yaml` (имя, варианты, фамилии, компания, домены) + хабы
`04-clients` (`title`, `aliases`, имена из H1, слаг и части слага ≥ 5 знаков, id) + явные `aliases` хабов
`02-knowledge`/`03-projects`; минимальная длина 4, без регистра, NFC/NFD, границы слова (дефис и `_` - граница).

| где используется | что делает при совпадении |
|---|---|
| `tests/test_owner_company.py::test_no_private_terms_in_shipped_code` | красный тест, `файл:строка:термин`; область - ровно состав кита (`SHIPPED_DIRS`, docs, installer, skills) |
| `scripts/build_vault_template.py` | отказ (код 1), дерево шаблона не пишется; в копиях политик приватные термины заменяются на `company` |
| `scripts/build_starter_kit.py` | отказ, zip не пишется; `--check` дополнительно прогоняет независимый проход |
| `scripts/verify_starter_kit.py` | независимая реализация (ручной поиск по границам слова) по тому же списку |

Не в кит: `cli/_oneoff/`, `scripts/demo_policy.py`, `scripts/retr_chunk_canary.py`, `scripts/smoke_retrieval.py` (id
и клиенты боевого vault зашиты в константы), `scripts/privacy-ignore.txt`, `tests/`, `docs/tz|audit|findings|incidents`.

**Исключения.** `scripts/privacy-ignore.txt` - по строке `термин # причина`; только общеупотребительные совпадения и
только по явному решению владельца (сейчас так решены три слова). Термин из файла, которого нет в vault, - мусор:
сборка кита, шаблона и гард тестов отказывают. `--privacy-ignore PATH` у обоих генераторов подставляет другой файл
(тесты на синтетическом vault берут пустой).

**Что гард не ловит:** имена короче 4 знаков (сокращения) и склоненные формы («Акме» ловится, «Акму» - нет): такое
ищут глазами при ревизии (`grep -ri` по распакованному киту: при приемке 0 совпадений по всем терминам).

## Снимки тяжелых чтений пульта (PULT-SURFACE-2)

Принцип: read-инструмент пульта **не считает тяжелое** (доктор ~10 с, скан NDA-следов по `.derived` и
статистика LanceDB ~6 с, обход vault за `linked_hub` ~5 с, реранкер кандидатов в золотой набор) - он читает
снимок. Расчет делает ночная цепочка либо явный `refresh=true` (кнопка в пульте).

| Что | Где лежит | TTL (knob) | Кто обновляет |
|---|---|---|---|
| `doctor()` | `.derived/status/cache/doctor.json` (`{as_of, elapsed_ms, payload}`) | `DT_PULT_DOCTOR_TTL_S`, 1800 с | ночной шаг `doctor`, CLI `dt-doctor` (живой расчет, как прежде, + пишет снимок), `doctor(refresh=true)` |
| `pult_storage_status()` | `.derived/status/cache/storage.json` | `DT_PULT_STORAGE_TTL_S`, 900 с | `refresh=true`; `pult_storage_action` сбрасывает снимок |
| `pult_deals()` | `.derived/status/cache/deals-<хэш client/rings>.json` | `DT_PULT_DEALS_TTL_S`, 300 с | протухает раньше при обновлении зеркала Timetta (mtime `deals.json`/`orbit.json`) и при связи/развязке хаба; `refresh=true` |
| `pult_cards` вид `gold` | `.derived/eval/candidates.json` (`refreshed_at`) | нет: на чтении не считается | ночной шаг `eval` (после прогона золотого набора, пока индекс/модель теплые); `pult_cards(refresh=true)` |

Файл снимка - `{as_of, elapsed_ms, stamp?, payload}`; запись атомарна (tmp + replace), расчет под локом
(параллельные вызовы дают один расчет), битый файл - пересчет без падения. Ответы инструментов получают
`as_of` и `cached` (`pult_deals` отдает прежний список - метаданные только в самом снимке). Снять снимок
руками - удалить файл из `.derived/status/cache/`. «Одной карточкой» читает их `pult_monitor()`: без снимка
блок говорит `{available: false}`, ничего не запускается.

Пульт (`webpult/pult.html`): boot грузит только активную вкладку (+ шапку: очередь, инбокс, kpi, «дозрели»);
доктор, хранилище и живые API на boot не зовутся. Опрос «Сейчас работает» после запуска синка - с бэкоффом
3→5→10→20→30 с (≤ ~35 вызовов на 15 минут). Вкладка «Мониторинг» - один вызов `pult_monitor` (карточка
«Движок»: здоровье, ночная цепочка, синхронизация и сервисы, задания и активность, свежесть, хранилище) +
«Журнал». Остановка `sync.fast`/`sync.index` в карточке подписана «Пауза» (плановый захват), старт -
«Возобновить» (`pult_service_control`, launchd bootout/bootstrap, не изменился).

## Гигиена: бэкапы `.bak`, журнал аудита, vault под git (SURFACE-HYGIENE-1)

* **`dt backup prune-bak [--keep 5] [--dry-run]`** (`uv run python cli/dt.py backup prune-bak`; то же -
  `cli/dt_backup.py prune-bak`) - ротация `<имя>.bak-<метка>` рядом с `.env` (корень `engine/`), в корне
  `.derived` и у копии артефакта пульта (`DT_BAK_ROOTS`, по умолчанию `~/Claude/Artifacts/dt-pult`). На каждый
  файл остаются `--keep` самых свежих. Удаляются только файлы по шаблону `*.bak-*` на верхнем уровне корня:
  `*.bak` без метки, подкаталоги, симлинки и сам журнал не трогаются. Сначала всегда `--dry-run` - он печатает
  «оставлено/удалилось бы» по корням. Доктор **«Бэкапы .bak»**: `warn`, если в корне больше `DT_BAK_WARN_COUNT`
  (10) файлов.
* **Журнал `pult-actions.log`.** Парсер (`core.operational.pult.parse_action_line`) явно отбрасывает строки с
  невалидным `ts`. Разовая чистка 6 тестовых строк `ts="T"`: `uv run python cli/_oneoff/dt_clean_actions_log.py`
  (dry-run) → `--apply` (сначала бэкап `<журнал>.bak-<метка>`); `prune-bak` журнал не трогает.
* **Доктор «Vault: git»** (только чтение: `git status --porcelain` + `git log -1`): `warn`, если незакоммиченных
  путей больше `DT_VAULT_DIRTY_MAX` (200) или последний коммит старше `DT_VAULT_COMMIT_MAX_DAYS` (7). Vault
  коммитится руками; движок в git vault не пишет.
* **`cli/_oneoff/`** - разовые миграции (что/когда/зачем - в `cli/_oneoff/README.md`); сняты и CLI без
  потребителей (`dt_link_propose`, `dt_link_apply`, `dt_mail_probe`, `dt_exemplar`, `dt_lift`, `dt_plan`,
  `dt_ingest_current`: то же делают `dt_link` и инструменты MCP).
* **Таблицы выше** (режимы `dt_sync`, задания launchd) генерируются: `uv run python scripts/ops_tables.py`,
  гард `tests/test_cli_inventory.py`. Справочник инструментов - `docs/08-tools-reference.md`
  (`scripts/tools_reference.py`).
* **Детектор хабов по кольцам.** `dt_hub_scan` печатает «сделок без хаба (strong / чужие unit)» и «снято
  ring_unit»: pending от чужой сделки без упоминаний снимается сверкой (`resolved`, причина `ring_unit`;
  обратимо). Доктор **«Хабы: кандидаты»**: `warn`, если есть pending старше 30 дней без решения.

## Выходы: прогоны eval/selftest, `dt outputs mark` (EVAL-HYGIENE-1)

* **`dt outputs mark [--dry-run] [--force] [--json]`** (`uv run python cli/dt.py outputs mark`; код -
  `cli/dt_outputs.py`, `core/outputs_mark.py`) - ретро-пометка прошлых выходов тем же выводом, что у живого
  контура (`purpose`: постановка = фраза золотой задачи `golden-generation.yaml` → `eval` + `eval_task`;
  тестовый хост `shim-test`/`dt-spike-*`/`idle-test` → `selftest`). `--dry-run` печатает план (что пометить,
  какие файлы «откуда → куда», какие selftest-папки удалить) и ничего не пишет; без флага: помечает (`meta.yaml` +
  frontmatter через писатели движка), переносит доставленные файлы из папок клиентов в
  `<корень>/_eval/<ГГГГ-ММ>/<папка выхода>/` (только наша доставка: на диске ровно sha из `meta.delivered`;
  правленный снаружи/пропавший/dataless - пропуск с причиной, не потеря; `--force` переносит и правленный
  снаружи файл - решение владельца «прогон остается прогоном», sha доставки в мете не переписывается; `meta.delivered` получает новый путь и
  `intended_dest`), удаляет selftest-папки (`-t` и подобные; не удаляет, если у них остались непереносимые
  файлы). Eval-выходы НЕ удаляются: eval-история (`dt_eval --generation`) читает помеченные. Идемпотентно.
  Отчет-бэкап списка (до и после) - `.derived/outputs_mark.json`. Первый боевой прогон - после `--dry-run` и
  vault-чекпойнта (коммит vault руками).
* Доктор **«Выходы: прогоны»**: `eval N, selftest M`; `warn` - доставка прогона вне `_eval`, selftest-папка в
  `07-outputs`, выход определяется как прогон, но не помечен (лекарство - `dt outputs mark`).
* Ручки: `DT_SELFTEST=1` - процесс считается самопроверкой (выходы `selftest`, доставка в `_eval`);
  `DT_EVAL_SESSION_H` (2) - окно «сессии прогона» для `place_download`/`store_file*`.
* Гард тестов: `tests/_vault_guard.py` - снимок боевого vault (`07-outputs` + `git status`) и запрет
  `socket.connect` на боевой порт демона; отладка снимка - `DT_SANDBOX_SNAPSHOT=0`.

## Выходы: провенанс сессии, `dt outputs sources` (PROV-SESSION-1)

* **`dt outputs sources [--since ГГГГ-ММ-ДД] [--dry-run] [--json]`** (`uv run python cli/dt.py outputs sources`; код - `cli/dt_outputs.py`, `core/outputs_sources.py`) - ретро сессионного провенанса: рабочим выходам, окно которых покрыто журналом запросов (`.derived/eval/queries.jsonl`, с 24.10), дописываются автосекции «## Прочитано в сессии»/«## Поиск в сессии» в `sources.md` (ad-hoc-выход без `sources.md` получает файл целиком; движковые чанки и старые таблицы не трогаются). У старых записей журнала `sid` нет - сегмент по хосту и времени, границы - по аудиту `save_output` (`pult-actions.log`). Выходы вне журнала, прогоны eval/selftest и выходы, у которых секции уже есть, пропускаются с причиной. Идемпотентно (второй прогон - ноль изменений); `--dry-run` печатает план «выход → read/lift/facts, поисков» и ничего не пишет. Отчет-бэкап списка (до и после) - `.derived/outputs_sources.json`. Живой прогон - после `--dry-run` и vault-чекпойнта.
* Доктор **«Выходы: провенанс»**: за 30 дн ad-hoc-выходов всего / с телеметрией сессии (`read`/`lift`/`facts`/поиск) / только руками / без провенанса (движковые - отдельным счетом); `warn` - без провенанса есть выход за 7 дн ИЛИ журнал выключен (`DT_EVAL_QUERY_LOG=0` гасит и провенанс сессии). Строка «Выход без источников (SRC-TRACE-2)» прежняя.
* Ручки: `DT_ADHOC_SOURCES_H` (8) - потолок окна сбора; `DT_PROV_LATE_BEGIN_MIN` (3) - порог «позднего» `output_begin`.

## Коннекторы: что включено у экземпляра (DEV-3-CORE)

Внешние сервисы - `timetta` (CRM, зеркало только чтение), `ticktick` (захваты по тегам), `outlook` (почта и
календарь через Classic Outlook) - выключаются одной настройкой `DT_CONNECTORS` (реестр
`core/connectors.py`, `uv run python cli/dt.py config show`):

| значение | что значит |
|---|---|
| не задан / `auto` | дефолт, поведение как до коннекторов: включен тот, чей `requires` есть - секрет (`TIMETTA_API_TOKEN`, `TICKTICK_ACCESS_TOKEN`: `.env` или Keychain) либо ручка (`DT_OUTLOOK_FOLDERS`) |
| `none` | «базовый DT»: знания, поиск, генерация, пульт без CRM/почты/таск-менеджера; `dt_sync fast` - только файлы |
| `timetta,outlook` (список или JSON) | включены ровно перечисленные; секрет не проверяется |

Выключенный коннектор: шаг `dt_sync` пропущен (в логе `шаг mail_ingest пропущен: коннектор outlook
выключен`), строки свежести/«Хранилища» нет, секции пульта (сделки, орбита, функция, встречи, «Дозрели», лента
внимания, если выключены все три) не объявлены, задания `Outlook · …` нет, проверки доктора (токены,
зеркало, орбита, почта, мост Outlook) заменены строкой `ok «коннектор X выключен»`, инструменты отвечают
конвертом `connector_disabled` (`mcp-server/README.md`). Состояние и причина - в «Настройках» пульта (строка
«Коннекторы»; секция появляется, когда что-то выключено) и в `pult_manifest().connectors`.

Проверка: `dt config check` предупреждает о явно включенном коннекторе без секрета и об опечатках в списке;
доктор - строки `Коннектор Timetta|TickTick|Outlook`. Профиль «базовый DT» целиком - `dt config set
DT_CONNECTORS none`; полный pytest при `DT_CONNECTORS=none` зеленый (тест, которому коннекторы нужны,
объявляет `@pytest.mark.connectors`). Личная роль коннекторов в манифесте не объявляет; TickTick-захват
личного экземпляра зависит от того же `DT_CONNECTORS`. Версия движка и схем - `dt version`, релизы -
`CHANGELOG.md`.

## Экземпляры: личный контур как опция развертывания (PERSONAL-1)

Второй экземпляр того же движка на личном vault (дизайн `docs/design-profile-1-owner-boundary.md` §3,
ТЗ `docs/tz/personal-1.md`). Рабочий экземпляр остается как есть (без оверлея, метки `com.dt.*`).

**Установка личного (одна команда, vault и derived создаются; рабочий vault/.derived/.env не трогаются):**

```bash
uv run python cli/dt.py instance add personal --vault ~/Claude/Projects/"Digital twin"/vault-personal --port 8788
launchctl list | grep dt          # три новые метки *-personal
uv run python cli/dt.py instance status
```

Что создает `dt instance add <имя>`:

| Что | Где | Заметки |
|---|---|---|
| оверлей env | `engine/instances/<имя>.env` (в `.gitignore`) | роль, vault, derived, порт, каталог секретов, `DT_EMBED_OWNER=0` + `DT_EMBED_URL`, `DT_WORK_URL`, `DT_WORK_TOKEN_FILE`; `DT_INSTANCE` в оверлее нет - его ставит plist |
| секреты экземпляра | `<workspace>/.secrets-<имя>/` (700) | свои `web_token`/`web_token_rw`; `work_token` - копия токена ЧТЕНИЯ рабочего (никогда `_rw`); `embed_token` - узкий токен эмбеддера |
| derived | `<workspace>/.derived-<имя>/` | свой индекс, dedup захвата, очередь `bridge.jsonl`, логи |
| каркас vault | `--vault` (`core/vault_template`, `dt vault init --kind personal`) | `_system/` (профиль - копия `owner.yaml`, канон ИИ-маркеров), `_staging/inbox`, `02-notes`, `05-journal`, `06-content`, `07-outputs`, `README.md` с правилом границы |
| plist-ы | `~/Library/LaunchAgents/` | `com.dt.server-<имя>` (демон, bind 127.0.0.1), `com.dt.sync.fast-<имя>` (30 мин, `--steps pull_capture,file_ingest`), `com.dt.sync.index-<имя>` (03:30, цепочка + `bridge`); все с `EnvironmentVariables: DT_INSTANCE` |

Единственная запись в рабочие секреты - `embed_token` (если его там еще нет): узкий токен, открывающий
рабочему демону только `/internal/embed` для личного. Токен чтения рабочего берется из `.secrets/web_token`
(нет файла - мост даст `work_unavailable`, пока он не появится: `dt web-token show read`).

Команды: `dt instance add|list|status|remove` (`remove` снимает plist-ы и оверлей; vault, derived, секреты не
трогает), `dt bridge [--dry-run] [--limit N] [--probe-level]` (скан связей), `dt vault init --kind
work|personal`, `dt host-config <хост> --instance personal` (запись `digital-twin-personal`). Пульт
личного - тот же `pult.html` на порту экземпляра; карточки `bridge` приходят в «Требуют решения»
(`pult_cards`), решения - `pult_card_decide`.

Захват: тот же проект TickTick, свой dedup-стейт. `#дневник` → `05-journal/ГГГГ-ММ-ДД.md` (секция `## ЧЧ:ММ`),
`#контент`/`#личное` → инбокс личного (`lane: content|personal`). Рабочий контур теги `#личное`, `#дневник`,
`#контент` отбрасывает до записи.

Проверка: `/health` экземпляра отдает `instance: {name, role, embed_owner}` (у рабочего ключа нет); доктор
личного - строки «Экземпляр» и «Мост»; RSS личного демона мал (модель не грузится).

### Экземпляр на существующем vault (PERSONAL-2)

Личный экземпляр можно посадить на живой Obsidian-vault, у которого уже своя структура (в том числе в
OneDrive/iCloud). Папки, куда движок пишет, задаются ручками оверлея; без них - канон каркаса, как раньше.

```bash
uv run python cli/dt.py instance add personal --vault "<путь к vault>" --port 8788 \
  --journal-dir Journal --ideas-dir Ideas --content-dirs "Podcasts,Articles,Books"
uv run python cli/dt.py instance set personal DT_PERSONAL_IDEAS_DIR "Random thoughts"   # правка ручки оверлея
```

| Ручка (оверлей) | Что задает | По умолчанию |
|---|---|---|
| `DT_PERSONAL_JOURNAL_DIR` | куда `#дневник` пишет `ГГГГ-ММ-ДД.md` | `05-journal` |
| `DT_PERSONAL_IDEAS_DIR` | куда `#личное` ложится заметкой идеи (`tags: [idea]`, имя - первая строка) | пусто: `#личное` идет в инбокс, как в PERSONAL-1 |
| `DT_PERSONAL_CONTENT_DIRS` | папки контента (подкасты/статьи/книги) для скилла разбора | пусто |
| `DT_PERSONAL_INBOX` | инбокс личного | `_staging/inbox` |
| `DT_BRIDGE_EXCLUDE` | глобы заметок, чей текст НЕ уходит рабочему демону при скане моста | `Templates/**`; пустое значение - без исключений |
| `DT_INDEX_EXCLUDE` | что не индексировать (только личная роль) | `Templates/**,.smart-*/**,.trash/**`; у рабочего исключений нет |

Правила: все пути - относительные внутри vault (абсолютный, `..` и выход через симлинк отклоняются);
глобы - без учета регистра и в NFC, `**` - любая вложенность. Исключение для моста стоит ДО запроса к
рабочему демону: текст такой заметки в запрос не попадает, карточки новых исключенных заметок снимаются,
принятые связи остаются.

**Что `instance add` создает в непустом vault (или при заданных папках):** только `_system/` (ingest-roots,
profile, style-guides), инбокс и папки дневника/идей, если их не было. НЕ создаются `README.md`, `02-notes`,
`05-journal`, `06-content`, `07-outputs`; `.obsidian`, шаблоны владельца и существующие заметки не трогаются.
Пустой vault без ручек получает прежний полный каркас.

**OneDrive.** Файлы «по требованию» (dataless) движок не читает вслепую: `fsguard` узнает облачный корень
(`CloudStorage/OneDrive*`, iCloud), читает с таймаутом, при недоступности дает подсказку «закрепите папку
(Always Keep on This Device)». Доктор показывает строку «Источники: не локальны» для личного vault.

**Администрирование из пульта.** Пульт личного экземпляра (порт экземпляра, либо переключатель «Работа |
Личное» в артефакте) показывает «Машинное отделение» со службами `com.dt.*-personal`; «Запуск синхронизации»
гоняет шаги личной цепочки (`fast`: `pull_capture,file_ingest`; `index`: цепочка + `bridge`); настройки
`bridge` и `personal` правятся из пульта (`pult_settings_set`) и пишутся в оверлей экземпляра, а не в `.env`.
Рабочие службы и настройки из личного пульта не видны и не управляются.

**PERSONAL-3: источник захвата, мост, запись в Desktop.**

```bash
uv run python cli/dt.py instance add personal --vault "<vault>" --port 8788 \
  --capture-project "Личный захват" --untagged-lane personal \
  --bridge-exclude "Templates/**,Ideas/Self therapy/**"
uv run python cli/dt.py host-config claude --instance personal --install --relaunch
uv run python cli/dt.py bridge --rescan --limit 20      # пересчет связей по новым правилам (канарейка)
```

* **Захват.** `--capture-project` - свой список TickTick личного (имя или id; без него - список
  рабочего, развод идет тегами); `--untagged-lane` - куда класть задачи без тега (`skip` по умолчанию).
  Не `skip` без своего списка нельзя (`same_project`): задача без тега ушла бы в оба vault. Правка -
  из пульта (настройки «Папки личного vault») или `dt instance set <имя> DT_PERSONAL_UNTAGGED_LANE …`;
  доктор «Захват» показывает список и полосу.
* **Desktop.** Claude Desktop перезаписывает свой конфиг при выходе: `--install` при запущенном Desktop
  отклоняется (`desktop_running`); `--relaunch` - выход, ожидание до 60 с (без kill), запись, запуск;
  шаги в выводе и в аудите. После `dt instance add` команда подсказана в выводе; `dt instance status` и
  доктор «Хосты: подключение» показывают, на месте ли запись экземпляра.
* **Мост.** Заглушки шаблонов не опрашиваются (`DT_BRIDGE_MIN_BODY_CHARS`), рабочий корпус - `vault`,
  страницы и слабая лексика отсеиваются, карточка хранит общие термины. `--rescan` снимает ждущие
  карточки, переставшие проходить (`withdrawn`): запускать на боевом с `--limit`.

## Замечания

- **Ноут должен быть включён** (не выключен/не в режиме сна) в момент срабатывания.
  Пропущенные интервалы launchd подхватывает при пробуждении — то есть после сна
  fast/index запустятся один раз, наверстав пропуск, а не за каждый пропущенный интервал.
- `RunAtLoad` гоняет задание сразу при `load` — удобно проверить установку.
- Уведомления об ошибках (macOS notification / почта) — вне scope; смотри логи.
